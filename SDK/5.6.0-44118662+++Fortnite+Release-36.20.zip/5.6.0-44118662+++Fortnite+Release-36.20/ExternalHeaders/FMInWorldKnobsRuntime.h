/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMInWorldKnobsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FMDeviceCablesRuntime.h"
#include "FabricUI.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FabricRuntime.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "FabricMetasoundDataTypes.h"
#include "Engine.h"

// Size: 0xe8
class UFabricChildActorTickSubsystem : public UFortManagedTickSubsystem
{
public:
    TArray<TWeakObjectPtr<UFabricChildActorComponent*>> ChildActorComponentsPendingSpawn() const { return Read<TArray<TWeakObjectPtr<UFabricChildActorComponent*>>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_ChildActorComponentsPendingSpawn(const TArray<TWeakObjectPtr<UFabricChildActorComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricChildActorComponent*>>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x310
class UFabricChildActorComponent : public UChildActorComponent
{
public:
    UFMDeviceCableModulatorPortComponent* InWorldKnobModulatorPort() const { return Read<UFMDeviceCableModulatorPortComponent*>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    bool bUseScreenGrid() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    FVector2D ScreenGridPosition() const { return Read<FVector2D>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: StructProperty)
    FModulatorPortSaveData ModulatorPortSaveData() const { return Read<FModulatorPortSaveData>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x20, Type: StructProperty)
    UClass* CableManagerClassForModulatorPorts() const { return Read<UClass*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ClassProperty)

    void SET_InWorldKnobModulatorPort(const UFMDeviceCableModulatorPortComponent*& Value) { Write<UFMDeviceCableModulatorPortComponent*>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    void SET_bUseScreenGrid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_ScreenGridPosition(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: StructProperty)
    void SET_ModulatorPortSaveData(const FModulatorPortSaveData& Value) { Write<FModulatorPortSaveData>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x20, Type: StructProperty)
    void SET_CableManagerClassForModulatorPorts(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x2e0
class UFabricScreenComponent : public USceneComponent
{
public:
    TWeakObjectPtr<UFabricScreenWidget*> ScreenWidget() const { return Read<TWeakObjectPtr<UFabricScreenWidget*>>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UWidgetComponent*> ScreenWidgetComponent() const { return Read<TWeakObjectPtr<UWidgetComponent*>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: WeakObjectProperty)
    TMap<UFMInWorldKnobActorCopyComponent*, FScreenWidgetLayoutInfo> CopyComponentsToWidget() const { return Read<TMap<UFMInWorldKnobActorCopyComponent*, FScreenWidgetLayoutInfo>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x50, Type: MapProperty)

    void SET_ScreenWidget(const TWeakObjectPtr<UFabricScreenWidget*>& Value) { Write<TWeakObjectPtr<UFabricScreenWidget*>>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ScreenWidgetComponent(const TWeakObjectPtr<UWidgetComponent*>& Value) { Write<TWeakObjectPtr<UWidgetComponent*>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CopyComponentsToWidget(const TMap<UFMInWorldKnobActorCopyComponent*, FScreenWidgetLayoutInfo>& Value) { Write<TMap<UFMInWorldKnobActorCopyComponent*, FScreenWidgetLayoutInfo>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x50, Type: MapProperty)
};

// Size: 0x58
class UFabricScreenLayoutDataAsset : public UDataAsset
{
public:
    TArray<FFabricScreenLayout> Layout() const { return Read<TArray<FFabricScreenLayout>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricWidgetLayout> AdditionalWidgetLayout() const { return Read<TArray<FFabricWidgetLayout>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    UClass* FabricScreenWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)

    void SET_Layout(const TArray<FFabricScreenLayout>& Value) { Write<TArray<FFabricScreenLayout>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_AdditionalWidgetLayout(const TArray<FFabricWidgetLayout>& Value) { Write<TArray<FFabricWidgetLayout>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_FabricScreenWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x40
class UFabricUserOptionPresetAsset : public UDataAsset
{
public:
    FFabricUserOptionPresetCollection UserOptionPreset() const { return Read<FFabricUserOptionPresetCollection>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_UserOptionPreset(const FFabricUserOptionPresetCollection& Value) { Write<FFabricUserOptionPresetCollection>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x358
class UFabricUserOptionSaveModulatable : public UFabricModulatable
{
public:
};

// Size: 0x220
class UFabricUserOptionSaveComponent : public UActorComponent
{
public:
    TArray<FString> UserOptionsToSave() const { return Read<TArray<FString>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxSaveSlots() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)
    FString SaveIndexParam() const { return Read<FString>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StrProperty)
    TArray<UFabricUserOptionPresetAsset*> PresetAssets() const { return Read<TArray<UFabricUserOptionPresetAsset*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    FString PresetIndexParam() const { return Read<FString>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: StrProperty)
    FString ApplyIndexImmediatelyToggleParam() const { return Read<FString>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: StrProperty)
    ABuildingActor* Owner() const { return Read<ABuildingActor*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    UFabricUserOptionSaveModulatable* UserOptionSaveModulatable() const { return Read<UFabricUserOptionSaveModulatable*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    TArray<FFabricUserOptionSaveData> Presets() const { return Read<TArray<FFabricUserOptionSaveData>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricUserOptionSaveData> Saves() const { return Read<TArray<FFabricUserOptionSaveData>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    TSet<FString> FloatUserOptions() const { return Read<TSet<FString>>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x50, Type: SetProperty)
    int32_t ActiveSaveIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: IntProperty)
    int32_t ActivePresetIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: IntProperty)

    void SET_UserOptionsToSave(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxSaveSlots(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
    void SET_SaveIndexParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StrProperty)
    void SET_PresetAssets(const TArray<UFabricUserOptionPresetAsset*>& Value) { Write<TArray<UFabricUserOptionPresetAsset*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_PresetIndexParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: StrProperty)
    void SET_ApplyIndexImmediatelyToggleParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: StrProperty)
    void SET_Owner(const ABuildingActor*& Value) { Write<ABuildingActor*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_UserOptionSaveModulatable(const UFabricUserOptionSaveModulatable*& Value) { Write<UFabricUserOptionSaveModulatable*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    void SET_Presets(const TArray<FFabricUserOptionSaveData>& Value) { Write<TArray<FFabricUserOptionSaveData>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_Saves(const TArray<FFabricUserOptionSaveData>& Value) { Write<TArray<FFabricUserOptionSaveData>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_FloatUserOptions(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x50, Type: SetProperty)
    void SET_ActiveSaveIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: IntProperty)
    void SET_ActivePresetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x198
class UFMInWorldCableOptionsComponent : public UActorComponent
{
public:
};

// Size: 0x430
class UFMInWorldDrumPlayerOptionsComponent : public UFMInWorldKnobOptionsBaseComponent
{
public:
    TMap<FString, FFMLinkPreset> SlotPropertyNameToParam() const { return Read<TMap<FString, FFMLinkPreset>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>> LinkButtonComponents() const { return Read<TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>> SelectionSampleCarouselComponents() const { return Read<TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FText> ParamNameToLinkedCheckBoxWidgetText() const { return Read<TMap<FString, FText>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x50, Type: MapProperty)
    TMap<FString, FText> ParamNameToSamplePropertyBoxWidgetText() const { return Read<TMap<FString, FText>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x50, Type: MapProperty)
    FText LinkedCheckBoxToolTipText() const { return Read<FText>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: TextProperty)
    FText SampleNamePropertyBoxToolTipText() const { return Read<FText>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: TextProperty)
    TArray<FString> SlotUserOptions() const { return Read<TArray<FString>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SlotLinkUserOptions() const { return Read<TArray<FString>>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SlotSampleUserOptions() const { return Read<TArray<FString>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    FString MainKitParamUseroption() const { return Read<FString>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: StrProperty)
    UFabricMetasoundDrumPlayerDataAsset* DrumPlayerBank() const { return Read<UFabricMetasoundDrumPlayerDataAsset*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    AFMInWorldKnobActorBase* MainKitIndexComponent() const { return Read<AFMInWorldKnobActorBase*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)

    void SET_SlotPropertyNameToParam(const TMap<FString, FFMLinkPreset>& Value) { Write<TMap<FString, FFMLinkPreset>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x50, Type: MapProperty)
    void SET_LinkButtonComponents(const TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>>& Value) { Write<TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectionSampleCarouselComponents(const TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>>& Value) { Write<TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    void SET_ParamNameToLinkedCheckBoxWidgetText(const TMap<FString, FText>& Value) { Write<TMap<FString, FText>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x50, Type: MapProperty)
    void SET_ParamNameToSamplePropertyBoxWidgetText(const TMap<FString, FText>& Value) { Write<TMap<FString, FText>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x50, Type: MapProperty)
    void SET_LinkedCheckBoxToolTipText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: TextProperty)
    void SET_SampleNamePropertyBoxToolTipText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: TextProperty)
    void SET_SlotUserOptions(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    void SET_SlotLinkUserOptions(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    void SET_SlotSampleUserOptions(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    void SET_MainKitParamUseroption(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: StrProperty)
    void SET_DrumPlayerBank(const UFabricMetasoundDrumPlayerDataAsset*& Value) { Write<UFabricMetasoundDrumPlayerDataAsset*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_MainKitIndexComponent(const AFMInWorldKnobActorBase*& Value) { Write<AFMInWorldKnobActorBase*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x290
class UFMInWorldKnobOptionsBaseComponent : public UActorComponent
{
public:
    TSet<UObject*> InWorldKnobInterfaceObjects() const { return Read<TSet<UObject*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x50, Type: SetProperty)
    ABuildingActor* BuildingActorOwner() const { return Read<ABuildingActor*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    UClass* OwnerClass() const { return Read<UClass*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ClassProperty)
    UFabricUserOptionSaveComponent* SaveComponent() const { return Read<UFabricUserOptionSaveComponent*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    TMap<FString, UPlaylistUserOptionBase*> PropertiesEditedByUserOptions() const { return Read<TMap<FString, UPlaylistUserOptionBase*>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x50, Type: MapProperty)
    TMap<FString, UObject*> OptionKeyToInWorldKnobObject() const { return Read<TMap<FString, UObject*>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x50, Type: MapProperty)
    TMap<FString, UFMDeviceCableModulatorPortComponent*> OptionKeyToModulatorPort() const { return Read<TMap<FString, UFMDeviceCableModulatorPortComponent*>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x50, Type: MapProperty)
    TArray<UFabricModulatable*> PendingFabricModulatables() const { return Read<TArray<UFabricModulatable*>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    FTimerHandle ActorSaveRequestTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: StructProperty)

    void SET_InWorldKnobInterfaceObjects(const TSet<UObject*>& Value) { Write<TSet<UObject*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x50, Type: SetProperty)
    void SET_BuildingActorOwner(const ABuildingActor*& Value) { Write<ABuildingActor*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ClassProperty)
    void SET_SaveComponent(const UFabricUserOptionSaveComponent*& Value) { Write<UFabricUserOptionSaveComponent*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    void SET_PropertiesEditedByUserOptions(const TMap<FString, UPlaylistUserOptionBase*>& Value) { Write<TMap<FString, UPlaylistUserOptionBase*>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x50, Type: MapProperty)
    void SET_OptionKeyToInWorldKnobObject(const TMap<FString, UObject*>& Value) { Write<TMap<FString, UObject*>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x50, Type: MapProperty)
    void SET_OptionKeyToModulatorPort(const TMap<FString, UFMDeviceCableModulatorPortComponent*>& Value) { Write<TMap<FString, UFMDeviceCableModulatorPortComponent*>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x50, Type: MapProperty)
    void SET_PendingFabricModulatables(const TArray<UFabricModulatable*>& Value) { Write<TArray<UFabricModulatable*>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_ActorSaveRequestTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: StructProperty)
};

// Size: 0x4c8
class AFMInWorldKnobActorBase : public AActor
{
public:
    FString OptionKey() const { return Read<FString>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: StrProperty)
    FText OverriddenTitle() const { return Read<FText>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x10, Type: TextProperty)
    FText OverriddenDescription() const { return Read<FText>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: TextProperty)
    bool bCanBeModulated() const { return Read<bool>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x1, Type: BoolProperty)
    bool bKnobEnabled() const { return Read<bool>(uintptr_t(this) + 0x339); } // 0x339 (Size: 0x1, Type: BoolProperty)
    bool bKnobDisplayOnly() const { return Read<bool>(uintptr_t(this) + 0x33a); } // 0x33a (Size: 0x1, Type: BoolProperty)
    bool bRestrictSettingNumericValues() const { return Read<bool>(uintptr_t(this) + 0x33b); } // 0x33b (Size: 0x1, Type: BoolProperty)
    USceneComponent* ModulatorPortParent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCableModulatorPortComponent* ModulatorPort() const { return Read<UFMDeviceCableModulatorPortComponent*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x20, Type: StructProperty)
    UPlaylistUserOptionBase* MyUserOption() const { return Read<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    TArray<TWeakObjectPtr<UFabricFloatProviderBase*>> CurrentFloatProviders() const { return Read<TArray<TWeakObjectPtr<UFabricFloatProviderBase*>>>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x10, Type: ArrayProperty)
    USceneComponent* HitComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<APlayerController*> InteractingController() const { return Read<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t InteractableType() const { return Read<uint8_t>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<UFabricInteractableViewModel*> WidgetViewModel() const { return Read<TWeakObjectPtr<UFabricInteractableViewModel*>>(uintptr_t(this) + 0x444); } // 0x444 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UFabricButtonComponentBase*>> AttachedButtons() const { return Read<TArray<TWeakObjectPtr<UFabricButtonComponentBase*>>>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    TArray<FText> OverrideLabels() const { return Read<TArray<FText>>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x10, Type: ArrayProperty)
    TArray<FText> OptionLabels() const { return Read<TArray<FText>>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> OptionValues() const { return Read<TArray<FString>>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    int32_t SerializedOptionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x4, Type: IntProperty)
    int32_t CurrentOptionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x494); } // 0x494 (Size: 0x4, Type: IntProperty)
    FString SerializedUnrestrictedOptionValue() const { return Read<FString>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x10, Type: StrProperty)
    FString CurrentUnrestrictedOptionValue() const { return Read<FString>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x10, Type: StrProperty)
    float CurrentAlpha() const { return Read<float>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x4, Type: FloatProperty)
    float AlphaAtStartOfTransition() const { return Read<float>(uintptr_t(this) + 0x4bc); } // 0x4bc (Size: 0x4, Type: FloatProperty)
    float ClampedKnobValue() const { return Read<float>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x4, Type: FloatProperty)
    bool bTrackingInput() const { return Read<bool>(uintptr_t(this) + 0x4c4); } // 0x4c4 (Size: 0x1, Type: BoolProperty)
    bool bIsVisibilityBound() const { return Read<bool>(uintptr_t(this) + 0x4c5); } // 0x4c5 (Size: 0x1, Type: BoolProperty)

    void SET_OptionKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: StrProperty)
    void SET_OverriddenTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x10, Type: TextProperty)
    void SET_OverriddenDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: TextProperty)
    void SET_bCanBeModulated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x1, Type: BoolProperty)
    void SET_bKnobEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x339, Value); } // 0x339 (Size: 0x1, Type: BoolProperty)
    void SET_bKnobDisplayOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x33a, Value); } // 0x33a (Size: 0x1, Type: BoolProperty)
    void SET_bRestrictSettingNumericValues(const bool& Value) { Write<bool>(uintptr_t(this) + 0x33b, Value); } // 0x33b (Size: 0x1, Type: BoolProperty)
    void SET_ModulatorPortParent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_ModulatorPort(const UFMDeviceCableModulatorPortComponent*& Value) { Write<UFMDeviceCableModulatorPortComponent*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x20, Type: StructProperty)
    void SET_MyUserOption(const UPlaylistUserOptionBase*& Value) { Write<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentFloatProviders(const TArray<TWeakObjectPtr<UFabricFloatProviderBase*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricFloatProviderBase*>>>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x10, Type: ArrayProperty)
    void SET_HitComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractingController(const TWeakObjectPtr<APlayerController*>& Value) { Write<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: WeakObjectProperty)
    void SET_InteractableType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x1, Type: EnumProperty)
    void SET_WidgetViewModel(const TWeakObjectPtr<UFabricInteractableViewModel*>& Value) { Write<TWeakObjectPtr<UFabricInteractableViewModel*>>(uintptr_t(this) + 0x444, Value); } // 0x444 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AttachedButtons(const TArray<TWeakObjectPtr<UFabricButtonComponentBase*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricButtonComponentBase*>>>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideLabels(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x10, Type: ArrayProperty)
    void SET_OptionLabels(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: ArrayProperty)
    void SET_OptionValues(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    void SET_SerializedOptionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x4, Type: IntProperty)
    void SET_CurrentOptionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x494, Value); } // 0x494 (Size: 0x4, Type: IntProperty)
    void SET_SerializedUnrestrictedOptionValue(const FString& Value) { Write<FString>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x10, Type: StrProperty)
    void SET_CurrentUnrestrictedOptionValue(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x10, Type: StrProperty)
    void SET_CurrentAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaAtStartOfTransition(const float& Value) { Write<float>(uintptr_t(this) + 0x4bc, Value); } // 0x4bc (Size: 0x4, Type: FloatProperty)
    void SET_ClampedKnobValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x4, Type: FloatProperty)
    void SET_bTrackingInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c4, Value); } // 0x4c4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsVisibilityBound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c5, Value); } // 0x4c5 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x450
class UFMInWorldKnobActorCopyComponent : public UFabricChildActorComponent
{
public:
    UClass* DefaultKnobActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ClassProperty)
    AFMInWorldKnobActorBase* InWorldKnobActor() const { return Read<AFMInWorldKnobActorBase*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    FString OptionKey() const { return Read<FString>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: StrProperty)
    FText OverriddenTitle() const { return Read<FText>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: TextProperty)
    bool bCanBeModulated() const { return Read<bool>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x1, Type: BoolProperty)
    bool bKnobEnabled() const { return Read<bool>(uintptr_t(this) + 0x3a1); } // 0x3a1 (Size: 0x1, Type: BoolProperty)
    UPlaylistUserOptionBase* OuterUserOption() const { return Read<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    FFabricUserOption OuterFabricUserOption() const { return Read<FFabricUserOption>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x38, Type: StructProperty)
    UPlaylistUserOptionBase* CopiedUserOption() const { return Read<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultKnobActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ClassProperty)
    void SET_InWorldKnobActor(const AFMInWorldKnobActorBase*& Value) { Write<AFMInWorldKnobActorBase*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_OptionKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: StrProperty)
    void SET_OverriddenTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: TextProperty)
    void SET_bCanBeModulated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x1, Type: BoolProperty)
    void SET_bKnobEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a1, Value); } // 0x3a1 (Size: 0x1, Type: BoolProperty)
    void SET_OuterUserOption(const UPlaylistUserOptionBase*& Value) { Write<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_OuterFabricUserOption(const FFabricUserOption& Value) { Write<FFabricUserOption>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x38, Type: StructProperty)
    void SET_CopiedUserOption(const UPlaylistUserOptionBase*& Value) { Write<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UInWorldKnobInterface : public UInterface
{
public:
};

// Size: 0x2c0
class UFMInWorldKnobOptionsComponent : public UFMInWorldKnobOptionsBaseComponent
{
public:
    TArray<UObject*> ReplicatedInWorldKnobInterfaceObjects() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> ReplicatedFabricInteractableObjects() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFMDeviceCableModulatorPortComponent*> ReplicatedModulatorPorts() const { return Read<TArray<UFMDeviceCableModulatorPortComponent*>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)

    void SET_ReplicatedInWorldKnobInterfaceObjects(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedFabricInteractableObjects(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedModulatorPorts(const TArray<UFMDeviceCableModulatorPortComponent*>& Value) { Write<TArray<UFMDeviceCableModulatorPortComponent*>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1d0
class UPlaylistUserOptionFMLinkPreset : public UPlaylistUserOptionBase
{
public:
    FFMLinkPreset DefaultValue() const { return Read<FFMLinkPreset>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x14, Type: StructProperty)

    void SET_DefaultValue(const FFMLinkPreset& Value) { Write<FFMLinkPreset>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x14, Type: StructProperty)
};

// Size: 0x208
class UPlaylistUserOptionFMOutgoingCableConnection : public UPlaylistUserOptionBase
{
public:
    FFMOutgoingCableConnection DefaultValue() const { return Read<FFMOutgoingCableConnection>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x50, Type: StructProperty)

    void SET_DefaultValue(const FFMOutgoingCableConnection& Value) { Write<FFMOutgoingCableConnection>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x50, Type: StructProperty)
};

// Size: 0x208
class UPlaylistUserOptionFMIncomingCableConnection : public UPlaylistUserOptionBase
{
public:
    FFMIncomingCableConnection DefaultValue() const { return Read<FFMIncomingCableConnection>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x50, Type: StructProperty)

    void SET_DefaultValue(const FFMIncomingCableConnection& Value) { Write<FFMIncomingCableConnection>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x50, Type: StructProperty)
};

// Size: 0x10
struct FFabricUserOptionSaveData
{
public:
    TArray<FFabricUserOptionSavedValue> SavedUserOptions() const { return Read<TArray<FFabricUserOptionSavedValue>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_SavedUserOptions(const TArray<FFabricUserOptionSavedValue>& Value) { Write<TArray<FFabricUserOptionSavedValue>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFabricUserOptionSavedValue
{
public:
    FString Key() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Key(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FScreenMeshArray
{
public:
    TArray<TSoftObjectPtr<UStaticMesh*>> ScreenMeshArrayByHeight() const { return Read<TArray<TSoftObjectPtr<UStaticMesh*>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ScreenMeshArrayByHeight(const TArray<TSoftObjectPtr<UStaticMesh*>>& Value) { Write<TArray<TSoftObjectPtr<UStaticMesh*>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FScreenWidgetLayoutInfo
{
public:
};

// Size: 0x18
struct FFabricWidgetLayout
{
public:
    FVector2D GridPosition() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    UClass* FabricWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)

    void SET_GridPosition(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_FabricWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x20
struct FFabricScreenLayout : public FFabricWidgetLayout
{
public:
    FName UserOptionName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)

    void SET_UserOptionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
};

// Size: 0x8
struct FFabricUserOptionValue
{
public:
};

// Size: 0x10
struct FFabricUserOptionValueInt : public FFabricUserOptionValue
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FFabricUserOptionValueFloat : public FFabricUserOptionValue
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FFabricUserOptionValueEnum : public FFabricUserOptionValue
{
public:
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FFabricUserOptionValueBool : public FFabricUserOptionValue
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FFabricUserOptionValueString : public FFabricUserOptionValue
{
public:
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FFabricUserOptionPreset
{
public:
    FString UserOption() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FInstancedStruct UserOptionValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_UserOption(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UserOptionValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FFabricUserOptionPresetCollection
{
public:
    TArray<FFabricUserOptionPreset> UserOptionPresets() const { return Read<TArray<FFabricUserOptionPreset>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_UserOptionPresets(const TArray<FFabricUserOptionPreset>& Value) { Write<TArray<FFabricUserOptionPreset>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FFloatProviderState
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    int32_t Weight() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float LastValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Weight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_LastValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x14
struct FFMLinkPreset
{
public:
    bool bIsLinked() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FName SelectionSampleIndexName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    int32_t UnlinkedSelectionSampleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t UnlinkedKitIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MainKitIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_bIsLinked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_SelectionSampleIndexName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_UnlinkedSelectionSampleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_UnlinkedKitIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_MainKitIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FUserOptionDefinitionFMLinkPresetMetaData : public FUserOptionDefinitionMetaData
{
public:
    FFMLinkPreset DefaultValue() const { return Read<FFMLinkPreset>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)

    void SET_DefaultValue(const FFMLinkPreset& Value) { Write<FFMLinkPreset>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
};

// Size: 0x28
struct FFMCableAdditionalConnection
{
public:
    FName OutputPortName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UObject> Device() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_OutputPortName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Device(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x50
struct FFMCableConnection
{
public:
    FName OutputPortName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UObject> Device() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    FName ComponentName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    TArray<FFMCableAdditionalConnection> InputConnections() const { return Read<TArray<FFMCableAdditionalConnection>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t PortDirectionType() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)

    void SET_OutputPortName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Device(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_InputConnections(const TArray<FFMCableAdditionalConnection>& Value) { Write<TArray<FFMCableAdditionalConnection>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_PortDirectionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x50
struct FFMOutgoingCableConnection : public FFMCableConnection
{
public:
};

// Size: 0x50
struct FFMIncomingCableConnection : public FFMCableConnection
{
public:
};

// Size: 0x58
struct FUserOptionDefinitionFMOutgoingConnectionMetaData : public FUserOptionDefinitionMetaData
{
public:
    FFMOutgoingCableConnection DefaultValue() const { return Read<FFMOutgoingCableConnection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: StructProperty)

    void SET_DefaultValue(const FFMOutgoingCableConnection& Value) { Write<FFMOutgoingCableConnection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: StructProperty)
};

// Size: 0x58
struct FUserOptionDefinitionFMIncomingConnectionMetaData : public FUserOptionDefinitionMetaData
{
public:
    FFMIncomingCableConnection DefaultValue() const { return Read<FFMIncomingCableConnection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: StructProperty)

    void SET_DefaultValue(const FFMIncomingCableConnection& Value) { Write<FFMIncomingCableConnection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: StructProperty)
};

