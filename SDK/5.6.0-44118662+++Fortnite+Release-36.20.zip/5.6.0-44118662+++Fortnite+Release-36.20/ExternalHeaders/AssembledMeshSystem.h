/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AssembledMeshSystem
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "CustomizableObject.h"
#include "Engine.h"

// Size: 0x28
class UAssembledMeshUser_AttachToComponentSpecifier : public UInterface
{
public:
};

// Size: 0x1e0
class UAssembledMeshSchema : public UPrimaryDataAsset
{
public:
    FGameplayTag MeshSchemaTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UCustomizableObjectInstance> CustomizableObjectInstance() const { return Read<TSoftObjectPtr<UCustomizableObjectInstance>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UCustomizableObject> CustomizableObject() const { return Read<TSoftObjectPtr<UCustomizableObject>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: SoftObjectProperty)
    int32_t ComponentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    FName ComponentName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<USkeletalMesh> SkeletalMesh() const { return Read<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FString, FString> SelectedIntParams() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)
    TMap<FString, float> SelectedFloatParams() const { return Read<TMap<FString, float>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    FAssembledMeshAttachmentRules AttachmentRules() const { return Read<FAssembledMeshAttachmentRules>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x50, Type: StructProperty)
    FGameplayTagContainer SoundLibraryTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x20, Type: StructProperty)
    TArray<FInstancedStruct> AdditionalData() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: ArrayProperty)

    void SET_MeshSchemaTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_CustomizableObjectInstance(const TSoftObjectPtr<UCustomizableObjectInstance>& Value) { Write<TSoftObjectPtr<UCustomizableObjectInstance>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CustomizableObject(const TSoftObjectPtr<UCustomizableObject>& Value) { Write<TSoftObjectPtr<UCustomizableObject>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ComponentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_ComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_SkeletalMesh(const TSoftObjectPtr<USkeletalMesh>& Value) { Write<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SelectedIntParams(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
    void SET_SelectedFloatParams(const TMap<FString, float>& Value) { Write<TMap<FString, float>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_AttachmentRules(const FAssembledMeshAttachmentRules& Value) { Write<FAssembledMeshAttachmentRules>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x50, Type: StructProperty)
    void SET_SoundLibraryTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x20, Type: StructProperty)
    void SET_AdditionalData(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x128
class UHeadAccDataAssetLink : public UDataAssetLink
{
public:
};

// Size: 0x128
class UNeckAccDataAssetLink : public UDataAssetLink
{
public:
};

// Size: 0x128
class UHipAccDataAssetLink : public UDataAssetLink
{
public:
};

// Size: 0x110
class UAssembledMeshUserComponent : public UActorComponent
{
public:
    TArray<UObject*> LoadedAssets() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<UAssembledMeshSchema*> MeshParts() const { return Read<TArray<UAssembledMeshSchema*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TArray<FAssembledComponentReferences> MeshPartComponents() const { return Read<TArray<FAssembledComponentReferences>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    bool bDuplicateCOIs() const { return Read<bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: BoolProperty)
    bool bAssignMeshPartsOnBeginPlay() const { return (Read<uint8_t>(uintptr_t(this) + 0x109) >> 0x0) & 1; } // 0x109:0 (Size: 0x1, Type: BoolProperty)

    void SET_LoadedAssets(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshParts(const TArray<UAssembledMeshSchema*>& Value) { Write<TArray<UAssembledMeshSchema*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshPartComponents(const TArray<FAssembledComponentReferences>& Value) { Write<TArray<FAssembledComponentReferences>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_bDuplicateCOIs(const bool& Value) { Write<bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: BoolProperty)
    void SET_bAssignMeshPartsOnBeginPlay(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x109); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x109, B); } // 0x109:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FAssembledComponentReferences
{
public:
    USkeletalMeshComponent* SkeletalMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UCustomizableObjectInstanceUsage* CustomizableObjectInstanceUsage() const { return Read<UCustomizableObjectInstanceUsage*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag AssembledMeshSchemaTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)

    void SET_SkeletalMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomizableObjectInstanceUsage(const UCustomizableObjectInstanceUsage*& Value) { Write<UCustomizableObjectInstanceUsage*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_AssembledMeshSchemaTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
};

// Size: 0x1
struct FAssembledMeshSchemaData
{
public:
};

// Size: 0x80
struct FAssembledMeshSchemaData_Icons : public FAssembledMeshSchemaData
{
public:
    TSoftObjectPtr<UTexture2D> WidePreviewImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> SmallPreviewImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> LargePreviewImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> FullScreenImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)

    void SET_WidePreviewImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SmallPreviewImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LargePreviewImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    void SET_FullScreenImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x50
struct FAssembledMeshAttachmentRules
{
public:
    FName AttachSocketName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector AttachOffset() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator AttachRotation() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector AttachScale() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_AttachSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AttachOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_AttachRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_AttachScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x10
struct FBaseParamData
{
public:
    FString ParamName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_ParamName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FIntParamData : public FBaseParamData
{
public:
    TArray<FString> ParamOptions() const { return Read<TArray<FString>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ParamOptions(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFloatParamData : public FBaseParamData
{
public:
    float FloatValue() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MinFloatValue() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxFloatValue() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_FloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MinFloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_MaxFloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

