/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDebugMenuRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x1f8
class UFortControllerComponent_CreativeDebugger : public UFortControllerComponent
{
public:
    FScalableFloat DebuggerEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat VerseDebugDrawEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NavigationMeshEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x28, Type: StructProperty)
    FScalableFloat NavigationPathsEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x28, Type: StructProperty)
    FScalableFloat GhostModeEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x28, Type: StructProperty)
    FScalableFloat InvincibilityEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x28, Type: StructProperty)
    FScalableFloat FastIterationEnabledByDataRegistry() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    UClass* AIDebuggerClass() const { return Read<UClass*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ClassProperty)

    void SET_DebuggerEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_VerseDebugDrawEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
    void SET_NavigationMeshEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x28, Type: StructProperty)
    void SET_NavigationPathsEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x28, Type: StructProperty)
    void SET_GhostModeEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x28, Type: StructProperty)
    void SET_InvincibilityEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x28, Type: StructProperty)
    void SET_FastIterationEnabledByDataRegistry(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_AIDebuggerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
};

