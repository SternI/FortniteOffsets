/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ForwardingChannels
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UForwardingChannelFactory : public UInterface
{
public:
};

// Size: 0x98
class UForwardingChannelsSubsystem : public UGameInstanceSubsystem
{
public:
    TArray<TScriptInterface<Class>> ForwardingChannelFactories() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_ForwardingChannelFactories(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

