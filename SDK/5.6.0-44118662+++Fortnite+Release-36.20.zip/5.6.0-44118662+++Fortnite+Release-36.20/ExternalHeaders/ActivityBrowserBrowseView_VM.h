/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserBrowseView_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "UI.h"
#include "ActivityCategoryTilePanelBase.h"
#include "Engine.h"
#include "ActivityCategoryTilePanelBase_VM.h"
#include "FortniteUI.h"
#include "UMG.h"
#include "UIKit.h"

// Size: 0x502
class UActivityBrowserBrowseView_VM_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Throbber_C* WBP_UIKit_Throbber() const { return Read<UWBP_UIKit_Throbber_C*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* WBP_BottomBarHack_BackToTop() const { return Read<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VerticalBox_Panels() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UActivityCategoryTilePanelBase_VM_C* TilePanel_Featured_VMversion() const { return Read<UActivityCategoryTilePanelBase_VM_C*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UActivityCategoryTilePanelBase_VM_C* TilePanel_All_VMversion() const { return Read<UActivityCategoryTilePanelBase_VM_C*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_HeaderSoftEdge() const { return Read<UImage*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ShiftToNextPanel() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_DisplayLoading() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverBrowseViewModel* FortDiscoverBrowseViewModel() const { return Read<UFortDiscoverBrowseViewModel*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    double CategoryIndexAnimator() const { return Read<double>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: DoubleProperty)
    int32_t DesiredPanelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x4, Type: IntProperty)
    int32_t LastDesiredPanelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4d4); } // 0x4d4 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPanelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x4, Type: IntProperty)
    UActivityCategoryTilePanelBase_C* LastSelectedPanel() const { return Read<UActivityCategoryTilePanelBase_C*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EUMGSequencePlayMode> CurrentPlayDirection() const { return Read<TEnumAsByte<EUMGSequencePlayMode>>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x1, Type: ByteProperty)
    uint8_t CurrentInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x1, Type: EnumProperty)
    bool IsClickedOnBottomPanel() const { return Read<bool>(uintptr_t(this) + 0x501); } // 0x501 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_Throbber(const UWBP_UIKit_Throbber_C*& Value) { Write<UWBP_UIKit_Throbber_C*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_BottomBarHack_BackToTop(const UWBP_BottomBarDecoyButton_C*& Value) { Write<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_VerticalBox_Panels(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_TilePanel_Featured_VMversion(const UActivityCategoryTilePanelBase_VM_C*& Value) { Write<UActivityCategoryTilePanelBase_VM_C*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_TilePanel_All_VMversion(const UActivityCategoryTilePanelBase_VM_C*& Value) { Write<UActivityCategoryTilePanelBase_VM_C*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_HeaderSoftEdge(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_ShiftToNextPanel(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_DisplayLoading(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_FortDiscoverBrowseViewModel(const UFortDiscoverBrowseViewModel*& Value) { Write<UFortDiscoverBrowseViewModel*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_CategoryIndexAnimator(const double& Value) { Write<double>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: DoubleProperty)
    void SET_DesiredPanelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x4, Type: IntProperty)
    void SET_LastDesiredPanelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4d4, Value); } // 0x4d4 (Size: 0x4, Type: IntProperty)
    void SET_CurrentPanelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x4, Type: IntProperty)
    void SET_LastSelectedPanel(const UActivityCategoryTilePanelBase_C*& Value) { Write<UActivityCategoryTilePanelBase_C*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentPlayDirection(const TEnumAsByte<EUMGSequencePlayMode>& Value) { Write<TEnumAsByte<EUMGSequencePlayMode>>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x1, Type: ByteProperty)
    void SET_CurrentInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x1, Type: EnumProperty)
    void SET_IsClickedOnBottomPanel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x501, Value); } // 0x501 (Size: 0x1, Type: BoolProperty)
};

