/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Components
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "SparksMusicPlayspaceRuntime.h"
#include "Athena.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "SparksCharacterCommonRuntime.h"
#include "Data.h"
#include "GameplayEventRouter.h"
#include "SlateCore.h"
#include "SoundLibrary.h"
#include "FMJamPlayspaceRuntime.h"
#include "DynamicUI.h"
#include "Playspace.h"
#include "SparksCoreUI.h"
#include "InputPromptManagerRuntime.h"
#include "EnhancedInput.h"

// Size: 0x1c8
class UBP_JamOnOffSwitchComponent_C : public UJamOnOffSwitchComponent
{
public:
};

// Size: 0x28
class URidingGeneric_Interafce_C : public UInterface
{
public:
};

// Size: 0xd2
class UCreatureBaseNonRidableComponent_C : public UActorComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: StructProperty)
    double Jump_Attach_Ground_Height_Min() const { return Read<double>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: DoubleProperty)
    double Jump_Attach_Ground_Height_Buffer() const { return Read<double>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    bool Uses_Alt_Riding_Message() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool KillOnRideAttempt() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: StructProperty)
    void SET_Jump_Attach_Ground_Height_Min(const double& Value) { Write<double>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: DoubleProperty)
    void SET_Jump_Attach_Ground_Height_Buffer(const double& Value) { Write<double>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    void SET_Uses_Alt_Riding_Message(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_KillOnRideAttempt(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x9b0
class UBP_VehicleCosmeticsAMUC_C : public UVehicleCosmeticsAssembledMeshUserComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x970); } // 0x970 (Size: 0x8, Type: StructProperty)
    AFortAthenaVehicle* VehiclePawn() const { return Read<AFortAthenaVehicle*>(uintptr_t(this) + 0x978); } // 0x978 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GC_LoopingApplication() const { return Read<FGameplayTag>(uintptr_t(this) + 0x980); } // 0x980 (Size: 0x4, Type: StructProperty)
    FName BoostTestSocketName() const { return Read<FName>(uintptr_t(this) + 0x984); } // 0x984 (Size: 0x4, Type: NameProperty)
    AActor* BoostTestSpawnedActor() const { return Read<AActor*>(uintptr_t(this) + 0x988); } // 0x988 (Size: 0x8, Type: ObjectProperty)
    UClass* BoostTestActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x990); } // 0x990 (Size: 0x8, Type: ClassProperty)
    AActor* TrailTestSpawnedActor() const { return Read<AActor*>(uintptr_t(this) + 0x998); } // 0x998 (Size: 0x8, Type: ObjectProperty)
    FName TrailTestSocketName() const { return Read<FName>(uintptr_t(this) + 0x9a0); } // 0x9a0 (Size: 0x4, Type: NameProperty)
    UClass* TrailTestActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x9a8); } // 0x9a8 (Size: 0x8, Type: ClassProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x970, Value); } // 0x970 (Size: 0x8, Type: StructProperty)
    void SET_VehiclePawn(const AFortAthenaVehicle*& Value) { Write<AFortAthenaVehicle*>(uintptr_t(this) + 0x978, Value); } // 0x978 (Size: 0x8, Type: ObjectProperty)
    void SET_GC_LoopingApplication(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x980, Value); } // 0x980 (Size: 0x4, Type: StructProperty)
    void SET_BoostTestSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x984, Value); } // 0x984 (Size: 0x4, Type: NameProperty)
    void SET_BoostTestSpawnedActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x988, Value); } // 0x988 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostTestActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x990, Value); } // 0x990 (Size: 0x8, Type: ClassProperty)
    void SET_TrailTestSpawnedActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x998, Value); } // 0x998 (Size: 0x8, Type: ObjectProperty)
    void SET_TrailTestSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x9a0, Value); } // 0x9a0 (Size: 0x4, Type: NameProperty)
    void SET_TrailTestActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x9a8, Value); } // 0x9a8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x248
class UIntercomManager_C : public UActorComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: StructProperty)
    UGameplayEventRouterComponent* Event_Router() const { return Read<UGameplayEventRouterComponent*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayTag, FGameplayEvent_IntercomBroadcastRequest> Active_Channel_Broadcasts() const { return Read<TMap<FGameplayTag, FGameplayEvent_IntercomBroadcastRequest>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, UAudioComponent*> Channel_Audio_Components() const { return Read<TMap<FGameplayTag, UAudioComponent*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FIntercomChannelQueue> Channel_Broadcast_Queues() const { return Read<TMap<FGameplayTag, FIntercomChannelQueue>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FIntercomChannelListeners> Channel_Listeners() const { return Read<TMap<FGameplayTag, FIntercomChannelListeners>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x50, Type: MapProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: StructProperty)
    void SET_Event_Router(const UGameplayEventRouterComponent*& Value) { Write<UGameplayEventRouterComponent*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_Active_Channel_Broadcasts(const TMap<FGameplayTag, FGameplayEvent_IntercomBroadcastRequest>& Value) { Write<TMap<FGameplayTag, FGameplayEvent_IntercomBroadcastRequest>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x50, Type: MapProperty)
    void SET_Channel_Audio_Components(const TMap<FGameplayTag, UAudioComponent*>& Value) { Write<TMap<FGameplayTag, UAudioComponent*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x50, Type: MapProperty)
    void SET_Channel_Broadcast_Queues(const TMap<FGameplayTag, FIntercomChannelQueue>& Value) { Write<TMap<FGameplayTag, FIntercomChannelQueue>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x50, Type: MapProperty)
    void SET_Channel_Listeners(const TMap<FGameplayTag, FIntercomChannelListeners>& Value) { Write<TMap<FGameplayTag, FIntercomChannelListeners>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x288
class UBP_JamInLobbyPlayspaceComponent_ReactiveFX_C : public UBP_JamPlayspaceComponent_ReactiveFX_C
{
public:
};

// Size: 0x120
class UBP_PlayerStateCustomFeedMessages_C : public UFortPlayerStateComponent_CustomFeedMessage
{
public:
};

// Size: 0x888
class UPlayerRiderComponent_C : public UControllingRiderComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer T_PlayerIsRiding() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x20, Type: StructProperty)
    UClass* GE_PlayerIsRiding() const { return Read<UClass*>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x8, Type: ClassProperty)
    AFortPlayerPawn* FortPlayerRef() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x788); } // 0x788 (Size: 0x8, Type: ObjectProperty)
    double JumpOnMountDistanceCheck() const { return Read<double>(uintptr_t(this) + 0x790); } // 0x790 (Size: 0x8, Type: DoubleProperty)
    double targetEnergy() const { return Read<double>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x8, Type: DoubleProperty)
    double targetHealth() const { return Read<double>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer T_CannotRideBucket() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x20, Type: StructProperty)
    AActor* CachedRidableActor() const { return Read<AActor*>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Cannot_Ride_Rider_Bucket() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x20, Type: StructProperty)
    FGameplayTag JumpOnCreature_Cue_Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x4, Type: StructProperty)
    UClass* GE_PlayerPetting() const { return Read<UClass*>(uintptr_t(this) + 0x838); } // 0x838 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer Tag_Quests_Wildlife_Pet() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x20, Type: StructProperty)
    UAbilityAsync_WaitGameplayTagAdded* ActiveRidableBlockRidingGameplayTagAsyncAction() const { return Read<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0x860); } // 0x860 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AllowRidingMovementModeChangeTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x20, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x8, Type: StructProperty)
    void SET_T_PlayerIsRiding(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x20, Type: StructProperty)
    void SET_GE_PlayerIsRiding(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x8, Type: ClassProperty)
    void SET_FortPlayerRef(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x788, Value); } // 0x788 (Size: 0x8, Type: ObjectProperty)
    void SET_JumpOnMountDistanceCheck(const double& Value) { Write<double>(uintptr_t(this) + 0x790, Value); } // 0x790 (Size: 0x8, Type: DoubleProperty)
    void SET_targetEnergy(const double& Value) { Write<double>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x8, Type: DoubleProperty)
    void SET_targetHealth(const double& Value) { Write<double>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x8, Type: DoubleProperty)
    void SET_T_CannotRideBucket(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x20, Type: StructProperty)
    void SET_CachedRidableActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x8, Type: ObjectProperty)
    void SET_Cannot_Ride_Rider_Bucket(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x20, Type: StructProperty)
    void SET_JumpOnCreature_Cue_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x4, Type: StructProperty)
    void SET_GE_PlayerPetting(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x838, Value); } // 0x838 (Size: 0x8, Type: ClassProperty)
    void SET_Tag_Quests_Wildlife_Pet(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x20, Type: StructProperty)
    void SET_ActiveRidableBlockRidingGameplayTagAsyncAction(const UAbilityAsync_WaitGameplayTagAdded*& Value) { Write<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0x860, Value); } // 0x860 (Size: 0x8, Type: ObjectProperty)
    void SET_AllowRidingMovementModeChangeTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x20, Type: StructProperty)
};

// Size: 0xec1
class UCreatureBaseRidableComponent_C : public UControllableRidableComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer T_CreatureIsBeingRidden() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x20, Type: StructProperty)
    UClass* GE_CreatureIsBeingRidden() const { return Read<UClass*>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x8, Type: ClassProperty)
    UClass* GE_CreatureIsBeingRidden_Passive() const { return Read<UClass*>(uintptr_t(this) + 0x838); } // 0x838 (Size: 0x8, Type: ClassProperty)
    bool bDebugDisplay() const { return Read<bool>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x1, Type: BoolProperty)
    double DebugTickRate() const { return Read<double>(uintptr_t(this) + 0x848); } // 0x848 (Size: 0x8, Type: DoubleProperty)
    FVector DebugServerRiderLocation() const { return Read<FVector>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x18, Type: StructProperty)
    double CapsuleRadiusOffset() const { return Read<double>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x8, Type: DoubleProperty)
    double CapsuleHalfHeightOffset() const { return Read<double>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer T_RidingSpecialAbility() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x878); } // 0x878 (Size: 0x20, Type: StructProperty)
    UAnimSequence* IdleAnim_Add() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x898); } // 0x898 (Size: 0x8, Type: ObjectProperty)
    UAnimSequence* RunAnim_Add() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    UBlendSpace* TurnBS() const { return Read<UBlendSpace*>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    double MinSpeedToRun() const { return Read<double>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x8, Type: DoubleProperty)
    double Run_RampIntoSpeed() const { return Read<double>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x8, Type: DoubleProperty)
    double Run_RampIntoSpeed_ADS() const { return Read<double>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x8, Type: DoubleProperty)
    double Run_PlayRate() const { return Read<double>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x8, Type: DoubleProperty)
    double Run_PlayRate_ADS() const { return Read<double>(uintptr_t(this) + 0x8d0); } // 0x8d0 (Size: 0x8, Type: DoubleProperty)
    double SpringAlpha() const { return Read<double>(uintptr_t(this) + 0x8d8); } // 0x8d8 (Size: 0x8, Type: DoubleProperty)
    double SpringAlpha_ADS() const { return Read<double>(uintptr_t(this) + 0x8e0); } // 0x8e0 (Size: 0x8, Type: DoubleProperty)
    double Idle_Alpha() const { return Read<double>(uintptr_t(this) + 0x8e8); } // 0x8e8 (Size: 0x8, Type: DoubleProperty)
    double Idle_Alpha_ADS() const { return Read<double>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x8, Type: DoubleProperty)
    double Run_Alpha() const { return Read<double>(uintptr_t(this) + 0x8f8); } // 0x8f8 (Size: 0x8, Type: DoubleProperty)
    double Run_Alpha_ADS() const { return Read<double>(uintptr_t(this) + 0x900); } // 0x900 (Size: 0x8, Type: DoubleProperty)
    double Turn_Alpha() const { return Read<double>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x8, Type: DoubleProperty)
    double Turn_Alpha_ADS() const { return Read<double>(uintptr_t(this) + 0x910); } // 0x910 (Size: 0x8, Type: DoubleProperty)
    UAnimSequence* Clamp_AnimPose_LastResort() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x918); } // 0x918 (Size: 0x8, Type: ObjectProperty)
    FRotator Clamp_Foot_R_Adjust() const { return Read<FRotator>(uintptr_t(this) + 0x920); } // 0x920 (Size: 0x18, Type: StructProperty)
    FRotator Clamp_Foot_L_Adjust() const { return Read<FRotator>(uintptr_t(this) + 0x938); } // 0x938 (Size: 0x18, Type: StructProperty)
    double CapsuleRadiusOffset_Emote() const { return Read<double>(uintptr_t(this) + 0x950); } // 0x950 (Size: 0x8, Type: DoubleProperty)
    double CapsuleHalfHeightOffset_Emote() const { return Read<double>(uintptr_t(this) + 0x958); } // 0x958 (Size: 0x8, Type: DoubleProperty)
    FVector Clamp_Location_Offset() const { return Read<FVector>(uintptr_t(this) + 0x960); } // 0x960 (Size: 0x18, Type: StructProperty)
    FRotator Clamp_Rotation_Offset() const { return Read<FRotator>(uintptr_t(this) + 0x978); } // 0x978 (Size: 0x18, Type: StructProperty)
    FVector Clamp_ScaleAdjust() const { return Read<FVector>(uintptr_t(this) + 0x990); } // 0x990 (Size: 0x18, Type: StructProperty)
    FName RidableSocketName() const { return Read<FName>(uintptr_t(this) + 0x9a8); } // 0x9a8 (Size: 0x4, Type: NameProperty)
    double RidableSocket_Alpha() const { return Read<double>(uintptr_t(this) + 0x9b0); } // 0x9b0 (Size: 0x8, Type: DoubleProperty)
    UClass* GE_CooldownOverride() const { return Read<UClass*>(uintptr_t(this) + 0x9b8); } // 0x9b8 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer T_CreatureOverrideCooldown() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x20, Type: StructProperty)
    TMap<TEnumAsByte<ECollisionChannel>, TEnumAsByte<ECollisionResponse>> OriginalCollisionResponseMap() const { return Read<TMap<TEnumAsByte<ECollisionChannel>, TEnumAsByte<ECollisionResponse>>>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x50, Type: MapProperty)
    FSoundIndicatorIconPicker RidingSoundIndicatorIconOverride() const { return Read<FSoundIndicatorIconPicker>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x28, Type: StructProperty)
    char MovementMode() const { return Read<char>(uintptr_t(this) + 0xa78); } // 0xa78 (Size: 0x1, Type: ByteProperty)
    bool bFalling() const { return Read<bool>(uintptr_t(this) + 0xa79); } // 0xa79 (Size: 0x1, Type: BoolProperty)
    FScalableFloat RidingAbilityEnable_HF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x28, Type: StructProperty)
    double JumpAttach_GroundHeightMin() const { return Read<double>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x8, Type: DoubleProperty)
    double JumpAttach_GroundHeightBuffer() const { return Read<double>(uintptr_t(this) + 0xab0); } // 0xab0 (Size: 0x8, Type: DoubleProperty)
    bool UseAltRidingMessage() const { return Read<bool>(uintptr_t(this) + 0xab8); } // 0xab8 (Size: 0x1, Type: BoolProperty)
    FText Riding_Interaction_Text() const { return Read<FText>(uintptr_t(this) + 0xac0); } // 0xac0 (Size: 0x10, Type: TextProperty)
    double currentEnergyValue() const { return Read<double>(uintptr_t(this) + 0xad0); } // 0xad0 (Size: 0x8, Type: DoubleProperty)
    UPlayerRiderComponent_C* PlayerRiderComponentRef() const { return Read<UPlayerRiderComponent_C*>(uintptr_t(this) + 0xad8); } // 0xad8 (Size: 0x8, Type: ObjectProperty)
    ANPC_Pawn_Wildlife_Parent_C* NPCPawnWildlifeRef() const { return Read<ANPC_Pawn_Wildlife_Parent_C*>(uintptr_t(this) + 0xae0); } // 0xae0 (Size: 0x8, Type: ObjectProperty)
    double previousTimeTracked() const { return Read<double>(uintptr_t(this) + 0xae8); } // 0xae8 (Size: 0x8, Type: DoubleProperty)
    double energyTrackingDeltaTime() const { return Read<double>(uintptr_t(this) + 0xaf0); } // 0xaf0 (Size: 0x8, Type: DoubleProperty)
    bool OldEnergyFlowEnabled() const { return Read<bool>(uintptr_t(this) + 0xaf8); } // 0xaf8 (Size: 0x1, Type: BoolProperty)
    bool ShouldHaveEnergy() const { return Read<bool>(uintptr_t(this) + 0xaf9); } // 0xaf9 (Size: 0x1, Type: BoolProperty)
    double EnergyRateOfDecayStopped() const { return Read<double>(uintptr_t(this) + 0xb00); } // 0xb00 (Size: 0x8, Type: DoubleProperty)
    bool allowUpdateEnergyTrackingTick() const { return Read<bool>(uintptr_t(this) + 0xb08); } // 0xb08 (Size: 0x1, Type: BoolProperty)
    bool lastBeingRiddenState() const { return Read<bool>(uintptr_t(this) + 0xb09); } // 0xb09 (Size: 0x1, Type: BoolProperty)
    FCurveTableRowHandle EnergyRateOfDecayMoving() const { return Read<FCurveTableRowHandle>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x10, Type: StructProperty)
    FCurveTableRowHandle EnergyRateOfDecaySprinting() const { return Read<FCurveTableRowHandle>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x10, Type: StructProperty)
    double CurrentEnergyRateOfRecharge() const { return Read<double>(uintptr_t(this) + 0xb30); } // 0xb30 (Size: 0x8, Type: DoubleProperty)
    FCurveTableRowHandle ExhaustedEnergyRateOfRecharge() const { return Read<FCurveTableRowHandle>(uintptr_t(this) + 0xb38); } // 0xb38 (Size: 0x10, Type: StructProperty)
    double EnergyWarningThreshold() const { return Read<double>(uintptr_t(this) + 0xb48); } // 0xb48 (Size: 0x8, Type: DoubleProperty)
    double EnergyCriticalThreshold() const { return Read<double>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x8, Type: DoubleProperty)
    bool energyWarningActive() const { return Read<bool>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x1, Type: BoolProperty)
    bool energyCriticalActive() const { return Read<bool>(uintptr_t(this) + 0xb59); } // 0xb59 (Size: 0x1, Type: BoolProperty)
    double minMovementSpeedTreshold() const { return Read<double>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x8, Type: DoubleProperty)
    bool IsJumping() const { return Read<bool>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x1, Type: BoolProperty)
    double EnergyRegenThreshold() const { return Read<double>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: DoubleProperty)
    bool AlwaysRegenWhenNotRidden() const { return Read<bool>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x1, Type: BoolProperty)
    UClass* GE_EnergyWarning() const { return Read<UClass*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ClassProperty)
    UClass* GE_EnergyCritical() const { return Read<UClass*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ClassProperty)
    UClass* GE_EnergyDepleted() const { return Read<UClass*>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer T_EnergyWarning() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer T_EnergyCritical() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer T_EnergyDepleted() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer T_CannotRideBucket() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x20, Type: StructProperty)
    UClass* Gameplay_Effect() const { return Read<UClass*>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SprintingAbilityTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x4, Type: StructProperty)
    UClass* GE_EatToRefuel() const { return Read<UClass*>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x8, Type: ClassProperty)
    FSlateBrush IconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0xb0, Type: StructProperty)
    UClass* GE_Creature_Sprint() const { return Read<UClass*>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x8, Type: ClassProperty)
    USoundLibrary* RidingFoleySoundLibrary() const { return Read<USoundLibrary*>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer TagsPreventSprinting() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x20, Type: StructProperty)
    FGameplayTag OutOfEnergySoundLibTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintStartSoundLibTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd34); } // 0xd34 (Size: 0x4, Type: StructProperty)
    TEnumAsByte<TInteractionType> Riding_Interaction_Type() const { return Read<TEnumAsByte<TInteractionType>>(uintptr_t(this) + 0xd38); } // 0xd38 (Size: 0x1, Type: ByteProperty)
    double StartInAirTimestamp() const { return Read<double>(uintptr_t(this) + 0xd40); } // 0xd40 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle RetryJumpExitTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xd48); } // 0xd48 (Size: 0x8, Type: StructProperty)
    double JumpExitBufferStartTimeStamp() const { return Read<double>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat JumpExitBufferTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x28, Type: StructProperty)
    FTimerHandle JumpExitBufferTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x8, Type: StructProperty)
    FGameplayTag MountLandedCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x4, Type: StructProperty)
    UClass* GE_BlockCreatureAttackOnDismount() const { return Read<UClass*>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x8, Type: ClassProperty)
    bool EnergyRegenActive() const { return Read<bool>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer BlockPetting_TagContainer() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x20, Type: StructProperty)
    bool infiniteStaminaBuffEnabled() const { return Read<bool>(uintptr_t(this) + 0xdc0); } // 0xdc0 (Size: 0x1, Type: BoolProperty)
    FGameplayTag InfiniteStaminaEffect_GameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xdc4); } // 0xdc4 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer Cannot_Ride_Rider_Bucket() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xdc8); } // 0xdc8 (Size: 0x20, Type: StructProperty)
    FScalableFloat JumpFatigue_Enabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xde8); } // 0xde8 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpFatigue_ApplyFatigueMinJumpCount() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe10); } // 0xe10 (Size: 0x28, Type: StructProperty)
    UClass* JumpFatigueGameplayEffect() const { return Read<UClass*>(uintptr_t(this) + 0xe38); } // 0xe38 (Size: 0x8, Type: ClassProperty)
    bool JumpFatigueDebugEnabled() const { return Read<bool>(uintptr_t(this) + 0xe40); } // 0xe40 (Size: 0x1, Type: BoolProperty)
    int32_t JumpFatigueJumpCount() const { return Read<int32_t>(uintptr_t(this) + 0xe44); } // 0xe44 (Size: 0x4, Type: IntProperty)
    double JumpFatigue_LastLandingTimeStamp() const { return Read<double>(uintptr_t(this) + 0xe48); } // 0xe48 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat JumpFatigue_ResetCounterDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe50); } // 0xe50 (Size: 0x28, Type: StructProperty)
    bool JumpFatigue_ShouldTimeStampNextLanding() const { return Read<bool>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle JumpFatigue_GEHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xe7c); } // 0xe7c (Size: 0x8, Type: StructProperty)
    FTimerHandle JumpFatigue_RemovalTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xe88); } // 0xe88 (Size: 0x8, Type: StructProperty)
    FScalableFloat JumpFatigue_GeDurationPostLanding() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe90); } // 0xe90 (Size: 0x28, Type: StructProperty)
    UClass* GE_NotPetable_IsBeingRidden() const { return Read<UClass*>(uintptr_t(this) + 0xeb8); } // 0xeb8 (Size: 0x8, Type: ClassProperty)
    bool bAllowRidingInteraction() const { return Read<bool>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x8, Type: StructProperty)
    void SET_T_CreatureIsBeingRidden(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x20, Type: StructProperty)
    void SET_GE_CreatureIsBeingRidden(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x8, Type: ClassProperty)
    void SET_GE_CreatureIsBeingRidden_Passive(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x838, Value); } // 0x838 (Size: 0x8, Type: ClassProperty)
    void SET_bDebugDisplay(const bool& Value) { Write<bool>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x1, Type: BoolProperty)
    void SET_DebugTickRate(const double& Value) { Write<double>(uintptr_t(this) + 0x848, Value); } // 0x848 (Size: 0x8, Type: DoubleProperty)
    void SET_DebugServerRiderLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x18, Type: StructProperty)
    void SET_CapsuleRadiusOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x8, Type: DoubleProperty)
    void SET_CapsuleHalfHeightOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x8, Type: DoubleProperty)
    void SET_T_RidingSpecialAbility(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x878, Value); } // 0x878 (Size: 0x20, Type: StructProperty)
    void SET_IdleAnim_Add(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x898, Value); } // 0x898 (Size: 0x8, Type: ObjectProperty)
    void SET_RunAnim_Add(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    void SET_TurnBS(const UBlendSpace*& Value) { Write<UBlendSpace*>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    void SET_MinSpeedToRun(const double& Value) { Write<double>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x8, Type: DoubleProperty)
    void SET_Run_RampIntoSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x8, Type: DoubleProperty)
    void SET_Run_RampIntoSpeed_ADS(const double& Value) { Write<double>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x8, Type: DoubleProperty)
    void SET_Run_PlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x8, Type: DoubleProperty)
    void SET_Run_PlayRate_ADS(const double& Value) { Write<double>(uintptr_t(this) + 0x8d0, Value); } // 0x8d0 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringAlpha(const double& Value) { Write<double>(uintptr_t(this) + 0x8d8, Value); } // 0x8d8 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringAlpha_ADS(const double& Value) { Write<double>(uintptr_t(this) + 0x8e0, Value); } // 0x8e0 (Size: 0x8, Type: DoubleProperty)
    void SET_Idle_Alpha(const double& Value) { Write<double>(uintptr_t(this) + 0x8e8, Value); } // 0x8e8 (Size: 0x8, Type: DoubleProperty)
    void SET_Idle_Alpha_ADS(const double& Value) { Write<double>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x8, Type: DoubleProperty)
    void SET_Run_Alpha(const double& Value) { Write<double>(uintptr_t(this) + 0x8f8, Value); } // 0x8f8 (Size: 0x8, Type: DoubleProperty)
    void SET_Run_Alpha_ADS(const double& Value) { Write<double>(uintptr_t(this) + 0x900, Value); } // 0x900 (Size: 0x8, Type: DoubleProperty)
    void SET_Turn_Alpha(const double& Value) { Write<double>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x8, Type: DoubleProperty)
    void SET_Turn_Alpha_ADS(const double& Value) { Write<double>(uintptr_t(this) + 0x910, Value); } // 0x910 (Size: 0x8, Type: DoubleProperty)
    void SET_Clamp_AnimPose_LastResort(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x918, Value); } // 0x918 (Size: 0x8, Type: ObjectProperty)
    void SET_Clamp_Foot_R_Adjust(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x920, Value); } // 0x920 (Size: 0x18, Type: StructProperty)
    void SET_Clamp_Foot_L_Adjust(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x938, Value); } // 0x938 (Size: 0x18, Type: StructProperty)
    void SET_CapsuleRadiusOffset_Emote(const double& Value) { Write<double>(uintptr_t(this) + 0x950, Value); } // 0x950 (Size: 0x8, Type: DoubleProperty)
    void SET_CapsuleHalfHeightOffset_Emote(const double& Value) { Write<double>(uintptr_t(this) + 0x958, Value); } // 0x958 (Size: 0x8, Type: DoubleProperty)
    void SET_Clamp_Location_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x960, Value); } // 0x960 (Size: 0x18, Type: StructProperty)
    void SET_Clamp_Rotation_Offset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x978, Value); } // 0x978 (Size: 0x18, Type: StructProperty)
    void SET_Clamp_ScaleAdjust(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x990, Value); } // 0x990 (Size: 0x18, Type: StructProperty)
    void SET_RidableSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x9a8, Value); } // 0x9a8 (Size: 0x4, Type: NameProperty)
    void SET_RidableSocket_Alpha(const double& Value) { Write<double>(uintptr_t(this) + 0x9b0, Value); } // 0x9b0 (Size: 0x8, Type: DoubleProperty)
    void SET_GE_CooldownOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x9b8, Value); } // 0x9b8 (Size: 0x8, Type: ClassProperty)
    void SET_T_CreatureOverrideCooldown(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x20, Type: StructProperty)
    void SET_OriginalCollisionResponseMap(const TMap<TEnumAsByte<ECollisionChannel>, TEnumAsByte<ECollisionResponse>>& Value) { Write<TMap<TEnumAsByte<ECollisionChannel>, TEnumAsByte<ECollisionResponse>>>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x50, Type: MapProperty)
    void SET_RidingSoundIndicatorIconOverride(const FSoundIndicatorIconPicker& Value) { Write<FSoundIndicatorIconPicker>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x28, Type: StructProperty)
    void SET_MovementMode(const char& Value) { Write<char>(uintptr_t(this) + 0xa78, Value); } // 0xa78 (Size: 0x1, Type: ByteProperty)
    void SET_bFalling(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa79, Value); } // 0xa79 (Size: 0x1, Type: BoolProperty)
    void SET_RidingAbilityEnable_HF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x28, Type: StructProperty)
    void SET_JumpAttach_GroundHeightMin(const double& Value) { Write<double>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x8, Type: DoubleProperty)
    void SET_JumpAttach_GroundHeightBuffer(const double& Value) { Write<double>(uintptr_t(this) + 0xab0, Value); } // 0xab0 (Size: 0x8, Type: DoubleProperty)
    void SET_UseAltRidingMessage(const bool& Value) { Write<bool>(uintptr_t(this) + 0xab8, Value); } // 0xab8 (Size: 0x1, Type: BoolProperty)
    void SET_Riding_Interaction_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0xac0, Value); } // 0xac0 (Size: 0x10, Type: TextProperty)
    void SET_currentEnergyValue(const double& Value) { Write<double>(uintptr_t(this) + 0xad0, Value); } // 0xad0 (Size: 0x8, Type: DoubleProperty)
    void SET_PlayerRiderComponentRef(const UPlayerRiderComponent_C*& Value) { Write<UPlayerRiderComponent_C*>(uintptr_t(this) + 0xad8, Value); } // 0xad8 (Size: 0x8, Type: ObjectProperty)
    void SET_NPCPawnWildlifeRef(const ANPC_Pawn_Wildlife_Parent_C*& Value) { Write<ANPC_Pawn_Wildlife_Parent_C*>(uintptr_t(this) + 0xae0, Value); } // 0xae0 (Size: 0x8, Type: ObjectProperty)
    void SET_previousTimeTracked(const double& Value) { Write<double>(uintptr_t(this) + 0xae8, Value); } // 0xae8 (Size: 0x8, Type: DoubleProperty)
    void SET_energyTrackingDeltaTime(const double& Value) { Write<double>(uintptr_t(this) + 0xaf0, Value); } // 0xaf0 (Size: 0x8, Type: DoubleProperty)
    void SET_OldEnergyFlowEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaf8, Value); } // 0xaf8 (Size: 0x1, Type: BoolProperty)
    void SET_ShouldHaveEnergy(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaf9, Value); } // 0xaf9 (Size: 0x1, Type: BoolProperty)
    void SET_EnergyRateOfDecayStopped(const double& Value) { Write<double>(uintptr_t(this) + 0xb00, Value); } // 0xb00 (Size: 0x8, Type: DoubleProperty)
    void SET_allowUpdateEnergyTrackingTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb08, Value); } // 0xb08 (Size: 0x1, Type: BoolProperty)
    void SET_lastBeingRiddenState(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb09, Value); } // 0xb09 (Size: 0x1, Type: BoolProperty)
    void SET_EnergyRateOfDecayMoving(const FCurveTableRowHandle& Value) { Write<FCurveTableRowHandle>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x10, Type: StructProperty)
    void SET_EnergyRateOfDecaySprinting(const FCurveTableRowHandle& Value) { Write<FCurveTableRowHandle>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x10, Type: StructProperty)
    void SET_CurrentEnergyRateOfRecharge(const double& Value) { Write<double>(uintptr_t(this) + 0xb30, Value); } // 0xb30 (Size: 0x8, Type: DoubleProperty)
    void SET_ExhaustedEnergyRateOfRecharge(const FCurveTableRowHandle& Value) { Write<FCurveTableRowHandle>(uintptr_t(this) + 0xb38, Value); } // 0xb38 (Size: 0x10, Type: StructProperty)
    void SET_EnergyWarningThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0xb48, Value); } // 0xb48 (Size: 0x8, Type: DoubleProperty)
    void SET_EnergyCriticalThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x8, Type: DoubleProperty)
    void SET_energyWarningActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x1, Type: BoolProperty)
    void SET_energyCriticalActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb59, Value); } // 0xb59 (Size: 0x1, Type: BoolProperty)
    void SET_minMovementSpeedTreshold(const double& Value) { Write<double>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x8, Type: DoubleProperty)
    void SET_IsJumping(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x1, Type: BoolProperty)
    void SET_EnergyRegenThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: DoubleProperty)
    void SET_AlwaysRegenWhenNotRidden(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x1, Type: BoolProperty)
    void SET_GE_EnergyWarning(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ClassProperty)
    void SET_GE_EnergyCritical(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ClassProperty)
    void SET_GE_EnergyDepleted(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: ClassProperty)
    void SET_T_EnergyWarning(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x20, Type: StructProperty)
    void SET_T_EnergyCritical(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x20, Type: StructProperty)
    void SET_T_EnergyDepleted(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x20, Type: StructProperty)
    void SET_T_CannotRideBucket(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x20, Type: StructProperty)
    void SET_Gameplay_Effect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: ClassProperty)
    void SET_SprintingAbilityTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x4, Type: StructProperty)
    void SET_GE_EatToRefuel(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x8, Type: ClassProperty)
    void SET_IconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0xb0, Type: StructProperty)
    void SET_GE_Creature_Sprint(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x8, Type: ClassProperty)
    void SET_RidingFoleySoundLibrary(const USoundLibrary*& Value) { Write<USoundLibrary*>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x8, Type: ObjectProperty)
    void SET_TagsPreventSprinting(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x20, Type: StructProperty)
    void SET_OutOfEnergySoundLibTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x4, Type: StructProperty)
    void SET_SprintStartSoundLibTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd34, Value); } // 0xd34 (Size: 0x4, Type: StructProperty)
    void SET_Riding_Interaction_Type(const TEnumAsByte<TInteractionType>& Value) { Write<TEnumAsByte<TInteractionType>>(uintptr_t(this) + 0xd38, Value); } // 0xd38 (Size: 0x1, Type: ByteProperty)
    void SET_StartInAirTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0xd40, Value); } // 0xd40 (Size: 0x8, Type: DoubleProperty)
    void SET_RetryJumpExitTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xd48, Value); } // 0xd48 (Size: 0x8, Type: StructProperty)
    void SET_JumpExitBufferStartTimeStamp(const double& Value) { Write<double>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x8, Type: DoubleProperty)
    void SET_JumpExitBufferTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x28, Type: StructProperty)
    void SET_JumpExitBufferTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x8, Type: StructProperty)
    void SET_MountLandedCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x4, Type: StructProperty)
    void SET_GE_BlockCreatureAttackOnDismount(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x8, Type: ClassProperty)
    void SET_EnergyRegenActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x1, Type: BoolProperty)
    void SET_BlockPetting_TagContainer(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x20, Type: StructProperty)
    void SET_infiniteStaminaBuffEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdc0, Value); } // 0xdc0 (Size: 0x1, Type: BoolProperty)
    void SET_InfiniteStaminaEffect_GameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xdc4, Value); } // 0xdc4 (Size: 0x4, Type: StructProperty)
    void SET_Cannot_Ride_Rider_Bucket(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xdc8, Value); } // 0xdc8 (Size: 0x20, Type: StructProperty)
    void SET_JumpFatigue_Enabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xde8, Value); } // 0xde8 (Size: 0x28, Type: StructProperty)
    void SET_JumpFatigue_ApplyFatigueMinJumpCount(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe10, Value); } // 0xe10 (Size: 0x28, Type: StructProperty)
    void SET_JumpFatigueGameplayEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xe38, Value); } // 0xe38 (Size: 0x8, Type: ClassProperty)
    void SET_JumpFatigueDebugEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe40, Value); } // 0xe40 (Size: 0x1, Type: BoolProperty)
    void SET_JumpFatigueJumpCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe44, Value); } // 0xe44 (Size: 0x4, Type: IntProperty)
    void SET_JumpFatigue_LastLandingTimeStamp(const double& Value) { Write<double>(uintptr_t(this) + 0xe48, Value); } // 0xe48 (Size: 0x8, Type: DoubleProperty)
    void SET_JumpFatigue_ResetCounterDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe50, Value); } // 0xe50 (Size: 0x28, Type: StructProperty)
    void SET_JumpFatigue_ShouldTimeStampNextLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0x1, Type: BoolProperty)
    void SET_JumpFatigue_GEHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xe7c, Value); } // 0xe7c (Size: 0x8, Type: StructProperty)
    void SET_JumpFatigue_RemovalTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xe88, Value); } // 0xe88 (Size: 0x8, Type: StructProperty)
    void SET_JumpFatigue_GeDurationPostLanding(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe90, Value); } // 0xe90 (Size: 0x28, Type: StructProperty)
    void SET_GE_NotPetable_IsBeingRidden(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xeb8, Value); } // 0xeb8 (Size: 0x8, Type: ClassProperty)
    void SET_bAllowRidingInteraction(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf0c
class UBoarRidableComponent_C : public UCreatureBaseRidableComponent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xec8); } // 0xec8 (Size: 0x8, Type: StructProperty)
    USoundBase* BurtChargeStartSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xed0); } // 0xed0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* ChargeSoundComp() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xed8); } // 0xed8 (Size: 0x8, Type: ObjectProperty)
    double SprintCooldDownTime() const { return Read<double>(uintptr_t(this) + 0xee0); } // 0xee0 (Size: 0x8, Type: DoubleProperty)
    UClass* GESprintImpactPawn() const { return Read<UClass*>(uintptr_t(this) + 0xee8); } // 0xee8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SprintImpactGameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xef0); } // 0xef0 (Size: 0x4, Type: StructProperty)
    UClass* GESprintImpactVehicle() const { return Read<UClass*>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SprintChargeImpact_Default_CueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintChargeImpact_Pawn_CueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf04); } // 0xf04 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintChargeImpact_DestroyBuild_CueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf08); } // 0xf08 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xec8, Value); } // 0xec8 (Size: 0x8, Type: StructProperty)
    void SET_BurtChargeStartSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xed0, Value); } // 0xed0 (Size: 0x8, Type: ObjectProperty)
    void SET_ChargeSoundComp(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xed8, Value); } // 0xed8 (Size: 0x8, Type: ObjectProperty)
    void SET_SprintCooldDownTime(const double& Value) { Write<double>(uintptr_t(this) + 0xee0, Value); } // 0xee0 (Size: 0x8, Type: DoubleProperty)
    void SET_GESprintImpactPawn(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xee8, Value); } // 0xee8 (Size: 0x8, Type: ClassProperty)
    void SET_SprintImpactGameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xef0, Value); } // 0xef0 (Size: 0x4, Type: StructProperty)
    void SET_GESprintImpactVehicle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x8, Type: ClassProperty)
    void SET_SprintChargeImpact_Default_CueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x4, Type: StructProperty)
    void SET_SprintChargeImpact_Pawn_CueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf04, Value); } // 0xf04 (Size: 0x4, Type: StructProperty)
    void SET_SprintChargeImpact_DestroyBuild_CueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf08, Value); } // 0xf08 (Size: 0x4, Type: StructProperty)
};

// Size: 0xec1
class UWolfRidableComponent_C : public UCreatureBaseRidableComponent_C
{
public:
};

// Size: 0x2d8
class UBP_JamInstrumentAnimation_PlayerStateComponent_C : public UBP_SparksInstrumentAnimation_PlayerStateComponent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)
    AJamPlayspace* JamPlayspace() const { return Read<AJamPlayspace*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    UGameplayEventRouterComponent* EventRouter() const { return Read<UGameplayEventRouterComponent*>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    UAsyncAction_StartListeningToEvent* JamLoopStartedAsyncTask() const { return Read<UAsyncAction_StartListeningToEvent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UAsyncAction_StartListeningToEvent* JamLoopStoppedAsyncTask() const { return Read<UAsyncAction_StartListeningToEvent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    FString CanSwapInstrumentsCVarName() const { return Read<FString>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: StrProperty)
    uint8_t CurrentLoopType() const { return Read<uint8_t>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x1, Type: EnumProperty)
    int32_t LastLoadedAnimsId() const { return Read<int32_t>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: IntProperty)
    USparksInstrumentAnimations* LoadedAnims() const { return Read<USparksInstrumentAnimations*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
    void SET_JamPlayspace(const AJamPlayspace*& Value) { Write<AJamPlayspace*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    void SET_EventRouter(const UGameplayEventRouterComponent*& Value) { Write<UGameplayEventRouterComponent*>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    void SET_JamLoopStartedAsyncTask(const UAsyncAction_StartListeningToEvent*& Value) { Write<UAsyncAction_StartListeningToEvent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_JamLoopStoppedAsyncTask(const UAsyncAction_StartListeningToEvent*& Value) { Write<UAsyncAction_StartListeningToEvent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_CanSwapInstrumentsCVarName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: StrProperty)
    void SET_CurrentLoopType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x1, Type: EnumProperty)
    void SET_LastLoadedAnimsId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: IntProperty)
    void SET_LoadedAnims(const USparksInstrumentAnimations*& Value) { Write<USparksInstrumentAnimations*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UBP_JamVolumeComponent_C : public UFortPlayerStateComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: StructProperty)
    UGameplayEventRouterComponent* Event_Router() const { return Read<UGameplayEventRouterComponent*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: StructProperty)
    void SET_Event_Router(const UGameplayEventRouterComponent*& Value) { Write<UGameplayEventRouterComponent*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x180
class UBP_JamAnalytics_C : public UJamAnalytics
{
public:
};

// Size: 0x181
class UBP_Jam_Controller_LoopOptions_C : public UJamControllerComponent_LoopOptions
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer Playlist_Context_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Jam_Emote_First_Playlist_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x20, Type: StructProperty)
    bool bJamEmotesPostLockerInJamPlaylists() const { return Read<bool>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: StructProperty)
    void SET_Playlist_Context_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x20, Type: StructProperty)
    void SET_Jam_Emote_First_Playlist_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x20, Type: StructProperty)
    void SET_bJamEmotesPostLockerInJamPlaylists(const bool& Value) { Write<bool>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x288
class UBP_JamPlayspaceComponent_ReactiveFX_C : public UJamPlayspaceComponent_ReactiveFX
{
public:
};

// Size: 0x68
struct FJamUISceneByTags
{
public:
    FGameplayTagQuery PlaylistTags_2_12BFD2B24C209C9EE6A73EA9EFAADCEF() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FString EnableCVar_12_9379D68148A8F57DF6F463B28F8D491A() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    TArray<UDynamicUIScene*> UIScenesToAdd_6_6A717A3F46A28CA9EA3C9E8C1909000C() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_PlaylistTags_2_12BFD2B24C209C9EE6A73EA9EFAADCEF(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_EnableCVar_12_9379D68148A8F57DF6F463B28F8D491A(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_UIScenesToAdd_6_6A717A3F46A28CA9EA3C9E8C1909000C(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1a0
class UBP_JamControllerComponent_C : public UJamControllerComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: StructProperty)
    ABP_JamPlayspace_C* Leaf_Jam_Playspace() const { return Read<ABP_JamPlayspace_C*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagAdded* JammingTagAddedHandle() const { return Read<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagRemoved* JammingTagRemovedHandle() const { return Read<UAbilityAsync_WaitGameplayTagRemoved*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    FString EnableJamEmotesCVarName() const { return Read<FString>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StrProperty)
    FString EnableAutoJammersCVarName() const { return Read<FString>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: StrProperty)
    TArray<FJamUISceneByTags> UIScenes() const { return Read<TArray<FJamUISceneByTags>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicUIScene*> AddedUIScenes() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    bool CanAutoJam() const { return Read<bool>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: BoolProperty)
    UInputMappingContext* JamControlsMap() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    UInputMappingContext* AutoJamControlsMap() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    UClass* JammingGE() const { return Read<UClass*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ClassProperty)
    TArray<ABP_JamPlayspace_C*> KnownPlayspaces() const { return Read<TArray<ABP_JamPlayspace_C*>>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: ArrayProperty)
    TArray<FDynamicUISceneRequestHandle> DynamicUI_Scene_Requests() const { return Read<TArray<FDynamicUISceneRequestHandle>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    UDynamicUISceneRequestCoordinatorComponent* DynamicUICoordinator() const { return Read<UDynamicUISceneRequestCoordinatorComponent*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    bool bWantsJamControls() const { return Read<bool>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x1, Type: BoolProperty)
    bool bCanHaveJamControls() const { return Read<bool>(uintptr_t(this) + 0x189); } // 0x189 (Size: 0x1, Type: BoolProperty)
    TArray<UInputAlias*> Active_Input_Aliases() const { return Read<TArray<UInputAlias*>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: StructProperty)
    void SET_Leaf_Jam_Playspace(const ABP_JamPlayspace_C*& Value) { Write<ABP_JamPlayspace_C*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_JammingTagAddedHandle(const UAbilityAsync_WaitGameplayTagAdded*& Value) { Write<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_JammingTagRemovedHandle(const UAbilityAsync_WaitGameplayTagRemoved*& Value) { Write<UAbilityAsync_WaitGameplayTagRemoved*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_EnableJamEmotesCVarName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StrProperty)
    void SET_EnableAutoJammersCVarName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: StrProperty)
    void SET_UIScenes(const TArray<FJamUISceneByTags>& Value) { Write<TArray<FJamUISceneByTags>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_AddedUIScenes(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    void SET_CanAutoJam(const bool& Value) { Write<bool>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: BoolProperty)
    void SET_JamControlsMap(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    void SET_AutoJamControlsMap(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    void SET_JammingGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ClassProperty)
    void SET_KnownPlayspaces(const TArray<ABP_JamPlayspace_C*>& Value) { Write<TArray<ABP_JamPlayspace_C*>>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: ArrayProperty)
    void SET_DynamicUI_Scene_Requests(const TArray<FDynamicUISceneRequestHandle>& Value) { Write<TArray<FDynamicUISceneRequestHandle>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    void SET_DynamicUICoordinator(const UDynamicUISceneRequestCoordinatorComponent*& Value) { Write<UDynamicUISceneRequestCoordinatorComponent*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    void SET_bWantsJamControls(const bool& Value) { Write<bool>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x1, Type: BoolProperty)
    void SET_bCanHaveJamControls(const bool& Value) { Write<bool>(uintptr_t(this) + 0x189, Value); } // 0x189 (Size: 0x1, Type: BoolProperty)
    void SET_Active_Input_Aliases(const TArray<UInputAlias*>& Value) { Write<TArray<UInputAlias*>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf8
class UBP_JamPlayerPawnComponent_C : public UJamPlayerPawnComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: StructProperty)
    ABP_JamPlayspace_C* JamPlayspace() const { return Read<ABP_JamPlayspace_C*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    USparksMusicPlayspaceAudioState* JamAudioState() const { return Read<USparksMusicPlayspaceAudioState*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: StructProperty)
    void SET_JamPlayspace(const ABP_JamPlayspace_C*& Value) { Write<ABP_JamPlayspace_C*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_JamAudioState(const USparksMusicPlayspaceAudioState*& Value) { Write<USparksMusicPlayspaceAudioState*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x108
class UBP_FortGameStateComponent_JamInLobbyPlayspaceManager_C : public UFortGameStateComponent_JamInLobbyPlayspaceManager
{
public:
};

// Size: 0x228
class UEventMode_Activator_Component_C : public UFortGameFrameworkComponent_EventMode
{
public:
};

// Size: 0x158
class UBP_JamInLobbyControllerComponent_LoopOptions_C : public UJamInLobbyControllerComponent_LoopOptions
{
public:
};

