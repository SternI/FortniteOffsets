/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CompeteUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteUI.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "EpicCMSUIFramework.h"

// Size: 0xc8
class UFortCompeteGameUserSettings : public UObject
{
public:
    TArray<FFortEventBookmarks> SerializedEventBookmarks() const { return Read<TArray<FFortEventBookmarks>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)

    void SET_SerializedEventBookmarks(const TArray<FFortEventBookmarks>& Value) { Write<TArray<FFortEventBookmarks>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
class UFortPoblanoTournamentsCarouselVM : public UMVVMViewModelBase
{
public:
    FTournamentDetailsScreenParams TournamentDetailsScreenParams() const { return Read<FTournamentDetailsScreenParams>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)

    void SET_TournamentDetailsScreenParams(const FTournamentDetailsScreenParams& Value) { Write<FTournamentDetailsScreenParams>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
};

// Size: 0x90
class UFortTournamentBackgroundVM : public UMVVMViewModelBase
{
public:
    UTexture2D* TournamentTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FLinearColor BackgroundLeftColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundRightColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)

    void SET_TournamentTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_BackgroundLeftColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundRightColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
};

// Size: 0xa0
class UFortTournamentBookmarksVM : public UMVVMViewModelBase
{
public:
    bool bIsCurrentIslandRanked() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    TArray<FFortUpcomingTournamentData> UpcomingTournaments() const { return Read<TArray<FFortUpcomingTournamentData>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_bIsCurrentIslandRanked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_UpcomingTournaments(const TArray<FFortUpcomingTournamentData>& Value) { Write<TArray<FFortUpcomingTournamentData>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa8
class UFortTournamentHeaderVM : public UMVVMViewModelBase
{
public:
    FText TournamentName() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    FText WindowRoundText() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    FText WindowTimeText() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    uint8_t ExperienceType() const { return Read<uint8_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    uint8_t MatchType() const { return Read<uint8_t>(uintptr_t(this) + 0xa1); } // 0xa1 (Size: 0x1, Type: EnumProperty)
    uint8_t TournamentType() const { return Read<uint8_t>(uintptr_t(this) + 0xa2); } // 0xa2 (Size: 0x1, Type: EnumProperty)
    uint8_t GameType() const { return Read<uint8_t>(uintptr_t(this) + 0xa3); } // 0xa3 (Size: 0x1, Type: EnumProperty)
    bool bIsWindowLive() const { return Read<bool>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: BoolProperty)

    void SET_TournamentName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_WindowRoundText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_WindowTimeText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_ExperienceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    void SET_MatchType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa1, Value); } // 0xa1 (Size: 0x1, Type: EnumProperty)
    void SET_TournamentType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa2, Value); } // 0xa2 (Size: 0x1, Type: EnumProperty)
    void SET_GameType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa3, Value); } // 0xa3 (Size: 0x1, Type: EnumProperty)
    void SET_bIsWindowLive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UFortTournamentPlayerProfileVM : public UMVVMViewModelBase
{
public:
    FString AccountId() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FString DisplayName() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    FString FlagName() const { return Read<FString>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StrProperty)

    void SET_AccountId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_DisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_FlagName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StrProperty)
};

// Size: 0x78
class UFortTournamentRewardItemVM : public UMVVMViewModelBase
{
public:
    UFortItemVM* ItemVM() const { return Read<UFortItemVM*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bIsGreyedOut() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_ItemVM(const UFortItemVM*& Value) { Write<UFortItemVM*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsGreyedOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x190
class UFortTournamentViewVM : public UMVVMViewModelBase
{
public:
    UFortTournamentRequirementsModalVM* EligibilityRequirementsModalVM() const { return Read<UFortTournamentRequirementsModalVM*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentWatchLiveVM* WatchLiveVM() const { return Read<UFortTournamentWatchLiveVM*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentHeaderVM* TournamentHeaderVM() const { return Read<UFortTournamentHeaderVM*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    FText TournamentDescription() const { return Read<FText>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: TextProperty)
    FText RegionName() const { return Read<FText>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: TextProperty)
    TArray<FFortShowdownScoringRuleInfo> ScoringRules() const { return Read<TArray<FFortShowdownScoringRuleInfo>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortEventWindowsListInfo> EventWindowsList() const { return Read<TArray<FFortEventWindowsListInfo>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FTournamentLeaderboardPayoutTableData> Payouts() const { return Read<TArray<FTournamentLeaderboardPayoutTableData>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FTournamentPayoutThresholdData HighestThresholdData() const { return Read<FTournamentPayoutThresholdData>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x80, Type: StructProperty)
    bool bIsPlayerEligibleForWindow() const { return Read<bool>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x1, Type: BoolProperty)
    bool bPlayerMeetsRankRequirement() const { return Read<bool>(uintptr_t(this) + 0x159); } // 0x159 (Size: 0x1, Type: BoolProperty)
    int32_t MinRankLevelRequirement() const { return Read<int32_t>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: IntProperty)
    bool bIsWindowLive() const { return Read<bool>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: BoolProperty)
    bool bIsLeaderboardAvailable() const { return Read<bool>(uintptr_t(this) + 0x161); } // 0x161 (Size: 0x1, Type: BoolProperty)
    bool bIsCurrentWindowBookmarked() const { return Read<bool>(uintptr_t(this) + 0x162); } // 0x162 (Size: 0x1, Type: BoolProperty)

    void SET_EligibilityRequirementsModalVM(const UFortTournamentRequirementsModalVM*& Value) { Write<UFortTournamentRequirementsModalVM*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_WatchLiveVM(const UFortTournamentWatchLiveVM*& Value) { Write<UFortTournamentWatchLiveVM*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentHeaderVM(const UFortTournamentHeaderVM*& Value) { Write<UFortTournamentHeaderVM*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: TextProperty)
    void SET_RegionName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: TextProperty)
    void SET_ScoringRules(const TArray<FFortShowdownScoringRuleInfo>& Value) { Write<TArray<FFortShowdownScoringRuleInfo>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_EventWindowsList(const TArray<FFortEventWindowsListInfo>& Value) { Write<TArray<FFortEventWindowsListInfo>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_Payouts(const TArray<FTournamentLeaderboardPayoutTableData>& Value) { Write<TArray<FTournamentLeaderboardPayoutTableData>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_HighestThresholdData(const FTournamentPayoutThresholdData& Value) { Write<FTournamentPayoutThresholdData>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x80, Type: StructProperty)
    void SET_bIsPlayerEligibleForWindow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayerMeetsRankRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x159, Value); } // 0x159 (Size: 0x1, Type: BoolProperty)
    void SET_MinRankLevelRequirement(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: IntProperty)
    void SET_bIsWindowLive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: BoolProperty)
    void SET_bIsLeaderboardAvailable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x161, Value); } // 0x161 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCurrentWindowBookmarked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x162, Value); } // 0x162 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x6c0
class UFortCompeteUIManager : public UEngineSubsystem
{
public:
    TMap<UFortUINotification*, FFortCompeteFrontendNotificationData> FrontendNotificationDataMap() const { return Read<TMap<UFortUINotification*, FFortCompeteFrontendNotificationData>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x50, Type: MapProperty)
    UFortPoblanoTournamentsCalendarFilterVM* CalendarFilterVM() const { return Read<UFortPoblanoTournamentsCalendarFilterVM*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentBookmarksVM* BookmarksVM() const { return Read<UFortTournamentBookmarksVM*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFortCompeteGameUserSettings* CompeteGameUserSettings() const { return Read<UFortCompeteGameUserSettings*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<UFortTournamentLeaderboardEntryData*> LeaderboardEntries() const { return Read<TArray<UFortTournamentLeaderboardEntryData*>>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x10, Type: ArrayProperty)
    UFortTournamentLeaderboardEntryData* LeaderboardLocalPlayerEntry() const { return Read<UFortTournamentLeaderboardEntryData*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentLeaderboardEntryData* LeaderboardScreenSelectedEntry() const { return Read<UFortTournamentLeaderboardEntryData*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    TMap<FString, UFortTournamentPlayerProfileVM*> PlayersProfiles() const { return Read<TMap<FString, UFortTournamentPlayerProfileVM*>>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x50, Type: MapProperty)
    TArray<UFortTournamentWatchLiveEntryVM*> LiveGames() const { return Read<TArray<UFortTournamentWatchLiveEntryVM*>>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x10, Type: ArrayProperty)
    bool bShowDebugInfo() const { return Read<bool>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x1, Type: BoolProperty)

    void SET_FrontendNotificationDataMap(const TMap<UFortUINotification*, FFortCompeteFrontendNotificationData>& Value) { Write<TMap<UFortUINotification*, FFortCompeteFrontendNotificationData>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x50, Type: MapProperty)
    void SET_CalendarFilterVM(const UFortPoblanoTournamentsCalendarFilterVM*& Value) { Write<UFortPoblanoTournamentsCalendarFilterVM*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_BookmarksVM(const UFortTournamentBookmarksVM*& Value) { Write<UFortTournamentBookmarksVM*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_CompeteGameUserSettings(const UFortCompeteGameUserSettings*& Value) { Write<UFortCompeteGameUserSettings*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderboardEntries(const TArray<UFortTournamentLeaderboardEntryData*>& Value) { Write<TArray<UFortTournamentLeaderboardEntryData*>>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x10, Type: ArrayProperty)
    void SET_LeaderboardLocalPlayerEntry(const UFortTournamentLeaderboardEntryData*& Value) { Write<UFortTournamentLeaderboardEntryData*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderboardScreenSelectedEntry(const UFortTournamentLeaderboardEntryData*& Value) { Write<UFortTournamentLeaderboardEntryData*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayersProfiles(const TMap<FString, UFortTournamentPlayerProfileVM*>& Value) { Write<TMap<FString, UFortTournamentPlayerProfileVM*>>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x50, Type: MapProperty)
    void SET_LiveGames(const TArray<UFortTournamentWatchLiveEntryVM*>& Value) { Write<TArray<UFortTournamentWatchLiveEntryVM*>>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x10, Type: ArrayProperty)
    void SET_bShowDebugInfo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
class UFortUIGameFeatureAction_CompeteUI : public UFortUIGameFeatureAction
{
public:
};

// Size: 0x98
class UFortPoblanoTournamentsCalendarDayTileVM : public UMVVMViewModelBase
{
public:
    uint8_t CashCups() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t ShopCups() const { return Read<uint8_t>(uintptr_t(this) + 0x69); } // 0x69 (Size: 0x1, Type: EnumProperty)
    uint8_t FNCS() const { return Read<uint8_t>(uintptr_t(this) + 0x6a); } // 0x6a (Size: 0x1, Type: EnumProperty)
    uint8_t VictoryCups() const { return Read<uint8_t>(uintptr_t(this) + 0x6b); } // 0x6b (Size: 0x1, Type: EnumProperty)
    uint8_t RankedCups() const { return Read<uint8_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x1, Type: EnumProperty)
    uint8_t OtherCups() const { return Read<uint8_t>(uintptr_t(this) + 0x6d); } // 0x6d (Size: 0x1, Type: EnumProperty)
    TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*> BookmarkedTournaments() const { return Read<TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_CashCups(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
    void SET_ShopCups(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x69, Value); } // 0x69 (Size: 0x1, Type: EnumProperty)
    void SET_FNCS(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6a, Value); } // 0x6a (Size: 0x1, Type: EnumProperty)
    void SET_VictoryCups(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6b, Value); } // 0x6b (Size: 0x1, Type: EnumProperty)
    void SET_RankedCups(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x1, Type: EnumProperty)
    void SET_OtherCups(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6d, Value); } // 0x6d (Size: 0x1, Type: EnumProperty)
    void SET_BookmarkedTournaments(const TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*>& Value) { Write<TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3c0
class UFortPoblanoTournamentsCalendarFilterVM : public UMVVMViewModelBase
{
public:
    FTournamentsFilterSection SectionExperienceFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)
    TMap<EFortCompeteExperienceType, bool> SectionExperienceValues() const { return Read<TMap<EFortCompeteExperienceType, bool>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionTeamSizeFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x28, Type: StructProperty)
    TMap<EFortCompeteMatchType, bool> SectionTeamSizeValues() const { return Read<TMap<EFortCompeteMatchType, bool>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionRegionFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x28, Type: StructProperty)
    TMap<ERegionType, bool> SectionRegionValues() const { return Read<TMap<ERegionType, bool>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionTournamentTypeFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x28, Type: StructProperty)
    TMap<ETournamentTypeFilter, bool> SectionTournamentTypeValues() const { return Read<TMap<ETournamentTypeFilter, bool>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionTournamentStatusFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x28, Type: StructProperty)
    TMap<ETournamentStatusFilter, bool> SectionTournamentStatusValues() const { return Read<TMap<ETournamentStatusFilter, bool>>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionElegibilityFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x28, Type: StructProperty)
    TMap<EEligibilityType, bool> SectionElegibilityValues() const { return Read<TMap<EEligibilityType, bool>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionBookmarksFilter() const { return Read<FTournamentsFilterSection>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x28, Type: StructProperty)
    TMap<EBookmarkStateFilter, bool> SectionBookmarksValues() const { return Read<TMap<EBookmarkStateFilter, bool>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x50, Type: MapProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)

    void SET_SectionExperienceFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
    void SET_SectionExperienceValues(const TMap<EFortCompeteExperienceType, bool>& Value) { Write<TMap<EFortCompeteExperienceType, bool>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x50, Type: MapProperty)
    void SET_SectionTeamSizeFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x28, Type: StructProperty)
    void SET_SectionTeamSizeValues(const TMap<EFortCompeteMatchType, bool>& Value) { Write<TMap<EFortCompeteMatchType, bool>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x50, Type: MapProperty)
    void SET_SectionRegionFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x28, Type: StructProperty)
    void SET_SectionRegionValues(const TMap<ERegionType, bool>& Value) { Write<TMap<ERegionType, bool>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x50, Type: MapProperty)
    void SET_SectionTournamentTypeFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x28, Type: StructProperty)
    void SET_SectionTournamentTypeValues(const TMap<ETournamentTypeFilter, bool>& Value) { Write<TMap<ETournamentTypeFilter, bool>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x50, Type: MapProperty)
    void SET_SectionTournamentStatusFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x28, Type: StructProperty)
    void SET_SectionTournamentStatusValues(const TMap<ETournamentStatusFilter, bool>& Value) { Write<TMap<ETournamentStatusFilter, bool>>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x50, Type: MapProperty)
    void SET_SectionElegibilityFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x28, Type: StructProperty)
    void SET_SectionElegibilityValues(const TMap<EEligibilityType, bool>& Value) { Write<TMap<EEligibilityType, bool>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x50, Type: MapProperty)
    void SET_SectionBookmarksFilter(const FTournamentsFilterSection& Value) { Write<FTournamentsFilterSection>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x28, Type: StructProperty)
    void SET_SectionBookmarksValues(const TMap<EBookmarkStateFilter, bool>& Value) { Write<TMap<EBookmarkStateFilter, bool>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x50, Type: MapProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x190
class UFortPoblanoTournamentsCalendarTournamentTileVM : public UMVVMViewModelBase
{
public:
    FDateTime Date() const { return Read<FDateTime>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: StructProperty)
    FText TextDate() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    uint8_t Region() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t RankRequirement() const { return Read<uint8_t>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: EnumProperty)
    uint8_t RankRequirementCheckResult() const { return Read<uint8_t>(uintptr_t(this) + 0x82); } // 0x82 (Size: 0x1, Type: EnumProperty)
    uint8_t TournamentEligibility() const { return Read<uint8_t>(uintptr_t(this) + 0x83); } // 0x83 (Size: 0x1, Type: EnumProperty)
    bool bMeetsTournamentSystemRequirements() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    bool bMeetsRequiresQualifyingRound() const { return Read<bool>(uintptr_t(this) + 0x85); } // 0x85 (Size: 0x1, Type: BoolProperty)
    bool bMeetsEventsNumberHistoryRequirement() const { return Read<bool>(uintptr_t(this) + 0x86); } // 0x86 (Size: 0x1, Type: BoolProperty)
    bool bMeetsCheckTournamentLocksRequirement() const { return Read<bool>(uintptr_t(this) + 0x87); } // 0x87 (Size: 0x1, Type: BoolProperty)
    bool bMeetsAgeRequirement() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bMeetsAccountLevelRequirement() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)
    bool bMeetsPermanentTournamentBanRequirement() const { return Read<bool>(uintptr_t(this) + 0x8a); } // 0x8a (Size: 0x1, Type: BoolProperty)
    uint8_t TournamentState() const { return Read<uint8_t>(uintptr_t(this) + 0x8b); } // 0x8b (Size: 0x1, Type: EnumProperty)
    uint8_t TournamentTag() const { return Read<uint8_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x1, Type: EnumProperty)
    uint8_t ExperienceType() const { return Read<uint8_t>(uintptr_t(this) + 0x8d); } // 0x8d (Size: 0x1, Type: EnumProperty)
    uint8_t TeamSize() const { return Read<uint8_t>(uintptr_t(this) + 0x8e); } // 0x8e (Size: 0x1, Type: EnumProperty)
    FText TournamentTitle() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    bool bIsLive() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    bool bIsBookmarked() const { return Read<bool>(uintptr_t(this) + 0xa1); } // 0xa1 (Size: 0x1, Type: BoolProperty)
    UTexture2D* PosterTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FText RoundDateTime() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)
    FText BookmarksAmount() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FBackgroundColors BackgroundCalendarColors() const { return Read<FBackgroundColors>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    FString TournamentID() const { return Read<FString>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: StrProperty)
    FString TournamentWindowId() const { return Read<FString>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StrProperty)
    uint8_t GameType() const { return Read<uint8_t>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: EnumProperty)
    FFortTournamentLockStatus AllTournamentLocks() const { return Read<FFortTournamentLockStatus>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x20, Type: StructProperty)
    UEpicCMSImage* Poster() const { return Read<UEpicCMSImage*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    FTournamentRankRequirements RankInfo() const { return Read<FTournamentRankRequirements>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x28, Type: StructProperty)

    void SET_Date(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: StructProperty)
    void SET_TextDate(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_Region(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_RankRequirement(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: EnumProperty)
    void SET_RankRequirementCheckResult(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x82, Value); } // 0x82 (Size: 0x1, Type: EnumProperty)
    void SET_TournamentEligibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x83, Value); } // 0x83 (Size: 0x1, Type: EnumProperty)
    void SET_bMeetsTournamentSystemRequirements(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_bMeetsRequiresQualifyingRound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x85, Value); } // 0x85 (Size: 0x1, Type: BoolProperty)
    void SET_bMeetsEventsNumberHistoryRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x86, Value); } // 0x86 (Size: 0x1, Type: BoolProperty)
    void SET_bMeetsCheckTournamentLocksRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x87, Value); } // 0x87 (Size: 0x1, Type: BoolProperty)
    void SET_bMeetsAgeRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_bMeetsAccountLevelRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
    void SET_bMeetsPermanentTournamentBanRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8a, Value); } // 0x8a (Size: 0x1, Type: BoolProperty)
    void SET_TournamentState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8b, Value); } // 0x8b (Size: 0x1, Type: EnumProperty)
    void SET_TournamentTag(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x1, Type: EnumProperty)
    void SET_ExperienceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8d, Value); } // 0x8d (Size: 0x1, Type: EnumProperty)
    void SET_TeamSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8e, Value); } // 0x8e (Size: 0x1, Type: EnumProperty)
    void SET_TournamentTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_bIsLive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsBookmarked(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa1, Value); } // 0xa1 (Size: 0x1, Type: BoolProperty)
    void SET_PosterTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_RoundDateTime(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
    void SET_BookmarksAmount(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_BackgroundCalendarColors(const FBackgroundColors& Value) { Write<FBackgroundColors>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_TournamentID(const FString& Value) { Write<FString>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: StrProperty)
    void SET_TournamentWindowId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StrProperty)
    void SET_GameType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: EnumProperty)
    void SET_AllTournamentLocks(const FFortTournamentLockStatus& Value) { Write<FFortTournamentLockStatus>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x20, Type: StructProperty)
    void SET_Poster(const UEpicCMSImage*& Value) { Write<UEpicCMSImage*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_RankInfo(const FTournamentRankRequirements& Value) { Write<FTournamentRankRequirements>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x28, Type: StructProperty)
};

// Size: 0xe8
class UFortPoblanoTournamentsCalendarVM : public UMVVMViewModelBase
{
public:
    FTournamentsTilesData TournamentsTilesData() const { return Read<FTournamentsTilesData>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)
    FCalendarTilesData CalendarTilesData() const { return Read<FCalendarTilesData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FDateTime CurrentTime() const { return Read<FDateTime>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: StructProperty)
    FDateTime DisplayMonthDate() const { return Read<FDateTime>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: StructProperty)
    TArray<FString> MonthTournamentsIDs() const { return Read<TArray<FString>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_TournamentsTilesData(const FTournamentsTilesData& Value) { Write<FTournamentsTilesData>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
    void SET_CalendarTilesData(const FCalendarTilesData& Value) { Write<FCalendarTilesData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_CurrentTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: StructProperty)
    void SET_DisplayMonthDate(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: StructProperty)
    void SET_MonthTournamentsIDs(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf0
class UFortTournamentBaseEntryVM : public UFortPerUserViewModel
{
public:
    FString LiveSessionId() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    TArray<FString> TeammatesAccountIds() const { return Read<TArray<FString>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, UFortTournamentPlayerProfileVM*> PlayersProfiles() const { return Read<TMap<FString, UFortTournamentPlayerProfileVM*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x50, Type: MapProperty)
    int32_t AdjustedRank() const { return Read<int32_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: IntProperty)
    int32_t MatchesPlayed() const { return Read<int32_t>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: IntProperty)
    int32_t TotalPoints() const { return Read<int32_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: IntProperty)

    void SET_LiveSessionId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_TeammatesAccountIds(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayersProfiles(const TMap<FString, UFortTournamentPlayerProfileVM*>& Value) { Write<TMap<FString, UFortTournamentPlayerProfileVM*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x50, Type: MapProperty)
    void SET_AdjustedRank(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: IntProperty)
    void SET_MatchesPlayed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: IntProperty)
    void SET_TotalPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1b8
class UFortTournamentLeaderboardEntryData : public UFortTournamentBaseEntryVM
{
public:
    int32_t DisplayIndex() const { return Read<int32_t>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: IntProperty)
    int32_t EntryIndex() const { return Read<int32_t>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: IntProperty)
    TMap<FString, int32_t> TrackedStatsTimesAchieved() const { return Read<TMap<FString, int32_t>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x50, Type: MapProperty)
    TMap<FString, int32_t> TrackedStatsPoints() const { return Read<TMap<FString, int32_t>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x50, Type: MapProperty)
    int32_t TotalVictoryRoyales() const { return Read<int32_t>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x4, Type: IntProperty)
    int32_t TotalEliminations() const { return Read<int32_t>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x4, Type: IntProperty)
    float AveragePlacement() const { return Read<float>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    bool bUseQualifiedIcons() const { return Read<bool>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x1, Type: BoolProperty)
    bool bIsTeamQualified() const { return Read<bool>(uintptr_t(this) + 0x1a5); } // 0x1a5 (Size: 0x1, Type: BoolProperty)
    bool bIsMatchPointWinner() const { return Read<bool>(uintptr_t(this) + 0x1a6); } // 0x1a6 (Size: 0x1, Type: BoolProperty)
    bool bIsSeriesPointLeaderboards() const { return Read<bool>(uintptr_t(this) + 0x1a7); } // 0x1a7 (Size: 0x1, Type: BoolProperty)
    TArray<UFortTournamentLeaderboardSessionTeamEntryVM*> SessionsTeamEntries() const { return Read<TArray<UFortTournamentLeaderboardSessionTeamEntryVM*>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)

    void SET_DisplayIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: IntProperty)
    void SET_EntryIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: IntProperty)
    void SET_TrackedStatsTimesAchieved(const TMap<FString, int32_t>& Value) { Write<TMap<FString, int32_t>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x50, Type: MapProperty)
    void SET_TrackedStatsPoints(const TMap<FString, int32_t>& Value) { Write<TMap<FString, int32_t>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x50, Type: MapProperty)
    void SET_TotalVictoryRoyales(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x4, Type: IntProperty)
    void SET_TotalEliminations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x4, Type: IntProperty)
    void SET_AveragePlacement(const float& Value) { Write<float>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    void SET_bUseQualifiedIcons(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTeamQualified(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a5, Value); } // 0x1a5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsMatchPointWinner(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a6, Value); } // 0x1a6 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSeriesPointLeaderboards(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a7, Value); } // 0x1a7 (Size: 0x1, Type: BoolProperty)
    void SET_SessionsTeamEntries(const TArray<UFortTournamentLeaderboardSessionTeamEntryVM*>& Value) { Write<TArray<UFortTournamentLeaderboardSessionTeamEntryVM*>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd8
class UFortTournamentLeaderboardSessionTeamEntryVM : public UMVVMViewModelBase
{
public:
    FString SessionId() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    int32_t SessionNumber() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    TMap<FString, int32_t> TrackedStatsTimesAchieved() const { return Read<TMap<FString, int32_t>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)
    int32_t CreativeScore() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)
    bool bShowCreativeScore() const { return Read<bool>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    bool bShowEliminations() const { return Read<bool>(uintptr_t(this) + 0xd5); } // 0xd5 (Size: 0x1, Type: BoolProperty)
    bool bIsScoreContributor() const { return Read<bool>(uintptr_t(this) + 0xd6); } // 0xd6 (Size: 0x1, Type: BoolProperty)

    void SET_SessionId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_SessionNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_TrackedStatsTimesAchieved(const TMap<FString, int32_t>& Value) { Write<TMap<FString, int32_t>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
    void SET_CreativeScore(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
    void SET_bShowCreativeScore(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    void SET_bShowEliminations(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd5, Value); } // 0xd5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsScoreContributor(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd6, Value); } // 0xd6 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c8
class UFortTournamentLeaderboardVM : public UMVVMViewModelBase
{
public:
    TMap<FString, FFortTournamentLeaderboardViewState> ViewStates() const { return Read<TMap<FString, FFortTournamentLeaderboardViewState>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x50, Type: MapProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortCompeteUILeaderboardCategory> LeaderboardCategories() const { return Read<TArray<FFortCompeteUILeaderboardCategory>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    int32_t CurrentLeaderboardCategoryIndex() const { return Read<int32_t>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: IntProperty)
    bool bShowFriendsOnly() const { return Read<bool>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x1, Type: BoolProperty)
    FText TournamentName() const { return Read<FText>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: TextProperty)
    FText RegionName() const { return Read<FText>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: TextProperty)
    TArray<FString> EventWindowsList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    bool bIsModelInitialized() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)
    int32_t QualifierScore() const { return Read<int32_t>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: IntProperty)
    FTournamentPayoutThresholdData TokenData() const { return Read<FTournamentPayoutThresholdData>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x80, Type: StructProperty)
    FDateTime LeaderboardUpdateTime() const { return Read<FDateTime>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: StructProperty)
    UUIKitDialogViewModel* MatchHistoryDialogVM() const { return Read<UUIKitDialogViewModel*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)

    void SET_ViewStates(const TMap<FString, FFortTournamentLeaderboardViewState>& Value) { Write<TMap<FString, FFortTournamentLeaderboardViewState>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x50, Type: MapProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderboardCategories(const TArray<FFortCompeteUILeaderboardCategory>& Value) { Write<TArray<FFortCompeteUILeaderboardCategory>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentLeaderboardCategoryIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: IntProperty)
    void SET_bShowFriendsOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x1, Type: BoolProperty)
    void SET_TournamentName(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: TextProperty)
    void SET_RegionName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: TextProperty)
    void SET_EventWindowsList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsModelInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
    void SET_QualifierScore(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: IntProperty)
    void SET_TokenData(const FTournamentPayoutThresholdData& Value) { Write<FTournamentPayoutThresholdData>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x80, Type: StructProperty)
    void SET_LeaderboardUpdateTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: StructProperty)
    void SET_MatchHistoryDialogVM(const UUIKitDialogViewModel*& Value) { Write<UUIKitDialogViewModel*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x118
class UFortTournamentRequirementsModalVM : public UMVVMViewModelBase
{
public:
    TArray<FTournamentRequirementItem> RequirementsList() const { return Read<TArray<FTournamentRequirementItem>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    bool bAllChecksPassed() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    FTournamentRankRequirements RankInfo() const { return Read<FTournamentRankRequirements>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    uint8_t LastCheckRankResult() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)

    void SET_RequirementsList(const TArray<FTournamentRequirementItem>& Value) { Write<TArray<FTournamentRequirementItem>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllChecksPassed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_RankInfo(const FTournamentRankRequirements& Value) { Write<FTournamentRankRequirements>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_LastCheckRankResult(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1f8
class UFortTournamentSeriesPointLeaderboardVM : public UFortTournamentLeaderboardVM
{
public:
};

// Size: 0x1c8
class UFortTournamentSessionLeaderboardVM : public UFortTournamentLeaderboardVM
{
public:
};

// Size: 0x108
class UFortTournamentWatchLiveEntryVM : public UFortTournamentBaseEntryVM
{
public:
    FText TimeSinceGameStart() const { return Read<FText>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: TextProperty)

    void SET_TimeSinceGameStart(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: TextProperty)
};

// Size: 0xd8
class UFortTournamentWatchLiveVM : public UMVVMViewModelBase
{
public:
    bool bIsModelInitialized() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    UFortCompeteUIManager* CompeteUIManager() const { return Read<UFortCompeteUIManager*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    FText TournamentName() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    TArray<UFortTournamentWatchLiveEntryVM*> LiveGames() const { return Read<TArray<UFortTournamentWatchLiveEntryVM*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_bIsModelInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_CompeteUIManager(const UFortCompeteUIManager*& Value) { Write<UFortCompeteUIManager*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_LiveGames(const TArray<UFortTournamentWatchLiveEntryVM*>& Value) { Write<TArray<UFortTournamentWatchLiveEntryVM*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x178
struct FFortCompeteTournamentDisplayInfo : public FTableRowBase
{
public:
    FText TitleLine1() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText TitleLine2() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    FText ScheduleInfo() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)
    FText FlavorDescription() const { return Read<FText>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: TextProperty)
    FText DetailsDescription() const { return Read<FText>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: TextProperty)
    FText ShortFormatTitle() const { return Read<FText>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: TextProperty)
    FText LongFormatTitle() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    FText BackgroundTitle() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    int32_t PinScoreRequirement() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    FText PinEarnedText() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FLinearColor BaseColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)
    FLinearColor PrimaryColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: StructProperty)
    FLinearColor SecondaryColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: StructProperty)
    FLinearColor HighlightColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    FLinearColor TitleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StructProperty)
    FLinearColor ShadowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundLeftColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundRightColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundTextColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: StructProperty)
    FLinearColor PosterFadeColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: StructProperty)
    FText AlertText() const { return Read<FText>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: TextProperty)
    FText SeriesPointLeaderboardName() const { return Read<FText>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: TextProperty)
    uint8_t AlertType() const { return Read<uint8_t>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: EnumProperty)
    TArray<FText> RoundDisplayNames() const { return Read<TArray<FText>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: ArrayProperty)

    void SET_TitleLine1(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_TitleLine2(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_ScheduleInfo(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
    void SET_FlavorDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: TextProperty)
    void SET_DetailsDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: TextProperty)
    void SET_ShortFormatTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: TextProperty)
    void SET_LongFormatTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_BackgroundTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_PinScoreRequirement(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_PinEarnedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_BaseColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
    void SET_PrimaryColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: StructProperty)
    void SET_SecondaryColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: StructProperty)
    void SET_HighlightColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_TitleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StructProperty)
    void SET_ShadowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundLeftColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundRightColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundTextColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: StructProperty)
    void SET_PosterFadeColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: StructProperty)
    void SET_AlertText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: TextProperty)
    void SET_SeriesPointLeaderboardName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: TextProperty)
    void SET_AlertType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: EnumProperty)
    void SET_RoundDisplayNames(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FFortCompeteUILeaderboardCategory
{
public:
    FText LeaderboardName() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FString GroupingKey() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString InstanceID() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_LeaderboardName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_GroupingKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_InstanceID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x60
struct FFortCompeteUILeaderboardRequestParams
{
public:
    UClass* LeaderboardClassPtr() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)

    void SET_LeaderboardClassPtr(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
struct FTournamentRankRequirements
{
public:
    FString Type() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Mode() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t Level() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_Type(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Mode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Level(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0xa8
struct FFortCompeteTournamentStyleInfo : public FTableRowBase
{
public:
    FLinearColor BaseColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FLinearColor PrimaryColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor SecondaryColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor HighlightColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor TitleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor ShadowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundLeftColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundRightColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundTextColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    FLinearColor PosterFadeColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)

    void SET_BaseColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_PrimaryColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_SecondaryColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_HighlightColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_TitleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_ShadowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundLeftColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundRightColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundTextColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_PosterFadeColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FTournamentLeaderboardScreenParams
{
public:
    APlayerController* ContextPC() const { return Read<APlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FString TournamentID() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FString TournamentWindowId() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    bool bIsTournamentSeriesPointLeaderboard() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    UFortTournamentWatchLiveVM* TournamentWatchLiveEntryVM() const { return Read<UFortTournamentWatchLiveVM*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentHeaderVM* TournamentHeaderVM() const { return Read<UFortTournamentHeaderVM*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    TArray<FTournamentLeaderboardPayoutTableData> PayoutDisplayData() const { return Read<TArray<FTournamentLeaderboardPayoutTableData>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_ContextPC(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_TournamentWindowId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_bIsTournamentSeriesPointLeaderboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_TournamentWatchLiveEntryVM(const UFortTournamentWatchLiveVM*& Value) { Write<UFortTournamentWatchLiveVM*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentHeaderVM(const UFortTournamentHeaderVM*& Value) { Write<UFortTournamentHeaderVM*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_PayoutDisplayData(const TArray<FTournamentLeaderboardPayoutTableData>& Value) { Write<TArray<FTournamentLeaderboardPayoutTableData>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FSetTournamentLeaderboardType
{
public:
    bool bIsTournamentSeriesPointLeaderboard() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    UFortTournamentWatchLiveVM* TournamentWatchLiveVM() const { return Read<UFortTournamentWatchLiveVM*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentHeaderVM* TournamentHeaderVM() const { return Read<UFortTournamentHeaderVM*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<FTournamentLeaderboardPayoutTableData> PayoutDisplayData() const { return Read<TArray<FTournamentLeaderboardPayoutTableData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_bIsTournamentSeriesPointLeaderboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_TournamentWatchLiveVM(const UFortTournamentWatchLiveVM*& Value) { Write<UFortTournamentWatchLiveVM*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentHeaderVM(const UFortTournamentHeaderVM*& Value) { Write<UFortTournamentHeaderVM*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_PayoutDisplayData(const TArray<FTournamentLeaderboardPayoutTableData>& Value) { Write<TArray<FTournamentLeaderboardPayoutTableData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FBackgroundColors
{
public:
    FLinearColor Main() const { return Read<FLinearColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor Sub() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Main(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Sub(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FTournamentTypeWithName
{
public:
    FText Name() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_Name(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
struct FTournamentsFilterSection
{
public:
    FText SectionName() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    TArray<FTournamentTypeWithName> FilterOptions() const { return Read<TArray<FTournamentTypeWithName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bRadioType() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_SectionName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_FilterOptions(const TArray<FTournamentTypeWithName>& Value) { Write<TArray<FTournamentTypeWithName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bRadioType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FTournamentRequirementItemArguments
{
public:
    uint8_t HabaneroRankCheckResult() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FString EULAKey() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t MinimumAccountLevel() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t NumberMatchesPlayed() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t NumberOfMatchesNeedToBePlayed() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t SeasonNumber() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)

    void SET_HabaneroRankCheckResult(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_EULAKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_MinimumAccountLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_NumberMatchesPlayed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_NumberOfMatchesNeedToBePlayed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_SeasonNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FTournamentRequirementItem
{
public:
    uint8_t RequirementType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bHasPassed() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    FTournamentRequirementItemArguments Arguments() const { return Read<FTournamentRequirementItemArguments>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)

    void SET_RequirementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_bHasPassed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_Arguments(const FTournamentRequirementItemArguments& Value) { Write<FTournamentRequirementItemArguments>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x30
struct FFortCompeteFrontendNotificationData
{
public:
    FString EventId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString EventWindowId() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_EventId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_EventWindowId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
struct FTournamentsTilesData
{
public:
    TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*> TournamentTiles() const { return Read<TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t PreviouslySelectedEvent() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t FirstUpcomingEvent() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t FirstLiveEvent() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t FirstCurrentDateEvent() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    bool bIsLoadingTournaments() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_TournamentTiles(const TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*>& Value) { Write<TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviouslySelectedEvent(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_FirstUpcomingEvent(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_FirstLiveEvent(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_FirstCurrentDateEvent(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_bIsLoadingTournaments(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FCalendarTilesData
{
public:
    TArray<UFortPoblanoTournamentsCalendarDayTileVM*> DayTiles() const { return Read<TArray<UFortPoblanoTournamentsCalendarDayTileVM*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t FirstDayOfWeekForCurrentMonth() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_DayTiles(const TArray<UFortPoblanoTournamentsCalendarDayTileVM*>& Value) { Write<TArray<UFortPoblanoTournamentsCalendarDayTileVM*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_FirstDayOfWeekForCurrentMonth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x68
struct FFortTournamentLeaderboardViewState
{
public:
    TArray<UFortTournamentLeaderboardEntryData*> Entries() const { return Read<TArray<UFortTournamentLeaderboardEntryData*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortTournamentLeaderboardEntryData*> FilteredEntries() const { return Read<TArray<UFortTournamentLeaderboardEntryData*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UFortTournamentLeaderboardEntryData> LocalPlayerEntry() const { return Read<TSoftObjectPtr<UFortTournamentLeaderboardEntryData>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Entries(const TArray<UFortTournamentLeaderboardEntryData*>& Value) { Write<TArray<UFortTournamentLeaderboardEntryData*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_FilteredEntries(const TArray<UFortTournamentLeaderboardEntryData*>& Value) { Write<TArray<UFortTournamentLeaderboardEntryData*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_LocalPlayerEntry(const TSoftObjectPtr<UFortTournamentLeaderboardEntryData>& Value) { Write<TSoftObjectPtr<UFortTournamentLeaderboardEntryData>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

