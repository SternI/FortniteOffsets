/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContentResolver
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa8
class UPluginBatchLoaderHelper : public UObject
{
public:
};

// Size: 0x48
class UExternalContentLoader : public UEngineSubsystem
{
public:
};

