/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortVehicleSimulationStepsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DataRegistry.h"

// Size: 0x88
class UFortVehicleSimulationStepsManager : public UObject
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EVehicleSimStepFlags> DefaultSimulationStepFlags() const { return Read<TEnumAsByte<EVehicleSimStepFlags>>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: ByteProperty)
    FDataRegistryType DataRegistryType_VehicleSimulationStepsPermissions() const { return Read<FDataRegistryType>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)
    FDataRegistryType DataRegistryType_VehicleSimulationStepsConfig() const { return Read<FDataRegistryType>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultSimulationStepFlags(const TEnumAsByte<EVehicleSimStepFlags>& Value) { Write<TEnumAsByte<EVehicleSimStepFlags>>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: ByteProperty)
    void SET_DataRegistryType_VehicleSimulationStepsPermissions(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
    void SET_DataRegistryType_VehicleSimulationStepsConfig(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FFortVehicleSimulationStepOverrideTableRow : public FTableRowBase
{
public:
    TEnumAsByte<EVehicleSimStep> SimulationStep() const { return Read<TEnumAsByte<EVehicleSimStep>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVehicleSimStepFlags> SimulationStepFlags() const { return Read<TEnumAsByte<EVehicleSimStepFlags>>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: ByteProperty)

    void SET_SimulationStep(const TEnumAsByte<EVehicleSimStep>& Value) { Write<TEnumAsByte<EVehicleSimStep>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
    void SET_SimulationStepFlags(const TEnumAsByte<EVehicleSimStepFlags>& Value) { Write<TEnumAsByte<EVehicleSimStepFlags>>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x10
struct FFortVehicleSimulationConfigTableRow : public FTableRowBase
{
public:
    bool bIsSimulationManagerEnabled() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EVehicleSimStepFlags> DefaultSimulationStepFlags() const { return Read<TEnumAsByte<EVehicleSimStepFlags>>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: ByteProperty)

    void SET_bIsSimulationManagerEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultSimulationStepFlags(const TEnumAsByte<EVehicleSimStepFlags>& Value) { Write<TEnumAsByte<EVehicleSimStepFlags>>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: ByteProperty)
};

