/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Constraints
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "MovieScene.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimationCore.h"

// Size: 0x50
class UConstraintSubsystem : public UEngineSubsystem
{
public:
    uint8_t OnConstraintAddedToSystem_BP() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t OnConstraintRemovedFromSystem_BP() const { return Read<uint8_t>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    TArray<FConstraintsInWorld> ConstraintsInWorld() const { return Read<TArray<FConstraintsInWorld>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_OnConstraintAddedToSystem_BP(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    void SET_OnConstraintRemovedFromSystem_BP(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    void SET_ConstraintsInWorld(const TArray<FConstraintsInWorld>& Value) { Write<TArray<FConstraintsInWorld>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2b0
class AConstraintsActor : public AActor
{
public:
    UConstraintsManager* ConstraintsManager() const { return Read<UConstraintsManager*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_ConstraintsManager(const UConstraintsManager*& Value) { Write<UConstraintsManager*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x90
class UTickableConstraint : public UObject
{
public:
    bool Active() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bValid() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)

    void SET_Active(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
class UConstraintsManager : public UObject
{
public:
    uint8_t OnConstraintAdded_BP() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t OnConstraintRemoved_BP() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    TArray<UTickableConstraint*> Constraints() const { return Read<TArray<UTickableConstraint*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_OnConstraintAdded_BP(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    void SET_OnConstraintRemoved_BP(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    void SET_Constraints(const TArray<UTickableConstraint*>& Value) { Write<TArray<UTickableConstraint*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UConstraintsScriptingLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x60
class UTransformableHandle : public UObject
{
public:
    FMovieSceneObjectBindingID ConstraintBindingID() const { return Read<FMovieSceneObjectBindingID>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x18, Type: StructProperty)

    void SET_ConstraintBindingID(const FMovieSceneObjectBindingID& Value) { Write<FMovieSceneObjectBindingID>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
class UTransformableComponentHandle : public UTransformableHandle
{
public:
    TWeakObjectPtr<USceneComponent*> Component() const { return Read<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: WeakObjectProperty)
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: NameProperty)

    void SET_Component(const TWeakObjectPtr<USceneComponent*>& Value) { Write<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: NameProperty)
};

// Size: 0xb0
class UTickableTransformConstraint : public UTickableConstraint
{
public:
    UTransformableHandle* ParentTRSHandle() const { return Read<UTransformableHandle*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    UTransformableHandle* ChildTRSHandle() const { return Read<UTransformableHandle*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    bool bDynamicOffset() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0xa9); } // 0xa9 (Size: 0x1, Type: EnumProperty)

    void SET_ParentTRSHandle(const UTransformableHandle*& Value) { Write<UTransformableHandle*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_ChildTRSHandle(const UTransformableHandle*& Value) { Write<UTransformableHandle*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_bDynamicOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa9, Value); } // 0xa9 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xd8
class UTickableTranslationConstraint : public UTickableTransformConstraint
{
public:
    FVector OffsetTranslation() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    FFilterOptionPerAxis AxisFilter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x3, Type: StructProperty)

    void SET_OffsetTranslation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_AxisFilter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x3, Type: StructProperty)
};

// Size: 0xf0
class UTickableRotationConstraint : public UTickableTransformConstraint
{
public:
    FQuat OffsetRotation() const { return Read<FQuat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x20, Type: StructProperty)
    FFilterOptionPerAxis AxisFilter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x3, Type: StructProperty)

    void SET_OffsetRotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x20, Type: StructProperty)
    void SET_AxisFilter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x3, Type: StructProperty)
};

// Size: 0xd8
class UTickableScaleConstraint : public UTickableTransformConstraint
{
public:
    FVector OffsetScale() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    FFilterOptionPerAxis AxisFilter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x3, Type: StructProperty)

    void SET_OffsetScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_AxisFilter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x3, Type: StructProperty)
};

// Size: 0x130
class UTickableParentConstraint : public UTickableTransformConstraint
{
public:
    FTransform OffsetTransform() const { return Read<FTransform>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x60, Type: StructProperty)
    bool bScaling() const { return Read<bool>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: BoolProperty)
    FTransformFilter TransformFilter() const { return Read<FTransformFilter>(uintptr_t(this) + 0x121); } // 0x121 (Size: 0x9, Type: StructProperty)

    void SET_OffsetTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x60, Type: StructProperty)
    void SET_bScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: BoolProperty)
    void SET_TransformFilter(const FTransformFilter& Value) { Write<FTransformFilter>(uintptr_t(this) + 0x121, Value); } // 0x121 (Size: 0x9, Type: StructProperty)
};

// Size: 0xc8
class UTickableLookAtConstraint : public UTickableTransformConstraint
{
public:
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x18, Type: StructProperty)

    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FConstraintsInWorld
{
public:
    TWeakObjectPtr<UWorld*> World() const { return Read<TWeakObjectPtr<UWorld*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UTickableConstraint*>> Constraints() const { return Read<TArray<TWeakObjectPtr<UTickableConstraint*>>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_World(const TWeakObjectPtr<UWorld*>& Value) { Write<TWeakObjectPtr<UWorld*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Constraints(const TArray<TWeakObjectPtr<UTickableConstraint*>>& Value) { Write<TArray<TWeakObjectPtr<UTickableConstraint*>>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x108
struct FMovieSceneConstraintChannel : public FMovieSceneBoolChannel
{
public:
};

// Size: 0x110
struct FConstraintAndActiveChannel
{
public:
    FMovieSceneConstraintChannel ActiveChannel() const { return Read<FMovieSceneConstraintChannel>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x108, Type: StructProperty)
    UTickableConstraint* ConstraintCopyToSpawn() const { return Read<UTickableConstraint*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)

    void SET_ActiveChannel(const FMovieSceneConstraintChannel& Value) { Write<FMovieSceneConstraintChannel>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x108, Type: StructProperty)
    void SET_ConstraintCopyToSpawn(const UTickableConstraint*& Value) { Write<UTickableConstraint*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
struct FConstraintTickFunction : public FTickFunction
{
public:
};

