/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ArmoredBattleBusRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x13d0
class UFortArmoredBattleBusPassengerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    FRotator PreviousVehicleRotator() const { return Read<FRotator>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x18, Type: StructProperty)
    float SmoothedVehicleYawRate() const { return Read<float>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x4, Type: FloatProperty)
    int32_t PawnSeat() const { return Read<int32_t>(uintptr_t(this) + 0x1324); } // 0x1324 (Size: 0x4, Type: IntProperty)
    bool bIsFrontTurretPassenger() const { return Read<bool>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x1, Type: BoolProperty)
    bool bIsRearTurretPassenger() const { return Read<bool>(uintptr_t(this) + 0x1329); } // 0x1329 (Size: 0x1, Type: BoolProperty)
    float Speed() const { return Read<float>(uintptr_t(this) + 0x132c); } // 0x132c (Size: 0x4, Type: FloatProperty)
    float YawDelta() const { return Read<float>(uintptr_t(this) + 0x1330); } // 0x1330 (Size: 0x4, Type: FloatProperty)
    float TurretYaw() const { return Read<float>(uintptr_t(this) + 0x1334); } // 0x1334 (Size: 0x4, Type: FloatProperty)
    float TurretPitch() const { return Read<float>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x4, Type: FloatProperty)
    FRotator TurretYawRotator() const { return Read<FRotator>(uintptr_t(this) + 0x1340); } // 0x1340 (Size: 0x18, Type: StructProperty)
    float SlopeRollDegreeAngle() const { return Read<float>(uintptr_t(this) + 0x1358); } // 0x1358 (Size: 0x4, Type: FloatProperty)
    float SlopePitchDegreeAngle() const { return Read<float>(uintptr_t(this) + 0x135c); } // 0x135c (Size: 0x4, Type: FloatProperty)
    FVector HandAttachL() const { return Read<FVector>(uintptr_t(this) + 0x1360); } // 0x1360 (Size: 0x18, Type: StructProperty)
    FVector HandAttachR() const { return Read<FVector>(uintptr_t(this) + 0x1378); } // 0x1378 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ERelativeTransformSpace> TransformSpace() const { return Read<TEnumAsByte<ERelativeTransformSpace>>(uintptr_t(this) + 0x1390); } // 0x1390 (Size: 0x1, Type: ByteProperty)
    float UpdateYawDeltaSmoothedLerpRate() const { return Read<float>(uintptr_t(this) + 0x1394); } // 0x1394 (Size: 0x4, Type: FloatProperty)
    int32_t TurretPassengerFront() const { return Read<int32_t>(uintptr_t(this) + 0x1398); } // 0x1398 (Size: 0x4, Type: IntProperty)
    int32_t TurretPassengerRear() const { return Read<int32_t>(uintptr_t(this) + 0x139c); } // 0x139c (Size: 0x4, Type: IntProperty)
    FName FrontFootBoneName() const { return Read<FName>(uintptr_t(this) + 0x13a0); } // 0x13a0 (Size: 0x4, Type: NameProperty)
    FName RearFootBoneName() const { return Read<FName>(uintptr_t(this) + 0x13a4); } // 0x13a4 (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_FrontLeft() const { return Read<FName>(uintptr_t(this) + 0x13a8); } // 0x13a8 (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_RearLeft() const { return Read<FName>(uintptr_t(this) + 0x13ac); } // 0x13ac (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_FrontRight() const { return Read<FName>(uintptr_t(this) + 0x13b0); } // 0x13b0 (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_RearRight() const { return Read<FName>(uintptr_t(this) + 0x13b4); } // 0x13b4 (Size: 0x4, Type: NameProperty)
    FName PassengerBoneName_Front() const { return Read<FName>(uintptr_t(this) + 0x13b8); } // 0x13b8 (Size: 0x4, Type: NameProperty)
    FName PassengerBoneName_Rear() const { return Read<FName>(uintptr_t(this) + 0x13bc); } // 0x13bc (Size: 0x4, Type: NameProperty)
    float TurretPitchDegMin() const { return Read<float>(uintptr_t(this) + 0x13c0); } // 0x13c0 (Size: 0x4, Type: FloatProperty)
    float TurretPitchDegMax() const { return Read<float>(uintptr_t(this) + 0x13c4); } // 0x13c4 (Size: 0x4, Type: FloatProperty)
    float LocalPlayerTurretPitchEaseRate() const { return Read<float>(uintptr_t(this) + 0x13c8); } // 0x13c8 (Size: 0x4, Type: FloatProperty)

    void SET_PreviousVehicleRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x18, Type: StructProperty)
    void SET_SmoothedVehicleYawRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x4, Type: FloatProperty)
    void SET_PawnSeat(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1324, Value); } // 0x1324 (Size: 0x4, Type: IntProperty)
    void SET_bIsFrontTurretPassenger(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x1, Type: BoolProperty)
    void SET_bIsRearTurretPassenger(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1329, Value); } // 0x1329 (Size: 0x1, Type: BoolProperty)
    void SET_Speed(const float& Value) { Write<float>(uintptr_t(this) + 0x132c, Value); } // 0x132c (Size: 0x4, Type: FloatProperty)
    void SET_YawDelta(const float& Value) { Write<float>(uintptr_t(this) + 0x1330, Value); } // 0x1330 (Size: 0x4, Type: FloatProperty)
    void SET_TurretYaw(const float& Value) { Write<float>(uintptr_t(this) + 0x1334, Value); } // 0x1334 (Size: 0x4, Type: FloatProperty)
    void SET_TurretPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x4, Type: FloatProperty)
    void SET_TurretYawRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1340, Value); } // 0x1340 (Size: 0x18, Type: StructProperty)
    void SET_SlopeRollDegreeAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x1358, Value); } // 0x1358 (Size: 0x4, Type: FloatProperty)
    void SET_SlopePitchDegreeAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x135c, Value); } // 0x135c (Size: 0x4, Type: FloatProperty)
    void SET_HandAttachL(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1360, Value); } // 0x1360 (Size: 0x18, Type: StructProperty)
    void SET_HandAttachR(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1378, Value); } // 0x1378 (Size: 0x18, Type: StructProperty)
    void SET_TransformSpace(const TEnumAsByte<ERelativeTransformSpace>& Value) { Write<TEnumAsByte<ERelativeTransformSpace>>(uintptr_t(this) + 0x1390, Value); } // 0x1390 (Size: 0x1, Type: ByteProperty)
    void SET_UpdateYawDeltaSmoothedLerpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1394, Value); } // 0x1394 (Size: 0x4, Type: FloatProperty)
    void SET_TurretPassengerFront(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1398, Value); } // 0x1398 (Size: 0x4, Type: IntProperty)
    void SET_TurretPassengerRear(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x139c, Value); } // 0x139c (Size: 0x4, Type: IntProperty)
    void SET_FrontFootBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13a0, Value); } // 0x13a0 (Size: 0x4, Type: NameProperty)
    void SET_RearFootBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13a4, Value); } // 0x13a4 (Size: 0x4, Type: NameProperty)
    void SET_GunHandAttachBoneName_FrontLeft(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13a8, Value); } // 0x13a8 (Size: 0x4, Type: NameProperty)
    void SET_GunHandAttachBoneName_RearLeft(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13ac, Value); } // 0x13ac (Size: 0x4, Type: NameProperty)
    void SET_GunHandAttachBoneName_FrontRight(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13b0, Value); } // 0x13b0 (Size: 0x4, Type: NameProperty)
    void SET_GunHandAttachBoneName_RearRight(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13b4, Value); } // 0x13b4 (Size: 0x4, Type: NameProperty)
    void SET_PassengerBoneName_Front(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13b8, Value); } // 0x13b8 (Size: 0x4, Type: NameProperty)
    void SET_PassengerBoneName_Rear(const FName& Value) { Write<FName>(uintptr_t(this) + 0x13bc, Value); } // 0x13bc (Size: 0x4, Type: NameProperty)
    void SET_TurretPitchDegMin(const float& Value) { Write<float>(uintptr_t(this) + 0x13c0, Value); } // 0x13c0 (Size: 0x4, Type: FloatProperty)
    void SET_TurretPitchDegMax(const float& Value) { Write<float>(uintptr_t(this) + 0x13c4, Value); } // 0x13c4 (Size: 0x4, Type: FloatProperty)
    void SET_LocalPlayerTurretPitchEaseRate(const float& Value) { Write<float>(uintptr_t(this) + 0x13c8, Value); } // 0x13c8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x730
class UFortArmoredBattleBusVehicleAnimInstance : public UFortVehicleAnimInstance
{
public:
    float FrontTurretAimPitch() const { return Read<float>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x4, Type: FloatProperty)
    float RearTurretAimPitch() const { return Read<float>(uintptr_t(this) + 0x69c); } // 0x69c (Size: 0x4, Type: FloatProperty)
    float FrontYawDeltaSmoothed() const { return Read<float>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x4, Type: FloatProperty)
    float RearYawDeltaSmoothed() const { return Read<float>(uintptr_t(this) + 0x6a4); } // 0x6a4 (Size: 0x4, Type: FloatProperty)
    float SmoothedVehicleYawRate() const { return Read<float>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x4, Type: FloatProperty)
    float FrontYawDeltaSmoothedAlpha() const { return Read<float>(uintptr_t(this) + 0x6ac); } // 0x6ac (Size: 0x4, Type: FloatProperty)
    float RearYawDeltaSmoothedAlpha() const { return Read<float>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x4, Type: FloatProperty)
    FRotator FrontWeaponYaw() const { return Read<FRotator>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x18, Type: StructProperty)
    FRotator RearWeaponYaw() const { return Read<FRotator>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x18, Type: StructProperty)
    FRotator PreviousVehicleRotator() const { return Read<FRotator>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x18, Type: StructProperty)
    bool bHasFrontTurretPassenger() const { return Read<bool>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x1, Type: BoolProperty)
    bool bHasRearTurretPassenger() const { return Read<bool>(uintptr_t(this) + 0x701); } // 0x701 (Size: 0x1, Type: BoolProperty)
    float NetworkEaseRate() const { return Read<float>(uintptr_t(this) + 0x704); } // 0x704 (Size: 0x4, Type: FloatProperty)
    float UpdateYawDeltaSmoothedLerpRate() const { return Read<float>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x4, Type: FloatProperty)
    int32_t FrontPassengerSeatIndex() const { return Read<int32_t>(uintptr_t(this) + 0x70c); } // 0x70c (Size: 0x4, Type: IntProperty)
    int32_t RearPassengerSeatIndex() const { return Read<int32_t>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x4, Type: IntProperty)
    float FrontPassengerYawOffset() const { return Read<float>(uintptr_t(this) + 0x714); } // 0x714 (Size: 0x4, Type: FloatProperty)
    float RearPassengerYawOffset() const { return Read<float>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x4, Type: FloatProperty)
    FName FrontPassengerBoneName() const { return Read<FName>(uintptr_t(this) + 0x71c); } // 0x71c (Size: 0x4, Type: NameProperty)
    FName RearPassengerBoneName() const { return Read<FName>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x4, Type: NameProperty)

    void SET_FrontTurretAimPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x4, Type: FloatProperty)
    void SET_RearTurretAimPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x69c, Value); } // 0x69c (Size: 0x4, Type: FloatProperty)
    void SET_FrontYawDeltaSmoothed(const float& Value) { Write<float>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x4, Type: FloatProperty)
    void SET_RearYawDeltaSmoothed(const float& Value) { Write<float>(uintptr_t(this) + 0x6a4, Value); } // 0x6a4 (Size: 0x4, Type: FloatProperty)
    void SET_SmoothedVehicleYawRate(const float& Value) { Write<float>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x4, Type: FloatProperty)
    void SET_FrontYawDeltaSmoothedAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x6ac, Value); } // 0x6ac (Size: 0x4, Type: FloatProperty)
    void SET_RearYawDeltaSmoothedAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x4, Type: FloatProperty)
    void SET_FrontWeaponYaw(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x18, Type: StructProperty)
    void SET_RearWeaponYaw(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x18, Type: StructProperty)
    void SET_PreviousVehicleRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x18, Type: StructProperty)
    void SET_bHasFrontTurretPassenger(const bool& Value) { Write<bool>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x1, Type: BoolProperty)
    void SET_bHasRearTurretPassenger(const bool& Value) { Write<bool>(uintptr_t(this) + 0x701, Value); } // 0x701 (Size: 0x1, Type: BoolProperty)
    void SET_NetworkEaseRate(const float& Value) { Write<float>(uintptr_t(this) + 0x704, Value); } // 0x704 (Size: 0x4, Type: FloatProperty)
    void SET_UpdateYawDeltaSmoothedLerpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x4, Type: FloatProperty)
    void SET_FrontPassengerSeatIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70c, Value); } // 0x70c (Size: 0x4, Type: IntProperty)
    void SET_RearPassengerSeatIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x4, Type: IntProperty)
    void SET_FrontPassengerYawOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x714, Value); } // 0x714 (Size: 0x4, Type: FloatProperty)
    void SET_RearPassengerYawOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x4, Type: FloatProperty)
    void SET_FrontPassengerBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x71c, Value); } // 0x71c (Size: 0x4, Type: NameProperty)
    void SET_RearPassengerBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x4, Type: NameProperty)
};

