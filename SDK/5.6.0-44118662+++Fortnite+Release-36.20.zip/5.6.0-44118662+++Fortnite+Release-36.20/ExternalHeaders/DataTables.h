/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataTables
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x30
class UBP_FlagsDecorator_C : public URichTextBlockImageDecorator
{
public:
};

// Size: 0x20
struct FStruct_VEH_Windows
{
public:
    TSoftObjectPtr<UMaterialInstanceConstant> Window_23_9242D84D446944DD0D7D739136E38C28() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Window_23_9242D84D446944DD0D7D739136E38C28(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x40
struct FStruct_VehicleCosmetics_Painted
{
public:
    FLinearColor PrimaryColor_32_9242D84D446944DD0D7D739136E38C28() const { return Read<FLinearColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor Balanced_34_F677FC9D4B1B4146E8CC9DBCB9E0943E() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FLinearColor Metallic_41_F57CE68E419E301DD160BEB5D0E32BFC() const { return Read<FLinearColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FLinearColor Emissive_44_23B897DD46FCCC1FE8A014AA4FE4104B() const { return Read<FLinearColor>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_PrimaryColor_32_9242D84D446944DD0D7D739136E38C28(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Balanced_34_F677FC9D4B1B4146E8CC9DBCB9E0943E(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Metallic_41_F57CE68E419E301DD160BEB5D0E32BFC(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_Emissive_44_23B897DD46FCCC1FE8A014AA4FE4104B(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

