/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTile_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x15b8
class UActivityBrowserTile_NEW_VM_C : public UFortActivityBrowserTile
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: StructProperty)
};

