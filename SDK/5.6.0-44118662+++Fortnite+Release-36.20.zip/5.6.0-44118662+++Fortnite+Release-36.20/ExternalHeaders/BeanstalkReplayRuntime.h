/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkReplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xb8
class UFortGameStateComponent_BeanstalkReplay : public UFortGameStateComponent_Replay
{
public:
};

