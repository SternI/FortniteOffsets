/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ArmASR
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UArmASRSettings : public UObject
{
public:
};

