/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicGamesTemporary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x20
struct FVerseRotation_Deprecated
{
public:
    FQuat Quaternion() const { return Read<FQuat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)

    void SET_Quaternion(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
};

