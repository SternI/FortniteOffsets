/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AmbientAudio
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "AudioGameplay.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0xf0
class UAmbientAudioComponent : public UAudioGameplayComponent
{
public:
    UAmbientAudioDataAsset* AmbientAsset() const { return Read<UAmbientAudioDataAsset*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)
    float CrossfadeTime() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    FGuid AmbientGuid() const { return Read<FGuid>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StructProperty)
    FName DisplayName() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)

    void SET_AmbientAsset(const UAmbientAudioDataAsset*& Value) { Write<UAmbientAudioDataAsset*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
    void SET_CrossfadeTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_AmbientGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StructProperty)
    void SET_DisplayName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x58
class UAmbientAudioDataAsset : public UDataAsset
{
public:
    TArray<FAmbientAudioLoop> LoopingSounds() const { return Read<TArray<FAmbientAudioLoop>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FAmbientAudioOneShot> OneShotSounds() const { return Read<TArray<FAmbientAudioOneShot>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    float TagCrossfadeTime() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_LoopingSounds(const TArray<FAmbientAudioLoop>& Value) { Write<TArray<FAmbientAudioLoop>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_OneShotSounds(const TArray<FAmbientAudioOneShot>& Value) { Write<TArray<FAmbientAudioOneShot>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_TagCrossfadeTime(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x258
class UAmbientAudioSubsystem : public UWorldSubsystem
{
public:
    TArray<UAmbientAudioComponent*> AmbientComponents() const { return Read<TArray<UAmbientAudioComponent*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    AAmbientAudioParameterActor* ParameterActor() const { return Read<AAmbientAudioParameterActor*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_AmbientComponents(const TArray<UAmbientAudioComponent*>& Value) { Write<TArray<UAmbientAudioComponent*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_ParameterActor(const AAmbientAudioParameterActor*& Value) { Write<AAmbientAudioParameterActor*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b0
class AAmbientAudioParameterActor : public AActor
{
public:
    UAudioParameterComponent* Parameters() const { return Read<UAudioParameterComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_Parameters(const UAudioParameterComponent*& Value) { Write<UAudioParameterComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
struct FAmbientAudioBase
{
public:
    TSoftObjectPtr<USoundBase> Sound() const { return Read<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTagQuery Requirements() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x48, Type: StructProperty)
    FAudioGameplayRequirements PlaybackRequirements() const { return Read<FAudioGameplayRequirements>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x50, Type: StructProperty)

    void SET_Sound(const TSoftObjectPtr<USoundBase>& Value) { Write<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Requirements(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x48, Type: StructProperty)
    void SET_PlaybackRequirements(const FAudioGameplayRequirements& Value) { Write<FAudioGameplayRequirements>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x50, Type: StructProperty)
};

// Size: 0xb8
struct FAmbientAudioLoop : public FAmbientAudioBase
{
public:
};

// Size: 0xd8
struct FAmbientAudioOneShot : public FAmbientAudioBase
{
public:
    FVector2D RetriggerTimeRange() const { return Read<FVector2D>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    FVector2D TriggerDistanceRange() const { return Read<FVector2D>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StructProperty)

    void SET_RetriggerTimeRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_TriggerDistanceRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StructProperty)
};

