/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorProfile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "UMG.h"
#include "FortniteUI.h"
#include "Foundation.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "Systems.h"
#include "UIKit.h"

// Size: 0x50
struct FUI_SocialIcons_Structure
{
public:
    TMap<ESocialLinkType, UMaterialInstance*> SocialIconsMap_5_40D24916421067524EA597910CB76455() const { return Read<TMap<ESocialLinkType, UMaterialInstance*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_SocialIconsMap_5_40D24916421067524EA597910CB76455(const TMap<ESocialLinkType, UMaterialInstance*>& Value) { Write<TMap<ESocialLinkType, UMaterialInstance*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x78
class UUI_SocialLinkType_Icons_Map_C : public UObject
{
public:
    FUI_SocialIcons_Structure SocialLinkIconsMap() const { return Read<FUI_SocialIcons_Structure>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: StructProperty)

    void SET_SocialLinkIconsMap(const FUI_SocialIcons_Structure& Value) { Write<FUI_SocialIcons_Structure>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: StructProperty)
};

// Size: 0x1910
class UWBP_CreatorPage_Button_Link_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18d0); } // 0x18d0 (Size: 0x8, Type: StructProperty)
    FString URL() const { return Read<FString>(uintptr_t(this) + 0x18d8); } // 0x18d8 (Size: 0x10, Type: StrProperty)
    FString Platform() const { return Read<FString>(uintptr_t(this) + 0x18e8); } // 0x18e8 (Size: 0x10, Type: StrProperty)
    int32_t EntryBoxIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18f8); } // 0x18f8 (Size: 0x4, Type: IntProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18d0, Value); } // 0x18d0 (Size: 0x8, Type: StructProperty)
    void SET_URL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18d8, Value); } // 0x18d8 (Size: 0x10, Type: StrProperty)
    void SET_Platform(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18e8, Value); } // 0x18e8 (Size: 0x10, Type: StrProperty)
    void SET_EntryBoxIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18f8, Value); } // 0x18f8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x4c8
class UWBP_CreatorPage_QRCode_Modal_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Block_Outline_C* WBP_Outline() const { return Read<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_URL() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ModalTitle() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Desc() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_QRCode() const { return Read<UImage*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Dialog_Internal_C* Dialog_Internal() const { return Read<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UButton* Button_URL() const { return Read<UButton*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Close() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UCloseButton_C* Button_BackTouch() const { return Read<UCloseButton_C*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    double Mobile_Scale() const { return Read<double>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: DoubleProperty)
    FString URL() const { return Read<FString>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x10, Type: StrProperty)
    FString SocialPlatform() const { return Read<FString>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x10, Type: StrProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: StructProperty)
    void SET_WBP_Outline(const UWBP_UIKit_Block_Outline_C*& Value) { Write<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_URL(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ModalTitle(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Desc(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_QRCode(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Dialog_Internal(const UWBP_UIKit_Dialog_Internal_C*& Value) { Write<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_URL(const UButton*& Value) { Write<UButton*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Close(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_BackTouch(const UCloseButton_C*& Value) { Write<UCloseButton_C*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_Mobile_Scale(const double& Value) { Write<double>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: DoubleProperty)
    void SET_URL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x10, Type: StrProperty)
    void SET_SocialPlatform(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x5d0
class UWBP_FollowCreator_ProfilePage_C : public UWBP_Discover_Surface_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: StructProperty)
    UWBP_CreatorPage_Infos_C* WBP_CreatorPage_Infos() const { return Read<UWBP_CreatorPage_Infos_C*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    UWBP_CreatorInfo_NonCollapsible_C* WBP_CreatorInfo_NonCollapsible() const { return Read<UWBP_CreatorInfo_NonCollapsible_C*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* HeaderOverlay() const { return Read<UOverlay*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    UFortPlayerPageVM* FortPlayerPageVM() const { return Read<UFortPlayerPageVM*>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    UWidget* LastFocusedCreatorWidget() const { return Read<UWidget*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Unfavorite_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Favorite_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: StructProperty)
    void SET_WBP_CreatorPage_Infos(const UWBP_CreatorPage_Infos_C*& Value) { Write<UWBP_CreatorPage_Infos_C*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_CreatorInfo_NonCollapsible(const UWBP_CreatorInfo_NonCollapsible_C*& Value) { Write<UWBP_CreatorInfo_NonCollapsible_C*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_HeaderOverlay(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_FortPlayerPageVM(const UFortPlayerPageVM*& Value) { Write<UFortPlayerPageVM*>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    void SET_LastFocusedCreatorWidget(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Unfavorite_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Favorite_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3d8
class UWBP_CreatorPage_Infos_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    UWBP_CreatorPage_Followed_CoachMark_C* WBP_CreatorPage_Followed_CoachMark() const { return Read<UWBP_CreatorPage_Followed_CoachMark_C*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VB_MiniHeaderCollapsibleArea() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Txt_Bio() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    UDynamicEntryBox* EntryBox_MediaButtons() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    UWBP_CreatorPage_Button_Main_C* Button_Follow() const { return Read<UWBP_CreatorPage_Button_Main_C*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ContextMenuAnchorButton_C* Button_ContextMenu() const { return Read<UWBP_UIKit_ContextMenuAnchorButton_C*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UUIKitContextMenuActionContext* ContextMenuActionContext() const { return Read<UUIKitContextMenuActionContext*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    FUI_SocialIcons_Structure SocialIconsMapReference() const { return Read<FUI_SocialIcons_Structure>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x50, Type: StructProperty)
    UUserWidget* LastFocusedWidget() const { return Read<UUserWidget*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    int32_t LastFocusedSocialButtonIndex() const { return Read<int32_t>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x4, Type: IntProperty)
    FText CreatorName() const { return Read<FText>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x10, Type: TextProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_CreatorPage_Followed_CoachMark(const UWBP_CreatorPage_Followed_CoachMark_C*& Value) { Write<UWBP_CreatorPage_Followed_CoachMark_C*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_VB_MiniHeaderCollapsibleArea(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_Txt_Bio(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryBox_MediaButtons(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Follow(const UWBP_CreatorPage_Button_Main_C*& Value) { Write<UWBP_CreatorPage_Button_Main_C*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ContextMenu(const UWBP_UIKit_ContextMenuAnchorButton_C*& Value) { Write<UWBP_UIKit_ContextMenuAnchorButton_C*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_ContextMenuActionContext(const UUIKitContextMenuActionContext*& Value) { Write<UUIKitContextMenuActionContext*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_SocialIconsMapReference(const FUI_SocialIcons_Structure& Value) { Write<FUI_SocialIcons_Structure>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x50, Type: StructProperty)
    void SET_LastFocusedWidget(const UUserWidget*& Value) { Write<UUserWidget*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_LastFocusedSocialButtonIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x4, Type: IntProperty)
    void SET_CreatorName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x10, Type: TextProperty)
};

// Size: 0xe0
class UDialogVM_FollowLimitReached_C : public UUIKitDialogViewModel
{
public:
};

// Size: 0x4c8
class UWBP_CreatorPage_Followed_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1908
class UWBP_CreatorPage_Button_Main_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18d0); } // 0x18d0 (Size: 0x8, Type: StructProperty)
    UWidgetAnimation* Anim_Following() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x18d8); } // 0x18d8 (Size: 0x8, Type: ObjectProperty)
    double AnimValue_Following_Icon() const { return Read<double>(uintptr_t(this) + 0x18e0); } // 0x18e0 (Size: 0x8, Type: DoubleProperty)
    bool Is_Following() const { return Read<bool>(uintptr_t(this) + 0x18e8); } // 0x18e8 (Size: 0x1, Type: BoolProperty)
    double AnimValue_Following_Background() const { return Read<double>(uintptr_t(this) + 0x18f0); } // 0x18f0 (Size: 0x8, Type: DoubleProperty)
    bool IsInitialized() const { return Read<bool>(uintptr_t(this) + 0x18f8); } // 0x18f8 (Size: 0x1, Type: BoolProperty)
    double IconRightPadding() const { return Read<double>(uintptr_t(this) + 0x1900); } // 0x1900 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18d0, Value); } // 0x18d0 (Size: 0x8, Type: StructProperty)
    void SET_Anim_Following(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x18d8, Value); } // 0x18d8 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimValue_Following_Icon(const double& Value) { Write<double>(uintptr_t(this) + 0x18e0, Value); } // 0x18e0 (Size: 0x8, Type: DoubleProperty)
    void SET_Is_Following(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18e8, Value); } // 0x18e8 (Size: 0x1, Type: BoolProperty)
    void SET_AnimValue_Following_Background(const double& Value) { Write<double>(uintptr_t(this) + 0x18f0, Value); } // 0x18f0 (Size: 0x8, Type: DoubleProperty)
    void SET_IsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18f8, Value); } // 0x18f8 (Size: 0x1, Type: BoolProperty)
    void SET_IconRightPadding(const double& Value) { Write<double>(uintptr_t(this) + 0x1900, Value); } // 0x1900 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x310
class UWBP_CreatorPage_FavoriteCount_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Txt_Favorite() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Txt_Count() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    void SET_Txt_Favorite(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_Txt_Count(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x340
class UWBP_CreatorInfo_NonCollapsible_C : public UUserWidget
{
public:
    UWBP_CreatorPage_FavoriteCount_C* WBP_CreatorPage_FavoriteCount() const { return Read<UWBP_CreatorPage_FavoriteCount_C*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Creator_AvatarImage_C* WBP_Creator_AvatarImage() const { return Read<UWBP_Creator_AvatarImage_C*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Txt_CreatorName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)

    void SET_WBP_CreatorPage_FavoriteCount(const UWBP_CreatorPage_FavoriteCount_C*& Value) { Write<UWBP_CreatorPage_FavoriteCount_C*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_Creator_AvatarImage(const UWBP_Creator_AvatarImage_C*& Value) { Write<UWBP_Creator_AvatarImage_C*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_Txt_CreatorName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x354
class UWBP_Creator_AvatarImage_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UImage* LiveFeedback() const { return Read<UImage*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UImage* CreatorThumbnail() const { return Read<UImage*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnLoadedImage() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    FVector2D CreatorAvatarSize() const { return Read<FVector2D>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x10, Type: StructProperty)
    FName TextureParam() const { return Read<FName>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x4, Type: NameProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_LiveFeedback(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_CreatorThumbnail(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnLoadedImage(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_CreatorAvatarSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x10, Type: StructProperty)
    void SET_TextureParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x4, Type: NameProperty)
};

