/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_UILibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x1500
class UFNE_ModularButton : public UCommonButtonBase
{
public:
    TArray<UFNE_UIBlock*> ModularBlocks() const { return Read<TArray<UFNE_UIBlock*>>(uintptr_t(this) + 0x14f0); } // 0x14f0 (Size: 0x10, Type: ArrayProperty)

    void SET_ModularBlocks(const TArray<UFNE_UIBlock*>& Value) { Write<TArray<UFNE_UIBlock*>>(uintptr_t(this) + 0x14f0, Value); } // 0x14f0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x338
class UFNE_UIBlock : public UUserWidget
{
public:
    FFNE_UIBlockTiming TransitionTiming() const { return Read<FFNE_UIBlockTiming>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x2c, Type: StructProperty)

    void SET_TransitionTiming(const FFNE_UIBlockTiming& Value) { Write<FFNE_UIBlockTiming>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x2c, Type: StructProperty)
};

// Size: 0x28
class UFNE_UIBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x1520
class UFNE_CTAButton : public UFNE_ModularButton
{
public:
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x1500); } // 0x1500 (Size: 0x10, Type: TextProperty)
    FText SecondaryText() const { return Read<FText>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x10, Type: TextProperty)

    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1500, Value); } // 0x1500 (Size: 0x10, Type: TextProperty)
    void SET_SecondaryText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x10, Type: TextProperty)
};

// Size: 0x1520
class UFNE_StylableButton : public UFNE_ModularButton
{
public:
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x1500); } // 0x1500 (Size: 0x10, Type: TextProperty)
    FText SecondaryText() const { return Read<FText>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x10, Type: TextProperty)

    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1500, Value); } // 0x1500 (Size: 0x10, Type: TextProperty)
    void SET_SecondaryText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x10, Type: TextProperty)
};

// Size: 0x2c
struct FFNE_UIBlockTiming
{
public:
    float Hovering() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Unhovering() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Focusing() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Unfocusing() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Pressing() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Releasing() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Disabling() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float Enabling() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float Selecting() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float DeselectingIdle() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float DeselectingFocused() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_Hovering(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Unhovering(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Focusing(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Unfocusing(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Pressing(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Releasing(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Disabling(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_Enabling(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_Selecting(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_DeselectingIdle(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_DeselectingFocused(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

