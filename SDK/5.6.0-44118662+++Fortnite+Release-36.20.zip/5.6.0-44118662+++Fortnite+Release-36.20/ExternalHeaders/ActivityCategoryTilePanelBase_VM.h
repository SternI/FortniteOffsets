/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityCategoryTilePanelBase_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CommonUI.h"
#include "DiscoveryBrowserUI.h"
#include "UMG.h"

// Size: 0x370
class UActivityCategoryTilePanelBase_VM_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VerticalBox_Content() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UFortActivityTileView* TileView_Categories() const { return Read<UFortActivityTileView*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Title() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ActiveInactivate() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnMoveUpOutOfView() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    double EntryHeight() const { return Read<double>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: DoubleProperty)
    double EntryWidth() const { return Read<double>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_VerticalBox_Content(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_TileView_Categories(const UFortActivityTileView*& Value) { Write<UFortActivityTileView*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Title(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveInactivate(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_OnMoveUpOutOfView(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: DoubleProperty)
    void SET_EntryWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: DoubleProperty)
};

