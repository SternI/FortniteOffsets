/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Foundation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "SlateCore.h"
#include "InputCore.h"
#include "UMG.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "Input.h"
#include "Engine.h"
#include "UI.h"
#include "FortniteUI.h"

// Size: 0x1589
class UCloseButton_C : public UCommonButtonLegacy
{
public:
    UCommonTextBlock* Text_ButtonAction() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Control() const { return Read<USizeBox*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UImage* CloseIcon() const { return Read<UImage*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Container() const { return Read<UBorder*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    FText Button_Description() const { return Read<FText>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x10, Type: TextProperty)
    bool FontSizeOveride() const { return Read<bool>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x1, Type: BoolProperty)
    int32_t FontSize() const { return Read<int32_t>(uintptr_t(this) + 0x1574); } // 0x1574 (Size: 0x4, Type: IntProperty)
    FMargin Padding_Overide() const { return Read<FMargin>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x10, Type: StructProperty)
    bool PaddingOveride() const { return Read<bool>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x1, Type: BoolProperty)

    void SET_Text_ButtonAction(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_Control(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_CloseIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Container(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x10, Type: TextProperty)
    void SET_FontSizeOveride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x1, Type: BoolProperty)
    void SET_FontSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1574, Value); } // 0x1574 (Size: 0x4, Type: IntProperty)
    void SET_Padding_Overide(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x10, Type: StructProperty)
    void SET_PaddingOveride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x710
class UButtonStyle_Feature_M_Yellow_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_Red_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Tab_Main_Recolor_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_M_Disabled_C : public UCommonTextStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Feature_L_Disabled_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_BottomBar_Console_C : public UButtonStyle_MediumBase_C
{
public:
};

// Size: 0x710
class UButtonStyle_Feature_L_Yellow_s11_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_15_White_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x190
class UTextStyle_MediumButton_Disabled_C : public UTextStyle_MediumButton_C
{
public:
};

// Size: 0x710
class UButtonStyle_MediumBase_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x190
class UTextStyle_Button_Feature_M_Feature_s11_C : public UCommonTextStyle
{
public:
};

// Size: 0x560
class URootLayout_Athena_C : public UFortRootViewportLayout_Athena
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: StructProperty)
    UConfirmationWindow_C* ConfirmationWindow() const { return Read<UConfirmationWindow_C*>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    UProgressModalWidget_C* ControllerDisconnectedModal() const { return Read<UProgressModalWidget_C*>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    bool bClosingErrorDialog() const { return Read<bool>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x1, Type: BoolProperty)
    FText QuitTitle() const { return Read<FText>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x10, Type: TextProperty)
    FText QuitMessage() const { return Read<FText>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x10, Type: TextProperty)
    USoundBase* TakeControlAudio() const { return Read<USoundBase*>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: StructProperty)
    void SET_ConfirmationWindow(const UConfirmationWindow_C*& Value) { Write<UConfirmationWindow_C*>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    void SET_ControllerDisconnectedModal(const UProgressModalWidget_C*& Value) { Write<UProgressModalWidget_C*>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    void SET_bClosingErrorDialog(const bool& Value) { Write<bool>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x1, Type: BoolProperty)
    void SET_QuitTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x10, Type: TextProperty)
    void SET_QuitMessage(const FText& Value) { Write<FText>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x10, Type: TextProperty)
    void SET_TakeControlAudio(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x710
class UButtonStyle_Primary_M_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_M_C : public UCommonTextStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_15_LightBlue_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x16d9
class UIconTextButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    UNamedSlot* RightExtraContentSlot() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UImage* LeftSideImage() const { return Read<UImage*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_ButtonContent() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder() const { return Read<UBorder*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0xb0, Type: StructProperty)
    UClass* ControllerInputStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1630); } // 0x1630 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1638); } // 0x1638 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1640); } // 0x1640 (Size: 0x1, Type: ByteProperty)
    bool bMouseKeyboardStyleSet() const { return Read<bool>(uintptr_t(this) + 0x1641); } // 0x1641 (Size: 0x1, Type: BoolProperty)
    FText OverrideButtonText() const { return Read<FText>(uintptr_t(this) + 0x1648); } // 0x1648 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> ButtonTextJustification() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x1658); } // 0x1658 (Size: 0x1, Type: ByteProperty)
    bool bDisplayAllCaps() const { return Read<bool>(uintptr_t(this) + 0x1659); } // 0x1659 (Size: 0x1, Type: BoolProperty)
    double PressProgress() const { return Read<double>(uintptr_t(this) + 0x1660); } // 0x1660 (Size: 0x8, Type: DoubleProperty)
    bool bIgnoreInputActionWidgetText() const { return Read<bool>(uintptr_t(this) + 0x1668); } // 0x1668 (Size: 0x1, Type: BoolProperty)
    FSlateFontInfo Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x1680); } // 0x1680 (Size: 0x58, Type: StructProperty)
    bool UseLightInput() const { return Read<bool>(uintptr_t(this) + 0x16d8); } // 0x16d8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_RightExtraContentSlot(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftSideImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_ButtonContent(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentBorder(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_CenterButtonTextWidget(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x10, Type: TextProperty)
    void SET_IconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0xb0, Type: StructProperty)
    void SET_ControllerInputStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1630, Value); } // 0x1630 (Size: 0x8, Type: ClassProperty)
    void SET_MouseKeyboardStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1638, Value); } // 0x1638 (Size: 0x8, Type: ClassProperty)
    void SET_ContentAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1640, Value); } // 0x1640 (Size: 0x1, Type: ByteProperty)
    void SET_bMouseKeyboardStyleSet(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1641, Value); } // 0x1641 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1648, Value); } // 0x1648 (Size: 0x10, Type: TextProperty)
    void SET_ButtonTextJustification(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x1658, Value); } // 0x1658 (Size: 0x1, Type: ByteProperty)
    void SET_bDisplayAllCaps(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1659, Value); } // 0x1659 (Size: 0x1, Type: BoolProperty)
    void SET_PressProgress(const double& Value) { Write<double>(uintptr_t(this) + 0x1660, Value); } // 0x1660 (Size: 0x8, Type: DoubleProperty)
    void SET_bIgnoreInputActionWidgetText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1668, Value); } // 0x1668 (Size: 0x1, Type: BoolProperty)
    void SET_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x1680, Value); } // 0x1680 (Size: 0x58, Type: StructProperty)
    void SET_UseLightInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16d8, Value); } // 0x16d8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x190
class UTextStyle_Button_Outline_XS_Disabled_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Outline_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_TextOnlyBase_EmptyFocus_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x710
class UButtonStyle_Feature_L_Skew_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_20_LightGrey_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x15f8
class UGamepadKeyTextButton_C : public UFortGamepadCustomListItem
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBox_Nokey() const { return Read<USizeBox*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UFortRichTextBlockLegacy* FortRichTextBlock_NoKey() const { return Read<UFortRichTextBlockLegacy*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UFortRichTextBlockLegacy* FortRichTextBlock_Desc() const { return Read<UFortRichTextBlockLegacy*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder() const { return Read<UBorder*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    UKeybindWidget_C* BoundKey() const { return Read<UKeybindWidget_C*>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x10, Type: TextProperty)
    UClass* ControllerInputStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x1, Type: ByteProperty)
    FName ActionNameData() const { return Read<FName>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x4, Type: NameProperty)
    FKey KeyData() const { return Read<FKey>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x18, Type: StructProperty)
    FText TextData() const { return Read<FText>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x10, Type: TextProperty)
    FKey KeyNone() const { return Read<FKey>(uintptr_t(this) + 0x15e0); } // 0x15e0 (Size: 0x18, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: StructProperty)
    void SET_SizeBox_Nokey(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_FortRichTextBlock_NoKey(const UFortRichTextBlockLegacy*& Value) { Write<UFortRichTextBlockLegacy*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_FortRichTextBlock_Desc(const UFortRichTextBlockLegacy*& Value) { Write<UFortRichTextBlockLegacy*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentBorder(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundKey(const UKeybindWidget_C*& Value) { Write<UKeybindWidget_C*>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x10, Type: TextProperty)
    void SET_ControllerInputStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ClassProperty)
    void SET_ContentAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x1, Type: ByteProperty)
    void SET_ActionNameData(const FName& Value) { Write<FName>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x4, Type: NameProperty)
    void SET_KeyData(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x18, Type: StructProperty)
    void SET_TextData(const FText& Value) { Write<FText>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x10, Type: TextProperty)
    void SET_KeyNone(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x15e0, Value); } // 0x15e0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x190
class UTextStyle_Button_BottomBar_S_Selected_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_TextOnlyBase_Empty_NoSound_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_M_Skew_BurbankLightBlue_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Empty_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x178
class UUIManager_Startup_C : public UFortUIManager_Startup
{
public:
};

// Size: 0x198
class UUIManager_Athena_C : public UFortUIManager_Athena
{
public:
};

// Size: 0x190
class UTextStyle_MediumButton_C : public UCommonTextStyle
{
public:
};

// Size: 0x15b0
class UPanelButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    UNamedSlot* ContentSlot() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UClass* ControllerInputStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> InputActionHorizontalAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> InputActionVerticalAlignment() const { return Read<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x1561); } // 0x1561 (Size: 0x1, Type: ByteProperty)
    FVector2D InputActionRenderTranslation() const { return Read<FVector2D>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x10, Type: StructProperty)
    bool InputActionUseRimBrush() const { return Read<bool>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x1, Type: BoolProperty)
    FVector2D InputActionRimBrushSize() const { return Read<FVector2D>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_ContentSlot(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_ControllerInputStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ClassProperty)
    void SET_MouseKeyboardStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ClassProperty)
    void SET_InputActionHorizontalAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x1, Type: ByteProperty)
    void SET_InputActionVerticalAlignment(const TEnumAsByte<EVerticalAlignment>& Value) { Write<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x1561, Value); } // 0x1561 (Size: 0x1, Type: ByteProperty)
    void SET_InputActionRenderTranslation(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x10, Type: StructProperty)
    void SET_InputActionUseRimBrush(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x1, Type: BoolProperty)
    void SET_InputActionRimBrushSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1633
class UScrollingTextButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    UImage* LeftSideImage() const { return Read<UImage*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder() const { return Read<UBorder*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0xb0, Type: StructProperty)
    UClass* ControllerInputStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1620); } // 0x1620 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1628); } // 0x1628 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1630); } // 0x1630 (Size: 0x1, Type: ByteProperty)
    bool bMouseKeyboardStyleSet() const { return Read<bool>(uintptr_t(this) + 0x1631); } // 0x1631 (Size: 0x1, Type: BoolProperty)
    bool UseLightInput() const { return Read<bool>(uintptr_t(this) + 0x1632); } // 0x1632 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_LeftSideImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentBorder(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_CenterButtonTextWidget(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x10, Type: TextProperty)
    void SET_IconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0xb0, Type: StructProperty)
    void SET_ControllerInputStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1620, Value); } // 0x1620 (Size: 0x8, Type: ClassProperty)
    void SET_MouseKeyboardStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1628, Value); } // 0x1628 (Size: 0x8, Type: ClassProperty)
    void SET_ContentAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1630, Value); } // 0x1630 (Size: 0x1, Type: ByteProperty)
    void SET_bMouseKeyboardStyleSet(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1631, Value); } // 0x1631 (Size: 0x1, Type: BoolProperty)
    void SET_UseLightInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1632, Value); } // 0x1632 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1570
class UTextRotatorWhite_C : public UCommonRotator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: StructProperty)
    UCommonBorder* MainBorder() const { return Read<UCommonBorder*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: StructProperty)
    void SET_MainBorder(const UCommonBorder*& Value) { Write<UCommonBorder*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15a2
class USoloButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_ButtonAction() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Control() const { return Read<USizeBox*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UImage* ButtonBacking() const { return Read<UImage*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Container() const { return Read<UBorder*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Pressed() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    FText Button_Description() const { return Read<FText>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x10, Type: TextProperty)
    bool FontSizeOveride() const { return Read<bool>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x1, Type: BoolProperty)
    int32_t FontSize() const { return Read<int32_t>(uintptr_t(this) + 0x158c); } // 0x158c (Size: 0x4, Type: IntProperty)
    FMargin Padding_Overide() const { return Read<FMargin>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x10, Type: StructProperty)
    bool PaddingOveride() const { return Read<bool>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x1, Type: BoolProperty)
    bool IsDisabled() const { return Read<bool>(uintptr_t(this) + 0x15a1); } // 0x15a1 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_Text_ButtonAction(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_Control(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonBacking(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Container(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_Hover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_Pressed(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x10, Type: TextProperty)
    void SET_FontSizeOveride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x1, Type: BoolProperty)
    void SET_FontSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x158c, Value); } // 0x158c (Size: 0x4, Type: IntProperty)
    void SET_Padding_Overide(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x10, Type: StructProperty)
    void SET_PaddingOveride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x1, Type: BoolProperty)
    void SET_IsDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15a1, Value); } // 0x15a1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x710
class UButtonStyle_Skew_LessTransparent_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Tab_Main_S11_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_LessDesirable_AddFriend_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_TransparentList_Social_NoHovered_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_TransparentList_Nothing_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_ItemShopTile_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_LessDesirable_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Primary_Radio_M_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_RotatorBorder_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UAthena_ButtonStyle_BlueMenuButton_Settings_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_MediumTransparentNoCues_C : public UButtonStyle_MediumBase_C
{
public:
};

// Size: 0x190
class UTextStyle_Button_BottomBar_S_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Icon_Transparent_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_MediumTransparentWithCues_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x16a8
class UIconTextButtonHold_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    UNamedSlot* RightExtraContentSlot() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UImage* LeftSideImage() const { return Read<UImage*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_ButtonContent() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder() const { return Read<UBorder*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0xb0, Type: StructProperty)
    UClass* ControllerInputStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1630); } // 0x1630 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1638); } // 0x1638 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1640); } // 0x1640 (Size: 0x1, Type: ByteProperty)
    bool bMouseKeyboardStyleSet() const { return Read<bool>(uintptr_t(this) + 0x1641); } // 0x1641 (Size: 0x1, Type: BoolProperty)
    FText OverrideButtonText() const { return Read<FText>(uintptr_t(this) + 0x1648); } // 0x1648 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> ButtonTextJustification() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x1658); } // 0x1658 (Size: 0x1, Type: ByteProperty)
    bool bDisplayAllCaps() const { return Read<bool>(uintptr_t(this) + 0x1659); } // 0x1659 (Size: 0x1, Type: BoolProperty)
    double PressProgress() const { return Read<double>(uintptr_t(this) + 0x1660); } // 0x1660 (Size: 0x8, Type: DoubleProperty)
    bool bIgnoreInputActionWidgetText() const { return Read<bool>(uintptr_t(this) + 0x1668); } // 0x1668 (Size: 0x1, Type: BoolProperty)
    bool bHolding() const { return Read<bool>(uintptr_t(this) + 0x1680); } // 0x1680 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_RightExtraContentSlot(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftSideImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_ButtonContent(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentBorder(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_CenterButtonTextWidget(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x10, Type: TextProperty)
    void SET_IconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0xb0, Type: StructProperty)
    void SET_ControllerInputStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1630, Value); } // 0x1630 (Size: 0x8, Type: ClassProperty)
    void SET_MouseKeyboardStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1638, Value); } // 0x1638 (Size: 0x8, Type: ClassProperty)
    void SET_ContentAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x1640, Value); } // 0x1640 (Size: 0x1, Type: ByteProperty)
    void SET_bMouseKeyboardStyleSet(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1641, Value); } // 0x1641 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1648, Value); } // 0x1648 (Size: 0x10, Type: TextProperty)
    void SET_ButtonTextJustification(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x1658, Value); } // 0x1658 (Size: 0x1, Type: ByteProperty)
    void SET_bDisplayAllCaps(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1659, Value); } // 0x1659 (Size: 0x1, Type: BoolProperty)
    void SET_PressProgress(const double& Value) { Write<double>(uintptr_t(this) + 0x1660, Value); } // 0x1660 (Size: 0x8, Type: DoubleProperty)
    void SET_bIgnoreInputActionWidgetText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1668, Value); } // 0x1668 (Size: 0x1, Type: BoolProperty)
    void SET_bHolding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1680, Value); } // 0x1680 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x710
class UButtonStyle_OutlineEmptyFill_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_Desirable_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_20_White50pc_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_20_White_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x558
class UWBP_Modal_ReviewYourSettings_C : public UFortReviewYourSettingsModal
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: StructProperty)
    USafeZone* MobileClose() const { return Read<USafeZone*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UImage* Lightbox_HitTestBlocker() const { return Read<UImage*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BackgroundBottomBar() const { return Read<UImage*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    USafeZone* ContentSZ() const { return Read<USafeZone*>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    UImage* Containment() const { return Read<UImage*>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: StructProperty)
    void SET_MobileClose(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_Lightbox_HitTestBlocker(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_BackgroundBottomBar(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentSZ(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    void SET_Containment(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1518
class UBackButtonSmall_C : public UCommonButtonBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x14f0); } // 0x14f0 (Size: 0x8, Type: StructProperty)
    UFortMobileImage* Image_Arrow() const { return Read<UFortMobileImage*>(uintptr_t(this) + 0x14f8); } // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_3() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1500); } // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* CommonActionWidget_65() const { return Read<UCommonActionWidget*>(uintptr_t(this) + 0x1508); } // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnHover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x14f0, Value); } // 0x14f0 (Size: 0x8, Type: StructProperty)
    void SET_Image_Arrow(const UFortMobileImage*& Value) { Write<UFortMobileImage*>(uintptr_t(this) + 0x14f8, Value); } // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_3(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1500, Value); } // 0x1500 (Size: 0x8, Type: ObjectProperty)
    void SET_CommonActionWidget_65(const UCommonActionWidget*& Value) { Write<UCommonActionWidget*>(uintptr_t(this) + 0x1508, Value); } // 0x1508 (Size: 0x8, Type: ObjectProperty)
    void SET_OnHover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1690
class UIconTabButton_Legacy_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBoxShell() const { return Read<USizeBox*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UImage* LeftSideImage() const { return Read<UImage*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* ContentHB() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UNormalBangWrapper_C* BangWrapper() const { return Read<UNormalBangWrapper_C*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0xb0, Type: StructProperty)
    bool UseText() const { return Read<bool>(uintptr_t(this) + 0x1630); } // 0x1630 (Size: 0x1, Type: BoolProperty)
    FLinearColor SelectedIconTint() const { return Read<FLinearColor>(uintptr_t(this) + 0x1634); } // 0x1634 (Size: 0x10, Type: StructProperty)
    FLinearColor DeselectedIconTint() const { return Read<FLinearColor>(uintptr_t(this) + 0x1644); } // 0x1644 (Size: 0x10, Type: StructProperty)
    FLinearColor HoveredIconTint() const { return Read<FLinearColor>(uintptr_t(this) + 0x1654); } // 0x1654 (Size: 0x10, Type: StructProperty)
    bool bBangEnabled() const { return Read<bool>(uintptr_t(this) + 0x1664); } // 0x1664 (Size: 0x1, Type: BoolProperty)
    bool ChangeIconColorWhenSelected() const { return Read<bool>(uintptr_t(this) + 0x1665); } // 0x1665 (Size: 0x1, Type: BoolProperty)
    FSlateColor SelectedIconColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x1668); } // 0x1668 (Size: 0x14, Type: StructProperty)
    FSlateColor UnSelectedIconColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x167c); } // 0x167c (Size: 0x14, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_SizeBoxShell(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftSideImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentHB(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_CenterButtonTextWidget(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_BangWrapper(const UNormalBangWrapper_C*& Value) { Write<UNormalBangWrapper_C*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x10, Type: TextProperty)
    void SET_IconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0xb0, Type: StructProperty)
    void SET_UseText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1630, Value); } // 0x1630 (Size: 0x1, Type: BoolProperty)
    void SET_SelectedIconTint(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1634, Value); } // 0x1634 (Size: 0x10, Type: StructProperty)
    void SET_DeselectedIconTint(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1644, Value); } // 0x1644 (Size: 0x10, Type: StructProperty)
    void SET_HoveredIconTint(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1654, Value); } // 0x1654 (Size: 0x10, Type: StructProperty)
    void SET_bBangEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1664, Value); } // 0x1664 (Size: 0x1, Type: BoolProperty)
    void SET_ChangeIconColorWhenSelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1665, Value); } // 0x1665 (Size: 0x1, Type: BoolProperty)
    void SET_SelectedIconColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x1668, Value); } // 0x1668 (Size: 0x14, Type: StructProperty)
    void SET_UnSelectedIconColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x167c, Value); } // 0x167c (Size: 0x14, Type: StructProperty)
};

// Size: 0x710
class UButtonStyle_PageChevron_Left_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x710
class UButtonStyle_PageChevron_Right_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x710
class UButtonStyle_GamepadBindings_NonInteractable_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x710
class UButtonStyle_GamepadBindings_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x710
class UButtonStyle_ClearSocialSearch_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_SocialInteraction_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_15_Red_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x710
class UButtonStyle_Tab_Manage_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Rotator_Small_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_Error_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_TransparentList_Social_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyleClearDismissTooltip_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Clear_C : public UCommonButtonStyle
{
public:
};

// Size: 0x42b0
class UDefaultUIDataConfiguration_C : public UFortUIDataConfiguration
{
public:
};

// Size: 0x710
class UAthena_ButtonStyle_AngledBlueMenuButton_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_20_LightBlue_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x190
class UTextStyle_Button_Feature_M_Base_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Slot_Gadget_S_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_FullyInvisible_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_15_Green_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x710
class UAthena_ButtonStyle_AngledBlackMenuButton_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_L_Disabled_C : public UCommonTextStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_L_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Primary_L_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_LSkew_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Feature_M_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_M_Skew_BurbankDark_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Primary_M_Skew_Yellow_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_LDarkBlue_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Outline_Skew_Blue_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew2_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Feature_L_Yellow_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Lightbox_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x710
class UButtonStyle_Primary_L_Yellow_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Tab_Main_Bacchus_NoPadding_C : public UButtonStyle_Tab_Main_C
{
public:
};

// Size: 0x710
class UButtonStyle_Tab_Main_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Empty_NoSound_C : public UButtonStyle_Base_C
{
public:
};

// Size: 0x190
class UTextStyle_Button_Primary_MSkew_C : public UCommonTextStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Feature_L_Base_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_PlayerSurvey_ChoiceResponse_C : public UCommonButtonStyle
{
public:
};

// Size: 0x30
class UCommonRichTextDecorators_C : public URichTextBlockImageDecorator
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_15_White50pc_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x190
class UTextStyle_BurbSmBk_15_DarkBlue_C : public UTextStyle_BaseParent_C
{
public:
};

// Size: 0x710
class UAthena_ButtonStyle_CollectionTab_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Radial_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

// Size: 0x710
class UButtonStyle_Clear_NoSound_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_Skew_LBlue_C : public UCommonButtonStyle
{
public:
};

// Size: 0x190
class UTextStyle_Button_Feature_M_Disabled_C : public UCommonTextStyle
{
public:
};

// Size: 0x710
class UButtonStyle_NewFeature_M_Yellow_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_SoloButton_C : public UCommonButtonStyle
{
public:
};

// Size: 0x30
class UCommonUIRichTextData_C : public UCommonUIRichTextData
{
public:
};

// Size: 0x710
class UButtonStyle_Base_C : public UCommonButtonStyle
{
public:
};

// Size: 0x710
class UButtonStyle_TextOnlyBase_Empty_C : public UButtonStyle_Base_C
{
public:
};

