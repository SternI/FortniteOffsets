/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BoostedJumpCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x1f0
class UFortControllerComponent_BoostedJump : public UControllerComponent
{
public:
    FGameplayTagContainer DefaultBlockingTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x20, Type: StructProperty)
    FGameplayTag BoostedJumpCanBeActivatedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: StructProperty)
    UClass* MovementModeExtension() const { return Read<UClass*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    FFortBoostedJumpActivationConfig BoostJumpWalkingConfig() const { return Read<FFortBoostedJumpActivationConfig>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0xa0, Type: StructProperty)
    FScalableFloat BoostedJumpFeatureEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x28, Type: StructProperty)
    float BoostedJumpMonitorRate() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)

    void SET_DefaultBlockingTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x20, Type: StructProperty)
    void SET_BoostedJumpCanBeActivatedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: StructProperty)
    void SET_MovementModeExtension(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    void SET_BoostJumpWalkingConfig(const FFortBoostedJumpActivationConfig& Value) { Write<FFortBoostedJumpActivationConfig>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0xa0, Type: StructProperty)
    void SET_BoostedJumpFeatureEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x28, Type: StructProperty)
    void SET_BoostedJumpMonitorRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
class UFortMovementMode_BoostedJumpRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

// Size: 0x300
class UFortMovementMode_ExtLogicBoostedJump : public UFortMovementMode_BaseExtLogic
{
public:
    FScalableFloat JumpAddedVelocityMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpZVelocity() const { return Read<FScalableFloat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpHorizontalVelocityMax() const { return Read<FScalableFloat>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x28, Type: StructProperty)
    float MaxTimeSpentInBoostedJump() const { return Read<float>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x4, Type: FloatProperty)
    UClass* AnimLayer() const { return Read<UClass*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ClassProperty)
    UClass* CameraStartShake() const { return Read<UClass*>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: ClassProperty)
    FGameplayTag GC_BoostedJumpBeingActivated() const { return Read<FGameplayTag>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x4, Type: StructProperty)
    UAnimMontage* AnimationMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag SkipAnimationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer PreventHolsterTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x20, Type: StructProperty)
    FGameplayTag AllowPrimaryFireTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x4, Type: StructProperty)
    FGameplayTag AllowSecondaryFireTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x4, Type: StructProperty)

    void SET_JumpAddedVelocityMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x28, Type: StructProperty)
    void SET_JumpZVelocity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x28, Type: StructProperty)
    void SET_JumpHorizontalVelocityMax(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x28, Type: StructProperty)
    void SET_MaxTimeSpentInBoostedJump(const float& Value) { Write<float>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x4, Type: FloatProperty)
    void SET_AnimLayer(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ClassProperty)
    void SET_CameraStartShake(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: ClassProperty)
    void SET_GC_BoostedJumpBeingActivated(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x4, Type: StructProperty)
    void SET_AnimationMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    void SET_SkipAnimationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: StructProperty)
    void SET_PreventHolsterTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x20, Type: StructProperty)
    void SET_AllowPrimaryFireTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x4, Type: StructProperty)
    void SET_AllowSecondaryFireTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa0
struct FFortBoostedJumpActivationConfig
{
public:
    FScalableFloat MinSpeedToActivate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinTimeSpentInModeToActivate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat EdgeMinHeightToTheGround() const { return Read<FScalableFloat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat EdgeForwardPredictionMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)

    void SET_MinSpeedToActivate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_MinTimeSpentInModeToActivate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_EdgeMinHeightToTheGround(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_EdgeForwardPredictionMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
};

