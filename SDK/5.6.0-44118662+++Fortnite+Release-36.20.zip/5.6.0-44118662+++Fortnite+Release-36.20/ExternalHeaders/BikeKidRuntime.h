/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BikeKidRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AudioGameplay.h"
#include "TargetingSystem.h"
#include "Niagara.h"
#include "EnhancedInput.h"

// Size: 0x148
class UFortBikeKidAnalyticsComponent : public UFortControllerComponent
{
public:
    float SessionStartTime() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SessionLength() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    FScalableFloat MinSessionLength() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    float DistanceTraveled() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    FGameplayTag DismissalReason() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: StructProperty)
    FScalableFloat DistanceTraveledUpdateInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x28, Type: StructProperty)
    FTimerHandle DistanceTraveledUpdateTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: StructProperty)
    FVector LastRecorderBikeKidLocation() const { return Read<FVector>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x18, Type: StructProperty)

    void SET_SessionStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_SessionLength(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_MinSessionLength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_DistanceTraveled(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_DismissalReason(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: StructProperty)
    void SET_DistanceTraveledUpdateInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x28, Type: StructProperty)
    void SET_DistanceTraveledUpdateTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: StructProperty)
    void SET_LastRecorderBikeKidLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x18, Type: StructProperty)
};

// Size: 0xca0
class UFortGameplayAbility_BikeKid_SpeedBoost : public UFortGameplayAbility_BikeKid_TargetingBase
{
public:
    FGameplayTag DoorBashCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    UClass* DamageGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag DoorBashPawnLaunchGameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x4, Type: StructProperty)
    FScalableFloat DoorBashEnabledHotfix() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DoorBashSphereRadiusForPawnLaunch() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DoorBashScalarForPawnLaunch() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x28, Type: StructProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> DoorBashCollisionTypesForPawn() const { return Read<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat DoorBashEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x28, Type: StructProperty)
    FScalableFloat DamageOnBoostEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x28, Type: StructProperty)

    void SET_DoorBashCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    void SET_DamageGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: ClassProperty)
    void SET_DoorBashPawnLaunchGameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x4, Type: StructProperty)
    void SET_DoorBashEnabledHotfix(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x28, Type: StructProperty)
    void SET_DoorBashSphereRadiusForPawnLaunch(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x28, Type: StructProperty)
    void SET_DoorBashScalarForPawnLaunch(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x28, Type: StructProperty)
    void SET_DoorBashCollisionTypesForPawn(const TArray<TEnumAsByte<EObjectTypeQuery>>& Value) { Write<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x10, Type: ArrayProperty)
    void SET_DoorBashEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x28, Type: StructProperty)
    void SET_DamageOnBoostEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x28, Type: StructProperty)
};

// Size: 0xbb0
class UFortGameplayAbility_BikeKid_TargetingBase : public UFortGameplayAbility
{
public:
    UTargetingPreset* TargetingPreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    FTargetingRequestHandle AsyncTargetingHandle() const { return Read<FTargetingRequestHandle>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x4, Type: StructProperty)
    FTimerHandle TargetingTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)
    FScalableFloat TargetingInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x28, Type: StructProperty)
    bool bUseControllerAsInstigator() const { return Read<bool>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x1, Type: BoolProperty)

    void SET_TargetingPreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    void SET_AsyncTargetingHandle(const FTargetingRequestHandle& Value) { Write<FTargetingRequestHandle>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x4, Type: StructProperty)
    void SET_TargetingTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
    void SET_TargetingInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x28, Type: StructProperty)
    void SET_bUseControllerAsInstigator(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb90
class UFortGameplayAbility_BikeKid_Activate : public UFortGameplayAbility
{
public:
    UClass* RCActorClass() const { return Read<UClass*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ClassProperty)
    FVector SpawnOffset() const { return Read<FVector>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x18, Type: StructProperty)
    float ForwardObstructionCheckDistance() const { return Read<float>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x4, Type: FloatProperty)

    void SET_RCActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ClassProperty)
    void SET_SpawnOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x18, Type: StructProperty)
    void SET_ForwardObstructionCheckDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb78
class UFortGameplayAbility_BikeKid_Dismiss : public UFortGameplayAbility
{
public:
    FBikeKidDismissalData DismissDelayData() const { return Read<FBikeKidDismissalData>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x10, Type: StructProperty)

    void SET_DismissDelayData(const FBikeKidDismissalData& Value) { Write<FBikeKidDismissalData>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x10, Type: StructProperty)
};

// Size: 0xce8
class UFortGameplayAbility_BikeKid_MarkPotentialTargets : public UFortGameplayAbility_BikeKid_TargetingBase
{
public:
    FIndicatedActorData IndicatedActorData() const { return Read<FIndicatedActorData>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x100, Type: StructProperty)
    FScalableFloat MaxNumberOfPotentialTargets() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x28, Type: StructProperty)

    void SET_IndicatedActorData(const FIndicatedActorData& Value) { Write<FIndicatedActorData>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x100, Type: StructProperty)
    void SET_MaxNumberOfPotentialTargets(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x30
class UBikeKidPassiveMarkPayload : public UObject
{
public:
    FBikeKidStatusData TargetStatus() const { return Read<FBikeKidStatusData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)

    void SET_TargetStatus(const FBikeKidStatusData& Value) { Write<FBikeKidStatusData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
};

// Size: 0xdb0
class UFortGameplayAbility_BikeKid_PassiveMark : public UFortGameplayAbility_BikeKid_TargetingBase
{
public:
    FBikeKidStatusData CurrentTargetStatus() const { return Read<FBikeKidStatusData>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x8, Type: StructProperty)
    FStenciledActorData StenciledActorData() const { return Read<FStenciledActorData>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x80, Type: StructProperty)
    FIndicatedActorData IndicatedActorData() const { return Read<FIndicatedActorData>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x100, Type: StructProperty)
    FScalableFloat ActorTargetingRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd38); } // 0xd38 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeToConfirmTarget() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd60); } // 0xd60 (Size: 0x28, Type: StructProperty)
    AActor* CurrentTarget() const { return Read<AActor*>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle TargetConfirmationTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x8, Type: StructProperty)
    UBikeKidPassiveMarkPayload* PayloadCache() const { return Read<UBikeKidPassiveMarkPayload*>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentTargetStatus(const FBikeKidStatusData& Value) { Write<FBikeKidStatusData>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x8, Type: StructProperty)
    void SET_StenciledActorData(const FStenciledActorData& Value) { Write<FStenciledActorData>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x80, Type: StructProperty)
    void SET_IndicatedActorData(const FIndicatedActorData& Value) { Write<FIndicatedActorData>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x100, Type: StructProperty)
    void SET_ActorTargetingRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd38, Value); } // 0xd38 (Size: 0x28, Type: StructProperty)
    void SET_TimeToConfirmTarget(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd60, Value); } // 0xd60 (Size: 0x28, Type: StructProperty)
    void SET_CurrentTarget(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetConfirmationTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x8, Type: StructProperty)
    void SET_PayloadCache(const UBikeKidPassiveMarkPayload*& Value) { Write<UBikeKidPassiveMarkPayload*>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xbe0
class UFortGameplayAbility_BikeKid_Tether : public UFortGameplayAbility
{
public:
    FScalableFloat WarningRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x28, Type: StructProperty)
    FScalableFloat SignalLossRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x28, Type: StructProperty)
    bool bIsInWarningRange() const { return Read<bool>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x1, Type: BoolProperty)
    bool bIsInSignalLossRange() const { return Read<bool>(uintptr_t(this) + 0xbb9); } // 0xbb9 (Size: 0x1, Type: BoolProperty)
    FTimerHandle TetheringTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: StructProperty)
    FTimerHandle TetheringReportTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: StructProperty)
    FBikeKidDismissalData DismissDelayData() const { return Read<FBikeKidDismissalData>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x10, Type: StructProperty)

    void SET_WarningRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x28, Type: StructProperty)
    void SET_SignalLossRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x28, Type: StructProperty)
    void SET_bIsInWarningRange(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInSignalLossRange(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb9, Value); } // 0xbb9 (Size: 0x1, Type: BoolProperty)
    void SET_TetheringTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: StructProperty)
    void SET_TetheringReportTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: StructProperty)
    void SET_DismissDelayData(const FBikeKidDismissalData& Value) { Write<FBikeKidDismissalData>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x368
class AFortAthenaMutator_BikeKid : public AFortAthenaMutator
{
public:
    bool bIsControllingBikeKid() const { return Read<bool>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x1, Type: BoolProperty)

    void SET_bIsControllingBikeKid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x7b0
class AFortBikeKid : public ACharacter
{
public:
    UNiagaraComponent* NSBikeKidIdle_Native() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    UClass* TeamMateIndicatorMarkerWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x8, Type: ClassProperty)
    UAudioComponent* BikeKidMotorLoopComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* BikeKidThrustSoundComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer DefaultTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x20, Type: StructProperty)
    FGameplayTag ExplosionCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x4, Type: StructProperty)
    bool bExploded() const { return Read<bool>(uintptr_t(this) + 0x6c4); } // 0x6c4 (Size: 0x1, Type: BoolProperty)
    UFortAbilitySystemComponent* AbilitySystemComponent() const { return Read<UFortAbilitySystemComponent*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UFortActorComponent_Affiliation* AffiliationComponent() const { return Read<UFortActorComponent_Affiliation*>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    UFortAbilitySet* StartupAbilitySet() const { return Read<UFortAbilitySet*>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    AFortPawn* ControllingPlayerPawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UFortHealthSet* HealthSet() const { return Read<UFortHealthSet*>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UFortChargingSet_BikeKidEnergy* EnergySet() const { return Read<UFortChargingSet_BikeKidEnergy*>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    FFortAttributeInitializationKey AttributeInitKey() const { return Read<FFortAttributeInitializationKey>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x8, Type: StructProperty)
    TEnumAsByte<EPhysicalSurface> PrimarySurfaceType() const { return Read<TEnumAsByte<EPhysicalSurface>>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFortBaseWeaponDamage> WeaponResponseType() const { return Read<TEnumAsByte<EFortBaseWeaponDamage>>(uintptr_t(this) + 0x709); } // 0x709 (Size: 0x1, Type: ByteProperty)
    bool bPlayedDeath() const { return Read<bool>(uintptr_t(this) + 0x70a); } // 0x70a (Size: 0x1, Type: BoolProperty)
    FBikeKidDismissalData OutOfHealthDismissDelayData() const { return Read<FBikeKidDismissalData>(uintptr_t(this) + 0x70c); } // 0x70c (Size: 0x10, Type: StructProperty)
    TArray<FFortGameplayEffectContainerSpec> ExplodeEffectContainerSpecs() const { return Read<TArray<FFortGameplayEffectContainerSpec>>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x10, Type: ArrayProperty)
    UClass* PawnOverrideComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x8, Type: ClassProperty)
    USoundBase* BikeKidMotorLoopSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    USoundBase* BikeKidThrusterSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    UAudioParameterComponent* AudioParameter() const { return Read<UAudioParameterComponent*>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    FName LocallyViewedPawnAudioParamName() const { return Read<FName>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x4, Type: NameProperty)
    FName IsEnemyAudioParamName() const { return Read<FName>(uintptr_t(this) + 0x764); } // 0x764 (Size: 0x4, Type: NameProperty)
    FName ThrustAmountAudioParamName() const { return Read<FName>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x4, Type: NameProperty)
    float ThrustSoundThreshold() const { return Read<float>(uintptr_t(this) + 0x76c); } // 0x76c (Size: 0x4, Type: FloatProperty)
    FScalableFloat LaunchDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x28, Type: StructProperty)
    float ServerWorldCreationTime() const { return Read<float>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x4, Type: FloatProperty)

    void SET_NSBikeKidIdle_Native(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamMateIndicatorMarkerWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x8, Type: ClassProperty)
    void SET_BikeKidMotorLoopComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    void SET_BikeKidThrustSoundComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x20, Type: StructProperty)
    void SET_ExplosionCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x4, Type: StructProperty)
    void SET_bExploded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6c4, Value); } // 0x6c4 (Size: 0x1, Type: BoolProperty)
    void SET_AbilitySystemComponent(const UFortAbilitySystemComponent*& Value) { Write<UFortAbilitySystemComponent*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    void SET_AffiliationComponent(const UFortActorComponent_Affiliation*& Value) { Write<UFortActorComponent_Affiliation*>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    void SET_StartupAbilitySet(const UFortAbilitySet*& Value) { Write<UFortAbilitySet*>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ControllingPlayerPawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    void SET_HealthSet(const UFortHealthSet*& Value) { Write<UFortHealthSet*>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    void SET_EnergySet(const UFortChargingSet_BikeKidEnergy*& Value) { Write<UFortChargingSet_BikeKidEnergy*>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    void SET_AttributeInitKey(const FFortAttributeInitializationKey& Value) { Write<FFortAttributeInitializationKey>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x8, Type: StructProperty)
    void SET_PrimarySurfaceType(const TEnumAsByte<EPhysicalSurface>& Value) { Write<TEnumAsByte<EPhysicalSurface>>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x1, Type: ByteProperty)
    void SET_WeaponResponseType(const TEnumAsByte<EFortBaseWeaponDamage>& Value) { Write<TEnumAsByte<EFortBaseWeaponDamage>>(uintptr_t(this) + 0x709, Value); } // 0x709 (Size: 0x1, Type: ByteProperty)
    void SET_bPlayedDeath(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70a, Value); } // 0x70a (Size: 0x1, Type: BoolProperty)
    void SET_OutOfHealthDismissDelayData(const FBikeKidDismissalData& Value) { Write<FBikeKidDismissalData>(uintptr_t(this) + 0x70c, Value); } // 0x70c (Size: 0x10, Type: StructProperty)
    void SET_ExplodeEffectContainerSpecs(const TArray<FFortGameplayEffectContainerSpec>& Value) { Write<TArray<FFortGameplayEffectContainerSpec>>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnOverrideComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x8, Type: ClassProperty)
    void SET_BikeKidMotorLoopSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    void SET_BikeKidThrusterSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioParameter(const UAudioParameterComponent*& Value) { Write<UAudioParameterComponent*>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    void SET_LocallyViewedPawnAudioParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x4, Type: NameProperty)
    void SET_IsEnemyAudioParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x764, Value); } // 0x764 (Size: 0x4, Type: NameProperty)
    void SET_ThrustAmountAudioParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x4, Type: NameProperty)
    void SET_ThrustSoundThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x76c, Value); } // 0x76c (Size: 0x4, Type: FloatProperty)
    void SET_LaunchDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x28, Type: StructProperty)
    void SET_ServerWorldCreationTime(const float& Value) { Write<float>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1f8
class UFortBikeKidCameraMode : public UFort3PCameraMode
{
public:
    bool bShouldInterpolateLocation() const { return Read<bool>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
    bool bShouldInterpolateRotation() const { return Read<bool>(uintptr_t(this) + 0x1f1); } // 0x1f1 (Size: 0x1, Type: BoolProperty)

    void SET_bShouldInterpolateLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldInterpolateRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f1, Value); } // 0x1f1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UBikeKidDeferredDestructionPayload : public UObject
{
public:
    FBikeKidDismissalData DeferredDestructionData() const { return Read<FBikeKidDismissalData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_DeferredDestructionData(const FBikeKidDismissalData& Value) { Write<FBikeKidDismissalData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x458
class UFortBikeKidControllingComponent : public UFortControllerComponent
{
public:
    FRotator CachedControllerRotator() const { return Read<FRotator>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    UInputComponent* BikeKidInputComponent() const { return Read<UInputComponent*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    AFortBikeKid* ControlledBikeKid() const { return Read<AFortBikeKid*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    AFortBikeKid* LastControlledBikeKid() const { return Read<AFortBikeKid*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    AActor* OriginalBikeKidOwner() const { return Read<AActor*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    UFortInputMappingContext* BikeKidInputContext() const { return Read<UFortInputMappingContext*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    TArray<FBikeKidInputTriggerableEvent> InputTriggerableEvents() const { return Read<TArray<FBikeKidInputTriggerableEvent>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    UInputAction* DismissAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    FStenciledActorData OwningActorStencilData() const { return Read<FStenciledActorData>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x80, Type: StructProperty)
    FBikeKidDismissalData CurrentDismissalData() const { return Read<FBikeKidDismissalData>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: StructProperty)
    UClass* FirstPersonCameraModeOverride() const { return Read<UClass*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
    UClass* ThirdPersonCameraModeOverride() const { return Read<UClass*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
    FGameplayAbilitySpec FakeCameraAbilitySpec() const { return Read<FGameplayAbilitySpec>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0xf0, Type: StructProperty)
    TArray<FName> LegacyInputActionsToBlock() const { return Read<TArray<FName>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    UClass* BlockActionsGameplayEffect() const { return Read<UClass*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ClassProperty)
    UBikeKidDeferredDestructionPayload* DismissPayloadCache() const { return Read<UBikeKidDeferredDestructionPayload*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat DismissButtonPressCooldown() const { return Read<FScalableFloat>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x28, Type: StructProperty)
    float InitialDismissInputCooldown() const { return Read<float>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: FloatProperty)
    FViewTargetTransitionParams PlayerToBikeKidTransitionParams() const { return Read<FViewTargetTransitionParams>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x10, Type: StructProperty)
    FViewTargetTransitionParams BikeKidToPlayerTransitionParams() const { return Read<FViewTargetTransitionParams>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x10, Type: StructProperty)
    FGameplayTagContainer InterruptingPlayerTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x20, Type: StructProperty)
    FScalableFloat MaxTurnRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x28, Type: StructProperty)
    FScalableFloat MouseTurnRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat GamepadTurnRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TouchLookAccelerationMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x28, Type: StructProperty)
    FScalableFloat GyroTurnRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x28, Type: StructProperty)

    void SET_CachedControllerRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_BikeKidInputComponent(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlledBikeKid(const AFortBikeKid*& Value) { Write<AFortBikeKid*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_LastControlledBikeKid(const AFortBikeKid*& Value) { Write<AFortBikeKid*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_OriginalBikeKidOwner(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_BikeKidInputContext(const UFortInputMappingContext*& Value) { Write<UFortInputMappingContext*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_InputTriggerableEvents(const TArray<FBikeKidInputTriggerableEvent>& Value) { Write<TArray<FBikeKidInputTriggerableEvent>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    void SET_DismissAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_OwningActorStencilData(const FStenciledActorData& Value) { Write<FStenciledActorData>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x80, Type: StructProperty)
    void SET_CurrentDismissalData(const FBikeKidDismissalData& Value) { Write<FBikeKidDismissalData>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: StructProperty)
    void SET_FirstPersonCameraModeOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
    void SET_ThirdPersonCameraModeOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
    void SET_FakeCameraAbilitySpec(const FGameplayAbilitySpec& Value) { Write<FGameplayAbilitySpec>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0xf0, Type: StructProperty)
    void SET_LegacyInputActionsToBlock(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_BlockActionsGameplayEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ClassProperty)
    void SET_DismissPayloadCache(const UBikeKidDeferredDestructionPayload*& Value) { Write<UBikeKidDeferredDestructionPayload*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_DismissButtonPressCooldown(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x28, Type: StructProperty)
    void SET_InitialDismissInputCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: FloatProperty)
    void SET_PlayerToBikeKidTransitionParams(const FViewTargetTransitionParams& Value) { Write<FViewTargetTransitionParams>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x10, Type: StructProperty)
    void SET_BikeKidToPlayerTransitionParams(const FViewTargetTransitionParams& Value) { Write<FViewTargetTransitionParams>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x10, Type: StructProperty)
    void SET_InterruptingPlayerTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x20, Type: StructProperty)
    void SET_MaxTurnRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x28, Type: StructProperty)
    void SET_MouseTurnRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x28, Type: StructProperty)
    void SET_GamepadTurnRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x28, Type: StructProperty)
    void SET_TouchLookAccelerationMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x28, Type: StructProperty)
    void SET_GyroTurnRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x28, Type: StructProperty)
};

// Size: 0x1020
class UFortBikeKidMovementComponent : public UCharacterMovementComponent
{
public:
    FScalableFloat PreLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xfa8); } // 0xfa8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PostLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xfd0); } // 0xfd0 (Size: 0x28, Type: StructProperty)
    UBoxComponent* HitBoxComponent() const { return Read<UBoxComponent*>(uintptr_t(this) + 0xff8); } // 0xff8 (Size: 0x8, Type: ObjectProperty)

    void SET_PreLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xfa8, Value); } // 0xfa8 (Size: 0x28, Type: StructProperty)
    void SET_PostLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xfd0, Value); } // 0xfd0 (Size: 0x28, Type: StructProperty)
    void SET_HitBoxComponent(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0xff8, Value); } // 0xff8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UFortBikeKidPawnOverrideComponent : public UFortPawnOverrideComponent
{
public:
    UClass* BikeKidSpectateCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)

    void SET_BikeKidSpectateCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xc8
class UFortBikeKidPawnOwnerOverrideComponent : public UFortPawnOverrideComponent
{
public:
    TWeakObjectPtr<AFortBikeKid*> ControlledBikeKid() const { return Read<TWeakObjectPtr<AFortBikeKid*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ControlledBikeKid(const TWeakObjectPtr<AFortBikeKid*>& Value) { Write<TWeakObjectPtr<AFortBikeKid*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x108
class UFortChargingSet_BikeKidEnergy : public UFortChargingSet_Base
{
public:
    FFortGameplayAttributeData Energy() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData MaxEnergy() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData EnergyChargeRate() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ServerTimeEnergyIncrements() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)

    void SET_Energy(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x28, Type: StructProperty)
    void SET_MaxEnergy(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_EnergyChargeRate(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_ServerTimeEnergyIncrements(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x10
struct FBikeKidDismissalData
{
public:
    float DeposessDelay() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bInstantDestruction() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FGameplayTag DismissalReason() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    float ServerDismissStartTime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_DeposessDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bInstantDestruction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_DismissalReason(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_ServerDismissStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FOnFortBikeKidDeployed
{
public:
    TWeakObjectPtr<AFortBikeKid*> DeployedBikeKid() const { return Read<TWeakObjectPtr<AFortBikeKid*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_DeployedBikeKid(const TWeakObjectPtr<AFortBikeKid*>& Value) { Write<TWeakObjectPtr<AFortBikeKid*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x4
struct FOnFortBikeKidDismissed
{
public:
    FGameplayTag DismissalReason() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_DismissalReason(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x18
struct FOnFortBikeKidMarkedEnemies
{
public:
    FGameplayTag Source() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<AActor*> MarkedActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Source(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_MarkedActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FBikeKidStatusData
{
public:
    uint8_t Status() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float ServerTimeStatusChanged() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Status(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ServerTimeStatusChanged(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FBikeKidInputTriggerableEvent
{
public:
    FName InputActionName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UInputAction* InputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GameplayEventToTrigger() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)

    void SET_InputActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_InputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayEventToTrigger(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
};

