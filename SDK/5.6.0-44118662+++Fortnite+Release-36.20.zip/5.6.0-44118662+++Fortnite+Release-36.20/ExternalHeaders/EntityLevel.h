/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityLevel
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x530
class UEntitySceneComponent : public UPrimitiveComponent
{
public:
    ALevelEntity* LevelEntity() const { return Read<ALevelEntity*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    bool bIgnoreAttachmentUponPaste() const { return Read<bool>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x1, Type: BoolProperty)

    void SET_LevelEntity(const ALevelEntity*& Value) { Write<ALevelEntity*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    void SET_bIgnoreAttachmentUponPaste(const bool& Value) { Write<bool>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2e8
class AEntityProxyActor : public AActor
{
public:
    UObject* Entity() const { return Read<UObject*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    ALevelEntity* LevelEntity() const { return Read<ALevelEntity*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UObject* TransformComponent() const { return Read<UObject*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UObject* DuplicatedEntity() const { return Read<UObject*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)

    void SET_Entity(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_LevelEntity(const ALevelEntity*& Value) { Write<ALevelEntity*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_TransformComponent(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_DuplicatedEntity(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UEntityProxyActorComponent : public UActorComponent
{
public:
    UObject* Entity() const { return Read<UObject*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UObject* EntityComponent() const { return Read<UObject*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_Entity(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_EntityComponent(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2c0
class ALevelEntity : public AActor
{
public:
    UObject* LevelEntity() const { return Read<UObject*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_LevelEntity(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

