/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteEngineLoadingScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x580
class UFortniteUserInterfaceSettings : public UDeveloperSettings
{
public:
    FRuntimeFloatCurve WidthScaleCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_iOS_InGame() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_iOS_InGame() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_iOS_FrontEnd() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_iOS_FrontEnd() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_Android_InGame() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_Android_InGame() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_Android_FrontEnd() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_Android_FrontEnd() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x88, Type: StructProperty)

    void SET_WidthScaleCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x88, Type: StructProperty)
    void SET_HeightScaleCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x88, Type: StructProperty)
    void SET_WidthScaleCurve_iOS_InGame(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x88, Type: StructProperty)
    void SET_HeightScaleCurve_iOS_InGame(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x88, Type: StructProperty)
    void SET_WidthScaleCurve_iOS_FrontEnd(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x88, Type: StructProperty)
    void SET_HeightScaleCurve_iOS_FrontEnd(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x88, Type: StructProperty)
    void SET_WidthScaleCurve_Android_InGame(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x88, Type: StructProperty)
    void SET_HeightScaleCurve_Android_InGame(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x88, Type: StructProperty)
    void SET_WidthScaleCurve_Android_FrontEnd(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x88, Type: StructProperty)
    void SET_HeightScaleCurve_Android_FrontEnd(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x88, Type: StructProperty)
};

