/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Curie
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0x28
class UFireAllocationHandler_C : public UFortCurieElementAllocationHandlerFire
{
public:
};

// Size: 0x40
class UFireAttachConditionHandler_C : public UFortCurieElementAttachConditionHandlerFire
{
public:
};

// Size: 0x30
class UWaterSelfInteractHandler_C : public UFortCurieElementInteractWithSameElementHandler
{
public:
};

// Size: 0x30
class UFireSelfInteractHandler_C : public UFortCurieElementInteractWithSameElementHandlerFire
{
public:
};

// Size: 0xe0
class UCurieEntityStateBehavior_FullyIgnited_C : public UFortCurieEntityStateBehavior_Burning
{
public:
};

// Size: 0xe8
class UCurieEntityStateBehavior_Drying_C : public UFortCurieEntityStateBehavior_Drying
{
public:
};

// Size: 0xe0
class UCurieEntityStateBehavior_ElemInteraction_Water_C : public UFortCurieEntityStateBehavior
{
public:
};

// Size: 0xe0
class UCurieEntityStateBehavior_ElemInteraction_Fire_C : public UFortCurieEntityStateBehavior
{
public:
};

// Size: 0xe0
class UCurieEntityStateBehavior_ElemAttached_Fire_C : public UFortCurieEntityStateBehavior
{
public:
};

// Size: 0x40
class UWaterAttachConditionHandler_C : public UFortCurieElementAttachConditionHandlerWater
{
public:
};

// Size: 0x90
class UFireContainerInteractHandler_C : public UFortCurieElementInteractWithContainerHandler
{
public:
};

// Size: 0xa68
class UGE_Curie_FireInteract_Vehicle_C : public UGameplayEffect
{
public:
};

// Size: 0x90
class UFireMaterialInteractHandler_C : public UFortCurieElementInteractWithMaterialHandlerFire
{
public:
};

// Size: 0xa0
class UWaterMaterialInteractHandler_C : public UFortCurieElementInteractWithMaterialHandlerWater
{
public:
};

// Size: 0x90
class UFireAttachHandler_C : public UFortCurieElementAttachHandlerFire
{
public:
};

// Size: 0x80
class UFireWaterInteractHandler_C : public UFortCurieElementInteractWithElementHandler
{
public:
};

// Size: 0xa68
class UGE_CurieElementalStatus_Burning_C : public UGameplayEffect
{
public:
};

// Size: 0x80
class UWaterFireInteractHandler_C : public UFortCurieElementInteractWithElementHandler
{
public:
};

// Size: 0xc8
class UCurieComponent : public UActorComponent
{
public:
};

// Size: 0xc0
class UCurieEntityStateBehavior : public UCurieElementGameplayEffectOwner
{
public:
    FGameplayTagContainer RequiredAttachedElements() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer RequiredInteractingElements() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedAttachmentEntityTypes() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x20, Type: StructProperty)
    TArray<FCurieEffectContainer> OnBeginEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OngoingEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnEndEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    bool bShouldDetach() const { return (Read<uint8_t>(uintptr_t(this) + 0xb8) >> 0x0) & 1; } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    bool bSkipExecuteAttachDetach() const { return (Read<uint8_t>(uintptr_t(this) + 0xb8) >> 0x1) & 1; } // 0xb8:1 (Size: 0x1, Type: BoolProperty)

    void SET_RequiredAttachedElements(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_RequiredInteractingElements(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_AllowedAttachmentEntityTypes(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x20, Type: StructProperty)
    void SET_OnBeginEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_OngoingEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_OnEndEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_bShouldDetach(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb8, B); } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipExecuteAttachDetach(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xb8, B); } // 0xb8:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UCurieElementGameplayEffectOwner : public UObject
{
public:
};

// Size: 0x50
class UCurieGlobals : public UObject
{
public:
    bool bEnableCurie() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FSoftClassPath CurieGlobalsClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    UCurieManager* RegisteredCurieManager() const { return Read<UCurieManager*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_bEnableCurie(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_CurieGlobalsClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_RegisteredCurieManager(const UCurieManager*& Value) { Write<UCurieManager*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UCurieElementAllocationHandler : public UObject
{
public:
};

// Size: 0x30
class UCurieElementInteractWithElementHandler : public UObject
{
public:
    uint8_t HandlerPriority() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    FGameplayTag ElementTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)

    void SET_HandlerPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_HandlerBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_ElementTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
};

// Size: 0x30
class UCurieElementInteractWithMaterialHandler : public UObject
{
public:
    uint8_t HandlerPriority() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    FGameplayTag ElementTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)

    void SET_HandlerPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_HandlerBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_ElementTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
};

// Size: 0x60
class UCurieElementAttachHandler : public UCurieElementGameplayEffectOwner
{
public:
    uint8_t HandlerPriority() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    FGameplayTag ElementTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)
    TArray<FCurieEffectContainer> OnBeginAttachmentEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OngoingAttachmentEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnEndAttachmentEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_HandlerPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_HandlerBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_ElementTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
    void SET_OnBeginAttachmentEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_OngoingAttachmentEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_OnEndAttachmentEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
class UCurieElementAttachConditionHandler : public UObject
{
public:
    uint8_t HandlerPriority() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FGameplayTag ElementTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)

    void SET_HandlerPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_ElementTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
};

// Size: 0x70
class UCurieElementInteractWithContainerHandler : public UCurieElementGameplayEffectOwner
{
public:
    uint8_t HandlerPriority() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    FGameplayTag ElementTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)
    TArray<FCurieEffectContainer> OnInstantInteractionEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnBeginInteractionEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OngoingInteractionEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnEndInteractionEffects() const { return Read<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)

    void SET_HandlerPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_HandlerBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_ElementTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
    void SET_OnInstantInteractionEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_OnBeginInteractionEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_OngoingInteractionEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_OnEndInteractionEffects(const TArray<FCurieEffectContainer>& Value) { Write<TArray<FCurieEffectContainer>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UCurieInterface : public UInterface
{
public:
};

// Size: 0x648
class UCurieManager : public UGameStateComponent
{
public:
    UClass* CurieComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    FName CurieManagerRegistryName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FName MaterialDataRegistryName() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)
    FName ElementDataRegistryName() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    FName EntityStateDataRegistryName() const { return Read<FName>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: NameProperty)
    TMap<FGameplayTag, UCurieElementAllocationHandler*> ElementAllocationHandlers() const { return Read<TMap<FGameplayTag, UCurieElementAllocationHandler*>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FCurieElementAttachHandlersContainer> ElementAttachmentHandlers() const { return Read<TMap<FGameplayTag, FCurieElementAttachHandlersContainer>>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FCurieElementAttachConditionHandlersContainer> ElementAttachmentConditionHandlers() const { return Read<TMap<FGameplayTag, FCurieElementAttachConditionHandlersContainer>>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x50, Type: MapProperty)
    TMap<FCurieElementPairKey, FCurieElementInteractWithElementHandlersContainer> ElementInteractWithElementHandlers() const { return Read<TMap<FCurieElementPairKey, FCurieElementInteractWithElementHandlersContainer>>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FCurieElementInteractWithMaterialHandlersContainer> ElementInteractWithMaterialHandlers() const { return Read<TMap<FGameplayTag, FCurieElementInteractWithMaterialHandlersContainer>>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FCurieElementInteractWithContainerHandlersContainer> ElementInteractWithContainerHandlers() const { return Read<TMap<FGameplayTag, FCurieElementInteractWithContainerHandlersContainer>>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x50, Type: MapProperty)
    TArray<UCurieManagerComponent*> CurieManagerComponents() const { return Read<TArray<UCurieManagerComponent*>>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x10, Type: ArrayProperty)

    void SET_CurieComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_CurieManagerRegistryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_MaterialDataRegistryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
    void SET_ElementDataRegistryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_EntityStateDataRegistryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: NameProperty)
    void SET_ElementAllocationHandlers(const TMap<FGameplayTag, UCurieElementAllocationHandler*>& Value) { Write<TMap<FGameplayTag, UCurieElementAllocationHandler*>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x50, Type: MapProperty)
    void SET_ElementAttachmentHandlers(const TMap<FGameplayTag, FCurieElementAttachHandlersContainer>& Value) { Write<TMap<FGameplayTag, FCurieElementAttachHandlersContainer>>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    void SET_ElementAttachmentConditionHandlers(const TMap<FGameplayTag, FCurieElementAttachConditionHandlersContainer>& Value) { Write<TMap<FGameplayTag, FCurieElementAttachConditionHandlersContainer>>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x50, Type: MapProperty)
    void SET_ElementInteractWithElementHandlers(const TMap<FCurieElementPairKey, FCurieElementInteractWithElementHandlersContainer>& Value) { Write<TMap<FCurieElementPairKey, FCurieElementInteractWithElementHandlersContainer>>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x50, Type: MapProperty)
    void SET_ElementInteractWithMaterialHandlers(const TMap<FGameplayTag, FCurieElementInteractWithMaterialHandlersContainer>& Value) { Write<TMap<FGameplayTag, FCurieElementInteractWithMaterialHandlersContainer>>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x50, Type: MapProperty)
    void SET_ElementInteractWithContainerHandlers(const TMap<FGameplayTag, FCurieElementInteractWithContainerHandlersContainer>& Value) { Write<TMap<FGameplayTag, FCurieElementInteractWithContainerHandlersContainer>>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x50, Type: MapProperty)
    void SET_CurieManagerComponents(const TArray<UCurieManagerComponent*>& Value) { Write<TArray<UCurieManagerComponent*>>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UCurieManagerComponentInterface : public UInterface
{
public:
};

// Size: 0x40
class UCurieManagerComponentConfig : public UPrimaryDataAsset
{
public:
    FName ConfigName() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    FGameplayTag ConfigTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: StructProperty)

    void SET_ConfigName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_ConfigTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: StructProperty)
};

// Size: 0x30
class UCurieManagerComponent : public UObject
{
public:
    UCurieManagerComponentConfig* CachedConfig() const { return Read<UCurieManagerComponentConfig*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_CachedConfig(const UCurieManagerComponentConfig*& Value) { Write<UCurieManagerComponentConfig*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4
struct FCurieContainerHandle
{
public:
};

// Size: 0x88
struct FCurieMaterialDefinitionBase : public FTableRowBase
{
public:
    FGameplayTagContainer ElementalImmunities() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ElementAttachmentImmunities() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ElementsAllowedWhenCannotBeDamaged() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer MaterialProperties() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x20, Type: StructProperty)

    void SET_ElementalImmunities(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_ElementAttachmentImmunities(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_ElementsAllowedWhenCannotBeDamaged(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_MaterialProperties(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x20, Type: StructProperty)
};

// Size: 0x80
struct FCurieElementDefinitionBase : public FTableRowBase
{
public:
    UClass* ElementAllocationHandler() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> ElementAttachHandlers() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    UClass* ElementAttachConditionHandler() const { return Read<UClass*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> ElementInteractHandlers() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ElementMaterialInteractHandlers() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ElementContainerInteractHandlers() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ElementalImmunities() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    bool bIsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x78) >> 0x0) & 1; } // 0x78:0 (Size: 0x1, Type: BoolProperty)

    void SET_ElementAllocationHandler(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_ElementAttachHandlers(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ElementAttachConditionHandler(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ClassProperty)
    void SET_ElementInteractHandlers(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ElementMaterialInteractHandlers(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_ElementContainerInteractHandlers(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_ElementalImmunities(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_bIsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x78); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x78, B); } // 0x78:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FCurieEntityStateDefinitionBase : public FTableRowBase
{
public:
    UClass* StateBehaviorClass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bIsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x0) & 1; } // 0x10:0 (Size: 0x1, Type: BoolProperty)

    void SET_StateBehaviorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_bIsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FCurieElementAttachHandlersContainer
{
public:
    TArray<UCurieElementAttachHandler*> Handlers() const { return Read<TArray<UCurieElementAttachHandler*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Handlers(const TArray<UCurieElementAttachHandler*>& Value) { Write<TArray<UCurieElementAttachHandler*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCurieElementAttachConditionHandlersContainer
{
public:
    TArray<UCurieElementAttachConditionHandler*> Handlers() const { return Read<TArray<UCurieElementAttachConditionHandler*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Handlers(const TArray<UCurieElementAttachConditionHandler*>& Value) { Write<TArray<UCurieElementAttachConditionHandler*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCurieElementInteractWithElementHandlersContainer
{
public:
    TArray<UCurieElementInteractWithElementHandler*> Handlers() const { return Read<TArray<UCurieElementInteractWithElementHandler*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Handlers(const TArray<UCurieElementInteractWithElementHandler*>& Value) { Write<TArray<UCurieElementInteractWithElementHandler*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCurieElementInteractWithMaterialHandlersContainer
{
public:
    TArray<UCurieElementInteractWithMaterialHandler*> Handlers() const { return Read<TArray<UCurieElementInteractWithMaterialHandler*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Handlers(const TArray<UCurieElementInteractWithMaterialHandler*>& Value) { Write<TArray<UCurieElementInteractWithMaterialHandler*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCurieElementInteractWithContainerHandlersContainer
{
public:
    TArray<UCurieElementInteractWithContainerHandler*> Handlers() const { return Read<TArray<UCurieElementInteractWithContainerHandler*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Handlers(const TArray<UCurieElementInteractWithContainerHandler*>& Value) { Write<TArray<UCurieElementInteractWithContainerHandler*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCurieInteractParamsHandle
{
public:
};

// Size: 0x8
struct FCurieElementPairKey
{
public:
};

// Size: 0x20
struct FCurieManagerComponentEntry : public FTableRowBase
{
public:
    bool bIsActive() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Priority() const { return Read<uint8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: EnumProperty)
    UClass* ManagerType() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)
    UCurieManagerComponentConfig* Config() const { return Read<UCurieManagerComponentConfig*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_bIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_Priority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: EnumProperty)
    void SET_ManagerType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
    void SET_Config(const UCurieManagerComponentConfig*& Value) { Write<UCurieManagerComponentConfig*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4
struct FCurieInteractHandle
{
public:
};

// Size: 0x50
struct FCurieEffectContainer
{
public:
    FGameplayTagQuery TargetFilter() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    UClass* GameplayEffect() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)

    void SET_TargetFilter(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_GameplayEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x4
struct FCurieStateHandle
{
public:
};

// Size: 0x4
struct FCurieElementHandle
{
public:
};

