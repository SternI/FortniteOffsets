/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameFeatureSet
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28
class UGameFeatureSetAssetReplacementMappingBase : public UObject
{
public:
};

// Size: 0x48
class UGameFeatureSetPlayerSpawnerReplacement : public UGameFeatureSetAssetReplacementMappingBase
{
public:
    TSoftObjectPtr<UObject> PlayerSpawnerClass() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_PlayerSpawnerClass(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x48
class UGameFeatureSetIslandSettingsReplacement : public UGameFeatureSetAssetReplacementMappingBase
{
public:
};

// Size: 0x38
class UGameFeatureAction_SetGFSClassReplacements : public UGameFeatureAction
{
public:
    TArray<UGameFeatureSetAssetReplacementMappingBase*> ReplacementMappings() const { return Read<TArray<UGameFeatureSetAssetReplacementMappingBase*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ReplacementMappings(const TArray<UGameFeatureSetAssetReplacementMappingBase*>& Value) { Write<TArray<UGameFeatureSetAssetReplacementMappingBase*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x248
class UGameFeatureSetSubsystem : public UEngineSubsystem
{
public:
};

