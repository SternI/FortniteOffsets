/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnnualRefundTokenUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "UMG.h"

// Size: 0x15d0
class UFortPurchaseHistoryEntryBase : public UFortHoldableButton
{
public:
    UClass* ItemCardClass() const { return Read<UClass*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ClassProperty)
    float CardWidthOverride() const { return Read<float>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x4, Type: FloatProperty)
    UCommonTextBlock* Text_Name() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    TArray<FString> LootEntryItemTypesToExclude() const { return Read<TArray<FString>>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LootEntryItemTypesToCombine() const { return Read<TArray<FString>>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x10, Type: ArrayProperty)

    void SET_ItemCardClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ClassProperty)
    void SET_CardWidthOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x4, Type: FloatProperty)
    void SET_Text_Name(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_LootEntryItemTypesToExclude(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x10, Type: ArrayProperty)
    void SET_LootEntryItemTypesToCombine(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x15d0
class UFortPurchaseHistoryEntry : public UFortPurchaseHistoryEntryBase
{
public:
};

// Size: 0x15d0
class UFortPurchaseHistoryBundleEntry : public UFortPurchaseHistoryEntryBase
{
public:
    bool bIsExpanded() const { return Read<bool>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x1, Type: BoolProperty)

    void SET_bIsExpanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3e8
class UFortPurchaseHistoryTreeView : public UFortPurchaseHistoryListView
{
public:
    UClass* HeaderEntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ClassProperty)

    void SET_HeaderEntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x3b0
class UFortPurchaseHistoryListView : public UListViewBase
{
public:
};

// Size: 0x300
class UFortAnnualRefundTicket : public UUserWidget
{
public:
    UCommonTextBlock* Text_AvailableDate() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_AvailableDate(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x510
class UFortAnnualRefundTokenData : public UFortGameFeatureData
{
public:
};

// Size: 0x6c0
class UFortPurchaseHistoryScreen : public UFortActivatablePanel
{
public:
    FDataTableRowHandle BackAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x10, Type: StructProperty)
    UCommonAnimatedSwitcher* Switcher_MainContent() const { return Read<UCommonAnimatedSwitcher*>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: ObjectProperty)
    UFortPurchaseHistoryTreeView* TreeView_Purchases() const { return Read<UFortPurchaseHistoryTreeView*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PostApproval() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* ScrollBox_ReturnTypeInfo() const { return Read<UScrollBox*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Desc() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RefundCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ResultHeader() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ResultTitle() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ResultDesc() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Left() const { return Read<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Center() const { return Read<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Right() const { return Read<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_CancelPurchaseInfo() const { return Read<UWidget*>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_ReturnTicketInfo() const { return Read<UWidget*>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_TokenlessRefundInfo() const { return Read<UWidget*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_NonRefundableInfo() const { return Read<UWidget*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_BundledPurchaseInfo() const { return Read<UWidget*>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_BundledPurchaseTokenlessRefundInfo() const { return Read<UWidget*>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)

    void SET_BackAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x10, Type: StructProperty)
    void SET_Switcher_MainContent(const UCommonAnimatedSwitcher*& Value) { Write<UCommonAnimatedSwitcher*>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: ObjectProperty)
    void SET_TreeView_Purchases(const UFortPurchaseHistoryTreeView*& Value) { Write<UFortPurchaseHistoryTreeView*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PostApproval(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_ScrollBox_ReturnTypeInfo(const UScrollBox*& Value) { Write<UScrollBox*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Desc(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_RefundCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ResultHeader(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ResultTitle(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ResultDesc(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_RefundTicket_Left(const UFortAnnualRefundTicket*& Value) { Write<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    void SET_RefundTicket_Center(const UFortAnnualRefundTicket*& Value) { Write<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_RefundTicket_Right(const UFortAnnualRefundTicket*& Value) { Write<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_CancelPurchaseInfo(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_ReturnTicketInfo(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_TokenlessRefundInfo(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_NonRefundableInfo(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_BundledPurchaseInfo(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_BundledPurchaseTokenlessRefundInfo(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x618
class UFortRefundConfirmation : public UFortActivatablePanel
{
public:
    UCommonTextBlock* Text_RefundsRemaining() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RefundCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_AreYouSure() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Yes() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_No() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Left() const { return Read<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Center() const { return Read<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Right() const { return Read<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_RefundsRemaining(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_RefundCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_AreYouSure(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Yes(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_No(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    void SET_RefundTicket_Left(const UFortAnnualRefundTicket*& Value) { Write<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    void SET_RefundTicket_Center(const UFortAnnualRefundTicket*& Value) { Write<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x8, Type: ObjectProperty)
    void SET_RefundTicket_Right(const UFortAnnualRefundTicket*& Value) { Write<UFortAnnualRefundTicket*>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FPurchaseHistoryBundleEntry
{
public:
    FString ID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_ID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

