/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AutoAimWeaponUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayAbilities.h"

// Size: 0x2b0
class UFortAutoAimTargetImage : public UImage
{
public:
    FScalableFloat AutoAimReticleSize() const { return Read<FScalableFloat>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)

    void SET_AutoAimReticleSize(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
};

