/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeatSyncedAnimRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "MusicEventSystem.h"
#include "HarmonixMetasound.h"
#include "BeatSyncedAnimMetaData.h"

// Size: 0x28
class UBeatSyncedAnimLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UFMBeatTimingUtils : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x118
class UMontageBeatSyncComponent : public UActorComponent
{
public:
    float UsingMaxPlayRateBeforeHalf() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float UsingMinPlayRateBeforeDoubling() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UMusicClockComponent*> WeakMusicClockPtr() const { return Read<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicEventInstance*> WeakMusicEventPtr() const { return Read<TWeakObjectPtr<UMusicEventInstance*>>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t UserEmoteBeatSyncingPermission() const { return Read<uint8_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x1, Type: EnumProperty)
    uint8_t UsingUserEmoteBeatSyncingPermission() const { return Read<uint8_t>(uintptr_t(this) + 0xd5); } // 0xd5 (Size: 0x1, Type: EnumProperty)
    bool bIsMusicPlaying() const { return Read<bool>(uintptr_t(this) + 0xd6); } // 0xd6 (Size: 0x1, Type: BoolProperty)
    bool bHaveTimingInfo() const { return Read<bool>(uintptr_t(this) + 0xd7); } // 0xd7 (Size: 0x1, Type: BoolProperty)
    int32_t LastKnownMontageInstanceId() const { return Read<int32_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: IntProperty)
    AFortPlayerPawn* OwnerFortPlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    ASkeletalMeshActor* OwnerSkeletalMeshActor() const { return Read<ASkeletalMeshActor*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* OwnerMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UPreciseBeatSyncedAnimMetaData* ActiveTimingInfo() const { return Read<UPreciseBeatSyncedAnimMetaData*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)

    void SET_UsingMaxPlayRateBeforeHalf(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_UsingMinPlayRateBeforeDoubling(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_WeakMusicClockPtr(const TWeakObjectPtr<UMusicClockComponent*>& Value) { Write<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_WeakMusicEventPtr(const TWeakObjectPtr<UMusicEventInstance*>& Value) { Write<TWeakObjectPtr<UMusicEventInstance*>>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserEmoteBeatSyncingPermission(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x1, Type: EnumProperty)
    void SET_UsingUserEmoteBeatSyncingPermission(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd5, Value); } // 0xd5 (Size: 0x1, Type: EnumProperty)
    void SET_bIsMusicPlaying(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd6, Value); } // 0xd6 (Size: 0x1, Type: BoolProperty)
    void SET_bHaveTimingInfo(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd7, Value); } // 0xd7 (Size: 0x1, Type: BoolProperty)
    void SET_LastKnownMontageInstanceId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: IntProperty)
    void SET_OwnerFortPlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerSkeletalMeshActor(const ASkeletalMeshActor*& Value) { Write<ASkeletalMeshActor*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveTimingInfo(const UPreciseBeatSyncedAnimMetaData*& Value) { Write<UPreciseBeatSyncedAnimMetaData*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd0
class USparksAnimLoggingComponent : public UActorComponent
{
public:
};

// Size: 0x38
class UAnimNotify_BeatMarker : public UAnimNotify
{
public:
};

// Size: 0xb0
struct FAnimNode_PlayBeatSyncedAnim : public FAnimNode_SequenceEvaluator
{
public:
    UAnimSequenceBase* InSequence() const { return Read<UAnimSequenceBase*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FBeatAndTime BeatAndTime() const { return Read<FBeatAndTime>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    float TempoMultiplier() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float PreviewBPM() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    bool bAlwaysAllowPreviewBPM() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t SyncAnimBeatTo() const { return Read<uint8_t>(uintptr_t(this) + 0x61); } // 0x61 (Size: 0x1, Type: EnumProperty)
    uint8_t Logging() const { return Read<uint8_t>(uintptr_t(this) + 0x62); } // 0x62 (Size: 0x1, Type: EnumProperty)
    bool bSideloadedLipSync() const { return Read<bool>(uintptr_t(this) + 0x63); } // 0x63 (Size: 0x1, Type: BoolProperty)

    void SET_InSequence(const UAnimSequenceBase*& Value) { Write<UAnimSequenceBase*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_BeatAndTime(const FBeatAndTime& Value) { Write<FBeatAndTime>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_TempoMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_PreviewBPM(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_bAlwaysAllowPreviewBPM(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
    void SET_SyncAnimBeatTo(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x61, Value); } // 0x61 (Size: 0x1, Type: EnumProperty)
    void SET_Logging(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x62, Value); } // 0x62 (Size: 0x1, Type: EnumProperty)
    void SET_bSideloadedLipSync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x63, Value); } // 0x63 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FBeatAndTime
{
public:
    uint8_t GotBeatTimeFrom() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float Beat() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float time() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float BeatsPerSecond() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_GotBeatTimeFrom(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Beat(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_time(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_BeatsPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

