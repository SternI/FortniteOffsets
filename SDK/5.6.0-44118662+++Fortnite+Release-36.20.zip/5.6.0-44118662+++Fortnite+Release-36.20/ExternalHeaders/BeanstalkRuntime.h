/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "EnhancedInput.h"
#include "MotionWarping.h"
#include "Niagara.h"

// Size: 0x80
class UBeanAudioDataAsset : public UDataAsset
{
public:
    TMap<FBeanAudioKey, FBeanAudioSet> SoundListsByCategory() const { return Read<TMap<FBeanAudioKey, FBeanAudioSet>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_SoundListsByCategory(const TMap<FBeanAudioKey, FBeanAudioSet>& Value) { Write<TMap<FBeanAudioKey, FBeanAudioSet>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0xd0
class UBeanCameraModeOverrideComponent : public UFortCameraModeOverrideComponent
{
public:
    UClass* BeanCurrentCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> CharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_BeanCurrentCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_CharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2080
class UBeanCameraMode_ThirdPerson : public UFortCameraMode_ThirdPerson
{
public:
    bool bEnableDraggedBehaviour() const { return Read<bool>(uintptr_t(this) + 0x2018); } // 0x2018 (Size: 0x1, Type: BoolProperty)
    double ControllerYawToleranceForDragEnable() const { return Read<double>(uintptr_t(this) + 0x2020); } // 0x2020 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer DisableDraggedCameraTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2028); } // 0x2028 (Size: 0x20, Type: StructProperty)
    double ResetCameraPitch() const { return Read<double>(uintptr_t(this) + 0x2048); } // 0x2048 (Size: 0x8, Type: DoubleProperty)

    void SET_bEnableDraggedBehaviour(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2018, Value); } // 0x2018 (Size: 0x1, Type: BoolProperty)
    void SET_ControllerYawToleranceForDragEnable(const double& Value) { Write<double>(uintptr_t(this) + 0x2020, Value); } // 0x2020 (Size: 0x8, Type: DoubleProperty)
    void SET_DisableDraggedCameraTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2028, Value); } // 0x2028 (Size: 0x20, Type: StructProperty)
    void SET_ResetCameraPitch(const double& Value) { Write<double>(uintptr_t(this) + 0x2048, Value); } // 0x2048 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x6550
class ABeanCharacter : public AFortStandInPlayerPawn
{
public:
    UFortAbilitySet* AbilitySet() const { return Read<UFortAbilitySet*>(uintptr_t(this) + 0x61f0); } // 0x61f0 (Size: 0x8, Type: ObjectProperty)
    UBeanCharAnimInstance* AnimInstance() const { return Read<UBeanCharAnimInstance*>(uintptr_t(this) + 0x61f8); } // 0x61f8 (Size: 0x8, Type: ObjectProperty)
    UMotionWarpingComponent* MotionWarpingComponent() const { return Read<UMotionWarpingComponent*>(uintptr_t(this) + 0x6200); } // 0x6200 (Size: 0x8, Type: ObjectProperty)
    UClass* ConfigurationClass() const { return Read<UClass*>(uintptr_t(this) + 0x6208); } // 0x6208 (Size: 0x8, Type: ClassProperty)
    UInputMappingContext* DefaultMappingContext() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x6210); } // 0x6210 (Size: 0x8, Type: ObjectProperty)
    UInputAction* DiveAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x6218); } // 0x6218 (Size: 0x8, Type: ObjectProperty)
    UInputAction* GrabAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x6220); } // 0x6220 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag JumpButtonDiveIconOverrideTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6228); } // 0x6228 (Size: 0x4, Type: StructProperty)
    UBeanCharMovementComponent* MovementComponent() const { return Read<UBeanCharMovementComponent*>(uintptr_t(this) + 0x6258); } // 0x6258 (Size: 0x8, Type: ObjectProperty)
    UBeanJiggleMotionComponent* JiggleComponent() const { return Read<UBeanJiggleMotionComponent*>(uintptr_t(this) + 0x6260); } // 0x6260 (Size: 0x8, Type: ObjectProperty)
    UBeanCharStateMachine* StateMachine() const { return Read<UBeanCharStateMachine*>(uintptr_t(this) + 0x6280); } // 0x6280 (Size: 0x8, Type: ObjectProperty)
    UBeanStreamingManager* BeanStreamManager() const { return Read<UBeanStreamingManager*>(uintptr_t(this) + 0x6288); } // 0x6288 (Size: 0x8, Type: ObjectProperty)
    bool bPressedDive() const { return (Read<uint8_t>(uintptr_t(this) + 0x6290) >> 0x0) & 1; } // 0x6290:0 (Size: 0x1, Type: BoolProperty)
    UBeanCameraModeOverrideComponent* BeanCameraModeOverrideComponent() const { return Read<UBeanCameraModeOverrideComponent*>(uintptr_t(this) + 0x62c0); } // 0x62c0 (Size: 0x8, Type: ObjectProperty)
    UBeanParticleSystemsComponent* ParticleSystemsComponent() const { return Read<UBeanParticleSystemsComponent*>(uintptr_t(this) + 0x62c8); } // 0x62c8 (Size: 0x8, Type: ObjectProperty)
    UBeanCharGrabComponent* GrabComponent() const { return Read<UBeanCharGrabComponent*>(uintptr_t(this) + 0x62d0); } // 0x62d0 (Size: 0x8, Type: ObjectProperty)
    UBeanCharBeingGrabbedComponent* BeingGrabbedComponent() const { return Read<UBeanCharBeingGrabbedComponent*>(uintptr_t(this) + 0x62d8); } // 0x62d8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GrabFeatureEnabledTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x62e0); } // 0x62e0 (Size: 0x4, Type: StructProperty)
    bool bPressingGrab() const { return (Read<uint8_t>(uintptr_t(this) + 0x62e4) >> 0x0) & 1; } // 0x62e4:0 (Size: 0x1, Type: BoolProperty)
    UBeanCharMantleComponent* MantleComponent() const { return Read<UBeanCharMantleComponent*>(uintptr_t(this) + 0x62e8); } // 0x62e8 (Size: 0x8, Type: ObjectProperty)
    bool bWantsToMantle() const { return (Read<uint8_t>(uintptr_t(this) + 0x62f0) >> 0x0) & 1; } // 0x62f0:0 (Size: 0x1, Type: BoolProperty)
    UBeanCharRagdollComponent* RagdollComponent() const { return Read<UBeanCharRagdollComponent*>(uintptr_t(this) + 0x6300); } // 0x6300 (Size: 0x8, Type: ObjectProperty)
    UPhysicsConstraintComponent* RagdollPhysicsConstraint() const { return Read<UPhysicsConstraintComponent*>(uintptr_t(this) + 0x6308); } // 0x6308 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* RagdollRootCapsule() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0x6310); } // 0x6310 (Size: 0x8, Type: ObjectProperty)
    float CapsuleUnscaledHalfHeight() const { return Read<float>(uintptr_t(this) + 0x6318); } // 0x6318 (Size: 0x4, Type: FloatProperty)
    UNetworkPhysicsSettingsComponent* NetworkPhysicsSettingsComponent() const { return Read<UNetworkPhysicsSettingsComponent*>(uintptr_t(this) + 0x6320); } // 0x6320 (Size: 0x8, Type: ObjectProperty)
    UBeanCharCollisionManagerComponent* CollisionManagerComponent() const { return Read<UBeanCharCollisionManagerComponent*>(uintptr_t(this) + 0x6328); } // 0x6328 (Size: 0x8, Type: ObjectProperty)
    UInteractSelection_Base* PushedInteractionSelection() const { return Read<UInteractSelection_Base*>(uintptr_t(this) + 0x6340); } // 0x6340 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UAnimMontage> MantleAnimationMontage() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6378); } // 0x6378 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage> GetupAnimationMontage_Front() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6398); } // 0x6398 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage> GetupAnimationMontage_Left() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x63b8); } // 0x63b8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage> GetupAnimationMontage_Right() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x63d8); } // 0x63d8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage> GetupAnimationMontage_Back() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x63f8); } // 0x63f8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage> LandStaggerAnimationMontage() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6418); } // 0x6418 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage> LandStaggerAnimationMontageAlt() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6438); } // 0x6438 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UBeanCosmeticBackpackAllowList> BackpackAllowList() const { return Read<TSoftObjectPtr<UBeanCosmeticBackpackAllowList>>(uintptr_t(this) + 0x6458); } // 0x6458 (Size: 0x20, Type: SoftObjectProperty)
    bool bCharacterCosmeticsVisibility() const { return Read<bool>(uintptr_t(this) + 0x6478); } // 0x6478 (Size: 0x1, Type: BoolProperty)
    bool bBackpackCosmeticsVisibility() const { return Read<bool>(uintptr_t(this) + 0x6479); } // 0x6479 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer IdleBreakBlockingTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6480); } // 0x6480 (Size: 0x20, Type: StructProperty)
    bool bEnableInventoryMode() const { return Read<bool>(uintptr_t(this) + 0x64a0); } // 0x64a0 (Size: 0x1, Type: BoolProperty)
    USkeletalMeshComponent* RetargetSourceMesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x64a8); } // 0x64a8 (Size: 0x8, Type: ObjectProperty)

    void SET_AbilitySet(const UFortAbilitySet*& Value) { Write<UFortAbilitySet*>(uintptr_t(this) + 0x61f0, Value); } // 0x61f0 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimInstance(const UBeanCharAnimInstance*& Value) { Write<UBeanCharAnimInstance*>(uintptr_t(this) + 0x61f8, Value); } // 0x61f8 (Size: 0x8, Type: ObjectProperty)
    void SET_MotionWarpingComponent(const UMotionWarpingComponent*& Value) { Write<UMotionWarpingComponent*>(uintptr_t(this) + 0x6200, Value); } // 0x6200 (Size: 0x8, Type: ObjectProperty)
    void SET_ConfigurationClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x6208, Value); } // 0x6208 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultMappingContext(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x6210, Value); } // 0x6210 (Size: 0x8, Type: ObjectProperty)
    void SET_DiveAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x6218, Value); } // 0x6218 (Size: 0x8, Type: ObjectProperty)
    void SET_GrabAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x6220, Value); } // 0x6220 (Size: 0x8, Type: ObjectProperty)
    void SET_JumpButtonDiveIconOverrideTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6228, Value); } // 0x6228 (Size: 0x4, Type: StructProperty)
    void SET_MovementComponent(const UBeanCharMovementComponent*& Value) { Write<UBeanCharMovementComponent*>(uintptr_t(this) + 0x6258, Value); } // 0x6258 (Size: 0x8, Type: ObjectProperty)
    void SET_JiggleComponent(const UBeanJiggleMotionComponent*& Value) { Write<UBeanJiggleMotionComponent*>(uintptr_t(this) + 0x6260, Value); } // 0x6260 (Size: 0x8, Type: ObjectProperty)
    void SET_StateMachine(const UBeanCharStateMachine*& Value) { Write<UBeanCharStateMachine*>(uintptr_t(this) + 0x6280, Value); } // 0x6280 (Size: 0x8, Type: ObjectProperty)
    void SET_BeanStreamManager(const UBeanStreamingManager*& Value) { Write<UBeanStreamingManager*>(uintptr_t(this) + 0x6288, Value); } // 0x6288 (Size: 0x8, Type: ObjectProperty)
    void SET_bPressedDive(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x6290); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x6290, B); } // 0x6290:0 (Size: 0x1, Type: BoolProperty)
    void SET_BeanCameraModeOverrideComponent(const UBeanCameraModeOverrideComponent*& Value) { Write<UBeanCameraModeOverrideComponent*>(uintptr_t(this) + 0x62c0, Value); } // 0x62c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ParticleSystemsComponent(const UBeanParticleSystemsComponent*& Value) { Write<UBeanParticleSystemsComponent*>(uintptr_t(this) + 0x62c8, Value); } // 0x62c8 (Size: 0x8, Type: ObjectProperty)
    void SET_GrabComponent(const UBeanCharGrabComponent*& Value) { Write<UBeanCharGrabComponent*>(uintptr_t(this) + 0x62d0, Value); } // 0x62d0 (Size: 0x8, Type: ObjectProperty)
    void SET_BeingGrabbedComponent(const UBeanCharBeingGrabbedComponent*& Value) { Write<UBeanCharBeingGrabbedComponent*>(uintptr_t(this) + 0x62d8, Value); } // 0x62d8 (Size: 0x8, Type: ObjectProperty)
    void SET_GrabFeatureEnabledTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x62e0, Value); } // 0x62e0 (Size: 0x4, Type: StructProperty)
    void SET_bPressingGrab(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x62e4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x62e4, B); } // 0x62e4:0 (Size: 0x1, Type: BoolProperty)
    void SET_MantleComponent(const UBeanCharMantleComponent*& Value) { Write<UBeanCharMantleComponent*>(uintptr_t(this) + 0x62e8, Value); } // 0x62e8 (Size: 0x8, Type: ObjectProperty)
    void SET_bWantsToMantle(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x62f0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x62f0, B); } // 0x62f0:0 (Size: 0x1, Type: BoolProperty)
    void SET_RagdollComponent(const UBeanCharRagdollComponent*& Value) { Write<UBeanCharRagdollComponent*>(uintptr_t(this) + 0x6300, Value); } // 0x6300 (Size: 0x8, Type: ObjectProperty)
    void SET_RagdollPhysicsConstraint(const UPhysicsConstraintComponent*& Value) { Write<UPhysicsConstraintComponent*>(uintptr_t(this) + 0x6308, Value); } // 0x6308 (Size: 0x8, Type: ObjectProperty)
    void SET_RagdollRootCapsule(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0x6310, Value); } // 0x6310 (Size: 0x8, Type: ObjectProperty)
    void SET_CapsuleUnscaledHalfHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x6318, Value); } // 0x6318 (Size: 0x4, Type: FloatProperty)
    void SET_NetworkPhysicsSettingsComponent(const UNetworkPhysicsSettingsComponent*& Value) { Write<UNetworkPhysicsSettingsComponent*>(uintptr_t(this) + 0x6320, Value); } // 0x6320 (Size: 0x8, Type: ObjectProperty)
    void SET_CollisionManagerComponent(const UBeanCharCollisionManagerComponent*& Value) { Write<UBeanCharCollisionManagerComponent*>(uintptr_t(this) + 0x6328, Value); } // 0x6328 (Size: 0x8, Type: ObjectProperty)
    void SET_PushedInteractionSelection(const UInteractSelection_Base*& Value) { Write<UInteractSelection_Base*>(uintptr_t(this) + 0x6340, Value); } // 0x6340 (Size: 0x8, Type: ObjectProperty)
    void SET_MantleAnimationMontage(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6378, Value); } // 0x6378 (Size: 0x20, Type: SoftObjectProperty)
    void SET_GetupAnimationMontage_Front(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6398, Value); } // 0x6398 (Size: 0x20, Type: SoftObjectProperty)
    void SET_GetupAnimationMontage_Left(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x63b8, Value); } // 0x63b8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_GetupAnimationMontage_Right(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x63d8, Value); } // 0x63d8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_GetupAnimationMontage_Back(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x63f8, Value); } // 0x63f8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LandStaggerAnimationMontage(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6418, Value); } // 0x6418 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LandStaggerAnimationMontageAlt(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x6438, Value); } // 0x6438 (Size: 0x20, Type: SoftObjectProperty)
    void SET_BackpackAllowList(const TSoftObjectPtr<UBeanCosmeticBackpackAllowList>& Value) { Write<TSoftObjectPtr<UBeanCosmeticBackpackAllowList>>(uintptr_t(this) + 0x6458, Value); } // 0x6458 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bCharacterCosmeticsVisibility(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6478, Value); } // 0x6478 (Size: 0x1, Type: BoolProperty)
    void SET_bBackpackCosmeticsVisibility(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6479, Value); } // 0x6479 (Size: 0x1, Type: BoolProperty)
    void SET_IdleBreakBlockingTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6480, Value); } // 0x6480 (Size: 0x20, Type: StructProperty)
    void SET_bEnableInventoryMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x64a0, Value); } // 0x64a0 (Size: 0x1, Type: BoolProperty)
    void SET_RetargetSourceMesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x64a8, Value); } // 0x64a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x750
class UBeanCharAnimInstance : public UFortAnimInstance
{
public:
    bool bIsSimulatedProxy() const { return Read<bool>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x1, Type: BoolProperty)
    uint8_t UpperStateID() const { return Read<uint8_t>(uintptr_t(this) + 0x5c9); } // 0x5c9 (Size: 0x1, Type: EnumProperty)
    uint8_t LowerStateID() const { return Read<uint8_t>(uintptr_t(this) + 0x5ca); } // 0x5ca (Size: 0x1, Type: EnumProperty)
    uint8_t PrevLowerStateID() const { return Read<uint8_t>(uintptr_t(this) + 0x5cb); } // 0x5cb (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EMovementMode> MovementMode() const { return Read<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x5cc); } // 0x5cc (Size: 0x1, Type: ByteProperty)
    bool bIsMoving() const { return Read<bool>(uintptr_t(this) + 0x5cd); } // 0x5cd (Size: 0x1, Type: BoolProperty)
    bool bIsGrounded() const { return Read<bool>(uintptr_t(this) + 0x5ce); } // 0x5ce (Size: 0x1, Type: BoolProperty)
    float TurningPercentage() const { return Read<float>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x4, Type: FloatProperty)
    float SpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x5d4); } // 0x5d4 (Size: 0x4, Type: FloatProperty)
    FVector CurrentVelocity() const { return Read<FVector>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x18, Type: StructProperty)
    bool bIsAnticipatingJumpLanding() const { return Read<bool>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x1, Type: BoolProperty)
    FVector LastRagdollImpactForce() const { return Read<FVector>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x18, Type: StructProperty)
    FVector LastImpactForce() const { return Read<FVector>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x18, Type: StructProperty)
    FVector LastImpactRelativeDirection() const { return Read<FVector>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x18, Type: StructProperty)
    uint8_t TurnState() const { return Read<uint8_t>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x1, Type: EnumProperty)
    bool bIsGrabbing() const { return Read<bool>(uintptr_t(this) + 0x641); } // 0x641 (Size: 0x1, Type: BoolProperty)
    bool bHasGrabTarget() const { return Read<bool>(uintptr_t(this) + 0x642); } // 0x642 (Size: 0x1, Type: BoolProperty)
    float GrabStumbleDuration() const { return Read<float>(uintptr_t(this) + 0x644); } // 0x644 (Size: 0x4, Type: FloatProperty)
    FVector LeftHandIKPosition() const { return Read<FVector>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x18, Type: StructProperty)
    FVector RightHandIKPosition() const { return Read<FVector>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x18, Type: StructProperty)
    FRotator LeftHandIKRotation() const { return Read<FRotator>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x18, Type: StructProperty)
    FRotator RightHandIKRotation() const { return Read<FRotator>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x18, Type: StructProperty)
    float IKAlpha() const { return Read<float>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x4, Type: FloatProperty)
    bool bUseImpactAnims() const { return Read<bool>(uintptr_t(this) + 0x6ac); } // 0x6ac (Size: 0x1, Type: BoolProperty)
    bool bImpactTriggered() const { return Read<bool>(uintptr_t(this) + 0x6ad); } // 0x6ad (Size: 0x1, Type: BoolProperty)
    uint8_t ImpactAnimType() const { return Read<uint8_t>(uintptr_t(this) + 0x6ae); } // 0x6ae (Size: 0x1, Type: EnumProperty)
    float LowImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x4, Type: FloatProperty)
    float MediumImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x6b4); } // 0x6b4 (Size: 0x4, Type: FloatProperty)
    float HighImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x4, Type: FloatProperty)
    FRotator JiggleRotator0() const { return Read<FRotator>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator1() const { return Read<FRotator>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator2() const { return Read<FRotator>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x18, Type: StructProperty)
    bool bLowerStateUsesLocomotionAnim() const { return Read<bool>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EFortWeaponCoreAnimation> WeaponCoreAnim() const { return Read<TEnumAsByte<EFortWeaponCoreAnimation>>(uintptr_t(this) + 0x709); } // 0x709 (Size: 0x1, Type: ByteProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x70c); } // 0x70c (Size: 0x8, Type: WeakObjectProperty)

    void SET_bIsSimulatedProxy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x1, Type: BoolProperty)
    void SET_UpperStateID(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5c9, Value); } // 0x5c9 (Size: 0x1, Type: EnumProperty)
    void SET_LowerStateID(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5ca, Value); } // 0x5ca (Size: 0x1, Type: EnumProperty)
    void SET_PrevLowerStateID(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5cb, Value); } // 0x5cb (Size: 0x1, Type: EnumProperty)
    void SET_MovementMode(const TEnumAsByte<EMovementMode>& Value) { Write<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x5cc, Value); } // 0x5cc (Size: 0x1, Type: ByteProperty)
    void SET_bIsMoving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5cd, Value); } // 0x5cd (Size: 0x1, Type: BoolProperty)
    void SET_bIsGrounded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5ce, Value); } // 0x5ce (Size: 0x1, Type: BoolProperty)
    void SET_TurningPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x5d4, Value); } // 0x5d4 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x18, Type: StructProperty)
    void SET_bIsAnticipatingJumpLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x1, Type: BoolProperty)
    void SET_LastRagdollImpactForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x18, Type: StructProperty)
    void SET_LastImpactForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x18, Type: StructProperty)
    void SET_LastImpactRelativeDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x18, Type: StructProperty)
    void SET_TurnState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x1, Type: EnumProperty)
    void SET_bIsGrabbing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x641, Value); } // 0x641 (Size: 0x1, Type: BoolProperty)
    void SET_bHasGrabTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x642, Value); } // 0x642 (Size: 0x1, Type: BoolProperty)
    void SET_GrabStumbleDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x644, Value); } // 0x644 (Size: 0x4, Type: FloatProperty)
    void SET_LeftHandIKPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x18, Type: StructProperty)
    void SET_RightHandIKPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x18, Type: StructProperty)
    void SET_LeftHandIKRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x18, Type: StructProperty)
    void SET_RightHandIKRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x18, Type: StructProperty)
    void SET_IKAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x4, Type: FloatProperty)
    void SET_bUseImpactAnims(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6ac, Value); } // 0x6ac (Size: 0x1, Type: BoolProperty)
    void SET_bImpactTriggered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6ad, Value); } // 0x6ad (Size: 0x1, Type: BoolProperty)
    void SET_ImpactAnimType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6ae, Value); } // 0x6ae (Size: 0x1, Type: EnumProperty)
    void SET_LowImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x4, Type: FloatProperty)
    void SET_MediumImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x6b4, Value); } // 0x6b4 (Size: 0x4, Type: FloatProperty)
    void SET_HighImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x4, Type: FloatProperty)
    void SET_JiggleRotator0(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator1(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator2(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x18, Type: StructProperty)
    void SET_bLowerStateUsesLocomotionAnim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x1, Type: BoolProperty)
    void SET_WeaponCoreAnim(const TEnumAsByte<EFortWeaponCoreAnimation>& Value) { Write<TEnumAsByte<EFortWeaponCoreAnimation>>(uintptr_t(this) + 0x709, Value); } // 0x709 (Size: 0x1, Type: ByteProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x70c, Value); } // 0x70c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x110
class UBeanCharBeingGrabbedComponent : public UActorComponent
{
public:
};

// Size: 0x128
class UBeanCharCollisionManagerComponent : public UActorComponent
{
public:
    double MaxConfigImpactThreshold() const { return Read<double>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: DoubleProperty)
    double NextImpactCueExecution() const { return Read<double>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: DoubleProperty)
    float RagdollThresholdMultiplier() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)

    void SET_MaxConfigImpactThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: DoubleProperty)
    void SET_NextImpactCueExecution(const double& Value) { Write<double>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: DoubleProperty)
    void SET_RagdollThresholdMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1d0
class UBeanCharGrabComponent : public UActorComponent
{
public:
    UAnimMontage* ArmsOutMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FVector LeftHandIKPosition() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector RightHandIKPosition() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    FRotator LeftHandIKRotation() const { return Read<FRotator>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FRotator RightHandIKRotation() const { return Read<FRotator>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    float IKAlpha() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    bool bHasIKTarget() const { return Read<bool>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: BoolProperty)
    bool bIsGrabStumbling() const { return Read<bool>(uintptr_t(this) + 0x125); } // 0x125 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> GrabTarget() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    float ServerLatestHoldStartTime() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)

    void SET_ArmsOutMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftHandIKPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_RightHandIKPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_LeftHandIKRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_RightHandIKRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_IKAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_bHasIKTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: BoolProperty)
    void SET_bIsGrabStumbling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x125, Value); } // 0x125 (Size: 0x1, Type: BoolProperty)
    void SET_GrabTarget(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ServerLatestHoldStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x100
class UBeanCharMantleComponent : public UActorComponent
{
public:
    FScalableFloat ClamberingEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ABeanCharacter*> BeanCharacter() const { return Read<TWeakObjectPtr<ABeanCharacter*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    float CachedClamberingEnabledValue() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    double LastClamberingEnabledCacheTime() const { return Read<double>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    double ClamberingEnableCacheInterval() const { return Read<double>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: DoubleProperty)

    void SET_ClamberingEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_BeanCharacter(const TWeakObjectPtr<ABeanCharacter*>& Value) { Write<TWeakObjectPtr<ABeanCharacter*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedClamberingEnabledValue(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_LastClamberingEnabledCacheTime(const double& Value) { Write<double>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    void SET_ClamberingEnableCacheInterval(const double& Value) { Write<double>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x6990
class UBeanCharMovementComponent : public UFortMovementComp_CharacterAthena
{
public:
    float MovementBaseVelocitySamplingPeriod() const { return Read<float>(uintptr_t(this) + 0x6864); } // 0x6864 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UPrimitiveComponent*> CurrentSampledMovementBase() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x6868); } // 0x6868 (Size: 0x8, Type: WeakObjectProperty)
    bool bAllowFloorHeightAdjustments() const { return Read<bool>(uintptr_t(this) + 0x6971); } // 0x6971 (Size: 0x1, Type: BoolProperty)
    uint8_t TurnState() const { return Read<uint8_t>(uintptr_t(this) + 0x6972); } // 0x6972 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> CharConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x6980); } // 0x6980 (Size: 0x8, Type: WeakObjectProperty)

    void SET_MovementBaseVelocitySamplingPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x6864, Value); } // 0x6864 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentSampledMovementBase(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x6868, Value); } // 0x6868 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bAllowFloorHeightAdjustments(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6971, Value); } // 0x6971 (Size: 0x1, Type: BoolProperty)
    void SET_TurnState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6972, Value); } // 0x6972 (Size: 0x1, Type: EnumProperty)
    void SET_CharConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x6980, Value); } // 0x6980 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x470
class UBeanCharRagdollComponent : public UActorComponent
{
public:
    FComponentReference PhysicsConstraintComponentReference() const { return Read<FComponentReference>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    FComponentReference RootPrimitiveReference() const { return Read<FComponentReference>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x28, Type: StructProperty)
    FComponentReference SkeletalMeshReference() const { return Read<FComponentReference>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x28, Type: StructProperty)
    bool bEnableInputControlCurve() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve RagdollInputControlWithTimeCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x88, Type: StructProperty)
    bool bIsConfiguredCorrectly() const { return Read<bool>(uintptr_t(this) + 0x1c1); } // 0x1c1 (Size: 0x1, Type: BoolProperty)
    bool bHasRequestedRagdollExit() const { return Read<bool>(uintptr_t(this) + 0x1c2); } // 0x1c2 (Size: 0x1, Type: BoolProperty)
    FTransform StartingMeshTransform() const { return Read<FTransform>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x60, Type: StructProperty)
    FCollisionResponseContainer OriginalActorRootCollisionResponse() const { return Read<FCollisionResponseContainer>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x20, Type: StructProperty)
    FVector RagdollControlInputVector() const { return Read<FVector>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x18, Type: StructProperty)
    bool bIsRagdollGrounded() const { return Read<bool>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    float TimeOnGround() const { return Read<float>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    FVector LatestRagdollFloorOffset() const { return Read<FVector>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x18, Type: StructProperty)
    FVector LatestRagdollFloorNormal() const { return Read<FVector>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x18, Type: StructProperty)
    FBeanCharRagdollImpactData CurrentImpactData() const { return Read<FBeanCharRagdollImpactData>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x40, Type: StructProperty)
    float CurrentGravityZOverride() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    FVector CurrentAdditionalGravity() const { return Read<FVector>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x18, Type: StructProperty)
    TArray<int32_t> CachedMeshBodyIndexesForCCD() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    double LowerLinearDistanceTarget() const { return Read<double>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: DoubleProperty)
    double UpperLinearDistanceTarget() const { return Read<double>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    float DefaultHardSnapLinearDistance() const { return Read<float>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x4, Type: FloatProperty)
    double MaxHardsnapLinearDistance() const { return Read<double>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: DoubleProperty)
    bool bHasAddedIgnoredObjects() const { return Read<bool>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x1, Type: BoolProperty)
    FBeanRagdollDebugComponentHistory RagdollComponentHistory() const { return Read<FBeanRagdollDebugComponentHistory>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x20, Type: StructProperty)

    void SET_PhysicsConstraintComponentReference(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_RootPrimitiveReference(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x28, Type: StructProperty)
    void SET_SkeletalMeshReference(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x28, Type: StructProperty)
    void SET_bEnableInputControlCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
    void SET_RagdollInputControlWithTimeCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x88, Type: StructProperty)
    void SET_bIsConfiguredCorrectly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c1, Value); } // 0x1c1 (Size: 0x1, Type: BoolProperty)
    void SET_bHasRequestedRagdollExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c2, Value); } // 0x1c2 (Size: 0x1, Type: BoolProperty)
    void SET_StartingMeshTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x60, Type: StructProperty)
    void SET_OriginalActorRootCollisionResponse(const FCollisionResponseContainer& Value) { Write<FCollisionResponseContainer>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x20, Type: StructProperty)
    void SET_RagdollControlInputVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x18, Type: StructProperty)
    void SET_bIsRagdollGrounded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    void SET_TimeOnGround(const float& Value) { Write<float>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    void SET_LatestRagdollFloorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x18, Type: StructProperty)
    void SET_LatestRagdollFloorNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x18, Type: StructProperty)
    void SET_CurrentImpactData(const FBeanCharRagdollImpactData& Value) { Write<FBeanCharRagdollImpactData>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x40, Type: StructProperty)
    void SET_CurrentGravityZOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentAdditionalGravity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x18, Type: StructProperty)
    void SET_CachedMeshBodyIndexesForCCD(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    void SET_LowerLinearDistanceTarget(const double& Value) { Write<double>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: DoubleProperty)
    void SET_UpperLinearDistanceTarget(const double& Value) { Write<double>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    void SET_DefaultHardSnapLinearDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x4, Type: FloatProperty)
    void SET_MaxHardsnapLinearDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: DoubleProperty)
    void SET_bHasAddedIgnoredObjects(const bool& Value) { Write<bool>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x1, Type: BoolProperty)
    void SET_RagdollComponentHistory(const FBeanRagdollDebugComponentHistory& Value) { Write<FBeanRagdollDebugComponentHistory>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x20, Type: StructProperty)
};

// Size: 0x198
class UBeanCharStateBase : public UObject
{
public:
    uint8_t StateId() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t LayerMask() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EMovementMode> MovementMode() const { return Read<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFortCustomMovement> FortCustomMovementMode() const { return Read<TEnumAsByte<EFortCustomMovement>>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: ByteProperty)
    FGameplayTag GameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)
    FGameplayCueTag GameplayCue() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    FGameplayCueParameters GameplayCueParameters() const { return Read<FGameplayCueParameters>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0xd0, Type: StructProperty)
    bool bShouldSetMovementMode() const { return Read<bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: BoolProperty)
    bool bReplicateToSimulatedProxies() const { return Read<bool>(uintptr_t(this) + 0x109); } // 0x109 (Size: 0x1, Type: BoolProperty)
    bool bExecuteCodeOnSimulatedProxies() const { return Read<bool>(uintptr_t(this) + 0x10a); } // 0x10a (Size: 0x1, Type: BoolProperty)
    bool bTryActivateFailsIfAlreadyActive() const { return Read<bool>(uintptr_t(this) + 0x10b); } // 0x10b (Size: 0x1, Type: BoolProperty)
    bool bServerMustFlushStateManually() const { return Read<bool>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x1, Type: BoolProperty)
    bool bFlushPendingStateChangesOnStateExit() const { return Read<bool>(uintptr_t(this) + 0x10d); } // 0x10d (Size: 0x1, Type: BoolProperty)
    float Priority() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    bool bShouldRemainVertical() const { return Read<bool>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x1, Type: BoolProperty)
    bool bCanPerformMantle() const { return Read<bool>(uintptr_t(this) + 0x115); } // 0x115 (Size: 0x1, Type: BoolProperty)
    float DecelerationOverride() const { return Read<float>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: FloatProperty)
    bool bPauseJiggleCalculations() const { return Read<bool>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x1, Type: BoolProperty)
    UBeanCharStateMachine* OwnerStateMachine() const { return Read<UBeanCharStateMachine*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<uint16_t> RootMotionSourceIDs() const { return Read<TArray<uint16_t>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer GrantedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedAbilityTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x20, Type: StructProperty)

    void SET_StateId(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_LayerMask(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_MovementMode(const TEnumAsByte<EMovementMode>& Value) { Write<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: ByteProperty)
    void SET_FortCustomMovementMode(const TEnumAsByte<EFortCustomMovement>& Value) { Write<TEnumAsByte<EFortCustomMovement>>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: ByteProperty)
    void SET_GameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
    void SET_GameplayCue(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_GameplayCueParameters(const FGameplayCueParameters& Value) { Write<FGameplayCueParameters>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0xd0, Type: StructProperty)
    void SET_bShouldSetMovementMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: BoolProperty)
    void SET_bReplicateToSimulatedProxies(const bool& Value) { Write<bool>(uintptr_t(this) + 0x109, Value); } // 0x109 (Size: 0x1, Type: BoolProperty)
    void SET_bExecuteCodeOnSimulatedProxies(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10a, Value); } // 0x10a (Size: 0x1, Type: BoolProperty)
    void SET_bTryActivateFailsIfAlreadyActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10b, Value); } // 0x10b (Size: 0x1, Type: BoolProperty)
    void SET_bServerMustFlushStateManually(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x1, Type: BoolProperty)
    void SET_bFlushPendingStateChangesOnStateExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10d, Value); } // 0x10d (Size: 0x1, Type: BoolProperty)
    void SET_Priority(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_bShouldRemainVertical(const bool& Value) { Write<bool>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x1, Type: BoolProperty)
    void SET_bCanPerformMantle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x115, Value); } // 0x115 (Size: 0x1, Type: BoolProperty)
    void SET_DecelerationOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: FloatProperty)
    void SET_bPauseJiggleCalculations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x1, Type: BoolProperty)
    void SET_OwnerStateMachine(const UBeanCharStateMachine*& Value) { Write<UBeanCharStateMachine*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_RootMotionSourceIDs(const TArray<uint16_t>& Value) { Write<TArray<uint16_t>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_GrantedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x20, Type: StructProperty)
    void SET_BlockedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x20, Type: StructProperty)
    void SET_BlockedAbilityTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x20, Type: StructProperty)
};

// Size: 0x218
class UBeanCharStateMachine : public UActorComponent
{
public:
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    FBeanCharStateMachineContext Layers() const { return Read<FBeanCharStateMachineContext>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x80, Type: StructProperty)
    TArray<UBeanCharStateBase*> TempTickStateList() const { return Read<TArray<UBeanCharStateBase*>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: ArrayProperty)
    TArray<UBeanCharStateBase*> States() const { return Read<TArray<UBeanCharStateBase*>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x10, Type: ArrayProperty)
    bool bFlushMoveToServerAtEndOfFrame() const { return Read<bool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: BoolProperty)
    bool bFlushPendingStateChangesAtEndOfFrame() const { return Read<bool>(uintptr_t(this) + 0x199); } // 0x199 (Size: 0x1, Type: BoolProperty)
    bool bIsReplaying() const { return Read<bool>(uintptr_t(this) + 0x19a); } // 0x19a (Size: 0x1, Type: BoolProperty)
    uint8_t ServerForceSetUpperState() const { return Read<uint8_t>(uintptr_t(this) + 0x19b); } // 0x19b (Size: 0x1, Type: EnumProperty)
    uint8_t ServerForceSetLowerState() const { return Read<uint8_t>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x1, Type: EnumProperty)
    uint16_t SimulatedProxyStateData() const { return Read<uint16_t>(uintptr_t(this) + 0x19e); } // 0x19e (Size: 0x2, Type: UInt16Property)
    uint32_t AutonomousProxyServerStateData() const { return Read<uint32_t>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: UInt32Property)
    char StateSyncID() const { return Read<char>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x1, Type: ByteProperty)
    char ServerStateSyncID() const { return Read<char>(uintptr_t(this) + 0x1a5); } // 0x1a5 (Size: 0x1, Type: ByteProperty)
    TArray<FBeanStateHistoryItem> AutonomousProxyStateHistory() const { return Read<TArray<FBeanStateHistoryItem>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    float AutonomousProxyServerStateCheckTimer() const { return Read<float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    float RequestClientStateChangeTimeout() const { return Read<float>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: FloatProperty)
    uint8_t RequestClientStateChangePendingStateID() const { return Read<uint8_t>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x1, Type: EnumProperty)
    TArray<FBeanStateGameplayTagsDefinition> StateTagsDefinitions() const { return Read<TArray<FBeanStateGameplayTagsDefinition>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    UClass* AnimLayer_Swimming() const { return Read<UClass*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Ragdoll() const { return Read<UClass*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Zipline() const { return Read<UClass*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Flying() const { return Read<UClass*>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Grab() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_EditMode() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)

    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_Layers(const FBeanCharStateMachineContext& Value) { Write<FBeanCharStateMachineContext>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x80, Type: StructProperty)
    void SET_TempTickStateList(const TArray<UBeanCharStateBase*>& Value) { Write<TArray<UBeanCharStateBase*>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: ArrayProperty)
    void SET_States(const TArray<UBeanCharStateBase*>& Value) { Write<TArray<UBeanCharStateBase*>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x10, Type: ArrayProperty)
    void SET_bFlushMoveToServerAtEndOfFrame(const bool& Value) { Write<bool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: BoolProperty)
    void SET_bFlushPendingStateChangesAtEndOfFrame(const bool& Value) { Write<bool>(uintptr_t(this) + 0x199, Value); } // 0x199 (Size: 0x1, Type: BoolProperty)
    void SET_bIsReplaying(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19a, Value); } // 0x19a (Size: 0x1, Type: BoolProperty)
    void SET_ServerForceSetUpperState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x19b, Value); } // 0x19b (Size: 0x1, Type: EnumProperty)
    void SET_ServerForceSetLowerState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x1, Type: EnumProperty)
    void SET_SimulatedProxyStateData(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x19e, Value); } // 0x19e (Size: 0x2, Type: UInt16Property)
    void SET_AutonomousProxyServerStateData(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: UInt32Property)
    void SET_StateSyncID(const char& Value) { Write<char>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x1, Type: ByteProperty)
    void SET_ServerStateSyncID(const char& Value) { Write<char>(uintptr_t(this) + 0x1a5, Value); } // 0x1a5 (Size: 0x1, Type: ByteProperty)
    void SET_AutonomousProxyStateHistory(const TArray<FBeanStateHistoryItem>& Value) { Write<TArray<FBeanStateHistoryItem>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_AutonomousProxyServerStateCheckTimer(const float& Value) { Write<float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    void SET_RequestClientStateChangeTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: FloatProperty)
    void SET_RequestClientStateChangePendingStateID(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x1, Type: EnumProperty)
    void SET_StateTagsDefinitions(const TArray<FBeanStateGameplayTagsDefinition>& Value) { Write<TArray<FBeanStateGameplayTagsDefinition>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    void SET_AnimLayer_Swimming(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ClassProperty)
    void SET_AnimLayer_Ragdoll(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
    void SET_AnimLayer_Zipline(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
    void SET_AnimLayer_Flying(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: ClassProperty)
    void SET_AnimLayer_Grab(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_AnimLayer_EditMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x1a0
class UBeanCharState_Dive : public UBeanCharStateBase
{
public:
};

// Size: 0x1a0
class UBeanCharState_Emote : public UBeanCharStateBase
{
public:
};

// Size: 0x1a0
class UBeanCharState_Falling : public UBeanCharStateBase
{
public:
};

// Size: 0x198
class UBeanCharState_Flying : public UBeanCharStateBase
{
public:
};

// Size: 0x230
class UBeanCharState_Getup : public UBeanCharStateBase
{
public:
    UAnimMontage* ActiveAnim() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)

    void SET_ActiveAnim(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1e0
class UBeanCharState_GetupRoll : public UBeanCharStateBase
{
public:
};

// Size: 0x198
class UBeanCharState_Grab : public UBeanCharStateBase
{
public:
};

// Size: 0x198
class UBeanCharState_GrabStumble : public UBeanCharStateBase
{
public:
};

// Size: 0x1b8
class UBeanCharState_Grounded : public UBeanCharStateBase
{
public:
};

// Size: 0x1f8
class UBeanCharState_Jostle : public UBeanCharStateBase
{
public:
    FVector SeparationForce() const { return Read<FVector>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x18, Type: StructProperty)

    void SET_SeparationForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1b0
class UBeanCharState_Jump : public UBeanCharStateBase
{
public:
};

// Size: 0x1e8
class UBeanCharState_Mantle : public UBeanCharStateBase
{
public:
};

// Size: 0x1c0
class UBeanCharState_Ragdoll : public UBeanCharStateBase
{
public:
};

// Size: 0x1a0
class UBeanCharState_Roll : public UBeanCharStateBase
{
public:
};

// Size: 0x1a8
class UBeanCharState_Staggered : public UBeanCharStateBase
{
public:
    UAnimMontage* CurrentMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x198
class UBeanCharState_SurfaceSwimming : public UBeanCharStateBase
{
public:
};

// Size: 0x1b0
class UBeanCharState_WaterJump : public UBeanCharState_Jump
{
public:
};

// Size: 0x198
class UBeanCharState_Zipline : public UBeanCharStateBase
{
public:
};

// Size: 0x3f0
class UBeanChar_EditMode_AnimLayer : public UAnimInstance
{
public:
    TEnumAsByte<EFortWeaponCoreAnimation> WeaponCoreAnim() const { return Read<TEnumAsByte<EFortWeaponCoreAnimation>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x1, Type: ByteProperty)
    bool bIsMoving() const { return Read<bool>(uintptr_t(this) + 0x3d9); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x8, Type: WeakObjectProperty)

    void SET_WeaponCoreAnim(const TEnumAsByte<EFortWeaponCoreAnimation>& Value) { Write<TEnumAsByte<EFortWeaponCoreAnimation>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x1, Type: ByteProperty)
    void SET_bIsMoving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d9, Value); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3e0
class UBeanChar_Flying_AnimLayer : public UAnimInstance
{
public:
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x450
class UBeanChar_Grab_AnimLayer : public UAnimInstance
{
public:
    bool bHasGrabTarget() const { return Read<bool>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    float GrabStumbleDuration() const { return Read<float>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    FVector LeftHandIKPosition() const { return Read<FVector>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x18, Type: StructProperty)
    FVector RightHandIKPosition() const { return Read<FVector>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x18, Type: StructProperty)
    FRotator LeftHandIKRotation() const { return Read<FRotator>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x18, Type: StructProperty)
    FRotator RightHandIKRotation() const { return Read<FRotator>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x18, Type: StructProperty)
    float IKAlpha() const { return Read<float>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x444); } // 0x444 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bHasGrabTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    void SET_GrabStumbleDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    void SET_LeftHandIKPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x18, Type: StructProperty)
    void SET_RightHandIKPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x18, Type: StructProperty)
    void SET_LeftHandIKRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x18, Type: StructProperty)
    void SET_RightHandIKRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x18, Type: StructProperty)
    void SET_IKAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x4, Type: FloatProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x444, Value); } // 0x444 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x430
class UBeanChar_GroundLoc_AnimInstance : public UAnimInstance
{
public:
    float TurningPercentage() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    float SpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    uint8_t TurnState() const { return Read<uint8_t>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TurningPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    void SET_TurnState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x1, Type: EnumProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x420
class UBeanChar_Idle_AnimInstance : public UAnimInstance
{
public:
    UAnimSequence* CurrentIdleBreakAnimation() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayingIdleBreak() const { return Read<bool>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x1, Type: BoolProperty)
    float CurrentIdleBreakTime() const { return Read<float>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    TArray<TSoftObjectPtr<UAnimSequence*>> IdleBreaks() const { return Read<TArray<TSoftObjectPtr<UAnimSequence*>>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    float IdleBreakMinTime() const { return Read<float>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x4, Type: FloatProperty)
    float IdleBreakMaxTime() const { return Read<float>(uintptr_t(this) + 0x404); } // 0x404 (Size: 0x4, Type: FloatProperty)
    float StopIdleBreakTrimTime() const { return Read<float>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x40c); } // 0x40c (Size: 0x8, Type: WeakObjectProperty)

    void SET_CurrentIdleBreakAnimation(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsPlayingIdleBreak(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentIdleBreakTime(const float& Value) { Write<float>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    void SET_IdleBreaks(const TArray<TSoftObjectPtr<UAnimSequence*>>& Value) { Write<TArray<TSoftObjectPtr<UAnimSequence*>>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    void SET_IdleBreakMinTime(const float& Value) { Write<float>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x4, Type: FloatProperty)
    void SET_IdleBreakMaxTime(const float& Value) { Write<float>(uintptr_t(this) + 0x404, Value); } // 0x404 (Size: 0x4, Type: FloatProperty)
    void SET_StopIdleBreakTrimTime(const float& Value) { Write<float>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x4, Type: FloatProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x40c, Value); } // 0x40c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3f0
class UBeanChar_InAirLoc_AnimInstance : public UAnimInstance
{
public:
    bool bIsJumping() const { return Read<bool>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    bool bIsFalling() const { return Read<bool>(uintptr_t(this) + 0x3d9); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    bool bIsAnticipatingJumpLanding() const { return Read<bool>(uintptr_t(this) + 0x3da); } // 0x3da (Size: 0x1, Type: BoolProperty)
    bool bIsDiving() const { return Read<bool>(uintptr_t(this) + 0x3db); } // 0x3db (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x8, Type: WeakObjectProperty)
    bool bWasJumping() const { return Read<bool>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x1, Type: BoolProperty)
    float JumpStartZ() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)

    void SET_bIsJumping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFalling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d9, Value); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsAnticipatingJumpLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3da, Value); } // 0x3da (Size: 0x1, Type: BoolProperty)
    void SET_bIsDiving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3db, Value); } // 0x3db (Size: 0x1, Type: BoolProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x8, Type: WeakObjectProperty)
    void SET_bWasJumping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x1, Type: BoolProperty)
    void SET_JumpStartZ(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x480
class UBeanChar_Jiggle_AnimInstance : public UAnimInstance
{
public:
    FVector LastImpactForce() const { return Read<FVector>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x18, Type: StructProperty)
    FVector LastImpactRelativeDirection() const { return Read<FVector>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x18, Type: StructProperty)
    bool bJustLandedFromJump() const { return Read<bool>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x1, Type: BoolProperty)
    bool bIsMoving() const { return Read<bool>(uintptr_t(this) + 0x409); } // 0x409 (Size: 0x1, Type: BoolProperty)
    bool bUseImpactAnims() const { return Read<bool>(uintptr_t(this) + 0x40a); } // 0x40a (Size: 0x1, Type: BoolProperty)
    bool bImpactTriggered() const { return Read<bool>(uintptr_t(this) + 0x40b); } // 0x40b (Size: 0x1, Type: BoolProperty)
    uint8_t ImpactAnimType() const { return Read<uint8_t>(uintptr_t(this) + 0x40c); } // 0x40c (Size: 0x1, Type: EnumProperty)
    float LowImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x4, Type: FloatProperty)
    float MediumImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x414); } // 0x414 (Size: 0x4, Type: FloatProperty)
    float HighImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x4, Type: FloatProperty)
    FRotator JiggleRotator0() const { return Read<FRotator>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator1() const { return Read<FRotator>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator2() const { return Read<FRotator>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: WeakObjectProperty)

    void SET_LastImpactForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x18, Type: StructProperty)
    void SET_LastImpactRelativeDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x18, Type: StructProperty)
    void SET_bJustLandedFromJump(const bool& Value) { Write<bool>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x1, Type: BoolProperty)
    void SET_bIsMoving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x409, Value); } // 0x409 (Size: 0x1, Type: BoolProperty)
    void SET_bUseImpactAnims(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40a, Value); } // 0x40a (Size: 0x1, Type: BoolProperty)
    void SET_bImpactTriggered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40b, Value); } // 0x40b (Size: 0x1, Type: BoolProperty)
    void SET_ImpactAnimType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40c, Value); } // 0x40c (Size: 0x1, Type: EnumProperty)
    void SET_LowImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x4, Type: FloatProperty)
    void SET_MediumImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x414, Value); } // 0x414 (Size: 0x4, Type: FloatProperty)
    void SET_HighImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x4, Type: FloatProperty)
    void SET_JiggleRotator0(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator1(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator2(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x18, Type: StructProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x640
class UBeanChar_Main_AnimInstance : public UFortAnimInstance
{
public:
    bool bIsSimulatedProxy() const { return Read<bool>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> MovementMode() const { return Read<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x5c9); } // 0x5c9 (Size: 0x1, Type: ByteProperty)
    bool bIsMoving() const { return Read<bool>(uintptr_t(this) + 0x5ca); } // 0x5ca (Size: 0x1, Type: BoolProperty)
    bool bIsGrounded() const { return Read<bool>(uintptr_t(this) + 0x5cb); } // 0x5cb (Size: 0x1, Type: BoolProperty)
    FVector CurrentVelocity() const { return Read<FVector>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator0() const { return Read<FRotator>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator1() const { return Read<FRotator>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator2() const { return Read<FRotator>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x18, Type: StructProperty)
    bool bLowerStateUsesLocomotionAnim() const { return Read<bool>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x634); } // 0x634 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bIsSimulatedProxy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x1, Type: BoolProperty)
    void SET_MovementMode(const TEnumAsByte<EMovementMode>& Value) { Write<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x5c9, Value); } // 0x5c9 (Size: 0x1, Type: ByteProperty)
    void SET_bIsMoving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5ca, Value); } // 0x5ca (Size: 0x1, Type: BoolProperty)
    void SET_bIsGrounded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5cb, Value); } // 0x5cb (Size: 0x1, Type: BoolProperty)
    void SET_CurrentVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator0(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator1(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x18, Type: StructProperty)
    void SET_JiggleRotator2(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x18, Type: StructProperty)
    void SET_bLowerStateUsesLocomotionAnim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x1, Type: BoolProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x634, Value); } // 0x634 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x420
class UBeanChar_Ragdoll_AnimLayer : public UAnimInstance
{
public:
    float HighImpactUpperThresholdReciprocal() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    FVector LastRagdollImpactForce() const { return Read<FVector>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x18, Type: StructProperty)
    FVector LastImpactRelativeDirection() const { return Read<FVector>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: WeakObjectProperty)

    void SET_HighImpactUpperThresholdReciprocal(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_LastRagdollImpactForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x18, Type: StructProperty)
    void SET_LastImpactRelativeDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x18, Type: StructProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3f0
class UBeanChar_Swimming_AnimLayer : public UAnimInstance
{
public:
    float SpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    bool bIsJumping() const { return Read<bool>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_SpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_bIsJumping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x1, Type: BoolProperty)
    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3e0
class UBeanChar_Zipline_AnimLayer : public UAnimInstance
{
public:
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig() const { return Read<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_BeanCharacterConfig(const TWeakObjectPtr<UBeanCharConfigObject*>& Value) { Write<TWeakObjectPtr<UBeanCharConfigObject*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x48
class UBeanCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x80
class UBeanCosmeticBackpackAllowList : public UDataAsset
{
public:
    TSet<TSoftObjectPtr<UAthenaBackpackItemDefinition*>> AllowedBackpacks() const { return Read<TSet<TSoftObjectPtr<UAthenaBackpackItemDefinition*>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: SetProperty)

    void SET_AllowedBackpacks(const TSet<TSoftObjectPtr<UAthenaBackpackItemDefinition*>>& Value) { Write<TSet<TSoftObjectPtr<UAthenaBackpackItemDefinition*>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: SetProperty)
};

// Size: 0x28
class UBeanGrabbable : public UInterface
{
public:
};

// Size: 0x2c0
class UBeanJiggleMotionComponent : public UActorComponent
{
public:
    FRuntimeFloatCurve VelocityCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x88, Type: StructProperty)
    TArray<FQuat> CurrentBoneRotations() const { return Read<TArray<FQuat>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    TArray<FQuat> TargetBoneRotations() const { return Read<TArray<FQuat>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    TArray<FRotator> CurrentInterpolatedBoneRotations() const { return Read<TArray<FRotator>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: ArrayProperty)

    void SET_VelocityCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x88, Type: StructProperty)
    void SET_CurrentBoneRotations(const TArray<FQuat>& Value) { Write<TArray<FQuat>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    void SET_TargetBoneRotations(const TArray<FQuat>& Value) { Write<TArray<FQuat>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentInterpolatedBoneRotations(const TArray<FRotator>& Value) { Write<TArray<FRotator>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UBeanLaunchPredictorInterface : public UInterface
{
public:
};

// Size: 0x108
class UBeanParticleSystemsComponent : public UActorComponent
{
public:
    TMap<EBeanParticleVfxTypes, TSoftObjectPtr<UNiagaraSystem*>> VfxParticleSystemsMap() const { return Read<TMap<EBeanParticleVfxTypes, TSoftObjectPtr<UNiagaraSystem*>>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)

    void SET_VfxParticleSystemsMap(const TMap<EBeanParticleVfxTypes, TSoftObjectPtr<UNiagaraSystem*>>& Value) { Write<TMap<EBeanParticleVfxTypes, TSoftObjectPtr<UNiagaraSystem*>>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x80
class UBeanPhysicsDOFConstraintSubsystem : public UGameInstanceSubsystem
{
public:
    TMap<ABeanCharacter*, FBeanPhysicsDOFConstraint> PreviousConstraints() const { return Read<TMap<ABeanCharacter*, FBeanPhysicsDOFConstraint>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_PreviousConstraints(const TMap<ABeanCharacter*, FBeanPhysicsDOFConstraint>& Value) { Write<TMap<ABeanCharacter*, FBeanPhysicsDOFConstraint>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x78
class UBeanStreamingManager : public UObject
{
public:
    TSet<UObject*> LoadedAssets() const { return Read<TSet<UObject*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: SetProperty)

    void SET_LoadedAssets(const TSet<UObject*>& Value) { Write<TSet<UObject*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: SetProperty)
};

// Size: 0x360
class AFortAthenaMutator_BeanGameStateCore : public AFortAthenaMutator
{
public:
};

// Size: 0x380
class AFortAthenaMutator_BeanPlayerPawn : public AFortAthenaMutator
{
public:
};

// Size: 0x90
class UFortAutomationRpcManager_Beanstalk : public UFortAutomationRpcManager
{
public:
};

// Size: 0xd8
class UFortPickupInteractOverrideComponent_Beanstalk : public UFortPickupInteractOverrideComponent
{
public:
};

// Size: 0x48
class UInteractSelection_BeanPawn : public UInteractSelection_Base
{
public:
};

// Size: 0xb18
class UBeanCharConfigObject : public UObject
{
public:
    FBeanCharInteractionsConfig Interaction() const { return Read<FBeanCharInteractionsConfig>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xf0, Type: StructProperty)
    FBeanCharInventoryModeConfig InventoryMode() const { return Read<FBeanCharInventoryModeConfig>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x80, Type: StructProperty)
    FBeanCharMovementConfig Movement() const { return Read<FBeanCharMovementConfig>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x278, Type: StructProperty)
    FBeanCharJumpConfig Jump() const { return Read<FBeanCharJumpConfig>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x48, Type: StructProperty)
    FBeanCharDiveConfig Dive() const { return Read<FBeanCharDiveConfig>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x58, Type: StructProperty)
    FBeanCharImpactConfig Impact() const { return Read<FBeanCharImpactConfig>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x190, Type: StructProperty)
    FBeanCharStaggerConfig Stagger() const { return Read<FBeanCharStaggerConfig>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0xc, Type: StructProperty)
    FBeanCharRagdollConfig Ragdoll() const { return Read<FBeanCharRagdollConfig>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x198, Type: StructProperty)
    FBeanCharRollConfig Roll() const { return Read<FBeanCharRollConfig>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x28, Type: StructProperty)
    FBeanCharGrabConfig Grab() const { return Read<FBeanCharGrabConfig>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0xd0, Type: StructProperty)
    FBeanCharGetupConfig Getup() const { return Read<FBeanCharGetupConfig>(uintptr_t(this) + 0x8e0); } // 0x8e0 (Size: 0x28, Type: StructProperty)
    FBeanCharGetupRollConfig GetupRoll() const { return Read<FBeanCharGetupRollConfig>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x10, Type: StructProperty)
    FBeanCharMantleConfig Mantle() const { return Read<FBeanCharMantleConfig>(uintptr_t(this) + 0x918); } // 0x918 (Size: 0xc0, Type: StructProperty)
    FBeanCharJostleConfig Jostle() const { return Read<FBeanCharJostleConfig>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x30, Type: StructProperty)
    FBeanCharCameraConfig Camera() const { return Read<FBeanCharCameraConfig>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x18, Type: StructProperty)
    FBeanCharCosmeticConfig Cosmetics() const { return Read<FBeanCharCosmeticConfig>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x10, Type: StructProperty)
    FBeanCharSwimmingConfig Swimming() const { return Read<FBeanCharSwimmingConfig>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x20, Type: StructProperty)
    FBeanCharZiplineConfig Zipline() const { return Read<FBeanCharZiplineConfig>(uintptr_t(this) + 0xa50); } // 0xa50 (Size: 0x4, Type: StructProperty)
    FBeanCharJiggleConfig Jiggle() const { return Read<FBeanCharJiggleConfig>(uintptr_t(this) + 0xa58); } // 0xa58 (Size: 0x90, Type: StructProperty)
    FBeanCharHUDConfig HUD() const { return Read<FBeanCharHUDConfig>(uintptr_t(this) + 0xae8); } // 0xae8 (Size: 0x20, Type: StructProperty)
    FBeanCharTouchControlsConfig TouchControls() const { return Read<FBeanCharTouchControlsConfig>(uintptr_t(this) + 0xb08); } // 0xb08 (Size: 0xc, Type: StructProperty)

    void SET_Interaction(const FBeanCharInteractionsConfig& Value) { Write<FBeanCharInteractionsConfig>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xf0, Type: StructProperty)
    void SET_InventoryMode(const FBeanCharInventoryModeConfig& Value) { Write<FBeanCharInventoryModeConfig>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x80, Type: StructProperty)
    void SET_Movement(const FBeanCharMovementConfig& Value) { Write<FBeanCharMovementConfig>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x278, Type: StructProperty)
    void SET_Jump(const FBeanCharJumpConfig& Value) { Write<FBeanCharJumpConfig>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x48, Type: StructProperty)
    void SET_Dive(const FBeanCharDiveConfig& Value) { Write<FBeanCharDiveConfig>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x58, Type: StructProperty)
    void SET_Impact(const FBeanCharImpactConfig& Value) { Write<FBeanCharImpactConfig>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x190, Type: StructProperty)
    void SET_Stagger(const FBeanCharStaggerConfig& Value) { Write<FBeanCharStaggerConfig>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0xc, Type: StructProperty)
    void SET_Ragdoll(const FBeanCharRagdollConfig& Value) { Write<FBeanCharRagdollConfig>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x198, Type: StructProperty)
    void SET_Roll(const FBeanCharRollConfig& Value) { Write<FBeanCharRollConfig>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x28, Type: StructProperty)
    void SET_Grab(const FBeanCharGrabConfig& Value) { Write<FBeanCharGrabConfig>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0xd0, Type: StructProperty)
    void SET_Getup(const FBeanCharGetupConfig& Value) { Write<FBeanCharGetupConfig>(uintptr_t(this) + 0x8e0, Value); } // 0x8e0 (Size: 0x28, Type: StructProperty)
    void SET_GetupRoll(const FBeanCharGetupRollConfig& Value) { Write<FBeanCharGetupRollConfig>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x10, Type: StructProperty)
    void SET_Mantle(const FBeanCharMantleConfig& Value) { Write<FBeanCharMantleConfig>(uintptr_t(this) + 0x918, Value); } // 0x918 (Size: 0xc0, Type: StructProperty)
    void SET_Jostle(const FBeanCharJostleConfig& Value) { Write<FBeanCharJostleConfig>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x30, Type: StructProperty)
    void SET_Camera(const FBeanCharCameraConfig& Value) { Write<FBeanCharCameraConfig>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x18, Type: StructProperty)
    void SET_Cosmetics(const FBeanCharCosmeticConfig& Value) { Write<FBeanCharCosmeticConfig>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x10, Type: StructProperty)
    void SET_Swimming(const FBeanCharSwimmingConfig& Value) { Write<FBeanCharSwimmingConfig>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x20, Type: StructProperty)
    void SET_Zipline(const FBeanCharZiplineConfig& Value) { Write<FBeanCharZiplineConfig>(uintptr_t(this) + 0xa50, Value); } // 0xa50 (Size: 0x4, Type: StructProperty)
    void SET_Jiggle(const FBeanCharJiggleConfig& Value) { Write<FBeanCharJiggleConfig>(uintptr_t(this) + 0xa58, Value); } // 0xa58 (Size: 0x90, Type: StructProperty)
    void SET_HUD(const FBeanCharHUDConfig& Value) { Write<FBeanCharHUDConfig>(uintptr_t(this) + 0xae8, Value); } // 0xae8 (Size: 0x20, Type: StructProperty)
    void SET_TouchControls(const FBeanCharTouchControlsConfig& Value) { Write<FBeanCharTouchControlsConfig>(uintptr_t(this) + 0xb08, Value); } // 0xb08 (Size: 0xc, Type: StructProperty)
};

// Size: 0x28
class UBeanstalkFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x8
struct FBeanAudioKey
{
public:
};

// Size: 0x20
struct FBeanAudioSet
{
public:
    TArray<USoundBase*> SoundClips2D() const { return Read<TArray<USoundBase*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundBase*> SoundClips3D() const { return Read<TArray<USoundBase*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_SoundClips2D(const TArray<USoundBase*>& Value) { Write<TArray<USoundBase*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_SoundClips3D(const TArray<USoundBase*>& Value) { Write<TArray<USoundBase*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FBeanCharIdleBreakDef
{
public:
    TSoftObjectPtr<UAnimMontage> IdleAnim() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    float Weighting() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_IdleAnim(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Weighting(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FBeanCharGrabPrediction
{
public:
};

// Size: 0xd0
struct FBeanCharMantleCheckDebug
{
public:
};

// Size: 0x110
struct FBeanCharMantleCheckDebug_StepOne : public FBeanCharMantleCheckDebug
{
public:
};

// Size: 0xe0
struct FBeanCharMantleCheckDebug_StepTwo : public FBeanCharMantleCheckDebug
{
public:
};

// Size: 0xe0
struct FBeanCharMantleCheckDebug_StepThree : public FBeanCharMantleCheckDebug
{
public:
};

// Size: 0x110
struct FBeanCharMantleCheckDebug_StepFour : public FBeanCharMantleCheckDebug
{
public:
};

// Size: 0x430
struct FBeanCharMantleTargetDebug
{
public:
};

// Size: 0x38
struct FBeanCharMantleTargetData
{
public:
};

// Size: 0x40
struct FBeanCharRagdollImpactData
{
public:
    double Strength() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    bool bFromLaunch() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_Strength(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_bFromLaunch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FBeanRagdollDebugComponentSnapshot
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FBeanRagdollDebugComponentHistory
{
public:
    TArray<FBeanRagdollDebugComponentSnapshot> CapsuleHistory() const { return Read<TArray<FBeanRagdollDebugComponentSnapshot>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FBeanRagdollDebugComponentSnapshot> MeshHistory() const { return Read<TArray<FBeanRagdollDebugComponentSnapshot>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_CapsuleHistory(const TArray<FBeanRagdollDebugComponentSnapshot>& Value) { Write<TArray<FBeanRagdollDebugComponentSnapshot>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshHistory(const TArray<FBeanRagdollDebugComponentSnapshot>& Value) { Write<TArray<FBeanRagdollDebugComponentSnapshot>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FBeanCharStateMachineContext
{
public:
    UBeanCharStateBase* CurrentState() const { return Read<UBeanCharStateBase*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UBeanCharStateBase* NewState() const { return Read<UBeanCharStateBase*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentState(const UBeanCharStateBase*& Value) { Write<UBeanCharStateBase*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_NewState(const UBeanCharStateBase*& Value) { Write<UBeanCharStateBase*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4
struct FBeanStateHistoryItem
{
public:
};

// Size: 0x68
struct FBeanStateGameplayTagsDefinition
{
public:
    uint8_t StateId() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FGameplayTagContainer GrantedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedAbilityTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)

    void SET_StateId(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_GrantedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_BlockedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_BlockedAbilityTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
};

// Size: 0x58
struct FBeanPredictedLaunch
{
public:
    TWeakObjectPtr<ABeanCharacter*> Character() const { return Read<TWeakObjectPtr<ABeanCharacter*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FVector LaunchVector() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector CharacterLocationBeforeLaunch() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector CharacterVelocityBeforeLaunch() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UObject*> OptionalSourceSubobject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Character(const TWeakObjectPtr<ABeanCharacter*>& Value) { Write<TWeakObjectPtr<ABeanCharacter*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LaunchVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_CharacterLocationBeforeLaunch(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_CharacterVelocityBeforeLaunch(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_OptionalSourceSubobject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x20
struct FBeanPhysicsDOFConstraint
{
public:
};

// Size: 0x100
struct FBeanRootMotionSource_MoveToWithTimeMappingForce : public FRootMotionSource
{
public:
    FVector StartLocation() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    UCurveFloat* TimeMappingCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    float PreviousPreCurvedTargetRotationTimeFraction() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)

    void SET_StartLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_TimeMappingCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousPreCurvedTargetRotationTimeFraction(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf0
struct FBeanRootMotionSource_RotationDeltaForce : public FRootMotionSource
{
public:
    FQuat DeltaRotation() const { return Read<FQuat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x20, Type: StructProperty)
    UCurveFloat* TimeMappingCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    float PreviousPreCurvedTargetRotationTimeFraction() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)

    void SET_DeltaRotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x20, Type: StructProperty)
    void SET_TimeMappingCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousPreCurvedTargetRotationTimeFraction(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe0
struct FBeanRootMotionSource_RotationCurveForce : public FRootMotionSource
{
public:
    bool bUseNormalizedTime() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    UCurveVector* RotationCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    float SimulatedTargetTimeFraction() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)

    void SET_bUseNormalizedTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_RotationCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_SimulatedTargetTimeFraction(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3
struct FBeanStateHistoryRecord
{
public:
    uint8_t StateId() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LayerId() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    bool bIsReplaying() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)

    void SET_StateId(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_LayerId(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_bIsReplaying(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FInteractSelectionData_BeanPawn : public FInteractSelectionData_Base
{
public:
    float InteractRadius() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float InteractHalfAngle() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_InteractRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_InteractHalfAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FBeanJiggleStateWeightOverride
{
public:
    uint8_t StateId() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float Weighting() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_StateId(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Weighting(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FBeanCharCollisionResponseData
{
public:
    float ImpactThreshold() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bActivateKnockback() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bActivateRagdoll() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    uint8_t ImpactAnimType() const { return Read<uint8_t>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: EnumProperty)
    bool bPlayImpactVFX() const { return Read<bool>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x1, Type: BoolProperty)
    UForceFeedbackEffect* ForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bPlayFeedbackOnLand() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bPlayFeedbackOnLaunch() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)

    void SET_ImpactThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bActivateKnockback(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bActivateRagdoll(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_ImpactAnimType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: EnumProperty)
    void SET_bPlayImpactVFX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x1, Type: BoolProperty)
    void SET_ForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bPlayFeedbackOnLand(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayFeedbackOnLaunch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf0
struct FBeanCharInteractionsConfig
{
public:
    FGameplayTagContainer PersistentTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DisallowedPlayerActions() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedGameplayAbilityTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedItems() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedInteractableTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InteractablesRequiringReticle() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x20, Type: StructProperty)
    FText BlockedInteractableContextText() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FLinearColor BlockedInteractableContextTextColour() const { return Read<FLinearColor>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    bool bBlockedInteractableContextTextOnly() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    FInteractSelectionData_BeanPawn InteractSelectionData() const { return Read<FInteractSelectionData_BeanPawn>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x8, Type: StructProperty)

    void SET_PersistentTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_DisallowedPlayerActions(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_BlockedGameplayAbilityTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_AllowedItems(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
    void SET_BlockedInteractableTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: StructProperty)
    void SET_InteractablesRequiringReticle(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x20, Type: StructProperty)
    void SET_BlockedInteractableContextText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_BlockedInteractableContextTextColour(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_bBlockedInteractableContextTextOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_InteractSelectionData(const FInteractSelectionData_BeanPawn& Value) { Write<FInteractSelectionData_BeanPawn>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x8, Type: StructProperty)
};

// Size: 0x80
struct FBeanCharInventoryModeConfig
{
public:
    FGameplayTagContainer ActionsToAllow() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayAbilityTagsToUnblock() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer HUDElementsToUnhide() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ItemsToAllow() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)

    void SET_ActionsToAllow(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_GameplayAbilityTagsToUnblock(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_HUDElementsToUnhide(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_ItemsToAllow(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
};

// Size: 0x278
struct FBeanCharMovementConfig
{
public:
    float Mass() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float GravityScale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve NormalMaxAccelerationCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve NormalMaxDecelerationCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x88, Type: StructProperty)
    float LeanAnimTurnThreshold() const { return Read<float>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: FloatProperty)
    float LeanAnimTurnMaxAngleRadians() const { return Read<float>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: FloatProperty)
    float LeanAnimBlendSpeed() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float TurnSpeedGrounded() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve TurnYawMultiplierGrounded() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x88, Type: StructProperty)
    float TurnSpeedAerial() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float TurnSpeedFlying() const { return Read<float>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    bool bIsTurn180Enabled() const { return Read<bool>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x1, Type: BoolProperty)
    float Turn180MinSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: FloatProperty)
    float Turn180DotProductTolerance() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float Turn180Duration() const { return Read<float>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve Turn180YawMultiplier() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x88, Type: StructProperty)
    float Turn180CancelDotProductTolerance() const { return Read<float>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x4, Type: FloatProperty)
    bool UseMeshPositionLerp() const { return Read<bool>(uintptr_t(this) + 0x254); } // 0x254 (Size: 0x1, Type: BoolProperty)
    bool UseCameraPositionLerp() const { return Read<bool>(uintptr_t(this) + 0x255); } // 0x255 (Size: 0x1, Type: BoolProperty)
    float PositionLerpSpeed() const { return Read<float>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x4, Type: FloatProperty)
    float PositionLerpAccelerationFactor() const { return Read<float>(uintptr_t(this) + 0x25c); } // 0x25c (Size: 0x4, Type: FloatProperty)
    float MaxCorrectionDistanceToTriggerMeshLerp() const { return Read<float>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x4, Type: FloatProperty)
    float MaxCorrectionDistanceToTriggerCameraLerp() const { return Read<float>(uintptr_t(this) + 0x264); } // 0x264 (Size: 0x4, Type: FloatProperty)
    float MaxFallDuration() const { return Read<float>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x4, Type: FloatProperty)
    double FallToRagdollZVelocityThreshold() const { return Read<double>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: DoubleProperty)

    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_GravityScale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_NormalMaxAccelerationCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x88, Type: StructProperty)
    void SET_NormalMaxDecelerationCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x88, Type: StructProperty)
    void SET_LeanAnimTurnThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: FloatProperty)
    void SET_LeanAnimTurnMaxAngleRadians(const float& Value) { Write<float>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: FloatProperty)
    void SET_LeanAnimBlendSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_TurnSpeedGrounded(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_TurnYawMultiplierGrounded(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x88, Type: StructProperty)
    void SET_TurnSpeedAerial(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    void SET_TurnSpeedFlying(const float& Value) { Write<float>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    void SET_bIsTurn180Enabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x1, Type: BoolProperty)
    void SET_Turn180MinSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: FloatProperty)
    void SET_Turn180DotProductTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_Turn180Duration(const float& Value) { Write<float>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    void SET_Turn180YawMultiplier(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x88, Type: StructProperty)
    void SET_Turn180CancelDotProductTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x4, Type: FloatProperty)
    void SET_UseMeshPositionLerp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x254, Value); } // 0x254 (Size: 0x1, Type: BoolProperty)
    void SET_UseCameraPositionLerp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x255, Value); } // 0x255 (Size: 0x1, Type: BoolProperty)
    void SET_PositionLerpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x4, Type: FloatProperty)
    void SET_PositionLerpAccelerationFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x25c, Value); } // 0x25c (Size: 0x4, Type: FloatProperty)
    void SET_MaxCorrectionDistanceToTriggerMeshLerp(const float& Value) { Write<float>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x4, Type: FloatProperty)
    void SET_MaxCorrectionDistanceToTriggerCameraLerp(const float& Value) { Write<float>(uintptr_t(this) + 0x264, Value); } // 0x264 (Size: 0x4, Type: FloatProperty)
    void SET_MaxFallDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x4, Type: FloatProperty)
    void SET_FallToRagdollZVelocityThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x48
struct FBeanCharJumpConfig
{
public:
    float JumpZVelocity() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float LandingVelocityConserve() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    double TransitionToFallingZThreshold() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    float JumpCoyoteTime() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float JumpReverseCoyoteTime() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector ParticleEmitterScale() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    double ParticleSpawnZOffset() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    double AnticipateLandingInitialTraceLength() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    double AnticipateLandingZVelocityMultiplier() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)

    void SET_JumpZVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LandingVelocityConserve(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TransitionToFallingZThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_JumpCoyoteTime(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_JumpReverseCoyoteTime(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_ParticleEmitterScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_ParticleSpawnZOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_AnticipateLandingInitialTraceLength(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    void SET_AnticipateLandingZVelocityMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x58
struct FBeanCharDiveConfig
{
public:
    float GroundDiveVelocity() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float GroundDiveAngle() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float AirDiveVelocity() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float AirDiveAngle() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    double HorizontalVelocityConservePercentageNormalized() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    float TurnSpeedDiving() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float GroundTimeBeforeGetup() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float LandingVelocityReductionPercentageNormalized() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    UCurveVector* DiveRotationCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FVector ParticleEmitterScale() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    double ParticleSpawnZOffset() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    bool bLaunchZOverrideResetsDive() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bLaunchXYOverrideResetsDive() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)

    void SET_GroundDiveVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_GroundDiveAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_AirDiveVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AirDiveAngle(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_HorizontalVelocityConservePercentageNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_TurnSpeedDiving(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_GroundTimeBeforeGetup(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_LandingVelocityReductionPercentageNormalized(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_DiveRotationCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_ParticleEmitterScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_ParticleSpawnZOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_bLaunchZOverrideResetsDive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bLaunchXYOverrideResetsDive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x190
struct FBeanCharImpactConfig
{
public:
    TArray<FBeanCharCollisionResponseData> CollisionResponseData() const { return Read<TArray<FBeanCharCollisionResponseData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    double DiveHeadOnCollisionReactionMultiplier() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double GroundLandingCollisionReactionMultiplier() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double LedgeUpwardDotTolerance() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    FVector LedgeKnockbackMultiplier() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    double InAirKnockbackDampening() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double MinKnockbackForce() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    double MaxKnockbackForce() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    float ImpactVFXCooldown() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float ImpactOffsetAmount() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float ImpactThresholdLarge() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float ImpactThresholdMedium() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float ImpactThresholdSmall() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    double MinimumImpactGameplayCueStrength() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    double ImpactGameplayCueCooldown() const { return Read<double>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    TSet<EBeanCharStateID> IgnoreImpactStates() const { return Read<TSet<EBeanCharStateID>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: SetProperty)
    FName RootUnpinnedBone() const { return Read<FName>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: NameProperty)
    float BasePinStrength() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve PinningResetCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x88, Type: StructProperty)
    TArray<TEnumAsByte<ECollisionChannel>> PinningCollisionChannels() const { return Read<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: ArrayProperty)
    FPhysicalAnimationData PinningPhysicalAnimationData() const { return Read<FPhysicalAnimationData>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x20, Type: StructProperty)

    void SET_CollisionResponseData(const TArray<FBeanCharCollisionResponseData>& Value) { Write<TArray<FBeanCharCollisionResponseData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_DiveHeadOnCollisionReactionMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_GroundLandingCollisionReactionMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_LedgeUpwardDotTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_LedgeKnockbackMultiplier(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_InAirKnockbackDampening(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_MinKnockbackForce(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxKnockbackForce(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_ImpactVFXCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_ImpactOffsetAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_ImpactThresholdLarge(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_ImpactThresholdMedium(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_ImpactThresholdSmall(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumImpactGameplayCueStrength(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    void SET_ImpactGameplayCueCooldown(const double& Value) { Write<double>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    void SET_IgnoreImpactStates(const TSet<EBeanCharStateID>& Value) { Write<TSet<EBeanCharStateID>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: SetProperty)
    void SET_RootUnpinnedBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: NameProperty)
    void SET_BasePinStrength(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_PinningResetCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x88, Type: StructProperty)
    void SET_PinningCollisionChannels(const TArray<TEnumAsByte<ECollisionChannel>>& Value) { Write<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: ArrayProperty)
    void SET_PinningPhysicalAnimationData(const FPhysicalAnimationData& Value) { Write<FPhysicalAnimationData>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x20, Type: StructProperty)
};

// Size: 0xc
struct FBeanCharStaggerConfig
{
public:
    float LandStaggerZVelocityThreshold() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float LandStaggerStunDurationSeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float VelocityMultiplierOnStagger() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_LandStaggerZVelocityThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LandStaggerStunDurationSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_VelocityMultiplierOnStagger(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd0
struct FBeanCharGrabConfig
{
public:
    float GrabbedJumpForceMultiplier() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float GrabRadius() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float GrabTargetCheckHeight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float UngrabDistanceAny() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float UngrabDistanceVertical() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float GrabbingRunSpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float HoldingRunSpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float HoldingMaxTurnSpeed() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float BeingGrabbedRunSpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float BeingGrabbedMaxTurnSpeed() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float HoldPositionForwardOffset() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float RotateToFaceTargetSpeed() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float DragPositionTolerance() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float DragSpeed() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float GrabberVelocityFactor() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float MaxForceOnGrabber() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float GrabbeeVelocityFactor() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float MaxForceOnGrabbee() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float GrabBreakTime() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float GrabbeeCooldownAfterGrabBreak() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float GrabbeeJumpBreakTimeReduction() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float GrabBreakApartForce() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float GrabStumbleDuration() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FVector PlayerGrabOffsetIK() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FVector LeftHandRotationAdjustment() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    FVector RightHandRotationAdjustment() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    float ServerNetLocationToleranceGrabber() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float ServerNetLocationToleranceGrabbee() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    FVector ParticleEmitterScale() const { return Read<FVector>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x18, Type: StructProperty)
    float HoldingRunSpeedAnimationMultiplier() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)

    void SET_GrabbedJumpForceMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_GrabRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_GrabTargetCheckHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_UngrabDistanceAny(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_UngrabDistanceVertical(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_GrabbingRunSpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_HoldingRunSpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_HoldingMaxTurnSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_BeingGrabbedRunSpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_BeingGrabbedMaxTurnSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_HoldPositionForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_RotateToFaceTargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_DragPositionTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_DragSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_GrabberVelocityFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_MaxForceOnGrabber(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_GrabbeeVelocityFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_MaxForceOnGrabbee(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_GrabBreakTime(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_GrabbeeCooldownAfterGrabBreak(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_GrabbeeJumpBreakTimeReduction(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_GrabBreakApartForce(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_GrabStumbleDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_PlayerGrabOffsetIK(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_LeftHandRotationAdjustment(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_RightHandRotationAdjustment(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_ServerNetLocationToleranceGrabber(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_ServerNetLocationToleranceGrabbee(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_ParticleEmitterScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x18, Type: StructProperty)
    void SET_HoldingRunSpeedAnimationMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x198
struct FBeanCharRagdollConfig
{
public:
    double ImpactForceMultiplier() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    bool bUseLaunchForceMultiplier() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve LaunchForceMultiplier() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x88, Type: StructProperty)
    double GroundedRagdollControlForce() const { return Read<double>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    double InAirRagdollControlForce() const { return Read<double>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: DoubleProperty)
    float RagdollControlVelocityThreshold() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float ExitLinearVelocity() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    float ExitAngularVelocity() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    float GetupVerticalityDotProductTolerance() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    float GetupVerticalityDotProductDeadZoneMin() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float GetupVerticalityDotProductDeadZoneMax() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MinimumActiveSeconds() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MaxActiveSeconds() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    double AngularVelocityMagnitude() const { return Read<double>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    float HighImpactMaxAnimThreshold() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    FName SkeletalMeshAnchorBone() const { return Read<FName>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: NameProperty)
    float PhysicsBlendWeight() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    FRotator MeshCapsuleRotationalOffset() const { return Read<FRotator>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)
    FVector MeshCapsulePositionalOffset() const { return Read<FVector>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x18, Type: StructProperty)
    double DebugTriggerRagdollForce() const { return Read<double>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: DoubleProperty)
    bool bEnableRollExit() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    double SpeedForRollGetup() const { return Read<double>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: DoubleProperty)
    float GroundedCheckHalfHeightScale() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    double GroundedCheckRadius() const { return Read<double>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: DoubleProperty)
    float MinimumTimeOnGround() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    TArray<TEnumAsByte<ECollisionChannel>> MeshCollisionChannels() const { return Read<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> MeshBonesWithCCD() const { return Read<TArray<FString>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxRemoteRagdollCharacters() const { return Read<int32_t>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: IntProperty)
    double MaxRemoteRagdollDistance() const { return Read<double>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: DoubleProperty)
    double RemoteRagdollMinimumDeactiveTime() const { return Read<double>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: DoubleProperty)
    bool bCullRemoteRagdollsBehindCamera() const { return Read<bool>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: BoolProperty)
    double ReplicationHardsnapDistanceOverride() const { return Read<double>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: DoubleProperty)
    double MaxSecondsStuck() const { return Read<double>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    double SameLocationDistanceTolerance() const { return Read<double>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: DoubleProperty)

    void SET_ImpactForceMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_bUseLaunchForceMultiplier(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_LaunchForceMultiplier(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x88, Type: StructProperty)
    void SET_GroundedRagdollControlForce(const double& Value) { Write<double>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    void SET_InAirRagdollControlForce(const double& Value) { Write<double>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: DoubleProperty)
    void SET_RagdollControlVelocityThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_ExitLinearVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_ExitAngularVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_GetupVerticalityDotProductTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_GetupVerticalityDotProductDeadZoneMin(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_GetupVerticalityDotProductDeadZoneMax(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MinimumActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_AngularVelocityMagnitude(const double& Value) { Write<double>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    void SET_HighImpactMaxAnimThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_SkeletalMeshAnchorBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: NameProperty)
    void SET_PhysicsBlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_MeshCapsuleRotationalOffset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
    void SET_MeshCapsulePositionalOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x18, Type: StructProperty)
    void SET_DebugTriggerRagdollForce(const double& Value) { Write<double>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: DoubleProperty)
    void SET_bEnableRollExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_SpeedForRollGetup(const double& Value) { Write<double>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: DoubleProperty)
    void SET_GroundedCheckHalfHeightScale(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_GroundedCheckRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: DoubleProperty)
    void SET_MinimumTimeOnGround(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_MeshCollisionChannels(const TArray<TEnumAsByte<ECollisionChannel>>& Value) { Write<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshBonesWithCCD(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxRemoteRagdollCharacters(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: IntProperty)
    void SET_MaxRemoteRagdollDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: DoubleProperty)
    void SET_RemoteRagdollMinimumDeactiveTime(const double& Value) { Write<double>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: DoubleProperty)
    void SET_bCullRemoteRagdollsBehindCamera(const bool& Value) { Write<bool>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: BoolProperty)
    void SET_ReplicationHardsnapDistanceOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxSecondsStuck(const double& Value) { Write<double>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    void SET_SameLocationDistanceTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x28
struct FBeanCharGetupConfig
{
public:
    float AnimationRate() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    UCurveFloat* MotionTimeCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float RunSpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float TurnSpeedOverride() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float RestoreMovementAfterDurationNormalized() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float EarlyExitStateDurationNormalized() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float GetupAnimationThresholdPitch() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float SkipAnimationRotationDuration() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)

    void SET_AnimationRate(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MotionTimeCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_RunSpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_TurnSpeedOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_RestoreMovementAfterDurationNormalized(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_EarlyExitStateDurationNormalized(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_GetupAnimationThresholdPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_SkipAnimationRotationDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FBeanCharGetupRollConfig
{
public:
    float duration() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    UCurveFloat* MotionTimeCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MotionTimeCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FBeanCharRollConfig
{
public:
    double ScaleSpeed() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    float MinimumDuration() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaximumDurationBeforeForcedExit() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    double ExitSpeed() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double GetupDirectionTolerance() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ForwardRollBlendSpeed() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)

    void SET_ScaleSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_MinimumDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumDurationBeforeForcedExit(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_ExitSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_GetupDirectionTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_ForwardRollBlendSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xc0
struct FBeanCharMantleConfig
{
public:
    TArray<TEnumAsByte<ECollisionChannel>> AcceptedCollisionChannels() const { return Read<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<EComponentMobility> HighestAcceptedComponentMobility() const { return Read<TEnumAsByte<EComponentMobility>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: ByteProperty)
    bool bAllowMantleOnAllSceneGraphEntities() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    double WallCheckDownOffset() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double WallCheckDownOffsetDiving() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    double WallCheckRadius() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    double WallCheckHeight() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    double WallCheckLength() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    double WallCheckMaxAngle() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double WallCheckMinFacingAlignment() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    double WallTopCheckMinimumLength() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    double WallTopCheckRadius() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double WallTopMinUpwardAlignment() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    double LedgeCheckLength() const { return Read<double>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    double LedgeCheckRadius() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotHorizontalOffset() const { return Read<double>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotVerticalOffset() const { return Read<double>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotMinimumHeight() const { return Read<double>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotMaxInclineDot() const { return Read<double>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    float AnimationRate() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float RestoreMovementAfterDurationNormalized() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float RestoreMovementVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float CancelBuffer() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    float CancelInputDuration() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float CooldownTime() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    float TimeToValidate() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    FName HangingSpotMotionWarp() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    float ClamberEnabledCacheTime() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float VelocityProjectionSeconds() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)

    void SET_AcceptedCollisionChannels(const TArray<TEnumAsByte<ECollisionChannel>>& Value) { Write<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_HighestAcceptedComponentMobility(const TEnumAsByte<EComponentMobility>& Value) { Write<TEnumAsByte<EComponentMobility>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: ByteProperty)
    void SET_bAllowMantleOnAllSceneGraphEntities(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_WallCheckDownOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_WallCheckDownOffsetDiving(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_WallCheckRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_WallCheckHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_WallCheckLength(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    void SET_WallCheckMaxAngle(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_WallCheckMinFacingAlignment(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_WallTopCheckMinimumLength(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_WallTopCheckRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_WallTopMinUpwardAlignment(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_LedgeCheckLength(const double& Value) { Write<double>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    void SET_LedgeCheckRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    void SET_HangingSpotHorizontalOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    void SET_HangingSpotVerticalOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    void SET_HangingSpotMinimumHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: DoubleProperty)
    void SET_HangingSpotMaxInclineDot(const double& Value) { Write<double>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    void SET_AnimationRate(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_RestoreMovementAfterDurationNormalized(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_RestoreMovementVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_CancelBuffer(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_CancelInputDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_CooldownTime(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_TimeToValidate(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_HangingSpotMotionWarp(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_ClamberEnabledCacheTime(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_VelocityProjectionSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FBeanCharJostleConfig
{
public:
    float JostleTriggerRadius() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float JostleOuterRadius() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float JostleInnerRadius() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float JostleMandatoryRadius() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    double JostleForceMultiplier() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    float JostlerMinSpeedToApplyForce() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float JostleeMaxSpeedToTrigger() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float JostleeMaxSpeedToApplyForce() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float JostleRefreshInterval() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float PositionToleranceDuringJostle() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_JostleTriggerRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_JostleOuterRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_JostleInnerRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_JostleMandatoryRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_JostleForceMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_JostlerMinSpeedToApplyForce(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_JostleeMaxSpeedToTrigger(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_JostleeMaxSpeedToApplyForce(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_JostleRefreshInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_PositionToleranceDuringJostle(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FBeanCharCameraConfig
{
public:
    UClass* CameraMode() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    UClass* OverrideVehicleCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    float EnableDragAfterTeleportTimeout() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_CameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_OverrideVehicleCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_EnableDragAfterTeleportTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FBeanCharCosmeticConfig
{
public:
    TArray<UAthenaDanceItemDefinition*> DefaultEmotes() const { return Read<TArray<UAthenaDanceItemDefinition*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_DefaultEmotes(const TArray<UAthenaDanceItemDefinition*>& Value) { Write<TArray<UAthenaDanceItemDefinition*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FBeanCharSwimmingConfig
{
public:
    float HeadingAdjustmentStrength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinImmersionDepth() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxImmersionDepth() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float TargetImmersionDepth() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float JumpMinVelocityZ() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float JumpMaxVelocityZ() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float JumpForceZ() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float JumpForceDuration() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_HeadingAdjustmentStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MinImmersionDepth(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxImmersionDepth(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_TargetImmersionDepth(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_JumpMinVelocityZ(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_JumpMaxVelocityZ(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_JumpForceZ(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_JumpForceDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FBeanCharZiplineConfig
{
public:
    float ZiplineTurnSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_ZiplineTurnSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FBeanCharJiggleConfig
{
public:
    TArray<float> BoneWeights() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    double BeingGrabbedWeightMultiplier() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    TArray<FBeanJiggleStateWeightOverride> StateWeightOverrides() const { return Read<TArray<FBeanJiggleStateWeightOverride>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    float StateWeightBlendDuration() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    double PlatformVelocityMultiplier() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    double AccelerationNoiseCutoff() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    double Mass() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double SpringConst() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    double SpringPivotOffset() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    double SpringDamping() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double SpringInterpSpeed() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    double ClampOffsetFactor() const { return Read<double>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    double MaxInputForce() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    FVector AccelerationAxisWeights() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)

    void SET_BoneWeights(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_BeingGrabbedWeightMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_StateWeightOverrides(const TArray<FBeanJiggleStateWeightOverride>& Value) { Write<TArray<FBeanJiggleStateWeightOverride>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_StateWeightBlendDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_PlatformVelocityMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_AccelerationNoiseCutoff(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    void SET_Mass(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringConst(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringPivotOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringDamping(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringInterpSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_ClampOffsetFactor(const double& Value) { Write<double>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxInputForce(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    void SET_AccelerationAxisWeights(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FBeanCharHUDConfig
{
public:
    FGameplayTagContainer HiddenHUDElements() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)

    void SET_HiddenHUDElements(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
};

// Size: 0xc
struct FBeanCharTouchControlsConfig
{
public:
    int32_t NumLandingPredictionTraceSubdivisions() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float JumpDiveButtonAdditionalCoyoteTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float JumpDiveButtonAdditionalReverseCoyoteTime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_NumLandingPredictionTraceSubdivisions(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_JumpDiveButtonAdditionalCoyoteTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_JumpDiveButtonAdditionalReverseCoyoteTime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

