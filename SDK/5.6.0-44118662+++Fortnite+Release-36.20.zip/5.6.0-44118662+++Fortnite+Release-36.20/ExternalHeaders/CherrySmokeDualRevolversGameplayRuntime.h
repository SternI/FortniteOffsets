/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CherrySmokeDualRevolversGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "Engine.h"

// Size: 0x13b0
class UCherrySmokeDualRevolverLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    double AdditiveLoopPlayRate() const { return Read<double>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x8, Type: DoubleProperty)
    double DodgeAngleRadians() const { return Read<double>(uintptr_t(this) + 0x1310); } // 0x1310 (Size: 0x8, Type: DoubleProperty)
    bool bIsHangtimeActive() const { return Read<bool>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x1, Type: BoolProperty)
    bool bDidRebound() const { return Read<bool>(uintptr_t(this) + 0x1319); } // 0x1319 (Size: 0x1, Type: BoolProperty)
    bool bIncompatibleMovement() const { return Read<bool>(uintptr_t(this) + 0x131a); } // 0x131a (Size: 0x1, Type: BoolProperty)
    bool bReloading() const { return Read<bool>(uintptr_t(this) + 0x131b); } // 0x131b (Size: 0x1, Type: BoolProperty)
    bool bAirDodgeActive() const { return Read<bool>(uintptr_t(this) + 0x131c); } // 0x131c (Size: 0x1, Type: BoolProperty)
    bool bDoubleJumpActive() const { return Read<bool>(uintptr_t(this) + 0x131d); } // 0x131d (Size: 0x1, Type: BoolProperty)
    bool bIsLeftDodgeSpace() const { return Read<bool>(uintptr_t(this) + 0x131e); } // 0x131e (Size: 0x1, Type: BoolProperty)
    bool bCanEnterDodgeStart() const { return Read<bool>(uintptr_t(this) + 0x131f); } // 0x131f (Size: 0x1, Type: BoolProperty)
    bool bIsLastHandFireLeft() const { return Read<bool>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x1, Type: BoolProperty)
    bool bCanFall() const { return Read<bool>(uintptr_t(this) + 0x1321); } // 0x1321 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterDoubleJump() const { return Read<bool>(uintptr_t(this) + 0x1322); } // 0x1322 (Size: 0x1, Type: BoolProperty)
    FVector CurrentWorldSpaceDodgeDirection() const { return Read<FVector>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x18, Type: StructProperty)
    FVector InitialDodgeDirection() const { return Read<FVector>(uintptr_t(this) + 0x1340); } // 0x1340 (Size: 0x18, Type: StructProperty)
    float LastDodgeDirection() const { return Read<float>(uintptr_t(this) + 0x1358); } // 0x1358 (Size: 0x4, Type: FloatProperty)
    double InAirTime() const { return Read<double>(uintptr_t(this) + 0x1360); } // 0x1360 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer IncompatibleMovementTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1368); } // 0x1368 (Size: 0x20, Type: StructProperty)
    double HangtimeAnimationRate() const { return Read<double>(uintptr_t(this) + 0x1388); } // 0x1388 (Size: 0x8, Type: DoubleProperty)

    void SET_AdditiveLoopPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x8, Type: DoubleProperty)
    void SET_DodgeAngleRadians(const double& Value) { Write<double>(uintptr_t(this) + 0x1310, Value); } // 0x1310 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsHangtimeActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x1, Type: BoolProperty)
    void SET_bDidRebound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1319, Value); } // 0x1319 (Size: 0x1, Type: BoolProperty)
    void SET_bIncompatibleMovement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131a, Value); } // 0x131a (Size: 0x1, Type: BoolProperty)
    void SET_bReloading(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131b, Value); } // 0x131b (Size: 0x1, Type: BoolProperty)
    void SET_bAirDodgeActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131c, Value); } // 0x131c (Size: 0x1, Type: BoolProperty)
    void SET_bDoubleJumpActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131d, Value); } // 0x131d (Size: 0x1, Type: BoolProperty)
    void SET_bIsLeftDodgeSpace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131e, Value); } // 0x131e (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterDodgeStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131f, Value); } // 0x131f (Size: 0x1, Type: BoolProperty)
    void SET_bIsLastHandFireLeft(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x1, Type: BoolProperty)
    void SET_bCanFall(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1321, Value); } // 0x1321 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterDoubleJump(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1322, Value); } // 0x1322 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentWorldSpaceDodgeDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x18, Type: StructProperty)
    void SET_InitialDodgeDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1340, Value); } // 0x1340 (Size: 0x18, Type: StructProperty)
    void SET_LastDodgeDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x1358, Value); } // 0x1358 (Size: 0x4, Type: FloatProperty)
    void SET_InAirTime(const double& Value) { Write<double>(uintptr_t(this) + 0x1360, Value); } // 0x1360 (Size: 0x8, Type: DoubleProperty)
    void SET_IncompatibleMovementTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1368, Value); } // 0x1368 (Size: 0x20, Type: StructProperty)
    void SET_HangtimeAnimationRate(const double& Value) { Write<double>(uintptr_t(this) + 0x1388, Value); } // 0x1388 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x28
class UCherrySmokeDualRevolverPawnComponentAnimInterface : public UInterface
{
public:
};

// Size: 0x28
class UCherrySmokeDualRevolverWeaponAnimInterface : public UInterface
{
public:
};

// Size: 0x78
class UFortMovementMode_HangTimeRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

// Size: 0x310
class UFortMovementMode_HangTime : public UFortMovementMode_BaseExtLogic
{
public:
    FScalableFloat TimeDilationScale() const { return Read<FScalableFloat>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaximumDurationSeconds() const { return Read<FScalableFloat>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x28, Type: StructProperty)
    FScalableFloat ExtraVelocityUpwards() const { return Read<FScalableFloat>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat BlendInSeconds() const { return Read<FScalableFloat>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    UCurveFloat* BlendInCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat BlendOutNonDilatedTimeToGroundSeconds() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* BlendOutCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    FVector ConstantVelocityOffset() const { return Read<FVector>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x18, Type: StructProperty)
    float CachedMaximumDurationSeconds() const { return Read<float>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    float CachedTimeDilationScale() const { return Read<float>(uintptr_t(this) + 0x2f4); } // 0x2f4 (Size: 0x4, Type: FloatProperty)
    float CachedBlendInSeconds() const { return Read<float>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float CachedBlendOutNonDilatedTimeToGroundSeconds() const { return Read<float>(uintptr_t(this) + 0x2fc); } // 0x2fc (Size: 0x4, Type: FloatProperty)

    void SET_TimeDilationScale(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x28, Type: StructProperty)
    void SET_MaximumDurationSeconds(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x28, Type: StructProperty)
    void SET_ExtraVelocityUpwards(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x28, Type: StructProperty)
    void SET_BlendInSeconds(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_BlendInCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendOutNonDilatedTimeToGroundSeconds(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_BlendOutCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_ConstantVelocityOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x18, Type: StructProperty)
    void SET_CachedMaximumDurationSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    void SET_CachedTimeDilationScale(const float& Value) { Write<float>(uintptr_t(this) + 0x2f4, Value); } // 0x2f4 (Size: 0x4, Type: FloatProperty)
    void SET_CachedBlendInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x4, Type: FloatProperty)
    void SET_CachedBlendOutNonDilatedTimeToGroundSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2fc, Value); } // 0x2fc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4b8
class UFortMovementMode_HangTimeDilatedMotion : public UFortMovementMode_ExtGuidedMotion
{
public:
};

// Size: 0x26b0
class AFortWeaponCherrySmokeDualRevolvers : public AFortWeaponRanged_DualWieldable
{
public:
    bool bGateFireCall() const { return (Read<uint8_t>(uintptr_t(this) + 0x2681) >> 0x2) & 1; } // 0x2681:2 (Size: 0x1, Type: BoolProperty)
    FGameplayTag IsFiringGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2684); } // 0x2684 (Size: 0x4, Type: StructProperty)
    FVector MuzzleLocationOffset() const { return Read<FVector>(uintptr_t(this) + 0x2688); } // 0x2688 (Size: 0x18, Type: StructProperty)
    FGameplayTag ReloadingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x26a0); } // 0x26a0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ReloadAbilityEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x26a4); } // 0x26a4 (Size: 0x4, Type: StructProperty)
    FGameplayTag FireAbilityEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x26a8); } // 0x26a8 (Size: 0x4, Type: StructProperty)

    void SET_bGateFireCall(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2681); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x2681, B); } // 0x2681:2 (Size: 0x1, Type: BoolProperty)
    void SET_IsFiringGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2684, Value); } // 0x2684 (Size: 0x4, Type: StructProperty)
    void SET_MuzzleLocationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2688, Value); } // 0x2688 (Size: 0x18, Type: StructProperty)
    void SET_ReloadingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x26a0, Value); } // 0x26a0 (Size: 0x4, Type: StructProperty)
    void SET_ReloadAbilityEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x26a4, Value); } // 0x26a4 (Size: 0x4, Type: StructProperty)
    void SET_FireAbilityEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x26a8, Value); } // 0x26a8 (Size: 0x4, Type: StructProperty)
};

