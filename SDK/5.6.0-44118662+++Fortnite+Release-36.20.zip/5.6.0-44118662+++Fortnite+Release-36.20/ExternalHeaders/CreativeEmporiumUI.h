/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeEmporiumUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "Engine.h"
#include "ItemizationCoreRuntime.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "InputCore.h"

// Size: 0x1560
class UEmporiumBrowserFilterEntry : public UCommonButtonBase
{
public:
    UCommonTextBlock* TextBlock_FilterName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1530); } // 0x1530 (Size: 0x8, Type: ObjectProperty)
    bool bFilterActive() const { return Read<bool>(uintptr_t(this) + 0x1538); } // 0x1538 (Size: 0x1, Type: BoolProperty)
    UEmporiumBrowserTag* Tag() const { return Read<UEmporiumBrowserTag*>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x10, Type: TextProperty)

    void SET_TextBlock_FilterName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1530, Value); } // 0x1530 (Size: 0x8, Type: ObjectProperty)
    void SET_bFilterActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1538, Value); } // 0x1538 (Size: 0x1, Type: BoolProperty)
    void SET_Tag(const UEmporiumBrowserTag*& Value) { Write<UEmporiumBrowserTag*>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x10, Type: TextProperty)
};

// Size: 0x5a8
class UEmporiumBrowserFiltersPanel : public UCommonUserWidget
{
public:
    UClass* FilterSectionHeaderWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x8, Type: ClassProperty)
    UClass* FilterCategoryHeaderWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: ClassProperty)
    UClass* FilterHomeHeaderWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x8, Type: ClassProperty)
    UClass* FilterEntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ClassProperty)
    TArray<FFortEmporiumSortEntry> SortEntries() const { return Read<TArray<FFortEmporiumSortEntry>>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortEmporiumFilterEntry> FilterEntries() const { return Read<TArray<FFortEmporiumFilterEntry>>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortEmporiumPriceFilterEntry> PriceFilterEntries() const { return Read<TArray<FFortEmporiumPriceFilterEntry>>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> LicenseFilterEntries() const { return Read<TArray<FName>>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    FName DefaultCategoryFilter() const { return Read<FName>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x4, Type: NameProperty)
    uint8_t DefaultTagFilterMode() const { return Read<uint8_t>(uintptr_t(this) + 0x494); } // 0x494 (Size: 0x1, Type: EnumProperty)
    UCommonButtonBase* Button_SortAndFilter() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortCreativeContentBrowserTabPanelBase*> LastSelectedTab() const { return Read<TWeakObjectPtr<UFortCreativeContentBrowserTabPanelBase*>>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: WeakObjectProperty)

    void SET_FilterSectionHeaderWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x8, Type: ClassProperty)
    void SET_FilterCategoryHeaderWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: ClassProperty)
    void SET_FilterHomeHeaderWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x8, Type: ClassProperty)
    void SET_FilterEntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ClassProperty)
    void SET_SortEntries(const TArray<FFortEmporiumSortEntry>& Value) { Write<TArray<FFortEmporiumSortEntry>>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    void SET_FilterEntries(const TArray<FFortEmporiumFilterEntry>& Value) { Write<TArray<FFortEmporiumFilterEntry>>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x10, Type: ArrayProperty)
    void SET_PriceFilterEntries(const TArray<FFortEmporiumPriceFilterEntry>& Value) { Write<TArray<FFortEmporiumPriceFilterEntry>>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: ArrayProperty)
    void SET_LicenseFilterEntries(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultCategoryFilter(const FName& Value) { Write<FName>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x4, Type: NameProperty)
    void SET_DefaultTagFilterMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x494, Value); } // 0x494 (Size: 0x1, Type: EnumProperty)
    void SET_Button_SortAndFilter(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_LastSelectedTab(const TWeakObjectPtr<UFortCreativeContentBrowserTabPanelBase*>& Value) { Write<TWeakObjectPtr<UFortCreativeContentBrowserTabPanelBase*>>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x330
class UFortEmporiumFilterCategoryHeader : public UUserWidget
{
public:
    UEmporiumBrowserTag* Tag() const { return Read<UEmporiumBrowserTag*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)

    void SET_Tag(const UEmporiumBrowserTag*& Value) { Write<UEmporiumBrowserTag*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x340
class UFortEmporiumFiltersSubPanel : public UUserWidget
{
public:
    UClass* FilterEntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ClassProperty)
    UEmporiumBrowserFilterEntry* Button_All() const { return Read<UEmporiumBrowserFilterEntry*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UEmporiumBrowserFilterEntry* Button_LastSelected() const { return Read<UEmporiumBrowserFilterEntry*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* CachedItemTab() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)

    void SET_FilterEntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ClassProperty)
    void SET_Button_All(const UEmporiumBrowserFilterEntry*& Value) { Write<UEmporiumBrowserFilterEntry*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_LastSelected(const UEmporiumBrowserFilterEntry*& Value) { Write<UEmporiumBrowserFilterEntry*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedItemTab(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UFortEmporiumHomeEntryObjectWrapper : public UObject
{
public:
    uint8_t EntrySource() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    UFortEmporiumItemListTabPanel* TabPanel() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxItemsToShow() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)

    void SET_EntrySource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_TabPanel(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxItemsToShow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
};

// Size: 0x520
class UFortEmporiumHomeListEntry : public UUserWidget
{
public:
    UFortEmporiumHomeListView* ParentView() const { return Read<UFortEmporiumHomeListView*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxItemsToShow() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)
    UFortEmporiumItemListTabPanel* TabPanel() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_CategoryLabel() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UAthenaCreativeItemTileView* HomeListView_ItemOptions() const { return Read<UAthenaCreativeItemTileView*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_ParentView(const UFortEmporiumHomeListView*& Value) { Write<UFortEmporiumHomeListView*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxItemsToShow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
    void SET_TabPanel(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_CategoryLabel(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_HomeListView_ItemOptions(const UAthenaCreativeItemTileView*& Value) { Write<UAthenaCreativeItemTileView*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10d0
class UFortEmporiumHomeListView : public UCommonListView
{
public:
    TMap<UFortEmporiumItemListTabPanel*, UFortEmporiumHomeListEntry*> Map_TabToHomeList() const { return Read<TMap<UFortEmporiumItemListTabPanel*, UFortEmporiumHomeListEntry*>>(uintptr_t(this) + 0xee0); } // 0xee0 (Size: 0x50, Type: MapProperty)
    TArray<UFortEmporiumItemListTabPanel*> TabPanelList() const { return Read<TArray<UFortEmporiumItemListTabPanel*>>(uintptr_t(this) + 0xf30); } // 0xf30 (Size: 0x10, Type: ArrayProperty)
    UFortEmporiumItemListTabPanel* CurrentSelectionTab() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x10a8); } // 0x10a8 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumHomeListEntry* RecentItemsEntry() const { return Read<UFortEmporiumHomeListEntry*>(uintptr_t(this) + 0x10b8); } // 0x10b8 (Size: 0x8, Type: ObjectProperty)

    void SET_Map_TabToHomeList(const TMap<UFortEmporiumItemListTabPanel*, UFortEmporiumHomeListEntry*>& Value) { Write<TMap<UFortEmporiumItemListTabPanel*, UFortEmporiumHomeListEntry*>>(uintptr_t(this) + 0xee0, Value); } // 0xee0 (Size: 0x50, Type: MapProperty)
    void SET_TabPanelList(const TArray<UFortEmporiumItemListTabPanel*>& Value) { Write<TArray<UFortEmporiumItemListTabPanel*>>(uintptr_t(this) + 0xf30, Value); } // 0xf30 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentSelectionTab(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x10a8, Value); } // 0x10a8 (Size: 0x8, Type: ObjectProperty)
    void SET_RecentItemsEntry(const UFortEmporiumHomeListEntry*& Value) { Write<UFortEmporiumHomeListEntry*>(uintptr_t(this) + 0x10b8, Value); } // 0x10b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x508
class UFortEmporiumHomeTabPanel : public UFortCreativeContentBrowserTabPanelBase
{
public:
    FName FeaturedItemTag() const { return Read<FName>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x4, Type: NameProperty)
    UFortEmporiumHomeListView* FortEmporiumHomeListView_Options() const { return Read<UFortEmporiumHomeListView*>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: ObjectProperty)

    void SET_FeaturedItemTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x4, Type: NameProperty)
    void SET_FortEmporiumHomeListView_Options(const UFortEmporiumHomeListView*& Value) { Write<UFortEmporiumHomeListView*>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa8
class UFortEmporiumItem : public UFortItem
{
public:
    UFortEmporiumItemDefinition* ItemDefinition() const { return Read<UFortEmporiumItemDefinition*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_ItemDefinition(const UFortEmporiumItemDefinition*& Value) { Write<UFortEmporiumItemDefinition*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1b0
class UFortEmporiumItemDefinition : public UFortItemDefinition
{
public:
};

// Size: 0x390
class UFortEmporiumItemDetailsPanel : public UCommonUserWidget
{
public:
    FDataTableRowHandle ItemDetailTagsInputRowHandle() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: StructProperty)
    UItemDefinitionBase* CachedItemDefinition() const { return Read<UItemDefinitionBase*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UItemDefinitionBase* CachedParentDefinition() const { return Read<UItemDefinitionBase*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_Details() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemInfo* ItemDetails() const { return Read<UFortEmporiumItemInfo*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UAthenaInventoryItemInfo* LegacyItemDetails() const { return Read<UAthenaInventoryItemInfo*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_ItemDetailTagsInputRowHandle(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: StructProperty)
    void SET_CachedItemDefinition(const UItemDefinitionBase*& Value) { Write<UItemDefinitionBase*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedParentDefinition(const UItemDefinitionBase*& Value) { Write<UItemDefinitionBase*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Details(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemDetails(const UFortEmporiumItemInfo*& Value) { Write<UFortEmporiumItemInfo*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_LegacyItemDetails(const UAthenaInventoryItemInfo*& Value) { Write<UAthenaInventoryItemInfo*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x330
class UFortEmporiumItemInfo : public UCommonUserWidget
{
public:
    TArray<FName> HiddenTags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: ArrayProperty)

    void SET_HiddenTags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x48
class UFortEmporiumCategoryEntry : public UObject
{
public:
    FString Path() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString Hash() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)

    void SET_Path(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_Hash(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
};

// Size: 0xc40
class UFortEmporiumItemListMenu : public UCommonActivatableWidget
{
public:
    UClass* PanelDataClass() const { return Read<UClass*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ClassProperty)
    UDataTable* ItemListCategorySource() const { return Read<UDataTable*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UFortCreativeItemListPanelData* ItemListPanelData() const { return Read<UFortCreativeItemListPanelData*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UClass* InventoryTabClass() const { return Read<UClass*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ClassProperty)
    UClass* LevelManagementTabClass() const { return Read<UClass*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ClassProperty)
    UClass* HomeTabClass() const { return Read<UClass*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ClassProperty)
    UClass* InventoryTabButton() const { return Read<UClass*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ClassProperty)
    TMap<FName, FText> Map_CreativeBetaTagNames() const { return Read<TMap<FName, FText>>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings> Map_ToggleFilterFocusKeys() const { return Read<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings> Map_ToggleFilterSubPanelFocusKeys() const { return Read<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings> Map_CycleTagFilterModeModifierKeys() const { return Read<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings> Map_ClearTagFiltersModifierKeys() const { return Read<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings> Map_ToggleSidePanelDockingModifierKeys() const { return Read<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x50, Type: MapProperty)
    FKey ToggleSidePanelDockingKey() const { return Read<FKey>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x18, Type: StructProperty)
    FKey ToggleSubPanelMode() const { return Read<FKey>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x18, Type: StructProperty)
    FDataTableRowHandle FocusSearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ClearSearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle CycleSortInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RequestItemFocusInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x10, Type: StructProperty)
    UFortEmporiumItemListTabPanel* ChestTabPanel() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* VersePrefabsTabPanel() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x8, Type: ObjectProperty)
    UFortCreativeLevelManagementTabPanel* LevelManagementTabPanel() const { return Read<UFortCreativeLevelManagementTabPanel*>(uintptr_t(this) + 0x738); } // 0x738 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumHomeTabPanel* HomeTabPanel() const { return Read<UFortEmporiumHomeTabPanel*>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* FabTabPanel() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* SubItemsTabPanel() const { return Read<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    FName FabTabNameId() const { return Read<FName>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x4, Type: NameProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo() const { return Read<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0xf0, Type: StructProperty)
    FAthenaMapScreenContainerTabInfo MapScreenContainerTabInfo() const { return Read<FAthenaMapScreenContainerTabInfo>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x40, Type: StructProperty)
    bool bIsDefaultActiveTab() const { return Read<bool>(uintptr_t(this) + 0x890); } // 0x890 (Size: 0x1, Type: BoolProperty)
    bool bAddItemToInventoryOnEquip() const { return Read<bool>(uintptr_t(this) + 0x891); } // 0x891 (Size: 0x1, Type: BoolProperty)
    bool bLoadItemsOnInitialized() const { return Read<bool>(uintptr_t(this) + 0x892); } // 0x892 (Size: 0x1, Type: BoolProperty)
    int32_t LastUsedSlot() const { return Read<int32_t>(uintptr_t(this) + 0x894); } // 0x894 (Size: 0x4, Type: IntProperty)
    TMap<FName, UFortCreativeContentBrowserTabPanelBase*> TabMap() const { return Read<TMap<FName, UFortCreativeContentBrowserTabPanelBase*>>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x50, Type: MapProperty)
    TArray<UFortEmporiumItemDefinition*> EmporiumItemDefinitionList() const { return Read<TArray<UFortEmporiumItemDefinition*>>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, UFortEmporiumItemListTabPanel*> Map_ItemNameToTab() const { return Read<TMap<FName, UFortEmporiumItemListTabPanel*>>(uintptr_t(this) + 0xad0); } // 0xad0 (Size: 0x50, Type: MapProperty)
    UCommonVisibilitySwitcher* Switcher_SidePanels() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_Categories() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0xb28); } // 0xb28 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_ItemTabWarnings() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0xb30); } // 0xb30 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ChestEmpty() const { return Read<UOverlay*>(uintptr_t(this) + 0xb38); } // 0xb38 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_TabEmpty() const { return Read<UOverlay*>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_DownloadingFabCategories() const { return Read<UOverlay*>(uintptr_t(this) + 0xb48); } // 0xb48 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_FabCategoriesNotLoaded() const { return Read<UOverlay*>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_CommandBar() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ChestCommands() const { return Read<UOverlay*>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_VendCommands() const { return Read<UOverlay*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    UFortCreativeMenuQuickbar* MenuQuickbar_QuickBars() const { return Read<UFortCreativeMenuQuickbar*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ResetChest() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CreateChest() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_AddToQuickBar() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_OpenItem() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PlaceNow() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Equip() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_AddToChest() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Drop() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CreateLlama() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_RemoveFromChest() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_SearchFilters() const { return Read<UOverlay*>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    UCommonAnimatedSwitcher* Switcher_LeftPanel() const { return Read<UCommonAnimatedSwitcher*>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    UEmporiumBrowserFiltersPanel* FiltersPanel() const { return Read<UEmporiumBrowserFiltersPanel*>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumFiltersSubPanel* FiltersSubPanel() const { return Read<UFortEmporiumFiltersSubPanel*>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemDetailsPanel* SubTabItemDetailsPanel() const { return Read<UFortEmporiumItemDetailsPanel*>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x8, Type: ObjectProperty)
    UAthenaCustomizationPickerSortAndFilterBlade* Blade_SortAndFilter() const { return Read<UAthenaCustomizationPickerSortAndFilterBlade*>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemDetailsPanel* ItemDetailsSidePanel_DefaultSidePanel() const { return Read<UFortEmporiumItemDetailsPanel*>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_ProductPage() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ItemBrowser() const { return Read<UOverlay*>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemDetailsPanel* ItemProductPagePanel() const { return Read<UFortEmporiumItemDetailsPanel*>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_InventoryPermission() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EmporiumPanel() const { return Read<UOverlay*>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_InventoryNotAllowed() const { return Read<UOverlay*>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EditorDisconnected() const { return Read<UOverlay*>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_InitializingInventory() const { return Read<UOverlay*>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x8, Type: ObjectProperty)

    void SET_PanelDataClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ClassProperty)
    void SET_ItemListCategorySource(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemListPanelData(const UFortCreativeItemListPanelData*& Value) { Write<UFortCreativeItemListPanelData*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_InventoryTabClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ClassProperty)
    void SET_LevelManagementTabClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ClassProperty)
    void SET_HomeTabClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ClassProperty)
    void SET_InventoryTabButton(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ClassProperty)
    void SET_Map_CreativeBetaTagNames(const TMap<FName, FText>& Value) { Write<TMap<FName, FText>>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x50, Type: MapProperty)
    void SET_Map_ToggleFilterFocusKeys(const TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>& Value) { Write<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x50, Type: MapProperty)
    void SET_Map_ToggleFilterSubPanelFocusKeys(const TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>& Value) { Write<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x50, Type: MapProperty)
    void SET_Map_CycleTagFilterModeModifierKeys(const TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>& Value) { Write<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x50, Type: MapProperty)
    void SET_Map_ClearTagFiltersModifierKeys(const TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>& Value) { Write<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x50, Type: MapProperty)
    void SET_Map_ToggleSidePanelDockingModifierKeys(const TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>& Value) { Write<TMap<ECommonInputType, FFortEmporiumKeyEdgeMappings>>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x50, Type: MapProperty)
    void SET_ToggleSidePanelDockingKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x18, Type: StructProperty)
    void SET_ToggleSubPanelMode(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x18, Type: StructProperty)
    void SET_FocusSearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x10, Type: StructProperty)
    void SET_ClearSearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x10, Type: StructProperty)
    void SET_CycleSortInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x10, Type: StructProperty)
    void SET_RequestItemFocusInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x10, Type: StructProperty)
    void SET_ChestTabPanel(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x8, Type: ObjectProperty)
    void SET_VersePrefabsTabPanel(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x8, Type: ObjectProperty)
    void SET_LevelManagementTabPanel(const UFortCreativeLevelManagementTabPanel*& Value) { Write<UFortCreativeLevelManagementTabPanel*>(uintptr_t(this) + 0x738, Value); } // 0x738 (Size: 0x8, Type: ObjectProperty)
    void SET_HomeTabPanel(const UFortEmporiumHomeTabPanel*& Value) { Write<UFortEmporiumHomeTabPanel*>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x8, Type: ObjectProperty)
    void SET_FabTabPanel(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    void SET_SubItemsTabPanel(const UFortEmporiumItemListTabPanel*& Value) { Write<UFortEmporiumItemListTabPanel*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    void SET_FabTabNameId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x4, Type: NameProperty)
    void SET_TabButtonLabelInfo(const FFortTabButtonLabelInfo& Value) { Write<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0xf0, Type: StructProperty)
    void SET_MapScreenContainerTabInfo(const FAthenaMapScreenContainerTabInfo& Value) { Write<FAthenaMapScreenContainerTabInfo>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x40, Type: StructProperty)
    void SET_bIsDefaultActiveTab(const bool& Value) { Write<bool>(uintptr_t(this) + 0x890, Value); } // 0x890 (Size: 0x1, Type: BoolProperty)
    void SET_bAddItemToInventoryOnEquip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x891, Value); } // 0x891 (Size: 0x1, Type: BoolProperty)
    void SET_bLoadItemsOnInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x892, Value); } // 0x892 (Size: 0x1, Type: BoolProperty)
    void SET_LastUsedSlot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x894, Value); } // 0x894 (Size: 0x4, Type: IntProperty)
    void SET_TabMap(const TMap<FName, UFortCreativeContentBrowserTabPanelBase*>& Value) { Write<TMap<FName, UFortCreativeContentBrowserTabPanelBase*>>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x50, Type: MapProperty)
    void SET_EmporiumItemDefinitionList(const TArray<UFortEmporiumItemDefinition*>& Value) { Write<TArray<UFortEmporiumItemDefinition*>>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x10, Type: ArrayProperty)
    void SET_Map_ItemNameToTab(const TMap<FName, UFortEmporiumItemListTabPanel*>& Value) { Write<TMap<FName, UFortEmporiumItemListTabPanel*>>(uintptr_t(this) + 0xad0, Value); } // 0xad0 (Size: 0x50, Type: MapProperty)
    void SET_Switcher_SidePanels(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Categories(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0xb28, Value); } // 0xb28 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_ItemTabWarnings(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0xb30, Value); } // 0xb30 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_ChestEmpty(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xb38, Value); } // 0xb38 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_TabEmpty(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_DownloadingFabCategories(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xb48, Value); } // 0xb48 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_FabCategoriesNotLoaded(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_CommandBar(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_ChestCommands(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_VendCommands(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    void SET_MenuQuickbar_QuickBars(const UFortCreativeMenuQuickbar*& Value) { Write<UFortCreativeMenuQuickbar*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ResetChest(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CreateChest(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_AddToQuickBar(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_OpenItem(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PlaceNow(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Equip(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_AddToChest(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Drop(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CreateLlama(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_RemoveFromChest(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_SearchFilters(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_LeftPanel(const UCommonAnimatedSwitcher*& Value) { Write<UCommonAnimatedSwitcher*>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    void SET_FiltersPanel(const UEmporiumBrowserFiltersPanel*& Value) { Write<UEmporiumBrowserFiltersPanel*>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    void SET_FiltersSubPanel(const UFortEmporiumFiltersSubPanel*& Value) { Write<UFortEmporiumFiltersSubPanel*>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    void SET_SubTabItemDetailsPanel(const UFortEmporiumItemDetailsPanel*& Value) { Write<UFortEmporiumItemDetailsPanel*>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x8, Type: ObjectProperty)
    void SET_Blade_SortAndFilter(const UAthenaCustomizationPickerSortAndFilterBlade*& Value) { Write<UAthenaCustomizationPickerSortAndFilterBlade*>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemDetailsSidePanel_DefaultSidePanel(const UFortEmporiumItemDetailsPanel*& Value) { Write<UFortEmporiumItemDetailsPanel*>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_ProductPage(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_ItemBrowser(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemProductPagePanel(const UFortEmporiumItemDetailsPanel*& Value) { Write<UFortEmporiumItemDetailsPanel*>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_InventoryPermission(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_EmporiumPanel(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_InventoryNotAllowed(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_EditorDisconnected(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_InitializingInventory(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x818
class UFortEmporiumItemListTabPanel : public UFortCreativeContentBrowserTabPanelBase
{
public:
    UAthenaCreativeItemTileView* CreativeTileView_ItemOptions() const { return Read<UAthenaCreativeItemTileView*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Sort() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    FFortItemEntry CurrentItemEntry() const { return Read<FFortItemEntry>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x158, Type: StructProperty)
    TArray<FFortItemEntry> Items() const { return Read<TArray<FFortItemEntry>>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortItemEntry> SourceItems() const { return Read<TArray<FFortItemEntry>>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    UFortEmporiumItemListMenu* EmporiumItemListMenuParent() const { return Read<UFortEmporiumItemListMenu*>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x8, Type: ObjectProperty)

    void SET_CreativeTileView_ItemOptions(const UAthenaCreativeItemTileView*& Value) { Write<UAthenaCreativeItemTileView*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Sort(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentItemEntry(const FFortItemEntry& Value) { Write<FFortItemEntry>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x158, Type: StructProperty)
    void SET_Items(const TArray<FFortItemEntry>& Value) { Write<TArray<FFortItemEntry>>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x10, Type: ArrayProperty)
    void SET_SourceItems(const TArray<FFortItemEntry>& Value) { Write<TArray<FFortItemEntry>>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    void SET_EmporiumItemListMenuParent(const UFortEmporiumItemListMenu*& Value) { Write<UFortEmporiumItemListMenu*>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UEmporiumBrowserTag : public UObject
{
public:
    FName TagID() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)

    void SET_TagID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
class UFortEmporiumUtilities : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x20
struct FFortEmporiumPriceFilterEntry
{
public:
    FName ID() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    uint8_t Filter() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)

    void SET_ID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_Filter(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FFortEmporiumFilterEntry
{
public:
    FName ID() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FText TextRoot() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)

    void SET_ID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_TextRoot(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FFortEmporiumSortEntry
{
public:
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xe8
struct FFortEmporiumItemData
{
public:
    FString ID() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Title() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString Namespace() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FString EntityType() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString ThumbnailURL() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    float Price() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FString BaseCurrency() const { return Read<FString>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StrProperty)
    FString SketchfabUID() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    TArray<FName> TagList() const { return Read<TArray<FName>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t LicenseType() const { return Read<uint8_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: EnumProperty)
    bool bRequiresEntitlement() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)
    FString VersePath() const { return Read<FString>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StrProperty)
    TArray<FString> AssetIds() const { return Read<TArray<FString>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    int32_t FileSize() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)
    FString Seller() const { return Read<FString>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StrProperty)
    int32_t MaterialCount() const { return Read<int32_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: IntProperty)
    int32_t PolygonCount() const { return Read<int32_t>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: IntProperty)
    int32_t VertexCount() const { return Read<int32_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: IntProperty)
    int32_t ChildAssetCount() const { return Read<int32_t>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: IntProperty)

    void SET_ID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Title(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Namespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_EntityType(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_ThumbnailURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_Price(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_BaseCurrency(const FString& Value) { Write<FString>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StrProperty)
    void SET_SketchfabUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_TagList(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_LicenseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: EnumProperty)
    void SET_bRequiresEntitlement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
    void SET_VersePath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StrProperty)
    void SET_AssetIds(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_FileSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
    void SET_Seller(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StrProperty)
    void SET_MaterialCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: IntProperty)
    void SET_PolygonCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: IntProperty)
    void SET_VertexCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: IntProperty)
    void SET_ChildAssetCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FFortEmporiumKeyEdgeMappings
{
public:
    TArray<FKey> Keys() const { return Read<TArray<FKey>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Keys(const TArray<FKey>& Value) { Write<TArray<FKey>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FFortEmporiumItemLicenseData
{
public:
    FName ID() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FString Keyword() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FText Name() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    uint8_t License() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FString URL() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)

    void SET_ID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Keyword(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_Name(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_License(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_URL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FFortEmporiumFilterCategory
{
public:
    FName ID() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName ParentID() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    bool bIsTab() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bShowCategoryModal() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    TArray<FName> SubcategoryIDList() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParentID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_bIsTab(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bShowCategoryModal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_SubcategoryIDList(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

