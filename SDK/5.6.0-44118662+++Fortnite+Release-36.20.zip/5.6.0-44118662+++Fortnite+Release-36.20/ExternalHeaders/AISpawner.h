/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AISpawner
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x58
class UFortGameFeatureAction_AddSpawnerDeviceBindingTrack : public UGameFeatureAction
{
public:
    FSoftClassPath SpawnerDeviceClassPath() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FSoftClassPath BindingTrackClassPath() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_SpawnerDeviceClassPath(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_BindingTrackClassPath(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x2b0
class UAISpawnerPreviewerComponent : public UChildActorComponent
{
public:
    UClass* PlayerMannequinClass() const { return Read<UClass*>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: ClassProperty)
    UClass* DefaultCustomAnimationBPClass() const { return Read<UClass*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ClassProperty)
    float RotationWhenFacingY() const { return Read<float>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: FloatProperty)

    void SET_PlayerMannequinClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultCustomAnimationBPClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ClassProperty)
    void SET_RotationWhenFacingY(const float& Value) { Write<float>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4b8
class AFortAthenaMutator_AISpawner : public AFortAthenaMutator_GameModeBase
{
public:
};

