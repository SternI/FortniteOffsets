/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamInLobbyUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FMJamInLobbyRuntime.h"
#include "Engine.h"

// Size: 0xa8
class UJamInLobbyOpenGlobalControlsSubsystem : public UFortLocalPlayerSubsystem
{
public:
    FDataTableRowHandle InputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)
    TWeakObjectPtr<AJamInLobbyPlayspace*> LocalPlayerPlayspace() const { return Read<TWeakObjectPtr<AJamInLobbyPlayspace*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)

    void SET_InputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
    void SET_LocalPlayerPlayspace(const TWeakObjectPtr<AJamInLobbyPlayspace*>& Value) { Write<TWeakObjectPtr<AJamInLobbyPlayspace*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
};

