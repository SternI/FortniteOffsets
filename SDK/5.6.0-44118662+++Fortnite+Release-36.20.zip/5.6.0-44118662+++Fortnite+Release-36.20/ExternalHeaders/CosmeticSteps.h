/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticSteps
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xc8
class UBP_FortCosmeticStep_ApplyBeanCD_C : public UFortCosmeticStep_ApplyBeanCD
{
public:
};

