/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayDebugger
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "InputCore.h"
#include "CoreUObject.h"

// Size: 0x360
class AGameplayDebuggerCategoryReplicator : public AActor
{
public:
    APlayerController* OwnerPC() const { return Read<APlayerController*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    FGameplayDebuggerNetPack ReplicatedData() const { return Read<FGameplayDebuggerNetPack>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x18, Type: StructProperty)
    FGameplayDebuggerDebugActor DebugActor() const { return Read<FGameplayDebuggerDebugActor>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: StructProperty)
    FGameplayDebuggerVisLogSync VisLogSync() const { return Read<FGameplayDebuggerVisLogSync>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: StructProperty)
    UGameplayDebuggerRenderingComponent* RenderingComp() const { return Read<UGameplayDebuggerRenderingComponent*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)

    void SET_OwnerPC(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    void SET_ReplicatedData(const FGameplayDebuggerNetPack& Value) { Write<FGameplayDebuggerNetPack>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x18, Type: StructProperty)
    void SET_DebugActor(const FGameplayDebuggerDebugActor& Value) { Write<FGameplayDebuggerDebugActor>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: StructProperty)
    void SET_VisLogSync(const FGameplayDebuggerVisLogSync& Value) { Write<FGameplayDebuggerVisLogSync>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: StructProperty)
    void SET_RenderingComp(const UGameplayDebuggerRenderingComponent*& Value) { Write<UGameplayDebuggerRenderingComponent*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x258
class UGameplayDebuggerConfig : public UObject
{
public:
    FKey ActivationKey() const { return Read<FKey>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FKey CategoryRowNextKey() const { return Read<FKey>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FKey CategoryRowPrevKey() const { return Read<FKey>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot0() const { return Read<FKey>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot1() const { return Read<FKey>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot2() const { return Read<FKey>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot3() const { return Read<FKey>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot4() const { return Read<FKey>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot5() const { return Read<FKey>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot6() const { return Read<FKey>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot7() const { return Read<FKey>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot8() const { return Read<FKey>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot9() const { return Read<FKey>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x18, Type: StructProperty)
    float DebugCanvasPaddingLeft() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)
    float DebugCanvasPaddingRight() const { return Read<float>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: FloatProperty)
    float DebugCanvasPaddingTop() const { return Read<float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: FloatProperty)
    float DebugCanvasPaddingBottom() const { return Read<float>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x4, Type: FloatProperty)
    bool bDebugCanvasEnableTextShadow() const { return Read<bool>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayDebuggerCategoryConfig> Categories() const { return Read<TArray<FGameplayDebuggerCategoryConfig>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayDebuggerExtensionConfig> Extensions() const { return Read<TArray<FGameplayDebuggerExtensionConfig>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x10, Type: ArrayProperty)

    void SET_ActivationKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CategoryRowNextKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_CategoryRowPrevKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot0(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot1(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot2(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot3(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot4(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot5(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot6(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot7(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot8(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x18, Type: StructProperty)
    void SET_CategorySlot9(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x18, Type: StructProperty)
    void SET_DebugCanvasPaddingLeft(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
    void SET_DebugCanvasPaddingRight(const float& Value) { Write<float>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: FloatProperty)
    void SET_DebugCanvasPaddingTop(const float& Value) { Write<float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: FloatProperty)
    void SET_DebugCanvasPaddingBottom(const float& Value) { Write<float>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x4, Type: FloatProperty)
    void SET_bDebugCanvasEnableTextShadow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x1, Type: BoolProperty)
    void SET_Categories(const TArray<FGameplayDebuggerCategoryConfig>& Value) { Write<TArray<FGameplayDebuggerCategoryConfig>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x10, Type: ArrayProperty)
    void SET_Extensions(const TArray<FGameplayDebuggerExtensionConfig>& Value) { Write<TArray<FGameplayDebuggerExtensionConfig>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UGameplayDebuggerUserSettings : public UDeveloperSettings
{
public:
    bool bEnableGameplayDebuggerInEditor() const { return (Read<uint8_t>(uintptr_t(this) + 0x30) >> 0x0) & 1; } // 0x30:0 (Size: 0x1, Type: BoolProperty)
    float MaxViewDistance() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float MaxViewAngle() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    TSet<FName> EnabledCategories() const { return Read<TSet<FName>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: SetProperty)
    int32_t FontSize() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)

    void SET_bEnableGameplayDebuggerInEditor(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x30); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x30, B); } // 0x30:0 (Size: 0x1, Type: BoolProperty)
    void SET_MaxViewDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_MaxViewAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_EnabledCategories(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: SetProperty)
    void SET_FontSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
};

// Size: 0x88
class UGameplayDebuggerLocalController : public UObject
{
public:
    AGameplayDebuggerCategoryReplicator* CachedReplicator() const { return Read<AGameplayDebuggerCategoryReplicator*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    AGameplayDebuggerPlayerManager* CachedPlayerManager() const { return Read<AGameplayDebuggerPlayerManager*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    AActor* DebugActorCandidate() const { return Read<AActor*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UFont* HUDFont() const { return Read<UFont*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_CachedReplicator(const AGameplayDebuggerCategoryReplicator*& Value) { Write<AGameplayDebuggerCategoryReplicator*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedPlayerManager(const AGameplayDebuggerPlayerManager*& Value) { Write<AGameplayDebuggerPlayerManager*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugActorCandidate(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_HUDFont(const UFont*& Value) { Write<UFont*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2d8
class AGameplayDebuggerPlayerManager : public AActor
{
public:
    TArray<FGameplayDebuggerPlayerData> PlayerData() const { return Read<TArray<FGameplayDebuggerPlayerData>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<AGameplayDebuggerCategoryReplicator*> PendingRegistrations() const { return Read<TArray<AGameplayDebuggerCategoryReplicator*>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)

    void SET_PlayerData(const TArray<FGameplayDebuggerPlayerData>& Value) { Write<TArray<FGameplayDebuggerPlayerData>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    void SET_PendingRegistrations(const TArray<AGameplayDebuggerCategoryReplicator*>& Value) { Write<TArray<AGameplayDebuggerCategoryReplicator*>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x5f0
class UGameplayDebuggerRenderingComponent : public UDebugDrawComponent
{
public:
};

// Size: 0x28
struct FGameplayDebuggerDataPackRPCParams
{
public:
    FName CategoryName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t DataPackIdx() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FGameplayDebuggerDataPackHeader Header() const { return Read<FGameplayDebuggerDataPackHeader>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<char> Data() const { return Read<TArray<char>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_CategoryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_DataPackIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Header(const FGameplayDebuggerDataPackHeader& Value) { Write<FGameplayDebuggerDataPackHeader>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Data(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FGameplayDebuggerDataPackHeader
{
public:
    int16_t DataVersion() const { return Read<int16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t SyncCounter() const { return Read<int16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: Int16Property)
    int32_t DataSize() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t DataOffset() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    bool bIsCompressed() const { return (Read<uint8_t>(uintptr_t(this) + 0xc) >> 0x0) & 1; } // 0xc:0 (Size: 0x1, Type: BoolProperty)

    void SET_DataVersion(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: Int16Property)
    void SET_SyncCounter(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: Int16Property)
    void SET_DataSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_DataOffset(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_bIsCompressed(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc, B); } // 0xc:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FGameplayDebuggerCategoryData
{
public:
    FName CategoryName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FString> TextLines() const { return Read<TArray<FString>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayDebuggerShape> Shapes() const { return Read<TArray<FGameplayDebuggerShape>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayDebuggerDataPackHeader> DataPacks() const { return Read<TArray<FGameplayDebuggerDataPackHeader>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_CategoryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_TextLines(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Shapes(const TArray<FGameplayDebuggerShape>& Value) { Write<TArray<FGameplayDebuggerShape>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_DataPacks(const TArray<FGameplayDebuggerDataPackHeader>& Value) { Write<TArray<FGameplayDebuggerDataPackHeader>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FGameplayDebuggerShape
{
public:
    TArray<FVector> ShapeData() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FColor Color() const { return Read<FColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: EnumProperty)

    void SET_ShapeData(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Color(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FGameplayDebuggerNetPack
{
public:
    AGameplayDebuggerCategoryReplicator* Owner() const { return Read<AGameplayDebuggerCategoryReplicator*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayDebuggerCategoryData> SavedData() const { return Read<TArray<FGameplayDebuggerCategoryData>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Owner(const AGameplayDebuggerCategoryReplicator*& Value) { Write<AGameplayDebuggerCategoryReplicator*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SavedData(const TArray<FGameplayDebuggerCategoryData>& Value) { Write<TArray<FGameplayDebuggerCategoryData>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FGameplayDebuggerDebugActor
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FName ActorName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    int16_t SyncCounter() const { return Read<int16_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x2, Type: Int16Property)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_SyncCounter(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x2, Type: Int16Property)
};

// Size: 0x10
struct FGameplayDebuggerVisLogSync
{
public:
    FString DeviceIDs() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_DeviceIDs(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x30
struct FGameplayDebuggerInputConfig
{
public:
    FString ConfigName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FKey Key() const { return Read<FKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    bool bModShift() const { return (Read<uint8_t>(uintptr_t(this) + 0x28) >> 0x0) & 1; } // 0x28:0 (Size: 0x1, Type: BoolProperty)
    bool bModCtrl() const { return (Read<uint8_t>(uintptr_t(this) + 0x28) >> 0x1) & 1; } // 0x28:1 (Size: 0x1, Type: BoolProperty)
    bool bModAlt() const { return (Read<uint8_t>(uintptr_t(this) + 0x28) >> 0x2) & 1; } // 0x28:2 (Size: 0x1, Type: BoolProperty)
    bool bModCmd() const { return (Read<uint8_t>(uintptr_t(this) + 0x28) >> 0x3) & 1; } // 0x28:3 (Size: 0x1, Type: BoolProperty)

    void SET_ConfigName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Key(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_bModShift(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x28, B); } // 0x28:0 (Size: 0x1, Type: BoolProperty)
    void SET_bModCtrl(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x28, B); } // 0x28:1 (Size: 0x1, Type: BoolProperty)
    void SET_bModAlt(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x28, B); } // 0x28:2 (Size: 0x1, Type: BoolProperty)
    void SET_bModCmd(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x28, B); } // 0x28:3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FGameplayDebuggerCategoryConfig
{
public:
    FString CategoryName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t SlotIdx() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t ActiveInGame() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t ActiveInSimulate() const { return Read<uint8_t>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: EnumProperty)
    uint8_t Hidden() const { return Read<uint8_t>(uintptr_t(this) + 0x16); } // 0x16 (Size: 0x1, Type: EnumProperty)
    bool bOverrideSlotIdx() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x0) & 1; } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayDebuggerInputConfig> InputHandlers() const { return Read<TArray<FGameplayDebuggerInputConfig>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_CategoryName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_SlotIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_ActiveInGame(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_ActiveInSimulate(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: EnumProperty)
    void SET_Hidden(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x16, Value); } // 0x16 (Size: 0x1, Type: EnumProperty)
    void SET_bOverrideSlotIdx(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    void SET_InputHandlers(const TArray<FGameplayDebuggerInputConfig>& Value) { Write<TArray<FGameplayDebuggerInputConfig>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FGameplayDebuggerExtensionConfig
{
public:
    FString ExtensionName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t UseExtension() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    TArray<FGameplayDebuggerInputConfig> InputHandlers() const { return Read<TArray<FGameplayDebuggerInputConfig>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ExtensionName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UseExtension(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_InputHandlers(const TArray<FGameplayDebuggerInputConfig>& Value) { Write<TArray<FGameplayDebuggerInputConfig>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FGameplayDebuggerPlayerData
{
public:
    UGameplayDebuggerLocalController* Controller() const { return Read<UGameplayDebuggerLocalController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UInputComponent* InputComponent() const { return Read<UInputComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    AGameplayDebuggerCategoryReplicator* Replicator() const { return Read<AGameplayDebuggerCategoryReplicator*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Controller(const UGameplayDebuggerLocalController*& Value) { Write<UGameplayDebuggerLocalController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_InputComponent(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Replicator(const AGameplayDebuggerCategoryReplicator*& Value) { Write<AGameplayDebuggerCategoryReplicator*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

