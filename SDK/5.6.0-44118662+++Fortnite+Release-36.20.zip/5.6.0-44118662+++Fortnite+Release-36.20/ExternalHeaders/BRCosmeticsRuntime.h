/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BRCosmeticsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0x8d0
class USquidGlistenLiftDairyGliderAnimInstance : public UFortGliderAnimInstance
{
public:
    TSoftObjectPtr<USkeletalMesh> PackMatchSkel() const { return Read<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x20, Type: SoftObjectProperty)
    bool bPackMatch() const { return Read<bool>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x1, Type: BoolProperty)
    bool bIsCosmeticPreview() const { return Read<bool>(uintptr_t(this) + 0x8c9); } // 0x8c9 (Size: 0x1, Type: BoolProperty)
    bool bCanTransitionClosedToOpenInto() const { return Read<bool>(uintptr_t(this) + 0x8ca); } // 0x8ca (Size: 0x1, Type: BoolProperty)
    bool bCanTransitionIdleOpenToClosed() const { return Read<bool>(uintptr_t(this) + 0x8cb); } // 0x8cb (Size: 0x1, Type: BoolProperty)
    bool bCanTransitionOpenIntoToClosed() const { return Read<bool>(uintptr_t(this) + 0x8cc); } // 0x8cc (Size: 0x1, Type: BoolProperty)

    void SET_PackMatchSkel(const TSoftObjectPtr<USkeletalMesh>& Value) { Write<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bPackMatch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCosmeticPreview(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8c9, Value); } // 0x8c9 (Size: 0x1, Type: BoolProperty)
    void SET_bCanTransitionClosedToOpenInto(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8ca, Value); } // 0x8ca (Size: 0x1, Type: BoolProperty)
    void SET_bCanTransitionIdleOpenToClosed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8cb, Value); } // 0x8cb (Size: 0x1, Type: BoolProperty)
    void SET_bCanTransitionOpenIntoToClosed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8cc, Value); } // 0x8cc (Size: 0x1, Type: BoolProperty)
};

