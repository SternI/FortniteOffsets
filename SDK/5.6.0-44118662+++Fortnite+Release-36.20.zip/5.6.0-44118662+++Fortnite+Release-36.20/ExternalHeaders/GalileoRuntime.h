/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GalileoRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x850
class UGalileoLobsterLayerAnimInstance : public UFortItemLayerAnimInstance_Lobster
{
public:
    float PelvisTwistAlpha() const { return Read<float>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x4, Type: FloatProperty)
    float CustomPelvisTwist() const { return Read<float>(uintptr_t(this) + 0x7e4); } // 0x7e4 (Size: 0x4, Type: FloatProperty)
    float ResultingPitch() const { return Read<float>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x4, Type: FloatProperty)
    double BlendLowerBodyFloat() const { return Read<double>(uintptr_t(this) + 0x7f0); } // 0x7f0 (Size: 0x8, Type: DoubleProperty)
    double IsMeleeGuardingFloat() const { return Read<double>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x8, Type: DoubleProperty)
    double ResultingYaw() const { return Read<double>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x8, Type: DoubleProperty)
    bool bIsUsingPowerAO() const { return Read<bool>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x1, Type: BoolProperty)
    bool bIsDoubleJumpFall() const { return Read<bool>(uintptr_t(this) + 0x809); } // 0x809 (Size: 0x1, Type: BoolProperty)
    bool bAO_BlendIn() const { return Read<bool>(uintptr_t(this) + 0x80a); } // 0x80a (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer InMeleeTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x20, Type: StructProperty)
    FGameplayTag PassengerTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x4, Type: StructProperty)
    FGameplayTag InMotorcycleTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x834); } // 0x834 (Size: 0x4, Type: StructProperty)
    FGameplayTag HoverActiveTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x838); } // 0x838 (Size: 0x4, Type: StructProperty)
    UAnimMontage* GalileoLobsterEquipMAnimMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x8, Type: ObjectProperty)

    void SET_PelvisTwistAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x4, Type: FloatProperty)
    void SET_CustomPelvisTwist(const float& Value) { Write<float>(uintptr_t(this) + 0x7e4, Value); } // 0x7e4 (Size: 0x4, Type: FloatProperty)
    void SET_ResultingPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x4, Type: FloatProperty)
    void SET_BlendLowerBodyFloat(const double& Value) { Write<double>(uintptr_t(this) + 0x7f0, Value); } // 0x7f0 (Size: 0x8, Type: DoubleProperty)
    void SET_IsMeleeGuardingFloat(const double& Value) { Write<double>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x8, Type: DoubleProperty)
    void SET_ResultingYaw(const double& Value) { Write<double>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsUsingPowerAO(const bool& Value) { Write<bool>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x1, Type: BoolProperty)
    void SET_bIsDoubleJumpFall(const bool& Value) { Write<bool>(uintptr_t(this) + 0x809, Value); } // 0x809 (Size: 0x1, Type: BoolProperty)
    void SET_bAO_BlendIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80a, Value); } // 0x80a (Size: 0x1, Type: BoolProperty)
    void SET_InMeleeTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x20, Type: StructProperty)
    void SET_PassengerTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x4, Type: StructProperty)
    void SET_InMotorcycleTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x834, Value); } // 0x834 (Size: 0x4, Type: StructProperty)
    void SET_HoverActiveTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x838, Value); } // 0x838 (Size: 0x4, Type: StructProperty)
    void SET_GalileoLobsterEquipMAnimMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x8, Type: ObjectProperty)
};

