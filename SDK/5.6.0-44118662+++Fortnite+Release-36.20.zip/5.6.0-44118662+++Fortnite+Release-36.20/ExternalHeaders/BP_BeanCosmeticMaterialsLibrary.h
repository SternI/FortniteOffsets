/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_BeanCosmeticMaterialsLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UBP_BeanCosmeticMaterialsLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

