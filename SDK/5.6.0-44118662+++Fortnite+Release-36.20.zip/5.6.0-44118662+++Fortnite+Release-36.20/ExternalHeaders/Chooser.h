/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Chooser
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x40
class UChooserParameterBool_ContextProperty : public UObject
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
class UChooserColumnBool : public UObject
{
public:
    TScriptInterface<Class> InputValue() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    TArray<bool> RowValues() const { return Read<TArray<bool>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    void SET_RowValues(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UChooserParameterEnum_ContextProperty : public UObject
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
class UChooserColumnEnum : public UObject
{
public:
    TScriptInterface<Class> InputValue() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    TArray<FChooserEnumRowData> RowValues() const { return Read<TArray<FChooserEnumRowData>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    void SET_RowValues(const TArray<FChooserEnumRowData>& Value) { Write<TArray<FChooserEnumRowData>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UFloatAutoPopulator : public UObject
{
public:
};

// Size: 0x40
class UChooserParameterFloat_ContextProperty : public UObject
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
class UChooserColumnFloatRange : public UObject
{
public:
    TScriptInterface<Class> InputValue() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    TArray<FChooserFloatRangeRowData> RowValues() const { return Read<TArray<FChooserFloatRangeRowData>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    void SET_RowValues(const TArray<FChooserFloatRangeRowData>& Value) { Write<TArray<FChooserFloatRangeRowData>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UChooserParameterGameplayTag_ContextProperty : public UObject
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
class UChooserColumnGameplayTag : public UObject
{
public:
    TScriptInterface<Class> InputValue() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    uint8_t TagMatchType() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    TArray<FGameplayTagContainer> RowValues() const { return Read<TArray<FGameplayTagContainer>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
    void SET_TagMatchType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_RowValues(const TArray<FGameplayTagContainer>& Value) { Write<TArray<FGameplayTagContainer>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UChooserColumn : public UInterface
{
public:
};

// Size: 0x28
class UChooserParameterBool : public UInterface
{
public:
};

// Size: 0x28
class UChooserParameterEnum : public UInterface
{
public:
};

// Size: 0x28
class UChooserParameterFloat : public UInterface
{
public:
};

// Size: 0x28
class UChooserParameterGameplayTag : public UInterface
{
public:
};

// Size: 0x28
class UHasContextClass : public UInterface
{
public:
};

// Size: 0x28
class UObjectChooser : public UInterface
{
public:
};

// Size: 0x38
class UObjectChooser_Asset : public UObject
{
public:
    UObject* Asset() const { return Read<UObject*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_Asset(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa0
class UChooserTable : public UObject
{
public:
    UChooserTable* RootChooser() const { return Read<UChooserTable*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    FInstancedStruct FallbackResult() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> CookedResults() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ColumnsStructs() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    UClass* OutputObjectType() const { return Read<UClass*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ClassProperty)
    TArray<FInstancedStruct> ContextData() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_RootChooser(const UChooserTable*& Value) { Write<UChooserTable*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_FallbackResult(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_CookedResults(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_ColumnsStructs(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_OutputObjectType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ClassProperty)
    void SET_ContextData(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UObjectChooser_EvaluateChooser : public UObject
{
public:
    UChooserTable* Chooser() const { return Read<UChooserTable*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_Chooser(const UChooserTable*& Value) { Write<UChooserTable*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UChooserColumnMenuContext : public UObject
{
public:
};

// Size: 0x28
class UChooserFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x8
struct FChooserParameterBase
{
public:
};

// Size: 0x8
struct FChooserParameterBoolBase : public FChooserParameterBase
{
public:
};

// Size: 0x48
struct FBoolContextProperty : public FChooserParameterBoolBase
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserPropertyBinding Binding() const { return Read<FChooserPropertyBinding>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Binding(const FChooserPropertyBinding& Value) { Write<FChooserPropertyBinding>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
};

// Size: 0x30
struct FChooserPropertyBinding
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t ContextIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    bool IsBoundToRoot() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ContextIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_IsBoundToRoot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FChooserColumnBase
{
public:
};

// Size: 0x28
struct FBoolColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<EBoolColumnCellValue> RowValuesWithAny() const { return Read<TArray<EBoolColumnCellValue>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValuesWithAny(const TArray<EBoolColumnCellValue>& Value) { Write<TArray<EBoolColumnCellValue>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FChooserEnumPropertyBinding : public FChooserPropertyBinding
{
public:
};

// Size: 0x30
struct FChooserObjectPropertyBinding : public FChooserPropertyBinding
{
public:
};

// Size: 0x30
struct FChooserStructPropertyBinding : public FChooserPropertyBinding
{
public:
};

// Size: 0x4
struct FContextObjectTypeBase
{
public:
};

// Size: 0x10
struct FContextObjectTypeClass : public FContextObjectTypeBase
{
public:
    UClass* Class() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)

    void SET_Class(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x10
struct FContextObjectTypeStruct : public FContextObjectTypeBase
{
public:
    UScriptStruct* Struct() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Struct(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FAnimCurveOverride
{
public:
    FName CurveName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float CurveValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_CurveValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FAnimCurveOverrideList
{
public:
    TArray<FAnimCurveOverride> Values() const { return Read<TArray<FAnimCurveOverride>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint32_t Hash() const { return Read<uint32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: UInt32Property)

    void SET_Values(const TArray<FAnimCurveOverride>& Value) { Write<TArray<FAnimCurveOverride>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Hash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x40
struct FChooserPlayerSettings
{
public:
    bool bMirror() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float StartTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bForceLooping() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float PlaybackRate() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    FAnimCurveOverrideList CurveOverrides() const { return Read<FAnimCurveOverrideList>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    UBlendProfile* BlendProfile() const { return Read<UBlendProfile*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    uint8_t BlendOption() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    bool bUseInertialBlend() const { return Read<bool>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: BoolProperty)

    void SET_bMirror(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_StartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bForceLooping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_PlaybackRate(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_CurveOverrides(const FAnimCurveOverrideList& Value) { Write<FAnimCurveOverrideList>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_BlendProfile(const UBlendProfile*& Value) { Write<UBlendProfile*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendOption(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_bUseInertialBlend(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FChooserParameterEnumBase : public FChooserParameterBase
{
public:
};

// Size: 0x48
struct FEnumContextProperty : public FChooserParameterEnumBase
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserEnumPropertyBinding Binding() const { return Read<FChooserEnumPropertyBinding>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Binding(const FChooserEnumPropertyBinding& Value) { Write<FChooserEnumPropertyBinding>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
};

// Size: 0x8
struct FChooserEnumRowData
{
public:
    char Value() const { return Read<char>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: ByteProperty)

    void SET_Value(const char& Value) { Write<char>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x8
struct FEnumColumnBase : public FChooserColumnBase
{
public:
};

// Size: 0x28
struct FEnumColumn : public FEnumColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserEnumRowData> RowValues() const { return Read<TArray<FChooserEnumRowData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FChooserEnumRowData>& Value) { Write<TArray<FChooserEnumRowData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FChooserFloatDistanceRowData
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
struct FFloatDistanceColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    double MaxDistance() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    float CostMultiplier() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bFilterOverMaxDistance() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bWrapInput() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)
    double MinValue() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    double MaxValue() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    TArray<FChooserFloatDistanceRowData> RowValues() const { return Read<TArray<FChooserFloatDistanceRowData>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_MaxDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_CostMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_bFilterOverMaxDistance(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_bWrapInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
    void SET_MinValue(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxValue(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_RowValues(const TArray<FChooserFloatDistanceRowData>& Value) { Write<TArray<FChooserFloatDistanceRowData>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FChooserParameterFloatBase : public FChooserParameterBase
{
public:
};

// Size: 0x48
struct FFloatContextProperty : public FChooserParameterFloatBase
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserPropertyBinding Binding() const { return Read<FChooserPropertyBinding>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Binding(const FChooserPropertyBinding& Value) { Write<FChooserPropertyBinding>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
};

// Size: 0xc
struct FChooserFloatRangeRowData
{
public:
    float Min() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Max() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bNoMin() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bNoMax() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Max(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bNoMin(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bNoMax(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FFloatRangeColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    bool bWrapInput() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    double MinValue() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    double MaxValue() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    TArray<FChooserFloatRangeRowData> RowValues() const { return Read<TArray<FChooserFloatRangeRowData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_bWrapInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_MinValue(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxValue(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_RowValues(const TArray<FChooserFloatRangeRowData>& Value) { Write<TArray<FChooserFloatRangeRowData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FChooserParameterGameplayTagBase : public FChooserParameterBase
{
public:
};

// Size: 0x48
struct FGameplayTagContextProperty : public FChooserParameterGameplayTagBase
{
public:
    TArray<FName> PropertyBindingChain() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserPropertyBinding Binding() const { return Read<FChooserPropertyBinding>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)

    void SET_PropertyBindingChain(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Binding(const FChooserPropertyBinding& Value) { Write<FChooserPropertyBinding>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
};

// Size: 0x30
struct FGameplayTagColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t TagMatchType() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t TagMatchDirection() const { return Read<uint8_t>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: EnumProperty)
    bool bMatchExact() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    bool bInvertMatchingLogic() const { return Read<bool>(uintptr_t(this) + 0x1b); } // 0x1b (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayTagContainer> RowValues() const { return Read<TArray<FGameplayTagContainer>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_TagMatchType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_TagMatchDirection(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: EnumProperty)
    void SET_bMatchExact(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET_bInvertMatchingLogic(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1b, Value); } // 0x1b (Size: 0x1, Type: BoolProperty)
    void SET_RowValues(const TArray<FGameplayTagContainer>& Value) { Write<TArray<FGameplayTagContainer>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FGameplayTagQueryColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FGameplayTagQuery> RowValues() const { return Read<TArray<FGameplayTagQuery>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FGameplayTagQuery>& Value) { Write<TArray<FGameplayTagQuery>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FChooserParameterObjectBase : public FChooserParameterBase
{
public:
};

// Size: 0x50
struct FChooserRandomizationContext
{
public:
};

// Size: 0x8
struct FChooserParameterRandomizeBase : public FChooserParameterBase
{
public:
};

// Size: 0x8
struct FChooserParameterStructBase : public FChooserParameterBase
{
public:
};

// Size: 0x8
struct FChooserEvaluationInputObject
{
public:
};

// Size: 0x78
struct FChooserEvaluationContext
{
public:
};

// Size: 0x8
struct FObjectChooserBase
{
public:
};

// Size: 0x4
struct FChooserMultiEnumRowData
{
public:
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x28
struct FMultiEnumColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserMultiEnumRowData> RowValues() const { return Read<TArray<FChooserMultiEnumRowData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FChooserMultiEnumRowData>& Value) { Write<TArray<FChooserMultiEnumRowData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAssetChooser : public FObjectChooserBase
{
public:
    UObject* Asset() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Asset(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FSoftAssetChooser : public FObjectChooserBase
{
public:
    TSoftObjectPtr<UObject> Asset() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Asset(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x10
struct FClassChooser : public FObjectChooserBase
{
public:
    UClass* Class() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)

    void SET_Class(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x10
struct FChooserObjectClassRowData
{
public:
    UClass* Value() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)

    void SET_Value(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
struct FObjectClassColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserObjectClassRowData> RowValues() const { return Read<TArray<FChooserObjectClassRowData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FChooserObjectClassRowData>& Value) { Write<TArray<FChooserObjectClassRowData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FObjectContextProperty : public FChooserParameterObjectBase
{
public:
    FChooserObjectPropertyBinding Binding() const { return Read<FChooserObjectPropertyBinding>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x30, Type: StructProperty)

    void SET_Binding(const FChooserObjectPropertyBinding& Value) { Write<FChooserObjectPropertyBinding>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x30, Type: StructProperty)
};

// Size: 0x28
struct FChooserObjectRowData
{
public:
    TSoftObjectPtr<UObject> Value() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Value(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x28
struct FObjectColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserObjectRowData> RowValues() const { return Read<TArray<FChooserObjectRowData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FChooserObjectRowData>& Value) { Write<TArray<FChooserObjectRowData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FOutputBoolColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    bool bFallbackValue() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    TArray<bool> RowValues() const { return Read<TArray<bool>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_bFallbackValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_RowValues(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FChooserOutputEnumRowData
{
public:
    char Value() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)

    void SET_Value(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x30
struct FOutputEnumColumn : public FEnumColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FChooserOutputEnumRowData FallbackValue() const { return Read<FChooserOutputEnumRowData>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: StructProperty)
    TArray<FChooserOutputEnumRowData> RowValues() const { return Read<TArray<FChooserOutputEnumRowData>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_FallbackValue(const FChooserOutputEnumRowData& Value) { Write<FChooserOutputEnumRowData>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: StructProperty)
    void SET_RowValues(const TArray<FChooserOutputEnumRowData>& Value) { Write<TArray<FChooserOutputEnumRowData>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FOutputFloatColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    double FallbackValue() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    TArray<double> RowValues() const { return Read<TArray<double>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_FallbackValue(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_RowValues(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FChooserOutputObjectRowData
{
public:
    FInstancedStruct Value() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FOutputObjectColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserOutputObjectRowData> RowValues() const { return Read<TArray<FChooserOutputObjectRowData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FChooserOutputObjectRowData FallbackValue() const { return Read<FChooserOutputObjectRowData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FChooserOutputObjectRowData>& Value) { Write<TArray<FChooserOutputObjectRowData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_FallbackValue(const FChooserOutputObjectRowData& Value) { Write<FChooserOutputObjectRowData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FStructContextProperty : public FChooserParameterStructBase
{
public:
    FChooserStructPropertyBinding Binding() const { return Read<FChooserStructPropertyBinding>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x30, Type: StructProperty)

    void SET_Binding(const FChooserStructPropertyBinding& Value) { Write<FChooserStructPropertyBinding>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x30, Type: StructProperty)
};

// Size: 0x38
struct FOutputStructColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FInstancedStruct FallbackValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> RowValues() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_FallbackValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_RowValues(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRandomizeContextProperty : public FChooserParameterRandomizeBase
{
public:
    FChooserPropertyBinding Binding() const { return Read<FChooserPropertyBinding>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x30, Type: StructProperty)

    void SET_Binding(const FChooserPropertyBinding& Value) { Write<FChooserPropertyBinding>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x30, Type: StructProperty)
};

// Size: 0x30
struct FRandomizeColumn : public FChooserColumnBase
{
public:
    FInstancedStruct InputValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    float RepeatProbabilityMultiplier() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float EqualCostThreshold() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    TArray<float> RowValues() const { return Read<TArray<float>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_InputValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RepeatProbabilityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_EqualCostThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_RowValues(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x248
struct FAnimNode_ChooserPlayer : public FAnimNode_BlendStack_Standalone
{
public:
    FInstancedStruct Chooser() const { return Read<FInstancedStruct>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: StructProperty)
    UMirrorDataTable* MirrorDataTable() const { return Read<UMirrorDataTable*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    float BlendSpaceX() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    float BlendSpaceY() const { return Read<float>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: FloatProperty)
    FChooserPlayerSettings DefaultSettings() const { return Read<FChooserPlayerSettings>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x40, Type: StructProperty)
    TArray<FInstancedStruct> ChooserContextDefinition() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    bool bStartFromMatchingPose() const { return Read<bool>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: BoolProperty)

    void SET_Chooser(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: StructProperty)
    void SET_MirrorDataTable(const UMirrorDataTable*& Value) { Write<UMirrorDataTable*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendSpaceX(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_BlendSpaceY(const float& Value) { Write<float>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultSettings(const FChooserPlayerSettings& Value) { Write<FChooserPlayerSettings>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x40, Type: StructProperty)
    void SET_ChooserContextDefinition(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_bStartFromMatchingPose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FNestedChooser : public FObjectChooserBase
{
public:
    UChooserTable* Chooser() const { return Read<UChooserTable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Chooser(const UChooserTable*& Value) { Write<UChooserTable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FEvaluateChooser : public FObjectChooserBase
{
public:
    UChooserTable* Chooser() const { return Read<UChooserTable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Chooser(const UChooserTable*& Value) { Write<UChooserTable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

