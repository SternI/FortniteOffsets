/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayEffectTemplates
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa68
class UGET_PeriodicDamageParent_C : public UGET_AfflictedParent_C
{
public:
};

// Size: 0xa68
class UGET_DirectDamage_LootOnDestroy_C : public UGET_DamageParent_C
{
public:
};

// Size: 0xa68
class UGET_DirectCreatureDamage_C : public UGET_DirectPhysicalDamage_C
{
public:
};

// Size: 0xa68
class UGET_DirectVehicleDamage_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xa68
class UGET_FatalDamage_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xa68
class UGET_AfflictedParent_C : public UGET_DamageParent_C
{
public:
};

// Size: 0xa68
class UGET_PeriodicPhysicalDamage_C : public UGET_PeriodicDamageParent_C
{
public:
};

// Size: 0xa68
class UGET_PeriodicEnergyDamage_C : public UGET_PeriodicPhysicalDamage_C
{
public:
};

// Size: 0xa68
class UGet_DirectDamageParent_C : public UGET_DamageParent_C
{
public:
};

// Size: 0xa68
class UGET_DamageParent_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGET_DirectEnvironmentDamage_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xa68
class UGET_FallingDamage_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xa68
class UGET_TagContainer_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGET_Status_FullHealth_C : public UGET_TagContainer_C
{
public:
};

// Size: 0xa68
class UGET_CooldownDuration_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGET_DirectPhysicalDamage_C : public UGet_DirectDamageParent_C
{
public:
};

