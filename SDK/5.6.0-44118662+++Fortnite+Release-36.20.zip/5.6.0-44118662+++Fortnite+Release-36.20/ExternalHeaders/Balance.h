/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Balance
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x3d0
class ABP_FortPhysicsObjectManager_C : public AFortPhysicsObjectManager
{
public:
};

// Size: 0xa68
class UGE_PhysicsObject_ImpactDamage_Default_C : public UGameplayEffect
{
public:
};

// Size: 0xf8
class UBP_PhysicsCollisionHandler_C : public UFortPhysicsCollisionHandler
{
public:
};

// Size: 0xa68
class UGE_HidePlayerPawn_Default_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Map_Fortitude_To_Health_C : public UGameplayEffect
{
public:
};

