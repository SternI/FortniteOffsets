/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CherrySmokeDangerRoomRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayAbilities.h"

// Size: 0x28
class UCherrySmokeDangerRoomCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x790
class ACherrySmokeDangerRoomPlayspace : public AFortPlayspace
{
public:
    FCherrySmokeDangerRoomMinigameState MinigameState() const { return Read<FCherrySmokeDangerRoomMinigameState>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x2, Type: StructProperty)
    FScalableFloat NumMinigameTargets() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat NumMinigameCollectables() const { return Read<FScalableFloat>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x28, Type: StructProperty)
    int32_t RemainingObjectives() const { return Read<int32_t>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x4, Type: IntProperty)

    void SET_MinigameState(const FCherrySmokeDangerRoomMinigameState& Value) { Write<FCherrySmokeDangerRoomMinigameState>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x2, Type: StructProperty)
    void SET_NumMinigameTargets(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x28, Type: StructProperty)
    void SET_NumMinigameCollectables(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x28, Type: StructProperty)
    void SET_RemainingObjectives(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1
struct FCherrySmokeDangerRoomObjectiveComplete
{
public:
    bool bIsCollectable() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bIsCollectable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FCherrySmokeDangerRoomMinigameActivated
{
public:
};

// Size: 0x2
struct FCherrySmokeDangerRoomMinigameState
{
public:
    bool bIsActive() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWasSuccessful() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_bIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bWasSuccessful(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

