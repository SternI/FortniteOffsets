/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityVideoScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UI.h"
#include "Engine.h"
#include "UMG.h"
#include "UIKit.h"

// Size: 0x470
class UActivityVideoScreen_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: StructProperty)
    USafeZone* SafeZone_SkipButton() const { return Read<USafeZone*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_Skip() const { return Read<UWBP_UIKit_Button_Quiet_C*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UActivityVideoCycleWidget_C* ActivityVideoCycleWidget() const { return Read<UActivityVideoCycleWidget_C*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: StructProperty)
    void SET_SafeZone_SkipButton(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Skip(const UWBP_UIKit_Button_Quiet_C*& Value) { Write<UWBP_UIKit_Button_Quiet_C*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityVideoCycleWidget(const UActivityVideoCycleWidget_C*& Value) { Write<UActivityVideoCycleWidget_C*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
};

