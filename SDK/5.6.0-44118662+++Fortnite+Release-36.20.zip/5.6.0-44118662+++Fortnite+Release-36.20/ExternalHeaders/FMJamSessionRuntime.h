/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamSessionRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
#include "Engine.h"

// Size: 0x28
class UJamSessionInterface : public UInterface
{
public:
};

// Size: 0x28
class UJamSessionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x38
struct FJamMusicSlotSearchParams
{
public:
    FUniqueNetIdRepl ContextPlayer() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    uint8_t SpecificLoopType() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t AutojammerMode() const { return Read<uint8_t>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: EnumProperty)

    void SET_ContextPlayer(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_SpecificLoopType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_AutojammerMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: EnumProperty)
};

