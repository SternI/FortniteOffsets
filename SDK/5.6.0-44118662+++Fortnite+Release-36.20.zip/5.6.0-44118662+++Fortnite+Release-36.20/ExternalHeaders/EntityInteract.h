/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityInteract
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x28
class UEntityInteractLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x410
class AEntityInteractProxyActor : public AActor
{
public:
    FText InteractText() const { return Read<FText>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: TextProperty)
    FText CannotInteractText() const { return Read<FText>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: TextProperty)
    FTimerHandle CoolDownTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: StructProperty)
    TMap<AController*, UFortControllerComponent_Interaction*> PerControllerOverriddenInteractDurationPlayerComponents() const { return Read<TMap<AController*, UFortControllerComponent_Interaction*>>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x50, Type: MapProperty)
    TMap<AController*, UFortControllerComponent_Interaction*> PerControllerCooldownTimerHandlePlayerComponents() const { return Read<TMap<AController*, UFortControllerComponent_Interaction*>>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x50, Type: MapProperty)
    TArray<AController*> InteractingControllers() const { return Read<TArray<AController*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UObject*> CachedInteractComponent() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: WeakObjectProperty)
    float ForwardInteractOffset() const { return Read<float>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x4, Type: FloatProperty)
    float RightInteractOffset() const { return Read<float>(uintptr_t(this) + 0x404); } // 0x404 (Size: 0x4, Type: FloatProperty)
    bool bInteractEnabled() const { return Read<bool>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x1, Type: BoolProperty)

    void SET_InteractText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: TextProperty)
    void SET_CannotInteractText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: TextProperty)
    void SET_CoolDownTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: StructProperty)
    void SET_PerControllerOverriddenInteractDurationPlayerComponents(const TMap<AController*, UFortControllerComponent_Interaction*>& Value) { Write<TMap<AController*, UFortControllerComponent_Interaction*>>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x50, Type: MapProperty)
    void SET_PerControllerCooldownTimerHandlePlayerComponents(const TMap<AController*, UFortControllerComponent_Interaction*>& Value) { Write<TMap<AController*, UFortControllerComponent_Interaction*>>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x50, Type: MapProperty)
    void SET_InteractingControllers(const TArray<AController*>& Value) { Write<TArray<AController*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedInteractComponent(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ForwardInteractOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x4, Type: FloatProperty)
    void SET_RightInteractOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x404, Value); } // 0x404 (Size: 0x4, Type: FloatProperty)
    void SET_bInteractEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x360
class AFortAthenaMutator_EntityInteract : public AFortAthenaMutator
{
public:
};

// Size: 0x30
struct FInteractComponentBackup
{
public:
};

