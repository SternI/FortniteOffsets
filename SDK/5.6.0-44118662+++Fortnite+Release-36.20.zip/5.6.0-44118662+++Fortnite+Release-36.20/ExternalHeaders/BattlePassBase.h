/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattlePassBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"

// Size: 0x308
class UFortBattlePassLevelCount : public UUserWidget
{
public:
    UCommonTextBlock* Text_LevelCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_LevelCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2f8
class URebootRallyQuestPanel : public UUserWidget
{
public:
};

