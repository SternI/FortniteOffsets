/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalShrineGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x9f0
class AFirePetalShrineBase : public ABuildingGameplayActor
{
public:
};

// Size: 0x618
class AFirePetalShrineSpriteSpawner : public AFortAthenaLivingWorldVolume
{
public:
    TArray<TWeakObjectPtr<AActor*>> SpawnedActors() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x10, Type: ArrayProperty)

    void SET_SpawnedActors(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x10, Type: ArrayProperty)
};

