/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserArrowButton
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "UMG.h"
#include "UIKit.h"

// Size: 0x15a1
class UActivityBrowserArrowButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Block_Outline_C* WBP_UIKit_Block_Outline() const { return Read<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Backplate_C* WBP_UIKit_Backplate() const { return Read<UWBP_UIKit_Backplate_C*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    USpacer* S_ButtonSize() const { return Read<USpacer*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GP_ButtonWrapper() const { return Read<UGridPanel*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UImage* BgFade() const { return Read<UImage*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UImage* Arrow() const { return Read<UImage*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* RowActive() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* RowInactive() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    bool Flip() const { return Read<bool>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x1, Type: BoolProperty)
    bool InputActionOnSide() const { return Read<bool>(uintptr_t(this) + 0x1591); } // 0x1591 (Size: 0x1, Type: BoolProperty)
    bool IsActive() const { return Read<bool>(uintptr_t(this) + 0x1592); } // 0x1592 (Size: 0x1, Type: BoolProperty)
    double ActiveRatio() const { return Read<double>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: DoubleProperty)
    bool ShowArrowBackgroundFade() const { return Read<bool>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_Block_Outline(const UWBP_UIKit_Block_Outline_C*& Value) { Write<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_UIKit_Backplate(const UWBP_UIKit_Backplate_C*& Value) { Write<UWBP_UIKit_Backplate_C*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_S_ButtonSize(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_GP_ButtonWrapper(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_BgFade(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_Arrow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    void SET_Hover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    void SET_RowActive(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_RowInactive(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_Flip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x1, Type: BoolProperty)
    void SET_InputActionOnSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1591, Value); } // 0x1591 (Size: 0x1, Type: BoolProperty)
    void SET_IsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1592, Value); } // 0x1592 (Size: 0x1, Type: BoolProperty)
    void SET_ActiveRatio(const double& Value) { Write<double>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: DoubleProperty)
    void SET_ShowArrowBackgroundFade(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x1, Type: BoolProperty)
};

