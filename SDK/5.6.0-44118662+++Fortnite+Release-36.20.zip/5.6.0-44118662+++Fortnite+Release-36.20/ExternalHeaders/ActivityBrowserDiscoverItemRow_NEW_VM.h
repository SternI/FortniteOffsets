/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserDiscoverItemRow_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "TabScreens.h"
#include "ActivityBrowserArrowButton.h"
#include "CommonUI.h"
#include "Rows.h"
#include "UMG.h"

// Size: 0x528
class UActivityBrowserDiscoverItemRow_NEW_VM_C : public UFortDiscoverItemBrowserRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: StructProperty)
    UWBP_Row_Header_C* WBP_Row_Header() const { return Read<UWBP_Row_Header_C*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UWBP_LoadingMorePages_C* WBP_LoadingMorePages() const { return Read<UWBP_LoadingMorePages_C*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VBContent() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UImage* InactiveOverlayDim() const { return Read<UImage*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* InactiveDarken() const { return Read<UCommonBorder*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowActiveInactiveAnim() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveUpOutOfViewAnim() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveDownIntoView() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnPeek() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    TArray<UActivityBrowserArrowButton_C*> ArrowButtons() const { return Read<TArray<UActivityBrowserArrowButton_C*>>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    FName FontHoverAnimateParam() const { return Read<FName>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam() const { return Read<FName>(uintptr_t(this) + 0x4f4); } // 0x4f4 (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim() const { return Read<bool>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x1, Type: BoolProperty)
    double LoadingMoreDisplayDelay() const { return Read<double>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible() const { return Read<bool>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive() const { return Read<bool>(uintptr_t(this) + 0x509); } // 0x509 (Size: 0x1, Type: BoolProperty)
    FTimerHandle LoadingMoreDelayTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: StructProperty)
    FString RowPanelName() const { return Read<FString>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x10, Type: StrProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: StructProperty)
    void SET_WBP_Row_Header(const UWBP_Row_Header_C*& Value) { Write<UWBP_Row_Header_C*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_LoadingMorePages(const UWBP_LoadingMorePages_C*& Value) { Write<UWBP_LoadingMorePages_C*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_VBContent(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_InactiveOverlayDim(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_InactiveDarken(const UCommonBorder*& Value) { Write<UCommonBorder*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRowActiveInactiveAnim(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRowMoveUpOutOfViewAnim(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRowMoveDownIntoView(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnPeek(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnLoadingMore(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    void SET_ArrowButtons(const TArray<UActivityBrowserArrowButton_C*>& Value) { Write<TArray<UActivityBrowserArrowButton_C*>>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    void SET_FontHoverAnimateParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x4, Type: NameProperty)
    void SET_FontPressedAnimateParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4f4, Value); } // 0x4f4 (Size: 0x4, Type: NameProperty)
    void SET_IsWaitingForInactiveAnim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingMoreDisplayDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: DoubleProperty)
    void SET_IsLoadingMoreVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x1, Type: BoolProperty)
    void SET_IsLoadingMoreQueryActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x509, Value); } // 0x509 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingMoreDelayTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: StructProperty)
    void SET_RowPanelName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x10, Type: StrProperty)
};

// Size: 0x510
class UActivityBrowserDiscoverItemRow_C : public UFortDiscoverItemBrowserRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VBContent() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* LoadingMoreTilesHB() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UImage* InactiveOverlayDim() const { return Read<UImage*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* InactiveDarken() const { return Read<UCommonBorder*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowActiveInactiveAnim() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveUpOutOfViewAnim() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveDownIntoView() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnPeek() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    TArray<UActivityBrowserArrowButton_C*> ArrowButtons() const { return Read<TArray<UActivityBrowserArrowButton_C*>>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x10, Type: ArrayProperty)
    FName FontHoverAnimateParam() const { return Read<FName>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam() const { return Read<FName>(uintptr_t(this) + 0x4ec); } // 0x4ec (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim() const { return Read<bool>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x1, Type: BoolProperty)
    double LoadingMoreDisplayDelay() const { return Read<double>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible() const { return Read<bool>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive() const { return Read<bool>(uintptr_t(this) + 0x501); } // 0x501 (Size: 0x1, Type: BoolProperty)
    FTimerHandle LoadingMoreDelayTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: StructProperty)
    void SET_VBContent(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_LoadingMoreTilesHB(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_InactiveOverlayDim(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_InactiveDarken(const UCommonBorder*& Value) { Write<UCommonBorder*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRowActiveInactiveAnim(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRowMoveUpOutOfViewAnim(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRowMoveDownIntoView(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnPeek(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnLoadingMore(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_ArrowButtons(const TArray<UActivityBrowserArrowButton_C*>& Value) { Write<TArray<UActivityBrowserArrowButton_C*>>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x10, Type: ArrayProperty)
    void SET_FontHoverAnimateParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x4, Type: NameProperty)
    void SET_FontPressedAnimateParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4ec, Value); } // 0x4ec (Size: 0x4, Type: NameProperty)
    void SET_IsWaitingForInactiveAnim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingMoreDisplayDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: DoubleProperty)
    void SET_IsLoadingMoreVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x1, Type: BoolProperty)
    void SET_IsLoadingMoreQueryActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x501, Value); } // 0x501 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingMoreDelayTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: StructProperty)
};

