/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataAssets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x80
class UPDA_RankConfig_C : public UPrimaryDataAsset
{
public:
    TMap<int32_t, TSoftObjectPtr<UTexture2D*>> RankIcons() const { return Read<TMap<int32_t, TSoftObjectPtr<UTexture2D*>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_RankIcons(const TMap<int32_t, TSoftObjectPtr<UTexture2D*>>& Value) { Write<TMap<int32_t, TSoftObjectPtr<UTexture2D*>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

