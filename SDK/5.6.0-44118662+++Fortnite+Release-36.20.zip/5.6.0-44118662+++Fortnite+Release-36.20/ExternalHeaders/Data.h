/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Data
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x16
struct FGameplayEvent_IntercomBroadcastRequest
{
public:
    FGameplayTag ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    USoundBase* Sound_5_E6C156894D5A0E2986A423BDC3A9A16C() const { return Read<USoundBase*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    int32_t Priority_8_9D44E8734E35A1B467EFD28590B1B0B9() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    bool IsBlocking_15_691F1A6045C7C88EA3C3F7AFD0EA541F() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    bool QueueifOccupied_17_4342B4C348EAAE8774A2088805EC7A55() const { return Read<bool>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: BoolProperty)

    void SET_ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Sound_5_E6C156894D5A0E2986A423BDC3A9A16C(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Priority_8_9D44E8734E35A1B467EFD28590B1B0B9(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_IsBlocking_15_691F1A6045C7C88EA3C3F7AFD0EA541F(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_QueueifOccupied_17_4342B4C348EAAE8774A2088805EC7A55(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FIntercomChannelQueue
{
public:
    TArray<FGameplayEvent_IntercomBroadcastRequest> BroadcastQueue_6_2E5A2A644F60CA2CEBCE13800EBD31C5() const { return Read<TArray<FGameplayEvent_IntercomBroadcastRequest>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_BroadcastQueue_6_2E5A2A644F60CA2CEBCE13800EBD31C5(const TArray<FGameplayEvent_IntercomBroadcastRequest>& Value) { Write<TArray<FGameplayEvent_IntercomBroadcastRequest>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FIntercomChannelListeners
{
public:
    TArray<USoundSourceBus*> SourceBuses_13_2E5A2A644F60CA2CEBCE13800EBD31C5() const { return Read<TArray<USoundSourceBus*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_SourceBuses_13_2E5A2A644F60CA2CEBCE13800EBD31C5(const TArray<USoundSourceBus*>& Value) { Write<TArray<USoundSourceBus*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FGameplayEvent_IntercomStopBroadcast
{
public:
    FGameplayTag ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    double FadeOutDuration_19_4342B4C348EAAE8774A2088805EC7A55() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_FadeOutDuration_19_4342B4C348EAAE8774A2088805EC7A55(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xe0
class UDialogVM_BuyRewards_C : public UUIKitDialogViewModel
{
public:
};

