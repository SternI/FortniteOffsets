/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserCategoryTile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "UMG.h"

// Size: 0x15a8
class UActivityBrowserCategoryTile_C : public UFortActivityCategoryTile
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: StructProperty)
    UImage* Image_Tile() const { return Read<UImage*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* TileHover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: StructProperty)
    void SET_Image_Tile(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_TileHover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
};

