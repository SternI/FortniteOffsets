/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FN1NativeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0xc0
class UVerseFortniteBusVolumeComponent : public UActorComponent
{
public:
    AVolume* DropZone() const { return Read<AVolume*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_DropZone(const AVolume*& Value) { Write<AVolume*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UVerseFortniteBattlebus : public UObject
{
public:
};

// Size: 0x368
class AFortVerseBusMutator : public AFortAthenaMutator
{
public:
};

// Size: 0x28
class UVerseFortGameMode : public UObject
{
public:
};

// Size: 0xc8
class UVerseFortniteStormVolumeComponent : public UActorComponent
{
public:
    TArray<FVFortStormVolume> SafeZoneVolumes() const { return Read<TArray<FVFortStormVolume>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)

    void SET_SafeZoneVolumes(const TArray<FVFortStormVolume>& Value) { Write<TArray<FVFortStormVolume>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UVerseFortniteStorm : public UObject
{
public:
};

// Size: 0x10
struct FVFortStormVolume
{
public:
    AVolume* VolumeActor() const { return Read<AVolume*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float RejectionChance() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_VolumeActor(const AVolume*& Value) { Write<AVolume*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_RejectionChance(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

