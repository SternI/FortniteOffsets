/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CollectionMapShared
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "FortniteUI.h"
#include "CoreUObject.h"

// Size: 0x720
class UAthenaCollectionScreenMapBase : public UAthenaCollectionScreenBase
{
public:
    UAthenaFullScreenMapBase* MapWidget() const { return Read<UAthenaFullScreenMapBase*>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    UClass* CollectionIconType() const { return Read<UClass*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ClassProperty)
    TMap<FGameplayTag, UAthenaMapCollectionIcon*> MapCollectionIcons() const { return Read<TMap<FGameplayTag, UAthenaMapCollectionIcon*>>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x50, Type: MapProperty)

    void SET_MapWidget(const UAthenaFullScreenMapBase*& Value) { Write<UAthenaFullScreenMapBase*>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    void SET_CollectionIconType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ClassProperty)
    void SET_MapCollectionIcons(const TMap<FGameplayTag, UAthenaMapCollectionIcon*>& Value) { Write<TMap<FGameplayTag, UAthenaMapCollectionIcon*>>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x3c0
class UAthenaMapCollectionIcon : public UAthenaMapNavigableIconCustom
{
public:
};

