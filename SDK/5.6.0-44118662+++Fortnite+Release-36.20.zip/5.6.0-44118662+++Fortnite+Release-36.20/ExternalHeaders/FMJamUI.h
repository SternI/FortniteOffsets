/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
#include "Engine.h"
#include "UMG.h"
#include "CoreUObject.h"

// Size: 0xe0
class UJamControllerComponent_EmotePickerOverrider : public UControllerComponent
{
public:
};

// Size: 0x2f0
class AJamDynamicUIDirector : public ASparksDynamicUIDirector
{
public:
};

// Size: 0x450
class UJamEmoteWheelOverlay : public UCommonActivatableWidget
{
public:
};

// Size: 0x510
class UJamHUDBase : public UFortNullHUD
{
public:
};

// Size: 0xa0
class UJamMusicSlotManagerVM : public UFortPerUserViewModel
{
public:
    TArray<UJamMusicSlotVM*> MusicSlots() const { return Read<TArray<UJamMusicSlotVM*>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_MusicSlots(const TArray<UJamMusicSlotVM*>& Value) { Write<TArray<UJamMusicSlotVM*>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd8
class UJamMusicSlotVM : public UMVVMViewModelBase
{
public:
    FUniqueNetIdRepl OwningPlayerID() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x30, Type: StructProperty)
    FText Title() const { return Read<FText>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: TextProperty)
    FText Artist() const { return Read<FText>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: TextProperty)
    uint8_t UserMode() const { return Read<uint8_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayState() const { return Read<uint8_t>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: EnumProperty)
    uint8_t ResolveState() const { return Read<uint8_t>(uintptr_t(this) + 0xba); } // 0xba (Size: 0x1, Type: EnumProperty)
    uint8_t LoopType() const { return Read<uint8_t>(uintptr_t(this) + 0xbb); } // 0xbb (Size: 0x1, Type: EnumProperty)
    uint8_t FocusState() const { return Read<uint8_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x1, Type: EnumProperty)

    void SET_OwningPlayerID(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x30, Type: StructProperty)
    void SET_Title(const FText& Value) { Write<FText>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: TextProperty)
    void SET_Artist(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: TextProperty)
    void SET_UserMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: EnumProperty)
    void SET_PlayState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: EnumProperty)
    void SET_ResolveState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xba, Value); } // 0xba (Size: 0x1, Type: EnumProperty)
    void SET_LoopType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xbb, Value); } // 0xbb (Size: 0x1, Type: EnumProperty)
    void SET_FocusState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x1, Type: EnumProperty)
};

// Size: 0x150
class UJamUIManagerComponent_SongIndicators : public UFortControllerComponent
{
public:
    UClass* JamSongIndicatorClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    FUserWidgetPool IndicatorPool() const { return Read<FUserWidgetPool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x88, Type: StructProperty)

    void SET_JamSongIndicatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_IndicatorPool(const FUserWidgetPool& Value) { Write<FUserWidgetPool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x88, Type: StructProperty)
};

// Size: 0x430
class UJamSongIndicator : public UFortActorIndicatorWidget
{
public:
};

