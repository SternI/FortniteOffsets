/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FeralCorgiUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteUI.h"

// Size: 0x478
class UFeralCorgiPurchaseModal : public UCommonActivatableWidget
{
public:
    UInputComponent* IntroModalInputComp() const { return Read<UInputComponent*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle AcceptActionBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x10, Type: StructProperty)
    FPrimaryContentSetup PrimaryContentSetup() const { return Read<FPrimaryContentSetup>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x4, Type: StructProperty)

    void SET_IntroModalInputComp(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_AcceptActionBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x10, Type: StructProperty)
    void SET_PrimaryContentSetup(const FPrimaryContentSetup& Value) { Write<FPrimaryContentSetup>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x4, Type: StructProperty)
};

