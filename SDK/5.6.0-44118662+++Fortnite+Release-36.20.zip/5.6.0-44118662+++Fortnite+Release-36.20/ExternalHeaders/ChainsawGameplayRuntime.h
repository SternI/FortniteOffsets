/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChainsawGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x400
class UChainsawAnimInstance : public UAnimInstance
{
public:
    double ChainPlayRate() const { return Read<double>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    bool bIsSpinning() const { return Read<bool>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x1, Type: BoolProperty)
    bool bIsSprinting() const { return Read<bool>(uintptr_t(this) + 0x3e1); } // 0x3e1 (Size: 0x1, Type: BoolProperty)
    bool bIsEquip() const { return Read<bool>(uintptr_t(this) + 0x3e2); } // 0x3e2 (Size: 0x1, Type: BoolProperty)
    bool bIsNotEquip() const { return Read<bool>(uintptr_t(this) + 0x3e3); } // 0x3e3 (Size: 0x1, Type: BoolProperty)
    bool bIsFalling() const { return Read<bool>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x1, Type: BoolProperty)
    bool bIsSliding() const { return Read<bool>(uintptr_t(this) + 0x3e5); } // 0x3e5 (Size: 0x1, Type: BoolProperty)
    FGameplayTag SprintTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: StructProperty)
    FGameplayTag EquippedTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x4, Type: StructProperty)
    FGameplayTag FallingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x4, Type: StructProperty)
    FGameplayTag SlidingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x4, Type: StructProperty)

    void SET_ChainPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsSpinning(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSprinting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e1, Value); } // 0x3e1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEquip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e2, Value); } // 0x3e2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsNotEquip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e3, Value); } // 0x3e3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFalling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSliding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e5, Value); } // 0x3e5 (Size: 0x1, Type: BoolProperty)
    void SET_SprintTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: StructProperty)
    void SET_EquippedTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x4, Type: StructProperty)
    void SET_FallingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x4, Type: StructProperty)
    void SET_SlidingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x58
class UChainsawAttributeSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData Overheat() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)

    void SET_Overheat(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
};

// Size: 0x1410
class UChainsawLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bIsChainsawScooter() const { return Read<bool>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x1, Type: BoolProperty)
    float LeanX() const { return Read<float>(uintptr_t(this) + 0x130c); } // 0x130c (Size: 0x4, Type: FloatProperty)
    float LeanY() const { return Read<float>(uintptr_t(this) + 0x1310); } // 0x1310 (Size: 0x4, Type: FloatProperty)
    bool bIsFallingIntoScooter() const { return Read<bool>(uintptr_t(this) + 0x1314); } // 0x1314 (Size: 0x1, Type: BoolProperty)
    bool bIsScooterFalling() const { return Read<bool>(uintptr_t(this) + 0x1315); } // 0x1315 (Size: 0x1, Type: BoolProperty)
    bool bIsNotChainsawScooter() const { return Read<bool>(uintptr_t(this) + 0x1316); } // 0x1316 (Size: 0x1, Type: BoolProperty)
    float CustomMeleeTwist() const { return Read<float>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x4, Type: FloatProperty)
    bool bIsNotEquip() const { return Read<bool>(uintptr_t(this) + 0x131c); } // 0x131c (Size: 0x1, Type: BoolProperty)
    float ChainsawScooterPelvisOffset() const { return Read<float>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x4, Type: FloatProperty)
    bool bIsUpperBodyEquip() const { return Read<bool>(uintptr_t(this) + 0x1324); } // 0x1324 (Size: 0x1, Type: BoolProperty)
    double ForwardSpeedInterp() const { return Read<double>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x8, Type: DoubleProperty)
    double LateralSpeedInterp() const { return Read<double>(uintptr_t(this) + 0x1330); } // 0x1330 (Size: 0x8, Type: DoubleProperty)
    bool bIsSlidingMovementMode() const { return Read<bool>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x1, Type: BoolProperty)
    bool bIsOtherMovementMode() const { return Read<bool>(uintptr_t(this) + 0x1339); } // 0x1339 (Size: 0x1, Type: BoolProperty)
    FGameplayTag StartedSharpTurnTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x133c); } // 0x133c (Size: 0x4, Type: StructProperty)
    FGameplayTag EndedSharpTurnTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1340); } // 0x1340 (Size: 0x4, Type: StructProperty)
    FGameplayTag FallingIntoScooterTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1344); } // 0x1344 (Size: 0x4, Type: StructProperty)
    FGameplayTag HoldingScooterButtonTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1348); } // 0x1348 (Size: 0x4, Type: StructProperty)
    FGameplayTag ScooteringTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x134c); } // 0x134c (Size: 0x4, Type: StructProperty)
    FGameplayTag ZipliningOnSplineTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1350); } // 0x1350 (Size: 0x4, Type: StructProperty)
    FGameplayTag SurfaceSwimmingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1354); } // 0x1354 (Size: 0x4, Type: StructProperty)
    FGameplayTag ParachutingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1358); } // 0x1358 (Size: 0x4, Type: StructProperty)
    FGameplayTag SkydivingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x135c); } // 0x135c (Size: 0x4, Type: StructProperty)
    FGameplayTag BallooningTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1360); } // 0x1360 (Size: 0x4, Type: StructProperty)
    FGameplayTag GrindingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1364); } // 0x1364 (Size: 0x4, Type: StructProperty)
    FGameplayTag SlidingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1368); } // 0x1368 (Size: 0x4, Type: StructProperty)
    FGameplayTag DrivingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x136c); } // 0x136c (Size: 0x4, Type: StructProperty)
    FGameplayTag PassengerTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1370); } // 0x1370 (Size: 0x4, Type: StructProperty)
    FGameplayTag ChainsawTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1374); } // 0x1374 (Size: 0x4, Type: StructProperty)

    void SET_bIsChainsawScooter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x1, Type: BoolProperty)
    void SET_LeanX(const float& Value) { Write<float>(uintptr_t(this) + 0x130c, Value); } // 0x130c (Size: 0x4, Type: FloatProperty)
    void SET_LeanY(const float& Value) { Write<float>(uintptr_t(this) + 0x1310, Value); } // 0x1310 (Size: 0x4, Type: FloatProperty)
    void SET_bIsFallingIntoScooter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1314, Value); } // 0x1314 (Size: 0x1, Type: BoolProperty)
    void SET_bIsScooterFalling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1315, Value); } // 0x1315 (Size: 0x1, Type: BoolProperty)
    void SET_bIsNotChainsawScooter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1316, Value); } // 0x1316 (Size: 0x1, Type: BoolProperty)
    void SET_CustomMeleeTwist(const float& Value) { Write<float>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x4, Type: FloatProperty)
    void SET_bIsNotEquip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131c, Value); } // 0x131c (Size: 0x1, Type: BoolProperty)
    void SET_ChainsawScooterPelvisOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x4, Type: FloatProperty)
    void SET_bIsUpperBodyEquip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1324, Value); } // 0x1324 (Size: 0x1, Type: BoolProperty)
    void SET_ForwardSpeedInterp(const double& Value) { Write<double>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x8, Type: DoubleProperty)
    void SET_LateralSpeedInterp(const double& Value) { Write<double>(uintptr_t(this) + 0x1330, Value); } // 0x1330 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsSlidingMovementMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x1, Type: BoolProperty)
    void SET_bIsOtherMovementMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1339, Value); } // 0x1339 (Size: 0x1, Type: BoolProperty)
    void SET_StartedSharpTurnTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x133c, Value); } // 0x133c (Size: 0x4, Type: StructProperty)
    void SET_EndedSharpTurnTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1340, Value); } // 0x1340 (Size: 0x4, Type: StructProperty)
    void SET_FallingIntoScooterTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1344, Value); } // 0x1344 (Size: 0x4, Type: StructProperty)
    void SET_HoldingScooterButtonTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1348, Value); } // 0x1348 (Size: 0x4, Type: StructProperty)
    void SET_ScooteringTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x134c, Value); } // 0x134c (Size: 0x4, Type: StructProperty)
    void SET_ZipliningOnSplineTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1350, Value); } // 0x1350 (Size: 0x4, Type: StructProperty)
    void SET_SurfaceSwimmingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1354, Value); } // 0x1354 (Size: 0x4, Type: StructProperty)
    void SET_ParachutingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1358, Value); } // 0x1358 (Size: 0x4, Type: StructProperty)
    void SET_SkydivingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x135c, Value); } // 0x135c (Size: 0x4, Type: StructProperty)
    void SET_BallooningTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1360, Value); } // 0x1360 (Size: 0x4, Type: StructProperty)
    void SET_GrindingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1364, Value); } // 0x1364 (Size: 0x4, Type: StructProperty)
    void SET_SlidingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1368, Value); } // 0x1368 (Size: 0x4, Type: StructProperty)
    void SET_DrivingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x136c, Value); } // 0x136c (Size: 0x4, Type: StructProperty)
    void SET_PassengerTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1370, Value); } // 0x1370 (Size: 0x4, Type: StructProperty)
    void SET_ChainsawTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1374, Value); } // 0x1374 (Size: 0x4, Type: StructProperty)
};

// Size: 0x50
class UFortMovementMode_ChainsawRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

// Size: 0x438
class UFortMovementMode_ExtChainsaw : public UFortMovementMode_BaseExtLogic
{
public:
    FGameplayTag TAG_Scootering() const { return Read<FGameplayTag>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_BlockedByObstacle() const { return Read<FGameplayTag>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_StopSawScooter() const { return Read<FGameplayTag>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_StopSawScooterFromLedgeFall() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_StartedSharpTurn() const { return Read<FGameplayTag>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_EndedSharpTurn() const { return Read<FGameplayTag>(uintptr_t(this) + 0x214); } // 0x214 (Size: 0x4, Type: StructProperty)
    FScalableFloat SpeedDefault() const { return Read<FScalableFloat>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedBlocked() const { return Read<FScalableFloat>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedSharpTurn() const { return Read<FScalableFloat>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    FScalableFloat InterpSpeedDefault() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat InterpSpeedBlocked() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TurnSpeedDefault() const { return Read<FScalableFloat>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x28, Type: StructProperty)
    FScalableFloat TurnSpeedSharpTurn() const { return Read<FScalableFloat>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x28, Type: StructProperty)
    FScalableFloat DotProductSharpTurn() const { return Read<FScalableFloat>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x28, Type: StructProperty)
    FScalableFloat DotProductStraightenedOut() const { return Read<FScalableFloat>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinTimeForSharpTurn() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat GoalDirectionThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x28, Type: StructProperty)
    bool bDeNativize() const { return Read<bool>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x1, Type: BoolProperty)
    UClass* DenativizedRuntimeDataClass() const { return Read<UClass*>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x8, Type: ClassProperty)

    void SET_TAG_Scootering(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: StructProperty)
    void SET_TAG_BlockedByObstacle(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: StructProperty)
    void SET_TAG_StopSawScooter(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: StructProperty)
    void SET_TAG_StopSawScooterFromLedgeFall(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x4, Type: StructProperty)
    void SET_TAG_StartedSharpTurn(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x4, Type: StructProperty)
    void SET_TAG_EndedSharpTurn(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x214, Value); } // 0x214 (Size: 0x4, Type: StructProperty)
    void SET_SpeedDefault(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x28, Type: StructProperty)
    void SET_SpeedBlocked(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x28, Type: StructProperty)
    void SET_SpeedSharpTurn(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_InterpSpeedDefault(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_InterpSpeedBlocked(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x28, Type: StructProperty)
    void SET_TurnSpeedDefault(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x28, Type: StructProperty)
    void SET_TurnSpeedSharpTurn(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x28, Type: StructProperty)
    void SET_DotProductSharpTurn(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x28, Type: StructProperty)
    void SET_DotProductStraightenedOut(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x28, Type: StructProperty)
    void SET_MinTimeForSharpTurn(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x28, Type: StructProperty)
    void SET_GoalDirectionThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x28, Type: StructProperty)
    void SET_bDeNativize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x1, Type: BoolProperty)
    void SET_DenativizedRuntimeDataClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x10
struct FFortMovementMode_ChainsawCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
};

