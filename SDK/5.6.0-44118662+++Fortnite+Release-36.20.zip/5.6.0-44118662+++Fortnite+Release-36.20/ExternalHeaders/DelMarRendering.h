/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarRendering
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x50
class UDelMarMaterialFXSubsystem : public UTickableWorldSubsystem
{
public:
    UMaterialParameterCollection* GameplayMPC() const { return Read<UMaterialParameterCollection*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayMPC(const UMaterialParameterCollection*& Value) { Write<UMaterialParameterCollection*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

