/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomDebugCommandsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "GameplayTags.h"
#include "UMG.h"
#include "CommonUI.h"
#include "CommonUILegacy.h"

// Size: 0x910
class UCustomDebugCommandsPanel : public UFortSettingsPanel
{
public:
    FDataTableRowHandle ResetInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ModifyInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RunCommandInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x8d8); } // 0x8d8 (Size: 0x10, Type: StructProperty)
    UCustomDebugCommandsPromptWidget* CmdPromptWidget() const { return Read<UCustomDebugCommandsPromptWidget*>(uintptr_t(this) + 0x900); } // 0x900 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Details() const { return Read<UOverlay*>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x8, Type: ObjectProperty)

    void SET_ResetInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x10, Type: StructProperty)
    void SET_ModifyInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x10, Type: StructProperty)
    void SET_RunCommandInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x8d8, Value); } // 0x8d8 (Size: 0x10, Type: StructProperty)
    void SET_CmdPromptWidget(const UCustomDebugCommandsPromptWidget*& Value) { Write<UCustomDebugCommandsPromptWidget*>(uintptr_t(this) + 0x900, Value); } // 0x900 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Details(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x498
class UCustomDebugCommandsPromptWidget : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle FocusSearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ClearSearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: StructProperty)

    void SET_FocusSearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: StructProperty)
    void SET_ClearSearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1b8
class UCustomDebugCommandsRegistry : public UFortSettingRegistry
{
public:
};

// Size: 0x670
class UCustomDebugCommandsScreen : public USettingsScreen
{
public:
    FGameplayTagContainer HudHidingTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x20, Type: StructProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle BackActionRowHandle() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x10, Type: StructProperty)

    void SET_HudHidingTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x20, Type: StructProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    void SET_BackActionRowHandle(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x10, Type: StructProperty)
};

// Size: 0x368
class UFortDebugCommandSettingsListEntrySetting_Action : public UFortSettingsListEntrySetting_Action
{
public:
};

// Size: 0x3b0
class UFortDebugCommandSettingsListEntrySetting_Discrete : public UFortSettingsListEntrySetting_Discrete
{
public:
    UCommonButtonLegacy* Button_EditEntry() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonLegacy* Button_Commit() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    bool bIsInEditMode() const { return Read<bool>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x1, Type: BoolProperty)

    void SET_Button_EditEntry(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Commit(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsInEditMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x390
class UFortDebugCommandSettingsListEntrySetting_Scalar : public UFortSettingsListEntrySetting_Scalar
{
public:
    UCommonButtonLegacy* Button_EditEntry() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonLegacy* Button_Commit() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    bool bIsInEditMode() const { return Read<bool>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x1, Type: BoolProperty)

    void SET_Button_EditEntry(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Commit(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsInEditMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
class UFortSettingDataSourceModel_DebugCommand : public UFortSettingDataSourceModel
{
public:
    FString ConsoleCommandName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    bool bIsServerConsoleCommand() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    TArray<FString> CommandArgs() const { return Read<TArray<FString>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    bool bInjectVariableParameter() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    int32_t VariableParameterArgumentPosition() const { return Read<int32_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: IntProperty)

    void SET_ConsoleCommandName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_bIsServerConsoleCommand(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_CommandArgs(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_bInjectVariableParameter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_VariableParameterArgumentPosition(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
class USettingRegistryPermissionRequirement_DebugCommands : public USettingRegistryPermissionRequirement
{
public:
};

