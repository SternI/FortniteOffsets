/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActorEntity
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Entity.h"
#include "CoreUObject.h"

// Size: 0x258
class UActorEntityComponent : public UActorComponent
{
public:
    FActorEntityMappingArray EntityMappingArray() const { return Read<FActorEntityMappingArray>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x130, Type: StructProperty)

    void SET_EntityMappingArray(const FActorEntityMappingArray& Value) { Write<FActorEntityMappingArray>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x130, Type: StructProperty)
};

// Size: 0xa0
class UActorEntitySubsystem : public UWorldSubsystem
{
public:
    UPhysicsQueryConvertor* PhysicsQueryConvertor() const { return Read<UPhysicsQueryConvertor*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)

    void SET_PhysicsQueryConvertor(const UPhysicsQueryConvertor*& Value) { Write<UPhysicsQueryConvertor*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UPhysicsComponentBridgeHelper : public UObject
{
public:
};

// Size: 0x38
class UPhysicsQueryConvertor : public UObject
{
public:
    UActorEntitySubsystem* ActorEntitySubsystem() const { return Read<UActorEntitySubsystem*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_ActorEntitySubsystem(const UActorEntitySubsystem*& Value) { Write<UActorEntitySubsystem*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
struct FActorEntityInteropRules
{
public:
    TArray<TSoftClassPtr> AllowedEntityComponents() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FSubEntityInteropRules> SubEntityRules() const { return Read<TArray<FSubEntityInteropRules>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bEnableEntityReplication() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)

    void SET_AllowedEntityComponents(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_SubEntityRules(const TArray<FSubEntityInteropRules>& Value) { Write<TArray<FSubEntityInteropRules>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_bEnableEntityReplication(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FSubEntityInteropRules
{
public:
    FName ComponentName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<TSoftClassPtr> AllowedEntityComponents() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AllowedEntityComponents(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FActorEntityMappingArrayItem : public FFastArraySerializerItem
{
public:
    UBaseEntity* Entity() const { return Read<UBaseEntity*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UObject* Object() const { return Read<UObject*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_Entity(const UBaseEntity*& Value) { Write<UBaseEntity*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_Object(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x130
struct FActorEntityMappingArray : public FFastArraySerializer
{
public:
    TArray<FActorEntityMappingArrayItem> Entities() const { return Read<TArray<FActorEntityMappingArrayItem>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)

    void SET_Entities(const TArray<FActorEntityMappingArrayItem>& Value) { Write<TArray<FActorEntityMappingArrayItem>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
};

