/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayCueNotifies
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "Blueprints.h"
#include "CoreUObject.h"
#include "Athena.h"
#include "FortniteGame.h"
#include "Niagara.h"

// Size: 0x598
class AGC_Abilities_Death_FadeCapsule_StW_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    float CapsuleFadeTL_RemoveShadow_D18D776D462C2233B7D3E1B7577403C1() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CapsuleFadeTL__Direction_D18D776D462C2233B7D3E1B7577403C1() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* CapsuleFadeTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    double Starting_Min_Capsule_Shadow_Vis() const { return Read<double>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: DoubleProperty)
    TArray<USkinnedMeshComponent*> SkinnedMesh() const { return Read<TArray<USkinnedMeshComponent*>>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_CapsuleFadeTL_RemoveShadow_D18D776D462C2233B7D3E1B7577403C1(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_CapsuleFadeTL__Direction_D18D776D462C2233B7D3E1B7577403C1(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x1, Type: ByteProperty)
    void SET_CapsuleFadeTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_Starting_Min_Capsule_Shadow_Vis(const double& Value) { Write<double>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: DoubleProperty)
    void SET_SkinnedMesh(const TArray<USkinnedMeshComponent*>& Value) { Write<TArray<USkinnedMeshComponent*>>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x598
class AGC_Abilities_Death_FadeCapsule_Athena_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    float CapsuleFadeTL_RemoveShadow_B48F4431426ECD264BA37C992B6887C3() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CapsuleFadeTL__Direction_B48F4431426ECD264BA37C992B6887C3() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* CapsuleFadeTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    double Starting_Min_Capsule_Shadow_Vis() const { return Read<double>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: DoubleProperty)
    TArray<USkinnedMeshComponent*> SkinnedMesh() const { return Read<TArray<USkinnedMeshComponent*>>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_CapsuleFadeTL_RemoveShadow_B48F4431426ECD264BA37C992B6887C3(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_CapsuleFadeTL__Direction_B48F4431426ECD264BA37C992B6887C3(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x1, Type: ByteProperty)
    void SET_CapsuleFadeTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_Starting_Min_Capsule_Shadow_Vis(const double& Value) { Write<double>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: DoubleProperty)
    void SET_SkinnedMesh(const TArray<USkinnedMeshComponent*>& Value) { Write<TArray<USkinnedMeshComponent*>>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x730
class AGCN_RezIn_Frontend_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_43B69932442AE90AB9E7D9819F3D3E71() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_43B69932442AE90AB9E7D9819F3D3E71() const { return Read<float>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_43B69932442AE90AB9E7D9819F3D3E71() const { return Read<float>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_43B69932442AE90AB9E7D9819F3D3E71() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x57c); } // 0x57c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_580AB4094AE6911DB445A58F9580C544() const { return Read<float>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_580AB4094AE6911DB445A58F9580C544() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c); } // 0x58c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_GlowCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_ANIMATION() const { return Read<bool>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x1, Type: BoolProperty)
    bool SpawnDrone() const { return Read<bool>(uintptr_t(this) + 0x599); } // 0x599 (Size: 0x1, Type: BoolProperty)
    UClass* Teleportation_Drone() const { return Read<UClass*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ClassProperty)
    double Teleport_Bot_AnimPlayRate() const { return Read<double>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    double Teleport_Bot_Lifespan() const { return Read<double>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Teleportation_Point_Light() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset() const { return Read<FVector>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve() const { return Read<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top() const { return Read<FName>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x4, Type: NameProperty)
    double Max_Light_Intensity() const { return Read<double>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom() const { return Read<FName>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x4, Type: NameProperty)
    TArray<USkeletalMeshComponent*> Meshes_to_Dissolve() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x10, Type: ArrayProperty)
    ABP_TeleportationDrone_C* Drone() const { return Read<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_CHILDCOMPONENTS() const { return Read<bool>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x1, Type: BoolProperty)
    TArray<UFXSystemComponent*> Particle_Components() const { return Read<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Teleport_VFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Teleport_In_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    FName Teleport_In_VFX_Attach_Point_Name() const { return Read<FName>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x4, Type: NameProperty)
    int32_t Cur_Dissolve_Setup_Attempt() const { return Read<int32_t>(uintptr_t(this) + 0x6b4); } // 0x6b4 (Size: 0x4, Type: IntProperty)
    int32_t AmountOfTimesToAttemptRestoreMats() const { return Read<int32_t>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x4, Type: IntProperty)
    bool Spawn_VFX_Attached() const { return Read<bool>(uintptr_t(this) + 0x6bc); } // 0x6bc (Size: 0x1, Type: BoolProperty)
    double Dissolve_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x8, Type: DoubleProperty)
    UNiagaraSystem* Drone_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_TESTJANUSFX() const { return Read<bool>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x1, Type: BoolProperty)
    FName Drone_VFX_Attach_Point() const { return Read<FName>(uintptr_t(this) + 0x6dc); } // 0x6dc (Size: 0x4, Type: NameProperty)
    FGuid Material_Override_ID() const { return Read<FGuid>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters() const { return Read<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x30, Type: StructProperty)
    FDelegateHandleController Delegate_Handle_Controller() const { return Read<FDelegateHandleController>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_TFX_ResOutCharacterMesh_LightIntensity_43B69932442AE90AB9E7D9819F3D3E71(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_ZHeightParam_43B69932442AE90AB9E7D9819F3D3E71(const float& Value) { Write<float>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_TransitionParam_43B69932442AE90AB9E7D9819F3D3E71(const float& Value) { Write<float>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh__Direction_43B69932442AE90AB9E7D9819F3D3E71(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x57c, Value); } // 0x57c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_ResOutCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_TFX_GlowCharacterMesh_EmissiveWarp_580AB4094AE6911DB445A58F9580C544(const float& Value) { Write<float>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_GlowCharacterMesh__Direction_580AB4094AE6911DB445A58F9580C544(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c, Value); } // 0x58c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_GlowCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_ANIMATION(const bool& Value) { Write<bool>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnDrone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x599, Value); } // 0x599 (Size: 0x1, Type: BoolProperty)
    void SET_Teleportation_Drone(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ClassProperty)
    void SET_Teleport_Bot_AnimPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    void SET_Teleport_Bot_Lifespan(const double& Value) { Write<double>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    void SET_Teleportation_Point_Light(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleportation_Light_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    void SET_Teleportation_Light_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x10, Type: StructProperty)
    void SET_DissolveMIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    void SET_Mat_Chracter_Dissolve(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Pawn(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    void SET_Dissolve(const TSet<USkeletalMeshComponent*>& Value) { Write<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x50, Type: SetProperty)
    void SET_Socket_Mesh_Top(const FName& Value) { Write<FName>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x4, Type: NameProperty)
    void SET_Max_Light_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: DoubleProperty)
    void SET_Socket_Mesh_Bottom(const FName& Value) { Write<FName>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x4, Type: NameProperty)
    void SET_Meshes_to_Dissolve(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x10, Type: ArrayProperty)
    void SET_Drone(const ABP_TeleportationDrone_C*& Value) { Write<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_CHILDCOMPONENTS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x1, Type: BoolProperty)
    void SET_Particle_Components(const TArray<UFXSystemComponent*>& Value) { Write<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    void SET_Spawned_Teleport_VFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleport_In_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleport_In_VFX_Attach_Point_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x4, Type: NameProperty)
    void SET_Cur_Dissolve_Setup_Attempt(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6b4, Value); } // 0x6b4 (Size: 0x4, Type: IntProperty)
    void SET_AmountOfTimesToAttemptRestoreMats(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x4, Type: IntProperty)
    void SET_Spawn_VFX_Attached(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6bc, Value); } // 0x6bc (Size: 0x1, Type: BoolProperty)
    void SET_Dissolve_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: DoubleProperty)
    void SET_Glow_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x8, Type: DoubleProperty)
    void SET_Drone_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_TESTJANUSFX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x1, Type: BoolProperty)
    void SET_Drone_VFX_Attach_Point(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6dc, Value); } // 0x6dc (Size: 0x4, Type: NameProperty)
    void SET_Material_Override_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x10, Type: StructProperty)
    void SET_Copied_Parameters(const FFortPawnMaterialOverrideCopiedParameters& Value) { Write<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x30, Type: StructProperty)
    void SET_Delegate_Handle_Controller(const FDelegateHandleController& Value) { Write<FDelegateHandleController>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x10, Type: StructProperty)
};

// Size: 0x731
class AGCN_RezIn_CreativeRespawn_C : public AGCN_RezIn_C
{
public:
};

// Size: 0x731
class AGCN_RezIn_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_81C5527F43A6972D94623590BA582E8C() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_81C5527F43A6972D94623590BA582E8C() const { return Read<float>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_81C5527F43A6972D94623590BA582E8C() const { return Read<float>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_81C5527F43A6972D94623590BA582E8C() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x57c); } // 0x57c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_9EA15145493A8F1A5915938D5529A028() const { return Read<float>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_9EA15145493A8F1A5915938D5529A028() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c); } // 0x58c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_GlowCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_ANIMATION() const { return Read<bool>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x1, Type: BoolProperty)
    bool SpawnDrone() const { return Read<bool>(uintptr_t(this) + 0x599); } // 0x599 (Size: 0x1, Type: BoolProperty)
    UClass* Teleportation_Drone() const { return Read<UClass*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ClassProperty)
    double Teleport_Bot_AnimPlayRate() const { return Read<double>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    double Teleport_Bot_Lifespan() const { return Read<double>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Teleportation_Point_Light() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset() const { return Read<FVector>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve() const { return Read<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top() const { return Read<FName>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x4, Type: NameProperty)
    double Max_Light_Intensity() const { return Read<double>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom() const { return Read<FName>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x4, Type: NameProperty)
    TArray<USkeletalMeshComponent*> Meshes_to_Dissolve() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x10, Type: ArrayProperty)
    ABP_TeleportationDrone_C* Drone() const { return Read<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_CHILDCOMPONENTS() const { return Read<bool>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x1, Type: BoolProperty)
    TArray<UFXSystemComponent*> Particle_Components() const { return Read<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Teleport_VFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Teleport_In_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    FName Teleport_In_VFX_Attach_Point_Name() const { return Read<FName>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x4, Type: NameProperty)
    int32_t Cur_Dissolve_Setup_Attempt() const { return Read<int32_t>(uintptr_t(this) + 0x6b4); } // 0x6b4 (Size: 0x4, Type: IntProperty)
    int32_t AmountOfTimesToAttemptRestoreMats() const { return Read<int32_t>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x4, Type: IntProperty)
    bool Spawn_VFX_Attached() const { return Read<bool>(uintptr_t(this) + 0x6bc); } // 0x6bc (Size: 0x1, Type: BoolProperty)
    double Dissolve_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x8, Type: DoubleProperty)
    UNiagaraSystem* Drone_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_TESTJANUSFX() const { return Read<bool>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x1, Type: BoolProperty)
    FName Drone_VFX_Attach_Point() const { return Read<FName>(uintptr_t(this) + 0x6dc); } // 0x6dc (Size: 0x4, Type: NameProperty)
    FGuid Material_Override_ID() const { return Read<FGuid>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters() const { return Read<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x30, Type: StructProperty)
    FDelegateHandleController Delegate_Handle_Controller() const { return Read<FDelegateHandleController>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x10, Type: StructProperty)
    bool bCleanedUp() const { return Read<bool>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_TFX_ResOutCharacterMesh_LightIntensity_81C5527F43A6972D94623590BA582E8C(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_ZHeightParam_81C5527F43A6972D94623590BA582E8C(const float& Value) { Write<float>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_TransitionParam_81C5527F43A6972D94623590BA582E8C(const float& Value) { Write<float>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh__Direction_81C5527F43A6972D94623590BA582E8C(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x57c, Value); } // 0x57c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_ResOutCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_TFX_GlowCharacterMesh_EmissiveWarp_9EA15145493A8F1A5915938D5529A028(const float& Value) { Write<float>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_GlowCharacterMesh__Direction_9EA15145493A8F1A5915938D5529A028(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c, Value); } // 0x58c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_GlowCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_ANIMATION(const bool& Value) { Write<bool>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnDrone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x599, Value); } // 0x599 (Size: 0x1, Type: BoolProperty)
    void SET_Teleportation_Drone(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ClassProperty)
    void SET_Teleport_Bot_AnimPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    void SET_Teleport_Bot_Lifespan(const double& Value) { Write<double>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    void SET_Teleportation_Point_Light(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleportation_Light_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    void SET_Teleportation_Light_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x10, Type: StructProperty)
    void SET_DissolveMIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    void SET_Mat_Chracter_Dissolve(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Pawn(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    void SET_Dissolve(const TSet<USkeletalMeshComponent*>& Value) { Write<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x50, Type: SetProperty)
    void SET_Socket_Mesh_Top(const FName& Value) { Write<FName>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x4, Type: NameProperty)
    void SET_Max_Light_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: DoubleProperty)
    void SET_Socket_Mesh_Bottom(const FName& Value) { Write<FName>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x4, Type: NameProperty)
    void SET_Meshes_to_Dissolve(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x10, Type: ArrayProperty)
    void SET_Drone(const ABP_TeleportationDrone_C*& Value) { Write<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_CHILDCOMPONENTS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x1, Type: BoolProperty)
    void SET_Particle_Components(const TArray<UFXSystemComponent*>& Value) { Write<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    void SET_Spawned_Teleport_VFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleport_In_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleport_In_VFX_Attach_Point_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x4, Type: NameProperty)
    void SET_Cur_Dissolve_Setup_Attempt(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6b4, Value); } // 0x6b4 (Size: 0x4, Type: IntProperty)
    void SET_AmountOfTimesToAttemptRestoreMats(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x4, Type: IntProperty)
    void SET_Spawn_VFX_Attached(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6bc, Value); } // 0x6bc (Size: 0x1, Type: BoolProperty)
    void SET_Dissolve_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: DoubleProperty)
    void SET_Glow_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x8, Type: DoubleProperty)
    void SET_Drone_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_TESTJANUSFX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x1, Type: BoolProperty)
    void SET_Drone_VFX_Attach_Point(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6dc, Value); } // 0x6dc (Size: 0x4, Type: NameProperty)
    void SET_Material_Override_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x10, Type: StructProperty)
    void SET_Copied_Parameters(const FFortPawnMaterialOverrideCopiedParameters& Value) { Write<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x30, Type: StructProperty)
    void SET_Delegate_Handle_Controller(const FDelegateHandleController& Value) { Write<FDelegateHandleController>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x10, Type: StructProperty)
    void SET_bCleanedUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x7c0
class AGCN_RezOut_TacElim_C : public AGCN_RezOut_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x7c8
class AGCN_RezOut_NPC_C : public AGCN_RezOut_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x8, Type: StructProperty)
    USoundBase* SoundOnNPCDeath() const { return Read<USoundBase*>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x8, Type: StructProperty)
    void SET_SoundOnNPCDeath(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x7b8
class AGCN_RezOut_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_E9C2D3554642468472CCCFA609A39FBC() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_E9C2D3554642468472CCCFA609A39FBC() const { return Read<float>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_E9C2D3554642468472CCCFA609A39FBC() const { return Read<float>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_E9C2D3554642468472CCCFA609A39FBC() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x57c); } // 0x57c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_39A37BC9407CF090A09ABDA5A488F776() const { return Read<float>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_39A37BC9407CF090A09ABDA5A488F776() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c); } // 0x58c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_GlowCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_ANIMATION() const { return Read<bool>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x1, Type: BoolProperty)
    bool SpawnDrone() const { return Read<bool>(uintptr_t(this) + 0x599); } // 0x599 (Size: 0x1, Type: BoolProperty)
    UClass* Teleportation_Drone() const { return Read<UClass*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ClassProperty)
    double Teleport_Bot_AnimPlayRate() const { return Read<double>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    double Teleport_Bot_Lifespan() const { return Read<double>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Teleportation_Point_Light() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset() const { return Read<FVector>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve() const { return Read<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top() const { return Read<FName>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x4, Type: NameProperty)
    double Max_Light_Intensity() const { return Read<double>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom() const { return Read<FName>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x4, Type: NameProperty)
    TArray<USkeletalMeshComponent*> Meshes_to_Dissolve() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x10, Type: ArrayProperty)
    ABP_TeleportationDrone_C* Drone() const { return Read<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_CHILDCOMPONENTS() const { return Read<bool>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x1, Type: BoolProperty)
    TArray<UFXSystemComponent*> Particle_Components() const { return Read<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Death_VFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Dissolve_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    FName Dissolve_VFX_Spawn_Point_Name() const { return Read<FName>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x4, Type: NameProperty)
    UAnimMontage* Base_Elimination_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DBNO_Elimination_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Skydiving_Elimination_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Swimming_Elimination_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DBNO_Swimming_Elimination_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    bool Spawn_VFX_Attached() const { return Read<bool>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x1, Type: BoolProperty)
    double Dissolve_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x8, Type: DoubleProperty)
    bool DEBUG_REMOVESPAWNVFX() const { return Read<bool>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x1, Type: BoolProperty)
    bool DEBUG_REMOVESPAWNEDPOINTLIGHT() const { return Read<bool>(uintptr_t(this) + 0x6f9); } // 0x6f9 (Size: 0x1, Type: BoolProperty)
    UNiagaraSystem* Drone_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x8, Type: ObjectProperty)
    FName Drone_VFX_Attach_Point() const { return Read<FName>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x4, Type: NameProperty)
    bool DEBUG_FXSYSTEMCOMPONENTS() const { return Read<bool>(uintptr_t(this) + 0x70c); } // 0x70c (Size: 0x1, Type: BoolProperty)
    bool DEBUG_IMACTDATA() const { return Read<bool>(uintptr_t(this) + 0x70d); } // 0x70d (Size: 0x1, Type: BoolProperty)
    bool ShouldDelayBetweenAnimAndVFX() const { return Read<bool>(uintptr_t(this) + 0x70e); } // 0x70e (Size: 0x1, Type: BoolProperty)
    double DelayBetweenAnimAndVFX() const { return Read<double>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x8, Type: DoubleProperty)
    bool Send_Impact_Location_to_Dissolve_Material() const { return Read<bool>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x1, Type: BoolProperty)
    FName Impact_Location_Parameter_Name() const { return Read<FName>(uintptr_t(this) + 0x71c); } // 0x71c (Size: 0x4, Type: NameProperty)
    FGuid Material_Override_ID() const { return Read<FGuid>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters() const { return Read<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x30, Type: StructProperty)
    FVector On_Death_Hit_Location() const { return Read<FVector>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x18, Type: StructProperty)
    FVector On_Death_Hit_Momentum() const { return Read<FVector>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x18, Type: StructProperty)
    bool bIsHeadShot() const { return Read<bool>(uintptr_t(this) + 0x790); } // 0x790 (Size: 0x1, Type: BoolProperty)
    FVector On_Death_Hit_Normal() const { return Read<FVector>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x18, Type: StructProperty)
    USoundBase* RezOutSweetener() const { return Read<USoundBase*>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_TFX_ResOutCharacterMesh_LightIntensity_E9C2D3554642468472CCCFA609A39FBC(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_ZHeightParam_E9C2D3554642468472CCCFA609A39FBC(const float& Value) { Write<float>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_TransitionParam_E9C2D3554642468472CCCFA609A39FBC(const float& Value) { Write<float>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh__Direction_E9C2D3554642468472CCCFA609A39FBC(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x57c, Value); } // 0x57c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_ResOutCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_TFX_GlowCharacterMesh_EmissiveWarp_39A37BC9407CF090A09ABDA5A488F776(const float& Value) { Write<float>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_GlowCharacterMesh__Direction_39A37BC9407CF090A09ABDA5A488F776(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c, Value); } // 0x58c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_GlowCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_ANIMATION(const bool& Value) { Write<bool>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnDrone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x599, Value); } // 0x599 (Size: 0x1, Type: BoolProperty)
    void SET_Teleportation_Drone(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ClassProperty)
    void SET_Teleport_Bot_AnimPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    void SET_Teleport_Bot_Lifespan(const double& Value) { Write<double>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    void SET_Teleportation_Point_Light(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleportation_Light_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    void SET_Teleportation_Light_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x10, Type: StructProperty)
    void SET_DissolveMIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    void SET_Mat_Chracter_Dissolve(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Pawn(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    void SET_Dissolve(const TSet<USkeletalMeshComponent*>& Value) { Write<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x50, Type: SetProperty)
    void SET_Socket_Mesh_Top(const FName& Value) { Write<FName>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x4, Type: NameProperty)
    void SET_Max_Light_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: DoubleProperty)
    void SET_Socket_Mesh_Bottom(const FName& Value) { Write<FName>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x4, Type: NameProperty)
    void SET_Meshes_to_Dissolve(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x10, Type: ArrayProperty)
    void SET_Drone(const ABP_TeleportationDrone_C*& Value) { Write<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_DEBUG_CHILDCOMPONENTS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x1, Type: BoolProperty)
    void SET_Particle_Components(const TArray<UFXSystemComponent*>& Value) { Write<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: ArrayProperty)
    void SET_Spawned_Death_VFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Dissolve_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Dissolve_VFX_Spawn_Point_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x4, Type: NameProperty)
    void SET_Base_Elimination_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    void SET_DBNO_Elimination_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Skydiving_Elimination_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Swimming_Elimination_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    void SET_DBNO_Swimming_Elimination_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Spawn_VFX_Attached(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x1, Type: BoolProperty)
    void SET_Dissolve_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x8, Type: DoubleProperty)
    void SET_Glow_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x8, Type: DoubleProperty)
    void SET_DEBUG_REMOVESPAWNVFX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x1, Type: BoolProperty)
    void SET_DEBUG_REMOVESPAWNEDPOINTLIGHT(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6f9, Value); } // 0x6f9 (Size: 0x1, Type: BoolProperty)
    void SET_Drone_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x8, Type: ObjectProperty)
    void SET_Drone_VFX_Attach_Point(const FName& Value) { Write<FName>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x4, Type: NameProperty)
    void SET_DEBUG_FXSYSTEMCOMPONENTS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70c, Value); } // 0x70c (Size: 0x1, Type: BoolProperty)
    void SET_DEBUG_IMACTDATA(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70d, Value); } // 0x70d (Size: 0x1, Type: BoolProperty)
    void SET_ShouldDelayBetweenAnimAndVFX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70e, Value); } // 0x70e (Size: 0x1, Type: BoolProperty)
    void SET_DelayBetweenAnimAndVFX(const double& Value) { Write<double>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x8, Type: DoubleProperty)
    void SET_Send_Impact_Location_to_Dissolve_Material(const bool& Value) { Write<bool>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x1, Type: BoolProperty)
    void SET_Impact_Location_Parameter_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x71c, Value); } // 0x71c (Size: 0x4, Type: NameProperty)
    void SET_Material_Override_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x10, Type: StructProperty)
    void SET_Copied_Parameters(const FFortPawnMaterialOverrideCopiedParameters& Value) { Write<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x30, Type: StructProperty)
    void SET_On_Death_Hit_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x18, Type: StructProperty)
    void SET_On_Death_Hit_Momentum(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x18, Type: StructProperty)
    void SET_bIsHeadShot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x790, Value); } // 0x790 (Size: 0x1, Type: BoolProperty)
    void SET_On_Death_Hit_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x18, Type: StructProperty)
    void SET_RezOutSweetener(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6e8
class AGCN_RezIn_StyleTransfer_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_47520A324BFF8E84CA190293605B9FEB() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_47520A324BFF8E84CA190293605B9FEB() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_GlowCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_8D8520244DCE1E895202BA9542045934() const { return Read<float>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_8D8520244DCE1E895202BA9542045934() const { return Read<float>(uintptr_t(this) + 0x584); } // 0x584 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_8D8520244DCE1E895202BA9542045934() const { return Read<float>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_8D8520244DCE1E895202BA9542045934() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c); } // 0x58c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    UPointLightComponent* Teleportation_Point_Light() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset() const { return Read<FVector>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve() const { return Read<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top() const { return Read<FName>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x4, Type: NameProperty)
    double Max_Light_Intensity() const { return Read<double>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom() const { return Read<FName>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x4, Type: NameProperty)
    ABP_TeleportationDrone_C* Drone() const { return Read<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    TArray<UFXSystemComponent*> Particle_Components() const { return Read<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Teleport_VFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Teleport_In_Visual_Effect() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    FName Teleport_In_VFX_Attach_Point_Name() const { return Read<FName>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x4, Type: NameProperty)
    int32_t Cur_Dissolve_Setup_Attempt() const { return Read<int32_t>(uintptr_t(this) + 0x67c); } // 0x67c (Size: 0x4, Type: IntProperty)
    int32_t AmountOfTimesToAttemptRestoreMats() const { return Read<int32_t>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x4, Type: IntProperty)
    bool Spawn_VFX_Attached() const { return Read<bool>(uintptr_t(this) + 0x684); } // 0x684 (Size: 0x1, Type: BoolProperty)
    double Dissolve_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate() const { return Read<double>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x8, Type: DoubleProperty)
    FGuid Material_Override_ID() const { return Read<FGuid>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters() const { return Read<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x30, Type: StructProperty)
    FDelegateHandleController Delegate_Handle_Controller() const { return Read<FDelegateHandleController>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_TFX_GlowCharacterMesh_EmissiveWarp_47520A324BFF8E84CA190293605B9FEB(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_GlowCharacterMesh__Direction_47520A324BFF8E84CA190293605B9FEB(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x1, Type: ByteProperty)
    void SET_TFX_GlowCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_TFX_ResOutCharacterMesh_LightIntensity_8D8520244DCE1E895202BA9542045934(const float& Value) { Write<float>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_ZHeightParam_8D8520244DCE1E895202BA9542045934(const float& Value) { Write<float>(uintptr_t(this) + 0x584, Value); } // 0x584 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh_TransitionParam_8D8520244DCE1E895202BA9542045934(const float& Value) { Write<float>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x4, Type: FloatProperty)
    void SET_TFX_ResOutCharacterMesh__Direction_8D8520244DCE1E895202BA9542045934(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x58c, Value); } // 0x58c (Size: 0x1, Type: ByteProperty)
    void SET_TFX_ResOutCharacterMesh(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleportation_Point_Light(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleportation_Light_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x18, Type: StructProperty)
    void SET_Teleportation_Light_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x10, Type: StructProperty)
    void SET_DissolveMIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x10, Type: ArrayProperty)
    void SET_Mat_Chracter_Dissolve(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Pawn(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Dissolve(const TSet<USkeletalMeshComponent*>& Value) { Write<TSet<USkeletalMeshComponent*>>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x50, Type: SetProperty)
    void SET_Socket_Mesh_Top(const FName& Value) { Write<FName>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x4, Type: NameProperty)
    void SET_Max_Light_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: DoubleProperty)
    void SET_Socket_Mesh_Bottom(const FName& Value) { Write<FName>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x4, Type: NameProperty)
    void SET_Drone(const ABP_TeleportationDrone_C*& Value) { Write<ABP_TeleportationDrone_C*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_Particle_Components(const TArray<UFXSystemComponent*>& Value) { Write<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x10, Type: ArrayProperty)
    void SET_Spawned_Teleport_VFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleport_In_Visual_Effect(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_Teleport_In_VFX_Attach_Point_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x4, Type: NameProperty)
    void SET_Cur_Dissolve_Setup_Attempt(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x67c, Value); } // 0x67c (Size: 0x4, Type: IntProperty)
    void SET_AmountOfTimesToAttemptRestoreMats(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x4, Type: IntProperty)
    void SET_Spawn_VFX_Attached(const bool& Value) { Write<bool>(uintptr_t(this) + 0x684, Value); } // 0x684 (Size: 0x1, Type: BoolProperty)
    void SET_Dissolve_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x8, Type: DoubleProperty)
    void SET_Glow_Timeline_Playrate(const double& Value) { Write<double>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x8, Type: DoubleProperty)
    void SET_Material_Override_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x10, Type: StructProperty)
    void SET_Copied_Parameters(const FFortPawnMaterialOverrideCopiedParameters& Value) { Write<FFortPawnMaterialOverrideCopiedParameters>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x30, Type: StructProperty)
    void SET_Delegate_Handle_Controller(const FDelegateHandleController& Value) { Write<FDelegateHandleController>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x741
class AGCN_RezIn_SCMachine_C : public AGCN_RezIn_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x738); } // 0x738 (Size: 0x8, Type: StructProperty)
    bool bEnhancedResurrection() const { return Read<bool>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x738, Value); } // 0x738 (Size: 0x8, Type: StructProperty)
    void SET_bEnhancedResurrection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UEliminationBotVFXInterface_C : public UInterface
{
public:
};

