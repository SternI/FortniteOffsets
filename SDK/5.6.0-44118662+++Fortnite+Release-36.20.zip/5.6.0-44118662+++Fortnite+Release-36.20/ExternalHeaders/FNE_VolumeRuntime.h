/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_VolumeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x348
class AFNE_Volume : public AGameplayVolume
{
public:
};

// Size: 0x330
class UFNE_VolumeComponent : public UChildActorComponent
{
public:
    bool bEnableOverlap() const { return Read<bool>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*> FNEVolumeShapeMap() const { return Read<TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*>>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x50, Type: MapProperty)
    USpatialGameplayActorTrackerComponent* SpatialGameplayActorTracker() const { return Read<USpatialGameplayActorTrackerComponent*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)

    void SET_bEnableOverlap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    void SET_FNEVolumeShapeMap(const TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*>& Value) { Write<TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*>>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x50, Type: MapProperty)
    void SET_SpatialGameplayActorTracker(const USpatialGameplayActorTrackerComponent*& Value) { Write<USpatialGameplayActorTrackerComponent*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x730
class UFNE_VolumeOverlapComponent : public UStaticMeshComponent
{
public:
    uint8_t EnableOverlapBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x1, Type: EnumProperty)
    TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*> FNEVolumeShapeMap() const { return Read<TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*>>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x50, Type: MapProperty)
    uint8_t SceneQueryShape() const { return Read<uint8_t>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x1, Type: EnumProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> SceneQueryObjectTypes() const { return Read<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<AFortMinigame*> CachedMinigame() const { return Read<TWeakObjectPtr<AFortMinigame*>>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: WeakObjectProperty)
    TSet<AActor*> TrackedActors() const { return Read<TSet<AActor*>>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x50, Type: SetProperty)

    void SET_EnableOverlapBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x1, Type: EnumProperty)
    void SET_FNEVolumeShapeMap(const TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*>& Value) { Write<TMap<EFNEVolumeShapeTypeEnum, UStaticMesh*>>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x50, Type: MapProperty)
    void SET_SceneQueryShape(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x1, Type: EnumProperty)
    void SET_SceneQueryObjectTypes(const TArray<TEnumAsByte<EObjectTypeQuery>>& Value) { Write<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedMinigame(const TWeakObjectPtr<AFortMinigame*>& Value) { Write<TWeakObjectPtr<AFortMinigame*>>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackedActors(const TSet<AActor*>& Value) { Write<TSet<AActor*>>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x50, Type: SetProperty)
};

