/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AccoladesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x168
class UPFWAccoladeCollection_Container : public UPersistenceFrameworkContainer
{
public:
};

// Size: 0xe0
class UPFWAccoladeCollection_Module : public UPersistenceFrameworkModule
{
public:
};

// Size: 0xa0
class UPFWAccoladeCollection_Trigger : public UPersistenceFrameworkSaveTrigger_Manual
{
public:
};

// Size: 0x120
class UPFWAccoladeCollection_FilteredListContainer : public UPersistenceFrameworkFilteredListContainer
{
public:
};

// Size: 0x38
class UFortAccoladeCollectionFeatureCollector : public UObject
{
public:
};

// Size: 0x38
class UGameFeatureAction_AddAccoladeTables : public UGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UDataTable*>> AccoladeTables() const { return Read<TArray<TSoftObjectPtr<UDataTable*>>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_AccoladeTables(const TArray<TSoftObjectPtr<UDataTable*>>& Value) { Write<TArray<TSoftObjectPtr<UDataTable*>>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UFortCheatManager_Accolades : public UChildCheatManager
{
public:
};

// Size: 0x338
class UFortControllerComponent_AccoladeCollection : public UFortControllerComponent
{
public:
    FName PinnedAccoladeName() const { return Read<FName>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x4, Type: NameProperty)
    FPersistenceFrameworkSaveControl SaveControl() const { return Read<FPersistenceFrameworkSaveControl>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x10, Type: StructProperty)
    FFortAccoladeCollectionDataArray AccoladeCollectionDataArray() const { return Read<FFortAccoladeCollectionDataArray>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x120, Type: StructProperty)

    void SET_PinnedAccoladeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x4, Type: NameProperty)
    void SET_SaveControl(const FPersistenceFrameworkSaveControl& Value) { Write<FPersistenceFrameworkSaveControl>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x10, Type: StructProperty)
    void SET_AccoladeCollectionDataArray(const FFortAccoladeCollectionDataArray& Value) { Write<FFortAccoladeCollectionDataArray>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x120, Type: StructProperty)
};

// Size: 0x538
class UFortControllerComponent_Accolades : public UFortControllerComponent
{
public:
    FFortUpdatedTrackedAccoladeDataArray UpdatedTrackedAccoladeDataArray() const { return Read<FFortUpdatedTrackedAccoladeDataArray>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x120, Type: StructProperty)
    FFortCompletedAccoladeDataArray CompletedAccoladeDataArray() const { return Read<FFortCompletedAccoladeDataArray>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x120, Type: StructProperty)

    void SET_UpdatedTrackedAccoladeDataArray(const FFortUpdatedTrackedAccoladeDataArray& Value) { Write<FFortUpdatedTrackedAccoladeDataArray>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x120, Type: StructProperty)
    void SET_CompletedAccoladeDataArray(const FFortCompletedAccoladeDataArray& Value) { Write<FFortCompletedAccoladeDataArray>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x120, Type: StructProperty)
};

// Size: 0xc8
class UFortGameStateComponent_AccoladeCollection : public UFortGameStateComponent
{
public:
};

// Size: 0x1c0
class UFortGameStateComponent_Accolades : public UFortGameStateComponent
{
public:
};

// Size: 0x18
struct FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData
{
public:
    FString AccoladeName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    uint32_t AccoladeCount() const { return Read<uint32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: UInt32Property)

    void SET_AccoladeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_AccoladeCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x10
struct FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData
{
public:
    FString AccoladeName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_AccoladeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData
{
public:
    TArray<FString> AccoladeNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_AccoladeNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FPFWAccoladeCollection_PersistentInfo
{
public:
    TArray<FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData> AccoladeCollection_AchievedAccolades() const { return Read<TArray<FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData AccoladeCollection_PinnedAccolade() const { return Read<FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData AccoladeCollection_UnacknowledgedAccolades() const { return Read<FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_AccoladeCollection_AchievedAccolades(const TArray<FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData>& Value) { Write<TArray<FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_AccoladeCollection_PinnedAccolade(const FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData& Value) { Write<FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_AccoladeCollection_UnacknowledgedAccolades(const FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData& Value) { Write<FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FFortAccoladeCollectionDataItem : public FFastArraySerializerItem
{
public:
    FName AccoladeName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    FFortAccoladeCollectionData CollectionData() const { return Read<FFortAccoladeCollectionData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)

    void SET_AccoladeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_CollectionData(const FFortAccoladeCollectionData& Value) { Write<FFortAccoladeCollectionData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FFortAccoladeCollectionData
{
public:
    uint32_t AchievedCount() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    bool bAcknowledged() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_AchievedCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_bAcknowledged(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FFortAccoladeCollectionDataArray : public FFastArraySerializer
{
public:
    TArray<FFortAccoladeCollectionDataItem> AccoladeCollectionData() const { return Read<TArray<FFortAccoladeCollectionDataItem>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)

    void SET_AccoladeCollectionData(const TArray<FFortAccoladeCollectionDataItem>& Value) { Write<TArray<FFortAccoladeCollectionDataItem>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FFortAccoladeSessionData
{
public:
};

// Size: 0x14
struct FFortUpdatedTrackedAccoladeData : public FFastArraySerializerItem
{
public:
    FName AccoladeRowName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    uint32_t Count() const { return Read<uint32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: UInt32Property)

    void SET_AccoladeRowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_Count(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x120
struct FFortUpdatedTrackedAccoladeDataArray : public FFastArraySerializer
{
public:
    TArray<FFortUpdatedTrackedAccoladeData> UpdatedTrackedAccolades() const { return Read<TArray<FFortUpdatedTrackedAccoladeData>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)

    void SET_UpdatedTrackedAccolades(const TArray<FFortUpdatedTrackedAccoladeData>& Value) { Write<TArray<FFortUpdatedTrackedAccoladeData>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FFortCompletedAccoladeData : public FFastArraySerializerItem
{
public:
    FName AccoladeRowName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    uint32_t XPAwarded() const { return Read<uint32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: UInt32Property)
    uint8_t AccoladeType() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)

    void SET_AccoladeRowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_XPAwarded(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: UInt32Property)
    void SET_AccoladeType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x120
struct FFortCompletedAccoladeDataArray : public FFastArraySerializer
{
public:
    TArray<FFortCompletedAccoladeData> CompletedAccolades() const { return Read<TArray<FFortCompletedAccoladeData>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)

    void SET_CompletedAccolades(const TArray<FFortCompletedAccoladeData>& Value) { Write<TArray<FFortCompletedAccoladeData>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x110
struct FFortAccoladesTableRow : public FTableRowBase
{
public:
    FInstancedStruct EventConditional() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> EventRewards() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> OneTimeEventRewards() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: TextProperty)
    FText DisplayDescription() const { return Read<FText>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: TextProperty)
    int32_t DisplayOrder() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)
    uint8_t AccoladeType() const { return Read<uint8_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: EnumProperty)
    uint8_t Priority() const { return Read<uint8_t>(uintptr_t(this) + 0x5d); } // 0x5d (Size: 0x1, Type: EnumProperty)
    uint8_t AccoladeTier() const { return Read<uint8_t>(uintptr_t(this) + 0x5e); } // 0x5e (Size: 0x1, Type: EnumProperty)
    TSoftObjectPtr<USoundCue> AwardedSoundCue() const { return Read<TSoftObjectPtr<USoundCue>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> PreviewImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    int32_t MaxMatchCount() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t MaxPlayerCount() const { return Read<int32_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: IntProperty)
    FGameplayTagContainer Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: StructProperty)
    FGameplayTagQuery ProductCompatibilityQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x48, Type: StructProperty)

    void SET_EventConditional(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_EventRewards(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_OneTimeEventRewards(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: TextProperty)
    void SET_DisplayDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: TextProperty)
    void SET_DisplayOrder(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
    void SET_AccoladeType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: EnumProperty)
    void SET_Priority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5d, Value); } // 0x5d (Size: 0x1, Type: EnumProperty)
    void SET_AccoladeTier(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5e, Value); } // 0x5e (Size: 0x1, Type: EnumProperty)
    void SET_AwardedSoundCue(const TSoftObjectPtr<USoundCue>& Value) { Write<TSoftObjectPtr<USoundCue>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PreviewImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MaxMatchCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_MaxPlayerCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: IntProperty)
    void SET_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: StructProperty)
    void SET_ProductCompatibilityQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x70
struct FFortTriggeredAccoladeData
{
public:
};

