/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "SlateCore.h"
#include "CommonInput.h"

// Size: 0x28
class UDynamicUITransitionableWidgetInterface : public UInterface
{
public:
};

// Size: 0x2c8
class ADynamicUIDirectorBase : public AActor
{
public:
    TArray<UDynamicUIScene*> DefaultScenes() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer() const { return Read<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    bool bEnabledDuringReplay() const { return Read<bool>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x1, Type: BoolProperty)

    void SET_DefaultScenes(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_OwningLocalPlayer(const TWeakObjectPtr<ULocalPlayer*>& Value) { Write<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bEnabledDuringReplay(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UDynamicUIExcludeBase : public UObject
{
public:
};

// Size: 0x38
class UDynamicUIExcludeInputType : public UDynamicUIExcludeBase
{
public:
    TArray<ECommonInputType> InputTypes() const { return Read<TArray<ECommonInputType>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_InputTypes(const TArray<ECommonInputType>& Value) { Write<TArray<ECommonInputType>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
class UDynamicUIConstraintBase : public UObject
{
public:
    FVector2D Offset() const { return Read<FVector2D>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    TArray<UDynamicUIConstraintOverrideBase*> ConstraintOverrides() const { return Read<TArray<UDynamicUIConstraintOverrideBase*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    bool bUseOffset() const { return (Read<uint8_t>(uintptr_t(this) + 0x70) >> 0x0) & 1; } // 0x70:0 (Size: 0x1, Type: BoolProperty)
    bool bUseOverride() const { return (Read<uint8_t>(uintptr_t(this) + 0x70) >> 0x1) & 1; } // 0x70:1 (Size: 0x1, Type: BoolProperty)
    UDynamicUIConstraintOverrideBase* ConstraintOverride() const { return Read<UDynamicUIConstraintOverrideBase*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_Offset(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_ConstraintOverrides(const TArray<UDynamicUIConstraintOverrideBase*>& Value) { Write<TArray<UDynamicUIConstraintOverrideBase*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseOffset(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x70); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x70, B); } // 0x70:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseOverride(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x70); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x70, B); } // 0x70:1 (Size: 0x1, Type: BoolProperty)
    void SET_ConstraintOverride(const UDynamicUIConstraintOverrideBase*& Value) { Write<UDynamicUIConstraintOverrideBase*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x98
class UDynamicUIConstraintPosition : public UDynamicUIConstraintBase
{
public:
    FVector2D Position() const { return Read<FVector2D>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    bool bUseSafeZone() const { return (Read<uint8_t>(uintptr_t(this) + 0x94) >> 0x0) & 1; } // 0x94:0 (Size: 0x1, Type: BoolProperty)

    void SET_Position(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_bUseSafeZone(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x94); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x94, B); } // 0x94:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
class UDynamicUIConstraintAlignment : public UDynamicUIConstraintBase
{
public:
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment() const { return Read<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: ByteProperty)
    FDynamicUIVerticalMargin VerticalMargin() const { return Read<FDynamicUIVerticalMargin>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: StructProperty)
    FDynamicUIHorizontalMargin HorizontalMargin() const { return Read<FDynamicUIHorizontalMargin>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: StructProperty)
    FDynamicUIAspectRatio MaxAspectRatio() const { return Read<FDynamicUIAspectRatio>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)
    bool bUseSafeZone() const { return (Read<uint8_t>(uintptr_t(this) + 0xa0) >> 0x0) & 1; } // 0xa0:0 (Size: 0x1, Type: BoolProperty)
    bool bUseMaxAspectRatio() const { return (Read<uint8_t>(uintptr_t(this) + 0xa0) >> 0x1) & 1; } // 0xa0:1 (Size: 0x1, Type: BoolProperty)

    void SET_HorizontalAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: ByteProperty)
    void SET_VerticalAlignment(const TEnumAsByte<EVerticalAlignment>& Value) { Write<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: ByteProperty)
    void SET_VerticalMargin(const FDynamicUIVerticalMargin& Value) { Write<FDynamicUIVerticalMargin>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: StructProperty)
    void SET_HorizontalMargin(const FDynamicUIHorizontalMargin& Value) { Write<FDynamicUIHorizontalMargin>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: StructProperty)
    void SET_MaxAspectRatio(const FDynamicUIAspectRatio& Value) { Write<FDynamicUIAspectRatio>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
    void SET_bUseSafeZone(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xa0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xa0, B); } // 0xa0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseMaxAspectRatio(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xa0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xa0, B); } // 0xa0:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
class UDynamicUIConstraintWidget : public UDynamicUIConstraintBase
{
public:
    FDynamicUIWidgetTarget TargetWidget() const { return Read<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x78, Type: StructProperty)
    TArray<UDynamicUIConstraintBase*> Fallbacks() const { return Read<TArray<UDynamicUIConstraintBase*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    bool bConstrainToUnallowedWidgets() const { return (Read<uint8_t>(uintptr_t(this) + 0x118) >> 0x0) & 1; } // 0x118:0 (Size: 0x1, Type: BoolProperty)
    bool bUseFallbacks() const { return (Read<uint8_t>(uintptr_t(this) + 0x118) >> 0x1) & 1; } // 0x118:1 (Size: 0x1, Type: BoolProperty)

    void SET_TargetWidget(const FDynamicUIWidgetTarget& Value) { Write<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x78, Type: StructProperty)
    void SET_Fallbacks(const TArray<UDynamicUIConstraintBase*>& Value) { Write<TArray<UDynamicUIConstraintBase*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_bConstrainToUnallowedWidgets(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x118); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x118, B); } // 0x118:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseFallbacks(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x118); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x118, B); } // 0x118:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
class UDynamicUIConstraintContainer : public UDynamicUIConstraintBase
{
public:
    TArray<FDynamicUIWidgetTarget> WidgetsToContain() const { return Read<TArray<FDynamicUIWidgetTarget>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    FMargin Padding() const { return Read<FMargin>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StructProperty)
    bool bMustMatchAllWidgets() const { return (Read<uint8_t>(uintptr_t(this) + 0xa0) >> 0x0) & 1; } // 0xa0:0 (Size: 0x1, Type: BoolProperty)

    void SET_WidgetsToContain(const TArray<FDynamicUIWidgetTarget>& Value) { Write<TArray<FDynamicUIWidgetTarget>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_Padding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StructProperty)
    void SET_bMustMatchAllWidgets(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xa0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xa0, B); } // 0xa0:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
class UDynamicUIConstraintReplace : public UDynamicUIConstraintBase
{
public:
    FDynamicUIWidgetTarget TargetWidget() const { return Read<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x78, Type: StructProperty)
    TArray<UDynamicUIConstraintBase*> Fallbacks() const { return Read<TArray<UDynamicUIConstraintBase*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    bool bUseFallbacks() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x0) & 1; } // 0x108:0 (Size: 0x1, Type: BoolProperty)

    void SET_TargetWidget(const FDynamicUIWidgetTarget& Value) { Write<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x78, Type: StructProperty)
    void SET_Fallbacks(const TArray<UDynamicUIConstraintBase*>& Value) { Write<TArray<UDynamicUIConstraintBase*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseFallbacks(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UDynamicUIConstraintOverrideBase : public UObject
{
public:
};

// Size: 0xd0
class UDynamicUIConstraintPlatformOverride : public UDynamicUIConstraintOverrideBase
{
public:
    TMap<FName, UDynamicUIConstraintBase*> PlatformVisibilityControls() const { return Read<TMap<FName, UDynamicUIConstraintBase*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, UDynamicUIConstraintBase*> InputTypeVisibilityControls() const { return Read<TMap<ECommonInputType, UDynamicUIConstraintBase*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x50, Type: MapProperty)

    void SET_PlatformVisibilityControls(const TMap<FName, UDynamicUIConstraintBase*>& Value) { Write<TMap<FName, UDynamicUIConstraintBase*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
    void SET_InputTypeVisibilityControls(const TMap<ECommonInputType, UDynamicUIConstraintBase*>& Value) { Write<TMap<ECommonInputType, UDynamicUIConstraintBase*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x50, Type: MapProperty)
};

// Size: 0x30
class UDynamicUIConstraintSplitscreenOverride : public UDynamicUIConstraintOverrideBase
{
public:
    UDynamicUIConstraintBase* SplitscreenConstraintOverride() const { return Read<UDynamicUIConstraintBase*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_SplitscreenConstraintOverride(const UDynamicUIConstraintBase*& Value) { Write<UDynamicUIConstraintBase*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x98
class UDynamicUIManager : public UWorldSubsystem
{
public:
    TMap<TWeakObjectPtr<ULocalPlayer*>, FDynamicUIPlayerData> PlayerDataMap() const { return Read<TMap<TWeakObjectPtr<ULocalPlayer*>, FDynamicUIPlayerData>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: MapProperty)

    void SET_PlayerDataMap(const TMap<TWeakObjectPtr<ULocalPlayer*>, FDynamicUIPlayerData>& Value) { Write<TMap<TWeakObjectPtr<ULocalPlayer*>, FDynamicUIPlayerData>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: MapProperty)
};

// Size: 0x78
class UDynamicUIScene : public UDataAsset
{
public:
    char LayerId() const { return Read<char>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: ByteProperty)
    TArray<FDynamicUIAllowed> Allowed() const { return Read<TArray<FDynamicUIAllowed>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicUIUnallowBase*> Unallow() const { return Read<TArray<UDynamicUIUnallowBase*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FDynamicUIAdjust> Adjust() const { return Read<TArray<FDynamicUIAdjust>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FDynamicUIPreload> Preload() const { return Read<TArray<FDynamicUIPreload>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_LayerId(const char& Value) { Write<char>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: ByteProperty)
    void SET_Allowed(const TArray<FDynamicUIAllowed>& Value) { Write<TArray<FDynamicUIAllowed>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_Unallow(const TArray<UDynamicUIUnallowBase*>& Value) { Write<TArray<UDynamicUIUnallowBase*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_Adjust(const TArray<FDynamicUIAdjust>& Value) { Write<TArray<FDynamicUIAdjust>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_Preload(const TArray<FDynamicUIPreload>& Value) { Write<TArray<FDynamicUIPreload>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
class UDynamicUISizeBase : public UObject
{
public:
    UDynamicUISizeOverrideBase* SizeOverride() const { return Read<UDynamicUISizeOverrideBase*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bUseOverride() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x0) & 1; } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    bool bUseRenderTransform() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x1) & 1; } // 0x58:1 (Size: 0x1, Type: BoolProperty)

    void SET_SizeOverride(const UDynamicUISizeOverrideBase*& Value) { Write<UDynamicUISizeOverrideBase*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_bUseOverride(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseRenderTransform(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
class UDynamicUISizeFixed : public UDynamicUISizeBase
{
public:
    FVector2f Size() const { return Read<FVector2f>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)

    void SET_Size(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
};

// Size: 0x68
class UDynamicUISizeScale : public UDynamicUISizeBase
{
public:
    FVector2f Scale() const { return Read<FVector2f>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)

    void SET_Scale(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
};

// Size: 0xf8
class UDynamicUISizeMatchWidget : public UDynamicUISizeBase
{
public:
    FDynamicUIWidgetTarget TargetWidget() const { return Read<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x78, Type: StructProperty)
    TArray<UDynamicUISizeBase*> Fallbacks() const { return Read<TArray<UDynamicUISizeBase*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    bool bUseFallbacks() const { return (Read<uint8_t>(uintptr_t(this) + 0xf0) >> 0x0) & 1; } // 0xf0:0 (Size: 0x1, Type: BoolProperty)

    void SET_TargetWidget(const FDynamicUIWidgetTarget& Value) { Write<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x78, Type: StructProperty)
    void SET_Fallbacks(const TArray<UDynamicUISizeBase*>& Value) { Write<TArray<UDynamicUISizeBase*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseFallbacks(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xf0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xf0, B); } // 0xf0:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UDynamicUISizeOverrideBase : public UObject
{
public:
};

// Size: 0xd0
class UDynamicUISizeOverridePlatform : public UDynamicUISizeOverrideBase
{
public:
    TMap<FName, UDynamicUISizeBase*> PlatformOverrides() const { return Read<TMap<FName, UDynamicUISizeBase*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)
    TMap<ECommonInputType, UDynamicUISizeBase*> InputTypeOverrides() const { return Read<TMap<ECommonInputType, UDynamicUISizeBase*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x50, Type: MapProperty)

    void SET_PlatformOverrides(const TMap<FName, UDynamicUISizeBase*>& Value) { Write<TMap<FName, UDynamicUISizeBase*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
    void SET_InputTypeOverrides(const TMap<ECommonInputType, UDynamicUISizeBase*>& Value) { Write<TMap<ECommonInputType, UDynamicUISizeBase*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x50, Type: MapProperty)
};

// Size: 0x30
class UDynamicUISizeSplitscreenOverride : public UDynamicUISizeOverrideBase
{
public:
    UDynamicUISizeBase* SplitscreenSizeModifier() const { return Read<UDynamicUISizeBase*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_SplitscreenSizeModifier(const UDynamicUISizeBase*& Value) { Write<UDynamicUISizeBase*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UDynamicUIUnallowBase : public UObject
{
public:
    TArray<UDynamicUIExcludeBase*> ExcludeConditions() const { return Read<TArray<UDynamicUIExcludeBase*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bUseExclude() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x0) & 1; } // 0x40:0 (Size: 0x1, Type: BoolProperty)

    void SET_ExcludeConditions(const TArray<UDynamicUIExcludeBase*>& Value) { Write<TArray<UDynamicUIExcludeBase*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseExclude(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc8
class UDynamicUIUnallowWidget : public UDynamicUIUnallowBase
{
public:
    FDynamicUIWidgetTarget Widget() const { return Read<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x78, Type: StructProperty)
    bool bTargetAll() const { return (Read<uint8_t>(uintptr_t(this) + 0xc0) >> 0x0) & 1; } // 0xc0:0 (Size: 0x1, Type: BoolProperty)

    void SET_Widget(const FDynamicUIWidgetTarget& Value) { Write<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x78, Type: StructProperty)
    void SET_bTargetAll(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc0, B); } // 0xc0:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UDynamicUIUnallowLayer : public UDynamicUIUnallowBase
{
public:
    char LayerId() const { return Read<char>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    uint8_t Comparison() const { return Read<uint8_t>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: EnumProperty)

    void SET_LayerId(const char& Value) { Write<char>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_Comparison(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x110
class UDynamicUIUnallowScene : public UDynamicUIUnallowBase
{
public:
    FDynamicUISceneTarget Scene() const { return Read<FDynamicUISceneTarget>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    TArray<FDynamicUIWidgetTarget> Exclusions() const { return Read<TArray<FDynamicUIWidgetTarget>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)

    void SET_Scene(const FDynamicUISceneTarget& Value) { Write<FDynamicUISceneTarget>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_Exclusions(const TArray<FDynamicUIWidgetTarget>& Value) { Write<TArray<FDynamicUIWidgetTarget>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FDynamicUIManagerDebug
{
public:
};

// Size: 0x1
struct FDynamicUIPanelDebug
{
public:
};

// Size: 0x88
struct FDynamicUIAdjust
{
public:
    FDynamicUIWidgetTarget TargetWidget() const { return Read<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x78, Type: StructProperty)
    UDynamicUIConstraintBase* LayoutConstraint() const { return Read<UDynamicUIConstraintBase*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    UDynamicUISizeBase* SizeModifier() const { return Read<UDynamicUISizeBase*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetWidget(const FDynamicUIWidgetTarget& Value) { Write<FDynamicUIWidgetTarget>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x78, Type: StructProperty)
    void SET_LayoutConstraint(const UDynamicUIConstraintBase*& Value) { Write<UDynamicUIConstraintBase*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeModifier(const UDynamicUISizeBase*& Value) { Write<UDynamicUISizeBase*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
struct FDynamicUIWidgetTarget
{
public:
    FName WidgetPath() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FSoftObjectPath WidgetAssetPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FName UniqueID() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)
    bool bUseWidgetClass() const { return (Read<uint8_t>(uintptr_t(this) + 0x44) >> 0x0) & 1; } // 0x44:0 (Size: 0x1, Type: BoolProperty)
    bool bUseUniqueID() const { return (Read<uint8_t>(uintptr_t(this) + 0x44) >> 0x1) & 1; } // 0x44:1 (Size: 0x1, Type: BoolProperty)

    void SET_WidgetPath(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_WidgetAssetPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_UniqueID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
    void SET_bUseWidgetClass(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x44); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x44, B); } // 0x44:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseUniqueID(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x44); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x44, B); } // 0x44:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
struct FDynamicUIAllowed
{
public:
    int32_t CustomZOrder() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    FName UniqueID() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UCommonInputActionDomain> ActionDomain() const { return Read<TSoftObjectPtr<UCommonInputActionDomain>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    UDynamicUIConstraintBase* LayoutConstraint() const { return Read<UDynamicUIConstraintBase*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    UDynamicUISizeBase* SizeModifier() const { return Read<UDynamicUISizeBase*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicUIExcludeBase*> ExcludeConditions() const { return Read<TArray<UDynamicUIExcludeBase*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    char LayerIDOverride() const { return Read<char>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: ByteProperty)
    bool bIsUnique() const { return (Read<uint8_t>(uintptr_t(this) + 0x71) >> 0x0) & 1; } // 0x71:0 (Size: 0x1, Type: BoolProperty)
    bool bUseActionDomain() const { return (Read<uint8_t>(uintptr_t(this) + 0x71) >> 0x1) & 1; } // 0x71:1 (Size: 0x1, Type: BoolProperty)
    bool bUseLayerOverride() const { return (Read<uint8_t>(uintptr_t(this) + 0x71) >> 0x2) & 1; } // 0x71:2 (Size: 0x1, Type: BoolProperty)
    bool bUseExclude() const { return (Read<uint8_t>(uintptr_t(this) + 0x71) >> 0x3) & 1; } // 0x71:3 (Size: 0x1, Type: BoolProperty)

    void SET_CustomZOrder(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_UniqueID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_ActionDomain(const TSoftObjectPtr<UCommonInputActionDomain>& Value) { Write<TSoftObjectPtr<UCommonInputActionDomain>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LayoutConstraint(const UDynamicUIConstraintBase*& Value) { Write<UDynamicUIConstraintBase*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeModifier(const UDynamicUISizeBase*& Value) { Write<UDynamicUISizeBase*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_ExcludeConditions(const TArray<UDynamicUIExcludeBase*>& Value) { Write<TArray<UDynamicUIExcludeBase*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_LayerIDOverride(const char& Value) { Write<char>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: ByteProperty)
    void SET_bIsUnique(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x71); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x71, B); } // 0x71:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseActionDomain(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x71); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x71, B); } // 0x71:1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseLayerOverride(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x71); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x71, B); } // 0x71:2 (Size: 0x1, Type: BoolProperty)
    void SET_bUseExclude(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x71); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x71, B); } // 0x71:3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FDynamicUIAspectRatio
{
public:
    float CustomAspectRatio() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_CustomAspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDynamicUIVerticalMargin
{
public:
    float Top() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Bottom() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Top(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Bottom(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDynamicUIHorizontalMargin
{
public:
    float Left() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Right() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Left(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Right(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FDynamicUIPreload
{
public:
};

// Size: 0x18
struct FDynamicUISceneTarget
{
public:
    FSoftObjectPath SceneAssetPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_SceneAssetPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1
struct FDynamicUISceneData
{
public:
};

// Size: 0x30
struct FDynamicUIDirectorData
{
public:
    TWeakObjectPtr<AActor*> Instance() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Instance(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x90
struct FDynamicUIPlayerData
{
public:
    TMap<FString, FDynamicUIDirectorData> ActiveDirectors() const { return Read<TMap<FString, FDynamicUIDirectorData>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: MapProperty)

    void SET_ActiveDirectors(const TMap<FString, FDynamicUIDirectorData>& Value) { Write<TMap<FString, FDynamicUIDirectorData>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: MapProperty)
};

