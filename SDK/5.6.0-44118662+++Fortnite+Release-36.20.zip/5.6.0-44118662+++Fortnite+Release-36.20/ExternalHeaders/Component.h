/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Component
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "Niagara.h"

// Size: 0xa30
class ACameraEntityProxyActor : public ACameraActor
{
public:
};

// Size: 0x2b0
class APointLightProxyActor : public ALightProxyActor
{
public:
};

// Size: 0x2b0
class ALightProxyActor : public AActor
{
public:
    ULightComponent* LightComponent() const { return Read<ULightComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_LightComponent(const ULightComponent*& Value) { Write<ULightComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b0
class ADirectionalLightProxyActor : public ALightProxyActor
{
public:
};

// Size: 0x200
class UStaticMeshEntityComponent_Implementation : public UObject
{
public:
    TArray<UMaterialInterface*> OverrideMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x10, Type: ArrayProperty)

    void SET_OverrideMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2b0
class AParticleSystemProxyActor : public AActor
{
public:
    UNiagaraComponent* NiagaraComponent() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_NiagaraComponent(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1b0
class UPhysicsEntityComponent_Implementation : public UObject
{
public:
    FBodyInstance BodyInstance() const { return Read<FBodyInstance>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x178, Type: StructProperty)

    void SET_BodyInstance(const FBodyInstance& Value) { Write<FBodyInstance>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x178, Type: StructProperty)
};

// Size: 0x60
class UPresentationOwner : public UObject
{
public:
    FUniqueNetIdRepl NetId() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x30, Type: StructProperty)
    TWeakObjectPtr<AController*> Controller() const { return Read<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: WeakObjectProperty)

    void SET_NetId(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x30, Type: StructProperty)
    void SET_Controller(const TWeakObjectPtr<AController*>& Value) { Write<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2b0
class ARectLightProxyActor : public ALightProxyActor
{
public:
};

// Size: 0x100
class UVerseRigidBodyMeshPhysics : public UObject
{
public:
};

// Size: 0x2b0
class ASoundProxyActor : public AActor
{
public:
    UAudioComponent* AudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_AudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b0
class ASphereLightProxyActor : public ALightProxyActor
{
public:
};

// Size: 0x2b0
class ASpotLightProxyActor : public ALightProxyActor
{
public:
};

// Size: 0x320
class ATextDisplayProxyActor : public AActor
{
public:
    UTextRenderComponent* TextRenderComponent() const { return Read<UTextRenderComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* TextMaterialInstanceDynamic() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UFont* Font() const { return Read<UFont*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)

    void SET_TextRenderComponent(const UTextRenderComponent*& Value) { Write<UTextRenderComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_TextMaterialInstanceDynamic(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Font(const UFont*& Value) { Write<UFont*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FEntityMeshFragment : public FMassConstSharedFragment
{
public:
    TWeakObjectPtr<UStaticMesh*> Mesh() const { return Read<TWeakObjectPtr<UStaticMesh*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Mesh(const TWeakObjectPtr<UStaticMesh*>& Value) { Write<TWeakObjectPtr<UStaticMesh*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x21
struct FEntityColliderFragment : public FMassConstSharedFragment
{
public:
    TEnumAsByte<ECollisionEnabled> CollisionType() const { return Read<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    FCollisionResponseContainer CollisionResponse() const { return Read<FCollisionResponseContainer>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x20, Type: StructProperty)

    void SET_CollisionType(const TEnumAsByte<ECollisionEnabled>& Value) { Write<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_CollisionResponse(const FCollisionResponseContainer& Value) { Write<FCollisionResponseContainer>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x20, Type: StructProperty)
};

