/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDPlayerTracker
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0xb8
class UCRDPlayerTrackerComponent : public UActorComponent
{
public:
};

// Size: 0x2b8
class ACRDPlayerTrackerMarker : public AActor
{
public:
    UClass* WidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ClassProperty)
    UActorComponent* PlayerTrackerUIActorComponent() const { return Read<UActorComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_WidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ClassProperty)
    void SET_PlayerTrackerUIActorComponent(const UActorComponent*& Value) { Write<UActorComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

