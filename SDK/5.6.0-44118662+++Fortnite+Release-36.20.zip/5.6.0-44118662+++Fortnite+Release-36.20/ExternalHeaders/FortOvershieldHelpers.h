/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortOvershieldHelpers
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x160
class UFortOvershieldHelperComponent : public UActorComponent
{
public:
};

// Size: 0x48
struct FFortOvershieldDelegateContainer
{
public:
};

