/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Blade
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "SlateCore.h"
#include "Engine.h"
#include "UMG.h"

// Size: 0xcb0
class UWBP_Blade_C : public UFortBladeWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: StructProperty)
    USafeZone* SafeZone() const { return Read<USafeZone*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_BladeContent() const { return Read<UOverlay*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UNamedSlot* NamedSlot_BladeContent_Foreground() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UNamedSlot* NamedSlot_BladeContent() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Grid_BladeBase() const { return Read<UGridPanel*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UImage* FullBackplate_Image() const { return Read<UImage*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UButton* EmptyButton_ForPeekMode() const { return Read<UButton*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UButton* EmptyButton_ClickCatcherCloseBlade() const { return Read<UButton*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ExpandContract() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_BackplateOpacity() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_BetweenPeekStates() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<E_BladeUIAnchor> EBladeAlignment() const { return Read<TEnumAsByte<E_BladeUIAnchor>>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x1, Type: ByteProperty)
    bool bStartExpanded() const { return Read<bool>(uintptr_t(this) + 0x3b9); } // 0x3b9 (Size: 0x1, Type: BoolProperty)
    int32_t RowSpan_Content() const { return Read<int32_t>(uintptr_t(this) + 0x3bc); } // 0x3bc (Size: 0x4, Type: IntProperty)
    int32_t Row_Content() const { return Read<int32_t>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: IntProperty)
    int32_t ColumnSpan_Content() const { return Read<int32_t>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x4, Type: IntProperty)
    int32_t Column_Content() const { return Read<int32_t>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: IntProperty)
    double ContentWidth() const { return Read<double>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: DoubleProperty)
    double ContentHeight() const { return Read<double>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    double LerpAnimatorExpandContractBlade() const { return Read<double>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: DoubleProperty)
    double NudgeForOffscreen() const { return Read<double>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    bool UseFullscreenBlade() const { return Read<bool>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x1, Type: BoolProperty)
    double PeekPushPercent() const { return Read<double>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: DoubleProperty)
    double PeekPushPercent_Mobile() const { return Read<double>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: DoubleProperty)
    bool EnableSecondaryPeekState() const { return Read<bool>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x1, Type: BoolProperty)
    double PeekPushPercentSecondary() const { return Read<double>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: DoubleProperty)
    double PeekPushPercentSecondary_Mobile() const { return Read<double>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: DoubleProperty)
    FSlateBrush BackplateImageBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0xb0, Type: StructProperty)
    bool bHasClickCatcherButton() const { return Read<bool>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x1, Type: BoolProperty)
    bool bIsClickCatcherButtonTransparent() const { return Read<bool>(uintptr_t(this) + 0x4d1); } // 0x4d1 (Size: 0x1, Type: BoolProperty)
    FButtonStyle ClickCatcherButtonStyle() const { return Read<FButtonStyle>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x390, Type: StructProperty)
    FButtonStyle TransparentButtonStyle() const { return Read<FButtonStyle>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x390, Type: StructProperty)
    TEnumAsByte<E_BladeAnimationState> EBladeAnimState() const { return Read<TEnumAsByte<E_BladeAnimationState>>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x1, Type: ByteProperty)
    FMargin ContentPadding() const { return Read<FMargin>(uintptr_t(this) + 0xc04); } // 0xc04 (Size: 0x10, Type: StructProperty)
    bool AnimateBackplateWhenExpanding() const { return Read<bool>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x1, Type: BoolProperty)
    bool HidePeekButton() const { return Read<bool>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x1, Type: BoolProperty)
    bool FinishedTransitionToSecondPeekState() const { return Read<bool>(uintptr_t(this) + 0xc51); } // 0xc51 (Size: 0x1, Type: BoolProperty)
    double LerpAnimatorBetweenPeekStates() const { return Read<double>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: DoubleProperty)
    bool StartedTransitionToSecondPeekState() const { return Read<bool>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x1, Type: BoolProperty)
    double PreviousLerpAnimValue() const { return Read<double>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: StructProperty)
    void SET_SafeZone(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_BladeContent(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_NamedSlot_BladeContent_Foreground(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_NamedSlot_BladeContent(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Grid_BladeBase(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_FullBackplate_Image(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_EmptyButton_ForPeekMode(const UButton*& Value) { Write<UButton*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_EmptyButton_ClickCatcherCloseBlade(const UButton*& Value) { Write<UButton*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_ExpandContract(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_BackplateOpacity(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_BetweenPeekStates(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_EBladeAlignment(const TEnumAsByte<E_BladeUIAnchor>& Value) { Write<TEnumAsByte<E_BladeUIAnchor>>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x1, Type: ByteProperty)
    void SET_bStartExpanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b9, Value); } // 0x3b9 (Size: 0x1, Type: BoolProperty)
    void SET_RowSpan_Content(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3bc, Value); } // 0x3bc (Size: 0x4, Type: IntProperty)
    void SET_Row_Content(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: IntProperty)
    void SET_ColumnSpan_Content(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x4, Type: IntProperty)
    void SET_Column_Content(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: IntProperty)
    void SET_ContentWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: DoubleProperty)
    void SET_ContentHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    void SET_LerpAnimatorExpandContractBlade(const double& Value) { Write<double>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: DoubleProperty)
    void SET_NudgeForOffscreen(const double& Value) { Write<double>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    void SET_UseFullscreenBlade(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x1, Type: BoolProperty)
    void SET_PeekPushPercent(const double& Value) { Write<double>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: DoubleProperty)
    void SET_PeekPushPercent_Mobile(const double& Value) { Write<double>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: DoubleProperty)
    void SET_EnableSecondaryPeekState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x1, Type: BoolProperty)
    void SET_PeekPushPercentSecondary(const double& Value) { Write<double>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: DoubleProperty)
    void SET_PeekPushPercentSecondary_Mobile(const double& Value) { Write<double>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: DoubleProperty)
    void SET_BackplateImageBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0xb0, Type: StructProperty)
    void SET_bHasClickCatcherButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsClickCatcherButtonTransparent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d1, Value); } // 0x4d1 (Size: 0x1, Type: BoolProperty)
    void SET_ClickCatcherButtonStyle(const FButtonStyle& Value) { Write<FButtonStyle>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x390, Type: StructProperty)
    void SET_TransparentButtonStyle(const FButtonStyle& Value) { Write<FButtonStyle>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x390, Type: StructProperty)
    void SET_EBladeAnimState(const TEnumAsByte<E_BladeAnimationState>& Value) { Write<TEnumAsByte<E_BladeAnimationState>>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x1, Type: ByteProperty)
    void SET_ContentPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0xc04, Value); } // 0xc04 (Size: 0x10, Type: StructProperty)
    void SET_AnimateBackplateWhenExpanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x1, Type: BoolProperty)
    void SET_HidePeekButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x1, Type: BoolProperty)
    void SET_FinishedTransitionToSecondPeekState(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc51, Value); } // 0xc51 (Size: 0x1, Type: BoolProperty)
    void SET_LerpAnimatorBetweenPeekStates(const double& Value) { Write<double>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: DoubleProperty)
    void SET_StartedTransitionToSecondPeekState(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x1, Type: BoolProperty)
    void SET_PreviousLerpAnimValue(const double& Value) { Write<double>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x8, Type: DoubleProperty)
};

