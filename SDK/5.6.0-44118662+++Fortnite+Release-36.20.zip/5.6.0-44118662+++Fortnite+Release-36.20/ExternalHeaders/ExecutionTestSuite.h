/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ExecutionTestSuite
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x60
class UExecTestObject : public UObject
{
public:
};

