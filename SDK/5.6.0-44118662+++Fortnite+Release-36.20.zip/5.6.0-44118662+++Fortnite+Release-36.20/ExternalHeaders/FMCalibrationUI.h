/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMCalibrationUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FMCalibrationRuntime.h"

// Size: 0xf8
class UCalibrationProcessVM : public UMVVMViewModelBase
{
public:
    TWeakObjectPtr<UFMCalibrationControllerComponent*> StoredCalibrationComponent() const { return Read<TWeakObjectPtr<UFMCalibrationControllerComponent*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: WeakObjectProperty)
    float MinAudioCalibrationMs() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float MaxAudioCalibrationMs() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float MinVideoCalibrationMs() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaxVideoCalibrationMs() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    float ErrorFractionOutOfWindow() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float ErrorHalfWindowFrames() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinErrorHalfWindowSizeMs() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float AudioSamplesMultiplier() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)

    void SET_StoredCalibrationComponent(const TWeakObjectPtr<UFMCalibrationControllerComponent*>& Value) { Write<TWeakObjectPtr<UFMCalibrationControllerComponent*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MinAudioCalibrationMs(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAudioCalibrationMs(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_MinVideoCalibrationMs(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_MaxVideoCalibrationMs(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_ErrorFractionOutOfWindow(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_ErrorHalfWindowFrames(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MinErrorHalfWindowSizeMs(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_AudioSamplesMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UCalibrationProfileVM : public UMVVMViewModelBase
{
public:
    bool bHasUsedCalibrationProfileFeature() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    int32_t ActiveProfileIndex() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    UFMCalibrationControllerComponent* CalibrationComponent() const { return Read<UFMCalibrationControllerComponent*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)

    void SET_bHasUsedCalibrationProfileFeature(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_ActiveProfileIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_CalibrationComponent(const UFMCalibrationControllerComponent*& Value) { Write<UFMCalibrationControllerComponent*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
};

