/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Execution
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x48
class UExecutionSubsystem : public UEngineSubsystem
{
public:
};

// Size: 0x48
class UBaseExecution : public UObject
{
public:
};

