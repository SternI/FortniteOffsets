/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AIDebuggerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28
class UAIDebuggerCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x5c0
class UAIDebuggerRendererComponent : public UPrimitiveComponent
{
public:
    UMaterial* NavMeshMaterial() const { return Read<UMaterial*>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    float NavLinkLineThickness() const { return Read<float>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    float NavLinkMaxDrawDistance() const { return Read<float>(uintptr_t(this) + 0x5bc); } // 0x5bc (Size: 0x4, Type: FloatProperty)

    void SET_NavMeshMaterial(const UMaterial*& Value) { Write<UMaterial*>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    void SET_NavLinkLineThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    void SET_NavLinkMaxDrawDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x5bc, Value); } // 0x5bc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x128
class UFortControllerComponent_AIDebugger : public UFortControllerComponent
{
public:
    APlayerController* OwnerPC() const { return Read<APlayerController*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UClass* NavMeshRendererComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    char DefaultEnabledVisualizers() const { return Read<char>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: ByteProperty)
    int32_t DefaultNavDataIndexToDisplay() const { return Read<int32_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: IntProperty)
    char EnabledVisualizers() const { return Read<char>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: ByteProperty)
    char NumNavMeshes() const { return Read<char>(uintptr_t(this) + 0xd9); } // 0xd9 (Size: 0x1, Type: ByteProperty)

    void SET_OwnerPC(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_NavMeshRendererComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultEnabledVisualizers(const char& Value) { Write<char>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: ByteProperty)
    void SET_DefaultNavDataIndexToDisplay(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: IntProperty)
    void SET_EnabledVisualizers(const char& Value) { Write<char>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: ByteProperty)
    void SET_NumNavMeshes(const char& Value) { Write<char>(uintptr_t(this) + 0xd9, Value); } // 0xd9 (Size: 0x1, Type: ByteProperty)
};

