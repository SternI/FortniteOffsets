/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AttachableWheelsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x348
class AAttachableWheel : public AActor
{
public:
    UStaticMeshComponent* WheelMeshComponent() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    FRotator WheelOrientation() const { return Read<FRotator>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x18, Type: StructProperty)
    float WheelDistance() const { return Read<float>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    UPhysicsConstraintComponent* AxleConstraint() const { return Read<UPhysicsConstraintComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    FAttachableWheelAttachData AttachData() const { return Read<FAttachableWheelAttachData>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x58, Type: StructProperty)
    bool bAutoCreateAttachableWheelsComponent() const { return Read<bool>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x1, Type: BoolProperty)
    bool bEnableWheelWheelCollision() const { return Read<bool>(uintptr_t(this) + 0x331); } // 0x331 (Size: 0x1, Type: BoolProperty)
    bool bReplicateRuntimeData() const { return Read<bool>(uintptr_t(this) + 0x332); } // 0x332 (Size: 0x1, Type: BoolProperty)
    FAttachableWheelRuntimeData RuntimeData() const { return Read<FAttachableWheelRuntimeData>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0xc, Type: StructProperty)

    void SET_WheelMeshComponent(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_WheelOrientation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x18, Type: StructProperty)
    void SET_WheelDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    void SET_AxleConstraint(const UPhysicsConstraintComponent*& Value) { Write<UPhysicsConstraintComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_AttachData(const FAttachableWheelAttachData& Value) { Write<FAttachableWheelAttachData>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x58, Type: StructProperty)
    void SET_bAutoCreateAttachableWheelsComponent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableWheelWheelCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x331, Value); } // 0x331 (Size: 0x1, Type: BoolProperty)
    void SET_bReplicateRuntimeData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x332, Value); } // 0x332 (Size: 0x1, Type: BoolProperty)
    void SET_RuntimeData(const FAttachableWheelRuntimeData& Value) { Write<FAttachableWheelRuntimeData>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0xc, Type: StructProperty)
};

// Size: 0x120
class UAttachableWheelsComponent : public UActorComponent
{
public:
    TSet<AAttachableWheel*> AttachedWheels() const { return Read<TSet<AAttachableWheel*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x50, Type: SetProperty)
    float MaxChassisMassFraction() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)

    void SET_AttachedWheels(const TSet<AAttachableWheel*>& Value) { Write<TSet<AAttachableWheel*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x50, Type: SetProperty)
    void SET_MaxChassisMassFraction(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
struct FAttachableWheelAttachData
{
public:
    TWeakObjectPtr<UPrimitiveComponent*> PrimitiveComponent() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FVector Pos() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Axis1() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Axis2() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    float Damping() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FName AttachmentName() const { return Read<FName>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: NameProperty)

    void SET_PrimitiveComponent(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Pos(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Axis1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Axis2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_Damping(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_AttachmentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: NameProperty)
};

// Size: 0xc
struct FAttachableWheelRuntimeData
{
public:
    float Torque() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Velocity() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float SteerAngle() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Torque(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Velocity(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_SteerAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

