/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_ProjectileTrajectory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x322
class ABP_ProjectileTrajectory_C : public AFortProjectileTrajectory
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* InvalidTarget() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Target() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxMeshCount() const { return Read<int32_t>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x4, Type: IntProperty)
    UMaterialInstanceDynamic* SplineMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    double SplineFadeDistance() const { return Read<double>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: DoubleProperty)
    double SplineFadeStartDistance() const { return Read<double>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: DoubleProperty)
    UObject* TrajectoryOwner() const { return Read<UObject*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool ShouldUpdate() const { return Read<bool>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* InvalidSplineMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    bool bIsTrajectoryValid() const { return Read<bool>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x1, Type: BoolProperty)
    bool bWaitFirstTrajectoryValid() const { return Read<bool>(uintptr_t(this) + 0x321); } // 0x321 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: StructProperty)
    void SET_InvalidTarget(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxMeshCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x4, Type: IntProperty)
    void SET_SplineMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineFadeDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: DoubleProperty)
    void SET_SplineFadeStartDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: DoubleProperty)
    void SET_TrajectoryOwner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_ShouldUpdate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x1, Type: BoolProperty)
    void SET_InvalidSplineMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsTrajectoryValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x1, Type: BoolProperty)
    void SET_bWaitFirstTrajectoryValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x321, Value); } // 0x321 (Size: 0x1, Type: BoolProperty)
};

