/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AndroidPermission
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x50
class UAndroidPermissionCallbackProxy : public UObject
{
public:
};

// Size: 0x28
class UAndroidPermissionFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

