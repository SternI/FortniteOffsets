/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayCameras
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CameraCalibrationCore.h"
#include "MovieScene.h"
#include "CinematicCamera.h"
#include "EnhancedInput.h"
#include "StateTreeModule.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x28
class UBlueprintCameraEvaluationDataFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UBlueprintCameraVariableTableFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UBlueprintCameraContextDataTableFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UHasCameraBuildStatus : public UInterface
{
public:
};

// Size: 0x48
class UCombinedCameraRigsCameraNode : public UCameraNode
{
public:
    TArray<FCameraRigAssetReference> CameraRigReferences() const { return Read<TArray<FCameraRigAssetReference>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_CameraRigReferences(const TArray<FCameraRigAssetReference>& Value) { Write<TArray<FCameraRigAssetReference>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UCameraNode : public UObject
{
public:
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UCameraRigInput1DSlot : public UInput1DCameraNode
{
public:
    FCameraRigInputSlotParameters InputSlotParameters() const { return Read<FCameraRigInputSlotParameters>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x2, Type: StructProperty)
    FCameraParameterClamping clamp() const { return Read<FCameraParameterClamping>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FCameraParameterNormalization Normalize() const { return Read<FCameraParameterNormalization>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FDoubleCameraVariableReference CustomVariable() const { return Read<FDoubleCameraVariableReference>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StructProperty)
    FCameraVariableID TransientVariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: StructProperty)

    void SET_InputSlotParameters(const FCameraRigInputSlotParameters& Value) { Write<FCameraRigInputSlotParameters>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x2, Type: StructProperty)
    void SET_clamp(const FCameraParameterClamping& Value) { Write<FCameraParameterClamping>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Normalize(const FCameraParameterNormalization& Value) { Write<FCameraParameterNormalization>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_CustomVariable(const FDoubleCameraVariableReference& Value) { Write<FDoubleCameraVariableReference>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StructProperty)
    void SET_TransientVariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
class UInput1DCameraNode : public UCameraNode
{
public:
};

// Size: 0xb0
class UCameraRigInput2DSlot : public UInput2DCameraNode
{
public:
    FCameraRigInputSlotParameters InputSlotParameters() const { return Read<FCameraRigInputSlotParameters>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x2, Type: StructProperty)
    FCameraParameterClamping ClampX() const { return Read<FCameraParameterClamping>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FCameraParameterClamping ClampY() const { return Read<FCameraParameterClamping>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FCameraParameterNormalization NormalizeX() const { return Read<FCameraParameterNormalization>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StructProperty)
    FCameraParameterNormalization NormalizeY() const { return Read<FCameraParameterNormalization>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    FVector2dCameraVariableReference CustomVariable() const { return Read<FVector2dCameraVariableReference>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    FCameraVariableID TransientVariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: StructProperty)

    void SET_InputSlotParameters(const FCameraRigInputSlotParameters& Value) { Write<FCameraRigInputSlotParameters>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x2, Type: StructProperty)
    void SET_ClampX(const FCameraParameterClamping& Value) { Write<FCameraParameterClamping>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_ClampY(const FCameraParameterClamping& Value) { Write<FCameraParameterClamping>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_NormalizeX(const FCameraParameterNormalization& Value) { Write<FCameraParameterNormalization>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StructProperty)
    void SET_NormalizeY(const FCameraParameterNormalization& Value) { Write<FCameraParameterNormalization>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_CustomVariable(const FVector2dCameraVariableReference& Value) { Write<FVector2dCameraVariableReference>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_TransientVariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
class UInput2DCameraNode : public UCameraNode
{
public:
};

// Size: 0x28
class UCameraRigInstanceFunctions : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x48
class UCompositeShakeCameraNode : public UShakeCameraNode
{
public:
    TArray<UShakeCameraNode*> Shakes() const { return Read<TArray<UShakeCameraNode*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Shakes(const TArray<UShakeCameraNode*>& Value) { Write<TArray<UShakeCameraNode*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UShakeCameraNode : public UCameraNode
{
public:
};

// Size: 0x70
class UEnvelopeShakeCameraNode : public UShakeCameraNode
{
public:
    FFloatCameraParameter EaseInTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter EaseOutTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter TotalTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    UShakeCameraNode* Shake() const { return Read<UShakeCameraNode*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_EaseInTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_EaseOutTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_TotalTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_Shake(const UShakeCameraNode*& Value) { Write<UShakeCameraNode*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1f8
class UGameplayCameraParameterSetterComponent : public UActorComponent
{
public:
    FCameraRigAssetReference CameraRigReference() const { return Read<FCameraRigAssetReference>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x120, Type: StructProperty)
    float BlendInTime() const { return Read<float>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: FloatProperty)
    float BlendOutTime() const { return Read<float>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0x4, Type: FloatProperty)
    uint8_t BlendType() const { return Read<uint8_t>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x1, Type: EnumProperty)

    void SET_CameraRigReference(const FCameraRigAssetReference& Value) { Write<FCameraRigAssetReference>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x120, Type: StructProperty)
    void SET_BlendInTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: FloatProperty)
    void SET_BlendOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0x4, Type: FloatProperty)
    void SET_BlendType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x30e0
class AGameplayCamerasPlayerCameraManager : public APlayerCameraManager
{
public:
    bool bOverrideViewRotationMode() const { return Read<bool>(uintptr_t(this) + 0x27f4); } // 0x27f4 (Size: 0x1, Type: BoolProperty)
    APlayerCameraManager* OriginalCameraManager() const { return Read<APlayerCameraManager*>(uintptr_t(this) + 0x27f8); } // 0x27f8 (Size: 0x8, Type: ObjectProperty)

    void SET_bOverrideViewRotationMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x27f4, Value); } // 0x27f4 (Size: 0x1, Type: BoolProperty)
    void SET_OriginalCameraManager(const APlayerCameraManager*& Value) { Write<APlayerCameraManager*>(uintptr_t(this) + 0x27f8, Value); } // 0x27f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UViewTargetTransitionParamsBlendCameraNode : public USimpleBlendCameraNode
{
public:
    FViewTargetTransitionParams TransitionParams() const { return Read<FViewTargetTransitionParams>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_TransitionParams(const FViewTargetTransitionParams& Value) { Write<FViewTargetTransitionParams>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
class USimpleBlendCameraNode : public UBlendCameraNode
{
public:
};

// Size: 0x38
class UBlendCameraNode : public UCameraNode
{
public:
};

// Size: 0x78
class UUpdateTrackerCameraNode : public UCameraNode
{
public:
    FDoubleCameraParameter DoubleParameter() const { return Read<FDoubleCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector3dCameraParameter VectorParameter() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)

    void SET_DoubleParameter(const FDoubleCameraParameter& Value) { Write<FDoubleCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_VectorParameter(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UAssetReferenceCameraNode : public UInterface
{
public:
};

// Size: 0x28
class UCustomCameraNodeParameterProvider : public UInterface
{
public:
};

// Size: 0x28
class UGameplayCameraSystemHost : public UInterface
{
public:
};

// Size: 0x100
class UInputAxisBinding2DCameraNode : public UCameraRigInput2DSlot
{
public:
    TArray<UInputAction*> AxisActions() const { return Read<TArray<UInputAction*>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    FBooleanCameraParameter RevertAxisX() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter RevertAxisY() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    FVector2dCameraParameter Multiplier() const { return Read<FVector2dCameraParameter>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x20, Type: StructProperty)

    void SET_AxisActions(const TArray<UInputAction*>& Value) { Write<TArray<UInputAction*>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_RevertAxisX(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: StructProperty)
    void SET_RevertAxisY(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_Multiplier(const FVector2dCameraParameter& Value) { Write<FVector2dCameraParameter>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UObjectTreeGraphObject : public UInterface
{
public:
};

// Size: 0x28
class UObjectTreeGraphRootObject : public UInterface
{
public:
};

// Size: 0x80
class UPerlinNoiseLocationShakeCameraNode : public UShakeCameraNode
{
public:
    FFloatCameraParameter AmplitudeMultiplier() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter FrequencyMultiplier() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FInteger32CameraParameter Octaves() const { return Read<FInteger32CameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FPerlinNoiseData X() const { return Read<FPerlinNoiseData>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData Y() const { return Read<FPerlinNoiseData>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData Z() const { return Read<FPerlinNoiseData>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)

    void SET_AmplitudeMultiplier(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_FrequencyMultiplier(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_Octaves(const FInteger32CameraParameter& Value) { Write<FInteger32CameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_X(const FPerlinNoiseData& Value) { Write<FPerlinNoiseData>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: StructProperty)
    void SET_Y(const FPerlinNoiseData& Value) { Write<FPerlinNoiseData>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: StructProperty)
    void SET_Z(const FPerlinNoiseData& Value) { Write<FPerlinNoiseData>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
};

// Size: 0x80
class UPerlinNoiseRotationShakeCameraNode : public UShakeCameraNode
{
public:
    FFloatCameraParameter AmplitudeMultiplier() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter FrequencyMultiplier() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FInteger32CameraParameter Octaves() const { return Read<FInteger32CameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FPerlinNoiseData Yaw() const { return Read<FPerlinNoiseData>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData pitch() const { return Read<FPerlinNoiseData>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData Roll() const { return Read<FPerlinNoiseData>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)

    void SET_AmplitudeMultiplier(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_FrequencyMultiplier(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_Octaves(const FInteger32CameraParameter& Value) { Write<FInteger32CameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_Yaw(const FPerlinNoiseData& Value) { Write<FPerlinNoiseData>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: StructProperty)
    void SET_pitch(const FPerlinNoiseData& Value) { Write<FPerlinNoiseData>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: StructProperty)
    void SET_Roll(const FPerlinNoiseData& Value) { Write<FPerlinNoiseData>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa8
class UBaseCameraObject : public UObject
{
public:
    FCameraObjectInterface Interface() const { return Read<FCameraObjectInterface>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x30, Type: StructProperty)
    FCameraObjectAllocationInfo AllocationInfo() const { return Read<FCameraObjectAllocationInfo>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FInstancedPropertyBag DefaultParameters() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    TArray<FCameraObjectInterfaceParameterDefinition> ParameterDefinitions() const { return Read<TArray<FCameraObjectInterfaceParameterDefinition>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)

    void SET_Interface(const FCameraObjectInterface& Value) { Write<FCameraObjectInterface>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x30, Type: StructProperty)
    void SET_AllocationInfo(const FCameraObjectAllocationInfo& Value) { Write<FCameraObjectAllocationInfo>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_DefaultParameters(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_ParameterDefinitions(const TArray<FCameraObjectInterfaceParameterDefinition>& Value) { Write<TArray<FCameraObjectInterfaceParameterDefinition>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UBlendStackCameraNode : public UCameraNode
{
public:
    uint8_t Layer() const { return Read<uint8_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: EnumProperty)

    void SET_Layer(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: EnumProperty)
};

// Size: 0x48
class UBlendStackRootCameraNode : public UCameraNode
{
public:
    UBlendCameraNode* Blend() const { return Read<UBlendCameraNode*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UCameraNode* RootNode() const { return Read<UCameraNode*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_Blend(const UBlendCameraNode*& Value) { Write<UBlendCameraNode*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_RootNode(const UCameraNode*& Value) { Write<UCameraNode*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
class UCameraAsset : public UObject
{
public:
    UCameraDirector* CameraDirector() const { return Read<UCameraDirector*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    TArray<UCameraRigTransition*> EnterTransitions() const { return Read<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigTransition*> ExitTransitions() const { return Read<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    uint8_t BuildStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    FInstancedPropertyBag DefaultParameters() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)
    TArray<FCameraObjectInterfaceParameterDefinition> ParameterDefinitions() const { return Read<TArray<FCameraObjectInterfaceParameterDefinition>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigAsset*> ParameterOwners() const { return Read<TArray<UCameraRigAsset*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    FCameraAssetAllocationInfo AllocationInfo() const { return Read<FCameraAssetAllocationInfo>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: StructProperty)
    TArray<UCameraRigAsset*> CameraRigs() const { return Read<TArray<UCameraRigAsset*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_CameraDirector(const UCameraDirector*& Value) { Write<UCameraDirector*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_EnterTransitions(const TArray<UCameraRigTransition*>& Value) { Write<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_ExitTransitions(const TArray<UCameraRigTransition*>& Value) { Write<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_BuildStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_DefaultParameters(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
    void SET_ParameterDefinitions(const TArray<FCameraObjectInterfaceParameterDefinition>& Value) { Write<TArray<FCameraObjectInterfaceParameterDefinition>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_ParameterOwners(const TArray<UCameraRigAsset*>& Value) { Write<TArray<UCameraRigAsset*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_AllocationInfo(const FCameraAssetAllocationInfo& Value) { Write<FCameraAssetAllocationInfo>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: StructProperty)
    void SET_CameraRigs(const TArray<UCameraRigAsset*>& Value) { Write<TArray<UCameraRigAsset*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UCameraDirector : public UObject
{
public:
    FCameraRigProxyRedirectTable CameraRigProxyRedirectTable() const { return Read<FCameraRigProxyRedirectTable>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    UCameraRigProxyTable* CameraRigProxyTable() const { return Read<UCameraRigProxyTable*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRigProxyRedirectTable(const FCameraRigProxyRedirectTable& Value) { Write<FCameraRigProxyRedirectTable>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_CameraRigProxyTable(const UCameraRigProxyTable*& Value) { Write<UCameraRigProxyTable*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x60
class UCameraObjectInterfaceParameterBase : public UObject
{
public:
    FString InterfaceParameterName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    UCameraNode* Target() const { return Read<UCameraNode*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName TargetPropertyName() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x10, Type: StructProperty)

    void SET_InterfaceParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_Target(const UCameraNode*& Value) { Write<UCameraNode*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x10, Type: StructProperty)
};

// Size: 0x80
class UCameraObjectInterfaceBlendableParameter : public UCameraObjectInterfaceParameterBase
{
public:
    UScriptStruct* BlendableStructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bIsPreBlended() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    FCameraVariableID PrivateVariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: StructProperty)
    UCameraVariableAsset* PrivateVariable() const { return Read<UCameraVariableAsset*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_BlendableStructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsPreBlended(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_PrivateVariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: StructProperty)
    void SET_PrivateVariable(const UCameraVariableAsset*& Value) { Write<UCameraVariableAsset*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
class UCameraObjectInterfaceDataParameter : public UCameraObjectInterfaceParameterBase
{
public:
    UObject* DataTypeObject() const { return Read<UObject*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FCameraContextDataID PrivateDataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)

    void SET_DataTypeObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_PrivateDataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
};

// Size: 0x128
class UCameraRigAsset : public UBaseCameraObject
{
public:
    UCameraNode* RootNode() const { return Read<UCameraNode*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    TArray<UCameraRigTransition*> EnterTransitions() const { return Read<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigTransition*> ExitTransitions() const { return Read<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    uint8_t BuildStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x1, Type: EnumProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: StructProperty)

    void SET_RootNode(const UCameraNode*& Value) { Write<UCameraNode*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_EnterTransitions(const TArray<UCameraRigTransition*>& Value) { Write<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_ExitTransitions(const TArray<UCameraRigTransition*>& Value) { Write<TArray<UCameraRigTransition*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_BuildStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x1, Type: EnumProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
class UCameraRigProxyAsset : public UObject
{
public:
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
class UCameraRigProxyTable : public UObject
{
public:
    TArray<FCameraRigProxyRedirectTableEntry> Entries() const { return Read<TArray<FCameraRigProxyRedirectTableEntry>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FCameraRigProxyRedirectTableEntry>& Value) { Write<TArray<FCameraRigProxyRedirectTableEntry>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
class UCameraRigTransitionCondition : public UObject
{
public:
};

// Size: 0x50
class UCameraRigTransition : public UObject
{
public:
    TArray<UCameraRigTransitionCondition*> Conditions() const { return Read<TArray<UCameraRigTransitionCondition*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    UBlendCameraNode* Blend() const { return Read<UBlendCameraNode*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    bool bOverrideInitialOrientation() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bAllowCameraRigMerging() const { return Read<bool>(uintptr_t(this) + 0x4d); } // 0x4d (Size: 0x1, Type: BoolProperty)

    void SET_Conditions(const TArray<UCameraRigTransitionCondition*>& Value) { Write<TArray<UCameraRigTransitionCondition*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Blend(const UBlendCameraNode*& Value) { Write<UBlendCameraNode*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_bOverrideInitialOrientation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_bAllowCameraRigMerging(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d, Value); } // 0x4d (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf0
class UCameraShakeAsset : public UBaseCameraObject
{
public:
    UShakeCameraNode* RootNode() const { return Read<UShakeCameraNode*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    USimpleFixedTimeBlendCameraNode* BlendIn() const { return Read<USimpleFixedTimeBlendCameraNode*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    USimpleFixedTimeBlendCameraNode* BlendOut() const { return Read<USimpleFixedTimeBlendCameraNode*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    bool bIsSingleInstance() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t BuildStatus() const { return Read<uint8_t>(uintptr_t(this) + 0xd9); } // 0xd9 (Size: 0x1, Type: EnumProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x10, Type: StructProperty)

    void SET_RootNode(const UShakeCameraNode*& Value) { Write<UShakeCameraNode*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendIn(const USimpleFixedTimeBlendCameraNode*& Value) { Write<USimpleFixedTimeBlendCameraNode*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendOut(const USimpleFixedTimeBlendCameraNode*& Value) { Write<USimpleFixedTimeBlendCameraNode*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsSingleInstance(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    void SET_BuildStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd9, Value); } // 0xd9 (Size: 0x1, Type: EnumProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
class UCameraValueInterpolator : public UObject
{
public:
};

// Size: 0x28
class UPopValueInterpolator : public UCameraValueInterpolator
{
public:
};

// Size: 0x40
class UCameraVariableAsset : public UObject
{
public:
    bool bAutoReset() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsPrivate() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bIsInput() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)

    void SET_bAutoReset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPrivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
class UBooleanCameraVariable : public UCameraVariableAsset
{
public:
    bool bDefaultValue() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)

    void SET_bDefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
class UInteger32CameraVariable : public UCameraVariableAsset
{
public:
    int32_t DefaultValue() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)

    void SET_DefaultValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
};

// Size: 0x48
class UFloatCameraVariable : public UCameraVariableAsset
{
public:
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
class UDoubleCameraVariable : public UCameraVariableAsset
{
public:
    double DefaultValue() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)

    void SET_DefaultValue(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x48
class UVector2fCameraVariable : public UCameraVariableAsset
{
public:
    FVector2f DefaultValue() const { return Read<FVector2f>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: StructProperty)

    void SET_DefaultValue(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: StructProperty)
};

// Size: 0x50
class UVector2dCameraVariable : public UCameraVariableAsset
{
public:
    FVector2D DefaultValue() const { return Read<FVector2D>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_DefaultValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
class UVector3fCameraVariable : public UCameraVariableAsset
{
public:
    FVector3f DefaultValue() const { return Read<FVector3f>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xc, Type: StructProperty)

    void SET_DefaultValue(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xc, Type: StructProperty)
};

// Size: 0x58
class UVector3dCameraVariable : public UCameraVariableAsset
{
public:
    FVector3d DefaultValue() const { return Read<FVector3d>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_DefaultValue(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
class UVector4fCameraVariable : public UCameraVariableAsset
{
public:
    FVector4f DefaultValue() const { return Read<FVector4f>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_DefaultValue(const FVector4f& Value) { Write<FVector4f>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x60
class UVector4dCameraVariable : public UCameraVariableAsset
{
public:
    FVector4d DefaultValue() const { return Read<FVector4d>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)

    void SET_DefaultValue(const FVector4d& Value) { Write<FVector4d>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
class URotator3fCameraVariable : public UCameraVariableAsset
{
public:
    FRotator3f DefaultValue() const { return Read<FRotator3f>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xc, Type: StructProperty)

    void SET_DefaultValue(const FRotator3f& Value) { Write<FRotator3f>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xc, Type: StructProperty)
};

// Size: 0x58
class URotator3dCameraVariable : public UCameraVariableAsset
{
public:
    FRotator3d DefaultValue() const { return Read<FRotator3d>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_DefaultValue(const FRotator3d& Value) { Write<FRotator3d>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
class UTransform3fCameraVariable : public UCameraVariableAsset
{
public:
    FTransform3f DefaultValue() const { return Read<FTransform3f>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x30, Type: StructProperty)

    void SET_DefaultValue(const FTransform3f& Value) { Write<FTransform3f>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x30, Type: StructProperty)
};

// Size: 0xa0
class UTransform3dCameraVariable : public UCameraVariableAsset
{
public:
    FTransform3d DefaultValue() const { return Read<FTransform3d>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x60, Type: StructProperty)

    void SET_DefaultValue(const FTransform3d& Value) { Write<FTransform3d>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x60, Type: StructProperty)
};

// Size: 0x38
class UCameraVariableCollection : public UObject
{
public:
    TArray<UCameraVariableAsset*> Variables() const { return Read<TArray<UCameraVariableAsset*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Variables(const TArray<UCameraVariableAsset*>& Value) { Write<TArray<UCameraVariableAsset*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
class UDefaultRootCameraNode : public URootCameraNode
{
public:
    UBlendStackCameraNode* BaseLayer() const { return Read<UBlendStackCameraNode*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UBlendStackCameraNode* MainLayer() const { return Read<UBlendStackCameraNode*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    UBlendStackCameraNode* GlobalLayer() const { return Read<UBlendStackCameraNode*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UBlendStackCameraNode* VisualLayer() const { return Read<UBlendStackCameraNode*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_BaseLayer(const UBlendStackCameraNode*& Value) { Write<UBlendStackCameraNode*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_MainLayer(const UBlendStackCameraNode*& Value) { Write<UBlendStackCameraNode*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_GlobalLayer(const UBlendStackCameraNode*& Value) { Write<UBlendStackCameraNode*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_VisualLayer(const UBlendStackCameraNode*& Value) { Write<UBlendStackCameraNode*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class URootCameraNode : public UCameraNode
{
public:
};

// Size: 0x30
class UObjectTreeGraphComment : public UObject
{
public:
};

// Size: 0x140
class UBlueprintCameraDirectorEvaluator : public UObject
{
public:
};

// Size: 0x48
class UBlueprintCameraDirector : public UCameraDirector
{
public:
    UClass* CameraDirectorEvaluatorClass() const { return Read<UClass*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ClassProperty)

    void SET_CameraDirectorEvaluatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x38
class UCameraDirectorStateTreeSchema : public UStateTreeSchema
{
public:
    TArray<FStateTreeExternalDataDesc> ContextDataDescs() const { return Read<TArray<FStateTreeExternalDataDesc>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ContextDataDescs(const TArray<FStateTreeExternalDataDesc>& Value) { Write<TArray<FStateTreeExternalDataDesc>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UPriorityQueueCameraDirector : public UCameraDirector
{
public:
};

// Size: 0x48
class USingleCameraDirector : public UCameraDirector
{
public:
    UCameraRigAsset* CameraRig() const { return Read<UCameraRigAsset*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRig(const UCameraRigAsset*& Value) { Write<UCameraRigAsset*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x68
class UStateTreeCameraDirector : public UCameraDirector
{
public:
    FStateTreeReference StateTreeReference() const { return Read<FStateTreeReference>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x28, Type: StructProperty)

    void SET_StateTreeReference(const FStateTreeReference& Value) { Write<FStateTreeReference>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UActivateCameraRigFunctions : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x38
class UCameraComponentCameraNode : public UCameraNode
{
public:
};

// Size: 0x38
class UCalcCameraActorCameraNode : public UCameraNode
{
public:
};

// Size: 0x28
class UBlueprintCameraPoseFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UCameraRigParameterInterop : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xe8
class UControllerGameplayCameraEvaluationComponent : public UActorComponent
{
public:
    TScriptInterface<Class> CameraSystemHost() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: InterfaceProperty)

    void SET_CameraSystemHost(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x2b0
class AGameplayCameraActor : public AGameplayCameraActorBase
{
public:
    UGameplayCameraComponent* CameraComponent() const { return Read<UGameplayCameraComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraComponent(const UGameplayCameraComponent*& Value) { Write<UGameplayCameraComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2a8
class AGameplayCameraActorBase : public AActor
{
public:
};

// Size: 0x2c0
class UGameplayCameraComponent : public UGameplayCameraComponentBase
{
public:
    FCameraAssetReference CameraReference() const { return Read<FCameraAssetReference>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x38, Type: StructProperty)
    UCameraAsset* Camera() const { return Read<UCameraAsset*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraReference(const FCameraAssetReference& Value) { Write<FCameraAssetReference>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x38, Type: StructProperty)
    void SET_Camera(const UCameraAsset*& Value) { Write<UCameraAsset*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x280
class UGameplayCameraComponentBase : public USceneComponent
{
public:
    TEnumAsByte<EAutoReceiveInput> AutoActivateForPlayer() const { return Read<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x1, Type: ByteProperty)
    bool bSetControlRotationWhenViewTarget() const { return Read<bool>(uintptr_t(this) + 0x259); } // 0x259 (Size: 0x1, Type: BoolProperty)
    UCineCameraComponent* OutputCameraComponent() const { return Read<UCineCameraComponent*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)

    void SET_AutoActivateForPlayer(const TEnumAsByte<EAutoReceiveInput>& Value) { Write<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x1, Type: ByteProperty)
    void SET_bSetControlRotationWhenViewTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x259, Value); } // 0x259 (Size: 0x1, Type: BoolProperty)
    void SET_OutputCameraComponent(const UCineCameraComponent*& Value) { Write<UCineCameraComponent*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b0
class AGameplayCameraRigActor : public AGameplayCameraActorBase
{
public:
    UGameplayCameraRigComponent* CameraRigComponent() const { return Read<UGameplayCameraRigComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRigComponent(const UGameplayCameraRigComponent*& Value) { Write<UGameplayCameraRigComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3b0
class UGameplayCameraRigComponent : public UGameplayCameraComponentBase
{
public:
    FCameraRigAssetReference CameraRigReference() const { return Read<FCameraRigAssetReference>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x120, Type: StructProperty)
    UCameraAsset* GeneratedCameraAsset() const { return Read<UCameraAsset*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRigReference(const FCameraRigAssetReference& Value) { Write<FCameraRigAssetReference>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x120, Type: StructProperty)
    void SET_GeneratedCameraAsset(const UCameraAsset*& Value) { Write<UCameraAsset*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b0
class AGameplayCameraSystemActor : public AActor
{
public:
    UGameplayCameraSystemComponent* CameraSystemComponent() const { return Read<UGameplayCameraSystemComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraSystemComponent(const UGameplayCameraSystemComponent*& Value) { Write<UGameplayCameraSystemComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x270
class UGameplayCameraSystemComponent : public USceneComponent
{
public:
    TEnumAsByte<EAutoReceiveInput> AutoActivateForPlayer() const { return Read<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x1, Type: ByteProperty)
    bool bSetPlayerControllerRotation() const { return Read<bool>(uintptr_t(this) + 0x259); } // 0x259 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<APlayerController*> WeakPlayerController() const { return Read<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x25c); } // 0x25c (Size: 0x8, Type: WeakObjectProperty)

    void SET_AutoActivateForPlayer(const TEnumAsByte<EAutoReceiveInput>& Value) { Write<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x1, Type: ByteProperty)
    void SET_bSetPlayerControllerRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x259, Value); } // 0x259 (Size: 0x1, Type: BoolProperty)
    void SET_WeakPlayerController(const TWeakObjectPtr<APlayerController*>& Value) { Write<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x25c, Value); } // 0x25c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x100
class UGameplayControlRotationComponent : public UActorComponent
{
public:
    TArray<UInputAction*> AxisActions() const { return Read<TArray<UInputAction*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    float AxisActionAngularSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float AxisActionMagnitudeThreshold() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAutoReceiveInput> AutoActivateForPlayer() const { return Read<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: ByteProperty)
    APlayerController* PlayerController() const { return Read<APlayerController*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> CameraSystemHost() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: InterfaceProperty)

    void SET_AxisActions(const TArray<UInputAction*>& Value) { Write<TArray<UInputAction*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_AxisActionAngularSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_AxisActionMagnitudeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_AutoActivateForPlayer(const TEnumAsByte<EAutoReceiveInput>& Value) { Write<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: ByteProperty)
    void SET_PlayerController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraSystemHost(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x60
class UGameplayCamerasSettings : public UDeveloperSettings
{
public:
    bool bAutoBuildInPIE() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    int32_t CombinedCameraRigNumThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    double DefaultIKAimingAngleTolerance() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double DefaultIKAimingDistanceTolerance() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    char DefaultIKAimingMaxIterations() const { return Read<char>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: ByteProperty)
    double DefaultIKAimingMinDistance() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)

    void SET_bAutoBuildInPIE(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_CombinedCameraRigNumThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_DefaultIKAimingAngleTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_DefaultIKAimingDistanceTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_DefaultIKAimingMaxIterations(const char& Value) { Write<char>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: ByteProperty)
    void SET_DefaultIKAimingMinDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x58
class UMovieSceneCameraFramingZonePropertySystem : public UMovieScenePropertySystem
{
public:
};

// Size: 0x570
class UMovieSceneCameraFramingZoneSection : public UMovieSceneSection
{
public:
    FMovieSceneDoubleChannel LeftMarginCurve() const { return Read<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x118, Type: StructProperty)
    FMovieSceneDoubleChannel TopMarginCurve() const { return Read<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x118, Type: StructProperty)
    FMovieSceneDoubleChannel RightMarginCurve() const { return Read<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x118, Type: StructProperty)
    FMovieSceneDoubleChannel BottomMarginCurve() const { return Read<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x118, Type: StructProperty)

    void SET_LeftMarginCurve(const FMovieSceneDoubleChannel& Value) { Write<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x118, Type: StructProperty)
    void SET_TopMarginCurve(const FMovieSceneDoubleChannel& Value) { Write<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x118, Type: StructProperty)
    void SET_RightMarginCurve(const FMovieSceneDoubleChannel& Value) { Write<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x118, Type: StructProperty)
    void SET_BottomMarginCurve(const FMovieSceneDoubleChannel& Value) { Write<FMovieSceneDoubleChannel>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x118, Type: StructProperty)
};

// Size: 0x138
class UMovieSceneCameraFramingZoneTrack : public UMovieScenePropertyTrack
{
public:
};

// Size: 0x30
class UMovieSceneCameraParameterDecoration : public UObject
{
public:
};

// Size: 0x50
class UMovieSceneCameraParameterInstantiator : public UMovieSceneEntityInstantiatorSystem
{
public:
};

// Size: 0x78
class UAttachToActorCameraNode : public UCameraNode
{
public:
    FCameraActorAttachmentInfo Attachment() const { return Read<FCameraActorAttachmentInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FCameraContextDataID AttachmentDataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: StructProperty)
    FBooleanCameraParameter AttachToLocation() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AttachToRotation() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)

    void SET_Attachment(const FCameraActorAttachmentInfo& Value) { Write<FCameraActorAttachmentInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_AttachmentDataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: StructProperty)
    void SET_AttachToLocation(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_AttachToRotation(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
class UAttachToActorGroupCameraNode : public UCameraNode
{
public:
    TArray<FCameraActorAttachmentInfo> Attachments() const { return Read<TArray<FCameraActorAttachmentInfo>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    FCameraContextDataID AttachmentsDataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: StructProperty)

    void SET_Attachments(const TArray<FCameraActorAttachmentInfo>& Value) { Write<TArray<FCameraActorAttachmentInfo>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_AttachmentsDataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: StructProperty)
};

// Size: 0x58
class UAttachToPlayerPawnCameraNode : public UCameraNode
{
public:
    FBooleanCameraParameter AttachToLocation() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AttachToRotation() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)

    void SET_AttachToLocation(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_AttachToRotation(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
class ULinearBlendCameraNode : public USimpleFixedTimeBlendCameraNode
{
public:
};

// Size: 0x40
class USimpleFixedTimeBlendCameraNode : public USimpleBlendCameraNode
{
public:
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
class ULocationRotationBlendCameraNode : public UBlendCameraNode
{
public:
    USimpleBlendCameraNode* LocationBlend() const { return Read<USimpleBlendCameraNode*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    USimpleBlendCameraNode* RotationBlend() const { return Read<USimpleBlendCameraNode*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    USimpleBlendCameraNode* OtherBlend() const { return Read<USimpleBlendCameraNode*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_LocationBlend(const USimpleBlendCameraNode*& Value) { Write<USimpleBlendCameraNode*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_RotationBlend(const USimpleBlendCameraNode*& Value) { Write<USimpleBlendCameraNode*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherBlend(const USimpleBlendCameraNode*& Value) { Write<USimpleBlendCameraNode*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UOrbitBlendCameraNode : public UBlendCameraNode
{
public:
    USimpleBlendCameraNode* DrivingBlend() const { return Read<USimpleBlendCameraNode*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_DrivingBlend(const USimpleBlendCameraNode*& Value) { Write<USimpleBlendCameraNode*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UPopBlendCameraNode : public UBlendCameraNode
{
public:
};

// Size: 0x48
class USmoothBlendCameraNode : public USimpleFixedTimeBlendCameraNode
{
public:
};

// Size: 0xc0
class UCollisionPushCameraNode : public UCameraNode
{
public:
    uint8_t SafePosition() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    FVector3dCameraVariableReference CustomSafePosition() const { return Read<FVector3dCameraVariableReference>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    FVector3dCameraParameter SafePositionOffset() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    uint8_t SafePositionOffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    FBooleanCameraVariableReference EnableCollision() const { return Read<FBooleanCameraVariableReference>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter CollisionSphereRadius() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> CollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: ByteProperty)
    UCameraValueInterpolator* PushInterpolator() const { return Read<UCameraValueInterpolator*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UCameraValueInterpolator* PullInterpolator() const { return Read<UCameraValueInterpolator*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    bool bRunAsyncCollision() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)

    void SET_SafePosition(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_CustomSafePosition(const FVector3dCameraVariableReference& Value) { Write<FVector3dCameraVariableReference>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_SafePositionOffset(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_SafePositionOffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_EnableCollision(const FBooleanCameraVariableReference& Value) { Write<FBooleanCameraVariableReference>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_CollisionSphereRadius(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StructProperty)
    void SET_CollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: ByteProperty)
    void SET_PushInterpolator(const UCameraValueInterpolator*& Value) { Write<UCameraValueInterpolator*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_PullInterpolator(const UCameraValueInterpolator*& Value) { Write<UCameraValueInterpolator*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_bRunAsyncCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UOcclusionMaterialCameraNode : public UCameraNode
{
public:
    UMaterialInterface* OcclusionTransparencyMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    FFloatCameraParameter OcclusionSphereRadius() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> OcclusionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: ByteProperty)
    uint8_t OcclusionTargetPosition() const { return Read<uint8_t>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: EnumProperty)
    uint8_t OcclusionTargetOffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x52); } // 0x52 (Size: 0x1, Type: EnumProperty)
    FVector3dCameraParameter OcclusionTargetOffset() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)

    void SET_OcclusionTransparencyMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_OcclusionSphereRadius(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_OcclusionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: ByteProperty)
    void SET_OcclusionTargetPosition(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: EnumProperty)
    void SET_OcclusionTargetOffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x52, Value); } // 0x52 (Size: 0x1, Type: EnumProperty)
    void SET_OcclusionTargetOffset(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
};

// Size: 0x48
class UArrayCameraNode : public UCameraNode
{
public:
    TArray<UCameraNode*> Children() const { return Read<TArray<UCameraNode*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Children(const TArray<UCameraNode*>& Value) { Write<TArray<UCameraNode*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
class UAutoFocusCameraNode : public UCameraNode
{
public:
    FBooleanCameraVariableReference EnableAutoFocus() const { return Read<FBooleanCameraVariableReference>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter AutoFocusDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)

    void SET_EnableAutoFocus(const FBooleanCameraVariableReference& Value) { Write<FBooleanCameraVariableReference>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_AutoFocusDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
};

// Size: 0x58
class UBodyParametersCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter ShutterSpeed() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter ISO() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)

    void SET_ShutterSpeed(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_ISO(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
};

// Size: 0xa0
class UBoomArmCameraNode : public UCameraNode
{
public:
    FVector3dCameraParameter BoomOffset() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    UCameraValueInterpolator* BoomLengthInterpolator() const { return Read<UCameraValueInterpolator*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    FDoubleCameraParameter MaxForwardInterpolationFactor() const { return Read<FDoubleCameraParameter>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FDoubleCameraParameter MaxBackwardInterpolationFactor() const { return Read<FDoubleCameraParameter>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    UInput2DCameraNode* InputSlot() const { return Read<UInput2DCameraNode*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)

    void SET_BoomOffset(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_BoomLengthInterpolator(const UCameraValueInterpolator*& Value) { Write<UCameraValueInterpolator*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxForwardInterpolationFactor(const FDoubleCameraParameter& Value) { Write<FDoubleCameraParameter>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_MaxBackwardInterpolationFactor(const FDoubleCameraParameter& Value) { Write<FDoubleCameraParameter>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_InputSlot(const UInput2DCameraNode*& Value) { Write<UInput2DCameraNode*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x168
class UCameraRigCameraNode : public UCameraNode
{
public:
    FCameraRigAssetReference CameraRigReference() const { return Read<FCameraRigAssetReference>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x120, Type: StructProperty)

    void SET_CameraRigReference(const FCameraRigAssetReference& Value) { Write<FCameraRigAssetReference>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x120, Type: StructProperty)
};

// Size: 0x68
class UClippingPlanesCameraNode : public UCameraNode
{
public:
    FDoubleCameraParameter NearPlane() const { return Read<FDoubleCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FDoubleCameraParameter FarPlane() const { return Read<FDoubleCameraParameter>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)

    void SET_NearPlane(const FDoubleCameraParameter& Value) { Write<FDoubleCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_FarPlane(const FDoubleCameraParameter& Value) { Write<FDoubleCameraParameter>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
class UDampenPositionCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter ForwardDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter LateralDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter VerticalDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    uint8_t DampenSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)

    void SET_ForwardDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_LateralDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_VerticalDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_DampenSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x68
class UDampenRotationCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter YawDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter PitchDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter RollDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)

    void SET_YawDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_PitchDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_RollDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
class UFieldOfViewCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter FieldOfView() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_FieldOfView(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0xb0
class UFilmbackCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter SensorWidth() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter SensorHeight() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter SensorHorizontalOffset() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter SensorVerticalOffset() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter Overscan() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter ConstrainAspectRatio() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter OverrideAspectRatioAxisConstraint() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EAspectRatioAxisConstraint> AspectRatioAxisConstraint() const { return Read<TEnumAsByte<EAspectRatioAxisConstraint>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: ByteProperty)

    void SET_SensorWidth(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_SensorHeight(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_SensorHorizontalOffset(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_SensorVerticalOffset(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_Overscan(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
    void SET_ConstrainAspectRatio(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_OverrideAspectRatioAxisConstraint(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_AspectRatioAxisConstraint(const TEnumAsByte<EAspectRatioAxisConstraint>& Value) { Write<TEnumAsByte<EAspectRatioAxisConstraint>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x40
class ULensCalibrationCameraNode : public UCameraNode
{
public:
    ULensFile* LensFile() const { return Read<ULensFile*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_LensFile(const ULensFile*& Value) { Write<ULensFile*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
class ULensParametersCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter FocalLength() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter FocusDistance() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter Aperture() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter EnablePhysicalCamera() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)

    void SET_FocalLength(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_FocusDistance(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_Aperture(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_EnablePhysicalCamera(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
};

// Size: 0x90
class UOffsetCameraNode : public UCameraNode
{
public:
    FVector3dCameraParameter TranslationOffset() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    FRotator3dCameraParameter RotationOffset() const { return Read<FRotator3dCameraParameter>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    uint8_t OffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: EnumProperty)

    void SET_TranslationOffset(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_RotationOffset(const FRotator3dCameraParameter& Value) { Write<FRotator3dCameraParameter>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_OffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x58
class UOrthographicCameraNode : public UCameraNode
{
public:
    FBooleanCameraParameter EnableOrthographicMode() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter OrthographicWidth() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)

    void SET_EnableOrthographicMode(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_OrthographicWidth(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
};

// Size: 0x7a0
class UPostProcessCameraNode : public UCameraNode
{
public:
    FPostProcessSettings PostProcessSettings() const { return Read<FPostProcessSettings>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x760, Type: StructProperty)

    void SET_PostProcessSettings(const FPostProcessSettings& Value) { Write<FPostProcessSettings>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x760, Type: StructProperty)
};

// Size: 0x68
class USetLocationCameraNode : public UCameraNode
{
public:
    FVector3dCameraParameter Location() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    uint8_t OffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: EnumProperty)

    void SET_Location(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_OffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x68
class USetRotationCameraNode : public UCameraNode
{
public:
    FRotator3dCameraParameter Rotation() const { return Read<FRotator3dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    uint8_t OffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: EnumProperty)

    void SET_Rotation(const FRotator3dCameraParameter& Value) { Write<FRotator3dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_OffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xc8
class USplineFieldOfViewCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter SplineInput() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FCameraSingleCurve FieldOfViewSpline() const { return Read<FCameraSingleCurve>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x80, Type: StructProperty)

    void SET_SplineInput(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_FieldOfViewSpline(const FCameraSingleCurve& Value) { Write<FCameraSingleCurve>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x80, Type: StructProperty)
};

// Size: 0x350
class USplineOffsetCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter SplineInput() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FCameraVectorCurve TranslationOffsetSpline() const { return Read<FCameraVectorCurve>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x180, Type: StructProperty)
    FCameraRotatorCurve RotationOffsetSpline() const { return Read<FCameraRotatorCurve>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x180, Type: StructProperty)
    uint8_t OffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: EnumProperty)

    void SET_SplineInput(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_TranslationOffsetSpline(const FCameraVectorCurve& Value) { Write<FCameraVectorCurve>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x180, Type: StructProperty)
    void SET_RotationOffsetSpline(const FCameraRotatorCurve& Value) { Write<FCameraRotatorCurve>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x180, Type: StructProperty)
    void SET_OffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x4d8
class USplineOrbitCameraNode : public UCameraNode
{
public:
    FCameraVectorCurve LocationOffsetSpline() const { return Read<FCameraVectorCurve>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x180, Type: StructProperty)
    FCameraVectorCurve TargetOffsetSpline() const { return Read<FCameraVectorCurve>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x180, Type: StructProperty)
    FCameraRotatorCurve RotationOffsetSpline() const { return Read<FCameraRotatorCurve>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x180, Type: StructProperty)
    FFloatCameraParameter LocationOffsetMultiplier() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x10, Type: StructProperty)
    uint8_t TargetOffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x1, Type: EnumProperty)
    UInput2DCameraNode* InputSlot() const { return Read<UInput2DCameraNode*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)

    void SET_LocationOffsetSpline(const FCameraVectorCurve& Value) { Write<FCameraVectorCurve>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x180, Type: StructProperty)
    void SET_TargetOffsetSpline(const FCameraVectorCurve& Value) { Write<FCameraVectorCurve>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x180, Type: StructProperty)
    void SET_RotationOffsetSpline(const FCameraRotatorCurve& Value) { Write<FCameraRotatorCurve>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x180, Type: StructProperty)
    void SET_LocationOffsetMultiplier(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x10, Type: StructProperty)
    void SET_TargetOffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x1, Type: EnumProperty)
    void SET_InputSlot(const UInput2DCameraNode*& Value) { Write<UInput2DCameraNode*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UTargetRayCastCameraNode : public UCameraNode
{
public:
    TEnumAsByte<ECollisionChannel> TraceChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    FBooleanCameraParameter AutoFocus() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_TraceChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_AutoFocus(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x168
class UBaseFramingCameraNode : public UCameraNode
{
public:
    FVector3dCameraVariableReference TargetLocation() const { return Read<FVector3dCameraVariableReference>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    TArray<FCameraActorTargetInfo> TargetInfos() const { return Read<TArray<FCameraActorTargetInfo>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    FCameraContextDataID TargetInfosDataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: StructProperty)
    FBooleanCameraParameter SetTargetDistance() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter InitializeWithIdealFraming() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)
    FVector2dCameraParameter IdealFramingLocation() const { return Read<FVector2dCameraParameter>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x20, Type: StructProperty)
    FFloatCameraParameter ReframeDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter LowReframeDampingFactor() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter ReengageTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter DisengageTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter TargetMovementAnticipationTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: StructProperty)
    FCameraFramingZoneParameter DeadZone() const { return Read<FCameraFramingZoneParameter>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x28, Type: StructProperty)
    FCameraFramingZoneParameter SoftZone() const { return Read<FCameraFramingZoneParameter>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x28, Type: StructProperty)
    FCameraActorTargetInfo TargetInfo() const { return Read<FCameraActorTargetInfo>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x20, Type: StructProperty)

    void SET_TargetLocation(const FVector3dCameraVariableReference& Value) { Write<FVector3dCameraVariableReference>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_TargetInfos(const TArray<FCameraActorTargetInfo>& Value) { Write<TArray<FCameraActorTargetInfo>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_TargetInfosDataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: StructProperty)
    void SET_SetTargetDistance(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_InitializeWithIdealFraming(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
    void SET_IdealFramingLocation(const FVector2dCameraParameter& Value) { Write<FVector2dCameraParameter>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x20, Type: StructProperty)
    void SET_ReframeDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StructProperty)
    void SET_LowReframeDampingFactor(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_ReengageTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StructProperty)
    void SET_DisengageTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StructProperty)
    void SET_TargetMovementAnticipationTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: StructProperty)
    void SET_DeadZone(const FCameraFramingZoneParameter& Value) { Write<FCameraFramingZoneParameter>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x28, Type: StructProperty)
    void SET_SoftZone(const FCameraFramingZoneParameter& Value) { Write<FCameraFramingZoneParameter>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x28, Type: StructProperty)
    void SET_TargetInfo(const FCameraActorTargetInfo& Value) { Write<FCameraActorTargetInfo>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x20, Type: StructProperty)
};

// Size: 0x188
class UDollyFramingCameraNode : public UBaseFramingCameraNode
{
public:
    FBooleanCameraParameter CanMoveLaterally() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter CanMoveVertically() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x10, Type: StructProperty)

    void SET_CanMoveLaterally(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: StructProperty)
    void SET_CanMoveVertically(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x10, Type: StructProperty)
};

// Size: 0x188
class UPanningFramingCameraNode : public UBaseFramingCameraNode
{
public:
    FBooleanCameraParameter CanPanLaterally() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter CanPanVertically() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x10, Type: StructProperty)

    void SET_CanPanLaterally(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: StructProperty)
    void SET_CanPanVertically(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x10, Type: StructProperty)
};

// Size: 0xc0
class UAutoRotateInput2DCameraNode : public UInput2DCameraNode
{
public:
    FVector3dCameraVariableReference DirectionVector() const { return Read<FVector3dCameraVariableReference>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter WaitTime() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter DeactivationThreshold() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)
    UCameraValueInterpolator* Interpolator() const { return Read<UCameraValueInterpolator*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    FBooleanCameraParameter FreezeControlRotation() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter EnableAutoRotate() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AutoRotateYaw() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AutoRotatePitch() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StructProperty)
    UInput2DCameraNode* InputNode() const { return Read<UInput2DCameraNode*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_DirectionVector(const FVector3dCameraVariableReference& Value) { Write<FVector3dCameraVariableReference>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_WaitTime(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_DeactivationThreshold(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
    void SET_Interpolator(const UCameraValueInterpolator*& Value) { Write<UCameraValueInterpolator*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_FreezeControlRotation(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
    void SET_EnableAutoRotate(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_AutoRotateYaw(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_AutoRotatePitch(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StructProperty)
    void SET_InputNode(const UInput2DCameraNode*& Value) { Write<UInput2DCameraNode*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
class UCameraShakeCameraNode : public UCameraNode
{
public:
    FCameraShakeAssetReference CameraShakeReference() const { return Read<FCameraShakeAssetReference>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x30, Type: StructProperty)
    uint8_t EvaluationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)

    void SET_CameraShakeReference(const FCameraShakeAssetReference& Value) { Write<FCameraShakeAssetReference>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x30, Type: StructProperty)
    void SET_EvaluationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x110
class UBlueprintCameraNodeEvaluator : public UObject
{
public:
    bool bIsFirstFrame() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    UObject* EvaluationContextOwner() const { return Read<UObject*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FBlueprintCameraEvaluationDataRef CameraData() const { return Read<FBlueprintCameraEvaluationDataRef>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FBlueprintCameraPose CameraPose() const { return Read<FBlueprintCameraPose>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x88, Type: StructProperty)
    FBlueprintCameraEvaluationDataRef VariableTable() const { return Read<FBlueprintCameraEvaluationDataRef>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)

    void SET_bIsFirstFrame(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_EvaluationContextOwner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraData(const FBlueprintCameraEvaluationDataRef& Value) { Write<FBlueprintCameraEvaluationDataRef>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_CameraPose(const FBlueprintCameraPose& Value) { Write<FBlueprintCameraPose>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x88, Type: StructProperty)
    void SET_VariableTable(const FBlueprintCameraEvaluationDataRef& Value) { Write<FBlueprintCameraEvaluationDataRef>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
class UBlueprintCameraNode : public UCameraNode
{
public:
    UBlueprintCameraNodeEvaluator* CameraNodeEvaluatorTemplate() const { return Read<UBlueprintCameraNodeEvaluator*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FCustomCameraNodeParameters CameraNodeEvaluatorOverrides() const { return Read<FCustomCameraNodeParameters>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    UClass* CameraNodeEvaluatorClass() const { return Read<UClass*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ClassProperty)

    void SET_CameraNodeEvaluatorTemplate(const UBlueprintCameraNodeEvaluator*& Value) { Write<UBlueprintCameraNodeEvaluator*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraNodeEvaluatorOverrides(const FCustomCameraNodeParameters& Value) { Write<FCustomCameraNodeParameters>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_CameraNodeEvaluatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x38
class UCameraShakeServiceCameraNode : public UCameraNode
{
public:
};

// Size: 0x40
class UIsCameraRigTransitionCondition : public UCameraRigTransitionCondition
{
public:
    UCameraRigAsset* PreviousCameraRig() const { return Read<UCameraRigAsset*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UCameraRigAsset* NextCameraRig() const { return Read<UCameraRigAsset*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_PreviousCameraRig(const UCameraRigAsset*& Value) { Write<UCameraRigAsset*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_NextCameraRig(const UCameraRigAsset*& Value) { Write<UCameraRigAsset*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc0
class UGameplayTagTransitionCondition : public UCameraRigTransitionCondition
{
public:
    FGameplayTagQuery PreviousGameplayTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery NextGameplayTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x48, Type: StructProperty)

    void SET_PreviousGameplayTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
    void SET_NextGameplayTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x48, Type: StructProperty)
};

// Size: 0x38
class UAccelerationDecelerationValueInterpolator : public UCameraValueInterpolator
{
public:
    float Acceleration() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MaxSpeed() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float Deceleration() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_Acceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_Deceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
class UCriticalDamperValueInterpolator : public UCameraValueInterpolator
{
public:
    float DampingFactor() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_DampingFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class UDoubleIIRValueInterpolator : public UCameraValueInterpolator
{
public:
    float PrimarySpeed() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float IntermediateSpeed() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bUseFixedStep() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_PrimarySpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_IntermediateSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bUseFixedStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UIIRValueInterpolator : public UCameraValueInterpolator
{
public:
    float Speed() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bUseFixedStep() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_Speed(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_bUseFixedStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FBlueprintCameraEvaluationDataRef
{
public:
};

// Size: 0x18
struct FCameraActorAttachmentInfo
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FName BoneName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_BoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FCameraActorTargetInfo
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FName BoneName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    uint8_t TargetShape() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    float TargetSize() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_BoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_TargetShape(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_TargetSize(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FCameraContextDataDefinition
{
public:
    FCameraContextDataID DataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UObject* DataTypeObject() const { return Read<UObject*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    bool bAutoReset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_DataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_DataTypeObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_bAutoReset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FCameraContextDataID
{
public:
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x10
struct FCameraContextDataTableAllocationInfo
{
public:
    TArray<FCameraContextDataDefinition> DataDefinitions() const { return Read<TArray<FCameraContextDataDefinition>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_DataDefinitions(const TArray<FCameraContextDataDefinition>& Value) { Write<TArray<FCameraContextDataDefinition>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FCameraFramingZone
{
public:
    double Left() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Top() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Right() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double Bottom() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_Left(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Top(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Right(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_Bottom(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x28
struct FCameraFramingZoneParameter
{
public:
    FCameraFramingZone Value() const { return Read<FCameraFramingZone>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_Value(const FCameraFramingZone& Value) { Write<FCameraFramingZone>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FCameraVariableID
{
public:
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x4
struct FCameraNodeEvaluatorAllocationInfo
{
public:
    int16_t TotalSizeof() const { return Read<int16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t MaxAlignof() const { return Read<int16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: Int16Property)

    void SET_TotalSizeof(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: Int16Property)
    void SET_MaxAlignof(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: Int16Property)
};

// Size: 0x40
struct FCameraObjectInterfaceParameterDefinition
{
public:
    FName ParameterName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FGuid ParameterGuid() const { return Read<FGuid>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    uint8_t ParameterType() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)
    UScriptStruct* BlendableStructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    FCameraContextDataID DataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    UObject* DataTypeObject() const { return Read<UObject*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParameterGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_ParameterType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
    void SET_BlendableStructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_DataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_DataTypeObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FBooleanCameraParameter
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    UBooleanCameraVariable* Variable() const { return Read<UBooleanCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UBooleanCameraVariable*& Value) { Write<UBooleanCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FInteger32CameraParameter
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    UInteger32CameraVariable* Variable() const { return Read<UInteger32CameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UInteger32CameraVariable*& Value) { Write<UInteger32CameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FFloatCameraParameter
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    UFloatCameraVariable* Variable() const { return Read<UFloatCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UFloatCameraVariable*& Value) { Write<UFloatCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FDoubleCameraParameter
{
public:
    double Value() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    UDoubleCameraVariable* Variable() const { return Read<UDoubleCameraVariable*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UDoubleCameraVariable*& Value) { Write<UDoubleCameraVariable*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FVector2fCameraParameter
{
public:
    FVector2f Value() const { return Read<FVector2f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    UVector2fCameraVariable* Variable() const { return Read<UVector2fCameraVariable*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector2fCameraVariable*& Value) { Write<UVector2fCameraVariable*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FVector2dCameraParameter
{
public:
    FVector2D Value() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    UVector2dCameraVariable* Variable() const { return Read<UVector2dCameraVariable*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector2dCameraVariable*& Value) { Write<UVector2dCameraVariable*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FVector3fCameraParameter
{
public:
    FVector3f Value() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    UVector3fCameraVariable* Variable() const { return Read<UVector3fCameraVariable*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector3fCameraVariable*& Value) { Write<UVector3fCameraVariable*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FVector3dCameraParameter
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)
    UVector3dCameraVariable* Variable() const { return Read<UVector3dCameraVariable*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector3dCameraVariable*& Value) { Write<UVector3dCameraVariable*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FVector4fCameraParameter
{
public:
    FVector4f Value() const { return Read<FVector4f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    UVector4fCameraVariable* Variable() const { return Read<UVector4fCameraVariable*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FVector4f& Value) { Write<FVector4f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector4fCameraVariable*& Value) { Write<UVector4fCameraVariable*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FVector4dCameraParameter
{
public:
    FVector4 Value() const { return Read<FVector4>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    UVector4dCameraVariable* Variable() const { return Read<UVector4dCameraVariable*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FVector4& Value) { Write<FVector4>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector4dCameraVariable*& Value) { Write<UVector4dCameraVariable*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FRotator3fCameraParameter
{
public:
    FRotator3f Value() const { return Read<FRotator3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    URotator3fCameraVariable* Variable() const { return Read<URotator3fCameraVariable*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FRotator3f& Value) { Write<FRotator3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_Variable(const URotator3fCameraVariable*& Value) { Write<URotator3fCameraVariable*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FRotator3dCameraParameter
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)
    URotator3dCameraVariable* Variable() const { return Read<URotator3dCameraVariable*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const URotator3dCameraVariable*& Value) { Write<URotator3dCameraVariable*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
struct FTransform3fCameraParameter
{
public:
    FTransform3f Value() const { return Read<FTransform3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    UTransform3fCameraVariable* Variable() const { return Read<UTransform3fCameraVariable*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FTransform3f& Value) { Write<FTransform3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UTransform3fCameraVariable*& Value) { Write<UTransform3fCameraVariable*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x70
struct FTransform3dCameraParameter
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: StructProperty)
    UTransform3dCameraVariable* Variable() const { return Read<UTransform3dCameraVariable*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UTransform3dCameraVariable*& Value) { Write<UTransform3dCameraVariable*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2
struct FCameraRigInputSlotParameters
{
public:
    bool bIsAccumulated() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIsPreBlended() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_bIsAccumulated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPreBlended(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FCameraParameterClamping
{
public:
    double MinValue() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double MaxValue() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bClampMin() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bClampMax() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)

    void SET_MinValue(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxValue(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_bClampMin(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bClampMax(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FCameraParameterNormalization
{
public:
    double MaxValue() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    bool bNormalize() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_MaxValue(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_bNormalize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FCameraRigInstanceID
{
public:
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint8_t Layer() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)

    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Layer(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x180
struct FCameraRotatorCurve
{
public:
    FRichCurve Curves() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x180, Type: StructProperty)

    void SET_Curves(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x180, Type: StructProperty)
};

// Size: 0x80
struct FCameraSingleCurve
{
public:
    FRichCurve Curve() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)

    void SET_Curve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
};

// Size: 0x10
struct FBooleanCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UBooleanCameraVariable* Variable() const { return Read<UBooleanCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UBooleanCameraVariable*& Value) { Write<UBooleanCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FInteger32CameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UInteger32CameraVariable* Variable() const { return Read<UInteger32CameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UInteger32CameraVariable*& Value) { Write<UInteger32CameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FFloatCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UFloatCameraVariable* Variable() const { return Read<UFloatCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UFloatCameraVariable*& Value) { Write<UFloatCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FDoubleCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UDoubleCameraVariable* Variable() const { return Read<UDoubleCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UDoubleCameraVariable*& Value) { Write<UDoubleCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FVector2fCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UVector2fCameraVariable* Variable() const { return Read<UVector2fCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector2fCameraVariable*& Value) { Write<UVector2fCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FVector2dCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UVector2dCameraVariable* Variable() const { return Read<UVector2dCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector2dCameraVariable*& Value) { Write<UVector2dCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FVector3fCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UVector3fCameraVariable* Variable() const { return Read<UVector3fCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector3fCameraVariable*& Value) { Write<UVector3fCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FVector3dCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UVector3dCameraVariable* Variable() const { return Read<UVector3dCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector3dCameraVariable*& Value) { Write<UVector3dCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FVector4fCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UVector4fCameraVariable* Variable() const { return Read<UVector4fCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector4fCameraVariable*& Value) { Write<UVector4fCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FVector4dCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UVector4dCameraVariable* Variable() const { return Read<UVector4dCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UVector4dCameraVariable*& Value) { Write<UVector4dCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FRotator3fCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    URotator3fCameraVariable* Variable() const { return Read<URotator3fCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const URotator3fCameraVariable*& Value) { Write<URotator3fCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FRotator3dCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    URotator3dCameraVariable* Variable() const { return Read<URotator3dCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const URotator3dCameraVariable*& Value) { Write<URotator3dCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FTransform3fCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UTransform3fCameraVariable* Variable() const { return Read<UTransform3fCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UTransform3fCameraVariable*& Value) { Write<UTransform3fCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FTransform3dCameraVariableReference
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UTransform3dCameraVariable* Variable() const { return Read<UTransform3dCameraVariable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Variable(const UTransform3dCameraVariable*& Value) { Write<UTransform3dCameraVariable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FCameraVariableSetterHandle
{
public:
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t SerialNumber() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)

    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_SerialNumber(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x18
struct FCameraVariableDefinition
{
public:
    FCameraVariableID VariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UScriptStruct* BlendableStructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bIsPrivate() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bIsInput() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bAutoReset() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)

    void SET_VariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_BlendableStructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsPrivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoReset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FCameraVariableTableAllocationInfo
{
public:
    TArray<FCameraVariableDefinition> VariableDefinitions() const { return Read<TArray<FCameraVariableDefinition>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_VariableDefinitions(const TArray<FCameraVariableDefinition>& Value) { Write<TArray<FCameraVariableDefinition>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x180
struct FCameraVectorCurve
{
public:
    FRichCurve Curves() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x180, Type: StructProperty)

    void SET_Curves(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x180, Type: StructProperty)
};

// Size: 0x20
struct FCustomCameraNodeBlendableParameter
{
public:
    FName ParameterName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UScriptStruct* BlendableStructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FCameraVariableID OverrideVariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    UCameraVariableAsset* OverrideVariable() const { return Read<UCameraVariableAsset*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_ParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BlendableStructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideVariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_OverrideVariable(const UCameraVariableAsset*& Value) { Write<UCameraVariableAsset*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FCustomCameraNodeDataParameter
{
public:
    FName ParameterName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UObject* ParameterTypeObject() const { return Read<UObject*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FCameraContextDataID OverrideDataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)

    void SET_ParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParameterTypeObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideDataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
};

// Size: 0x20
struct FCustomCameraNodeParameters
{
public:
    TArray<FCustomCameraNodeBlendableParameter> BlendableParameters() const { return Read<TArray<FCustomCameraNodeBlendableParameter>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomCameraNodeDataParameter> DataParameters() const { return Read<TArray<FCustomCameraNodeDataParameter>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_BlendableParameters(const TArray<FCustomCameraNodeBlendableParameter>& Value) { Write<TArray<FCustomCameraNodeBlendableParameter>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_DataParameters(const TArray<FCustomCameraNodeDataParameter>& Value) { Write<TArray<FCustomCameraNodeDataParameter>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FCameraObjectAllocationInfo
{
public:
    FCameraNodeEvaluatorAllocationInfo EvaluatorInfo() const { return Read<FCameraNodeEvaluatorAllocationInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FCameraVariableTableAllocationInfo VariableTableInfo() const { return Read<FCameraVariableTableAllocationInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FCameraContextDataTableAllocationInfo ContextDataTableInfo() const { return Read<FCameraContextDataTableAllocationInfo>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_EvaluatorInfo(const FCameraNodeEvaluatorAllocationInfo& Value) { Write<FCameraNodeEvaluatorAllocationInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_VariableTableInfo(const FCameraVariableTableAllocationInfo& Value) { Write<FCameraVariableTableAllocationInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_ContextDataTableInfo(const FCameraContextDataTableAllocationInfo& Value) { Write<FCameraContextDataTableAllocationInfo>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1c
struct FCameraObjectInterfaceParameterMetaData
{
public:
    FGuid ParameterGuid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraVariableID OverrideVariableID() const { return Read<FCameraVariableID>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    FCameraContextDataID OverrideDataID() const { return Read<FCameraContextDataID>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: StructProperty)
    bool bIsOverridden() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bIsAnimated() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)

    void SET_ParameterGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_OverrideVariableID(const FCameraVariableID& Value) { Write<FCameraVariableID>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_OverrideDataID(const FCameraContextDataID& Value) { Write<FCameraContextDataID>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: StructProperty)
    void SET_bIsOverridden(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bIsAnimated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FBaseCameraObjectReference
{
public:
    FInstancedPropertyBag Parameters() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FCameraObjectInterfaceParameterMetaData> ParameterMetaData() const { return Read<TArray<FCameraObjectInterfaceParameterMetaData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_ParameterMetaData(const TArray<FCameraObjectInterfaceParameterMetaData>& Value) { Write<TArray<FCameraObjectInterfaceParameterMetaData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FCameraAssetAllocationInfo
{
public:
    FCameraVariableTableAllocationInfo VariableTableInfo() const { return Read<FCameraVariableTableAllocationInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraContextDataTableAllocationInfo ContextDataTableInfo() const { return Read<FCameraContextDataTableAllocationInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_VariableTableInfo(const FCameraVariableTableAllocationInfo& Value) { Write<FCameraVariableTableAllocationInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_ContextDataTableInfo(const FCameraContextDataTableAllocationInfo& Value) { Write<FCameraContextDataTableAllocationInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FCameraAssetReference
{
public:
    UCameraAsset* CameraAsset() const { return Read<UCameraAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FInstancedPropertyBag Parameters() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> ParameterOverrideGuids() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FGuid> ParameterAnimatedGuids() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_CameraAsset(const UCameraAsset*& Value) { Write<UCameraAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Parameters(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_ParameterOverrideGuids(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_ParameterAnimatedGuids(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FCameraObjectInterface
{
public:
    TArray<UCameraObjectInterfaceBlendableParameter*> BlendableParameters() const { return Read<TArray<UCameraObjectInterfaceBlendableParameter*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraObjectInterfaceDataParameter*> DataParameters() const { return Read<TArray<UCameraObjectInterfaceDataParameter*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString DisplayName() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_BlendableParameters(const TArray<UCameraObjectInterfaceBlendableParameter*>& Value) { Write<TArray<UCameraObjectInterfaceBlendableParameter*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_DataParameters(const TArray<UCameraObjectInterfaceDataParameter*>& Value) { Write<TArray<UCameraObjectInterfaceDataParameter*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_DisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x88
struct FCameraPose
{
public:
    FVector3d Location() const { return Read<FVector3d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator3d Rotation() const { return Read<FRotator3d>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    double TargetDistance() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    float FieldOfView() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float FocalLength() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float OrthographicWidth() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float Aperture() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float ShutterSpeed() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float FocusDistance() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float SensorWidth() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float SensorHeight() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float SensorHorizontalOffset() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float SensorVerticalOffset() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float ISO() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float SqueezeFactor() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float Overscan() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    int32_t DiaphragmBladeCount() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    float NearClippingPlane() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float FarClippingPlane() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float PhysicalCameraBlendWeight() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    bool EnablePhysicalCamera() const { return Read<bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: BoolProperty)
    bool ConstrainAspectRatio() const { return Read<bool>(uintptr_t(this) + 0x7d); } // 0x7d (Size: 0x1, Type: BoolProperty)
    bool OverrideAspectRatioAxisConstraint() const { return Read<bool>(uintptr_t(this) + 0x7e); } // 0x7e (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAspectRatioAxisConstraint> AspectRatioAxisConstraint() const { return Read<TEnumAsByte<EAspectRatioAxisConstraint>>(uintptr_t(this) + 0x7f); } // 0x7f (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ECameraProjectionMode> ProjectionMode() const { return Read<TEnumAsByte<ECameraProjectionMode>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: ByteProperty)

    void SET_Location(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator3d& Value) { Write<FRotator3d>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_TargetDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_FieldOfView(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_FocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_OrthographicWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Aperture(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_ShutterSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_FocusDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_SensorWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_SensorHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_SensorHorizontalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_SensorVerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_ISO(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_SqueezeFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_Overscan(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_DiaphragmBladeCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_NearClippingPlane(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_FarClippingPlane(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_PhysicalCameraBlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_EnablePhysicalCamera(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: BoolProperty)
    void SET_ConstrainAspectRatio(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7d, Value); } // 0x7d (Size: 0x1, Type: BoolProperty)
    void SET_OverrideAspectRatioAxisConstraint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7e, Value); } // 0x7e (Size: 0x1, Type: BoolProperty)
    void SET_AspectRatioAxisConstraint(const TEnumAsByte<EAspectRatioAxisConstraint>& Value) { Write<TEnumAsByte<EAspectRatioAxisConstraint>>(uintptr_t(this) + 0x7f, Value); } // 0x7f (Size: 0x1, Type: ByteProperty)
    void SET_ProjectionMode(const TEnumAsByte<ECameraProjectionMode>& Value) { Write<TEnumAsByte<ECameraProjectionMode>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x38
struct FCameraRigParameterOverrideBase
{
public:
    FGuid InterfaceParameterGuid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid PrivateVariableGuid() const { return Read<FGuid>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FString InterfaceParameterName() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    bool bInvalid() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_InterfaceParameterGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_PrivateVariableGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_InterfaceParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_bInvalid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
struct FBooleanCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FBooleanCameraParameter Value() const { return Read<FBooleanCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FBooleanCameraParameter& Value) { Write<FBooleanCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
struct FInteger32CameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FInteger32CameraParameter Value() const { return Read<FInteger32CameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FInteger32CameraParameter& Value) { Write<FInteger32CameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
struct FFloatCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FFloatCameraParameter Value() const { return Read<FFloatCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FFloatCameraParameter& Value) { Write<FFloatCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FDoubleCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FDoubleCameraParameter Value() const { return Read<FDoubleCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FDoubleCameraParameter& Value) { Write<FDoubleCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FVector2fCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FVector2fCameraParameter Value() const { return Read<FVector2fCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector2fCameraParameter& Value) { Write<FVector2fCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FVector2dCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FVector2dCameraParameter Value() const { return Read<FVector2dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FVector2dCameraParameter& Value) { Write<FVector2dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
struct FVector3fCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FVector3fCameraParameter Value() const { return Read<FVector3fCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector3fCameraParameter& Value) { Write<FVector3fCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x60
struct FVector3dCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FVector3dCameraParameter Value() const { return Read<FVector3dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)

    void SET_Value(const FVector3dCameraParameter& Value) { Write<FVector3dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
};

// Size: 0x60
struct FVector4fCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FVector4fCameraParameter Value() const { return Read<FVector4fCameraParameter>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FVector4fCameraParameter& Value) { Write<FVector4fCameraParameter>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
};

// Size: 0x70
struct FVector4dCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FVector4dCameraParameter Value() const { return Read<FVector4dCameraParameter>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x30, Type: StructProperty)

    void SET_Value(const FVector4dCameraParameter& Value) { Write<FVector4dCameraParameter>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x30, Type: StructProperty)
};

// Size: 0x50
struct FRotator3fCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FRotator3fCameraParameter Value() const { return Read<FRotator3fCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator3fCameraParameter& Value) { Write<FRotator3fCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x60
struct FRotator3dCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FRotator3dCameraParameter Value() const { return Read<FRotator3dCameraParameter>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)

    void SET_Value(const FRotator3dCameraParameter& Value) { Write<FRotator3dCameraParameter>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
};

// Size: 0x80
struct FTransform3fCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FTransform3fCameraParameter Value() const { return Read<FTransform3fCameraParameter>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x40, Type: StructProperty)

    void SET_Value(const FTransform3fCameraParameter& Value) { Write<FTransform3fCameraParameter>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x40, Type: StructProperty)
};

// Size: 0xb0
struct FTransform3dCameraRigParameterOverride : public FCameraRigParameterOverrideBase
{
public:
    FTransform3dCameraParameter Value() const { return Read<FTransform3dCameraParameter>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x70, Type: StructProperty)

    void SET_Value(const FTransform3dCameraParameter& Value) { Write<FTransform3dCameraParameter>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x70, Type: StructProperty)
};

// Size: 0xe0
struct FCameraRigParameterOverrides
{
public:
    TArray<FBooleanCameraRigParameterOverride> BooleanOverrides() const { return Read<TArray<FBooleanCameraRigParameterOverride>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FInteger32CameraRigParameterOverride> Integer32Overrides() const { return Read<TArray<FInteger32CameraRigParameterOverride>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FFloatCameraRigParameterOverride> FloatOverrides() const { return Read<TArray<FFloatCameraRigParameterOverride>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FDoubleCameraRigParameterOverride> DoubleOverrides() const { return Read<TArray<FDoubleCameraRigParameterOverride>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2fCameraRigParameterOverride> Vector2fOverrides() const { return Read<TArray<FVector2fCameraRigParameterOverride>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2dCameraRigParameterOverride> Vector2dOverrides() const { return Read<TArray<FVector2dCameraRigParameterOverride>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3fCameraRigParameterOverride> Vector3fOverrides() const { return Read<TArray<FVector3fCameraRigParameterOverride>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3dCameraRigParameterOverride> Vector3dOverrides() const { return Read<TArray<FVector3dCameraRigParameterOverride>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector4fCameraRigParameterOverride> Vector4fOverrides() const { return Read<TArray<FVector4fCameraRigParameterOverride>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector4dCameraRigParameterOverride> Vector4dOverrides() const { return Read<TArray<FVector4dCameraRigParameterOverride>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FRotator3fCameraRigParameterOverride> Rotator3fOverrides() const { return Read<TArray<FRotator3fCameraRigParameterOverride>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRotator3dCameraRigParameterOverride> Rotator3dOverrides() const { return Read<TArray<FRotator3dCameraRigParameterOverride>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3fCameraRigParameterOverride> Transform3fOverrides() const { return Read<TArray<FTransform3fCameraRigParameterOverride>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3dCameraRigParameterOverride> Transform3dOverrides() const { return Read<TArray<FTransform3dCameraRigParameterOverride>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)

    void SET_BooleanOverrides(const TArray<FBooleanCameraRigParameterOverride>& Value) { Write<TArray<FBooleanCameraRigParameterOverride>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Integer32Overrides(const TArray<FInteger32CameraRigParameterOverride>& Value) { Write<TArray<FInteger32CameraRigParameterOverride>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FloatOverrides(const TArray<FFloatCameraRigParameterOverride>& Value) { Write<TArray<FFloatCameraRigParameterOverride>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_DoubleOverrides(const TArray<FDoubleCameraRigParameterOverride>& Value) { Write<TArray<FDoubleCameraRigParameterOverride>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Vector2fOverrides(const TArray<FVector2fCameraRigParameterOverride>& Value) { Write<TArray<FVector2fCameraRigParameterOverride>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_Vector2dOverrides(const TArray<FVector2dCameraRigParameterOverride>& Value) { Write<TArray<FVector2dCameraRigParameterOverride>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_Vector3fOverrides(const TArray<FVector3fCameraRigParameterOverride>& Value) { Write<TArray<FVector3fCameraRigParameterOverride>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_Vector3dOverrides(const TArray<FVector3dCameraRigParameterOverride>& Value) { Write<TArray<FVector3dCameraRigParameterOverride>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_Vector4fOverrides(const TArray<FVector4fCameraRigParameterOverride>& Value) { Write<TArray<FVector4fCameraRigParameterOverride>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_Vector4dOverrides(const TArray<FVector4dCameraRigParameterOverride>& Value) { Write<TArray<FVector4dCameraRigParameterOverride>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_Rotator3fOverrides(const TArray<FRotator3fCameraRigParameterOverride>& Value) { Write<TArray<FRotator3fCameraRigParameterOverride>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_Rotator3dOverrides(const TArray<FRotator3dCameraRigParameterOverride>& Value) { Write<TArray<FRotator3dCameraRigParameterOverride>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_Transform3fOverrides(const TArray<FTransform3fCameraRigParameterOverride>& Value) { Write<TArray<FTransform3fCameraRigParameterOverride>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_Transform3dOverrides(const TArray<FTransform3dCameraRigParameterOverride>& Value) { Write<TArray<FTransform3dCameraRigParameterOverride>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x120
struct FCameraRigAssetReference : public FBaseCameraObjectReference
{
public:
    UCameraRigAsset* CameraRig() const { return Read<UCameraRigAsset*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FGuid> ParameterOverrideGuids() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    FCameraRigParameterOverrides ParameterOverrides() const { return Read<FCameraRigParameterOverrides>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xe0, Type: StructProperty)

    void SET_CameraRig(const UCameraRigAsset*& Value) { Write<UCameraRigAsset*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_ParameterOverrideGuids(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ParameterOverrides(const FCameraRigParameterOverrides& Value) { Write<FCameraRigParameterOverrides>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xe0, Type: StructProperty)
};

// Size: 0x10
struct FCameraRigProxyRedirectTableEntry
{
public:
    UCameraRigProxyAsset* CameraRigProxy() const { return Read<UCameraRigProxyAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UCameraRigAsset* CameraRig() const { return Read<UCameraRigAsset*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRigProxy(const UCameraRigProxyAsset*& Value) { Write<UCameraRigProxyAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraRig(const UCameraRigAsset*& Value) { Write<UCameraRigAsset*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FCameraRigProxyRedirectTable
{
public:
    TArray<FCameraRigProxyRedirectTableEntry> Entries() const { return Read<TArray<FCameraRigProxyRedirectTableEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FCameraRigProxyRedirectTableEntry>& Value) { Write<TArray<FCameraRigProxyRedirectTableEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FCameraShakeAssetReference : public FBaseCameraObjectReference
{
public:
    UCameraShakeAsset* CameraShake() const { return Read<UCameraShakeAsset*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraShake(const UCameraShakeAsset*& Value) { Write<UCameraShakeAsset*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FBlueprintCameraDirectorEvaluationParams
{
public:
    float DeltaTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    UObject* EvaluationContextOwner() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_DeltaTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EvaluationContextOwner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FBlueprintCameraDirectorActivateParams
{
public:
    UObject* EvaluationContextOwner() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_EvaluationContextOwner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FBlueprintCameraDirectorDeactivateParams
{
public:
    UObject* EvaluationContextOwner() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_EvaluationContextOwner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FCameraDirectorStateTreeEvaluationData
{
public:
    TArray<UCameraRigAsset*> ActiveCameraRigs() const { return Read<TArray<UCameraRigAsset*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigProxyAsset*> ActiveCameraRigProxies() const { return Read<TArray<UCameraRigProxyAsset*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ActiveCameraRigs(const TArray<UCameraRigAsset*>& Value) { Write<TArray<UCameraRigAsset*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveCameraRigProxies(const TArray<UCameraRigProxyAsset*>& Value) { Write<TArray<UCameraRigProxyAsset*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FGameplayCamerasStateTreeTask : public FStateTreeTaskBase
{
public:
};

// Size: 0x20
struct FGameplayCamerasStateTreeCondition : public FStateTreeConditionBase
{
public:
};

// Size: 0x8
struct FGameplayCamerasActivateCameraRigTaskInstanceData
{
public:
    UCameraRigAsset* CameraRig() const { return Read<UCameraRigAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRig(const UCameraRigAsset*& Value) { Write<UCameraRigAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FGameplayCamerasActivateCameraRigTask : public FGameplayCamerasStateTreeTask
{
public:
    bool bRunOnce() const { return Read<bool>(uintptr_t(this) + 0x26); } // 0x26 (Size: 0x1, Type: BoolProperty)

    void SET_bRunOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x26, Value); } // 0x26 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FGameplayCamerasActivateCameraRigViaProxyTaskInstanceData
{
public:
    UCameraRigProxyAsset* CameraRigProxy() const { return Read<UCameraRigProxyAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraRigProxy(const UCameraRigProxyAsset*& Value) { Write<UCameraRigProxyAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FGameplayCamerasActivateCameraRigViaProxyTask : public FGameplayCamerasStateTreeTask
{
public:
    bool bRunOnce() const { return Read<bool>(uintptr_t(this) + 0x26); } // 0x26 (Size: 0x1, Type: BoolProperty)

    void SET_bRunOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x26, Value); } // 0x26 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
struct FBlueprintCameraPose
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    double TargetDistance() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    float FieldOfView() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float FocalLength() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float OrthographicWidth() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float Aperture() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float ShutterSpeed() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float FocusDistance() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float SensorWidth() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float SensorHeight() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float SensorHorizontalOffset() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float SensorVerticalOffset() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float ISO() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float SqueezeFactor() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float Overscan() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    int32_t DiaphragmBladeCount() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    float NearClippingPlane() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float FarClippingPlane() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float PhysicalCameraBlendWeight() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    bool EnablePhysicalCamera() const { return Read<bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: BoolProperty)
    bool ConstrainAspectRatio() const { return Read<bool>(uintptr_t(this) + 0x7d); } // 0x7d (Size: 0x1, Type: BoolProperty)
    bool OverrideAspectRatioAxisConstraint() const { return Read<bool>(uintptr_t(this) + 0x7e); } // 0x7e (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAspectRatioAxisConstraint> AspectRatioAxisConstraint() const { return Read<TEnumAsByte<EAspectRatioAxisConstraint>>(uintptr_t(this) + 0x7f); } // 0x7f (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ECameraProjectionMode> ProjectionMode() const { return Read<TEnumAsByte<ECameraProjectionMode>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: ByteProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_TargetDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_FieldOfView(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_FocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_OrthographicWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Aperture(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_ShutterSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_FocusDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_SensorWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_SensorHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_SensorHorizontalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_SensorVerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_ISO(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_SqueezeFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_Overscan(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_DiaphragmBladeCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_NearClippingPlane(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_FarClippingPlane(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_PhysicalCameraBlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_EnablePhysicalCamera(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: BoolProperty)
    void SET_ConstrainAspectRatio(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7d, Value); } // 0x7d (Size: 0x1, Type: BoolProperty)
    void SET_OverrideAspectRatioAxisConstraint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7e, Value); } // 0x7e (Size: 0x1, Type: BoolProperty)
    void SET_AspectRatioAxisConstraint(const TEnumAsByte<EAspectRatioAxisConstraint>& Value) { Write<TEnumAsByte<EAspectRatioAxisConstraint>>(uintptr_t(this) + 0x7f, Value); } // 0x7f (Size: 0x1, Type: ByteProperty)
    void SET_ProjectionMode(const TEnumAsByte<ECameraProjectionMode>& Value) { Write<TEnumAsByte<ECameraProjectionMode>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x8
struct FPerlinNoiseData
{
public:
    float Amplitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Amplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FSplineOrbitControlPoint
{
public:
    FVector3d LocationOffset() const { return Read<FVector3d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d TargetOffset() const { return Read<FVector3d>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FRotator3d RotationOffset() const { return Read<FRotator3d>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float PitchAngle() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)

    void SET_LocationOffset(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_TargetOffset(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_RotationOffset(const FRotator3d& Value) { Write<FRotator3d>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_PitchAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
};

