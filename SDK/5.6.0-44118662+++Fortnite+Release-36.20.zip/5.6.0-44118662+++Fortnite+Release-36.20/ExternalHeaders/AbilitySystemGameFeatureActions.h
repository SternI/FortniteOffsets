/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AbilitySystemGameFeatureActions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x48
class UGameFeatureAction_AddAttributeDefaults : public UGameFeatureAction
{
public:
    bool bApplyOnRegister() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TArray<FSoftObjectPath> AttribDefaultTableNames() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_bApplyOnRegister(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_AttribDefaultTableNames(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

