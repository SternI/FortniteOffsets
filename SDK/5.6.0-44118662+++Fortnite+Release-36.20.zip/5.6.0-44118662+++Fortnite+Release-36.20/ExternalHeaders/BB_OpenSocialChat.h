/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BB_OpenSocialChat
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x328
class UBB_OpenSocialChat_C : public UFortMobileActionButtonBehavior
{
public:
};

