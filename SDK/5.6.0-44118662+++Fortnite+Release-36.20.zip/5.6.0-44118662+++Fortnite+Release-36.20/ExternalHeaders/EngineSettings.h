/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineSettings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x70
class UConsoleSettings : public UObject
{
public:
    int32_t MaxScrollbackSize() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    TArray<FAutoCompleteCommand> ManualAutoCompleteList() const { return Read<TArray<FAutoCompleteCommand>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> AutoCompleteMapPaths() const { return Read<TArray<FString>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    float BackgroundOpacityPercentage() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bOrderTopToBottom() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    bool bDisplayHelpInAutoComplete() const { return Read<bool>(uintptr_t(this) + 0x55); } // 0x55 (Size: 0x1, Type: BoolProperty)
    FColor InputColor() const { return Read<FColor>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: StructProperty)
    FColor HistoryColor() const { return Read<FColor>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: StructProperty)
    FColor AutoCompleteCommandColor() const { return Read<FColor>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: StructProperty)
    FColor AutoCompleteCVarColor() const { return Read<FColor>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: StructProperty)
    FColor AutoCompleteFadedColor() const { return Read<FColor>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: StructProperty)

    void SET_MaxScrollbackSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_ManualAutoCompleteList(const TArray<FAutoCompleteCommand>& Value) { Write<TArray<FAutoCompleteCommand>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_AutoCompleteMapPaths(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_BackgroundOpacityPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_bOrderTopToBottom(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_bDisplayHelpInAutoComplete(const bool& Value) { Write<bool>(uintptr_t(this) + 0x55, Value); } // 0x55 (Size: 0x1, Type: BoolProperty)
    void SET_InputColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: StructProperty)
    void SET_HistoryColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: StructProperty)
    void SET_AutoCompleteCommandColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: StructProperty)
    void SET_AutoCompleteCVarColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: StructProperty)
    void SET_AutoCompleteFadedColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: StructProperty)
};

// Size: 0xf0
class UGameMapsSettings : public UObject
{
public:
    FString LocalMapOptions() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FSoftObjectPath TransitionMap() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    bool bUseSplitscreen() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ETwoPlayerSplitScreenType> TwoPlayerSplitscreenLayout() const { return Read<TEnumAsByte<ETwoPlayerSplitScreenType>>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EThreePlayerSplitScreenType> ThreePlayerSplitscreenLayout() const { return Read<TEnumAsByte<EThreePlayerSplitScreenType>>(uintptr_t(this) + 0x52); } // 0x52 (Size: 0x1, Type: ByteProperty)
    uint8_t FourPlayerSplitscreenLayout() const { return Read<uint8_t>(uintptr_t(this) + 0x53); } // 0x53 (Size: 0x1, Type: EnumProperty)
    bool bOffsetPlayerGamepadIds() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    FSoftClassPath GameInstanceClass() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath GameDefaultMap() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath ServerDefaultMap() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FSoftClassPath GlobalDefaultGameMode() const { return Read<FSoftClassPath>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)
    FSoftClassPath GlobalDefaultServerGameMode() const { return Read<FSoftClassPath>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    TArray<FGameModeName> GameModeMapPrefixes() const { return Read<TArray<FGameModeName>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameModeName> GameModeClassAliases() const { return Read<TArray<FGameModeName>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)

    void SET_LocalMapOptions(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_TransitionMap(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_bUseSplitscreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_TwoPlayerSplitscreenLayout(const TEnumAsByte<ETwoPlayerSplitScreenType>& Value) { Write<TEnumAsByte<ETwoPlayerSplitScreenType>>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: ByteProperty)
    void SET_ThreePlayerSplitscreenLayout(const TEnumAsByte<EThreePlayerSplitScreenType>& Value) { Write<TEnumAsByte<EThreePlayerSplitScreenType>>(uintptr_t(this) + 0x52, Value); } // 0x52 (Size: 0x1, Type: ByteProperty)
    void SET_FourPlayerSplitscreenLayout(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x53, Value); } // 0x53 (Size: 0x1, Type: EnumProperty)
    void SET_bOffsetPlayerGamepadIds(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_GameInstanceClass(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_GameDefaultMap(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_ServerDefaultMap(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_GlobalDefaultGameMode(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
    void SET_GlobalDefaultServerGameMode(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_GameModeMapPrefixes(const TArray<FGameModeName>& Value) { Write<TArray<FGameModeName>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_GameModeClassAliases(const TArray<FGameModeName>& Value) { Write<TArray<FGameModeName>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
class UGameNetworkManagerSettings : public UObject
{
public:
    int32_t MinDynamicBandwidth() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MaxDynamicBandwidth() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t TotalNetBandwidth() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t BadPingThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    bool bIsStandbyCheckingEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x0) & 1; } // 0x38:0 (Size: 0x1, Type: BoolProperty)
    float StandbyRxCheatTime() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float StandbyTxCheatTime() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float PercentMissingForRxStandby() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float PercentMissingForTxStandby() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float PercentForBadPing() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float JoinInProgressStandbyWaitTime() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_MinDynamicBandwidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_MaxDynamicBandwidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_TotalNetBandwidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_BadPingThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_bIsStandbyCheckingEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:0 (Size: 0x1, Type: BoolProperty)
    void SET_StandbyRxCheatTime(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_StandbyTxCheatTime(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_PercentMissingForRxStandby(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_PercentMissingForTxStandby(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_PercentForBadPing(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_JoinInProgressStandbyWaitTime(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class UGameSessionSettings : public UObject
{
public:
    int32_t MaxSpectators() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MaxPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    bool bRequiresPushToTalk() const { return (Read<uint8_t>(uintptr_t(this) + 0x30) >> 0x0) & 1; } // 0x30:0 (Size: 0x1, Type: BoolProperty)

    void SET_MaxSpectators(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_MaxPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_bRequiresPushToTalk(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x30); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x30, B); } // 0x30:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UGeneralEngineSettings : public UObject
{
public:
};

// Size: 0x110
class UGeneralProjectSettings : public UObject
{
public:
    FString CompanyName() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString CompanyDistinguishedName() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    FString CopyrightNotice() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StrProperty)
    FString Homepage() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FString LicensingTerms() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    FString PrivacyPolicy() const { return Read<FString>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StrProperty)
    FGuid ProjectID() const { return Read<FGuid>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    FString ProjectName() const { return Read<FString>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StrProperty)
    FString ProjectVersion() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)
    FString SupportContact() const { return Read<FString>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StrProperty)
    FText ProjectDisplayedTitle() const { return Read<FText>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: TextProperty)
    FText ProjectDebugTitleInfo() const { return Read<FText>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: TextProperty)
    bool bShouldWindowPreserveAspectRatio() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    bool bUseBorderlessWindow() const { return Read<bool>(uintptr_t(this) + 0xf9); } // 0xf9 (Size: 0x1, Type: BoolProperty)
    bool bStartInVR() const { return Read<bool>(uintptr_t(this) + 0xfa); } // 0xfa (Size: 0x1, Type: BoolProperty)
    bool bAllowWindowResize() const { return Read<bool>(uintptr_t(this) + 0xfb); } // 0xfb (Size: 0x1, Type: BoolProperty)
    bool bAllowClose() const { return Read<bool>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x1, Type: BoolProperty)
    bool bAllowMaximize() const { return Read<bool>(uintptr_t(this) + 0xfd); } // 0xfd (Size: 0x1, Type: BoolProperty)
    bool bAllowMinimize() const { return Read<bool>(uintptr_t(this) + 0xfe); } // 0xfe (Size: 0x1, Type: BoolProperty)
    float EyeOffsetForFakeStereoRenderingDevice() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    float FOVForFakeStereoRenderingDevice() const { return Read<float>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: FloatProperty)
    float TopFOVRatioForFakeStereoRenderingDevice() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float DifferenceBetweenEyesForFakeStereoRenderingDevice() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)

    void SET_CompanyName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_CompanyDistinguishedName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_CopyrightNotice(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StrProperty)
    void SET_Homepage(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_LicensingTerms(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_PrivacyPolicy(const FString& Value) { Write<FString>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StrProperty)
    void SET_ProjectID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_ProjectName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StrProperty)
    void SET_ProjectVersion(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
    void SET_SupportContact(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StrProperty)
    void SET_ProjectDisplayedTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: TextProperty)
    void SET_ProjectDebugTitleInfo(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: TextProperty)
    void SET_bShouldWindowPreserveAspectRatio(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    void SET_bUseBorderlessWindow(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf9, Value); } // 0xf9 (Size: 0x1, Type: BoolProperty)
    void SET_bStartInVR(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfa, Value); } // 0xfa (Size: 0x1, Type: BoolProperty)
    void SET_bAllowWindowResize(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfb, Value); } // 0xfb (Size: 0x1, Type: BoolProperty)
    void SET_bAllowClose(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x1, Type: BoolProperty)
    void SET_bAllowMaximize(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfd, Value); } // 0xfd (Size: 0x1, Type: BoolProperty)
    void SET_bAllowMinimize(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfe, Value); } // 0xfe (Size: 0x1, Type: BoolProperty)
    void SET_EyeOffsetForFakeStereoRenderingDevice(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_FOVForFakeStereoRenderingDevice(const float& Value) { Write<float>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: FloatProperty)
    void SET_TopFOVRatioForFakeStereoRenderingDevice(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_DifferenceBetweenEyesForFakeStereoRenderingDevice(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
class UHudSettings : public UObject
{
public:
    bool bShowHUD() const { return (Read<uint8_t>(uintptr_t(this) + 0x28) >> 0x0) & 1; } // 0x28:0 (Size: 0x1, Type: BoolProperty)
    TArray<FName> DebugDisplay() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_bShowHUD(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x28, B); } // 0x28:0 (Size: 0x1, Type: BoolProperty)
    void SET_DebugDisplay(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FAutoCompleteCommand
{
public:
    FString Command() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Desc() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Command(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Desc(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
struct FGameModeName
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FSoftClassPath GameMode() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_GameMode(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FTemplateMapInfoOverride
{
public:
    FSoftObjectPath Thumbnail() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath Map() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)

    void SET_Thumbnail(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Map(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
};

