/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteEarlyPreloadWidgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x158
class UFortniteBootUpBackground : public UWidget
{
public:
};

