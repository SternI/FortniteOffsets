/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_ProjectileTrajectorySplineMesh
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x740
class UBP_ProjectileTrajectorySplineMesh_C : public USplineMeshComponent
{
public:
};

