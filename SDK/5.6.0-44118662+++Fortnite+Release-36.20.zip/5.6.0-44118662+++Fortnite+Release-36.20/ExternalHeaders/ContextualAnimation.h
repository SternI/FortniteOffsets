/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContextualAnimation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MotionWarping.h"

// Size: 0x38
class UAnimNotifyState_EarlyOutContextualAnimWindow : public UAnimNotifyState
{
public:
    bool bStopEveryone() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_bStopEveryone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
class UAnimNotifyState_IKWindow : public UAnimNotifyState
{
public:
    FName GoalName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    FAlphaBlend BlendIn() const { return Read<FAlphaBlend>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x30, Type: StructProperty)
    FAlphaBlend BlendOut() const { return Read<FAlphaBlend>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x30, Type: StructProperty)
    bool bEnable() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)

    void SET_GoalName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_BlendIn(const FAlphaBlend& Value) { Write<FAlphaBlend>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x30, Type: StructProperty)
    void SET_BlendOut(const FAlphaBlend& Value) { Write<FAlphaBlend>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x30, Type: StructProperty)
    void SET_bEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UContextualAnimActorInterface : public UInterface
{
public:
};

// Size: 0x410
class UContextualAnimSceneActorComponent : public USceneComponent
{
public:
    UContextualAnimSceneAsset* SceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAnimInstance*> OwnerAnimInstance() const { return Read<TWeakObjectPtr<UAnimInstance*>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: WeakObjectProperty)
    FContextualAnimRepBindingsData RepBindings() const { return Read<FContextualAnimRepBindingsData>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x50, Type: StructProperty)
    FContextualAnimRepLateJoinData RepLateJoinData() const { return Read<FContextualAnimRepLateJoinData>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x30, Type: StructProperty)
    FContextualAnimRepTransitionData RepTransitionData() const { return Read<FContextualAnimRepTransitionData>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x28, Type: StructProperty)
    FContextualAnimRepTransitionData RepTransitionSingleActorData() const { return Read<FContextualAnimRepTransitionData>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x28, Type: StructProperty)
    FContextualAnimSceneBindings Bindings() const { return Read<FContextualAnimSceneBindings>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x28, Type: StructProperty)
    TArray<FContextualAnimIKTarget> IKTargets() const { return Read<TArray<FContextualAnimIKTarget>>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> WarpTargetNamesCache() const { return Read<TArray<FName>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)

    void SET_SceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerAnimInstance(const TWeakObjectPtr<UAnimInstance*>& Value) { Write<TWeakObjectPtr<UAnimInstance*>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RepBindings(const FContextualAnimRepBindingsData& Value) { Write<FContextualAnimRepBindingsData>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x50, Type: StructProperty)
    void SET_RepLateJoinData(const FContextualAnimRepLateJoinData& Value) { Write<FContextualAnimRepLateJoinData>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x30, Type: StructProperty)
    void SET_RepTransitionData(const FContextualAnimRepTransitionData& Value) { Write<FContextualAnimRepTransitionData>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x28, Type: StructProperty)
    void SET_RepTransitionSingleActorData(const FContextualAnimRepTransitionData& Value) { Write<FContextualAnimRepTransitionData>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x28, Type: StructProperty)
    void SET_Bindings(const FContextualAnimSceneBindings& Value) { Write<FContextualAnimSceneBindings>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x28, Type: StructProperty)
    void SET_IKTargets(const TArray<FContextualAnimIKTarget>& Value) { Write<TArray<FContextualAnimIKTarget>>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: ArrayProperty)
    void SET_WarpTargetNamesCache(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UContextualAnimRolesAsset : public UDataAsset
{
public:
    TArray<FContextualAnimRoleDefinition> Roles() const { return Read<TArray<FContextualAnimRoleDefinition>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Roles(const TArray<FContextualAnimRoleDefinition>& Value) { Write<TArray<FContextualAnimRoleDefinition>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UContextualAnimSceneAsset : public UDataAsset
{
public:
    UContextualAnimRolesAsset* RolesAsset() const { return Read<UContextualAnimRolesAsset*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName PrimaryRole() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    TArray<FContextualAnimSceneSection> Sections() const { return Read<TArray<FContextualAnimSceneSection>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t CollisionBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: EnumProperty)
    TArray<FContextualAnimIgnoreChannelsParam> CollisionChannelsToIgnoreParams() const { return Read<TArray<FContextualAnimIgnoreChannelsParam>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimAttachmentParams> AttachmentParams() const { return Read<TArray<FContextualAnimAttachmentParams>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FContextualAnimIKTargetParams IKTargetParams() const { return Read<FContextualAnimIKTargetParams>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    bool bIgnoreClientMovementErrorChecksAndCorrection() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bDisableMovementReplicationForSimulatedProxy() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)
    bool bPrecomputeAlignmentTracks() const { return Read<bool>(uintptr_t(this) + 0x92); } // 0x92 (Size: 0x1, Type: BoolProperty)
    int32_t SampleRate() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)

    void SET_RolesAsset(const UContextualAnimRolesAsset*& Value) { Write<UContextualAnimRolesAsset*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_PrimaryRole(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_Sections(const TArray<FContextualAnimSceneSection>& Value) { Write<TArray<FContextualAnimSceneSection>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: EnumProperty)
    void SET_CollisionChannelsToIgnoreParams(const TArray<FContextualAnimIgnoreChannelsParam>& Value) { Write<TArray<FContextualAnimIgnoreChannelsParam>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_AttachmentParams(const TArray<FContextualAnimAttachmentParams>& Value) { Write<TArray<FContextualAnimAttachmentParams>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_IKTargetParams(const FContextualAnimIKTargetParams& Value) { Write<FContextualAnimIKTargetParams>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_bIgnoreClientMovementErrorChecksAndCorrection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bDisableMovementReplicationForSimulatedProxy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
    void SET_bPrecomputeAlignmentTracks(const bool& Value) { Write<bool>(uintptr_t(this) + 0x92, Value); } // 0x92 (Size: 0x1, Type: BoolProperty)
    void SET_SampleRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
class UContextualAnimSelectionCriterion : public UObject
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x30
class UContextualAnimSelectionCriterion_Blueprint : public UContextualAnimSelectionCriterion
{
public:
};

// Size: 0x48
class UContextualAnimSelectionCriterion_TriggerArea : public UContextualAnimSelectionCriterion
{
public:
    TArray<FVector> PolygonPoints() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_PolygonPoints(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
class UContextualAnimSelectionCriterion_Cone : public UContextualAnimSelectionCriterion
{
public:
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float HalfAngle() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float Offset() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_HalfAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Offset(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
class UContextualAnimSelectionCriterion_Distance : public UContextualAnimSelectionCriterion
{
public:
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    float MinDistance() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float MaxDistance() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_MinDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UContextualAnimUtilities : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x40
struct FContextualAnimWarpTarget
{
public:
    FName Role() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName TargetName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat TargetRotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_TargetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_TargetRotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1
struct FContextualAnimRepData
{
public:
    char RepCounter() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)

    void SET_RepCounter(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FContextualAnimRepBindingsData : public FContextualAnimRepData
{
public:
    FContextualAnimSceneBindings Bindings() const { return Read<FContextualAnimSceneBindings>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    TArray<FContextualAnimWarpPoint> WarpPoints() const { return Read<TArray<FContextualAnimWarpPoint>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpTarget> ExternalWarpTargets() const { return Read<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Bindings(const FContextualAnimSceneBindings& Value) { Write<FContextualAnimSceneBindings>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_WarpPoints(const TArray<FContextualAnimWarpPoint>& Value) { Write<TArray<FContextualAnimWarpPoint>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalWarpTargets(const TArray<FContextualAnimWarpTarget>& Value) { Write<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FContextualAnimWarpPoint
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FContextualAnimSceneBindings
{
public:
    char ID() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    UContextualAnimSceneAsset* SceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    int32_t SectionIdx() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    TArray<FContextualAnimSceneBinding> Data() const { return Read<TArray<FContextualAnimSceneBinding>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ID(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_SceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_SectionIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_AnimSetIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_Data(const TArray<FContextualAnimSceneBinding>& Value) { Write<TArray<FContextualAnimSceneBinding>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf0
struct FContextualAnimSceneBinding
{
public:
    FContextualAnimSceneBindingContext Context() const { return Read<FContextualAnimSceneBindingContext>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xe0, Type: StructProperty)
    int32_t AnimTrackIdx() const { return Read<int32_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: IntProperty)

    void SET_Context(const FContextualAnimSceneBindingContext& Value) { Write<FContextualAnimSceneBindingContext>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xe0, Type: StructProperty)
    void SET_AnimTrackIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: IntProperty)
};

// Size: 0xe0
struct FContextualAnimSceneBindingContext
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UContextualAnimSceneActorComponent*> CachedSceneActorComp() const { return Read<TWeakObjectPtr<UContextualAnimSceneActorComponent*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAnimInstance*> CachedAnimInstance() const { return Read<TWeakObjectPtr<UAnimInstance*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> CachedSkeletalMesh() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UCharacterMovementComponent*> CachedMovementComp() const { return Read<TWeakObjectPtr<UCharacterMovementComponent*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMotionWarpingComponent*> CachedMotionWarpingComp() const { return Read<TWeakObjectPtr<UMotionWarpingComponent*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedSceneActorComp(const TWeakObjectPtr<UContextualAnimSceneActorComponent*>& Value) { Write<TWeakObjectPtr<UContextualAnimSceneActorComponent*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedAnimInstance(const TWeakObjectPtr<UAnimInstance*>& Value) { Write<TWeakObjectPtr<UAnimInstance*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedSkeletalMesh(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedMovementComp(const TWeakObjectPtr<UCharacterMovementComponent*>& Value) { Write<TWeakObjectPtr<UCharacterMovementComponent*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedMotionWarpingComp(const TWeakObjectPtr<UMotionWarpingComponent*>& Value) { Write<TWeakObjectPtr<UMotionWarpingComponent*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x30
struct FContextualAnimRepLateJoinData : public FContextualAnimRepData
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
    FName Role() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    TArray<FContextualAnimWarpPoint> WarpPoints() const { return Read<TArray<FContextualAnimWarpPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpTarget> ExternalWarpTargets() const { return Read<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_WarpPoints(const TArray<FContextualAnimWarpPoint>& Value) { Write<TArray<FContextualAnimWarpPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalWarpTargets(const TArray<FContextualAnimWarpTarget>& Value) { Write<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FContextualAnimRepTransitionData : public FContextualAnimRepData
{
public:
    char ID() const { return Read<char>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: ByteProperty)
    char SectionIdx() const { return Read<char>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: ByteProperty)
    char AnimSetIdx() const { return Read<char>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: ByteProperty)
    bool bStopEveryone() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    TArray<FContextualAnimWarpPoint> WarpPoints() const { return Read<TArray<FContextualAnimWarpPoint>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpTarget> ExternalWarpTargets() const { return Read<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ID(const char& Value) { Write<char>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: ByteProperty)
    void SET_SectionIdx(const char& Value) { Write<char>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: ByteProperty)
    void SET_AnimSetIdx(const char& Value) { Write<char>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: ByteProperty)
    void SET_bStopEveryone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_WarpPoints(const TArray<FContextualAnimWarpPoint>& Value) { Write<TArray<FContextualAnimWarpPoint>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalWarpTargets(const TArray<FContextualAnimWarpTarget>& Value) { Write<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FContextualAnimIgnoreChannelsParam
{
public:
    FName Role() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<TEnumAsByte<ECollisionChannel>> Channels() const { return Read<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Channels(const TArray<TEnumAsByte<ECollisionChannel>>& Value) { Write<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FContextualAnimAttachmentParams
{
public:
    FName Role() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FTransform RelativeTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_RelativeTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x68
struct FContextualAnimSet
{
public:
    TArray<FContextualAnimTrack> Tracks() const { return Read<TArray<FContextualAnimTrack>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FTransform> WarpPoints() const { return Read<TMap<FName, FTransform>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)
    float RandomWeight() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)

    void SET_Tracks(const TArray<FContextualAnimTrack>& Value) { Write<TArray<FContextualAnimTrack>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_WarpPoints(const TMap<FName, FTransform>& Value) { Write<TMap<FName, FTransform>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
    void SET_RandomWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf0
struct FContextualAnimTrack
{
public:
    UAnimSequenceBase* Animation() const { return Read<UAnimSequenceBase*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float AnimMaxStartTime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bChangeMovementMode() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> MovementMode() const { return Read<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: ByteProperty)
    char CustomMovementMode() const { return Read<char>(uintptr_t(this) + 0xe); } // 0xe (Size: 0x1, Type: ByteProperty)
    bool bControlCharacterRotation() const { return Read<bool>(uintptr_t(this) + 0xf); } // 0xf (Size: 0x1, Type: BoolProperty)
    bool bOptional() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FContextualAnimAlignmentTrackContainer AlignmentData() const { return Read<FContextualAnimAlignmentTrackContainer>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x28, Type: StructProperty)
    FContextualAnimAlignmentTrackContainer IKTargetData() const { return Read<FContextualAnimAlignmentTrackContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x28, Type: StructProperty)
    TArray<UContextualAnimSelectionCriterion*> SelectionCriteria() const { return Read<TArray<UContextualAnimSelectionCriterion*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FTransform MeshToScene() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    FName Role() const { return Read<FName>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: NameProperty)
    int32_t SectionIdx() const { return Read<int32_t>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx() const { return Read<int32_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: IntProperty)
    int32_t AnimTrackIdx() const { return Read<int32_t>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: IntProperty)

    void SET_Animation(const UAnimSequenceBase*& Value) { Write<UAnimSequenceBase*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimMaxStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bChangeMovementMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_MovementMode(const TEnumAsByte<EMovementMode>& Value) { Write<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: ByteProperty)
    void SET_CustomMovementMode(const char& Value) { Write<char>(uintptr_t(this) + 0xe, Value); } // 0xe (Size: 0x1, Type: ByteProperty)
    void SET_bControlCharacterRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf, Value); } // 0xf (Size: 0x1, Type: BoolProperty)
    void SET_bOptional(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_AlignmentData(const FContextualAnimAlignmentTrackContainer& Value) { Write<FContextualAnimAlignmentTrackContainer>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x28, Type: StructProperty)
    void SET_IKTargetData(const FContextualAnimAlignmentTrackContainer& Value) { Write<FContextualAnimAlignmentTrackContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x28, Type: StructProperty)
    void SET_SelectionCriteria(const TArray<UContextualAnimSelectionCriterion*>& Value) { Write<TArray<UContextualAnimSelectionCriterion*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshToScene(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: NameProperty)
    void SET_SectionIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: IntProperty)
    void SET_AnimSetIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: IntProperty)
    void SET_AnimTrackIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FContextualAnimAlignmentTrackContainer
{
public:
    FAnimSequenceTrackContainer Tracks() const { return Read<FAnimSequenceTrackContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    float SampleInterval() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Tracks(const FAnimSequenceTrackContainer& Value) { Write<FAnimSequenceTrackContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_SampleInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FContextualAnimSceneSection
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FContextualAnimSet> AnimSets() const { return Read<TArray<FContextualAnimSet>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpPointDefinition> WarpPointDefinitions() const { return Read<TArray<FContextualAnimWarpPointDefinition>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bSyncAnimations() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AnimSets(const TArray<FContextualAnimSet>& Value) { Write<TArray<FContextualAnimSet>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_WarpPointDefinitions(const TArray<FContextualAnimWarpPointDefinition>& Value) { Write<TArray<FContextualAnimWarpPointDefinition>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_bSyncAnimations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c
struct FContextualAnimWarpPointDefinition
{
public:
    FName WarpTargetName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FContextualAnimWarpPointCustomParams Params() const { return Read<FContextualAnimWarpPointCustomParams>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)

    void SET_WarpTargetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Params(const FContextualAnimWarpPointCustomParams& Value) { Write<FContextualAnimWarpPointCustomParams>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FContextualAnimWarpPointCustomParams
{
public:
    FName origin() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bAlongClosestDistance() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FName OtherRole() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_origin(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bAlongClosestDistance(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_OtherRole(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
struct FContextualAnimPoint
{
public:
    FName Role() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    float Speed() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    int32_t SectionIdx() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t AnimTrackIdx() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)

    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Speed(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_SectionIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_AnimSetIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_AnimTrackIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
};

// Size: 0x88
struct FContextualAnimActorPreviewData
{
public:
    FName Role() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    TSoftObjectPtr<USkeletalMesh> PreviewSkeletalMesh() const { return Read<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> PreviewStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_PreviewSkeletalMesh(const TSoftObjectPtr<USkeletalMesh>& Value) { Write<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PreviewStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x14
struct FContextualAnimIKTargetDefinition
{
public:
    FName GoalName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    uint8_t Provider() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    FName TargetRoleName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    FName TargetBoneName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)

    void SET_GoalName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_Provider(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_TargetRoleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_TargetBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
};

// Size: 0x70
struct FContextualAnimIKTarget
{
public:
    FName GoalName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_GoalName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x18
struct FContextualAnimIKTargetDefContainer
{
public:
    FName Role() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FContextualAnimIKTargetDefinition> IKTargetDefs() const { return Read<TArray<FContextualAnimIKTargetDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Role(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_IKTargetDefs(const TArray<FContextualAnimIKTargetDefinition>& Value) { Write<TArray<FContextualAnimIKTargetDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FContextualAnimIKTargetParams
{
public:
    TArray<FContextualAnimIKTargetDefContainer> IKTargetDefsForEachRole() const { return Read<TArray<FContextualAnimIKTargetDefContainer>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t AlphaProvider() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_IKTargetDefsForEachRole(const TArray<FContextualAnimIKTargetDefContainer>& Value) { Write<TArray<FContextualAnimIKTargetDefContainer>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_AlphaProvider(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x70
struct FContextualAnimRoleDefinition
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bIsCharacter() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    float PreviewCapsuleHalfHeight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float PreviewCapsuleRadius() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    FTransform MeshToComponent() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bIsCharacter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_PreviewCapsuleHalfHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_PreviewCapsuleRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MeshToComponent(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x68
struct FContextualAnimStartSceneParams
{
public:
    TMap<FName, FContextualAnimSceneBindingContext> RoleToActorMap() const { return Read<TMap<FName, FContextualAnimSceneBindingContext>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    int32_t SectionIdx() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx() const { return Read<int32_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: IntProperty)

    void SET_RoleToActorMap(const TMap<FName, FContextualAnimSceneBindingContext>& Value) { Write<TMap<FName, FContextualAnimSceneBindingContext>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_SectionIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
    void SET_AnimSetIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: IntProperty)
};

// Size: 0xe0
struct FContextualAnimQueryResult
{
public:
    TWeakObjectPtr<UAnimMontage*> Animation() const { return Read<TWeakObjectPtr<UAnimMontage*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FTransform EntryTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform SyncTransform() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    float AnimStartTime() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    int32_t AnimSetIdx() const { return Read<int32_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: IntProperty)

    void SET_Animation(const TWeakObjectPtr<UAnimMontage*>& Value) { Write<TWeakObjectPtr<UAnimMontage*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EntryTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_SyncTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_AnimStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_AnimSetIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
struct FContextualAnimQueryParams
{
public:
    TWeakObjectPtr<AActor*> Querier() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FTransform QueryTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    bool bComplexQuery() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bFindAnimStartTime() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)

    void SET_Querier(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_QueryTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_bComplexQuery(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bFindAnimStartTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
};

