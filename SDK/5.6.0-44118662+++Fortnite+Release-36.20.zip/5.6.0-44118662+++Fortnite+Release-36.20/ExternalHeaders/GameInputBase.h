/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameInputBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DeveloperSettings.h"

// Size: 0x60
class UGameInputPlatformSettings : public UPlatformSettings
{
public:
    bool bProcessController() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bProcessRawInput() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bSpecialDevicesRequireExplicitDeviceConfiguration() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)
    bool bProcessGamepad() const { return Read<bool>(uintptr_t(this) + 0x43); } // 0x43 (Size: 0x1, Type: BoolProperty)
    bool bProcessKeyboard() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    bool bProcessMouse() const { return Read<bool>(uintptr_t(this) + 0x45); } // 0x45 (Size: 0x1, Type: BoolProperty)
    bool bProcessRacingWheel() const { return Read<bool>(uintptr_t(this) + 0x46); } // 0x46 (Size: 0x1, Type: BoolProperty)
    float RacingWheelDeadzone() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bProcessArcadeStick() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bProcessFlightStick() const { return Read<bool>(uintptr_t(this) + 0x4d); } // 0x4d (Size: 0x1, Type: BoolProperty)
    float FlightStickPitchDeadzone() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float FlightStickRollDeadzone() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float FlightStickThrottleDeadzone() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float FlightStickYawDeadzone() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)

    void SET_bProcessController(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessRawInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_bSpecialDevicesRequireExplicitDeviceConfiguration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessGamepad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43, Value); } // 0x43 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessKeyboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessMouse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x45, Value); } // 0x45 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessRacingWheel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x46, Value); } // 0x46 (Size: 0x1, Type: BoolProperty)
    void SET_RacingWheelDeadzone(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_bProcessArcadeStick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_bProcessFlightStick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d, Value); } // 0x4d (Size: 0x1, Type: BoolProperty)
    void SET_FlightStickPitchDeadzone(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_FlightStickRollDeadzone(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_FlightStickThrottleDeadzone(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_FlightStickYawDeadzone(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
class UGameInputDeveloperSettings : public UObject
{
public:
    TArray<FGameInputDeviceConfiguration> DeviceConfigurations() const { return Read<TArray<FGameInputDeviceConfiguration>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FPerPlatformSettings PlatformSpecificSettings() const { return Read<FPerPlatformSettings>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    bool bDoNotProcessDuplicateCapabilitiesForSingleUser() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_DeviceConfigurations(const TArray<FGameInputDeviceConfiguration>& Value) { Write<TArray<FGameInputDeviceConfiguration>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_PlatformSpecificSettings(const FPerPlatformSettings& Value) { Write<FPerPlatformSettings>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_bDoNotProcessDuplicateCapabilitiesForSingleUser(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FGameInputDeviceIdentifier
{
public:
    uint16_t VendorId() const { return Read<uint16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: UInt16Property)
    uint16_t ProductID() const { return Read<uint16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: UInt16Property)

    void SET_VendorId(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: UInt16Property)
    void SET_ProductID(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x10
struct FGameInputControllerAxisData
{
public:
    FName KeyName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float DeadZone() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Scalar() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bIsPackedPositveAndNegative() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_KeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_DeadZone(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Scalar(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bIsPackedPositveAndNegative(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
struct FGameInputRawDeviceReportData
{
public:
    FName KeyName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bIgnoreAnalogInputDeviceScopeForThisRawReport() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t TranslationBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: EnumProperty)
    char AnalogDeadzone() const { return Read<char>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: ByteProperty)
    float Scalar() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    TMap<int32_t, FName> ButtonBitMaskMappings() const { return Read<TMap<int32_t, FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)
    char LowerBitAxisIndex() const { return Read<char>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: ByteProperty)
    char HigherBitAxisIndex() const { return Read<char>(uintptr_t(this) + 0x61); } // 0x61 (Size: 0x1, Type: ByteProperty)

    void SET_KeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bIgnoreAnalogInputDeviceScopeForThisRawReport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_TranslationBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: EnumProperty)
    void SET_AnalogDeadzone(const char& Value) { Write<char>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: ByteProperty)
    void SET_Scalar(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ButtonBitMaskMappings(const TMap<int32_t, FName>& Value) { Write<TMap<int32_t, FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
    void SET_LowerBitAxisIndex(const char& Value) { Write<char>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: ByteProperty)
    void SET_HigherBitAxisIndex(const char& Value) { Write<char>(uintptr_t(this) + 0x61, Value); } // 0x61 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x118
struct FGameInputDeviceConfiguration
{
public:
    FGameInputDeviceIdentifier DeviceIdentifier() const { return Read<FGameInputDeviceIdentifier>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    bool bOverrideHardwareDeviceIdString() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FString OverriddenHardwareDeviceId() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    bool bProcessControllerButtons() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bProcessControllerSwitchState() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bProcessControllerAxis() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    TMap<uint32_t, FName> ControllerButtonMappingData() const { return Read<TMap<uint32_t, FName>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: MapProperty)
    TMap<uint32_t, FGameInputControllerAxisData> ControllerAxisMappingData() const { return Read<TMap<uint32_t, FGameInputControllerAxisData>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x50, Type: MapProperty)
    bool bProcessRawReportData() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint32_t RawReportReadingId() const { return Read<uint32_t>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: UInt32Property)
    TMap<int32_t, FGameInputRawDeviceReportData> RawReportMappingData() const { return Read<TMap<int32_t, FGameInputRawDeviceReportData>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x50, Type: MapProperty)

    void SET_DeviceIdentifier(const FGameInputDeviceIdentifier& Value) { Write<FGameInputDeviceIdentifier>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_bOverrideHardwareDeviceIdString(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_OverriddenHardwareDeviceId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_bProcessControllerButtons(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessControllerSwitchState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_bProcessControllerAxis(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET_ControllerButtonMappingData(const TMap<uint32_t, FName>& Value) { Write<TMap<uint32_t, FName>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: MapProperty)
    void SET_ControllerAxisMappingData(const TMap<uint32_t, FGameInputControllerAxisData>& Value) { Write<TMap<uint32_t, FGameInputControllerAxisData>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x50, Type: MapProperty)
    void SET_bProcessRawReportData(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_RawReportReadingId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: UInt32Property)
    void SET_RawReportMappingData(const TMap<int32_t, FGameInputRawDeviceReportData>& Value) { Write<TMap<int32_t, FGameInputRawDeviceReportData>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x50, Type: MapProperty)
};

