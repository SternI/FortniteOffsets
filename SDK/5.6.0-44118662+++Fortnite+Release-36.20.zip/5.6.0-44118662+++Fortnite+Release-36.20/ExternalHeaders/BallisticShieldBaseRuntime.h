/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BallisticShieldBaseRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x13f0
class UBallisticShieldItemLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bIsRush() const { return Read<bool>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x1, Type: BoolProperty)
    bool bIsEquipping() const { return Read<bool>(uintptr_t(this) + 0x1309); } // 0x1309 (Size: 0x1, Type: BoolProperty)
    bool bEnterLanding() const { return Read<bool>(uintptr_t(this) + 0x130a); } // 0x130a (Size: 0x1, Type: BoolProperty)
    bool bExitLanding() const { return Read<bool>(uintptr_t(this) + 0x130b); } // 0x130b (Size: 0x1, Type: BoolProperty)
    bool bIsShieldBlocking() const { return Read<bool>(uintptr_t(this) + 0x130c); } // 0x130c (Size: 0x1, Type: BoolProperty)
    bool bIsStaggerBuildup() const { return Read<bool>(uintptr_t(this) + 0x130d); } // 0x130d (Size: 0x1, Type: BoolProperty)
    float Yaw() const { return Read<float>(uintptr_t(this) + 0x1310); } // 0x1310 (Size: 0x4, Type: FloatProperty)
    float ChargeAOAlpha() const { return Read<float>(uintptr_t(this) + 0x1314); } // 0x1314 (Size: 0x4, Type: FloatProperty)
    int32_t GenderAndSize() const { return Read<int32_t>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x4, Type: IntProperty)
    float ReloadUBAlpha() const { return Read<float>(uintptr_t(this) + 0x131c); } // 0x131c (Size: 0x4, Type: FloatProperty)
    float MaskLeftArmAlpha() const { return Read<float>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x4, Type: FloatProperty)
    float StaggerAmount() const { return Read<float>(uintptr_t(this) + 0x1324); } // 0x1324 (Size: 0x4, Type: FloatProperty)

    void SET_bIsRush(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEquipping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1309, Value); } // 0x1309 (Size: 0x1, Type: BoolProperty)
    void SET_bEnterLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130a, Value); } // 0x130a (Size: 0x1, Type: BoolProperty)
    void SET_bExitLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130b, Value); } // 0x130b (Size: 0x1, Type: BoolProperty)
    void SET_bIsShieldBlocking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130c, Value); } // 0x130c (Size: 0x1, Type: BoolProperty)
    void SET_bIsStaggerBuildup(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130d, Value); } // 0x130d (Size: 0x1, Type: BoolProperty)
    void SET_Yaw(const float& Value) { Write<float>(uintptr_t(this) + 0x1310, Value); } // 0x1310 (Size: 0x4, Type: FloatProperty)
    void SET_ChargeAOAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x1314, Value); } // 0x1314 (Size: 0x4, Type: FloatProperty)
    void SET_GenderAndSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x4, Type: IntProperty)
    void SET_ReloadUBAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x131c, Value); } // 0x131c (Size: 0x4, Type: FloatProperty)
    void SET_MaskLeftArmAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x4, Type: FloatProperty)
    void SET_StaggerAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x1324, Value); } // 0x1324 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UBallisticShieldWeaponInterface : public UInterface
{
public:
};

// Size: 0x5b0
class UFortMovementMode_ELBShieldSprint : public UFortMovementMode_ELTacSprint
{
public:
};

// Size: 0xb0
class UTargetingFilterTask_BShieldCharge : public UTargetingFilterTask_BasicFilterTemplate
{
public:
    TArray<UClass*> WalkableActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat BashableActorAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    FScalableFloat MainTraceDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorHitZTolerance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)

    void SET_WalkableActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_BashableActorAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_MainTraceDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_FloorHitZTolerance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
};

