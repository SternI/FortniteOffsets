/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRigSpline
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "ControlRig.h"

// Size: 0x68
struct FControlRigSplineImpl
{
public:
};

// Size: 0x18
struct FControlRigSpline
{
public:
};

// Size: 0x8
struct FRigUnit_ControlRigSplineBase : public FRigUnit
{
public:
};

// Size: 0x40
struct FRigUnit_ControlRigSplineFromPoints : public FRigUnit_ControlRigSplineBase
{
public:
    TArray<FVector> Points() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t SplineMode() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bClosed() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    int32_t SamplesPerSegment() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    float Compression() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float Stretch() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Points(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_SplineMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bClosed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_SamplesPerSegment(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_Compression(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Stretch(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_ControlRigSplineFromTransforms : public FRigUnit_ControlRigSplineBase
{
public:
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t SplineMode() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bClosed() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    int32_t SamplesPerSegment() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    float Compression() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float Stretch() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_SplineMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bClosed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_SamplesPerSegment(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_Compression(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Stretch(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SetSplinePoints : public FRigUnitMutable
{
public:
    TArray<FVector> Points() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Points(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SetSplineTransforms : public FRigUnitMutable
{
public:
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_PositionFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_TransformFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector UpVector() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Roll() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x60, Type: StructProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_UpVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Roll(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x60, Type: StructProperty)
};

// Size: 0xc0
struct FRigUnit_TransformFromControlRigSpline2 : public FRigUnit_ControlRigSplineBase
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x60, Type: StructProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x60, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_TangentFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FVector Tangent() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Tangent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_DrawControlRigSpline : public FRigUnitMutable
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    int32_t Detail() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Detail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FRigUnit_GetLengthControlRigSpline : public FRigUnit
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float Length() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Length(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FRigUnit_GetLengthAtParamControlRigSpline : public FRigUnit
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float Length() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Length(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1e0
struct FRigUnit_FitChainToSplineCurve : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision() const { return Read<int32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations() const { return Read<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings() const { return Read<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData() const { return Read<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x98, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_SamplingPrecision(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: IntProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_Rotations(const TArray<FRigUnit_FitChainToCurve_Rotation>& Value) { Write<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_FitChainToCurve_DebugSettings& Value) { Write<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x90, Type: StructProperty)
    void SET_WorkData(const FRigUnit_FitChainToCurve_WorkData& Value) { Write<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x98, Type: StructProperty)
};

// Size: 0x1e0
struct FRigUnit_FitChainToSplineCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision() const { return Read<int32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations() const { return Read<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings() const { return Read<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData() const { return Read<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x98, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_SamplingPrecision(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: IntProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_Rotations(const TArray<FRigUnit_FitChainToCurve_Rotation>& Value) { Write<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_FitChainToCurve_DebugSettings& Value) { Write<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x90, Type: StructProperty)
    void SET_WorkData(const FRigUnit_FitChainToCurve_WorkData& Value) { Write<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x98, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SplineConstraint_WorkData
{
public:
    float ChainLength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<FTransform> ItemTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemSegments() const { return Read<TArray<float>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ChainLength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ItemTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemSegments(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb8
struct FRigUnit_SplineConstraint : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    FRigUnit_SplineConstraint_WorkData WorkData() const { return Read<FRigUnit_SplineConstraint_WorkData>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x38, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_SplineConstraint_WorkData& Value) { Write<FRigUnit_SplineConstraint_WorkData>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x38, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_FitSplineCurveToChain : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_FitSplineCurveToChainItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_ClosestParameterFromControlRigSpline : public FRigUnit_ControlRigSplineBase
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FRigUnit_ParameterAtPercentage : public FRigUnit_ControlRigSplineBase
{
public:
    FControlRigSpline Spline() const { return Read<FControlRigSpline>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float Percentage() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float U() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)

    void SET_Spline(const FControlRigSpline& Value) { Write<FControlRigSpline>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Percentage(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_U(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
};

