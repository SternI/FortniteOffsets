/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNOnlineFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x40
class UFNOnlineFrameworkSubsystem : public UGameInstanceSubsystem
{
public:
};

