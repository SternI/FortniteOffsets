/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricDevices
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "HarmonixMetasound.h"
#include "FMCoreRuntime.h"
#include "FabricRuntime.h"

// Size: 0x178
class UFabricDeviceComponent : public UFabricDeviceComponentBase
{
public:
    bool bListenToMusicManagerEvents() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UFabricSpeakerManagerComponent*> SpeakerManager() const { return Read<TWeakObjectPtr<UFabricSpeakerManagerComponent*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> MetaSoundManager() const { return Read<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFMCoreMusicManagerComponent*> MusicManager() const { return Read<TWeakObjectPtr<UFMCoreMusicManagerComponent*>>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClock() const { return Read<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicTempometerComponent*> MusicTempometer() const { return Read<TWeakObjectPtr<UMusicTempometerComponent*>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bListenToMusicManagerEvents(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    void SET_SpeakerManager(const TWeakObjectPtr<UFabricSpeakerManagerComponent*>& Value) { Write<TWeakObjectPtr<UFabricSpeakerManagerComponent*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MetaSoundManager(const TWeakObjectPtr<UFabricMetaSoundManagerComponent*>& Value) { Write<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MusicManager(const TWeakObjectPtr<UFMCoreMusicManagerComponent*>& Value) { Write<TWeakObjectPtr<UFMCoreMusicManagerComponent*>>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MusicClock(const TWeakObjectPtr<UMusicClockComponent*>& Value) { Write<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MusicTempometer(const TWeakObjectPtr<UMusicTempometerComponent*>& Value) { Write<TWeakObjectPtr<UMusicTempometerComponent*>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: WeakObjectProperty)
};

