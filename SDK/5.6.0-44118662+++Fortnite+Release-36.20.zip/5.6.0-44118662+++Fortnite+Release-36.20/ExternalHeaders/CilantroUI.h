/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CilantroUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CommonUI.h"
#include "FortniteUI.h"

// Size: 0x4a0
class UFortPlaytimeBlock : public UCommonActivatableWidget
{
public:
    UCommonActivatableWidgetStack* WidgetStack_Takeover() const { return Read<UCommonActivatableWidgetStack*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)

    void SET_WidgetStack_Takeover(const UCommonActivatableWidgetStack*& Value) { Write<UCommonActivatableWidgetStack*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x690
class UFortPlaytimeManagementScreen : public UFortPinScreen
{
public:
    UCommonActivatableWidgetSwitcher* Switcher_SubViews() const { return Read<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    UFortSettingsPanel* Panel_PlaytimeSettings() const { return Read<UFortSettingsPanel*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UFortSettingsPanel* Panel_PlaytimeScheduleSettings() const { return Read<UFortSettingsPanel*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    UFortSettingDetailView* Details_Settings() const { return Read<UFortSettingDetailView*>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeScheduleWidget* PlaytimeScheduleWidget() const { return Read<UFortPlaytimeScheduleWidget*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeSettingRegistry* PlaytimeSettingRegistry() const { return Read<UFortPlaytimeSettingRegistry*>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeScheduleSettingRegistry* PlaytimeSettingScheduleRegistry() const { return Read<UFortPlaytimeScheduleSettingRegistry*>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)

    void SET_Switcher_SubViews(const UCommonActivatableWidgetSwitcher*& Value) { Write<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_Panel_PlaytimeSettings(const UFortSettingsPanel*& Value) { Write<UFortSettingsPanel*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Panel_PlaytimeScheduleSettings(const UFortSettingsPanel*& Value) { Write<UFortSettingsPanel*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Details_Settings(const UFortSettingDetailView*& Value) { Write<UFortSettingDetailView*>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaytimeScheduleWidget(const UFortPlaytimeScheduleWidget*& Value) { Write<UFortPlaytimeScheduleWidget*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaytimeSettingRegistry(const UFortPlaytimeSettingRegistry*& Value) { Write<UFortPlaytimeSettingRegistry*>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaytimeSettingScheduleRegistry(const UFortPlaytimeScheduleSettingRegistry*& Value) { Write<UFortPlaytimeScheduleSettingRegistry*>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2f8
class UFortPlaytimeScheduleWidget : public UUserWidget
{
public:
};

// Size: 0x1c0
class UFortPlaytimeReportSettingRegistry : public UFortSettingRegistry
{
public:
    UFortSettingCollection* PlaytimeReportSettings() const { return Read<UFortSettingCollection*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)

    void SET_PlaytimeReportSettings(const UFortSettingCollection*& Value) { Write<UFortSettingCollection*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1d0
class UFortPlaytimeSettingRegistry : public UFortSettingRegistry
{
public:
    UFortSettingCollection* PlaytimeSettings() const { return Read<UFortSettingCollection*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)

    void SET_PlaytimeSettings(const UFortSettingCollection*& Value) { Write<UFortSettingCollection*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1c0
class UFortPlaytimeScheduleSettingRegistry : public UFortSettingRegistry
{
public:
    UFortSettingCollection* PlaytimeScheduleSettings() const { return Read<UFortSettingCollection*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)

    void SET_PlaytimeScheduleSettings(const UFortSettingCollection*& Value) { Write<UFortSettingCollection*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1f8
class UFortSettingValueDiscreteSupervisedScheduleToggle : public UFortSettingValueDiscrete
{
public:
};

// Size: 0x458
class UFortTimeLimitPanelStw : public UCommonActivatableWidget
{
public:
    UCommonActivatableWidget* ViewTimeLimitPanel() const { return Read<UCommonActivatableWidget*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)

    void SET_ViewTimeLimitPanel(const UCommonActivatableWidget*& Value) { Write<UCommonActivatableWidget*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x450
class UFortViewTimeLimitPanel : public UCommonActivatableWidget
{
public:
};

// Size: 0xc8
class UPlayerPlaytimeVM : public UFortPerUserViewModel
{
public:
    float ElapsedSleepTime() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t PlayState() const { return Read<uint8_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: EnumProperty)

    void SET_ElapsedSleepTime(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_PlayState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x610
class UTimeReportsManagementScreen : public UFortPinScreen
{
public:
    UFortSettingsPanel* Panel_TimeReportSettings() const { return Read<UFortSettingsPanel*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    UFortSettingDetailView* Details_Settings() const { return Read<UFortSettingDetailView*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeReportSettingRegistry* PlaytimeReportSettingRegistry() const { return Read<UFortPlaytimeReportSettingRegistry*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)

    void SET_Panel_TimeReportSettings(const UFortSettingsPanel*& Value) { Write<UFortSettingsPanel*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_Details_Settings(const UFortSettingDetailView*& Value) { Write<UFortSettingDetailView*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaytimeReportSettingRegistry(const UFortPlaytimeReportSettingRegistry*& Value) { Write<UFortPlaytimeReportSettingRegistry*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x450
class UFortPlaytimePinActivatableWidget : public UCommonActivatableWidget
{
public:
};

// Size: 0x30
struct FPlaytimeScheduleEntryData
{
public:
    FText DayText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText AllowedTimeText() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    TArray<FText> TimeWindowTexts() const { return Read<TArray<FText>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_DayText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_AllowedTimeText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_TimeWindowTexts(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

