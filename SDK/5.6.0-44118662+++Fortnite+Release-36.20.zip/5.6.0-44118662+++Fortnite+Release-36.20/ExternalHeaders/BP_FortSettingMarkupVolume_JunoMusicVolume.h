/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_FortSettingMarkupVolume_JunoMusicVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa0
class UBP_FortSettingMarkupVolume_JunoMusicVolume_C : public UFortSettingVolumeMarkup
{
public:
};

