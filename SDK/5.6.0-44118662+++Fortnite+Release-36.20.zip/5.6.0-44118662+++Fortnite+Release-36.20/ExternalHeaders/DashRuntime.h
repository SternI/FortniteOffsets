/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DashRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayAbilities.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x60
class UFortMovementMode_DashRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

// Size: 0x4c0
class UFortMovementMode_ExtDash : public UFortMovementMode_BaseExtLogic
{
public:
    FScalableFloat DashDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x28, Type: StructProperty)
    FScalableFloat DashDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseMovementForTargetDeadzone() const { return Read<FScalableFloat>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat bUseDynamicZTarget() const { return Read<FScalableFloat>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZMaxReverseAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZMinReverseAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZReverseModifier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZReverseTargetMinZ() const { return Read<FScalableFloat>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x28, Type: StructProperty)
    FScalableFloat DashEndVelocity() const { return Read<FScalableFloat>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x28, Type: StructProperty)
    FScalableFloat bDashEndVelocityUseZ() const { return Read<FScalableFloat>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x28, Type: StructProperty)
    FScalableFloat DashAccelerationMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x28, Type: StructProperty)
    FScalableFloat EndVelocityMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat EndVelocityMultiplierOnNoUserInput() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat bRestrictSpeedToExpected() const { return Read<FScalableFloat>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x28, Type: StructProperty)
    uint8_t VelocityOnFinishMode() const { return Read<uint8_t>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x1, Type: EnumProperty)
    FScalableFloat ClampVelocityOnFinish() const { return Read<FScalableFloat>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x28, Type: StructProperty)
    FScalableFloat HeightAboveGround() const { return Read<FScalableFloat>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x28, Type: StructProperty)
    FScalableFloat bEnsureHeightAboveGround() const { return Read<FScalableFloat>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x28, Type: StructProperty)
    UCurveVector* PathOffsetCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)

    void SET_DashDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x28, Type: StructProperty)
    void SET_DashDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x28, Type: StructProperty)
    void SET_UseMovementForTargetDeadzone(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x28, Type: StructProperty)
    void SET_bUseDynamicZTarget(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_DynamicZMaxReverseAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x28, Type: StructProperty)
    void SET_DynamicZMinReverseAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x28, Type: StructProperty)
    void SET_DynamicZReverseModifier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x28, Type: StructProperty)
    void SET_DynamicZReverseTargetMinZ(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x28, Type: StructProperty)
    void SET_DashEndVelocity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x28, Type: StructProperty)
    void SET_bDashEndVelocityUseZ(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x28, Type: StructProperty)
    void SET_DashAccelerationMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x28, Type: StructProperty)
    void SET_EndVelocityMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x28, Type: StructProperty)
    void SET_EndVelocityMultiplierOnNoUserInput(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x28, Type: StructProperty)
    void SET_bRestrictSpeedToExpected(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x28, Type: StructProperty)
    void SET_VelocityOnFinishMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x1, Type: EnumProperty)
    void SET_ClampVelocityOnFinish(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x28, Type: StructProperty)
    void SET_HeightAboveGround(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x28, Type: StructProperty)
    void SET_bEnsureHeightAboveGround(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x28, Type: StructProperty)
    void SET_PathOffsetCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FFortMovementMode_DashCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
    FRotator AimDirection() const { return Read<FRotator>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    bool bHasMovementInput() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_AimDirection(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_bHasMovementInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

