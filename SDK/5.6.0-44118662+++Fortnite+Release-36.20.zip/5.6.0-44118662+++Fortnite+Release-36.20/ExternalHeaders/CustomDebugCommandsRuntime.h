/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomDebugCommandsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x30
class UCustomDebugCommandManager : public UObject
{
public:
    ADebugCameraController* DebugCameraControllerRef() const { return Read<ADebugCameraController*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_DebugCameraControllerRef(const ADebugCameraController*& Value) { Write<ADebugCameraController*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf0
class UFortControllerComponent_CustomDebugCommands : public UControllerComponent
{
public:
    FString CommandValidationPrefix() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)
    FString ServerCommandPrefix() const { return Read<FString>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StrProperty)
    UCustomDebugCommandManager* DebugCommandManager() const { return Read<UCustomDebugCommandManager*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)

    void SET_CommandValidationPrefix(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
    void SET_ServerCommandPrefix(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StrProperty)
    void SET_DebugCommandManager(const UCustomDebugCommandManager*& Value) { Write<UCustomDebugCommandManager*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
};

