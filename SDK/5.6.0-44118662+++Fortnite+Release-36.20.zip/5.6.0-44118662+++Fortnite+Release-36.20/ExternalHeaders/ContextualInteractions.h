/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContextualInteractions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0x28
class UContextualInteractionHandler : public UInterface
{
public:
};

// Size: 0x110
class UContextualInteractionsComponent : public UActorComponent
{
public:
    UCapsuleComponent* QuickJoinInteractCollisionComponent() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_QuickJoinInteractCollisionComponent(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x110
class UControllerComponent_ContextualInteractionsManager : public UControllerComponent
{
public:
    float TraceDistance() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float DesiredRadius() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float FullUpdateFrequencyInSeconds() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)

    void SET_TraceDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_FullUpdateFrequencyInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x118
class UInteractableComponent_ContextualInteractionViaAim : public UContextualInteractionsComponent
{
public:
};

// Size: 0xc0
class UInteractableComponent_FocusedViaAim : public UActorComponent
{
public:
};

// Size: 0xc0
class UInteractableComponent_FocusedViaOverlap : public UActorComponent
{
public:
};

// Size: 0x28
class UPlayerFocusable : public UInterface
{
public:
};

// Size: 0x28
class UHandlesPlayerFocusable : public UInterface
{
public:
};

// Size: 0xd8
class UPlayspaceComponent_ContextualInteractionsBridge : public UPlayspaceComponent
{
public:
};

