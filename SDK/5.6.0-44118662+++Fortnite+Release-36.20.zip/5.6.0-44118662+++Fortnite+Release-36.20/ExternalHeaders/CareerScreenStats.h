/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CareerScreenStats
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "WBP_CareerPlaceholderTab.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "CommonUI.h"
#include "Blueprints.h"
#include "CareerUI.h"
#include "FortniteUI.h"
#include "CoachMarks.h"
#include "WBP_LevelCountStats.h"
#include "WBP_StatsOptionsDisplay.h"
#include "OptionsModal.h"
#include "WBP_StatsRow.h"

// Size: 0x784
class UCareerScreenStats_C : public UAthenaCareerStatsScreen
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: StructProperty)
    UCommonActivatableWidgetSwitcher* WidgetSwitcher() const { return Read<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    UWBP_StatsRow_C* WBP_StatsRow_29() const { return Read<UWBP_StatsRow_C*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    UWBP_StatsRow_C* WBP_StatsRow() const { return Read<UWBP_StatsRow_C*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UWBP_StatsOptionsDisplay_C* WBP_StatsOptionsDisplay() const { return Read<UWBP_StatsOptionsDisplay_C*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UWBP_LevelCountStats_C* WBP_LevelCountStats() const { return Read<UWBP_LevelCountStats_C*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    UWBP_CareerPlaceholderTab_C* WBP_CareerPlaceholderTab() const { return Read<UWBP_CareerPlaceholderTab_C*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate_1() const { return Read<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate() const { return Read<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VerticalBox_RankedProgressInfo() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    USpacer* TopBarLeftSpacer() const { return Read<USpacer*>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_5() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_3() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_2() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_1() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_Content() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SB_Rank() const { return Read<USizeBox*>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    USafeZone* SafeZone() const { return Read<USafeZone*>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    UImage* ProgressSpinner() const { return Read<UImage*>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* PlaceholderScreen() const { return Read<UOverlay*>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* NoDataBox() const { return Read<UCommonBorder*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* MainScreen() const { return Read<UOverlay*>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    UFortFlagImage* Image_YourFlag() const { return Read<UFortFlagImage*>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background() const { return Read<UImage*>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HB_AccountLevel() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UCommonAnimatedSwitcher* CommonAnimatedSwitcher_ProgressInfo() const { return Read<UCommonAnimatedSwitcher*>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UFortVisualAttachment* ChangeFlag_VisualAttachment() const { return Read<UFortVisualAttachment*>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x8, Type: ObjectProperty)
    UWBP_ChangeFlag_CoachMark_C* ChangeFlag_CoachMark() const { return Read<UWBP_ChangeFlag_CoachMark_C*>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* FinishedLoading() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x8, Type: ObjectProperty)
    UFortCareerStatsScreenVM* FortCareerStatsScreenVM() const { return Read<UFortCareerStatsScreenVM*>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle Input_ReplayCinematic() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x10, Type: StructProperty)
    bool AutoPlayVideo() const { return Read<bool>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x1, Type: BoolProperty)
    FDataTableRowHandle Input_Replays() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x738); } // 0x738 (Size: 0x10, Type: StructProperty)
    UWBP_StatsOptionsModal_C* OptionsModal() const { return Read<UWBP_StatsOptionsModal_C*>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    bool InitializedRanksData() const { return Read<bool>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x1, Type: BoolProperty)
    USoundBase* WhooshTileSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    USoundBase* TabWhooshSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    bool HandledRanksLoaded() const { return Read<bool>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x1, Type: BoolProperty)
    FDataTableRowHandle Input_ChangeFlag() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x10, Type: StructProperty)
    FGameplayTag ChangeFlagCoachMarkTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: StructProperty)
    void SET_WidgetSwitcher(const UCommonActivatableWidgetSwitcher*& Value) { Write<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_StatsRow_29(const UWBP_StatsRow_C*& Value) { Write<UWBP_StatsRow_C*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_StatsRow(const UWBP_StatsRow_C*& Value) { Write<UWBP_StatsRow_C*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_StatsOptionsDisplay(const UWBP_StatsOptionsDisplay_C*& Value) { Write<UWBP_StatsOptionsDisplay_C*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_LevelCountStats(const UWBP_LevelCountStats_C*& Value) { Write<UWBP_LevelCountStats_C*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_CareerPlaceholderTab(const UWBP_CareerPlaceholderTab_C*& Value) { Write<UWBP_CareerPlaceholderTab_C*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_CaptureForPostBufferUpdate_1(const UWBP_CaptureForPostBufferUpdate_C*& Value) { Write<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_CaptureForPostBufferUpdate(const UWBP_CaptureForPostBufferUpdate_C*& Value) { Write<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_VerticalBox_RankedProgressInfo(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_TopBarLeftSpacer(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    void SET_Tier_Name_5(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_Tier_Name_3(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x8, Type: ObjectProperty)
    void SET_Tier_Name_2(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    void SET_Tier_Name_1(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    void SET_Tier_Name(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Content(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SB_Rank(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    void SET_SafeZone(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    void SET_ProgressSpinner(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaceholderScreen(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    void SET_NoDataBox(const UCommonBorder*& Value) { Write<UCommonBorder*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    void SET_MainScreen(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_YourFlag(const UFortFlagImage*& Value) { Write<UFortFlagImage*>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    void SET_HB_AccountLevel(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    void SET_CommonAnimatedSwitcher_ProgressInfo(const UCommonAnimatedSwitcher*& Value) { Write<UCommonAnimatedSwitcher*>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    void SET_ChangeFlag_VisualAttachment(const UFortVisualAttachment*& Value) { Write<UFortVisualAttachment*>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x8, Type: ObjectProperty)
    void SET_ChangeFlag_CoachMark(const UWBP_ChangeFlag_CoachMark_C*& Value) { Write<UWBP_ChangeFlag_CoachMark_C*>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x8, Type: ObjectProperty)
    void SET_FinishedLoading(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x8, Type: ObjectProperty)
    void SET_FortCareerStatsScreenVM(const UFortCareerStatsScreenVM*& Value) { Write<UFortCareerStatsScreenVM*>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x8, Type: ObjectProperty)
    void SET_Input_ReplayCinematic(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x10, Type: StructProperty)
    void SET_AutoPlayVideo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x1, Type: BoolProperty)
    void SET_Input_Replays(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x738, Value); } // 0x738 (Size: 0x10, Type: StructProperty)
    void SET_OptionsModal(const UWBP_StatsOptionsModal_C*& Value) { Write<UWBP_StatsOptionsModal_C*>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    void SET_InitializedRanksData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x1, Type: BoolProperty)
    void SET_WhooshTileSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    void SET_TabWhooshSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    void SET_HandledRanksLoaded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x1, Type: BoolProperty)
    void SET_Input_ChangeFlag(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x10, Type: StructProperty)
    void SET_ChangeFlagCoachMarkTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x4, Type: StructProperty)
};

