/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonUILegacy
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "UMG.h"

// Size: 0x588
class UCommonActivatablePanelLegacy : public UCommonActivatableWidget
{
public:
    bool bConsumeAllActions() const { return Read<bool>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x1, Type: BoolProperty)
    bool bExposeActionsExternally() const { return Read<bool>(uintptr_t(this) + 0x479); } // 0x479 (Size: 0x1, Type: BoolProperty)
    bool bShouldBypassStack() const { return Read<bool>(uintptr_t(this) + 0x47a); } // 0x47a (Size: 0x1, Type: BoolProperty)

    void SET_bConsumeAllActions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x1, Type: BoolProperty)
    void SET_bExposeActionsExternally(const bool& Value) { Write<bool>(uintptr_t(this) + 0x479, Value); } // 0x479 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldBypassStack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x47a, Value); } // 0x47a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x600
class UCommonButtonInternalLegacy : public UCommonButtonInternalBase
{
public:
};

// Size: 0x1540
class UCommonButtonLegacy : public UCommonButtonBase
{
public:
};

// Size: 0x70
class UCommonGlobalInputHandlerLegacy : public UObject
{
public:
};

// Size: 0x108
class UCommonInputManagerLegacy : public UObject
{
public:
    TScriptInterface<Class> CurrentlyHeldActionInputHandler() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: InterfaceProperty)
    TArray<UCommonActivatablePanelLegacy*> ActivatablePanelStack() const { return Read<TArray<UCommonActivatablePanelLegacy*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    UCommonGlobalInputHandlerLegacy* GlobalInputHandler() const { return Read<UCommonGlobalInputHandlerLegacy*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TArray<FOperation> Operations() const { return Read<TArray<FOperation>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)

    void SET_CurrentlyHeldActionInputHandler(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: InterfaceProperty)
    void SET_ActivatablePanelStack(const TArray<UCommonActivatablePanelLegacy*>& Value) { Write<TArray<UCommonActivatablePanelLegacy*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalInputHandler(const UCommonGlobalInputHandlerLegacy*& Value) { Write<UCommonGlobalInputHandlerLegacy*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Operations(const TArray<FOperation>& Value) { Write<TArray<FOperation>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x350
class UCommonInputReflectorLegacy : public UCommonUserWidget
{
public:
    UClass* ButtonType() const { return Read<UClass*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ClassProperty)
    TArray<UCommonButtonLegacy*> ActiveButtons() const { return Read<TArray<UCommonButtonLegacy*>>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: ArrayProperty)
    TArray<UCommonButtonLegacy*> InactiveButtons() const { return Read<TArray<UCommonButtonLegacy*>>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x10, Type: ArrayProperty)

    void SET_ButtonType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ClassProperty)
    void SET_ActiveButtons(const TArray<UCommonButtonLegacy*>& Value) { Write<TArray<UCommonButtonLegacy*>>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: ArrayProperty)
    void SET_InactiveButtons(const TArray<UCommonButtonLegacy*>& Value) { Write<TArray<UCommonButtonLegacy*>>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1550
class UCommonPopupButtonLegacy : public UCommonButtonLegacy
{
public:
    UMenuAnchor* PopupMenuAnchor() const { return Read<UMenuAnchor*>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    UCommonPopupMenuLegacy* PopupMenu() const { return Read<UCommonPopupMenuLegacy*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)

    void SET_PopupMenuAnchor(const UMenuAnchor*& Value) { Write<UMenuAnchor*>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    void SET_PopupMenu(const UCommonPopupMenuLegacy*& Value) { Write<UCommonPopupMenuLegacy*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x5a0
class UCommonPopupMenuLegacy : public UCommonActivatablePanelLegacy
{
public:
    bool bUseInputStack() const { return Read<bool>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UMenuAnchor*> OwningMenuAnchor() const { return Read<TWeakObjectPtr<UMenuAnchor*>>(uintptr_t(this) + 0x58c); } // 0x58c (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UObject*> ContextProvidingObject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x594); } // 0x594 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bUseInputStack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x1, Type: BoolProperty)
    void SET_OwningMenuAnchor(const TWeakObjectPtr<UMenuAnchor*>& Value) { Write<TWeakObjectPtr<UMenuAnchor*>>(uintptr_t(this) + 0x58c, Value); } // 0x58c (Size: 0x8, Type: WeakObjectProperty)
    void SET_ContextProvidingObject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x594, Value); } // 0x594 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x4b8
class UCommonTabListWidgetLegacy : public UCommonTabListWidgetBase
{
public:
};

// Size: 0x70
class UCommonUISubsystemLegacy : public UCommonUISubsystemBase
{
public:
    UCommonInputManagerLegacy* CommonInputManager() const { return Read<UCommonInputManagerLegacy*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_CommonInputManager(const UCommonInputManagerLegacy*& Value) { Write<UCommonInputManagerLegacy*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x300
class UCommonVisibilityWidgetLegacy : public UCommonBorder
{
public:
    bool bShowForGamepad() const { return Read<bool>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x1, Type: BoolProperty)
    bool bShowForMouseAndKeyboard() const { return Read<bool>(uintptr_t(this) + 0x2f1); } // 0x2f1 (Size: 0x1, Type: BoolProperty)
    bool bShowForTouch() const { return Read<bool>(uintptr_t(this) + 0x2f2); } // 0x2f2 (Size: 0x1, Type: BoolProperty)
    bool bShowForPC() const { return Read<bool>(uintptr_t(this) + 0x2f3); } // 0x2f3 (Size: 0x1, Type: BoolProperty)
    bool bShowForMac() const { return Read<bool>(uintptr_t(this) + 0x2f4); } // 0x2f4 (Size: 0x1, Type: BoolProperty)
    bool bShowForPS4() const { return Read<bool>(uintptr_t(this) + 0x2f5); } // 0x2f5 (Size: 0x1, Type: BoolProperty)
    bool bShowForPS5() const { return Read<bool>(uintptr_t(this) + 0x2f6); } // 0x2f6 (Size: 0x1, Type: BoolProperty)
    bool bShowForXBox() const { return Read<bool>(uintptr_t(this) + 0x2f7); } // 0x2f7 (Size: 0x1, Type: BoolProperty)
    bool bShowForXSX() const { return Read<bool>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x1, Type: BoolProperty)
    bool bShowForIOS() const { return Read<bool>(uintptr_t(this) + 0x2f9); } // 0x2f9 (Size: 0x1, Type: BoolProperty)
    bool bShowForAndroid() const { return Read<bool>(uintptr_t(this) + 0x2fa); } // 0x2fa (Size: 0x1, Type: BoolProperty)
    bool bShowForErebus() const { return Read<bool>(uintptr_t(this) + 0x2fb); } // 0x2fb (Size: 0x1, Type: BoolProperty)
    bool bShowForSwitch2() const { return Read<bool>(uintptr_t(this) + 0x2fc); } // 0x2fc (Size: 0x1, Type: BoolProperty)
    uint8_t VisibleType() const { return Read<uint8_t>(uintptr_t(this) + 0x2fd); } // 0x2fd (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenType() const { return Read<uint8_t>(uintptr_t(this) + 0x2fe); } // 0x2fe (Size: 0x1, Type: EnumProperty)

    void SET_bShowForGamepad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForMouseAndKeyboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f1, Value); } // 0x2f1 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForTouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f2, Value); } // 0x2f2 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForPC(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f3, Value); } // 0x2f3 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForMac(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f4, Value); } // 0x2f4 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForPS4(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f5, Value); } // 0x2f5 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForPS5(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f6, Value); } // 0x2f6 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForXBox(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f7, Value); } // 0x2f7 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForXSX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForIOS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f9, Value); } // 0x2f9 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForAndroid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2fa, Value); } // 0x2fa (Size: 0x1, Type: BoolProperty)
    void SET_bShowForErebus(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2fb, Value); } // 0x2fb (Size: 0x1, Type: BoolProperty)
    void SET_bShowForSwitch2(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2fc, Value); } // 0x2fc (Size: 0x1, Type: BoolProperty)
    void SET_VisibleType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2fd, Value); } // 0x2fd (Size: 0x1, Type: EnumProperty)
    void SET_HiddenType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2fe, Value); } // 0x2fe (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1b8
class UCommonWidgetStackLegacy : public UCommonVisibilitySwitcher
{
public:
};

// Size: 0x238
class UCommonWidgetSwitcherLegacy : public UCommonAnimatedSwitcher
{
public:
    bool bWidgetActivationEnabled() const { return Read<bool>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x1, Type: BoolProperty)
    bool bOutroPanelBelow() const { return Read<bool>(uintptr_t(this) + 0x231); } // 0x231 (Size: 0x1, Type: BoolProperty)

    void SET_bWidgetActivationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x1, Type: BoolProperty)
    void SET_bOutroPanelBelow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x231, Value); } // 0x231 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x200
class UCommonButtonGroupLegacy : public UCommonButtonGroupBase
{
public:
};

// Size: 0x1e0
class UCommonUIActionRouterLegacy : public UCommonUIActionRouterBase
{
public:
};

// Size: 0x28
struct FOperation
{
public:
    uint8_t Operation() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    UCommonActivatablePanelLegacy* Panel() const { return Read<UCommonActivatablePanelLegacy*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bIntroPanel() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bActivatePanel() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bOutroPanelBelow() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)

    void SET_Operation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Panel(const UCommonActivatablePanelLegacy*& Value) { Write<UCommonActivatablePanelLegacy*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIntroPanel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bActivatePanel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bOutroPanelBelow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x990
struct FCommonInputActionData : public FCommonInputActionDataBase
{
public:
    TMap<ECommonGamepadType, FCommonInputTypeInfo> GamepadInputTypeInfoOverrides() const { return Read<TMap<ECommonGamepadType, FCommonInputTypeInfo>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x50, Type: MapProperty)
    FCommonInputTypeInfo GamepadInputTypeInfos() const { return Read<FCommonInputTypeInfo>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x620, Type: StructProperty)

    void SET_GamepadInputTypeInfoOverrides(const TMap<ECommonGamepadType, FCommonInputTypeInfo>& Value) { Write<TMap<ECommonGamepadType, FCommonInputTypeInfo>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x50, Type: MapProperty)
    void SET_GamepadInputTypeInfos(const FCommonInputTypeInfo& Value) { Write<FCommonInputTypeInfo>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x620, Type: StructProperty)
};

