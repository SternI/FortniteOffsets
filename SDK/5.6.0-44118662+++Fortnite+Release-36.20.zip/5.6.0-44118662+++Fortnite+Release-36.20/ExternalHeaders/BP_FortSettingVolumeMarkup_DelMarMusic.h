/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_FortSettingVolumeMarkup_DelMarMusic
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa0
class UBP_FortSettingVolumeMarkup_DelMarMusic_C : public UFortSettingVolumeMarkup
{
public:
};

