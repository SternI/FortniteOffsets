/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ArtTools
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x1c
struct FHoudiniInstanceDataLayout
{
public:
    float Px_4_F5C0CE7F4E57E0634EEBA7986A38B75B() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Py_7_462CEB644FCF8818190E0DA7A4233236() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Pz_8_488530224541EBF7D43F2F99AE2CCEAF() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Nx_18_51E5EF044A718D85E72395AA9D96475D() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Ny_22_85D94369412DF832716FAD9638F05274() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Nz_23_267E08D5410B2BAA799B67975DE79784() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float pscale_24_C1C793994E739F1A41356ABC35528C18() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_Px_4_F5C0CE7F4E57E0634EEBA7986A38B75B(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Py_7_462CEB644FCF8818190E0DA7A4233236(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Pz_8_488530224541EBF7D43F2F99AE2CCEAF(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Nx_18_51E5EF044A718D85E72395AA9D96475D(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Ny_22_85D94369412DF832716FAD9638F05274(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Nz_23_267E08D5410B2BAA799B67975DE79784(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_pscale_24_C1C793994E739F1A41356ABC35528C18(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UB_TechArt_GlobalLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class URenderToTextureFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UEUW_FunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

