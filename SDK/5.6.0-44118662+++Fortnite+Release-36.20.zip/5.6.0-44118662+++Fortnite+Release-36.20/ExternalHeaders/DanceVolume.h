/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DanceVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0xf0
class UDanceSynchronizerComponent : public UActorComponent
{
public:
    bool bShouldHalfOrDoubleTimeDances() const { return (Read<uint8_t>(uintptr_t(this) + 0xb8) >> 0x0) & 1; } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    FDanceBeatInfo BeatInfo() const { return Read<FDanceBeatInfo>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x8, Type: StructProperty)
    uint8_t SyncMode() const { return Read<uint8_t>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x1, Type: EnumProperty)
    float Tempo() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    AFortPlayerPawn* OwnerPlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* OwnerMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* LeaderMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_bShouldHalfOrDoubleTimeDances(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb8, B); } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    void SET_BeatInfo(const FDanceBeatInfo& Value) { Write<FDanceBeatInfo>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x8, Type: StructProperty)
    void SET_SyncMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x1, Type: EnumProperty)
    void SET_Tempo(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_OwnerPlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UDanceVolumeLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x8
struct FDanceBeatInfo
{
public:
    float LengthBeats() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float StartOffsetMs() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_LengthBeats(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_StartOffsetMs(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

