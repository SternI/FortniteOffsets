/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaOptions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x110
struct FEpicMediaOptions
{
public:
    int32_t FrameRate() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaxResolutionForMediaStreaming() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MaxElectraVerticalResolutionOf60fpsVideos() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MaxElectraVerticalResolutionOfWindowsSWD() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    bool bElectraLiveUseConservativePresentationOffset() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bElectraUseDedicatedMediaSegmentDownloadThreads() const { return Read<bool>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: BoolProperty)
    double ElectraLivePresentationOffset() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ElectraLiveAudioPresentationOffset() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    bool bDisableBlastURLStreamSource() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsCN() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    TArray<FString> VideoEVMap() const { return Read<TArray<FString>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<float> CDNDistribution() const { return Read<TArray<float>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesCN() const { return Read<TArray<FString>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesCN() const { return Read<TArray<FString>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesDev() const { return Read<TArray<FString>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesDev() const { return Read<TArray<FString>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesHF() const { return Read<TArray<FString>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesHF() const { return Read<TArray<FString>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesCNHF() const { return Read<TArray<FString>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesCNHF() const { return Read<TArray<FString>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    bool bUseQuicksilverEntryPoint() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    bool bUseSegmentCaching() const { return Read<bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: BoolProperty)
    bool bForceSegmentCaching() const { return Read<bool>(uintptr_t(this) + 0x109); } // 0x109 (Size: 0x1, Type: BoolProperty)
    float MetadataRequestTimeout() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)

    void SET_FrameRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_MaxResolutionForMediaStreaming(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_MaxElectraVerticalResolutionOf60fpsVideos(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_MaxElectraVerticalResolutionOfWindowsSWD(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_bElectraLiveUseConservativePresentationOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_bElectraUseDedicatedMediaSegmentDownloadThreads(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: BoolProperty)
    void SET_ElectraLivePresentationOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_ElectraLiveAudioPresentationOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_bDisableBlastURLStreamSource(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCN(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_VideoEVMap(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_CDNDistribution(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_VODHostNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_VODHostNamesCN(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_LiveHostNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_LiveHostNamesCN(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_VODHostNamesDev(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_LiveHostNamesDev(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_VODHostNamesHF(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_LiveHostNamesHF(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_VODHostNamesCNHF(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_LiveHostNamesCNHF(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseQuicksilverEntryPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSegmentCaching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: BoolProperty)
    void SET_bForceSegmentCaching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x109, Value); } // 0x109 (Size: 0x1, Type: BoolProperty)
    void SET_MetadataRequestTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
};

