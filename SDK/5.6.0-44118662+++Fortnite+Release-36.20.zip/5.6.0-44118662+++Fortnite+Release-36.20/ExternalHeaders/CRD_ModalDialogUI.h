/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ModalDialogUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"

// Size: 0x28
class UCreativeModalDialogAllowedConversionFunction : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UCreativeModalDialogConversionFunction : public UCreativeModalDialogAllowedConversionFunction
{
public:
};

// Size: 0x270
class UCreativeModalDialogViewmodel : public UMVVMViewModelBase
{
public:
    FText Title() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    FText Body() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    UDataTable* TextStyleSet() const { return Read<UDataTable*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    FText Button01_MainText() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FText Button02_MainText() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)
    FText Button03_MainText() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)
    FText Button04_MainText() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText Button05_MainText() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    FText Button06_MainText() const { return Read<FText>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: TextProperty)
    FText Button07_MainText() const { return Read<FText>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: TextProperty)
    FText Button08_MainText() const { return Read<FText>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: TextProperty)
    FText Button09_MainText() const { return Read<FText>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: TextProperty)
    FText Button10_MainText() const { return Read<FText>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: TextProperty)
    FText Button11_MainText() const { return Read<FText>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: TextProperty)
    FText Button12_MainText() const { return Read<FText>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: TextProperty)
    FText Button01_SubText() const { return Read<FText>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: TextProperty)
    FText Button02_SubText() const { return Read<FText>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: TextProperty)
    FText Button03_SubText() const { return Read<FText>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: TextProperty)
    FText Button04_SubText() const { return Read<FText>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: TextProperty)
    FText Button05_SubText() const { return Read<FText>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: TextProperty)
    FText Button06_SubText() const { return Read<FText>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: TextProperty)
    FText Button07_SubText() const { return Read<FText>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    FText Button08_SubText() const { return Read<FText>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    FText Button09_SubText() const { return Read<FText>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    FText Button10_SubText() const { return Read<FText>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: TextProperty)
    FText Button11_SubText() const { return Read<FText>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: TextProperty)
    FText Button12_SubText() const { return Read<FText>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x10, Type: TextProperty)
    UTexture2D* Art01_Image() const { return Read<UTexture2D*>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Art02_Image() const { return Read<UTexture2D*>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* Art01_Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* Art02_Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: ObjectProperty)
    uint8_t ContentAlignment() const { return Read<uint8_t>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x1, Type: EnumProperty)
    bool bShowBackground() const { return Read<bool>(uintptr_t(this) + 0x231); } // 0x231 (Size: 0x1, Type: BoolProperty)
    float DialogBackgroundAlpha() const { return Read<float>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x4, Type: FloatProperty)
    uint8_t TimerOption() const { return Read<uint8_t>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: EnumProperty)
    float Timeout() const { return Read<float>(uintptr_t(this) + 0x23c); } // 0x23c (Size: 0x4, Type: FloatProperty)
    float RemainingTimeForTimeout() const { return Read<float>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: FloatProperty)
    float Progress() const { return Read<float>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: FloatProperty)
    int64_t NumberOfButtons() const { return Read<int64_t>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x8, Type: Int64Property)
    uint8_t BackActionBoundButton() const { return Read<uint8_t>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x1, Type: EnumProperty)
    uint8_t Response() const { return Read<uint8_t>(uintptr_t(this) + 0x251); } // 0x251 (Size: 0x1, Type: EnumProperty)
    uint8_t Button01_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x252); } // 0x252 (Size: 0x1, Type: EnumProperty)
    uint8_t Button02_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x253); } // 0x253 (Size: 0x1, Type: EnumProperty)
    uint8_t Button03_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x254); } // 0x254 (Size: 0x1, Type: EnumProperty)
    uint8_t Button04_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x255); } // 0x255 (Size: 0x1, Type: EnumProperty)
    uint8_t Button05_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x256); } // 0x256 (Size: 0x1, Type: EnumProperty)
    uint8_t Button06_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x257); } // 0x257 (Size: 0x1, Type: EnumProperty)
    uint8_t Button07_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x1, Type: EnumProperty)
    uint8_t Button08_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x259); } // 0x259 (Size: 0x1, Type: EnumProperty)
    uint8_t Button09_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x25a); } // 0x25a (Size: 0x1, Type: EnumProperty)
    uint8_t Button10_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x25b); } // 0x25b (Size: 0x1, Type: EnumProperty)
    uint8_t Button11_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x25c); } // 0x25c (Size: 0x1, Type: EnumProperty)
    uint8_t Button12_Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0x25d); } // 0x25d (Size: 0x1, Type: EnumProperty)
    USoundBase* HoveredSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PressedSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ObjectProperty)

    void SET_Title(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_Body(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_TextStyleSet(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_Button01_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_Button02_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
    void SET_Button03_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
    void SET_Button04_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_Button05_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_Button06_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: TextProperty)
    void SET_Button07_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: TextProperty)
    void SET_Button08_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: TextProperty)
    void SET_Button09_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: TextProperty)
    void SET_Button10_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: TextProperty)
    void SET_Button11_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: TextProperty)
    void SET_Button12_MainText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: TextProperty)
    void SET_Button01_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: TextProperty)
    void SET_Button02_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: TextProperty)
    void SET_Button03_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: TextProperty)
    void SET_Button04_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: TextProperty)
    void SET_Button05_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: TextProperty)
    void SET_Button06_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: TextProperty)
    void SET_Button07_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    void SET_Button08_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    void SET_Button09_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    void SET_Button10_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: TextProperty)
    void SET_Button11_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: TextProperty)
    void SET_Button12_SubText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x10, Type: TextProperty)
    void SET_Art01_Image(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x8, Type: ObjectProperty)
    void SET_Art02_Image(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    void SET_Art01_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    void SET_Art02_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentAlignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x1, Type: EnumProperty)
    void SET_bShowBackground(const bool& Value) { Write<bool>(uintptr_t(this) + 0x231, Value); } // 0x231 (Size: 0x1, Type: BoolProperty)
    void SET_DialogBackgroundAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x4, Type: FloatProperty)
    void SET_TimerOption(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: EnumProperty)
    void SET_Timeout(const float& Value) { Write<float>(uintptr_t(this) + 0x23c, Value); } // 0x23c (Size: 0x4, Type: FloatProperty)
    void SET_RemainingTimeForTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: FloatProperty)
    void SET_Progress(const float& Value) { Write<float>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: FloatProperty)
    void SET_NumberOfButtons(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x8, Type: Int64Property)
    void SET_BackActionBoundButton(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x1, Type: EnumProperty)
    void SET_Response(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x251, Value); } // 0x251 (Size: 0x1, Type: EnumProperty)
    void SET_Button01_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x252, Value); } // 0x252 (Size: 0x1, Type: EnumProperty)
    void SET_Button02_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x253, Value); } // 0x253 (Size: 0x1, Type: EnumProperty)
    void SET_Button03_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x254, Value); } // 0x254 (Size: 0x1, Type: EnumProperty)
    void SET_Button04_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x255, Value); } // 0x255 (Size: 0x1, Type: EnumProperty)
    void SET_Button05_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x256, Value); } // 0x256 (Size: 0x1, Type: EnumProperty)
    void SET_Button06_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x257, Value); } // 0x257 (Size: 0x1, Type: EnumProperty)
    void SET_Button07_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x1, Type: EnumProperty)
    void SET_Button08_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x259, Value); } // 0x259 (Size: 0x1, Type: EnumProperty)
    void SET_Button09_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x25a, Value); } // 0x25a (Size: 0x1, Type: EnumProperty)
    void SET_Button10_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x25b, Value); } // 0x25b (Size: 0x1, Type: EnumProperty)
    void SET_Button11_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x25c, Value); } // 0x25c (Size: 0x1, Type: EnumProperty)
    void SET_Button12_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x25d, Value); } // 0x25d (Size: 0x1, Type: EnumProperty)
    void SET_HoveredSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    void SET_PressedSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x460
class UCreativeModalDialogWidget : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle MainMenuInputRowHandle() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: StructProperty)

    void SET_MainMenuInputRowHandle(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: StructProperty)
};

