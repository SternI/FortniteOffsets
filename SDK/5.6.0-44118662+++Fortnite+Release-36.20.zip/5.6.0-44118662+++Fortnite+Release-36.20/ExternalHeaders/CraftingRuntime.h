/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CraftingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "DataRegistry.h"
#include "CoreUObject.h"
#include "ItemizationCoreRuntime.h"

// Size: 0xa28
class ACraftingObjectBGA : public ABuildingGameplayActor
{
public:
    AFortInventory* Inventory() const { return Read<AFortInventory*>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    USphereComponent* SphereComponent_InteractionRange() const { return Read<USphereComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetComponent* WidgetComponent_PotContents() const { return Read<UWidgetComponent*>(uintptr_t(this) + 0xa10); } // 0xa10 (Size: 0x8, Type: ObjectProperty)
    bool bShowCraftingUI() const { return Read<bool>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x1, Type: BoolProperty)
    bool bSendEventMessageOnLocalInteract() const { return Read<bool>(uintptr_t(this) + 0xa19); } // 0xa19 (Size: 0x1, Type: BoolProperty)
    bool bRunServerInteractionWhenSendingEventMessage() const { return Read<bool>(uintptr_t(this) + 0xa1a); } // 0xa1a (Size: 0x1, Type: BoolProperty)
    UStaticMeshComponent* CraftingObjectMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x8, Type: ObjectProperty)

    void SET_Inventory(const AFortInventory*& Value) { Write<AFortInventory*>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SphereComponent_InteractionRange(const USphereComponent*& Value) { Write<USphereComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_WidgetComponent_PotContents(const UWidgetComponent*& Value) { Write<UWidgetComponent*>(uintptr_t(this) + 0xa10, Value); } // 0xa10 (Size: 0x8, Type: ObjectProperty)
    void SET_bShowCraftingUI(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x1, Type: BoolProperty)
    void SET_bSendEventMessageOnLocalInteract(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa19, Value); } // 0xa19 (Size: 0x1, Type: BoolProperty)
    void SET_bRunServerInteractionWhenSendingEventMessage(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa1a, Value); } // 0xa1a (Size: 0x1, Type: BoolProperty)
    void SET_CraftingObjectMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UCraftingCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x510
class UCraftingObjectComponent : public UGameFrameworkComponent
{
public:
    FCraftingObjectRepStateData CraftingObjectRepStateData() const { return Read<FCraftingObjectRepStateData>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x18, Type: StructProperty)
    TMap<FCraftingMultiKey, FCraftingObjectServerStateData> CraftingObjectServerStateData() const { return Read<TMap<FCraftingMultiKey, FCraftingObjectServerStateData>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x50, Type: MapProperty)
    FName LastCraftedItemFormulaRow() const { return Read<FName>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: NameProperty)
    FString LastIngredientStringForAnalytics() const { return Read<FString>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: StrProperty)
    FString LastFormulaStringForAnalytics() const { return Read<FString>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: StrProperty)
    FString LastResultsStringForAnalytics() const { return Read<FString>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: StrProperty)
    FGameplayAbilitySpecHandle WhileCraftingAbilitySpecHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: StructProperty)
    FGameplayAbilitySpecHandle OwnerCraftingAbilitySpecHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: StructProperty)
    FGameplayTag CraftingObjectTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer CraftingObjectTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x20, Type: StructProperty)
    FScalableFloat CraftingTimeLength() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReadyTimeLength() const { return Read<FScalableFloat>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat OverCraftingTimeLength() const { return Read<FScalableFloat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat ResettingTimeLength() const { return Read<FScalableFloat>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x28, Type: StructProperty)
    FScalableFloat DefaultCraftingSpeedMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FName OverCraftingLootTierKey() const { return Read<FName>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: NameProperty)
    bool bTakeItemsAtCraftingStart() const { return (Read<uint8_t>(uintptr_t(this) + 0x2ac) >> 0x0) & 1; } // 0x2ac:0 (Size: 0x1, Type: BoolProperty)
    float DecayRate() const { return Read<float>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    bool bGiveIngredientsToCraftingObject() const { return (Read<uint8_t>(uintptr_t(this) + 0x2b4) >> 0x0) & 1; } // 0x2b4:0 (Size: 0x1, Type: BoolProperty)
    bool bGiveIngredientsToInstigator() const { return (Read<uint8_t>(uintptr_t(this) + 0x2b4) >> 0x1) & 1; } // 0x2b4:1 (Size: 0x1, Type: BoolProperty)
    FVector IngredientSpawnOffset() const { return Read<FVector>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x18, Type: StructProperty)
    bool bPrioritizeSmallestIngredientStacks() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d0) >> 0x0) & 1; } // 0x2d0:0 (Size: 0x1, Type: BoolProperty)
    bool bGiveToCraftingObject() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d0) >> 0x1) & 1; } // 0x2d0:1 (Size: 0x1, Type: BoolProperty)
    bool bGiveResultToInstigator() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d0) >> 0x2) & 1; } // 0x2d0:2 (Size: 0x1, Type: BoolProperty)
    bool bScaleMultiCraftingTime() const { return Read<bool>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer CraftingFailedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer IngredientsInventoryGroupTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x20, Type: StructProperty)
    bool FreeCraftingEnabled() const { return Read<bool>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x1, Type: BoolProperty)

    void SET_CraftingObjectRepStateData(const FCraftingObjectRepStateData& Value) { Write<FCraftingObjectRepStateData>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x18, Type: StructProperty)
    void SET_CraftingObjectServerStateData(const TMap<FCraftingMultiKey, FCraftingObjectServerStateData>& Value) { Write<TMap<FCraftingMultiKey, FCraftingObjectServerStateData>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x50, Type: MapProperty)
    void SET_LastCraftedItemFormulaRow(const FName& Value) { Write<FName>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: NameProperty)
    void SET_LastIngredientStringForAnalytics(const FString& Value) { Write<FString>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: StrProperty)
    void SET_LastFormulaStringForAnalytics(const FString& Value) { Write<FString>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: StrProperty)
    void SET_LastResultsStringForAnalytics(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: StrProperty)
    void SET_WhileCraftingAbilitySpecHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: StructProperty)
    void SET_OwnerCraftingAbilitySpecHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: StructProperty)
    void SET_CraftingObjectTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: StructProperty)
    void SET_CraftingObjectTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x20, Type: StructProperty)
    void SET_CraftingTimeLength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    void SET_ReadyTimeLength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x28, Type: StructProperty)
    void SET_OverCraftingTimeLength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x28, Type: StructProperty)
    void SET_ResettingTimeLength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x28, Type: StructProperty)
    void SET_DefaultCraftingSpeedMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_OverCraftingLootTierKey(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: NameProperty)
    void SET_bTakeItemsAtCraftingStart(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2ac); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2ac, B); } // 0x2ac:0 (Size: 0x1, Type: BoolProperty)
    void SET_DecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    void SET_bGiveIngredientsToCraftingObject(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2b4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2b4, B); } // 0x2b4:0 (Size: 0x1, Type: BoolProperty)
    void SET_bGiveIngredientsToInstigator(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2b4); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x2b4, B); } // 0x2b4:1 (Size: 0x1, Type: BoolProperty)
    void SET_IngredientSpawnOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x18, Type: StructProperty)
    void SET_bPrioritizeSmallestIngredientStacks(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2d0, B); } // 0x2d0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bGiveToCraftingObject(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x2d0, B); } // 0x2d0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bGiveResultToInstigator(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x2d0, B); } // 0x2d0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bScaleMultiCraftingTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x1, Type: BoolProperty)
    void SET_CraftingFailedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x20, Type: StructProperty)
    void SET_IngredientsInventoryGroupTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x20, Type: StructProperty)
    void SET_FreeCraftingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
class UFortControllerComponent_CraftingNetworkEvents : public UFortControllerComponent
{
public:
};

// Size: 0x268
class UFortGameStateComponent_Crafting : public UFortGameStateComponent
{
public:
    FDataRegistryType CraftingFormulaRegistryType() const { return Read<FDataRegistryType>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: StructProperty)
    FDataRegistryType CraftingIngredientsUIDataRegistryType() const { return Read<FDataRegistryType>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: StructProperty)
    TArray<FCraftingResult> CraftingResultsList() const { return Read<TArray<FCraftingResult>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x10, Type: ArrayProperty)

    void SET_CraftingFormulaRegistryType(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: StructProperty)
    void SET_CraftingIngredientsUIDataRegistryType(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: StructProperty)
    void SET_CraftingResultsList(const TArray<FCraftingResult>& Value) { Write<TArray<FCraftingResult>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf8
class UFortPickupInteractOverrideComponent_Crafting : public UFortPickupInteractOverrideComponent
{
public:
    UItemDefinitionBase* LastPickupItemDef() const { return Read<UItemDefinitionBase*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UItemDefinitionBase* LastFocusedItemDef() const { return Read<UItemDefinitionBase*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    FName LastTargetFormulaName() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    float ContextualCraftingInteractDuration() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<TInteractionType> CachedInteractionType() const { return Read<TEnumAsByte<TInteractionType>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EInteractionBeingAttempted> CachedInteractionBeingAttempted() const { return Read<TEnumAsByte<EInteractionBeingAttempted>>(uintptr_t(this) + 0xf1); } // 0xf1 (Size: 0x1, Type: ByteProperty)

    void SET_LastPickupItemDef(const UItemDefinitionBase*& Value) { Write<UItemDefinitionBase*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_LastFocusedItemDef(const UItemDefinitionBase*& Value) { Write<UItemDefinitionBase*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_LastTargetFormulaName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_ContextualCraftingInteractDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_CachedInteractionType(const TEnumAsByte<TInteractionType>& Value) { Write<TEnumAsByte<TInteractionType>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: ByteProperty)
    void SET_CachedInteractionBeingAttempted(const TEnumAsByte<EInteractionBeingAttempted>& Value) { Write<TEnumAsByte<EInteractionBeingAttempted>>(uintptr_t(this) + 0xf1, Value); } // 0xf1 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xf0
class UFortContextualTutorial_CraftingComplete : public UFortContextualTutorial
{
public:
};

// Size: 0xf0
class UFortContextualTutorial_CraftingReady : public UFortContextualTutorial
{
public:
};

// Size: 0xf8
class UFortContextualTutorial_CraftingTabOpen : public UFortContextualTutorial
{
public:
};

// Size: 0x28
class UCraftingLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x10
struct FCraftingObjectAdditionalValidationEvent
{
public:
    AFortPlayerController* Instigator() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName FormulaRow() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_Instigator(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_FormulaRow(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
struct FCraftingObjectSuccessEvent
{
public:
    AActor* CraftingObject() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCraftingMultiKey Key() const { return Read<FCraftingMultiKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    AFortPlayerController* Instigator() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FName FormulaRowName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    TArray<FFortItemEntry> ConsumedIngredients() const { return Read<TArray<FFortItemEntry>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_CraftingObject(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Key(const FCraftingMultiKey& Value) { Write<FCraftingMultiKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Instigator(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_FormulaRowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_ConsumedIngredients(const TArray<FFortItemEntry>& Value) { Write<TArray<FFortItemEntry>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FCraftingMultiKey
{
public:
    int64_t Key() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)

    void SET_Key(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
};

// Size: 0x28
struct FCraftingObjectStateChangedEvent
{
public:
    AActor* CraftingObject() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCraftingMultiKey Key() const { return Read<FCraftingMultiKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    AFortPlayerController* Instigator() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t CraftingState() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    float CraftingStateStartTime() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float CraftingStateDuration() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_CraftingObject(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Key(const FCraftingMultiKey& Value) { Write<FCraftingMultiKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Instigator(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_CraftingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_CraftingStateStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_CraftingStateDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FCraftingObjectRepStateData
{
public:
    TArray<FCraftingObjectEntryState> CraftingObjectEntryStates() const { return Read<TArray<FCraftingObjectEntryState>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    float CraftingSpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_CraftingObjectEntryStates(const TArray<FCraftingObjectEntryState>& Value) { Write<TArray<FCraftingObjectEntryState>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_CraftingSpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FCraftingObjectEntryState
{
public:
    FCraftingMultiKey Key() const { return Read<FCraftingMultiKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t CraftingObjectState() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    float StateChangeServerTime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float PausedCraftingTime() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float OverriddenObjectStateLength() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FName CraftingFormulaRow() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    int32_t NumToCraft() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AFortPlayerController*> CraftingInstigator() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FCraftingObjectEntryInventory> Inventories() const { return Read<TArray<FCraftingObjectEntryInventory>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Key(const FCraftingMultiKey& Value) { Write<FCraftingMultiKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_CraftingObjectState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_StateChangeServerTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_PausedCraftingTime(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_OverriddenObjectStateLength(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CraftingFormulaRow(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_NumToCraft(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_CraftingInstigator(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Inventories(const TArray<FCraftingObjectEntryInventory>& Value) { Write<TArray<FCraftingObjectEntryInventory>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FCraftingObjectEntryInventory
{
public:
    TWeakObjectPtr<UObject*> Inventory() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Inventory(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x1b0
struct FCraftingObjectServerStateData
{
public:
    bool bNextResultsHandledExternally() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bIsNextCraftFree() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    bool bCraftingCompleted() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x2) & 1; } // 0x0:2 (Size: 0x1, Type: BoolProperty)
    AFortPickup* PendingPickupCraftingItem() const { return Read<AFortPickup*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName PendingPickupCraftingFormula() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FFortItemEntry PendingPickupCraftingItemEntry() const { return Read<FFortItemEntry>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x158, Type: StructProperty)
    int32_t PendingPickupHeldCount() const { return Read<int32_t>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: IntProperty)
    TArray<FFortItemEntry> AllOfTheIngredientItems() const { return Read<TArray<FFortItemEntry>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> NonConsumedIngredientItemIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x10, Type: ArrayProperty)
    TArray<FItemAndCount> CraftingResults() const { return Read<TArray<FItemAndCount>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    FGameplayAbilitySpecHandle InstigatorWhileCraftingAbilitySpecHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: StructProperty)

    void SET_bNextResultsHandledExternally(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsNextCraftFree(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bCraftingCompleted(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:2 (Size: 0x1, Type: BoolProperty)
    void SET_PendingPickupCraftingItem(const AFortPickup*& Value) { Write<AFortPickup*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_PendingPickupCraftingFormula(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_PendingPickupCraftingItemEntry(const FFortItemEntry& Value) { Write<FFortItemEntry>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x158, Type: StructProperty)
    void SET_PendingPickupHeldCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: IntProperty)
    void SET_AllOfTheIngredientItems(const TArray<FFortItemEntry>& Value) { Write<TArray<FFortItemEntry>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x10, Type: ArrayProperty)
    void SET_NonConsumedIngredientItemIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x10, Type: ArrayProperty)
    void SET_CraftingResults(const TArray<FItemAndCount>& Value) { Write<TArray<FItemAndCount>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    void SET_InstigatorWhileCraftingAbilitySpecHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FCraftingEvent_OpenCraftingMenu
{
public:
    AActor* CraftingObject() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CraftingObject(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FCraftingIngredientRequirement
{
public:
    FGameplayTagContainer IngredientTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    int32_t Count() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_IngredientTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Count(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x118
struct FCraftingUpgradeRule
{
public:
    FGameplayTagRequirements SourceItemTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements TargetItemTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x88, Type: StructProperty)
    char UpgradeFlags() const { return Read<char>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: ByteProperty)

    void SET_SourceItemTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x88, Type: StructProperty)
    void SET_TargetItemTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x88, Type: StructProperty)
    void SET_UpgradeFlags(const char& Value) { Write<char>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xe0
struct FCraftingFormula : public FItemShopTableRowBase
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject> PreviewImage() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    bool bEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x0) & 1; } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    bool bAlwaysKnownFormula() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x1) & 1; } // 0x40:1 (Size: 0x1, Type: BoolProperty)
    bool bInstantlyConsumeIngredients() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x2) & 1; } // 0x40:2 (Size: 0x1, Type: BoolProperty)
    int32_t SortingPriority() const { return Read<int32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: IntProperty)
    FGameplayTag SourceObjectTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer AttributeTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)
    TArray<FCraftingIngredientRequirement> RequiredIngredients() const { return Read<TArray<FCraftingIngredientRequirement>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    FName ResultLootTierKey() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    TArray<FCraftingUpgradeRule> UpgradeRules() const { return Read<TArray<FCraftingUpgradeRule>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    float OverrideCraftingTime() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_PreviewImage(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAlwaysKnownFormula(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:1 (Size: 0x1, Type: BoolProperty)
    void SET_bInstantlyConsumeIngredients(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:2 (Size: 0x1, Type: BoolProperty)
    void SET_SortingPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: IntProperty)
    void SET_SourceObjectTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: StructProperty)
    void SET_AttributeTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
    void SET_RequiredIngredients(const TArray<FCraftingIngredientRequirement>& Value) { Write<TArray<FCraftingIngredientRequirement>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_ResultLootTierKey(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_UpgradeRules(const TArray<FCraftingUpgradeRule>& Value) { Write<TArray<FCraftingUpgradeRule>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideCraftingTime(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FCraftingResult
{
public:
    FName ResultLootTierKey() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FItemAndCount> Results() const { return Read<TArray<FItemAndCount>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ResultLootTierKey(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Results(const TArray<FItemAndCount>& Value) { Write<TArray<FItemAndCount>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FCraftingIngredientUIData : public FItemShopTableRowBase
{
public:
    FGameplayTagContainer IngredientTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    TArray<TSoftObjectPtr<UItemDefinitionBase*>> ItemDefs() const { return Read<TArray<TSoftObjectPtr<UItemDefinitionBase*>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UObject*>> Icons() const { return Read<TArray<TSoftObjectPtr<UObject*>>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_IngredientTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_ItemDefs(const TArray<TSoftObjectPtr<UItemDefinitionBase*>>& Value) { Write<TArray<TSoftObjectPtr<UItemDefinitionBase*>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Icons(const TArray<TSoftObjectPtr<UObject*>>& Value) { Write<TArray<TSoftObjectPtr<UObject*>>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FCraftingIngredientQueryState
{
public:
    FCraftingIngredientRequirement Requirement() const { return Read<FCraftingIngredientRequirement>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    int32_t Owned() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t Missing() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)

    void SET_Requirement(const FCraftingIngredientRequirement& Value) { Write<FCraftingIngredientRequirement>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_Owned(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_Missing(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FCraftingTagsChangedMessage
{
public:
    AActor* CraftingObject() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CraftingObject(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FCraftingParameters
{
public:
    AFortPlayerController* Instigator() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* CraftingObject() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<TScriptInterface<Class>> Inventories() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName FormulaRow() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    int32_t NumberToCraft() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    FCraftingMultiKey Key() const { return Read<FCraftingMultiKey>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)
    float OverriddenObjectStateLength() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_Instigator(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CraftingObject(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Inventories(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FormulaRow(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_NumberToCraft(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_Key(const FCraftingMultiKey& Value) { Write<FCraftingMultiKey>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
    void SET_OverriddenObjectStateLength(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FCraftingQueryParameters
{
public:
    AFortPlayerController* Instigator() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* CraftingObject() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<TScriptInterface<Class>> Inventories() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName FormulaRow() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    TArray<FItemAndCount> AdditionalItems() const { return Read<TArray<FItemAndCount>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    int32_t NumberToCraft() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    FGameplayTagContainer InventoryGroups() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)

    void SET_Instigator(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CraftingObject(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Inventories(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FormulaRow(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_AdditionalItems(const TArray<FItemAndCount>& Value) { Write<TArray<FItemAndCount>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_NumberToCraft(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_InventoryGroups(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
};

