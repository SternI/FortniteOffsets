/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataRegistry
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x48
class UDataRegistrySettings : public UDeveloperSettings
{
public:
    TArray<FDirectoryPath> DirectoriesToScan() const { return Read<TArray<FDirectoryPath>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bInitializeAllLoadedRegistries() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreMissingCookedAssetRegistryData() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bDelayLoadingDataRegistriesUntilPIE() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)

    void SET_DirectoriesToScan(const TArray<FDirectoryPath>& Value) { Write<TArray<FDirectoryPath>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_bInitializeAllLoadedRegistries(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreMissingCookedAssetRegistryData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_bDelayLoadingDataRegistriesUntilPIE(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb8
class UDataRegistry : public UObject
{
public:
    FName RegistryType() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    FDataRegistryIdFormat IdFormat() const { return Read<FDataRegistryIdFormat>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)
    UScriptStruct* ItemStruct() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    TArray<UDataRegistrySource*> DataSources() const { return Read<TArray<UDataRegistrySource*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<UDataRegistrySource*> RuntimeSources() const { return Read<TArray<UDataRegistrySource*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    float TimerUpdateFrequency() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FDataRegistryCachePolicy DefaultCachePolicy() const { return Read<FDataRegistryCachePolicy>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x14, Type: StructProperty)

    void SET_RegistryType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_IdFormat(const FDataRegistryIdFormat& Value) { Write<FDataRegistryIdFormat>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
    void SET_ItemStruct(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_DataSources(const TArray<UDataRegistrySource*>& Value) { Write<TArray<UDataRegistrySource*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_RuntimeSources(const TArray<UDataRegistrySource*>& Value) { Write<TArray<UDataRegistrySource*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_TimerUpdateFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultCachePolicy(const FDataRegistryCachePolicy& Value) { Write<FDataRegistryCachePolicy>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x14, Type: StructProperty)
};

// Size: 0x38
class UDataRegistrySource : public UObject
{
public:
    UDataRegistrySource* ParentSource() const { return Read<UDataRegistrySource*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_ParentSource(const UDataRegistrySource*& Value) { Write<UDataRegistrySource*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x108
class UMetaDataRegistrySource : public UDataRegistrySource
{
public:
    uint8_t AssetUsage() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    FAssetManagerSearchRules SearchRules() const { return Read<FAssetManagerSearchRules>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: StructProperty)
    TMap<FName, UDataRegistrySource*> RuntimeChildren() const { return Read<TMap<FName, UDataRegistrySource*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x50, Type: MapProperty)

    void SET_AssetUsage(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_SearchRules(const FAssetManagerSearchRules& Value) { Write<FAssetManagerSearchRules>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: StructProperty)
    void SET_RuntimeChildren(const TMap<FName, UDataRegistrySource*>& Value) { Write<TMap<FName, UDataRegistrySource*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x50, Type: MapProperty)
};

// Size: 0x98
class UDataRegistrySource_CurveTable : public UDataRegistrySource
{
public:
    TSoftObjectPtr<UCurveTable> SourceTable() const { return Read<TSoftObjectPtr<UCurveTable>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    FDataRegistrySource_DataTableRules TableRules() const { return Read<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)
    UCurveTable* CachedTable() const { return Read<UCurveTable*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UCurveTable* PreloadTable() const { return Read<UCurveTable*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_SourceTable(const TSoftObjectPtr<UCurveTable>& Value) { Write<TSoftObjectPtr<UCurveTable>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TableRules(const FDataRegistrySource_DataTableRules& Value) { Write<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
    void SET_CachedTable(const UCurveTable*& Value) { Write<UCurveTable*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_PreloadTable(const UCurveTable*& Value) { Write<UCurveTable*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x118
class UMetaDataRegistrySource_CurveTable : public UMetaDataRegistrySource
{
public:
    UClass* CreatedSource() const { return Read<UClass*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ClassProperty)
    FDataRegistrySource_DataTableRules TableRules() const { return Read<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: StructProperty)

    void SET_CreatedSource(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ClassProperty)
    void SET_TableRules(const FDataRegistrySource_DataTableRules& Value) { Write<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: StructProperty)
};

// Size: 0x98
class UDataRegistrySource_DataTable : public UDataRegistrySource
{
public:
    TSoftObjectPtr<UDataTable> SourceTable() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    FDataRegistrySource_DataTableRules TableRules() const { return Read<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)
    UDataTable* CachedTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UDataTable* PreloadTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_SourceTable(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TableRules(const FDataRegistrySource_DataTableRules& Value) { Write<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
    void SET_CachedTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_PreloadTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x118
class UMetaDataRegistrySource_DataTable : public UMetaDataRegistrySource
{
public:
    UClass* CreatedSource() const { return Read<UClass*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ClassProperty)
    FDataRegistrySource_DataTableRules TableRules() const { return Read<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: StructProperty)

    void SET_CreatedSource(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ClassProperty)
    void SET_TableRules(const FDataRegistrySource_DataTableRules& Value) { Write<FDataRegistrySource_DataTableRules>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: StructProperty)
};

// Size: 0xf8
class UDataRegistrySubsystem : public UEngineSubsystem
{
public:
};

// Size: 0x18
struct FDataRegistryLookup
{
public:
};

// Size: 0x8
struct FDataRegistryId
{
public:
    FDataRegistryType RegistryType() const { return Read<FDataRegistryType>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FName ItemName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_RegistryType(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ItemName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x4
struct FDataRegistryType
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
struct FSoftDataRegistryOrTable
{
public:
    bool bUseDataRegistry() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UDataTable> Table() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    FDataRegistryType RegistryType() const { return Read<FDataRegistryType>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)

    void SET_bUseDataRegistry(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Table(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_RegistryType(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FDataRegistrySource_DataTableRules
{
public:
    bool bPrecacheTable() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float CachedTableKeepSeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bPrecacheTable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_CachedTableKeepSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FDataRegistryIdFormat
{
public:
    FGameplayTag BaseGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_BaseGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x14
struct FDataRegistryCachePolicy
{
public:
    bool bCacheIsAlwaysVolatile() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUseCurveTableCacheVersion() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    int32_t MinNumberKept() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaxNumberKept() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    float ForceKeepSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float ForceReleaseSeconds() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_bCacheIsAlwaysVolatile(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseCurveTableCacheVersion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_MinNumberKept(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_MaxNumberKept(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_ForceKeepSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_ForceReleaseSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDataRegistrySourceItemId
{
public:
};

// Size: 0x20
struct FDataRegistryOrTableRow
{
public:
    bool bUseDataRegistryId() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FDataTableRowHandle DataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FDataRegistryId DataRegistryId() const { return Read<FDataRegistryId>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_bUseDataRegistryId(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_DataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_DataRegistryId(const FDataRegistryId& Value) { Write<FDataRegistryId>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

