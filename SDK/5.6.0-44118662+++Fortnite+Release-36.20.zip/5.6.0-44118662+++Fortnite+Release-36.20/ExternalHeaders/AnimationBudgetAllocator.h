/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationBudgetAllocator
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x28
class UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xff0
class USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
public:
    bool bAutoRegisterWithBudgetAllocator() const { return (Read<uint8_t>(uintptr_t(this) + 0xfe8) >> 0x0) & 1; } // 0xfe8:0 (Size: 0x1, Type: BoolProperty)
    bool bAutoCalculateSignificance() const { return (Read<uint8_t>(uintptr_t(this) + 0xfe8) >> 0x1) & 1; } // 0xfe8:1 (Size: 0x1, Type: BoolProperty)
    bool bShouldUseActorRenderedFlag() const { return (Read<uint8_t>(uintptr_t(this) + 0xfe8) >> 0x2) & 1; } // 0xfe8:2 (Size: 0x1, Type: BoolProperty)

    void SET_bAutoRegisterWithBudgetAllocator(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xfe8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xfe8, B); } // 0xfe8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoCalculateSignificance(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xfe8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xfe8, B); } // 0xfe8:1 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldUseActorRenderedFlag(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xfe8); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xfe8, B); } // 0xfe8:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
struct FAnimationBudgetAllocatorParameters
{
public:
    float BudgetInMs() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinQuality() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MaxTickRate() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    float WorkUnitSmoothingSpeed() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float AlwaysTickFalloffAggression() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float InterpolationFalloffAggression() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t InterpolationMaxRate() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t MaxInterpolatedComponents() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    float InterpolationTickMultiplier() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float InitialEstimatedWorkUnitTimeMs() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    int32_t MaxTickedOffsreenComponents() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t StateChangeThrottleInFrames() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    float BudgetFactorBeforeReducedWork() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float BudgetFactorBeforeReducedWorkEpsilon() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float BudgetPressureSmoothingSpeed() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    int32_t ReducedWorkThrottleMinInFrames() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t ReducedWorkThrottleMaxInFrames() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)
    float BudgetFactorBeforeAggressiveReducedWork() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    int32_t ReducedWorkThrottleMaxPerFrame() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    float BudgetPressureBeforeEmergencyReducedWork() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float AutoCalculatedSignificanceMaxDistance() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_BudgetInMs(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MinQuality(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTickRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_WorkUnitSmoothingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_AlwaysTickFalloffAggression(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_InterpolationFalloffAggression(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_InterpolationMaxRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_MaxInterpolatedComponents(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_InterpolationTickMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_InitialEstimatedWorkUnitTimeMs(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTickedOffsreenComponents(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_StateChangeThrottleInFrames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_BudgetFactorBeforeReducedWork(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_BudgetFactorBeforeReducedWorkEpsilon(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_BudgetPressureSmoothingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_ReducedWorkThrottleMinInFrames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_ReducedWorkThrottleMaxInFrames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
    void SET_BudgetFactorBeforeAggressiveReducedWork(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_ReducedWorkThrottleMaxPerFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_BudgetPressureBeforeEmergencyReducedWork(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_AutoCalculatedSignificanceMaxDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

