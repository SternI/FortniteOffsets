/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicCMSUIFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "SlateCore.h"
#include "Engine.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "UMG.h"

// Size: 0x510
class UEpicCMSImage : public UCommonLazyImage
{
public:
    bool bMatchImageSize() const { return Read<bool>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x1, Type: BoolProperty)
    FSlateBrush LoadingFailFallback() const { return Read<FSlateBrush>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0xb0, Type: StructProperty)
    UTexture2D* ExternalMedia() const { return Read<UTexture2D*>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    bool bDownloadingExternalMedia() const { return Read<bool>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x1, Type: BoolProperty)

    void SET_bMatchImageSize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingFailFallback(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0xb0, Type: StructProperty)
    void SET_ExternalMedia(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    void SET_bDownloadingExternalMedia(const bool& Value) { Write<bool>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x360
class UEpicCMSLayoutBase : public UUserWidget
{
public:
    TArray<FSlotDescription> CarouselSlotDescriptions() const { return Read<TArray<FSlotDescription>>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    UClass* CarouselClass() const { return Read<UClass*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ClassProperty)

    void SET_CarouselSlotDescriptions(const TArray<FSlotDescription>& Value) { Write<TArray<FSlotDescription>>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    void SET_CarouselClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa0
class UEpicCMSManager : public UObject
{
public:
};

// Size: 0x600
class UEpicCMSScreenBase : public UCommonActivatablePanelLegacy
{
public:
    FString TileSetFieldName() const { return Read<FString>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x10, Type: StrProperty)
    TSoftObjectPtr<UDataTable> TileTypeToTileClassDataTable() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UDataTable> LayoutTypeToLayoutClassDataTable() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_TileSetFieldName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x10, Type: StrProperty)
    void SET_TileTypeToTileClassDataTable(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LayoutTypeToLayoutClassDataTable(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x338
class UEpicCMSSimpleMessage : public UCommonUserWidget
{
public:
    UCommonTextBlock* TitleText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* BodyText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UEpicCMSImage* PrimaryImage() const { return Read<UEpicCMSImage*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)

    void SET_TitleText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_BodyText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_PrimaryImage(const UEpicCMSImage*& Value) { Write<UEpicCMSImage*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1650
class UEpicCMSTileBase : public UCommonButtonLegacy
{
public:
    UClass* DefaultTitleTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ClassProperty)
    UClass* FeaturedTitleTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ClassProperty)
    FText Title() const { return Read<FText>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x10, Type: TextProperty)
    FString Link() const { return Read<FString>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x10, Type: StrProperty)
    bool bDownloadingExternalMedia() const { return Read<bool>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x1, Type: BoolProperty)
    bool bRefreshingMcpCatalog() const { return Read<bool>(uintptr_t(this) + 0x1579); } // 0x1579 (Size: 0x1, Type: BoolProperty)
    UTexture2D* ExternalMedia() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_Icon() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* TitleTextBlock() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* SubtitleTextBlock() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* EyebrowTextBlock() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultTitleTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ClassProperty)
    void SET_FeaturedTitleTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ClassProperty)
    void SET_Title(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x10, Type: TextProperty)
    void SET_Link(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x10, Type: StrProperty)
    void SET_bDownloadingExternalMedia(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x1, Type: BoolProperty)
    void SET_bRefreshingMcpCatalog(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1579, Value); } // 0x1579 (Size: 0x1, Type: BoolProperty)
    void SET_ExternalMedia(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_LazyImage_Icon(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_TitleTextBlock(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SubtitleTextBlock(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_EyebrowTextBlock(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x348
class UEpicCMSTileCarousel : public UUserWidget
{
public:
    FSlateSound PreviousButtonSound() const { return Read<FSlateSound>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    FSlateSound NextButtonSound() const { return Read<FSlateSound>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x18, Type: StructProperty)
    UCommonWidgetCarousel* Carousel() const { return Read<UCommonWidgetCarousel*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UWidget* NextPageButton() const { return Read<UWidget*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UWidget* PreviousPageButton() const { return Read<UWidget*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    bool bShouldShowNavigationOnlyOnHover() const { return Read<bool>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x1, Type: BoolProperty)
    bool bInputActionsForPaging() const { return Read<bool>(uintptr_t(this) + 0x341); } // 0x341 (Size: 0x1, Type: BoolProperty)
    bool bIsShowingNavigation() const { return Read<bool>(uintptr_t(this) + 0x342); } // 0x342 (Size: 0x1, Type: BoolProperty)

    void SET_PreviousButtonSound(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    void SET_NextButtonSound(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x18, Type: StructProperty)
    void SET_Carousel(const UCommonWidgetCarousel*& Value) { Write<UCommonWidgetCarousel*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_NextPageButton(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousPageButton(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldShowNavigationOnlyOnHover(const bool& Value) { Write<bool>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x1, Type: BoolProperty)
    void SET_bInputActionsForPaging(const bool& Value) { Write<bool>(uintptr_t(this) + 0x341, Value); } // 0x341 (Size: 0x1, Type: BoolProperty)
    void SET_bIsShowingNavigation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x342, Value); } // 0x342 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FEpicCMSTileTypeMapping : public FTableRowBase
{
public:
};

// Size: 0x10
struct FSlotDescription
{
public:
    FName SlotName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t ColumnCount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t RowCount() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    bool bUseFeaturedTextStyle() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    bool bEnableAutoScroll() const { return Read<bool>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: BoolProperty)

    void SET_SlotName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ColumnCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_RowCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_bUseFeaturedTextStyle(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_bEnableAutoScroll(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
struct FEpicCMSPage
{
public:
};

// Size: 0x28
struct FEpicCMSLayoutTypeMapping : public FTableRowBase
{
public:
};

// Size: 0x88
struct FTileDefinition
{
public:
    FString TypeString() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Title() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString Subtitle() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FString Eyebrow() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString Link() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    FString GroupId() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    FDateTime Countdown() const { return Read<FDateTime>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)
    uint8_t CountdownType() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)
    FString MediaUrl() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    bool IsVisible() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_TypeString(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Title(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Subtitle(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_Eyebrow(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_Link(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_GroupId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_Countdown(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
    void SET_CountdownType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
    void SET_MediaUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_IsVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

