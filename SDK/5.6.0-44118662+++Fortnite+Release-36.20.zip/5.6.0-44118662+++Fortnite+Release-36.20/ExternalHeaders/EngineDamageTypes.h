/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineDamageTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x40
class UDmgTypeBP_Environmental_C : public UDamageType
{
public:
};

