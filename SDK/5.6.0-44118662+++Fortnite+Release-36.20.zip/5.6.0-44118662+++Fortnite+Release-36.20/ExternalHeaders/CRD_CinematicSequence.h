/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_CinematicSequence
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "LevelSequence.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0xce0
class ACinematicSequenceDeviceBase : public ABuildingProp
{
public:
    FSoftClassPath AISpawnerDeviceClassPath() const { return Read<FSoftClassPath>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x18, Type: StructProperty)
    ULevelSequence* Sequence() const { return Read<ULevelSequence*>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    ALevelSequenceActor* LevelSequenceActor() const { return Read<ALevelSequenceActor*>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerController* InstigatingController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    char InstigatingTeam() const { return Read<char>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x1, Type: ByteProperty)
    bool bLoopPlayback() const { return (Read<uint8_t>(uintptr_t(this) + 0xc84) >> 0x0) & 1; } // 0xc84:0 (Size: 0x1, Type: BoolProperty)
    bool bAutoPlay() const { return (Read<uint8_t>(uintptr_t(this) + 0xc84) >> 0x1) & 1; } // 0xc84:1 (Size: 0x1, Type: BoolProperty)
    uint8_t EnabledOnPhase() const { return Read<uint8_t>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x1, Type: EnumProperty)
    uint8_t Visibility() const { return Read<uint8_t>(uintptr_t(this) + 0xc89); } // 0xc89 (Size: 0x1, Type: EnumProperty)
    bool bLevelSequenceActorAlwaysRelevant() const { return Read<bool>(uintptr_t(this) + 0xc8a); } // 0xc8a (Size: 0x1, Type: BoolProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0xc8c); } // 0xc8c (Size: 0x4, Type: FloatProperty)
    uint8_t FinishCompletionStateOverride() const { return Read<uint8_t>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x1, Type: EnumProperty)

    void SET_AISpawnerDeviceClassPath(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x18, Type: StructProperty)
    void SET_Sequence(const ULevelSequence*& Value) { Write<ULevelSequence*>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    void SET_LevelSequenceActor(const ALevelSequenceActor*& Value) { Write<ALevelSequenceActor*>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x8, Type: ObjectProperty)
    void SET_InstigatingController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    void SET_InstigatingTeam(const char& Value) { Write<char>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x1, Type: ByteProperty)
    void SET_bLoopPlayback(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc84); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc84, B); } // 0xc84:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoPlay(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc84); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xc84, B); } // 0xc84:1 (Size: 0x1, Type: BoolProperty)
    void SET_EnabledOnPhase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x1, Type: EnumProperty)
    void SET_Visibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc89, Value); } // 0xc89 (Size: 0x1, Type: EnumProperty)
    void SET_bLevelSequenceActorAlwaysRelevant(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8a, Value); } // 0xc8a (Size: 0x1, Type: BoolProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0xc8c, Value); } // 0xc8c (Size: 0x4, Type: FloatProperty)
    void SET_FinishCompletionStateOverride(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x1, Type: EnumProperty)
};

