/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimPresetsCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "IKRig.h"

// Size: 0x28
class UAnimPreset : public UObject
{
public:
};

// Size: 0x7a0
class UNPCRetargetAnimInstance : public UAnimInstance
{
public:
    FAnimNode_RetargetPoseFromMesh RetargetNode() const { return Read<FAnimNode_RetargetPoseFromMesh>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x3c8, Type: StructProperty)

    void SET_RetargetNode(const FAnimNode_RetargetPoseFromMesh& Value) { Write<FAnimNode_RetargetPoseFromMesh>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x3c8, Type: StructProperty)
};

// Size: 0x7a0
struct FNPCRetargetAnimInstanceProxy : public FAnimInstanceProxy
{
public:
};

