/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortProcGenRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x128
class UFortProcGenManager : public UFortProcGenRandomSubsystem
{
public:
    TSet<AFortProcGenActor*> ActiveGeneratingActors() const { return Read<TSet<AFortProcGenActor*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x50, Type: SetProperty)

    void SET_ActiveGeneratingActors(const TSet<AFortProcGenActor*>& Value) { Write<TSet<AFortProcGenActor*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x50, Type: SetProperty)
};

// Size: 0x98
class UFortProcGenRandomSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0x48
class UAsyncAction_FortProcGenRandomSubsystemReady : public UBlueprintAsyncActionBase
{
public:
};

// Size: 0x2b0
class AFortProcGenActor : public AActor
{
public:
};

// Size: 0x58
struct FFortInstanceRandomStream
{
public:
};

