/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkCosmeticsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0xe0
class UBeanCosmeticItemDefinitionBase : public UFortCosmeticItemAdditionalData
{
public:
    TSoftObjectPtr<UTexture2D> Body_Pattern() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    int32_t BodyFaceplateColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    int32_t BodyFaceplateMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    int32_t BodyEyesColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)
    int32_t BodyEyesMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: IntProperty)
    bool bEyelashes() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    int32_t EyelashesColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: IntProperty)
    int32_t EyelashesMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: IntProperty)
    bool bGlasses() const { return Read<bool>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x1, Type: BoolProperty)
    int32_t GlassesFrameColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: IntProperty)
    int32_t GlassesFrameMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    bool bGlassesLenses() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    int32_t GlassesLensesColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t GlassesLensesMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeMainColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeMainMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: IntProperty)
    bool bHeadCostumeMainClothingPattern() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    int32_t HeadCostumeSecondaryColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeSecondaryMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    bool bHeadCostumeSecondaryClothingPattern() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    int32_t HeadCostumeAccentColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeAccentMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: IntProperty)
    bool bHeadCostumeAccentClothingPattern() const { return Read<bool>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x1, Type: BoolProperty)
    int32_t BodyMainColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t BodyMainMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: IntProperty)
    int32_t BodySecondaryColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: IntProperty)
    int32_t BodySecondaryMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: IntProperty)
    int32_t CostumePatternAtlasTextureSlot() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumePatternAtlasTextureSlot() const { return Read<int32_t>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: IntProperty)
    int32_t CostumeMainColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t CostumeMainMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: IntProperty)
    bool bCostumeMainClothingPattern() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    int32_t CostumeSecondaryColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: IntProperty)
    int32_t CostumeSecondaryMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)
    bool bCostumeSecondaryClothingPattern() const { return Read<bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: BoolProperty)
    int32_t CostumeAccentColorIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)
    int32_t CostumeAccentMaterialTypeIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: IntProperty)
    bool bCostumeAccentClothingPattern() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)

    void SET_Body_Pattern(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    void SET_BodyFaceplateColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_BodyFaceplateMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET_BodyEyesColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
    void SET_BodyEyesMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: IntProperty)
    void SET_bEyelashes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_EyelashesColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: IntProperty)
    void SET_EyelashesMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: IntProperty)
    void SET_bGlasses(const bool& Value) { Write<bool>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x1, Type: BoolProperty)
    void SET_GlassesFrameColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: IntProperty)
    void SET_GlassesFrameMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_bGlassesLenses(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_GlassesLensesColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_GlassesLensesMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_HeadCostumeMainColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
    void SET_HeadCostumeMainMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: IntProperty)
    void SET_bHeadCostumeMainClothingPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_HeadCostumeSecondaryColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_HeadCostumeSecondaryMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_bHeadCostumeSecondaryClothingPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_HeadCostumeAccentColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
    void SET_HeadCostumeAccentMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: IntProperty)
    void SET_bHeadCostumeAccentClothingPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x1, Type: BoolProperty)
    void SET_BodyMainColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_BodyMainMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: IntProperty)
    void SET_BodySecondaryColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: IntProperty)
    void SET_BodySecondaryMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: IntProperty)
    void SET_CostumePatternAtlasTextureSlot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_HeadCostumePatternAtlasTextureSlot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: IntProperty)
    void SET_CostumeMainColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: IntProperty)
    void SET_CostumeMainMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: IntProperty)
    void SET_bCostumeMainClothingPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_CostumeSecondaryColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: IntProperty)
    void SET_CostumeSecondaryMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
    void SET_bCostumeSecondaryClothingPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: BoolProperty)
    void SET_CostumeAccentColorIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
    void SET_CostumeAccentMaterialTypeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: IntProperty)
    void SET_bCostumeAccentClothingPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
class UBeanCosmeticsData : public UPrimaryDataAsset
{
public:
    UFortHeroType* HeroType() const { return Read<UFortHeroType*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UDataTable* CharacterCosmeticsMap() const { return Read<UDataTable*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UDataTable* EmoteLookupMap() const { return Read<UDataTable*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftObjectPtr<UAthenaCharacterItemDefinition*>> DefaultCharacterCosmetics() const { return Read<TArray<TSoftObjectPtr<UAthenaCharacterItemDefinition*>>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    UFortItemDefinition* EmptyHandsPickaxeDef() const { return Read<UFortItemDefinition*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)

    void SET_HeroType(const UFortHeroType*& Value) { Write<UFortHeroType*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_CharacterCosmeticsMap(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_EmoteLookupMap(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultCharacterCosmetics(const TArray<TSoftObjectPtr<UAthenaCharacterItemDefinition*>>& Value) { Write<TArray<TSoftObjectPtr<UAthenaCharacterItemDefinition*>>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_EmptyHandsPickaxeDef(const UFortItemDefinition*& Value) { Write<UFortItemDefinition*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6e8
class ABeanFortPlayerMannequin : public AFortPlayerMannequin
{
public:
};

// Size: 0x398
class AFortAthenaMutator_BeanBRCosmeticsOverride : public AFortAthenaMutator_CosmeticLoadoutOverride
{
public:
    TSoftObjectPtr<UBeanCosmeticsData> CosmeticsData() const { return Read<TSoftObjectPtr<UBeanCosmeticsData>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x20, Type: SoftObjectProperty)
    UBeanCosmeticsData* CosmeticsDataCache() const { return Read<UBeanCosmeticsData*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)

    void SET_CosmeticsData(const TSoftObjectPtr<UBeanCosmeticsData>& Value) { Write<TSoftObjectPtr<UBeanCosmeticsData>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CosmeticsDataCache(const UBeanCosmeticsData*& Value) { Write<UBeanCosmeticsData*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UFortCosmeticStep_ApplyBeanCD : public UFortCosmeticStep
{
public:
    FGameplayTagQuery BeanPartQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x48, Type: StructProperty)

    void SET_BeanPartQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x48, Type: StructProperty)
};

// Size: 0x80
class UFortCosmeticStep_BeanRemoveBackpack : public UFortCosmeticStep
{
public:
};

// Size: 0x28
struct FBeanCosmeticDataTableRow : public FTableRowBase
{
public:
    TSoftObjectPtr<UAthenaCharacterItemDefinition> Definition() const { return Read<TSoftObjectPtr<UAthenaCharacterItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Definition(const TSoftObjectPtr<UAthenaCharacterItemDefinition>& Value) { Write<TSoftObjectPtr<UAthenaCharacterItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x28
struct FBeanEmoteConversionRow : public FTableRowBase
{
public:
    TSoftObjectPtr<UAthenaDanceItemDefinition> EmoteDefinition() const { return Read<TSoftObjectPtr<UAthenaDanceItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_EmoteDefinition(const TSoftObjectPtr<UAthenaDanceItemDefinition>& Value) { Write<TSoftObjectPtr<UAthenaDanceItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

