/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AdvancedWidgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x720
class URadialSlider : public UWidget
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    bool bUseCustomDefaultValue() const { return Read<bool>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: BoolProperty)
    float CustomDefaultValue() const { return Read<float>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SliderRange() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x88, Type: StructProperty)
    TArray<float> ValueTags() const { return Read<TArray<float>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    float SliderHandleStartAngle() const { return Read<float>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: FloatProperty)
    float SliderHandleEndAngle() const { return Read<float>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x4, Type: FloatProperty)
    float AngularOffset() const { return Read<float>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x4, Type: FloatProperty)
    FVector2D HandStartEndRatio() const { return Read<FVector2D>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x10, Type: StructProperty)
    FSliderStyle WidgetStyle() const { return Read<FSliderStyle>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x440, Type: StructProperty)
    FLinearColor SliderBarColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderProgressColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderHandleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: StructProperty)
    FLinearColor CenterBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x10, Type: StructProperty)
    bool Locked() const { return Read<bool>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x1, Type: BoolProperty)
    bool MouseUsesStep() const { return Read<bool>(uintptr_t(this) + 0x6b1); } // 0x6b1 (Size: 0x1, Type: BoolProperty)
    bool RequiresControllerLock() const { return Read<bool>(uintptr_t(this) + 0x6b2); } // 0x6b2 (Size: 0x1, Type: BoolProperty)
    float StepSize() const { return Read<float>(uintptr_t(this) + 0x6b4); } // 0x6b4 (Size: 0x4, Type: FloatProperty)
    bool IsFocusable() const { return Read<bool>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x1, Type: BoolProperty)
    bool UseVerticalDrag() const { return Read<bool>(uintptr_t(this) + 0x6b9); } // 0x6b9 (Size: 0x1, Type: BoolProperty)
    bool ShowSliderHandle() const { return Read<bool>(uintptr_t(this) + 0x6ba); } // 0x6ba (Size: 0x1, Type: BoolProperty)
    bool ShowSliderHand() const { return Read<bool>(uintptr_t(this) + 0x6bb); } // 0x6bb (Size: 0x1, Type: BoolProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_bUseCustomDefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: BoolProperty)
    void SET_CustomDefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x4, Type: FloatProperty)
    void SET_SliderRange(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x88, Type: StructProperty)
    void SET_ValueTags(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    void SET_SliderHandleStartAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: FloatProperty)
    void SET_SliderHandleEndAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x4, Type: FloatProperty)
    void SET_AngularOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x4, Type: FloatProperty)
    void SET_HandStartEndRatio(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x10, Type: StructProperty)
    void SET_WidgetStyle(const FSliderStyle& Value) { Write<FSliderStyle>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x440, Type: StructProperty)
    void SET_SliderBarColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x10, Type: StructProperty)
    void SET_SliderProgressColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x10, Type: StructProperty)
    void SET_SliderHandleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: StructProperty)
    void SET_CenterBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x10, Type: StructProperty)
    void SET_Locked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x1, Type: BoolProperty)
    void SET_MouseUsesStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b1, Value); } // 0x6b1 (Size: 0x1, Type: BoolProperty)
    void SET_RequiresControllerLock(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b2, Value); } // 0x6b2 (Size: 0x1, Type: BoolProperty)
    void SET_StepSize(const float& Value) { Write<float>(uintptr_t(this) + 0x6b4, Value); } // 0x6b4 (Size: 0x4, Type: FloatProperty)
    void SET_IsFocusable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x1, Type: BoolProperty)
    void SET_UseVerticalDrag(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b9, Value); } // 0x6b9 (Size: 0x1, Type: BoolProperty)
    void SET_ShowSliderHandle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6ba, Value); } // 0x6ba (Size: 0x1, Type: BoolProperty)
    void SET_ShowSliderHand(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6bb, Value); } // 0x6bb (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2e0
struct FColorGradingSpinBoxStyle : public FSlateWidgetStyle
{
public:
    FSlateBrush BorderBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xb0, Type: StructProperty)
    FSlateBrush ActiveBorderBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush HoveredBorderBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectorBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0xb0, Type: StructProperty)
    float SelectorWidth() const { return Read<float>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x4, Type: FloatProperty)

    void SET_BorderBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xb0, Type: StructProperty)
    void SET_ActiveBorderBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xb0, Type: StructProperty)
    void SET_HoveredBorderBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xb0, Type: StructProperty)
    void SET_SelectorBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0xb0, Type: StructProperty)
    void SET_SelectorWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x4, Type: FloatProperty)
};

