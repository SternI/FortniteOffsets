/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DLSSBlueprint
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UDLSSLibrary : public UBlueprintFunctionLibrary
{
public:
};

