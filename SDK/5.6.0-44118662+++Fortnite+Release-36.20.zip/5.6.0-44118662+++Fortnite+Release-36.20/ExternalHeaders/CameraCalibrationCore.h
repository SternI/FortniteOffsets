/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CameraCalibrationCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CinematicCamera.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x108
class UAnamorphicLensDistortionModelHandler : public ULensDistortionModelHandlerBase
{
public:
};

// Size: 0xd0
class ULensDistortionModelHandlerBase : public UObject
{
public:
    UClass* LensModelClass() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)
    UMaterialInstanceDynamic* DistortionPostProcessMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FLensDistortionState CurrentState() const { return Read<FLensDistortionState>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x30, Type: StructProperty)
    FCameraFilmbackSettings CameraFilmback() const { return Read<FCameraFilmbackSettings>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x14, Type: StructProperty)
    FString DisplayName() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)
    float OverscanFactor() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    UMaterialInstanceDynamic* UndistortionDisplacementMapMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DistortionDisplacementMapMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* UndistortionDisplacementMapRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DistortionDisplacementMapRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    FGuid DistortionProducerID() const { return Read<FGuid>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)

    void SET_LensModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
    void SET_DistortionPostProcessMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentState(const FLensDistortionState& Value) { Write<FLensDistortionState>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x30, Type: StructProperty)
    void SET_CameraFilmback(const FCameraFilmbackSettings& Value) { Write<FCameraFilmbackSettings>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x14, Type: StructProperty)
    void SET_DisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
    void SET_OverscanFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_UndistortionDisplacementMapMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_DistortionDisplacementMapMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    void SET_UndistortionDisplacementMapRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_DistortionDisplacementMapRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_DistortionProducerID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
class UAnamorphicLensModel : public ULensModel
{
public:
};

// Size: 0x28
class ULensModel : public UObject
{
public:
};

// Size: 0x640
class UCalibrationPointComponent : public UProceduralMeshComponent
{
public:
    TMap<FString, FVector> SubPoints() const { return Read<TMap<FString, FVector>>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x50, Type: MapProperty)
    bool bVisualizePointsInEditor() const { return Read<bool>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x1, Type: BoolProperty)
    float PointVisualizationScale() const { return Read<float>(uintptr_t(this) + 0x634); } // 0x634 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECalibrationPointVisualization> VisualizationShape() const { return Read<TEnumAsByte<ECalibrationPointVisualization>>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x1, Type: ByteProperty)

    void SET_SubPoints(const TMap<FString, FVector>& Value) { Write<TMap<FString, FVector>>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x50, Type: MapProperty)
    void SET_bVisualizePointsInEditor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x1, Type: BoolProperty)
    void SET_PointVisualizationScale(const float& Value) { Write<float>(uintptr_t(this) + 0x634, Value); } // 0x634 (Size: 0x4, Type: FloatProperty)
    void SET_VisualizationShape(const TEnumAsByte<ECalibrationPointVisualization>& Value) { Write<TEnumAsByte<ECalibrationPointVisualization>>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x300
class ACameraCalibrationCheckerboard : public AActor
{
public:
    USceneComponent* Root() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UCalibrationPointComponent* TopLeft() const { return Read<UCalibrationPointComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UCalibrationPointComponent* TopRight() const { return Read<UCalibrationPointComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UCalibrationPointComponent* BottomLeft() const { return Read<UCalibrationPointComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UCalibrationPointComponent* BottomRight() const { return Read<UCalibrationPointComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UCalibrationPointComponent* Center() const { return Read<UCalibrationPointComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    int32_t NumCornerRows() const { return Read<int32_t>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    int32_t NumCornerCols() const { return Read<int32_t>(uintptr_t(this) + 0x2dc); } // 0x2dc (Size: 0x4, Type: IntProperty)
    float SquareSideLength() const { return Read<float>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x2e4); } // 0x2e4 (Size: 0x4, Type: FloatProperty)
    UStaticMesh* CubeMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* OddCubeMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* EvenCubeMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)

    void SET_Root(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_TopLeft(const UCalibrationPointComponent*& Value) { Write<UCalibrationPointComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_TopRight(const UCalibrationPointComponent*& Value) { Write<UCalibrationPointComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_BottomLeft(const UCalibrationPointComponent*& Value) { Write<UCalibrationPointComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_BottomRight(const UCalibrationPointComponent*& Value) { Write<UCalibrationPointComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Center(const UCalibrationPointComponent*& Value) { Write<UCalibrationPointComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_NumCornerRows(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    void SET_NumCornerCols(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2dc, Value); } // 0x2dc (Size: 0x4, Type: IntProperty)
    void SET_SquareSideLength(const float& Value) { Write<float>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x2e4, Value); } // 0x2e4 (Size: 0x4, Type: FloatProperty)
    void SET_CubeMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_OddCubeMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_EvenCubeMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x160
class UCameraCalibrationSettings : public UDeveloperSettings
{
public:
    TSoftObjectPtr<ULensFile> StartupLensFile() const { return Read<TSoftObjectPtr<ULensFile>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    FIntPoint DisplacementMapResolution() const { return Read<FIntPoint>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: StructProperty)
    float CalibrationInputTolerance() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float CheckerboardDetectionTimeout() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>> DefaultUndistortionDisplacementMaterials() const { return Read<TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: MapProperty)
    TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>> DefaultDistortionDisplacementMaterials() const { return Read<TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x50, Type: MapProperty)
    TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>> DefaultDistortionMaterials() const { return Read<TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x50, Type: MapProperty)
    bool bEnableCalibrationDatasetImportExport() const { return Read<bool>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: BoolProperty)

    void SET_StartupLensFile(const TSoftObjectPtr<ULensFile>& Value) { Write<TSoftObjectPtr<ULensFile>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DisplacementMapResolution(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: StructProperty)
    void SET_CalibrationInputTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_CheckerboardDetectionTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_DefaultUndistortionDisplacementMaterials(const TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>& Value) { Write<TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: MapProperty)
    void SET_DefaultDistortionDisplacementMaterials(const TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>& Value) { Write<TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x50, Type: MapProperty)
    void SET_DefaultDistortionMaterials(const TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>& Value) { Write<TMap<UClass*, TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x50, Type: MapProperty)
    void SET_bEnableCalibrationDatasetImportExport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UCameraCalibrationEditorSettings : public UDeveloperSettings
{
public:
};

// Size: 0x28
class UCameraCalibrationStep : public UObject
{
public:
};

// Size: 0x230
class UCameraCalibrationSubsystem : public UEngineSubsystem
{
public:
    ULensFile* DefaultLensFile() const { return Read<ULensFile*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    TMap<FName, UClass*> LensModelMap() const { return Read<TMap<FName, UClass*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: MapProperty)
    TMap<FName, UClass*> CameraNodalOffsetAlgosMap() const { return Read<TMap<FName, UClass*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x50, Type: MapProperty)
    TMap<FName, UClass*> CameraImageCenterAlgosMap() const { return Read<TMap<FName, UClass*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x50, Type: MapProperty)
    TMap<FName, UClass*> CameraCalibrationStepsMap() const { return Read<TMap<FName, UClass*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x50, Type: MapProperty)

    void SET_DefaultLensFile(const ULensFile*& Value) { Write<ULensFile*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_LensModelMap(const TMap<FName, UClass*>& Value) { Write<TMap<FName, UClass*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: MapProperty)
    void SET_CameraNodalOffsetAlgosMap(const TMap<FName, UClass*>& Value) { Write<TMap<FName, UClass*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x50, Type: MapProperty)
    void SET_CameraImageCenterAlgosMap(const TMap<FName, UClass*>& Value) { Write<TMap<FName, UClass*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x50, Type: MapProperty)
    void SET_CameraCalibrationStepsMap(const TMap<FName, UClass*>& Value) { Write<TMap<FName, UClass*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x50, Type: MapProperty)
};

// Size: 0x30
class UCameraImageCenterAlgo : public UObject
{
public:
};

// Size: 0x28
class UCameraLensDistortionAlgo : public UObject
{
public:
};

// Size: 0x28
class UCameraNodalOffsetAlgo : public UObject
{
public:
};

// Size: 0x308
class ULensFile : public UObject
{
public:
    FLensInfo LensInfo() const { return Read<FLensInfo>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)
    uint8_t DataMode() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    TMap<FString, FString> UserMetadata() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)
    FEncodersTable EncodersTable() const { return Read<FEncodersTable>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x100, Type: StructProperty)
    FDistortionTable DistortionTable() const { return Read<FDistortionTable>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x30, Type: StructProperty)
    FFocalLengthTable FocalLengthTable() const { return Read<FFocalLengthTable>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x30, Type: StructProperty)
    FImageCenterTable ImageCenterTable() const { return Read<FImageCenterTable>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x30, Type: StructProperty)
    FNodalOffsetTable NodalOffsetTable() const { return Read<FNodalOffsetTable>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x30, Type: StructProperty)
    FSTMapTable STMapTable() const { return Read<FSTMapTable>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x30, Type: StructProperty)
    TArray<UTextureRenderTarget2D*> UndistortionDisplacementMapHolders() const { return Read<TArray<UTextureRenderTarget2D*>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    TArray<UTextureRenderTarget2D*> DistortionDisplacementMapHolders() const { return Read<TArray<UTextureRenderTarget2D*>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)

    void SET_LensInfo(const FLensInfo& Value) { Write<FLensInfo>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
    void SET_DataMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_UserMetadata(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
    void SET_EncodersTable(const FEncodersTable& Value) { Write<FEncodersTable>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x100, Type: StructProperty)
    void SET_DistortionTable(const FDistortionTable& Value) { Write<FDistortionTable>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x30, Type: StructProperty)
    void SET_FocalLengthTable(const FFocalLengthTable& Value) { Write<FFocalLengthTable>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x30, Type: StructProperty)
    void SET_ImageCenterTable(const FImageCenterTable& Value) { Write<FImageCenterTable>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x30, Type: StructProperty)
    void SET_NodalOffsetTable(const FNodalOffsetTable& Value) { Write<FNodalOffsetTable>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x30, Type: StructProperty)
    void SET_STMapTable(const FSTMapTable& Value) { Write<FSTMapTable>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x30, Type: StructProperty)
    void SET_UndistortionDisplacementMapHolders(const TArray<UTextureRenderTarget2D*>& Value) { Write<TArray<UTextureRenderTarget2D*>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    void SET_DistortionDisplacementMapHolders(const TArray<UTextureRenderTarget2D*>& Value) { Write<TArray<UTextureRenderTarget2D*>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe8
class USphericalLensDistortionModelHandler : public ULensDistortionModelHandlerBase
{
public:
};

// Size: 0x28
class USphericalLensModel : public ULensModel
{
public:
};

// Size: 0x38
struct FAnamorphicDistortionParameters
{
public:
    float PixelAspect() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float CX02() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float CX04() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float CX22() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float CX24() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float CX44() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float CY02() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float CY04() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float CY22() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float CY24() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float CY44() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float SqueezeX() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float SqueezeY() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float LensRotation() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_PixelAspect(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_CX02(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_CX04(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_CX22(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_CX24(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_CX44(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CY02(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_CY04(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_CY22(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CY24(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_CY44(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_SqueezeX(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_SqueezeY(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_LensRotation(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FBaseFocusPoint
{
public:
};

// Size: 0x1
struct FBaseFocusCurve
{
public:
};

// Size: 0x10
struct FBaseLensTable
{
public:
    TWeakObjectPtr<ULensFile*> LensFile() const { return Read<TWeakObjectPtr<ULensFile*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_LensFile(const TWeakObjectPtr<ULensFile*>& Value) { Write<TWeakObjectPtr<ULensFile*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3
struct FCalibratedMapFormat
{
public:
    uint8_t PixelOrigin() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t UndistortionChannels() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t DistortionChannels() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)

    void SET_PixelOrigin(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_UndistortionChannels(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_DistortionChannels(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1c
struct FLensDataCategoryEditorColor
{
public:
    FColor Focus() const { return Read<FColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FColor Iris() const { return Read<FColor>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FColor Zoom() const { return Read<FColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FColor Distortion() const { return Read<FColor>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    FColor ImageCenter() const { return Read<FColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    FColor STMap() const { return Read<FColor>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: StructProperty)
    FColor NodalOffset() const { return Read<FColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)

    void SET_Focus(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Iris(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_Zoom(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_Distortion(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_ImageCenter(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_STMap(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: StructProperty)
    void SET_NodalOffset(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
};

// Size: 0xc0
struct FDistortionCalibrationResult
{
public:
    float EvaluatedFocus() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float EvaluatedZoom() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    double ReprojectionError() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    FFocalLengthInfo FocalLength() const { return Read<FFocalLengthInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FImageCenterInfo ImageCenter() const { return Read<FImageCenterInfo>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    TArray<FTransform> CameraPoses() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    FNodalPointOffset NodalOffset() const { return Read<FNodalPointOffset>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x40, Type: StructProperty)
    FDistortionInfo Parameters() const { return Read<FDistortionInfo>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    FSTMapInfo STMap() const { return Read<FSTMapInfo>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StructProperty)
    FString STMapFullPath() const { return Read<FString>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StrProperty)
    FText ErrorMessage() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)

    void SET_EvaluatedFocus(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EvaluatedZoom(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ReprojectionError(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_FocalLength(const FFocalLengthInfo& Value) { Write<FFocalLengthInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ImageCenter(const FImageCenterInfo& Value) { Write<FImageCenterInfo>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_CameraPoses(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_NodalOffset(const FNodalPointOffset& Value) { Write<FNodalPointOffset>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x40, Type: StructProperty)
    void SET_Parameters(const FDistortionInfo& Value) { Write<FDistortionInfo>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_STMap(const FSTMapInfo& Value) { Write<FSTMapInfo>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StructProperty)
    void SET_STMapFullPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StrProperty)
    void SET_ErrorMessage(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
};

// Size: 0x10
struct FSTMapInfo
{
public:
    UTexture* DistortionMap() const { return Read<UTexture*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCalibratedMapFormat MapFormat() const { return Read<FCalibratedMapFormat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x3, Type: StructProperty)

    void SET_DistortionMap(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MapFormat(const FCalibratedMapFormat& Value) { Write<FCalibratedMapFormat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x3, Type: StructProperty)
};

// Size: 0x10
struct FDistortionInfo
{
public:
    TArray<float> Parameters() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FNodalPointOffset
{
public:
    FVector LocationOffset() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FQuat RotationOffset() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_LocationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_RotationOffset(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x10
struct FImageCenterInfo
{
public:
    FVector2D PrincipalPoint() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_PrincipalPoint(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FFocalLengthInfo
{
public:
    FVector2D FxFy() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_FxFy(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FDistortionHandlerPicker
{
public:
    UCineCameraComponent* TargetCameraComponent() const { return Read<UCineCameraComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGuid DistortionProducerID() const { return Read<FGuid>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FString HandlerDisplayName() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_TargetCameraComponent(const UCineCameraComponent*& Value) { Write<UCineCameraComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_DistortionProducerID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_HandlerDisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FDistortionZoomPoint
{
public:
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FDistortionInfo DistortionInfo() const { return Read<FDistortionInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_DistortionInfo(const FDistortionInfo& Value) { Write<FDistortionInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0xa0
struct FDistortionFocusPoint : public FBaseFocusPoint
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FRichCurve MapBlendingCurve() const { return Read<FRichCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x80, Type: StructProperty)
    TArray<FDistortionZoomPoint> ZoomPoints() const { return Read<TArray<FDistortionZoomPoint>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MapBlendingCurve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x80, Type: StructProperty)
    void SET_ZoomPoints(const TArray<FDistortionZoomPoint>& Value) { Write<TArray<FDistortionZoomPoint>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FDistortionFocusCurve : public FBaseFocusCurve
{
public:
    FRichCurve MapBlendingCurve() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)

    void SET_MapBlendingCurve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDistortionTable : public FBaseLensTable
{
public:
    TArray<FDistortionFocusPoint> FocusPoints() const { return Read<TArray<FDistortionFocusPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FDistortionFocusCurve> FocusCurves() const { return Read<TArray<FDistortionFocusCurve>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_FocusPoints(const TArray<FDistortionFocusPoint>& Value) { Write<TArray<FDistortionFocusPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusCurves(const TArray<FDistortionFocusCurve>& Value) { Write<TArray<FDistortionFocusCurve>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x100
struct FEncodersTable
{
public:
    FRichCurve Focus() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    FRichCurve Iris() const { return Read<FRichCurve>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x80, Type: StructProperty)

    void SET_Focus(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_Iris(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x80, Type: StructProperty)
};

// Size: 0x20
struct FFocalLengthZoomPoint
{
public:
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FFocalLengthInfo FocalLengthInfo() const { return Read<FFocalLengthInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    bool bIsCalibrationPoint() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_FocalLengthInfo(const FFocalLengthInfo& Value) { Write<FFocalLengthInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_bIsCalibrationPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FFocalLengthFocusPoint : public FBaseFocusPoint
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FRichCurve Fx() const { return Read<FRichCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x80, Type: StructProperty)
    FRichCurve Fy() const { return Read<FRichCurve>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x80, Type: StructProperty)
    TArray<FFocalLengthZoomPoint> ZoomPoints() const { return Read<TArray<FFocalLengthZoomPoint>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Fx(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x80, Type: StructProperty)
    void SET_Fy(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x80, Type: StructProperty)
    void SET_ZoomPoints(const TArray<FFocalLengthZoomPoint>& Value) { Write<TArray<FFocalLengthZoomPoint>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x108
struct FFocalLengthFocusCurve : public FBaseFocusCurve
{
public:
    FRichCurve Fx() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    FRichCurve Fy() const { return Read<FRichCurve>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x80, Type: StructProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)

    void SET_Fx(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_Fy(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x80, Type: StructProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FFocalLengthTable : public FBaseLensTable
{
public:
    TArray<FFocalLengthFocusPoint> FocusPoints() const { return Read<TArray<FFocalLengthFocusPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FFocalLengthFocusCurve> FocusCurves() const { return Read<TArray<FFocalLengthFocusCurve>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_FocusPoints(const TArray<FFocalLengthFocusPoint>& Value) { Write<TArray<FFocalLengthFocusPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusCurves(const TArray<FFocalLengthFocusCurve>& Value) { Write<TArray<FFocalLengthFocusCurve>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x110
struct FImageCenterFocusPoint : public FBaseFocusPoint
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FRichCurve Cx() const { return Read<FRichCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x80, Type: StructProperty)
    FRichCurve Cy() const { return Read<FRichCurve>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x80, Type: StructProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Cx(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x80, Type: StructProperty)
    void SET_Cy(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x80, Type: StructProperty)
};

// Size: 0x108
struct FImageCenterFocusCurve : public FBaseFocusCurve
{
public:
    FRichCurve Cx() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    FRichCurve Cy() const { return Read<FRichCurve>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x80, Type: StructProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)

    void SET_Cx(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_Cy(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x80, Type: StructProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FImageCenterTable : public FBaseLensTable
{
public:
    TArray<FImageCenterFocusPoint> FocusPoints() const { return Read<TArray<FImageCenterFocusPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FImageCenterFocusCurve> FocusCurves() const { return Read<TArray<FImageCenterFocusCurve>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_FocusPoints(const TArray<FImageCenterFocusPoint>& Value) { Write<TArray<FImageCenterFocusPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusCurves(const TArray<FImageCenterFocusCurve>& Value) { Write<TArray<FImageCenterFocusCurve>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x48
struct FLensInfo
{
public:
    FString LensModelName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString LensSerialNumber() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    UClass* LensModel() const { return Read<UClass*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ClassProperty)
    FVector2D SensorDimensions() const { return Read<FVector2D>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FIntPoint ImageDimensions() const { return Read<FIntPoint>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: StructProperty)
    float SqueezeFactor() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_LensModelName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_LensSerialNumber(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_LensModel(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ClassProperty)
    void SET_SensorDimensions(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_ImageDimensions(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: StructProperty)
    void SET_SqueezeFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FCameraFeedInfo
{
public:
    FIntPoint Dimensions() const { return Read<FIntPoint>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float AspectRatio() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Dimensions(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_AspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FSimulcamInfo
{
public:
    FIntPoint MediaResolution() const { return Read<FIntPoint>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float MediaPlateAspectRatio() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float CGLayerAspectRatio() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_MediaResolution(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_MediaPlateAspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_CGLayerAspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDistortionData
{
public:
    TArray<FVector2D> DistortedUVs() const { return Read<TArray<FVector2D>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    float OverscanFactor() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_DistortedUVs(const TArray<FVector2D>& Value) { Write<TArray<FVector2D>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_OverscanFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDataTablePointInfoBase
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDistortionPointInfo : public FDataTablePointInfoBase
{
public:
    FDistortionInfo DistortionInfo() const { return Read<FDistortionInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_DistortionInfo(const FDistortionInfo& Value) { Write<FDistortionInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FFocalLengthPointInfo : public FDataTablePointInfoBase
{
public:
    FFocalLengthInfo FocalLengthInfo() const { return Read<FFocalLengthInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_FocalLengthInfo(const FFocalLengthInfo& Value) { Write<FFocalLengthInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FSTMapPointInfo : public FDataTablePointInfoBase
{
public:
    FSTMapInfo STMapInfo() const { return Read<FSTMapInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_STMapInfo(const FSTMapInfo& Value) { Write<FSTMapInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FImageCenterPointInfo : public FDataTablePointInfoBase
{
public:
    FImageCenterInfo ImageCenterInfo() const { return Read<FImageCenterInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_ImageCenterInfo(const FImageCenterInfo& Value) { Write<FImageCenterInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FNodalOffsetPointInfo : public FDataTablePointInfoBase
{
public:
    FNodalPointOffset NodalPointOffset() const { return Read<FNodalPointOffset>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x40, Type: StructProperty)

    void SET_NodalPointOffset(const FNodalPointOffset& Value) { Write<FNodalPointOffset>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x40, Type: StructProperty)
};

// Size: 0x30
struct FLensDistortionState
{
public:
    FDistortionInfo DistortionInfo() const { return Read<FDistortionInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FFocalLengthInfo FocalLengthInfo() const { return Read<FFocalLengthInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FImageCenterInfo ImageCenter() const { return Read<FImageCenterInfo>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_DistortionInfo(const FDistortionInfo& Value) { Write<FDistortionInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_FocalLengthInfo(const FFocalLengthInfo& Value) { Write<FFocalLengthInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ImageCenter(const FImageCenterInfo& Value) { Write<FImageCenterInfo>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FLensFilePicker
{
public:
    bool bUseDefaultLensFile() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    ULensFile* LensFile() const { return Read<ULensFile*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_bUseDefaultLensFile(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_LensFile(const ULensFile*& Value) { Write<ULensFile*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x24
struct FLensFileEvaluationInputs
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Iris() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FCameraFilmbackSettings Filmback() const { return Read<FCameraFilmbackSettings>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x14, Type: StructProperty)
    bool bIsValid() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Iris(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Filmback(const FCameraFilmbackSettings& Value) { Write<FCameraFilmbackSettings>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x14, Type: StructProperty)
    void SET_bIsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x310
struct FNodalOffsetFocusPoint : public FBaseFocusPoint
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FRichCurve LocationOffset() const { return Read<FRichCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x180, Type: StructProperty)
    FRichCurve RotationOffset() const { return Read<FRichCurve>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x180, Type: StructProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_LocationOffset(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x180, Type: StructProperty)
    void SET_RotationOffset(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x180, Type: StructProperty)
};

// Size: 0x308
struct FNodalOffsetFocusCurve : public FBaseFocusCurve
{
public:
    FRichCurve LocationOffset() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x180, Type: StructProperty)
    FRichCurve RotationOffset() const { return Read<FRichCurve>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x180, Type: StructProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: FloatProperty)

    void SET_LocationOffset(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x180, Type: StructProperty)
    void SET_RotationOffset(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x180, Type: StructProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FNodalOffsetTable : public FBaseLensTable
{
public:
    TArray<FNodalOffsetFocusPoint> FocusPoints() const { return Read<TArray<FNodalOffsetFocusPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FNodalOffsetFocusCurve> FocusCurves() const { return Read<TArray<FNodalOffsetFocusCurve>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_FocusPoints(const TArray<FNodalOffsetFocusPoint>& Value) { Write<TArray<FNodalOffsetFocusPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusCurves(const TArray<FNodalOffsetFocusCurve>& Value) { Write<TArray<FNodalOffsetFocusCurve>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x14
struct FSphericalDistortionParameters
{
public:
    float K1() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float K2() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float K3() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float P1() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float P2() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_K1(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_K2(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_K3(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_P1(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_P2(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDerivedDistortionData
{
public:
    FDistortionData DistortionData() const { return Read<FDistortionData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    UTextureRenderTarget2D* UndistortionDisplacementMap() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DistortionDisplacementMap() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_DistortionData(const FDistortionData& Value) { Write<FDistortionData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_UndistortionDisplacementMap(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_DistortionDisplacementMap(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
struct FSTMapZoomPoint
{
public:
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FSTMapInfo STMapInfo() const { return Read<FSTMapInfo>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FDerivedDistortionData DerivedDistortionData() const { return Read<FDerivedDistortionData>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)
    bool bIsCalibrationPoint() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_STMapInfo(const FSTMapInfo& Value) { Write<FSTMapInfo>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_DerivedDistortionData(const FDerivedDistortionData& Value) { Write<FDerivedDistortionData>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
    void SET_bIsCalibrationPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
struct FSTMapFocusPoint : public FBaseFocusPoint
{
public:
    float Focus() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FRichCurve MapBlendingCurve() const { return Read<FRichCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x80, Type: StructProperty)
    TArray<FSTMapZoomPoint> ZoomPoints() const { return Read<TArray<FSTMapZoomPoint>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_Focus(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MapBlendingCurve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x80, Type: StructProperty)
    void SET_ZoomPoints(const TArray<FSTMapZoomPoint>& Value) { Write<TArray<FSTMapZoomPoint>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FSTMapFocusCurve : public FBaseFocusCurve
{
public:
    FRichCurve MapBlendingCurve() const { return Read<FRichCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    float Zoom() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)

    void SET_MapBlendingCurve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_Zoom(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FSTMapTable : public FBaseLensTable
{
public:
    TArray<FSTMapFocusPoint> FocusPoints() const { return Read<TArray<FSTMapFocusPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FSTMapFocusCurve> FocusCurves() const { return Read<TArray<FSTMapFocusCurve>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_FocusPoints(const TArray<FSTMapFocusPoint>& Value) { Write<TArray<FSTMapFocusPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusCurves(const TArray<FSTMapFocusCurve>& Value) { Write<TArray<FSTMapFocusCurve>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

