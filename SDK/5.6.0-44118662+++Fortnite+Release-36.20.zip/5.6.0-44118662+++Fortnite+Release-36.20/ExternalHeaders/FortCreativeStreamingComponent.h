/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortCreativeStreamingComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "SubtitlesWidgets.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "MetasoundEngine.h"
#include "MediaAssets.h"
#include "HarmonixMidi.h"
#include "HarmonixMetasound.h"

// Size: 0x160
class UFortCreativeStreamingMusicalReactivityComponent : public UActorComponent
{
public:
    FComponentReference AudioComponentRef() const { return Read<FComponentReference>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    FComponentReference MusicClockComponentRef() const { return Read<FComponentReference>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x28, Type: StructProperty)
    UMetaSoundSource* MetaSoundSource() const { return Read<UMetaSoundSource*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    FName MetaSoundParamNameMediaPlayer() const { return Read<FName>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: NameProperty)
    FName MetaSoundParamNameMidiFile() const { return Read<FName>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: NameProperty)
    UMidiFile* TempoMapMidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag MusicEventSubsystemEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer MusicEventSubsystemBehaviorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<UAudioComponent*> AudioComponent() const { return Read<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClockComponent() const { return Read<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortCreativeStreamingComponent*> StreamingComponent() const { return Read<TWeakObjectPtr<UFortCreativeStreamingComponent*>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: WeakObjectProperty)

    void SET_AudioComponentRef(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_MusicClockComponentRef(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x28, Type: StructProperty)
    void SET_MetaSoundSource(const UMetaSoundSource*& Value) { Write<UMetaSoundSource*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_MetaSoundParamNameMediaPlayer(const FName& Value) { Write<FName>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: NameProperty)
    void SET_MetaSoundParamNameMidiFile(const FName& Value) { Write<FName>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: NameProperty)
    void SET_TempoMapMidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicEventSubsystemEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: StructProperty)
    void SET_MusicEventSubsystemBehaviorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x20, Type: StructProperty)
    void SET_AudioComponent(const TWeakObjectPtr<UAudioComponent*>& Value) { Write<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MusicClockComponent(const TWeakObjectPtr<UMusicClockComponent*>& Value) { Write<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: WeakObjectProperty)
    void SET_StreamingComponent(const TWeakObjectPtr<UFortCreativeStreamingComponent*>& Value) { Write<TWeakObjectPtr<UFortCreativeStreamingComponent*>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x308
class UFortCreativeStreamingComponent : public UActorComponent
{
public:
    USoundSubmix* DefaultSubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* LicensedSubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* AudioAnalysisSubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UMaterialParameterCollection* JukeboxMPC() const { return Read<UMaterialParameterCollection*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    FVideoPlayerDeviceAudioAnalysisSettings AudioAnalysisSettings() const { return Read<FVideoPlayerDeviceAudioAnalysisSettings>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x40, Type: StructProperty)
    USoundConcurrency* SoundConcurrency() const { return Read<USoundConcurrency*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    USoundConcurrency* MirrorSoundConcurrency() const { return Read<USoundConcurrency*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    USoundClass* AudioSoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    UMaterial* VideoMaterial() const { return Read<UMaterial*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    int32_t MaterialSlot() const { return Read<int32_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: IntProperty)
    UFortDownloadLocalizedOverlays* LocalizedOverlays() const { return Read<UFortDownloadLocalizedOverlays*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    UFortMediaSubtitlesPlayer* SubtitlesPlayer() const { return Read<UFortMediaSubtitlesPlayer*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    UFortBaseStreamingVideo* BaseStreamingVideoPlayer() const { return Read<UFortBaseStreamingVideo*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    FVideoPlayerDeviceComponents DeviceComponents() const { return Read<FVideoPlayerDeviceComponents>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x30, Type: StructProperty)
    FVideoPlayerDeviceMediaMetadata CurrentlyPlayingData() const { return Read<FVideoPlayerDeviceMediaMetadata>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x48, Type: StructProperty)
    TSoftObjectPtr<AActor> MirroredDevice() const { return Read<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x20, Type: SoftObjectProperty)
    UAudioComponent* MirrorAudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* MirrorSoundAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    uint8_t StreamingMode() const { return Read<uint8_t>(uintptr_t(this) + 0x289); } // 0x289 (Size: 0x1, Type: EnumProperty)
    FVideoPlayerDeviceCMSEventData CMSEventData() const { return Read<FVideoPlayerDeviceCMSEventData>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x38, Type: StructProperty)

    void SET_DefaultSubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_LicensedSubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioAnalysisSubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_JukeboxMPC(const UMaterialParameterCollection*& Value) { Write<UMaterialParameterCollection*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioAnalysisSettings(const FVideoPlayerDeviceAudioAnalysisSettings& Value) { Write<FVideoPlayerDeviceAudioAnalysisSettings>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x40, Type: StructProperty)
    void SET_SoundConcurrency(const USoundConcurrency*& Value) { Write<USoundConcurrency*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_MirrorSoundConcurrency(const USoundConcurrency*& Value) { Write<USoundConcurrency*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioSoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_VideoMaterial(const UMaterial*& Value) { Write<UMaterial*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    void SET_MaterialSlot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: IntProperty)
    void SET_LocalizedOverlays(const UFortDownloadLocalizedOverlays*& Value) { Write<UFortDownloadLocalizedOverlays*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_SubtitlesPlayer(const UFortMediaSubtitlesPlayer*& Value) { Write<UFortMediaSubtitlesPlayer*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    void SET_BaseStreamingVideoPlayer(const UFortBaseStreamingVideo*& Value) { Write<UFortBaseStreamingVideo*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_DeviceComponents(const FVideoPlayerDeviceComponents& Value) { Write<FVideoPlayerDeviceComponents>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x30, Type: StructProperty)
    void SET_CurrentlyPlayingData(const FVideoPlayerDeviceMediaMetadata& Value) { Write<FVideoPlayerDeviceMediaMetadata>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x48, Type: StructProperty)
    void SET_MirroredDevice(const TSoftObjectPtr<AActor>& Value) { Write<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MirrorAudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x8, Type: ObjectProperty)
    void SET_MirrorSoundAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_StreamingMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x289, Value); } // 0x289 (Size: 0x1, Type: EnumProperty)
    void SET_CMSEventData(const FVideoPlayerDeviceCMSEventData& Value) { Write<FVideoPlayerDeviceCMSEventData>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x38, Type: StructProperty)
};

// Size: 0x30
struct FVideoPlayerDeviceComponents
{
public:
    UStaticMeshComponent* ScreenMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ScreenMaterialDynamic() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* SoundComponent() const { return Read<UMediaSoundComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* VideoTexture() const { return Read<UMediaTexture*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    USoundSourceBus* SourceBus() const { return Read<USoundSourceBus*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_ScreenMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ScreenMaterialDynamic(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundComponent(const UMediaSoundComponent*& Value) { Write<UMediaSoundComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_VideoTexture(const UMediaTexture*& Value) { Write<UMediaTexture*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_SourceBus(const USoundSourceBus*& Value) { Write<USoundSourceBus*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FVideoPlayerDeviceFullscreenData
{
public:
    bool bEnable() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    int32_t InstanceID() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_bEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_InstanceID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc
struct FVideoPlayerDevicePIPSettings
{
public:
    float TriggerRange() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bAlwaysAllow() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    int32_t InstanceID() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_TriggerRange(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bAlwaysAllow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_InstanceID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FVideoPlayerDevicePIPFullscreenSettings
{
public:
    AController* Instigator() const { return Read<AController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bEnableFullscreen() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    int32_t InstanceID() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_Instigator(const AController*& Value) { Write<AController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableFullscreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_InstanceID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FVideoPlayerDeviceCMSEventData
{
public:
    FString EventName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString EventPage() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString VUID() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_EventName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_EventPage(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_VUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FVideoPlayerDeviceAudioAnalysisSettings
{
public:
    TArray<FSoundSubmixSpectralAnalysisBandSettings> AudioAnalysisBandSettings() const { return Read<TArray<FSoundSubmixSpectralAnalysisBandSettings>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> AudioAnalysisBandNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName PercussionParameterName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    FName AverageAmplitudeParameterName() const { return Read<FName>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: NameProperty)
    float UpdateRate() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float DecibelNoiseFloor() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bDoNormalize() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bDoAutoRange() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    float AutoRangeAttackTime() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float AutoRangeReleaseTime() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_AudioAnalysisBandSettings(const TArray<FSoundSubmixSpectralAnalysisBandSettings>& Value) { Write<TArray<FSoundSubmixSpectralAnalysisBandSettings>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_AudioAnalysisBandNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_PercussionParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_AverageAmplitudeParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: NameProperty)
    void SET_UpdateRate(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_DecibelNoiseFloor(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bDoNormalize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bDoAutoRange(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_AutoRangeAttackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_AutoRangeReleaseTime(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

