/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicStreamMediaSource
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "EpicMediaCDNHostnames.h"
#include "EpicMediaLocalizedOverlays.h"
#include "EpicMediaMetadataResolver.h"
#include "MediaAssets.h"

// Size: 0x870
class UEpicStreamMediaSource : public UStreamMediaSource
{
public:
    FString VideoStreamSource() const { return Read<FString>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StrProperty)
    float VideoStreamSourceAB() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    TMap<FString, FString> VideoId() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x50, Type: MapProperty)
    bool bIsLive() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)
    bool bBlurlLive() const { return Read<bool>(uintptr_t(this) + 0x101); } // 0x101 (Size: 0x1, Type: BoolProperty)
    int32_t MaxResolution() const { return Read<int32_t>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: IntProperty)
    int32_t MaxBandwidth() const { return Read<int32_t>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: IntProperty)
    float AspectRatio() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    bool bSharelock() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)
    bool bAudioOnly() const { return Read<bool>(uintptr_t(this) + 0x111); } // 0x111 (Size: 0x1, Type: BoolProperty)
    bool bPartySync() const { return Read<bool>(uintptr_t(this) + 0x112); } // 0x112 (Size: 0x1, Type: BoolProperty)
    float MediaDuration() const { return Read<float>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: FloatProperty)
    FString mimetype() const { return Read<FString>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: StrProperty)
    FString StreamDenyHTTPCode() const { return Read<FString>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: StrProperty)
    UEpicMediaCDNHostnames* CDNHostNames() const { return Read<UEpicMediaCDNHostnames*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    bool bEnableCDNFailureRetries() const { return Read<bool>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: BoolProperty)
    bool bEnableBLURLRetries() const { return Read<bool>(uintptr_t(this) + 0x141); } // 0x141 (Size: 0x1, Type: BoolProperty)
    int32_t MaxBLURLRetryAttempts() const { return Read<int32_t>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: IntProperty)
    bool bEnableScrubOptimization() const { return Read<bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: BoolProperty)
    int32_t SeekBitrate() const { return Read<int32_t>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: IntProperty)
    int32_t CacheSizeKiB() const { return Read<int32_t>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: IntProperty)
    int32_t TimeToCacheMilliseconds() const { return Read<int32_t>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: IntProperty)
    UEpicMediaDownloadLocalizedOverlays* EpicMediaDownloadLocalizedOverlays() const { return Read<UEpicMediaDownloadLocalizedOverlays*>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    FString ProtectUserFromAVSettings() const { return Read<FString>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x10, Type: StrProperty)
    FString StreamID() const { return Read<FString>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x10, Type: StrProperty)
    FString StreamID_Development() const { return Read<FString>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x10, Type: StrProperty)
    UMediaSource* LocalFilePlaybackAsset() const { return Read<UMediaSource*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    double HighestFramerate() const { return Read<double>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: DoubleProperty)
    TMap<FString, int32_t> RetryAttempts() const { return Read<TMap<FString, int32_t>>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x50, Type: MapProperty)
    TArray<int32_t> RetryErrorCodes() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> SwitchCDNErrorCodes() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> RetryDelayMS() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x10, Type: ArrayProperty)
    UEpicMediaMetadataResolver* MetadataResolver() const { return Read<UEpicMediaMetadataResolver*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)

    void SET_VideoStreamSource(const FString& Value) { Write<FString>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StrProperty)
    void SET_VideoStreamSourceAB(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_VideoId(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x50, Type: MapProperty)
    void SET_bIsLive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
    void SET_bBlurlLive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x101, Value); } // 0x101 (Size: 0x1, Type: BoolProperty)
    void SET_MaxResolution(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: IntProperty)
    void SET_MaxBandwidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: IntProperty)
    void SET_AspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_bSharelock(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
    void SET_bAudioOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x111, Value); } // 0x111 (Size: 0x1, Type: BoolProperty)
    void SET_bPartySync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x112, Value); } // 0x112 (Size: 0x1, Type: BoolProperty)
    void SET_MediaDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: FloatProperty)
    void SET_mimetype(const FString& Value) { Write<FString>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: StrProperty)
    void SET_StreamDenyHTTPCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: StrProperty)
    void SET_CDNHostNames(const UEpicMediaCDNHostnames*& Value) { Write<UEpicMediaCDNHostnames*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableCDNFailureRetries(const bool& Value) { Write<bool>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableBLURLRetries(const bool& Value) { Write<bool>(uintptr_t(this) + 0x141, Value); } // 0x141 (Size: 0x1, Type: BoolProperty)
    void SET_MaxBLURLRetryAttempts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: IntProperty)
    void SET_bEnableScrubOptimization(const bool& Value) { Write<bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: BoolProperty)
    void SET_SeekBitrate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: IntProperty)
    void SET_CacheSizeKiB(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: IntProperty)
    void SET_TimeToCacheMilliseconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: IntProperty)
    void SET_EpicMediaDownloadLocalizedOverlays(const UEpicMediaDownloadLocalizedOverlays*& Value) { Write<UEpicMediaDownloadLocalizedOverlays*>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    void SET_ProtectUserFromAVSettings(const FString& Value) { Write<FString>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x10, Type: StrProperty)
    void SET_StreamID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x10, Type: StrProperty)
    void SET_StreamID_Development(const FString& Value) { Write<FString>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x10, Type: StrProperty)
    void SET_LocalFilePlaybackAsset(const UMediaSource*& Value) { Write<UMediaSource*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    void SET_HighestFramerate(const double& Value) { Write<double>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: DoubleProperty)
    void SET_RetryAttempts(const TMap<FString, int32_t>& Value) { Write<TMap<FString, int32_t>>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x50, Type: MapProperty)
    void SET_RetryErrorCodes(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x10, Type: ArrayProperty)
    void SET_SwitchCDNErrorCodes(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x10, Type: ArrayProperty)
    void SET_RetryDelayMS(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x10, Type: ArrayProperty)
    void SET_MetadataResolver(const UEpicMediaMetadataResolver*& Value) { Write<UEpicMediaMetadataResolver*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FRetryRequestResponse
{
public:
    float RetryDelay() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    int32_t ErrorCode() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t RetryAttempt() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    bool ShouldRetry() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    bool SwitchCDN() const { return Read<bool>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: BoolProperty)

    void SET_RetryDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ErrorCode(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_RetryAttempt(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_ShouldRetry(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_SwitchCDN(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: BoolProperty)
};

