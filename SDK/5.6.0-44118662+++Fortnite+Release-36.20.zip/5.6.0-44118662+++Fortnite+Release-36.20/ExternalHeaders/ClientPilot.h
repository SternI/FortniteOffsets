/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClientPilot
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x78
class UClientPilotBlackboard : public UObject
{
public:
};

// Size: 0x30
class UClientPilotBlackboardManager : public UObject
{
public:
    UClientPilotBlackboard* PilotBlackboard() const { return Read<UClientPilotBlackboard*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_PilotBlackboard(const UClientPilotBlackboard*& Value) { Write<UClientPilotBlackboard*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UClientPilotComponent : public UObject
{
public:
};

