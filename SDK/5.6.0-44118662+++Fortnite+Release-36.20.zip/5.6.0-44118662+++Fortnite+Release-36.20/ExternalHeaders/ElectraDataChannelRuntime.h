/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ElectraDataChannelRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x2d8
class AElectraDataChannelPlayer : public AActor
{
public:
};

// Size: 0x2e0
class AElectraDataChannelRecorder : public AActor
{
public:
};

// Size: 0x320
class AElectraDataChannelTarget : public AActor
{
public:
};

