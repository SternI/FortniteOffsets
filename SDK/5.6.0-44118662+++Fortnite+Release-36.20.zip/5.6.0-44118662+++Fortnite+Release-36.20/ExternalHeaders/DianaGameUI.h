/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaGameUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x90
class UDianaSessionTimerViewModel : public UFortPerUserViewModel
{
public:
    int32_t PlayerCount() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    float MaxSessionTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t MaxPlayersInGame() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)

    void SET_PlayerCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_MaxSessionTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_MaxPlayersInGame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1
struct FDianaFinalSurvivorEvent
{
public:
};

// Size: 0x1
struct FDianaFinalSurvivorCompleteEvent
{
public:
};

