/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiamondCurrencyUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "UMG.h"
#include "FortniteGame.h"
#include "GameplayTags.h"

// Size: 0x3b8
class UFortDiamondHUDWidget : public UFortHUDElementWidget
{
public:
    UPanelWidget* Panel_BoundVisibility() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UFortResourceItemDefinition* ResourceItemDefinition() const { return Read<UFortResourceItemDefinition*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer DiamondSpendablesActorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x20, Type: StructProperty)
    float OverlapDiamondSpendableSphereRadius() const { return Read<float>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x4, Type: FloatProperty)

    void SET_Panel_BoundVisibility(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_ResourceItemDefinition(const UFortResourceItemDefinition*& Value) { Write<UFortResourceItemDefinition*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_DiamondSpendablesActorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x20, Type: StructProperty)
    void SET_OverlapDiamondSpendableSphereRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x4, Type: FloatProperty)
};

