/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CraftingUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CommonUILegacy.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "GameplayTags.h"
#include "UMG.h"

// Size: 0x158
class UFortCraftingListItem : public UObject
{
public:
};

// Size: 0x1520
class UAthenaCraftingQuickBarButton : public UAthenaQuickBarSlotButtonBase
{
public:
};

// Size: 0x340
class UAthenaEquippedItemCraftingIndicator : public UCommonUserWidget
{
public:
};

// Size: 0x340
class UAthenaInventoryItemInfoCraftingIndicator : public UCommonUserWidget
{
public:
};

// Size: 0x358
class UAthenaQuickBarSlotCraftingIndicator : public UAthenaQuickBarSlotExtensionWidgetBase
{
public:
    bool bCheckForIngredientChangesWhenCraftable() const { return Read<bool>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: BoolProperty)

    void SET_bCheckForIngredientChangesWhenCraftable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4a0
class UFortCookingScreen : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle CloseInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x10, Type: StructProperty)
    UCommonButtonLegacy* Button_EjectAll() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonLegacy* Button_Cancel() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RecipeName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RecipeDescription() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Recipe() const { return Read<UImage*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UFortSlottedRadialMenu* RadialMenu_Recipes() const { return Read<UFortSlottedRadialMenu*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)

    void SET_CloseInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x10, Type: StructProperty)
    void SET_Button_EjectAll(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Cancel(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_RecipeName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_RecipeDescription(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Recipe(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_RadialMenu_Recipes(const UFortSlottedRadialMenu*& Value) { Write<UFortSlottedRadialMenu*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x328
class UFortCraftingFormulaIngredientsWidget : public UCommonUserWidget
{
public:
    UDynamicEntryBox* EntryBox_Ingredients() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)

    void SET_EntryBox_Ingredients(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x348
class UFortCraftingIngredientWidget : public UCommonUserWidget
{
public:
    UCommonTextBlock* Text_NumAvailable() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_NumRequired() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UAthenaItemIcon* ItemIcon() const { return Read<UAthenaItemIcon*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_Icon() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_NumAvailable(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_NumRequired(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemIcon(const UAthenaItemIcon*& Value) { Write<UAthenaItemIcon*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_LazyImage_Icon(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4b0
class UFortCraftingItemInfoWidget : public UCommonActivatableWidget
{
public:
    FText RarityTextFormat() const { return Read<FText>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x10, Type: TextProperty)
    UCommonTextBlock* Text_ItemName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemRarity() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemCategory() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UFortItemCategoryIndicator* ItemCategoryIndicator() const { return Read<UFortItemCategoryIndicator*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemDescription() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UAthenaInventoryItemStatsWidget* ItemStatsWidget() const { return Read<UAthenaInventoryItemStatsWidget*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UFortCraftingFormulaIngredientsWidget* IngredientsWidget() const { return Read<UFortCraftingFormulaIngredientsWidget*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonLegacy* Button_StartCrafting() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)

    void SET_RarityTextFormat(const FText& Value) { Write<FText>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x10, Type: TextProperty)
    void SET_Text_ItemName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ItemRarity(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ItemCategory(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemCategoryIndicator(const UFortItemCategoryIndicator*& Value) { Write<UFortItemCategoryIndicator*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ItemDescription(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemStatsWidget(const UAthenaInventoryItemStatsWidget*& Value) { Write<UAthenaInventoryItemStatsWidget*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_IngredientsWidget(const UFortCraftingFormulaIngredientsWidget*& Value) { Write<UFortCraftingFormulaIngredientsWidget*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_StartCrafting(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1560
class UFortCraftingListEntry : public UCommonButtonLegacy
{
public:
    UAthenaItemIcon* ItemIcon() const { return Read<UAthenaItemIcon*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    bool bCanCraftItem() const { return Read<bool>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x1, Type: BoolProperty)

    void SET_ItemIcon(const UAthenaItemIcon*& Value) { Write<UAthenaItemIcon*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_bCanCraftItem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x590
class UFortCraftingTab : public UCommonActivatableWidget
{
public:
    FName TabNameID() const { return Read<FName>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x4, Type: NameProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo() const { return Read<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0xf0, Type: StructProperty)
    FGameplayTagContainer PrimaryIngredientTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x20, Type: StructProperty)
    UFortCraftingItemInfoWidget* CraftingItemInfo() const { return Read<UFortCraftingItemInfoWidget*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    UCommonListView* ListView_Recipes() const { return Read<UCommonListView*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    UAthenaQuickbarEditorBase* QuickbarEditor() const { return Read<UAthenaQuickbarEditorBase*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    UAthenaInventoryItemInfo* ItemInfoWidget() const { return Read<UAthenaInventoryItemInfo*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)

    void SET_TabNameID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x4, Type: NameProperty)
    void SET_TabButtonLabelInfo(const FFortTabButtonLabelInfo& Value) { Write<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0xf0, Type: StructProperty)
    void SET_PrimaryIngredientTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x20, Type: StructProperty)
    void SET_CraftingItemInfo(const UFortCraftingItemInfoWidget*& Value) { Write<UFortCraftingItemInfoWidget*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_ListView_Recipes(const UCommonListView*& Value) { Write<UCommonListView*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_QuickbarEditor(const UAthenaQuickbarEditorBase*& Value) { Write<UAthenaQuickbarEditorBase*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemInfoWidget(const UAthenaInventoryItemInfo*& Value) { Write<UAthenaInventoryItemInfo*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x320
class UFortPotContentsPopup : public UUserWidget
{
public:
    int32_t MaxItemsToShow() const { return Read<int32_t>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x4, Type: IntProperty)
    UCommonTileView* TileView_PotContents() const { return Read<UCommonTileView*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_MoreItems() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_Popup() const { return Read<UWidget*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)

    void SET_MaxItemsToShow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x4, Type: IntProperty)
    void SET_TileView_PotContents(const UCommonTileView*& Value) { Write<UCommonTileView*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_MoreItems(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Popup(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1550
class UFortPotContentsTile : public UCommonButtonLegacy
{
public:
    UCommonLazyImage* Image_Item() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)

    void SET_Image_Item(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
class UFortUIGameFeatureAction_SetCraftMenuWidget : public UFortUIGameFeatureAction
{
public:
    UClass* CraftingObject() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)

    void SET_CraftingObject(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
};

