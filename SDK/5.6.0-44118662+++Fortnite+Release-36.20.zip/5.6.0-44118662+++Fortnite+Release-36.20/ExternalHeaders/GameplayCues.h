/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayCues
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "Effects.h"
#include "Gameplay.h"
#include "FortniteGame.h"

// Size: 0x9e0
class AGCNL_CubeSurfing_Boosting_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UFXSystemComponent* CachedNiagara() const { return Read<UFXSystemComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    UClass* Camera_Modifier_Class() const { return Read<UClass*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ClassProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_CachedNiagara(const UFXSystemComponent*& Value) { Write<UFXSystemComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Camera_Modifier_Class(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa48
class AGCNL_CubeSurfing_Surfing_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float Timeline_0_Strength_26C30DFA43BDF23157808EA7146F062C() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_26C30DFA43BDF23157808EA7146F062C() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    float Timeline_Strength_56F87FEC433E85562402C69D285D6AE6() const { return Read<float>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline__Direction_56F87FEC433E85562402C69D285D6AE6() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9e4); } // 0x9e4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    AFortPawn* PlayerPawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    UFXSystemComponent* CachedNiagara() const { return Read<UFXSystemComponent*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagAdded* WaitTagAddAsync() const { return Read<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    TArray<FLinearColor> ColorArray() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x10, Type: ArrayProperty)
    AFN_RadialForce_C* RadialForceActor() const { return Read<AFN_RadialForce_C*>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* CachedWeapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x8, Type: ObjectProperty)
    AB_CubeSurfing_Weapon_C* As_B_Cube_Surfing_Weapon() const { return Read<AB_CubeSurfing_Weapon_C*>(uintptr_t(this) + 0xa28); } // 0xa28 (Size: 0x8, Type: ObjectProperty)
    AFN_WashForce_C* Physical_Wash_Force() const { return Read<AFN_WashForce_C*>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x8, Type: ObjectProperty)
    double Strength() const { return Read<double>(uintptr_t(this) + 0xa38); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    UFXSystemComponent* CachedNiagaraWater() const { return Read<UFXSystemComponent*>(uintptr_t(this) + 0xa40); } // 0xa40 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_0_Strength_26C30DFA43BDF23157808EA7146F062C(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_26C30DFA43BDF23157808EA7146F062C(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_Strength_56F87FEC433E85562402C69D285D6AE6(const float& Value) { Write<float>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline__Direction_56F87FEC433E85562402C69D285D6AE6(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9e4, Value); } // 0x9e4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerPawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedNiagara(const UFXSystemComponent*& Value) { Write<UFXSystemComponent*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    void SET_WaitTagAddAsync(const UAbilityAsync_WaitGameplayTagAdded*& Value) { Write<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    void SET_ColorArray(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x10, Type: ArrayProperty)
    void SET_RadialForceActor(const AFN_RadialForce_C*& Value) { Write<AFN_RadialForce_C*>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedWeapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x8, Type: ObjectProperty)
    void SET_As_B_Cube_Surfing_Weapon(const AB_CubeSurfing_Weapon_C*& Value) { Write<AB_CubeSurfing_Weapon_C*>(uintptr_t(this) + 0xa28, Value); } // 0xa28 (Size: 0x8, Type: ObjectProperty)
    void SET_Physical_Wash_Force(const AFN_WashForce_C*& Value) { Write<AFN_WashForce_C*>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x8, Type: ObjectProperty)
    void SET_Strength(const double& Value) { Write<double>(uintptr_t(this) + 0xa38, Value); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    void SET_CachedNiagaraWater(const UFXSystemComponent*& Value) { Write<UFXSystemComponent*>(uintptr_t(this) + 0xa40, Value); } // 0xa40 (Size: 0x8, Type: ObjectProperty)
};

