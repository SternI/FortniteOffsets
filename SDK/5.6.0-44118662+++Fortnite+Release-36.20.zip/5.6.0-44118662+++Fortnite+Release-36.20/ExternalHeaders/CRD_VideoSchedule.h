/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_VideoSchedule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "LevelSequence.h"
#include "CoreUObject.h"

// Size: 0xd08
class AVideoScheduleDeviceBase : public ABuildingProp
{
public:
    uint8_t RepeatSchedule() const { return Read<uint8_t>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x1, Type: EnumProperty)
    TArray<FVideoScheduleDeviceEntryAbsolute> AbsoluteSchedule() const { return Read<TArray<FVideoScheduleDeviceEntryAbsolute>>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x10, Type: ArrayProperty)
    TArray<FVideoScheduleDeviceEntryDaily> DailySchedule() const { return Read<TArray<FVideoScheduleDeviceEntryDaily>>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x10, Type: ArrayProperty)
    TArray<FVideoScheduleDeviceEntryHourly> HourlySchedule() const { return Read<TArray<FVideoScheduleDeviceEntryHourly>>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x10, Type: ArrayProperty)
    bool bFillSchedule() const { return Read<bool>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x1, Type: BoolProperty)
    int32_t FillScheduleGap() const { return Read<int32_t>(uintptr_t(this) + 0xc84); } // 0xc84 (Size: 0x4, Type: IntProperty)
    int32_t FillScheduleAlign() const { return Read<int32_t>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x4, Type: IntProperty)
    FString SimpleSchedule() const { return Read<FString>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x10, Type: StrProperty)

    void SET_RepeatSchedule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x1, Type: EnumProperty)
    void SET_AbsoluteSchedule(const TArray<FVideoScheduleDeviceEntryAbsolute>& Value) { Write<TArray<FVideoScheduleDeviceEntryAbsolute>>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x10, Type: ArrayProperty)
    void SET_DailySchedule(const TArray<FVideoScheduleDeviceEntryDaily>& Value) { Write<TArray<FVideoScheduleDeviceEntryDaily>>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x10, Type: ArrayProperty)
    void SET_HourlySchedule(const TArray<FVideoScheduleDeviceEntryHourly>& Value) { Write<TArray<FVideoScheduleDeviceEntryHourly>>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x10, Type: ArrayProperty)
    void SET_bFillSchedule(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x1, Type: BoolProperty)
    void SET_FillScheduleGap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc84, Value); } // 0xc84 (Size: 0x4, Type: IntProperty)
    void SET_FillScheduleAlign(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x4, Type: IntProperty)
    void SET_SimpleSchedule(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
struct FVideoScheduleDeviceEntryHourly
{
public:
    int32_t Minutes() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Seconds() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FString VUID() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    ULevelSequence* Sequence() const { return Read<ULevelSequence*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_Minutes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Seconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_VUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_DurationSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Sequence(const ULevelSequence*& Value) { Write<ULevelSequence*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FVideoScheduleDeviceEntryDaily
{
public:
    int32_t Hours() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Seconds() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FString VUID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    ULevelSequence* Sequence() const { return Read<ULevelSequence*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Hours(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Minutes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Seconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_VUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_DurationSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_Sequence(const ULevelSequence*& Value) { Write<ULevelSequence*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FVideoScheduleDeviceEntryAbsolute
{
public:
    FString IsoStartTime() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString VUID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    ULevelSequence* Sequence() const { return Read<ULevelSequence*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_IsoStartTime(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_VUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_DurationSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_Sequence(const ULevelSequence*& Value) { Write<ULevelSequence*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FVideoScheduleDeviceScheduleInfo
{
public:
    FDateTime StartTime() const { return Read<FDateTime>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FTimespan RelativeStartTime() const { return Read<FTimespan>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FString VUID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    ULevelSequence* Sequence() const { return Read<ULevelSequence*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_StartTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_RelativeStartTime(const FTimespan& Value) { Write<FTimespan>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_VUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Sequence(const ULevelSequence*& Value) { Write<ULevelSequence*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

