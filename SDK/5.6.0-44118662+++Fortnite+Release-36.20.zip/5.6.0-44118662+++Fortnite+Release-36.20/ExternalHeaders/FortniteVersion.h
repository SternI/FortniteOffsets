/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteVersion
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x4
struct FFortReleaseVersion
{
public:
    FName VersionName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_VersionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

