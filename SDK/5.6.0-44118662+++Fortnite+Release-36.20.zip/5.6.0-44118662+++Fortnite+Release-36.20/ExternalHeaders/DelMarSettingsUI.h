/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x30
class UFortGameSettingRegistryExtension_DelMar : public UFortGameSettingRegistryExtension
{
public:
};

