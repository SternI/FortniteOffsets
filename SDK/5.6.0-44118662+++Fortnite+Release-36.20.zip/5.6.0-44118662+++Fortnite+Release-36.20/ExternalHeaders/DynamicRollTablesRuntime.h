/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicRollTablesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DataRegistry.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0x1b8
class UFortControllerComponent_DynamicRollPlayerComponent : public UFortControllerComponent
{
public:
    UClass* AssociatedManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat Enabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    UFortGamestateComponent_DynamicRollTableManager* TableManager() const { return Read<UFortGamestateComponent_DynamicRollTableManager*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    FRandomStream SeededRNG() const { return Read<FRandomStream>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x8, Type: StructProperty)

    void SET_AssociatedManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_Enabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_TableManager(const UFortGamestateComponent_DynamicRollTableManager*& Value) { Write<UFortGamestateComponent_DynamicRollTableManager*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_SeededRNG(const FRandomStream& Value) { Write<FRandomStream>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x8, Type: StructProperty)
};

// Size: 0x2f0
class UFortGamestateComponent_DynamicRollTableManager : public UFortGameStateComponent
{
public:
    FDataRegistryType DataRegistryType_BaseWeights() const { return Read<FDataRegistryType>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: StructProperty)
    FDataRegistryType DataRegistryType_WeightModifiers() const { return Read<FDataRegistryType>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: StructProperty)
    FScalableFloat Enabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)

    void SET_DataRegistryType_BaseWeights(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: StructProperty)
    void SET_DataRegistryType_WeightModifiers(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: StructProperty)
    void SET_Enabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x8
struct FFortDynamicRollResult
{
public:
    UFortItemDefinition* Item() const { return Read<UFortItemDefinition*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Item(const UFortItemDefinition*& Value) { Write<UFortItemDefinition*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FFortDynamicRollBaseWeightTableRow : public FTableRowBase
{
public:
    UFortItemDefinition* ItemDefinition() const { return Read<UFortItemDefinition*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float BaseWeight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    TArray<FGameplayTag> ModTags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bOwningItemZerosWeight() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    float MaxModifiedWeight() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float MinModifiedWeight() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_ItemDefinition(const UFortItemDefinition*& Value) { Write<UFortItemDefinition*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_BaseWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_ModTags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_bOwningItemZerosWeight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_MaxModifiedWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_MinModifiedWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FFortDynamicRollWeightModifierTableRow : public FTableRowBase
{
public:
    FGameplayTag ActivatingPlayerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag TargetModTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    uint8_t WeightModifierOperation() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    float WeightModificationValue() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_ActivatingPlayerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_TargetModTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_WeightModifierOperation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_WeightModificationValue(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FDynamicRollModifiersActivatedByPlayerTagContainer
{
public:
};

