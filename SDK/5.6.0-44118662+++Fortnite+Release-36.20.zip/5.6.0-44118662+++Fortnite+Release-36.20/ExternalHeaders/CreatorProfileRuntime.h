/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorProfileRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"

// Size: 0x28
class UCreatorProfileBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x150
class UFortPlayspaceComponent_CreatorProfile : public UFortPlayspaceComponent
{
public:
    TWeakObjectPtr<AFortPlayerController*> CachedPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FString> UpdatedCreatorSocialInfoStrings() const { return Read<TArray<FString>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    bool HasCreatorSocialInfoFetched() const { return Read<bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: BoolProperty)

    void SET_CachedPlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UpdatedCreatorSocialInfoStrings(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    void SET_HasCreatorSocialInfoFetched(const bool& Value) { Write<bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: BoolProperty)
};

