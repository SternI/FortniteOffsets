/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosCaching
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "MovieScene.h"

// Size: 0x40
class UMovieSceneSpawnableChaosCacheBinding : public UMovieSceneSpawnableActorBinding
{
public:
};

// Size: 0x40
class UChaosCacheCollection : public UObject
{
public:
    TArray<UChaosCache*> Caches() const { return Read<TArray<UChaosCache*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t InterpolationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)

    void SET_Caches(const TArray<UChaosCache*>& Value) { Write<TArray<UChaosCache*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_InterpolationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x360
class AChaosCacheManager : public AActor
{
public:
    UChaosCacheCollection* CacheCollection() const { return Read<UChaosCacheCollection*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t CacheMode() const { return Read<uint8_t>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: EnumProperty)
    uint8_t StartMode() const { return Read<uint8_t>(uintptr_t(this) + 0x2b1); } // 0x2b1 (Size: 0x1, Type: EnumProperty)
    float StartTime() const { return Read<float>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    TArray<FObservedComponent> ObservedComponents() const { return Read<TArray<FObservedComponent>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)

    void SET_CacheCollection(const UChaosCacheCollection*& Value) { Write<UChaosCacheCollection*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: EnumProperty)
    void SET_StartMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b1, Value); } // 0x2b1 (Size: 0x1, Type: EnumProperty)
    void SET_StartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    void SET_ObservedComponents(const TArray<FObservedComponent>& Value) { Write<TArray<FObservedComponent>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x360
class AChaosCachePlayer : public AChaosCacheManager
{
public:
};

// Size: 0x28
class UChaosCacheData : public UInterface
{
public:
};

// Size: 0x390
class UChaosCache : public UObject
{
public:
    float RecordedDuration() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint32_t NumRecordedFrames() const { return Read<uint32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: UInt32Property)
    uint8_t InterpolationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    TArray<int32_t> TrackToParticle() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FPerParticleCacheData> ParticleTracks() const { return Read<TArray<FPerParticleCacheData>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ChannelCurveToParticle() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FRichCurves> ChannelsTracks() const { return Read<TMap<FName, FRichCurves>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x50, Type: MapProperty)
    TMap<FName, FCompressedRichCurves> CompressedChannelsTracks() const { return Read<TMap<FName, FCompressedRichCurves>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    TMap<FName, FRichCurve> CurveData() const { return Read<TMap<FName, FRichCurve>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x50, Type: MapProperty)
    TMap<FName, FParticleTransformTrack> NamedTransformTracks() const { return Read<TMap<FName, FParticleTransformTrack>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x50, Type: MapProperty)
    bool bCompressChannels() const { return Read<bool>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x1, Type: BoolProperty)
    float ChannelsCompressionErrorThreshold() const { return Read<float>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    float ChannelsCompressionSampleRate() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    TScriptInterface<Class> CacheData() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: InterfaceProperty)
    TMap<FName, FCacheEventTrack> EventTracks() const { return Read<TMap<FName, FCacheEventTrack>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x50, Type: MapProperty)
    FCacheSpawnableTemplate Spawnable() const { return Read<FCacheSpawnableTemplate>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0xd0, Type: StructProperty)
    FGuid AdapterGuid() const { return Read<FGuid>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: StructProperty)
    int32_t Version() const { return Read<int32_t>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: IntProperty)

    void SET_RecordedDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_NumRecordedFrames(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: UInt32Property)
    void SET_InterpolationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_TrackToParticle(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_ParticleTracks(const TArray<FPerParticleCacheData>& Value) { Write<TArray<FPerParticleCacheData>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_ChannelCurveToParticle(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_ChannelsTracks(const TMap<FName, FRichCurves>& Value) { Write<TMap<FName, FRichCurves>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x50, Type: MapProperty)
    void SET_CompressedChannelsTracks(const TMap<FName, FCompressedRichCurves>& Value) { Write<TMap<FName, FCompressedRichCurves>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_CurveData(const TMap<FName, FRichCurve>& Value) { Write<TMap<FName, FRichCurve>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x50, Type: MapProperty)
    void SET_NamedTransformTracks(const TMap<FName, FParticleTransformTrack>& Value) { Write<TMap<FName, FParticleTransformTrack>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x50, Type: MapProperty)
    void SET_bCompressChannels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x1, Type: BoolProperty)
    void SET_ChannelsCompressionErrorThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    void SET_ChannelsCompressionSampleRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    void SET_CacheData(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: InterfaceProperty)
    void SET_EventTracks(const TMap<FName, FCacheEventTrack>& Value) { Write<TMap<FName, FCacheEventTrack>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x50, Type: MapProperty)
    void SET_Spawnable(const FCacheSpawnableTemplate& Value) { Write<FCacheSpawnableTemplate>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0xd0, Type: StructProperty)
    void SET_AdapterGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: StructProperty)
    void SET_Version(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: IntProperty)
};

// Size: 0x138
class UMovieSceneChaosCacheSection : public UMovieSceneBaseCacheSection
{
public:
    FMovieSceneChaosCacheParams Params() const { return Read<FMovieSceneChaosCacheParams>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)

    void SET_Params(const FMovieSceneChaosCacheParams& Value) { Write<FMovieSceneChaosCacheParams>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
};

// Size: 0x128
class UMovieSceneChaosCacheTrack : public UMovieSceneNameableTrack
{
public:
    TArray<UMovieSceneSection*> AnimationSections() const { return Read<TArray<UMovieSceneSection*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)

    void SET_AnimationSections(const TArray<UMovieSceneSection*>& Value) { Write<TArray<UMovieSceneSection*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FCacheEventBase
{
public:
};

// Size: 0x10
struct FEnableStateEvent : public FCacheEventBase
{
public:
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    bool bEnable() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_bEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
struct FBreakingEvent : public FCacheEventBase
{
public:
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FQuat orientation() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    FVector BoundingBoxMin() const { return Read<FVector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FVector BoundingBoxMax() const { return Read<FVector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)

    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_orientation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_BoundingBoxMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_BoundingBoxMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xf0
struct FCollisionEvent : public FCacheEventBase
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector AccumulatedImpulse() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector Velocity1() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector Velocity2() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FVector DeltaVelocity1() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    FVector DeltaVelocity2() const { return Read<FVector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity1() const { return Read<FVector>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity2() const { return Read<FVector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x18, Type: StructProperty)
    float Mass1() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    float Mass2() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float PenetrationDepth() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_AccumulatedImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_Velocity1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_Velocity2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_DeltaVelocity1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_DeltaVelocity2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x18, Type: StructProperty)
    void SET_Mass1(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_Mass2(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_PenetrationDepth(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
struct FTrailingEvent : public FCacheEventBase
{
public:
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FQuat orientation() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FVector BoundingBoxMin() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    FVector BoundingBoxMax() const { return Read<FVector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)

    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_orientation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_BoundingBoxMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_BoundingBoxMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FCacheEventTrack
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UScriptStruct* Struct() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<float> TimeStamps() const { return Read<TArray<float>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Struct(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_TimeStamps(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x180
struct FObservedComponent
{
public:
    FName CacheName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FComponentReference ComponentRef() const { return Read<FComponentReference>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    FSoftComponentReference SoftComponentRef() const { return Read<FSoftComponentReference>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x40, Type: StructProperty)
    bool bIsSimulating() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bPlaybackEnabled() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)
    FDirectoryPath USDCacheDirectory() const { return Read<FDirectoryPath>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)

    void SET_CacheName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ComponentRef(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_SoftComponentRef(const FSoftComponentReference& Value) { Write<FSoftComponentReference>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x40, Type: StructProperty)
    void SET_bIsSimulating(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bPlaybackEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
    void SET_USDCacheDirectory(const FDirectoryPath& Value) { Write<FDirectoryPath>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
struct FParticleTransformTrack
{
public:
    FRawAnimSequenceTrack RawTransformTrack() const { return Read<FRawAnimSequenceTrack>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    float BeginOffset() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    bool bDeactivateOnEnd() const { return Read<bool>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: BoolProperty)
    TArray<float> KeyTimestamps() const { return Read<TArray<float>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_RawTransformTrack(const FRawAnimSequenceTrack& Value) { Write<FRawAnimSequenceTrack>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_BeginOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_bDeactivateOnEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: BoolProperty)
    void SET_KeyTimestamps(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
struct FPerParticleCacheData
{
public:
    FParticleTransformTrack TransformData() const { return Read<FParticleTransformTrack>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    TMap<FName, FRichCurve> CurveData() const { return Read<TMap<FName, FRichCurve>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: MapProperty)

    void SET_TransformData(const FParticleTransformTrack& Value) { Write<FParticleTransformTrack>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_CurveData(const TMap<FName, FRichCurve>& Value) { Write<TMap<FName, FRichCurve>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: MapProperty)
};

// Size: 0xd0
struct FCacheSpawnableTemplate
{
public:
    UObject* DuplicatedTemplate() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FTransform InitialTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform ComponentTransform() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)

    void SET_DuplicatedTemplate(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_InitialTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_ComponentTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
};

// Size: 0x10
struct FRichCurves
{
public:
    TArray<FRichCurve> RichCurves() const { return Read<TArray<FRichCurve>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_RichCurves(const TArray<FRichCurve>& Value) { Write<TArray<FRichCurve>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCompressedRichCurves
{
public:
    TArray<FCompressedRichCurve> CompressedRichCurves() const { return Read<TArray<FCompressedRichCurve>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_CompressedRichCurves(const TArray<FCompressedRichCurve>& Value) { Write<TArray<FCompressedRichCurve>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FMovieSceneChaosCacheParams : public FMovieSceneBaseCacheParams
{
public:
    UChaosCacheCollection* CacheCollection() const { return Read<UChaosCacheCollection*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_CacheCollection(const UChaosCacheCollection*& Value) { Write<UChaosCacheCollection*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FMovieSceneChaosCacheSectionTemplateParameters : public FMovieSceneBaseCacheSectionTemplateParameters
{
public:
    FMovieSceneChaosCacheParams ChaosCacheParams() const { return Read<FMovieSceneChaosCacheParams>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)

    void SET_ChaosCacheParams(const FMovieSceneChaosCacheParams& Value) { Write<FMovieSceneChaosCacheParams>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x50
struct FMovieSceneChaosCacheSectionTemplate : public FMovieSceneEvalTemplate
{
public:
    FMovieSceneChaosCacheSectionTemplateParameters Params() const { return Read<FMovieSceneChaosCacheSectionTemplateParameters>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)

    void SET_Params(const FMovieSceneChaosCacheSectionTemplateParameters& Value) { Write<FMovieSceneChaosCacheSectionTemplateParameters>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
};

