/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoachMarks
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "Blueprints.h"
#include "SlateCore.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "UIKit.h"

// Size: 0x688
class UWBP_ChangeFlag_CoachMark_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    USizeBox* WidgetSize() const { return Read<USizeBox*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate() const { return Read<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* TopGrid() const { return Read<UGridPanel*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Header() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Description() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background() const { return Read<UImage*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Arrow() const { return Read<UImage*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* Description() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Content() const { return Read<UGridPanel*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* Buttons() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Outro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<E_UI_OutBoardPosition> ArrowPosition() const { return Read<TEnumAsByte<E_UI_OutBoardPosition>>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x1, Type: ByteProperty)
    double OutsideOffset() const { return Read<double>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: DoubleProperty)
    FSlateBrush Brush_Icon() const { return Read<FSlateBrush>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0xb0, Type: StructProperty)
    float Angle_Icon() const { return Read<float>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<E_UI_DirectionLeftRightNone> IconPosition() const { return Read<TEnumAsByte<E_UI_DirectionLeftRightNone>>(uintptr_t(this) + 0x444); } // 0x444 (Size: 0x1, Type: ByteProperty)
    FText TextHeader() const { return Read<FText>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> JustificationHeader() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x1, Type: ByteProperty)
    FText TextDescription() const { return Read<FText>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x10, Type: TextProperty)
    FSlateColor DefaultDescriptoinColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x14, Type: StructProperty)
    TEnumAsByte<ETextJustify> JustificationDescription() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x484); } // 0x484 (Size: 0x1, Type: ByteProperty)
    FText TextDismissButton() const { return Read<FText>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x10, Type: TextProperty)
    bool IsShowDismissButton() const { return Read<bool>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x1, Type: BoolProperty)
    FText TextOtherActionButton() const { return Read<FText>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x10, Type: TextProperty)
    bool IsShowOtherActionButton() const { return Read<bool>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x1, Type: BoolProperty)
    FSlateBrush BackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0xb0, Type: StructProperty)
    float Widget_Width() const { return Read<float>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x4, Type: FloatProperty)
    double SafeZone() const { return Read<double>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    TArray<UClass*> In_Decorator_Classes() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x10, Type: ArrayProperty)
    FDataTableRowHandle Input_Action_Other() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle Input_Action_Dismiss() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x10, Type: StructProperty)
    UMaterialInstanceDynamic* BackgroundDynamicMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* DismissButton() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* OtherActionButton() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UClass* HoldDataOther() const { return Read<UClass*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ClassProperty)
    bool RequiresHoldOther() const { return Read<bool>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x1, Type: BoolProperty)
    UClass* HoldDataDismiss() const { return Read<UClass*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ClassProperty)
    bool RequiresHoldDismiss() const { return Read<bool>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x1, Type: BoolProperty)
    UImage* Image_Icon() const { return Read<UImage*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ESlateSizeRule> ButtonFillRule() const { return Read<TEnumAsByte<ESlateSizeRule>>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x1, Type: ByteProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_WidgetSize(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_CaptureForPostBufferUpdate(const UWBP_CaptureForPostBufferUpdate_C*& Value) { Write<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_TopGrid(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_RichText_Header(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_RichText_Description(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Arrow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_Description(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Content(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_Buttons(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Outro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_ArrowPosition(const TEnumAsByte<E_UI_OutBoardPosition>& Value) { Write<TEnumAsByte<E_UI_OutBoardPosition>>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x1, Type: ByteProperty)
    void SET_OutsideOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: DoubleProperty)
    void SET_Brush_Icon(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0xb0, Type: StructProperty)
    void SET_Angle_Icon(const float& Value) { Write<float>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x4, Type: FloatProperty)
    void SET_IconPosition(const TEnumAsByte<E_UI_DirectionLeftRightNone>& Value) { Write<TEnumAsByte<E_UI_DirectionLeftRightNone>>(uintptr_t(this) + 0x444, Value); } // 0x444 (Size: 0x1, Type: ByteProperty)
    void SET_TextHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x10, Type: TextProperty)
    void SET_JustificationHeader(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x1, Type: ByteProperty)
    void SET_TextDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x10, Type: TextProperty)
    void SET_DefaultDescriptoinColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x14, Type: StructProperty)
    void SET_JustificationDescription(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x484, Value); } // 0x484 (Size: 0x1, Type: ByteProperty)
    void SET_TextDismissButton(const FText& Value) { Write<FText>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x10, Type: TextProperty)
    void SET_IsShowDismissButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x1, Type: BoolProperty)
    void SET_TextOtherActionButton(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x10, Type: TextProperty)
    void SET_IsShowOtherActionButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x1, Type: BoolProperty)
    void SET_BackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0xb0, Type: StructProperty)
    void SET_Widget_Width(const float& Value) { Write<float>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x4, Type: FloatProperty)
    void SET_SafeZone(const double& Value) { Write<double>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    void SET_In_Decorator_Classes(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x10, Type: ArrayProperty)
    void SET_Input_Action_Other(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x10, Type: StructProperty)
    void SET_Input_Action_Dismiss(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundDynamicMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    void SET_DismissButton(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherActionButton(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_HoldDataOther(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ClassProperty)
    void SET_RequiresHoldOther(const bool& Value) { Write<bool>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x1, Type: BoolProperty)
    void SET_HoldDataDismiss(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ClassProperty)
    void SET_RequiresHoldDismiss(const bool& Value) { Write<bool>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x1, Type: BoolProperty)
    void SET_Image_Icon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonFillRule(const TEnumAsByte<ESlateSizeRule>& Value) { Write<TEnumAsByte<ESlateSizeRule>>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x4c8
class UWBP_Locker_MusicMoments_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4c8
class UWBP_Locker_PresetCap_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4e8
class UWBP_Locker_SaveLoadout_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4d8
class UWBP_Locker_PCB_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4c8
class UWBP_Locker_PresetAccess_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

