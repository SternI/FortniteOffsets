/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EcosystemReadyUpErrorsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x120
class UBaseDownloadErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UBaseMatchmakingGroupErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UBaseRegionErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class UBaseTournamentLockErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UCannotUseWhileLookingForPartyUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x120
class UCannotUseWhileUsingPartySignalUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x120
class UContentGatedUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x110
class UCrossplayReadyUpErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x140
class UEULAErrorUI : public UReadyUpErrorUI
{
public:
    FText TitleOverride() const { return Read<FText>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: TextProperty)

    void SET_TitleOverride(const FText& Value) { Write<FText>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: TextProperty)
};

// Size: 0x118
class UGeneralBanUI : public UTimedErrorUI
{
public:
};

// Size: 0x118
class UTimedErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class UIneligibleEventErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class UIsInstallingUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class UIsLoadingBuiltInGFPsUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class UIsPreDownloadingUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UNotAvailableInSplitScreenErrorUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x120
class UNotEnoughPartyMembersUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x110
class UNotEnoughPlayersForPrivateUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UPlayersNotQualifiedErrorUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x110
class UQuestErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class URequiresInstallUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class URequiresPreDownloadUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x130
class USTWGeneralErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x110
class USTWRequiresFrontendErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UTooManyPartyMembersUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x120
class UTooManySplitscreenMembersUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

// Size: 0x110
class UTournamentLockedByAccountErrorUI : public UBaseTournamentLockErrorUI
{
public:
};

// Size: 0x110
class UTournamentLockedByRegionUI : public UBaseTournamentLockErrorUI
{
public:
};

// Size: 0x110
class UTournamentLockedByTeamErrorUI : public UBaseTournamentLockErrorUI
{
public:
};

// Size: 0x140
class UTournamentRequiresMFAErrorUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x120
class UUnusableRegionUI : public UBaseRegionErrorUI
{
public:
};

// Size: 0x178
class UWorldOwnerMustBePartyLeaderErrorUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

