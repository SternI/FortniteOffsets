/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayEventRouter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0xb8
class UAsyncAction_StartListeningToEvent : public UBlueprintAsyncActionBase
{
public:
};

// Size: 0xd8
class UAsyncAction_StartListeningToStatefulEvent : public UBlueprintAsyncActionBase
{
public:
};

// Size: 0x2f0
class UGameplayEventRouterComponent : public UActorComponent
{
public:
};

// Size: 0x28
class UGameplayEventRouterOwnerInterface : public UInterface
{
public:
};

// Size: 0x198
class UGameplayEventRouterSubsystem : public UGameInstanceSubsystem
{
public:
    TArray<FGameplayEventGlobalRouterPendingListenerData> PendingGlobalRouterListenerDatas() const { return Read<TArray<FGameplayEventGlobalRouterPendingListenerData>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x10, Type: ArrayProperty)

    void SET_PendingGlobalRouterListenerDatas(const TArray<FGameplayEventGlobalRouterPendingListenerData>& Value) { Write<TArray<FGameplayEventGlobalRouterPendingListenerData>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1c
struct FGameplayEventListenerHandle
{
public:
    int32_t Handle() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_Handle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FGameplayEventId
{
public:
};

// Size: 0x48
struct FGameplayEventListenerBackwardCompatibleHandle
{
public:
};

// Size: 0xc0
struct FGameplayEventListenerData
{
public:
    UScriptStruct* EventType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    UObject* EventContext() const { return Read<UObject*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)

    void SET_EventType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_EventContext(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FGameplayEventListenerList
{
public:
};

// Size: 0xc0
struct FGameplayEventGlobalRouterPendingListenerData
{
public:
    UScriptStruct* EventType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UObject* EventContext() const { return Read<UObject*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_EventType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_EventContext(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

