/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Figure_Core
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x148
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
public:
    FName __NameProperty_4() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_5() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FAnimNodeFunctionRef __StructProperty_6() const { return Read<FAnimNodeFunctionRef>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x80, Type: StructProperty)
    FAnimSubsystem_Base AnimBlueprintExtension_Base() const { return Read<FAnimSubsystem_Base>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x40, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x30, Type: StructProperty)

    void SET___NameProperty_4(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_5(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET___StructProperty_6(const FAnimNodeFunctionRef& Value) { Write<FAnimNodeFunctionRef>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystem_PropertyAccess& Value) { Write<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x80, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystem_Base& Value) { Write<FAnimSubsystem_Base>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x40, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x30, Type: StructProperty)
};

// Size: 0x4c0
class UABP_Figure_PlaceHolder_C : public UAnimInstance
{
public:
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_Base() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose() const { return Read<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0xb0, Type: StructProperty)

    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose(const FAnimNode_LinkedInputPose& Value) { Write<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0xb0, Type: StructProperty)
};

