/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AssetTags
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x30
class UAssetTagsSubsystem : public UEngineSubsystem
{
public:
};

