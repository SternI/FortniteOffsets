/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Chaos
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "ChaosVDRuntime.h"
#include "CoreUObject.h"

// Size: 0xb0
struct FManagedArrayCollection
{
public:
};

// Size: 0xb0
struct FFieldCollection : public FManagedArrayCollection
{
public:
};

// Size: 0x28
struct FClosestPhysicsObjectResult
{
public:
};

// Size: 0x14
struct FChaosSolverDestructionSettings
{
public:
    int32_t PerAdvanceBreaksAllowed() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PerAdvanceBreaksRescheduleLimit() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t ClusteringParticleReleaseThrottlingMinCount() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ClusteringParticleReleaseThrottlingMaxCount() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    bool bOptimizeForRuntimeMemory() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_PerAdvanceBreaksAllowed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_PerAdvanceBreaksRescheduleLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_ClusteringParticleReleaseThrottlingMinCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_ClusteringParticleReleaseThrottlingMaxCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_bOptimizeForRuntimeMemory(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x84
struct FChaosSolverConfiguration
{
public:
    int32_t PositionIterations() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t VelocityIterations() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t ProjectionIterations() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    float CollisionMarginFraction() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float CollisionMarginMax() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float CollisionCullDistance() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float CollisionMaxPushOutVelocity() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float CollisionInitialOverlapDepenetrationVelocity() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float ClusterConnectionFactor() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t ClusterUnionConnectionType() const { return Read<uint8_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: EnumProperty)
    FChaosSolverDestructionSettings DestructionSettings() const { return Read<FChaosSolverDestructionSettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x14, Type: StructProperty)
    bool bGenerateCollisionData() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    FSolverCollisionFilterSettings CollisionFilterSettings() const { return Read<FSolverCollisionFilterSettings>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    bool bGenerateBreakData() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FSolverBreakingFilterSettings BreakingFilterSettings() const { return Read<FSolverBreakingFilterSettings>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x10, Type: StructProperty)
    bool bGenerateTrailingData() const { return Read<bool>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x1, Type: BoolProperty)
    FSolverTrailingFilterSettings TrailingFilterSettings() const { return Read<FSolverTrailingFilterSettings>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    int32_t Iterations() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t PushOutIterations() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)
    bool bGenerateContactGraph() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_PositionIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_VelocityIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_ProjectionIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_CollisionMarginFraction(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_CollisionMarginMax(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionCullDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionMaxPushOutVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionInitialOverlapDepenetrationVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_ClusterConnectionFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_ClusterUnionConnectionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: EnumProperty)
    void SET_DestructionSettings(const FChaosSolverDestructionSettings& Value) { Write<FChaosSolverDestructionSettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x14, Type: StructProperty)
    void SET_bGenerateCollisionData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_CollisionFilterSettings(const FSolverCollisionFilterSettings& Value) { Write<FSolverCollisionFilterSettings>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_bGenerateBreakData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_BreakingFilterSettings(const FSolverBreakingFilterSettings& Value) { Write<FSolverBreakingFilterSettings>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x10, Type: StructProperty)
    void SET_bGenerateTrailingData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x1, Type: BoolProperty)
    void SET_TrailingFilterSettings(const FSolverTrailingFilterSettings& Value) { Write<FSolverTrailingFilterSettings>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_Iterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_PushOutIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
    void SET_bGenerateContactGraph(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FSolverTrailingFilterSettings
{
public:
    bool FilterEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float MinMass() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinVolume() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_FilterEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_MinMass(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinVolume(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FSolverBreakingFilterSettings
{
public:
    bool FilterEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float MinMass() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinVolume() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_FilterEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_MinMass(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinVolume(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FSolverCollisionFilterSettings
{
public:
    bool FilterEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float MinMass() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinImpulse() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_FilterEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_MinMass(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinImpulse(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FSerializedSolverScene
{
public:
    TArray<FChaosVDParticleDataWrapper> ParticleData() const { return Read<TArray<FChaosVDParticleDataWrapper>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FChaosVDJointConstraint> JointConstraintData() const { return Read<TArray<FChaosVDJointConstraint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FChaosVDCharacterGroundConstraint> CharacterGroundConstraintData() const { return Read<TArray<FChaosVDCharacterGroundConstraint>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FChaosVDParticlePairMidPhase> CollisionMidPhaseData() const { return Read<TArray<FChaosVDParticlePairMidPhase>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_ParticleData(const TArray<FChaosVDParticleDataWrapper>& Value) { Write<TArray<FChaosVDParticleDataWrapper>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_JointConstraintData(const TArray<FChaosVDJointConstraint>& Value) { Write<TArray<FChaosVDJointConstraint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CharacterGroundConstraintData(const TArray<FChaosVDCharacterGroundConstraint>& Value) { Write<TArray<FChaosVDCharacterGroundConstraint>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_CollisionMidPhaseData(const TArray<FChaosVDParticlePairMidPhase>& Value) { Write<TArray<FChaosVDParticlePairMidPhase>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc0
struct FSolverCollisionData
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector AccumulatedImpulse() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector Velocity1() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector Velocity2() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity1() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity2() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    float Mass1() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float Mass2() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t LevelsetIndex() const { return Read<int32_t>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: IntProperty)
    int32_t ParticleIndexMesh() const { return Read<int32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t LevelsetIndexMesh() const { return Read<int32_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: IntProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_AccumulatedImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Velocity1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_Velocity2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_Mass1(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_Mass2(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_LevelsetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: IntProperty)
    void SET_ParticleIndexMesh(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: IntProperty)
    void SET_LevelsetIndexMesh(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
struct FSolverBreakingData
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    int32_t ParticleIndexMesh() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET_ParticleIndexMesh(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
struct FSolverTrailingData
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    int32_t ParticleIndexMesh() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET_ParticleIndexMesh(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
};

// Size: 0xb8
struct FRecordedFrame
{
public:
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> TransformIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> PreviousTransformIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<bool> DisabledFlags() const { return Read<TArray<bool>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FSolverCollisionData> Collisions() const { return Read<TArray<FSolverCollisionData>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FSolverBreakingData> Breakings() const { return Read<TArray<FSolverBreakingData>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TSet<FSolverTrailingData> Trailings() const { return Read<TSet<FSolverTrailingData>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: SetProperty)
    float Timestamp() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)

    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_TransformIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviousTransformIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_DisabledFlags(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Collisions(const TArray<FSolverCollisionData>& Value) { Write<TArray<FSolverCollisionData>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_Breakings(const TArray<FSolverBreakingData>& Value) { Write<TArray<FSolverBreakingData>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_Trailings(const TSet<FSolverTrailingData>& Value) { Write<TSet<FSolverTrailingData>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: SetProperty)
    void SET_Timestamp(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FRecordedTransformTrack
{
public:
    TArray<FRecordedFrame> Records() const { return Read<TArray<FRecordedFrame>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Records(const TArray<FRecordedFrame>& Value) { Write<TArray<FRecordedFrame>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FSolverRemovalFilterSettings
{
public:
    bool FilterEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float MinMass() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinVolume() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_FilterEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_MinMass(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinVolume(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

