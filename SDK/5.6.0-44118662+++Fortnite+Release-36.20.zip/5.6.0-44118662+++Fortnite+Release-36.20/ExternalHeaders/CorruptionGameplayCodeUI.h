/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CorruptionGameplayCodeUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
// Size: 0x3a0
class UFortPowerupReticleExtensionWidget : public UFortWeaponReticleExtensionWidgetBase
{
public:
    uint8_t LastPowerupHeatState() const { return Read<uint8_t>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x1, Type: EnumProperty)

    void SET_LastPowerupHeatState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x1, Type: EnumProperty)
};

