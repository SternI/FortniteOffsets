/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaVideoWidgetBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CommonUI.h"
#include "EpicMediaBasePlayer.h"
#include "UMG.h"
#include "MediaAssets.h"

// Size: 0x50
class UEpicMediaVideoWidgetConfig : public UObject
{
public:
    FString MediaID() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString MediaName() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    char PerfControl() const { return Read<char>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    bool bAllowSkipping() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bHoldToSkip() const { return Read<bool>(uintptr_t(this) + 0x4a); } // 0x4a (Size: 0x1, Type: BoolProperty)
    bool bHideControls() const { return Read<bool>(uintptr_t(this) + 0x4b); } // 0x4b (Size: 0x1, Type: BoolProperty)
    bool bAutoPlay() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bLoop() const { return Read<bool>(uintptr_t(this) + 0x4d); } // 0x4d (Size: 0x1, Type: BoolProperty)
    bool bNoAudio() const { return Read<bool>(uintptr_t(this) + 0x4e); } // 0x4e (Size: 0x1, Type: BoolProperty)

    void SET_MediaID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_MediaName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_PerfControl(const char& Value) { Write<char>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_bAllowSkipping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
    void SET_bHoldToSkip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a, Value); } // 0x4a (Size: 0x1, Type: BoolProperty)
    void SET_bHideControls(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b, Value); } // 0x4b (Size: 0x1, Type: BoolProperty)
    void SET_bAutoPlay(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_bLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d, Value); } // 0x4d (Size: 0x1, Type: BoolProperty)
    void SET_bNoAudio(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e, Value); } // 0x4e (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4f8
class UEpicMediaVideoWidgetBase : public UCommonActivatableWidget
{
public:
    UEpicBaseStreamingVideo* BasePlayer() const { return Read<UEpicBaseStreamingVideo*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UEpicMediaVideoWidgetConfig* Config() const { return Read<UEpicMediaVideoWidgetConfig*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle PressToSkipAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle HoldToSkipAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x10, Type: StructProperty)
    UCommonButtonBase* Button_Skip() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* MediaTexture() const { return Read<UMediaTexture*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Throbber() const { return Read<UImage*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* SoundComponent() const { return Read<UMediaSoundComponent*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    USoundMix* ActiveSoundMix() const { return Read<USoundMix*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* DefaultSubmix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    USoundClass* SoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* LicensedSubmix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    bool bAutoBroadcastRebuild() const { return Read<bool>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x1, Type: BoolProperty)

    void SET_BasePlayer(const UEpicBaseStreamingVideo*& Value) { Write<UEpicBaseStreamingVideo*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Config(const UEpicMediaVideoWidgetConfig*& Value) { Write<UEpicMediaVideoWidgetConfig*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_PressToSkipAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x10, Type: StructProperty)
    void SET_HoldToSkipAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x10, Type: StructProperty)
    void SET_Button_Skip(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_MediaTexture(const UMediaTexture*& Value) { Write<UMediaTexture*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Throbber(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundComponent(const UMediaSoundComponent*& Value) { Write<UMediaSoundComponent*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveSoundMix(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSubmix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_LicensedSubmix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_bAutoBroadcastRebuild(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x1, Type: BoolProperty)
};

