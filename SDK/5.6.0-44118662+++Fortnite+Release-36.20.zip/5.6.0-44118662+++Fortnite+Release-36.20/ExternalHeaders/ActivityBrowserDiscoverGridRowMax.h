/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserDiscoverGridRowMax
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteUI.h"
#include "Rows.h"
#include "UMG.h"
#include "TabScreens.h"

// Size: 0x4d0
class UActivityBrowserDiscoverGridRowMax_C : public UFortDiscoverBrowserGridRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: StructProperty)
    UWBP_Row_PanelList_C* WBP_Row_PanelList() const { return Read<UWBP_Row_PanelList_C*>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x8, Type: ObjectProperty)
    UWBP_LoadingMorePages_C* WBP_LoadingMorePages() const { return Read<UWBP_LoadingMorePages_C*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GridRoot_WithCustomNavEvents() const { return Read<UGridPanel*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverProviderViewModel* FortDiscoverProviderViewModel() const { return Read<UFortDiscoverProviderViewModel*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    FName FontHoverAnimateParam() const { return Read<FName>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam() const { return Read<FName>(uintptr_t(this) + 0x46c); } // 0x46c (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim() const { return Read<bool>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x1, Type: BoolProperty)
    double LoadingMoreDisplayDelay() const { return Read<double>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible() const { return Read<bool>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive() const { return Read<bool>(uintptr_t(this) + 0x481); } // 0x481 (Size: 0x1, Type: BoolProperty)
    FTimerHandle LoadingMoreDelayTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: StructProperty)
    double EntriesSpacing() const { return Read<double>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: DoubleProperty)
    bool bAllowNonFullRows() const { return Read<bool>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: StructProperty)
    void SET_WBP_Row_PanelList(const UWBP_Row_PanelList_C*& Value) { Write<UWBP_Row_PanelList_C*>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_LoadingMorePages(const UWBP_LoadingMorePages_C*& Value) { Write<UWBP_LoadingMorePages_C*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    void SET_GridRoot_WithCustomNavEvents(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_OnLoadingMore(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_FortDiscoverProviderViewModel(const UFortDiscoverProviderViewModel*& Value) { Write<UFortDiscoverProviderViewModel*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_FontHoverAnimateParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x4, Type: NameProperty)
    void SET_FontPressedAnimateParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x46c, Value); } // 0x46c (Size: 0x4, Type: NameProperty)
    void SET_IsWaitingForInactiveAnim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingMoreDisplayDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: DoubleProperty)
    void SET_IsLoadingMoreVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x1, Type: BoolProperty)
    void SET_IsLoadingMoreQueryActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x481, Value); } // 0x481 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingMoreDelayTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: StructProperty)
    void SET_EntriesSpacing(const double& Value) { Write<double>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: DoubleProperty)
    void SET_bAllowNonFullRows(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x1, Type: BoolProperty)
};

