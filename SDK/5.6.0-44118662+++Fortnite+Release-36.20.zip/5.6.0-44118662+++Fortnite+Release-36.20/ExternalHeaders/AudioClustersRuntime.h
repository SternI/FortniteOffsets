/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioClustersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x30
class UAudioClusterConfig : public UObject
{
public:
    UAudioClusterBehavior* Behavior() const { return Read<UAudioClusterBehavior*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Behavior(const UAudioClusterBehavior*& Value) { Write<UAudioClusterBehavior*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
class UAudioClusterConfigMap : public UObject
{
public:
    TMap<FGameplayTag, UAudioClusterConfig*> TagConfigMap() const { return Read<TMap<FGameplayTag, UAudioClusterConfig*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_TagConfigMap(const TMap<FGameplayTag, UAudioClusterConfig*>& Value) { Write<TMap<FGameplayTag, UAudioClusterConfig*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x30
class UAudioClusterBehavior : public UObject
{
public:
};

// Size: 0x38
class UAudioClustersSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0xc
struct FAudioClusterActorInfo
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

