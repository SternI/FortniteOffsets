/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricLevelSequencer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "HarmonixMidi.h"
#include "CoreUObject.h"
#include "LevelSequence.h"
#include "FabricRuntime.h"
#include "HarmonixMetasound.h"
#include "FabricEngineSequencer.h"
#include "Engine.h"

// Size: 0x268
class UFabricSongSyncComponent : public UActorComponent
{
public:
    float MinAllowedTempo() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MaxAllowedTempo() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    TArray<int32_t> AllowedTimeSignatureNumerators() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> AllowedTimeSignatureDenominators() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    FName MidiFilePropertyName() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    FName OffsetBarsProperty() const { return Read<FName>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: NameProperty)
    FName OffsetBeatsProperty() const { return Read<FName>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: NameProperty)
    FName IgnoreSeeksProperty() const { return Read<FName>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: NameProperty)
    UClass* MidiFileClockProviderPatchClass() const { return Read<UClass*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ClassProperty)
    FName AudioComponentName() const { return Read<FName>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: NameProperty)
    bool bAllowSpeedAdjustSyncChanges() const { return Read<bool>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x1, Type: BoolProperty)
    FSongSyncPlaybackRequest ServerPlaybackRequest() const { return Read<FSongSyncPlaybackRequest>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0xc, Type: StructProperty)
    FMusicTimestamp PlaybackStartTimestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp RelativeOffsetTimestampMidi() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x8, Type: StructProperty)
    FMusicTimestamp RelativeOffsetTimestampLinked() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x8, Type: StructProperty)
    bool bWaitForClockRestart() const { return Read<bool>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x1, Type: BoolProperty)
    FMusicTimestamp CachedTimeStampPreRestart() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: StructProperty)
    FSongSyncMidiSource MidiSource() const { return Read<FSongSyncMidiSource>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x18, Type: StructProperty)
    TScriptInterface<Class> CurrentFabricMidiProvider() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x10, Type: InterfaceProperty)
    UMidiFile* MidiSourceLatestMidi() const { return Read<UMidiFile*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    FSongSyncSequenceActor ServerLevelSequenceActor() const { return Read<FSongSyncSequenceActor>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0xc, Type: StructProperty)
    TWeakObjectPtr<UFabricSongSyncComponent*> AuthoritySongSync() const { return Read<TWeakObjectPtr<UFabricSongSyncComponent*>>(uintptr_t(this) + 0x21c); } // 0x21c (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UFabricSongSyncComponent*>> LinkedSongSyncs() const { return Read<TArray<TWeakObjectPtr<UFabricSongSyncComponent*>>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    UMusicClockMovieSceneClockSource* CustomClockSource() const { return Read<UMusicClockMovieSceneClockSource*>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFabricTimelineSyncComponent*> FabricTimelineSyncComponent() const { return Read<TWeakObjectPtr<UFabricTimelineSyncComponent*>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMidiFollowComponent*> FollowComponent() const { return Read<TWeakObjectPtr<UFabricMidiFollowComponent*>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClock() const { return Read<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> FabricMetasoundManager() const { return Read<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x8, Type: WeakObjectProperty)
    UFabricSongSyncUtilityProviderPatchWrapper* MidiFileClockProviderPatchInstance() const { return Read<UFabricSongSyncUtilityProviderPatchWrapper*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)

    void SET_MinAllowedTempo(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAllowedTempo(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_AllowedTimeSignatureNumerators(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_AllowedTimeSignatureDenominators(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_MidiFilePropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_OffsetBarsProperty(const FName& Value) { Write<FName>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: NameProperty)
    void SET_OffsetBeatsProperty(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: NameProperty)
    void SET_IgnoreSeeksProperty(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: NameProperty)
    void SET_MidiFileClockProviderPatchClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ClassProperty)
    void SET_AudioComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: NameProperty)
    void SET_bAllowSpeedAdjustSyncChanges(const bool& Value) { Write<bool>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x1, Type: BoolProperty)
    void SET_ServerPlaybackRequest(const FSongSyncPlaybackRequest& Value) { Write<FSongSyncPlaybackRequest>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0xc, Type: StructProperty)
    void SET_PlaybackStartTimestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x8, Type: StructProperty)
    void SET_RelativeOffsetTimestampMidi(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x8, Type: StructProperty)
    void SET_RelativeOffsetTimestampLinked(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x8, Type: StructProperty)
    void SET_bWaitForClockRestart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x1, Type: BoolProperty)
    void SET_CachedTimeStampPreRestart(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: StructProperty)
    void SET_MidiSource(const FSongSyncMidiSource& Value) { Write<FSongSyncMidiSource>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x18, Type: StructProperty)
    void SET_CurrentFabricMidiProvider(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x10, Type: InterfaceProperty)
    void SET_MidiSourceLatestMidi(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerLevelSequenceActor(const FSongSyncSequenceActor& Value) { Write<FSongSyncSequenceActor>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0xc, Type: StructProperty)
    void SET_AuthoritySongSync(const TWeakObjectPtr<UFabricSongSyncComponent*>& Value) { Write<TWeakObjectPtr<UFabricSongSyncComponent*>>(uintptr_t(this) + 0x21c, Value); } // 0x21c (Size: 0x8, Type: WeakObjectProperty)
    void SET_LinkedSongSyncs(const TArray<TWeakObjectPtr<UFabricSongSyncComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricSongSyncComponent*>>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    void SET_CustomClockSource(const UMusicClockMovieSceneClockSource*& Value) { Write<UMusicClockMovieSceneClockSource*>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x8, Type: ObjectProperty)
    void SET_FabricTimelineSyncComponent(const TWeakObjectPtr<UFabricTimelineSyncComponent*>& Value) { Write<TWeakObjectPtr<UFabricTimelineSyncComponent*>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FollowComponent(const TWeakObjectPtr<UFabricMidiFollowComponent*>& Value) { Write<TWeakObjectPtr<UFabricMidiFollowComponent*>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MusicClock(const TWeakObjectPtr<UMusicClockComponent*>& Value) { Write<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FabricMetasoundManager(const TWeakObjectPtr<UFabricMetaSoundManagerComponent*>& Value) { Write<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MidiFileClockProviderPatchInstance(const UFabricSongSyncUtilityProviderPatchWrapper*& Value) { Write<UFabricSongSyncUtilityProviderPatchWrapper*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1d0
class UPlaylistUserOptionMidiSource : public UPlaylistUserOptionBase
{
public:
    FMidiSource DefaultValue() const { return Read<FMidiSource>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x18, Type: StructProperty)

    void SET_DefaultValue(const FMidiSource& Value) { Write<FMidiSource>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1d8
class UPlaylistUserOptionLinkedSequence : public UPlaylistUserOptionBase
{
public:
    FLinkedSequence DefaultValue() const { return Read<FLinkedSequence>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x20, Type: StructProperty)

    void SET_DefaultValue(const FLinkedSequence& Value) { Write<FLinkedSequence>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1c8
class UPlaylistUserOptionLinkedSongSyncList : public UPlaylistUserOptionBase
{
public:
    FLinkedSongSyncList DefaultValue() const { return Read<FLinkedSongSyncList>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: StructProperty)

    void SET_DefaultValue(const FLinkedSongSyncList& Value) { Write<FLinkedSongSyncList>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1f8
class UFabricSongSyncUtilityProviderPatchWrapper : public UFabricMetaSoundUtilityProviderPatchWrapper
{
public:
    FName ClockProviderMidiFileInName() const { return Read<FName>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: NameProperty)
    UMidiFile* DefaultMidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UMidiFile*> TempoMapMidiFile() const { return Read<TWeakObjectPtr<UMidiFile*>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ClockProviderMidiFileInName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: NameProperty)
    void SET_DefaultMidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    void SET_TempoMapMidiFile(const TWeakObjectPtr<UMidiFile*>& Value) { Write<TWeakObjectPtr<UMidiFile*>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xc
struct FSongSyncPlaybackRequest
{
public:
    FMusicTimestamp StartingTimestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    bool bPlay() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_StartingTimestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_bPlay(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FSongSyncSequenceActor
{
public:
    TWeakObjectPtr<ALevelSequenceActor*> LevelSequenceActor() const { return Read<TWeakObjectPtr<ALevelSequenceActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t SequenceState() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_LevelSequenceActor(const TWeakObjectPtr<ALevelSequenceActor*>& Value) { Write<TWeakObjectPtr<ALevelSequenceActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SequenceState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FSongSyncMidiSource
{
public:
    UMidiFile* MidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t MidiSourceType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    FName SelectedMidiTrackName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    bool bHasBeenSet() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_MidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MidiSourceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_SelectedMidiTrackName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_bHasBeenSet(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FMidiSource
{
public:
    uint8_t MidiSourceType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    UMidiFile* MidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName SelectedMidiTrackName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)

    void SET_MidiSourceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_MidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedMidiTrackName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
};

// Size: 0x20
struct FLinkedSequence
{
public:
    TSoftObjectPtr<ULevelSequence> LevelSequence() const { return Read<TSoftObjectPtr<ULevelSequence>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_LevelSequence(const TSoftObjectPtr<ULevelSequence>& Value) { Write<TSoftObjectPtr<ULevelSequence>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x20
struct FLinkedSongSync
{
public:
    TSoftObjectPtr<AActor> LinkedSongSync() const { return Read<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_LinkedSongSync(const TSoftObjectPtr<AActor>& Value) { Write<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x10
struct FLinkedSongSyncList
{
public:
    TArray<FLinkedSongSync> LinkedSongSyncs() const { return Read<TArray<FLinkedSongSync>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_LinkedSongSyncs(const TArray<FLinkedSongSync>& Value) { Write<TArray<FLinkedSongSync>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FUserOptionDefinitionMidiSourceMetaData : public FUserOptionDefinitionMetaData
{
public:
};

// Size: 0x8
struct FUserOptionDefinitionLinkedSequenceMetaData : public FUserOptionDefinitionMetaData
{
public:
};

// Size: 0x18
struct FUserOptionDefinitionLinkedSongSyncListMetaData : public FUserOptionDefinitionMetaData
{
public:
    FLinkedSongSyncList DefaultValue() const { return Read<FLinkedSongSyncList>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_DefaultValue(const FLinkedSongSyncList& Value) { Write<FLinkedSongSyncList>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

