/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMDeviceCablesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "FabricRuntime.h"
#include "GameplayEventRouter.h"

// Size: 0x940
class AFMDeviceCable : public ABuildingActor
{
public:
    USplineComponent* SplineComponent() const { return Read<USplineComponent*>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* DeviceCableHead() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x8, Type: ObjectProperty)
    UClass* SplineMeshComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UStaticMesh> ScalarStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> AudioStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> NoteStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> TextureStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> MeshStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x20, Type: SoftObjectProperty)
    FName SplineLengthParam() const { return Read<FName>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0x4, Type: NameProperty)
    FName SplineStartParam() const { return Read<FName>(uintptr_t(this) + 0x81c); } // 0x81c (Size: 0x4, Type: NameProperty)
    FName SplineEndParam() const { return Read<FName>(uintptr_t(this) + 0x820); } // 0x820 (Size: 0x4, Type: NameProperty)
    FName PortTypeParam() const { return Read<FName>(uintptr_t(this) + 0x824); } // 0x824 (Size: 0x4, Type: NameProperty)
    float CableStubLength() const { return Read<float>(uintptr_t(this) + 0x828); } // 0x828 (Size: 0x4, Type: FloatProperty)
    float CableDistanceFromPortB() const { return Read<float>(uintptr_t(this) + 0x82c); } // 0x82c (Size: 0x4, Type: FloatProperty)
    float CableMinTangent() const { return Read<float>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x4, Type: FloatProperty)
    float CableMaxTangent() const { return Read<float>(uintptr_t(this) + 0x834); } // 0x834 (Size: 0x4, Type: FloatProperty)
    float CableSectionLengthAtCableCenter() const { return Read<float>(uintptr_t(this) + 0x838); } // 0x838 (Size: 0x4, Type: FloatProperty)
    float CableSectionLengthAtCableHeads() const { return Read<float>(uintptr_t(this) + 0x83c); } // 0x83c (Size: 0x4, Type: FloatProperty)
    int32_t CableSectionCountAtCableHeads() const { return Read<int32_t>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x4, Type: IntProperty)
    int32_t CableCenterSectionsMaxCount() const { return Read<int32_t>(uintptr_t(this) + 0x844); } // 0x844 (Size: 0x4, Type: IntProperty)
    float ExtremeMinDotProduct() const { return Read<float>(uintptr_t(this) + 0x848); } // 0x848 (Size: 0x4, Type: FloatProperty)
    float MaxExtremeCableBendSize() const { return Read<float>(uintptr_t(this) + 0x84c); } // 0x84c (Size: 0x4, Type: FloatProperty)
    float ExtremeAngleTangentScale() const { return Read<float>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x4, Type: FloatProperty)
    TArray<USplineMeshComponent*> CableSplineMeshArray() const { return Read<TArray<USplineMeshComponent*>>(uintptr_t(this) + 0x858); } // 0x858 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UFMDeviceCableAnimatorBase*> DeviceCableAnimator() const { return Read<TWeakObjectPtr<UFMDeviceCableAnimatorBase*>>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x8, Type: WeakObjectProperty)
    UMaterialInstanceDynamic* DeviceCableMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DeviceCableHeadMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x878); } // 0x878 (Size: 0x8, Type: ObjectProperty)
    FVector DeviceCableHeadScale() const { return Read<FVector>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x18, Type: StructProperty)
    UFMDeviceCablePortComponent* ConstantPort() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* PortA() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ServerPortA() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* PortB() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ServerPortB() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    bool bPermittedToShowVisuals() const { return Read<bool>(uintptr_t(this) + 0x8d0); } // 0x8d0 (Size: 0x1, Type: BoolProperty)

    void SET_SplineComponent(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    void SET_DeviceCableHead(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineMeshComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x8, Type: ClassProperty)
    void SET_ScalarStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AudioStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x20, Type: SoftObjectProperty)
    void SET_NoteStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TextureStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MeshStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SplineLengthParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0x4, Type: NameProperty)
    void SET_SplineStartParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x81c, Value); } // 0x81c (Size: 0x4, Type: NameProperty)
    void SET_SplineEndParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x820, Value); } // 0x820 (Size: 0x4, Type: NameProperty)
    void SET_PortTypeParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x824, Value); } // 0x824 (Size: 0x4, Type: NameProperty)
    void SET_CableStubLength(const float& Value) { Write<float>(uintptr_t(this) + 0x828, Value); } // 0x828 (Size: 0x4, Type: FloatProperty)
    void SET_CableDistanceFromPortB(const float& Value) { Write<float>(uintptr_t(this) + 0x82c, Value); } // 0x82c (Size: 0x4, Type: FloatProperty)
    void SET_CableMinTangent(const float& Value) { Write<float>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x4, Type: FloatProperty)
    void SET_CableMaxTangent(const float& Value) { Write<float>(uintptr_t(this) + 0x834, Value); } // 0x834 (Size: 0x4, Type: FloatProperty)
    void SET_CableSectionLengthAtCableCenter(const float& Value) { Write<float>(uintptr_t(this) + 0x838, Value); } // 0x838 (Size: 0x4, Type: FloatProperty)
    void SET_CableSectionLengthAtCableHeads(const float& Value) { Write<float>(uintptr_t(this) + 0x83c, Value); } // 0x83c (Size: 0x4, Type: FloatProperty)
    void SET_CableSectionCountAtCableHeads(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x4, Type: IntProperty)
    void SET_CableCenterSectionsMaxCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x844, Value); } // 0x844 (Size: 0x4, Type: IntProperty)
    void SET_ExtremeMinDotProduct(const float& Value) { Write<float>(uintptr_t(this) + 0x848, Value); } // 0x848 (Size: 0x4, Type: FloatProperty)
    void SET_MaxExtremeCableBendSize(const float& Value) { Write<float>(uintptr_t(this) + 0x84c, Value); } // 0x84c (Size: 0x4, Type: FloatProperty)
    void SET_ExtremeAngleTangentScale(const float& Value) { Write<float>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x4, Type: FloatProperty)
    void SET_CableSplineMeshArray(const TArray<USplineMeshComponent*>& Value) { Write<TArray<USplineMeshComponent*>>(uintptr_t(this) + 0x858, Value); } // 0x858 (Size: 0x10, Type: ArrayProperty)
    void SET_DeviceCableAnimator(const TWeakObjectPtr<UFMDeviceCableAnimatorBase*>& Value) { Write<TWeakObjectPtr<UFMDeviceCableAnimatorBase*>>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x8, Type: WeakObjectProperty)
    void SET_DeviceCableMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x8, Type: ObjectProperty)
    void SET_DeviceCableHeadMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x878, Value); } // 0x878 (Size: 0x8, Type: ObjectProperty)
    void SET_DeviceCableHeadScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x18, Type: StructProperty)
    void SET_ConstantPort(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    void SET_PortA(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerPortA(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    void SET_PortB(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerPortB(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    void SET_bPermittedToShowVisuals(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8d0, Value); } // 0x8d0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
class UFMDeviceCableAnimatorTickSubsystem : public UFortManagedTickSubsystem
{
public:
};

// Size: 0xe8
class UFMDeviceCableAnimatorBase : public UObject
{
public:
    TWeakObjectPtr<UFMDeviceCablePortComponent*> OwnerPort() const { return Read<TWeakObjectPtr<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: WeakObjectProperty)

    void SET_OwnerPort(const TWeakObjectPtr<UFMDeviceCablePortComponent*>& Value) { Write<TWeakObjectPtr<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x190
class UFMDeviceCableAnimatorMidiEvent : public UFMDeviceCableAnimatorBase
{
public:
    FName NoteTextureParam() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    UCurveFloat* NoteShapeCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    float NotePercentOfTexture() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float NoteTravelBeats() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float NoteStartDelayBeats() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    UTexture2D* NoteTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundPatchWrapper* PatchWrapper() const { return Read<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_NoteTextureParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_NoteShapeCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_NotePercentOfTexture(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_NoteTravelBeats(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_NoteStartDelayBeats(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_NoteTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_PatchWrapper(const UFabricMetaSoundPatchWrapper*& Value) { Write<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x100
class UFMDeviceCableAnimatorFloatProvider : public UFMDeviceCableAnimatorBase
{
public:
    FName CableDataParam() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    FName FloatProviderTypeParam() const { return Read<FName>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: NameProperty)
    TArray<UFabricFloatProviderBase*> FloatProviders() const { return Read<TArray<UFabricFloatProviderBase*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)

    void SET_CableDataParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_FloatProviderTypeParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: NameProperty)
    void SET_FloatProviders(const TArray<UFabricFloatProviderBase*>& Value) { Write<TArray<UFabricFloatProviderBase*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf8
class UFMDeviceCableAnimatorTextureProvider : public UFMDeviceCableAnimatorBase
{
public:
    FName CableDataParam() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    float DecayRate() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    UFabricTextureProviderBase* TextureProvider() const { return Read<UFabricTextureProviderBase*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)

    void SET_CableDataParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_DecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_TextureProvider(const UFabricTextureProviderBase*& Value) { Write<UFabricTextureProviderBase*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf8
class UFMDeviceCableAnimatorMeshProvider : public UFMDeviceCableAnimatorBase
{
public:
    FName CableDataParam() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    float DecayRate() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    UFabricMeshProviderBase* MeshProvider() const { return Read<UFabricMeshProviderBase*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)

    void SET_CableDataParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_DecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_MeshProvider(const UFabricMeshProviderBase*& Value) { Write<UFabricMeshProviderBase*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x168
class UFMDeviceCableAnimatorAudioAnalyzer : public UFMDeviceCableAnimatorBase
{
public:
    FName FftTextureParam() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    FName WaveformTextureParam() const { return Read<FName>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: NameProperty)
    FName AmplitudeTextureParam() const { return Read<FName>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: NameProperty)
    FName AmplitudeDataParam() const { return Read<FName>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: NameProperty)
    FName CableQualityParam() const { return Read<FName>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: NameProperty)
    FName CableReactivityParam() const { return Read<FName>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: NameProperty)
    int32_t WaveformNumSamplesHeld() const { return Read<int32_t>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: IntProperty)
    int32_t WaveformSmoothingDistance() const { return Read<int32_t>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: IntProperty)
    float WaveformSmoothingFactor() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float WaveformDecayPerSecond() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    UTexture2D* WaveformTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* AmplitudeTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundPatchWrapper* PatchWrapper() const { return Read<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_FftTextureParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_WaveformTextureParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: NameProperty)
    void SET_AmplitudeTextureParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: NameProperty)
    void SET_AmplitudeDataParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: NameProperty)
    void SET_CableQualityParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: NameProperty)
    void SET_CableReactivityParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: NameProperty)
    void SET_WaveformNumSamplesHeld(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: IntProperty)
    void SET_WaveformSmoothingDistance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: IntProperty)
    void SET_WaveformSmoothingFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_WaveformDecayPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_WaveformTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_AmplitudeTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_PatchWrapper(const UFabricMetaSoundPatchWrapper*& Value) { Write<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x98
class UFMDeviceCableConnectionBase : public UObject
{
public:
    bool bConnectionActive() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)
    TArray<TWeakObjectPtr<UFMDeviceCablePortComponent*>> BuildingCompositeArtifactFromPorts() const { return Read<TArray<TWeakObjectPtr<UFMDeviceCablePortComponent*>>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_bConnectionActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
    void SET_BuildingCompositeArtifactFromPorts(const TArray<TWeakObjectPtr<UFMDeviceCablePortComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UFMDeviceCablePortComponent*>>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UFMDeviceCableMetaSoundConnection : public UFMDeviceCableConnectionBase
{
public:
};

// Size: 0x98
class UFMDeviceCableNoteConnection : public UFMDeviceCableMetaSoundConnection
{
public:
};

// Size: 0x98
class UFMDeviceCableAudioConnection : public UFMDeviceCableMetaSoundConnection
{
public:
};

// Size: 0x98
class UFMDeviceCableFloatConnection : public UFMDeviceCableConnectionBase
{
public:
};

// Size: 0x98
class UFMDeviceCableTextureConnection : public UFMDeviceCableConnectionBase
{
public:
};

// Size: 0xa0
class UFMDeviceCableMeshConnection : public UFMDeviceCableConnectionBase
{
public:
    uint32_t PreviousMeshInstanceHash() const { return Read<uint32_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: UInt32Property)

    void SET_PreviousMeshInstanceHash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x128
class UFMDeviceCableControllerComponent : public UActorComponent
{
public:
    UClass* ControllerCablePort() const { return Read<UClass*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ClassProperty)
    UClass* DeviceCableManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<AFortPawn*> CurrentPlayerPawn() const { return Read<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    AFortPlayerControllerAthena* PlayerController() const { return Read<AFortPlayerControllerAthena*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* LocalControllerPort() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ServerControllerPort() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> LocalControllerPortActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    UFMDeviceCableManagerComponent* LocalDeviceCableManager() const { return Read<UFMDeviceCableManagerComponent*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCableManagerComponent* ServerDeviceCableManager() const { return Read<UFMDeviceCableManagerComponent*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    bool bFitIsEquipped() const { return Read<bool>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: BoolProperty)

    void SET_ControllerCablePort(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ClassProperty)
    void SET_DeviceCableManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    void SET_CurrentPlayerPawn(const TWeakObjectPtr<AFortPawn*>& Value) { Write<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerController(const AFortPlayerControllerAthena*& Value) { Write<AFortPlayerControllerAthena*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalControllerPort(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerControllerPort(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalControllerPortActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LocalDeviceCableManager(const UFMDeviceCableManagerComponent*& Value) { Write<UFMDeviceCableManagerComponent*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerDeviceCableManager(const UFMDeviceCableManagerComponent*& Value) { Write<UFMDeviceCableManagerComponent*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_bFitIsEquipped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x940
class UFMDeviceCableModulatorPortComponent : public UFMDeviceCablePortComponent
{
public:
    FString AssociatedProperty() const { return Read<FString>(uintptr_t(this) + 0x920); } // 0x920 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<UObject*> AssociatedObject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x930); } // 0x930 (Size: 0x8, Type: WeakObjectProperty)

    void SET_AssociatedProperty(const FString& Value) { Write<FString>(uintptr_t(this) + 0x920, Value); } // 0x920 (Size: 0x10, Type: StrProperty)
    void SET_AssociatedObject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x930, Value); } // 0x930 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x920
class UFMDeviceCablePortComponent : public UStaticMeshComponent
{
public:
    UClass* DeviceCableManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UStaticMesh> OutputStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> AudioInStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> NoteInStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> TextureInStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> MeshInStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x788); } // 0x788 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> ScalarInStaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x20, Type: SoftObjectProperty)
    TMap<EDeviceCablePortDataType, UClass*> CableAnimatorClasses() const { return Read<TMap<EDeviceCablePortDataType, UClass*>>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x50, Type: MapProperty)
    uint8_t PortFlowType() const { return Read<uint8_t>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0x1, Type: EnumProperty)
    uint8_t PortDataType() const { return Read<uint8_t>(uintptr_t(this) + 0x819); } // 0x819 (Size: 0x1, Type: EnumProperty)
    uint8_t PortLoadableState() const { return Read<uint8_t>(uintptr_t(this) + 0x81a); } // 0x81a (Size: 0x1, Type: EnumProperty)
    uint8_t AnimationSyncType() const { return Read<uint8_t>(uintptr_t(this) + 0x81b); } // 0x81b (Size: 0x1, Type: EnumProperty)
    bool bAllowMultipleConnections() const { return Read<bool>(uintptr_t(this) + 0x81c); } // 0x81c (Size: 0x1, Type: BoolProperty)
    bool bAllowSiblingConnections() const { return Read<bool>(uintptr_t(this) + 0x81d); } // 0x81d (Size: 0x1, Type: BoolProperty)
    uint8_t OverrideAllowMultipleConnections() const { return Read<uint8_t>(uintptr_t(this) + 0x81e); } // 0x81e (Size: 0x1, Type: EnumProperty)
    uint8_t OverrideAllowSiblingConnections() const { return Read<uint8_t>(uintptr_t(this) + 0x81f); } // 0x81f (Size: 0x1, Type: EnumProperty)
    bool bHideWhenNotRelevant() const { return Read<bool>(uintptr_t(this) + 0x820); } // 0x820 (Size: 0x1, Type: BoolProperty)
    bool bIsPlayerPort() const { return Read<bool>(uintptr_t(this) + 0x821); } // 0x821 (Size: 0x1, Type: BoolProperty)
    bool bIsOnPreviewBuildingActor() const { return Read<bool>(uintptr_t(this) + 0x822); } // 0x822 (Size: 0x1, Type: BoolProperty)
    FName EnterVolumeTag() const { return Read<FName>(uintptr_t(this) + 0x824); } // 0x824 (Size: 0x4, Type: NameProperty)
    FName ExitVolumeTag() const { return Read<FName>(uintptr_t(this) + 0x828); } // 0x828 (Size: 0x4, Type: NameProperty)
    TArray<UFMDeviceCablePortComponent*> ConnectedPorts() const { return Read<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x10, Type: ArrayProperty)
    TArray<UFMDeviceCablePortComponent*> ServerConnectedPorts() const { return Read<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x10, Type: ArrayProperty)
    TArray<UFMDeviceCableConnectionBase*> CurrentConnections() const { return Read<TArray<UFMDeviceCableConnectionBase*>>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x10, Type: ArrayProperty)
    AFMDeviceCable* ConstantCable() const { return Read<AFMDeviceCable*>(uintptr_t(this) + 0x860); } // 0x860 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCableManagerComponent* DeviceCableManager() const { return Read<UFMDeviceCableManagerComponent*>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x8, Type: ObjectProperty)
    TArray<UFMDeviceCablePortComponent*> OtherPortsOnActor() const { return Read<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x10, Type: ArrayProperty)
    uint8_t PortActivatedState() const { return Read<uint8_t>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x1, Type: EnumProperty)
    uint8_t ServerPortActivatedState() const { return Read<uint8_t>(uintptr_t(this) + 0x881); } // 0x881 (Size: 0x1, Type: EnumProperty)
    uint8_t PortSelectableState() const { return Read<uint8_t>(uintptr_t(this) + 0x882); } // 0x882 (Size: 0x1, Type: EnumProperty)
    UFMDeviceCableAnimatorBase* DeviceCableAnimator() const { return Read<UFMDeviceCableAnimatorBase*>(uintptr_t(this) + 0x888); } // 0x888 (Size: 0x8, Type: ObjectProperty)
    FGuid ConnectionGuid() const { return Read<FGuid>(uintptr_t(this) + 0x890); } // 0x890 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> ConnectedGuids() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x10, Type: ArrayProperty)
    FFMDeviceCableArtifact CachedArtifact() const { return Read<FFMDeviceCableArtifact>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x20, Type: StructProperty)
    TArray<UFMDeviceCablePortComponent*> PendingConnectionBroadcasts() const { return Read<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x8e0); } // 0x8e0 (Size: 0x10, Type: ArrayProperty)
    FGuid SaveGuid() const { return Read<FGuid>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x10, Type: StructProperty)

    void SET_DeviceCableManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x8, Type: ClassProperty)
    void SET_OutputStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AudioInStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x20, Type: SoftObjectProperty)
    void SET_NoteInStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TextureInStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MeshInStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x788, Value); } // 0x788 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ScalarInStaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CableAnimatorClasses(const TMap<EDeviceCablePortDataType, UClass*>& Value) { Write<TMap<EDeviceCablePortDataType, UClass*>>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x50, Type: MapProperty)
    void SET_PortFlowType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0x1, Type: EnumProperty)
    void SET_PortDataType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x819, Value); } // 0x819 (Size: 0x1, Type: EnumProperty)
    void SET_PortLoadableState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81a, Value); } // 0x81a (Size: 0x1, Type: EnumProperty)
    void SET_AnimationSyncType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81b, Value); } // 0x81b (Size: 0x1, Type: EnumProperty)
    void SET_bAllowMultipleConnections(const bool& Value) { Write<bool>(uintptr_t(this) + 0x81c, Value); } // 0x81c (Size: 0x1, Type: BoolProperty)
    void SET_bAllowSiblingConnections(const bool& Value) { Write<bool>(uintptr_t(this) + 0x81d, Value); } // 0x81d (Size: 0x1, Type: BoolProperty)
    void SET_OverrideAllowMultipleConnections(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81e, Value); } // 0x81e (Size: 0x1, Type: EnumProperty)
    void SET_OverrideAllowSiblingConnections(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81f, Value); } // 0x81f (Size: 0x1, Type: EnumProperty)
    void SET_bHideWhenNotRelevant(const bool& Value) { Write<bool>(uintptr_t(this) + 0x820, Value); } // 0x820 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPlayerPort(const bool& Value) { Write<bool>(uintptr_t(this) + 0x821, Value); } // 0x821 (Size: 0x1, Type: BoolProperty)
    void SET_bIsOnPreviewBuildingActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x822, Value); } // 0x822 (Size: 0x1, Type: BoolProperty)
    void SET_EnterVolumeTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x824, Value); } // 0x824 (Size: 0x4, Type: NameProperty)
    void SET_ExitVolumeTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x828, Value); } // 0x828 (Size: 0x4, Type: NameProperty)
    void SET_ConnectedPorts(const TArray<UFMDeviceCablePortComponent*>& Value) { Write<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerConnectedPorts(const TArray<UFMDeviceCablePortComponent*>& Value) { Write<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentConnections(const TArray<UFMDeviceCableConnectionBase*>& Value) { Write<TArray<UFMDeviceCableConnectionBase*>>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x10, Type: ArrayProperty)
    void SET_ConstantCable(const AFMDeviceCable*& Value) { Write<AFMDeviceCable*>(uintptr_t(this) + 0x860, Value); } // 0x860 (Size: 0x8, Type: ObjectProperty)
    void SET_DeviceCableManager(const UFMDeviceCableManagerComponent*& Value) { Write<UFMDeviceCableManagerComponent*>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherPortsOnActor(const TArray<UFMDeviceCablePortComponent*>& Value) { Write<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x10, Type: ArrayProperty)
    void SET_PortActivatedState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x1, Type: EnumProperty)
    void SET_ServerPortActivatedState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x881, Value); } // 0x881 (Size: 0x1, Type: EnumProperty)
    void SET_PortSelectableState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x882, Value); } // 0x882 (Size: 0x1, Type: EnumProperty)
    void SET_DeviceCableAnimator(const UFMDeviceCableAnimatorBase*& Value) { Write<UFMDeviceCableAnimatorBase*>(uintptr_t(this) + 0x888, Value); } // 0x888 (Size: 0x8, Type: ObjectProperty)
    void SET_ConnectionGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x890, Value); } // 0x890 (Size: 0x10, Type: StructProperty)
    void SET_ConnectedGuids(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedArtifact(const FFMDeviceCableArtifact& Value) { Write<FFMDeviceCableArtifact>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x20, Type: StructProperty)
    void SET_PendingConnectionBroadcasts(const TArray<UFMDeviceCablePortComponent*>& Value) { Write<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x8e0, Value); } // 0x8e0 (Size: 0x10, Type: ArrayProperty)
    void SET_SaveGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
class UFMDeviceCablesFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x2a8
class AFMDeviceCableSystem : public AActor
{
public:
};

// Size: 0x578
class UFMDeviceCableWildcardOrderingComponent : public UActorComponent
{
public:
    FFMDeviceCableOrderingMovementInfo InputsShowHideMovementInfo() const { return Read<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x30, Type: StructProperty)
    FFMDeviceCableOrderingMovementInfo InOutMovementInfo() const { return Read<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x30, Type: StructProperty)
    FFMDeviceCableOrderingMovementInfo TransitionMovementInfo() const { return Read<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x30, Type: StructProperty)
    FFMDeviceCableOrderingMovementInfo CollapseExpandMovementInfo() const { return Read<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x30, Type: StructProperty)
    FVector CollapsedOutputPosition() const { return Read<FVector>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x18, Type: StructProperty)
    float VisualChangeTimeoutTime() const { return Read<float>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    FName ClosedMeshTag() const { return Read<FName>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: NameProperty)
    FName TopMeshTag() const { return Read<FName>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x4, Type: NameProperty)
    FName MiddleMeshTag() const { return Read<FName>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: NameProperty)
    FName BottomMeshTag() const { return Read<FName>(uintptr_t(this) + 0x3d4); } // 0x3d4 (Size: 0x4, Type: NameProperty)
    FName InputPortParentTag() const { return Read<FName>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: NameProperty)
    UStaticMeshComponent* ClosedMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* TopMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    TArray<UStaticMeshComponent*> MiddleMeshes() const { return Read<TArray<UStaticMeshComponent*>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    UStaticMeshComponent* BottomMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    TArray<UFMDeviceCableWildcardPortComponent*> InputWildcardPorts() const { return Read<TArray<UFMDeviceCableWildcardPortComponent*>>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x10, Type: ArrayProperty)
    USceneComponent* InputWildcardPortParent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    TArray<UFMDeviceCableWildcardPortComponent*> OutputWildcardPorts() const { return Read<TArray<UFMDeviceCableWildcardPortComponent*>>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x10, Type: ArrayProperty)
    TArray<FFMDeviceCableOrderingPortState> ServerPortStates() const { return Read<TArray<FFMDeviceCableOrderingPortState>>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x10, Type: ArrayProperty)

    void SET_InputsShowHideMovementInfo(const FFMDeviceCableOrderingMovementInfo& Value) { Write<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x30, Type: StructProperty)
    void SET_InOutMovementInfo(const FFMDeviceCableOrderingMovementInfo& Value) { Write<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x30, Type: StructProperty)
    void SET_TransitionMovementInfo(const FFMDeviceCableOrderingMovementInfo& Value) { Write<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x30, Type: StructProperty)
    void SET_CollapseExpandMovementInfo(const FFMDeviceCableOrderingMovementInfo& Value) { Write<FFMDeviceCableOrderingMovementInfo>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x30, Type: StructProperty)
    void SET_CollapsedOutputPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x18, Type: StructProperty)
    void SET_VisualChangeTimeoutTime(const float& Value) { Write<float>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    void SET_ClosedMeshTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: NameProperty)
    void SET_TopMeshTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x4, Type: NameProperty)
    void SET_MiddleMeshTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: NameProperty)
    void SET_BottomMeshTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3d4, Value); } // 0x3d4 (Size: 0x4, Type: NameProperty)
    void SET_InputPortParentTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: NameProperty)
    void SET_ClosedMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_TopMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_MiddleMeshes(const TArray<UStaticMeshComponent*>& Value) { Write<TArray<UStaticMeshComponent*>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    void SET_BottomMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_InputWildcardPorts(const TArray<UFMDeviceCableWildcardPortComponent*>& Value) { Write<TArray<UFMDeviceCableWildcardPortComponent*>>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x10, Type: ArrayProperty)
    void SET_InputWildcardPortParent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    void SET_OutputWildcardPorts(const TArray<UFMDeviceCableWildcardPortComponent*>& Value) { Write<TArray<UFMDeviceCableWildcardPortComponent*>>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerPortStates(const TArray<FFMDeviceCableOrderingPortState>& Value) { Write<TArray<FFMDeviceCableOrderingPortState>>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x960
class UFMDeviceCableWildcardPortComponent : public UFMDeviceCablePortComponent
{
public:
    int32_t SlotIndex() const { return Read<int32_t>(uintptr_t(this) + 0x940); } // 0x940 (Size: 0x4, Type: IntProperty)
    int32_t SavedSlotIndex() const { return Read<int32_t>(uintptr_t(this) + 0x944); } // 0x944 (Size: 0x4, Type: IntProperty)
    uint8_t SavedPortDataType() const { return Read<uint8_t>(uintptr_t(this) + 0x948); } // 0x948 (Size: 0x1, Type: EnumProperty)

    void SET_SlotIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x940, Value); } // 0x940 (Size: 0x4, Type: IntProperty)
    void SET_SavedSlotIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x944, Value); } // 0x944 (Size: 0x4, Type: IntProperty)
    void SET_SavedPortDataType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x948, Value); } // 0x948 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x320
class UFMDeviceCableManagerComponent : public UActorComponent
{
public:
    UClass* DeviceCableClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    int32_t StartingCablePoolSize() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)
    uint8_t CableInteractionType() const { return Read<uint8_t>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: EnumProperty)
    TMap<EDeviceCablePortDataType, UClass*> ConnectionClasses() const { return Read<TMap<EDeviceCablePortDataType, UClass*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)
    FGameplayEventListenerBackwardCompatibleHandle PlayerEnteredHandle() const { return Read<FGameplayEventListenerBackwardCompatibleHandle>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x48, Type: StructProperty)
    TArray<AFMDeviceCable*> FreeDeviceCables() const { return Read<TArray<AFMDeviceCable*>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: ArrayProperty)
    TMap<EDeviceCablePortDataType, UFMDeviceCableConnectionBase*> CableConnectionsByType() const { return Read<TMap<EDeviceCablePortDataType, UFMDeviceCableConnectionBase*>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x50, Type: MapProperty)
    TMap<FGuid, TWeakObjectPtr<UFMDeviceCablePortComponent*>> PortsInVolume() const { return Read<TMap<FGuid, TWeakObjectPtr<UFMDeviceCablePortComponent*>>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x50, Type: MapProperty)
    TMap<FGuid, FGuid> OriginalGuidToDuplicatedGuidThisFrame() const { return Read<TMap<FGuid, FGuid>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<AFMDeviceCable*>> CablesToBeNotifiedOfVisualPermissions() const { return Read<TArray<TWeakObjectPtr<AFMDeviceCable*>>>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    bool bVisualPermissionsAlreadyEstablished() const { return Read<bool>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x1, Type: BoolProperty)
    bool bUnregisterWithSignificanceSystem() const { return Read<bool>(uintptr_t(this) + 0x319); } // 0x319 (Size: 0x1, Type: BoolProperty)

    void SET_DeviceCableClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_StartingCablePoolSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
    void SET_CableInteractionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: EnumProperty)
    void SET_ConnectionClasses(const TMap<EDeviceCablePortDataType, UClass*>& Value) { Write<TMap<EDeviceCablePortDataType, UClass*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
    void SET_PlayerEnteredHandle(const FGameplayEventListenerBackwardCompatibleHandle& Value) { Write<FGameplayEventListenerBackwardCompatibleHandle>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x48, Type: StructProperty)
    void SET_FreeDeviceCables(const TArray<AFMDeviceCable*>& Value) { Write<TArray<AFMDeviceCable*>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: ArrayProperty)
    void SET_CableConnectionsByType(const TMap<EDeviceCablePortDataType, UFMDeviceCableConnectionBase*>& Value) { Write<TMap<EDeviceCablePortDataType, UFMDeviceCableConnectionBase*>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x50, Type: MapProperty)
    void SET_PortsInVolume(const TMap<FGuid, TWeakObjectPtr<UFMDeviceCablePortComponent*>>& Value) { Write<TMap<FGuid, TWeakObjectPtr<UFMDeviceCablePortComponent*>>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x50, Type: MapProperty)
    void SET_OriginalGuidToDuplicatedGuidThisFrame(const TMap<FGuid, FGuid>& Value) { Write<TMap<FGuid, FGuid>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x50, Type: MapProperty)
    void SET_CablesToBeNotifiedOfVisualPermissions(const TArray<TWeakObjectPtr<AFMDeviceCable*>>& Value) { Write<TArray<TWeakObjectPtr<AFMDeviceCable*>>>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    void SET_bVisualPermissionsAlreadyEstablished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x1, Type: BoolProperty)
    void SET_bUnregisterWithSignificanceSystem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x319, Value); } // 0x319 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FPortUpdateInfo
{
public:
    uint8_t PortSelectStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    UFMDeviceCablePortComponent* ConstantPort() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ConnectedPort() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* DisconnectedPort() const { return Read<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_PortSelectStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ConstantPort(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ConnectedPort(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_DisconnectedPort(const UFMDeviceCablePortComponent*& Value) { Write<UFMDeviceCablePortComponent*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFMDeviceCableArtifact
{
public:
    UFabricMeshTreeNode* MeshTreeNode() const { return Read<UFabricMeshTreeNode*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundTreeNode* MetaSoundTreeNode() const { return Read<UFabricMetaSoundTreeNode*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFabricTextureTreeNode* TextureTreeNode() const { return Read<UFabricTextureTreeNode*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UFabricModulationNode* ModulationNode() const { return Read<UFabricModulationNode*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_MeshTreeNode(const UFabricMeshTreeNode*& Value) { Write<UFabricMeshTreeNode*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MetaSoundTreeNode(const UFabricMetaSoundTreeNode*& Value) { Write<UFabricMetaSoundTreeNode*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_TextureTreeNode(const UFabricTextureTreeNode*& Value) { Write<UFabricTextureTreeNode*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ModulationNode(const UFabricModulationNode*& Value) { Write<UFabricModulationNode*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FModulatorPortSaveData
{
public:
    FGuid ConnectionGuid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> ConnectedGuids() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ConnectionGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_ConnectedGuids(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FFMDeviceCableOrderingMovementInfo
{
public:
    UCurveFloat* Curve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UCurveVector* ScaleCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector Vector() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    float MovementTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_Curve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ScaleCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Vector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MovementTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb8
struct FFMDeviceCableOrderingMovementState
{
public:
};

// Size: 0x270
struct FFMDeviceCableOrderingPortState
{
public:
    UFMDeviceCableWildcardPortComponent* WildcardPort() const { return Read<UFMDeviceCableWildcardPortComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* VerticalPositionParent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    int32_t Slot() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t TargetSlot() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UFMDeviceCableWildcardOrderingComponent*> Owner() const { return Read<TWeakObjectPtr<UFMDeviceCableWildcardOrderingComponent*>>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: WeakObjectProperty)

    void SET_WildcardPort(const UFMDeviceCableWildcardPortComponent*& Value) { Write<UFMDeviceCableWildcardPortComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_VerticalPositionParent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Slot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_TargetSlot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_Owner(const TWeakObjectPtr<UFMDeviceCableWildcardOrderingComponent*>& Value) { Write<TWeakObjectPtr<UFMDeviceCableWildcardOrderingComponent*>>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: WeakObjectProperty)
};

