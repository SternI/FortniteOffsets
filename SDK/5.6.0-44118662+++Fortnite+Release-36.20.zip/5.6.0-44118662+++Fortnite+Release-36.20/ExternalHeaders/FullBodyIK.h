/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FullBodyIK
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "ControlRig.h"

// Size: 0x20
struct FFBIKBoneLimit
{
public:
    uint8_t LimitType_X() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LimitType_Y() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t LimitType_Z() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    FVector Limit() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_LimitType_X(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_LimitType_Y(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_LimitType_Z(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_Limit(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FFBIKConstraintOption
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bUseStiffness() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    FVector LinearStiffness() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector AngularStiffness() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    bool bUseAngularLimit() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    FFBIKBoneLimit AngularLimit() const { return Read<FFBIKBoneLimit>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    bool bUsePoleVector() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t PoleVectorOption() const { return Read<uint8_t>(uintptr_t(this) + 0x69); } // 0x69 (Size: 0x1, Type: EnumProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FRotator OffsetRotation() const { return Read<FRotator>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bUseStiffness(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_LinearStiffness(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_AngularStiffness(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_bUseAngularLimit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_AngularLimit(const FFBIKBoneLimit& Value) { Write<FFBIKBoneLimit>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_bUsePoleVector(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_PoleVectorOption(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x69, Value); } // 0x69 (Size: 0x1, Type: EnumProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_OffsetRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0x2
struct FMotionProcessInput
{
public:
    bool bForceEffectorRotationTarget() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bOnlyApplyWhenReachedToTarget() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_bForceEffectorRotationTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlyApplyWhenReachedToTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FFBIKDebugOption
{
public:
    bool bDrawDebugHierarchy() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bColorAngularMotionStrength() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bColorLinearMotionStrength() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugAxes() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugEffector() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugConstraints() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    FTransform DrawWorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    float DrawSize() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)

    void SET_bDrawDebugHierarchy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bColorAngularMotionStrength(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bColorLinearMotionStrength(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawDebugAxes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawDebugEffector(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawDebugConstraints(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_DrawWorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_DrawSize(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x24
struct FSolverInput
{
public:
    float LinearMotionStrength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinLinearMotionStrength() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float AngularMotionStrength() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinAngularMotionStrength() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float DefaultTargetClamp() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Damping() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    bool bUseJacobianTranspose() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_LinearMotionStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MinLinearMotionStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_AngularMotionStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinAngularMotionStrength(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_DefaultTargetClamp(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Damping(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_bUseJacobianTranspose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
struct FFBIKEndEffector
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float PositionAlpha() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    int32_t PositionDepth() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    float RotationAlpha() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    int32_t RotationDepth() const { return Read<int32_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: IntProperty)
    float Pull() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_PositionAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_PositionDepth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_RotationAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_RotationDepth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: IntProperty)
    void SET_Pull(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x198
struct FRigUnit_FullbodyIK_WorkData
{
public:
};

// Size: 0x280
struct FRigUnit_FullbodyIK : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Root() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FFBIKEndEffector> Effectors() const { return Read<TArray<FFBIKEndEffector>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FFBIKConstraintOption> Constraints() const { return Read<TArray<FFBIKConstraintOption>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FSolverInput SolverProperty() const { return Read<FSolverInput>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x24, Type: StructProperty)
    FMotionProcessInput MotionProperty() const { return Read<FMotionProcessInput>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x2, Type: StructProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x5e); } // 0x5e (Size: 0x1, Type: BoolProperty)
    FFBIKDebugOption DebugOption() const { return Read<FFBIKDebugOption>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x80, Type: StructProperty)
    FRigUnit_FullbodyIK_WorkData WorkData() const { return Read<FRigUnit_FullbodyIK_WorkData>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x198, Type: StructProperty)

    void SET_Root(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Effectors(const TArray<FFBIKEndEffector>& Value) { Write<TArray<FFBIKEndEffector>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Constraints(const TArray<FFBIKConstraintOption>& Value) { Write<TArray<FFBIKConstraintOption>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_SolverProperty(const FSolverInput& Value) { Write<FSolverInput>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x24, Type: StructProperty)
    void SET_MotionProperty(const FMotionProcessInput& Value) { Write<FMotionProcessInput>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x2, Type: StructProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5e, Value); } // 0x5e (Size: 0x1, Type: BoolProperty)
    void SET_DebugOption(const FFBIKDebugOption& Value) { Write<FFBIKDebugOption>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x80, Type: StructProperty)
    void SET_WorkData(const FRigUnit_FullbodyIK_WorkData& Value) { Write<FRigUnit_FullbodyIK_WorkData>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x198, Type: StructProperty)
};

