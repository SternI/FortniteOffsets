#pragma once

// Dumped By Stern

enum EAutomationEventType : uint8_t
{
    EAutomationEventType__Info = 0,
    EAutomationEventType__Warning = 1,
    EAutomationEventType__Error = 2
};

enum ERangeBoundTypes : uint8_t
{
    ERangeBoundTypes__Exclusive = 0,
    ERangeBoundTypes__Inclusive = 1,
    ERangeBoundTypes__Open = 2
};

enum EInterpCurveMode : uint8_t
{
    CIM_Linear = 0,
    CIM_CurveAuto = 1,
    CIM_Constant = 2,
    CIM_CurveUser = 3,
    CIM_CurveBreak = 4,
    CIM_CurveAutoClamped = 5
};

enum EInputDeviceConnectionState : uint8_t
{
    EInputDeviceConnectionState__Invalid = 0,
    EInputDeviceConnectionState__Unknown = 1,
    EInputDeviceConnectionState__Disconnected = 2,
    EInputDeviceConnectionState__Connected = 3
};

enum ELocalizedTextSourceCategory : uint8_t
{
    ELocalizedTextSourceCategory__Game = 0,
    ELocalizedTextSourceCategory__Engine = 1,
    ELocalizedTextSourceCategory__Editor = 2
};

enum ETextGender : uint8_t
{
    ETextGender__Masculine = 0,
    ETextGender__Feminine = 1,
    ETextGender__Neuter = 2
};

enum EFormatArgumentType : uint8_t
{
    EFormatArgumentType__Int = 0,
    EFormatArgumentType__UInt = 1,
    EFormatArgumentType__Float = 2,
    EFormatArgumentType__Double = 3,
    EFormatArgumentType__Text = 4,
    EFormatArgumentType__Gender = 5
};

enum EAnimDataModelNotifyType : uint8_t
{
    EAnimDataModelNotifyType__BracketOpened = 0,
    EAnimDataModelNotifyType__BracketClosed = 1,
    EAnimDataModelNotifyType__TrackAdded = 2,
    EAnimDataModelNotifyType__TrackChanged = 3,
    EAnimDataModelNotifyType__TrackRemoved = 4,
    EAnimDataModelNotifyType__SequenceLengthChanged = 5,
    EAnimDataModelNotifyType__FrameRateChanged = 6,
    EAnimDataModelNotifyType__CurveAdded = 7,
    EAnimDataModelNotifyType__CurveChanged = 8,
    EAnimDataModelNotifyType__CurveRemoved = 9,
    EAnimDataModelNotifyType__CurveFlagsChanged = 10,
    EAnimDataModelNotifyType__CurveRenamed = 11,
    EAnimDataModelNotifyType__CurveScaled = 12,
    EAnimDataModelNotifyType__CurveColorChanged = 13,
    EAnimDataModelNotifyType__CurveCommentChanged = 14,
    EAnimDataModelNotifyType__AttributeAdded = 15
};

enum ETouchIndex : uint8_t
{
    ETouchIndex__Touch1 = 0,
    ETouchIndex__Touch2 = 1,
    ETouchIndex__Touch3 = 2,
    ETouchIndex__Touch4 = 3,
    ETouchIndex__Touch5 = 4,
    ETouchIndex__Touch6 = 5,
    ETouchIndex__Touch7 = 6,
    ETouchIndex__Touch8 = 7,
    ETouchIndex__Touch9 = 8,
    ETouchIndex__Touch10 = 9,
    ETouchIndex__CursorPointerIndex = 10,
    ETouchIndex__MAX_TOUCHES = 11
};

enum EMovementMode : uint8_t
{
    MOVE_None = 0,
    MOVE_Walking = 1,
    MOVE_NavWalking = 2,
    MOVE_Falling = 3,
    MOVE_Swimming = 4,
    MOVE_Flying = 5,
    MOVE_Custom = 6
};

enum EAudioComponentPlayState : uint8_t
{
    EAudioComponentPlayState__Playing = 0,
    EAudioComponentPlayState__Stopped = 1,
    EAudioComponentPlayState__Paused = 2,
    EAudioComponentPlayState__FadingIn = 3,
    EAudioComponentPlayState__FadingOut = 4,
    EAudioComponentPlayState__Count = 5
};

enum EDataLayerRuntimeState : uint8_t
{
    EDataLayerRuntimeState__Unloaded = 0,
    EDataLayerRuntimeState__Loaded = 1,
    EDataLayerRuntimeState__Activated = 2
};

enum EQuartzCommandDelegateSubType : uint8_t
{
    EQuartzCommandDelegateSubType__CommandOnFailedToQueue = 0,
    EQuartzCommandDelegateSubType__CommandOnQueued = 1,
    EQuartzCommandDelegateSubType__CommandOnCanceled = 2,
    EQuartzCommandDelegateSubType__CommandOnAboutToStart = 3,
    EQuartzCommandDelegateSubType__CommandOnStarted = 4,
    EQuartzCommandDelegateSubType__Count = 5
};

enum EQuartzCommandQuantization : uint8_t
{
    EQuartzCommandQuantization__Bar = 0,
    EQuartzCommandQuantization__Beat = 1,
    EQuartzCommandQuantization__ThirtySecondNote = 2,
    EQuartzCommandQuantization__SixteenthNote = 3,
    EQuartzCommandQuantization__EighthNote = 4,
    EQuartzCommandQuantization__QuarterNote = 5,
    EQuartzCommandQuantization__HalfNote = 6,
    EQuartzCommandQuantization__WholeNote = 7,
    EQuartzCommandQuantization__DottedSixteenthNote = 8,
    EQuartzCommandQuantization__DottedEighthNote = 9,
    EQuartzCommandQuantization__DottedQuarterNote = 10,
    EQuartzCommandQuantization__DottedHalfNote = 11,
    EQuartzCommandQuantization__DottedWholeNote = 12,
    EQuartzCommandQuantization__SixteenthNoteTriplet = 13,
    EQuartzCommandQuantization__EighthNoteTriplet = 14,
    EQuartzCommandQuantization__QuarterNoteTriplet = 15,
    EQuartzCommandQuantization__HalfNoteTriplet = 16,
    EQuartzCommandQuantization__Tick = 17,
    EQuartzCommandQuantization__Count = 18,
    EQuartzCommandQuantization__None = 19
};

enum EEndPlayReason : uint8_t
{
    EEndPlayReason__Destroyed = 0,
    EEndPlayReason__LevelTransition = 1,
    EEndPlayReason__EndPlayInEditor = 2,
    EEndPlayReason__RemovedFromWorld = 3,
    EEndPlayReason__Quit = 4
};

enum ETickingGroup : uint8_t
{
    TG_PrePhysics = 0,
    TG_StartPhysics = 1,
    TG_DuringP_____r = 2,
    TG_EndPhysics = 3,
    TG_PostPhysics = 4,
    TG_PostUpdateWork = 5,
    TG_LastDemotable = 6,
    TG_NewlySpawned = 7
};

enum EComponentCreationMethod : uint8_t
{
    EComponentCreationMethod__Native = 0,
    EComponentCreationMethod__SimpleConstructionScript = 1,
    EComponentCreationMethod__UserConstructionScript = 2,
    EComponentCreationMethod__Instance = 3
};

enum ETemperatureSeverityType : uint8_t
{
    ETemperatureSeverityType__Unknown = 0,
    ETemperatureSeverityType__Good = 1,
    ETemperatureSeverityType__Bad = 2,
    ETemperatureSeverityType__Serious = 3,
    ETemperatureSeverityType__Critical = 4,
    ETemperatureSeverityType__NumSeverities = 5
};

enum EPlaneConstraintAxisSetting : uint8_t
{
    EPlaneConstraintAxisSetting__Custom = 0,
    EPlaneConstraintAxisSetting__X = 1,
    EPlaneConstraintAxisSetting__Y = 2,
    EPlaneConstraintAxisSetting__Z = 3,
    EPlaneConstraintAxisSetting__UseGlobalPhysicsSetting = 4
};

enum EInterpToBehaviourType : uint8_t
{
    EInterpToBehaviourType__OneShot = 0,
    EInterpToBehaviourType__OneShot_Reverse = 1,
    EInterpToBehaviourType__Loop_Reset = 2,
    EInterpToBehaviourType__PingPong = 3
};

enum ETeleportType : uint8_t
{
    ETeleportType__None = 0,
    ETeleportType__TeleportPhysics = 1,
    ETeleportType__ResetPhysics = 2
};

enum EObjectTypeQuery : uint8_t
{
    ObjectTypeQuery1 = 0,
    ObjectTypeQuery2 = 1,
    ObjectTypeQuery3 = 2,
    ObjectTypeQuery4 = 3,
    ObjectTypeQuery5 = 4,
    ObjectTypeQuery6 = 5,
    ObjectTypeQuery7 = 6,
    ObjectTypeQuery8 = 7,
    ObjectTypeQuery9 = 8,
    ObjectTypeQuery10 = 9,
    ObjectTypeQuery11 = 10,
    ObjectTypeQuery12 = 11,
    ObjectTypeQuery13 = 12,
    ObjectTypeQuery14 = 13,
    ObjectTypeQuery15 = 14,
    ObjectTypeQuery16 = 15,
    ObjectTypeQuery17 = 16,
    ObjectTypeQuery18 = 17,
    ObjectTypeQuery19 = 18,
    ObjectTypeQuery20 = 19,
    ObjectType_f___At = 20,
    ObjectTypeQuery22 = 21,
    ObjectTypeQuery23 = 22,
    ObjectTypeQuery24 = 23,
    ObjectTypeQuery25 = 24,
    ObjectTypeQuery26 = 25,
    ObjectTypeQuery27 = 26,
    ObjectTypeQuery28 = 27,
    ObjectTypeQuery29 = 28,
    ObjectTypeQuery30 = 29,
    ObjectTypeQuery31 = 30,
    ObjectTypeQuery32 = 31
};

enum EDrawDebugTrace : uint8_t
{
    EDrawDebugTrace__None = 0,
    EDrawDebugTrace__ForOneFrame = 1,
    EDrawDebugTrace__ForDuration = 2,
    EDrawDebugTrace__Persistent = 3
};

enum ETraceTypeQuery : uint8_t
{
    TraceTypeQuery1 = 0,
    TraceTypeQuery2 = 1,
    TraceTypeQuery3 = 2,
    TraceTypeQuery4 = 3,
    TraceTypeQuery5 = 4,
    TraceTypeQuery6 = 5,
    TraceTypeQuery7 = 6,
    TraceTypeQuery8 = 7,
    TraceTypeQuery9 = 8,
    TraceTypeQuery10 = 9,
    TraceTypeQuery11 = 10,
    TraceTypeQuery12 = 11,
    TraceTypeQuery13 = 12,
    TraceTypeQuery14 = 13,
    TraceTypeQuery15 = 14,
    TraceTypeQuery16 = 15,
    TraceTypeQuery17 = 16,
    TraceTypeQuery18 = 17,
    TraceTypeQuery19 = 18,
    TraceTypeQuery20 = 19,
    TraceTypeQuery21 = 20,
    TraceTypeQuery22 = 21,
    TraceTypeQuery23 = 22,
    TraceTypeQuery24 = 23,
    TraceTypeQuery25 = 24,
    TraceTypeQuery26 = 25,
    TraceTypeQuery27 = 26,
    TraceTypeQuery28 = 27,
    TraceTypeQuery29 = 28,
    TraceTypeQuery30 = 29,
    TraceTypeQuery31 = 30,
    TraceTypeQuery32 = 31
};

enum EMoveComponentAction : uint8_t
{
    EMoveComponentAction__Move = 0,
    EMoveComponentAction__Stop = 1,
    EMoveComponentAction__Return = 2
};

enum ENetworkFailure : uint8_t
{
    ENetworkFailure__NetDriverAlreadyExists = 0,
    ENetworkFailure__NetDriverCreateFailure = 1,
    ENetworkFailure__NetDriverListenFailure = 2,
    ENetworkFailure__ConnectionLost = 3,
    ENetworkFailure__ConnectionTimeout = 4,
    ENetworkFailure__FailureReceived = 5,
    ENetworkFailure__OutdatedClient = 6,
    ENetworkFailure__OutdatedServer = 7,
    ENetworkFailure__PendingConnectionFailure = 8,
    ENetworkFailure__NetGuidMismatch = 9,
    ENetworkFailure__NetChecksumMismatch = 10
};

enum ETravelFailure : uint8_t
{
    ETravelFailure__NoLevel = 0,
    ETravelFailure__LoadMapFailure = 1,
    ETravelFailure__InvalidURL = 2,
    ETravelFailure__PackageMissing = 3,
    ETravelFailure__PackageVersion = 4,
    ETravelFailure__NoDownload = 5,
    ETravelFailure__TravelFailure = 6,
    ETravelFailure__CheatCommands = 7,
    ETravelFailure__PendingNetGameCreateFailure = 8,
    ETravelFailure__CloudSaveFailure = 9,
    ETrave__3___ = 10,
    ETravelFailure__ClientTravelFailure = 11
};

enum EApplicationState : uint8_t
{
    EApplicationState__Unknown = 0,
    EApplicationState__Inactive = 1,
    EApplicationState__Background = 2,
    EApplicationState__Active = 3
};

enum EScreenOrientation : uint8_t
{
    EScreenOrientation__Unknown = 0,
    EScreenOrientation__Portrait = 1,
    EScreenOrientation__PortraitUpsideDown = 2,
    EScreenOrientation__LandscapeLeft = 3,
    EScreenOrientation__LandscapeRight = 4,
    EScreenOrientation__FaceUp = 5,
    EScreenOrientation__FaceDown = 6,
    EScreenOrientation__PortraitSensor = 7,
    EScreenOrientation__LandscapeSensor = 8,
    EScreenOrientation__FullSensor = 9
};

enum EComponentPhysicsStateChange : uint8_t
{
    EComponentPhysicsStateChange__Created = 0,
    EComponentPhysicsStateChange__Destroyed = 1
};

enum ELifetimeCondition : uint8_t
{
    COND_None = 0,
    COND_InitialOnly = 1
};

enum ESearchCase : uint8_t
{
    ESearchCase__CaseSensitive = 0,
    ESearchCase__IgnoreCase = 1
};

enum ESearchDir : uint8_t
{
    ESearchDir__FromStart = 0,
    ESearchDir__FromEnd = 1
};

enum ELogTimes : uint8_t
{
    ELogTimes__None = 0,
    ELogTimes__UTC = 1,
    ELogTimes__SinceGStartTime = 2,
    ELogTimes__Local = 3
};

enum EAxis : uint8_t
{
    EAxis__None = 0,
    EAxis__X = 1,
    EAxis__Y = 2,
    EAxis__Z = 3
};

enum EAxisList : uint8_t
{
    EAxisList__None = 0,
    EAxisList__X = 1,
    EAxisList__Y = 2,
    EAxisList__Z = 4,
    EAxisList__Screen = 8,
    EAxisList__XY = 3,
    EAxisList__XZ = 5,
    EAxisList__YZ = 6,
    EAxisList__XYZ = 7,
    EAxisList__All = 15,
    EAxisList__ZRotation = 6,
    EAxisList__Rotate2D = 8
};

enum EPixelFormat : uint8_t
{
    PF_Unknown = 0,
    PF_A32B32G32R32F = 1,
    PF_B8G8R8A8 = 2,
    PF_G8 = 3,
    PF_G16 = 4,
    PF_DXT1 = 5,
    PF_DXT3 = 6,
    PF_DXT5 = 7,
    PF_UYVY = 8,
    PF_FloatRGB = 9,
    PF_FloatRGBA = 10,
    PF_DepthStencil = 11,
    PF_ShadowDepth = 12,
    PF_R32_FLOAT = 13,
    PF_G16R16 = 14,
    PF_G16R16F = 15,
    PF_G16R16F_FILTER = 16,
    PF_G32R32F = 17,
    PF_A2B10G10R10 = 18,
    PF_A16B16G16R16 = 19,
    PF_D24 = 20,
    PF_R16F = 21,
    PF_R16F_FILTER = 22,
    PF_BC5 = 23,
    PF_V8U8 = 24,
    PF_A1 = 25,
    PF_FloatR11G11B10 = 26,
    PF_A8 = 27,
    PF_R32_UINT = 28,
    PF_R32_SINT = 29,
    PF_PVRTC2 = 30,
    PF_PVRTC4 = 31,
    PF_R16_UINT = 32,
    PF_R16_SINT = 33,
    PF_R16G16B16A16_UINT = 34,
    PF_R16G16B16A16_SINT = 35,
    PF_R5G6B5_UNORM = 36,
    PF_R8G8B8A8 = 37,
    PF_A8R8G8B8 = 38,
    PF_BC4 = 39,
    PF_R8G8 = 40,
    PF_ATC_RGB = 41,
    PF_ATC_RGBA_E = 42,
    PF_ATC_RGBA_I = 43,
    PF_X24_G8 = 44,
    PF_ETC1 = 45,
    PF_ETC2_RGB = 46,
    PF_ETC2_RGBA = 47,
    PF_R32G32B32A32_UINT = 48,
    PF_R16G16_UINT = 49,
    PF_ASTC_4x4 = 50,
    PF_ASTC_6x6 = 51,
    PF_ASTC_8x8 = 52,
    PF_ASTC_10x10 = 53,
    PF_ASTC_12x12 = 54,
    PF_BC6H = 55,
    PF_BC7 = 56,
    PF_R8_UINT = 57,
    PF_L8 = 58,
    PF_XGXR8 = 59,
    PF_R8G8B8A8_UINT = 60,
    PF_R8G8B8A8_SNORM = 61,
    PF_R16G16B16A16_UNORM = 62,
    PF_R16G16B16A16_SNORM = 63,
    PF_PLATFORM_HDR = 64,
    PF_PLATFORM_HDR = 65,
    PF_PLATFORM_HDR = 66,
    PF_NV12 = 67,
    PF_R32G32_UINT = 68,
    PF_ETC2_R11_EAC = 69,
    PF_ETC2_RG11_EAC = 70,
    PF_R8 = 71,
    PF_B5G5R5A1_UNORM = 72,
    PF_ASTC_4x4_HDR = 73,
    PF_ASTC_6x6_HDR = 74,
    PF_ASTC_8x8_HDR = 75,
    PF_ASTC_10x10_HDR = 76,
    PF_ASTC_12x12_HDR = 77,
    PF_G16R16_SNORM = 78,
    PF_R8G8_UINT = 79,
    PF_R32G32B32_UINT = 80,
    PF_R32G32B32_SINT = 81,
    PF_R32G32B32F = 82,
    PF_R8_SINT = 83,
    PF_R64_UINT = 84,
    PF_R9G9B9EXP5 = 85,
    PF_P010 = 86,
    PF_ASTC_4x4_NORM_RG = 87,
    PF_ASTC_6x6_NORM_RG = 88,
    PF_ASTC_8x8_NORM_RG = 89,
    PF_ASTC_10x10_NORM_RG = 90,
    PF_ASTC_12x12_NORM_RG = 91,
    PF_R16G16_SINT = 92
};

enum EMouseCursor : uint8_t
{
    EMouseCursor__None = 0,
    EMouseCursor__Default = 1,
    EMouse_I__4_1_____np_l___i = 2,
    EMouseCursor__ResizeLeftRight = 3,
    EMouseCursor__ResizeUpDown = 4,
    EMouseCursor__ResizeSouthEast = 5,
    EMouseCursor__ResizeSouthWest = 6,
    EMouseCursor__CardinalCross = 7,
    EMouseCursor__Crosshairs = 8,
    EMouseCursor__Hand = 9,
    EMouseCursor__GrabHand = 10,
    EMouseCursor__GrabHandClosed = 11,
    EMouseCursor__SlashedCircle = 12,
    EMouseCursor__EyeDropper = 13,
    EMouseCursor__Custom = 14
};

enum EUnit : uint8_t
{
    EUnit__Micrometers = 0,
    EUnit__Millimeters = 1,
    EUnit__Centimeters = 2,
    EUnit__Meters = 3,
    EUnit__Kilometers = 4,
    EUnit__Inches = 5,
    EUnit__Feet = 6,
    EUnit__Yards = 7,
    EUnit__Miles = 8,
    EUnit__Lightyears = 9,
    EUnit__Degrees = 10,
    EUnit__Radians = 11,
    EUnit__CentimetersPerSecond = 12,
    EUnit__MetersPerSecond = 13,
    EUnit__KilometersPerHour = 14,
    EUnit__MilesPerHour = 15,
    EUnit__DegreesPerSecond = 16,
    EUnit__RadiansPerSecond = 17,
    EUnit__CentimetersPerSecondSquared = 18,
    EUnit__MetersPerSecondSquared = 19,
    EUnit__Celsius = 20,
    EUnit__Farenheit = 21,
    EUnit__Kelvin = 22,
    EUnit__Micrograms = 23,
    EUnit__Milligrams = 24,
    EUnit__Grams = 25,
    EUnit__Kilograms = 26,
    EUnit__MetricTons = 27,
    EUnit__Ounces = 28,
    EUnit__Pounds = 29,
    EUnit__Stones = 30,
    EUnit__GramsPerCubicCentimeter = 31,
    EUnit__GramsPerCubicMeter = 32,
    EUnit__KilogramsPerCubicCentimeter = 33,
    EUnit__KilogramsPerCubicMeter = 34,
    EUnit__Newtons = 35,
    EUnit__PoundsForce = 36,
    EUnit__KilogramsForce = 37,
    EUnit__KilogramCentimetersPerSecondSquared = 38,
    EUnit__NewtonMeters = 39
};

enum EPropertyAccessChangeNotifyMode : uint8_t
{
    EPropertyAccessChangeNotifyMode__Default = 0,
    EPropertyAccessChangeNotifyMode__Never = 1,
    EPropertyAccessChangeNotifyMode__Always = 2
};

enum EAppReturnType : uint8_t
{
    EAppReturnType__No = 0,
    EAppReturnType__Yes = 1,
    EAppReturnType__YesAll = 2,
    EAppReturnType__NoAll = 3,
    EAppReturnType__Cancel = 4,
    EAppReturnType__Ok = 5,
    EAppReturnType__Retry = 6,
    EAppReturnType__Continue = 7
};

enum EAppMsgType : uint8_t
{
    EAppMsgType__Ok = 0,
    EAppMsgType__YesNo = 1,
    EAppMsgType__OkCancel = 2,
    EAppMsgType__YesNoCancel = 3,
    EAppMsgType__CancelRetryContinue = 4,
    EAppMsgType__YesNoYesAllNoAll = 5,
    EAppMsgType__YesNoYesAllNoAllCancel = 6,
    EAppMsgType__YesNoYesAll = 7
};

enum EInputDeviceTriggerMask : uint8_t
{
    EInputDeviceTriggerMask__None = 0,
    EInputDeviceTriggerMask__Left = 1,
    EInputDeviceTriggerMask__Right = 2,
    EInputDeviceTriggerMask__All = 3
};

enum EInputDeviceAnalogStickMask : uint8_t
{
    EInputDeviceAnalogStickMask__None = 0,
    EInputDeviceAnalogStickMask__Left = 1,
    EInputDeviceAnalogStickMask__Right = 2
};

enum EDataValidationResult : uint8_t
{
    EDataValidationResult__Invalid = 0,
    EDataValidationResult__Valid = 1,
    EDataValidationResult__NotValidated = 2
};

enum ETestInstanceDataObjectBird : uint8_t
{
    TIDOB_None = 0,
    TIDOB_Cardinal = 1,
    TIDOB_Crow = 2,
    TIDOB_Eagle = 3,
    TIDOB_Hawk = 4,
    TIDOB_Owl = 5,
    TIDOB_Raven = 6
};

enum ETestInstanceDataObjectGrain : uint8_t
{
    ETestInstanceDataObjectGrain__None = 0,
    ETestInstanceDataObjectGrain__Barley = 1,
    ETestInstanceDataObjectGrain__Corn = 2,
    ETestInstanceDataObjectGrain__Quinoa = 3,
    ETestInstanceDataObjectGrain__Rice = 4,
    ETestInstanceDataObjectGrain__Wheat = 5
};

enum ETestInstanceDataObjectDirectionAlternate : uint8_t
{
    ETestInstanceDataObjectDirectionAlternate__None = 0,
    ETestInstanceDataObjectDirectionAlternate__Up = 1,
    ETestInstanceDataObjectDirectionAlternate__Down = 2,
    ETestInstanceDataObjectDirectionAlternate__North = 4,
    ETestInstanceDataObjectDirectionAlternate__East = 8,
    ETestInstanceDataObjectDirectionAlternate__South = 16,
    ETestInstanceDataObjectDirectionAlternate__West = 32
};

enum ETestInstanceDataObjectFullFlags : uint8_t
{
    ETestInstanceDataObjectFullFlags__None = 0,
    ETestInstanceDataObjectFullFlags__Flag0 = 1,
    ETestInstanceDataObjectFullFlags__Flag1 = 2,
    ETestInstanceDataObjectFullFlags__Flag2 = 4,
    ETestInstanceDataObjectFullFlags__Flag4 = 16,
    ETestInstanceDataObjectFullFlags__Flag5 = 32,
    ETestInstanceDataObjectFullFlags__Flag6 = 64,
    ETestInstanceDataObjectFullFlags__Flag7 = 128
};

enum EUserDefinedStructureStatus : uint8_t
{
    UDSS_UpToDate = 0,
    UDSS_Dirty = 1,
    UDSS_Error = 2,
    UDSS_Duplicate = 3
};

enum EVersePackageScope : uint8_t
{
    EVersePackageScope__PublicAPI = 0,
    EVersePackageScope__InternalAPI = 1,
    EVersePackageScope__PublicUser = 2,
    EVersePackageScope__InternalUser = 3
};

enum EVersePackageType : uint8_t
{
    EVersePackageType__VNI = 0,
    EVersePackageType__Content = 1,
    EVersePackageType__PublishedContent = 2,
    EVersePackageType__Assets = 3
};

enum EVerseEnumFlags : uint8_t
{
    EVerseEnumFlags__None = 0,
    EVerseEnumFlags__NativeBound = 1
};

enum EVerseFalse : uint8_t
{
    EVerseFalse__Value = 0
};

enum EVerseTrue : uint8_t
{
    EVerseTrue__Value = 0
};

enum EPropertyBagPropertyType : uint8_t
{
    EPropertyBagPropertyType__None = 0,
    EPropertyBagPropertyType__Bool = 1,
    EPropertyBagPropertyType__Byte = 2,
    EPropertyBagPropertyType__Int32 = 3,
    EPropertyBagPropertyType__Int64 = 4,
    EPropertyBagPropertyType__Float = 5,
    EPropertyBagPropertyType__Double = 6,
    EPropertyBagPropertyType__Name = 7,
    EPropertyBagPropertyType__String = 8,
    EPropertyBagPropertyType__Text = 9,
    EPropertyBagPropertyType__Enum = 10,
    EPropertyBagPropertyType__Struct = 11,
    EPropertyBagPropertyType__Object = 12,
    EPropertyBagPropertyType__SoftObject = 13,
    EPropertyBagPropertyType__Class = 14,
    EPropertyBagPropertyType__SoftClass = 15,
    EPropertyBagPropertyType__UInt32 = 16,
    EPropertyBagPropertyType__UInt64 = 17,
    EPropertyBagPropertyType__Count = 18
};

enum EPropertyBagContainerType : uint8_t
{
    EPropertyBagContainerType__None = 0,
    EPropertyBagContainerType__Array = 1,
    EPropertyBagContainerType__Set = 2,
    EPropertyBagContainerType__Count = 3
};

enum EPropertyBagMissingEnum : uint8_t
{
    EPropertyBagMissingEnum__Missing = 0
};

enum EVerseEffectSet : uint8_t
{
    EVerseEffectSet__None = 0,
    EVerseEffectO__A_ec_9____ = 1,
    EVerseEffectSet__Decides = 2,
    EVerseEffectSet__Diverges = 4,
    EVerseEffectSet__Reads = 8,
    EVerseEffectSet__Writes = 16,
    EVerseEffectSet__Allocates = 32,
    EVerseEffectSet__NoRollback = 64
};

enum ETransformConstraintType : uint8_t
{
    ETransformConstraintType__Translation = 0,
    ETransformConstraintType__Rotation = 1,
    ETransformConstraintType__Scale = 2,
    ETransformConstraintType__Parent = 3,
    ETransformConstraintType__LookAt = 4
};

enum EControllerHand : uint8_t
{
    EControllerHand__Left = 0,
    EControllerHand__Right = 1,
    EControllerHand__AnyHand = 2,
    EControllerHand__Pad = 3,
    EControllerHand__ExternalCamera = 4,
    EControllerHand__Gun = 5,
    EControllerHand__HMD = 6,
    EControllerHand__Chest = 7,
    EControllerHand__LeftShoulder = 8,
    EControllerHand__RightShoulder = 9,
    EControllerHand__LeftElbow = 10,
    EControllerHand__RightElbow = 11,
    EControllerHand__Waist = 12,
    EControllerHand__LeftKnee = 13,
    EControllerHand__RightKnee = 14,
    EControllerHand__LeftFoot = 15,
    EControllerHand__RightFoot = 16,
    EControllerHand__Special = 17,
    EControllerHand__ControllerHand_Count = 18
};

enum EConsoleForGamepadLabels : uint8_t
{
    EConsoleForGamepadLabels__None = 0,
    EConsoleForGamepadLabels__XBoxOne = 1,
    EConsoleForGamepadLabels__PS4 = 2
};

enum ETouchType : uint8_t
{
    ETouchType__Began = 0,
    ETouchType__Moved = 1,
    ETouchType__Stationary = 2,
    ETouchType__ForceChanged = 3,
    ETouchType__FirstMove = 4,
    ETouchType__Ended = 5,
    ETouchType__NumTypes = 6
};

enum EFontRasterizationMode : uint8_t
{
    EFontRasterizationMode__Bitmap = 0,
    EFontRasterizationMode__Msdf = 1,
    EFontRasterizationMode__Sdf = 2,
    EFontRasterizationMode__SdfApproximation = 3
};

enum EUINavigationRule : uint8_t
{
    EUINavigationRule__Escape = 0,
    EUINavigationRule__Explicit = 1,
    EUINavigationRule__Wrap = 2,
    EUINavigationRule__Stop = 3,
    EUINavigationRul__6______ = 4,
    EUINavigationRule__CustomBoundary = 5,
    EUINavigationRule__Invalid = 6
};

enum EButtonClickMethod : uint8_t
{
    EButtonClickMethod__DownAndUp = 0,
    EButtonClickMethod__MouseDown = 1,
    EButtonClickMethod__MouseUp = 2,
    EButtonClickMethod__PreciseClick = 3
};

enum EButtonTouchMethod : uint8_t
{
    EButtonTouchMethod__DownAndUp = 0,
    EButtonTouchMethod__Down = 1,
    EButtonTouchMethod__PreciseTap = 2
};

enum EButtonPressMethod : uint8_t
{
    EButtonPressMethod__DownAndUp = 0,
    EButtonPressMethod__ButtonPress = 1,
    EButtonPressMethod__ButtonRelease = 2
};

enum EUINavigation : uint8_t
{
    EUINavigation__Left = 0,
    EUINavigation__Right = 1,
    EUINavigation__Up = 2,
    EUINavigation__Down = 3,
    EUINavigation__Next = 4,
    EUINavigation__Previous = 5,
    EUINavigation__Num = 6,
    EUINavigation__Invalid = 7
};

enum EUINavigationAction : uint8_t
{
    EUINavigationAction__Accept = 0,
    EUINavigationAction__Back = 1,
    EUINavigationAction__Num = 2,
    EUINavigationAction__Il__N__ = 3
};

enum ENavigationGenesis : uint8_t
{
    ENavigationGenesis__Keyboard = 0,
    ENavigationGenesis__Controller = 1,
    ENavigationGenesis__User = 2
};

enum EHorizontalAlignment : uint8_t
{
    HAlign_Fill = 0,
    HAlign_Left = 1,
    HAlign_Center = 2,
    HAlign_Right = 3
};

enum EVerticalAlignment : uint8_t
{
    VAlign_Fill = 0,
    VAlign_Top = 1,
    VAlign_Center = 2,
    VAlign_Bottom = 3
};

enum EMenuPlacement : uint8_t
{
    MenuPlacement_BelowAnchor = 0,
    MenuPlacement_CenteredBelowAnchor = 1,
    MenuPlacement_BelowRightAnchor = 2,
    MenuPlacement_ComboBox = 3,
    MenuPlacement_ComboBoxRight = 4,
    MenuPlacement_MenuRight = 5,
    MenuPlacement_AboveAnchor = 6,
    MenuPlacement_CenteredAboveAnchor = 7,
    MenuPlacement_AboveRightAnchor = 8,
    MenuPlacement_MenuLeft = 9,
    MenuPlacement_Center = 10,
    MenuPlacement_RightLeftCenter = 11,
    MenuPlacement_MatchBottomLeft = 12
};

enum ETextCommit : uint8_t
{
    ETextCommit__Default = 0,
    ETextCommit__OnEnter = 1,
    ETextCommit__OnUserMovedFocus = 2,
    ETextCommit__OnCleared = 3
};

enum ESelectInfo : uint8_t
{
    ESelectInfo__OnKeyPress = 0,
    ESelectInfo__OnNavigation = 1,
    ESelectInfo__OnMouseClick = 2,
    ESelectInfo__Direct = 3
};

enum ESlatePostRT : uint8_t
{
    ESlatePostRT__None = 0,
    ESlatePostRT__ESlatePostRT = 1,
    ESlatePostRT__ESlatePostRT = 2,
    ESlatePostRT__ESlatePostRT = 4,
    ESlatePostRT__ESlatePostRT = 8,
    ESlatePostRT__ESlatePostRT = 16,
    ESlatePostRT__All = 31,
    ESlatePostRT__Num = 5
};

enum EWidgetPixelSnapping : uint8_t
{
    EWidgetPixelSnapping__Inherit = 0,
    EWidgetPixelSnapping__Disabled = 1,
    EWidgetPixelSnapping__SnapToPixel = 2
};

enum ESlateDebuggingFocusEvent : uint8_t
{
    ESlateDebuggingFocusEvent__FocusChanging = 0,
    ESlateDebuggingFocusEvent__FocusLost = 1,
    ESlateDebuggingFocusEvent__FocusReceived = 2
};

enum EFontLoadingPolicy : uint8_t
{
    EFontLoadingPolicy__LazyLoad = 0,
    EFontLoadingPolicy__Stream = 1,
    EFontLoadingPolicy__Inline = 2
};

enum ETextShapingMethod : uint8_t
{
    ETextShapingMethod__Auto = 0,
    ETextShapingMethod__KerningOnly = 1,
    ETextShapingMethod__FullShaping = 2
};

enum EFlowDirectionPreference : uint8_t
{
    EFlowDirectionPreference__Inherit = 0,
    EFlowDirectionPreference__Culture = 1,
    EFlowDirectionPreference__LeftToRight = 2,
    EFlowDirectionPreference__RightToLeft = 3
};

enum ESlateBrushDrawType : uint8_t
{
    ESlateBrushDrawType__NoDrawType = 0,
    ESlateBrushDrawType__Box = 1,
    ESlateBrushDrawType__Border = 2,
    ESlateBrushDrawType__Image = 3,
    ESlateBrushDrawType__RoundedBox = 4
};

enum ESlateBrushTileType : uint8_t
{
    ESlateBrushTileType__NoTile = 0,
    ESlateBrushTileType__Horizontal = 1,
    ESlateBrushTileType__Vertical = 2,
    ESlateBrushTileType__Both = 3
};

enum ESlateBrushMirrorType : uint8_t
{
    ESlateBrushMirrorType__NoMirror = 0,
    ESlateBrushMirrorType__Horizontal = 1,
    ESlateBrushMirrorType__Vertical = 2,
    ESlateBrushMirrorType__Both = 3
};

enum ESlateBrushImageType : uint8_t
{
    ESlateBrushImageType__NoImage = 0,
    ESlateBrushImageType__FullColor = 1,
    ESlateBrushImageType__Linear = 2,
    ESlateBrushImageType__Vector = 3
};

enum EConsumeMouseWheel : uint8_t
{
    EConsumeMouseWheel__WhenScrollingPossible = 0,
    EConsumeMouseWheel__Always = 1,
    EConsumeMouseWheel__Never = 2
};

enum ECheckBoxState : uint8_t
{
    ECheckBoxState__Unchecked = 0,
    ECheckBoxState__Checked = 1,
    ECheckBoxState__Undetermined = 2
};

enum ETextOverflowPolicy : uint8_t
{
    ETextOverflowPolicy__Clip = 0,
    ETextOverflowPolicy__Ellipsis = 1,
    ETextOverflowPolicy__MultilineEllipsis = 2,
    ETextOverflowPolicy__MiddleEllipsis = 3
};

enum ETextTransformPolicy : uint8_t
{
    ETextTransformPolicy__None = 0,
    ETextTransformPolicy__ToLower = 1,
    ETextTransformPolicy__ToUpper = 2
};

enum EStyleColor : uint8_t
{
    EStyleColor__Black = 0,
    EStyleColor__Background = 1,
    EStyleColor__Title = 2,
    EStyleColor__WindowBorder = 3,
    EStyleColor__Foldout = 4,
    EStyleColor__Input = 5,
    EStyleColor__InputOutline = 6,
    EStyleColor__Recessed = 7,
    EStyleColor__Panel = 8,
    EStyleColor__Header = 9,
    EStyleColor__Dropdown = 10,
    EStyleColor__DropdownOutline = 11,
    EStyleColor__Hover = 12,
    EStyleColor__Hover2 = 13,
    EStyleColor__White = 14,
    EStyleColor__White25 = 15,
    EStyleColor__Highlight = 16,
    EStyleColor__Primary = 17,
    EStyleColor__PrimaryHover = 18,
    EStyleColor__PrimaryPress = 19,
    EStyleColor__Secondary = 20,
    EStyleColor__Foreground = 21,
    EStyleColor__ForegroundHover = 22,
    EStyleColor__ForegroundInverted = 23,
    EStyleColor__ForegroundHeader = 24,
    EStyleColor__Select = 25,
    EStyleColor__SelectInactive = 26,
    EStyleColor__SelectParent = 27,
    EStyleColor__SelectHover = 28,
    EStyleColor__Notifications = 29,
    EStyleColor__AccentBlue = 30,
    EStyleColor__AccentPurple = 31,
    EStyleColor__AccentPink = 32,
    EStyleColor__AccentRed = 33,
    EStyleColor__AccentOrange = 34,
    EStyleColor__AccentYellow = 35,
    EStyleColor__AccentGreen = 36,
    EStyleColor__AccentBrown = 37,
    EStyleColor__AccentBlack = 38,
    EStyleColor__AccentGray = 39,
    EStyleColor__AccentWhite = 40,
    EStyleColor__AccentFolder = 41,
    EStyleColor__Warning = 42,
    EStyleColor__Error = 43,
    EStyleColor__Success = 44,
    EStyleColor__User1 = 45,
    EStyleColor__User2 = 46,
    EStyleColor__User3 = 47,
    EStyleColor__User4 = 48,
    EStyleColor__User5 = 49,
    EStyleColor__User6 = 50,
    EStyleColor__User7 = 51,
    EStyleColor__User8 = 52,
    EStyleColor__User9 = 53,
    EStyleColor__User10 = 54,
    EStyleColor__User11 = 55,
    EStyleColor__User12 = 56,
    EStyleColor__User13 = 57,
    EStyleColor__User14 = 58,
    EStyleColor__User15 = 59,
    EStyleColor__User16 = 60
};

enum EVirtualKeyboardDismissAction : uint8_t
{
    EVirtualKeyboardDismissAction__TextChangeOnDismiss = 0,
    EVirtualKeyboardDismissAction__TextCommitOnAccept = 1,
    EVirtualKeyboardDismissAction__TextCommitOnDismiss = 2
};

enum ESelectionMode : uint8_t
{
    ESelectionMode__None = 0,
    ESelectionMode__Single = 1,
    ESelectionMode__SingleToggle = 2,
    ESelectionMode__Multi = 3
};

enum ETableViewMode : uint8_t
{
    ETableViewMode__List = 0,
    ETableViewMode__Tile = 1,
    ETableViewMode__Tree = 2
};

enum EMultiBoxType : uint8_t
{
    EMultiBoxType__MenuBar = 0,
    EMultiBoxType__ToolBar = 1,
    EMultiBoxType__VerticalToolBar = 2,
    EMultiBoxType__SlimHorizontalToolBar = 3,
    EMultiBoxType__UniformToolBar = 4,
    EMultiBoxType__Menu = 5,
    EMultiBoxType__ButtonRow = 6,
    EMultiBoxType__SlimHorizontalUniformToolBar = 7
};

enum EMultiBlockType : uint8_t
{
    EMultiBlockType__None = 0,
    EMultiBlockType__ButtonRow = 1,
    EMultiBlockType__EditableText = 2,
    EMultiBlockType__Heading = 3,
    EMultiBlockType__MenuEntry = 4,
    EMultiBlockType__Separator = 5,
    EMultiBlockType__ToolBarButton = 6,
    EMultiBlockType__ToolBarComboButton = 7,
    EMultiBlockType__Widget = 8
};

enum EInputPreProcessorType : uint8_t
{
    EInputPreProcessorType__Overlay = 0,
    EInputPreProcessorType__PreEngine = 1,
    EInputPreProcessorType__Engine = 2,
    EInputPreProcessorType__PreEditor = 3,
    EInputPreProcessorType__Editor = 4,
    EInputPreProcessorType__PreGame = 5,
    EInputPreProcessorType__Game = 6,
    EInputPreProcessorType__Count = 7
};

enum EDescendantScrollDestination : uint8_t
{
    EDescendantScrollDestination__IntoView = 0,
    EDescendantScrollDestination__TopOrLeft = 1,
    EDescendantScrollDestinau____L_i__Cj = 2,
    EDescendantScrollDestination__BottomOrRight = 3
};

enum EScrollWhenFocusChanges : uint8_t
{
    EScrollWhenFocusChanges__NoScroll = 0,
    EScrollWhenFocusChanges__InstantScroll = 1,
    EScrollWhenFocusChanges__AnimatedScroll = 2
};

enum ECustomizedToolMenuVisibility : uint8_t
{
    ECustomizedToolMenuVisibility__None = 0,
    ECustomizedToolMenuVisibility__Visible = 1,
    ECustomizedToolMenuVisibility__Hidden = 2
};

enum EMultipleKeyBindingIndex : uint8_t
{
    EMultipleKeyBindingIndex__Primary = 0,
    EMultipleKeyBindingIndex__Secondary = 1,
    EMultipleKeyBindingIndex__NumChords = 2
};

enum ETextFlowDirection : uint8_t
{
    ETextFlowDirection__Auto = 0,
    ETextFlowDirection__LeftToRight = 1,
    ETextFlowDirection__RightToLeft = 2,
    ETextFlowDirection__Culture = 3
};

enum EStretchDirection : uint8_t
{
    EStretchDirection__Both = 0,
    EStretchDirection__DownOnly = 1,
    EStretchDirection__UpOnly = 2
};

enum EStretch : uint8_t
{
    EStretch__None = 0,
    EStretch__Fill = 1,
    EStretch__ScaleToFit = 2,
    EStretch__ScaleToFitX = 3,
    EStretch__ScaleToFitY = 4,
    EStretch__ScaleToFill = 5,
    EStretch__ScaleBySafeZone = 6,
    EStretch__UserSpecified = 7,
    EStretch__UserSpecifiedWithClipping = 8
};

enum EProgressBarFillType : uint8_t
{
    EProgressBarFillType__LeftToRight = 0,
    EProgressBarFillType__RightToLeft = 1,
    EProgressBarFillType__FillFromCenter = 2,
    EProgressBarFillType__FillFromCenterHorizontal = 3,
    EProgressBarFillType__FillFromCenterVertical = 4,
    EProgressBarFillType__TopToBottom = 5,
    EProgressBarFillType__BottomToTop = 6
};

enum EListItemAlignment : uint8_t
{
    EListItemAlignment__EvenlyDistributed = 0,
    EListItemAlignment__EvenlySize = 1,
    EListItemAlignment__EvenlyWide = 2,
    EListItemAlignment__LeftAligned = 3,
    EListItemAlignment__RightAligned = 4,
    EListItemAlignment__CenterAligned = 5,
    EListItemAlignment__Fill = 6
};

enum EScrollIntoViewAlignment : uint8_t
{
    EScrollIntoViewAlignment__IntoView = 0,
    EScrollIntoViewAlignment__TopOrLeft = 1,
    EScrollIntoViewAlignment__CenterAligned = 2,
    EScrollIntoViewAlignment__BottomOrRight = 3
};

enum EThreePlayerSplitScreenType : uint8_t
{
    EThreePlayerSplitScreenType__FavorTop = 0,
    EThreePlayerSplitScreenType__FavorBottom = 1,
    EThreePlayerSplitScreenType__Vertical = 2,
    EThreePlayerSplitScreenType__Horizontal = 3
};

enum EFourPlayerSplitScreenType : uint8_t
{
    EFourPlayerSplitScreenType__Grid = 0,
    EFourPlayerSplitScreenType__Vertical = 1,
    EFourPlayerSplitScreenType__Horizontal = 2
};

enum ENNEAttributeDataType : uint8_t
{
    ENNEAttributeDataType__None = 0,
    ENNEAttributeDataType__Float = 1,
    ENNEAttributeDataType__FloatArray = 2,
    ENNEAttributeDataType__Int32 = 3,
    ENNEAttributeDataType__Int32Array = 4,
    ENNEAttributeDataType__String = 5,
    ENNEAttributeDataType__StringArray = 6,
    ENNEAttributeDataType__Tensor = 7,
    ENNEAttributeDataType__TensorArray = 8
};

enum ENNEFormatTensorType : uint8_t
{
    ENNEFormatTensorType__None = 0,
    ENNEFormatTensorType__Input = 1,
    ENNEFormatTensorType__Output = 2,
    ENNEFormatTensorType__Intermediate = 3,
    ENNEFormatTensorType__Initializer = 4,
    ENNEFormatTensorType__Empty = 5,
    ENNEFormatTensorType__NUM = 6
};

enum ENNEInferenceFormat : uint8_t
{
    ENNEInferenceFormat__Invalid = 0,
    ENNEInferenceFormat__ONNX = 1,
    ENNEInferenceFormat__ORT = 2,
    ENNEInferenceFormat__NNERT = 3
};

enum ENNETensorDataType : uint8_t
{
    ENNETensorDataType__None = 0,
    ENNETensorDataType__Char = 1,
    ENNETensorDataType__Boolean = 2,
    ENNETensorDataType__Half = 3,
    ENNETensorDataType__Float = 4,
    ENNETensorDataType__Double = 5,
    ENNETensorDataType__Int8 = 6,
    ENNETensorDataType__Int16 = 7,
    ENNETensorDataType__Int32 = 8,
    ENNETensorDataType__Int64 = 9,
    ENNETensorDataType__UInt8 = 10,
    ENNETensorDataType__UInt16 = 11,
    ENNETensorDataType__UInt32 = 12,
    ENNETensorDataType__UInt64 = 13,
    ENNETensorDataType__Complex64 = 14,
    ENNETensorDataType__Complex128 = 15,
    ENNETensorDataType__BFloat16 = 16
};

enum ChaosDeformableSimSpace : uint8_t
{
    World = 0,
    ComponentXf = 1,
    bone = 2
};

enum ESetMaskConditionType : uint8_t
{
    Field_Set_Always = 0,
    Field_Set_IFF_NOT_Interior = 1,
    Field_Set_IFF_NOT_Exterior = 2,
    Field_MaskCondition_Max = 3
};

enum EWaveFunctionType : uint8_t
{
    Field_Wave_Cosine = 0,
    Field_Wave_Gaussian = 1,
    Field_Wave_Falloff = 2,
    Field_Wave_Decay = 3,
    Field_Wave_Max = 4
};

enum EFieldOperationType : uint8_t
{
    Field_Multiply = 0,
    Field_Divide = 1,
    Field_Add = 2,
    Field_Substract = 3,
    Field_Operation_Max = 4
};

enum EFieldCullingOperationType : uint8_t
{
    Field_Culling_Inside = 0,
    Field_Culling_Outside = 1,
    Field_Culling_Operation_Max = 2
};

enum EFieldResolutionType : uint8_t
{
    Field_Resolution_Minimal = 0,
    Field_Resolution_DisabledParents = 1,
    Field_Resolution_Maximum = 2,
    Field_Resolution_Max = 3
};

enum EFieldObjectType : uint8_t
{
    Field_Object_Rigid = 0,
    Field_Object_Cloth = 1,
    Field_Object_Destruction = 2,
    Field_Object_Character = 3,
    Field_Object_All = 4,
    Field__P________ = 5
};

enum EFieldFalloffType : uint8_t
{
    Field_FallOff_None = 0,
    Field_Falloff_Linear = 1,
    Field_Falloff_Inverse = 2,
    Field_Falloff_Squared = 3,
    Field_Falloff_Logarithmic = 4,
    Field_Falloff_Max = 5
};

enum EFieldPhysicsType : uint8_t
{
    Field_None = 0,
    Field_DynamicState = 1,
    Field_LinearForce = 2,
    Field_ExternalClusterStrain = 3,
    Field_Kill = 4,
    Field_LinearVelocity = 5,
    Field_AngularVelociy = 6,
    Field_AngularTorque = 7,
    Field_InternalClusterStrain = 8,
    Field_DisableThreshold = 9,
    Field_SleepingThreshold = 10,
    Field_PositionStatic = 11,
    Field_PositionAnimated = 12,
    Field_PositionTarget = 13,
    Field_DynamicConstraint = 14,
    Field_CollisionGroup = 15,
    Field_ActivateDisabled = 16,
    Field_InitialLinearVelocity = 17,
    Field_InitialAngularVelocity = 18,
    Field_LinearImpulse = 19,
    Field_PhysicsType_Max = 20
};

enum EFieldVectorType : uint8_t
{
    Vector_LinearForce = 0,
    Vector_LinearVelocity = 1,
    Vector_AngularVelocity = 2,
    Vector_AngularTorque = 3,
    Vector_PositionTarget = 4,
    Vector_InitialLinearVelocity = 5,
    Vector_InitialAngularVelocity = 6,
    Vector_LinearImpulse = 7,
    Vector_TargetMax = 8
};

enum EFieldScalarType : uint8_t
{
    Scalar_ExternalClusterStrain = 0,
    Scalar_Kill = 1,
    Scalar_DisableThreshold = 2,
    Scalar_SleepingThreshold = 3,
    Scalar_InternalClusterStrain = 4,
    Scalar_DynamicConstraint = 5,
    Scalar_TargetMax = 6
};

enum EFieldOutputType : uint8_t
{
    Field_Output_Vector = 0,
    Field_Output_Scalar = 1,
    Field_Output_Integer = 2,
    Field_Output_Max = 3
};

enum EConvexOverlapRemoval : uint8_t
{
    EConvexOverlapRemoval__None = 0,
    EConvexOverlapRemoval__All = 1,
    EConvexOverlapRemoval__OnlyClusters = 2,
    EConvexOverlapRemoval__OnlyClustersVsClusters = 3
};

enum EGenerateConvexMethod : uint8_t
{
    EGenerateConvexMethod__ExternalCollision = 0,
    EGenerateConvexMethod__ComputedFromGeometry = 1,
    EGenerateConvexMethod__IntersectExternalWithComputed = 2
};

enum EProximityContactMethod : uint8_t
{
    EProximityContactMethod__MinOverlapInProjectionToMajorAxes = 0,
    EProximityContactMethod__ConvexHullSharpContact = 1,
    EProximityContactMethod__ConvexHullAreaContact = 2
};

enum EObjectStateTypeEnum : uint8_t
{
    EObjectStateTypeEnum__Chaos_NONE = 0,
    EObjectStateTypeEnum__Chaos_Object_Sleeping = 1,
    EObjectStateTypeEnum__Chaos_Object_Kinematic = 2,
    EObjectStateTypeEnum__Chaos_Object_Static = 3,
    EObjectStateTypeEnum__Chaos_Object_Dynamic = 4,
    EObjectStateTypeEnum__Chaos_Object_UserDefined = 100,
    EObjectStateTypeEnum__Chaos_Max = 101
};

enum EChaosSolverTickMode : uint8_t
{
    EChaosSolverTickMode__Fixed = 0,
    EChaosSolverTickMode__Variable = 1,
    EChaosSolverTickMode__VariableCapped = 2,
    EChaosSolverTickMode__VariableCappedWithTarget = 3
};

enum EChaosThreadingMode : uint8_t
{
    EChaosThreadingMode__DedicatedThread = 0,
    EChaosThreadingMode__TaskGraph = 1,
    EChaosThreadingMode__SingleThread = 2,
    EChaosThreadingMode__Num = 3,
    EChaosThreadingMode__Invalid = 4
};

enum EChaosSoftsSimulationSpace : uint8_t
{
    EChaosSoftsSimulationSpace__WorldSpace = 0,
    EChaosSoftsSimulationSpace__ComponentSpace = 1,
    ECha__t_1T______v____S_____Jt_________W14E____ = 2
};

enum EGeometryCollectionCacheType : uint8_t
{
    EGeometryCollectionCacheType__None = 0,
    EGeometryCollectionCacheType__Record = 1,
    EGeometryCollectionCacheType__Play = 2,
    EGeometryCollectionCacheType__RecordAndPlay = 3
};

enum ECollisionTraceFlag : uint8_t
{
    CTF_UseDefault = 0,
    CTF_UseSimpleAndComplex = 1,
    CTF_UseSimpleAsComplex = 2,
    CTF_UseComplexAsSimple = 3
};

enum EPhysicsType : uint8_t
{
    PhysType_Default = 0
};

enum EPhysicalSurface : uint8_t
{
    SurfaceType_Default = 0,
    SurfaceType1 = 1,
    SurfaceType2 = 2,
    SurfaceType3 = 3,
    SurfaceType4 = 4,
    SurfaceType5 = 5,
    SurfaceType6 = 6,
    SurfaceType7 = 7,
    SurfaceType8 = 8,
    SurfaceType9 = 9,
    SurfaceType10 = 10,
    SurfaceType11 = 11,
    SurfaceType12 = 12,
    SurfaceType13 = 13,
    SurfaceType14 = 14,
    Surf____1____ = 15,
    SurfaceType16 = 16,
    SurfaceType17 = 17,
    SurfaceType18 = 18,
    SurfaceType19 = 19,
    SurfaceType20 = 20,
    SurfaceType21 = 21,
    SurfaceType22 = 22,
    SurfaceType23 = 23,
    SurfaceType24 = 24,
    SurfaceType25 = 25,
    SurfaceType26 = 26,
    SurfaceType27 = 27,
    SurfaceType28 = 28,
    SurfaceType29 = 29,
    SurfaceType30 = 30,
    SurfaceType31 = 31,
    SurfaceType32 = 32,
    SurfaceType33 = 33,
    SurfaceType34 = 34
};

enum ESleepFamily : uint8_t
{
    ESleepFamily__Normal = 0,
    ESleepFamily__Sensitive = 1,
    ESleepFamily__Custom = 2
};

enum EAngularConstraintMotion : uint8_t
{
    ACM_Free = 0,
    ACM_Limited = 1,
    ACM_Locked = 2
};

enum EConstraintPlasticityType : uint8_t
{
    CCPT_Free = 0,
    CCPT_Shrink = 1,
    CCPT_Grow = 2
};

enum ELinearConstraintMotion : uint8_t
{
    LCM_Free = 0,
    LCM_Limited = 1,
    LCM_Locked = 2
};

enum EFrictionCombineMode : uint8_t
{
    EFrictionCombineMode__Average = 0,
    EFrictionCombineMode__Min = 1,
    EFrictionCombineMode__Multiply = 2,
    EFrictionCombineMode__Max = 3
};

enum EPhysicalMaterialSoftCollisionMode : uint8_t
{
    EPhysicalMaterialSoftCollisionMode__None = 0,
    EPhysicalMaterialSoftCollisionMode__RelativeThickness = 1,
    EPhysicalMaterialSoftCollisionMode__AbsoluteThickess = 2
};

enum EReplicationSystem : uint8_t
{
    EReplicationSystem__Default = 0,
    EReplicationSystem__Generic = 1,
    EReplicationSystem__Iris = 2
};

enum ENetCloseResult : uint8_t
{
    ENetCloseResult__NetDriverAlreadyExists = 0,
    ENetCloseResult__NetDriverCreateFailure = 1,
    ENetCloseResult__NetDriverListenFailure = 2,
    ENetCloseResult__ConnectionLost = 3,
    ENetCloseResult__ConnectionTimeout = 4,
    ENetCloseResult__FailureReceived = 5,
    ENetCloseResult__OutdatedClient = 6,
    ENetCloseResult__OutdatedServer = 7,
    ENetCloseResult__PendingConnectionFailure = 8,
    ENetCloseResult__NetGuidMismatch = 9,
    ENetCloseResult__NetChecksumMismatch = 10,
    ENetCloseResult__SecurityMalformedPacket = 11,
    ENetCloseResult__SecurityInvalidData = 12,
    ENetCloseResult__SecurityClosed = 13,
    ENetCloseResult__Unknown = 14,
    ENetCloseResult__Success = 15,
    ENetCloseResult__Extended = 16,
    ENetCloseResult__HostClosedConnection = 17,
    ENetCloseResult__Disconnect = 18,
    ENetCloseResult__Upgrade = 19,
    ENetCloseResult__PreLoginFailure = 20,
    ENetCloseResult__JoinFailure = 21,
    ENetCloseResult__JoinSplitFailure = 22,
    ENetCloseResult__AddressResolutionFailed = 23,
    ENetCloseResult__RPCDoS = 24,
    ENetCloseResult__Cleanup = 25,
    ENetCloseResult__MissingLevelPackage = 26,
    ENetCloseResult__PacketHandlerIncomingError = 27,
    ENetCloseResult__ZeroLastByte = 28,
    ENetCloseResult__ZeroSize = 29,
    ENetCloseResult__ReadHeaderFail = 30,
    ENetCloseResult__ReadHeaderExtraFail = 31,
    ENetCloseResult__AckSequenceMismatch = 32,
    ENetCloseResult__BunchBadChannelIndex = 33,
    ENetCloseResult__BunchChannelNameFail = 34,
    ENetCloseResult__BunchWrongChannelType = 35,
    ENetCloseResult__BunchHeaderOverflow = 36,
    ENetCloseResult__BunchDataOverflow = 37,
    ENetCloseResult__BunchServerPackageMapExports = 38,
    ENetCloseResult__BunchPrematureControlChannel = 39,
    ENetCloseResult__BunchPrematureChannel = 40,
    ENetCloseResult__BunchPrematureControlClose = 41,
    ENetCloseResult__UnknownChannelType = 42,
    ENetCloseResult__PrematureSend = 43,
    ENetCloseResult__CorruptData = 44,
    ENetCloseResult__SocketSendFailure = 45,
    ENetCloseResult__BadChildConnectionIndex = 46,
    ENetCloseResult__LogLimitInstant = 47,
    ENetCloseResult__LogLimitSustained = 48,
    ENetCloseResult__EncryptionFailure = 49,
    ENetCloseResult__EncryptionTokenMissing = 50,
    ENetCloseResult__ReceivedNetGUIDBunchFail = 51,
    ENetCloseResult__ReceivedNetExtBunchFail = 52,
    ENetCloseResult__MaxReliableExceeded = 53,
    ENetCloseResult__ReceivedNextBunchFail = 54,
    ENetCloseResult__ReceivedNextBunchQueueFail = 55,
    ENetCloseResult__PartialInitialReliableDestroy = 56,
    ENetCloseResult__PartialMergeReliableDestroy = 57,
    ENetCloseResult__PartialInitialNonByteAligned = 58,
    ENetCloseResult__PartialNonByteAligned = 59,
    ENetCloseResult__PartialFinalPackageMapExports = 60,
    ENetCloseResult__PartialTooLarge = 61,
    ENetCloseResult__AlreadyOpen = 62,
    ENetCloseResult__ReliableBeforeOpen = 63,
    ENetCloseResult__ReliableBufferOverflow = 64,
    ENetCloseResult__RPCReliableBufferOverflow = 65,
    ENetCloseResult__ControlChannelClose = 66,
    ENetCloseResult__ControlChannelEndianCheck = 67,
    ENetCloseResult__ControlChannelPlayerChannelFail = 68,
    ENetCloseResult__ControlChannelMessageUnknown = 69,
    ENetCloseResult__ControlChannelMessageFail = 70,
    ENetCloseResult__ControlChannelMessagePayloadFail = 71,
    ENetCloseResult__ControlChannelBunchOverflowed = 72,
    ENetCloseResult__ControlChannelQueueBunchOverflowed = 73,
    ENetCloseResult__ClientHasMustBeMappedGUIDs = 74,
    ENetCloseResult__ClientSentDestructionInfo = 75,
    ENetCloseResult__UnregisteredMustBeMappedGUID = 76,
    ENetCloseResult__ObjectReplicatorReceivedBunchFail = 77,
    ENetCloseResult__ContentBlockFail = 78,
    ENetCloseResult__ContentBlockHeaderRepLayoutFail = 79,
    ENetCloseResult__ContentBlockHeaderIsActorFail = 80,
    ENetCloseResult__ContentBlockHeaderObjFail = 81,
    ENetCloseResult__ContentBlockHeaderPrematureEnd = 82,
    ENetCloseResult__ContentBlockHeaderSubObjectActor = 83,
    ENetCloseResult__ContentBlockHeaderBadParent = 84,
    ENetCloseResult__ContentBlockHeaderInvalidCreate = 85,
    ENetCloseResult__ContentBlockHeaderStablyNamedFail = 86,
    ENetCloseResult__ContentBlockHeaderNoSubObjectClass = 87,
    ENetCloseResult__ContentBlockHeaderUObjectSubObject = 88,
    ENetCloseResult__ContentBlockHeaderAActorSubObject = 89,
    ENetCloseResult__ContentBlockHeaderFail = 90,
    ENetCloseRes______F___g__2__26_o___hx__N____ = 91,
    ENetCloseResult__FieldHeaderRepIndex = 92,
    ENetCloseResult__FieldHeaderBadRepIndex = 93,
    ENetCloseResult__FieldHeaderPayloadBitsFail = 94,
    ENetCloseResult__FieldPayloadFail = 95,
    ENetCloseResult__ReplicationChannelCountMaxedOut = 96,
    ENetCloseResult__BeaconControlFlowError = 97,
    ENetCloseResult__BeaconUnableToParsePacket = 98,
    ENetCloseResult__BeaconAuthenticationFailure = 99,
    ENetCloseResult__BeaconLoginInvalidIdError = 100,
    ENetCloseResult__BeaconLoginInvalidAuthHandlerError = 101,
    ENetCloseResult__BeaconAuthError = 102,
    ENetCloseResult__BeaconSpawnClientWorldPackageNameError = 103,
    ENetCloseResult__BeaconSpawnExistingActorError = 104,
    ENetCloseResult__BeaconSpawnFailureError = 105,
    ENetCloseResult__BeaconSpawnNetGUIDAckNoActor = 106,
    ENetCloseResult__BeaconSpawnNetGUIDAckNoHost = 107,
    ENetCloseResult__BeaconSpawnUnexpectedError = 108,
    ENetCloseResult__IrisProtocolMismatch = 109,
    ENetCloseResult__IrisNetRefHandleError = 110,
    ENetCloseResult__FaultDisconnect = 111,
    ENetCloseResult__NotRecoverable = 112
};

enum ENetObjectCountLimiterMode : uint8_t
{
    ENetObjectCountLimiterMode__RoundRobin = 0,
    ENetObjectCountLimiterMode__Fill = 1
};

enum ELocatorResolveFlags : uint8_t
{
    ELocatorResolveFlags__None = 0,
    ELocatorResolveFlags__Load = 1,
    ELocatorResolveFlags__Unload = 2,
    ELocatorResolveFlags__Async = 4,
    ELocatorResolveFlags__WillWait = 8,
    ELocatorResolveFlags__AsyncWait = 12
};

enum ESoundWaveCloudStreamingPlatformProjectEnableType : uint8_t
{
    ESoundWaveCloudStreamingPlatformProjectEnableType__Enabled = 0,
    ESoundWaveCloudStreamingPlatformProjectEnableType__Disabled = 1
};

enum ESoundWaveCloudStreamingPlatformEnableType : uint8_t
{
    ESoundWaveCloudStreamingPlatformEnableType__Inherited = 0,
    ESoundWaveCloudStreamingPlatformEnableType__Disabled = 1,
    ESoundWaveCloudStreamingPlatformEnableType__SWC_MultipleValues = 2
};

enum EAudioParameterType : uint8_t
{
    EAudioParameterType__None = 0,
    EAudioParameterType__Boolean = 1,
    EAudioParameterType__Integer = 2,
    EAudioParameterType__Float = 3,
    EAudioParameterType__String = 4,
    EAudioParameterType__Object = 5,
    EAudioParameterType__NoneArray = 6,
    EAudioParameterType__BooleanArray = 7,
    EAudioParameterType__IntegerArray = 8,
    EAudioParameterType__FloatArray = 9,
    EAudioParameterType__StringArray = 10,
    EAudioParameterType__ObjectArray = 11,
    EAudioParameterType__Trigger = 12,
    EAudioParameterType__COUNT = 13
};

enum FTypedElementAlertColumnType : uint8_t
{
    FTypedElementAlertColumnType__Error = 0,
    FTypedElementAlertColumnType__Warning = 1
};

enum ETypedElementChildInclusionMethod : uint8_t
{
    ETypedElementChildInclusionMethod__None = 0,
    ETypedElementChildInclusionMethod__Immediate = 1,
    ETypedElementChildInclusionMethod__Recursive = 2
};

enum ETypedElementSelectionMethod : uint8_t
{
    ETypedElementSelectionMethod__Primary = 0,
    ETypedElementSelectionMethod__Secondary = 1,
    ETypedElementSelectionMethod__FromSecondary = 2
};

enum ESoundwaveSampleRateSettings : uint8_t
{
    ESoundwaveSampleRateSettings__Max = 0,
    ESoundwaveSampleRateSettings__High = 1,
    ESoundwaveSampleRateSettings__Medium = 2,
    ESoundwaveSampleRateSettings__Low = 3,
    ESoundwaveSampleRateSettings__Min = 4
};

enum EAssetRegistrySortOrder : uint8_t
{
    EAssetRegistrySortOrder__Ascending = 0,
    EAssetRegistrySortOrder__Descending = 1
};

enum EDesiredImageFormat : uint8_t
{
    EDesiredImageFormat__PNG = 0,
    EDesiredImageFormat__JPG = 1,
    EDesiredImageFormat__BMP = 2,
    EDesiredImageFormat__EXR = 3
};

enum EMobileShadowQuality : uint8_t
{
    EMobileShadowQuality__NoFiltering = 0,
    EMobileShadowQuality__PCF_1x1 = 1,
    EMobileShadowQuality__PCF_3x3 = 2,
    EMobileShadowQuality__PCF_5x5 = 3
};

enum EEyeTrackerStatus : uint8_t
{
    EEyeTrackerStatus__NotConnected = 0,
    EEyeTrackerStatus__NotTracking = 1,
    EEyeTrackerStatus__Tracking = 2
};

enum ESparseVolumeTexturePreviewAttribute : uint8_t
{
    ESVTPA_AttributesA_R = 0,
    ESVTPA_AttributesA_G = 1,
    ESVTPA_AttributesA_B = 2,
    ESVTPA_AttributesA_A = 3,
    ESVTPA_AttributesB_R = 4,
    ESVTPA_AttributesB_G = 5,
    ESVTPA_AttributesB_B = 6,
    ESVTPA_AttributesB_A = 7
};

enum EOrientPositionSelector : uint8_t
{
    EOrientPositionSelector__Orientation = 0,
    EOrientPositionSelector__Position = 1,
    EOrientPositionSelector__OrientationAndPosition = 2
};

enum EHMDWornState : uint8_t
{
    EHMDWornState__Unknown = 0,
    EHMDWornState__Worn = 1,
    EHMDWornState__NotWorn = 2
};

enum ESpectatorScreenMode : uint8_t
{
    ESpectatorScreenMode__Disabled = 0,
    ESpectatorScreenMode__SingleEyeLetterboxed = 1,
    ESpectatorScreenMode__Undistorted = 2,
    ESpectatorScreenMode__Distorted = 3,
    ESpectatorScreenMode__SingleEye = 4,
    ESpectatorScreenMode__SingleEyeCroppedToFill = 5,
    ESpectatorScreenMode__Texture = 6,
    ESpectatorScreenMode__TexturePlusEye = 7
};

enum EXRTrackedDeviceType : uint16_t
{
    EXRTrackedDeviceType__HeadMountedDisplay = 0,
    EXRTrackedDeviceType__Controller = 1,
    EXRTrackedDeviceType__TrackingReference = 2,
    EXRTrackedDeviceType__Tracker = 3,
    EXRTrackedDeviceType__Other = 4,
    EXRTrackedDeviceType__Invalid = 254,
    EXRTrackedDeviceType__Any = 255
};

enum EXRVisualType : uint8_t
{
    EXRVisualType__Controller = 0,
    EXRVisualType__Hand = 1
};

enum EXRSpaceType : uint8_t
{
    EXRSpaceType__UnrealWorldSpace = 0,
    EXRSpaceType__XRTrackingSpace = 1
};

enum EXRControllerPoseType : uint8_t
{
    EXRControllerPoseType__Aim = 0,
    EXRControllerPoseType__Grip = 1,
    EXRControllerPoseType__Palm = 2
};

enum ETrackingStatus : uint8_t
{
    ETrackingStatus__NotTracked = 0,
    ETrackingStatus__InertialOnly = 1,
    ETrackingStatus__Tracked = 2
};

enum ESimulationOverlap : uint8_t
{
    ESimulationOverlap__CollisionOverlap = 0,
    ESimulationOverlap__ShadeOverlap = 1,
    ESimulationOverlap__None = 2
};

enum ESimulationQuery : uint8_t
{
    ESimulationQuery__None = 0,
    ESimulationQuery__CollisionOverlap = 1,
    ESimulationQuery__ShadeOverlap = 2,
    ESimulationQuery__AnyOverlap = 3
};

enum EHeightmapRTType : uint8_t
{
    EHeightmapRTType__HeightmapRT_CombinedAtlas = 0,
    EHeightmapRTType__HeightmapRT_CombinedNonAtlas = 1,
    EHeightmapRTType__HeightmapRT_Scratch1 = 2,
    EHeightmapRTType__HeightmapRT_Scratch2 = 3,
    EHeightmapRTType__HeightmapRT_Scratch3 = 4,
    EHeightmapRTType__HeightmapRT_BoundaryNormal = 5,
    EHeightmapRTType__HeightmapRT_Mip1 = 6,
    EHeightmapRTType__HeightmapRT_Mip2 = 7,
    EHeightmapRTType__HeightmapRT_Mip3 = 8,
    EHeightmapRTType__HeightmapRT_Mip4 = 9,
    EHeightmapRTType__HeightmapRT_Mip5 = 10,
    EHeightmapRTType__HeightmapRT_Mip6 = 11,
    EHeightmapRTType__HeightmapRT_Mip7 = 12,
    EHeightmapRTType__HeightmapRT_Count = 13,
    EHeightmapRTType______L7_______l_ = 14
};

enum EWeightmapRTType : uint8_t
{
    EWeightmapRTType__WeightmapRT_Scratch_RGBA = 0,
    EWeightmapRTType__WeightmapRT_Scratch1 = 1,
    EWeightmapRTType__WeightmapRT_Scratch2 = 2,
    EWeightmapRTType__WeightmapRT_Scratch3 = 3,
    EWeightmapRTType__WeightmapRT_Mip0 = 4,
    EWeightmapRTType__WeightmapRT_Mip1 = 5,
    EWeightmapRTType__WeightmapRT_Mip2 = 6,
    EWeightmapRTType__WeightmapRT_Mip3 = 7,
    EWeightmapRTType__WeightmapRT_Mip4 = 8,
    EWeightmapRTType__WeightmapRT_Mip5 = 9,
    EWeightmapRTType__WeightmapRT_Mip6 = 10,
    EWeightmapRTType__WeightmapRT_Mip7 = 11,
    EWeightmapRTType__WeightmapRT_Count = 12
};

enum ELandscapeBlendMode : uint8_t
{
    LSBM_AdditiveBlend = 0,
    LSBM_AlphaBlend = 1
};

enum ELandscapeClearMode : uint8_t
{
    Clear_Weightmap = 1,
    Clear_Heightmap = 2,
    Clear_All = 3
};

enum ELandscapeGizmoType : uint8_t
{
    LGT_None = 0,
    LGT_Height = 1,
    LGT_Weight = 2
};

enum ELandscapeGizmoSnapType : uint8_t
{
    ELandscapeGizmoSnapType__None = 0,
    ELandscapeGizmoSnapType__Component = 1,
    ELandscapeGizmoSnapType__Texel = 2
};

enum EGrassScaling : uint8_t
{
    EGrassScaling__Uniform = 0,
    EGrassScaling__Free = 1,
    EGrassScaling__LockXY = 2
};

enum ESplineModulationColorMask : uint8_t
{
    ESplineModulationColorMask__Red = 0,
    ESplineModulationColorMask__Green = 1,
    ESplineModulationColorMask__Blue = 2,
    ESplineModulationColorMask__Alpha = 3
};

enum ELandscapeDirtyingMode : uint8_t
{
    ELandscapeDirtyingMode__Auto = 0,
    ELandscapeDirtyingMode__InLandscapeModeOnly = 1,
    ELandscapeDirtyingMode__InLandscapeModeAndUserTriggeredChanges = 2
};

enum LandscapeSplineMeshOrientation : uint8_t
{
    LSMO_XUp = 0,
    LSMO_YUp = 1
};

enum ELandscapeLayerBlendType : uint8_t
{
    LB_WeightBlend = 0,
    LB_AlphaBlend = 1,
    LB_HeightBlend = 2
};

enum ETerrainCoordMappingType : uint8_t
{
    TCMT_Auto = 0,
    TCMT_XY = 1,
    TCMT_XZ = 2,
    TCMT_YZ = 3
};

enum ELandscapeCustomizedCoordType : uint8_t
{
    LCCT_None = 0,
    LCCT_CustomUV0 = 1,
    LCCT_CustomUV1 = 2,
    LCCT_CustomUV2 = 3,
    LCCT_WeightMapUV = 4
};

enum ELandscapeResizeMode : uint8_t
{
    ELandscapeResizeMode__Resample = 0,
    ELandscapeResizeMode__Clip = 1,
    ELandscapeResizeMode__Expand = 2
};

enum ELandscapeImportAlphamapType : uint8_t
{
    ELandscapeImportAlphamapType__Additive = 0,
    ELandscapeImportAlphamapType__Layered = 1
};

enum ELandscapeLayerDisplayMode : uint8_t
{
    ELandscapeLayerDisplayMode__Default = 0,
    ELandscapeLayerDisplayMode__Alphabetical = 1,
    ELandscapeLayerDisplayMode__UserSpecific = 2
};

enum ELandscapeHLODTextureSizePolicy : uint8_t
{
    ELandscapeHLODTextureSizePolicy__AutomaticSize = 0,
    ELandscapeHLODTextureSizePolicy__SpecificSize = 1
};

enum ELandscapeHLODMeshSourceLODPolicy : uint8_t
{
    ELandscapeHLODMeshSourceLODPolicy__AutomaticLOD = 0,
    ELandscapeHLODMeshSourceLODPolicy__SpecificLOD = 1,
    ELandscapeHLODMeshSourceLODPolicy__LowestDetailLOD = 2
};

enum ELandscapeLODFalloff : uint8_t
{
    ELandscapeLODFalloff__Linear = 0,
    ELandscapeLODFalloff__SquareRoot = 1
};

enum ETimedDataInputEvaluationType : uint8_t
{
    ETimedDataInputEvaluationType__None = 0,
    ETimedDataInputEvaluationType__Timecode = 1,
    ETimedDataInputEvaluationType__PlatformTime = 2
};

enum ETimedDataInputState : uint8_t
{
    ETimedDataInputState__Connected = 0,
    ETimedDataInputState__Unresponsive = 1,
    ETimedDataInputState__Disconnected = 2
};

enum EMovieSceneCompletionMode : uint8_t
{
    EMovieSceneCompletionMode__KeepState = 0,
    EMovieSceneCompletionMode__RestoreState = 1,
    EMovieSceneCompletionMode__ProjectDefault = 2
};

enum EMovieSceneConditionScope : uint8_t
{
    EMovieSceneConditionScope__Global = 0,
    EMovieSceneConditionScope__Binding = 1,
    EMovieSceneConditionScope__OwnerObject = 2
};

enum EMovieSceneConditionCheckFrequency : uint8_t
{
    EMovieSceneConditionCheckFrequency__Once = 0,
    EMovieSceneConditionCheckFrequency__OnTick = 1
};

enum EMovieSceneEvaluationType : uint8_t
{
    EMovieSceneEvaluationType__FrameLocked = 0,
    EMovieSceneEvaluationType__WithSubFrames = 1
};

enum EMovieSceneSequenceFlags : uint8_t
{
    EMovieSceneSequenceFlags__None = 0,
    EMovieSceneSequenceFlags__Volatile = 1,
    EMovieSceneSequenceFlags__BlockingEvaluation = 2,
    EMovieSceneSequenceFlags__DynamicWeighting = 4,
    EMovieSceneSequenceFlags__InheritedFlags = 1
};

enum EMovieSceneGroupConditionOperator : uint8_t
{
    EMovieSceneGroupConditionOperator__And = 0,
    EMovieSceneGroupConditionOperator__Or = 1,
    EMovieSceneGroupConditionOperator__Xor = 2
};

enum EMovieSceneCompletionModeOverride : uint8_t
{
    EMovieSceneCompletionModeOverride__None = 0,
    EMovieSceneCompletionModeOverride__ForceKeepState = 1,
    EMovieSceneCompletionModeOverride__ForceRestoreState = 2
};

enum EMovieSceneTimeWarpType : uint8_t
{
    EMovieSceneTimeWarpType__FixedPlayRate = 0,
    EMovieSceneTimeWarpType__Custom = 1,
    EMovieSceneTimeWarpType__FixedTime = 2,
    EMovieSceneTimeWarpType__FrameRate = 3,
    EMovieSceneTimeWarpType__Loop = 4,
    EMovieSceneTimeWarpType__Clamp = 5,
    EMovieSceneTimeWarpType__LoopFloat = 6,
    EMovieSceneTimeWarpType__ClampFloat = 7
};

enum EEvaluationMethod : uint8_t
{
    EEvaluationMethod__Static = 0,
    EEvaluationMethod_______ = 1
};

enum EMovieSceneObjectBindingSpace : uint8_t
{
    EMovieSceneObjectBindingSpace__Local = 0,
    EMovieSceneObjectBindingSpace__Root = 1,
    EMovieSceneObjectBindingSpace__Unused = 2
};

enum EUpdatePositionMethod : uint8_t
{
    EUpdatePositionMethod__Play = 0,
    EUpdatePositionMethod__Jump = 1,
    EUpdatePositionMethod__Scrub = 2
};

enum EClusterConnectionTypeEnum : uint8_t
{
    EClusterConnectionTypeEnum__Chaos_PointImplicit = 0,
    EClusterConnectionTypeEnum__Chaos_DelaunayTriangulation = 1,
    EClusterConnectionTypeEnum__Chaos_MinimalSpanningSubsetDelaunayTriangulation = 2,
    EClusterConnectionTypeEnum__Chaos_PointImplicitAugmentedWithMinimalDelaunay = 3,
    EClusterConnectionTypeEnum__Chaos_BoundsOverlapFilteredDelaunayTriangulation = 4,
    EClusterConnectionTypeEnum__Chaos_None = 5,
    EClusterConnectionTypeEnum__Chaos_EClsuterCreationParameters_Max = 6
};

enum EAttachLocation : uint8_t
{
    EAttachLocation__KeepRelativeOffset = 0,
    EAttachLocation__KeepWorldPosition = 1,
    EAttachLocation__SnapToTarget = 2,
    EAttachLocation__SnapToTargetIncludingScale = 3
};

enum EAttachmentRule : uint8_t
{
    EAttachmentRule__KeepRelative = 0,
    EAttachmentRule__KeepWorld = 1,
    EAttachmentRule__SnapToTarget = 2
};

enum EComponentMobility : uint8_t
{
    EComponentMobility__Static = 0,
    EComponentMobility__Stationary = 1,
    EComponentMobility__Movable = 2
};

enum EDetailMode : uint8_t
{
    DM_Low = 0,
    DM_Medium = 1,
    DM_High = 2,
    DM_Epic = 3
};

enum ECollisionEnabled : uint8_t
{
    ECollisionEnabled__NoCollision = 0,
    ECollisionEnabled__QueryOnly = 1,
    ECollisionEnabled__PhysicsOnly = 2,
    ECollisionEnabled__QueryAndPhysics = 3,
    ECollisionEnabled__ProbeOnly = 4,
    ECollisionEnabled__QueryAndProbe = 5
};

enum ECollisionChannel : uint8_t
{
    ECC_WorldStatic = 0,
    ECC_WorldDynamic = 1,
    ECC_Pawn = 2,
    ECC_Visibility = 3,
    ECC_Camera = 4,
    ECC_PhysicsBody = 5,
    ECC_Vehicle = 6,
    ECC_Destructible = 7,
    ECC_EngineTraceChannel1 = 8,
    ECC_EngineTraceChannel2 = 9,
    ECC_EngineTraceChannel3 = 10,
    ECC_EngineTraceChannel4 = 11,
    ECC_EngineTraceChannel5 = 12,
    ECC_EngineTraceChannel6 = 13,
    ECC_GameTraceChannel1 = 14,
    ECC_GameTraceChannel2 = 15,
    ECC_GameTraceChannel3 = 16,
    ECC_GameTraceChannel4 = 17,
    ECC_GameTraceChannel5 = 18,
    ECC_GameTraceChannel6 = 19,
    ECC_GameTraceChannel7 = 20,
    ECC_GameTraceChannel8 = 21,
    ECC_GameTraceChannel9 = 22,
    ECC_GameTraceChannel10 = 23,
    ECC_GameTraceChannel11 = 24,
    ECC_GameTraceChannel12 = 25,
    ECC_GameTraceChannel13 = 26,
    ECC_GameTraceChannel14 = 27,
    ECC_GameTraceChannel15 = 28,
    ECC_GameTraceChannel16 = 29,
    ECC_GameTraceChannel17 = 30,
    ECC_GameTraceChannel18 = 31,
    ECC_OverlapAll_Deprecated = 32
};

enum ECollisionResponse : uint8_t
{
    ECR_Ignore = 0,
    ECR_Overlap = 1,
    ECR_Block = 2
};

enum EWalkableSlopeBehavior : uint8_t
{
    WalkableSlope_Default = 0,
    WalkableSlope_Increase = 1,
    WalkableSlope_Decrease = 2,
    WalkableSlope_Unwalkable = 3,
    WalkableSlope_Max = 4
};

enum EHLODLevelExclusion : uint8_t
{
    EHLODLevelExclusion__HLOD0 = 1,
    EHLODLevelExclusion__HLOD1 = 2,
    EHLODLevelExclusion__HLOD2 = 4,
    EHLODLevelExclusion__HLOD3 = 8,
    EHLODLevelExclusion__HLOD4 = 16,
    EHLODLevelExclusion__HLOD5 = 32,
    EHLODLevelExclusion__HLOD6 = 64,
    EHLODLevelExclusion__HLOD7 = 128
};

enum EDOFMode : uint8_t
{
    EDOFMode__Default = 0,
    EDOFMode__SixDOF = 1,
    EDOFMode__YZPlane = 2,
    EDOFMode__XZPlane = 3,
    EDOFMode__XYPlane = 4,
    EDOFMode__CustomPlane = 5,
    EDOFMode__None = 6
};

enum ERendererStencilMask : uint8_t
{
    ERendererStencilMask__ERSM_Default = 0,
    ERendererStencilMask__ERSM = 1,
    ERendererStencilMask__ERSM = 2,
    ERendererStencilMask__ERSM = 3,
    ERendererStencilMask__ERSM = 4,
    ERendererStencilMask__ERSM = 5,
    ERendererStencilMask__ERSM = 6,
    ERendererStencilMask__ERSM = 7,
    ERendererStencilMask__ERSM = 8,
    ERendererStencilMask__ERSM = 9
};

enum EFirstPersonPrimitiveType : uint8_t
{
    EFirstPersonPrimitiveType__None = 0,
    EFirstPersonPrimitiveType__FirstPerson = 1,
    EFirstPersonPrimitiveType__WorldSpaceRepresentation = 2
};

enum ERuntimeVirtualTextureMainPassType : uint8_t
{
    ERuntimeVirtualTextureMainPassType__Never = 0,
    ERuntimeVirtualTextureMainPassType__Exclusive = 1,
    ERuntimeVirtualTextureMainPassType__Always = 2
};

enum ERayTracingGroupCullingPriority : uint8_t
{
    ERayTracingGroupCullingPriority__CP_0_NEVER_CULL = 0,
    ERayTracingGroupCullingPriority__CP = 1,
    ERayTracingGroupCullingPriority__CP = 2,
    ERayTracingGroupCullingPriority__CP = 3,
    ERayTracingGroupCullingPriority__CP_4_DEFAULT = 4,
    ERayTracingGroupCullingPriority__CP = 5,
    ERayTracingGroupCullingPriority__CP = 6,
    ERayTracingGroupCullingPriority__CP = 7,
    ERayTracingGroupCullingPriority__CP_8_QUICKLY_CULL = 8
};

enum ECanBeCharacterBase : uint8_t
{
    ECB_No = 0,
    ECB_Yes = 1,
    ECB_Owner = 2
};

enum EHLODBatchingPolicy : uint8_t
{
    EHLODBatchingPolicy__None = 0,
    EHLODBatchingPolicy__MeshSection = 1,
    EHLODBatchingPolicy__Instancing = 2
};

enum ELightmapType : uint8_t
{
    ELightmapType__Default = 0,
    ELightmapType__ForceSurface = 1,
    ELightmapType__ForceVolumetric = 2
};

enum EIndirectLightingCacheQuality : uint8_t
{
    ILCQ_Off = 0,
    ILCQ_Point = 1,
    ILCQ_Volume = 2
};

enum ESceneDepthPriorityGroup : uint8_t
{
    SDPG_World = 0,
    SDPG_Foreground = 1
};

enum ECollectionAttributeEnum : uint8_t
{
    ECollectionAttributeEnum__Chaos_Active = 0,
    ECollectionAttributeEnum__Chaos_DynamicState = 1,
    ECollectionAttributeEnum__Chaos_CollisionGroup = 2,
    ECollectionAttributeEnum__Chaos_Max = 3
};

enum EChaosBreakingSortMethod : uint8_t
{
    EChaosBreakingSortMethod__SortNone = 0,
    EChaosBreakingSortMethod__SortByHighestMass = 1,
    EChaosBreakingSortMethod__SortByHighestSpeed = 2,
    EChaosBreakingSortMethod__SortByNearestFirst = 3,
    EChaosBreakingSortMethod__Count = 4
};

enum EChaosCollisionSortMethod : uint8_t
{
    EChaosCollisionSortMethod__SortNone = 0,
    EChaosCollisionSortMethod__SortByHighestMass = 1,
    EChaosCollisionSortMethod__SortByHighestSpeed = 2,
    EChaosCollisionSortMethod__SortByHighestImpulse = 3,
    EChaosCollisionSortMethod__SortByNearestFirst = 4,
    EChaosCollisionSortMethod__Count = 5
};

enum EChaosTrailingSortMethod : uint8_t
{
    EChaosTrailingSortMethod__SortNone = 0,
    EChaosTrailingSortMethod__SortByHighestMass = 1,
    EChaosTrailingSortMethod__SortByHighestSpeed = 2,
    EChaosTrailingSortMethod__SortByNearestFirst = 3,
    EChaosTrailingSortMethod__Count = 4
};

enum EGeometryCollectionDebugDrawActorHideGeometry : uint8_t
{
    EGeometryCollectionDebugDrawActorHideGeometry__HideNone = 0,
    EGeometryCollectionDebugDrawActorHideGeometry__HideWithCollision = 1,
    EGeometryCollectionDebugDrawActorHideGeometry__HideSelected = 2,
    EGeometryCollectionDebugDrawActorHideGeometry__HideWholeCollection = 3,
    EGeometryCollectionDebugDrawActorHideGeometry__HideAll = 4
};

enum EBoneModificationMode : uint8_t
{
    BMM_Ignore = 0,
    BMM_Replace = 1,
    BMM_Additive = 2
};

enum ERefPoseType : uint8_t
{
    EIT_LocalSpace = 0,
    EIT_Additive = 1
};

enum EEasingFuncType : uint8_t
{
    EEasingFuncTyp_y0______ = 0,
    EEasingFuncType__Sinusoidal = 1,
    EEasingFuncType__Cubic = 2,
    EEasingFuncType__QuadraticInOut = 3,
    EEasingFuncType__CubicInOut = 4,
    EEasingFuncType__HermiteCubic = 5,
    EEasingFuncType__QuarticInOut = 6,
    EEasingFuncType__QuinticInOut = 7,
    EEasingFuncType__CircularIn = 8,
    EEasingFuncType__CircularOut = 9,
    EEasingFuncType__CircularInOut = 10,
    EEasingFuncType__ExpIn = 11,
    EEasingFuncType__ExpOut = 12,
    EEasingFuncType__ExpInOut = 13,
    EEasingFuncType__CustomCurve = 14
};

enum ERotationComponent : uint8_t
{
    ERotationComponent__EulerX = 0,
    ERotationComponent__EulerY = 1,
    ERotationComponent__EulerZ = 2,
    ERotationComponent__QuaternionAngle = 3,
    ERotationComponent__SwingAngle = 4,
    ERotationComponent__TwistAngle = 5
};

enum EBlendListTransitionType : uint8_t
{
    EBlendListTransitionType__StandardBlend = 0,
    EBlendListTransitionType__Inertialization = 1
};

enum EBlendListChildUpdateMode : uint8_t
{
    EBlendListChildUpdateMode__Default = 0,
    EBlendListChildUpdateMode__ResetChildOnActivate = 1,
    EBlendListChildUpdateMode__AlwaysTickChildren = 2
};

enum EAnimFunctionCallSite : uint8_t
{
    EAnimFunctionCallSite__OnInitialize = 0,
    EAnimFunctionCallSite__OnUpdate = 1,
    EAnimFunctionCallSite__OnBecomeRelevant = 2,
    EAnimFunctionCallSite__OnEvaluate = 3,
    EAnimFunctionCallSite__OnInitializePostRecursion = 4,
    EAnimFunctionCallSite__OnUpdatePostRecursion = 5,
    EAnimFunctionCallSite__OnBecomeRelevantPostRecursion = 6,
    EAnimFunctionCallSite__OnEvaluatePostRecursion = 7,
    EAnimFunctionCallSite__OnStartedBlendingOut = 8,
    EAnimFunctionCallSite__OnStartedBlendingIn = 9,
    EAnimFunctionCallSite__OnFinishedBlendingOut = 10,
    EAnimFunctionCallSite__OnFinishedBlendingIn = 11
};

enum EModifyCurveApplyMode : uint8_t
{
    EModifyCurveApplyMode__Add = 0,
    EModifyCurveApplyMode__Scale = 1,
    EModifyCurveApplyMode__Blend = 2,
    EModifyCurveApplyMode__WeightedMovingAverage = 3,
    EModifyCurveApplyMode__RemapCurve = 4
};

enum EPoseDriverType : uint8_t
{
    EPoseDriverType__SwingAndTwist = 0,
    EPoseDriverType__SwingOnly = 1,
    EPoseDriverType__Translation = 2
};

enum EPoseDriverSource : uint8_t
{
    EPoseDriverSource__Rotation = 0,
    EPoseDriverSource__Translation = 1
};

enum EPoseDriverOutput : uint8_t
{
    EPoseDriverOutput__DrivePoses = 0,
    EPoseDriverOutput__DriveCurves = 1
};

enum ESnapshotSourceMode : uint8_t
{
    ESnapshotSourceMode__NamedSnapshot = 0,
    ESnapshotSourceMode__SnapshotPin = 1
};

enum ESequenceEvalReinit : uint8_t
{
    ESequenceEvalReinit__NoReset = 0,
    ESequenceEvalReinit__StartPosition = 1,
    ESequenceEvalReinit__ExplicitTime = 2
};

enum ESwapRootBone : uint8_t
{
    ESwapRootBone__SwapRootBone_Component = 0,
    ESwapRootBone__SwapRootBone_Actor = 1,
    ESwapRootBone__SwapRootBone_None = 2
};

enum AnimPhysAngularConstraintType : uint8_t
{
    AnimPhysAngularConstraintType__Angular = 0,
    AnimPhysAngularConstraintType__Cone = 1
};

enum AnimPhysLinearConstraintType : uint8_t
{
    AnimPhysLinearConstraintType__Free = 0,
    AnimPhysLinearConstraintType__Limited = 1
};

enum AnimPhysSimSpaceType : uint8_t
{
    AnimPhysSimSpaceType__Component = 0,
    AnimPhysSimSpaceType__Actor = 1,
    AnimPhysSimSpaceType__World = 2,
    AnimPhysSimSpaceType__RootRelative = 3,
    AnimPhysSimSpaceType__BoneRelative = 4
};

enum ESphericalLimitType : uint8_t
{
    ESphericalLimitType__Inner = 0,
    ESphericalLimitType__Outer = 1
};

enum EDrivenBoneModificationMode : uint8_t
{
    EDrivenBoneModificationMode__AddToInput = 0,
    EDrivenBoneModificationMode__ReplaceComponent = 1,
    EDrivenBoneModificationMode__AddToRefPose = 2
};

enum EDrivenDestinationMode : uint8_t
{
    EDrivenDestinationMode__Bone = 0,
    EDrivenDestinationMode__MorphTarget = 1,
    EDrivenDestinationMode__MaterialParameter = 2
};

enum EConstraintOffsetOption : uint8_t
{
    EConstraintOffsetOption__None = 0,
    EConstraintOffsetOption__Offset_RefPose = 1
};

enum CopyBoneDeltaMode : uint8_t
{
    CopyBoneDeltaMode__Accumulate = 0,
    CopyBoneDeltaMode__Copy = 1
};

enum EInterpolationBlend : uint8_t
{
    EInterpolationBlend__Linear = 0,
    EInterpolationBlend__Cubic = 1,
    EInterpolationBlend__Sinusoidal = 2,
    EInterpolationBlend__EaseInOutExponent2 = 3,
    EInterpolationBlend__EaseInOutExponent3 = 4,
    EInterpolationBlend__EaseInOutExponent4 = 5,
    EInterpolationBlend__EaseInOutExponent5 = 6
};

enum ESimulationSpace : uint8_t
{
    ESimulationSpace__ComponentSpace = 0,
    ESimulationSpace__WorldSpace = 1,
    ESimulationSpace__BaseBoneSpace = 2
};

enum ESimulationTiming : uint8_t
{
    ESimulationTiming__Default = 0,
    ESimulationTiming__Synchronous = 1,
    ESimulationTiming__Deferred = 2
};

enum EScaleChainInitialLength : uint8_t
{
    EScaleChainInitialLength__FixedDefaultLengthValue = 0,
    EScaleChainInitialLength__Distance = 1,
    EScaleChainInitialLength__ChainLength = 2
};

enum ERBFFunctionType : uint8_t
{
    ERBFFunctionType__Gaussian = 0,
    ERBFFunctionType__Exponential = 1,
    ERBFFunctionType__Linear = 2,
    ERBFFunctionType__Cubic = 3,
    ERBFFunctionType__Quintic = 4,
    ERBFFunctionType__DefaultFunction = 5
};

enum ERBFDistanceMethod : uint8_t
{
    ERBFDistanceMethod__Euclidean = 0,
    ERBFDistanceMethod__Quaternion = 1,
    ERBFDistanceMethod__SwingAngle = 2,
    ERBFDistanceMethod__TwistAngle = 3,
    ERBFDistanceMethod__DefaultMethod = 4
};

enum ERBFNormalizeMethod : uint8_t
{
    ERBFNormalizeMethod__OnlyNormalizeAboveOne = 0,
    ERBFNormalizeMethod__AlwaysNormalize = 1,
    ERBFNormalizeMethod__NormalizeWithinMedian = 2,
    ERBFNormalizeMethod__NoNormalization = 3
};

enum EHandleEvent : uint8_t
{
    EHandleEvent__LocalTransformUpdated = 0,
    EHandleEvent__GlobalTransformUpdated = 1,
    EHandleEvent__ComponentUpdated = 2,
    EHandleEvent__UpperDependencyUQb__TB = 3,
    EHandleEvent__Max = 4
};

enum EMovieSceneScalabilityConditionGroup : uint8_t
{
    EMovieSceneScalabilityConditionGroup__ViewDistance = 0,
    EMovieSceneScalabilityConditionGroup__AntiAliasing = 1,
    EMovieSceneScalabilityConditionGroup__Shadow = 2,
    EMovieSceneScalabilityConditionGroup__GlobalIllumination = 3,
    EMovieSceneScalabilityConditionGroup__Reflection = 4,
    EMovieSceneScalabilityConditionGroup__PostProcess = 5,
    EMovieSceneScalabilityConditionGroup__Text___ = 6,
    EMovieSceneScalabilityConditionGroup__Effects = 7,
    EMovieSceneScalabilityConditionGroup__Foliage = 8,
    EMovieSceneScalabilityConditionGroup__Shading = 9,
    EMovieSceneScalabilityConditionGroup__Landscape = 10
};

enum MovieScene3DPathSection_Axis : uint8_t
{
    MovieScene3DPathSection_Axis__X = 0,
    MovieScene3DPathSection_Axis__Y = 1,
    MovieScene3DPathSection_Axis__Z = 2,
    MovieScene3DPathSection_Axis__NEG_X = 3,
    MovieScene3DPathSection_Axis__NEG_Y = 4,
    MovieScene3DPathSection_Axis__NEG_Z = 5
};

enum EParticleKey : uint8_t
{
    EParticleKey__Activate = 0,
    EParticleKey__Deactivate = 1,
    EParticleKey__Trigger = 2
};

enum EFireEventsAtPosition : uint8_t
{
    EFireEventsAtPosition__AtStartOfEvaluation = 0,
    EFireEventsAtPosition__AtEndOfEvaluation = 1,
    EFireEventsAtPosition__AfterSpawn = 2
};

enum ESlateVisibility : uint8_t
{
    ESlateVisibility__Visible = 0,
    ESlateVisibility__Collapsed = 1,
    ESlateVisibility__Hidden = 2,
    ESlateVisibility__HitTestInvisible = 3,
    ESlateVisibility__SelfHitTestInvisible = 4
};

enum EVirtualKeyboardType : uint8_t
{
    EVirtualKeyboardType__Default = 0,
    EVirtualKeyboardType__Number = 1,
    EVirtualKeyboardType__Web = 2,
    EVirtualKeyboardType__Email = 3,
    EVirtualKeyboardType__Password = 4,
    EVirtualKeyboardType__AlphaNumeric = 5
};

enum ESlateAccessibleBehavior : uint8_t
{
    ESlateAccessibleBehavior__NotAccessible = 0,
    ESlateAccessibleBehavior__Auto = 1,
    ESlateAccessibleBehavior__Summary = 2,
    ESlateAccessibleBehavior__Custom = 3,
    ESlateAccessibleBehavior__ToolTip = 4
};

enum EMouseLockMode : uint8_t
{
    EMouseLockMode__DoNotLock = 0,
    EMouseLockMode__LockOnCapture = 1,
    EMouseLockMode__LockAlways = 2,
    EMouseLockMode__LockInFullscreen = 3
};

enum EWindowTitleBarMode : uint8_t
{
    EWindowTitleBarMode__Overlay = 0,
    EWindowTitleBarMode__VerticalBox = 1
};

enum ESlateSizeRule : uint8_t
{
    ESlateSizeRule__Automatic = 0,
    ESlateSizeRule__Fill = 1
};

enum EWidgetDesignFlags : uint8_t
{
    EWidgetDesignFlags__None = 0,
    EWidgetDesignFlags__Designing = 1,
    EWidgetDesignFlags__ShowOutline = 2,
    EWidgetDesignFlags__ExecutePreConstruct = 4,
    EWidgetDesignFlags__Previewing = 8
};

enum EWidgetSpace : uint8_t
{
    EWidgetSpace__World = 0,
    EWidgetSpace__Screen = 1
};

enum EWidgetTimingPolicy : uint8_t
{
    EWidgetTimingPolicy__RealTime = 0,
    EWidgetTimingPolicy__GameTime = 1
};

enum EWidgetBlendMode : uint8_t
{
    EWidgetBlendMode__Opaque = 0,
    EWidgetBlendMode__Masked = 1,
    EWidgetBlendMode__Transparent = 2
};

enum EWidgetGeometryMode : uint8_t
{
    EWidgetGeometryMode__Plane = 0,
    EWidgetGeometryMode__Cylinder = 1
};

enum ETickMode : uint8_t
{
    ETickMode__Disabled = 0,
    ETickMode__Enabled = 1,
    ETickMode__Automatic = 2
};

enum EWidgetInteractionSource : uint8_t
{
    EWidgetInteractionSource__World = 0,
    EWidgetInteractionSource__Mouse = 1,
    EWidgetInteractionSource__CenterScreen = 2,
    EWidgetInteractionSource__Custom = 3
};

enum EDragPivot : uint8_t
{
    EDragPivot____D_o____ = 0,
    EDragPivot__TopLeft = 1,
    EDragPivot__TopCenter = 2,
    EDragPivot__TopRight = 3,
    EDragPivot__CenterLeft = 4,
    EDragPivot__CenterCenter = 5,
    EDragPivot__CenterRight = 6,
    EDragPivot__BottomLeft = 7,
    EDragPivot__BottomCenter = 8,
    EDragPivot__BottomRight = 9
};

enum EUMGSequencePlayMode : uint8_t
{
    EUMGSequencePlayMode__Forward = 0,
    EUMGSequencePlayMode__Reverse = 1,
    EUMGSequencePlayMode__PingPong = 2
};

enum EBindingKind : uint8_t
{
    EBindingKind__Function = 0,
    EBindingKind__Property = 1
};

enum ECameraFocusMethod : uint8_t
{
    ECameraFocusMethod__DoNotOverride = 0,
    ECameraFocusMethod__Manual = 1,
    ECameraFocusMethod__Tracking = 2,
    ECameraFocusMethod__Disable = 3
};

enum EAudioDeviceChangedRole : uint8_t
{
    EAudioDeviceChangedRole__Invalid = 0,
    EAudioDeviceChangedRole__Console = 1,
    EAudioDeviceChangedRole__Multimedia = 2,
    EAudioDeviceChangedRole__Communications = 3,
    EAudioDeviceChangedRole__Count = 4
};

enum EAudioMixerChannelType : uint8_t
{
    EAudioMixerChannelType__FrontLeft = 0,
    EAudioMixerChannelType__FrontRight = 1,
    EAudioMixerChannelType__FrontCenter = 2,
    EAudioMixerChannelType__LowFrequency = 3,
    EAudioMixerChannelType__BackLeft = 4,
    EAudioMixerChannelType__BackRight = 5,
    EAudioMixerChannelType__FrontLeftOfCenter = 6,
    EAudioMixerChannelType__FrontRightOfCenter = 7,
    EAudioMixerChannelType__BackCenter = 8,
    EAudioMixerChannelType__SideLeft = 9,
    EAudioMixerChannelType__SideRight = 10,
    EAudioMixerChannelType__TopCenter = 11,
    EAudioMixerChannelType__TopFrontLeft = 12,
    EAudioMixerChannelType__TopFrontCenter = 13,
    EAudioMixerChannelType__TopFrontRight = 14,
    EAudioMixerChannelType__TopBackLeft = 15,
    EAudioMixerChannelType__TopBackCenter = 16,
    EAudioMixerChannelType__TopBackRight = 17,
    EAudioMixerChannelType__Unknown = 18,
    EAudioMixerChannelType__ChannelTypeCount = 19,
    EAudioMixerChannelType__DefaultChannel = 0
};

enum ESwapAudioOutputDeviceResultState : uint8_t
{
    ESwapAudioOutputDeviceResultState__Failure = 0,
    ESwapAudioOutputDeviceResultState__Success = 1,
    ESwapAudioOutputDeviceResultState__None = 2
};

enum ESourceManagerRenderThreadPhase : uint8_t
{
    Begin = 0,
    PumpMpscCmds = 1,
    PumpCmds = 2,
    ProcessModulators = 3,
    UpdatePendingReleaseData = 4,
    GenerateSrcAudio_WithBusses = 5,
    ComputeBusses = 6,
    GenerateSrcAudio_WithoutBusses = 7,
    UpdateBusses = 8,
    SpatialInterface_OnAllSourcesProcessed = 9,
    SourceDataOverride_OnAllSourcesProcessed = 10,
    UpdateGameThreadCopies = 11,
    Finished = 12
};

enum EMusicalNoteName : uint8_t
{
    EMusicalNoteName__C = 0,
    EMusicalNoteName__Db = 1,
    EMusicalNoteName__D = 2,
    EMusicalNoteName__Eb = 3,
    EMusicalNoteName__E = 4,
    EMusicalNoteName__F = 5,
    EMusicalNoteName__Gb = 6,
    EMusicalNoteName__G = 7,
    EMusicalNoteName__Ab = 8,
    EMusicalNoteName__A = 9,
    EMusicalNoteName__Bb = 10,
    EMusicalNoteName__B = 11
};

enum ESubmixEffectDynamicsPeakMode : uint8_t
{
    ESubmixEffectDynamicsPeakMode__MeanSquared = 0,
    ESubmixEffectDynamicsPeakMode__RootMeanSquared = 1,
    ESubmixEffectDynamicsPeakMode__Peak = 2,
    ESubmixEffectDynamicsPeakMode__Count = 3
};

enum ESubmixEffectDynamicsChannelLinkMode : uint8_t
{
    ESubmixEffectDynamicsChannelLinkMode__Disabled = 0,
    ESubmixEffectDynamicsChannelLinkMode__Average = 1,
    ESubmixEffectDynamicsChannelLinkMode__Peak = 2,
    ESubmixEffectDynamicsChannelLinkMode__Count = 3
};

enum EGameplayContainerMatchType : uint8_t
{
    EGameplayContainerMatchType__Any = 0,
    EGameplayContainerMatchType__All = 1
};

enum EGameplayTagSelectionType : uint8_t
{
    EGameplayTagSelectionType__None = 0,
    EGameplayTagSelectionType__NonRestrictedOnly = 1,
    EGameplayTagSelectionType__RestrictedOnly = 2,
    EGameplayT______D__O_______2_C = 3
};

enum EMovieSceneCaptureProtocolState : uint8_t
{
    EMovieSceneCaptureProtocolState__Idle = 0,
    EMovieSceneCaptureProtocolState__Initialized = 1,
    EMovieSceneCaptureProtocolState__Capturing = 2,
    EMovieSceneCaptureProtocolState__Finalizing = 3
};

enum EMediaPlayerOptionBooleanOverride : uint8_t
{
    EMediaPlayerOptionBooleanOverride__UseMediaPlayerSetting = 0,
    EMediaPlayerOptionBooleanOverride__Enabled = 1,
    EMediaPlayerOptionBooleanOverride__Disabled = 2
};

enum EMediaPlayerOptionSeekTimeType : uint8_t
{
    EMediaPlayerOptionSeekTimeType__Ignored = 0,
    EMediaPlayerOptionSeekTimeType__RelativeToStartTime = 1
};

enum EMediaPlayerOptionTrackSelectMode : uint8_t
{
    EMediaPlayerOptionTrackSelectMode__UseMediaPlayerDefaults = 0,
    EMediaPlayerOptionTrackSelectMode__UseTrackOptionIndices = 1
};

enum MediaTextureOutputFormat : uint8_t
{
    MTOF_Default = 0,
    MTOF_SRGB_LINOUT = 1
};

enum EMediaTimeRangeBPType : uint8_t
{
    EMediaTimeRangeBPType__Absolute = 0,
    EM__n_c__u______w__P______x_2D = 1
};

enum EMediaSoundChannels : uint8_t
{
    EMediaSoundChannels__Mono = 0,
    EMediaSoundChannels__Stereo = 1,
    EMediaSoundChannels__Surround = 2
};

enum EMediaTextureVisibleMipsTiles : uint8_t
{
    EMediaTextureVisibleMipsTiles__None = 0,
    EMediaTextureVisibleMipsTiles__Plane = 1,
    EMediaTextureVisibleMipsTiles__Sphere = 2
};

enum EHttpReplayResult : uint8_t
{
    EHttpReplayResult__Success = 0,
    EHttpReplayResult__FailedJsonParse = 1,
    EHttpReplayResult__DataUnavailable = 2,
    EHttpReplayResult__InvalidHttpResponse = 3,
    EHttpReplayResult__CompressionFailed = 4,
    EHttpReplayResult__DecompressionFailed = 5,
    EHttpReplayResult__InvalidPayload = 6,
    EHttpReplayResult__Unknown = 7
};

enum EMassCommandOperationType : uint8_t
{
    EMassCommandOperationType__None = 0,
    EMassCommandOperationType__Create = 1,
    EMassCommandOperationType__Add = 2,
    EMassCommandOperationType__Remove = 3,
    EMassCommandOperationType__ChangeComposition = 4,
    EMassCommandOperationType__Set = 5,
    EMassCommandOperationType__Destroy = 6
};

enum EMassObservedOperation : uint8_t
{
    EMassObservedOperation__Add = 0,
    EMassObservedOperation__Remove = 1
};

enum EProcessorExecutionFlags : uint8_t
{
    EProcessorExecutionFlags__None = 0,
    EProcessorExecutionFlags__Standalone = 1,
    EProcessorExecutionFlags__Server = 2,
    EProcessorExecutionFlags__Client = 4,
    EProcessorExecutionFlags__Editor = 8,
    EProcessorExecutionFlags__EditorWorld = 16,
    EProcessorExecutionFlags__AllNetModes = 7,
    EProcessorExecutionFlags__AllWorldModes = 23,
    EProcessorExecutionFlags__All = 31
};

enum EMassProcessingPhase : uint8_t
{
    EMassProcessingPhase__PrePhysics = 0,
    EMassProcessingPhase__StartPhysics = 1,
    EMassProcessingPhase__DuringPhysics = 2,
    EMassProcessingPhase__EndPhysics = 3,
    EMassProcessingPhase__PostPhysics = 4,
    EMassProcessingPhase__FrameEnd = 5
};

enum EAnimAssetCurveFlags : uint8_t
{
    AACF_NONE = 0,
    AACF_DriveMorphTarget_DEPRECATED = 1,
    AACF_DriveAttribute_DEPRECATED = 2,
    AACF_Editable = 4,
    AACF_DriveMaterial_DEPRECATED = 8,
    AACF_Metadata = 16,
    AACF_DriveTrack = 32,
    AACF_Disabled = 64
};

enum AnimationCompressionFormat : uint8_t
{
    ACF_None = 0,
    ACF_Float96NoW = 1,
    ACF_Fixed48NoW = 2,
    ACF_IntervalFixed32NoW = 3,
    ACF_Fixed32NoW = 4,
    ACF_Float32NoW = 5,
    ACF_Identity = 6
};

enum ECurveBlendOption : uint8_t
{
    ECurveBlendOption__Override = 0,
    ECurveBlendOption__DoNotOverride = 1,
    ECurveBlendOption__NormalizeByWeight = 2,
    ECurveBlendOption__BlendByWeight = 3,
    ECurveBlendOption__UseBasePose = 4,
    ECurveBlendOption__UseMaxValue = 5,
    ECurveBlendOption__UseMinValue = 6
};

enum EBlendableLocation : uint8_t
{
    BL_SceneColorBeforeDOF = 2,
    BL_SceneColorAfterDOF = 1,
    BL_TranslucencyAfterDOF = 5,
    BL_SSRInput = 4,
    BL_SceneColorBeforeBloom = 6,
    BL_ReplacingTonemapper = 3,
    BL_SceneColorAfterTonemapping = 0,
    BL_BeforeTranslucency = 2,
    BL_BeforeTonemapping = 1,
    BL_AfterTonemapping = 0
};

enum EBlueprintStatus : uint8_t
{
    BS_Unknown = 0,
    BS_Dirty = 1,
    BS_Error = 2,
    BS_UpToDate = 3,
    BS_BeingCreated = 4,
    BS_UpToDateWithWarnings = 5
};

enum EBlueprintType : uint8_t
{
    BPTYPE_Normal = 0,
    BPTYPE_Const = 1,
    BPTYPE_MacroLibrary = 2,
    BPTYPE_Interface = 3,
    BPTYPE_LevelScript = 4,
    BPTYPE_FunctionLibrary = 5
};

enum ECsgOper : uint8_t
{
    CSG_Active = 0,
    CSG_Add = 1,
    CSG_Subtract = 2,
    CSG_Intersect = 3,
    CSG_Deintersect = 4,
    CSG_None = 5
};

enum ECloudStorageDelegate : uint8_t
{
    CSD_KeyValueReadComplete = 0,
    CSD_KeyValueWriteComplete = 1,
    CSD_ValueChanged = 2,
    CSD_DocumentQueryComplete = 3,
    CSD_DocumentReadComplete = 4,
    CSD_DocumentWriteComplete = 5,
    CSD_DocumentConflictDetected = 6
};

enum EContentBundleClientState : uint8_t
{
    EContentBundleClientState__Unregistered = 0,
    EContentBundleClientState__Registered = 1,
    EContentBundleClientState__ContentInjectionRequested = 2,
    EContentBundleClientState__ContentRemovalRequested = 3,
    EContentBundleClientState__RegistrationFailed = 4
};

enum EContentBundleStatus : uint8_t
{
    EContentBundleStatus__Registered = 0,
    EContentBundleStatus__ReadyToInject = 1,
    EContentBundleStatus__FailedToInject = 2,
    EContentBundleStatus__ContentInjected = 3,
    EContentBundleStatus__Unknown = -1
};

enum ENodeTitleType : uint8_t
{
    ENodeTitleType__FullTitle = 0,
    ENodeTitleType__ListView = 1,
    ENodeTitleType__EditableTitle = 2,
    ENodeTitleType__MenuTitle = 3,
    ENodeTitleType__MAX_TitleTypes = 4
};

enum ECanCreateConnectionResponse : uint8_t
{
    CONNECT_RESPONSE_MAKE = 0,
    CONNECT_RESPONSE_DISALLOW = 1,
    CONNECT_RESPONSE_BREAK_OTHERS_A = 2,
    CONNECT_RESPONSE_BREAK_OTHERS_B = 3,
    CONNECT_RESPONSE_BREAK_OTHERS_AB = 4,
    CONNECT_RESPONSE_MAKE_WITH_CONVERSION_NODE = 5,
    CONNECT_RESPONSE_MAKE_WITH_PROMOTION = 6
};

enum ETransitionType : uint8_t
{
    ETransitionType__None = 0,
    ETransitionType__Paused = 1,
    ETransitionType__Loading = 2,
    ETransitionType__Saving = 3,
    ETransitionType__Connecting = 4,
    ETransitionType__Precaching = 5,
    ETransitionType__WaitingToConnect = 6
};

enum EMouseCaptureMode : uint8_t
{
    EMouseCaptureMode__NoCapture = 0,
    EMouseCaptureMode__CapturePermanently = 1,
    EMouseCaptureMode__CapturePermanently_IncludingInitialMouseDown = 2,
    EMouseCaptureMode__CaptureDuringMouseDown = 3,
    EMouseCaptureMode__CaptureDuringRightMouseDown = 4
};

enum EDemoPlayFailure : uint8_t
{
    EDemoPlayFailure__Generic = 0,
    EDemoPlayFailure__DemoNotFound = 1,
    EDemoPlayFailure__Corrupt = 2,
    EDemoPlayFailure__InvalidVersion = 3,
    EDemoPlayFailure__InitBase = 4,
    EDemoPlayFailure__GameSpecificHeader = 5,
    EDemoPlayFailure__ReplayStreamerInternal = 6,
    EDemoPlayFailure__LoadMap = 7,
    EDemoPlayFailure________f__DW__ = 8
};

enum EViewModeIndex : uint8_t
{
    VMI_BrushWireframe = 0,
    VMI_Wireframe = 1,
    VMI_Unlit = 2,
    VMI_Lit = 3,
    VMI_Lit_DetailLighting = 4,
    VMI_LightingOnly = 5,
    VMI_LightComplexity = 6,
    VMI_ShaderComplexity = 8,
    VMI_LightmapDensity = 9,
    VMI_LitLightmapDensity = 10,
    VMI_ReflectionOverride = 11,
    VMI_VisualizeBuffer = 12,
    VMI_StationaryLightOverlap = 14,
    VMI_CollisionPawn = 15,
    VMI_CollisionVisibility = 16,
    VMI_LODColoration = 18,
    VMI_QuadOverdraw = 19,
    VMI_PrimitiveDistanceAccuracy = 20,
    VMI_MeshUVDensityAccuracy = 21,
    VMI_ShaderComplexityWithQuadOverdraw = 22,
    VMI_HLODColoration = 23,
    VMI_GroupLODColoration = 24,
    VMI_MaterialTextureScaleAccuracy = 25,
    VMI_RequiredTextureResolution = 26,
    VMI_PathTracing = 27,
    VMI_RayTracingDebug = 28,
    VMI_VisualizeNanite = 29,
    VMI_VirtualTexturePendingMips = 30,
    VMI_VisualizeLumen = 31,
    VMI_VisualizeVirtualShadowMap = 32,
    VMI_VisualizeGPUSkinCache = 33,
    VMI_VisualizeSubstrate = 34,
    VMI_VisualizeGroom = 35,
    VMI_LWCComplexity = 36,
    VMI_Lit_Wireframe = 37,
    VMI_VisualizeActorColoration = 38,
    VMI_Max = 39,
    VMI_Unknown = 255
};

enum EBlendMode : uint8_t
{
    BLEND_Opaque = 0,
    BLEND_Masked = 1,
    BLEND_Translucent = 2,
    BLEND_Additive = 3,
    BLEND_Modulate = 4,
    BLEND_AlphaComposite = 5,
    BLEND_AlphaHoldout = 6,
    BLEND_TranslucentColoredTransmittance = 7,
    BLEND_TranslucentGreyTransmittance = 2,
    BLEND_ColoredTransmittanceOnly = 4
};

enum EMaterialFloatPrecisionMode : uint8_t
{
    MFPM_Default = 0,
    MFPM_Full_MaterialExpressionOnly = 1,
    MFPM_Full = 2,
    MFPM_Half = 3
};

enum ETranslucencyLightingMode : uint8_t
{
    TLM_VolumetricNonDirectional = 0,
    TLM_VolumetricDirectional = 1,
    TLM_VolumetricPerVertexNonDirectional = 2,
    TLM_VolumetricPerVertexDirectional = 3,
    TLM_Surface = 4,
    TLM_SurfacePerPixelLighting = 5
};

enum EReflectionMethod : uint8_t
{
    EReflectionMethod__None = 0,
    EReflectionMethod__Lumen = 1,
    EReflectionMethod__ScreenSpace = 2
};

enum ECastRayTracedShadow : uint8_t
{
    ECastRayTracedShadow__Disabled = 0,
    ECastRayTracedShadow__UseProjectSetting = 1,
    ECastRayTracedShadow__Enabled = 2
};

enum EMegaLightsShadowMethod : uint8_t
{
    EMegaLightsShadowMethod__Default = 0,
    EMegaLightsShadowMethod__RayTracing = 1,
    EMegaLightsShadowMethod__VirtualShadowMap = 2
};

enum ESceneCaptureSource : uint8_t
{
    SCS_SceneColorHDR = 0,
    SCS_SceneColorHDRNoAlpha = 1,
    SCS_FinalColorLDR = 2,
    SCS_SceneColorSceneDepth = 3,
    SCS_SceneDepth = 4,
    SCS_DeviceDepth = 5,
    SCS_Normal = 6,
    SCS_BaseColor = 7,
    SCS_FinalColorHDR = 8,
    SCS_FinalToneCurveHDR = 9
};

enum ESceneCaptureCompositeMode : uint8_t
{
    SCCM_Overwrite = 0,
    SCCM_Additive = 1,
    SCCM_Composite = 2
};

enum EMobileLocalLightSetting : uint8_t
{
    LOCAL_LIGHTS_DISABLED = 0,
    LOCAL_LIGHTS_ENABLED = 1,
    LOCAL_LIGHTS_BUFFER = 2
};

enum ETrailWidthMode : uint8_t
{
    ETrailWidthMode_FromCentre = 0,
    ETrailWidthMode_FromFirst = 1,
    ETrailWidthMode_FromSecond = 2
};

enum EMaterialSamplerType : uint8_t
{
    SAMPLERTYPE_Color = 0,
    SAMPLERTYPE_Grayscale = 1,
    SAMPLERTYPE_Alpha = 2,
    SAMPLERTYPE_Normal = 3,
    SAMPLERTYPE_Masks = 4,
    SAMPLERTYPE_DistanceFieldFont = 5,
    SAMPLERTYPE_LinearColor = 6,
    SAMPLERTYPE_LinearGrayscale = 7,
    SAMPLERTYPE_Data = 8,
    SAMPLERTYPE_External = 9,
    SAMPLERTYPE_VirtualColor = 10,
    SAMPLERTYPE_VirtualGrayscale = 11,
    SAMPLERTYPE_VirtualAlpha = 12,
    SAMPLERTYPE_VirtualNormal = 13,
    SAMPLERTYPE_VirtualMasks = 14,
    SAMPLERTYPE_VirtualLinearColor = 15,
    SAMPLERTYPE_VirtualLinearGrayscale = 16
};

enum EMaterialStencilCompare : uint8_t
{
    MSC_Less = 0,
    MSC_LessEqual = 1,
    MSC_Greater = 2,
    MSC_GreaterEqual = 3,
    MSC_Equal = 4,
    MSC_NotEqual = 5,
    MSC_Never = 6,
    MSC_Always = 7,
    MSC_Count = 8
};

enum EMaterialShadingRate : uint8_t
{
    MSR_1x1 = 0,
    MSR_2x1 = 1,
    MSR_1x2 = 2,
    MSR_2x2 = 3,
    MSR_4x2 = 4,
    MSR_2x4 = 5,
    MSR_4x4 = 6,
    MSR_Count = 7
};

enum ENetworkSmoothingMode : uint8_t
{
    ENetworkSmoothingMode__Disabled = 0,
    ENetworkSmoothingMode__Linear = 1,
    ENetworkSmoothingMode__Exponential = 2
};

enum EFilterInterpolationType : uint8_t
{
    BSIT_Average = 0,
    BSIT_Linear = 1,
    BSIT_Cubic = 2,
    BSIT_EaseInOut = 3,
    BSIT_ExponentialDecay = 4,
    BSIT_SpringDamper = 5
};

enum ETimelineSigType : uint8_t
{
    ETS_EventSignature = 0,
    ETS_FloatSignature = 1,
    ETS_VectorSignature = 2,
    ETS_LinearColorSignature = 3,
    ETS_InvalidSignature = 4
};

enum ENetDormancy : uint8_t
{
    DORM_Never = 0,
    DORM_Awake = 1,
    DORM_DormantAll = 2,
    DORM_D_________u___ = 3,
    DORM_Initial = 4
};

enum EAutoReceiveInput : uint8_t
{
    EAutoReceiveInput__Disabled = 0,
    EAutoReceiveInput__Player0 = 1,
    EAutoReceiveInput__Player1 = 2,
    EAutoReceiveInput__Player2 = 3,
    EAutoReceiveInput__Player3 = 4,
    EAutoReceiveInput__Player4 = 5,
    EAutoReceiveInput__Player5 = 6,
    EAutoReceiveInput__Player6 = 7,
    EAutoReceiveInput__Player7 = 8
};

enum EAutoPossessAI : uint8_t
{
    EAutoPossessAI__Disabled = 0,
    EAutoPossessAI__PlacedInWorld = 1,
    EAutoPossessAI__Spawned = 2,
    EAutoPossessAI__PlacedInWorldOrSpawned = 3
};

enum EPhysicalMaterialMaskColor : uint8_t
{
    EPhysicalMaterialMaskColor__Red = 0,
    EPhysicalMaterialMaskColor__Green = 1,
    EPhysicalMaterialMaskColor__Blue = 2,
    EPhysicalMaterialMaskColor__Cyan = 3,
    EPhysicalMaterialMaskColor__Magenta = 4,
    EPhysicalMaterialMaskColor__Yellow = 5,
    EPhysicalMaterialMaskColor__White = 6,
    EPhysicalMaterialMaskColor__Black = 7
};

enum ESpawnActorCollisionHandlingMethod : uint8_t
{
    ESpawnActorCollisionHandlingMethod__Undefined = 0,
    ESpawnActorCollisionHandlingMethod__AlwaysSpawn = 1,
    ESpawnActorCollisionHandlingMethod__AdjustIfPossibleButAlwaysSpawn = 2,
    ESpawnActorCollisionHandlingMethod__AdjustIfPossibleButDontSpawnIfColliding = 3,
    ESpawnActorCollisionHandlingMethod__DontSpawnIfColliding = 4
};

enum EHitProxyPriority : uint8_t
{
    HPP_World = 0,
    HPP_Wireframe = 1,
    HPP_Foreground = 2,
    HPP_UI = 3
};

enum EHierarchicalSimplificationMethod : uint8_t
{
    EHierarchicalSimplificationMethod__None = 0,
    EHierarchicalSimplificationMethod__Merge = 1,
    EHierarchicalSimplificationMethod__Simplify = 2,
    EHierarchicalSimplificationMethod__Approximate = 3
};

enum EViewStatusForScreenPercentage : uint8_t
{
    EViewStatusForScreenPercentage__NonRealtime = 0,
    EViewStatusForScreenPercentage__Desktop = 1,
    EViewStatusForScreenPercentage__Mobile = 2,
    EViewStatusForScreenPercentage__VR = 3,
    EViewStatusForScreenPercentage__PathTracer = 4
};

enum ELevelInstanceRuntimeBehavior : uint8_t
{
    ELevelInstanceRuntimeBehavior__None = 0,
    ELevelInstanceRuntimeBehavior__Embedded_Deprecated = 1,
    ELevelInstanceRuntimeBehavior__Partitioned = 2,
    ELevelInstanceRuntimeBehavior__LevelStreaming = 3
};

enum ELevelInstancePivotType : uint8_t
{
    ELevelInstancePivotType__CenterMinZ = 0,
    ELevelInstancePivotType__Center = 1,
    ELevelInstancePivotType__Actor = 2,
    ELevelInstancePivotType__WorldOrigin = 3
};

enum EMaterialDomain : uint8_t
{
    MD_Surface = 0,
    MD_DeferredDecal = 1,
    MD_LightFunction = 2,
    MD_Volume = 3,
    MD_PostProcess = 4,
    MD_UI = 5,
    MD_RuntimeVirtualTexture = 6
};

enum EChannelMaskParameterColor : uint8_t
{
    EChannelMaskParameterColor__Red = 0,
    EChannelMaskParameterColor__Green = 1,
    EChannelMaskParameterColor__Blue = 2,
    EChannel__7H____YV____K_____V__f_ = 3
};

enum ECustomMaterialOutputType : uint8_t
{
    CMOT_Float1 = 0,
    CMOT_Float2 = 1,
    CMOT_Float3 = 2,
    CMOT_Float4 = 3,
    CMOT_MaterialAttributes = 4
};

enum EFloatToIntMode : uint8_t
{
    EFloatToIntMode__Truncate = 0,
    EFloatToIntMode__Floor = 1,
    EFloatToIntMode__Round = 2,
    EFloatToIntMode__Ceil = 3
};

enum ENoiseFunction : uint8_t
{
    NOISEFUNCTION_SimplexTex = 0,
    NOISEFUNCTION_GradientTex = 1,
    NOISEFUNCTION_GradientTex3D = 2,
    NOISEFUNCTION_GradientALU = 3,
    NOISEFUNCTION_ValueALU = 4,
    NOISEFUNCTION_VoronoiALU = 5
};

enum EPathTracingBufferTextureId : uint8_t
{
    PTBT_Radiance = 0,
    PTBT_DenoisedRadiance = 1,
    PTBT_Albedo = 2,
    PTBT_Normal = 3,
    PTBT_Variance = 4
};

enum ERuntimeVirtualTextureMipValueMode : uint8_t
{
    RVTMVM_None = 0,
    RVTMVM_MipLevel = 1,
    RVTMVM_MipBias = 2,
    RVTMVM_RecalculateDerivatives = 3,
    RVTMVM_DerivativeUV = 4,
    RVTMVM_DerivativeWorld = 5
};

enum ESpeedTreeGeometryType : uint8_t
{
    STG_Branch = 0,
    STG_Frond = 1,
    STG_Leaf = 2,
    STG_FacingLeaf = 3,
    STG_Billboard = 4
};

enum ETextureCollectionMemberType : uint8_t
{
    ETextureCollectionMemberType__Texture2D = 0,
    ETextureCollectionMemberType__TextureCube = 1,
    ETextureCollectionMemberType__Texture2DArray = 2,
    ETextureCollectionMemberType__TextureCubeArray = 3,
    ETextureCollectionMemberType__TextureVolume = 4,
    ETextureCollectionMemberType__Max = 5
};

enum EMaterialVectorCoordTransformSource : uint8_t
{
    TRANSFORMSOURCE_Tangent = 0,
    TRANSFORMSOURCE_Local = 1,
    TRANSFORMSOURCE_World = 2,
    TRANSFORMSOURCE_View = 3,
    TRANSFORMSOURCE_Camera = 4,
    TRANSFORMSOURCE_ParticleWo__5 = 5,
    TRANSFORMSOURCE_Instance = 6
};

enum EMaterialVectorCoordTransform : uint8_t
{
    TRANSFORM_Tangent = 0,
    TRANSFORM_Local = 1,
    TRANSFORM_World = 2,
    TRANSFORM_View = 3,
    TRANSFORM_Camera = 4,
    TRANSFORM_ParticleWorld = 5,
    TRANSFORM_Instance = 6
};

enum EMaterialPositionTransformSource : uint8_t
{
    TRANSFORMPOSSOURCE_Local = 0,
    TRANSFORMPOSSOURCE_World = 1,
    TRANSFORMPOSSOURCE_PeriodicWorld = 2,
    TRANSFORMPOSSOURCE_TranslatedWorld = 3,
    TRANSFORMPOSSOURCE_View = 4
};

enum EVectorNoiseFunction : uint8_t
{
    VNF_CellnoiseALU = 0,
    VNF_VectorALU = 1,
    VNF_GradientALU = 2,
    VNF_CurlALU = 3,
    VNF_VoronoiALU = 4
};

enum EMaterialExposedViewProperty : uint8_t
{
    MEVP_BufferSize = 0,
    MEVP_FieldOfView = 1,
    MEVP_TanHalfFieldOfView = 2,
    MEVP_ViewSize = 3,
    MEVP_WorldSpaceViewPosition = 4,
    MEVP_WorldSpaceCameraPosition = 5,
    MEVP_ViewportOffset = 6,
    MEVP_TemporalSampleCount = 7,
    MEVP_TemporalSampleIndex = 8,
    MEVP_TemporalSampleOffset = 9,
    MEVP_RuntimeVirtualTextureOutputLevel = 10,
    MEVP_RuntimeVirtualTextureOutputDerivative = 11,
    MEVP_PreExposure = 12,
    MEVP_RuntimeVirtualTextureMaxLevel = 13,
    MEVP_ResolutionFraction = 14,
    MEVP_PostVolumeUserFlags = 15
};

enum EMaterialUsage : uint8_t
{
    MATUSAGE_SkeletalMesh = 0,
    MATUSAGE_ParticleSprites = 1,
    MATUSAGE_BeamTrails = 2,
    MATUSAGE_MeshParticles = 3,
    MATUSAGE_StaticLighting = 4,
    MATUSAGE_MorphTargets = 5,
    MATUSAGE_SplineMesh = 6,
    MATUSAGE_InstancedStaticMeshes = 7,
    MATUSAGE_GeometryCollections = 8,
    MATUSAGE_Clothing = 9,
    MATUSAGE_NiagaraSprites = 10,
    MATUSAGE_NiagaraRibbons = 11,
    MATUSAGE_NiagaraMeshParticles = 12,
    MATUSAGE_GeometryCache = 13,
    MATUSAGE_Water = 14,
    MATUSAGE_HairStrands = 15,
    MATUSAGE_LidarPointCloud = 16,
    MATUSAGE_VirtualHeightfieldMesh = 17,
    MATUSAGE_Nanite = 18,
    MATUSAGE_VolumetricCloud = 19,
    MATUSAGE_HeterogeneousVolumes = 20
};

enum EMaterialLayerLinkState : uint8_t
{
    EMaterialLayerLinkState__Uninitialized = 0,
    EMaterialLayerLinkState__LinkedToParent = 1,
    EMaterialLayerLinkState__UnlinkedFromParent = 2,
    EMaterialLayerLinkState__NotFromParent = 3
};

enum ETextureSizingType : uint8_t
{
    TextureSizingType_UseSingleTextureSize = 0,
    TextureSizingType_UseAutomaticBiasedSizes = 1,
    TextureSizingType_UseManualOverrideTextureSize = 2,
    TextureSizingType_UseSimplygonAutomaticSizing = 3,
    TextureSizingType_AutomaticFromTexelDensity = 4,
    TextureSizingType_AutomaticFromMeshScreenSize = 5,
    TextureSizingType_AutomaticFromMeshDrawDistance = 6
};

enum ESceneTextureId : uint8_t
{
    PPI_SceneColor = 0,
    PPI_SceneDepth = 1,
    PPI_DiffuseColor = 2,
    PPI_SpecularColor = 3,
    PPI_SubsurfaceColor = 4,
    PPI_BaseColor = 5,
    PPI_Specular = 6,
    PPI_Metallic = 7,
    PPI_WorldNormal = 8,
    PPI_SeparateTranslucency = 9,
    PPI_Opacity = 10,
    PPI_Roughness = 11,
    PPI_MaterialAO = 12,
    PPI_CustomDepth = 13,
    PPI_PostProcessInput0 = 14,
    PPI_PostProcessInput1 = 15,
    PPI_PostProcessInput2 = 16,
    PPI_PostProcessInput3 = 17,
    PPI_PostProcessInput4 = 18,
    PPI_PostProcessInput5 = 19,
    PPI_PostProcessInput6 = 20,
    PPI_DecalMask = 21,
    PPI_ShadingModelColor = 22,
    PPI_ShadingModelID = 23,
    PPI_AmbientOcclusion = 24,
    PPI_CustomStencil = 25,
    PPI_StoredBaseColor = 26,
    PPI_StoredSpecular = 27,
    PPI_Velocity = 28,
    PPI_WorldTangent = 29,
    PPI_Anisotropy = 30,
    PPI_UserSceneTexture0 = 32,
    PPI_UserSceneTexture1 = 33,
    PPI_UserSceneTexture2 = 34,
    PPI_UserSceneTexture3 = 35,
    PPI_UserSceneTexture4 = 36,
    PPI_UserSceneTexture5 = 37,
    PPI_UserSceneTexture6 = 38
};

enum ELWCFunctionKind : uint8_t
{
    ELWCFunctionKind__Constructor = 0,
    ELWCFunctionKind__Promote = 1,
    ELWCFunctionKind__Demote = 2,
    ELWCFunctionKind__Add = 3,
    ELWCFunctionKind__Subtract = 4,
    ELWCFunctionKind__Divide = 5,
    ELWCFunctionKind__MultiplyVectorVector = 6,
    ELWCFunctionKind__MultiplyVectorMatrix = 7,
    ELWCFunctionKind__MultiplyMatrixMatrix = 8,
    ELWCFunctionKind__Other = 9,
    ELWCFunctionKind__Max = 10
};

enum EMaterialParameterType : uint16_t
{
    EMaterialParameterType__Scalar = 0,
    EMaterialParametB__Y______v__B = 1,
    EMaterialParameterType__DoubleVector = 2,
    EMaterialParameterType__Texture = 3,
    EMaterialParameterType__TextureCollection = 4,
    EMaterialParameterType__Font = 5,
    EMaterialParameterType__RuntimeVirtualTexture = 6,
    EMaterialParameterType__SparseVolumeTexture = 7,
    EMaterialParameterType__StaticSwitch = 8,
    EMaterialParameterType__NumRuntime = 9,
    EMaterialParameterType__StaticComponentMask = 9,
    EMaterialParameterType__Num = 10,
    EMaterialParameterType__None = 255
};

enum EMeshApproximationGroundPlaneClippingPolicy : uint8_t
{
    EMeshApproximationGroundPlaneClippingPolicy__NoGroundClipping = 0,
    EMeshApproximationGroundPlaneClippingPolicy__DiscardWithZPlane = 1,
    EMeshApproximationGroundPlaneClippingPolicy__CutWithZPlane = 2,
    EMeshApproximationGroundPlaneClippingPolicy__CutAndFillWithZPlane = 3
};

enum EMeshLODSelectionType : uint8_t
{
    EMeshLODSelectionType__AllLODs = 0,
    EMeshLODSelectionType__SpecificLOD = 1,
    EMeshLODSelectionType__CalculateLOD = 2,
    EMeshLODSelectionType__LowestDetailLOD = 3
};

enum EMeshFeatureImportance : uint8_t
{
    EMeshFeatureImportance__Off = 0,
    EMeshFeatureImportance__Lowest = 1,
    EMeshFeatureImportance__Low = 2,
    EMeshFeatureImportance__Normal = 3,
    EMeshFeatureImportance__High = 4,
    EMeshFeatureImportance__Highest = 5
};

enum EPingType : uint8_t
{
    EPingType__None = 0,
    EPingType__RoundTrip = 1,
    EPingType__RoundTripExclFrame = 2,
    EPingType__ICMP = 4,
    EPingType__UDPQoS = 8,
    EPingType__Max = 8,
    EPingType__Count = 4
};

enum EEmitterRenderMode : uint8_t
{
    ERM_Normal = 0,
    ERM_Point = 1,
    ERM_Cross = 2,
    ERM_LightsOnly = 3,
    ERM_None = 4
};

enum EParticleSignificanceLevel : uint8_t
{
    EParticleSignificanceLevel__Low = 0,
    EParticleSignificanceLevel__Medium = 1,
    EParticleSignificanceLevel__High = 2,
    EParticleSignificanceLevel__Critical = 3,
    EParticleSignificanceLevel__Num = 4
};

enum EParticleSystemInsignificanceReaction : uint8_t
{
    EParticleSystemInsignificanceReaction__Auto = 0,
    EParticleSystemInsignificanceReaction__Complete = 1,
    EParticleSystemInsignificanceReaction__DisableTick = 2,
    EParticleSystemInsignificanceReaction__DisableTickAndKill = 3,
    EParticleSystemInsignificanceReaction__Num = 4
};

enum EModuleType : uint8_t
{
    EPMT_General = 0,
    EPMT_TypeData = 1,
    EPMT_Beam = 2,
    EPMT_Trail = 3,
    EPMT_Spawn = 4,
    EPMT_Required = 5,
    EPMT_Event = 6,
    EPMT_Light = 7,
    EPMT_SubUV = 8
};

enum EParticleCollisionComplete : uint8_t
{
    EPCC_Kill = 0,
    EPCC_Freeze = 1,
    EPCC_HaltCollisions = 2,
    EPCC_FreezeTranslation = 3,
    EPCC_FreezeRotation = 4,
    EPCC_FreezeMovement = 5
};

enum EParticleAxisLock : uint8_t
{
    EPAL_NONE = 0,
    EPAL_X = 1,
    EPAL_Y = 2,
    EPAL_Z = 3,
    EPAL_NEGATIVE_X = 4,
    EPAL_NEGATIVE_Y = 5,
    EPAL_NEGATIVE_Z = 6,
    EPAL_ROTATE_X = 7,
    EPAL_ROTATE_Y = 8,
    EPAL_ROTATE_Z = 9
};

enum EEmitterDynamicParameterValue : uint8_t
{
    EDPV_UserSet = 0,
    EDPV_AutoSet = 1,
    EDPV_VelocityX = 2,
    EDPV_VelocityY = 3,
    EDPV_VelocityZ = 4,
    EDPV_VelocityMag = 5
};

enum EParticleUVFlipMode : uint8_t
{
    EParticleUVFlipMode__None = 0,
    EParticleUVFlipMode__FlipUV = 1,
    EParticleUVFlipMode__FlipUOnly = 2,
    EParticleUVFlipMode__FlipVOnly = 3,
    EParticleUVFlipMode__RandomFlipUV = 4,
    EParticleUVFlipMode__RandomFlipUOnly = 5,
    EParticleUVFlipMode__RandomFlipVOnly = 6,
    EParticleUVFlipMode__RandomFlipUVIndependent = 7
};

enum EMeshCameraFacingUpAxis : uint8_t
{
    CameraFacing_NoneUP = 0,
    CameraFacing_ZUp = 1
};

enum EMeshCameraFacingOptions : uint8_t
{
    XAxisFacing_NoUp = 0,
    XAxisFacing_ZUp = 1,
    XAxisFacing_NegativeZUp = 2,
    XAxisFacing_YUp = 3,
    XAxisFacing_NegativeYUp = 4,
    LockedAxis_ZAxisFacing = 5,
    LockedAxis_NegativeZAxisFacing = 6,
    LockedAxis_YAxisFacing = 7,
    LockedAxis_NegativeYAxisFacing = 8,
    VelocityAligned_ZAxisFacing = 9,
    VelocityAligned_NegativeZAxisFacing = 10,
    VelocityAligned_YAxisFacing = 11,
    VelocityAligned_NegativeYAxisFacing = 12
};

enum EParticleScreenAlignment : uint8_t
{
    PSA_FacingCameraPosition = 0,
    PSA_Square = 1,
    PSA_Rectangle = 2,
    PSA_Velocity = 3,
    PSA_AwayFromCenter = 4,
    PSA_TypeSpecific = 5,
    PSA_FacingCameraDistanceBlend = 6
};

enum EViewTargetBlendFunction : uint8_t
{
    VTBlend_Linear = 0,
    VTBlend_Cubic = 1,
    VTBlend_EaseIn = 2,
    VTBlend_EaseOut = 3,
    VTBlend_EaseInOut = 4,
    VTBlend_PreBlended = 5
};

enum ERichCurveInterpMode : uint8_t
{
    RCIM_Linear = 0,
    RCIM_Constant = 1,
    RCIM_Cubic = 2,
    RCIM_None = 3
};

enum ERichCurveExtrapolation : uint8_t
{
    RCCE_Cycle = 0,
    RCCE_CycleWithOffset = 1,
    RCCE_Oscillate = 2,
    RCCE_Linear = 3,
    RCCE_Constant = 4,
    RCCE_None = 5
};

enum ReverbPreset : uint8_t
{
    REVERB_Default = 0,
    REVERB_Bathroom = 1,
    REVERB_StoneRoom = 2,
    REVERB_Auditorium = 3,
    REVERB_ConcertHall = 4,
    REVERB_Cave = 5,
    REVERB_Hallway = 6,
    REVERB_StoneCorridor = 7,
    REVERB_Alley = 8,
    REVERB_Forest = 9,
    REVERB_City = 10,
    REVERB_Mountains = 11,
    REVERB_Quarry = 12,
    REVERB_Plain = 13,
    REVERB_ParkingLot = 14,
    REVERB_SewerPipe = 15,
    REVERB_Underwater = 16,
    REVERB_SmallRoom = 17,
    REVERB_MediumRoom = 18,
    REVERB_LargeRoom = 19,
    REVERB_MediumHall = 20,
    REVERB_LargeHall = 21,
    REVERB_Plate = 22
};

enum ERichCurveTangentMode : uint8_t
{
    RCTM_Auto = 0,
    RCTM_User = 1,
    RCTM_Break = 2,
    RCTM_None = 3,
    RCTM_SmartAuto = 4
};

enum ERichCurveTangentWeightMode : uint8_t
{
    RCTWM_WeightedNone = 0,
    RCTWM_WeightedArrive = 1,
    RCTWM_WeightedLeave = 2,
    RCTWM_WeightedBoth = 3
};

enum ERichCurveCompressionFormat : uint8_t
{
    RCCF_Empty = 0,
    RCCF_Constant = 1,
    RCCF_Linear = 2,
    RCCF_Cubic = 3,
    RCCF_Mixed = 4,
    RCCF_Weighted = 5
};

enum ERuntimeVirtualTextureMaterialType : uint8_t
{
    ERuntimeVirtualTextureMaterialType__BaseColor = 0,
    ERuntimeVirtualTextureMaterialType__Mask4 = 1,
    ERuntimeVirtualTextureMaterialType__BaseColor_Normal_Roughness = 2,
    ERuntimeVirtualTextureMaterialType__BaseColor_Normal_Specular = 3,
    ERuntimeVirtualTextureMaterialType__BaseColor_Normal_Specular_YCoCg = 4,
    ERuntimeVirtualTextureMaterialType__BaseColor_Normal_Specular_Mask_YCoCg = 5,
    ERuntimeVirtualTextureMaterialType__WorldHeight = 6,
    ERuntimeVirtualTextureMaterialType__Displacement = 7,
    ERuntimeVirtualTextureMaterialType__Count = 8,
    ERuntimeVirtualTextureMaterialType__ERuntimeVirtualTextu_I____FM__4_Xs____ = 9
};

enum ELightUnits : uint8_t
{
    ELightUnits__Unitless = 0,
    ELightUnits__Candelas = 1,
    ELightUnits__Lumens = 2,
    ELightUnits__EV = 3
};

enum ELumenRayLightingModeOverride : uint8_t
{
    ELumenRayLightingModeOverride__Default = 0,
    ELumenRayLightingModeOverride__SurfaceCache = 1,
    ELumenRayLightingModeOverride__HitLightingForReflections = 2,
    ELumenRayLightingModeOverride__HitLighting = 3
};

enum EMobilePixelProjectedReflectionQuality : uint8_t
{
    EMobilePixelProjectedReflectionQuality__Disabled = 0,
    EMobilePixelProjectedReflectionQuality__BestPerformance = 1,
    EMobilePixelProjectedReflectionQuality__BetterQuality = 2,
    EMobilePixelProjectedReflectionQuality__BestQuality = 3
};

enum EMaterialProperty : uint8_t
{
    MP_EmissiveColor = 0,
    MP_Opacity = 1,
    MP_OpacityMask = 2,
    MP_DiffuseColor = 3,
    MP_SpecularColor = 4,
    MP_BaseColor = 5,
    MP_Metallic = 6,
    MP_Specular = 7,
    MP_Roughness = 8,
    MP_Anisotropy = 9,
    MP_Normal = 10,
    MP_Tangent = 11,
    MP_WorldPositionOffset = 12,
    MP_WorldDisplacement_DEPRECATED = 13,
    MP_TessellationMultiplier_DEPRECATED = 14,
    MP_SubsurfaceColor = 15,
    MP_CustomData0 = 16,
    MP_CustomData1 = 17,
    MP_AmbientOcclusion = 18,
    MP_Refraction = 19,
    MP_CustomizedUVs0 = 20,
    MP_CustomizedUVs1 = 21,
    MP_CustomizedUVs2 = 22,
    MP_CustomizedUVs3 = 23,
    MP_CustomizedUVs4 = 24,
    MP_CustomizedUVs5 = 25,
    MP_CustomizedUVs6 = 26,
    MP_CustomizedUVs7 = 27,
    MP_PixelDepthOffset = 28,
    MP_ShadingModel = 29,
    MP_FrontMaterial = 30,
    MP_SurfaceThickness = 31,
    MP_Displacement = 32,
    MP_MaterialAttributes = 33,
    MP_CustomOutput = 34
};

enum EAntiAliasingMethod : uint8_t
{
    AAM_None = 0,
    AAM_FXAA = 1,
    AAM_TemporalAA = 2,
    AAM_MSAA = 3,
    AAM_TSR = 4
};

enum SkeletalMeshOptimizationType : uint8_t
{
    SMOT_NumOfTriangles = 0,
    SMOT_MaxDeviation = 1,
    SMOT_TriangleOrDeviation = 2
};

enum ModulationParamMode : uint8_t
{
    MPM_Normal = 0,
    MPM_Abs = 1,
    MPM_Direct = 2
};

enum ESoundAssetCompressionType : uint8_t
{
    ESoundAssetCompressionType__BinkAudio = 0,
    ESoundAssetCompressionType__ADPCM = 1,
    ESoundAssetCompressionType__PCM = 2,
    ESoundAssetCompressionType__Opus = 3,
    ESoundAssetCompressionType__PlatformSpecific = 4,
    ESoundAssetCompressionType__ProjectDefined = 5,
    ESoundAssetCompressionType__RADAudio = 6
};

enum ESoundWaveLoadingBehavior : uint16_t
{
    ESoundWaveLoadingBehavior__Inherited = 0,
    ESoundWaveLoadingBehavior__RetainOnLoad = 1,
    ESoundWaveLoadingBehavior__PrimeOnLoad = 2,
    ESoundWaveLoadingBehavior__LoadOnDemand = 3,
    ESoundWaveLoadingBehavior__ForceInline = 4,
    ESoundWaveLoadingBehavior__Uninitialized = 255
};

enum EVerticalTextAligment : uint8_t
{
    EVRTA_TextTop = 0,
    EVRTA_TextCenter = 1,
    EVRTA_TextBottom = 2,
    EVRTA_QuadTop = 3
};

enum TextureGroup : uint8_t
{
    TEXTUREGROUP_World = 0,
    TEXTUREGROUP_WorldNormalMap = 1,
    TEXTUREGROUP_WorldSpecular = 2,
    TEXTUREGROUP_Character = 3,
    TEXTUREGROUP_CharacterNormalMap = 4,
    TEXTUREGROUP_CharacterSpecular = 5,
    TEXTUREGROUP_Weapon = 6,
    TEXTUREGROUP_WeaponNormalMap = 7,
    TEXTUREGROUP_WeaponSpecular = 8,
    TEXTUREGROUP_Vehicle = 9,
    TEXTUREGROUP_VehicleNormalMap = 10,
    TEXTUREGROUP_VehicleSpecular = 11,
    TEXTUREGROUP_Cinematic = 12,
    TEXTUREGROUP_Effects = 13,
    TEXTUREGROUP_EffectsNotFiltered = 14,
    TEXTUREGROUP_Skybox = 15,
    TEXTUREGROUP_UI = 16,
    TEXTUREGROUP_Lightmap = 17,
    TEXTUREGROUP_RenderTarget = 18,
    TEXTUREGROUP_MobileFlattened = 19,
    TEXTUREGROUP_ProcBuilding_Face = 20,
    TEXTUREGROUP_ProcBuilding_LightMap = 21,
    TEXTUREGROUP_Shadowmap = 22,
    TEXTUREGROUP_ColorLookupTable = 23,
    TEXTUREGROUP_Terrain_Heightmap = 24,
    TEXTUREGROUP_Terrain_Weightmap = 25,
    TEXTUREGROUP_Bokeh = 26,
    TEXTUREGROUP_IESLightProfile = 27,
    TEXTUREGROUP_Pixels2D = 28,
    TEXTUREGROUP_HierarchicalLOD = 29,
    TEXTUREGROUP_Impostor = 30,
    TEXTUREGROUP_ImpostorNormalDepth = 31,
    TEXTUREGROUP_8BitData = 32,
    TEXTUREGROUP_16BitData = 33,
    TEXTUREGROUP_Project01 = 34,
    TEXTUREGROUP_Project02 = 35,
    TEXTUREGROUP_Project03 = 36,
    TEXTUREGROUP_Project04 = 37,
    TEXTUREGROUP_Project05 = 38,
    TEXTUREGROUP_Project06 = 39,
    TEXTUREGROUP_Project07 = 40,
    TEXTUREGROUP_Project08 = 41,
    TEXTUREGROUP_Project09 = 42,
    TEXTUREGROUP_Project10 = 43,
    TEXTUREGROUP_Project11 = 44,
    TEXTUREGROUP_Project12 = 45,
    TEXTUREGROUP_Project13 = 46,
    TEXTUREGROUP_Project14 = 47,
    TEXTUREGROUP_Project15 = 48,
    TEXTUREGROUP_Project16 = 49,
    TEXTUREGROUP_Project17 = 50,
    TEXTUREGROUP_Project18 = 51,
    TEXTUREGROUP_Project19 = 52,
    TEXTUREGROUP_Project20 = 53,
    TEXTUREGROUP_Project21 = 54,
    TEXTUREGROUP_Project22 = 55,
    TEXTUREGROUP_Project23 = 56,
    TEXTUREGROUP_Project24 = 57,
    TEXTUREGROUP_Project25 = 58,
    TEXTUREGROUP_Project26 = 59,
    TEXTUREGROUP_Project27 = 60,
    TEXTUREGROUP_Project28 = 61,
    TEXTUREGROUP_Project29 = 62,
    TEXTUREGROUP_Project30 = 63,
    TEXTUREGROUP_Project31 = 64,
    TEXTUREGROUP_Project32 = 65
};

enum TextureMipGenSettings : uint8_t
{
    TMGS_FromTextureGroup = 0,
    TMGS_SimpleAverage = 1,
    TMGS_Sharpen0 = 2,
    TMGS_Sharpen1 = 3,
    TMGS_Sharpen2 = 4,
    TMGS_Sharpen3 = 5,
    TMGS_Sharpen4 = 6,
    TMGS_Sharpen5 = 7,
    TMGS_Sharpen6 = 8,
    TMGS_Sharpen7 = 9,
    TMGS_Sharpen8 = 10,
    TMGS_Sharpen9 = 11,
    TMGS_Sharpen10 = 12,
    TMGS_NoMipmaps = 13,
    TMGS_LeaveExistingMips = 14,
    TMGS_Blur1 = 15,
    TMGS_Blur2 = 16,
    TMGS_Blur3 = 17,
    TMGS_Blur4 = 18,
    TMGS_Blur5 = 19,
    TMGS_Unfiltered = 20,
    TMGS_Angular = 21
};

enum ETextureLossyCompressionAmount : uint8_t
{
    TLCA_Default = 0,
    TLCA_None = 1,
    TLCA_Lowest = 2,
    TLCA_Low = 3,
    TLCA_Medium = 4,
    TLCA_High = 5,
    TLCA_Highest = 6
};

enum ETextureClass : uint8_t
{
    ETextureClass__Invalid = 0,
    ETextureClass__TwoD = 1,
    ETextureClass__Cube = 2,
    ETextureClass__Array = 3,
    ETextureClass__CubeArray = 4,
    ETextureClass__Volume = 5,
    ETextureClass__TwoDDynamic = 6,
    ETextureClass__RenderTarget = 7,
    ETextureClass__Other2DNoSource = 8,
    ETextureClass__OtherUnknown = 9
};

enum ECompositeTextureMode : uint8_t
{
    CTM_Disabled = 0,
    CTM_NormalRoughnessToRed = 1,
    CTM_NormalRoughnessToGreen = 2,
    CTM_NormalRoughnessToBlue = 3,
    CTM_NormalRoughnessToAlpha = 4
};

enum ETextureSourceCompressionFormat : uint8_t
{
    TSCF_None = 0,
    TSCF_PNG = 1,
    TSCF_JPEG = 2,
    TSCF_UEJPEG = 3,
    TSCF_UEDELTA = 4
};

enum ETextureSourceFormat : uint8_t
{
    TSF_Invalid = 0,
    TSF_G8 = 1,
    TSF_BGRA8 = 2,
    TSF_BGRE8 = 3,
    TSF_RGBA16 = 4,
    TSF_RGBA16F = 5,
    TSF_RGBA8_DEPRECATED = 6,
    TSF_RGBE8_DEPRECATED = 7,
    TSF_G16 = 8,
    TSF_RGBA32F = 9,
    TSF_R16F = 10,
    TSF_R32F = 11
};

enum TextureCompressionSettings : uint8_t
{
    TC_Default = 0,
    TC_Normalmap = 1,
    TC_Masks = 2,
    TC_Grayscale = 3,
    TC_Displacementmap = 4,
    TC_VectorDisplacem______ = 5,
    TC_HDR = 6,
    TC_EditorIcon = 7,
    TC_Alpha = 8,
    TC_DistanceFieldFont = 9,
    TC_HDR_Compressed = 10,
    TC_BC7 = 11,
    TC_HalfFloat = 12,
    TC_LQ = 13,
    TC_EncodedReflectionCapture = 14,
    TC_SingleFloat = 15,
    TC_HDR_F32 = 16
};

enum ETextureSourceEncoding : uint8_t
{
    ETextureSourceEncoding__TSE_None = 0,
    ETextureSourceEncoding__TSE_Linear = 1,
    ETextureSourceEncoding__TSE_sRGB = 2,
    ETextureSourceEncoding__TSE_ST2084 = 3,
    ETextureSourceEncoding__TSE_Gamma22 = 4,
    ETextureSourceEncoding__TSE_BT1886 = 5,
    ETextureSourceEncoding__TSE_Gamma26 = 6,
    ETextureSourceEncoding__TSE_Cineon = 7,
    ETextureSourceEncoding__TSE_REDLog = 8,
    ETextureSourceEncoding__TSE_REDLog3G10 = 9,
    ETextureSourceEncoding__TSE_SLog1 = 10,
    ETextureSourceEncoding__TSE_SLog2 = 11,
    ETextureSourceEncoding__TSE_SLog3 = 12,
    ETextureSourceEncoding__TSE_AlexaV3LogC = 13,
    ETextureSourceEncoding__TSE_CanonLog = 14,
    ETextureSourceEncoding__TSE_ProTune = 15,
    ETextureSourceEncoding__TSE_VLog = 16
};

enum ETextureColorSpace : uint8_t
{
    ETextureColorSpace__TCS_None = 0,
    ETextureColorSpace__TCS_sRGB = 1,
    ETextureColorSpace__TCS_Rec2020 = 2,
    ETextureColorSpace__TCS_ACESAP0 = 3,
    ETextureColorSpace__TCS_ACESAP1 = 4,
    ETextureColorSpace__TCS_P3DCI = 5,
    ETextureColorSpace__TCS_P3D65 = 6,
    ETextureColorSpace__TCS_REDWideGamut = 7,
    ETextureColorSpace__TCS_SonySGamut3 = 8,
    ETextureColorSpace__TCS_SonySGamut3Cine = 9,
    ETextureColorSpace__TCS_AlexaWideGamut = 10,
    ETextureColorSpace__TCS_CanonCinemaGamut = 11,
    ETextureColorSpace__TCS_GoProProtuneNative = 12,
    ETextureColorSpace__TCS_PanasonicVGamut = 13,
    ETextureColorSpace__TCS_Custom = 99
};

enum ETimelineLengthMode : uint8_t
{
    TL_TimelineLength = 0,
    TL_LastKeyFrame = 1
};

enum EQuarztQuantizationReference : uint8_t
{
    EQuarztQuantizationReference__BarRelative = 0,
    EQuarztQuantizationReference__TransportRelative = 1,
    EQuarztQuantizationReference__CurrentTimeRelative = 2,
    EQuarztQuantizationReference__Count = 3
};

enum EQuartzCommandType : uint8_t
{
    EQuartzCommandType__PlaySound = 0,
    EQuartzCommandType__QueueSoundToPlay = 1,
    EQuartzCommandType__RetriggerSound = 2,
    EQuartzCommandType__TickRateChange = 3,
    EQuartzCommandType__TransportReset = 4,
    EQuartzCommandType__StartOtherClock = 5,
    EQuartzCommandType__Notify = 6,
    EQuartzCommandType__Custom = 7
};

enum EActorUpdateOverlapsMethod : uint8_t
{
    EActorUpdateOverlapsMethod__UseConfigDefault = 0,
    EActorUpdateOverlapsMethod__AlwaysUpdate = 1,
    EActorUpdateOverlapsMethod__OnlyUpdateMovable = 2,
    EActorUpdateOverlapsMethod__NeverUpdate = 3
};

enum ELevelInstanceType : uint8_t
{
    ELevelInstanceType__None = 0,
    ELevelInstanceType__LevelInstance = 1,
    ELevelInstanceType__LevelInstanceEdit = 2,
    ELevelInstanceType__LevelInstancePropertyOverride = 3
};

enum ELevelInstanceFlags : uint8_t
{
    ELevelInstanceFlags__None = 0,
    ELevelInstanceFlags__IsInEditHierarchy = 1,
    ELevelInstanceFlags__HasPropertyOverrides = 2,
    ELevelInstanceFlags__HasEditablePropertyOverrides = 4
};

enum FNavigationSystemRunMode : uint8_t
{
    FNavigationSystemRunMode__InvalidMode = 0,
    FNavigationSystemRunMode__GameMode = 1,
    FNavigationSystemRunMode__EditorMode = 2,
    FNavigationSystemRunMode__SimulationMode = 3,
    FNavigationSystemRunMode__PIEMode = 4,
    FNavigationSystemRunMode__InferFromWorldMode = 5,
    FNavigationSystemRunMode__EditorWorldPartitionBuildMode = 6
};

enum ENavigationSortPendingTilesMethod : uint8_t
{
    ENavigationSortPendingTilesMethod__SortWithSeedLocations = 0,
    ENavigationSortPendingTilesMethod__SortByPriority = 1,
    ENavigationSortPendingTilesMethod__None = 2
};

enum ENavPathEvent : uint8_t
{
    ENavPathEvent__Cleared = 0,
    ENavPathEvent__NewPath = 1,
    ENavPathEvent__UpdatedDueToGoalMoved = 2,
    ENavPathEvent__UpdatedDueToNavigationChanged = 3,
    ENavPathEvent__Invalidated = 4
};

enum ENavigationQueryResult : uint8_t
{
    ENavigationQueryResult__Invalid = 0,
    ENavigationQueryResult__Error = 1,
    ENavigationQueryResult__Fail = 2,
    ENavigationQueryResult__Success = 3
};

enum EAlphaBlendOption : uint8_t
{
    EAlphaBlendOption__Linear = 0,
    EAlphaBlendOption__Cubic = 1,
    EAlphaBlendOption__HermiteCubic = 2,
    EAlphaBlendOption__Sinusoidal = 3,
    EAlphaBlendOption__QuadraticInOut = 4,
    EAlphaBlendOption__CubicInOut = 5,
    EAlphaBlendOption__QuarticInOut = 6,
    EAlphaBlendOption__QuinticInOut = 7,
    EAlphaBlendOption__CircularIn = 8,
    EAlphaBlendOption__CircularOut = 9,
    EAlphaBlendOption__CircularInOut = 10,
    EAlphaBlendOption__ExpIn = 11,
    EAlphaBlendOption__ExpOut = 12,
    EAlphaBlendOption__ExpInOut = 13,
    EAlphaBlendOption__Custom = 14
};

enum EAnimGroupRole : uint8_t
{
    EAnimGroupRole__CanBeLeader = 0,
    EAnimGroupRole__AlwaysFollower = 1,
    EAnimGroupRole__AlwaysLeader = 2,
    EAnimGroupRole__TransitionLeader = 3,
    EAnimGroupRole__TransitionFollower = 4,
    EAnimGroupRole__ExclusiveAlwaysLeader = 5
};

enum EAnimSyncMethod : uint8_t
{
    EAnimSyncMethod__DoNotSync = 0,
    EAnimSyncMethod__SyncGroup = 1,
    EAnimSyncMethod__Graph = 2
};

enum EDrawDebugItemType : uint8_t
{
    EDrawDebugItemType__DirectionalArrow = 0,
    EDrawDebugItemType__Sphere = 1,
    EDrawDebugItemType__Line = 2,
    EDrawDebugItemType__OnScreenMessage = 3,
    EDrawDebugItemType__CoordinateSystem = 4,
    EDrawDebugItemType__Point = 5,
    EDrawDebugItemType__Circle = 6,
    EDrawDebugItemType__Cone = 7,
    EDrawDebugItemType__In___qS_w_____ = 8,
    EDrawDebugItemType__Capsule = 9
};

enum EMontageSubStepResult : uint8_t
{
    EMontageSubStepResult__Moved = 0,
    EMontageSubStepResult__NotMoved = 1,
    EMontageSubStepResult__InvalidSection = 2,
    EMontageSubStepResult__InvalidMontage = 3
};

enum EPinHidingMode : uint8_t
{
    EPinHidingMode__NeverAsPin = 0,
    EPinHidingMode__PinHiddenByDefault = 1,
    EPinHidingMode__PinShownByDefault = 2,
    EPinHidingMode__AlwaysAsPin = 3
};

enum EInertializationState : uint8_t
{
    EInertializationState__Inactive = 0,
    EInertializationState__Pending = 1,
    EInertializationState__Active = 2
};

enum EInertializationBoneState : uint8_t
{
    EInertializationBoneState__Invalid = 0,
    EInertializationBoneState__Valid = 1,
    EInertializationBoneState__Excluded = 2
};

enum EInertializationSpace : uint8_t
{
    EInertializationSpace__Default = 0,
    EInertializationSpace__WorldSpace = 1,
    EInertializationSpace__WorldRotation = 2
};

enum EEvaluatorDataSource : uint8_t
{
    EEvaluatorDataSource__EDS_SourcePose = 0,
    EEvaluatorDataSource__EDS_DestinationPose = 1
};

enum EEvaluatorMode : uint8_t
{
    EEvaluatorMode__EM_Standard = 0,
    EEvaluatorMode__EM_Freeze = 1,
    EEvaluatorMode__EM_DelayedFreeze = 2
};

enum EStripAnimDataOnDedicatedServerSettings : uint8_t
{
    EStripAnimDataOnDedicatedServerSettings__UseProjectSetting = 0,
    EStripAnimDataOnDedicatedServerSettings__StripAnimDataOnDedicatedServer = 1,
    EStripAnimDataOnDedicatedServerSettings__DoNotStripAnimDataOnDedicatedServer = 2
};

enum ETransitionRequestQueueMode : uint8_t
{
    ETransitionRequestQueueMode__Shared = 0,
    ETransitionRequestQueueMode__Unique = 1
};

enum ETransitionRequestOverwriteMode : uint8_t
{
    ETransitionRequestOverwriteMode__Append = 0,
    ETransitionRequestOverwriteMode__Ignore = 1,
    ETransitionRequestOverwriteMode__Overwrite = 2
};

enum ETransitionBlendMode : uint8_t
{
    ETransitionBlendMode__TBM_Linear = 0,
    ETransitionBlendMode__TBM_Cubic = 1
};

enum ETransitionLogicType : uint8_t
{
    ETransitionLogicType__TLT_StandardBlend = 0,
    ETransitionLogicType__TLT_Inertialization = 1,
    ETransitionLogicType__TLT_Custom = 2
};

enum EBlendProfileMode : uint8_t
{
    EBlendProfileMode__TimeFactor = 0,
    EBlendProfileMode__WeightFactor = 1,
    EBlendProfileMode__BlendMask = 2
};

enum ETransformCurveChannel : uint8_t
{
    ETransformCurveChannel__Position = 0,
    ETransformCurveChannel__Rotation = 1,
    ETransformCurveChannel__Scale = 2,
    ETransformCurveChannel__Invalid = 3
};

enum EVectorCurveChannel : uint8_t
{
    EVectorCurveChannel__X = 0,
    EVectorCurveChannel__Y = 1,
    EVectorCurveChannel__Z = 2,
    EVectorCurveChannel__Invalid = 3
};

enum EPostCopyOperation : uint8_t
{
    EPostCopyOperation__None = 0,
    EPostCopyOperation__LogicalNegateBool = 1,
    EPosO___________4_1_____x_____Jx____W_____ = 2
};

enum EPreviewAnimationBlueprintApplicationMethod : uint8_t
{
    EPreviewAnimationBlueprintApplicationMethod__LinkedLayers = 0,
    EPreviewAnimationBlueprintApplicationMethod__LinkedAnimGraph = 1
};

enum EPrimaryAssetCookRule : uint8_t
{
    EPrimaryAssetCookRule__Unknown = 0,
    EPrimaryAssetCookRule__NeverCook = 1,
    EPrimaryAssetCookRule__ProductionNeverCook = 2,
    EPrimaryAssetCookRule__DevelopmentCook = 2,
    EPrimaryAssetCookRule__DevelopmentAlwaysProductionNeverCook = 3,
    EPrimaryAssetCookRule__DevelopmentAlwaysCook = 3,
    EPrimaryAssetCookRule__DevelopmentAlwaysProductionUnknownCook = 4,
    EPrimaryAssetCookRule__AlwaysCook = 5
};

enum EAttenuationShape : uint8_t
{
    EAttenuationShape__Sphere = 0,
    EAttenuationShape__Capsule = 1,
    EAttenuationShape__Box = 2,
    EAttenuationShape__Cone = 3
};

enum EVoiceSampleRate : uint16_t
{
    EVoiceSampleRate__Low16000Hz = 16000,
    EVoiceSampleRate__Normal24000Hz = 24000
};

enum EPanningMethod : uint8_t
{
    EPanningMethod__Linear = 0,
    EPanningMethod__EqualPower = 1
};

enum EAudioVolumeLocationState : uint8_t
{
    EAudioVolumeLocationState__InsideTheVolume = 0,
    EAudioVolumeLocationState__OutsideTheVolume = 1
};

enum EStructUtilsResult : uint8_t
{
    EStructUtilsResult__Valid = 0,
    EStructUtilsResult__NotValid = 1
};

enum EInterfaceValidResult : uint8_t
{
    EInterfaceValidResult__Valid = 0,
    EInterfaceValidResult__Invalid = 1
};

enum ECameraShakePatternUpdateResultFlags : uint8_t
{
    ECameraShakePatternUpdateResultFlags__ApplyAsAbsolute = 1,
    ECameraShakePatternUpdateResultFlags__SkipAutoScale = 2,
    ECameraShakePatternUpdateResultFlags__SkipAutoPlaySpace = 4,
    ECameraShakePatternUpdateResultFlags__Default = 0
};

enum ECameraShakeAttenuation : uint8_t
{
    ECameraShakeAttenuation__Linear = 0,
    ECameraShakeAttenuation__Quadratic = 1
};

enum ECameraA___r_3D_n____ : uint8_t
{
    ECameraAlphaBlendMode__CABM_Linear = 0,
    ECameraAlphaBlendMode__CABM_Cubic = 1
};

enum EControllerAnalogStick : uint8_t
{
    EControllerAnalogStick__CAS_LeftStick = 0,
    EControllerAnalogStick__CAS_RightStick = 1
};

enum EPhysicsStateAction : uint8_t
{
    EPhysicsStateAction__AddForce = 0,
    EPhysicsStateAction__AddTorque = 1,
    EPhysicsStateAction__AddForceAtPosition = 2,
    EPhysicsStateAction__AddLinearVelocity = 3,
    EPhysicsStateAction__AddAngularVelocity = 4,
    EPhysicsStateAction__AddVelocityAtPosition = 5,
    EPhysicsStateAction__AddLinearImpulse = 6,
    EPhysicsStateAction__AddAngularImpulse = 7,
    EPhysicsStateAction__AddImpulseAtPosition = 8,
    EPhysicsStateAction__AddAcceleration = 9,
    EPhysicsStateAction__NumActions = 10
};

enum EReflectionSourceType : uint8_t
{
    EReflectionSourceType__CapturedScene = 0,
    EReflectionSourceType__SpecifiedCubemap = 1
};

enum ERuntimeVirtualTextureMaterialQuality : uint8_t
{
    ERuntimeVirtualTextureMaterialQuality__Low = 0,
    ERuntimeVirtualTextureMaterialQuality__Medium = 1,
    ERuntimeVirtualTextureMaterialQuality__High = 2,
    ERuntimeVirtualTextureMaterialQuality__Epic = 3
};

enum EKinematicBonesUpdateToPhysics : uint8_t
{
    EKinematicBonesUpdateToPhysics__SkipSimulatingBones = 0,
    EKinematicBonesUpdateToPhysics__SkipAllBones = 1
};

enum EPhysicsTransformUpdateMode : uint8_t
{
    EPhysicsTransformUpdateMode__SimulationUpatesComponentTransform = 0,
    EPhysicsTransformUpdateMode__ComponentTransformIsKinematic = 1
};

enum ESplineCoordinateSpace : uint8_t
{
    ESplineCoordinateSpace__Local = 0,
    ESplineCoordinateSpace__World = 1
};

enum EVolumetricCloudTracingMaxDistanceMode : uint8_t
{
    EVolumetricCloudTracingMaxDistanceMode__DistanceFromCloudLayerEntryPoint = 0,
    EVolumetricCloud_c__________e__OU__n2___28u___E__c_________8s__ = 1
};

enum FDataDrivenCVarType : uint8_t
{
    FDataDrivenCVarType__CVarFloat = 0,
    FDataDrivenCVarType__CVarInt = 1,
    FDataDrivenCVarType__CVarBool = 2
};

enum EEvaluateCurveTableResult : uint8_t
{
    EEvaluateCurveTableResult__RowFound = 0,
    EEvaluateCurveTableResult__RowNotFound = 1
};

enum EReporterLineStyle : uint8_t
{
    EReporterLineStyle__Line = 0,
    EReporterLineStyle__Dash = 1
};

enum EGraphAxisStyle : uint8_t
{
    EGraphAxisStyle__Lines = 0,
    EGraphAxisStyle__Notches = 1,
    EGraphAxisStyle__Grid = 2
};

enum EGraphDataStyle : uint8_t
{
    EGraphDataStyle__Lines = 0,
    EGraphDataStyle__Filled = 1
};

enum EGrammaticalGender : uint8_t
{
    EGrammaticalGender__Neuter = 0,
    EGrammaticalGender__Masculine = 1,
    EGrammaticalGender__Feminine = 2,
    EGrammaticalGender__Mixed = 3
};

enum ECustomTimeStepSynchronizationState : uint8_t
{
    ECustomTimeStepSynchronizationState__Closed = 0,
    ECustomTimeStepSynchronizationState__Error = 1,
    ECustomTimeStepSynchronizationState__Synchronized = 2,
    ECustomTimeStepSynchronizationState__Synchronizing = 3
};

enum EVectorQuantization : uint8_t
{
    EVectorQuantization__RoundWholeNumber = 0,
    EVectorQuantization__RoundOneDecimal = 1,
    EVectorQuantization__RoundTwoDecimals = 2
};

enum ETimecodeProviderSynchronizationState : uint8_t
{
    ETimecodeProviderSynchronizationState__Closed = 0,
    ETimecodeProviderSynchronizationState__Error = 1,
    ETimecodeProviderSynchronizationState__Synchronized = 2,
    ETimecodeProviderSynchronizationState__Synchronizing = 3
};

enum ERootMotionSourceStatusFlags : uint8_t
{
    ERootMotionSourceStatusFlags__Prepared = 1,
    ERootMotionSourceStatusFlags__Finished = 2,
    ERootMotionSourceStatusFlags__MarkedForRemoval = 4
};

enum ERootMotionSourceSettingsFlags : uint8_t
{
    ERootMotionSourceSettingsFlags__UseSensitiveLiftoffCheck = 1,
    ERootMotionSourceSettingsFlags__DisablePartialEndTick = 2,
    ERootMotionSourceSettingsFlags__IgnoreZAccumulate = 4
};

enum ERootMotionFinishVeloc_X_____ : uint8_t
{
    ERootMotionFinishVelocityMode__MaintainLastRootMotionVelocity = 0,
    ERootMotionFinishVelocityMode__SetVelocity = 1,
    ERootMotionFinishVelocityMode__ClampVelocity = 2
};

enum EWindowMode : uint8_t
{
    EWindowMode__Fullscreen = 0,
    EWindowMode__WindowedFullscreen = 1,
    EWindowMode__Windowed = 2
};

enum EEasingFunc : uint8_t
{
    EEasingFunc__Linear = 0,
    EEasingFunc__Step = 1,
    EEasingFunc__SinusoidalIn = 2,
    EEasingFunc__SinusoidalOut = 3,
    EEasingFunc__SinusoidalInOut = 4,
    EEasingFunc__EaseIn = 5,
    EEasingFunc__EaseOut = 6,
    EEasingFunc__EaseInOut = 7,
    EEasingFunc__ExpoIn = 8,
    EEasingFunc__ExpoOut = 9,
    EEasingFunc__ExpoInOut = 10,
    EEasingFunc__CircularIn = 11,
    EEasingFunc__CircularOut = 12,
    EEasingFunc__CircularInOut = 13
};

enum ELerpInterpolationMode : uint8_t
{
    ELerpInterpolationMode__QuatInterp = 0,
    ELerpInterpolationMode__EulerInterp = 1,
    ELerpInterpolationMode__DualQuatInterp = 2
};

enum EMatrixColumns : uint8_t
{
    EMatrixColumns__First = 0,
    EMatrixColumns__Second = 1,
    EMatrixColumns__Third = 2,
    EMatrixColumns__Fourth = 3
};

enum EEditorPropertyValueState : uint8_t
{
    EEditorPropertyValueState__Default = 0,
    EEditorPropertyValueState__Overridden = 1,
    EEditorPropertyValueState__NotFound = 2,
    EEditorPropertyValueState__AccessDenied = 3
};

enum EDecalBlendMode : uint8_t
{
    DBM_Translucent = 0,
    DBM_Stain = 1,
    DBM_Normal = 2,
    DBM_Emissive = 3,
    DBM_DBuffer_ColorNormalRoughness = 4,
    DBM_DBuffer_Color = 5,
    DBM_DBuffer_ColorNormal = 6,
    DBM_DBuffer_ColorRoughness = 7,
    DBM_DBuffer_Normal = 8,
    DBM_DBuffer_NormalRoughness = 9,
    DBM_DBuffer_Roughness = 10,
    DBM_DBuffer_Emissive = 11,
    DBM_DBuffer_AlphaComposite = 12,
    DBM_DBuffer_EmissiveAlphaComposite = 13,
    DBM_Volumetric_DistanceFunction = 14,
    DBM_AlphaComposite = 15,
    DBM_AmbientOcclusion = 16
};

enum EMaterialDecalResponse : uint8_t
{
    MDR_None = 0,
    MDR_ColorNormalRoughness = 1,
    MDR_Color = 2,
    MDR_ColorNormal = 3,
    MDR_ColorRoughness = 4,
    MDR_Normal = 5,
    MDR_NormalRoughness = 6,
    MDR_Roughness = 7
};

enum EVertexPaintAxis : uint8_t
{
    EVertexPaintAxis__X = 0,
    EVertexPaintAxis__Y = 1,
    EVertexPaintAxis__Z = 2
};

enum ENetworkMetricEnableMode : uint8_t
{
    ENetworkMetricEnableMode__EnableForAllReplication = 0,
    ENetworkMetricEnableMode__EnableForIrisOnly = 1,
    ENetworkMetricEnableMode__EnableForNonIrisOnly = 2
};

enum EReplayResult : uint8_t
{
    EReplayResult__Success = 0,
    EReplayResult__ReplayNotFound = 1,
    EReplayResult__Corrupt = 2,
    EReplayResult__UnsupportedCheckpoint = 3,
    EReplayResult__GameSpecific = 4,
    EReplayResult__InitConnect = 5,
    EReplayResult__LoadMap = 6,
    EReplayResult__Serialization = 7,
    EReplayResult__StreamerError = 8,
    EReplayResult__ConnectionClosed = 9,
    EReplayResult__MissingArchive = 10,
    EReplayResult__Unknown = 11
};

enum EParticleSysParamType : uint8_t
{
    PSPT_None = 0,
    PSPT_Scalar = 1,
    PSPT_ScalarRand = 2,
    PSPT_Vector = 3,
    PSPT_VectorRand = 4,
    PSPT_Color = 5,
    PSPT_Actor = 6,
    PSPT_Material = 7,
    PSPT_VectorUnitRand = 8
};

enum EConstraintTransformComponentFlags : uint8_t
{
    EConstraintTransformComponentFlags__None = 0,
    EConstraintTransformComponentFlags__ChildPosition = 1,
    EConstraintTransformComponentFlags__ChildRotation = 2,
    EConstraintTransformComponentFlags__ParentPosition = 4,
    EConstraintTransformComponentFlags__ParentRotation = 8,
    EConstraintTransformComponentFlags__AllChild = 3,
    EConstraintTransformComponentFlags__AllParent = 12,
    EConstraintTransformComponentFlags__AllPosition = 5,
    EConstraintTransformComponentFlags__AllRotation = 10,
    EConstraintTransformComponentFlags__All = 15
};

enum ESettingsDOF : uint8_t
{
    ESettingsDOF__Full3D = 0,
    ESettingsDOF__YZPlane = 1,
    ESettingsDOF__XZPlane = 2,
    ESettingsDOF__XYPlane = 3
};

enum EDynamicForceFeedbackAction : uint8_t
{
    EDynamicForceFeedbackAction__Start = 0,
    EDynamicForceFeedbackAction__Update = 1,
    EDynamicForceFeedbackAction__Stop = 2
};

enum EClearSceneOptions : uint8_t
{
    EClearSceneOptions__NoClear = 0,
    EClearSceneOptions__HardwareClear = 1,
    EClearSceneOptions__QuadAtMaxZ = 2
};

enum EVelocityOutputPass : uint8_t
{
    EVelocityOutputPass__DepthPass = 0,
    EVelocityOutputPass__BasePass = 1,
    EVelocityOutputPass__AfterBasePass = 2
};

enum EVertexDeformationOutputsVelocity : uint8_t
{
    EVertexDeformationOutputsVelocity__Off = 0,
    EVertexDeformationOutputsVelocity__On = 1,
    EVertexDeformationOutputsVelocity__Auto = 2
};

enum EMobileFloatPrecisionMode : uint8_t
{
    EMobileFloatPrecisionMode__Half = 0,
    EMobileFloatPrecisionMode__Full_MaterialExpressionOnly = 1,
    EMobileFloatPrecisionMode__Full = 2
};

enum ELumenRayLightingMode : uint8_t
{
    ELumenRayLightingMode__SurfaceCache = 0,
    ELumenRayLightingMode__HitLightingForReflections = 2,
    ELumenRayLightingMode__HitLighting = 1
};

enum ELumenScreenTracingSource : uint8_t
{
    ELumenScreenTracingSource__SceneColor = 0,
    ELumenScreenTracingSource__AntialiasedSceneColorWithTranslucency = 1
};

enum EWorkingColorSpace : uint8_t
{
    EWorkingColorSpace__sRGB = 1,
    EWorkingColorSpace__Rec2020 = 2,
    EWorkingColorSpace__ACESAP0 = 3,
    EWorkingColorSpace__ACESAP1 = 4,
    EWorkingColorSpace__P3DCI = 5,
    EWorkingColorSpace__P3D65 = 6,
    EWorkingColorSpace__Custom = 7
};

enum ESkeletalMeshAsyncProperties : uint64_t
{
    ESkeletalMeshAsyncProperties__None = 0,
    ESkeletalMeshAsyncProperties__Materials = 1,
    ESkeletalMeshAsyncProperties__Skeleton = 2,
    ESkeletalMeshAsyncProperties__RefSkeleton = 4,
    ESkeletalMeshAsyncProperties__RetargetBasePose = 8,
    ESkeletalMeshAsyncProperties__RefBasesInvMatrix = 16,
    ESkeletalMeshAsyncProperties__MeshClothingAssets = 32,
    ESkeletalMeshAsyncProperties__SourceModels = 64,
    ESkeletalMeshAsyncProperties__HasActiveClothingAssets = 128,
    ESkeletalMeshAsyncProperties__LODSettings = 256,
    ESkeletalMeshAsyncProperties__HasVertexColors = 512,
    ESkeletalMeshAsyncProperties__VertexColorGuid = 1024,
    ESkeletalMeshAsyncProperties__MorphTargets = 2048,
    ESkeletalMeshAsyncProperties__SkeletalMeshRenderData = 4096,
    ESkeletalMeshAsyncProperties__MeshEditorDataObject = 8192,
    ESkeletalMeshAsyncProperties__NeverStream = 16384,
    ESkeletalMeshAsyncProperties__OverrideLODStreamingSettings = 32768,
    ESkeletalMeshAsyncProperties__SupportLODStreaming = 65536,
    ESkeletalMeshAsyncProperties__MaxNumStreamedLODs = 131072,
    ESkeletalMeshAsyncProperties__MaxNumOptionalLODs = 262144,
    ESkeletalMeshAsyncProperties__ImportedModel = 524288,
    ESkeletalMeshAsyncProperties__LODInfo = 1048576,
    ESkeletalMeshAsyncProperties__SkinWeightProfiles = 2097152,
    ESkeletalMeshAsyncProperties__CachedComposedRefPoseMatrices = 4194304,
    ESkeletalMeshAsyncProperties__SamplingInfo = 8388608,
    ESkeletalMeshAsyncProperties__NodeMappingData = 16777216,
    ESkeletalMeshAsyncProperties__ShadowPhysicsAsset = 33554432,
    ESkeletalMeshAsyncProperties__SkelMirrorTable = 67108864,
    ESkeletalMeshAsyncProperties__MinLod = 134217728,
    ESkeletalMeshAsyncProperties__DisableBelowMinLodStripping = 268435456,
    ESkeletalMeshAsyncProperties__SkelMirrorAxis = 536870912,
    ESkeletalMeshAsyncProperties__SkelMirrorFlipAxis = 1073741824,
    ESkeletalMeshAsyncProperties__DefaultAnimationRig = 2147483648,
    ESkeletalMeshAsyncProperties__NegativeBoundsExtension = 4294967296,
    ESkeletalMeshAsyncProperties__PositiveBoundsExtension = 8589934592,
    ESkeletalMeshAsyncProperties__ExtendedBounds = 17179869184,
    ESkeletalMeshAsyncProperties__EnablePerPolyCollision = 68719476736,
    ESkeletalMeshAsyncProperties__BodySetup = 137438953472,
    ESkeletalMeshAsyncProperties__MorphTargetIndexMap = 274877906944,
    ESkeletalMeshAsyncProperties__FloorOffset = 549755813888,
    ESkeletalMeshAsyncProperties__ImportedBounds = 1099511627776,
    ESkeletalMeshAsyncProperties__PhysicsAsset = 2199023255552,
    ESkeletalMeshAsyncProperties__AssetImportData = 4398046511104,
    ESkeletalMeshAsyncProperties__ThumbnailInfo = 8796093022208,
    ESkeletalMeshAsyncProperties__HasCustomDefaultEditorCamera = 17592186044416,
    ESkeletalMeshAsyncProperties__DefaultEditorCameraLocation = 35184372088832,
    ESkeletalMeshAsyncProperties__DefaultEditorCameraRotation = 70368744177664,
    ESkeletalMeshAsyncProperties__RequiresLODScreenSizeConversion = 140737488355328,
    ESkeletalMeshAsyncProperties__PostProcessAnimBlueprint = 281474976710656,
    ESkeletalMeshAsyncProperties__DefaultEditorCameraLookAt = 562949953421312,
    ESkeletalMeshAsyncProperties__PreviewAttachedAssetContainer = 1125899906842624,
    ESkeletalMeshAsyncProperties__DefaultEditorCameraOrthoZoom = 2251799813685248,
    ESkeletalMeshAsyncProperties__RequiresLODHysteresisConversion = 4503599627370496,
    ESkeletalMeshAsyncProperties__bSupportRayTracing = 9007199254740992,
    ESkeletalMeshAsyncProperties__RayTracingMinLOD = 18014398509481984,
    ESkeletalMeshAsyncProperties__ClothLODBiasMode = 36028797018963968,
    ESkeletalMeshAsyncProperties__DefaultMeshDeformer = 72057594037927936,
    ESkeletalMeshAsyncProperties__OverlayMaterial = 144115188075855872,
    ESkeletalMeshAsyncProperties__OverlayMaterialMaxDrawDistance = 288230376151711744,
    ESkeletalMeshAsyncProperties__All = -1
};

enum EClothLODBiasMode : uint8_t
{
    EClothLODBiasMode__MappingsToSameLOD = 0,
    EClothLODBiasMode__MappingsToMinLOD = 1,
    EClothLODBiasMode__MappingsToAnyLOD = 2
};

enum EBoneFilterActionOption : uint8_t
{
    EBoneFilterActionOption__Remove = 0,
    EBoneFilterActionOption__Keep = 1,
    EBoneFilterActionOption__Invalid = 2
};

enum ESkinCacheUsage : uint16_t
{
    ESkinCacheUsage__Auto = 0,
    ESkinCacheUsage__Disabled = 255,
    ESkinCacheUsage__Enabled = 1
};

enum EVirtualizationMode : uint8_t
{
    EVirtualizationMode__Disabled = 0,
    EVirtualizationMode__PlayWhenSilent = 1,
    EVirtualizationMode__Restart = 2,
    EVirtualizationM_zL__ll_____Y__b____________ = 3
};

enum EMaxConcurrentResolutionRule : uint8_t
{
    EMaxConcurrentResolutionRule__PreventNew = 0,
    EMaxConcurrentResolutionRule__StopOldest = 1,
    EMaxConcurrentResolutionRule__StopFarthestThenPreventNew = 2,
    EMaxConcurrentResolutionRule__StopFarthestThenOldest = 3,
    EMaxConcurrentResolutionRule__StopLowestPriority = 4,
    EMaxConcurrentResolutionRule__StopQuietest = 5,
    EMaxConcurrentResolutionRule__StopLowestPriorityThenPreventNew = 6,
    EMaxConcurrentResolutionRule__Count = 7
};

enum EConcurrencyVolumeScaleMode : uint8_t
{
    EConcurrencyVolumeScaleMode__Default = 0,
    EConcurrencyVolumeScaleMode__Distance = 1,
    EConcurrencyVolumeScaleMode__Priority = 2
};

enum EAudioSpectrumType : uint8_t
{
    EAudioSpectrumType__MagnitudeSpectrum = 0,
    EAudioSpectrumType__PowerSpectrum = 1,
    EAudioSpectrumType__Decibel = 2
};

enum ESendLevelControlMethod : uint8_t
{
    ESendLevelControlMethod__Linear = 0,
    ESendLevelControlMethod__CustomCurve = 1,
    ESendLevelControlMethod__Manual = 2
};

enum EStaticMeshPaintSupport : uint8_t
{
    EStaticMeshPaintSupport__Default = 0,
    EStaticMeshPaintSupport__Enabled = 1,
    EStaticMeshPaintSupport__Disabled = 2
};

enum ETextureUniversalTiling : uint8_t
{
    ETextureUniversalTiling__Disabled = 0,
    ETextureUniversalTiling__Enabled_256KB = 1,
    ETextureUniversalTiling__Enabled_64KB = 2,
    ETextus3___ = 3
};

enum ETextureRenderTargetFormat : uint8_t
{
    RTF_R8 = 0,
    RTF_RG8 = 1,
    RTF_RGBA8 = 2,
    RTF_RGBA8_SRGB = 3,
    RTF_R16f = 4,
    RTF_RG16f = 5,
    RTF_RGBA16f = 6,
    RTF_R32f = 7,
    RTF_RG32f = 8,
    RTF_RGBA32f = 9,
    RTF_RGB10A2 = 10
};

enum ETextureRenderTargetSampleCount : uint8_t
{
    ETextureRenderTargetSampleCount__RTSC = 0,
    ETextureRenderTargetSampleCount__RTSC = 1,
    ETextureRenderTargetSampleCount__RTSC = 2,
    ETextureRenderTargetSampleCount__RTSC = 3
};

enum EFontDPI : uint8_t
{
    EFontDPI__Standard = 0,
    EFontDPI__Unreal = 1,
    EFontDPI__Custom = 2
};

enum EHardwareDeviceSupportedFeatures : uint32_t
{
    EHardwareDeviceSupportedFeatures__Unspecified = 0,
    EHardwareDeviceSupportedFeatures__Keypress = 1,
    EHardwareDeviceSupportedFeatures__Pointer = 2,
    EHardwareDeviceSupportedFeatures__Gamepad = 4,
    EHardwareDeviceSupportedFeatures__Touch = 8,
    EHardwareDeviceSupportedFeatures__Camera = 16,
    EHardwareDeviceSupportedFeatures__MotionTracking = 32,
    EHardwareDeviceSupportedFeatures__Lights = 64,
    EHardwareDeviceSupportedFeatures__TriggerHaptics = 128,
    EHardwareDeviceSupportedFeatures__ForceFeedback = 256,
    EHardwareDeviceSupportedFeatures__AudioBasedVibrations = 512,
    EHardwareDeviceSupportedFeatures__Acceleration = 1024,
    EHardwareDeviceSupportedFeatures__Virtual = 2048,
    EHardwareDeviceSupportedFeatures__Microphone = 4096,
    EHardwareDeviceSupportedFeatures__Orientation = 8192,
    EHardwareDeviceSupportedFeatures__Guitar = 16384,
    EHardwareDeviceSupportedFeatures__Drums = 32768,
    EHardwareDeviceSupportedFeatures__CustomA = 16777216,
    EHardwareDeviceSupportedFeatures__CustomB = 33554432,
    EHardwareDeviceSupportedFeatures__CustomC = 67108864,
    EHardwareDeviceSupportedFeatures__CustomD = 134217728,
    EHardwareDeviceSupportedFeatures__All = 2147483647
};

enum EHardwareDevicePrimaryType : uint8_t
{
    EHardwareDevicePrimaryType__Unspecified = 0,
    EHardwareDevicePrimaryType__KeyboardAndMouse = 1,
    EHardwareDevicePrimaryType__Gamepad = 2,
    EHardwareDevicePrimaryType__Touch = 3,
    EHardwareDevicePrimaryType__MotionTracking = 4,
    EHardwareDevicePrimaryType__RacingWheel = 5,
    EHardwareDevicePrimaryType__FlightStick = 6,
    EHardwareDevicePrimaryType__Camera = 7,
    EHardwareDevicePrimaryType__Instrument = 8,
    EHardwareDevicePrimaryType__CustomTypeA = 9,
    EHardwareDevicePrimaryType__CustomTypeB = 10,
    EHardwareDevicePrimaryType__CustomTypeC = 11,
    EHardwareDevicePrimaryType__CustomTypeD = 12
};

enum EDataLayerState : uint8_t
{
    EDataLayerState__Unloaded = 0,
    EDataLayerState__Loaded = 1,
    EDataLayerState__Activated = 2
};

enum EDataLayerLoadFilter : uint8_t
{
    EDataLayerLoadFilter__None = 0,
    EDataLayerLoadFilter__ClientOnly = 1,
    EDataLayerLoadFilter__ServerOnly = 2
};

enum EOverrideBlockOnSlowStreaming : uint8_t
{
    EOverrideBlockOnSlowStreaming__NoOverride = 0,
    EOverrideBlockOnSlowStreaming__Blocking = 1,
    EOverrideBlockOnSlowStreaming__NotBlocking = 2
};

enum EWorldPartitionServerStreamingOutMode : uint8_t
{
    EWorldPartitionServerStreamingOutMode__ProjectDefault = 0,
    EWorldPartitionServerStreamingOutMode__Disabled = 1,
    EWorldPartitionServerStreamingOutMode__Enabled = 2
};

enum EWorldPartitionRuntimeCellState : uint8_t
{
    EWorldPartitionRuntimeCellState__Unloaded = 0,
    EWorldPartitionRuntimeCellState__Loaded = 1,
    EWorldPartitionRuntimeCellState__Activated = 2
};

enum EWorldPartitionStreamingPerformance : uint8_t
{
    EWorldPartitionStreamingPerformance__Good = 0,
    EWorldPartitionStreamingPerformance__Slow = 1,
    EWorldPartitionStreamingPerformance__Critical = 2
};

enum EWorldPartitionCVarProjectDefaultOverride : uint8_t
{
    EWorldPartitionCVarProjectDefaultOverride__ProjectDefault = 0,
    EWorldPartitionCVarProjectDefaultOverride__Disabled = 1,
    EWorldPartitionCVarProjectDefaultOverride__Enabled = 2
};

enum EWeightMapTargetCommon : uint8_t
{
    EWeightMapTargetCommon__None = 0,
    EWeightMapTargetCommon__MaxDistance = 1,
    EWeightMapTargetCommon__BackstopDistance = 2,
    EWeightMapTargetCommon__BackstopRadius = 3,
    EWeightMapTargetCommon__AnimDriveStiffness = 4,
    EWeightMapTargetCommon__AnimDriveDamping_DEPRECATED = 5,
    EWeightMapTargetCommon__FirstUserTarget = 6,
    EWeightMapTargetCommon__LastUserTarget = 200,
    EWeightMapTargetCommon__TetherEndsMask = 201
};

enum EMPMatchOutcome : uint8_t
{
    EMPMatchOutcome__None = 0,
    EMPMatchOutcome__Quit = 1,
    EMPMatchOutcome__Won = 2,
    EMPMatchOutcome__Lost = 3,
    EMPMatchOutcome__Tied = 4,
    EMPMatchOutcome__TimeExpired = 5,
    EMPMatchOutcome__First = 6,
    EMPMatchOutcome__Second = 7,
    EMPMatchOutcome__Third = 8,
    EMPMatchOutcome__Fourth = 9
};

enum EInAppPurchaseStatus : uint8_t
{
    EInAppPurchaseStatus__Invalid = 0,
    EInAppPurchaseStatus__Failed = 1,
    EInAppPurchaseStatus__Deferred = 2,
    EInAppPurchaseStatus__Canceled = 3,
    EInAppPurchaseStatus__Purchased = 4,
    EInAppPurchaseStatus__Restored = 5
};

enum EPartyReservationResult : uint8_t
{
    EPartyReservationResult__NoResult = 0,
    EPartyReservationResult__RequestPending = 1,
    EPartyReservationResult__GeneralError = 2,
    EPartyReservationResult__PartyLimitReached = 3,
    EPartyReservationResult__IncorrectPlayerCount = 4,
    EPartyReservationResult__RequestTimedOut = 5,
    EPartyReservationResult__ReservationDuplicate = 6,
    EPartyReservationResult__ReservationNotFound = 7,
    EPartyReservationResult__ReservationAccepted = 8,
    EPartyReservationResult__ReservationDenied = 9,
    EPartyReservationResult__ReservationDenied_CrossPlayRestriction = 10,
    EPartyReservationResult__ReservationDenied_Banned = 11,
    EPartyReservationResult__ReservationRequestCanceled = 12,
    EPartyReservationResult__ReservationInvalid = 13,
    EPartyReservationResult__BadSessionId = 14,
    EPartyReservationResult__ReservationDenied_ContainsExistingPlayers = 15,
    EPartyReservationResult__ReservationDenied_ValidationFailed = 16
};

enum ESpectatorClientRequestType : uint8_t
{
    ESpectatorClientRequestType__NonePending = 0,
    ESpectatorClientRequestType__ExistingSessionReservation = 1,
    ESpectatorClientRequestType__ReservationUpdate = 2,
    ESpectatorClientRequestType__EmptyServerReservation = 3,
    ESpectatorClientRequestType__Reconnect = 4,
    ESpectatorClientRequestType__Abandon = 5
};

enum ESpectatorReservationResult : uint8_t
{
    ESpectatorReservationResult__NoResult = 0,
    ESpectatorReservationResult__RequestPending = 1,
    ESpectatorReservationResult__GeneralError = 2,
    ESpectatorReservationResult__SpectatorLimitReached = 3,
    ESpectatorReservationResult__IncorrectPlayerCount = 4,
    ESpectatorReservationResult__RequestTimedOut = 5,
    ESpectatorReservationResult__ReservationDuplicate = 6,
    ESpectatorReservationResult__ReservationNotFound = 7,
    ESpectatorReservationResult__ReservationAccepted = 8,
    ESpectatorReservationResult__ReservationDenied = 9,
    ESpectatorReservationResult__ReservationDenied_CrossPlayRestriction = 10,
    ESpectatorReservationResult__ReservationDenied_Banned = 11,
    ESpectatorReservationResult__ReservationRequestCanceled = 12,
    ESpectatorReservationResult__ReservationInvalid = 13,
    ESpectatorReservationResult__BadSessionId = 14,
    ESpectatorReservationResult__ReservationDenied_ContainsExistingPlayers = 15
};

enum EOnlineLinkModerationStatus : uint8_t
{
    EOnlineLinkModerationStatus__Unmoderated = 0,
    EOnlineLinkModerationStatus__Approved = 1,
    EOnlineLinkModerationStatus__Denied = 2
};

enum ESocialProfilePrivacySettingLevel : uint8_t
{
    ESocialProfilePrivacySettingLevel__Public = 0,
    ESocialProfilePrivacySettingLevel__FriendsOnly = 1,
    ESocialProfilePrivacySettingLevel__Private = 2
};

enum ESupervisedSettingsRestrictiveOrder : uint8_t
{
    ESupervisedSettingsRestrictiveOrder__FirstRestrictive = 0,
    ESupervisedSettingsRestrictiveOrder__FirstPermissive = 1,
    ESuperD_1_6____________________gf_______1__________ = 2,
    ESupervisedSettingsRestrictiveOrder__LowPermissive = 3,
    ESupervisedSettingsRestrictiveOrder__FalseRestrictive = 4,
    ESupervisedSettingsRestrictiveOrder__FalsePermissive = 5,
    ESupervisedSettingsRestrictiveOrder__None = 6
};

enum EDataRegistryAcquireStatus : uint8_t
{
    EDataRegistryAcquireStatus__NotStarted = 0,
    EDataRegistryAcquireStatus__WaitingForInitialAcquire = 1,
    EDataRegistryAcquireStatus__InitialAcquireFinished = 2,
    EDataRegistryAcquireStatus__WaitingForResources = 3,
    EDataRegistryAcquireStatus__AcquireFinished = 4,
    EDataRegistryAcquireStatus__AcquireError = 5,
    EDataRegistryAcquireStatus__DoesNotExist = 6
};

enum EDataRegistryAvailability : uint8_t
{
    EDataRegistryAvailability__DoesNotExist = 0,
    EDataRegistryAvailability__Unknown = 1,
    EDataRegistryAvailability__Remote = 2,
    EDataRegistryAvailability__OnDisk = 3,
    EDataRegistryAvailability__LocalAsset = 4,
    EDataRegistryAvailability__PreCached = 5
};

enum EGameFeatureTargetState : uint8_t
{
    EGameFeatureTargetState__Installed = 0,
    EGameFeatureTargetState__Registered = 1,
    EGameFeatureTargetState__Loaded = 2,
    EGameFeatureTargetState__Active = 3,
    EGameFeatureTargetState__Count = 4
};

enum EGameplayDebuggerOverrideMode : uint8_t
{
    EGameplayDebuggerOverrideMode__Enable = 0,
    EGameplayDebuggerOverrideMode__Disable = 1,
    EGameplayDebuggerOverrideMode__UseDefault = 2
};

enum EGameplayDebuggerShape : uint8_t
{
    EGameplayDebuggerShape__Invalid = 0,
    EGameplayDebuggerShape__Point = 1,
    EGameplayDebuggerShape__Segment = 2,
    EGameplayDebuggerShape__Box = 3,
    EGameplayDebuggerShape__Cone = 4,
    EGameplayDebug________o_______a_ = 5,
    EGameplayDebuggerShape__Circle = 6,
    EGameplayDebuggerShape__Rectangle = 7,
    EGameplayDebuggerShape__Capsule = 8,
    EGameplayDebuggerShape__Polygon = 9,
    EGameplayDebuggerShape__Polyline = 10,
    EGameplayDebuggerShape__Arrow = 11
};

enum ELinkGenerationDebugFlags : uint8_t
{
    ELinkGenerationDebugFlags__WalkableSurface = 1,
    ELinkGenerationDebugFlags__WalkableBorders = 2,
    ELinkGenerationDebugFlags__SelectedEdge = 4,
    ELinkGenerationDebugFlags__SelectedEdgeTrajectory = 8
};

enum ENavCostDisplay : uint8_t
{
    ENavCostDisplay__TotalCost = 0,
    ENavCostDisplay__HeuristicOnly = 1,
    ENavCostDisplay__RealCostOnly = 2
};

enum ERecastPartitioning : uint8_t
{
    ERecastPartitioning__Monotone = 0,
    ERecastPartitioning__Watershed = 1,
    ERecastPartitioning__ChunkyMonotone = 2
};

enum ENavigationLedgeSlopeFilterMode : uint8_t
{
    ENavigationLedgeSlopeFilterMode__Recast = 0,
    ENavigationLedgeSlopeFilterMode__None = 1,
    ENavigationLedgeSlopeFilterMode__UseStepHeightFromAgentMaxSlope = 2
};

enum EHeightFieldRenderMode : uint8_t
{
    EHeightFieldRenderMode__Solid = 0,
    EHeightFieldRenderMode__Walkable = 1
};

enum ENavSystemOverridePolicy : uint8_t
{
    ENavSystemOverridePolicy__Override = 0,
    ENavSystemOverridePolicy__Append = 1,
    ENavSystemOverridePolicy__Skip = 2
};

enum EPathFollowingResult : uint8_t
{
    EPathFollowingResult__Success = 0,
    EPathFollowingResult__Blocked = 1,
    EPathFollowingResult__OffPath = 2,
    EPathFollowingResult__Aborted = 3,
    EPathFollowingResult__Skipped_DEPRECATED = 4,
    EPathFollowingResult__Invalid = 5
};

enum EEnvQueryStatus : uint8_t
{
    EEnvQueryStatus__Processing = 0,
    EEnvQueryStatus__Success = 1,
    EEnvQueryStatus__Failed = 2,
    EEnvQueryStatus__Aborted = 3,
    EEnvQueryStatus__OwnerLost = 4,
    EEnvQueryStatus__MissingParam = 5
};

enum EPawnActionEventType : uint8_t
{
    EPawnActionEventType__Invalid = 0,
    EPawnActionEventType__FailedToStart = 1,
    EPawnActionEventType__InstantAbort = 2,
    EPawnActionEventType__FinishedAborting = 3,
    EPawnActionEventType__FinishedExecution = 4,
    EPawnActionEventType__Push = 5
};

enum EAIRequestPriority : uint8_t
{
    EAIRequestPriority__SoftScript = 0,
    EAIRequestPriority__Logic = 1,
    EAIRequestPriority__HardScript = 2,
    EAIRequestPriority__Reaction = 3,
    EAIRequestPriority__Ultimate = 4
};

enum EAILockSource : uint8_t
{
    EAILockSource__Animation = 0,
    EAILockSource__Logic = 1,
    EAILockSource__Script = 2,
    EAILockSource__Gameplay = 3
};

enum EGenericAICheck : uint8_t
{
    EGenericAICheck__Less = 0,
    EGenericAICheck__LessOrEqual = 1,
    EGenericAICheck__Equal = 2,
    EGenericAICheck__NotEqual = 3,
    EGenericAICheck__GreaterOrEqual = 4,
    EGenericAICheck__Greater = 5,
    EGenericAICheck__IsTrue = 6
};

enum EArithmeticKeyOperation : uint8_t
{
    EArithmeticKeyOperation__Equal = 0,
    EArithmeticKeyOperation__NotEqual = 1,
    EArithmeticKeyOperation__Less = 2,
    EArithmeticKeyOperation__LessOrEqual = 3,
    EArithmeticKeyOperation__Greater = 4,
    EArithmeticKeyOperation__GreaterOrEqual = 5
};

enum EEnvTestPurpose : uint8_t
{
    EEnvTestPurpose__Filter = 0,
    EEnvTestPurpose__Score = 1,
    EEnvTestPurpose__FilterAndScore = 2
};

enum EEnvTestWeight : uint8_t
{
    EEnvTestWeight__None = 0,
    EEnvTestWeight__Square = 1,
    EEnvTestWeight__Inverse = 2,
    EEnvTestWeight__Unused = 3,
    EEnvTestWeight__Constant = 4,
    EEnvTestWeight__Skip = 5
};

enum EEnvTestCost : uint8_t
{
    EEnvTestCost__Low = 0,
    EEnvTestCost__Medium = 1,
    EEnvTestCost__High = 2
};

enum EEnvTestScoreOperator : uint8_t
{
    EEnvTestScoreOperator__AverageScore = 0,
    EEnvTestScoreOperator__MinScore = 1,
    EEnvTestScoreOperator__MaxScore = 2,
    EEnvTestScoreOperator__Multiply = 3
};

enum EEnvQueryRunMode : uint8_t
{
    EEnvQueryRunMode__SingleResult = 0,
    EEnvQueryRunMode__RandomBest5Pct = 1,
    EEnvQueryRunMode__RandomBest25Pct = 2,
    EEnvQueryRunMode__AllMatching = 3
};

enum EEnvQueryParam : uint8_t
{
    EEnvQueryP_e__0______ = 0,
    EEnvQueryParam__Int = 1,
    EEnvQueryParam__Bool = 2
};

enum EEnvTraceShape : uint8_t
{
    EEnvTraceShape__Line = 0,
    EEnvTraceShape__Box = 1,
    EEnvTraceShape__Sphere = 2,
    EEnvTraceShape__Capsule = 3
};

enum EEnvOverlapShape : uint8_t
{
    EEnvOverlapShape__Box = 0,
    EEnvOverlapShape__Sphere = 1,
    EEnvOverlapShape__Capsule = 2
};

enum EEnvQueryTestClamping : uint8_t
{
    EEnvQueryTestClamping__None = 0,
    EEnvQueryTestClamping__SpecifiedValue = 1,
    EEnvQueryTestClamping__FilterThreshold = 2
};

enum ETeamAttitude : uint8_t
{
    ETeamAttitude__Friendly = 0,
    ETeamAttitude__Neutral = 1,
    ETeamAttitude__Hostile = 2
};

enum EPawnSubActionTriggeringPolicy : uint8_t
{
    EPawnSubActionTriggeringPolicy__CopyBeforeTriggering = 0,
    EPawnSubActionTriggeringPolicy__ReuseInstances = 1
};

enum EPawnActionFailHandling : uint8_t
{
    EPawnActionFailHandling__RequireSuccess = 0,
    EPawnActionFailHandling__IgnoreFailure = 1
};

enum EPawnActionMoveMode : uint8_t
{
    EPawnActionMoveMode__UsePathfinding = 0,
    EPawnActionMoveMode__StraightLine = 1
};

enum EBTNodeResult : uint8_t
{
    EBTNodeResult__Succeeded = 0,
    EBTNodeResult__Failed = 1,
    EBTNodeResult__Aborted = 2,
    EBTNodeResult__InProgress = 3
};

enum EBTFlowAbortMode : uint8_t
{
    EBTFlowAbortMode__None = 0,
    EBTFlowAbortMode__LowerPriority = 1,
    EBTFlowAbortMode__Self = 2,
    EBTFlowAbortMode__Both = 3
};

enum EBTChildIndex : uint8_t
{
    EBTChildIndex__FirstNode = 0,
    EBTChildIndex__TaskNode = 1
};

enum EBTParallelMode : uint8_t
{
    EBTParallelMode__AbortBackground = 0,
    EBTParallelMode__WaitForBackground = 1
};

enum EBTBlackboardRestart : uint8_t
{
    EBTBlackboardRestart__ValueChange = 0,
    EBTBlackboardRestart__ResultChange = 1
};

enum EBlackBoardEntryComparison : uint8_t
{
    EBlackBoardEntryComparison__Equal = 0,
    EBlackBoardEntryComparison__NotEqual = 1
};

enum EPathExistanceQueryType : uint8_t
{
    EPathExistanceQueryType__NavmeshRaycast2D = 0,
    EPathExistanceQueryType__HierarchicalQuery = 1,
    EPathExistanceQueryType__RegularPathFinding = 2
};

enum EEQSNormalizationType : uint8_t
{
    EEQSNormalizationType__Absolute = 0,
    EEQSNormalizationType__RelativeToScores = 1
};

enum EEnvQueryHightlightMode : uint8_t
{
    EEnvQueryHightlightMode__All = 0,
    EEnvQueryHightlightMode__Best5Pct = 1,
    EEnvQueryHightlightMode__Best25Pct = 2
};

enum EPointOnCircleSpacingMethod : uint8_t
{
    EPointOnCircleSpacingMethod__BySpaceBetween = 0,
    EPointOnCircleSpacingMethod__ByNumberOfPM____ = 1
};

enum EEnvTestDistance : uint8_t
{
    EEnvTestDistance__Distance3D = 0,
    EEnvTestDistance__Distance2D = 1,
    EEnvTestDistance__DistanceZ = 2,
    EEnvTestDistance__DistanceAbsoluteZ = 3
};

enum EEnvTestPathfinding : uint8_t
{
    EEnvTestPathfinding__PathExist = 0,
    EEnvTesth__w___________K_____ = 1,
    EEnvTestPathfinding__PathLength = 2
};

enum EPathFollowingStatus : uint8_t
{
    EPathFollowingStatus__Idle = 0,
    EPathFollowingStatus__Waiting = 1,
    EPathFollowingStatus__Paused = 2,
    EPathFollowingStatus__Moving = 3
};

enum EPathFollowingRequestResult : uint8_t
{
    EPathFollowingRequestResult__Failed = 0,
    EPathFollowingRequestResult__AlreadyAtGoal = 1,
    EPathFollowingRequestResult__RequestSuccessful = 2
};

enum EStateTreeBreakpointType : uint8_t
{
    EStateTreeBreakpointType__Unset = 0,
    EStateTreeBreakpointType__OnEnter = 1,
    EStateTreeBreakpointType__OnExit = 2,
    EStateTreeBreakpointType__OnTransition = 3
};

enum EStateTreeUpdatePhase : uint8_t
{
    EStateTreeUpdatePhase__Unset = 0,
    EStateTreeUpdatePhase__StartTree = 1,
    EStateTreeUpdatePhase__StopTree = 2,
    EStateTreeUpdatePhase__StartGlobalTasks = 3,
    EStateTreeUpdatePhase__StopGlobalTasks = 4,
    EStateTreeUpdatePhase__TickStateTree = 5,
    EStateTreeUpdatePhase__ApplyTransitions = 6,
    EStateTreeUpdatePhase__TriggerTransitions = 7,
    EStateTreeUpdatePhase__TickingGlobalTasks = 8,
    EStateTreeUpdatePhase__TickingTasks = 9,
    EStateTreeUpdatePhase__TransitionConditions = 10,
    EStateTreeUpdatePhase__StateSelection = 11,
    EStateTreeUpdatePhase__TrySelectBehavior = 12,
    EStateTreeUpdatePhase__EnterConditions = 13,
    EStateTreeUpdatePhase__EnterStates = 14,
    EStateTreeUpdatePhase__ExitStates = 15,
    EStateTreeUpdatePhase__StateCompleted = 16
};

enum EStateTreeStateChangeType : uint8_t
{
    EStateTreeStateChangeType__None = 0,
    EStateTreeStateChangeType__Changed = 1,
    EStateTreeStateChangeType__Sustained = 2
};

enum EStateTreeConditionEvaluationMode : uint8_t
{
    EStateTreeConditionEvaluationMode__Evaluated = 0,
    EStateTreeConditionEvaluationMode__ForcedTrue = 1,
    EStateTreeConditionEvaluationMode__ForcedFalse = 2
};

enum EStateTreeTransitionSourceType : uint8_t
{
    EStateTreeTransitionSourceType__Unset = 0,
    EStateTreeTransitionSourceType__Asset = 1,
    EStateTreeTransitionSourceType__ExternalRequest = 2,
    EStateTreeTransitionSourceType__Internal = 3
};

enum EStateTreeRecordTransitions : uint8_t
{
    EStateTreeRecordTransitions__No = 0,
    EStateTreeRecordTransitions__Yes = 1
};

enum EStateTreeLinkerStatus : uint8_t
{
    EStateTreeLinkerStatus__Succeeded = 0,
    EStateTreeLinkerStatus__Failed = 1
};

enum EStateTreeNodeFormatting : uint8_t
{
    RichText = 0,
    Text = 1
};

enum EStateTreePropertyRefType : uint8_t
{
    EStateTreePropertyRefType__None = 0,
    EStateTreePropertyRefType__Bool = 1,
    EStateTreePropertyRefType__Byte = 2,
    EStateTreePropertyRefType__Int32 = 3,
    EStateTreePropertyRefType__Int64 = 4,
    EStateTreePropertyRefType__Float = 5,
    EStateTreePropertyRefType__Double = 6,
    EStateTreePropertyRefType__Name = 7,
    EStateTreePropertyRefType__String = 8,
    EStateTreePropertyRefType__Text = 9,
    EStateTreePropertyRefType__Enum = 10,
    EStateTreePropertyRefType__Struct = 11,
    EStateTreePropertyRefType__Object = 12,
    EStateTreePropertyRefType__SoftObject = 13,
    EStateTreePropertyRefType__Class = 14,
    EStateTreePropertyRefType__SoftClass = 15
};

enum EStateTreeTraceStatus : uint8_t
{
    EStateTreeTraceStatus__TracesStarted = 0,
    EStateTreeTraceStatus__StoppingTrace = 1,
    EStateTreeTraceStatus__TracesStopped = 2
};

enum EStateTreeTraceEventType : uint8_t
{
    EStateTreeTraceEventType__Unset = 0,
    EStateTreeTraceEventType__OnEntering = 1,
    EStateTreeTraceEventType__OnEntered = 2,
    EStateTreeTraceEventType__OnExiting = 3,
    EStateTreeTraceEventType__OnExited = 4,
    EStateTreeTraceEventType__Push = 5,
    EStateTreeTraceEventType__Pop = 6,
    EStateTreeTraceEventType__OnStateSelected = 7,
    EStateTreeTraceEventType__OnStateCompleted = 8,
    EStateTreeTraceEventType__OnTicking = 9,
    EStateTreeTraceEventType__OnTaskCompleted = 10,
    EStateTreeTraceEventType__OnTicked = 11,
    EStateTreeTraceEventType__Passed = 12,
    EStateTreeTraceEventType__Failed = 13,
    EStateTreeTraceEventType__ForcedSuccess = 14,
    EStateTreeTraceEventType__ForcedFailure = 15,
    EStateTreeTraceEventType__InternalForcedFailure = 16,
    EStateTreeTraceEventType__OnEvaluating = 17,
    EStateTreeTraceEventType__OnTransition = 18,
    EStateTreeTraceEventType__OnTreeStarted = 19,
    EStateTreeTraceEventType__OnTreeStopped = 20
};

enum EStateTreeLoopEvents : uint8_t
{
    EStateTreeLoopEvents__Next = 0,
    EStateTreeLoopEvents__Break = 1,
    EStateTreeLoopEvents__Consume = 2
};

enum EStateTreeBindableStructSource : uint8_t
{
    EStateTreeBindableStructSource__Context = 0,
    EStateTreeBindableStructSource__Parameter = 1,
    EStateTreeBindableStructSource__Evaluator = 2,
    EStateTreeBindableStructSource__GlobalTask = 3,
    EStateTreeBindableStructSource__StateParameter = 4,
    EStateTreeBindableStructSource__Task = 5,
    EStateTreeBindableStructSource__Condition = 6,
    EStateTreeBindableStructSource__Consideration = 7,
    EStateTreeBindableStructSource__TransitionEvent = 8,
    EStateTreeBindableStructSource__StateEvent = 9,
    EStateTreeBindableStructSource__PropertyFunction = 10
};

enum EStateTreePropertyAccessType : uint8_t
{
    EStateTreePropertyAccessType__Offset = 0,
    EStateTreePropertyAccessType__Object = 1,
    EStateTreePropertyAccessType__WeakObject = 2,
    EStateTreePropertyAccessType__SoftObject = 3,
    EStateTreePropertyAccessType__ObjectInstance = 4,
    EStateTreePropertyAccessType__StructInstance = 5,
    EStateTreePropertyAccessType__IndexArray = 6
};

enum EStateTreePropertyCopyType : uint8_t
{
    EStateTreePropertyCopyType__None = 0,
    EStateTreePropertyCopyType__CopyPlain = 1,
    EStateTreePropertyCopyType__CopyComplex = 2,
    EStateTreePropertyCopyType__CopyBool = 3,
    EStateTreePropertyCopyType__CopyStruct = 4,
    EStateTreePropertyCopyType__CopyObject = 5,
    EStateTreePropertyCopyType__CopyName = 6,
    EStateTreePropertyCopyType__CopyFixedArray = 7,
    EStateTreePropertyCopyType__StructReference = 8,
    EStateTreePropertyCopyType__PromoteBoolToByte = 9,
    EStateTreePropertyCopyType__PromoteBoolToInt32 = 10,
    EStateTreePropertyCopyType__PromoteBoolToUInt32 = 11,
    EStateTreePropertyCopyType__PromoteBoolToInt64 = 12,
    EStateTreePropertyCopyType__PromoteBoolToFloat = 13,
    EStateTreePropertyCopyType__PromoteBoolToDouble = 14,
    EStateTreePropertyCopyType__PromoteByteToInt32 = 15,
    EStateTreePropertyCopyType__PromoteByteToUInt32 = 16,
    EStateTreePropertyCopyType__PromoteByteToInt64 = 17,
    EStateTreePropertyCopyType__PromoteByteToFloat = 18,
    EStateTreePropertyCopyType__PromoteByteToDouble = 19,
    EStateTreePropertyCopyType__PromoteInt32ToInt64 = 20,
    EStateTreePropertyCopyType__PromoteInt32ToFloat = 21,
    EStateTreePropertyCopyType__PromoteInt32ToDouble = 22,
    EStateTreePropertyCopyType__PromoteUInt32ToInt64 = 23,
    EStateTreePropertyCopyType__PromoteUInt32ToFloat = 24,
    EStateTreePropertyCopyType__PromoteUInt32ToDouble = 25,
    EStateTreePropertyCopyType__PromoteFloatToInt32 = 26,
    EStateTreePropertyCopyType__PromoteFloatToInt64 = 27,
    EStateTreePropertyCopyType__PromoteFloatToDouble = 28,
    EStateTreePropertyCopyType__DemoteDoubleToInt32 = 29,
    EStateTreePropertyCopyType__DemoteDoubleToInt64 = 30,
    EStateTreePropertyCopyType__DemoteDoubleToFloat = 31
};

enum EStateTreeTransitionType : uint8_t
{
    EStateTreeTransitionType__None = 0,
    EStateTreeTransitionType__Succeeded = 1,
    EStateTreeTransitionType__Failed = 2,
    EStateTreeTransitionType__GotoState = 3,
    EStateTreeTransitionType__NextState = 4,
    EStateTreeTransitionType__NextSelectableState = 5,
    EStateTreeTransitionType__NotSet = 6
};

enum EStateTreeExpressionOperand : uint8_t
{
    EStateTreeExpressionOperand__Copy = 0,
    EStateTreeExpressionOperand__And = 1,
    EStateTreeExpressionOperand__Or = 2
};

enum EStateTreeStateSelectionBehavior : uint8_t
{
    EStateTreeStateSelectionBehavior__None = 0,
    EStateTreeStateSelectionBehavior__TryEnterState = 1,
    EStateTreeStateSelectionBehavior__TrySelectChildrenInOrder = 2,
    EStateTreeStateSelectionBehavior__TrySelectChildrenAtRandom = 3,
    EStateTreeStateSelectionBehavior__TrySelectChildrenWithHighestUtility = 4,
    EStateTreeStateSelectionBehavior__TrySelectChildrenAtRandomWeightedByUtility = 5,
    EStateTreeStateSelectionBehavior__TryFollowTransitions = 6,
    EStateTreeStateSelectionBehavior__TrySelectChildrenAtUniformRandom = 3,
    EStateTreeStateSelectionBehavior__TrySelectChildrenBasedOnRelativeUtility = 5
};

enum EStateTreeTransitionPriority : uint8_t
{
    EStateTreeTransitionPriority__None = 0,
    EStateTreeTransitionPriority__Low = 1,
    EStateTreeTransitionPriority__Normal = 2,
    EStateTreeTransitionPriority__Medium = 3,
    EStateTreeTransitionPriority__High = 4,
    EStateTreeTransitionPriority__Critical = 5
};

enum EStateTreeDataSourceType : uint8_t
{
    EStateTreeDataSourceType__None = 0,
    EStateTreeDataSourceType__GlobalInstanceData = 1,
    EStateTreeDataSourceType__GlobalInstanceDataObject = 2,
    EStateTreeDataSourceType__ActiveInstanceData = 3,
    EStateTreeDataSourceType__ActiveInstanceDataObject = 4,
    EStateTreeDataSourceType__SharedInstanceData = 5,
    EStateTreeDataSourceType__SharedInstanceDataObject = 6,
    EStateTreeDataSourceType__ContextData = 7,
    EStateTreeDataSourceType__ExternalData = 8,
    EStateTreeDataSourceType__GlobalParameterData = 9,
    EStateTreeDataSourceType__SubtreeParameterData = 10,
    EStateTreeDataSourceType__StateParameterData = 11,
    EStateTreeDataSourceType__TransitionEvent = 12,
    EStateTreeDataSourceType__StateEvent = 13
};

enum EStateTreeSelectionFallback : uint8_t
{
    EStateTreeSelectionFallback__None = 0,
    EStateTreeSelectionFallback__NextSelectableSibling = 1,
    ES___________kZ__Aw_________s__f___Rl________lU__I__________ = 2
};

enum EStateTreeExternalDataRequirement : uint8_t
{
    EStateTreeExternalDataRequirement__Required = 0,
    EStateTreeExternalDataRequirement__Optional = 1
};

enum EEventBubblingRule : uint8_t
{
    EEventBubblingRule__None = 0,
    EEventBubblingRule__Down = 1,
    EEventBubblingRule__Up = 2
};

enum ERigVMPinDirection : uint8_t
{
    ERigVMPinDirection__Input = 0,
    ERigVMPinDirection__Output = 1,
    ERigVMPinDirection__IO = 2,
    ERigVMPinDirection__Visible = 3,
    ERigVMPinDirection__Hidden = 4,
    ERigVMPinDirection__Invalid = 5
};

enum ERigVMFunctionArgumentDirection : uint8_t
{
    ERigVMFunctionArgumentDirection__Input = 0,
    ERigVMFunctionArgumentDirection__Output = 1,
    ERigVMFunctionArgumentDirection__Invalid = 2
};

enum ERigVMTransformSpace : uint8_t
{
    ERigVMTransformSpace__LocalSpace = 0,
    ERigVMTransformSpace__GlobalSpace = 1,
    ERigVMTransformSpace__Max = 2
};

enum ERigVMClampSpatialMode : uint8_t
{
    ERigVMClampSpatialMode__Plane = 0,
    ERigVMClampSpatialMode__Cylinder = 1,
    ERigVMClampSpatialMode__Sphere = 2,
    ERigVMClampSpatialMode__Capsule = 3
};

enum ERigVMParameterType : uint8_t
{
    ERigVMParameterType__Input = 0,
    ERigVMParameterType__Output = 1,
    ERigVMParameterType__Invalid = 2
};

enum ERigVMOpCode : uint8_t
{
    ERigVMOpCode__Execute_0_Operands = 0,
    ERigVMOpCode__Execute_1_Operands = 1,
    ERigVMOpCode__Execute_2_Operands = 2,
    ERigVMOpCode__Execute_3_Operands = 3,
    ERigVMOpCode__Execute_4_Operands = 4,
    ERigVMOpCode__Execute_5_Operands = 5,
    ERigVMOpCode__Execute_6_Operands = 6,
    ERigVMOpCode__Execute_7_Operands = 7,
    ERigVMOpCode__Execute_8_Operands = 8,
    ERigVMOpCode__Execute_9_Operands = 9,
    ERigVMOpCode__Execute_10_Operands = 10,
    ERigVMOpCode__Execute_11_Operands = 11,
    ERigVMOpCode__Execute_12_Operands = 12,
    ERigVMOpCode__Execute_13_Operands = 13,
    ERigVMOpCode__Execute_14_Operands = 14,
    ERigVMOpCode__Execute_15_Operands = 15,
    ERigVMOpCode__Execute_16_Operands = 16,
    ERigVMOpCode__Execute_17_Operands = 17,
    ERigVMOpCode__Execute_18_Operands = 18,
    ERigVMOpCode__Execute_19_Operands = 19,
    ERigVMOpCode__Execute_20_Operands = 20,
    ERigVMOpCode__Execute_21_Operands = 21,
    ERigVMOpCode__Execute_22_Operands = 22,
    ERigVMOpCode__Execute_23_Operands = 23,
    ERigVMOpCode__Execute_24_Operands = 24,
    ERigVMOpCode__Execute_25_Operands = 25,
    ERigVMOpCode__Execute_26_Operands = 26,
    ERigVMOpCode__Execute_27_Operands = 27,
    ERigVMOpCode__Execute_28_Operands = 28,
    ERigVMOpCode__Execute_29_Operands = 29,
    ERigVMOpCode__Execute_30_Operands = 30,
    ERigVMOpCode__Execute_31_Operands = 31,
    ERigVMOpCode__Execute_32_Operands = 32,
    ERigVMOpCode__Execute_33_Operands = 33,
    ERigVMOpCode__Execute_34_Operands = 34,
    ERigVMOpCode__Execute_35_Operands = 35,
    ERigVMOpCode__Execute_36_Operands = 36,
    ERigVMOpCode__Execute_37_Operands = 37,
    ERigVMOpCode__Execute_38_Operands = 38,
    ERigVMOpCode__Execute_39_Operands = 39,
    ERigVMOpCode__Execute_40_Operands = 40,
    ERigVMOpCode__Execute_41_Operands = 41,
    ERigVMOpCode__Execute_42_Operands = 42,
    ERigVMOpCode__Execute_43_Operands = 43,
    ERigVMOpCode__Execute_44_Operands = 44,
    ERigVMOpCode__Execute_45_Operands = 45,
    ERigVMOpCode__Execute_46_Operands = 46,
    ERigVMOpCode__Execute_47_Operands = 47,
    ERigVMOpCode__Execute_48_Operands = 48,
    ERigVMOpCode__Execute_49_Operands = 49,
    ERigVMOpCode__Execute_50_Operands = 50,
    ERigVMOpCode__Execute_51_Operands = 51,
    ERigVMOpCode__Execute_52_Operands = 52,
    ERigVMOpCode__Execute_53_Operands = 53,
    ERigVMOpCode__Execute_54_Operands = 54,
    ERigVMOpCode__Execute_55_Operands = 55,
    ERigVMOpCode__Execute_56_Operands = 56,
    ERigVMOpCode__Execute_57_Operands = 57,
    ERigVMOpCode__Execute_58_Operands = 58,
    ERigVMOpCode__Execute_59_Operands = 59,
    ERigVMOpCode__Execute_60____f2_g_ = 60,
    ERigVMOpCode__Execute_61_Operands = 61,
    ERigVMOpCode__Execute_62_Operands = 62,
    ERigVMOpCode__Execute_63_Operands = 63,
    ERigVMOpCode__Execute_64_Operands = 64,
    ERigVMOpCode__Zero = 65,
    ERigVMOpCode__BoolFalse = 66,
    ERigVMOpCode__BoolTrue = 67,
    ERigVMOpCode__Copy = 68,
    ERigVMOpCode__Increment = 69,
    ERigVMOpCode__Decrement = 70,
    ERigVMOpCode__Equals = 71,
    ERigVMOpCode__NotEquals = 72,
    ERigVMOpCode__JumpAbsolute = 73,
    ERigVMOpCode__JumpForward = 74,
    ERigVMOpCode__JumpBackward = 75,
    ERigVMOpCode__JumpAbsoluteIf = 76,
    ERigVMOpCode__JumpForwardIf = 77,
    ERigVMOpCode__JumpBackwardIf = 78,
    ERigVMOpCode__ChangeType = 79,
    ERigVMOpCode__Exit = 80,
    ERigVMOpCode__BeginBlock = 81,
    ERigVMOpCode__EndBlock = 82,
    ERigVMOpCode__ArrayReset = 83,
    ERigVMOpCode__ArrayGetNum = 84,
    ERigVMOpCode__ArraySetNum = 85,
    ERigVMOpCode__ArrayGetAtIndex = 86,
    ERigVMOpCode__ArraySetAtIndex = 87,
    ERigVMOpCode__ArrayAdd = 88,
    ERigVMOpCode__ArrayInsert = 89,
    ERigVMOpCode__ArrayRemove = 90,
    ERigVMOpCode__ArrayFind = 91,
    ERigVMOpCode__ArrayAppend = 92,
    ERigVMOpCode__ArrayClone = 93,
    ERigVMOpCode__ArrayIterator = 94
};

enum ERigVMCopyType : uint8_t
{
    ERigVMCopyType__Default = 0,
    ERigVMCopyType__FloatToDouble = 1,
    ERigVMCopyType__DoubleToFloat = 2
};

enum ERigVMBreakpointAction : uint8_t
{
    ERigVMBreakpointAction__None = 0,
    ERigVMBreakpointAction__Resume = 1,
    ERigVMBreakpointAction__StepOver = 2,
    ERigVMBreakpointAction__StepInto = 3,
    ERigVMBreakpointAction__StepOut = 4,
    ERigVMBreakpointAction__Max = 5
};

enum ERigVMDrawSettings : uint8_t
{
    ERigVMDrawSettings__Points = 0,
    ERigVMDrawSettings__Lines = 1,
    ERigVMDrawSettings__LineStrip = 2,
    ERigVMDrawSettings__DynamicMesh = 3
};

enum ERigVMMemoryType : uint8_t
{
    ERigVMMemoryType__Work = 0,
    ERigVMMemoryType__Literal = 1,
    ERigVMMemoryType__External = 2,
    ERigVMMemoryType__Debug = 3,
    ERigVMMemoryType__Invalid = 4
};

enum ERigVMRegisterType : uint8_t
{
    ERigVMRegisterType__Plain = 0,
    ERigVMRegisterType__String = 1,
    ERigVMRegisterType__Name = 2,
    ERigVMRegisterType__Struct = 3,
    ERigVMRegisterType__Invalid = 4
};

enum ERigVMUserWorkflowType : uint8_t
{
    ERigVMUserWorkflowType__Invalid = 0,
    ERigVMUserWorkflowType__NodeContext = 1,
    ERigVMUserWorkflowType__PinContext = 2,
    ERigVMUserWorkflowType__OnPinDefaultChanged = 4,
    ERigVMUserWorkflowType__All = 7
};

enum ERigUnitDebugPointMode : uint8_t
{
    ERigUnitDebugPointMode__Point = 0,
    ERigUnitDebugPointMode__Vector = 1,
    ERigUnitDebugPointMode__Max = 2
};

enum ERigUnitVisualDebugPointMode : uint8_t
{
    ERigUnitVisualDebugPointMode__Point = 0,
    ERigUnitVisualDebugPointMode__Vector = 1,
    ERigUnitVisualDebugPointMode__Max = 2
};

enum ERBFKernelType : uint8_t
{
    ERBFKernelType__Gaussian = 0,
    ERBFKernelType__Exponential = 1,
    ERBFKernelType__Linear = 2,
    ERBFKernelType__Cubic = 3,
    ERBFKernelType__Quintic = 4
};

enum ERBFQuatDistanceType : uint8_t
{
    ERBFQuatDistanceType__Euclidean = 0,
    ERBFQuatDistanceType__ArcLength = 1,
    ERBFQuatDistanceType__SwingAngle = 2,
    ERBFQuatDistanceType__TwistAngle = 3
};

enum ERBFVectorDistanceType : uint8_t
{
    ERBFVectorDistanceType__Euclidean = 0,
    ERBFVectorDistanceType__Manhattan = 1,
    ERBFVectorDistanceType__ArcLength = 2
};

enum ERigVMSimPointIntegrateType : uint8_t
{
    ERigVMSimPointIntegrateType__Verlet = 0,
    ERigVMSimPointIntegrateType__SemiExplicitEuler = 1
};

enum ESoundLibraryNotifyTriggerType : uint8_t
{
    ESoundLibraryNotifyTriggerType__Play = 0,
    ESoundLibraryNotifyTriggerType__Stop = 1,
    ESoundLibraryNotifyTriggerType__None = 2
};

enum ESoundLibrarySelectionBehavior : uint8_t
{
    ESoundLibrarySelectionBehavior__SelectAll = 0,
    ESoundLibrarySelectionBehavior__Random = 1,
    ESoundLibrarySelectionBehavior__Shuffle = 2,
    ESoundLibrarySelectionBehavior__Max_None = 3
};

enum ETextureCompressionStrategy : uint8_t
{
    ETextureCompressionStrategy__None = 0,
    ETextureCompressionStrategy__DontCompressRuntime = 1,
    ETextureCompressionStrategy__NeverCompress = 2
};

enum EFaceCullStrategy : uint8_t
{
    EFaceCullStrategy__AllVerticesCulled = 0,
    EFaceCullStrategy__OneVertexCulled = 1
};

enum EPackageSaveResolutionType : uint8_t
{
    EPackageSaveResolutionType__None = 0,
    EPackageSaveResolutionType__NewFile = 1,
    EPackageSaveResolutionType__Overriden = 2,
    EPackageSaveResolutionType__UnableToOverride = 3
};

enum EUpdateResult : uint8_t
{
    EUpdateResult__Success = 0,
    EUpdateResult__Warning = 1,
    EUpdateResult__Error = 2,
    EUpdateResult__ErrorOptimized = 3,
    EUpdateResult__ErrorReplaced = 4,
    EUpdateResult__ErrorDiscarded = 5,
    EUpdateResult__Error16BitBoneIndex = 6
};

enum ECustomizableObjectNumBoneInfluences : uint8_t
{
    ECustomizableObjectNumBoneInfluences__Four = 4,
    ECustomizableObjectNumBoneInfluences__Eight = 8,
    ECustomizableObjectNumBoneInfluences__Twelve = 12
};

enum ECustomizableObjectTextureCompression : uint8_t
{
    ECustomizableObjectTextureCompression__None = 0,
    ECustomizableObjectTextureCompression__Fast = 1,
    ECustomizableObjectTextureCompression__HighQuality = 2
};

enum ECustomizableObjectGroupType : uint8_t
{
    ECustomizableObjectGroupType__COGT_TOGGLE = 0,
    ECustomizableObjectGroupType__COGT_ALL = 1,
    ECustomizableObjectGroupType__COGT_ONE = 2,
    ECustomizableObjectGroupType__COGT_ONE_OR_NONE = 3
};

enum EMutableCompileMeshType : uint8_t
{
    EMutableCompileMeshType__Full = 0,
    EMutableCompileMeshType__Local = 1,
    EMutableCompileMeshType__LocalAndChildren = 2,
    EMutableCompileMeshType__AddWorkingSetNoChildren = 3,
    EMutableCompileMeshType__AddWorkingSetAndChildren = 4
};

enum ECustomizableObjectProjectorType : uint8_t
{
    ECustomizableObjectProjectorType__Planar = 0,
    ECustomizableObjectProjectorType__Cylindrical = 1,
    ECustomizableObjectProjectorType__Wrapping = 2
};

enum ECOResourceDataType : uint8_t
{
    ECOResourceDataType__None = 0,
    ECOResourceDataType__AssetUserData = 1
};

enum ETaskObjectStateChangeType : uint8_t
{
    ETaskObjectStateChangeType__None = 0,
    ETaskObjectStateChangeType__BeginState = 1,
    ETaskObjectStateChangeType__EndState = 2
};

enum EPlayerMappableKeySlot : uint8_t
{
    EPlayerMappableKeySlot__First = 0,
    EPlayerMappableKeySlot__Second = 1,
    EPlayerMappableKeySlot__Third = 2,
    EPlayerMappableKeySlot__Fourth = 3,
    EPlayerMappableKeySlot__Fifth = 4,
    EPlayerMappableKeySlot__Sixth = 5,
    EPlayerMappableKeySlot__Seventh = 6,
    EPlayerMappableKeySlot__Unspecified = 7,
    EPlayerMappableKeySlot__Max = 8
};

enum EInputActionValueType : uint8_t
{
    EInputActionValueType__Boolean = 0,
    EInputActionValueType__Axis1D = 1,
    EInputActionValueType__Axis2D = 2,
    EInputActionValueType__Axis3D = 3
};

enum EMappingQueryResult : uint8_t
{
    EMappingQueryResult__Error_EnhancedInputNotEnabled = 0,
    EMappingQueryResult__Error_InputContextNotInActiveContexts = 1,
    EMappingQueryResult__Error_InvalidAction = 2,
    EMappingQueryResult__NotMappable = 3,
    EMappingQueryResult__MappingAvailable = 4
};

enum EMappingQueryIssue : uint8_t
{
    EMappingQueryIssue__NoIssue = 0,
    EMappingQueryIssue__ReservedByAction = 1,
    EMappingQueryIssue__HidesExistingMapping = 2,
    EMappingQueryIssue__HiddenByExistingMapping = 4,
    EMappingQueryIssue__CollisionWithMappingInSameContext = 8,
    EMappingQueryIssue__ForcesTypePromotion = 16,
    EMappingQueryIssue__ForcesTypeDemotion = 32
};

enum EPlayerMappableKeySettingBehaviors : uint8_t
{
    EPlayerMappableKeySettingBehaviors__InheritSettingsFromAction = 0,
    EPlayerMappableKeySettingBehaviors__OverrideSettings = 1,
    EPlayerMappableKeySettingBehaviors__IgnoreSettings = 2
};

enum EInputMappingRebuildType : uint8_t
{
    EInputMappingRebuildType__None = 0,
    EInputMappingRebuildType__Rebuild = 1,
    EInputMappingRebuildType__RebuildWithFlush = 2
};

enum EInputActionAccumulationBehavior : uint8_t
{
    EInputActionAccumulationBehavior__TakeHighestAbsoluteValue = 0,
    EInputActionAccumulationBehavior__Cumulative = 1
};

enum ENormalizeInputSmoothingType : uint8_t
{
    ENormalizeInputSmoothingType__None = 0,
    ENormalizeInputSmoothingType__Lerp = 1,
    ENormalizeInputSmoothingType__Interp_To = 2,
    ENormalizeInputSmoothingType__Interp_Constant_To = 3,
    ENormalizeInputSmoothingType__Interp_Circular_In = 4,
    ENormalizeInputSmoothingType__Interp_Circular_Out = 5,
    ENormalizeInputSmoothingType__Interp_Circular_In_Out = 6,
    ENormalizeInputSmoothingType__Interp_Ease_In = 7,
    ENormalizeInputSmoothingType__Interp_Ease_Out = 8,
    ENormalizeInputSmoothingType__Interp_Ease_In_Out = 9,
    ENormalizeInputSmoothingType__Interp_Expo_In = 10,
    ENormalizeInputSmoothingType__Interp_Expo_Out = 11,
    ENormalizeInputSmoothingType__Interp_Expo_In_Out = 12,
    ENormalizeInputSmoothingType__Interp_Sin_In = 13,
    ENormalizeInputSmoothingType__Interp_Sin_Out = 14,
    ENormalizeInputSmoothingType__Interp_Sin_In_Out = 15
};

enum EDeadZoneType : uint8_t
{
    EDeadZoneType__Axial = 0,
    EDeadZoneType__Radial = 1,
    EDeadZoneType__UnscaledRadial = 2
};

enum EFOVScalingType : uint8_t
{
    EFOVScalingType__Standard = 0,
    EFOVScalingType__UE4_BackCompat = 1
};

enum EInputAxisSwizzle : uint8_t
{
    EInputAxisSwizzle__YXZ = 0,
    EInputAxisSwizzle__ZYX = 1,
    EInputAxisSwizzle__XZY = 2,
    EInputAxisSwizzle__YZX = 3,
    EInputAxisSwizzle__ZXY = 4
};

enum ETriggerState : uint8_t
{
    ETriggerState__None = 0,
    ETriggerState__Ongoing = 1,
    ETriggerState__Triggered = 2
};

enum ETriggerEvent : uint8_t
{
    ETriggerEvent__None = 0,
    ETriggerEvent__Triggered = 1,
    ETriggerEvent__Started = 2,
    ETriggerEvent__Ongoing = 4,
    ETriggerEvent__Canceled = 8,
    ETriggerEvent__Completed = 16
};

enum ETriggerType : uint8_t
{
    ETriggerType__Explicit = 0,
    ETriggerType__Implicit = 1,
    ETriggerType__Blocker = 2
};

enum ETriggerEventsSupported : uint8_t
{
    ETriggerEventsSupported__None = 0,
    ETriggerEventsSupported__Instant = 1,
    ETriggerEventsSupported__Uninterruptible = 2,
    ETriggerEventsSupported__Ongoing = 4,
    ETriggerEventsSupported__All = 7
};

enum ECommonInputType : uint8_t
{
    ECommonInputType__MouseAndKeyboard = 0,
    ECommonInputType__Gamepad = 1,
    ECommonInputType__Touch = 2,
    ECommonInputType__Count = 3
};

enum ECommonInputMode : uint8_t
{
    ECommonInputMode__Menu = 0,
    ECommonInputMode__Game = 1,
    ECommonInputMode__All = 2
};

enum ECommonInputEventFlowBehavior : uint8_t
{
    ECommonInputEventFlowBehavior__BlockIfActive = 0,
    ECommonInputEventFlowBehavior__BlockIfHandled = 1,
    ECommonInputEventFlowBehavior__NeverBlock = 2
};

enum ERotatorDirection : uint8_t
{
    ERotatorDirection__Right = 0,
    ERotatorDirection__Left = 1
};

enum ECommonNumericType : uint8_t
{
    ECommonNumericType__Number = 0,
    ECommonNumericType__Percentage = 1,
    ECommonNumericType__Seconds = 2,
    ECommonNumericType__Distance = 3
};

enum ERichTextInlineIconDisplayMode : uint8_t
{
    ERichTextInlineIconDisplayMode__IconOnly = 0,
    ERichTextInlineIconDisplayMode__TextOnly = 1,
    ERichTextInlineIconDisplayMode__IconAndText = 2
};

enum EInputActionState : uint8_t
{
    EInputActionState__Enabled = 0,
    EInputActionState__Disabled = 1,
    EInputActionState__Hidden = 2,
    EInputActionState__HiddenAndDisabled = 3
};

enum ECommonSwitcherTransition : uint8_t
{
    ECommonSwitcherTransition__FadeOnly = 0,
    ECommonSwitcherTransition__Horizontal = 1,
    ECommonSwitcherTransition__Vertical = 2,
    ECommonSwitcherTransition__Zoom = 3
};

enum ETransitionCurve : uint8_t
{
    ETransitionCurve__Linear = 0,
    ETransitionCurve__QuadIn = 1,
    ETransitionCurve__QuadOut = 2,
    ETransitionCurve__QuadInOut = 3,
    ETransitionCurve__CubicIn = 4,
    ETransitionCurve__CubicOut = 5,
    ETransitionCurve__CubicInOut = 6
};

enum ECommonSwitcherTransitionFallbackStrategy : uint8_t
{
    ECommonSwitcherTransitionFallbackStrategy__None = 0,
    ECommonSwitcherTransitionFallbackStrategy__Previous = 1,
    ECommonSwitcherTransitionFallbackStrategy__Next = 2,
    ECommonSwitcherTransitionFallbackStrategy__First = 3,
    ECommonSwitcherTransitionFallbackStrategy__Last = 4,
    ECommonSwitcherT_________L_v_H_Y__I_L_x_t___________________m___BJ_Z_j_z________________ = 5
};

enum ESpriteCollisionMode : uint8_t
{
    ESpriteCollisionMode__None = 0,
    ESpriteCollisionMode__Use2DPhysics = 1,
    ESpriteCollisionMode__Use3DPhysics = 2
};

enum ESpriteShapeType : uint8_t
{
    ESpriteShapeType__Box = 0,
    ESpriteShapeType__Circle = 1,
    ESpriteShapeType__Polygon = 2
};

enum ESpritePolygonMode : uint8_t
{
    ESpritePolygonMode__SourceBoundingBox = 0,
    ESpritePolygonMode__TightBoundingBox = 1,
    ESpritePolygonMode__ShrinkWrapped = 2,
    ESpritePolygonMode__FullyCustom = 3,
    ESpritePolygonMode__Diced = 4
};

enum ESpritePivotMode : uint8_t
{
    ESpritePivotMode__Top_Left = 0,
    ESpritePivotMode__Top_Center = 1,
    ESpritePivotMode__Top_Right = 2,
    ESpritePivotMode__Center_Left = 3,
    ESpritePivotMode__Center_Center = 4,
    ESpritePivotMode__Center_Right = 5,
    ESpritePivotMode__Bottom_Left = 6,
    ESpritePivotMode__Bottom_Center = 7,
    ESpritePivotMode__Bottom_Right = 8,
    ESpritePivotMode__Custom = 9
};

enum EFlipbookCollisionMode : uint8_t
{
    EFlipbookCollisionMode__NoCollision = 0,
    EFlipbookCollisionMode__FirstFrameCollision = 1,
    EFlipbookCollisionMode__EachFrameCollision = 2
};

enum EPaperSpriteAtlasPadding : uint8_t
{
    EPaperSpriteAtlasPadding__DilateBorder = 0,
    EPaperSpriteAtlasPadding__PadWithZero = 1
};

enum ETileMapProjectionMode : uint8_t
{
    ETileMapProjectionMode__Orthogonal = 0,
    ETileMapProjectionMode__IsometricDiamond = 1,
    ETileMapProjectionMode__IsometricStaggered = 2,
    ETileMapProjectionMode__HexagonalStaggered = 3
};

enum ESolarisDebugMessageClientId : uint32_t
{
    ESolarisDebugMessageClientId__None = 0,
    ESolarisDebugMessageClientId__Max = 2147483646
};

enum ESolarisDebugMessageCommand : uint8_t
{
    ESolarisDebugMessageCommand__Connect = 0,
    ESolarisDebugMessageCommand__Disconnect = 1,
    ESolarisDebugMessageCommand__Message = 2,
    ESolarisDebugMessageCommand__PackageMapping = 3
};

enum EVerseDigestVariant : uint8_t
{
    EVerseDigestVariant__PublicAndEpicInternal = 0,
    EVerseDigestVariant__PublicOnly = 1
};

enum EScriptDiagnosticMessageType : uint8_t
{
    EScriptDiagnosticMessageType__Debug = 0,
    EScriptDiagnosticMessageType__Verbose = 1,
    EScriptDiagnosticMessageType__Normal = 2,
    EScriptDiagnosticMessageType__Warning = 3,
    EScriptDiagnosticMessageType__Error = 4
};

enum EMovementType : uint8_t
{
    EMovementType__SweepPhysics = 0,
    EMovementType__TeleportPhysics = 1,
    EMovementType__ResetPhysics = 2
};

enum EVectorVMBaseTypes : uint8_t
{
    EVectorVMBaseTypes__Float = 0,
    EVectorVMBaseTypes__Int = 1,
    EVectorVMBaseTypes__Bool = 2,
    EVectorVMBaseTypes__Num = 3
};

enum EVectorVMOperandLocation : uint8_t
{
    EVectorVMOperandLocation__Register = 0,
    EVectorVMOperandLocation__Constant = 1,
    EVectorVMOperandLocation__Num = 2
};

enum ENiagaraParameterAccessLevel : uint8_t
{
    ENiagaraParameterAccessLevel__Private = 0,
    ENiagaraParameterAccessLevel__Public = 1
};

enum ENiagaraIterationSource : uint8_t
{
    ENiagaraIterationSource__Particles = 0,
    ENiagaraIterationSource__DataInterface = 1,
    ENiagaraIterationSource__DirectSet = 2
};

enum ENiagaraMipMapGenerationType : uint8_t
{
    ENiagaraMipMapGenerationType__Unfiltered = 0,
    ENiagaraMipMapGenerationType__Linear = 1,
    ENiagaraMipMapGenerationType__Blur1 = 2,
    ENiagaraMipMapGenerationType__Blur2 = 3,
    ENiagaraMipMapGenerationType__Blur3 = 4,
    ENiagaraMipMapGenerationType__Blur4 = 5,
    ENiagara_Y_M____i_E__y_______j_L______r_G__e_____p7_g________P = 6
};

enum ENiagaraGpuDispatchType : uint8_t
{
    ENiagaraGpuDispatchType__OneD = 0,
    ENiagaraGpuDispatchType__TwoD = 1,
    ENiagaraGpuDispatchType__ThreeD = 2,
    ENiagaraGpuDispatchType__Custom = 3
};

enum ENiagaraDirectDispatchElementType : uint8_t
{
    ENiagaraDirectDispatchElementType__NumThreads = 0,
    ENiagaraDirectDispatchElementType__NumThreadsNoClipping = 1,
    ENiagaraDirectDispatchElementType__NumGroups = 2
};

enum ENiagaraSimStageExecuteBehavior : uint8_t
{
    ENiagaraSimStageExecuteBehavior__Always = 0,
    ENiagaraSimStageExecuteBehavior__OnSimulationReset = 1,
    ENiagaraSimStageExecuteBehavior__NotOnSimulationReset = 2
};

enum FNiagaraCompileEventSeverity : uint8_t
{
    FNiagaraCompileEventSeverity__Log = 0,
    FNiagaraCompileEventSeverity__Display = 1,
    FNiagaraCompileEventSeverity__Warning = 2,
    FNiagaraCompileEventSeverity__Error = 3
};

enum FNiagaraCompileEventSource : uint8_t
{
    FNiagaraCompileEventSource__Unset = 0,
    FNiagaraCompileEventSource__ScriptDependency = 1
};

enum ENiagaraSimCacheAttributeCaptureMode : uint8_t
{
    ENiagaraSimCacheAttributeCaptureMode__All = 0,
    ENiagaraSimCacheAttributeCaptureMode__RenderingOnly = 1,
    ENiagaraSimCacheAttributeCaptureMode__ExplicitAttributes = 2
};

enum ENiagaraAssetLibraryAssetTypes : uint8_t
{
    ENiagaraAssetLibraryAssetTypes__Emitters = 1,
    ENiagaraAssetLibraryAssetTypes__Systems = 2,
    ENiagaraAssetLibraryAssetTypes__Scripts = 4
};

enum ENiagaraAssetTagDefinitionImportance : uint8_t
{
    ENiagaraAssetTagDefinitionImportance__Primary = 0,
    ENiagaraAssetTagDefinitionImportance__Secondary = 1,
    ENiagaraAssetTagDefinitionImportance__Internal = 2
};

enum ENiagaraBaseTypes : uint8_t
{
    ENiagaraBaseTypes__Half = 0,
    ENiagaraBaseTypes__Float = 1,
    ENiagaraBaseTypes__Int32 = 2,
    ENiagaraBaseTypes__Bool = 3,
    ENiagaraBaseTypes__Max = 4
};

enum ENiagaraGpuBufferFormat : uint8_t
{
    ENiagaraGpuBufferFormat__Float = 0,
    ENiagaraGpuBufferFormat__HalfFloat = 1,
    ENiagaraGpuBufferFormat__UnsignedNormalizedByte = 2,
    ENiagaraGpuBufferFormat__Max = 3
};

enum ENiagaraMipMapGeneration : uint8_t
{
    ENiagaraMipMapGeneration__Disabled = 0,
    ENiagaraMipMapGeneration__PostStage = 1,
    ENiagaraMipMapGeneration__PostSimulate = 2
};

enum ENiagaraDefaultRendererMotionVectorSetting : uint8_t
{
    ENiagaraDefaultRendererMotionVectorSetting__Precise = 0,
    ENiagaraDefaultRendererMotionVectorSetting__Approximate = 1
};

enum ENiagaraSimTarget : uint8_t
{
    ENiagaraSimTarget__CPUSim = 0,
    ENiagaraSimTarget__GPUComputeSim = 1
};

enum ENiagaraAgeUpdateMode : uint8_t
{
    ENiagaraAgeUpdateMode__TickDeltaTime = 0,
    ENiagaraAgeUpdateMode__DesiredAge = 1,
    ENiagaraAgeUpdateMode__DesiredAgeNoSeek = 2
};

enum ENiagaraStatEvaluationType : uint8_t
{
    ENiagaraStatEvaluationType__Average = 0,
    ENiagaraStatEvaluationType__Maximum = 1
};

enum ENiagaraStatDisplayMode : uint8_t
{
    ENiagaraStatDisplayMode__Percent = 0,
    ENiagaraStatDisplayMode__Absolute = 1
};

enum ENiagaraDataSetType : uint8_t
{
    ENiagaraDataSetType__ParticleData = 0,
    ENiagaraDataSetType__Shared = 1,
    ENiagaraDataSetType__Event = 2
};

enum ENiagaraInputNodeUsage : uint8_t
{
    ENiagaraInputNodeUsage__Undefined = 0,
    ENiagaraInputNodeUsage__Parameter = 1,
    ENiagaraInputNodeUsage__Attribute = 2,
    ENiagaraInputNodeUsage__SystemConstant = 3,
    ENiagaraInputNodeUsage__TranslatorConstant = 4,
    ENiagaraInputNodeUsage__RapidIterationParameter = 5
};

enum ENiagaraScriptCompileStatus : uint8_t
{
    ENiagaraScriptCompileStatus__NCS_Unknown = 0,
    ENiagaraScriptCompileStatus__NCS_Dirty = 1,
    ENiagaraScriptCompileStatus__NCS_Error = 2,
    ENiagaraScriptCompileStatus__NCS_UpToDate = 3,
    ENiagaraScriptCompileStatus__NCS_BeingCreated = 4,
    ENiagaraScriptCompileStatus__NCS_UpToDateWithWarnings = 5,
    ENiagaraScriptCompileStatus__NCS_ComputeUpToDateWithWarnings = 6
};

enum ENiagaraScriptUsage : uint8_t
{
    ENiagaraScriptUsage__Function = 0,
    ENiagaraScriptUsage__Module = 1,
    ENiagaraScriptUsage__DynamicInput = 2,
    ENiagaraScriptUsage__ParticleSpawnScript = 3,
    ENiagaraScriptUsage__ParticleSpawnScriptInterpolated = 4,
    ENiagaraScriptUsage__ParticleUpdateScript = 5,
    ENiagaraScriptUsage__ParticleEventScript = 6,
    ENiagaraScriptUsage__ParticleSimulationStageScript = 7,
    ENiagaraScriptUsage__ParticleGPUComputeScript = 8,
    ENiagaraScriptUsage__EmitterSpawnScript = 9,
    ENiagaraScriptUsage__EmitterUpdateScript = 10,
    ENiagaraScriptUsage__SystemSpawnScript = 11,
    ENiagaraScriptUsage__SystemUpdateScript = 12
};

enum ENiagaraCompileUsageStaticSwitch : uint8_t
{
    ENiagaraCompileUsageStaticSwitch__Spawn = 0,
    ENiagaraCompileUsageStaticSwitch__Update = 1,
    ENiagaraCompileUsageStaticSwitch__Event = 2,
    ENiagaraCompileUsageStaticSwitch__SimulationStage = 3,
    ENiagaraCompileUsageStaticSwitch__Default = 4
};

enum ENiagaraScriptContextStaticSwitch : uint8_t
{
    ENiagaraScriptContextStaticSwitch__System = 0,
    ENiagaraScriptContextStaticSwitch__Emitter = 1,
    ENiagaraScriptContextStaticSwitch__Particle = 2
};

enum ENiagaraScriptGroup : uint8_t
{
    ENiagaraScriptGroup__Particle = 0,
    ENiagaraScriptGroup__Emitter = 1,
    ENiagaraScriptGroup__System = 2,
    ENiagaraScriptGroup__Max = 3
};

enum ENiagaraBindingSource : uint8_t
{
    ImplicitFromSource = 0,
    ExplicitParticles = 1,
    ExplicitEmitter = 2,
    ExplicitSystem = 3,
    ExplicitUser = 4,
    MaxBindingSource = 5
};

enum ENiagaraRendererSourceDataMode : uint8_t
{
    ENiagaraRendererSourceDataMode__Particles = 0,
    ENiagaraRendererSourceDataMode__Emitter = 1
};

enum ENiagaraLegacyTrailWidthMode : uint8_t
{
    ENiagaraLegacyTrailWidthMode__FromCentre = 0,
    ENiagaraLegacyTrailWidthMode__FromFirst = 1,
    ENiagaraLegacyTrailWidthMode__FromSecond = 2
};

enum ENiagaraSystemInstanceState : uint8_t
{
    ENiagaraSystemInstanceState__None = 0,
    ENiagaraSystemInstanceState__PendingSpawn = 1,
    ENiagaraSystemInstanceState__PendingSpawnPaused = 2,
    ENiagaraSystemInstanceState__Spawning = 3,
    ENiagaraSystemInstanceState__Running = 4,
    ENiagaraSystemInstanceState__Paused = 5,
    ENiagaraSystemInstanceState__Num = 6
};

enum ENiagaraFunctionDebugState : uint8_t
{
    ENiagaraFunctionDebugState__NoDebug = 0,
    ENiagaraFunctionDebugState__Basic = 1
};

enum ENiagaraGpuComputeTickStage : uint8_t
{
    ENiagaraGpuComputeTickStage__PreInitViews = 0,
    ENiagaraGpuComputeTickStage__PostInitViews = 1,
    ENiagaraGpuComputeTickStage__PostOpaqueRender = 2,
    ENiagaraGpuComputeTickStage__Max = 3,
    ENiagaraGpuComputeTickStage__First = 0,
    ENiagaraGpuComputeTickStage__Last = 2
};

enum ENiagaraConditionalOperator : uint8_t
{
    ENiagaraConditionalOperator__Equals = 0,
    ENiagaraConditionalOperator__NotEqual = 1,
    ENiagaraConditionalOperator__LessThan = 2,
    ENiagaraConditionalOperator__LessThanOrEqual = 3,
    ENiagaraConditionalOperator__GreaterThan = 4,
    ENiagaraConditionalOperator__GreaterThanOrEqual = 5,
    ENiagaraConditionalOperator__Max = 6
};

enum ENCPoolMethod : uint8_t
{
    ENCPoolM___________ = 0,
    ENCPoolMethod__AutoRelease = 1,
    ENCPoolMethod__ManualRelease = 2,
    ENCPoolMethod__ManualRelease_OnComplete = 3,
    ENCPoolMethod__FreeInPool = 4
};

enum ENiagraDataChannel_IslandMode : uint8_t
{
    ENiagraDataChannel_IslandMode__AlignedStatic = 0,
    ENiagraDataChannel_IslandMode__Dynamic = 1
};

enum ENiagaraDataChannelAllocationMode : uint8_t
{
    ENiagaraDataChannelAllocationMode__Static = 0,
    ENiagaraDataChannelAllocationMode__Dynamic = 1
};

enum ENDIDataChannelSpawnScaleMode : uint8_t
{
    ENDIDataChannelSpawnScaleMode__Override = 0,
    ENDIDataChannelSpawnScaleMode__Scale = 1,
    ENDIDataChannelSpawnScaleMode__Max = 2
};

enum ENiagaraSortMode : uint8_t
{
    ENiagaraSortMode__None = 0,
    ENiagaraSortMode__ViewDepth = 1,
    ENiagaraSortMode__ViewDistance = 2,
    ENiagaraSortMode__CustomAscending = 3,
    ENiagaraSortMode__CustomDecending = 4
};

enum ENDISkelMesh_GpuMaxInfluences : uint8_t
{
    ENDISkelMesh_GpuMaxInfluences__AllowMax4 = 0,
    ENDISkelMesh_GpuMaxInfluences__AllowMax8 = 1,
    ENDISkelMesh_GpuMaxInfluences__Unlimited = 2
};

enum ENDISkelMesh_GpuUniformSamplingFormat : uint8_t
{
    ENDISkelMesh_GpuUniformSamplingFormat__Full = 0,
    ENDISkelMesh_GpuUniformSamplingFormat__Limited_24 = 1,
    ENDISkelMesh_GpuUniformSamplingFormat__Limited_23 = 2
};

enum ENDISkelMesh_AdjacencyTriangleIndexFormat : uint8_t
{
    ENDISkelMesh_AdjacencyTriangleIndexFormat__Full = 0,
    ENDISkelMesh_AdjacencyTriangleIndexFormat__Half = 1
};

enum ENiagaraDefaultRendererPixelCoverageMode : uint8_t
{
    ENiagaraDefaultRendererPixelCoverageMode__Enabled = 0,
    ENiagaraDefaultRendererPixelCoverageMode__Disabled = 1
};

enum ENiagaraDefaultSortPrecision : uint8_t
{
    ENiagaraDefaultSortPrecision__Low = 0,
    ENiagaraDefaultSortPrecision__High = 1
};

enum ENiagaraDefaultGpuTranslucentLatency : uint8_t
{
    ENiagaraDefaultGpuTranslucentLatency__Immediate = 0,
    ENiagaraDefaultGpuTranslucentLatency__Latent = 1
};

enum ENiagaraCompileErrorSeverity : uint8_t
{
    ENiagaraCompileErrorSeverity__Ignore = 0,
    ENiagaraCompileErrorSeverity__LogOnly = 1,
    ENiagaraCompileErrorSeverity__Warning = 2,
    ENiagaraCompileErrorSeverity__Error = 3
};

enum ENDICollisionQuery_AsyncGpuTraceProvider : uint8_t
{
    ENDICollisionQuery_AsyncGpuTraceProvider__Default = 0,
    ENDICollisionQuery_AsyncGpuTraceProvider__HWRT = 1,
    ENDICollisionQuery_AsyncGpuTraceProvider__GSDF = 2,
    ENDICollisionQuery_AsyncGpuTraceProvider__None = 3
};

enum ENiagaraStripScriptByteCodeOption : uint8_t
{
    ENiagaraStripScriptByteCodeOption__Default = 0,
    ENiagaraStripScriptByteCodeOption__Strip_Original = 1,
    ENiagaraStripScriptByteCodeOption__Strip_Experimental = 2
};

enum ENiagaraStatelessFeatureMask : uint8_t
{
    ENiagaraStatelessFeatureMask__ExecuteGPU = 1,
    ENiagaraStatelessFeatureMask__ExecuteCPU = 2,
    ENiagaraStatelessFeatureMask__None = 0,
    ENiagaraStatelessFeatureMask__ExecuteAll = 3,
    ENiagaraStatelessFeatureMask__All = 3
};

enum ENiagaraDistributionMode : uint8_t
{
    ENiagaraDistributionMode__Binding = 0,
    ENiagaraDistributionMode__UniformConstant = 1,
    ENiagaraDistributionMode__NonUniformConstant = 2,
    ENiagaraDistributionMode__UniformRange = 3,
    ENiagaraDistributionMode__NonUniformRange = 4,
    ENiagaraDistributionMode__UniformCurve = 5,
    ENiagaraDistributionMode__NonUniformCurve = 6
};

enum ENSM_VelocityType : uint8_t
{
    ENSM_VelocityType__Linear = 0,
    ENSM_VelocityType__FromPoint = 1,
    ENSM_VelocityType__InCone = 2
};

enum ENSM_NoiseMode : uint8_t
{
    ENSM_NoiseMode__VectorField = 0,
    ENSM_NoiseMode__JacobNoise = 1,
    ENSM_NoiseMode__LUTJacob = 2,
    ENSM_NoiseMode__LUTJacobBicubic = 3
};

enum ENSMInitialMeshOrientationMode : uint8_t
{
    ENSMInitialMeshOrientationMode__None = 0,
    ENSMInitialMeshOrientationMode__Random = 1,
    ENSMInitialMeshOrientationMode__OrientToAxis = 2
};

enum ENSM_ShapePrimitive : uint8_t
{
    ENSM_ShapePrimitive__Box = 0,
    ENSM_ShapePrimitive__Cylinder = 1,
    ENSM_ShapePrimitive__Plane = 2,
    ENSM_ShapePrimitive__Ring = 3,
    ENSM_ShapePrimitive__Sphere = 4,
    ENSM_ShapePrimitive__Max = 5
};

enum ENSM_SurfaceExpansionMode : uint8_t
{
    ENSM_SurfaceExpansionMode__Inner = 0,
    ENSM_SurfaceExpansionMode__Centered = 1,
    ENSM_SurfaceExpansionMode__Outside = 2
};

enum ENSMSubUVAnimation_Mode : uint8_t
{
    ENSMSubUVAnimation_Mode__InfiniteLoop = 0,
    ENSMSubUVAnimation_Mode__Linear = 1,
    ENSMSubUVAnimation_Mode__Random = 2
};

enum ENiagaraStatelessSpawnInfoType : uint8_t
{
    ENiagaraStatelessSpawnInfoType__Burst = 0,
    ENiagaraStatelessSpawnInfoType__Rate = 1
};

enum ENiagaraSystemInactiveResponse : uint8_t
{
    ENiagaraSystemInactiveResponse__Complete = 0,
    ENiagaraSystemInactiveResponse__Kill = 1
};

enum ENiagaraEmitterInactiveResponse : uint8_t
{
    ENiagaraEmitterInactiveResponse__Complete = 0,
    ENiagaraEmitterInactiv__U_p_____Jt___ = 1
};

enum ENiagaraLoopBehavior : uint8_t
{
    ENiagaraLoopBehavior__Infinite = 0,
    ENiagaraLoopBehavior__Multiple = 1,
    ENiagaraLoopBehavior__Once = 2
};

enum ENiagaraLoopDurationMode : uint8_t
{
    ENiagaraLoopDurationMode__Fixed = 0,
    ENiagaraLoopDurationMode__Infinite = 1
};

enum ENiagaraTickBehavior : uint8_t
{
    ENiagaraTickBehavior__UsePrereqs = 0,
    ENiagaraTickBehavior__UseComponentTickGroup = 1,
    ENiagaraTickBehavior__ForceTickFirst = 2,
    ENiagaraTickBehavior__ForceTickLast = 3
};

enum ENiagaraInputWidgetType : uint8_t
{
    ENiagaraInputWidgetType__Default = 0,
    ENiagaraInputWidgetType__Slider = 1,
    ENiagaraInputWidgetType__Volume = 2,
    ENiagaraInputWidgetType__NumericDropdown = 3,
    ENiagaraInputWidgetType__EnumStyle = 4,
    ENiagaraInputWidgetType__SegmentedButtons = 5
};

enum ENiagaraBoolDisplayMode : uint8_t
{
    ENiagaraBoolDisplayMode__DisplayAlways = 0,
    ENiagaraBoolDisplayMode__DisplayIfTrue = 1,
    ENiagaraBoolDisplayMode__DisplayIfFalse = 2
};

enum ENDIActorComponentSourceMode : uint8_t
{
    ENDIActorComponentSourceMode__Default = 0,
    ENDIActorComponentSourceMode__AttachParent = 1,
    ENDIActorComponentSourceMode__LocalPlayer = 2
};

enum ENDISceneCapture2DSourceMode : uint8_t
{
    ENDISceneCapture2DSourceMode__UserParameterThenAttachParent = 0,
    ENDISceneCapture2DSourceMode__UserParameterOnly = 1,
    ENDISceneCapture2DSourceMode__AttachParentOnly = 2,
    ENDISceneCapture2DSourceMode__Managed = 3
};

enum ENDISceneCapture2DOffsetMode : uint8_t
{
    ENDISceneCapture2DOffsetMode__Disabled = 0,
    ENDISceneCapture2DOffsetMode__RelativeLocal = 1,
    ENDISceneCapture2DOffsetMode__RelativeWorld = 2,
    ENDISceneCapture2DOffsetMode__AbsoluteWorld = 3
};

enum ENDISocketReaderSourceMode : uint8_t
{
    ENDISocketReaderSourceMode__Default = 0,
    ENDISocketReaderSourceMode__ParameterBindingOnly = 1,
    ENDISocketReaderSourceMode__AttachedParentOnly = 2,
    ENDISocketReaderSourceMode__SourceOnly = 3
};

enum ENDIStaticMesh_SourceMode : uint8_t
{
    ENDIStaticMesh_SourceMode__Default = 0,
    ENDIStaticMesh_SourceMode__Source = 1,
    ENDIStaticMesh_SourceMode__AttachParent = 2,
    ENDIStaticMesh_SourceMode__DefaultMeshOnly = 3,
    ENDIStaticMesh_SourceMode__MeshParameterBinding = 4
};

enum ENDIObjectPropertyReaderSourceMode : uint8_t
{
    ENDIObjectPropertyReaderSourceMode__Binding = 0,
    ENDIObjectPropertyReaderSourceMode__AttachParentActor = 1,
    ENDIObjectPropertyReaderSourfw_M_W_x________________7_j_d__ODJ_G = 2
};

enum ENiagaraSystemSpawnSectionStartBehavior : uint8_t
{
    ENiagaraSystemSpawnSectionStartBehavior__Activate = 0
};

enum ENiagaraSystemSpawnSectionEndBehavior : uint8_t
{
    ENiagaraSystemSpawnSectionEndBehavior__SetSystemInactive = 0,
    ENiagaraSystemSpawnSectionEndBehavior__Deactivate = 1,
    ENiagaraSystemSpawnSectionEndBehavior__None = 2
};

enum ENiagaraCompilationState : uint8_t
{
    ENiagaraCompilationState__CheckDDC = 0,
    ENiagaraCompilationState__Precompile = 1,
    ENiagaraCompilationState__StartCompileJob = 2,
    ENiagaraCompilationState__AwaitResult = 3,
    ENiagaraCompilationState__OptimizeByteCode = 4,
    ENiagaraCompilationState__ProcessResult = 5,
    ENiagaraCompilationState__PutToDDC = 6,
    ENiagaraCompilationState__Finished = 7,
    ENiagaraCompilationState__Aborted = 8
};

enum ENiagaraOcclusionQueryMode : uint8_t
{
    ENiagaraOcclusionQueryMode__Default = 0,
    ENiagaraOcclusionQueryMode__AlwaysEnabled = 1,
    ENiagaraOcclusionQueryMode__AlwaysDisabled = 2
};

enum ENiagartaDataChannelReadResult : uint8_t
{
    ENiagartaDataChannelReadResult__Success = 0,
    ENiagartaDataChannelReadResult__Failure = 1
};

enum ENiagaraDataInterfaceEmitterBindingMode : uint8_t
{
    ENiagaraDataInterfaceEmitterBindingMode__Self = 0,
    ENiagaraDataInterfaceEmitterBindingMode__Other = 1
};

enum ENDIExport_GPUAllocationMode : uint8_t
{
    ENDIExport_GPUAllocationMode__FixedSize = 0,
    ENDIExport_GPUAllocationMode__PerParticle = 1
};

enum ENDILandscape_SourceMode : uint8_t
{
    ENDILandscape_SourceMode__Default = 0,
    ENDILandscape_SourceMode__Source = 1,
    ENDILandscape_SourceMode__AttachParent = 2
};

enum ESetResolutionMethod : uint8_t
{
    ESetResolutionMethod__Independent = 0,
    ESetResolutionMethod__MaxAxis = 1,
    ESetResolutionMethod__CellSize = 2
};

enum ENDISkeletalMesh_SourceMode : uint8_t
{
    ENDISkeletalMesh_SourceMode__Default = 0,
    ENDISkeletalMesh_SourceMode__Source = 1,
    ENDISkeletalMesh_SourceMode__AttachParent = 2,
    ENDISkeletalMesh_SourceMode__DefaultMeshOnly = 3
};

enum ENDISkeletalMesh_SkinningMode : uint16_t
{
    ENDISkeletalMesh_SkinningMode__Invalid = 255,
    ENDISkeletalMesh_SkinningMode__None = 0,
    ENDISkeletalMesh_SkinningMode__SkinOnTheFly = 1,
    ENDISkeletalMesh_SkinningMode__PreSkin = 2
};

enum ENiagaraDebugPlaybackMode : uint8_t
{
    ENiagaraDebugPlaybackMode__Play = 0,
    ENiagaraDebugPlaybackMode__Loop = 1,
    ENiagaraDebugPlaybackMode__Paused = 2,
    ENiagaraDebugPlaybackMode__Step = 3
};

enum ENiagaraDebugHudHAlign : uint8_t
{
    ENiagaraDebugHudHAlign__Left = 0,
    ENiagaraDebugHudHAlign__Center = 1,
    ENiagaraDebugHudHAlign__Right = 2
};

enum ENiagaraDebugHudVAlign : uint8_t
{
    ENiagaraDebugHudVAlign__Top = 0,
    ENiagaraDebugHudVAlign__Center = 1,
    ENiagaraDebugHudVAlign__Bottom = 2
};

enum ENiagaraDebugHudFont : uint8_t
{
    ENiagaraDebugHudFont__Small = 0,
    ENiagaraDebugHudFont__Normal = 1
};

enum ENiagaraDebugHudVerbosity : uint8_t
{
    ENiagaraDebugHudVerbosity__None = 0,
    ENiagaraDebugHudVerbosity__Basic = 1,
    ENiagaraDebugHudVerbosity__Verbose = 2
};

enum ENiagaraDebugHUDOverviewMode : uint8_t
{
    ENiagaraDebugHUDOverviewMode__Overview = 0,
    ENiagaraDebugHUDOverviewMode__Scalability = 1,
    ENiagaraDebugHUDOverviewMode__Performance = 2,
    ENiagaraDebugHUDOverviewMode__PerformanceGraph = 3,
    ENiagaraDebugHUDOverviewMode__GpuComputePerformance = 4
};

enum ENiagaraDebugHUDPerfGraphMode : uint8_t
{
    ENiagaraDebugHUDPerfGraphMode__GameThread = 0,
    ENiagaraDebugHUDPerfGraphMode__RenderThread = 1,
    ENiagaraDebugHUDPerfGraphMode__GPU = 2
};

enum ENiagaraDebugHUDPerfSampleMode : uint8_t
{
    ENiagaraDebugHUDPerfSampleMode__FrameTotal = 0,
    ENiagaraDebugHUDPerfSampleMode__PerInstanceAverage = 1
};

enum ENiagaraDebugHUDPerfUnits : uint8_t
{
    ENiagaraDebugHUDPerfUnits__Microseconds = 0,
    ENiagaraDebugHUDPerfUnits__Milliseconds = 1
};

enum ENiagaraDebugHUDDOverviewSort : uint8_t
{
    ENiagaraDebugHUDDOverviewSort__Name = 0,
    ENiagaraDebugHUDDOverviewSort__NumberRegistered = 1,
    ENiagaraDebugHUDDOverviewSort__NumberActive = 2,
    ENiagaraDebugHUDDOverviewSort__NumberScalability = 3,
    ENiagaraDebugHUDDOverviewSort__MemoryUsage = 4,
    ENiagaraDebugHUDDOverviewSort__RecentlyVisibilty = 5
};

enum ENiagaraCullReaction : uint8_t
{
    ENiagaraCullReaction__Deactivate = 0,
    ENiagaraCullReaction__DeactivateImmediate = 1,
    ENiagaraCullReaction__DeactivateResume = 2,
    ENiagaraCullReaction__DeactivateImmediateResume = 3,
    ENiagaraCullReaction__PauseResume = 4
};

enum ENiagaraScalabilityUpdateFrequency : uint8_t
{
    ENiagaraScalabilityUpdateFrequency__SpawnOnly = 0,
    ENiagaraScalabilityUpdateFrequency__Low = 1,
    ENiagaraScalabilityUpdateFrequency__Medium = 2,
    ENiagaraScalabilityUpdateFrequency__High = 3,
    ENiagaraScalabilityUpdateFrequency__Continuous = 4
};

enum ENiagaraCullProxyMode : uint8_t
{
    ENiagaraCullProxyMode__None = 0,
    ENiagaraCullProxyMode__Instanced_Rendered = 1
};

enum EScriptExecutionMode : uint8_t
{
    EScriptExecutionMode__EveryParticle = 0,
    EScriptExecutionMode__SpawnedParticles = 1,
    EScriptExecutionMode__SingleParticle = 2
};

enum EParticleAllocationMode : uint8_t
{
    EParticleAllocationMode__AutomaticEstimate = 0,
    EParticleAllocationMode__ManualEstimate = 1,
    EParticleAllocationMode__FixedCount = 2
};

enum ENiagaraEmitterCalculateBoundMode : uint8_t
{
    ENiagaraEmitterCalculateBoundMode__Dynamic = 0,
    ENiagaraEmitterCalculateBoundMode__Fixed = 1,
    ENiagaraEmitterCalculateBoundMode__Programmable = 2
};

enum ENiagaraEmitterMode : uint8_t
{
    ENiagaraEmitterMode__Standard = 0,
    ENiagaraEmitterMode__Stateless = 1
};

enum ENiagaraMeshFacingMode : uint8_t
{
    ENiagaraMeshFacingMode__Default = 0,
    ENiagaraMeshFacingMode__Velocity = 1,
    ENiagaraMeshFacingMode__CameraPosition = 2,
    ENiagaraMeshFacingMode__CameraPlane = 3
};

enum ENiagaraMeshPivotOffsetSpace : uint8_t
{
    ENiagaraMeshPivotOffsetSpace__Mesh = 0,
    ENiagaraMeshPivotOffsetSpace__Simulation = 1,
    ENiagaraMeshPivotOffsetSpace__World = 2,
    ENiagaraMeshPivotOffsetSpace__Local = 3
};

enum ENiagaraMeshLockedAxisSpace : uint8_t
{
    ENiagaraMeshLockedAxisSpace__Simulation = 0,
    ENiagaraMeshLockedAxisSpace__World = 1,
    ENiagaraMeshLockedAxisSpace__Local = 2
};

enum ENiagaraMeshLODMode : uint8_t
{
    ENiagaraMeshLODMode__LODLevel = 0,
    ENiagaraMeshLODMode__LODBias = 1,
    ENiagaraMeshLODMode__ByComponentBounds = 2,
    ENiagaraMeshLODMode__PerParticle = 3
};

enum ENiagaraPlatformSelectionState : uint8_t
{
    ENiagaraPlatformSelectionState__Default = 0,
    ENiagaraPlatformSelectionState__Enabled = 1,
    ENiagaraPlatformSelectionState__Disabled = 2
};

enum ENiagaraPlatformSetState : uint8_t
{
    ENiagaraPlatformSetState__Disabled = 0,
    ENiagaraPlatformSetState__Enabled = 1,
    ENiagaraPlatformSetState__Active = 2,
    ENiagaraPlatformSetState__Unknown = 3
};

enum ENiagaraCVarConditionResponse : uint8_t
{
    ENiagaraCVarConditionResponse__None = 0,
    ENiagaraCVarConditionResponse__Enable = 1,
    EN_______Nn________G__J________Mq____x = 2
};

enum ENiagaraDeviceProfileRedirectMode : uint8_t
{
    ENiagaraDeviceProfileRedirectMode__CVar = 0,
    ENiagaraDeviceProfileRedirectMode__DeviceProfile = 1
};

enum ENiagaraPreviewGridResetMode : uint8_t
{
    ENiagaraPreviewGridResetMode__Never = 0,
    ENiagaraPreviewGridResetMode__Individual = 1,
    ENiagaraPreviewGridResetMode__All = 2
};

enum ENiagaraRendererSortPrecision : uint8_t
{
    ENiagaraRendererSortPrecision__Default = 0,
    ENiagaraRendererSortPrecision__Low = 1,
    ENiagaraRendererSortPrecision__High = 2
};

enum ENiagaraRendererGpuTranslucentLatency : uint8_t
{
    ENiagaraRendererGpuTranslucentLatency__ProjectDefault = 0,
    ENiagaraRendererGpuTranslucentLatency__Immediate = 1,
    ENiagaraRendererGpuTranslucentLatency__Latent = 2
};

enum ENiagaraRibbonFacingMode : uint8_t
{
    ENiagaraRibbonFacingMode__Screen = 0,
    ENiagaraRibbonFacingMode__Custom = 1,
    ENiagaraRibbonFacingMode__CustomSideVector = 2
};

enum ENiagaraRibbonAgeOffsetMode : uint8_t
{
    ENiagaraRibbonAgeOffsetMode__Scale = 0,
    ENiagaraRibbonAgeOffsetMode__Clip = 1
};

enum ENiagaraRibbonDrawDirection : uint8_t
{
    ENiagaraRibbonDrawDirection__FrontToBack = 0,
    ENiagaraRibbonDrawDirection__BackToFront = 1
};

enum ENiagaraRibbonShapeMode : uint8_t
{
    ENiagaraRibbonShapeMode__Plane = 0,
    ENiagaraRibbonShapeMode__MultiPlane = 1,
    ENiagaraRibbonShapeMode__Tube = 2,
    ENiagaraRibbonShapeMode__Custom = 3
};

enum ENiagaraRibbonTessellationMode : uint8_t
{
    ENiagaraRibbonTessellationMode__Automatic = 0,
    ENiagaraRibbonTessellationMode__Custom = 1,
    ENiagaraRibbonTessellationMode__Disabled = 2
};

enum ENiagaraRibbonUVEdgeMode : uint8_t
{
    ENiagaraRibbonUVEdgeMode__SmoothTransition = 0,
    ENiagaraRibbonUVEdgeMode__Locked = 1
};

enum ENiagaraRibbonUVDistributionMode : uint8_t
{
    ENiagaraRibbonUVDistributionMode__ScaledUniformly = 0,
    ENiagaraRibbonUVDistributionMode__ScaledUsingRibbonSegmentLength = 1,
    ENiagaraRibbonUVDistributionMode__TiledOverRibbonLength = 2,
    ENiagaraRibbonUVDistributionMode__TiledFromStartOverRibbonLength = 3
};

enum EUnusedAttributeBehaviour : uint8_t
{
    EUnusedAttributeBehaviour__Copy = 0,
    EUnusedAttributeBehaviour__Zero = 1,
    EUnusedAttributeBehaviour__None = 2,
    EUnusedAttributeBehaviour__MarkInvalid = 3,
    EUnusedAttributeBehaviour__PassThrough = 4
};

enum ENiagaraModuleDependencyType : uint8_t
{
    ENiagaraModuleDependencyType__PreDependency = 0,
    ENiagaraModuleDependencyType__PostDependency = 1
};

enum ENiaga__p5I_q_I________________D___K__ : uint8_t
{
    ENiagaraModuleDependencyScriptConstraint__SameScript = 0,
    ENiagaraModuleDependencyScriptConstraint__AllScripts = 1
};

enum ENiagaraScriptLibraryVisibility : uint8_t
{
    ENiagaraScriptLibraryVisibility__Invalid = 0,
    ENiagaraScriptLibraryVisibility__Unexposed = 1,
    ENiagaraScriptLibraryVisibility__Library = 2,
    ENiagaraScriptLibraryVisibility__Hidden = 3
};

enum ENiagaraScriptTemplateSpecification : uint8_t
{
    ENiagaraScriptTemplateSpecification__None = 0,
    ENiagaraScriptTemplateSpecification__Template = 1,
    ENiagaraScriptTemplateSpecification__Behavior = 2
};

enum ENiagaraEmitterDefaultSummaryState : uint8_t
{
    ENiagaraEmitterDefaultSummaryState__Default = 0,
    ENiagaraEmitterDefaultSummaryState__Summary = 1
};

enum ENiagaraModuleDependencyUsage : uint8_t
{
    ENiagaraModuleDependencyUsage__None = 0,
    ENiagaraModuleDependencyUsage__Spawn = 1,
    ENiagaraModuleDependencyUsage__Update = 2,
    ENiagaraModuleDependencyUsage__Event = 3,
    ENiagaraModuleDependencyUsage__SimulationStage = 4
};

enum ENiagaraInlineDynamicInputFormatTokenUsage : uint8_t
{
    ENiagaraInlineDynamicInputFormatTokenUsage__Input = 0,
    ENiagaraInlineDynamicInputFormatTokenUsage__Decorator = 1,
    ENiagaraInlineDynamicInputFormatTokenUsage__LineBreak = 2
};

enum ENiagaraSpriteAlignment : uint8_t
{
    ENiagaraSpriteAlignment__Unaligned = 0,
    ENiagaraSpriteAlignment__VelocityAligned = 1,
    ENiagaraSpriteAlignment__CustomAlignment = 2,
    ENiagaraSpriteAlignment__Automatic = 3
};

enum ENiagaraSpriteFacingMode : uint8_t
{
    ENiagaraSpriteFacingMode__FaceCamera = 0,
    ENiagaraSpriteFacingMode__FaceCameraPlane = 1,
    ENiagaraSpriteFacingMode__CustomFacingVector = 2,
    ENiagaraSpriteFacingMode__FaceCameraPosition = 3,
    ENiagaraSpriteFacingMode__FaceCameraDistanceBlend = 4,
    ENiagaraSpriteFacingMode__Automatic = 5
};

enum ENiagaraRendererPixelCoverageMode : uint8_t
{
    ENiagaraRendererPixelCoverageMode__Automatic = 0,
    ENiagaraRendererPixelCoverageMode__Disabled = 1,
    ENiagaraRendererPixelCoverageMode__Enabled = 2,
    ENiagaraRendererPixelCoverageMode__Enabled_RGBA = 3,
    ENiagaraRendererPixelCoverageMode__Enabled_RGB = 4,
    ENiagaraRendererPixelCoverageMode__Enabled_A = 5
};

enum ENiagaraStructConversionType : uint8_t
{
    ENiagaraStructConversionType__CopyOnly = 0,
    ENiagaraStructConversionType__DoubleToFloat = 1,
    ENiagaraStructConversionType__Vector2 = 2,
    ENiagaraStructConversionType__Vector3 = 3,
    ENiagaraStructConversionType__Vector4 = 4,
    ENiagaraStructConversionType__Quat = 5
};

enum ENiagaraNumericOutputTypeSelectionMode : uint8_t
{
    ENiagaraNumericOutputTypeSelectionMode__None = 0,
    ENiagaraNumericOutputTypeSelectionMode__Largest = 1,
    ENiagaraNumericOutputTypeSelectionMode__Smallest = 2,
    ENiagaraNumericOutputTypeSelectionMode__Scalar = 3,
    ENiagaraNumericOutputTypeSelectionMode__Custom = 4
};

enum ENiagaraExecutionStateSource : uint8_t
{
    ENiagaraExecutionStateSource__Scalability = 0,
    ENiagaraExecutionStateSource__Internal = 1,
    ENiagaraExecutionStateSource__Owner = 2,
    ENiagaraExecutionStateSource__InternalCompletion = 3
};

enum ENiagaraExecutionState : uint8_t
{
    ENiagaraExecutionState__Active = 0,
    ENiagaraExecutionState__Inactive = 1,
    ENiagaraExecutionState__y_a____bpV__b = 2,
    ENiagaraExecutionState__Complete = 3,
    ENiagaraExecutionState__Disabled = 4,
    ENiagaraExecutionState__Num = 5
};

enum ENiagaraExecutionStateManagement : uint8_t
{
    ENiagaraExecutionStateManagement__Awaken = 0,
    ENiagaraExecutionStateManagement__SleepAndLetParticlesFinish = 1,
    ENiagaraExecutionStateManagement__SleepAndClearParticles = 2,
    ENiagaraExecutionStateManagement__KillImmediately = 3,
    ENiagaraExecutionStateManagement__KillAfterParticlesFinish = 4,
    ENiagaraExecutionStateManagement__Num = 5
};

enum ENiagaraCoordinateSpace : uint8_t
{
    ENiagaraCoordinateSpace__Simulation = 0,
    ENiagaraCoordinateSpace__World = 1,
    ENiagaraCoordinateSpace__Local = 2
};

enum ENiagaraPythonUpdateScriptReference : uint8_t
{
    ENiagaraPythonUpdateScriptReference__None = 0,
    ENiagaraPythonUpdateScriptReference__ScriptAsset = 1,
    ENiagaraPythonUpdateScriptReference__DirectTextEntry = 2
};

enum ENiagaraOrientationAxis : uint8_t
{
    ENiagaraOrientationAxis__XAxis = 0,
    ENiagaraOrientationAxis__YAxis = 1,
    ENiagaraOrientationAxis__ZAxis = 2
};

enum ENiagaraValidationSeverity : uint8_t
{
    ENiagaraValidationSeverity__Info = 0,
    ENiagaraValidationSeverity__Warning = 1,
    ENiagaraValidationSeverity__Error = 2
};

enum ENiagaraVariantMode : uint8_t
{
    ENiagaraVariantMode__None = 0,
    ENiagaraVariantMode__Object = 1,
    ENiagaraVariantMode__DataInterface = 2,
    ENiagaraVariantMode__Bytes = 3
};

enum EVolumeCacheType : uint8_t
{
    EVolumeCacheType__OpenVDB = 0
};

enum ESetParamResult : uint8_t
{
    ESetParamResult__Succeeded = 0,
    ESetParamResult__Failed = 1
};

enum EMetasoundFrontendVertexAccessType : uint8_t
{
    EMetasoundFrontendVertexAccessType__Reference = 0,
    EMetasoundFrontendVertexAccessType__Value = 1,
    EMetasoundFrontendVertexAccessType__Unset = 2
};

enum EMetasoundFrontendClassType : uint8_t
{
    EMetasoundFrontendClassType__External = 0,
    EMetasoundFrontendClassType__Graph = 1,
    EMetasoundFrontendClassType__Input = 2,
    EMetasoundFrontendClassType__Output = 3,
    EMetasoundFrontendClassType__Literal = 4,
    EMetasoundFrontendClassType__Variable = 5,
    EMetasoundFrontendClassType__VariableDeferredAccessor = 6,
    EMetasoundFrontendClassType__VariableAccessor = 7,
    EMetasoundFrontendClassType__VariableMutator = 8,
    EMetasoundFrontendClassType__Template = 9,
    EMetasoundFrontendClassType__Invalid = 10
};

enum EMetaSoundFrontendGraphCommentMoveMode : uint8_t
{
    EMetaSoundFrontendGraphCommentMoveMode__GroupMovement = 0,
    EMetaSoundFrontendGraphCommentMoveMode__NoGroupMovement = 1
};

enum EMetasoundFrontendNodeStyleDisplayVisibility : uint8_t
{
    EMetasoundFrontendNodeStyleDisplayVisibility__Visible = 0,
    EMetasoundFrontendNodeStyleDisplayVisibility__Hidden = 1
};

enum EMetasoundFrontendLiteralType : uint8_t
{
    EMetasoundFrontendLiteralType__None = 0,
    EMetasoundFrontendLiteralType__Boolean = 1,
    EMetasoundFrontendLiteralType__Integer = 2,
    EMetasoundFrontendLiteralType__Float = 3,
    EMetasoundFrontendLiteralType__String = 4,
    EMetasoundFrontendLiteralType__UObject = 5,
    EMetasoundFrontendLiteralType__NoneArray = 6,
    EMetasoundFrontendLiteralType__BooleanArray = 7,
    EMetasoundFrontendLiteralType__IntegerArray = 8,
    EMetasoundFrontendLiteralType__FloatArray = 9,
    EMetasoundFrontendLiteralType__StringArray = 10,
    EMetasoundFrontendLiteralType__UObjectArray = 11,
    EMetasoundFrontendLiteralType__Invalid = 12
};

enum EWaveTableBitDepth : uint8_t
{
    EWaveTableBitDepth__PCM = 0,
    EWaveTableBitDepth__IEEE_Float = 1,
    EWaveTableBitDepth__COUNT = 2
};

enum EWaveTableResolution : uint8_t
{
    EWaveTableResolution__None = 0,
    EWaveTableResolution__Res = 3,
    EWaveTableResolution__Res = 4,
    EWaveTableResolution__Res = 5,
    EWaveTableResolution__Res = 6,
    EWaveTableResolution__Res = 7,
    EWaveTableResolution__Res = 8,
    EWaveTableResolution__Res = 9,
    EWaveTableResolution__Res = 10,
    EWaveTableResolution__Res = 11,
    EWaveTableResolution__Res = 12,
    EWaveTableResolution__Res_Max = 12,
    EWaveTableResolution__Maximum = 13
};

enum EWaveTableSamplingMode : uint8_t
{
    EWaveTableSamplingMode__FixedSampleRate = 0,
    EWaveTableSamplingMode__FixedResolution = 1,
    EWaveTableSamplingMode__COUNT = 2
};

enum EWaveTableCurve : uint8_t
{
    EWaveTableCurve__Linear = 0,
    EWaveTableCurve__Linear_Inv = 1,
    EWaveTableCurve__Exp = 2,
    EWaveTableCurve__Exp_Inverse = 3,
    EWaveTableCurve__Log = 4,
    EWaveTableCurve__Sin = 5,
    EWaveTableCurve__Sin_Full = 6,
    EWaveTableCurve__SCurve = 7,
    EWaveTableCurve__Shared = 8,
    EWaveTableCurve__Custom = 9,
    EWaveTableCurve__File = 10,
    EWaveTableCurve__Count = 11
};

enum EMetaSoundMessageLevel : uint8_t
{
    EMetaSoundMessageLevel__Error = 0,
    EMetaSoundMessageLevel__Warning = 1,
    EMetaSoundMessageLevel__Info = 2
};

enum EMetaSou______k___O___p____ : uint8_t
{
    EMetaSoundOutputAudioFormat__Mono = 0,
    EMetaSoundOutputAudioFormat__Stereo = 1,
    EMetaSoundOutputAudioFormat__Quad = 2,
    EMetaSoundOutputAudioFormat__FiveDotOne = 3,
    EMetaSoundOutputAudioFormat__SevenDotOne = 4,
    EMetaSoundOutputAudioFormat__COUNT = 5
};

enum EMetaSoundBuilderResult : uint8_t
{
    EMetaSoundBuilderResult__Succeeded = 0,
    EMetaSoundBuilderResult__Failed = 1
};

enum ETemplateSectionPropertyScaleType : uint8_t
{
    ETemplateSectionPropertyScaleType__FloatProperty = 0,
    ETemplateSectionPropertyScaleType__TransformPropertyLocationOnly = 1,
    ETemplateSectionPropertyScaleType__TransformPropertyRotationOnly = 2
};

enum EBuiltInDoubleCameraVariable : uint8_t
{
    EBuiltInDoubleCameraVariable__None = 0,
    EBuiltInDoubleCameraVariable__Yaw = 1,
    EBuiltInDoubleCameraVariable__Pitch = 2,
    EBuiltInDoubleCameraVariable__Roll = 3,
    EBuiltInDoubleCameraVariable__Zoom = 4
};

enum EBuiltInVector2dCameraVariable : uint8_t
{
    EBuiltInVector2dCameraVariable__None = 0,
    EBuiltInVector2dCameraVariable__YawPitch = 1
};

enum EBuiltInRotator3dCameraVariable : uint8_t
{
    EBuiltInRotator3dCameraVariable__None = 0,
    EBuiltInRotator3dCameraVariable__ControlRotation = 1
};

enum ECameraBuildStatus : uint8_t
{
    ECameraBuildStatus__Clean = 0,
    ECameraBuildStatus__CleanWithWarnings = 1,
    ECameraBuildStatus__WithErrors = 2,
    ECameraBuildStatus__Dirty = 3
};

enum ECameraNodeOriginPosition : uint8_t
{
    ECameraNodeOriginPosition__CameraPose = 0,
    ECameraNodeOriginPosition__ActiveContext = 1,
    ECameraNodeOriginPosition__OwningContext = 2,
    ECameraNodeOriginPosition__Pivot = 3,
    ECameraNodeOriginPosition__Pawn = 4
};

enum ECameraNodeSpace : uint8_t
{
    ECameraNodeSpace__CameraPose = 0,
    ECameraNodeSpace__ActiveContext = 1,
    ECameraNodeSpace__OwningContext = 2,
    ECameraNodeSpace__Pivot = 3,
    ECameraNodeSpace__Pawn = 4,
    ECameraNodeSpace__World = 5
};

enum ECameraVariableType : uint8_t
{
    ECameraVariableType__Boolean = 0,
    ECameraVariableType__I____v_Gc = 1,
    ECameraVariableType__Float = 2,
    ECameraVariableType__Double = 3,
    ECameraVariableType__Vector2f = 4,
    ECameraVariableType__Vector2d = 5,
    ECameraVariableType__Vector3f = 6,
    ECameraVariableType__Vector3d = 7,
    ECameraVariableType__Vector4f = 8,
    ECameraVariableType__Vector4d = 9,
    ECameraVariableType__Rotator3f = 10,
    ECameraVariableType__Rotator3d = 11,
    ECameraVariableType__Transform3f = 12,
    ECameraVariableType__Transform3d = 13
};

enum ECameraBlendStackType : uint8_t
{
    ECameraBlendStackType__IsolatedTransient = 0,
    ECameraBlendStackType__AdditivePersistent = 1
};

enum ECameraRigInitialOrientation : uint8_t
{
    ECameraRigInitialOrientation__None = 0,
    ECameraRigInitialOrientation__ContextYawPitch = 1,
    ECameraRigInitialOrientation__PreviousYawPitch = 2,
    ECameraRigInitialOrientation__PreviousAbsoluteTarget = 3,
    ECameraRigInitialOrientation__PreviousRelativeTarget = 4
};

enum ECameraRigLayer : uint8_t
{
    ECameraRigLayer__Base = 0,
    ECameraRigLayer__Main = 1,
    ECameraRigLayer__Global = 2,
    ECameraRigLayer__Visual = 3
};

enum ESmoothCameraBlendType : uint8_t
{
    ESmoothCameraBlendType__SmoothStep = 0,
    ESmoothCameraBlendType__SmootherStep = 1
};

enum ECollisionSafePosition : uint8_t
{
    ECollisionSafePosition__ActiveContext = 0,
    ECollisionSafePosition__OwningContext = 1,
    ECollisionSafePosition__Pivot = 2,
    ECollisionSafePosition__Pawn = 3
};

enum ECollisionSafePositionOffsetSpace : uint8_t
{
    ECollisionSafePositionOffsetSpace__ActiveContext = 0,
    ECollisionSafePositionOffsetSpace__OwningContext = 1,
    ECollisionSafePositionOffsetSpace__Pivot = 2,
    ECollisionSafePositionOffsetSpace__CameraPose = 3,
    ECollisionSafePositionOffsetSpace__Pawn = 4
};

enum ECameraAutoRotateDirection : uint8_t
{
    ECameraAutoRotateDirection__Facing = 0,
    ECameraAutoRotateDirection__Movement = 1
};

enum EGameplayEffectGrantedAbilityRemovePolicy : uint8_t
{
    EGameplayEffectGrantedAbilityRemovePolicy__CancelAbilityImmediately = 0,
    EGameplayEffectGrantedAbilityRemovePolicy__RemoveAbilityOnEnd = 1,
    EGameplayEffectGrantedAbilityRemovePolicy__DoNothing = 2
};

enum EGameplayCueEvent : uint8_t
{
    EGameplayCueEvent__OnActive = 0,
    EGameplayCueEvent__WhileActive = 1,
    EGameplayCueEvent__Executed = 2,
    EGameplayCueEvent__Removed = 3
};

enum EGameplayAbilityActivationMode : uint8_t
{
    EGameplayAbilityActivationMode__Authority = 0,
    EGameplayAbilityActivationMode__NonAuthority = 1,
    EGameplayAbilityActivationMode__Predicting = 2,
    EGameplayAbilityActivationMode__Confirmed = 3,
    EGameplayAbilityActivationMode__Rejected = 4
};

enum EAbilityGenericReplicatedEvent : uint8_t
{
    EAbilityGenericReplicatedEvent__GenericConfirm = 0,
    EAbilityGenericReplicatedEvent__GenericCancel = 1,
    EAbilityGenericReplicatedEvent__InputPressed = 2,
    EAbilityGenericReplicatedEvent__InputReleased = 3,
    EAbilityGenericReplicatedEvent__GenericSignalFromClient = 4,
    EAbilityGenericReplicatedEvent__GenericSignalFromServer = 5,
    EAbilityGenericReplicatedEvent__GameCustom1 = 6,
    EAbilityGenericReplicatedEvent__GameCustom2 = 7,
    EAbilityGenericReplicatedEvent__GameCustom3 = 8,
    EAbilityGenericReplicatedEvent__GameCustom4 = 9,
    EAbilityGenericReplicatedEvent__GameCustom5 = 10,
    EAbilityGenericReplicatedEvent__GameCustom6 = 11
};

enum EGameplayCuePayloadType : uint8_t
{
    EGameplayCuePayloadType__CueParameters = 0,
    EGameplayCuePayloadType__FromSpec = 1
};

enum EGameplayAbilityInputBinds : uint8_t
{
    EGameplayAbilityInputBinds__Ability1 = 0,
    EGameplayAbilityInputBinds__Ability2 = 1,
    EGameplayAbilityInputBinds__Ability3 = 2,
    EGameplayAbilityInputBinds__Ability4 = 3,
    EGameplayAbilityInputBinds__Ability5 = 4,
    EGameplayAbilityInputBinds__Ability6 = 5,
    EGameplayAbilityInputBinds__Ability7 = 6,
    EGameplayAbilityInputBinds__Ability8 = 7,
    EGameplayAbilityInputBinds__Ability9 = 8
};

enum ETargetDataFilterSelf : uint8_t
{
    ETargetDataFilterSelf__TDFS_Any = 0,
    ETargetDataFilterSelf__TDFS_NoSelf = 1,
    ETargetDataFilterSelf__TDFS_NoOthers = 2
};

enum EAbilityTaskWaitState : uint8_t
{
    EAbilityTaskWaitState__WaitingOnGame = 1,
    EAbilityTaskWaitState__WaitingOnUser = 2,
    EAbilityTaskWaitState__WaitingOnAvatar = 4
};

enum ERootMotionMoveToActorTargetOffsetType : uint8_t
{
    ERootMotionMoveToActorTargetOffsetType__AlignFromTargetToSource = 0,
    ERootMotionMoveToActorTargetOffsetType__AlignToTargetForward = 1,
    ERootMotionMoveToActorTargetOffsetType__AlignToWorldSpace = 2
};

enum EAbilityTaskNetSyncType : uint8_t
{
    EAbilityTaskNetSyncType__BothWait = 0,
    EAbilityTaskNetSyncType__OnlyServerWait = 1,
    EAbilityTaskNetSyncType__OnlyClientWait = 2
};

enum EWaitAttributeChangeComparison : uint8_t
{
    EWaitAttributeChangeComparison__None = 0,
    EWaitAttributeChangeComparison__GreaterThan = 1,
    EWaitAttributeChangeComparison__LessThan = 2,
    EWaitAttributeChangeComparison__GreaterThanOrEqualTo = 3,
    EWaitAttributeChangeComparison__LessThanOrEqualTo = 4,
    EWaitAttributeChangeComparison__NotEqualTo = 5,
    EWaitAttributeChangeComparison__ExactlyEqualTo = 6
};

enum EWaitGameplayTagQueryTriggerCondition : uint8_t
{
    EWaitGameplayTagQueryTriggerCondition__WhenTrue = 0,
    EWaitGameplayTagQueryTriggerCondition__WhenFalse = 1
};

enum EGameplayEffectReplicationMode : uint8_t
{
    EGameplayEffectReplicationMode__Minimal = 0,
    EGameplayEffectReplicationMode__Mixed = 1,
    EGameplayEffectReplicationMode__Full = 2
};

enum ERepAnimPositionMethod : uint8_t
{
    ERepAnimPositionMethod__Position = 0,
    ERepAnimPositionMethod__CurrentSectionId = 1
};

enum EGameplayTargetingConfirmation : uint8_t
{
    EGameplayTargetingConfirmation__Instant = 0,
    EG____4_Q___________fy_________5_Q______e__G_ = 1,
    EGameplayTargetingConfirmation__Custom = 2,
    EGameplayTargetingConfirmation__CustomMulti = 3
};

enum EGameplayAbilityTargetingLocationType : uint8_t
{
    EGameplayAbilityTargetingLocationType__LiteralTransform = 0,
    EGameplayAbilityTargetingLocationType__ActorTransform = 1,
    EGameplayAbilityTargetingLocationType__SocketTransform = 2
};

enum EGameplayAbilityInstancingPolicy : uint8_t
{
    EGameplayAbilityInstancingPolicy__NonInstanced = 0,
    EGameplayAbilityInstancingPolicy__InstancedPerActor = 1,
    EGameplayAbilityInstancingPolicy__InstancedPerExecution = 2
};

enum EGameplayAbilityNetExecutionPolicy : uint8_t
{
    EGameplayAbilityNetExecutionPolicy__LocalPredicted = 0,
    EGameplayAbilityNetExecutionPolicy__LocalOnly = 1,
    EGameplayAbilityNetExecutionPolicy__ServerInitiated = 2,
    EGameplayAbilityNetExecutionPolicy__ServerOnly = 3
};

enum EGameplayAbilityNetSecurityPolicy : uint8_t
{
    EGameplayAbilityNetSecurityPolicy__ClientOrServer = 0,
    EGameplayAbilityNetSecurityPolicy__ServerOnlyExecution = 1,
    EGameplayAbilityNetSecurityPolicy__ServerOnlyTermination = 2,
    EGameplayAbilityNetSecurityPolicy__ServerOnly = 3
};

enum EGameplayAbilityReplicationPolicy : uint8_t
{
    EGameplayAbilityReplicationPolicy__ReplicateNo = 0,
    EGameplayAbilityReplicationPolicy__ReplicateYes = 1
};

enum EGameplayAbilityTriggerSource : uint8_t
{
    EGameplayAbilityTriggerSource__GameplayEvent = 0,
    EGameplayAbilityTriggerSource__OwnedTagAdded = 1,
    EGameplayAbilityTriggerSource__OwnedTagPresent = 2
};

enum EGameplayCueNotify_EffectPlaySpace : uint8_t
{
    EGameplayCueNotify_EffectPlaySpace__WorldSpace = 0,
    EGameplayCueNotify_EffectPlaySpace__CameraSpace = 1
};

enum EGameplayCueNotify_LocallyControlledSource : uint8_t
{
    EGameplayCueNotify_LocallyControlledSource__InstigatorActor = 0,
    EGameplayCueNotify_LocallyControlledSource__TargetActor = 1
};

enum EGameplayCueNotify_LocallyControlledPolicy : uint8_t
{
    EGameplayCueNotify_LocallyControlledPolicy__Always = 0,
    EGameplayCueNotify_LocallyControlledPolicy__LocalOnly = 1,
    EGameplayCueNotify_LocallyControlledPolicy__NotLocal = 2
};

enum EGameplayCueNotify_AttachPolicy : uint8_t
{
    EGameplayCueNotify_AttachPolicy__DoNotAttach = 0,
    EGameplayCueNotify_AttachPolicy__AttachToTarget = 1
};

enum EGameplayEffectMagnitudeCalculation : uint8_t
{
    EGameplayEffectMagnitudeCalculation__ScalableFloat = 0,
    EGameplayEffectMagnitudeCalculation__AttributeBased = 1
};

enum EAttributeBasedFloatCalculationType : uint8_t
{
    EAttributeBasedFloatCalculationType__AttributeMagnitude = 0,
    EAttributeBasedFloatCalculationType__AttributeBaseVa___ = 1,
    EAttributeBasedFloatCalculationType__AttributeBonusMagnitude = 2,
    EAttributeBasedFloatCalculationType__AttributeMagnitudeEvaluatedUpToChannel = 3
};

enum EGameplayEffectVersion : uint8_t
{
    EGameplayEffectVersion__Monolithic = 0,
    EGameplayEffectVersion__Modular53 = 1,
    EGameplayEffectVersion__AbilitiesComponent53 = 2,
    EGameplayEffectVersion__Current = 2
};

enum EGameplayEffectScopedModifierAggregatorType : uint8_t
{
    EGameplayEffectScopedModifierAggregatorType__CapturedAttributeBacked = 0,
    EGameplayEffectScopedModifierAggregatorType__Transient = 1
};

enum EGameplayEffectDurationType : uint8_t
{
    EGameplayEffectDurationType__Instant = 0,
    EGameplayEffectDurationType__Infinite = 1,
    EGameplayEffectDurationType__HasDuration = 2
};

enum EGameplayEffectStackingDurationPolicy : uint8_t
{
    EGameplayEffectStackingDurationPolicy__RefreshOnSuccessfulApplication = 0,
    EGameplayEffectStackingDurationPolicy__NeverRefresh = 1
};

enum EGameplayEffectStackingPeriodPolicy : uint8_t
{
    EGameplayEffectStackingPeriodPolicy__ResetOnSuccessfulApplication = 0,
    EGameplayEffectStackingPeriodPolicy__NeverReset = 1
};

enum EGameplayEffectStackingExpirationPolicy : uint8_t
{
    EGameplayEffectStackingExpirationPolicy__ClearEntireStack = 0,
    EGameplayEffectStackingExpirationPolicy__RemoveSingleStackAndRefreshDuration = 1,
    EGameplayEffectStackingExpirationPolicy__RefreshDuration = 2
};

enum EGameplayEffectPeriodInhibitionRemovedPolicy : uint8_t
{
    EGameplayEffectPeriodInhibitionRemovedPolicy__NeverReset = 0,
    EGameplayEffectPeriodInhibitionRemovedPolicy__ResetPeriod = 1,
    EGameplayEffectPeriodInhibitionRemovedPolicy__ExecuteAndResetPeriod = 2
};

enum EGameplayModEvaluationChannel : uint8_t
{
    EGameplayModEvaluationChannel__Channel0 = 0,
    EGameplayModEvaluationChannel__Channel1 = 1,
    EGameplayModEvaluationChannel__Channel2 = 2,
    EGameplayModEvaluationChannel__Channel3 = 3,
    EGameplayModEvaluationChannel__Channel4 = 4,
    EGameplayModEvaluationChannel__Channel5 = 5,
    EGameplayModEvaluationChannel__Channel6 = 6,
    EGameplayModEvaluationChannel__Channel7 = 7,
    EGameplayModEvaluationChannel__Channel8 = 8,
    EGameplayModEvaluationChannel__Channel9 = 9
};

enum EGameplayModOp : uint8_t
{
    EGameplayModOp__AddBase = 0,
    EGameplayModOp__MultiplyAdditive = 1,
    EGameplayModOp__DivideAdditive = 2,
    EGameplayModOp__MultiplyCompound = 4,
    EGameplayModOp__AddFinal = 5,
    EGameplayModOp__Max = 6,
    EGameplayModOp__Additive = 0,
    EGameplayModOp__Multiplicitive = 1,
    EGameplayModOp__Division = 2,
    EGameplayModOp__Override = 3
};

enum EGameplayEffectStackingType : uint8_t
{
    EGameplayEffectStackingType__None = 0,
    EGameplayEffectStackingType__AggregateBySource = 1,
    EGameplayEffectStackingType__AggregateByTarget = 2
};

enum EGameplayTagEventType : uint8_t
{
    EGameplayTagEventType__NewOrRemoved = 0,
    EGameplayTagEventType__AnyCountChange = 1
};

enum EEntityActorReplicationOverrideType : uint8_t
{
    AutoReplication = 0,
    DoNotReplicate = 1,
    ReplicateAlways = 2,
    Static_Spatial = 3,
    Dynamic_Spatial = 4,
    Dormancy_Spatial = 5
};

enum EEntityActorReplicationRelevancyBucketType : uint8_t
{
    UseVisualCullDistanceForReplicationRelevancy = 0,
    SmallReplicationRelevancy = 1,
    MediumReplicationRelevancy = 2,
    LargeReplicationRelevancy = 3,
    MaxTargetRangeReplicationRelevancy = 4,
    ImportantReplicationRelevancy = 5,
    CustomReplicationRelevancy = 6
};

enum ECollisionShapeMode : uint8_t
{
    ECollisionShapeMode__Mesh = 0,
    ECollisionShapeMode__Box = 1,
    ECollisionShapeMode__Capsule = 2,
    ECollisionShapeMode__Sphere = 3
};

enum EDefaultAnimationMode : uint8_t
{
    EDefaultAnimationMode__UseAnimationBlueprint = 0,
    EDefaultAnimationMode__UseAnimationAsset = 1,
    EDefaultAnimationMode__UseCustomMode = 2
};

enum EConstantQNormalizationEnum : uint8_t
{
    EConstantQNormalizationEnum__EqualEuclideanNorm = 0,
    EConstantQNormalizationEnum__EqualEnergy = 1,
    EConstantQNormalizationEnum__EqualAmplitude = 2
};

enum EConstantQFFTSizeEnum : uint8_t
{
    EConstantQFFTSizeEnum__Min = 0,
    EConstantQFFTSizeEnum__XXSmall = 1,
    EConstantQFFTSizeEnum__XSmall = 2,
    EConstantQFFTSizeEnum__Small = 3,
    EConstantQFFTSizeEnum__Medium = 4,
    EConstantQFFTSizeEnum__Large = 5,
    EConstantQFFTSizeEnum__XLarge = 6,
    EConstantQFFTSizeEnum__XXLarge = 7,
    EConstantQFFTSizeEnum__Max = 8
};

enum ELoudnessCurveTypeEnum : uint8_t
{
    ELoudnessCurveTypeEnum__A = 0,
    ELoudnessCurveTypeEnum__B = 1,
    ELoudnessCurveTypeEnum__C = 2,
    ELoudnessCurveTypeEnum__D = 3,
    ELoudnessCurveTypeEnum__K = 4,
    ELoudnessCurveTypeEnum__None = 5
};

enum EMeterPeakType : uint8_t
{
    EMeterPeakType__MeanSquared = 0,
    EMeterPeakType__RootMeanSquared = 1,
    EMeterPeakType__Peak = 2,
    EMeterPeakType__Count = 3
};

enum EAudioPanelLayoutType : uint8_t
{
    EAudioPanelLayoutType__Basic = 0,
    EAudioPanelLayoutType__Advanced = 1
};

enum EAudioOscilloscopeTriggerMode : uint8_t
{
    EAudioOscilloscopeTriggerMode__None = 0,
    EAudioOscilloscopeTriggerMode__Rising = 1,
    EAudioOscilloscopeTriggerMode__Falling = 2
};

enum EYAxisLabelsUnit : uint8_t
{
    EYAxisLabelsUnit__Linear = 0,
    EYAxisLabelsUnit__Db = 1
};

enum EXAxisLabelsUnit : uint8_t
{
    EXAxisLabelsUnit__Samples = 0,
    EXAxisLabelsUnit__Seconds = 1
};

enum EAudioColorGradient : uint8_t
{
    EAudioColorGradient__BlackToWhite = 0,
    EAudioColorGradient__WhiteToBlack = 1
};

enum EAudioMaterialEnvelopeType : uint8_t
{
    EAudioMaterialEnvelopeType__AD = 0,
    EAudioMaterialEnvelopeType__ADSR = 1
};

enum EAudioSpectrogramFrequencyAxisScale : uint8_t
{
    EAudioSpectrogramFrequencyAxisScale__Linear = 0,
    EAudioSpectrogramFrequencyAxisScale__Logarithmic = 1
};

enum EAudioSpectrogramFrequencyAxisPixelBucketMode : uint8_t
{
    EAudioSpectrogramFrequencyAxisPixelBucketMode__Sample = 0,
    EAudioSpectrogramFrequencyAxisPixelBucketMode__Peak = 1,
    EAudioSpectrogramFrequencyAxisPixelBucketMode__Average = 2
};

enum EAudioSpectrumAnalyzerBallistics : uint8_t
{
    EAudioSpectrumAnalyzerBallistics__Analog = 0,
    EAudioSpectrumAnalyzerBallistics__Digital = 1
};

enum EAudioSpectrumAnalyzerType : uint8_t
{
    EAudioSpectrumAnalyzerType__FFT = 0,
    EAudioSpectrumAnalyzerType__CQT = 1
};

enum EAudioUnitsValueType : uint8_t
{
    EAudioUnitsValueType__Linear = 0,
    EAudioUnitsValueType__Frequency = 1,
    EAudioUnitsValueType__Volume = 2
};

enum EAudioRadialSliderLayout : uint8_t
{
    Layout_LabelTop = 0,
    Layout_LabelCenter = 1,
    Layout_LabelBottom = 2
};

enum EAudioSpectrumPlotFrequencyAxisScale : uint8_t
{
    EAudioSpectrumPlotFrequencyAxisScale__Linear = 0,
    EAudioSpectrumPlotFrequencyAxisScale__Logarithmic = 1
};

enum EAudioSpectrumPlotFrequencyAxisPixelBucketMode : uint8_t
{
    EAudioSpectrumPlotFrequencyAxisPixelBucketMode__Sample = 0,
    EAudioSpectrumPlotFrequencyAxisPixelBucketMode__Peak = 1,
    EAudioSpectrumPlotFrequencyAxisPixelBucketMode__Average = 2
};

enum EDataAssetDirectoryTestEnum : uint8_t
{
    EDataAssetDirectoryTestEnum__A = 0,
    EDataAssetDirectoryTestEnum__B = 1,
    EDataAssetDirectoryTestEnum__C = 2,
    EDataAssetDirectoryTestEnum__D = 3
};

enum EDataAssetDirectoryUpdateStatus : uint8_t
{
    EDataAssetDirectoryUpdateStatus__Failed = 0,
    EDataAssetDirectoryUpdateStatus__Success = 1,
    EDataAssetDirectoryUpdateStatus__SuccessNoChange = 2
};

enum ECurieHandlerBehavior : uint8_t
{
    ECurieHandlerBehavior__Handler_Add = 0,
    ECurieHandlerBehavior__Handler_Replace = 1
};

enum ECurieHandlerPriority : uint8_t
{
    ECurieHandlerPriority__Priority = 1,
    ECurieHandlerPriority__Priority = 2,
    ECurieHandlerPriority__Priority = 3,
    ECurieHandlerPriority__Priority = 4,
    ECurieHandlerPriority__Priority = 5,
    ECurieHandlerPriority__Priority = 6,
    ECurieHandlerPriority__Priority = 7,
    ECurieHandlerPriority__Priority = 8,
    ECurieHandlerPriority__Priority = 9,
    ECurieHandlerPriority__Priority = 10,
    ECurieHandlerPriority__Priority_Default = 11
};

enum ECurieManagerComponentPriority : uint8_t
{
    ECurieManagerComponentPriority__Priority = 1,
    ECurieManagerComponentPriority__Priority = 2,
    ECurieManagerComponentPriority__Priority = 3,
    ECurieManagerComponentPriority__Priority = 4,
    ECurieManagerComponentPriority__Priority = 5,
    ECurieManagerComponentPriority__Priority = 6,
    ECurieManagerComponentPriority__Priority = 7,
    ECurieManagerComponentPriority__Priority = 8,
    ECurieManagerComponentPriority__Priority = 9,
    ECurieManagerComponentPriority__Priority = 10,
    ECurieManagerComponentPriority__Priority_Default = 11
};

enum ECurieEntityType : uint8_t
{
    ECurieEntityType__Invalid = 0,
    ECurieEntityType__Material = 1,
    ECurieEntityType__Element = 2
};

enum ERedeemRealMoneyPurchaseRefreshType : uint8_t
{
    ERedeemRealMoneyPurchaseRefreshType__Default = 0,
    ERedeemRealMoneyPurchaseRefreshType__ForceCurrent = 1,
    ERedeemRealMoneyPurchaseRefreshType__ForceAll = 2,
    ERedeemRealMoneyPurchaseRefreshType__UpdateOfflineAuth = 3
};

enum EAutoRenewState : uint8_t
{
    EAutoRenewState__None = 0,
    EAutoRenewState__AutoRenewEnabled = 1,
    EAutoRenewState__AutoRenewDisabled = 2,
    EAutoRenewState__NotAutoRenewable = 3
};

enum EFulfillmentVerifierModeOverride : uint8_t
{
    EFulfillmentVerifierModeOverride__DEFAULT_TO_CONFIG = 1,
    EFulfillmentVerifierModeOverride__V1 = 2,
    EFulfillmentVerifierModeOverride__V1_PRIMARY = 3,
    EFulfillmentVerifierModeOverride__V2 = 4
};

enum ECatalogOfferType : uint8_t
{
    ECatalogOfferType__StaticPrice = 0,
    ECatalogOfferType__DynamicBundle = 1
};

enum ECatalogRequirementType : uint8_t
{
    ECatalogRequirementType__RequireFulfillment = 0,
    ECatalogRequirementType__DenyOnFulfillment = 1,
    ECatalogRequirementType__RequireItemOwnership = 2,
    ECatalogRequirementType__DenyOnItemOwnership = 3
};

enum EAppStore : uint8_t
{
    EAppStore__DebugStore = 0,
    EAppStore__EpicPurchasingService = 1,
    EAppStore__IOSAppStore = 2,
    EAppStore__WeGameStore = 3,
    EAppStore__GooglePlayAppStore = 4,
    EAppStore__KindleStore = 5,
    EAppStore__PlayStation4Store = 6,
    EAppStore__XboxLiveStore = 7,
    EAppStore__NintendoEShop = 8,
    EAppStore__S________6___E_G___vg = 9,
    EAppStore__MicrosoftStore = 10,
    EAppStore__PlayStation5Store = 11
};

enum EStoreCurrencyType : uint8_t
{
    EStoreCurrencyType__RealMoney = 0,
    EStoreCurrencyType__MtxCurrency = 1,
    EStoreCurrencyType__GameItem = 2,
    EStoreCurrencyType__Other = 3
};

enum ECatalogSaleType : uint8_t
{
    ECatalogSaleType__NotOnSale = 0,
    ECatalogSaleType__UndecoratedNewPrice = 1,
    ECatalogSaleType__AmountOff = 2,
    ECatalogSaleType__PercentOff = 3,
    ECatalogSaleType__PercentOn = 4,
    ECatalogSaleType__Strikethrough = 5
};

enum EQosResponseType : uint8_t
{
    EQosResponseType__NoResponse = 0,
    EQosResponseType__Success = 1,
    EQosResponseType__Failure = 2
};

enum EQosDatacenterResult : uint8_t
{
    EQosDatacenterResult__Invalid = 0,
    EQosDatacenterResult__Success = 1,
    EQosDatacenterResult__Incomplete = 2
};

enum EQosCompletionResult : uint8_t
{
    EQosCompletionResult__Invalid = 0,
    EQosCompletionResult__Success = 1,
    EQosCompletionResult__Failure = 2,
    EQosCompletionResult__Canceled = 3
};

enum EHotfixResult : uint8_t
{
    EHotfixResult__Failed = 0,
    EHotfixResult__Success = 1,
    EHotfixResult__SuccessNoChange = 2,
    EHotfixResult__SuccessNeedsReload = 3,
    EHotfixResult__SuccessNeedsRelaunch = 4
};

enum EUpdateState : uint8_t
{
    EUpdateState__UpdateIdle = 0,
    EUpdateState__UpdatePending = 1,
    EUpdateState__CheckingForPatch = 2,
    EUpdateState__CheckingForHotfix = 3,
    EUpdateState__WaitingOnInitialLoad = 4,
    EUpdateState__InitialLoadComplete = 5,
    EUpdateState__UpdateComplete = 6
};

enum EUpdateCompletionStatus : uint8_t
{
    EUpdateCompletionStatus__UpdateUnknown = 0,
    EUpdateCompletionStatus__UpdateSuccess = 1,
    EUpdateCompletionStatus__UpdateSuccess_NoChange = 2,
    EUpdateCompletionStatus__UpdateSuccess_NeedsReload = 3,
    EUpdateCompletionStatus__UpdateSuccess_NeedsRelaunch = 4,
    EUpdateCompletionStatus__UpdateSuccess_NeedsPatch = 5,
    EUpdateCompletionStatus__UpdateFailure_PatchCheck = 6,
    EUpdateCompletionStatus__UpdateFailure_HotfixCheck = 7,
    EUpdateCompletionStatus__UpdateFailure_NotLoggedIn = 8
};

enum EExternalAccountType : uint8_t
{
    EExternalAccountType__None = 0,
    EExternalAccountType__Facebook = 1,
    EExternalAccountType__Google = 2,
    EExternalAccountType__Epic_PSN = 3,
    EExternalAccountType__Epic_XBL = 4,
    EExternalAccountType__Epic_Erebus = 5,
    EExternalAccountType__Epic_Facebook = 6,
    EExternalAccountType__Epic_Google = 7,
    EExternalAccountType__Epic_Portal = 8
};

enum ELoginResult : uint8_t
{
    ELoginResult__NotStarted = 0,
    ELoginResult__Pending = 1,
    ELoginResult__Success = 2,
    ELoginResult__Console_LoginFailed = 3,
    ELoginResult__Console_AuthFailed = 4,
    ELoginResult__Console_MissingAuthAssociation = 5,
    ELoginResult__Console_DuplicateAuthAssociation = 6,
    ELoginResult__Console_AddedAuthAssociation = 7,
    ELoginResult__Console_AuthAssociationFailure = 8,
    ELoginResult__Console_NotEntitled = 9,
    ELoginResult__Console_EntitlementCheckFailed = 10,
    ELoginResult__Console_PrivilegeCheck = 11,
    ELoginResult__Console_PatchOrUpdateRequired = 12,
    ELoginResult__AuthFailed = 13,
    ELoginResult__AuthFailed_RefreshInvalid = 14,
    ELoginResult__AuthFailed_InvalidMFA = 15,
    ELoginResult__AuthFailed_RequiresMFA = 16,
    ELoginResult__AuthFailed_AgeVerificationIncomplete = 17,
    ELoginResult__AuthFailed_LoginLockout = 18,
    ELoginResult__AuthFailed_InvalidCredentials = 19,
    ELoginResult__AuthFailed_CorrectiveActionRequired = 20,
    ELoginResult__AuthParentalLock = 21,
    ELoginResult__PlatformNotAllowed = 22,
    ELoginResult__NotEntitled = 23,
    ELoginResult__Banned = 24,
    ELoginResult__EULACheckFailed = 25,
    ELoginResult__EULADeclined = 26,
    ELoginResult__WaitingRoomFailed = 27,
    ELoginResult__ServiceUnavailable = 28,
    ELoginResult__GenericError = 29,
    ELoginResult__RegisterSecondaryPlayerInPrimaryPartyFailed = 30,
    ELoginResult__RejoinCheckFailure = 31,
    ELoginResult__ConnectionFailed = 32,
    ELoginResult__NetworkConnectionUnavailable = 33,
    ELoginResult__AlreadyLoggingIn = 34,
    ELoginResult__ExternalAuth_AddedAuthAssociation = 35,
    ELoginResult__ExternalAuth_ConnectionTimeout = 36,
    ELoginResult__ExternalAuth_AuthFailure = 37,
    ELoginResult__ExternalAuth_AssociationFailure = 38,
    ELoginResult__ExternalAuth_MissingAuthAssociation = 39,
    ELoginResult__ExternalAuth_Canceled = 40,
    ELoginResult__FailedToCreateParty = 41,
    ELoginResult__ProfileQueryFailed = 42,
    ELoginResult__QueryKeychainFailed = 43,
    ELoginResult__ClientSettingsDownloadFailed = 44,
    ELoginResult__SupervisedSettingsDownloadFailed = 45,
    ELoginResult__PinGrantFailure = 46,
    ELoginResult__PinGrantTimeout = 47,
    ELoginResult__PinGrantCanceled = 48,
    ELoginResult__LoginStepTimeout = 49,
    ELoginResult__Console_LoginCanceled = 50,
    ELoginResult__AlreadyLoggedIn = 51
};

enum ECreateAccountResult : uint8_t
{
    ECreateAccountResult__NotStarted = 0,
    ECreateAccountResult__Pending = 1,
    ECreateAccountResult__Success = 2,
    ECreateAccountResult__Console_LoginFailed = 3,
    ECreateAccountResult__Console_DuplicateAuthAssociation = 4,
    ECreateAccountResult__DuplicateAccount = 5,
    ECreateAccountResult__GenericError = 6
};

enum EInventoryPersistenceMode : uint8_t
{
    EInventoryPersistenceMode__Normal = 0,
    EInventoryPersistenceMode__Deferred = 1,
    EInventoryPersistenceMode__Disabled = 2,
    EInventoryPersistenceMode__ReadOnly = 3
};

enum ESocialChannelType : uint8_t
{
    ESocialChannelType__General = 0,
    ESocialChannelType__Founder = 1,
    ESocialChannelType__Party = 2,
    ESocialChannelType__Team = 3,
    ESocialChannelType__System = 4,
    ESocialChannelType__Private = 5,
    ESocialC_____P____1_____zh_l2__i____B_____ = 6
};

enum EPartyType : uint8_t
{
    EPartyType__Public = 0,
    EPartyType__FriendsOnly = 1,
    EPartyType__Private = 2
};

enum EPartyInviteRestriction : uint8_t
{
    EPartyInviteRestriction__AnyMember = 0,
    EPartyInviteRestriction__LeaderOnly = 1,
    EPartyInviteRestriction__NoInvites = 2
};

enum EPartyJoinDenialReason : uint8_t
{
    EPartyJoinDenialReason__NoReason = 0,
    EPartyJoinDenialReason__JoinAttemptAborted = 1,
    EPartyJoinDenialReason__Busy = 2,
    EPartyJoinDenialReason__OssUnavailable = 3,
    EPartyJoinDenialReason__PartyFull = 4,
    EPartyJoinDenialReason__GameFull = 5,
    EPartyJoinDenialReason__NotPartyLeader = 6,
    EPartyJoinDenialReason__PartyPrivate = 7,
    EPartyJoinDenialReason__JoinerCrossplayRestricted = 8,
    EPartyJoinDenialReason__MemberCrossplayRestricted = 9,
    EPartyJoinDenialReason__GameModeRestricted = 10,
    EPartyJoinDenialReason__Banned = 11,
    EPartyJoinDenialReason__NotLoggedIn = 12,
    EPartyJoinDenialReason__CheckingForRejoin = 13,
    EPartyJoinDenialReason__TargetUserMissingPresence = 14,
    EPartyJoinDenialReason__TargetUserUnjoinable = 15,
    EPartyJoinDenialReason__TargetUserAway = 16,
    EPartyJoinDenialReason__AlreadyLeaderInPlatformSession = 17,
    EPartyJoinDenialReason__TargetUserPlayingDifferentGame = 18,
    EPartyJoinDenialReason__TargetUserMissingPlatformSession = 19,
    EPartyJoinDenialReason__PlatformSessionMissingJoinInfo = 20,
    EPartyJoinDenialReason__FailedToStartFindConsoleSession = 21,
    EPartyJoinDenialReason__MissingPartyClassForTypeId = 22,
    EPartyJoinDenialReason__TargetUserBlocked = 23,
    EPartyJoinDenialReason__InvalidJoinInfo = 24,
    EPartyJoinDenialReason__NotFriends = 25,
    EPartyJoinDenialReason__CustomReason0 = 26,
    EPartyJoinDenialReason__CustomReason1 = 27,
    EPartyJoinDenialReason__CustomReason2 = 28,
    EPartyJoinDenialReason__CustomReason3 = 29,
    EPartyJoinDenialReason__CustomReason4 = 30,
    EPartyJoinDenialReason__CustomReason5 = 31,
    EPartyJoinDenialReason__CustomReason6 = 32,
    EPartyJoinDenialReason__CustomReason7 = 33,
    EPartyJoinDenialReason__CustomReason8 = 34,
    EPartyJoinDenialReason__CustomReason9 = 35
};

enum EApprovalAction : uint8_t
{
    EApprovalAction__Approve = 0,
    EApprovalAction__Enqueue = 1,
    EApprovalAction__EnqueueAndStartBeacon = 2,
    EApprovalAction__Deny = 3
};

enum ESocialPartyInviteMethod : uint8_t
{
    ESocialPartyInviteMethod__Other = 0,
    ESocialPartyInviteMethod__Notification = 1,
    ESocialPartyInviteMethod__AcceptRequestToJoin = 2,
    ESocialPartyInviteMethod__Custom0 = 3,
    ESocialPartyInviteMethod__Custom1 = 4,
    ESocialPartyInviteMethod__Custom2 = 5,
    ESocialPartyInviteMethod__Custom3 = 6,
    ESocialPartyInviteMethod__Custom4 = 7,
    ESocialPartyInviteMethod__Custom5 = 8,
    ESocialPartyInviteMethod__Custom6 = 9,
    ESocialPartyInviteMethod__Custom7 = 10,
    ESocialPartyInviteMethod__Custom8 = 11,
    ESocialPartyInviteMethod__Custom9 = 12
};

enum ESocialPartyInviteFailureReason : uint8_t
{
    ESocialPartyInviteFailureReason__Success = 0,
    ESocialPartyInviteFailureReason__NotOnline = 1,
    ESocialPartyInviteFailureReason__NotAcceptingMembers = 2,
    ESocialPartyInviteFailureReason__NotFriends = 3,
    ESocialPartyInviteFailureReason__AlreadyInParty = 4,
    ESocialPartyInviteFailureReason__OssValidationFailed = 5,
    ESocialPartyInviteFailureReason__PlatformInviteFailed = 6,
    ESocialPartyInviteFailureReason__PartyInviteFailed = 7,
    ESocialPartyInviteFailureReason__InviteRateLimitExceeded = 8
};

enum ESocialSubsystem : uint8_t
{
    ESocialSubsystem__Primary = 0,
    ESocialSubsystem__Platform = 1
};

enum ESocialRelationship : uint8_t
{
    ESocialRelationship__Any = 0,
    ESocialRelationship__FriendInviteReceived = 1,
    ESocialRelationship__FriendInviteSent = 2,
    ESocialRelationship__PartyInvite = 3,
    ESocialRelationship__Friend = 4,
    ESocialRelationship__BlockedPlayer = 5,
    ESocialRelationship__SuggestedFriend = 6,
    ESocialRelationship__RecentPlayer = 7,
    ESocialRelationship__JoinRequest = 8
};

enum ECrossplayPreference : uint8_t
{
    ECrossplayPreference__NoSelection = 0,
    ECrossplayPreference__OptedIn = 1,
    ECrossplayPreference__OptedOut = 2,
    ECrossplayPreference__OptedOutRestricted = 3
};

enum EPlatformIconDisplayRule : uint8_t
{
    EPlatformIconDisplayRule__Always = 0,
    EPlatformIconDisplayRule__AlwaysIfDifferent = 1,
    EPlatformIconDisplayRule__AlwaysWhenInCrossplayParty = 2,
    EPlatformIconDisplayRule__AlwaysIfDifferentWhenInCrossplayParty = 3,
    EPlatformIconDisplayRule__Never = 4
};

enum ELobbyBeaconJoinState : uint8_t
{
    ELobbyBeaconJoinState__None = 0,
    ELobbyBeaconJoinState__SentJoinRequest = 1,
    ELobbyBeaconJoinState__JoinRequestAcknowledged = 2
};

enum ERejoinStatus : uint8_t
{
    ERejoinStatus__NoMatchToRejoin = 0,
    ERejoinStatus__RejoinAvailable = 1,
    ERejoinStatus__UpdatingStatus = 2,
    ERejoinStatus__NeedsRecheck = 3,
    ERejoinStatus__NoMatchToRejoin_MatchEnded = 4
};

enum EGameplayEventNetPolicy : uint8_t
{
    EGameplayEventNetPolicy__ServerOnly = 0,
    EGameplayEventNetPolicy__ClientOrServer = 1
};

enum EEntityEndPlayReason : uint8_t
{
    EEntityEndPlayReason__RemoveFromWorld = 0,
    EEntityEndPlayReason__RemoveFromEntity = 1,
    EEntityEndPlayReason__Destroy = 2
};

enum EMVVMExecutionMode : uint8_t
{
    EMVVMExecutionMode__Immediate = 0,
    EMVVMExecutionMode__Delayed = 1,
    EMVVMExecutionMode__Tick = 2,
    EMVVMExecutionMode__DelayedWhenSharedElseImmediate = 3
};

enum EMVVMBindingMode : uint8_t
{
    EMVVMBindingMode__OneTimeToDestination = 0,
    EMVVMBindingMode__OneWayToDestination = 1,
    EMVVMBindingMode__TwoWay = 2,
    EMVVMBindingMode__OneTimeToSource = 3,
    EMVVMBindingMode__OneWayToSource = 4
};

enum EUIFrameworkGameLayerType : uint8_t
{
    EUIFrameworkGameLayerType__Viewport = 0,
    EUIFrameworkGameLayerType__PlayerScreen = 1
};

enum EUIFrameworkInputMode : uint8_t
{
    EUIFrameworkInputMode__UI = 0,
    EUIFrameworkInputMode__Game = 1
};

enum EEntityProxyFeature : uint16_t
{
    EEntityProxyFeature__Selection = 1,
    EEntityProxyFeature__PropertyChanges = 4,
    EEntityProxyFeature__Duplication = 8,
    EEntityProxyFeature__CopyPaste = 16,
    EEntityProxyFeature__Deletion = 32,
    EEntityProxyFeature__DetailsPanel = 64,
    EEntityProxyFeature__Outliner = 128,
    EEntityProxyFeature__SelectionRender = 256
};

enum EConsideredForActorEntityInterop : uint8_t
{
    EConsideredForActorEntityInterop__No = 0,
    EConsideredForActorEntityInterop__Partial = 1,
    EConsideredForActorEntityInterop__Yes = 2
};

enum ETargetingAOEShape : uint8_t
{
    ETargetingAOEShape__Box = 0,
    ETargetingAOEShape__Cylinder = 1,
    ETargetingAOEShape__Sphere = 2,
    ETargetingAOEShape__Capsule = 3,
    ETargetingAOEShape__SourceComponent = 4
};

enum ETargetingTraceType : uint8_t
{
    ETargetingTraceType__Line = 0,
    ETargetingTraceType__Sphere = 1,
    ETargetingTraceType__Capsule = 2,
    ETargetingTraceType__Box = 3
};

enum EPropertyBindingAccessType : uint8_t
{
    EPropertyBindingAccessType__Offset = 0,
    EPropertyBindingAccessType__Object = 1,
    EPropertyBindingAccessType__WeakObject = 2,
    EPropertyBindingAccessType__SoftObject = 3,
    EPropertyBindingAccessType__ObjectInstance = 4,
    EPropertyBindingAccessType__StructInstance = 5,
    EPropertyBindingAccessType__IndexArray = 6
};

enum EWorldConditionResultValue : uint8_t
{
    EWorldConditionResultValue__IsFalse = 0,
    EWorldConditionResultValue__IsTrue = 1,
    EWorldConditionResultValue__Invalid = 2
};

enum EWorldConditionOperator : uint8_t
{
    EWorldConditionOperator__And = 0,
    EWorldConditionOperator__Or = 1,
    EWorldConditionOperator__Copy = 2
};

enum ESmartObjectSlotShape : uint8_t
{
    ESmartObjectSlotShape__Circle = 0,
    ESmartObjectSlotShape__Rectangle = 1
};

enum ESmartObjectSlotState : uint8_t
{
    ESmartObjectSlotState__Invalid = 0,
    ESmartObjectSlotState__Free = 1,
    ESmartObjectSlotState__Claimed = 2,
    ESmartObjectSlotState__Occupied = 3,
    ESmartObjectSlotState__Disabled = 4
};

enum ESmartObjectCollectionRegistrationResult : uint8_t
{
    ESmartObjectCollectionRegistrationResult__Failed_InvalidCollection = 0,
    ESmartObjectCollectionRegistrationResult__Failed_AlreadyRegistered = 1,
    ESmartObjectCollectionRegistrationResult__Failed_NotFromPersistentLevel = 2,
    ESmartObjectCollectionRegistrationResult__Succeeded = 3
};

enum ESmartObjectTagFilteringPolicy : uint8_t
{
    ESmartObjectTagFilteringPolicy__NoFilter = 0,
    ESmartObjectTagFilteringPolicy__Combine = 1,
    ESmartObjectTagFilteringPolicy__Override = 2
};

enum ESmartObjectClaimPriority : uint8_t
{
    ESmartObjectClaimPriority__None = 0,
    ESmartObjectClaimPriority__Low = 1,
    ESmartObjectClaimPriority__BelowNormal = 2,
    ESmartObjectClaimPriority__Normal = 3,
    ESmartObjectClaimPriority__AboveNormal = 4,
    ESmartObjectClaimPriority__High = 5,
    ESmartObjectClaimPriority__MIN = 0
};

enum ESmartObjectTraceType : uint8_t
{
    ESmartObjectTraceType__ByChannel = 0,
    ESmartObjectTraceType__ByProfile = 1,
    ESmartObjectTraceType__ByObjectTypes = 2
};

enum EPlayspaceJurisdictionFilterState : uint8_t
{
    EPlayspaceJurisdictionFilterState__Initialized = 0,
    EPlayspaceJurisdictionFilterState__PendingResolve = 1,
    EPlayspaceJurisdictionFilterState__Resolved = 2
};

enum EPlayspaceCreationType : uint8_t
{
    EPlayspaceCreationType__ChildOfRoot = 0,
    EPlayspaceCreationType__RootDestroy = 1,
    EPlayspaceCreationType__RootInserted = 2,
    EPlayspaceCreationType__RootDoNotClobber = 3
};

enum EWithinBoundsEvaluationType : uint8_t
{
    EWithinBoundsEvaluationType__UseOver8_9_ = 0,
    EWithinBoundsEvaluationType__UseBoxBounds = 1,
    EWithinBoundsEvaluationType__UseSphereBounds = 2
};

enum EPlayspaceComponentCreationType : uint8_t
{
    EPlayspaceComponentCreationType__Root = 0,
    EPlayspaceComponentCreationType__ByLocation = 1,
    EPlayspaceComponentCreationType__ByTags = 2
};

enum ERigElementType : uint16_t
{
    ERigElementType__None = 0,
    ERigElementType__Bone = 1,
    ERigElementType__Null = 2,
    ERigElementType__Space = 2,
    ERigElementType__Control = 4,
    ERigElementType__Curve = 8,
    ERigElementType__Physics = 16,
    ERigElementType__Reference = 32,
    ERigElementType__Connector = 64,
    ERigElementType__Socket = 128,
    ERigElementType__First = 1,
    ERigElementType__Last = 128,
    ERigElementType__All = 255,
    ERigElementType__ToResetAfterConstructionEvent = 141
};

enum ERigHierarchyNotification : uint8_t
{
    ERigHierarchyNotification__ElementAdded = 0,
    ERigHierarchyNotification__ElementRemoved = 1,
    ERigHierarchyNotification__ElementRenamed = 2,
    ERigHierarchyNotification__ElementSelected = 3,
    ERigHierarchyNotification__ElementDeselected = 4,
    ERigHierarchyNotification__ParentChanged = 5,
    ERigHierarchyNotification__HierarchyReset = 6,
    ERigHierarchyNotification__ControlSettingChanged = 7,
    ERigHierarchyNotification__ControlVisibilityChanged = 8,
    ERigHierarchyNotification__ControlDrivenListChanged = 9,
    ERigHierarchyNotification__ControlShapeTransformChanged = 10,
    ERigHierarchyNotification__ParentWeightsChanged = 11,
    ERigHierarchyNotification__InteractionBracketOpened = 12,
    ERigHierarchyNotification__InteractionBracketClosed = 13,
    ERigHierarchyNotification__ElementReordered = 14,
    ERigHierarchyNotification__ConnectorSettingChanged = 15,
    ERigHierarchyNotification__SocketColorChanged = 16,
    ERigHierarchyNotification__SocketDescriptionChanged = 17,
    ERigHierarchyNotification__SocketDesiredParentChanged = 18,
    ERigHierarchyNotification__HierarchyCopied = 19,
    ERigHierarchyNotification__Max = 20
};

enum ERigControlTransformChannel : uint8_t
{
    ERigControlTransformChannel__TranslationX = 0,
    ERigControlTransformChannel__TranslationY = 1,
    ERigControlTransformChannel__TranslationZ = 2,
    ERigControlTransformChannel__Pitch = 3,
    ERigControlTransformChannel__Yaw = 4,
    ERigControlTransformChannel__Roll = 5,
    ERigControlTransformChannel__ScaleX = 6,
    ERigControlTransformChannel__ScaleY = 7,
    ERigControlTransformChannel__ScaleZ = 8
};

enum ERigControlAxis : uint8_t
{
    ERigControlAxis__X = 0,
    ERigControlAxis__Y = 1,
    ERigControlAxis__Z = 2
};

enum ERigControlType : uint8_t
{
    ERigControlType__Bool = 0,
    ERigControlType__Float = 1,
    ERigControlType__Integer = 2,
    ERigControlType__Vector2D = 3,
    ERigControlType__Position = 4,
    ERigControlType__Scale = 5,
    ERigControlType__Rotator = 6,
    ERigControlType__Transform = 7,
    ERigControlType__TransformNoScale = 8,
    ERigControlType__EulerTransform = 9,
    ERigControlType__ScaleFloat = 10
};

enum ERigControlAnimationType : uint8_t
{
    ERigControlAnimationType__AnimationControl = 0,
    ERigControlAnimationType__AnimationChannel = 1,
    ERigControlAnimationType__ProxyControl = 2,
    ERigControlAnimationType__VisualCue = 3
};

enum ERigTransformStackEntryType : uint8_t
{
    TransformPose = 0,
    ControlOffset = 1,
    ControlShape = 2,
    CurveValue = 3
};

enum ERigTransformType : uint8_t
{
    ERigTransformType__InitialLocal = 0,
    ERigTransformType__CurrentLocal = 1,
    ERigTransformType__InitialGlobal = 2,
    ERigTransformType__CurrentGlobal = 3,
    ERigTransformType__NumTransformTypes = 4
};

enum ERigTransformStorageType : uint8_t
{
    ERigTransformStorageType__Pose = 0,
    ERigTransformStorageType__Offset = 1,
    ERigTransformStorageType__Shape = 2,
    ERigTransformStorageType__NumStorageTypes = 3
};

enum EControlRigComponentSpace : uint8_t
{
    EControlRigComponentSpace__WorldSpace = 0,
    EControlRigComponentSpace__ActorSpace = 1,
    EControlRigComponentSpace__ComponentSpace = 2,
    EControlRigComponentSpace__RigSpace = 3,
    EControlRigComponentSpace__LocalSpace = 4,
    EControlRigComponentSpace__Max = 5
};

enum ETransformSpaceMode : uint8_t
{
    ETransformSpaceMode__LocalSpace = 0,
    ETransformSpaceMode__GlobalSpace = 1,
    ETransformSpaceMode__BaseSpace = 2,
    ETransformSpaceMode__BaseJoint = 3,
    ETransformSpaceMode__Max = 4
};

enum ETransformGetterType : uint8_t
{
    ETransformGetterType__Initial = 0,
    ETransformGetterType__Current = 1,
    ETransformGetterType__Max = 2
};

enum ECRSimConstraintType : uint8_t
{
    ECRSimConstraintType__Distance = 0,
    ECRSimConstraintType__DistanceFromA = 1,
    ECRSimConstraintType__DistanceFromB = 2,
    ECRSimConstraintType__Plane = 3
};

enum ECRSimPointForceType : uint8_t
{
    ECRSimPointForceType__Direction = 0
};

enum ECRSimSoftCollisionType : uint8_t
{
    ECRSimSoftCollisionType__Plane = 0,
    ECRSimSoftCollisionType__Sphere = 1,
    ECRSimSoftCollisionType__Cone = 2
};

enum EModularRigNotification : uint8_t
{
    EModulp4_________u__HY____2____U__Ee = 0,
    EModularRigNotification__ModuleRenamed = 1,
    EModularRigNotification__ModuleRemoved = 2,
    EModularRigNotification__ModuleReparented = 3,
    EModularRigNotification__ConnectionChanged = 4,
    EModularRigNotification__ModuleConfigValueChanged = 5,
    EModularRigNotification__ModuleShortNameChanged = 6,
    EModularRigNotification__InteractionBracketOpened = 7,
    EModularRigNotification__InteractionBracketClosed = 8,
    EModularRigNotification__InteractionBracketCanceled = 9,
    EModularRigNotification__ModuleClassChanged = 10,
    EModularRigNotification__ModuleSelected = 11,
    EModularRigNotification__ModuleDeselected = 12,
    EModularRigNotification__Max = 13
};

enum ERigBoneType : uint8_t
{
    ERigBoneType__Imported = 0,
    ERigBoneType__User = 1
};

enum ERigMetadataType : uint8_t
{
    ERigMetadataType__Bool = 0,
    ERigMetadataType__BoolArray = 1,
    ERigMetadataType__Float = 2,
    ERigMetadataType__FloatArray = 3,
    ERigMetadataType__Int32 = 4,
    ERigMetadataType__Int32Array = 5,
    ERigMetadataType__Name = 6,
    ERigMetadataType__NameArray = 7,
    ERigMetadataType__Vector = 8,
    ERigMetadataType__VectorArray = 9,
    ERigMetadataType__Rotator = 10,
    ERigMetadataType__RotatorArray = 11,
    ERigMetadataType__Quat = 12,
    ERigMetadataType__QuatArray = 13,
    ERigMetadataType__Transform = 14,
    ERigMetadataType__TransformArray = 15,
    ERigMetadataType__LinearColor = 16,
    ERigMetadataType__LinearColorArray = 17,
    ERigMetadataType__RigElementKey = 18,
    ERigMetadataType__RigElementKeyArray = 19,
    ERigMetadataType__Invalid = 20
};

enum ERigEvent : uint8_t
{
    ERigEvent__None = 0,
    ERigEvent__RequestAutoKey = 1,
    ERigEvent__OpenUndoBracket = 2,
    ERigEvent__CloseUndoBracket = 3,
    ERigEvent__Max = 4
};

enum EControlRigSetKey : uint8_t
{
    EControlRigSetKey__DoNotCare = 0,
    EControlRigSetKey__Always = 1,
    EControlRigSetKey__Never = 2
};

enum ERigControlValueType : uint8_t
{
    ERigControlValueType__Initial = 0,
    ERigControlValueType__Current = 1,
    ERigControlValueType__Minimum = 2,
    ERigControlValueType__Maximum = 3
};

enum ERigElementResolveState : uint8_t
{
    ERigElementResolveState__Unknown = 0
};

enum ERigSpaceType : uint8_t
{
    ERigSpaceType__Global = 0,
    ERigSpaceType__Bone = 1,
    ERigSpaceType__Control = 2,
    ERigSpaceType__Space = 3
};

enum EMovieSceneControlRigSpaceType : uint8_t
{
    EMovieSceneControlRigSpaceType__Parent = 0,
    EMovieSceneControlRigSpaceType__World = 1,
    EMovieSceneControlRigSpaceType__ControlRig = 2
};

enum EControlRigDrawHierarchyMode : uint8_t
{
    EControlRigDrawHierarchyMode__Axes = 0,
    EControlRigDrawHierarchyMode__Max = 1
};

enum ERigSwitchParentMode : uint8_t
{
    ERigSwitchParentMode__World = 0,
    ERigSwitchParentMode__DefaultParent = 1,
    ERigSwitchParentMode__ParentItem = 2
};

enum EControlRigModifyBoneMode : uint8_t
{
    EControlRigModifyBoneMode__OverrideLocal = 0,
    EControlRigModifyBoneMode__OverrideGlobal = 1,
    EControlRigModifyBoneMode__AdditiveLocal = 2,
    EControlRigModifyBoneMode__AdditiveGlobal = 3,
    EControlRigModifyBoneMode__Max = 4
};

enum EControlRigInteractionType : uint8_t
{
    EControlRigInteractionType__None = 0,
    EControlRigInteractionType__Translate = 1,
    EControlRigInteractionType__Rotate = 2,
    EControlRigInteractionTy____F__b_ = 4,
    EControlRigInteractionType__All = 7
};

enum ERigMetaDataNameSpace : uint8_t
{
    ERigMetaDataNameSpace__None = 0,
    ERigMetaDataNameSpace__Self = 1,
    ERigMetaDataNameSpace__Parent = 2,
    ERigMetaDataNameSpace__Root = 3,
    ERigMetaDataNameSpace__Last = 4
};

enum EPBIKLimitType : uint8_t
{
    EPBIKLimitType__Free = 0,
    EPBIKLimitType__Limited = 1,
    EPBIKLimitType__Locked = 2
};

enum EPBIKRootBehavior : uint8_t
{
    EPBIKRootBehavior__PrePull = 0,
    EPBIKRootBehavior__PinToInput = 1,
    EPBIKRootBehavior__Free = 2
};

enum EPinBoneType : uint8_t
{
    EPinBoneType__FullTransform = 0,
    EPinBoneType__TranslateOnly = 1,
    EPinBoneType__RotateOnly = 2,
    EPinBoneType__ScaleOnly = 3
};

enum ERetargetTranslationMode : uint8_t
{
    ERetargetTranslationMode__None = 0,
    ERetargetTranslationMode__GloballyScaled = 1,
    ERetargetTranslationMode__Absolute = 2
};

enum ERetargetRotationMode : uint8_t
{
    ERetargetRotationMode__Interpolated = 0,
    ERetargetRotationMode__OneToOne = 1,
    ERetargetRotationMode__OneToOneReversed = 2,
    ERetargetRotationMode__None = 3
};

enum EBasicAxis : uint8_t
{
    EBasicAxis__X = 0,
    EBasicAxis__Y = 1,
    EBasicAxis__Z = 2,
    EBasicAxis__NegX = 3,
    EBasicAxis__NegY = 4,
    EBasicAxis__NegZ = 5
};

enum EWarpingDirectionSource : uint8_t
{
    EWarpingDirectionSource__Goals = 0,
    EWarpingDirectionSource__Chain = 1,
    EWarpingDirectionSource__RootBone = 2
};

enum EIKRigGoalSpace : uint8_t
{
    EIKRigGoalSpace__Component = 0,
    EIKRigGoalSpace__Additive = 1,
    EIKRigGoalSpace__World = 2
};

enum EIKRigGoalTransformSource : uint8_t
{
    EIKRigGoalTransformSource__Manual = 0,
    EIKRigGoalTransformSource__Bone = 1,
    EIKRigGoalTransformSource__ActorComponent = 2
};

enum EOperation : uint8_t
{
    EOperation__Intro = 0,
    EOperation__Outro = 1,
    EOperation__Push = 2,
    EOperation__Pop = 3,
    EOperation__Invalid = 4
};

enum ECommonPlatformType : uint8_t
{
    ECommonPlatformType__PC = 0,
    ECommonPlatformType__Mac = 1,
    ECommonPlatformType__PS4 = 2,
    ECommonPlatformType__XBox = 3,
    ECommonPlatformType__IOS = 4,
    ECommonPlatformType__Android = 5,
    ECommonPlatformType__Switch = 6,
    ECommonPlatformType__XSX = 7,
    ECommonPlatformType__PS5 = 8,
    ECommonPlatformType__Count = 9
};

enum ECommonGamepadType : uint8_t
{
    ECommonGamepadType__XboxOneController = 0,
    ECommonGamepadType__PS4Controller = 1,
    ECommonGamepadType__SwitchController = 2,
    ECommonGamepadType__GenericController = 3,
    ECommonGamepadType__XboxSeriesXController = 4,
    ECommonGamepadType__PSK_____q____ = 5,
    ECommonGamepadType__Count = 6
};

enum EXpRewardRestedXpUsage : uint8_t
{
    EXpRewardRestedXpUsage__NoRestedXp = 0,
    EXpRewardRestedXpUsage__BaseRewardMultiplier = 1,
    EXpRewardRestedXpUsage__FixedRestedXp = 2
};

enum ERewardCalibrationUsage : uint8_t
{
    ERewardCalibrationUsage__NoCalibration = 0,
    ERewardCalibrationUsage__FireCalibrationEventsOnly = 1
};

enum EDynamicUIStrength : uint8_t
{
    EDynamicUIStrength__Weak = 0,
    EDynamicUIStrength__Medium = 1,
    EDynamicUIStrength__Strong = 2,
    EDynamicUIStrength__Required = 3
};

enum EDynamicUIAnchor : uint8_t
{
    EDynamicUIAnchor__TopLeft = 0,
    EDynamicUIAnchor__TopCenter = 1,
    EDynamicUIAnchor__TopRight = 2,
    EDynamicUIAnchor__CenterLeft = 3,
    EDynamicUIAnchor__CenterCenter = 4,
    EDynamicUIAnchor__CenterRight = 5,
    EDynamicUIAnchor__BottomLeft = 6,
    EDynamicUIAnchor__BottomCenter = 7,
    EDynamicUIAnchor__BottomRight = 8
};

enum EDynamicUIAspectRatioType : uint8_t
{
    EDynamicUIAspectRatioType__AspectRatio_1 = 0,
    EDynamicUIAspectRatioType__AspectRatio_4 = 1,
    EDynamicUIAspectRatioType__AspectRatio_5 = 2,
    EDynamicUIAspectRatioType__AspectRatio_16 = 3,
    EDynamicUIAspectRatioType__AspectRatio_16 = 4,
    EDynamicUIAspectRatioType__AspectRatio_21 = 5,
    EDynamicUIAspectRatioType__Custom = 6
};

enum EDynamicUISizeMatch : uint8_t
{
    EDynamicUISizeMatch__Both = 0,
    EDynamicUISizeMatch__Width = 1,
    EDynamicUISizeMatch__Height = 2
};

enum EDynamicUIZOrder : uint16_t
{
    EDynamicUIZOrder__Back = 1000,
    EDynamicUIZOrder__Middle = 2000,
    EDynamicUIZOrder__Front = 3000,
    EDynamicUIZOrder__Custom = 2500,
    EDynamicUIZOrder__CustomMin = 0,
    EDynamicUIZOrder__CustomMax = 5000,
    EDynamicUIZOrder__Loading = 30000,
    EDynamicUIZOrder__Top = 50000
};

enum EDynamicUIUnallowedBehavior : uint8_t
{
    EDynamicUIUnallowedBehavior__Hide = 0,
    EDynamicUIUnallowedBehavior__Collapse = 1,
    EDynamicUIUnallowedBehavior__Destroy = 2
};

enum EDynamicUIDebugDisplayMode : uint8_t
{
    EDynamicUIDebugDisplayMode__Hide = 0,
    EDynamicUIDebugDisplayMode__ShowSelected = 1,
    EDynamicUIDebugDisplayMode__ShowAll = 2
};

enum EDynamicUIUnallowLayerComparison : uint8_t
{
    EDynamicUIUnallowLayerComparison__Equal = 0,
    EDynamicUIUnallowLayerComparison__NotEqual = 1,
    EDynamicUIUnallowLayerComparison__Less = 2,
    EDynamicUIUnallowLayerComparison__LessOrEqual = 3,
    EDynamicUIUnallowLayerComparison__Greater = 4,
    EDynamicUIUnallowLayerComparison__GreaterOrEqual = 5
};

enum ESubtitleDisplayTextSize : uint8_t
{
    ESubtitleDisplayTextSize__ExtraSmall = 0,
    ESubtitleDisplayTextSize__Small = 1,
    ESubtitleDisplayTextSize__Medium = 2,
    ESubtitleDisplayTextSize__Large = 3,
    ESubtitleDisplayTextSize__ExtraLarge = 4
};

enum ESubtitleDisplayTextColor : uint8_t
{
    ESubtitleDisplayTextColor__White = 0,
    ESubtitleDisplayTextColor__Yellow = 1
};

enum ESubtitleDisplayTextBorder : uint8_t
{
    ESubtitleDisplayTextBorder__None = 0,
    ESubtitleDisplayTextBorder__Outline = 1,
    ESubtitleDisplayTextBorder__DropShadow = 2
};

enum ESubtitleDisplayBackgroundOpacity : uint8_t
{
    ESubtitleDisplayBackgroundOpacity__Clear = 0,
    ESubtitleDisplayBackgroundOpacity__Low = 1,
    ESubtitleDisplayBackgroundOpacity__Medium = 2,
    ESubtitleDisplayBackgroundOpacity__High = 3,
    ESubtitleDisplayBackgroundOpacity__Solid = 4
};

enum EBlendStack_BlendspaceUpdateMode : uint8_t
{
    EBlendStack_BlendspaceUpdateMode__InitialOnly = 0,
    EBlendStack_BlendspaceUpdateMo_qi_J__p_5_____DP___ = 1,
    EBlendStack_BlendspaceUpdateMode__UpdateAll = 2
};

enum EBoolColumnCellValue : uint8_t
{
    EBoolColumnCellValue__MatchFalse = 0,
    EBoolColumnCellValue__MatchTrue = 1,
    EBoolColumnCellValue__MatchAny = 2
};

enum EContextObjectDirection : uint8_t
{
    EContextObjectDirection__Read = 0,
    EContextObjectDirection__Write = 1,
    EContextObjectDirection__ReadWrite = 2
};

enum EEnumColumnCellValueComparison : uint8_t
{
    EEnumColumnCellValueComparison__MatchEqual = 0,
    EEnumColumnCellValueComparison__MatchNotEqual = 1,
    EEnumColumnCellValueComparison__MatchAny = 2,
    EEnumColumnCellValueComparison__Modulus = 3
};

enum EGameplayTagMatchDirection : uint8_t
{
    EGameplayTagMatchDirection__RowValueInInput = 0,
    EGameplayTagMatchDirection__InputInRowValue = 1
};

enum EObjectChooserResultType : uint8_t
{
    EObjectChooserResultType__ObjectResult = 0,
    EObjectChooserResultType__ClassResult = 1,
    EObjectChooserResultType__NoPrimaryResult = 2
};

enum EObjectClassColumnCellValueComparison : uint8_t
{
    EObjectClassColumnCellValueComparison__Equal = 0,
    EObjectClassColumnCellValueComparison__NotEqual = 1,
    EObjectClassColumnCellValueComparison__SubClassOf = 2,
    EObjectClassColumnCellValueComparison__NotSubClassOf = 3,
    EObjectClassColumnCellValueComparison__Any = 4
};

enum EObjectColumnCellValueComparison : uint8_t
{
    EObjectColumnCellValueComparison__MatchEqual = 0,
    EObjectColumnCellValueComparison__MatchNotEqual = 1,
    EObjectColumnCellValueComparison__MatchAny = 2,
    EObjectColumnCellValueComparison__Modulus = 3
};

enum EChooserEvaluationFrequency : uint8_t
{
    EChooserEvaluationFrequency__OnInitialUpdate = 0,
    EChooserEvaluationFrequency__OnBecomeRelevant = 1,
    EChooserEvaluationFrequency__OnLoop = 2,
    EChooserEvaluationFrequency__OnUpdate = 3
};

enum EEquipItemLimitHitBehaviour : uint8_t
{
    EEquipItemLimitHitBehaviour__UnequipLeastRecentlyUsed = 0,
    EEquipItemLimitHitBehaviour__Block = 1
};

enum EVkInventoryMoveResult : uint8_t
{
    EVkInventoryMoveResult__Success = 0,
    EVkInventoryMoveResult__Failed = 1,
    EVkInventoryMoveResult__InvalidRequest = 2,
    EVkInventoryMoveResult__NoChange = 3
};

enum EVkInventoryMoveBehaviour : uint8_t
{
    EVkInventoryMoveBehaviour__SwapSlotNumber = 0,
    EVkInventoryMoveBehaviour__EmplaceSlotNumber = 1
};

enum EItemizationInventoryType : uint8_t
{
    EItemizationInventoryType__Player = 0,
    EItemizationInventoryType__World = 1
};

enum EItemizationInventoryCreationType : uint16_t
{
    EItemizationInventoryCreationType__Runtime = 0,
    EItemizationInventoryCreationType__SetupData = 1,
    EItemizationInventoryCreationType__Invalid = 255
};

enum EInventoryCollectionAccess : uint8_t
{
    EInventoryCollectionAccess__None = 0,
    EInventoryCollectionAccess__Read = 1,
    EInventoryCollectionAccess__Write = 2,
    EInventoryCollectionAccess__All = 3
};

enum EItemState : uint8_t
{
    EItemState__NotInInventory = 0,
    EItemState__InInventory = 1,
    EItemState__EquippedAndActive = 2,
    EItemState__NumStates = 3
};

enum EItemStateFilter : uint8_t
{
    EItemStateFilter__Owned = 0,
    EItemStateFilter__Equipped = 1,
    EItemStateFilter_______5_Q_S__lsw_V = 2
};

enum EItemDataQueryResult : uint8_t
{
    EItemDataQueryResult__Found = 0,
    EItemDataQueryResult__NotFound = 1
};

enum EItemizationPersistenceRequestType : uint8_t
{
    EItemizationPersistenceRequestType__Invalid = 0,
    EItemizationPersistenceRequestType__Checkout = 1,
    EItemizationPersistenceRequestType__CheckIn = 2,
    EItemizationPersistenceRequestType__Clear = 3,
    EItemizationPersistenceRequestType__Update = 4
};

enum EItemizationPersistenceResponseType : uint16_t
{
    EItemizationPersistenceResponseType__Invalid = 0,
    EItemizationPersistenceResponseType__NoPersistenceManager = 1,
    EItemizationPersistenceResponseType__Failed = 2,
    EItemizationPersistenceResponseType__Success = 255
};

enum EInventoryCollectionLoadState : uint16_t
{
    EInventoryCollectionLoadState__Invalid = 0,
    EInventoryCollectionLoadState__WaitingToLoad = 10,
    EInventoryCollectionLoadState__Loading = 11,
    EInventoryCollectionLoadState__Loaded = 12,
    EInventoryCollectionLoadState__WaitingToUnload = 20,
    EInventoryCollectionLoadState__Unloading = 21,
    EInventoryCollectionLoadState__Unloaded = 22,
    EInventoryCollectionLoadState__WaitingToClear = 30,
    EInventoryCollectionLoadState__Clearing = 31,
    EInventoryCollectionLoadState__Cleared = 32,
    EInventoryCollectionLoadState__Ready = 255
};

enum EDateType : uint8_t
{
    EDateType__None = 0,
    EDateType__Coming = 1,
    EDateType__Ending = 2
};

enum EBrushFalloffMode : uint8_t
{
    EBrushFalloffMode__Angle = 0,
    EBrushFalloffMode__Width = 1
};

enum EBrushBlendType : uint8_t
{
    EBrushBlendType__AlphaBlend = 0,
    EBrushBlendType__Min = 1,
    EBrushBlendType__Max = 2,
    EBrushBlendType__Additive = 3
};

enum EBuoyancyEvent : uint8_t
{
    EBuoyancyEvent__EnteredWaterBody = 0,
    EBuoyancyEvent__ExitedWaterBody = 1
};

enum EWaveSpectrumType : uint8_t
{
    EWaveSpectrumType__Phillips = 0,
    EWaveSpectrumType__PiersonMoskowitz = 1,
    EWaveSpectrumType__JONSWAP = 2
};

enum EWaterExclusionMode : uint8_t
{
    EWaterExclusionMode__AddWaterBodiesListToExclusion = 0,
    EWaterExclusionMode__RemoveWaterBodiesListFromExclusion = 1
};

enum EWaterBrushFalloffMode : uint8_t
{
    EWaterBrushFalloffMode__Angle = 0,
    EWaterBrushFalloffMode__Width = 1
};

enum EOscillatorWaveform : uint8_t
{
    EOscillatorWaveform__SineWave = 0,
    EOscillatorWaveform__PerlinNoise = 1
};

enum ECameraAnimationPlaySpace : uint8_t
{
    ECameraAnimationPlaySpace__CameraLocal = 0,
    ECameraAnimationPlaySpace__World = 1,
    ECameraAnimationPlaySpace__UserDefined = 2
};

enum ECameraAnimationEasingType : uint8_t
{
    ECameraAnimationEasingType__Linear = 0,
    ECameraAnimationEasi_______R_Q_m__O___ = 1,
    ECameraAnimationEasingType__Quadratic = 2,
    ECameraAnimationEasingType__Cubic = 3,
    ECameraAnimationEasingType__Quartic = 4,
    ECameraAnimationEasingType__Quintic = 5,
    ECameraAnimationEasingType__Exponential = 6,
    ECameraAnimationEasingType__Circular = 7
};

enum ENetworkPredictionTickingPolicy : uint8_t
{
    ENetworkPredictionTickingPolicy__Independent = 1,
    ENetworkPredictionTickingPolicy__Fixed = 2,
    ENetworkPredictionTickingPolicy__All = 3
};

enum ENetworkLOD : uint8_t
{
    ENetworkLOD__Interpolated = 1,
    ENetworkLOD__SimExtrapolate = 2,
    ENetworkLOD__ForwardPredict = 4,
    ENetworkLOD__All = 7
};

enum ESynth1OscType : uint8_t
{
    ESynth1OscType__Si__ = 0,
    ESynth1OscType__Saw = 1,
    ESynth1OscType__Triangle = 2,
    ESynth1OscType__Square = 3,
    ESynth1OscType__Noise = 4,
    ESynth1OscType__Count = 5
};

enum ESynthLFOType : uint8_t
{
    ESynthLFOType__Sine = 0,
    ESynthLFOType__UpSaw = 1,
    ESynthLFOType__DownSaw = 2,
    ESynthLFOType__Square = 3,
    ESynthLFOType__Triangle = 4,
    ESynthLFOType__Exponential = 5,
    ESynthLFOType__RandomSampleHold = 6,
    ESynthLFOType__Count = 7
};

enum ESynthLFOMode : uint8_t
{
    ESynthLFOMode__Sync = 0,
    ESynthLFOMode__OneShot = 1,
    ESynthLFOMode__Free = 2,
    ESynthLFOMode__Count = 3
};

enum ESynthLFOPatchType : uint8_t
{
    ESynthLFOPatchType__PatchToNone = 0,
    ESynthLFOPatchType__PatchToGain = 1,
    ESynthLFOPatchType__PatchToOscFreq = 2,
    ESynthLFOPatchType__PatchToFilterFreq = 3,
    ESynthLFOPatchType__PatchToFilterQ = 4,
    ESynthLFOPatchType__PatchToOscPulseWidth = 5,
    ESynthLFOPatchType__PatchToOscPan = 6,
    ESynthLFOPatchType__PatchLFO1ToLFO2Frequency = 7,
    ESynthLFOPatchType__PatchLFO1ToLFO2Gain = 8,
    ESynthLFOPatchType__Count = 9
};

enum ESynthModEnvPatch : uint8_t
{
    ESynthModEnvPatch__PatchToNone = 0,
    ESynthModEnvPatch__PatchToOscFreq = 1,
    ESynthModEnvPatch__PatchToFilterFreq = 2,
    ESynthModEnvPatch__PatchToFilterQ = 3,
    ESynthModEnvPatch__PatchToLFO1Gain = 4,
    ESynthModEnvPatch__PatchToLFO2Gain = 5,
    ESynthModEnvPatch__PatchToLFO1Freq = 6,
    ESynthModEnvPatch__PatchToLFO2Freq = 7,
    ESynthModEnvPatch__Count = 8
};

enum ESynthModEnvBiasPatch : uint8_t
{
    ESynthModEnvBiasPatch__PatchToNone = 0,
    ESynthModEnvBiasPatch__PatchToOscFreq = 1,
    ESynthModEnvBiasPatch__PatchToFilterFreq = 2,
    ESynthModEnvBiasPatch__PatchToFilterQ = 3,
    ESynthModEnvBiasPatch__PatchToLFO1Gain = 4,
    ESynthModEnvBiasPatch__PatchToLFO2Gain = 5,
    ESynthModEnvBiasPatch__PatchToLFO1Freq = 6,
    ESynthModEnvBiasPatch__PatchToLFO2Freq = 7,
    ESynthModEnvBiasPatch__Count = 8
};

enum ESynthFilterAlgorithm : uint8_t
{
    ESynthFilterAlgorithm__OnePole = 0,
    ESynthFilterAlgorithm__StateVariable = 1,
    ESynthFilterAlgorithm__Ladder = 2,
    ESynthFilterAlgorithm__Count = 3
};

enum ESynthStereoDelayMode : uint8_t
{
    ESynthStereoDelayMode__Normal = 0,
    ESynthStereoDelayMode__Cross = 1,
    ESynthStereoDelayMode__PingPong = 2,
    ESynthStereoDelayMode__Count = 3
};

enum ESynth1PatchDestination : uint8_t
{
    ESynth1PatchDestination__Osc1Gain = 0,
    ESynth1PatchDestination__Osc1Frequency = 1,
    ESynth1PatchDestination__Osc1Pulsewidth = 2,
    ESynth1PatchDestination__Osc2Gain = 3,
    ESynth1PatchDestination__Osc2Frequency = 4,
    ESynth1PatchDestination__Osc2Pulsewidth = 5,
    ESynth1PatchDestination__FilterFrequency = 6,
    ESynth1PatchDestination__FilterQ = 7,
    ESynth1PatchDestination__Gain = 8,
    ESynth1PatchDestination__Pan = 9,
    ESynth1PatchDestination__LFO1Frequency = 10,
    ESynth1PatchDestination__LFO1Gain = 11,
    ESynth1PatchDestination__LFO2Frequency = 12,
    ESynth1PatchDestination__LFO2Gain = 13,
    ESynth1PatchDestination__Count = 14
};

enum ESubmixEffectConvolutionReverbBlockSize : uint8_t
{
    ESubmixEffectConvolutionReverbBlockSize__BlockSize256 = 0,
    ESubmixEffectConvolutionReverbBlockSize__BlockSize512 = 1,
    ESubmixEffectConvolutionReverbBlockSize__BlockSize1024 = 2
};

enum ESourceEffectDynamicsProcessorType : uint8_t
{
    ESourceEffectDynamicsProcessorType__Compressor = 0,
    ESourceEffectDynamicsProcessorType__Limiter = 1,
    ESourceEffectDynamicsProcessorType__Expander = 2,
    ESourceEffectDynamicsProcessorType__Gate = 3,
    ESourceEffectDynamicsProcessorType__UpwardsCompressor = 4,
    ESourceEffectDynamicsProcessorType__Count = 5
};

enum ESourceEffectDynamicsPeakMode : uint8_t
{
    ESourceEffectDynamicsPeakMode__MeanSquared = 0,
    ESourceEffectDynamicsPeakMode__RootMeanSquared = 1,
    ESourceEffectDynamicsPeakMode__Peak = 2,
    ESourceEffectDynamicsPeakMode__Count = 3
};

enum EEnvelopeFollowerPeakMode : uint8_t
{
    EEnvelopeFollowerPeakMode__MeanSquared = 0,
    EEnvelopeFollowerPeakMode__RootMeanSquared = 1,
    EEnvelopeFollowerPeakMode__Peak = 2,
    EEnvelopeFollowerPeakMode__Count = 3
};

enum ESourceEffectFilterCircuit : uint8_t
{
    ESourceEffectFilterCircuit__OnePole = 0,
    ESourceEffectFilterCircuit__StateVariable = 1,
    ESourceEffectFilterCircuit__Ladder = 2,
    ESourceEffectFil_V____G6____X2 = 3
};

enum ESourceEffectFilterParam : uint8_t
{
    ESourceEffectFilterParam__FilterFrequency = 0,
    ESourceEffectFilterParam__FilterResonance = 1,
    ESourceEffectFilterParam__Count = 2
};

enum EStereoChannelMode : uint8_t
{
    EStereoChannelMode__MidSide = 0,
    EStereoChannelMode__LeftRight = 1,
    EStereoChannelMode__count = 2
};

enum ESourceEffectMotionFilterModSource : uint8_t
{
    ESourceEffectMotionFilterModSource__DistanceFromListener = 0,
    ESourceEffectMotionFilterModSource__SpeedRelativeToListener = 1,
    ESourceEffectMotionFilterModSource__SpeedOfSourceEmitter = 2,
    ESourceEffectMotionFilterModSource__SpeedOfListener = 3,
    ESourceEffectMotionFilterModSource__SpeedOfAngleDelta = 4,
    ESourceEffectMotionFilterModSource__Count = 5
};

enum ESourceEffectMotionFilterModDestination : uint8_t
{
    ESourceEffectMotionFilterModDestination__FilterACutoffFrequency = 0,
    ESourceEffectMotionFilterModDestination__FilterAResonance = 1,
    ESourceEffectMotionFilterModDestination__FilterAOutputVolumeDB = 2,
    ESourceEffectMotionFilterModDestination__FilterBCutoffFrequency = 3,
    ESourceEffectMotionFilterModDestination__FilterBResonance = 4,
    ESourceEffectMotionFilterModDestination__FilterBOutputVolumeDB = 5,
    ESourceEffectMotionFilterModDestination__FilterMix = 6,
    ESourceEffectMotionFilterModDestination__Count = 7
};

enum ESourceEffectMotionFilterTopology : uint8_t
{
    ESourceEffectMotionFilterTopology__SerialMode = 0,
    ESourceEffectMotionFilterTopology__ParallelMode = 1,
    ESourceEffectMotionFilterTopology__Count = 2
};

enum ESourceEffectMotionFilterCircuit : uint8_t
{
    ESourceEffectMotionFilterCircuit__OnePole = 0,
    ESourceEffectMotionFilterCircuit__StateVariable = 1,
    ESourceEffectMotionFilterCircuit__Ladder = 2,
    ESourceEffectMotionFilterCircuit__Count = 3
};

enum EPhaserLFOType : uint8_t
{
    EPhaserLFOType__Sine = 0,
    EPhaserLFOType__UpSaw = 1,
    EPhaserLFOType__DownSaw = 2,
    EPhaserLFOType__Square = 3,
    EPhaserLFOType__Triangle = 4,
    EPhaserLFOType__Exponential = 5,
    EPhaserLFOType__RandomSampleHold = 6,
    EPhaserLFOType__Count = 7
};

enum EStereoDelaySourceEffect : uint8_t
{
    EStereoDelaySourceEffect__Normal = 0,
    EStereoDelaySourceEffect__Cross = 1,
    EStereoDelaySourceEffect__PingPong = 2,
    EStereoDelaySourceEffect__Count = 3
};

enum ESubmixFilterAlgorithm : uint8_t
{
    ESubmixFilterAlgorithm__OnePole = 0,
    ESubmixFilterAlgorithm__StateVariable = 1,
    ESubmixFilterAlgorithm__Ladder = 2,
    ESubmixFilterAlgorithm__Count = 3
};

enum ETapLineMode : uint8_t
{
    ETapLineMode__SendToChannel = 0,
    ETapLineMode__Panning = 1,
    ETapLineMode__Disabled = 2
};

enum EGranularSynthEnvelopeType : uint8_t
{
    EGranularSynthEnvelopeType__Rectangular = 0,
    EGranularSynthEnvelopeType__Triangle = 1,
    EGranularSynthEnvelopeType__DownwardTriangle = 2,
    EGranularSynthEnvelopeType__UpwardTriangle = 3,
    EGranularSynthEnvelopeType__ExponentialDecay = 4,
    EGranularSynthEnvelopeType__ExponentialIncrease = 5,
    EGranularSynthEnvelopeType__Gaussian = 6,
    EGranularSynthEnvelopeType__Hanning = 7,
    EGranularSynthEnvelopeType__Lanczos = 8,
    EGranularSynthEnvelopeType__Cosine = 9,
    EGranularSynthEnvelopeType__CosineSquared = 10,
    EGranularSynthEnvelopeType__Welch = 11,
    EGranularSynthEnvelopeType__Blackman = 12,
    EGranularSynthEnvelopeType__BlackmanHarris = 13,
    EGranularSynthEnvelopeType__Count = 14
};

enum EGranularSynthSeekType : uint8_t
{
    EGranularSynthSeekType__FromBeginning = 0,
    EGranularSynthSeekType__FromCurrentPosition = 1,
    EGranularSynthSeekType__Count = 2
};

enum CurveInterpolationType : uint8_t
{
    CurveInterpolationType__AUTOINTERP = 0,
    CurveInterpolationType__LINEAR = 1,
    CurveInterpolationType__CONSTANT = 2
};

enum ESamplePlayerSeekType : uint8_t
{
    ESamplePlayerSeekType__FromBeginning = 0,
    ESamplePlayerSeekType__FromCurrentPosition = 1,
    ESamplePlayerSeekType__FromEnd = 2,
    ESamplePlayerSeekType__Count = 3
};

enum ESynthKnobSize : uint8_t
{
    ESynthKnobSize__Medium = 0,
    ESynthKnobSize__Large = 1,
    ESynthKnobSize__Count = 2
};

enum ESynthSlateSizeType : uint8_t
{
    ESynthSlateSizeType__Small = 0,
    ESynthSlateSizeType__Medium = 1,
    ESynthSlateSizeType__Large = 2,
    ESynthSlateSizeType__Count = 3
};

enum ESynthSlateColorStyle : uint8_t
{
    ESynthSlateColorStyle__Light = 0,
    ESynthSlateColorStyle__Dark = 1,
    ESynthSlateColorStyle__Count = 2
};

enum EFortMetaSoundAutoInterfaceTypes : uint8_t
{
    EFortMetaSoundAutoInterfaceTypes__None = 0,
    EFortMetaSoundAutoInterfaceTypes__Movement = 1,
    EFortMetaSoundAutoInterfaceTypes__Time = 2,
    EFortMetaSoundAutoInterfaceTypes__ActiveSound = 4
};

enum EFortAudioAffiliation : uint8_t
{
    EFortAudioAffiliation__Local = 0,
    EFortAudioAffiliation__Friendly = 1,
    EFortAudioAffiliation__Enemy = 2,
    EFortAudioAffiliation__Neutral = 3
};

enum EAmbientAudioEntryActionType : uint8_t
{
    EAmbientAudioEntryActionType__Added = 0,
    EAmbientAudioEntryActionType__Updated = 1,
    EAmbientAudioEntryActionType__Removed = 2,
    EAmbientAudioEntryActionType__Count = 3
};

enum EAmbientAudioTagActionType : uint8_t
{
    EAmbientAudioTagActionType__Added = 0,
    EAmbientAudioTagActionType__Removed = 1,
    EAmbientAudioTagActionType__Count = 2
};

enum EAudioShapeComponentState : uint8_t
{
    EAudioShapeComponentState__Inactive = 0,
    EAudioShapeComponentState__Active = 1,
    EAudioShapeComponentState__Count = 2
};

enum UCPTypes : uint8_t
{
    UCPTypes__UCPAudio = 0,
    UCPTypes__UCPVideo = 1,
    UCPTypes__UCPBoth = 2,
    UCPTypes__UCPNone = 3
};

enum EBaseMediaTerminalErrorReason : uint8_t
{
    EBaseMediaTerminalErrorReason__Unknown = 0,
    EBaseMediaTerminalErrorReason__None = 1,
    EBaseMediaTerminalErrorReason__ClosedE_L__ = 2,
    EBaseMediaTerminalErrorReason__OpenTimeout = 3,
    EBaseMediaTerminalErrorReason__OpenFailed = 4,
    EBaseMediaTerminalErrorReason__Source = 5,
    EBaseMediaTerminalErrorReason__UCP = 6
};

enum EEpicMediaPriorityType : uint8_t
{
    EEpicMediaPriorityType__Primary = 0,
    EEpicMediaPriorityType__Secondary = 1,
    EEpicMediaPriorityType__Music = 2
};

enum EBaseMediaDelayAction : uint8_t
{
    EBaseMediaDelayAction__Open = 0,
    EBaseMediaDelayAction__Stop = 1,
    EBaseMediaDelayAction__Start = 2
};

enum EBaseMediaPlayerState : uint8_t
{
    EBaseMediaPlayerState__None = 0,
    EBaseMediaPlayerState__Released = 1,
    EBaseMediaPlayerState__Stopped = 2,
    EBaseMediaPlayerState__Started = 3,
    EBaseMediaPlayerState__Opened = 4,
    EBaseMediaPlayerState__Playing = 5,
    EBaseMediaPlayerState__Ended = 6,
    EBaseMediaPlayerState__Error = 7
};

enum ESoundModulationLFOShape : uint8_t
{
    ESoundModulationLFOShape__Sine = 0,
    ESoundModulationLFOShape__UpSaw = 1,
    ESoundModulationLFOShape__DownSaw = 2,
    ESoundModulationLFOShape__Square = 3,
    ESoundModulationLFOShape__Triangle = 4,
    ESoundModulationLFOShape__Exponential = 5,
    ESoundModulationLFOShape__RandomSampleHold = 6,
    ESoundModulationLFOShape__COUNT = 7
};

enum EConversationTaskResultType : uint8_t
{
    EConversationTaskResultType__Invalid = 0,
    EConversationTaskResultType__AbortConversation = 1,
    EConversationTaskResultType__AdvanceConversation = 2,
    EConversationTaskResultType__AdvanceConversationWithChoice = 3,
    EConversationTaskResultType__PauseConversationAndSendClientChoices = 4,
    EConversationTaskResultType__ReturnToLastClientChoice = 5,
    EConversationTaskResultType__ReturnToCurrentClientChoice = 6,
    EConversationTaskResultType__ReturnToConversationStart = 7
};

enum EConversationRequirementResult : uint8_t
{
    EConversationRequirementResult__Passed = 0,
    EConversationRequirementResult__FailedButVisible = 1,
    EConversationRequirementResult__FailedAndHidden = 2
};

enum EConversationChoiceType : uint8_t
{
    EConversationChoiceType__ServerOnly = 0,
    EConversationChoiceType__UserChoiceAvailable = 1,
    EConversationChoiceType__UserChoiceUnavailable = 2
};

enum ESwitchOffConditionDistanceOp : uint8_t
{
    ESwitchOffConditionDistanceOp__LessThan = 0,
    ESwitchOffConditionDistanceOp__GreaterThan = 1
};

enum ESwitchOffConditionDistanceAxesType : uint8_t
{
    ESwitchOffConditionDistanceAxesType__AllAxes = 0,
    ESwitchOffConditionDistanceAxesType__IgnoreZAxis = 1,
    ESwitchOffConditionDistanceAxesType__OnlyZAxis = 2
};

enum ESwitchOffConditionAngleOp : uint8_t
{
    ESwitchOffConditionAngleOp__LessThan = 0,
    ESwitchOffConditionAngleOp__GreaterThan = 1
};

enum ESwitchOffConditionCompositeOp : uint8_t
{
    ESwitchOffConditionCompositeOp__Or = 0,
    ESwitchOffConditionCompositeOp__And = 1
};

enum EAttributeBasedRootMotionMode : uint8_t
{
    EAttributeBasedRootMotionMode__ApplyDelta = 0,
    EAttributeBasedRootMotionMode__ApplyVelocity = 1
};

enum EWarpTargetLocationOffsetDirection : uint8_t
{
    EWarpTargetLocationOffsetDirection__TargetsForwardVector = 0,
    EWarpTargetLocationOffsetDirec_t_c__________________y_E____ = 1,
    EWarpTargetLocationOffsetDirection__WorldSpace = 2
};

enum EMotionWarpRotationType : uint8_t
{
    EMotionWarpRotationType__Default = 0,
    EMotionWarpRotationType__Facing = 1,
    EMotionWarpRotationType__OppositeDefault = 2
};

enum EMotionWarpRotationMethod : uint8_t
{
    EMotionWarpRotationMethod__Slerp = 0,
    EMotionWarpRotationMethod__SlerpWithClampedRate = 1,
    EMotionWarpRotationMethod__ConstantRate = 2
};

enum EWarpPointAnimProvider : uint8_t
{
    EWarpPointAnimProvider__None = 0,
    EWarpPointAnimProvider__Static = 1,
    EWarpPointAnimProvider__Bone = 2
};

enum EContextualAnimCollisionBehavior : uint8_t
{
    EContextualAnimCollisionBehavior__None = 0,
    EContextualAnimCollisionBehavior__IgnoreActorWhenMoving = 1,
    EContextualAnimCollisionBehavior__IgnoreChannels = 2
};

enum EContextualAnimPointType : uint8_t
{
    EContextualAnimPointType__FirstFrame = 0,
    EContextualAnimPointType__SyncFrame = 1,
    EContextualAnimPointType__LastFrame = 2
};

enum EContextualAnimCriterionToConsider : uint8_t
{
    EContextualAnimCriterionToConsider__All = 0,
    EContextualAnimCriterionToConsider__Spatial = 1,
    EContextualAnimCriterionToConsider__Other = 2
};

enum EContextualAnimCriterionType : uint8_t
{
    EContextualAnimCriterionType__Spatial = 0,
    EContextualAnimCriterionType__Other = 1
};

enum EContextualAnimCriterionConeMode : uint8_t
{
    EContextualAnimCriterionConeMode__ToPrimary = 0,
    EContextualAnimCriterionConeMode__FromPrimary = 1
};

enum EContextualAnimCriterionDistanceMode : uint8_t
{
    EContextualAnimCriterionDistanceMode__Distance_3D = 0,
    EContextualAnimCriterionDistanceMode__Distance_2D = 1
};

enum EContextualAnimJoinRule : uint8_t
{
    EContextualAnimJoinRule__Default = 0,
    EContextualAnimJoinRule__Late = 1
};

enum EContextualAnimIKTargetProvider : uint8_t
{
    EContextualAnimIKTargetProvider__Autogenerated = 0,
    EContextualAnimIKTargetProvider__Bone = 1
};

enum EContextualAnimIKTargetAlphaProvider : uint8_t
{
    EContextualAnimIKTargetAlphaProvider__AnimNotifyState = 0,
    EContextualAnimIKTargetAlphaProvider__Curve = 1,
    EContextualAnimIKTargetAlphaProvider__None = 2
};

enum EContextualAnimWarpPointDefinitionMode : uint8_t
{
    EContey____7_o__PT____________5___lY_________r___g__ = 0,
    EContextualAnimWarpPointDefinitionMode__Socket = 1,
    EContextualAnimWarpPointDefinitionMode__Custom = 2
};

enum EGameplayInteractionAbortReason : uint8_t
{
    EGameplayInteractionAbortReason__Unset = 0,
    EGameplayInteractionAbortReason__ExternalAbort = 1,
    EGameplayInteractionAbortReason__InternalAbort = 2
};

enum EGameplayInteractionModifyGameplayTagOperation : uint8_t
{
    EGameplayInteractionModifyGameplayTagOperation__Add = 0,
    EGameplayInteractionModifyGameplayTagOperation__Remove = 1
};

enum EGameplayInteractionMatchSlotTagSource : uint8_t
{
    EGameplayInteractionMatchSlotTagSource__ActivityTags = 0,
    EGameplayInteractionMatchSlotTagSource__RuntimeTags = 1
};

enum EGameplayInteractionSlotReferenceType : uint8_t
{
    EGameplayInteractionSlotReferenceType__ByActivityTag = 0,
    EGameplayInteractionSlotReferenceType__ByLinkTag = 1
};

enum EGameplayInteractionSyncSlotTransitionState : uint8_t
{
    EGameplayInteractionSyncSlotTransitionState__WaitingForFromTag = 0,
    EGameplayInteractionSyncSlotTransitionState__WaitingForToTag = 1,
    EGameplayInteractionSyncSlotTransitionState__Completed = 2
};

enum EValkyrieProjectDescriptorFileVersion : uint8_t
{
    EValkyrieProjectDescriptorFileVersion__Invalid = 0,
    EValkyrieProjectDescriptorFileVersion__Initial = 1,
    EValkyrieProjectDescriptorFileVersion__AddProjectMetadata = 2,
    EValkyrieProjectDescriptorFileVersion__AddedCompatibilityLabel = 3,
    EValkyrieProjectDescriptorFileVersion__AddBindings = 4,
    EValkyrieProjectDescriptorFileVersion__Add__________s_C_C__ = 5,
    EValkyrieProjectDescriptorFileVersion__AddEpicApp = 6,
    EValkyrieProjectDescriptorFileVersion__AddDataSets = 7,
    EValkyrieProjectDescriptorFileVersion__AddVersionSuffix = 8,
    EValkyrieProjectDescriptorFileVersion__AddProjectKind = 9,
    EValkyrieProjectDescriptorFileVersion__AddMetaDataTags = 10,
    EValkyrieProjectDescriptorFileVersion__RevertMetaDataTags = 11,
    EValkyrieProjectDescriptorFileVersion__AddDocsUrl = 12,
    EValkyrieProjectDescriptorFileVersion__AddTemplateCategory = 13,
    EValkyrieProjectDescriptorFileVersion__BranchDependencies = 14,
    EValkyrieProjectDescriptorFileVersion__AddFeatureSet = 15,
    EValkyrieProjectDescriptorFileVersion__LatestPlusOne = 16,
    EValkyrieProjectDescriptorFileVersion__Latest = 15
};

enum EValkyrieRedirectListFormatVersion : uint8_t
{
    EValkyrieRedirectListFormatVersion__Initial = 1,
    EValkyrieRedirectListFormatVersion__CurrentVersion = 1
};

enum EVkLaunchData_StartOption : uint8_t
{
    EVkLaunchData_StartOption__Download = 0,
    EVkLaunchData_StartOption__AutoReady = 1,
    EVkLaunchData_StartOption__Max_None = 2
};

enum EConsumerRole : uint8_t
{
    EConsumerRole__Server = 0,
    EConsumerRole__Client = 1,
    EConsumerRole__Editor = 2
};

enum EVkLinkPublishMode : uint8_t
{
    EVkLinkPublishMode__Live = 0,
    EVkLinkPublishMode__Playtest = 1
};

enum EVkIdType : uint8_t
{
    EVkIdType__Account = 0,
    EVkIdType__Team = 1
};

enum EVkAutoLocalizationJobStatus : uint8_t
{
    EVkAutoLocalizationJobStatus__Pending = 0,
    EVkAutoLocalizationJobStatus__Completed = 1,
    EVkAutoLocalizationJobStatus__Error = 2
};

enum EVkModuleAccess : uint8_t
{
    EVkModuleAccess__Private = 0,
    EVkModuleAccess__Protected = 1,
    EVkModuleAccess__Public = 2
};

enum EVkModulePublishStatus : uint8_t
{
    EVkModulePublishStatus__Unreleased = 0,
    EVkModulePublishStatus__PublishedLive = 1
};

enum EVkModuleModerationSource : uint8_t
{
    EVkModuleModerationSource__System = 0,
    EVkModuleModerationSource__Manual = 1,
    EVkModuleModerationSource__Error = 2,
    EVkModuleModerationSource__AdminAction = 3,
    EVkModuleModerationSource__CommandletError = 4,
    EVkModuleModerationSource__IngestionError = 5
};

enum EVkTeamMembershipStatus : uint8_t
{
    EVkTeamMembershipStatus__Pending = 0,
    EVkTeamMembershipStatus__Accepted = 1
};

enum EVkValidationFlags : uint8_t
{
    EVkValidationFlags__None = 0,
    EVkValidationFlags__VF_IgnoreValidation = 1,
    EVkValidationFlags__VF_AllowMissingGameFeatureDataAsset = 2,
    EVkValidationFlags__VF_AllowEngineContent = 4,
    EVkValidationFlags__VF_AllowGameContent = 8,
    EVkValidationFlags__VF_NoPreCheckVerse = 16,
    EVkValidationFlags__VF_ErrorsAsWarnings = 32
};

enum EMusicalBeatType : uint8_t
{
    EMusicalBeatType__Downbeat = 0,
    EMusicalBeatType__Strong = 1,
    EMusicalBeatType__Normal = 2
};

enum EMusicTimeSpanOffsetUnits : uint8_t
{
    EMusicTimeSpanOffsetUnits__Ms = 0,
    EMusicTimeSpanOffsetUnits__Bars = 1,
    EMusicTimeSpanOffsetUnits__Beats = 2,
    EMusicTimeSpanOffsetUnits__ThirtySecondNotes = 3,
    EMusicTimeSpanOffsetUnits__SixteenthNotes = 4,
    EMusicTimeSpanOffsetUnits__EighthNotes = 5,
    EMusicTimeSpanOffsetUnits__QuarterNotes = 6,
    EMusicTimeSpanOffsetUnits__HalfNotes = 7,
    EMusicTimeSpanOffsetUnits__WholeNotes = 8,
    EMusicTimeSpanOffsetUnits__DottedSixteenthNotes = 9,
    EMusicTimeSpanOffsetUnits__DottedEighthNotes = 10,
    EMusicTimeSpanOffsetUnits__DottedQuarterNotes = 11,
    EMusicTimeSpanOffsetUnits__DottedHalfNotes = 12,
    EMusicTimeSpanOffsetUnits__DottedWholeNotes = 13,
    EMusicTimeSpanOffsetUnits__SixteenthNoteTriplets = 14,
    EMusicTimeSpanOffsetUnits__EighthNoteTriplets = 15,
    EMusicTimeSpanOffsetUnits__QuarterNoteTriplets = 16,
    EMusicTimeSpanOffsetUnits__HalfNoteTriplets = 17
};

enum EMidiFileQuantizeDirection : uint8_t
{
    EMidiFileQuantizeDirection__Nearest = 0,
    EMidiFileQuantizeDirection__Up = 1,
    EMidiFileQuantizeDirection__Down = 2
};

enum EMidiClockSubdivisionQuantization : uint8_t
{
    EMidiClockSubdivisionQuantization__Bar = 0,
    EMidiClockSubdivisionQuantization__Beat = 1,
    EMidiClockSubdivisionQuantization__ThirtySecondNote = 2,
    EMidiClockSubdivisionQuantization__SixteenthNote = 3,
    EMidiClockSubdivisionQuantization__EighthNote = 4,
    EMidiClockSubdivisionQuantization__QuarterNote = 5,
    EMidiClockSubdivisionQuantization__HalfNote = 6,
    EMidiClockSubdivisionQuantization__WholeNote = 7,
    EMidiClockSubdivisionQuantization__DottedSixteenthNote = 8,
    EMidiClockSubdivisionQuantization__DottedEighthNote = 9,
    EMidiClockSubdivisionQuantization__DottedQuarterNote = 10,
    EMidiClockSubdivisionQuantization__DottedHalfNote = 11,
    EMidiClockSubdivisionQuantization__DottedWholeNote = 12,
    EMidiClockSubdivisionQuantization__SixteenthNoteTriplet = 13,
    EMidiClockSubdivisionQuantization__EighthNoteTriplet = 14,
    EMidiClockSubdivisionQuantization__QuarterNoteTriplet = 15,
    EMidiClockSubdivisionQuantization__HalfNoteTriplet = 16,
    EMidiClockSubdivisionQuantization__None = 19
};

enum EFusionPatchAudioLoadResult : uint8_t
{
    EFusionPatchAudioLoadResult__Success = 0,
    EFusionPatchAudioLoadResult__Fail = 1,
    EFusionPatchAu_____I__J____R___as____x = 2
};

enum EBiquadFilterType : uint8_t
{
    EBiquadFilterType__LowPass = 0,
    EBiquadFilterType__HighPass = 1,
    EBiquadFilterType__BandPass = 2,
    EBiquadFilterType__Peaking = 3,
    EBiquadFilterType__LowShelf = 4,
    EBiquadFilterType__HighShelf = 5,
    EBiquadFilterType__Num = 6,
    EBiquadFilterType__None = 7
};

enum EDelayStereoType : uint8_t
{
    EDelayStereoType__Default = 0,
    EDelayStereoType__CustomSpread = 1,
    EDelayStereoType__PingPongForceLR = 2,
    EDelayStereoType__PingPongSum = 3,
    EDelayStereoType__PingPongIndividual = 4,
    EDelayStereoType__Num = 5
};

enum EDistortionTypeV1 : uint8_t
{
    EDistortionTypeV1__Clean = 0,
    EDistortionTypeV1__Warm = 1,
    EDistortionTypeV1__Dirty = 2,
    EDistortionTypeV1__Soft = 3,
    EDistortionTypeV1__Asymmetric = 4,
    EDistortionTypeV1__Num = 5
};

enum EDistortionTypeV2 : uint8_t
{
    EDistortionTypeV2__Clean = 0,
    EDistortionTypeV2__Warm = 1,
    EDistortionTypeV2__Clip = 2,
    EDistortionTypeV2__Soft = 3,
    EDistortionTypeV2__Asymmetric = 4,
    EDistortionTypeV2__Cruncher = 5,
    EDistortionTypeV2__CaptCrunch = 6,
    EDistortionTypeV2__Rectifier = 7,
    EDistortionTypeV2__Num = 8
};

enum EKeyzoneSelectMode : uint8_t
{
    EKeyzoneSelectMode__Layers = 0,
    EKeyzoneSelectMode__Random = 1,
    EKeyzoneSelectMode__RandomWithRepetition = 2,
    EKeyzoneSelectMode__Cycle = 3,
    EKeyzoneSelectMode__Num = 4,
    EKeyzoneSelectMode__Invalid = 5
};

enum EWaveShape : uint8_t
{
    EWaveShape__Sine = 0,
    EWaveShape__Square = 1,
    EWaveShape__SawUp = 2,
    EWaveShape__SawDown = 3,
    EWaveShape__Triangle = 4,
    EWaveShape__Random = 5,
    EWaveShape__Num = 6,
    EWaveShape__None = 7
};

enum EPannerMode : uint8_t
{
    EPannerMode__LegacyStereo = 0,
    EPannerMode__Stereo = 1,
    EPannerMode__Surround = 2,
    EPannerMode__PolarSurround = 3,
    EPannerMode__DirectAssignment = 4,
    EPannerMode__Num = 5,
    EPannerMode__Invalid = 6
};

enum EParameterType : uint8_t
{
    EParameterType__Bool = 0,
    EParameterType__Double = 1,
    EParameterTy___MD____ = 2,
    EParameterType__Int8 = 3,
    EParameterType__Int16 = 4,
    EParameterType__Int32 = 5,
    EParameterType__Int64 = 6,
    EParameterType__Name = 7,
    EParameterType__String = 8,
    EParameterType__UInt8 = 9,
    EParameterType__UInt16 = 10,
    EParameterType__UInt32 = 11,
    EParameterType__UInt64 = 12,
    EParameterType__Num = 13,
    EParameterType__Invalid = 14
};

enum EVocoderBandConfig : uint8_t
{
    EVocoderBandConfig__k4 = 0,
    EVocoderBandConfig__k8 = 1,
    EVocoderBandConfig__k16 = 2,
    EVocoderBandConfig__k32 = 3,
    EVocoderBandConfig__k64 = 4,
    EVocoderBandConfig__k128 = 5,
    EVocoderBandConfig__k256 = 6,
    EVocoderBandConfig__Num = 7,
    EVocoderBandConfig__None = 8
};

enum EMusicTimeDiscontinuityType : uint8_t
{
    EMusicTimeDiscontinuityType__Loop = 0,
    EMusicTimeDiscontinuityType__Seek = 1
};

enum EMusicClockState : uint8_t
{
    EMusicClockState__Stopped = 0,
    EMusicClockState__Paused = 1,
    EMusicClockState__Running = 2
};

enum ESeekPointType : uint8_t
{
    ESeekPointType__BarBeat = 0,
    ESeekPointType__Millisecond = 1
};

enum EMusicClockDriveMethod : uint8_t
{
    EMusicClockDriveMethod__WallClock = 0,
    EMusicClockDriveMethod__MetaSound = 1
};

enum EMeshNetworkRelevancy : uint8_t
{
    EMeshNetworkRelevancy__NotRelevant = 0,
    EMeshNetworkRelevancy__RelevantToEdgeNodes = 1,
    EMeshNetworkRelevancy__RelevantToClients = 2
};

enum ESpatialMetricsConnectorResponseCode : uint8_t
{
    ESpatialMetricsConnectorResponseCode__Pending = 0,
    ESpatialMetricsConnectorResponseCode__Success = 1,
    ESpatialMetricsConnectorResponseCode__Failed = 2,
    ESpatialMetricsConnectorResponseCode__InvalidRequest = 3,
    ESpatialMetricsConnectorResponseCode__UnknownRequest = 4,
    ESpatialMetricsConnectorResponseCode__TimedOut = 5
};

enum EMotionMatchingInteractionEvaluationMode : uint8_t
{
    EMotionMatchingInteractionEvaluationMode__ContinuousReselection = 0,
    EMotionMatchingInteractionEvaluationMode__SingleSelection = 1
};

enum EPoseSearchAssetSamplerSpace : uint8_t
{
    EPoseSearchAssetSamplerSpace__Local = 0,
    EPoseSearchAssetSamplerSpace__Component = 1,
    EPoseSearchAssetSamplerSpace__World = 2
};

enum EPoseSearchMode : uint8_t
{
    EPoseSearchMode__BruteForce = 0,
    EPoseSearchMode__PCAKDTree = 1,
    EPoseSearchMode__VPTree = 2
};

enum EPoseSearchMirrorOption : uint8_t
{
    EPoseSearchMirrorOption__UnmirroredOnly = 0,
    EPoseSearchMirrorOption__MirroredOnly = 1,
    EPoseSearchMirrorOption__UnmirroredAndMirrored = 2
};

enum EComponentStrippingVector : uint8_t
{
    EComponentStrippingVector__None = 0,
    EComponentStrippingVector__StripXY = 1,
    EComponentStrippingVector__StripZ = 2
};

enum EInputQueryPose : uint8_t
{
    EInputQueryPose__UseCharacterPose = 0,
    EInputQueryPose__UseContinuingPose = 1
};

enum EPermutationTimeType : uint8_t
{
    EPermutationTimeType__UseSampleTime = 0,
    EPermutationTimeType__UsePermutationTime = 1,
    EPermutationTimeType__UseSampleToPermutationTime = 2
};

enum EPoseSearchTrajectoryFlags : uint8_t
{
    EPoseSearchTrajectoryFlags__Velocity = 1,
    EPoseSearchTrajectoryFlags__Position = 2,
    EPoseSearchTrajectoryFlags__VelocityDirection = 4,
    EPoseSearchTrajectoryFlags__FacingDirection = 8,
    EPoseSearchTrajectoryFlags__VelocityXY = 16,
    EPoseSearchTrajectoryFlags__PositionXY = 32,
    EPoseSearchTrajectoryFlags__VelocityDirectionXY = 64,
    EPoseSearchTrajectoryFlags__FacingDirectionXY = 128
};

enum ECosmeticsEventBindingFlags : uint8_t
{
    ECosmeticsEventBindingFlags__None = 0,
    ECosmeticsEventBindingFlags__ExecuteImmediately = 2,
    ECosmeticsEventBindingFlags__ExecuteOnce = 4
};

enum EMusicEventResolutionRule : uint8_t
{
    EMusicEventResolutionRule__NewestWins = 0,
    EMusicEventResolutionRule__OldestWins = 1,
    EMusicEventResolutionRule__ClosestWins = 2
};

enum EGameplayBehaviorInstantiationPolicy : uint8_t
{
    EGameplayBehaviorInstantiationPolicy__Instantiate = 0,
    EGameplayBehaviorInstantiationPolicy__ConditionallyInstantiate = 1,
    EGameplayBehaviorInstantiationPolicy__DontInstantiate = 2
};

enum EChaosCacheInterpolationMode : uint8_t
{
    EChaosCacheInterpolationMode__QuatInterp = 0,
    EChaosCacheInterpolationMode__EulerInterp = 1,
    EChaosCacheInterpolationMode__DualQuatInterp = 2
};

enum ECacheMode : uint8_t
{
    ECacheMode__None = 0,
    ECacheMode__Play = 1,
    ECacheMode__Record = 2
};

enum EStartMode : uint8_t
{
    EStartMode__Timed = 0,
    EStartMode__Triggered = 1
};

enum EChaosWeightMapTarget : uint8_t
{
    EChaosWeightMapTarget__None = 0,
    EChaosWeightMapTarget__MaxDistance = 1,
    EChaosWeightMapTarget__BackstopDistance = 2,
    EChaosWeightMapTarget__BackstopRadius = 3,
    EChaosWeightMapTarget__AnimDriveStiffness = 4,
    EChaosWeightMapTarget__TetherEndsMask = 201,
    EChaosWeightMapTarget__AnimDriveDamping = 5,
    EChaosWeightMapTarget__TetherStiffness = 6,
    EChaosWeightMapTarget__TetherScale = 7,
    EChaosWeightMapTarget__Drag = 8,
    EChaosWeightMapTarget__Lift = 9,
    EChaosWeightMapTarget__EdgeStiffness = 10,
    EChaosWeightMapTarget__BendingStiffness = 11,
    EChaosWeightMapTarget__AreaStiffness = 12,
    EChaosWeightMapTarget__BucklingStiffness = 13,
    EChaosWeightMapTarget__Pressure = 14,
    EChaosWeightMapTarget__FlatnessRatio = 15,
    EChaosWeightMapTarget__OuterDrag = 16,
    EChaosWeightMapTarget__OuterLift = 17
};

enum EVehicleSimStepFlags : uint8_t
{
    EVehicleSimStepFlags__None = 0,
    EVehicleSimStepFlags__ServerEnabled = 1,
    EVehicleSimStepFlags__LocalClientEnabled = 2,
    EVehicleSimStepFlags__RemoteClientEnabled = 4,
    EVehicleSimStepFlags__RemoteDisabled = 3,
    EVehicleSimStepFlags__AllEnabled = 7
};

enum ETraceDirection : uint8_t
{
    ETraceDirection__N = 0,
    ETraceDirection__E = 1,
    ETraceDirection__S = 2,
    ETraceDirection__W = 3,
    ETraceDirection__Up = 4,
    ETraceDirection__None = 5
};

enum EAESGCMNetResult : uint8_t
{
    EAESGCMNetResult__Unknown = 0,
    EAESGCMNetResult__Success = 1,
    EAESGCMNetResult__AESMissingIV = 2,
    EAESGCMNetResult__AESMissingAuthTag = 3,
    EAESGCMNetResult__AESMissingPayload = 4,
    EAESGCMNetResult__AESDecryptionFailed = 5,
    EAESGCMNetResult__AESZeroLastByte = 6
};

enum EDSSReplayResult : uint8_t
{
    EDSSReplayResult__Success = 0,
    EDSSReplayResult__FailedJsonParse = 1,
    EDSSReplayResult__DataUnavailable = 2,
    EDSSReplayResult__InvalidHttpResponse = 3,
    EDSSReplayResult__CompressionFailed = 4,
    EDSSReplayResult__InvalidPayload = 5,
    EDSSReplayResult__Unknown = 6
};

enum EGfeSDKReturnCode : uint8_t
{
    EGfeSDKReturnCode__Success = 0,
    EGfeSDKReturnCode__SuccessIpcOldSdk = 1,
    EGfeSDKReturnCode__SuccessIpcOldGfe = 2,
    EGfeSDKReturnCode__Error = 3,
    EGfeSDKReturnCode__ErrorGfeVersion = 4,
    EGfeSDKReturnCode__ErrorSdkVersion = 5,
    EGfeSDKReturnCode__ErrorModuleNotLoaded = 6
};

enum EGfeSDKPermission : uint8_t
{
    EGfeSDKPermission__Granted = 0,
    EGfeSDKPermission__Denied = 1,
    EGfeSDKPermission__MustAsk = 2,
    EGfeSDKPermission__Unknown = 3
};

enum EGfeSDKHighlightSignificance : uint8_t
{
    EGfeSDKHighlightSignificance__NONE = 0,
    EGfeSDKHighlightSignificance__ExtremelyBad = 1,
    EGfeSDKHighlightSignificance__VeryBad = 2,
    EGfeSDKHighlightSignificance__Bad = 4,
    EGfeSDKHighlightSignificance__Neutral = 8,
    EGfeSDKHighlightSignificance__Good = 16,
    EGfeSDKHighlightSignificance__VeryGood = 32,
    EGfeSDKHighlightSignificance__ExtremelyGood = 64
};

enum ECoordinatorFlowState : uint8_t
{
    ECoordinatorFlowState__NONE = 0,
    ECoordinatorFlowState__Initializing = 1,
    ECoordinatorFlowState__WaitingForRequest = 2,
    ECoordinatorFlowState__WaitingForConsensus_BeginChange = 3,
    ECoordinatorFlowState__WaitingForConsensus_Precommit = 4,
    ECoordinatorFlowState__Consensus_Success = 5,
    ECoordinatorFlowState__Consensus_Failed = 6
};

enum EPhaseCommit : uint8_t
{
    EPhaseCommit__One = 0,
    EPhaseCommit__Two = 1,
    EPhaseCommit__Three = 2
};

enum ECoordinatorBroadcasts : uint8_t
{
    ECoordinatorBroadcasts__ReadyForRequests = 0,
    ECoordinatorBroadcasts__BeginStateChange_TwoPhase = 1,
    ECoordinatorBroadcasts__BeginStateChange_ThreePhase = 2,
    ECoordinatorBroadcasts__PreCommit = 3,
    ECoordinatorBroadcasts__Success = 4,
    ECoordinatorBroadcasts__Aborted = 5,
    ECoordinatorBroadcasts__NUM = 6
};

enum ECoordinatorBroadcasts_Repl : uint8_t
{
    ECoordinatorBroadcasts_Repl__R = 0,
    ECoordinatorBroadcasts_Repl__A = 1,
    ECoordinatorBroadcasts_Repl__B = 2,
    ECoordinatorBroadcasts_Repl__C = 3,
    ECoordinatorBroadcasts_Repl__S = 4,
    ECoordinatorBroadcasts_Repl__F = 5,
    ECoordinatorBroadcasts_Repl__NUM = 6
};

enum EParticipantResponses : uint8_t
{
    EParticipantResponses__NONE = 0,
    EParticipantResponses__AcceptedBegin = 1,
    EParticipantResponses__RejectedBegin = 2,
    EParticipantResponses__AcceptedPreCommit = 3,
    EParticipantResponses__RejectedPreCommit = 4,
    EParticipantResponses__ReceivedSuccess = 5,
    EParticipantResponses__ReceivedAbort = 6,
    EParticipantResponses__NUM = 7
};

enum EParticipantResponses_Repl : uint8_t
{
    EParticipantResponses_Repl__N = 0,
    EParticipantResponses_Repl__A = 1,
    EParticipantResponses_Repl__B = 2,
    EParticipantResponses_Repl__C = 3,
    EParticipantResponses_Repl__D = 4,
    EParticipantResponses_Repl__S = 5,
    EParticipantResponses_Repl__F = 6,
    EParticipantResponses_Repl__NUM = 7
};

enum EDLSSSettingOverride : uint8_t
{
    EDLSSSettingOverride__Enabled = 0,
    EDLSSSettingOverride__Disabled = 1,
    EDLSSSettingOverride__UseProjectSettings = 2
};

enum EStreamlineSettingOverride : uint8_t
{
    EStreamlineSettingOverride__Enabled = 0,
    EStreamlineSettingOverride__Disabled = 1,
    EStreamlineSettingOverride__UseProjectSettings = 2
};

enum EStanceMode : uint8_t
{
    EStanceMode__Invalid = 0,
    EStanceMode__Crouch = 1,
    EStanceMode__Prone = 2
};

enum EMoveMixMode : uint8_t
{
    EMoveMixMode__AdditiveVelocity = 0,
    EMoveMixMode__OverrideVelocity = 1,
    EMoveMixMode__OverrideAll = 2
};

enum ELayeredMove_ConstantVelocitySettingsFlags : uint8_t
{
    ELayeredMove_ConstantVelocitySettingsFlags__NoFlags = 0,
    ELayeredMove_ConstantVelocitySettingsFlags__VelocityStartRelative = 1,
    ELayeredMove_ConstantVelocitySettingsFlags__VelocityAlwaysRelative = 2
};

enum ELayeredMoveFinishVelocityMode : uint8_t
{
    ELayeredMoveFinishVelocityMode__MaintainLastRootMotionVelocity = 0,
    ELayeredMoveFinishVelocityMode__SetVelocity = 1,
    ELayeredMoveFinishVelocityMode__ClampVelocity = 2
};

enum EMoveInputType : uint8_t
{
    EMoveInputType__Invalid = 0,
    EMoveInputType__DirectionalIntent = 1,
    EMoveInputType__Velocity = 2
};

enum EMoverSmoothingMode : uint8_t
{
    EMoverSmoothu__6_Oi_9__K_ = 0,
    EMoverSmoothingMode__VisualComponentOffset = 1
};

enum EDaySequenceModifierMode : uint8_t
{
    EDaySequenceModifierMode__Global = 0,
    EDaySequenceModifierMode__Volume = 1
};

enum EClothAssetAsyncProperties : uint8_t
{
    EClothAssetAsyncProperties__None = 0,
    EClothAssetAsyncProperties__RenderData = 1,
    EClothAssetAsyncProperties__ThumbnailInfo = 2,
    EClothAssetAsyncProperties__ImportedModel = 4,
    EClothAssetAsyncProperties__ClothCollection = 8,
    EClothAssetAsyncProperties__RefSkeleton = 16,
    EClothAssetAsyncProperties__All = -1
};

enum EEpicLeaderboardDataType : uint8_t
{
    EEpicLeaderboardDataType__Integer = 0,
    EEpicLeaderboardDataType__Double = 1
};

enum EEpicLeaderboardTimeWindow : uint8_t
{
    EEpicLeaderboardTimeWindow__Daily = 0,
    EEpicLeaderboardTimeWindow__Weekly = 1,
    EEpicLeaderboardTimeWindow__Monthly = 2,
    EEpicLeaderboardTimeWindow__AllTime = 3
};

enum ELiveLinkCameraProjectionMode : uint8_t
{
    ELiveLinkCameraProjectionMode__Perspective = 0,
    ELiveLinkCameraProjectionMode__Orthographic = 1
};

enum ELiveLinkSourceMode : uint8_t
{
    ELiveLinkSourceMode__Latest = 0,
    ELiveLinkSourceMode__EngineTime = 1,
    ELiveLinkSourceMode__Timecode = 2
};

enum EAthenaGameMessageDataFlags : uint8_t
{
    EAthenaGameMessageDataFlags__None = 0,
    EAthenaGameMessageDataFlags__DisableCreativeExclamation = 1
};

enum EAthenaGameMsgType : uint8_t
{
    EAthenaGameMsgType__None = 0,
    EAthenaGameMsgType__DefaultIntro = 1,
    EAthenaGameMsgType__DefaultMessage = 2,
    EAthenaGameMsgType__DefaultCriticalMessage = 3,
    EAthenaGameMsgType__CommIntro = 4,
    EAthenaGameMsgType__CommMessage = 5,
    EAthenaGameMsgType__CommCriticalMessage = 6,
    EAthenaGameMsgType__CornerIntro = 7,
    EAthenaGameMsgType__CornerMessage = 8,
    EAthenaGameMsgType__CornerCriticalMessage = 9,
    EAthenaGameMsgType__RespawnTurningOffWarning = 10,
    EAthenaGameMsgType__RespawnOffWarning = 11,
    EAthenaGameMsgType__CenterMessage = 12,
    EAthenaGameMsgType__CenterImportantMessage = 13,
    EAthenaGameMsgType__CenterCriticalMessage = 14
};

enum EUraniumRoundPhase : uint8_t
{
    EUraniumRoundPhase__None = 0,
    EUraniumRoundPhase__EndOfRoundStart = 1,
    EUraniumRoundPhase__ShowRoundEnd = 2,
    EUraniumRoundPhase__HideRoundEnd = 3,
    EUraniumRoundPhase__FadeOut = 4,
    EUraniumRoundPhase__SetupForNextRound = 5,
    EUraniumRoundPhase__ShowRoundIntro = 6,
    EUraniumRoundPhase__ShowPOICamera = 7,
    EUraniumRoundPhase__PerkSelect = 8,
    EUraniumRoundPhase__RoundActive = 9,
    EUraniumRoundPhase__FadeIn = 10,
    EUraniumRoundPhase__EndOfRoundFinish = 11,
    EUraniumRoundPhase__FadeBeforeReleasePlayerInt_____y___ = 12,
    EUraniumRoundPhase__ReleasePlayersIntoGameplay = 13,
    EUraniumRoundPhase__EndGame = 14
};

enum EUraniumEventId : uint8_t
{
    EUraniumEventId__Intro = 0,
    EUraniumEventId__CartBecomesPushable = 1,
    EUraniumEventId__CheckPointReached = 2,
    EUraniumEventId__NearCheckPoint = 3,
    EUraniumEventId__NearFinalCheckPoint = 4,
    EUraniumEventId__TimeIsLow = 5,
    EUraniumEventId__TimeIsExtraLow = 6,
    EUraniumEventId__OvertimeStarted = 7,
    EUraniumEventId__RoundEnd_PushersWin = 8,
    EUraniumEventId__RoundEnd_DefendersWin = 9,
    EUraniumEventId__RoundStart = 10,
    EUraniumEventId__GameEnded_AllRoundsPlayed = 11,
    EUraniumEventId__GameEndedEarly_BlowOut = 12,
    EUraniumEventId__GameEndedEarly_OutNumbered = 13
};

enum EUraniumRoundEndCondition : uint8_t
{
    EUraniumRoundEndCondition__RanOutOfTime_Or_CheckpointReached = 0,
    EUraniumRoundEndCondition__RanOutOfTime_Or_LastCheckpointReached = 1
};

enum EVehicleSeats : uint8_t
{
    EVehicleSeats__Driver = 0,
    EVehicleSeats__Passenger1 = 1,
    EVehicleSeats__Passenger2 = 2,
    EVehicleSeats__Passenger3 = 3,
    EVehicleSeats__Passenger4 = 4,
    EVehicleSeats__Passenger5 = 5,
    EVehicleSeats__Passenger6 = 6,
    EVehicleSeats__MaxCount = 7
};

enum ETireStates : uint8_t
{
    ETireStates__Default = 0,
    ETireStates__Popped = 1
};

enum EInteractionBeingAttempted : uint8_t
{
    FirstInteraction = 0,
    SecondInteraction = 1,
    AllInteraction = 2
};

enum TInteractionType : uint8_t
{
    IT_NoInteraction = 0,
    IT_Simple = 1,
    IT_LongPress = 2,
    IT_BuildingEdit = 3,
    IT_BuildingImprovement = 4,
    IT_TrapPlacement = 5
};

enum EVehicleWheelLocations : uint8_t
{
    EVehicleWheelLocations__FrontRight = 0,
    EVehicleWheelLocations__FrontLeft = 1,
    EVehicleWheelLocations__BackRight = 2,
    EVehicleWheelLocations__BackLeft = 3,
    EVehicleWheelLocations__MiddleRight = 4,
    EVehicleWheelLocations__MiddleLeft = 5,
    EVehicleWheelLocations__Max = 6
};

enum ETireSurfaces : uint8_t
{
    ETireSurfaces__Road = 0,
    ETireSurfaces__Dirt = 1,
    ETireSurfaces__Grass = 2,
    ETireSurfaces__Air = 3,
    ETireSurfaces__Water = 4
};

enum ESlotEnvironmentExposure : uint8_t
{
    ESlotEnvironmentExposure__Unknown = 0,
    ESlotEnvironmentExposure__Exposed = 1,
    ESlotEnvironmentExposure__Protected = 2
};

enum EFortMarkedActorScreenClamping : uint8_t
{
    EFortMarkedActorScreenClamping__Default = 0,
    EFortMarkedActorScreenClamping__Clamp = 1,
    EFortMarkedActorScreenClamping__ClampWhileNew = 2,
    EFortMarkedActorScreenClamping__DontClamp = 3
};

enum EFortBaseWeaponDamage : uint8_t
{
    EFortBaseWeaponDamage__Combat = 0,
    EFortBaseWeaponDamage__Environmental = 1
};

enum EFortItemType : uint8_t
{
    EFortItemType__WorldItem = 0,
    EFortItemType__Ammo = 1,
    EFortItemType__Badge = 2,
    EFortItemType__BackpackPickup = 3,
    EFortItemType__BuildingPiece = 4,
    EFortItemType__CharacterPart = 5,
    EFortItemType__Consumable = 6,
    EFortItemType__Deco = 7,
    EFortItemType__EditTool = 8,
    EFortItemType__Ingredient = 9,
    EFortItemType__ItemCache = 10,
    EFortItemType__Food = 11,
    EFortItemType__Gadget = 12,
    EFortItemType__AthenaGadget = 13,
    EFortItemType_______yH______X = 14,
    EFortItemType__SpyTechPerk = 15,
    EFortItemType__HeroAbility = 16,
    EFortItemType__MissionItem = 17,
    EFortItemType__Trap = 18,
    EFortItemType__MultiItem = 19,
    EFortItemType__Weapon = 20,
    EFortItemType__WeaponMelee = 21,
    EFortItemType__WeaponRanged = 22,
    EFortItemType__WeaponHarvest = 23,
    EFortItemType__WeaponCreativePhone = 24,
    EFortItemType__WeaponMod = 25,
    EFortItemType__WorldResource = 26,
    EFortItemType__CreativeUserPrefab = 27,
    EFortItemType__CreativePlayset = 28,
    EFortItemType__Vehicle = 29,
    EFortItemType__Npc = 30,
    EFortItemType__PlayerAugment = 31,
    EFortItemType__AccountItem = 32,
    EFortItemType__AccountResource = 33,
    EFortItemType__CollectedResource = 34,
    EFortItemType__Alteration = 35,
    EFortItemType__CardPack = 36,
    EFortItemType__Currency = 37,
    EFortItemType__Hero = 38,
    EFortItemType__Schematic = 39,
    EFortItemType__Worker = 40,
    EFortItemType__TeamPerk = 41,
    EFortItemType__PlayerTech = 42,
    EFortItemType__Token = 43,
    EFortItemType__DailyRewardScheduleToken = 44,
    EFortItemType__CodeToken = 45,
    EFortItemType__Stat = 46,
    EFortItemType__Buff = 47,
    EFortItemType__BuffCredit = 48,
    EFortItemType__Quest = 49,
    EFortItemType__Accolades = 50,
    EFortItemType__FriendChest = 51,
    EFortItemType__MedalsPunchCard = 52,
    EFortItemType__RepeatableDailiesCard = 53,
    EFortItemType__ChallengeBundle = 54,
    EFortItemType__ChallengeBundleSchedule = 55,
    EFortItemType__ChallengeBundleCompletionToken = 56,
    EFortItemType__GameplayModifier = 57,
    EFortItemType__Outpost = 58,
    EFortItemType__HomebaseNode = 59,
    EFortItemType__Defender = 60,
    EFortItemType__ConversionControl = 61,
    EFortItemType__DeployableBaseCloudSave = 62,
    EFortItemType__ConsumableAccountItem = 63,
    EFortItemType__Quota = 64,
    EFortItemType__Expedition = 65,
    EFortItemType__HomebaseBannerIcon = 66,
    EFortItemType__HomebaseBannerColor = 67,
    EFortItemType__AthenaSkyDiveContrail = 68,
    EFortItemType__PersonalVehicle = 69,
    EFortItemType__AthenaGlider = 70,
    EFortItemType__AthenaPickaxe = 71,
    EFortItemType__AthenaBackpack = 72,
    EFortItemType__CosmeticShoes = 73,
    EFortItemType__AthenaCharacter = 74,
    EFortItemType__AthenaDance = 75,
    EFortItemType__AthenaLoadingScreen = 76,
    EFortItemType__AthenaBattleBus = 77,
    EFortItemType__AthenaVehicleCosmetic = 78,
    EFortItemType__AthenaItemWrap = 79,
    EFortItemType__AthenaMusicPack = 80,
    EFortItemType__AthenaPetCosmetic = 81,
    EFortItemType__AthenaSeasonTreasure = 82,
    EFortItemType__AthenaSeason = 83,
    EFortItemType__AthenaRewardGraph = 84,
    EFortItemType__AthenaExtResource = 85,
    EFortItemType__EventDescription = 86,
    EFortItemType__AthenaEventToken = 87,
    EFortItemType__EventPurchaseTracker = 88,
    EFortItemType__CosmeticVariantToken = 89,
    EFortItemType__CampaignHeroLoadout = 90,
    EFortItemType__Playset = 91,
    EFortItemType__PrerollData = 92,
    EFortItemType__CreativePlot = 93,
    EFortItemType__PlayerSurveyToken = 94,
    EFortItemType__CosmeticLocker = 95,
    EFortItemType__BannerToken = 96,
    EFortItemType__RestedXpBoosterToken = 97,
    EFortItemType__RewardEventGraphPurchaseToken = 98,
    EFortItemType__HardcoreModifier = 99,
    EFortItemType__EventDependentItem = 100,
    EFortItemType__ItemAccessToken = 101,
    EFortItemType__STWAccoladeReward = 102,
    EFortItemType__Campsite = 103,
    EFortItemType__VictoryCrown = 104,
    EFortItemType__RealitySapling = 105,
    EFortItemType__Apparel = 106,
    EFortItemType__ApparelLayout = 107,
    EFortItemType__PlayerAugmentsPersistence = 108,
    EFortItemType__SparksAura = 109,
    EFortItemType__SparksGuitar = 110,
    EFortItemType__SparksBass = 111,
    EFortItemType__SparksKeyboard = 112,
    EFortItemType__SparksMicrophone = 113,
    EFortItemType__SparksDrums = 114,
    EFortItemType__SparksSpotlightAnim = 115,
    EFortItemType__SparksSong = 116,
    EFortItemType__JunoBuildingSet = 117,
    EFortItemType__JunoBuildingProp = 118,
    EFortItemType__SpecialItem = 119,
    EFortItemType__Emote = 120,
    EFortItemType__Stack = 121,
    EFortItemType__CollectionBookPage = 122,
    EFortItemType__BGAConsumableWrapper = 123,
    EFortItemType__GiftBox = 124,
    EFortItemType__GiftBoxUnlock = 125,
    EFortItemType__PlaysetProp = 126,
    EFortItemType__RegCosmeticDef = 127,
    EFortItemType__Profile = 128,
    EFortItemType__Max_None = 129
};

enum EFortGameplayState : uint8_t
{
    EFortGameplayState__NormalGameplay = 0,
    EFortGameplayState__WaitingToStart = 1,
    EFortGameplayState__EndOfZone = 2,
    EFortGameplayState__EnteringZone = 3,
    EFortGameplayState__LeavingZone = 4,
    EFortGameplayState__Invalid = 5
};

enum ESubGame : uint8_t
{
    ESubGame__Campaign = 0,
    ESubGame__Athena = 1,
    ESubGame__Invalid = 2,
    ESubGame__Count = 2,
    ESubGame__Creative = 3
};

enum EFortReportDayPhase : uint8_t
{
    EFortReportDayPhase__Dawn = 0,
    EFortReportDayPhase__Dusk = 1,
    EFortReportDayPhase__ZoneFinished = 2,
    EFortReportDayPhase__PlayerLogout = 3
};

enum EForceKickAfterDeathMode : uint8_t
{
    EForceKickAfterDeathMode__Disabled = 0,
    EForceKickAfterDeathMode__KickAll = 1,
    EForceKickAfterDeathMode__KickPrivate = 2
};

enum EFortIsFinalXpUpdate : uint8_t
{
    EFortIsFinalXpUpdate__Uninitialized = 0,
    EFortIsFinalXpUpdate__NotFinal = 1,
    EFortIsFinalXpUpdate__Final = 2
};

enum EFortTeam : uint8_t
{
    EFortTeam__Spectator = 0,
    EFortTeam__HumanCampaign = 1,
    EFortTeam__Monster = 2,
    EFortTeam__HumanPvP_Team1 = 3,
    EFortTeam__HumanPvP_Team2 = 4
};

enum EProfileCaptureType : uint8_t
{
    EProfileCaptureType__FramePro = 0,
    EProfileCaptureType__Insights = 1,
    EProfileCaptureType__Network = 2,
    EProfileCaptureType__Count = 3
};

enum EStatCategory : uint8_t
{
    EStatCategory__Combat = 0,
    EStatCategory__Building = 1,
    EStatCategory__Utility = 2,
    EStatCategory__Max_None = 3
};

enum EFortVoteArbitratorType : uint8_t
{
    EFortVoteArbitratorType__Invalid = 0,
    EFortVoteArbitratorType__Majority = 1,
    EFortVoteArbitratorType__Unanimous = 2
};

enum EFortCompletionResult : uint8_t
{
    EFortCompletionResult__Win = 0,
    EFortCompletionResult__Loss = 1,
    EFortCompletionResult__Draw = 2,
    EFortCompletionResult__Undefined = 3
};

enum EWaveRules : uint8_t
{
    EWaveRules__KillAllEnemies = 0,
    EWaveRules__Timed = 1,
    EWaveRules__KillPoints = 2,
    EWaveRules__KillSpecificEnemy = 3,
    EWaveRules__Mission = 4,
    EWaveRules__DestroyRifts = 5
};

enum EFortAIDirectorEvent : uint8_t
{
    EFortAIDirectorEvent__PlayerAIEnemies = 0,
    EFortAIDirectorEvent__PlayerTakeDamage = 1,
    EFortAIDirectorEvent__PlayerHealth = 2,
    EFortAIDirectorEvent__PlayerDeath = 3,
    EFortAIDirectorEvent__PlayerLookAtAIEnemy = 4,
    EFortAIDirectorEvent__PlayerDamageAIEnemy = 5,
    EFortAIDirectorEvent__PlayerKillAIEnemy = 6,
    EFortAIDirectorEvent__PlayerHealingPotential = 7,
    EFortAIDirectorEvent__PlayerAmmoLight = 8,
    EFortAIDirectorEvent__PlayerAmmoMedium = 9,
    EFortAIDirectorEvent__PlayerAmmoHeavy = 10,
    EFortAIDirectorEvent__PlayerAmmoShells = 11,
    EFortAIDirectorEvent__PlayerAmmoEnergy = 12,
    EFortAIDirectorEvent__PlayerAINear = 13,
    EFortAIDirectorEvent__PlayerMovement = 14,
    EFortAIDirectorEvent__ObjectiveTakeDamage = 15,
    EFortAIDirectorEvent__ObjectiveHealth = 16,
    EFortAIDirectorEvent__ObjectiveDestroyed = 17,
    EFortAIDirectorEvent__TrapFired = 18,
    EFortAIDirectorEvent__TrapDamagedAIEnemy = 19,
    EFortAIDirectorEvent__ObjectivePathCost = 20,
    EFortAIDirectorEvent__PlayerPathCost = 21,
    EFortAIDirectorEvent__ObjectiveNearbyBuildingDamaged = 22,
    EFortAIDirectorEvent__Max_None = 23
};

enum EServerStability : uint8_t
{
    EServerStability__Stable = 0,
    EServerStability__LowUnstability = 1,
    EServerStability__HighUnstability = 2,
    EServerStability__Count = 3
};

enum ETenacityType : uint8_t
{
    ETenacityType__Default = 0,
    ETenacityType__MaxHealth = 1,
    ETenacityType__Custom = 2
};

enum EDBNOMutatorType : uint8_t
{
    EDBNOMutatorType__Default = 0,
    EDBNOMutatorType__On = 1,
    EDBNOMutatorType__Off = 2,
    EDBNOMutatorType__Improved = 3
};

enum EFortPlaylistType : uint8_t
{
    EFortPlaylistType__Default = 0,
    EFortPlaylistType__Playground = 1,
    EFortPlaylistType__Creative = 2,
    EFortPlaylistType__Creative_LTM = 3
};

enum EAthenaGamePhaseStep : uint8_t
{
    EAthenaGamePhaseStep__None = 0,
    EAthenaGamePhaseStep__Setup = 1,
    EAthenaGamePhaseStep__Warmup = 2,
    EAthenaGamePhaseStep__GetReady = 3,
    EAthenaGamePhaseStep__BusLocked = 4,
    EAthenaGamePhaseStep__BusFlying = 5,
    EAthenaGamePhaseStep__StormForming = 6,
    EAthenaGamePhaseStep__StormHolding = 7,
    EAthenaGamePhaseStep__StormShrinking = 8,
    EAthenaGamePhaseStep__Countdown = 9,
    EAthenaGamePhaseStep__FinalCountdown = 10,
    EAthenaGamePhaseStep__EndGame = 11,
    EAthenaGamePhaseStep__Count = 12
};

enum EFortResourceType : uint8_t
{
    EFortResourceType__Wood = 0,
    EFortResourceType__Stone = 1,
    EFortResourceType__Metal = 2,
    EFortResourceType__Permanite = 3,
    EFortResourceType__GoldCurrency = 4,
    EFortResourceType__Ingredient = 5
};

enum EMapLocationStateType : uint8_t
{
    EMapLocationStateType__Normal = 0,
    EMapLocationStateType__Golden = 1,
    EMapLocationStateType__Undiscovered = 2,
    EMapLocationStateType__Max = 3
};

enum EEventTournamentRound : uint8_t
{
    EEventTournamentRound__Open = 0,
    EEventTournamentRound__Qualifiers = 1,
    EEventTournamentRound__SemiFinals = 2,
    EEventTournamentRound__Finals = 3,
    EEventTournamentRound__Unknown = 4,
    EEventTournamentRound__Arena = 5
};

enum EFriendlyFireType : uint8_t
{
    EFriendlyFireType__Off = 0,
    EFriendlyFireType__On = 1
};

enum EFortItemEntryState : uint8_t
{
    EFortItemEntryState__NoneState = 0,
    EFortItemEntryState__NewItemCount = 1,
    EFortItemEntryState__ShouldShowItemToast = 2,
    EFortItemEntryState__DurabilityInitialized = 3,
    EFortItemEntryState__DoNotShowSpawnParticles = 4,
    EFortItemEntryState__FromRecoveredBackpack = 5,
    EFortItemEntryState__FromGift = 6,
    EFortItemEntryState__PendingUpgradeCriteriaProgress = 7,
    EFortItemEntryState__OwnerBuildingHandle = 8,
    EFortItemEntryState__FromDroppedPickup = 9,
    EFortItemEntryState__JustCrafted = 10,
    EFortItemEntryState__CraftAndSlotTarget = 11,
    EFortItemEntryState__GenericAttributeValueSet = 12,
    EFortItemEntryState__PickupInstigatorHandle = 13,
    EFortItemEntryState__RechargingWeaponServerTime = 14,
    EFortItemEntryState__DisallowSwapOnNextPickUpAttempt = 15,
    EFortItemEntryState__DroppedFromQuestSource = 16,
    EFortItemEntryState__Tossed = 17,
    EFortItemEntryState__Loaded = 18,
    EFortItemEntryState__SaveMagazineAmmo = 19,
    EFortItemEntryState__MultiItemLevel = 20,
    EFortItemEntryState__MultiItemXP = 21,
    EFortItemEntryState__FromAugment = 22,
    EFortItemEntryState__PreventDropping = 23,
    EFortItemEntryState__PreventDroppingExceptFromDeath = 24,
    EFortItemEntryState__PreventDroppingExceptFromDeathWithCount = 25,
    EFortItemEntryState__ReAddedItem = 26,
    EFortItemEntryState__WeaponAmmoOverride = 27,
    EFortItemEntryState__DurabilityCooldownTimeRemainingOnUpdate = 28,
    EFortItemEntryState__LoadedAmmoHasBeenSet = 29
};

enum EFortQuickBars : uint8_t
{
    EFortQuickBars__Primary = 0,
    EFortQuickBars__Secondary = 1,
    EFortQuickBars__Creative = 2,
    EFortQuickBars__Max_None = 3
};

enum EAthenaCustomizationCategory : uint8_t
{
    EAthenaCustomizationCategory__None = 0,
    EAthenaCustomizationCategory__Glider = 1,
    EAthenaCustomizationCategory__Pickaxe = 2,
    EAthenaCustomizationCategory__Backpack = 3,
    EAthenaCustomizationCategory__Shoes = 4,
    EAthenaCustomizationCategory__Character = 5,
    EAthenaCustomizationCategory__LoadingScreen = 6,
    EAthenaCustomizationCategory__Dance = 7,
    EAthenaCustomizationCategory__SkyDiveContrail = 8,
    EAthenaCustomizationCategory__MusicPack = 9,
    EAthenaCustomizationCategory__ItemWrap = 10,
    EAthenaCustomizationCategory__RegCosmeticDef = 11,
    EAthenaCustomizationCategory__Apparel = 12,
    EAthenaCustomizationCategory__SparksAura = 13,
    EAthenaCustomizationCategory__SparksGuitar = 14,
    EAthenaCustomizationCategory__SparksBass = 15,
    EAthenaCustomizationCategory__SparksKeyboard = 16,
    EAthenaCustomizationCategory__SparksMicrophone = 17,
    EAthenaCustomizationCategory__SparksDrums = 18,
    EAthenaCustomizationCategory__SparksSpotlightAnim = 19,
    EAthenaCustomizationCategory__SparksSong = 20,
    EAthenaCustomizationCategory__Loadout = 21,
    EAthenaCustomizationCategory__SaveLoadout = 22
};

enum EFortObjectiveStatus : uint8_t
{
    EFortObjectiveStatus__Created = 0,
    EFortObjectiveStatus__InProgress = 1,
    EF____d__RR__t__________F__FD__ = 2,
    EFortObjectiveStatus__Failed = 3,
    EFortObjectiveStatus__NeutralCompletion = 4,
    EFortObjectiveStatus__Max_None = 5
};

enum ERichPresenceStateChange : uint8_t
{
    ERichPresenceStateChange__AutoUpdate = 0,
    ERichPresenceStateChange__Idle = 1,
    ERichPresenceStateChange__Active = 2,
    ERichPresenceStateChange__Busy = 3,
    ERichPresenceStateChange__NotBusy = 4
};

enum ELockOnState : uint8_t
{
    ELockOnState__NoTarget = 0,
    ELockOnState__TargetAcquired = 1,
    ELockOnState__LockingOnToTarget = 2,
    ELockOnState__TargetLockedOn = 3,
    ELockOnState__Cooldown = 4,
    ELockOnState__COUNT = 5
};

enum EStatRecordingPeriod : uint8_t
{
    EStatRecordingPeriod__Frame = 0,
    EStatRecordingPeriod__Minute = 1,
    EStatRecordingPeriod__AthenaSafeZonePhase = 2,
    EStatRecordingPeriod__Life = 3,
    EStatRecordingPeriod__Map = 4,
    EStatRecordingPeriod__Campaign = 5,
    EStatRecordingPeriod__Persistent = 6,
    EStatRecordingPeriod__Max = 7
};

enum EStatMod : uint8_t
{
    EStatMod__Delta = 0,
    EStatMod__Set = 1,
    EStatMod__Maximum = 2
};

enum EFortDamageZone : uint8_t
{
    EFortDamageZone__Light = 0,
    EFortDamageZone__Normal = 1,
    EFortDamageZone__Critical = 2,
    EFortDamageZone__Vulnerability = 3,
    EFortDamageZone__Invulnerability = 4,
    EFortDamageZone__Max = 5
};

enum ESpatialLoadingState : uint8_t
{
    ESpatialLoadingState__Uninitialized = 0,
    ESpatialLoadingState__ReadOnly = 1,
    ESpatialLoadingState__Initializing = 2,
    ESpatialLoadingState__Ready = 3
};

enum EFortEmotePlayMode : uint8_t
{
    EFortEmotePlayMode__CheckIfOwned = 0,
    EFortEmotePlayMode__ForcePlay = 1
};

enum EFortResourceLevel : uint8_t
{
    EFortResourceLevel__First = 0,
    EFortResourceLevel__Second = 1,
    EFortResourceLevel__Third = 2,
    EFortResourceLevel__Fourth = 3,
    EFortResourceLevel__Fifth = 4,
    EFortResourceLevel__Sixth = 5,
    EFortResourceLevel__NumLevels = 6,
    EFortResourceLevel__Invalid = 7
};

enum EFortRequestedGameplayAction : uint8_t
{
    EFortRequestedGameplayAction__ContinuePlaying = 0,
    EFortRequestedGameplayAction__StartPlaying = 1,
    EFortRequestedGameplay____S__a__M____ze__ = 2,
    EFortRequestedGameplayAction__EnterZone = 3,
    EFortRequestedGameplayAction__LeaveZone = 4
};

enum EFortQuestObjectiveStatEvent : uint8_t
{
    EFortQuestObjectiveStatEvent__Kill = 0,
    EFortQuestObjectiveStatEvent__TeamKill = 1,
    EFortQuestObjectiveStatEvent__KillContribution = 2,
    EFortQuestObjectiveStatEvent__Damage = 3,
    EFortQuestObjectiveStatEvent__SquadDamage = 4,
    EFortQuestObjectiveStatEvent__Visit = 5,
    EFortQuestObjectiveStatEvent__VisitDiscoverPOI = 6,
    EFortQuestObjectiveStatEvent__Land = 7,
    EFortQuestObjectiveStatEvent__Emote = 8,
    EFortQuestObjectiveStatEvent__Spray = 9,
    EFortQuestObjectiveStatEvent__Toy = 10,
    EFortQuestObjectiveStatEvent__Build = 11,
    EFortQuestObjectiveStatEvent__BuildingEdit = 12,
    EFortQuestObjectiveStatEvent__BuildingRepair = 13,
    EFortQuestObjectiveStatEvent__BuildingUpgrade = 14,
    EFortQuestObjectiveStatEvent__PlaceTrap = 15,
    EFortQuestObjectiveStatEvent__Complete = 16,
    EFortQuestObjectiveStatEvent__Craft = 17,
    EFortQuestObjectiveStatEvent__Collect = 18,
    EFortQuestObjectiveStatEvent__Win = 19,
    EFortQuestObjectiveStatEvent__Interact = 20,
    EFortQuestObjectiveStatEvent__TeamInteract = 21,
    EFortQuestObjectiveStatEvent__Destroy = 22,
    EFortQuestObjectiveStatEvent__Ability = 23,
    EFortQuestObjectiveStatEvent__WaveComplete = 24,
    EFortQuestObjectiveStatEvent__Custom = 25,
    EFortQuestObjectiveStatEvent__ComplexCustom = 26,
    EFortQuestObjectiveStatEvent__Client = 27,
    EFortQuestObjectiveStatEvent__AthenaRank = 28,
    EFortQuestObjectiveStatEvent__AthenaOutlive = 29,
    EFortQuestObjectiveStatEvent__RevivePlayer = 30,
    EFortQuestObjectiveStatEvent__Heal = 31,
    EFortQuestObjectiveStatEvent__EarnVehicleTrickPoints = 32,
    EFortQuestObjectiveStatEvent__VehicleAirTime = 33,
    EFortQuestObjectiveStatEvent__TimeElapsed = 34,
    EFortQuestObjectiveStatEvent__Death = 35,
    EFortQuestObjectiveStatEvent__AthenaMarker = 36,
    EFortQuestObjectiveStatEvent__PlacementUpdate = 37,
    EFortQuestObjectiveStatEvent__StormPhase = 38,
    EFortQuestObjectiveStatEvent__DistanceTraveled = 39,
    EFortQuestObjectiveStatEvent__DownOrElim = 40,
    EFortQuestObjectiveStatEvent__Accolade = 41,
    EFortQuestObjectiveStatEvent__TakeDamage = 42,
    EFortQuestObjectiveStatEvent__AthenaCollection = 43,
    EFortQuestObjectiveStatEvent__AthenaCollectionFoundItem = 44,
    EFortQuestObjectiveStatEvent__UsedNPCService = 45,
    EFortQuestObjectiveStatEvent__ReceivedNPCGift = 46,
    EFortQuestObjectiveStatEvent__InitiatedNPCConversation = 47,
    EFortQuestObjectiveStatEvent__AthenaCraft = 48,
    EFortQuestObjectiveStatEvent__AthenaTurnInQuest = 49,
    EFortQuestObjectiveStatEvent__AthenaVehicleMod = 50,
    EFortQuestObjectiveStatEvent__AthenaOpenedFriendChest = 51,
    EFortQuestObjectiveStatEvent__AthenaAcquire = 52,
    EFortQuestObjectiveStatEvent__InitiatedServiceStationConversation = 53,
    EFortQuestObjectiveStatEvent__AthenaAccumulatedItem = 54,
    EFortQuestObjectiveStatEvent__AthenaVehicleFlip = 55,
    EFortQuestObjectiveStatEvent__AthenaVehicleTirePopped = 56,
    EFortQuestObjectiveStatEvent__RevealedPawnDisguise = 57,
    EFortQuestObjectiveStatEvent__ManuallyCompleted = 58,
    EFortQuestObjectiveStatEvent__Hit = 59,
    EFortQuestObjectiveStatEvent__CreativeDevice = 60,
    EFortQuestObjectiveStatEvent__Feed = 61,
    EFortQuestObjectiveStatEvent__HitWeakpoint = 62,
    EFortQuestObjectiveStatEvent__PlaceTent = 63,
    EFortQuestObjectiveStatEvent__ConvertNPC = 64,
    EFortQuestObjectiveStatEvent__DiscoverLoot = 65,
    EFortQuestObjectiveStatEvent__GlideDistance = 66,
    EFortQuestObjectiveStatEvent__Throw = 67,
    EFortQuestObjectiveStatEvent__Repair = 68,
    EFortQuestObjectiveStatEvent__Ignite = 69,
    EFortQuestObjectiveStatEvent__Refuel = 70,
    EFortQuestObjectiveStatEvent__AthenaVehiclePartDisabled = 71,
    EFortQuestObjectiveStatEvent__RevivedFromDBNO = 72,
    EFortQuestObjectiveStatEvent__AthenaGainXp = 73,
    EFortQuestObjectiveStatEvent__AthenaDistanceTraveled = 74,
    EFortQuestObjectiveStatEvent__MatchStarted = 75,
    EFortQuestObjectiveStatEvent__Finish = 76,
    EFortQuestObjectiveStatEvent__TeammateDealtDamage = 77,
    EFortQuestObjectiveStatEvent__CurrencyCollected = 78,
    EFortQuestObjectiveStatEvent__ScoredPlayerElimination = 79,
    EFortQ_9__t________o_____I__Q_H____________________S_____I = 80,
    EFortQuestObjectiveStatEvent__SlayWildlife = 81,
    EFortQuestObjectiveStatEvent__TeamScoredPlayerElimination = 82,
    EFortQuestObjectiveStatEvent__AthenaLevelUp = 83,
    EFortQuestObjectiveStatEvent__AthenaEarnMiniGameScore = 84,
    EFortQuestObjectiveStatEvent__KillWhileMounted = 85,
    EFortQuestObjectiveStatEvent__DistanceTraveledWhileMounted = 86,
    EFortQuestObjectiveStatEvent__Deprecated = 87,
    EFortQuestObjectiveStatEvent__NumGameplayEvents = 88,
    EFortQuestObjectiveStatEvent__Acquire = 89,
    EFortQuestObjectiveStatEvent__Consume = 90,
    EFortQuestObjectiveStatEvent__OpenCardPack = 91,
    EFortQuestObjectiveStatEvent__PurchaseCardPack = 92,
    EFortQuestObjectiveStatEvent__Convert = 93,
    EFortQuestObjectiveStatEvent__Upgrade = 94,
    EFortQuestObjectiveStatEvent__UpgradeRarity = 95,
    EFortQuestObjectiveStatEvent__QuestComplete = 96,
    EFortQuestObjectiveStatEvent__AssignWorker = 97,
    EFortQuestObjectiveStatEvent__CollectExpedition = 98,
    EFortQuestObjectiveStatEvent__CollectSuccessfulExpedition = 99,
    EFortQuestObjectiveStatEvent__LevelUpCollectionBook = 100,
    EFortQuestObjectiveStatEvent__LevelUpAthenaSeason = 101,
    EFortQuestObjectiveStatEvent__LevelUpBattlePass = 102,
    EFortQuestObjectiveStatEvent__GainAthenaSeasonXp = 103,
    EFortQuestObjectiveStatEvent__HasItem = 104,
    EFortQuestObjectiveStatEvent__HasAccumulatedItem = 105,
    EFortQuestObjectiveStatEvent__SlotInCollection = 106,
    EFortQuestObjectiveStatEvent__AlterationRespec = 107,
    EFortQuestObjectiveStatEvent__AlterationUpgrade = 108,
    EFortQuestObjectiveStatEvent__HasCompletedQuest = 109,
    EFortQuestObjectiveStatEvent__HasAssignedWorker = 110,
    EFortQuestObjectiveStatEvent__HasUpgraded = 111,
    EFortQuestObjectiveStatEvent__HasConverted = 112,
    EFortQuestObjectiveStatEvent__HasUpgradedRarity = 113,
    EFortQuestObjectiveStatEvent__HasLeveledUpCollectionBook = 114,
    EFortQuestObjectiveStatEvent__SlotHeroInLoadout = 115,
    EFortQuestObjectiveStatEvent__HasLeveledUpAthenaSeason = 116,
    EFortQuestObjectiveStatEvent__HasLeveledUpBattlePass = 117,
    EFortQuestObjectiveStatEvent__HasGainedAthenaSeasonXp = 118,
    EFortQuestObjectiveStatEvent__MinigameDynamicEvent = 119,
    EFortQuestObjectiveStatEvent__MinigameComplete = 120,
    EFortQuestObjectiveStatEvent__MinigameDeath = 121,
    EFortQuestObjectiveStatEvent__MinigameAssist = 122,
    EFortQuestObjectiveStatEvent__Max_None = 123
};

enum EFortGameplayEventReferenceType : uint8_t
{
    EFortGameplayEventReferenceType__None = 0,
    EFortGameplayEventReferenceType__EventDescriptor = 1,
    EFortGameplayEventReferenceType__EventFunction = 2
};

enum EBuildingHighlightType : uint8_t
{
    EBuildingHighlightType__Primary = 0,
    EBuildingHighlightType__Interact = 1,
    EBuildingHighlightType__WillBeDestroyed = 2,
    EBuildingHighlightType__Quest = 3,
    EBuildingHighlightType__AuxiliaryInterestPoint = 4,
    EBuildingHighlightType__MAX_None = 5
};

enum EFortCollectedVariantClientUpdate : uint8_t
{
    EFortCollectedVariantClientUpdate__NewVariant = 0,
    EFortCollectedVariantClientUpdate__CollectedCount = 1,
    EFortCollectedVariantClientUpdate__Improvement = 2,
    EFortCollectedVariantClientUpdate__HiddenImprovement = 3
};

enum EFortCollectedState : uint8_t
{
    EFortCollectedState__Unknown = 0,
    EFortCollectedState__New = 1,
    EFortCollectedState__Known = 2,
    EFortCollectedState__NewlyCollected = 3,
    EFortCollectedState__Collected = 4,
    EFortCollectedState__NewBest = 5,
    EFortCollectedState__NewRecord = 6,
    EFortCollectedState__NewLocation = 7,
    EFortCollectedState__NewlyCompleted = 8,
    EFortCollectedState__Complete = 9
};

enum EFortJumpStaminaCost : uint8_t
{
    EFortJumpStaminaCost__None = 0,
    EFortJumpStaminaCost__Trigger = 1,
    EFortJumpStaminaCost__SprintTrigger = 2,
    EFortJumpStaminaCost__SprintAir = 3
};

enum EFortVoiceChatMethod : uint8_t
{
    EFortVoiceChatMethod__OpenMic = 0,
    EFortVoiceChatMethod__PTT = 1,
    EFortVoiceChatMethod__Mute = 2
};

enum EFortPCTutorialCompletedState : uint8_t
{
    EFortPCTutorialCompletedState__Unknown = 0,
    EFortPCTutorialCompletedState__Incomplete = 1,
    EFortPCTutorialCompletedState__Complete = 2
};

enum EFortRewardActivityType : uint8_t
{
    EFortRewardActivityType__General = 0,
    EFortRewardActivityType__MissionPrimary = 1,
    EFortRewardActivityType__MissionSecondary = 2,
    EFortRewardActivityType__AccountLevelUp = 3,
    EFortRewardActivityType__Max_None = 4
};

enum EFortDelayedQuickBarAction : uint8_t
{
    EFortDelayedQuickBarAction__Add = 0,
    EFortDelayedQuickBarAction__Remove = 1,
    EFortDelayedQuickBarAction__Replace = 2,
    EFortDelayedQuickBarAction__Invalid = 3
};

enum EFortElementalDamageType : uint8_t
{
    EFortElementalDamageType__None = 0,
    EFortElementalDamageType__Fire = 1,
    EFortElementalDamageType__Ice = 2,
    EFortElementalDamageType__Lightning = 3,
    EFortElementalDamageType__Energy = 4
};

enum EFortDamageNumberType : uint8_t
{
    EFortDamageNumberType__None = 0,
    EFortDamageNumberType__Pawn = 1,
    EFortDamageNumberType__Building = 2,
    EFortDamageNumberType__Player = 3,
    EFortDamageNumberType__Shield = 4,
    EFortDamageNumberType__Score = 5,
    EFortDamageNumberType__DBNO = 6,
    EFortDamageNumberType__Percent = 7
};

enum EFortCostInfoTypes : uint8_t
{
    EFortCostInfoTypes__Placement = 0,
    EFortCostInfoTypes__Repair = 1,
    EFortCostInfoTypes__Conversion = 2,
    EFortCostInfoTypes__Ability = 3,
    EFortCostInfoTypes__None = 4
};

enum EFortBuildPreviewMarkerOptionalAdjustment : uint8_t
{
    EFortBuildPreviewMarkerOptionalAdjustment__None = 0,
    EFortBuildPreviewMarkerOptionalAdjustment__FreeWallPieceOnTop = 1,
    EFortBuildPreviewMarkerOptionalAdjustment__FreeWallPieceOnBottom = 2
};

enum ESpectateBlendEasing : uint8_t
{
    ESpectateBlendEasing__Linear = 0,
    ESpectateBlendEasing__EaseOutQuad = 1
};

enum EFortSpectatorBlendType : uint8_t
{
    EFortSpectatorBlendType__None = 0,
    EFortSpectatorBlendType__Orbit = 1,
    EFortSpectatorBlendType__Default = 2
};

enum ESpectatorSquadIdMode : uint8_t
{
    ESpectatorSquadIdMode__AlwaysOff = 0,
    ESpectatorSquadIdMode__AlwaysOn = 1,
    ESpectatorSquadIdMode__HoldToDisplay = 2
};

enum ESpectatorCameraType : uint8_t
{
    ESpectatorCameraType__ThirdPerson = 0,
    ESpectatorCameraType__DroneFree = 1,
    ESpectatorCameraType__Gameplay = 2,
    ESpectatorCameraType__ReverseShot = 3,
    ESpectatorCameraType__FollowShot = 4,
    ESpectatorCameraType__DroneFollow = 5,
    ESpectatorCameraType__DroneAttach = 6,
    ESpectatorCameraType__BattleMap = 7,
    ESpectatorCameraType__ARDrone = 8
};

enum EPlayEventType : uint8_t
{
    EPlayEventType__None = 0,
    EPlayEventType__TeamFlight = 1,
    EPlayEventType__Zone = 2,
    EPlayEventType__Elimination = 3,
    EPlayEventType__PlayerMoves = 4,
    EPlayEventType__SinglePlayerMove = 5,
    EPlayEventType__ActorsPosition = 6,
    EPlayEventType__GameHighlights = 7,
    EPlayEventType__Timecode = 8
};

enum ECameraShotNotificationTypes : uint8_t
{
    ECameraShotNotificationTypes__Notification = 0,
    ECameraShotNotificationTypes__HighlightAnnotation = 1,
    ECameraShotNotificationTypes__TitleScreen = 2
};

enum EThirdPersonAutoFollowMode : uint8_t
{
    EThirdPersonAutoFollowMode__Off = 0,
    EThirdPersonAutoFollowMode__Auto = 1,
    EThirdPersonAutoFollowMode__Lazy = 2
};

enum EFortMinigameStatScope : uint8_t
{
    EFortMinigameStatS__hj_V____X = 0,
    EFortMinigameStatScope__Team = 1,
    EFortMinigameStatScope__Player = 2
};

enum EDeviceFireVolumeFireOption : uint8_t
{
    EDeviceFireVolumeFireOption__None = 0,
    EDeviceFireVolumeFireOption__UseIslandSettings = 1,
    EDeviceFireVolumeFireOption__Yes = 2,
    EDeviceFireVolumeFireOption__No = 3
};

enum EFortMinigamePlayerSpawnLocationSetting : uint8_t
{
    EFortMinigamePlayerSpawnLocationSetting__SpawnPads = 0,
    EFortMinigamePlayerSpawnLocationSetting__Device = 1,
    EFortMinigamePlayerSpawnLocationSetting__Preplaced = 2,
    EFortMinigamePlayerSpawnLocationSetting__Air = 3,
    EFortMinigamePlayerSpawnLocationSetting__CurrentLocation = 4,
    EFortMinigamePlayerSpawnLocationSetting__DoNotSpawn = 5
};

enum EFortMinigameEnd : uint8_t
{
    EFortMinigameEnd__Teardown = 0,
    EFortMinigameEnd__AbandonGame = 1,
    EFortMinigameEnd__EndGame = 2,
    EFortMinigameEnd__EndRound = 3
};

enum EMinigameTeamListType : uint8_t
{
    EMinigameTeamListType__Blacklist = 0,
    EMinigameTeamListType__Whitelist = 1
};

enum EMinigameScoreboardStates : uint8_t
{
    EMinigameScoreboardStates__RoundEndDisplayWinner = 0,
    EMinigameScoreboardStates__GameEndDisplayWinner = 1,
    EMinigameScoreboardStates__RoundEndDisplayScoreboard = 2,
    EMinigameScoreboardStates__GameEndDisplayScoreboard = 3,
    EMinigameScoreboardStates__Max = 4
};

enum EMinigameFullscreenMapWidgetType : uint8_t
{
    EMinigameFullscreenMapWidgetType__Last_Opened = 0,
    EMinigameFullscreenMapWidgetType__Default_Map = 1,
    EMinigameFullscreenMapWidgetType__Creative_Scoreboard = 2
};

enum EFortMinigameExec : uint8_t
{
    EFortMinigameExec__Yes = 0,
    EFortMinigameExec__No = 1
};

enum EClearItemOnSwitchRules : uint8_t
{
    EClearItemOnSwitchRules__NeverClear = 0,
    EClearItemOnSwitchRules__ClearOnTeamSwitch = 1,
    EClearItemOnSwitchRules__ClearOnClassSwitch = 2,
    EClearItemOnSwitchRules__ClearOnClassOrTeamSwitch = 3
};

enum ERoundVictoryAnimation : uint8_t
{
    ERoundVictoryAnimation__Default = 0,
    ERoundVictoryAnimation__None = 1
};

enum EMinigameGameEndCustomPostGameAnimationColorSet : uint8_t
{
    EMinigameGameEndCustomPostGameAnimationColorSet__Default = 0,
    EMinigameGameEndCustomPostGameAnimationColorSet__GoldenYellow = 1,
    EMinigameGameEndCustomPostGameAnimationColorSet__BlueGreen = 2,
    EMinigameGameEndCustomPostGameAnimationColorSet__VibrantPurple = 3,
    EMinigameGameEndCustomPostGameAnimationColorSet__FuriousFlame = 4,
    EMinigameGameEndCustomPostGameAnimationColorSet__Monochrome = 5,
    EMinigameGameEndCustomPostGameAnimationColorSet__FailureRed = 6
};

enum EMinigameGameEndCustomPostGameAnimationStyle : uint8_t
{
    EMinigameGameEndCustomPostGameAnimationStyle__LightningBolt = 0,
    EMinigameGameEndCustomPostGameAnimationStyle__Shards = 1,
    EMinigameGameEndCustomPostGameAnimationStyle__WipeLeftToRight = 2,
    EMinigameGameEndCustomPostGameAnimationStyle__WipeRightToLeft = 3,
    EMinigameGameEndCustomPostGameAnimationStyle__WipeTopToBottom = 4,
    EMinigameGameEndCustomPostGameAnimationStyle__WipeBottomToTop = 5,
    EMinigameGameEndCustomPostGameAnimationStyle__None = 6
};

enum EMinigameGameEndPostGameType : uint8_t
{
    EMinigameGameEndPostGameType__Classic = 0,
    EM__R________y____xX____Oe__A_h_____X_____ = 1,
    EMinigameGameEndPostGameType__Custom = 2
};

enum EMinigameGameEndCallout : uint8_t
{
    EMinigameGameEndCallout__WinLose = 0,
    EMinigameGameEndCallout__Placement = 1,
    EMinigameGameEndCallout__Cooperative = 2
};

enum EMinigameWinCondition : uint8_t
{
    EMinigameWinCondition__MostRoundWins = 0,
    EMinigameWinCondition__MostScoreWins = 1
};

enum EMinigamePlayerPersistence : uint8_t
{
    EMinigamePlayerPersistence__None = 0,
    EMinigamePlayerPersistence__PartyLeaderOnly = 1,
    EMinigamePlayerPersistence__AllPlayers = 2
};

enum ECreativeBossDisplayMode : uint8_t
{
    ECreativeBossDisplayMode__DontOverride = 0,
    ECreativeBossDisplayMode__Yes = 1,
    ECreativeBossDisplayMode__No = 2
};

enum EPlayerIndicatorDisplayMode : uint8_t
{
    EPlayerIndicatorDisplayMode__DontOverride = 0,
    EPlayerIndicatorDisplayMode__TeamOnly = 1,
    EPlayerIndicatorDisplayMode__Enemies = 2,
    EPlayerIndicatorDisplayMode__Anyone = 3,
    EPlayerIndicatorDisplayMode__Never = 4
};

enum ELeecherStatus : uint8_t
{
    ELeecherStatus__NotReady = 0,
    ELeecherStatus__NonLeecher = 1,
    ELeecherStatus__Leecher = 2
};

enum EFortInputActionGroup : uint8_t
{
    EFortInputActionGroup__AllModes = 0,
    EFortInputActionGroup__Combat = 1,
    EFortInputActionGroup__Building = 2,
    EFortInputActionGroup__Movement = 3,
    EFortInputActionGroup__Edit = 4,
    EFortInputActionGroup__Death = 5,
    EFortInputAction______o___A___a_ = 6,
    EFortInputActionGroup__Picker = 7,
    EFortInputActionGroup__Other = 8,
    EFortInputActionGroup__Interaction = 9,
    EFortInputActionGroup__AthenaLTMAbilities = 10,
    EFortInputActionGroup__ShoppingCart = 11,
    EFortInputActionGroup__ShoppingCartDriver = 12,
    EFortInputActionGroup__ShoppingCartPassenger = 13,
    EFortInputActionGroup__Cannon = 14,
    EFortInputActionGroup__CannonDriver = 15,
    EFortInputActionGroup__CannonPassenger = 16,
    EFortInputActionGroup__GolfCart = 17,
    EFortInputActionGroup__GolfCartDriver = 18,
    EFortInputActionGroup__GolfCartPassenger = 19,
    EFortInputActionGroup__QuadCrasher = 20,
    EFortInputActionGroup__QuadCrasherDriver = 21,
    EFortInputActionGroup__QuadCrasherPassenger = 22,
    EFortInputActionGroup__Biplane = 23,
    EFortInputActionGroup__BiplaneDriver = 24,
    EFortInputActionGroup__BiplaneGroundDriver = 25,
    EFortInputActionGroup__BiplanePassenger = 26,
    EFortInputActionGroup__Hamsterball = 27,
    EFortInputActionGroup__Jackal = 28,
    EFortInputActionGroup__Ostrich = 29,
    EFortInputActionGroup__OstrichDriver = 30,
    EFortInputActionGroup__OstrichPassenger = 31,
    EFortInputActionGroup__Meatball = 32,
    EFortInputActionGroup__MeatballDriver = 33,
    EFortInputActionGroup__MeatballPassenger = 34,
    EFortInputActionGroup__HoagieDriver = 35,
    EFortInputActionGroup__Dagwood = 36,
    EFortInputActionGroup__DagwoodDriver = 37,
    EFortInputActionGroup__DagwoodPassenger = 38,
    EFortInputActionGroup__Nevada = 39,
    EFortInputActionGroup__NevadaDriver = 40,
    EFortInputActionGroup__MountedTurret = 41,
    EFortInputActionGroup__Spectating = 42,
    EFortInputActionGroup__FullscreenMap = 43,
    EFortInputActionGroup__CreativeAll = 44,
    EFortInputActionGroup__CreativeModeratorMode = 45,
    EFortInputActionGroup__CreativeMoveToolEquipped = 46,
    EFortInputActionGroup__CreativeMoveObjectsFreely = 47,
    EFortInputActionGroup__CreativeMoveBuildingsOnGrid = 48,
    EFortInputActionGroup__CreativeFlying = 49,
    EFortInputActionGroup__CreativeIslandPanel = 50,
    EFortInputActionGroup__CreativeChair = 51,
    EFortInputActionGroup__PropSelectorEquipped = 52,
    EFortInputActionGroup__CreativeInputDevice = 53,
    EFortInputActionGroup__DBNOCarryStart = 54,
    EFortInputActionGroup__DBNOCarryStop = 55,
    EFortInputActionGroup__DBNOCarry = 56,
    EFortInputActionGroup__InteractionStart = 57,
    EFortInputActionGroup__InteractionStop = 58,
    EFortInputActionGroup__BattleLab = 59,
    EFortInputActionGroup__RemoteControl = 60,
    EFortInputActionGroup__SuperDuper = 61,
    EFortInputActionGroup__Tether = 62,
    EFortInputActionGroup__Riding = 63,
    EFortInputActionGroup__Tank = 64,
    EFortInputActionGroup__TankDriver = 65,
    EFortInputActionGroup__TankPassenger = 66,
    EFortInputActionGroup__RockVehicle = 67,
    EFortInputActionGroup__RockVehicleB = 68,
    EFortInputActionGroup__Dirtbike = 69,
    EFortInputActionGroup__DirtbikeDriver = 70,
    EFortInputActionGroup__DirtbikePassenger = 71,
    EFortInputActionGroup__Sportbike = 72,
    EFortInputActionGroup__SportbikeDriver = 73,
    EFortInputActionGroup__SportbikePassenger = 74,
    EFortInputActionGroup__PlayerAugments = 75,
    EFortInputActionGroup__Targeting = 76,
    EFortInputActionGroup__SimpleBuild = 77,
    EFortInputActionGroup__CombatAndBuilding = 78,
    EFortInputActionGroup__CombatAndAthenaLTMAbilities = 79,
    EFortInputActionGroup__CombatBuildingAndAthenaLTMAbilities = 80
};

enum EEndOfMatchReason : uint8_t
{
    EEndOfMatchReason__LastManStanding = 0,
    EEndOfMatchReason__ScoreReached = 1,
    EEndOfMatchReason__TimeRanOut = 2,
    EEndOfMatchReason__WinEventOccurred = 3,
    EEndOfMatchReason__AllLoggedOut = 4,
    EEndOfMatchReason__AllEliminated = 5
};

enum EDeathCause : uint8_t
{
    EDeathCause__OutsideSafeZone = 0,
    EDeathCause__FallDamage = 1,
    EDeathCause__Pistol = 2,
    EDeathCause__Shotgun = 3,
    EDeathCause__Rifle = 4,
    EDeathCause__SMG = 5,
    EDeathCause__Sniper = 6,
    EDeathCause__SniperNoScope = 7,
    EDeathCause__Melee = 8,
    EDeathCause__InfinityBlade = 9,
    EDeathCause__Grenade = 10,
    EDeathCause__C4 = 11,
    EDeathCause__GrenadeLauncher = 12,
    EDeathCause__RocketLauncher = 13,
    EDeathCause__Minigun = 14,
    EDeathCause__Bow = 15,
    EDeathCause__Trap = 16,
    EDeathCause__DBNOTimeout = 17,
    EDeathCause__Banhammer = 18,
    EDeathCause__RemovedFromGame = 19,
    EDeathCause__MassiveMelee = 20,
    EDeathCause__MassiveDiveBomb = 21,
    EDeathCause__MassiveRanged = 22,
    EDeathCause__Vehicle = 23,
    EDeathCause__ShoppingCart = 24,
    EDeathCause__ATK = 25,
    EDeathCause__QuadCrasher = 26,
    EDeathCause__Biplane = 27,
    EDeathCause__BiplaneGun = 28,
    EDeathCause__LMG = 29,
    EDeathCause__GasGrenade = 30,
    EDeathCause__InstantEnvironmental = 31,
    EDeathCause__InstantEnvironmentalFellOutOfWorld = 32
};

enum ERewardSource : uint8_t
{
    ERewardSource__Invalid = 0,
    ERewardSource__FirstWin = 1,
    ERewardSource__SeasonLevelUp = 2,
    ERewardSource__BookLevelUp = 3,
    ERewardSource__MatchXP = 4,
    ERewardSource__MAX_COUNT = 5
};

enum EAthenaMatchXpMultiplierSource : uint8_t
{
    EAthenaMatchXpMultiplierSource__Invalid = 0,
    EAthenaMatchXpMultiplierSource__BattlePassSelf = 1,
    EAthenaMatchXpMultiplierSource__BattlePassFriends = 2,
    EAthenaMatchXpMultiplierSource__CosmeticSet = 3,
    EAthenaMatchXpMultiplierSource__AntiAddictionPenalty = 4,
    EAthenaMatchXpMultiplierSource__BonusXpEvent = 5,
    EAthenaMatchXpMultiplierSource__MAX_COUNT = 6
};

enum EDuelState : uint8_t
{
    EDuelState__Started = 0,
    EDuelState__Won = 1,
    EDuelState__Lost = 2
};

enum EFortEncounterDirection : uint8_t
{
    EFortEncounterDirection__North = 0,
    EFortEncounterDirection__NorthEast = 1,
    EFortEncounterDirection__East = 2,
    EFortEncounterDirection__SouthEast = 3,
    EFortEncounterDirection__South = 4,
    EFortEncounterDirection__SouthWest = 5,
    EFortEncounterDirection__West = 6,
    EFortEncounterDirection__NorthWest = 7,
    EFortEncounterDirection__Max_None = 8
};

enum EAlertLevel : uint8_t
{
    EAlertLevel__Unaware = 0,
    EAlertLevel__Suspicious = 1,
    EAlertLevel__LostTarget = 2,
    EAlertLevel__Threatened = 3,
    EAlertLevel__Count = 4
};

enum PingCommandType : uint8_t
{
    PingCommandType__GoTo = 0,
    PingCommandType__BackToMe = 1,
    PingCommandType__BackToDefault = 2,
    PingCommandType__HoldPosition = 3,
    PingCommandType__Revive = 4,
    PingCommandType__Dismiss = 5,
    PingCommandType__Item = 6,
    PingCommandType__Attack = 7,
    PingCommandType__Invalid = 8
};

enum EMatchmakingUtilityState : uint8_t
{
    EMatchmakingUtilityState__Idle = 0,
    EMatchmakingUtilityState__MatchmakingUtilityBegin = 1,
    EMatchmakingUtilityState__MatchmakingUtilityCompleted = 2,
    EMatchmakingUtilityState__Completed = 3,
    EMatchmakingUtilityState__Failed = 4,
    EMatchmakingUtilityState__CheckSittingOutState = 5,
    EMatchmakingUtilityState__InitializePlaylistSelection = 6,
    EMatchmakingUtilityState__JoinMatchInProgress = 7,
    EMatchmakingUtilityState__CheckingIfBanned = 8,
    EMatchmakingUtilityState__PrivateMatchMinPartySize = 9,
    EMatchmakingUtilityState__GameFeaturePluginDownloadModal = 10,
    EMatchmakingUtilityState__CreativeContentDownloadModal = 11,
    EMatchmakingUtilityState__CheckModeratorModePermissions = 12,
    EMatchmakingUtilityState__CrossplayOptIn_GameMode = 13,
    EMatchmakingUtilityState__CrossplayOptIn_Fill = 14,
    EMatchmakingUtilityState__CrossplayDevices = 15,
    EMatchmakingUtilityState__FactionChoice = 16,
    EMatchmakingUtilityState__SetPartyReadiness = 17,
    EMatchmakingUtilityState__WaitingForPartyReadinessConfirmed_UnreadyLocalPlayers = 18,
    EMatchmakingUtilityState__WaitingForPartyReadinessConfirmed = 19,
    EMatchmakingUtilityState__TournamentEligibility = 20,
    EMatchmakingUtilityState__TournamentRegionLock = 21,
    EMatchmakingUtilityState__TournamentMFA = 22,
    EMatchmakingUtilityState__TournamentEULA = 23,
    EMatchmakingUtilityState__AppEnvSecurity = 24,
    EMatchmakingUtilityState__WaitingForInitialPlaylistSelection = 25,
    EMatchmakingUtilityState__ServerBrowsers = 26,
    EMatchmakingUtilityState__WaitingForServerBrowserPlaylistSwap = 27,
    EMatchmakingUtilityState__DelayReadyUp = 28,
    EMatchmakingUtilityState__QoSSettings_UpdateManager = 29,
    EMatchmakingUtilityState__QoSSettings_UpdateManager_Success = 30,
    EMatchmakingUtilityState__SetAthenaReady = 31,
    EMatchmakingUtilityState__WaitingForAthenaReadinessConfirmed = 32,
    EMatchmakingUtilityState__PreloadAthena = 33,
    EMatchmakingUtilityState__UpdateHiddenMatchmakingDelay = 34,
    EMatchmakingUtilityState__WaitingForUpdateHiddenMatchmakingDelay = 35,
    EMatchmakingUtilityState__HiddenMatchmakingDelay = 36,
    EMatchmakingUtilityState__FindExistingEditSession = 37,
    EMatchmakingUtilityState__SelectingFlow = 38,
    EMatchmakingUtilityState__ReadyingUpforFlow = 39,
    EMatchmakingUtilityS_ik_u______qa_j______G____6__h___e = 40,
    EMatchmakingUtilityState__CallingMatchmakingForFlow = 41,
    EMatchmakingUtilityState__WaitingForJoinMatchInProgressResponse = 42,
    EMatchmakingUtilityState__WaitingForMatchmakingResponse = 43,
    EMatchmakingUtilityState__WaitingForMatchmakingToCompleteAsPartyMember = 44,
    EMatchmakingUtilityState__WaitingForEntirePartyReady = 45,
    EMatchmakingUtilityState__WaitingForPartyToBeInSameLocation = 46,
    EMatchmakingUtilityState__WaitingForPartyToSwitchSubgames = 47,
    EMatchmakingUtilityState__WaitingToRestartMatchmaking_TooFrequentRequest = 48,
    EMatchmakingUtilityState__RequestingSpectateMatch = 49,
    EMatchmakingUtilityState__ProcessingMatchmakingResults_Success = 50,
    EMatchmakingUtilityState__ProcessingMatchmakingResults_Fail = 51,
    EMatchmakingUtilityState__PreloadingForJoiningMatchInProgress = 52,
    EMatchmakingUtilityState__ProcessingJoinMatchInProgressResults_Success = 53,
    EMatchmakingUtilityState__ProcessingJoinMatchInProgressResults_Fail = 54,
    EMatchmakingUtilityState__RestartingReadyChecksForLegacyFlow = 55,
    EMatchmakingUtilityState__RestartingMatchmaking = 56,
    EMatchmakingUtilityState__QueryingForLiveSpectatorEula = 57,
    EMatchmakingUtilityState__PreTravelToSessionSetup = 58,
    EMatchmakingUtilityState__RunningPlaylistChecks = 59,
    EMatchmakingUtilityState__NewReadiness_Begin = 60,
    EMatchmakingUtilityState__NewReadiness_Ready_WaitingForConfirmation = 61,
    EMatchmakingUtilityState__NewReadiness_Unready_WaitingForConfirmation = 62,
    EMatchmakingUtilityState__NewReadiness_End = 63,
    EMatchmakingUtilityState__RefreshingKeychain = 64,
    EMatchmakingUtilityState__INVALID = 65
};

enum EFortBuildingInitializationReason : uint8_t
{
    EFortBuildingInitializationReason__StaticallyPlaced = 0,
    EFortBuildingInitializationReason__Spawned = 1,
    EFortBuildingInitializationReason__Replaced = 2,
    EFortBuildingInitializationReason__LoadedFromSave = 3,
    EFortBuildingInitializationReason__DynamicBuilderPlaced = 4,
    EFortBuildingInitializationReason__PlacementTool = 5,
    EFortBuildingInitializationReason__TrapTool = 6,
    EFortBuildingInitializationReason__None = 7
};

enum EBuildingNavigationDataResolutionOverrideMode : uint8_t
{
    EBuildingNavigationDataResolutionOverrideMode__Disabled = 0,
    EBuildingNavigationDataResolutionOverrideMode__AlwaysLow = 1,
    EBuildingNavigationDataResolutionOverrideMode__AlwaysDefault = 2,
    EBuildingNavigationDataResolutionOverrideMode__AlwaysHigh = 3,
    EBuildingNavigationDataResolutionOverrideMode__Custom = 4
};

enum EDynamicBuildingPlacementType : uint8_t
{
    EDynamicBuildingPlacementType__CountsTowardsBounds = 0,
    EDynamicBuildingPlacementType__DestroyIfColliding = 1,
    EDynamicBuildingPlacementType__DestroyAnythingThatCollides = 2
};

enum EBuildingActorComponentCreationPolicy : uint8_t
{
    EBuildingActorComponentCreationPolicy__Never = 0,
    EBuildingActorComponentCreationPolicy__Lazy = 1,
    EBuildingActorComponentCreationPolicy__Always = 2
};

enum UFortMatchmakingKnobsDataSource : uint8_t
{
    UFortMatchmakingKnobsDataSource__None = 0,
    UFortMatchmakingKnobsDataSource__Playlist = 1,
    UFortMatchmakingKnobsDataSource__Mutator = 2,
    UFortMatchmakingKnobsDataSource__GameMode = 3,
    UFortMatchmakingKnobsDataSource__Permissions = 4,
    UFortMatchmakingKnobsDataSource__UISettings = 5,
    UFortMatchmakingKnobsDataSource__CreativeGlobalOption = 6,
    UFortMatchmakingKnobsDataSource__MatchmakingGenerated = 7,
    UFortMatchmakingKnobsDataSource__Debug = 8,
    UFortMatchmakingKnobsDataSource__Max = 9
};

enum EAttributeInitLevelSource : uint8_t
{
    EAttributeInitLevelSource__WorldDifficulty = 0,
    EAttributeInitLevelSource__PlayerBuildingSkill = 1,
    EAttributeInitLevelSource__AthenaPlaylist = 2
};

enum EFortAbilityTargetingSource : uint8_t
{
    EFortAbilityTargetingSource__Camera = 0,
    EFortAbilityTargetingSource__PawnForward = 1,
    EFortAbilityTargetingSource__PawnTowardsFocus = 2,
    EFortAbilityTargetingSource__WeaponForward = 3,
    EFortAbilityTargetingSource__WeaponTowardsFocus = 4,
    EFortAbilityTargetingSource__Custom = 5,
    EFortAbilityTargetingSource__Max_None = 6
};

enum EFortDeliveryInfoBuildingActorSpecification : uint8_t
{
    EFortDeliveryInfoBuildingActorSpecification__All = 0,
    EFortDeliveryInfoBuildingActorSpecification__PlayerBuildable = 1,
    EFortDeliveryInfoBuildingActorSpecification__NonPlayerBuildable = 2
};

enum EFortTeamAffiliation : uint8_t
{
    EFortTeamAffiliation__Friendly = 0,
    EFortTeamAffiliation__Neutral = 1,
    EFortTeamAffiliation__Hostile = 2
};

enum EFortProximityBasedGEApplicationType : uint8_t
{
    EFortProximityBasedGEApplicationType__ApplyOnProximityPulse = 0,
    EFortProximityBasedGEApplicationType__ApplyOnProximityTouch = 1,
    EFortProximityBasedGEApplicationType__ApplyOnlyDuringProximityTouch = 2,
    EFortProximityBasedGEApplicationType__ApplyOnProximityExit = 3,
    EFortProximityBasedGEApplicationType__ApplyOnProximityPrePulse = 4
};

enum ETrustedPlatformType : uint8_t
{
    ETrustedPlatformType__Unknown = 0,
    ETrustedPlatformType__Untrusted = 1,
    ETrustedPlatformType__PS4 = 2,
    ETrustedPlatformType__PS5 = 3,
    ETrustedPlatformType__XboxOne = 4,
    ETrustedPlatformType__Switch = 5
};

enum EReadyCheckState : uint8_t
{
    EReadyCheckState__CheckStarted = 0,
    EReadyCheckState__Ready = 1,
    EReadyCheckState__NotReady = 2
};

enum EFortAppliedSwapItemAndVariantState : uint8_t
{
    EFortAppliedSwapItemAndVariantState__None = 0,
    EFortAppliedSwapItemAndVariantState__Active = 1,
    EFortAppliedSwapItemAndVariantState__Inactive = 2
};

enum EFortCustomBodyType : uint8_t
{
    EFortCustomBodyType__NONE = 0,
    EFortCustomBodyType__Small = 1,
    EFortCustomBodyType__Medium = 2,
    EFortCustomBodyType__MediumAndSmall = 3,
    EFortCustomBodyType__Large = 4,
    EFortCustomBodyType__LargeAndSmall = 5,
    EFortCustomBodyType__LargeAndMedium = 6,
    EFortCustomBodyType__All = 7,
    EFortCustomBodyType__Deprecated = 8
};

enum EFortKickReason : uint8_t
{
    EFortKickReason__NotKicked = 0,
    EFortKickReason__GenericKick = 1,
    EFortKickReason__WasBanned = 2,
    EFortKickReason__EncryptionRequired = 3,
    EFortKickReason__CrossPlayRestriction = 4,
    EFortKickReason__ClientIdRestriction = 5
};

enum EMessageDispatcherErrorMessageType : uint8_t
{
    EMessageDispatcherErrorMessageType__FailedToSetTrigger_TooManyTriggers = 0,
    EMessageDispatcherErrorMessageType__FailedToSetReceiver_TooManyReceivers = 1,
    EMessageDispatcherErrorMessageType__FailedToSetReceiver_TooManyReceiversOnOneChannel = 2,
    EMessageDispatcherErrorMessageType__FailedToSetTriggerReceiver_InvalidChannel = 3,
    EMessageDispatcherErrorMessageType__FailedToEnqueueMessage = 4,
    EMessageDispatcherErrorMessageType__BuildLimitReached = 5,
    EMessageDispatcherErrorMessageType__UnknownError = 6
};

enum ECreativePersistenceErrorTypes : uint8_t
{
    ECreativePersistenceErrorTypes__None = 0,
    ECreativePersistenceErrorTypes__VersionError = 1,
    ECreativePersistenceErrorTypes__LocalOnly = 2,
    ECreativePersistenceErrorTypes__LSRError = 3
};

enum EFortBudgetCategory : uint8_t
{
    EFortBudgetCategory__Memory = 0,
    EFortBudgetCategory__Simulation = 1,
    EFortBudgetCategory__Rendering = 2,
    EFortBudgetCategory__Network = 3,
    EFortBudgetCategory__Audio = 4,
    EFortBudgetCategory__Max = 5
};

enum EMatchAbandonState : uint8_t
{
    EMatchAbandonState__None = 0,
    EMatchAbandonState__Joining = 1,
    EMatchAbandonState__CanAbandon = 2,
    EMatchAbandonState__TeamLocked = 3
};

enum EFortWeaponSoundState : uint8_t
{
    EFortWeaponSoundState__Normal = 0,
    EFortWeaponSoundState__LowAmmo = 1,
    EFortWeaponSoundState__Degraded = 2,
    EFortWeaponSoundState__Max_None = 3
};

enum EFortWeaponCoreAnimation : uint8_t
{
    EFortWeaponCoreAni_ = 0,
    EFortWeaponCoreAnimation__Pistol = 1,
    EFortWeaponCoreAnimation__Shotgun = 2,
    EFortWeaponCoreAnimation__PaperBlueprint = 3,
    EFortWeaponCoreAnimation__Rifle = 4,
    EFortWeaponCoreAnimation__MeleeOneHand = 5,
    EFortWeaponCoreAnimation__MachinePistol = 6,
    EFortWeaponCoreAnimation__RocketLauncher = 7,
    EFortWeaponCoreAnimation__GrenadeLauncher = 8,
    EFortWeaponCoreAnimation__GoingCommando = 9,
    EFortWeaponCoreAnimation__AssaultRifle = 10,
    EFortWeaponCoreAnimation__TacticalShotgun = 11,
    EFortWeaponCoreAnimation__SniperRifle = 12,
    EFortWeaponCoreAnimation__TrapPlacement = 13,
    EFortWeaponCoreAnimation__ShoulderLauncher = 14,
    EFortWeaponCoreAnimation__AbilityDecoTool = 15,
    EFortWeaponCoreAnimation__Crossbow = 16,
    EFortWeaponCoreAnimation__C4 = 17,
    EFortWeaponCoreAnimation__RemoteControl = 18,
    EFortWeaponCoreAnimation__DualWield = 19,
    EFortWeaponCoreAnimation__AR_BullPup = 20,
    EFortWeaponCoreAnimation__AR_ForwardGrip = 21,
    EFortWeaponCoreAnimation__MedPackPaddles = 22,
    EFortWeaponCoreAnimation__SMG_P90 = 23,
    EFortWeaponCoreAnimation__AR_DrumGun = 24,
    EFortWeaponCoreAnimation__Consumable_Small = 25,
    EFortWeaponCoreAnimation__Consumable_Large = 26,
    EFortWeaponCoreAnimation__Balloon = 27,
    EFortWeaponCoreAnimation__MountedTurret = 28,
    EFortWeaponCoreAnimation__CreativeTool = 29,
    EFortWeaponCoreAnimation__ExplosiveBow = 30,
    EFortWeaponCoreAnimation__AshtonIndigo = 31,
    EFortWeaponCoreAnimation__AshtonChicago = 32,
    EFortWeaponCoreAnimation__MeleeDualWield = 33,
    EFortWeaponCoreAnimation__Unarmed = 34
};

enum EFortWeaponChargeStateForFireFX : uint8_t
{
    EFortWeaponChargeStateForFireFX__Partial = 0,
    EFortWeaponChargeStateForFireFX__Full = 1,
    EFortWeaponChargeStateForFireFX__Over = 2,
    EFortWeaponChargeStateForFireFX__Max_None = 3
};

enum EFortRarity : uint8_t
{
    EFortRarity__Common = 0,
    EFortRarity__Uncommon = 1,
    EFortRarity__Rare = 2,
    EFortRarity__Epic = 3,
    EFortRarity__Legendary = 4,
    EFortRarity__Mythic = 5,
    EFortRarity__Transcendent = 6,
    EFortRarity__Unattainable = 7,
    EFortRarity__NumRarityValues = 8
};

enum EFortWeaponTriggerType : uint8_t
{
    EFortWeaponTriggerType__OnPress = 0,
    EFortWeaponTriggerType__Automatic = 1,
    EFortWeaponTriggerType__OnRelease = 2,
    EFortWeaponTriggerType__OnPressAndRelease = 3,
    EFortWeaponTriggerType__Custom = 4
};

enum EFortWeaponReloadType : uint8_t
{
    EFortWeaponReloadType__ReloadWholeClip = 0,
    EFortWeaponReloadType__ReloadIndividualBullets = 1,
    EFortWeaponReloadType__ReloadBasedOnAmmoCostPerFire = 2,
    EFortWeaponReloadType__ReloadBasedOnCartridgePerFire = 3
};

enum EFortReloadFXState : uint8_t
{
    EFortReloadFXState__ReloadStart = 0,
    EFortReloadFXState__ReloadCartridge = 1,
    EFortReloadFXState__ReloadEnd = 2,
    EFortReloadFXState__Max_None = 3
};

enum EFortWeaponHandGripType : uint8_t
{
    EFortWeaponHandGripType__Default = 0,
    EFortWeaponHandGripType__OneHand = 1,
    EFortWeaponHandGripType__TwoHand = 2
};

enum EFortCustomPartType : uint8_t
{
    EFortCustomPartType__Head = 0,
    EFortCustomPartType__Body = 1,
    EFortCustomPartType__Hat = 2,
    EFortCustomPartType__Backpack = 3,
    EFortCustomPartType__MiscOrTail = 4,
    EFortCustomPartType__Face = 5,
    EFortCustomPartType__Gameplay = 6,
    EFortCustomPartType__ExtraPart = 7,
    EFortC__L_eO_________J_K_____ = 8
};

enum EFortWeaponReduceMeshWorkSetting : uint8_t
{
    EFortWeaponReduceMeshWorkSetting__DisableTick = 0,
    EFortWeaponReduceMeshWorkSetting__DontReduceWork = 1,
    EFortWeaponReduceMeshWorkSetting__HandledInAnimInstance = 2
};

enum EFortWeaponAbilityRemovalPolicy : uint8_t
{
    EFortWeaponAbilityRemovalPolicy__GameDefault = 0,
    EFortWeaponAbilityRemovalPolicy__Remove = 1,
    EFortWeaponAbilityRemovalPolicy__Persist = 2
};

enum EItemWrapMaterialType : uint8_t
{
    EItemWrapMaterialType__WeaponWrap = 0,
    EItemWrapMaterialType__VehicleWrap_Opaque = 1,
    EItemWrapMaterialType__VehicleWrap_Masked = 2,
    EItemWrapMaterialType__Character = 3
};

enum EAdHocSquads_InviteStatus : uint8_t
{
    EAdHocSquads_InviteStatus__Unset = 0,
    EAdHocSquads_I_____6_4_0___p_fgq___ = 1,
    EAdHocSquads_InviteStatus__InviteEnded_APlayerAcceptedTheInvite = 2,
    EAdHocSquads_InviteStatus__InviteCancelled_SquadFull = 3,
    EAdHocSquads_InviteStatus__InviteCancelled_ByInvitingPlayer = 4
};

enum EBuildingReplacementType : uint8_t
{
    BRT_None = 0,
    BRT_Edited = 1,
    BRT_Upgrade = 2
};

enum EAdHocSquads_SquadUpResult : uint8_t
{
    EAdHocSquads_SquadUpResult__Success = 0,
    EAdHocSquads_SquadUpResult__Failure_OneOrMorePlayersWereNull = 1,
    EAdHocSquads_SquadUpResult__Failure_BothPlayersAreInAdHocSquads = 2,
    EAdHocSquads_SquadUpResult__Failure_BothPlayersAreAlreadyInTheSameAdHocSquad = 3,
    EAdHocSquads_SquadUpResult__Failure_CouldNotCreateAdHocSquad = 4,
    EAdHocSquads_SquadUpResult__Failure_CalledOnClient = 5,
    EAdHocSquads_SquadUpResult__Failure_SquadIsAlreadyFull = 6,
    EAdHocSquads_SquadUpResult__Failure_TooManyPlayersToMergeSquads = 7,
    EAdHocSquads_SquadUpResult__Failure_MutatorIsDisabled = 8,
    EAdHocSquads_SquadUpResult__Failure_Unknown = 9,
    EAdHocSquads_SquadUpResult__Failure_Custom = 10
};

enum EDialogMarkerInteractionState : uint8_t
{
    EDialogMarkerInteractionState__Conversation = 0,
    EDialogMarkerInteractionState__InteractionRange = 1,
    EDialogMarkerInteractionState__IndicatorRange = 2,
    EDialogMarkerInteractionState__None = 3
};

enum EFortInventoryType : uint8_t
{
    EFortInventoryType__World = 0,
    EFortInventoryType__Account = 1,
    EFortInventoryType__Outpost = 2
};

enum ECollectionBookRewardType : uint8_t
{
    ECollectionBookRewardType__Uninitialized = 0,
    ECollectionBookRewardType__Book = 1,
    ECollectionBookRewardType__Page = 2,
    ECollectionBookRewardType__Section = 3
};

enum EFortWeakPointState : uint8_t
{
    EFortWeakPointState__Uninitialized = 0,
    EFortWeakPointState__Inactive = 1,
    EFortWeakPointState__Active = 2,
    EFortWeakPointState__Destroyed = 3
};

enum EFortCreativeHeatmapDrawState : uint8_t
{
    EFortCreativeHeatmapDrawState__Visible = 0,
    EFortCreativeHeatmapDrawState__VisibleWithValues = 1,
    EFortCreativeHeatmapDrawState__NotVisible = 2,
    EFortCreativeHeatmapDrawState__Count = 3
};

enum ECreativeKeyLockState : uint8_t
{
    ECreativeKeyLockState__LOCKED = 0,
    ECreativeKeyLockState__UNLOCKED = 1,
    ECreativeKeyLockState__INVALID = 2
};

enum ELockState : uint8_t
{
    ELockState__INVALID = 0,
    ELockState__UNLOCKED = 1,
    ELockState__LOCKED = 2
};

enum EMatchConditionMutatorTimingType : uint8_t
{
    EMatchConditionMutatorTimingType__Round = 0,
    EMatchConditionMutatorTimingType__MatchAtEndOfRound = 1,
    EMatchConditionMutatorTimingType__MatchImmediate = 2,
    EMatchConditionMutatorTimingType__COUNT = 3
};

enum EFortPawnMateria_PW_________G0 : uint8_t
{
    EFortPawnMaterialOverrideFlags__None = 0,
    EFortPawnMaterialOverrideFlags__HideParticleSystems = 1,
    EFortPawnMaterialOverrideFlags__ApplyToWeapon = 2,
    EFortPawnMaterialOverrideFlags__ApplyToEmoteProps = 4,
    EFortPawnMaterialOverrideFlags__RespectPartOverrides = 8
};

enum EMiniMapComponentDiscoverableVisibility : uint8_t
{
    EMiniMapComponentDiscoverableVisibility__Unset = 0,
    EMiniMapComponentDiscoverableVisibility__NotVisible = 1,
    EMiniMapComponentDiscoverableVisibility__Visible_NotDiscovered = 2,
    EMiniMapComponentDiscoverableVisibility__Discovered = 3
};

enum EBackupSaveState : uint8_t
{
    EBackupSaveState__Ready = 0,
    EBackupSaveState__InProgress = 1,
    EBackupSaveState__OnCooldown = 2
};

enum EBuildingGameplayActorSentry_State : uint8_t
{
    EBuildingGameplayActorSentry_State__PassiveIdle = 0,
    EBuildingGameplayActorSentry_State__ActiveIdle = 1,
    EBuildingGameplayActorSentry_State__Tracking = 2,
    EBuildingGameplayActorSentry_State__Aggro = 3,
    EBuildingGameplayActorSentry_State__Dormant = 4,
    EBuildingGameplayActorSentry_State__Deactivated = 5,
    EBuildingGameplayActorSentry_State__ReturningToIdle = 6,
    EBuildingGameplayActorSentry_State__LocatingDamager = 7
};

enum ECapturePointState : uint8_t
{
    ECapturePointState__Idle = 0,
    ECapturePointState__Capturing = 1,
    ECapturePointState__Contested = 2,
    ECapturePointState__Resetting = 3,
    ECapturePointState__Captured = 4,
    ECapturePointState__Reset = 5
};

enum ECaptureState : uint8_t
{
    ECaptureState__Neutral = 0,
    ECaptureState__Capturing = 1,
    ECaptureState__Contested = 2,
    ECaptureState__Disabled = 3,
    ECaptureState__Decapturing = 4,
    ECaptureState__Neutralizing = 5,
    ECaptureState__Deneutralizing = 6,
    ECaptureState__Captured = 7
};

enum EFortMovementStyle : uint8_t
{
    EFortMovementStyle__Running = 0,
    EFortMovementStyle__Walking = 1,
    EFortMovementStyle__Charging = 2,
    EFortMovementStyle__Sprinting = 3,
    EFortMovementStyle__PersonalVehicle = 4,
    EFortMovementStyle__Flying = 5,
    EFortMovementStyle__Tethered = 6,
    EFortMovementStyle__Invalid = 7
};

enum EFortDBNOCarryEvent : uint8_t
{
    EFortDBNOCarryEvent__PickedUp = 0,
    EFortDBNOCarryEvent__Interrogating = 1,
    EFortDBNOCarryEvent__Dropped = 2,
    EFortDBNOCarryEvent__Thrown = 3
};

enum EAthenaGamePhase : uint8_t
{
    EAthenaGamePhase__None = 0,
    EAthenaGamePhase__Setup = 1,
    EAthenaGamePhase__Warmup = 2,
    EAthenaGamePhase__Aircraft = 3,
    EAthenaGamePhase__SafeZones = 4,
    EAthenaGamePhase__EndGame = 5,
    EAthenaGamePhase__Count = 6
};

enum EMatchmakingCompleteResult : uint8_t
{
    EMatchmakingCompleteResult__NotStarted = 0,
    EMatchmakingCompleteResult__UpdateNeeded = 1,
    EMatchmakingCompleteResult__OutpostNotFound = 2,
    EMatchmakingCompleteResult__Cancelled = 3,
    EMatchmakingCompleteResult__NoResults = 4,
    EMatchmakingCompleteResult__Failure = 5,
    EMatchmakingCompleteResult__CreateFailure = 6,
    EMatchmakingCompleteResult__Success = 7
};

enum EMatchmakingState : uint8_t
{
    EMatchmakingState__NotMatchmaking = 0,
    EMatchmakingState__CancelingMatchmaking = 1,
    EMatchmakingState__ReleasingLock = 2,
    EMatchmakingState__AcquiringLock = 3,
    EMatchmakingState__LockAcquistionFailure = 4,
    EMatchmakingState__FindingEmptyServer = 5,
    EMatchmakingState__FindingExistingSession = 6,
    EMatchmakingState__TestingEmptyServers = 7,
    EMatchmakingState__TestingExistingSessions = 8,
    EMatchmakingState__JoiningExistingSession = 9,
    EMatchmakingState__NoMatchesAvailable = 10,
    EMatchmakingState__CleaningUpExisting = 11,
    EMatchmakingState__HandlingFailure = 12,
    EMatchmakingState__JoinSuccess = 13
};

enum EHitTraceRule : uint8_t
{
    EHitTraceRule__Visibility = 0,
    EHitTraceRule__Terrain = 1,
    EHitTraceRule__None = 2
};

enum EScaleAxis : uint8_t
{
    EScaleAxis__All = 0,
    EScaleAxis__X = 1,
    EScaleAxis__Y = 2,
    EScaleAxis__Z = 3
};

enum ETransformationType : uint8_t
{
    ETransformationType__Translation = 0,
    ETransformationType__Rotation = 1,
    ETransformationType__Scale = 2,
    ETransformationType__None = 3
};

enum EPropertyOverrideTargetType : uint8_t
{
    EPropertyOverrideTargetType__None = 0,
    EPropertyOverrideTargetType__Default = 1,
    EPropertyOverrideTargetType__ImmutableTarget = 2
};

enum EFortMissionVisibilityOverride : uint8_t
{
    EFortMissionVisibilityOverride__Visible = 0,
    EFortMissionVisibilityOverride__Invisible = 1,
    EFortMissionVisibilityOverride__Max_None = 2,
    EFortMissionVisibilityOv_FA________________acT____sD_____43_____Lt = 3
};

enum EFortWeaponOverheatState : uint8_t
{
    EFortWeaponOverheatState__None = 0,
    EFortWeaponOverheatState__Heating = 1,
    EFortWeaponOverheatState__Cooling = 2,
    EFortWeaponOverheatState__Overheated = 3
};

enum EPortalLinkCodeLockStatus : uint8_t
{
    EPortalLinkCodeLockStatus__Unlocked_NotSet = 0,
    EPortalLinkCodeLockStatus__Unlocked = 1,
    EPortalLinkCodeLockStatus__Locked = 2
};

enum EQuartzGunfireState : uint8_t
{
    EQuartzGunfireState__FirstShot = 0,
    EQuartzGunfireState__Shooting = 1,
    EQuartzGunfireState__Stopped = 2,
    EQuartzGunfireState__Max_None = 3
};

enum EFortSafeZoneState : uint8_t
{
    EFortSafeZoneState__None = 0,
    EFortSafeZoneState__Starting = 1,
    EFortSafeZoneState__Holding = 2,
    EFortSafeZoneState__Shrinking = 3
};

enum EFortFactionAttitude : uint8_t
{
    EFortFactionAttitude__Friendly = 0,
    EFortFactionAttitude__Neutral = 1,
    EFortFactionAttitude__Hostile = 2
};

enum EAthenaStormCapState : uint8_t
{
    EAthenaStormCapState__None = 0,
    EAthenaStormCapState__Clear = 1,
    EAthenaStormCapState__Warning = 2,
    EAthenaStormCapState__Damaging = 3
};

enum ETimestampEventType : uint8_t
{
    ETimestampEventType__NamedEvent = 0,
    ETimestampEventType__ChangeBPM = 1,
    ETimestampEventType__Max_None = 2
};

enum EAthenaTravelLogPlayerType : uint8_t
{
    EAthenaTravelLogPlayerType__Self = 0,
    EAthenaTravelLogPlayerType__Ally = 1,
    EAthenaTravelLogPlayerType__Enemy = 2,
    EAthenaTravelLogPlayerType__Invalid = 3
};

enum EAthenaTravelEventType : uint8_t
{
    EAthenaTravelEventType__GroundMove = 0,
    EAthenaTravelEventType__AirMove = 1,
    EAthenaTravelEventType__BattleBusJump = 2,
    EAthenaTravelEventType__LaunchJump = 3,
    EAthenaTravelEventType__Landed = 4,
    EAthenaTravelEventType__OpenChest = 5,
    EAthenaTravelEventType__OpenAmmo = 6,
    EAthenaTravelEventType__GotAssist = 7,
    EAthenaTravelEventType__GotKnockdown = 8,
    EAthenaTravelEventType__GotKill = 9,
    EAthenaTravelEventType__PlayerDowned = 10,
    EAthenaTravelEventType__PlayerDied = 11,
    EAthenaTravelEventType__Won = 12,
    EAthenaTravelEventType__DealtDamage = 13,
    EAthenaTravelEventType__HealthChange = 14,
    EAthenaTravelEventType__GotItem = 15,
    EAthenaTravelEventType__DroppedItem = 16,
    EAthenaTravelEventType__ShieldChange = 17,
    EAthenaTravelEventType__WeaponExecuted = 18,
    EAthenaTravelEventType__EnteredVehicle = 19,
    EAthenaTravelEventType__ExitedVehicle = 20,
    EAthenaTravelEventType__TrapBuilt = 21,
    EAthenaTravelEventType__UsedItem = 22,
    EAthenaTravelEventType__ZoneUpdate = 23,
    EAthenaTravelEventType__PlacedBuilding = 24,
    EAthenaTravelEventType__EmoteUsed = 25,
    EAthenaTravelEventType__UpgradedBuilding = 26,
    EAthenaTravelEventType__EditedBuilding = 27,
    EAthenaTravelEventType__Count = 28
};

enum EGlobalWeatherState : uint8_t
{
    EGlobalWeatherState__Inactive = 0,
    EGlobalWeatherState__Active = 1,
    EGlobalWeatherState__BlendingIn = 2,
    EGlobalWeatherState__BlendingOut = 3
};

enum EUnconvertReason : uint8_t
{
    EUnconvertReason__StealByOtherPlayer = 0,
    EUnconvertReason__ConverterDeath = 1,
    EUnconvertReason__ConvertedDeath = 2,
    EUnconvertReason__TooManyConverted = 3,
    EUnconvertReason__TooFarFromConverter = 4,
    EUnconvertReason__GameplayTagBlockConvert = 5,
    EUnconvertReason__EndPlay = 6,
    EUnconvertReason__Dismiss = 7,
    EUnconvertReason__Unknown = 8
};

enum EHudVisibilityState : uint8_t
{
    EHudVisibilityState__FullyVisible = 0,
    EHudVisibilityState__FullyHidden = 1,
    EHudVisibilityState__GameOnly = 2,
    EHudVisibilityState__ReplayOnly = 3
};

enum EFortReplayEventType : uint8_t
{
    EFortReplayEventType__Elimination = 0,
    EFortReplayEventType__Eliminated = 1,
    EFortReplayEventType__DBNO = 2,
    EFortReplayEventType__UserPlaced = 3
};

enum EAthenaRoundsMutatorPhase : uint8_t
{
    EAthenaRoundsMutatorPhase__GamePhase_Setup = 0,
    EAthenaRoundsMutatorPhase__GamePhase_Warmup = 1,
    EAthenaRoundsMutatorPhase__FadeOutToNextRound = 2,
    EAthenaRoundsMutatorPhase__RoundSetup = 3,
    EAthenaRoundsMutatorPhase__RoundPlay = 4,
    EAthenaRoundsMutatorPhase__RoundEnd = 5,
    EAthenaRoundsMutatorPhase__RoundEndUI = 6,
    EAthenaRoundsMutatorPhase__MatchEndUI = 7,
    EAthenaRoundsMutatorPhase__MatchEndedPrematurely = 8
};

enum EQuestVisibilityResponse : uint8_t
{
    EQuestVisibilityResponse__Hide = 0,
    EQuestVisibilityResponse__Show = 1,
    EQuestVisibilityResponse__Custom = 2
};

enum EFortVisibilityBehavior : uint8_t
{
    EFortVisibilityBehavior__Proximity = 0,
    EFortVisibilityBehavior__OnceSeenAlwaysSeen = 1,
    EFortVisibilityBehavior__AlwaysSeen = 2,
    EFortVisibilityBehavior__Invalid = 3
};

enum EMiniMapIconParameterDataType : uint8_t
{
    EMiniMapIconParameterDataType__None = 0,
    EMiniMapIconParameterDataType__Scalar = 1,
    EMiniMapIconParameterDataType__Vector = 2,
    EMiniMapIconParameterDataType__Texture = 3
};

enum EFortMinimapLayer : uint8_t
{
    EFML_PrePOIText = 0,
    EFML_PostStorm = 1,
    EFML_PostSpecialActors = 2,
    EFML_PostSquadIcons = 3
};

enum ECreativeMinimapComponentIconColorType : uint8_t
{
    ECreativeMinimapComponentIconColorType__None = 0,
    ECreativeMinimapComponentIconColorType__White = 1,
    ECreativeMinimapComponentIconColorType__Red = 2,
    ECreativeMinimapComponentIconColorType__Orange = 3,
    ECreativeMinimapComponentIconColorType__Yellow = 4,
    ECreativeMinimapComponentIconColorType__Green = 5,
    ECreativeMinimapComponentIconColorType__Teal = 6,
    ECreativeMinimapComponentIconColorType__Blue = 7,
    ECreativeMinimapComponentIconColorType__Purple = 8
};

enum EFortProjectileDetachReason : uint8_t
{
    EFortProjectileDetachReason__HostDied = 0,
    EFortProjectileDetachReason__HostEndedPlay = 1,
    EFortProjectileDetachReason__Ejected = 2
};

enum EAllowedConfrontationalEmoteDisplaySources : uint8_t
{
    EAllowedConfrontationalEmoteDisplaySources__Anyone = 0,
    EAllowedConfrontationalEmoteDisplaySources__FriendsInParty = 1,
    EAllowedConfrontationalEmoteDisplaySources__LocalOnly = 2
};

enum EFortAllowBackgroundAudioSetting : uint8_t
{
    EFortAllowBackgroundAudioSetting__Off = 0,
    EFortAllowBackgroundAudioSetting__NotificationsOnly = 1,
    EFortAllowBackgroundAudioSetting__AllSounds = 2,
    EFortAllowBackgroundAudioSetting__Num = 3
};

enum EFortAutoMulchMode : uint8_t
{
    EFortAutoMulchMode__Off = 0,
    EFortAutoMulchMode__Common = 1,
    EFortAutoMulchMode__Uncommon = 2,
    EFortAutoMulchMode__Rare = 3,
    EFortAutoMulchMode__Epic = 4,
    EFortAutoMulchMode__Num = 5
};

enum EFortAutoMulchCategory : uint8_t
{
    EFortAutoMulchCategory__Invalid = 0,
    EFortAutoMulchCategory__Weapon = 1,
    EFortAutoMulchCategory__Trap = 2,
    EFortAutoMulchCategory__Survivor = 3,
    EFortAutoMulchCategory__Defender = 4,
    EFortAutoMulchCategory__Hero = 5,
    EFortAutoMulchCategory__Num = 6
};

enum EAutorunLockZonePreferenceMobile : uint8_t
{
    EAutorunLockZonePreferenceMobile__Off = 0,
    EAutorunLockZonePreferenceMobile__Fixed = 1,
    EAutorunLockZonePreferenceMobile__Dynamic = 2
};

enum EBrelmarCameraShake : uint8_t
{
    EBrelmarCameraShake__Default = 0,
    EBrelmarCameraShake__Low = 1,
    EBrelmarCameraShake__Off = 2
};

enum ECameraResetAxes : uint8_t
{
    ECameraResetAxes__Pitch = 0,
    ECameraResetAxes__Yaw = 1,
    ECameraResetAxes__Both = 2
};

enum EColorBlindMode : uint8_t
{
    EColorBlindMode__Off = 0,
    EColorBlindMode__Deuteranope = 1,
    EColorBlindMode__Protanope = 2,
    EColorBlindMode__Tritanope = 3
};

enum ECombinedADSFireMode : uint8_t
{
    ECombinedADSFireMode__Disabled = 0,
    ECombinedADSFireMode__OnPressed = 1,
    ECombinedADSFireMode__WhileHeld = 2
};

enum EEditAutoConfirmation : uint8_t
{
    EEditAutoConfirmation__None = 0,
    EEditAutoConfirmation__Edit = 1,
    EEditAutoConfirmation__Reset = 2,
    EEditAutoConfirmation__Both = 3
};

enum EGyroButtonResponse : uint8_t
{
    EGyroButtonResponse__NoChange = 0,
    EGyroButtonResponse__Disable = 1,
    EGyroButtonResponse__Trackball = 2,
    EGyroButtonResponse__Invert = 3,
    EGyroButtonResponse__Enable = 4
};

enum EDoughnutFillingSetting : uint8_t
{
    EDoughnutFillingSetting__CeilingAngle = 0,
    EDoughnutFillingSetting__CeilingTimeDelay = 1,
    EDoughnutFillingSetting__CeilingReleaseInput = 2,
    EDoughnutFillingSetting__Never = 3,
    EDoughnutFillingSetting__Always = 4
};

enum EGyroAcceleration : uint8_t
{
    EGyroAcceleration__Off = 0,
    EGyroAcceleration__Low = 1,
    EGyroAcceleration__Medium = 2,
    EGyroAcceleration__High = 3,
    EGyroAcceleration__Custom = 4,
    EGyroAcceleration__Legacy = 5
};

enum EGyroActiveBuildMode : uint8_t
{
    EGyroActiveBuildMode__None = 0,
    EGyroActiveBuildMode__Edit = 1,
    EGyroActiveBuildMode__All = 2
};

enum EGyroActiveMode : uint8_t
{
    EGyroActiveMode__None = 0,
    EGyroActiveMode__ScopeOnly = 1,
    EGyroActiveMode__ScopeADS = 2,
    EGyroActiveMode__ScopeADSHarvesting = 3,
    EGyroActiveMode__ScopeADSHarvestingFiring = 4,
    EGyroActiveMode__All = 5
};

enum EGyroButton : uint8_t
{
    EGyroBut_______u_e_ = 0,
    EGyroButton__ReloadInteract = 1,
    EGyroButton__TogglePickaxe = 2,
    EGyroButton__CrouchSlide = 3,
    EGyroButton__ResetCamera = 4,
    EGyroButton__Touch = 5
};

enum EAxisDirection : uint8_t
{
    EAxisDirection__Disabled = 0,
    EAxisDirection__Standard = 1,
    EAxisDirection__Inverted = 2
};

enum EGyroSpace : uint8_t
{
    EGyroSpace__Local = 0,
    EGyroSpace__Player = 1
};

enum EGyroStickMode : uint8_t
{
    EGyroStickMode__None = 0,
    EGyroStickMode__Disables = 1,
    EGyroStickMode__Enables = 2
};

enum EGyroTouchMode : uint8_t
{
    EGyroTouchMode__None = 0,
    EGyroTouchMode__Disables = 1,
    EGyroTouchMode__Enables = 2
};

enum EHitFeedbackMode : uint8_t
{
    EHitFeedbackMode__Invalid = 0,
    EHitFeedbackMode__HitAndIcon = 1,
    EHitFeedbackMode__HitOnly = 2,
    EHitFeedbackMode__Off = 3,
    EHitFeedbackMode__Num = 4
};

enum EHitNumbersMode : uint8_t
{
    EHitNumbersMode__Invalid = 0,
    EHitNumbersMode__Cumulative = 1,
    EHitNumbersMode__List = 2,
    EHitNumbersMode__Num = 3
};

enum EJoyConMotionSelection : uint8_t
{
    EJoyConMotionSelection__Left = 0,
    EJoyConMotionSelection__Right = 1
};

enum ELicensedAudioTreatment : uint8_t
{
    ELicensedAudioTreatment__None = 0,
    ELicensedAudioTreatment__MuteOthers = 1,
    ELicensedAudioTreatment__MuteAll = 2
};

enum EFortMotionYawAxis : uint8_t
{
    EFortMotionYawAxis__Yaw = 0,
    EFortMotionYawAxis__Roll = 1
};

enum EPostpartyClippingState : uint8_t
{
    EPostpartyClippingState__Unset = 0,
    EPostpartyClippingState__Disabled = 1,
    EPostpartyClippingState__Enabled = 2
};

enum EFortPreferredItemSlotItemType : uint8_t
{
    EFortPreferredItemSlotItemType__Unassigned = 0,
    EFortPreferredItemSlotItemType__AssaultRifle = 1,
    EFortPreferredItemSlotItemType__Shotgun = 2,
    EFortPreferredItemSlotItemType__SMG = 3,
    EFortPreferredItemSlotItemType__Pistol = 4,
    EFortPreferredItemSlotItemType__SniperAndBow = 5,
    EFortPreferredItemSlotItemType__Launcher = 6,
    EFortPreferredItemSlotItemType__Utility = 7,
    EFortPreferredItemSlotItemType__Consumable = 8,
    EFortPreferredItemSlotItemType__Num = 9
};

enum EQuickWeaponButtonGroup : uint8_t
{
    EQuickWeaponButtonGroup__DPad = 0,
    EQuickWeaponButtonGroup__FaceButtons = 1,
    EQuickWeaponButtonGroup__Both = 2
};

enum EQuickWeaponToggle : uint8_t
{
    EQuickWeaponToggle__None = 0,
    EQuickWeaponToggle__Secondary = 1,
    EQuickWeaponToggle__PreviouslyEquipped = 2
};

enum EFortReticleColor : uint8_t
{
    EFortReticleColor__Red = 0,
    EFortReticleColor__Orange = 1,
    EFortReticleColor__Yellow = 2,
    EFortReticleColor__Green = 3,
    EFortReticleColor__Cyan = 4,
    EFortReticleColor__Blue = 5,
    EFortReticleColor__Purple = 6,
    EFortReticleColor__Magenta = 7
};

enum ETouchInteractMode : uint8_t
{
    ETouchInteractMode__Off = 0,
    ETouchInteractMode__InWorld = 1,
    ETouchInteractMode__Buttons = 2
};

enum EVisualizeAudioPriority : uint8_t
{
    EVisualizeAudioPriority__HighPriority = 0,
    EVisualizeAudioPriority__All = 1
};

enum EFreeDroneFocusMode : uint8_t
{
    EFreeDroneFocusMode__Manual = 0,
    EFreeDroneFocusMode__Auto = 1,
    EFreeDroneFocusMode__Target = 2
};

enum EFortGamepadLookInputCurve : uint8_t
{
    EFortGamepadLookInputCurve__Linear = 0,
    EFortGamepadLookInputCurve__Exponential = 1
};

enum EFortGamepadSensitivity : uint8_t
{
    EFortGamepadSensitivity__Invalid = 0,
    EFortGamepadSensitivity__Slow = 1,
    EFortGamepadSensitivity__SlowPlus = 2,
    EFortGamepadSensitivity__SlowPlusPlus = 3,
    EFortGamepadSensitivity__Normal = 4,
    EFortGamepadSensitivity__NormalPlus = 5,
    EFortGamepadSensitivity__NormalPlusPlus = 6,
    EFortGamepadSensitivity__Fast = 7,
    EFortGamepadSensitivity__FastPlus = 8,
    EFortGamepadSensitivity__FastPlusPlus = 9,
    EFortGamepadSensitivity__Insane = 10
};

enum ECloudFileState : uint8_t
{
    ECloudFileState__Unitialized = 0,
    ECloudFileState__Saving = 1,
    ECloudFileState__Loading = 2,
    ECloudFileState__Idle = 3
};

enum EKWSSetttingIndividalMigration : uint8_t
{
    EKWSSetttingIndividalMigration__PartyJoinability = 0,
    EKWSSetttingIndividalMigration__ShowSeasonLevenInFeed = 1,
    EKWSSetttingIndividalMigration__ShowPlayerSurveys = 2,
    EKWSSetttingIndividalMigration__ReceiveGiftsAllowed = 3
};

enum EQuestMapScreenMode : uint8_t
{
    EQuestMapScreenMode__Invalid = 0,
    EQuestMapScreenMode__MainCampaign = 1,
    EQuestMapScreenMode__Event = 2,
    EQuestMapScreenMode__EQuestM___iW___J_______ = 3
};

enum EHUDLayoutToolTheme : uint8_t
{
    EHUDLayoutToolTheme__None = 0,
    EHUDLayoutToolTheme__Default = 1,
    EHUDLayoutToolTheme__Dark = 2
};

enum ESchemaModificationType : uint8_t
{
    ESchemaModificationType__AddOrModify = 0,
    ESchemaModificationType__Remove = 1,
    ESchemaModificationType__Count = 2
};

enum EFireModeType : uint8_t
{
    EFireModeType__Unset = 0,
    EFireModeType__TapToShoot = 1,
    EFireModeType__FireButton = 2,
    EFireModeType__AutoFire = 3,
    EFireModeType__ForceTouch = 4,
    EFireModeType__Custom = 5
};

enum EBacchusHUDStateType : uint8_t
{
    EBacchusHUDStateType__DoNothing = 0,
    EBacchusHUDStateType__Hide = 1,
    EBacchusHUDStateType__Show = 2,
    EBacchusHUDStateType__FallbackToDefault = 3
};

enum EAndroidAppStoreTypes : uint8_t
{
    EAndroidAppStoreTypes__Unset = 0,
    EAndroidAppStoreTypes__Epic = 1,
    EAndroidAppStoreTypes__Samsung = 2
};

enum EFortInventoryCustomFilter : uint8_t
{
    EFortInventoryCustomFilter__Mythic = 0,
    EFortInventoryCustomFilter__Legendary = 1,
    EFortInventoryCustomFilter__Epic = 2,
    EFortInventoryCustomFilter__Rare = 3,
    EFortInventoryCustomFilter__Uncommon = 4,
    EFortInventoryCustomFilter__Common = 5
};

enum EAthenaPinnedQuestType : uint8_t
{
    EAthenaPinnedQuestType__UserSelected = 0,
    EAthenaPinnedQuestType__ConciergeSuggested = 1,
    EAthenaPinnedQuestType__NoPinnedQuest = 2
};

enum EQuickEditPreviewMethod : uint8_t
{
    EQuickEditPreviewMethod__MeshPreview = 0,
    EQuickEditPreviewMethod__PatternGrid = 1,
    EQuickEditPreviewMethod__Pips = 2
};

enum EPlayerBountyThreatLevel : uint8_t
{
    EPlayerBountyThreatLevel__Low = 0,
    EPlayerBountyThreatLevel__Medium = 1,
    EPlayerBountyThreatLevel__High = 2
};

enum EFortQuestState : uint8_t
{
    EFortQuestState__Inactive = 0,
    EFortQuestState__Active = 1,
    EFortQuestState__Completed = 2,
    EFortQuestState__Claimed = 3
};

enum EFortSimulatedXPSize : uint8_t
{
    EFortSimulatedXPSize__None = 0,
    EFortSimulatedXPSize__VerySmall = 1,
    EFortSimulatedXPSize__Small = 2,
    EFortSimulatedXPSize__Medium = 3,
    EFortSimulatedXPSize__Large = 4,
    EFortSimulatedXPSize__VeryLarge = 5
};

enum EFortDialogFeedbackType : uint8_t
{
    EFortDialogFeedbackType__FriendRequestSent = 0,
    EFortDialogFeedbackType__FriendRequestReceived = 1,
    EFortDialogFeedbackType__FriendRequestAccepted = 2,
    EFortDialogFeedbackType__Default = 3
};

enum EFortAbilityTargetSelectionUsage : uint8_t
{
    EFortAbilityTargetSelectionUsage__BothTargetingAndCanHit = 0,
    EFortAbilityTargetSelectionUsage__OnlyTargeting = 1,
    EFortAbilityTargetSelectionUsage__OnlyCanHit = 2
};

enum EFortTargetSelectionFilter : uint8_t
{
    EFortTargetSelectionFilter__Damageable = 0,
    EFortTargetSelectionFilter_R_Y_ix_____ = 1,
    EFortTargetSelectionFilter__Pawns = 2,
    EFortTargetSelectionFilter__Buildings = 3,
    EFortTargetSelectionFilter__Walls = 4,
    EFortTargetSelectionFilter__Traps = 5,
    EFortTargetSelectionFilter__Players = 6,
    EFortTargetSelectionFilter__AIPawns = 7,
    EFortTargetSelectionFilter__Instigator = 8,
    EFortTargetSelectionFilter__WeakSpots = 9,
    EFortTargetSelectionFilter__World = 10,
    EFortTargetSelectionFilter__Max = 11
};

enum EFortTargetSelectionTestType : uint8_t
{
    EFortTargetSelectionTestType__Overlap = 0,
    EFortTargetSelectionTestType__Swept = 1,
    EFortTargetSelectionTestType__Ballistic = 2
};

enum EFortTargetSelectionShape : uint8_t
{
    EFortTargetSelectionShape__Sphere = 0,
    EFortTargetSelectionShape__Cone = 1,
    EFortTargetSelectionShape__Box = 2,
    EFortTargetSelectionShape__Capsule = 3,
    EFortTargetSelectionShape__Line = 4,
    EFortTargetSelectionShape__Cylinder = 5,
    EFortTargetSelectionShape__Custom = 6,
    EFortTargetSelectionShape__CustomOnSource = 7
};

enum EFortGetPlayerPawnExecutions : uint8_t
{
    EFortGetPlayerPawnExecutions__ValidFortPlayerPawn = 0,
    EFortGetPlayerPawnExecutions__AvatarCastFailed = 1
};

enum EFortGameplayAbilityTagChangedActionType : uint8_t
{
    EFortGameplayAbilityTagChangedActionType__Cancel = 0
};

enum EFortGameplayAbilityTagChangedEvent : uint8_t
{
    EFortGameplayAbilityTagChangedEvent__NewlyAdded = 0,
    EFortGameplayAbilityTagChangedEvent__Increased = 1,
    EFortGameplayAbilityTagChangedEvent__FullyRemoved = 2,
    EFortGameplayAbilityTagChangedEvent__Decreased = 3
};

enum EFortGameplayAbilityMontageSectionToPlay : uint8_t
{
    EFortGameplayAbilityMontageSectionToPlay__FirstSection = 0,
    EFortGameplayAbilityMontageSectionToPlay__RandomSection = 1,
    EFortGameplayAbilityMontageSectionToPlay__TestedRandomSection = 2
};

enum EFortAIWeaponUsage : uint8_t
{
    EFortAIWeaponUsage__NoWeaponUsage = 0,
    EFortAIWeaponUsage__UsesRangedWeapon = 1,
    EFortAIWeaponUsage__UsesMeleeWeapon = 2
};

enum EFortAILODLevel : uint8_t
{
    EFortAILODLevel__Invalid = 0,
    EFortAILODLevel__MIN = 0,
    EFortAILODLevel__Dormant = 1,
    EFortAILODLevel__BelowLower = 2,
    EFortAILODLevel__Lower = 3,
    EFortAILODLevel__AboveLower = 4,
    EFortAILODLevel__BelowNormal = 5,
    EFortAILODLevel__Normal = 6,
    EFortAILODLevel__AboveNormal = 7
};

enum EFortAbilityCostSource : uint8_t
{
    EFortAbilityCostSource__Stamina = 0,
    EFortAbilityCostSource__Durability = 1,
    EFortAbilityCostSource__AmmoMagazine = 2,
    EFortAbilityCostSource__AmmoPrimary = 3,
    EFortAbilityCostSource__Item = 4
};

enum EFortGameplayAbilityActivation : uint8_t
{
    EFortGameplayAbilityActivation__Passive = 0,
    EFortGameplayAbilityActivation__Triggered = 1,
    EFortGameplayAbilityActivation__Active = 2
};

enum EHeldObjectState : uint8_t
{
    EHeldObjectState__Unheld = 0,
    EHeldObjectState__Held = 1,
    EHeldObjectState__Thrown = 2,
    EHeldObjectState__Placed = 3,
    EHeldObjectState__Dropped = 4,
    EHeldObjectState__HeldInVehicle = 5
};

enum ELinkToDirection : uint8_t
{
    ELinkToDirection__Up = 0,
    ELinkToDirection__Down = 1,
    ELinkToDirection__Right = 2,
    ELinkToDirection__Left = 3,
    ELinkToDirection__Forward = 4,
    ELinkToDirection__Backward = 5
};

enum EFortAlteration : uint8_t
{
    EFortAlteration__AttributeSlot = 0,
    EFortAlteration__GameplaySlot = 1,
    EFortAlteration__ComplexCosmeticSlot = 2,
    EFortAlteration__UserPickedCosmeticSlot = 3,
    EFortAlteration__ColorSlot = 4,
    EFortAlteration__HeroSpecializationTier1Slot = 5,
    EFortAlteration__HeroSpecializationTier2Slot = 6,
    EFortAlteration__HeroSpecializationTier3Slot = 7,
    EFortAlteration__HeroSpecializationTier4Slot = 8,
    EFortAlteration__HeroSpecializationTier5Slot = 9
};

enum EPlayerCompetitiveBanReasons : uint8_t
{
    EPlayerCompetitiveBanReasons__None = 0,
    EPlayerCompetitiveBanReasons__Cheating = 1,
    EPlayerCompetitiveBanReasons__Collusion = 2,
    EPlayerCompetitiveBanReasons__Toxicity = 3,
    EPlayerCompetitiveBanReasons__Harassment = 4,
    EPlayerCompetitiveBanReasons__Ringing = 5,
    EPlayerCompetitiveBanReasons__Gambling = 6,
    EPlayerCompetitiveBanReasons__Exploiting = 7,
    EPlayerCompetitiveBanReasons__IntentionalDisconnect = 8,
    EPlayerCompetitiveBanReasons__IllegalRestart = 9,
    EPlayerCompetitiveBanReasons__Other = 10,
    EPlayerCompetitiveBanReasons__AccountSharing = 11,
    EPlayerCompetitiveBanReasons__CircumventingRegionLock = 12,
    EPlayerCompetitiveBanReasons__CircumventingBan = 13,
    EPlayerCompetitiveBanReasons__Smurfing = 14,
    EPlayerCompetitiveBanReasons__CircumventingTeamLock = 15,
    EPlayerCompetitiveBanReasons__RuleViolation = 16
};

enum EAthenaRebootEligiblityStatus : uint8_t
{
    EAthenaRebootEligiblityStatus__None = 0,
    EAthenaRebootEligiblityStatus__User = 1,
    EAthenaRebootEligiblityStatus__Squad = 2
};

enum ECampaignCustomizationCategory : uint8_t
{
    ECampaignCustomizationCategory__None = 0,
    ECampaignCustomizationCategory__PersonalVehicle = 1
};

enum EFortMusicPlaybackType : uint8_t
{
    EFortMusicPlaybackType__Normal = 0,
    EFortMusicPlaybackType__Preview = 1,
    EFortMusicPlaybackType__Stems = 2,
    EFortMusicPlaybackType__Instrumental = 3
};

enum EAthenaPartyMemberReadyType : uint8_t
{
    EAthenaPartyMemberReadyType__Ready = 0,
    EAthenaPartyMemberReadyType__NotReady = 1,
    EAthenaPartyMemberReadyType__Playing = 2,
    EAthenaPartyMemberReadyType__Spectating = 3,
    EAthenaPartyMemberReadyType__WatchingReplay = 4
};

enum EFortFriendRequestStatus : uint8_t
{
    EFors6E_________T__T________G0 = 0,
    EFortFriendRequestStatus__Accepted = 1,
    EFortFriendRequestStatus__PendingReceived = 2,
    EFortFriendRequestStatus__PendingSent = 3
};

enum EFortPartyMemberLocation : uint8_t
{
    EFortPartyMemberLocation__PreLobby = 0,
    EFortPartyMemberLocation__ConnectingToLobby = 1,
    EFortPartyMemberLocation__Lobby = 2,
    EFortPartyMemberLocation__JoiningGame = 3,
    EFortPartyMemberLocation__ProcessingRejoin = 4,
    EFortPartyMemberLocation__InGame = 5,
    EFortPartyMemberLocation__Spectating = 6,
    EFortPartyMemberLocation__WatchingReplay = 7,
    EFortPartyMemberLocation__ReturningToFrontEnd = 8
};

enum EFortPartyState : uint8_t
{
    EFortPartyState__Undetermined = 0,
    EFortPartyState__WorldView = 1,
    EFortPartyState__TheaterView = 2,
    EFortPartyState__Matchmaking = 3,
    EFortPartyState__PostMatchmaking = 4,
    EFortPartyState__ReturningToFrontEnd = 5,
    EFortPartyState__BattleRoyaleView = 6,
    EFortPartyState__BattleRoyalePreloading = 7,
    EFortPartyState__BattleRoyaleMatchmaking = 8,
    EFortPartyState__BattleRoyalePostMatchmaking = 9
};

enum EPlaytimeState : uint8_t
{
    EPlaytimeState__Unblocked = 0,
    EPlaytimeState__Blocked = 1,
    EPlaytimeState__Idle = 2,
    EPlaytimeState__Sleep = 3,
    EPlaytimeState__Uninitialized = 4
};

enum EFortHomingStyle : uint8_t
{
    EFortHomingStyle__None = 0,
    EFortHomingStyle__LockOn = 1,
    EFortHomingStyle__LaserTargeted = 2,
    EFortHomingStyle__LaserTargeted_NoTrace = 3,
    EFortHomingStyle__DrunkArtillery = 4
};

enum EFortHomingOffsetStyle : uint8_t
{
    EFortHomingOffsetStyle__Auto = 0,
    EFortHomingOffsetStyle__Absolute = 1
};

enum EFortPrototypingStatus : uint8_t
{
    EFortPrototypingStatus__Unknown = 0,
    EFortPrototypingStatus__Disabled = 1,
    EFortPrototypingStatus__Enabled = 2
};

enum EXPEventPriorityType : uint8_t
{
    EXPEventPriorityType__NearReticle = 0,
    EXPEventPriorityType__XPBarOnly = 1,
    EXPEventPriorityType__TopCenter = 2,
    EXPEventPriorityType__Feed = 3
};

enum EFortQuestAnalyticState : uint8_t
{
    EFortQuestAnalyticState__None = 0,
    EFortQuestAnalyticState__Granted = 1,
    EFortQuestAnalyt______0___G_K_pf = 2
};

enum EFortQuestType : uint8_t
{
    EFortQuestType__Task = 0,
    EFortQuestType__Optional = 1,
    EFortQuestType__DailyQuest = 2,
    EFortQuestType__TransientQuest = 3,
    EFortQuestType__SurvivorQuest = 4,
    EFortQuestType__Achievement = 5,
    EFortQuestType__Onboarding = 6,
    EFortQuestType__Athena = 7,
    EFortQuestType__AthenaDailyQuest = 8,
    EFortQuestType__AthenaEvent = 9,
    EFortQuestType__AthenaChallengeBundleQuest = 10,
    EFortQuestType__AthenaLooseQuest = 11,
    EFortQuestType__All = 12
};

enum EFortTheaterType : uint8_t
{
    EFortTheaterType__Standard = 0,
    EFortTheaterType__Elder = 1,
    EFortTheaterType__PvP = 2,
    EFortTheaterType__PvP2 = 3,
    EFortTheaterType__Tutorial = 4,
    EFortTheaterType__TutorialGate = 5,
    EFortTheaterType__Max_None = 6
};

enum EFortNotificationType : uint8_t
{
    EFortNotificationType__Default = 0,
    EFortNotificationType__Power = 1,
    EFortNotificationType__HealthWarning = 2,
    EFortNotificationType__Error = 3,
    EFortNotificationType__GiftSent = 4,
    EFortNotificationType__VoiceChannel = 5,
    EFortNotificationType__DonutChallenge = 6,
    EFortNotificationType__SocialNotification = 7,
    EFortNotificationType__BattlePassPageUnlock = 8,
    EFortNotificationType__DownloadOnDemandError = 9,
    EFortNotificationType__DownloadCompleted = 10,
    EFortNotificationType__CompeteStart = 11,
    EFortNotificationType__Playtime = 12,
    EFortNotificationType__Max = 13
};

enum EFortNotificationPriority : uint8_t
{
    EFortNotificationPriority__Vote = 0,
    EFortNotificationPriority__Friend = 1,
    EFortNotificationPriority__BoostedXP = 2,
    EFortNotificationPriority__GeneralSendNotification = 3,
    EFortNotificationPriority__Max = 4
};

enum EClampToScreenDirection : uint8_t
{
    EClampToScreenDirection__Left = 0,
    EClampToScreenDirection__Top = 1,
    EClampToScreenDirection__Right = 2,
    EClampToScreenDirection__Bottom = 3,
    EClampToScreenDirection__None = 4
};

enum EIntelStateEnum : uint8_t
{
    EIntelStateEnum__None = 0,
    EIntelStateEnum__OnGround = 1,
    EIntelStateEnum__HeldByAttacker = 2,
    EIntelStateEnum__HeldByDefender = 3,
    EIntelStateEnum__Downloaded = 4,
    EIntelStateEnum__Captured = 5,
    EIntelStateEnum__Downloading = 6
};

enum EFortCreativeLinearMoverRotationDirection : uint8_t
{
    EFortCreativeLinearMoverRotationDirection__EFCLMRD_Clockwise = 0,
    EFortCreativeLinearMoverRotationDirection__EFCLMRD_CounterClockwise = 1
};

enum EFortCreativeLinearMoverTranslationType : uint8_t
{
    EFortCreativeLinearMoverTranslationType__EFCLMTT_None = 0,
    EFortCreativeLinearMoverTranslationType__EFCLMTT_Forward = 1,
    EFortCreativeLinearMoverTranslationType__EFCLMTT_Reverse = 2
};

enum EFortCreativeLinearMoverMode : uint8_t
{
    EFortCreativeLinearMoverMode__EFCLMM_Translation = 0,
    EFortCreativeLinearMoverMode__EFCLMM_Rotation = 1
};

enum EFortCreativeLinearMoverRotationAxis : uint8_t
{
    EFortCreativeLinearMoverRotationAxis__EFCLMRA_Roll = 0,
    EFortCreativeLinearMoverRotationAxis__EFCLMRA_Pitch = 1,
    EFortCreativeLinearMoverRotationAxis__EFCLMRA_Yaw = 2
};

enum EFortCreativeLinearMoverMovementCompleteBehavior : uint8_t
{
    EFortCreativeLinearMoverMovementCompleteBehavior__EFCLMMS_None = 0,
    EFortCreativeLinearMoverMovementCompleteBehavior__EFCLMMS_Repeat = 1,
    EFortCreativeLinearMoverMovementCompleteBehavior__EFCLMMS_PingPong = 2,
    EFortCreativeLinearMoverMovementCompleteBehavior__EFCLMMS_Reset = 3
};

enum EFortKeyframedMovementMovementMode : uint8_t
{
    EFortKeyframedMovementMovementMode__EFKMMM_OneShot = 0,
    EFortKeyframedMovementMovementMode__EFKMMM_Loop = 1,
    EFortKeyframedMovementMovementMode__EFKMMM_PingPong = 2
};

enum EFortKeyframedMovementNetCommand : uint8_t
{
    EFortKeyframedMovementNetCommand__EFKMNC_PlayFrom = 0,
    EFortKeyframedMovementNetCommand__EFKMNC_HaltAt = 1
};

enum EAthenaBroadcastKillFeedEntryType : uint8_t
{
    EAthenaBroadcastKillFeedEntryType__Elimination = 0,
    EAthenaBroadcastKillFeedEntryType__Storm = 1,
    EAthenaBroadcastKillFeedEntryType__FallDamage = 2,
    EAthenaBroadcastKillFeedEntryType__Explosion = 3,
    EAthenaBroadcastKillFeedEntryType__DBNO = 4
};

enum EGroupMontagePreviewFollowerJoinBehavior : uint8_t
{
    EGroupMontagePreviewFollowerJoinBehavior__Automatic = 0,
    EGroupMontagePreviewFollowerJoinBehavior__Immediate = 1,
    EGroupMontagePreviewFollowerJoinBehavior__AfterLeaderIntroDelay = 2
};

enum EGroupEmotePreviewPivotOrigin : uint8_t
{
    EGroupEmotePreviewPivotOrigin__AtLeaderPawn = 0,
    EGroupEmotePreviewPivotOrigin__BetweenLeaderAndFirstFollower = 1,
    EGroupEmotePreviewPivotOrigin__ManualOffsetRelativeToLeaderPawn = 2
};

enum ECosmeticCompatibleModeLegacy : uint8_t
{
    ECosmeticCompatibleModeLegacy__BattleRoyale = 0,
    ECosmeticCompatibleModeLegacy__Juno = 1,
    ECosmeticCompatibleModeLegacy__DelMar = 2,
    ECosmeticCompatibleModeLegacy__Sparks = 3
};

enum EBattlePassRewardSource : uint8_t
{
    EBattlePassRewardSource__None = 0,
    EBattlePassRewardSource__ChallengeBundle = 1,
    EBattlePassRewardSource__Quest = 2
};

enum ESeasonTitleDisplayType : uint8_t
{
    ESeasonTitleDisplayType__ChapterAndSeason = 0,
    ESeasonTitleDisplayType__OnlySeason = 1,
    ESeasonTitleDisplayType__OnlyChapter = 2,
    ESeasonTitleDisplayType__OnlySeasonNoFormat = 3,
    ESeasonTitleDisplayType__OnlyChapterNoFormat = 4
};

enum EAttributeHandling : uint8_t
{
    EAttributeHandling__HealthAmount = 0,
    EAttributeHandling__HealthPercent = 1,
    EAttributeHandling__ShieldAmount = 2,
    EAttributeHandling__ShieldPercent = 3,
    EAttributeHandling__OverShieldAmount = 4,
    EAttributeHandling__OverShieldPercent = 5
};

enum ESidedVisibility : uint8_t
{
    ESidedVisibility__LeftOnly = 0,
    ESidedVisibility__RightOnly = 1,
    ESidedVisibility__Both = 2
};

enum ECreativeLayoutAnchorOption : uint8_t
{
    ECreativeLayoutAnchorOption__TopLeft = 0,
    ECreativeLayoutAnchorOption__TopCenter = 1,
    ECreativeLayoutAnchorOption__TopRight = 2,
    ECreativeLayoutAnchorOption__CenterLeft = 3,
    ECreativeLayoutAnchorOption__CenterCenter = 4,
    ECreativeLayoutAnchorOption__CenterRight = 5,
    ECreativeLayoutAnchorOption__BottomLeft = 6,
    ECreativeLayoutAnchorOption__BottomCenter = 7,
    ECreativeLayoutAnchorOption__BottomRight = 8
};

enum ECreativeLayoutAlignmentOption : uint8_t
{
    ECreativeLayoutAlignmentOption__TopLeft = 0,
    ECreativeLayoutAlignmentOption__TopCenter = 1,
    ECreativeLayoutAlignmentOption__TopRight = 2,
    ECreativeLayoutAlignmentOption__MiddleLeft = 3,
    ECreativeLayoutAlignmentOption__Centered = 4,
    ECreativeLayoutAlignmentOption__MiddleRight = 5,
    ECreativeLayoutAlignmentOption__BottomLeft = 6,
    ECreativeLayoutAlignmentOption__BottomCenter = 7,
    ECreativeLayoutAlignmentOption__BottomRight = 8,
    ECreativeLayoutAlignmentOption__CenteredFull = 9,
    ECreativeLayoutAlignmentOption__LeftTall = 10,
    ECreativeLayoutAlignmentOption__CenteredTall = 11,
    ECreativeLayoutAlignmentOption__RightTall = 12,
    ECreativeLayoutAlignmentOption__TopWide = 13,
    ECreativeLayoutAlignmentOption__CenteredWide = 14,
    ECreativeLayoutAlignmentOption__BottomWide = 15
};

enum ECreativeRegisteredPlayerGroups : uint8_t
{
    ECreativeRegisteredPlayerGroups__None = 0,
    ECreativeRegisteredPlayerGroups__RegisteredPlayers = 1,
    ECreativeRegisteredPlayerGroups__NonRegisteredPlayers = 2,
    ECreativeRegisteredPlayerGroups__Everyone = 3
};

enum ECreativePlayerSpawnMethod : uint8_t
{
    ECreativePlayerSpawnMethod__Spawner = 0,
    ECreativePlayerSpawnMethod__Rift = 1,
    ECreativePlayerSpawnMethod__Aircraft = 2
};

enum EScoreDistributionType : uint8_t
{
    EScoreDistributionType__Default = 0,
    EScoreDistributionType__DivideByDamage = 1,
    EScoreDistributionType__DivideEvenly = 2,
    EScoreDistributionType__AllToEliminator = 3
};

enum ECustomHatType : uint8_t
{
    ECustomHatType_None = 0,
    ECustomHatType_Cap = 1,
    ECustomHatType_Helmet = 2,
    ECustomHatType_Mask = 3,
    ECustomHatType_Hat = 4,
    ECustomHatType_HeadReplacement = 5,
    NumHatTypes = 6
};

enum EColorSwatchType : uint8_t
{
    EColorSwatchType_Skin = 0,
    EColorSwatchType_Hair = 1,
    EColorSwatchType_BodyAccessory = 2,
    EColorSwatchType_Accessory = 3,
    EColorSwatchType_NumTypes = 4
};

enum ECharacterColorSwatchType : uint8_t
{
    ECharacterColorSwatchType_Skin = 0,
    ECharacterColorSwatchType_Hair = 1,
    ECharacterColorSwatchType_NumTypes = 2
};

enum EVkEditStatus : uint8_t
{
    EVkEditStatus__DEFAULT = 0,
    EVkEditStatus__UpToDate = 1,
    EVkEditStatus__RefreshRequested = 2,
    EVkEditStatus__RefreshRequired = 3,
    EVkEditStatus__Uploading = 4,
    EVkEditStatus__Staging = 5,
    EVkEditStatus__Preparing = 6,
    EVkEditStatus__Downloading = 7,
    EVkEditStatus__LoadingProject = 8,
    EVkEditStatus__Error = 9,
    EVkEditStatus__NumStatuses = 10
};

enum EFortAccoladeType : uint8_t
{
    EFortAccoladeType__Acknowledgement = 0,
    EFortAccoladeType__Accolade = 1,
    EFortAccoladeType__Medal = 2
};

enum EFortAIUtility : uint8_t
{
    EFortAIUtility__KillPlayersMelee = 0,
    EFortAIUtility__KillPlayersRanged = 1,
    EFortAIUtility__KillPlayersArtillery = 2,
    EFortAIUtility__DestroyBuildingsMelee = 3,
    EFortAIUtility__DestroyBuildingsRanged = 4,
    EFortAIUtility__DestroyBuildingsArtillery = 5,
    EFortAIUtility__DestroyTraps = 6,
    EFortAIUtility__Tank = 7
};

enum EFortArrayElementPosition : uint8_t
{
    EFortArrayElementPosition__None = 0,
    EFortArrayElementPosition__First = 1,
    EFortArrayElementPosition__Last = 2,
    EFortArrayElementPosition__Random = 3
};

enum EBuildingDamageTeamFilter : uint8_t
{
    EBuildingDamageTeamFilter__Default = 0,
    EBuildingDamageTeamFilter__OwnerOnly = 1,
    EBuildingDamageTeamFilter__TeamOnly = 2,
    EBuildingDamageTeamFilter__EnemyOnly = 3,
    EBuildingDamageTeamFilter__EnemyAndOwnerOnly = 4,
    EBuildingDamageTeamFilter__None = 5
};

enum EEnvironmentDamageFilter : uint8_t
{
    EEnvironmentDamageFilter__Off = 0,
    EEnvironmentDamageFilter__PlayerBuiltOnly = 1,
    EEnvironmentDamageFilter__All = 2
};

enum ECoastState : uint8_t
{
    ECoastState__Idle = 0,
    ECoastState__Mount = 1,
    ECoastState__Coasting = 2,
    ECoastState__Pedaling = 3,
    ECoastState__PreDismount = 4,
    ECoastState__Dismount = 5,
    ECoastState__EndCoast = 6
};

enum EPowerSlideState : uint8_t
{
    EPowerSlideState__None = 0,
    EPowerSlideState__Entering = 1,
    EPowerSlideState__InProgress = 2,
    EPowerSlideState__Exiting = 3
};

enum ENaturalSlideState : uint8_t
{
    ENaturalSlideState__None = 0,
    ENaturalSlideState__Entering = 1,
    ENaturalSlideState__InProgress = 2,
    ENaturalSlideState__Exiting = 3
};

enum EBounceCompressionState : uint8_t
{
    EBounceCompressionState__None = 0,
    EBounceCompressionState__Crouching = 1,
    EBounceCompressionState__Crouched = 2,
    EBounceCompressionState__Jumping = 3,
    EBounceCompressionState__Recoiling = 4
};

enum EFortAudioTODScheduleMode : uint8_t
{
    EFortAudioTODScheduleMode__RelativeToDayPhaseChange = 0,
    EFortAudioTODScheduleMode__RandomTimeDuringDayPhase = 1,
    EFortAudioTODScheduleMode__PlayInTimeRange = 2,
    EFortAudioTODScheduleMode__Count = 3
};

enum EAutorunActivationMode : uint8_t
{
    EAutorunActivationMode__None = 0,
    EAutorunActivationMode__DoubleTap = 1,
    EAutorunActivationMode__LockZoneButton = 2
};

enum EDoghouseControlMode : uint8_t
{
    EDoghouseControlMode__GroundControls = 0,
    EDoghouseControlMode__AirControls = 1,
    EDoghouseControlMode__MaxCount = 2
};

enum EAileronRollDirection : uint8_t
{
    EAileronRollDirection__None = 0,
    EAileronRollDirection__Right = 1,
    EAileronRollDirection__Left = 2
};

enum EBiplaneSimEvent : uint8_t
{
    EBiplaneSimEvent__EngineStart = 0,
    EBiplaneSimEvent__EngineStop = 1,
    EBiplaneSimEvent__Takeoff = 2,
    EBiplaneSimEvent__Landing = 3,
    EBiplaneSimEvent__BoostBegin = 4,
    EBiplaneSimEvent__BoostEnd = 5,
    EBiplaneSimEvent__BoostChargeAboveThreshold = 6,
    EBiplaneSimEvent__AileronRoll = 7,
    EBiplaneSimEvent__ControlContextChange = 8
};

enum EFortBrushSize : uint8_t
{
    EFortBrushSize__VeryVerySmall = 0,
    EFortBrushSize__VerySmall = 1,
    EFortBrushSize__Small = 2,
    EFortBrushSize__Medium = 3,
    EFortBrushSize__Large = 4,
    EFortBrushSize__VeryLarge = 5
};

enum EFortCustomMovement : uint8_t
{
    EFortCustomMovement__Default = 0,
    EFortCustomMovement__Driving = 1,
    EFortCustomMovement__Passenger = 2,
    EFortCustomMovement__Parachuting = 3,
    EFortCustomMovement__Skydiving = 4,
    EFortCustomMovement__SkydiveFollowing = 5,
    EFortCustomMovement__Hover = 6,
    EFortCustomMovement__RemoteControl_Flying = 7,
    EFortCustomMovement__Ziplining = 8,
    EFortCustomMovement__ZipliningOnSpline = 9,
    EFortCustomMovement__Grinding = 10,
    EFortCustomMovement__Ballooning = 11,
    EFortCustomMovement__SurfaceSwimming = 12,
    EFortCustomMovement__DBNOCarried = 13,
    EFortCustomMovement__Floating = 14,
    EFortCustomMovement__Goop = 15,
    EFortCustomMovement__DeimosPreFall = 16,
    EFortCustomMovement__Sliding = 17,
    EFortCustomMovement__Skating = 18,
    EFortCustomMovement__Swinging = 19,
    EFortCustomMovement__SwingingGrounded = 20,
    EFortCustomMovement__SynchedAction = 21,
    EFortCustomMovement__Ridden = 22,
    EFortCustomMovement__FlyingRidden = 23,
    EFortCustomMovement__MovementExtension = 24,
    EFortCustomMovement__Count = 25
};

enum EChuteActions : uint8_t
{
    EChuteActions__None = 0,
    EChuteActions__WantsToOpen = 1,
    EChuteActions__WantsToClose = 2
};

enum EChatRoomJoinHelperState : uint8_t
{
    EChatRoomJoinHelperState__Ready = 0,
    EChatRoomJoinHelperState__AttemptingJoin = 1,
    EChatRoomJoinHelperState__Joined = 2,
    EChatRoomJoinHelperState__AttemptingLeave = 3
};

enum EFortCollectionBookState : uint8_t
{
    EFortCollectionBookState__Active = 0,
    EFortCollectionBookState__Completed = 1,
    EFortCollectionBookState__Claimed = 2
};

enum EFortCreativeEventSystemType : uint8_t
{
    EFortCreativeEventSystemType__Channels = 0,
    EFortCreativeEventSystemType__ChannelsWithEvents = 1,
    EFortCreativeEventSystemType__DirectBinding = 2
};

enum EIndexObjectRegisterLogType : uint8_t
{
    EIndexObjectRegisterLogType__Off = 0,
    EIndexObjectRegisterLogType__On = 1,
    EIndexObjectRegisterLogType__Verbose = 2
};

enum ECreativeItemListType : uint8_t
{
    ECreativeItemListType__ThemedCollection = 0,
    ECreativeItemListType__ItemCollection = 1,
    ECreativeItemListType__Device = 2,
    ECreativeItemListType__Equipment = 3,
    ECreativeItemListType__Expendable = 4,
    ECreativeItemListType__Island = 5,
    ECreativeItemListType__Hidden = 6,
    ECreativeItemListType__None = 7
};

enum ECreativeOptionDestructiveActionOperator : uint8_t
{
    ECreativeOptionDestructiveActionOperator__Invalid = 0,
    ECreativeOptionDestructiveActionOperator__LessThan = 1,
    ECreativeOptionDestructiveActionOperator__NotEqual = 2,
    ECreativeOptionDestructiveActionOperator__GreaterThan = 3
};

enum EFortSourDropperColorType : uint8_t
{
    EFortSourDropperColorType__None = 0,
    EFortSourDropperColorType__Bright = 1,
    EFortSourDropperColorType__MidBright = 2,
    EFortSourDropperColorType__MidDark = 3,
    EFortSourDropperColorType__Dark = 4
};

enum ECreativeVersionCompareResult : uint8_t
{
    ECreativeVersionCompareResult__OlderVersion = 0,
    ECreativeVersionCompareResult__Equal = 1,
    ECreativeVersionCompareResult__NewerVersion = 2
};

enum EFortDialogResult : uint8_t
{
    EFortDialogResult__Confirmed = 0,
    EFortDialogResult__Declined = 1,
    EFortDialogResult__Ignored = 2,
    EFortDialogResult__Killed = 3,
    EFortDialogResult__TimedOut = 4,
    EFortDialogResult__Unknown = 5
};

enum EDynamicBackgroudKey : uint8_t
{
    EDynamicBackgroudKey__Lobby = 0,
    EDynamicBackgroudKey__Vault = 1,
    EDynamicBackgroudKey__Max_None = 2
};

enum EDynamicXpReportingStatus : uint8_t
{
    EDynamicXpReportingStatus__NotSet = 0,
    EDynamicXpReportingStatus__Creative = 1,
    EDynamicXpReportingStatus__VkPlayXps = 2,
    EDynamicXpReportingStatus__VkPlayDisabled = 3,
    EDynamicXpReportingStatus__VkPlayXpsNotAvail = 4,
    EDynamicXpReportingStatus__VkPlayXpsNoData = 5,
    EDynamicXpReportingStatus__VkPlayXpsPlayerNotCached = 6,
    EDynamicXpReportingStatus__VkPlayXpsUpdateFailed = 7
};

enum EDynamicXpCalibrationPhase : uint8_t
{
    EDynamicXpCalibrationPhase__None = 0,
    EDynamicXpCalibrationPhase__DataGathering = 1,
    EDynamicXpCalibrationPhase__DataAnalysis = 2,
    EDynamicXpCalibrationPhase__LiveXpOnceApproved = 3,
    EDynamicXpCalibrationPhase__LiveXp = 4,
    EDynamicXpCalibrationPhase__Failed = 5
};

enum EFortEncounterSpawnLocationPlacementMode : uint8_t
{
    EFortEncounterSpawnLocationPlacementMode__Directional = 0,
    EFortEncounterSpawnLocationPlacementMode__Ring = 1,
    EFortEncounterSpawnLocationPlacementMode__Volume = 2,
    EFortEncounterSpawnLocationPlacementMode__Custom = 3,
    EFortEncounterSpawnLocationPlacementMode__Max_None = 4
};

enum EFortErrorSeverity : uint8_t
{
    EFortErrorSeverity__Unspecified = 0,
    EFortErrorSeverity__Silent = 1,
    EFortErrorSeverity__Passive = 2,
    EFortErrorSeverity__Blocking = 3,
    EFortErrorSeverity__SevereBlocking = 4
};

enum EReloadMtxExperimentBucketType : uint8_t
{
    EReloadMtxExperimentBucketType__Disabled = 0,
    EReloadMtxExperimentBucketType__ReloadMtxIncremental = 1,
    EReloadMtxExperimentBucketType__ReloadMtxStatic = 2
};

enum EMPLobbyExperimentBucketType : uint8_t
{
    EMPLobbyExperimentBucketType__OldLobby = 0,
    EMPLobbyExperimentBucketType__MultiproductLobby = 1,
    EMPLobbyExperimentBucketType__MultiproductLobbyWithSearch = 2
};

enum EItemShopCmsExperimentBucketType : uint8_t
{
    EItemShopCmsExperimentBucketType__CmsPageA = 0,
    EItemShopCmsExperimentBucketType__CmsPageB = 1,
    EItemShopCmsExperimentBucketType__CmsPageC = 2
};

enum EGfaCvarPriority : uint8_t
{
    EGfaCvarPriority__PluginLowPriority = 0,
    EGfaCvarPriority__DeviceProfile = 1,
    EGfaCvarPriority__PluginHighPriority = 2,
    EGfaCvarPriority__Code = 3
};

enum EFortEventReactionRowQueueBehavior : uint8_t
{
    EFortEventReactionRowQueueBehavior__Default = 0,
    EFortEventReactionRowQueueBehavior__DropIfNotImmediatelyRelevant = 1,
    EFortEventReactionRowQueueBehavior__NeverDrop = 2,
    EFortEventReactionRowQueueBehavior__OverrideTimeReactionStillRelevant = 3,
    EFortEve__yi____T________Y__3__E__Q_Tj____Oi_5__i________H__7_n_____o_____ = 4
};

enum EFortDisplayGender : uint8_t
{
    EFortDisplayGender__Unknown = 0,
    EFortDisplayGender__Male = 1,
    EFortDisplayGender__Female = 2,
    EFortDisplayGender__NumTypes = 3
};

enum EHabaneroTierType : uint8_t
{
    EHabaneroTierType__HabaneroSauce0 = 0,
    EHabaneroTierType__HabaneroSauce1 = 1,
    EHabaneroTierType__HabaneroSauce2 = 2,
    EHabaneroTierType__HabaneroSauce3 = 3,
    EHabaneroTierType__HabaneroSauce4 = 4,
    EHabaneroTierType__HabaneroSauce5 = 5,
    EHabaneroTierType__HabaneroSauce6 = 6,
    EHabaneroTierType__HabaneroSauce7 = 7,
    EHabaneroTierType__HabaneroSauce8 = 8
};

enum ESwingType : uint8_t
{
    ESwingType__Swing1 = 0,
    ESwingType__Swing2 = 1,
    ESwingType__Swing3 = 2,
    ESwingType__Swing4 = 3,
    ESwingType__UniqueSwingCount = 4
};

enum ESwingSequence : uint8_t
{
    ESwingSequence__UpperBodySwing = 0,
    ESwingSequence__UpperBodyReturn = 1,
    ESwingSequence__CrouchUpperBodySwing = 2,
    ESwingSequence__CrouchUpperBodyReturn = 3,
    ESwingSequence__CrouchInPlaceAdditiveSwing = 4,
    ESwingSequence__CrouchInPlaceAdditiveReturn = 5,
    ESwingSequence__SwingSequenceCount = 6
};

enum EAnimNotifyTracks : uint8_t
{
    EAnimNotifyTracks__GenericNotifies = 0,
    EAnimNotifyTracks__DualWield = 1,
    EAnimNotifyTracks__DecisionWindow = 2,
    EAnimNotifyTracks__AbilityTrigger = 3,
    EAnimNotifyTracks__AudioParameters = 4,
    EAnimNotifyTracks__ReloadFx = 5,
    EAnimNotifyTracks__MeleeTrails = 6,
    EAnimNotifyTracks__StopMeleeTrailsOnEnd = 7,
    EAnimNotifyTracks__PlaySwimmingSounds = 8,
    EAnimNotifyTracks__Count = 9
};

enum EFortInputMouseAxis : uint8_t
{
    EFortInputMouseAxis__X = 0,
    EFortInputMouseAxis__Y = 1,
    EFortInputMouseAxis__Both = 2
};

enum EInteriorAudioBuildingRelativePosition : uint8_t
{
    EInteriorAudioBuildingRelativePosition__SameCell = 0,
    EInteriorAudioBuildingRelativePosition__SameCellQuadrantTestFailed = 1,
    EInteriorAudioBuildingRelativePosition__OtherCellParallelToForward = 2,
    EInteriorAudioBuildingRelativePosition__OtherCellParallelToRight = 3,
    EInteriorAudioBuildingRelativePosition__OtherCellParallelToUp = 4,
    EInteriorAudioBuildingRelativePosition__Max_None = 5
};

enum EInteriorAudioBuildingTags : uint8_t
{
    EInteriorAudioBuildingTags__None = 0,
    EInteriorAudioBuildingTags__HasDoors = 1,
    EInteriorAudioBuildingTags__RotationDependant = 2,
    EInteriorAudioBuildingTags__UseConditionalEvaluation = 3
};

enum EInteriorAudioBuildingType : uint8_t
{
    EInteriorAudioBuildingType__None = 0,
    EInteriorAudioBuildingType__Wall = 1,
    EInteriorAudioBuildingType__Floor = 2,
    EInteriorAudioBuildingType__CenterCell = 3
};

enum EInteriorAudioQuadrant : uint8_t
{
    EInteriorAudioQuadrant__None = 0,
    EInteriorAudioQuadrant__Left = 1,
    EInteriorAudioQuadrant__Right = 2,
    EInteriorAudioQuadrant__Top = 4,
    EInteriorAudioQuadrant__Bottom = 8
};

enum EInteriorAudioBuildingDefaultRotation : uint8_t
{
    EInteriorAudioBuildingDefaultRotation__PositiveY = 0,
    EInteriorAudioBuildingDefaultRotation__NegativeX = 1,
    EInteriorAudioBuildingDefaultRotation__NegativeY = 2,
    EInteriorAudioBuildingDefaultRotation__PositiveX = 3
};

enum EInteriorAudioBuildingEvaluation : uint8_t
{
    EInteriorAudioBuildingEvaluation__Invalid = 0,
    EInteriorAudioBuildingEvaluation__Partial = 1,
    EInteriorAudioBuildingEvaluation__Solid = 2,
    EInteriorAudioBuildingEvaluation__EInteriorAudioBuildingEvaluation_M__ = 3
};

enum EInteriorAudioBuildingDirection : uint8_t
{
    EInteriorAudioBuildingDirection__Left = 0,
    EInteriorAudioBuildingDirection__Right = 1,
    EInteriorAudioBuildingDirection__Forward = 2,
    EInteriorAudioBuildingDirection__Backward = 3,
    EInteriorAudioBuildingDirection__Upward = 4
};

enum EInventoryContentSortType : uint8_t
{
    EInventoryContentSortType__ByName = 0,
    EInventoryContentSortType__ByRating = 1,
    EInventoryContentSortType__ByLevel = 2,
    EInventoryContentSortType__ByCategory = 3,
    EInventoryContentSortType__ByRarity = 4,
    EInventoryContentSortType__ByLocation = 5,
    EInventoryContentSortType__ByPersonality = 6,
    EInventoryContentSortType__ByBonus = 7,
    EInventoryContentSortType__BySubtype = 8,
    EInventoryContentSortType__ByGrantTime = 9,
    EInventoryContentSortType__BySeries = 10,
    EInventoryContentSortType__BySet = 11,
    EInventoryContentSortType__ByReleaseDate = 12,
    EInventoryContentSortType__Invalid = 13
};

enum EMinigameStatToSave : uint8_t
{
    EMinigameStatToSave__None = 0,
    EMinigameStatToSave__Round = 1,
    EMinigameStatToSave__Career = 2,
    EMinigameStatToSave__RoundAndCareer = 3
};

enum EMinigameStatSavePolicy : uint8_t
{
    Never = 0,
    Always = 1,
    OnlyIfLower = 2,
    OnlyIfHigher = 3
};

enum EWorldItemDropBehavior : uint8_t
{
    EWorldItemDropBehavior__DropAsPickup = 0,
    EWorldItemDropBehavior__DestroyOnDrop = 1,
    EWorldItemDropBehavior__DropAsPickupDestroyOnEmpty = 2,
    EWorldItemDropBehavior__DropAsPickupEvenWhenEmpty = 3
};

enum EFortItemShopOfferFilterCriteria : uint8_t
{
    EFortItemShopOfferFilterCriteria__FilterByItemCategory = 0,
    EFortItemShopOfferFilterCriteria__FilterBySubscriptionOrPassOffer = 1,
    EFortItemShopOfferFilterCriteria__FilterByItemType = 2
};

enum EFortJackalSimEvent : uint8_t
{
    EFortJackalSimEvent__Jumped = 0
};

enum EFortLeaderboardMetric : uint8_t
{
    EFortLeaderboardMetric__Score = 0,
    EFortLeaderboardMetric__Kills = 1,
    EFortLeaderboardMetric__TeamScore = 2
};

enum ELibraryStorageItemIconType : uint8_t
{
    ELibraryStorageItemIconType__Core = 0,
    ELibraryStorageItemIconType__BattleRoyale = 1,
    ELibraryStorageItemIconType__Juno = 2,
    ELibraryStorageItemIconType__Sparks = 3,
    ELibraryStorageItemIconType__DelMar = 4,
    ELibraryStorageItemIconType__Creative = 5,
    ELibraryStorageItemIconType__HighResTexture = 6
};

enum ELibraryStorageItemDownloadStatus : uint8_t
{
    ELibraryStorageItemDownloadStatus__NotDownloaded = 0,
    ELibraryStorageItemDownloadStatus__Downloaded = 1,
    ELibraryStorageItemDownloadStatus__Downloading = 2,
    ELibraryStorageItemDownloadStatus__UpdateRequired = 3,
    ELibraryStorageItemDownloadStatus__Updating = 4,
    ELibraryStorageItemDownloadStatus__Queued = 5,
    ELibraryStorageItemDownloadStatus__Paused = 6,
    ELibraryStorageItemDownloadStatus__Removing = 7
};

enum ELibraryStorageItemType : uint8_t
{
    ELibraryStorageItemType__BattleRoyale = 0,
    ELibraryStorageItemType__Juno = 1,
    ELibraryStorageItemType__Sparks = 2,
    ELibraryStorageItemType__DelMar = 3,
    ELibraryStorageItemType__Creative = 4,
    ELibraryStorageItemType__Core = 5,
    ELibraryStorageItemType__HighResTexture = 6,
    ELibraryStorageItemType__MAX_COUNT = 7
};

enum ELightweightProjectileRequestType : uint8_t
{
    ELightweightProjectileRequestType__None = 0,
    ELightweightProjectileRequestType__Single = 1,
    ELightweightProjectileRequestType__Looping = 2
};

enum ELinkEntryQueryResult : uint8_t
{
    ELinkEntryQueryResult__Success = 0,
    ELinkEntryQueryResult__PartialSuccess = 1,
    ELinkEntryQueryResult__FailedQuery = 2,
    ELinkEntryQueryResult__FailedPlayerDataQuery = 3,
    ELinkEntryQueryResult__FailedParse = 4,
    ELinkEntryQueryResult__NotAllowedOnPlatform = 5,
    ELinkEntryQueryResult__CabinModeBlocked = 6,
    ELinkEntryQueryResult__UnableToFind = 7,
    ELinkEntryQueryResult__NotVisible = 8,
    ELinkEntryQueryResult__TournamentDataUnavailable = 9,
    ELinkEntryQueryResult__FailedStringSanitization = 10,
    ELinkEntryQueryResult__FailedSubModePopulation = 11,
    ELinkEntryQueryResult__FailedSubModeSurfacePopulation = 12,
    ELinkEntryQueryResult__FailedSubModeParsing = 13,
    ELinkEntryQueryResult__FilteredOut = 14,
    ELinkEntryQueryResult__RatingUnrated = 15,
    ELinkEntryQueryResult__RatingRestricted = 16,
    ELinkEntryQueryResult__ModeratorOnly = 17
};

enum EJoinInProgressRole : uint8_t
{
    EJoinInProgressRole__None = 0,
    EJoinInProgressRole__Host = 1,
    EJoinInProgressRole__PartyMember = 2,
    EJoinInProgressRole__PartySpectator = 3,
    EJoinInProgressRole__Broadcaster = 4
};

enum EFortLobbyType : uint8_t
{
    EFortLobbyType__Default = 0,
    EFortLobbyType__Tournament = 1,
    EFortLobbyType__Creative = 2,
    EFortLobbyType__Division = 3
};

enum EFortMotionMatchingLocomotionStyle : uint8_t
{
    EFortMotionMatchingLocomotionStyle__Idle = 0,
    EFortMotionMatchingLocomotionStyle__Walk = 1,
    EFortMotionMatchingLocomotionStyle__Jog = 2,
    EFortMotionMatchingLocomotionStyle__Run = 3,
    EFortMotionMatchingLocomotionStyle__Sprint = 4
};

enum EFortSessionHelperJoinResult : uint8_t
{
    EFortSessionHelperJoinResult__NoResult = 0,
    EF______________________F_I__8K__G_G_6__________ = 1,
    EFortSessionHelperJoinResult__ReservationFailure_PartyLimitReached = 2,
    EFortSessionHelperJoinResult__ReservationFailure_IncorrectPlayerCount = 3,
    EFortSessionHelperJoinResult__ReservationFailure_RequestTimedOut = 4,
    EFortSessionHelperJoinResult__ReservationFailure_ReservationNotFound = 5,
    EFortSessionHelperJoinResult__ReservationFailure_ReservationDenied = 6,
    EFortSessionHelperJoinResult__ReservationFailure_ReservationDenied_Banned = 7,
    EFortSessionHelperJoinResult__ReservationFailure_ReservationRequestCanceled = 8,
    EFortSessionHelperJoinResult__ReservationFailure_ReservationInvalid = 9,
    EFortSessionHelperJoinResult__ReservationFailure_BadSessionId = 10,
    EFortSessionHelperJoinResult__ReservationFailure_ReservationDenied_ContainsExistingPlayers = 11,
    EFortSessionHelperJoinResult__ReservationFailure_GeneralError = 12,
    EFortSessionHelperJoinResult__ReservationFailure_NoSubsystem = 13,
    EFortSessionHelperJoinResult__ReservationFailure_NoIdentity = 14,
    EFortSessionHelperJoinResult__ReservationFailure_InvalidSession = 15,
    EFortSessionHelperJoinResult__ReservationFailure_InvalidUser = 16,
    EFortSessionHelperJoinResult__ReservationFailure_EncryptionKey = 17,
    EFortSessionHelperJoinResult__ReservationFailure_RefreshAuth = 18,
    EFortSessionHelperJoinResult__ReservationFailure_UserSessionIdToken = 19,
    EFortSessionHelperJoinResult__ReservationFailure_AlreadyJoiningDuringReserve = 20,
    EFortSessionHelperJoinResult__ReservationFailure_AlreadyJoiningDuringSkip = 21,
    EFortSessionHelperJoinResult__JoinSessionSuccess = 22,
    EFortSessionHelperJoinResult__JoinSessionFailure_SessionIsFull = 23,
    EFortSessionHelperJoinResult__JoinSessionFailure_SessionDoesNotExist = 24,
    EFortSessionHelperJoinResult__JoinSessionFailure_CouldNotRetrieveAddress = 25,
    EFortSessionHelperJoinResult__JoinSessionFailure_AlreadyInSession = 26,
    EFortSessionHelperJoinResult__JoinSessionFailure_UnknownError = 27,
    EFortSessionHelperJoinResult__JoinSessionFailure_InvalidSession = 28,
    EFortSessionHelperJoinResult__JoinSessionFailure_InvalidSearchResultIndex = 29,
    EFortSessionHelperJoinResult__JoinSessionFailure_AlreadyJoiningDuringJoin = 30,
    EFortSessionHelperJoinResult__SearchPassFailure_NoSessionHelper = 31,
    EFortSessionHelperJoinResult__SearchPassFailure_InvalidUser = 32,
    EFortSessionHelperJoinResult__SearchPassFailure_NoIdentity = 33,
    EFortSessionHelperJoinResult__SearchPassFailure_InvalidSearchResult = 34,
    EFortSessionHelperJoinResult__SearchPassFailure_InvalidSearchResultIndex = 35,
    EFortSessionHelperJoinResult__JoinSessionCanceled = 36
};

enum EMatchmakingUtilityFlows : uint8_t
{
    EMatchmakingUtilityFlows__Automatic = 0,
    EMatchmakingUtilityFlows__JoinMatchInProgress = 1,
    EMatchmakingUtilityFlows__SpectateMatch = 2,
    EMatchmakingUtilityFlows__Legacy = 3,
    EMatchmakingUtilityFlows__LinkCode = 4,
    EMatchmakingUtilityFlows__JoinEditingSession = 5,
    EMatchmakingUtilityFlows__SaveTheWorld = 6,
    EMatchmakingUtilityFlows__Internal_Unselected = 7
};

enum EMatchmakingReadyCheck : uint8_t
{
    EMatchmakingReadyCheck__NotReady = 0,
    EMatchmakingReadyCheck__Default = 1,
    EMatchmakingReadyCheck__SaveTheWorld = 2,
    EMatchmakingReadyCheck__LinkCode = 3,
    EMatchmakingReadyCheck__JoinEditingSession = 4,
    EMatchmakingReadyCheck__MAX_NUM = 5
};

enum EGameReadiness : uint8_t
{
    EGameReadiness__NotReady = 0,
    EGameReadiness__Ready = 1,
    EGameReadiness__Reevaluating = 2,
    EGameReadiness__SittingOut = 3,
    EGameReadiness__Away = 4,
    EGameReadiness__NUM = 5
};

enum EGameReadiness_Repl : uint8_t
{
    EGameReadiness_Repl__N = 0,
    EGameReadiness_Repl__Y = 1,
    EGameReadiness_Repl__R = 2,
    EGameReadiness_Repl__S = 3,
    EGameReadiness_Repl__A = 4,
    EGameReadiness_Repl__NUM = 5
};

enum EInGameLinkType : uint8_t
{
    EInGameLinkType__BattleRoyale = 0,
    EInGameLinkType__CreativeIsland = 1,
    EInGameLinkType__Competitive = 2,
    EInGameLinkType__UEFN = 3,
    EInGameLinkType__UNDEFINED = 4,
    EInGameLinkType__NUM = 5
};

enum EInGameLinkType_Repl : uint8_t
{
    EInGameLinkType_Repl__B = 0,
    EInGameLinkType_Repl__I = 1,
    EInGameLinkTGy_____5D_G = 2,
    EInGameLinkType_Repl__U = 3,
    EInGameLinkType_Repl__X = 4,
    EInGameLinkType_Repl__NUM = 5
};

enum EActivePreTravelSetupStepsMask : uint8_t
{
    EActivePreTravelSetupStepsMask__None = 0,
    EActivePreTravelSetupStepsMask__WaitingForSubGameContent = 1,
    EActivePreTravelSetupStepsMask__WaitingForDownloadableContent = 2,
    EActivePreTravelSetupStepsMask__WaitingForServerInitialization = 4,
    EActivePreTravelSetupStepsMask__WaitingForContentBeaconDisconnect = 8,
    EActivePreTravelSetupStepsMask__WaitingForSecondContentBeacon = 16,
    EActivePreTravelSetupStepsMask__CancelingPreTravelSetup = 32
};

enum EUseInputWithPartyResult : uint8_t
{
    EUseInputWithPartyResult__Success = 0,
    EUseInputWithPartyResult__LocalPlayerNeedsToAllowCrossplay = 1,
    EUseInputWithPartyResult__LocalPlayerRestricted = 2,
    EUseInputWithPartyResult__RemotePlayerRestricted = 3,
    EUseInputWithPartyResult__UnknownFailure = 4
};

enum EMatchmakingSourceV2 : uint8_t
{
    EMatchmakingSourceV2__None = 0,
    EMatchmakingSourceV2__AthenaMatchmakingWidget = 1,
    EMatchmakingSourceV2__ActivityMatchmakingWidget = 2,
    EMatchmakingSourceV2__ReadyUpScreenWidget = 3,
    EMatchmakingSourceV2__ForcedIntro = 4,
    EMatchmakingSourceV2__KeepPlayingTogetherWidget = 5,
    EMatchmakingSourceV2__Unknown = 6
};

enum EMatchmaking_UC_________A_________c_u____5_z_________ : uint8_t
{
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__Begin = 0,
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__Idle = 1,
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__Completed = 2,
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__Failed = 3,
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__INVALID = 4,
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__PreloadingAthena = 5,
    EMatchmakingV2_Temp_PreloadingAthenaForJoinInProgress__BeginningServerTransfer_UnfinishedRefactor = 6
};

enum EMatchmakingV2_Temp_JoinInProgressState : uint8_t
{
    EMatchmakingV2_Temp_JoinInProgressState__Begin = 0,
    EMatchmakingV2_Temp_JoinInProgressState__Idle = 1,
    EMatchmakingV2_Temp_JoinInProgressState__Completed = 2,
    EMatchmakingV2_Temp_JoinInProgressState__Failed = 3,
    EMatchmakingV2_Temp_JoinInProgressState__INVALID = 4,
    EMatchmakingV2_Temp_JoinInProgressState__Branch_JoinHost = 5,
    EMatchmakingV2_Temp_JoinInProgressState__Branch_JoinParty = 6,
    EMatchmakingV2_Temp_JoinInProgressState__Branch_JoinBroadcaster = 7,
    EMatchmakingV2_Temp_JoinInProgressState__Branch_JoinPartyMember = 8,
    EMatchmakingV2_Temp_JoinInProgressState__ConnectToReservationBeacon = 9,
    EMatchmakingV2_Temp_JoinInProgressState__ConnectToReservationBeaconForPersistentParty = 10,
    EMatchmakingV2_Temp_JoinInProgressState__CheckConnectToReservationBeaconForPersistentPartyData = 11,
    EMatchmakingV2_Temp_JoinInProgressState__DelayingCallToJoin = 12,
    EMatchmakingV2_Temp_JoinInProgressState__CheckNotMatchmaking = 13,
    EMatchmakingV2_Temp_JoinInProgressState__CallToJoin = 14
};

enum EMatchmakingV2Fork_ServerInit : uint8_t
{
    EMatchmakingV2Fork_ServerInit__Begin = 0,
    EMatchmakingV2Fork_ServerInit__Idle = 1,
    EMatchmakingV2Fork_ServerInit__Completed = 2,
    EMatchmakingV2Fork_ServerInit__Failed = 3,
    EMatchmakingV2Fork_ServerInit__INVALID = 4,
    EMatchmakingV2Fork_ServerInit__ReadyToTravel = 5,
    EMatchmakingV2Fork_ServerInit__WaitForInit = 6,
    EMatchmakingV2Fork_ServerInit__WaitForSubGameContent = 7,
    EMatchmakingV2Fork_ServerInit__WaitForSubGameContent_Callback = 8,
    EMatchmakingV2Fork_ServerInit__WaitForSubGameContent_Callback_Ready = 9,
    EMatchmakingV2Fork_ServerInit__WaitForSubGameContent_Callback_NotReady = 10,
    EMatchmakingV2Fork_ServerInit__WaitBeforeTravel = 11,
    EMatchmakingV2Fork_ServerInit__FailedToConnect = 12,
    EMatchmakingV2Fork_ServerInit__MissingParty = 13,
    EMatchmakingV2Fork_ServerInit__FailedCallback = 14,
    EMatchmakingV2Fork_ServerInit__ServerInitStateChange_Callback = 15,
    EMatchmakingV2Fork_ServerInit__ServerInitStateChange_Callback_Ready = 16,
    EMatchmakingV2Fork_ServerInit__ServerInitState________n_S______M__V___ = 17,
    EMatchmakingV2Fork_ServerInit__CancelRequested = 18
};

enum EFortMediaGlobalEventsPlayerType : uint8_t
{
    EFortMediaGlobalEventsPlayerType__Primary = 0,
    EFortMediaGlobalEventsPlayerType__Secondary = 1,
    EFortMediaGlobalEventsPlayerType__BackgroundAudio = 2
};

enum EMemorySamplerState : uint8_t
{
    EMemorySamplerState__Idle = 0,
    EMemorySamplerState__InProgress = 1,
    EMemorySamplerState__InProgressNotOwner = 2,
    EMemorySamplerState__LaunchError = 3,
    EMemorySamplerState__GeneratingSamplingLocations = 4,
    EMemorySamplerState__Initializing = 5,
    EMemorySamplerState__Ready = 6
};

enum EFortTextChatChannelType : uint8_t
{
    EFortTextChatChannelType__All = 0,
    EFortTextChatChannelType__Party = 1,
    EFortTextChatChannelType__Game = 2,
    EFortTextChatChannelType__Whisper = 3,
    EFortTextChatChannelType__AddCmd = 4,
    EFortTextChatChannelType__MAX_NUM = 5
};

enum EFortTextChatCurrentUIContext : uint8_t
{
    EFortTextChatCurrentUIContext__Unknown = 0,
    EFortTextChatCurrentUIContext__STW = 1,
    EFortTextChatCurrentUIContext__STW_InMatch = 2,
    EFortTextChatCurrentUIContext__Frontend = 3,
    EFortTextChatCurrentUIContext__InMatch = 4,
    EFortTextChatCurrentUIContext__MAX_NUM = 5
};

enum ETrackedObjectiveQuery : uint8_t
{
    ETrackedObjectiveQuery__All = 0,
    ETrackedObjectiveQuery__ExactTeam = 1,
    ETrackedObjectiveQuery__Friendly = 2,
    ETrackedObjectiveQuery__Neutral = 3,
    ETrackedObjectiveQuery__Hostile = 4,
    ETrackedObjectiveQuery__NotFriendly = 5
};

enum EBuildingMode : uint8_t
{
    EBuildingMode__None = 0,
    EBuildingMode__BuildingsOnly = 1,
    EBuildingMode__TrapsOnly = 2,
    EBuildingMode__All = 3
};

enum EMissionGenerationCategory : uint8_t
{
    EMissionGenerationCategory__Primary = 0,
    EMissionGenerationCategory__Secondary = 1,
    EMissionGenerationCategory__Tertiary = 2,
    EMis_____________x__US__s_K____r__C_ = 3,
    EMissionGenerationCategory__Max_None = 4
};

enum EMobileInteractionIconTypes : uint8_t
{
    EMobileInteractionIconTypes__Interact = 0,
    EMobileInteractionIconTypes__Swap = 1,
    EMobileInteractionIconTypes__Revive = 2,
    EMobileInteractionIconTypes__Blocked = 3
};

enum ELowerBodyBlendMask : uint8_t
{
    ELowerBodyBlendMask__None = 0,
    ELowerBodyBlendMask__Default = 1,
    ELowerBodyBlendMask__LowerBodyNoFeathering = 2,
    ELowerBodyBlendMask__CrouchShuffleRelaxedLocalSpace = 3,
    ELowerBodyBlendMask__CrouchShuffleRelaxedMeshSpace = 4,
    ELowerBodyBlendMask__PartialUpperBodyLocalSpace = 5,
    ELowerBodyBlendMask__PartialUpperBodyMeshSpace = 6,
    ELowerBodyBlendMask__OneHandMontage = 7,
    ELowerBodyBlendMask__TwoHandMontage = 8
};

enum EFortMovementUrgency : uint8_t
{
    EFortMovementUrgency__None = 0,
    EFortMovementUrgency__Low = 1,
    EFortMovementUrgency__Medium = 2,
    EFortMovementUrgency__High = 3,
    EFortMovementUrgency__NumLevels = 4
};

enum EMovementLeanState : uint8_t
{
    EMovementLeanState__None = 0,
    EMovementLeanState__BlendingIn = 1,
    EMovementLeanState__BlendingOut = 2,
    EMovementLeanState__SettleDelay = 3,
    EMovementLeanState__Settling = 4,
    EMovementLeanState__Idle = 5
};

enum EFortMovementModeExt_PhysUpdateResult : uint8_t
{
    EFortMovementModeExt_PhysUpdateResult__Continue = 0,
    EFortMovementModeExt_PhysUpdateResult__AbortIteration = 1,
    EFortMovementModeExt_PhysUpdateResult__AbortPhysUpdate = 2
};

enum EGuidedMotionMMEFinishVelocityMode : uint8_t
{
    EGuidedMotionMMEFinishVelocityMode__MaintainLastRootMotionVelocity = 0,
    EGuidedMotionMMEFinishVelocityMode__SetVelocity = 1,
    EGuidedMotionMMEFinishVelocityMode__ClampVelocity = 2
};

enum EGuidedMotionMMETargetOffsetType : uint8_t
{
    EGuidedMotionMMETargetOffsetType__AlignFromTargetToSource = 0,
    EGuidedMotionMMETargetOffsetType__AlignToTargetForward = 1,
    EGuidedMotionMMETargetOffsetType__AlignToWorldSpace = 2
};

enum EGuidedMotionMMEMode : uint8_t
{
    EGuidedMotionMMEMode__ConstantForce = 0,
    EGuidedMotionMMEMode__MoveToLocation = 1,
    EGuidedMotionMMEMode__MoveToActor = 2
};

enum ERootMotionMMEFinishVelocityMode : uint8_t
{
    ERootMotionMMEFinishVelocityMode__MaintainLastRootMotionVelocity = 0,
    ERootMotionMMEFinishVelocityMode__SetVelocity = 1,
    ERootMotionMMEFinishVelocityMode__ClampVelocity = 2
};

enum ERootMotionMMETargetOffsetType : uint8_t
{
    ERootMotionMMETargetOffsetType__AlignFromTargetToSource = 0,
    ERootMotionMMETargetOffsetType__AlignToTargetForward = 1,
    ERootMotionMMETargetOffsetType__AlignToWorldSpace = 2
};

enum ERootMotionMMEMode : uint8_t
{
    ERootMotionMMEMode__ConstantForce = 0,
    ERootMotionMMEMode__MoveToTarget = 1,
    ERootMotionMMEMode__MoveToActor = 2
};

enum EFortMovementModeExt_UpdateResult : uint8_t
{
    EFortMovementModeExt_UpdateResult__Updating = 0,
    EFortMovementModeExt_UpdateResult__Active = 1,
    EFortMovementModeExt_UpdateResult__Active_Layered = 2,
    EFortMovementModeExt_UpdateResult__Ended = 3
};

enum EFortNetworkScope : uint8_t
{
    EFortNetworkScope__Neither = 0,
    EFortNetworkScope__Client = 1,
    EFortNetworkScope__Server = 2,
    EFortNetworkScope__Both = 3
};

enum EObjectiveProcessorPropertyRequirement : uint8_t
{
    EObjectiveProcessorPropertyRequirement__Ignored = 0,
    EObjectiveProcessorPropertyRequirement__Required = 1,
    EObjectiveProcessorPropertyRequirement__Prohibited = 2,
    EObjectiveProcessorPropertyRequireme_PyN______j___c1V__________yr_____C9___D6_p__p = 3
};

enum EDistanceTravelDirection : uint8_t
{
    EDistanceTravelDirection__Any = 0,
    EDistanceTravelDirection__Vertical = 1,
    EDistanceTravelDirection__Horizontal = 2,
    EDistanceTravelDirection__SingleAxis = 3
};

enum EAxisTravelBehavior : uint8_t
{
    EAxisTravelBehavior__RequireAny = 0,
    EAxisTravelBehavior__RequireAll = 1,
    EAxisTravelBehavior__RequireNone = 2
};

enum EGameplayDebugState : uint8_t
{
    EGameplayDebugState__Unset = 0,
    EGameplayDebugState__Show = 1,
    EGameplayDebugState__Hide = 2
};

enum EDistanceTravelMode : uint8_t
{
    EDistanceTravelMode__Any = 0,
    EDistanceTravelMode__Ballooning = 1,
    EDistanceTravelMode__Crouch = 2,
    EDistanceTravelMode__DBNOCarried = 3,
    EDistanceTravelMode__Driving = 4,
    EDistanceTravelMode__Falling = 5,
    EDistanceTravelMode__Floating = 6,
    EDistanceTravelMode__Flying = 7,
    EDistanceTravelMode__Goop = 8,
    EDistanceTravelMode__Grinding = 9,
    EDistanceTravelMode__Hover = 10,
    EDistanceTravelMode__Parachuting = 11,
    EDistanceTravelMode__Passenger = 12,
    EDistanceTravelMode__RemoteControl_Flying = 13,
    EDistanceTravelMode__Running = 14,
    EDistanceTravelMode__Skating = 15,
    EDistanceTravelMode__SkydiveFollowing = 16,
    EDistanceTravelMode__SkyDiving = 17,
    EDistanceTravelMode__Sliding = 18,
    EDistanceTravelMode__SurfaceSwimming = 19,
    EDistanceTravelMode__Swimming = 20,
    EDistanceTravelMode__Ziplining = 21,
    EDistanceTravelMode__ZipliningOnSpline = 22,
    EDistanceTravelMode__Sprinting = 23,
    EDistanceTravelMode__Jumping = 24
};

enum EVehicleSurfaceType : uint8_t
{
    EVehicleSurfaceType__None = 0,
    EVehicleSurfaceType__InAir = 1,
    EVehicleSurfaceType__InWater = 2,
    EVehicleSurfaceType__OnDirt = 3,
    EVehicleSurfaceType__OnGrass = 4,
    EVehicleSurfaceType__OnGround = 5,
    EVehicleSurfaceType__OnIce = 6,
    EVehicleSurfaceType__OnRoad = 7,
    EVehicleSurfaceType__OnSnow = 8
};

enum EFortHealingIncrementType : uint8_t
{
    EFortHealingIncrementType__Single = 0,
    EFortHealingIncrementType__HealingAmount = 1,
    EFortHealingIncrementType__HealthOverHealing = 2,
    EFortHealingIncrementType__PercentHealed = 3,
    EFortHealingIncrementType__TotalHealingDone = 4
};

enum EFortOctopusSimEvent : uint8_t
{
    EFortOctopusSimEvent__BeginBoostCooldown = 0
};

enum EFortPawnPushSize : uint8_t
{
    EFortPawnPushSize__FFPS_Normal = 0,
    EFortPawnPushSize__FPPS_Player = 1,
    EFortPawnPushSize__FPPS_Large = 2,
    EFortPawnPushSize__FPPS_SuperLarge = 3
};

enum EFortControlRecoveryBehavior : uint8_t
{
    EFortControlRecoveryBehavior__DefaultControl = 0,
    EFortControlRecoveryBehavior__LimitedControl = 1,
    EFortControlRecoveryBehavior__ChainControl = 2
};

enum EFortWeaponListRemovalBehavior : uint8_t
{
    EFortWeaponListRemovalBehavior__DestroyImmediately = 0,
    EFortWeaponListRemovalBehavior__DeferredLifespan = 1,
    EFortWeaponListRemovalBehavior__DoNotDestroy = 2
};

enum EWindVolumePriority : uint8_t
{
    EWindVolumePriority__Priority = 1,
    EWindVolumePriority__Priority = 2,
    EWindVolumePriority__Priority = 3,
    EWindVolumePriority__Priority = 4,
    EWindVolumePriority__Priority = 5,
    EWindVolumePriority__Priority = 6,
    EWindVolumePriority__Priority = 7,
    EWindVolumePriority__Priority = 8,
    EWindVolumePriority__Priority = 9,
    EWindVolumePriority__Priority = 10,
    EWindVolumePriority__Priority_Default = 11
};

enum EFortPickupSourceTypeFlag : uint8_t
{
    EFortPickupSourceTypeFlag__Other = 0,
    EFortPickupSourceTypeFlag__Player = 1,
    EFortPickupSourceTypeFlag__Destruction = 2,
    EFortPickupSourceTypeFlag__Container = 4,
    EFortPickupSourceTypeFlag__AI = 8,
    EFortPickupSourceTypeFlag__Tossed = 16,
    EFortPickupSourceTypeFlag__FloorLoot = 32,
    EFortPickupSourceTypeFlag__Fishing = 64,
    EFortPickupSourceTypeFlag__NPCService = 128
};

enum EFortPickupSpawnSource : uint8_t
{
    EFortPickupSpawnSource__Unset = 0,
    EFortPickupSpawnSource__PlayerElimination = 1,
    EFortPickupSpawnSource__Chest = 2,
    EFortPickupSpawnSource__SupplyDrop = 3,
    EFortPickupSpawnSource__AmmoBox = 4,
    EFortPickupSpawnSource__Drone = 5,
    EFortPickupSpawnSource__ItemSpawner = 6,
    EFortPickupSpawnSource__BotElimination = 7,
    EFortPickupSpawnSource__NPCElimination = 8,
    EFortPickupSpawnSource__LootDrop = 9,
    EFortPickupSpawnSource__TossedByPlayer = 10,
    EFortPickupSpawnSource__NPC = 11,
    EFortPickupSpawnSource__NPCGift = 12,
    EFortPickupSpawnSource__CraftingBench = 13,
    EFortPickupSpawnSource__VendingMachine = 14,
    EFortPickupSpawnSource__QuestReward = 15
};

enum EFortInputDevice : uint8_t
{
    EFortInputDevice__Mouse = 0,
    EFortInputDevice__Keyboard = 1,
    EFortInputDevice__Gamepad = 2,
    EFortInputDevice__Touch = 3
};

enum EFortInputActionType : uint8_t
{
    EFortInputActionType__Press = 0,
    EFortInputActionType__Click = 1,
    EFortInputActionType__Hold = 2,
    EFortInputActionType__Release = 3
};

enum EPlaylistAdvertisementType : uint8_t
{
    EPlaylistAdvertisementType__None = 0,
    EPlaylistAdvertisementType__New = 1,
    EPlaylistAdvertisementType__Updated = 2
};

enum EPlaylistVisibilityState : uint8_t
{
    EPlaylistVisibilityState__Enabled = 1,
    EPlaylistVisibilityState__Disabled = 2,
    EPlaylistVisibilityState__EnabledButInvisible = 3,
    EPlaylistVisibilityState__Hidden = 4
};

enum EFortIdleDetectionState : uint8_t
{
    EFortIdleDetectionState__Disabled = 0,
    EFortIdleDetectionState__Default = 1,
    EFortIdleDetectionState__Suspicious = 2,
    EFortIdleDetectionState__Problematic = 3,
    EFortIdleDetectionState__Inactive = 4
};

enum ETriggeredSpawnLocationType : uint8_t
{
    ETriggeredSpawnLocationType__AuthorLocation = 0,
    ETriggeredSpawnLocationType__EventLocation = 1,
    ETriggeredSpawnLocationType__NamedSubjectLocation = 2
};

enum EObjectiveNeeds : uint8_t
{
    EObjectiveNeeds__None = 0,
    EObjectiveNeeds__ObjectiveUpdate = 1,
    EObjectiveNeeds__ObjectiveUpdateWithContext = 2
};

enum EQuestEditorGenerateBackendNameReason : uint8_t
{
    EQuestEditorGenerateBackendNameReason__NoAction = 0,
    EQuestEditorGenerateBackendNameReason__OnlyBuildEmpty = 1,
    EQuestEditorGenerateBackendNameReason__ForceRebuild = 2
};

enum EObjectiveStatusUpdateType : uint8_t
{
    EObjectiveStatusUpdateType__Always = 0,
    EObjectiveStatusUpdateType__OnPercent = 1,
    EObjectiveStatusUpdateType__OnComplete = 2,
    EObjectiveStatusUpdateType__Never = 3
};

enum EObjectiveConversationTriggerType : uint8_t
{
    EObjectiveConversationTriggerType__StatEquals = 0,
    EObjectiveConversationTriggerType__StatIncreasedby = 1,
    EObjectiveConversationTriggerType__StatLessThan = 2,
    EObjectiveConversationTriggerType__Max = 3
};

enum EInlineObjectiveStatTagCheckEntryType : uint8_t
{
    EInlineObjectiveStatTagCheckEntryType__Target = 0,
    EInlineObjectiveStatTagCheckEntryType__Source = 1,
    EInlineObjectiveStatTagCheckEntryType__Context = 2
};

enum EFortXPPropagationRule : uint8_t
{
    EFortXPPropagationRule__Self = 0,
    EFortXPPropagationRule__Party = 1,
    EFortXPPropagationRule__Squad = 2
};

enum EFortReplenishmentType : uint8_t
{
    EFortReplenishmentType__Restricted = 0,
    EFortReplenishmentType__ClampMin = 1,
    EFortReplenishmentType__Add = 2,
    EFortReplenishmentType__Ability = 3
};

enum EFortReplicatedStat : uint8_t
{
    EFortReplicatedStat__MonsterKills = 0,
    EFortReplicatedStat__MonsterDamagePoints = 1,
    EFortReplicatedStat__PlayerKills = 2,
    EFortReplicatedStat__WoodGathered = 3,
    EFortReplicatedStat__StoneGathered = 4,
    EFortReplicatedStat__MetalGathered = 5,
    EFortReplicatedStat__Deaths = 6,
    EFortReplicatedStat__BluGloActivity = 7,
    EFortReplicatedStat__BuildingsBuilt = 8,
    EFortReplicatedStat__BuildingsBuilt_Wood = 9,
    EFortReplicatedStat__BuildingsBuilt_Stone = 10,
    EFortReplicatedStat__BuildingsBuilt_Metal = 11,
    EFortReplicatedStat__BuildingsUpgraded_Wood2 = 12,
    EFortReplicatedStat__BuildingsUpgraded_Wood3 = 13,
    EFortReplicatedStat__BuildingsUpgraded_Stone2 = 14,
    EFortReplicatedStat__BuildingsUpgraded_Stone3 = 15,
    EFortReplicatedStat__BuildingsUpgraded_Metal2 = 16,
    EFortReplicatedStat__BuildingsUpgraded_Metal3 = 17,
    EFortReplicatedStat__BuildingsDestroyed = 18,
    EFortReplicatedStat__Repair_Wood = 19,
    EFortReplicatedStat__Repair_Stone = 20,
    EFortReplicatedStat__Repair_Metal = 21,
    EFortReplicatedStat__FlagsCaptured = 22,
    EFortReplicatedStat__FlagsReturned = 23,
    EFortReplicatedStat__ContainersLooted = 24,
    EFortReplicatedStat__CraftingPoints = 25,
    EFortReplicatedStat__TrapPlacementPoints = 26,
    EFortReplicatedStat__TrapActivationPoints = 27,
    EFortReplicatedStat__TotalScore = 28,
    EFortReplicatedStat__OldTotalScore = 29,
    EFortReplicatedStat__CombatScore = 30,
    EFortReplicatedStat__BuildingScore = 31,
    EFortReplicatedStat__UtilityScore = 32,
    EFortReplicatedStat__BadgesScore = 33,
    EFortReplicatedStat__None = 34
};

enum EFortServerTickRate : uint8_t
{
    EFortServerTickRate__UseDefault = 0,
    EFortServerTickRate__Twenty = 1,
    EFortServerTickRate__Thirty = 2,
    EFortServerTickRate__Sixty = 3
};

enum ESubGameAccessStatus : uint8_t
{
    ESubGameAccessStatus__Disabled = 0,
    ESubGameAccessStatus__LimitedAccess = 1,
    ESubGameAccessStatus__OpenAccess = 2
};

enum EAugmentReRollType : uint8_t
{
    EAugmentReRollType__Any = 0,
    EAugmentReRollType__Free = 1,
    EAugmentReRollType__SpentBars = 2
};

enum EFortWeaponType : uint8_t
{
    EFortWeaponType__None = 0,
    EFortWeaponType__RangedAny = 1,
    EFortWeaponType__Pistol = 2,
    EFortWeaponType__Shotgun = 3,
    EFortWeaponType__Rifle = 4,
    EFortWeaponType__SMG = 5,
    EFortWeaponType__Sniper = 6,
    EFortWeaponType__GrenadeLauncher = 7,
    EFortWeaponType__RocketLauncher = 8,
    EFortWeaponType__Bow = 9,
    EFortWeaponType__Minigun = 10,
    EFortWeaponType__LMG = 11,
    EFortWeaponType__BiplaneGun = 12,
    EFortWeaponType__MeleeAny = 13,
    EFortWeaponType__Harvesting = 14
};

enum EFortWeaponReticleBehaviour : uint8_t
{
    EFortWeaponReticleBehaviour__Center = 0,
    EFortWeaponReticleBehaviour__FocusTarget = 1,
    EFortWeaponReticleBehaviour__Never = 2
};

enum EFortWorldPartitionActorDescMutatorRuleLogicalOperator : uint8_t
{
    EFortWorldPartitionActorDescMutatorRuleLogicalOperator__Or = 0,
    EFortWorldPartitionActorDescMutatorRuleLogicalOperator__And = 1,
    EFortWorldPartitionActorDescMutatorRuleLogicalOperator__Not = 2
};

enum EWorldStatUpdateType : uint8_t
{
    EWorldStatUpdateType__Increment = 0,
    EWorldStatUpdateType__Set = 1,
    EWorldStatUpdateType__Maximum = 2
};

enum EFrontEndCamera : uint8_t
{
    EFrontEndCamera__Invalid = 0,
    EFrontEndCamera__Command = 1,
    EFrontEndCamera__Command_HeroLoadout = 2,
    EFrontEndCamera__LegacyHeroLoadout = 3,
    EFrontEndCamera__Cosmetics = 4,
    EFrontEndCamera__Expeditions = 5,
    EFrontEndCamera__FrontendDefault = 6,
    EFrontEndCamera__Heroes = 7,
    EFrontEndCamera__HeroSelect = 8,
    EFrontEndCamera__HeroLoadout = 9,
    EFrontEndCamera__Home = 10,
    EFrontEndCamera__HomeBase = 11,
    EFrontEndCamera__Login = 12,
    EFrontEndCamera__Manage1 = 13,
    EFrontEndCamera__Manage2 = 14,
    EFrontEndCamera__Manage3 = 15,
    EFrontEndCamera__Manage4 = 16,
    EFrontEndCamera__MissionControl = 17,
    EFrontEndCamera__Party = 18,
    EFrontEndCamera__Play = 19,
    EFrontEndCamera__Research = 20,
    EFrontEndCamera__SkillTrees = 21,
    EFrontEndCamera__SmallCosmetics = 22,
    EFrontEndCamera__SpatialUI = 23,
    EFrontEndCamera__SpecialEvent = 24,
    EFrontEndCamera__SpecialEvent2 = 25,
    EFrontEndCamera__SpecialEvent3 = 26,
    EFrontEndCamera__Store = 27,
    EFrontEndCamera__StoreItemInspect = 28,
    EFrontEndCamera__StwFrontendDefault = 29,
    EFrontEndCamera__SurvivorSquadBuilding1 = 30,
    EFrontEndCamera__SurvivorSquadBuilding2 = 31,
    EFrontEndCamera__SurvivorSquadBuilding3 = 32,
    EFrontEndCamera__SurvivorSquadBuilding4 = 33,
    EFrontEndCamera__TutorialPhaseOne = 34,
    EFrontEndCamera__TutorialPhaseTwo = 35,
    EFrontEndCamera__TutorialPhaseThree = 36,
    EFrontEndCamera__Upgrades = 37,
    EFrontEndCamera__Vault = 38,
    EFrontEndCamera__WorldMap = 39,
    EFrontEndCamera__LobbyCentered = 40,
    EFrontEndCamera__CosmeticDisplay = 41,
    EFrontEndCamera__BattlePass = 42,
    EFrontEndCamera__Rewards = 43,
    EFrontEndCamera__SpecialEventRewards = 44,
    EFrontEndCamera__Armory = 45,
    EFrontEndCamera__DM_Customization = 46,
    EFrontEndCamera__DiscoveryHome = 47,
    EFrontEndCamera__MultipleSquads = 48
};

enum EFortActivityValidationResult : uint8_t
{
    EFortActivityValidationResult__NotFound = 0,
    EFortActivityValidationResult__InvalidKeyTooShort = 1,
    EFortActivityValidationResult__InvalidKeyCharacters = 2,
    EFortActivityValidationResult__IneligibleParty = 3,
    EFortActivityValidationResult__IslandPrivate = 4,
    EFortActivityValidationResult__Success = 5
};

enum EFortSharedAnimationState : uint8_t
{
    EFortSharedAnimationState__Anim_Walk = 0,
    EFortSharedAnimationState__Anim_Run = 1,
    EFortSharedAnimationState__Anim_Turn = 2,
    EFortSharedAnimationState__Anim_Attack = 3,
    EFortSharedAnimationState__Anim_Death = 4,
    EFortSharedAnimationState__Anim_Knockback = 5,
    EFortSharedAnimationState__Anim_FullBodyHit = 6,
    EFortSharedAnimationState__Anim_Pushed = 7,
    EFortSharedAnimationState__Anim_Dance = 8,
    EFortSharedAnimationState__Anim_Idle = 9,
    EFortSharedAnimationState__Anim_RangedAttack = 10
};

enum EHabaneroAnimatedMessage : uint8_t
{
    EHabaneroAnimatedMessage__None = 0,
    EHabaneroAnimatedMessage__HabaneroEngaged = 1,
    EHabaneroAnimatedMessage__ReadyUp = 2
};

enum EIslandInspectorState : uint8_t
{
    EIslandInspectorState__Initializing = 0,
    EIslandInspectorState__Ready = 1,
    EIslandInspectorStY_m_______H_qu_Q_o__5____b_ = 2,
    EIslandInspectorState__ProcessingCommand = 3
};

enum EBackgroundIntensityLevel : uint8_t
{
    EBackgroundIntensityLevel__None = 0,
    EBackgroundIntensityLevel__LowIntensity = 1,
    EBackgroundIntensityLevel__HighIntensity = 2
};

enum ELockedWidgetUnlockType : uint8_t
{
    ELockedWidgetUnlockType__QuestDaysFromEventStart = 0,
    ELockedWidgetUnlockType__QuestChallengesCompleteUntilUnlocked = 1,
    ELockedWidgetUnlockType__BundleDaysFromEventStart = 2,
    ELockedWidgetUnlockType__PrerequisiteQuest = 3
};

enum EIslandJoinability : uint8_t
{
    EIslandJoinability__CanNotBeJoinedOrWatched = 0,
    EIslandJoinability__Joinable = 1,
    EIslandJoinability__Watchable = 2
};

enum EMatchPrivacy : uint8_t
{
    EMatchPrivacy__Private = 0,
    EMatchPrivacy__NoFill = 1,
    EMatchPrivacy__Fill = 2,
    EMatchPrivacy__Undefined = 3
};

enum EGameplayTagGateBehavior : uint8_t
{
    EGameplayTagGateBehavior__OpenOnAdded = 0,
    EGameplayTagGateBehavior__CloseOnAdded = 1,
    EGameplayTagGateBehavior__OpenOnRemoved = 2,
    EGameplayTagGateBehavior__CloseOnRemoved = 3
};

enum EGateCheckType : uint8_t
{
    EGateCheckType__RequireAll = 0,
    EGateCheckType__RequireAny = 1,
    EGateCheckType__RequireSequentialOrder = 2
};

enum EObjectiveGateRelation : uint8_t
{
    EObjectiveGateRelation__RequiredOpen = 0,
    EObjectiveGateRelation__RequiredClosed = 1,
    EObjectiveGateRelation__RequiredSame = 2,
    EObjectiveGateRelation__RequiredOpposite = 3,
    EObjectiveGateRelation__Substitution = 4
};

enum EGateResetBehavior : uint8_t
{
    EGateResetBehavior__DoesNotReset = 0,
    EGateResetBehavior__ResetObjectiveOnGateClose = 1,
    EGateResetBehavior__ResetObjectiveAndDataOnGateClose = 2,
    EGateResetBehavior__ResetQuestOnGateClose = 3,
    EGateResetBehavior__ResetObjectiveAndDataOnGateClose_NoToast = 4
};

enum EPersistenceFrameworkExecutionOption : uint8_t
{
    EPersistenceFrameworkExecutionOption__RemoveAllActionsOnFinish = 0,
    EPersistenceFrameworkExecutionOption__AbortIfAnyActionFails = 1,
    EPersistenceFrameworkExecutionOption__EPersistenceFrameworkActionQueueOptions_MaxFlags = 2
};

enum EPersistenceFrameworkResult : uint8_t
{
    EPersistenceFrameworkResult__Failed = 0,
    EPersistenceFrameworkResult__Success = 1,
    EPersistenceFrameworkResult__InProgress = 2,
    EPersistenceFrameworkResult__NotReady = 3
};

enum EPersistenceFrameworkServiceLatentResult : uint8_t
{
    EPersistenceFrameworkServiceLatentResult__EndedTickingWithFailure = 0,
    EPersistenceFrameworkServiceLatentResult__EndedTickingWithSuccess = 1,
    EPersistenceFrameworkServiceLatentResult__ContinueTicking = 2
};

enum EPersistenceFrameworkState : uint8_t
{
    EPersistenceFrameworkState__NotReady = 0,
    EPersistenu__SW__v9____0r___h__C____f_____S__SE = 1,
    EPersistenceFrameworkState__Deinitializing = 2,
    EPersistenceFrameworkState__DeInitialized = 3
};

enum UPFWCheat_RootArea : uint8_t
{
    UPFWCheat_RootArea__Player = 0,
    UPFWCheat_RootArea__WorldForPlayer = 1,
    UPFWCheat_RootArea__World = 2
};

enum EModularGatePlatformTypes : uint8_t
{
    EModularGatePlatformTypes__None = 0,
    EModularGatePlatformTypes__Mobile = 1,
    EModularGatePlatformTypes__Console = 2,
    EModularGatePlatformTypes__Desktop = 4,
    EModularGatePlatformTypes__All = 7
};

enum EQuestParticipationScope : uint8_t
{
    EQuestParticipationScope__None = 0,
    EQuestParticipationScope__Personal = 1,
    EQuestParticipationScope__Playspace = 2,
    EQuestParticipationScope__World = 3,
    EQuestParticipationScope__Squad = 4,
    EQuestParticipationScope__Party = 5
};

enum EQuestObjectiveUpdateType : uint8_t
{
    EQuestObjectiveUpdateType__Progressed = 0,
    EQuestObjectiveUpdateType__ResetObjective = 1,
    EQuestObjectiveUpdateType__ResetQuest = 2,
    EQuestObjectiveUpdateType__ResetObjectiveNoDisplayUpdate = 3,
    EQuestObjectiveUpdateType__Decremented = 4
};

enum EPriorityInsertion : uint8_t
{
    EPriorityInsertion__AfterReferenceTag = 0,
    EPriorityInsertion__BeforeReferenceTag = 1
};

enum EIndexNavigationResult : uint8_t
{
    EIndexNavigationResult__Succeeded = 0,
    EIndexNavigationResult__Modified = 1,
    EIndexNavigationResult__Clamped = 2,
    EIndexNavigationResult__StepOff = 3,
    EIndexNavigationResult__NoMove = 4
};

enum ESocialRequirementsRequiredForGate : uint8_t
{
    ESocialRequirementsRequiredForGate__AllSocialRequirements = 0,
    ESocialRequirementsRequiredForGate__AnySocialRequirements = 1,
    ESocialRequirementsRequiredForGate__NoSocialRequirements = 2
};

enum ESocialRequirementGateGroupType : uint8_t
{
    ESocialRequirementGateGroupType__Solo = 0,
    ESocialRequirementGateGroupType__Squad = 1,
    ESocialRequirementGateGroupType__Party = 2
};

enum EStateTransitionControlEvent : uint8_t
{
    EStateTransitionControlEvent__OnStateTransitionPaused = 0,
    EStateTransitionControlEvent__OnStateTransitionComplete = 1,
    EStateTransitionControlEvent__Count = 2
};

enum EStateTransitionPauseRequestHandleClearType : uint8_t
{
    EStateTransitionPauseRequestHandleClearType__ClearWhenAllHandlesAreRemoved = 0,
    ES____________________O_O_9I_L_y_h____________________k1V__ = 1
};

enum ETriState : uint8_t
{
    ETriState__DefaultState = 0,
    ETriState__TrueState = 1,
    ETriState__FalseState = 2
};

enum EVkConversationRequirement_TargetEnum : uint8_t
{
    EVkConversationRequirement_TargetEnum__Instigator = 0,
    EVkConversationRequirement_TargetEnum__ConversationDevice = 1
};

enum EVkConversationRequirement_TypeOfCheckEnum : uint8_t
{
    EVkConversationRequirement_TypeOfCheckEnum__All = 0,
    EVkConversationRequirement_TypeOfCheckEnum__None = 1,
    EVkConversationRequirement_TypeOfCheckEnum__Any = 2
};

enum FTurnTransitionCondition : uint8_t
{
    FTurnTransitionCondition__None = 0,
    FTurnTransitionCondition__Inplace = 1,
    FTurnTransitionCondition__Start = 2,
    FTurnTransitionCondition__Moving = 3
};

enum EMedicPackState : uint8_t
{
    EMedicPackState__Idle = 0,
    EMedicPackState__Active = 1,
    EMedicPackState__None = 2
};

enum EFortGameplayCueSourceCondition : uint8_t
{
    EFortGameplayCueSourceCondition__AnySource = 0,
    EFortGameplayCueSourceCondition__LocalPlayerSource = 1,
    EFortGameplayCueSourceCondition__NonLocalPlayerSource = 2
};

enum EFortActorTemplateCostUpdateMethod : uint8_t
{
    EFortActorTemplateCostUpdateMethod__Latest = 0,
    EFortActorTemplateCostUpdateMethod__Smallest = 1,
    EFortActorTemplateCostUpdateMethod__OnlyNew = 2,
    EFortActorTemplateCostUpdateMethod__Double = 3
};

enum EFortAnalyticsClientEngagementEventType : uint8_t
{
    EFortAnalyticsClientEngagementEventType__None = 0,
    EFortAnalyticsClientEngagementEventType__DamageReceivedFromPlayerPawn = 1,
    EFortAnalyticsClientEngagementEventType__DamageDealtToPlayerPawn = 2,
    EFortAnalyticsClientEngagementEventType__DamageDealtToPlayerBuild = 3,
    EFortAnalyticsClientEngagementEventType__DamageDealtToOther = 4,
    EFortAnalyticsClientEngagementEventType__EngagementTimeout = 5,
    EFortAnalyticsClientEngagementEventType__PlayerWon = 6,
    EFortAnalyticsClientEngagementEventType__PlayerDeathOnWin = 7,
    EFortAnalyticsClientEngagementEventType__TeamWon = 8,
    EFortAnalyticsClientEngagementEventType__TeamLost = 9,
    EFortAnalyticsClientEngagementEventType__PlayerLost = 10,
    EFortAnalyticsClientEngagementEventType__PlayerKilledPlayer = 11,
    EFortAnalyticsClientEngagementEventType__PlayerFiredWeapon = 12,
    EFortAnalyticsClientEngagementEventType__ManagerStopped = 13,
    EFortAnalyticsClientEngagementEventType__PlayerPawnDied = 14,
    EFortAnalyticsClientEngagementEventType__PlayerPawnSpawned = 15,
    EFortAnalyticsClientEngagementEventType__Count = 16
};

enum EFortAnalyticsEventDenylistPlaylistKey : uint8_t
{
    EFortAnalyticsEventDenylistPlaylistKey__PlaylistType = 0,
    EFortAnalyticsEventDenylistPlaylistKey__PlaylistName = 1,
    EFortAnalyticsEventDenylistPlaylistKey__All = 2
};

enum EEnvironmentalItemEndReason : uint8_t
{
    EEnvironmentalItemEndReason__None = 0,
    EEnvironmentalItemEndReason__PlayerExit = 1,
    EEnvironmentalItemEndReason__PlayerDeath = 2,
    EEnvironmentalItemEndReason__ObjectDestroyed = 3
};

enum EAlphaFromDeltaTypes : uint8_t
{
    EAlphaFromDeltaTypes__TranslationX = 0,
    EAlphaFromDeltaTypes__TranslationY = 1,
    EAlphaFromDeltaTypes__TranslationZ = 2,
    EAlphaFromDeltaTypes__Scale = 3,
    EAlphaFromDeltaTypes__ScaleX = 4,
    EAlphaFromDeltaTypes__ScaleY = 5,
    EAlphaFromDeltaTypes__ScaleZ = 6,
    EAlphaFromDeltaTypes__EulerX = 7,
    EAlphaFromDeltaTypes__EulerY = 8,
    EAlphaFromDeltaTypes__EulerZ = 9,
    EAlphaFromDeltaTypes__QuaternionTwist = 10
};

enum EAnimRelaxedState : uint8_t
{
    EAnimRelaxedState__None = 0,
    EAnimRelaxedState__WeaponRaised = 1,
    EAnimRelaxedState__RelaxedLevel1 = 2,
    EAnimRelaxedState__RelaxedLevel2 = 3
};

enum ERidingFootPhase : uint8_t
{
    ERidingFootPhase__FeetInAir = 0,
    ERidingFootPhase__FrontFeetPlanted = 1,
    ERidingFootPhase__BackFeetPlanted = 2,
    ERidingFootPhase__LeftBackFeetForward = 3,
    ERidingFootPhase__RightBackFeetForward = 4,
    ERidingFootPhase__LeftPlantedRightPass = 5,
    ERidingFootPhase__RightPlantedLeftPass = 6
};

enum ESourceSelectionMode : uint8_t
{
    ESourceSelectionMode__MaxDifference = 0
};

enum EFortAnimNode_NoBlendCurveSlot_Mode : uint8_t
{
    EFortAnimNode_NoBlendCurveSlot_Mode__FullFromSourceWhileActive = 0,
    EFortAnimNode_NoBlendCurveSlot_Mode__FullFromLatestMontage = 1,
    EFortAnimNode_NoBlendCurveSlot_Mode__Blended = 2
};

enum EMontageSyncTargetType : uint8_t
{
    EMontageSyncTargetType__Pet = 0,
    EMontageSyncTargetType__CustomPartType = 1,
    EMontageSyncTargetType__Weapon = 2
};

enum EMontageInterrupt : uint8_t
{
    EMontageInterrupt__Any = 0,
    EMontageInterrupt__RootMotionOnly = 1,
    EMontageInterrupt__None = 2
};

enum EFortNotifyAudioParamsStoreSource : uint8_t
{
    EFortNotifyAudioParamsStoreSource__Weapon = 0,
    EFortNotifyAudioParamsStoreSource__Pawn = 1,
    EFortNotifyAudioParamsStoreSource__Controller = 2
};

enum EDeimosAnimState : uint8_t
{
    EDeimosAnimState__Idle = 0,
    EDeimosAnimState__Running = 1,
    EDeimosAnimState__Attack = 2,
    EDeimosAnimState__Dance = 3,
    EDeimosAnimState__Dying = 4,
    EDeimosAnimState__Died = 5,
    EDeimosAnimState__FullBodyHitReact = 6,
    EDeimosAnimState__AdditiveHitReact = 7,
    EDeimosAnimState__ActiveIdle = 8,
    EDeimosAnimState__Falling = 9,
    EDeimosAnimState__Frozen = 10,
    EDeimosAnimState__RangedAttack = 11,
    EDeimosAnimState__Walking = 12,
    EDeimosAnimState__Sprinting = 13
};

enum EFortFacialAnimTypes : uint8_t
{
    EFortFacialAnimTypes__Default = 0,
    EFortFacialAnimTypes__FaceOnly = 1,
    EFortFacialAnimTypes__FullHead = 2,
    EFortFacialAnimTypes__FromAmplitude = 3,
    EFortFacialAnimTypes__Max = 4
};

enum EGliderType : uint8_t
{
    EGliderType__HangGlider = 0,
    EGliderType__Umbrella = 1,
    EGliderType__Surfing = 2,
    EGliderType__SurfingSimple = 3,
    EGliderType__Cape = 4,
    EGliderType__Stairs = 5,
    EGliderType__NoGlider = 6
};

enum EFortCardinalDirection : uint8_t
{
    EFortCardinalDirection__North = 0,
    EFortCardinalDirection__East = 1,
    EFortCardinalDirection__South = 2,
    EFortCardinalDirection__West = 3
};

enum EFortPlayerAnimBodyType : uint8_t
{
    EFortPlayerAnimBodyType__Small = 0,
    EFortPlayerAnimBodyType__Medium = 1,
    EFortPlayerAnimBodyType__Large = 2,
    EFortPlayerAnimBodyType__All = 3
};

enum EFortHandIKOverrideType : uint8_t
{
    EFortHandIKOverrideType__UseDefault = 0,
    EFortHandIKOverrideType__ForceFK = 1,
    EFortHandIKOverrideType__ForceIK = 2,
    EFortHandIKOverrideType__ForceFKSnap = 3
};

enum EFortHuskAnimType : uint8_t
{
    EFortHuskAnimType__Basic = 0,
    EFortHuskAnimType__Dwarf = 1,
    EFortHuskAnimType__BlasterBig = 2,
    EFortHuskAnimType__Weak = 3,
    EFortHuskAnimType__TinyHead = 4,
    EFortHuskAnimType__Beehive = 5,
    EFortHuskAnimType__Husky = 6,
    EFortHuskAnimType__Sploder = 7,
    EFortHuskAnimType__Zapper = 8
};

enum EFortValetVehicleType : uint8_t
{
    EFortValetVehicleType__Default = 0,
    EFortValetVehicleType__Sport = 1,
    EFortValetVehicleType__BasicTruck = 2
};

enum EFortAnnouncementChannel : uint8_t
{
    EFortAnnouncementChannel__Primary = 0,
    EFortAnnouncementChannel__Conversation = 1,
    EFortAnnouncementChannel__Tutorial = 2,
    EFortAnnouncementChannel__Max_None = 3
};

enum EFortAnnouncementDisplayPreference : uint8_t
{
    EFortAnnouncementDisplayPreference__Default_HUD = 0,
    EFortAnnouncementDisplayPreference__QuestIntroduction = 1,
    EFortAnnouncementDisplayPreference__QuestJournal = 2
};

enum EAthenaQuickChatFilteringType : uint8_t
{
    EAthenaQuickChatFilteringType__AlwaysVisible = 0,
    EAthenaQuickChatFilteringType__ActiveMaterial = 1,
    EAthenaQuickChatFilteringType__FacingPickup = 2,
    EAthenaQuickChatFilteringType__ActiveHotbarItem = 3,
    EAthenaQuickChatFilteringType__ActiveHotbarItemAmmo = 4,
    EAthenaQuickChatFilteringType__FacingPickupOrActiveHotbarItem = 5,
    EAthenaQuickChatFilteringType__NoWeaponEquippedRequiringAmmo = 6,
    EAthenaQuickChatFilteringType__WeaponEquippedOfAmmoType = 7
};

enum EAthenaRewardItemType : uint8_t
{
    EAthenaRewardItemType__Normal = 0,
    EAthenaRewardItemType__HiddenReward = 1,
    EAthenaRewardItemType__GiftboxHiddenReward = 2,
    EAthenaRewardItemType__NonExportedFakeReward = 3
};

enum EBarrierState : uint8_t
{
    EBarrierState__BarrierUp = 0,
    EBarrierState__BarrierComingDown = 1,
    EBarrierState__BarrierDown = 2
};

enum EContentionRuleType : uint8_t
{
    EContentionRuleType__MajorityWins = 0,
    EContentionRuleType__OneTeamOnlyWins = 1
};

enum ECapturePointUnlockRules : uint8_t
{
    ECapturePointUnlockRules__Reset = 0,
    ECapturePointUnlockRules__MaintainState = 1,
    ECapturePointUnlockRules__ResetDeactivate = 2
};

enum ETraversePointState : uint8_t
{
    ETraversePointState__None = 0,
    ETraversePointState__Hidden = 1,
    ETraversePointState__Active = 2,
    ETraversePointState__TouchedByPlayer = 3,
    ETraversePointState__Finished = 4
};

enum ESpawnResult : uint8_t
{
    ESpawnResult__Success = 0,
    ESpawnResult__Failure_NoLocationFound = 1,
    ESpawnResult__Failure_NoActorClass = 2,
    ESpawnResult__Failure_BadQueryData = 3
};

enum EStashInventoryServiceSyncState : uint8_t
{
    EStashInventoryServiceSyncState__Uninitialized = 0,
    EStashInventoryServiceSyncState__Syncing = 1,
    EStashInventoryServiceSyncState__Ready = 2
};

enum EPoiDiscoveredState : uint8_t
{
    EPoiDiscoveredState__Undiscovered = 0,
    EPoiDiscoveredState__Discovered = 1,
    EPoiDiscoveredState__ForceDiscovered = 2
};

enum ESkydiveFeedbackPhase : uint8_t
{
    ESkydiveFeedbackPhase__Initial = 0,
    ESkydiveFeedbackPhase__WithGlider = 1,
    ESkydiveFeedbackPhase__InVortex = 2,
    ESkydiveFeedbackPhase__None = 3
};

enum EQuestAnalyticStage : uint8_t
{
    EQuestAnalyticStage__Granted = 0,
    EQuestAnalyticStage__AutoCompleted = 1,
    EQuestAnalyticStage__Completed = 2,
    EQuestAnalyticStage__Failed = 3
};

enum EDadBroHealthType : uint8_t
{
    EDadBroHealthType__None = 0,
    EDadBroHealthType__Weakpoints = 1,
    EDadBroHealthType__Horn = 2,
    EDadBroHealthType__Guy = 3
};

enum FCollisionWithBuildingActorReactionTypes : uint8_t
{
    FCollisionWithBuildingActorReactionTypes__DoNothing = 0,
    FCollisionWithBuildingActorReactionTypes__PlayAttackAbility = 1,
    FCollisionWithBuildingActorReactionTypes__Destroy = 2,
    FCollisionWithBuildingActorReactionTypes__ApplyGameplayEffect = 3
};

enum FCollisionWithLaunchableReactionTypes : uint8_t
{
    FCollisionWithLaunchableReactionTypes__DoNothing = 0,
    FCollisionWithLaunchableReactionTypes__Launch = 1,
    FCollisionWithLaunchableReactionTypes__OverrideOther = 2
};

enum ETypeOfBuildingActor : uint8_t
{
    ETypeOfBuildingActor__Anything = 0,
    ETypeOfBuildingActor__PlayerBuilt = 1,
    ETypeOfBuildingActor__NonPlayerBuilt = 2
};

enum EFreelookMode : uint8_t
{
    EFreelookMode__None = 0,
    EFreelookMode__Mouse = 1,
    EFreelookMode__Analog = 2,
    EFreelookMode__Touch = 3
};

enum EExitCraftState : uint8_t
{
    EExitCraftState__None = 0,
    EExitCraftState__Spawned = 1,
    EExitCraftState__Landed = 2,
    EExitCraftState__SpawnBalloon = 3,
    EExitCraftState__GettingIntoPosition = 4,
    EExitCraftState__GettingIntoPosition_Simple = 5,
    EExitCraftState__WaitingForPawns = 6,
    EExitCraftState__Exiting = 7
};

enum EBuildingGameplayActorAircraftSpawnSide : uint8_t
{
    EBuildingGameplayActorAircraftSpawnSide__None = 0,
    EBuildingGameplayActorAircraftSpawnSide__Side1 = 1,
    EBuildingGameplayActorAircraftSpawnSide__Side2 = 2
};

enum EDebugVehicleFlags : uint8_t
{
    EDebugVehicleFlags__Status = 0,
    EDebugVehicleFlags__Input = 1,
    EDebugVehicleFlags__Controls = 2,
    EDebugVehicleFlags__Shocks = 3,
    EDebugVehicleFlags__Exits = 4,
    EDebugVehicleFlags__Water = 5,
    EDebugVehicleFlags__Wheels = 6,
    EDebugVehicleFlags__Friction = 7,
    EDebugVehicleFlags__AirControl = 8,
    EDebugVehicleFlags__CenterOfMass = 9,
    EDebugVehicleFlags__Gravity = 10,
    EDebugVehicleFlags__Forces = 11,
    EDebugVehicleFlags__Damage = 12,
    EDebugVehicleFlags__Collisions = 13,
    EDebugVehicleFlags__OrientationCorrection = 14,
    EDebugVehicleFlags__BoundarySpline = 15,
    EDebugVehicleFlags__Sleeping = 16,
    EDebugVehicleFlags__Misc = 17,
    EDebugVehicleFlags__LeanBreak = 18,
    EDebugVehicleFlags__LevelOfDetail = 19
};

enum EOstrichDetonationState : uint8_t
{
    EOstrichDetonationState__None = 0,
    EOstrichDetonationState__Detonate = 1,
    EOstrichDetonationState__SelfDestruct = 2,
    EOstrichDetonationState__Instant = 3
};

enum EPartVisibilityCheatPolicy : uint8_t
{
    EPartVisibilityCheatPolicy__LocalPawn = 0,
    EPartVisibilityCheatPolicy__NearestNonLocalPawn = 1,
    EPartVisibilityCheatPolicy__AllPawns = 2
};

enum EFortContrailsState : uint8_t
{
    EFortContrailsState__NotActive = 0,
    EFortContrailsState__ActivationPending = 1,
    EFortContrai____UG____G7_______S_ = 2,
    EFortContrailsState__Active = 3
};

enum ECreativePortalManagerValidityResult : uint8_t
{
    ECreativePortalManagerValidityResult__Valid = 0,
    ECreativePortalManagerValidityResult__Invalid = 1
};

enum EAircraftLaunchReason : uint8_t
{
    EAircraftLaunchReason__StdTimerAllPlayers = 0,
    EAircraftLaunchReason__EarlyTimerAllPlayers = 1,
    EAircraftLaunchReason__StdTimerMostPlayers = 2,
    EAircraftLaunchReason__EarlyTimerMostPlayers = 3,
    EAircraftLaunchReason__StdTimerFewPlayers = 4
};

enum EGameModePauseWarmupMaskId : uint8_t
{
    EGameModePauseWarmupMaskId__None = 0,
    EGameModePauseWarmupMaskId__Debug = 1,
    EGameModePauseWarmupMaskId__Mutator = 2,
    EGameModePauseWarmupMaskId__BroadcastController = 4,
    EGameModePauseWarmupMaskId__PlayerBotsSpawning = 8,
    EGameModePauseWarmupMaskId__DownloadOnDemand = 16,
    EGameModePauseWarmupMaskId__Minigame = 32
};

enum EAthenaAerialPhase : uint8_t
{
    EAthenaAerialPhase__None = 0,
    EAthenaAerialPhase__BusCantExit = 1,
    EAthenaAerialPhase__BusCanExit = 2,
    EAthenaAerialPhase__BusCanExitEndZebulonDrone = 3,
    EAthenaAerialPhase__Skydiving = 4,
    EAthenaAerialPhase__Parachuting = 5,
    EAthenaAerialPhase__Falling = 6
};

enum EAthenaFilterDisplayType : uint8_t
{
    EAthenaFilterDisplayType__UseCategoryName = 0,
    EAthenaFilterDisplayType__ShowFilterString = 1
};

enum EMegaStormState : uint8_t
{
    EMegaStormState__GatheringActorList = 0,
    EMegaStormState__DamagingActors = 1
};

enum EMutatorListInitState : uint8_t
{
    EMutatorListInitState__Default = 0,
    EMutatorListInitState__Enabled = 1,
    EMutatorListInitState__Disabled = 2
};

enum EMutatorOverrideSource : uint8_t
{
    EMutatorOverrideSource__Default = 0,
    EMutatorOverrideSource__External = 1
};

enum EPartyRiftPortalManagerValidityResult : uint8_t
{
    EPartyRiftPortalManagerValidityResult__Valid = 0,
    EPartyRiftPortalManagerValidityResult__Invalid = 1
};

enum EPawnLaunchMinVelocityApply : uint8_t
{
    EPawnLaunchMinVelocityApply__Add = 0,
    EPawnLaunchMinVelocityApply__Min = 1
};

enum EMapZoomingMode : uint8_t
{
    EMapZoomingMode__None = 0,
    EMapZoomingMode__ZoomingIn = 1,
    EMapZoomingMode__ZoomingOut = 2
};

enum EBackpackType : uint8_t
{
    EBackpackType__Jetpack = 0,
    EBackpackType__Medic = 1,
    EBackpackType__StormTracker = 2,
    EBackpackType__Glider = 3,
    EBackpackType__COUNT = 4
};

enum EKeepPlayingTogetherAnalyticEventPhase : uint8_t
{
    EKeepPlayingTogetherAnalyticEventPhase__PrePostGamePhase = 0,
    EKeepPlayingTogetherAnalyticEventPhase__Countdown = 1,
    EKeepPlayingTogetherAnalyticEventPhase__TimedOut = 2,
    EKeepPlayingTogetherAnalyticEventPhase__AllSquadMembersVoted = 3,
    EKeepPlayingToge_l__R____0J____ZG____AyN___G__b__a_6v____0F____U______________B__I = 4
};

enum ECustomGameVoiceChannel : uint8_t
{
    ECustomGameVoiceChannel__Squad = 0,
    ECustomGameVoiceChannel__FullTeam = 1,
    ECustomGameVoiceChannel__WholeServer = 2
};

enum ESafeZoneStartUp : uint8_t
{
    ESafeZoneStartUp__UseDefaultGameBehavior = 0,
    ESafeZoneStartUp__StartsWithWarmUp = 1,
    ESafeZoneStartUp__StartsWithAirCraft = 2,
    ESafeZoneStartUp__StartsWithNoAirCraft = 3
};

enum EAirCraftBehavior : uint8_t
{
    EAirCraftBehavior__Default = 0,
    EAirCraftBehavior__OpposingAirCraftForEachTeam = 1,
    EAirCraftBehavior__FlyTowardFirstCircleCenter = 2,
    EAirCraftBehavior__NoAircraft = 3
};

enum EAthenaRespawnType : uint8_t
{
    EAthenaRespawnType__None = 0,
    EAthenaRespawnType__InfiniteRespawn = 1,
    EAthenaRespawnType__InfiniteRespawnExceptStorm = 2
};

enum EAthenaRespawnLocation : uint8_t
{
    EAthenaRespawnLocation__LastDeath = 0,
    EAthenaRespawnLocation__CreativePlayerStart = 1
};

enum EAthenaWinCondition : uint8_t
{
    EAthenaWinCondition__LastManStanding = 0,
    EAthenaWinCondition__LastManStandingIncludingAllies = 1,
    EAthenaWinCondition__TimedTeamFinalFight = 2,
    EAthenaWinCondition__FirstToGoalScore = 3,
    EAthenaWinCondition__TimedLastMenStanding = 4,
    EAthenaWinCondition__MutatorControlled = 5
};

enum ERewardTimePlayedType : uint8_t
{
    ERewardTimePlayedType__Default = 0,
    ERewardTimePlayedType__NoReward = 1,
    ERewardTimePlayedType__FlatValue = 2
};

enum ERewardPlacementBonusType : uint8_t
{
    ERewardPlacementBonusType__Solo = 0,
    ERewardPlacementBonusType__Duo = 1,
    ERewardPlacementBonusType__Squad = 2,
    ERewardPlacementBonusType__LargeTeam = 3,
    ERewardPlacementBonusType__None = 4,
    ERewardPlacementBonusType__TwoTeam = 5,
    ERewardPlacementBonusType__MediumTeam = 6,
    ERewardPlacementBonusType__QuickSolo = 7,
    ERewardPlacementBonusType__QuickDuo = 8,
    ERewardPlacementBonusType__QuickSquad = 9,
    ERewardPlacementBonusType__QuickLargeTeam = 10,
    ERewardPlacementBonusType__QuickTwoTeam = 11,
    ERewardPlacementBonusType__QuickMediumTeam = 12,
    ERewardPlacementBonusType__SinglePlacement = 13
};

enum EWeaponSelectionPreservationType : uint8_t
{
    EWeaponSelectionPreservationType__KeepSelectionWhenRespawning = 0,
    EWeaponSelectionPreservationType__NeverKeepSelection = 1
};

enum EFortSpawnActorTime : uint8_t
{
    EFortSpawnActorTime__PostPlaylistLoad = 0,
    EFortSpawnActorTime__StartOfStormHoldTime = 1
};

enum ESupplyDropSpawnType : uint8_t
{
    ESupplyDropSpawnType__SafeZoneDriven = 0,
    ESupplyDropSpawnType__ItemDeliveryManagement = 1,
    ESupplyDropSpawnType__MutatorManaged = 2
};

enum ESupplyDropItemTrackType : uint8_t
{
    ESupplyDropItemTrackType__SpecialActors = 0
};

enum EMessageFeedRelationshipFilter : uint8_t
{
    EMessageFeedRelationshipFilter__Anyone = 0,
    EMessageFeedRelationshipFilter__SquadAndTeamMembers = 1,
    EMessageFeedRelationshipFilter__SquadMembersOnly = 2,
    EMessageFeedRelationshipFilter__SelfOnly = 3
};

enum EMessageFeedSubject : uint8_t
{
    EMessageFeedSubject__ToyOwner = 0,
    EMessageFeedSubject__OtherPlayerInteractingWithToy = 1
};

enum EFortDualWieldSwingState : uint8_t
{
    EFortDualWieldSwingState__None = 0,
    EFortDualWieldSwingState__MainHand = 1,
    EFortDualWieldSwingState__OffHand = 2,
    EFortDualWieldSwingState__BothHands = 3
};

enum EFortDualWieldDataSource : uint8_t
{
    EFortDualWieldDataSource__BaseConfiguration = 0,
    EFortDd_________5w__TD___l3____i__XA = 1
};

enum EFortWeaponUpgradeCosts : uint8_t
{
    EFortWeaponUpgradeCosts__NotSet = 0,
    EFortWeaponUpgradeCosts__WoodUncommon = 1
};

enum EFortWeaponUpgradeInteractionResult : uint8_t
{
    EFortWeaponUpgradeInteractionResult__Upgradable = 0,
    EFortWeaponUpgradeInteractionResult__NotEnoughResources = 1,
    EFortWeaponUpgradeInteractionResult__CannotUpgrade = 2,
    EFortWeaponUpgradeInteractionResult__CannotInteract = 3
};

enum EPlayerAttributeClampType : uint8_t
{
    EPlayerAttributeClampType__Minimum = 0,
    EPlayerAttributeClampType__Maximum = 1
};

enum EFortAthenaMutator_TextChatGameChannelType : uint8_t
{
    EFortAthenaMutator_TextChatGameChannelType__Default = 0,
    EFortAthenaMutator_TextChatGameChannelType__TeamOnly = 1,
    EFortAthenaMutator_TextChatGameChannelType__None = 2,
    EFortAthenaMutator_TextChatGameChannelType__ScopeOnly = 3,
    EFortAthenaMutator_TextChatGameChannelType__ScopeTeamOnly = 4
};

enum ESpawnPointState : uint8_t
{
    ESpawnPointState__Inactive = 0,
    ESpawnPointState__Active_CarryObjectInRange = 1,
    ESpawnPointState__Active_CarryObjectOutOfRange = 2,
    ESpawnPointState__IntelCaptured = 3,
    ESpawnPointState__IntelDownloaded = 4
};

enum ECancelMarkerReason : uint8_t
{
    ECancelMarkerReason__Ping = 0,
    ECancelMarkerReason__MapOrDeath = 1
};

enum EMarkableResult : uint8_t
{
    EMarkableResult__Markable = 0,
    EMarkableResult__Block = 1,
    EMarkableResult__Continue = 2,
    EMarkableResult__MarkableWithoutAttaching = 3
};

enum EAshtonStoneType : uint8_t
{
    EAshtonStoneType__Purple = 0,
    EAshtonStoneType__Blue = 1,
    EAshtonStoneType__Red = 2,
    EAshtonStoneType__Orange = 3,
    EAshtonStoneType__Green = 4,
    EAshtonStoneType__Yellow = 5
};

enum EFortCreativeAutoPickupSetting : uint16_t
{
    EFortCreativeAutoPickupSetting__IsFalse = 0,
    EFortCreativeAutoPickupSetting__IsTrue = 1,
    EFortCreativeAutoPickupSetting__AutoOnly = 2,
    EFortCreativeAutoPickupSetting__Unset = 255
};

enum EBagelScoreEvent : uint8_t
{
    EBagelScoreEvent__FiendKill = 0,
    EBagelScoreEvent__BruteKill = 1,
    EBagelScoreEvent__RangedKill = 2,
    EBagelScoreEvent__ExplodingKill = 3,
    EBagelScoreEvent__ChillKill = 4,
    EBagelScoreEvent__PoisonKill = 5,
    EBagelScoreEvent__GoldKill = 6,
    EBagelScoreEvent__RiftDestroyed = 7,
    EBagelScoreEvent__ScoreMultiplierUsed = 8,
    EBagelScoreEvent__HeadshotKill = 9,
    EBagelScoreEvent__RespawnPenalty = 10,
    EBagelScoreEvent__AmmoBoxOpened = 11,
    EBagelScoreEvent__ChestOpened = 12,
    EBagelScoreEvent__FinalBossKill = 13
};

enum EBarrierFoodTeam : uint8_t
{
    EBarrierFoodTeam__Burger = 0,
    EBarrierFoodTeam__Tomato = 1
};

enum EBarrierObjectiveDamageState : uint8_t
{
    EBarrierObjectiveDamageState__Health = 0,
    EBarrierObjectiveDamageState__Health = 1,
    EBarrierObjectiveDamageState__Health = 2,
    EBarrierObjectiveDamageState__Health = 3,
    EBarrierObjectiveDamageState__Health = 4,
    EBarrierObjectiveDamageState__Health = 5,
    EBarrierObjectiveDamageState__Health = 6,
    EBarrierObjectiveDamageState__Health = 7,
    EBarrierObjectiveDamageState__Health = 8
};

enum EAllowedToEdit : uint8_t
{
    EAllowedToEdit__Default = 0,
    EAllowedToEdit__Anyone = 1
};

enum ECreativeRespawnWaveType : uint8_t
{
    ECreativeRespawnWaveType__None = 0,
    ECreativeRespawnWaveType__WaveStartingOnElimination = 1
};

enum EFortCrucibleStatType : uint8_t
{
    EFortCrucibleStatType__CourseOverall = 0,
    EFortCrucibleStatType__CourseSegment1 = 1,
    EFortCrucibleStatType__CourseSegment2 = 2,
    EFortCrucibleStatType__CourseSegment3 = 3,
    EFortCrucibleStatType__CourseSegment4 = 4,
    EFortCrucibleStatType__CourseSegment5 = 5,
    EFortCrucibleStatType__Count = 6
};

enum EFortCrucibleControlType : uint8_t
{
    EFortCrucibleControlType__Gamepad = 0,
    EFortCrucibleControlType__KBM = 1,
    EFortCrucibleControlType__Touch = 2,
    EFortCrucibleControlType__Count = 3
};

enum EFortCrucibleStatId : uint8_t
{
    EFortCrucibleStatId__Gamepad_CourseOverall = 0,
    EFortCrucibleStatId__Gamepad_CourseSegment1 = 1,
    EFortCrucibleStatId__Gamepad_CourseSegment2 = 2,
    EFortCrucibleStatId__Gamepad_CourseSegment3 = 3,
    EFortCrucibleStatId__Gamepad_CourseSegment4 = 4,
    EFortCrucibleStatId__Gamepad_CourseSegment5 = 5,
    EFortCrucibleStatId__KBM_CourseOverall = 6,
    EFortCrucibleStatId__KBM_CourseSegment1 = 7,
    EFortCrucibleStatId__KBM_CourseSegment2 = 8,
    EFortCrucibleStatId__KBM_CourseSegment3 = 9,
    EFortCrucibleStatId__KBM_CourseSegment4 = 10,
    EFortCrucibleStatId__KBM_CourseSegment5 = 11,
    EFortCrucibleStatId__Touch_CourseOverall = 12,
    EFortCrucibleStatId__Touch_CourseSegment1 = 13,
    EFortCrucibleStatId__Touch_CourseSegment2 = 14,
    EFortCrucibleStatId__Touch_CourseSegment3 = 15,
    EFortCrucibleStatId__Touch_CourseSegment4 = 16,
    EFortCrucibleStatId__Touch_CourseSegment5 = 17,
    EFortCrucibleStatId__Count = 18
};

enum EFortCrucibleLeaderboardId : uint8_t
{
    EFortCrucibleLeaderboardId__GlobalGamepad = 0,
    EFortCrucibleLeaderboardId__GlobalKBM = 1,
    EFortCrucibleLeaderboardId__GlobalTouch = 2,
    EFortCrucibleLeaderboardId__GlobalAll = 3,
    EFortCrucibleLeaderboardId__FriendsGamepad = 4,
    EFortCrucibleLeaderboardId__FriendsKBM = 5,
    EFortCrucibleLeaderboardId__FriendsTouch = 6,
    EFortCrucibleLeaderboardId__FriendsAll = 7,
    EFortCrucibleLeaderboardId__Count = 8
};

enum EFortCrucibleLeaderboardState : uint8_t
{
    EFortCrucibleLeaderboardState__Disabled = 0,
    EFortCrucibleLeaderboardState__ReadyForQuery = 1,
    EFortCrucibleLeaderboardState__WaitingForQueryResults = 2,
    EFortCrucibleLeaderboardState__NeedsUserInfoQueried = 3,
    EFortCrucibleLeaderboardState__Complete = 4
};

enum EEQSActorSpawnerTriggerType : uint8_t
{
    EEQSActorSpawnerTriggerType__Manual = 0,
    EEQSz________R____bK____bl_VA_Jb____x_____ = 1
};

enum EEQSActorSpawnerStopSpawningReason : uint8_t
{
    EEQSActorSpawnerStopSpawningReason__Success = 0,
    EEQSActorSpawnerStopSpawningReason__ManualStop = 1,
    EEQSActorSpawnerStopSpawningReason__Requeued = 2,
    EEQSActorSpawnerStopSpawningReason__RanOutOfRetries = 3
};

enum EAthenaMutatorEvaluators : uint8_t
{
    EAthenaMutatorEvaluators__NoOverride = 0,
    EAthenaMutatorEvaluators__ForceOverride = 1,
    EAthenaMutatorEvaluators__Add = 2,
    EAthenaMutatorEvaluators__Multiply = 3
};

enum EHeistExitCraftState : uint8_t
{
    EHeistExitCraftState__None = 0,
    EHeistExitCraftState__Incoming = 1,
    EHeistExitCraftState__Spawned = 2,
    EHeistExitCraftState__Exited = 3
};

enum EFortReticleVisibiltyOption : uint8_t
{
    EFortReticleVisibiltyOption__DoNotOverride = 0,
    EFortReticleVisibiltyOption__ShowAlways = 1,
    EFortReticleVisibiltyOption__ShowPickaxeOnly = 2,
    EFortReticleVisibiltyOption__ShowNonPickaxeOnly = 3,
    EFortReticleVisibiltyOption__HideAlways = 4
};

enum EFortHUDElementVisibiltyPriority : uint8_t
{
    EFortHUDElementVisibiltyPriority__Lowest = 0,
    EFortHUDElementVisibiltyPriority__VeryLow = 1,
    EFortHUDElementVisibiltyPriority__Low = 2,
    EFortHUDElementVisibiltyPriority__Normal = 3,
    EFortHUDElementVisibiltyPriority__High = 4,
    EFortHUDElementVisibiltyPriority__VeryHigh = 5,
    EFortHUDElementVisibiltyPriority__Highest = 6,
    EFortHUDElementVisibiltyPriority__COUNT = 7
};

enum EAthenaLootDropOverride : uint8_t
{
    EAthenaLootDropOverride__NoOverride = 0,
    EAthenaLootDropOverride__ForceDrop = 1,
    EAthenaLootDropOverride__ForceKeep = 2,
    EAthenaLootDropOverride__ForceDestroy = 3,
    EAthenaLootDropOverride__ForceDropUnlessRespawning = 4,
    EAthenaLootDropOverride__ForceDestroyUnlessRespawning = 5,
    EAthenaLootDropOverride__DropUnlessTeamSelectionUpdated = 6
};

enum EAthenaInventorySpawnOverride : uint8_t
{
    EAthenaInventorySpawnOverride__NoOverride = 0,
    EAthenaInventorySpawnOverride__Always = 1,
    EAthenaInventorySpawnOverride__IntialSpawn = 2,
    EAthenaInventorySpawnOverride__AircraftPhaseOnly = 3,
    EAthenaInventorySpawnOverride__AfterWarmup = 4
};

enum ECustomLootSelection : uint8_t
{
    ECustomLootSelection__Defaul_ = 0,
    ECustomLootSelection__SolidGold = 1
};

enum EMashAISpecialEncounterType : uint8_t
{
    EMashAISpecialEncounterType__Boss = 0,
    EMashAISpecialEncounterType__UniqueAISpawn = 1
};

enum EMashScoreEvent : uint8_t
{
    EMashScoreEvent__FiendKill = 0,
    EMashScoreEvent__BruteKill = 1,
    EMashScoreEvent__RangedKill = 2,
    EMashScoreEvent__ExplodingKill = 3,
    EMashScoreEvent__ChillKill = 4,
    EMashScoreEvent__PoisonKill = 5,
    EMashScoreEvent__GoldKill = 6,
    EMashScoreEvent__RiftDestroyed = 7,
    EMashScoreEvent__ScoreMultiplierUsed = 8,
    EMashScoreEvent__HeadshotKill = 9,
    EMashScoreEvent__RespawnPenalty = 10,
    EMashScoreEvent__AmmoBoxOpened = 11,
    EMashScoreEvent__ChestOpened = 12,
    EMashScoreEvent__BossKill = 13,
    EMashScoreEvent__FinalBossKill = 14,
    EMashScoreEvent__SafeDetonationDistanceKill = 15,
    EMashScoreEvent__SpecialEncounterKill = 16
};

enum EMatchConditionMutatorTeamStatus : uint8_t
{
    EMatchConditionMutatorTeamStatus__None = 0,
    EMatchConditionMutatorTeamStatus__Won = 1,
    EMatchConditionMutatorTeamStatus__Lost = 2,
    EMatchConditionMutatorTeamStatus__Placed = 3
};

enum EIndicatorDisplayMode : uint8_t
{
    EIndicatorDisplayMode__Default = 0,
    EIndicatorDisplayMode__Always = 1,
    EIndicatorDisplayMode__Never = 2,
    EIndicatorDisplayMode__MiniMap = 3,
    EIndicatorDisplayMode__Custom = 4
};

enum EVoiceIndicatorOnNameplateDisplayMode : uint8_t
{
    EVoiceIndicatorOnNameplateDisplayMode__Default = 0,
    EVoiceIndicatorOnNameplateDisplayMode__Team = 1,
    EVoiceIndicatorOnNameplateDisplayMode__Hostiles = 2,
    EVoiceIndicatorOnNameplateDisplayMode__All = 3,
    EVoiceIndicatorOnNameplateDisplayMode__Disable = 4
};

enum EHarvestStyleOverride : uint8_t
{
    EHarvestStyleOverride__None = 0,
    EHarvestStyleOverride__Creative = 1,
    EHarvestStyleOverride__BattleRoyale = 2,
    EHarvestStyleOverride__SaveTheWorld = 3
};

enum EGravityPresetOverride : uint8_t
{
    EGravityPresetOverride__Normal = 0,
    EGravityPresetOverride__Low = 1,
    EGravityPresetOverride__VeryLow = 2,
    EGravityPresetOverride__High = 3,
    EGravityPresetOverride__VeryHigh = 4
};

enum EFlightSpeedPresetOverride : uint8_t
{
    EFlightSpeedPresetOverride__FlightSpeed0 = 0,
    EFlightSpeedPresetOverride__FlightSpeed1 = 1,
    EFlightSpeedPresetOverride__FlightSpeed2 = 2,
    EFlightSpeedPresetOverride__FlightSpeed3 = 3,
    EFlightSpeedPresetOverride__FlightSpeed4 = 4,
    EFlightSpeedPresetOverride__FlightSpeed5 = 5,
    EFlightSpeedPresetOverride__FlightSpeed6 = 6
};

enum ESelfDamageWeaponTypePreset : uint8_t
{
    ESelfDamageWeaponTypePreset__PickaxeOnly = 0,
    ESelfDamageWeaponTypePreset__MeleeOnly = 1,
    ESelfDamageWeaponTypePreset__RangedOnly = 2,
    ESelfDamageWeaponTypePreset__All = 3
};

enum EAthenaTODPostProcessOverride : uint8_t
{
    EAthenaTODPostProcessOverride__NoOverride = 0,
    EAthenaTODPostProcessOverride__PostProcess0 = 1,
    EAthenaTODPostProcessOverride__PostProcess1 = 2,
    EAthenaTODPostProcessOverride__PostProcess2 = 3,
    EAthenaTODPostProcessOverride__PostProcess3 = 4,
    EAthenaTODPostProcessOverride__PostProcess4 = 5,
    EAthenaTODPostProcessOverride__PostProcess5 = 6,
    EAthenaTODPostProcessOverride__PostProcess6 = 7,
    EAthenaTODPostProcessOverride__PostProcess7 = 8,
    EAthenaTODPostProcessOverride__PostProcess8 = 9,
    EAthenaTODPostProcessOverride__PostProcess9 = 10,
    EAthenaTODPostProcessOverride__PostProcess10 = 11,
    EAthenaTODPostProcessOverride__PostProcess11 = 12,
    EAthenaTODPostProcessOverride__PostProcess12 = 13,
    EAthenaTODPostProcessOverride__PostProcess13 = 14,
    EAthenaTODPostProcessOverride__PostProcess14 = 15,
    EAthenaTODPostProcessOverride__PostProcess15 = 16
};

enum ERespawnAndSpectateServerPayloadId : uint8_t
{
    ERespawnAndSpectateServerPayloadId__SpectateTargetSelected = 0,
    ERespawnAndSpectateServerPayloadId__RespawnTargetSelected = 1,
    ERespawnAndSpectateServerPayloadId__SpectateAndRespawnTargetSelected = 2
};

enum EShowPlacardPhase : uint8_t
{
    EShowPlacardPhase__None = 0,
    EShowPlacardPhase__StartShow = 1,
    EShowPlacardPhase__WaitBeforeInitialFadeOut = 2,
    EShowPlacardPhase__PreShowFadeOut = 3,
    EShowPlacardPhase__Show = 4,
    EShowPlacardPhase__FadeOut = 5,
    EShowPlacardPhase__PostShowFadeIn = 6,
    EShowPlacardPhase__DoneShowingScreen = 7
};

enum EAthenaLightIntensityOverride : uint8_t
{
    EAthenaLightIntensityOverride__NoOverride = 0,
    EAthenaLightIntensityOverride__Intensity0 = 1,
    EAthenaLightIntensityOverride__Intensity1 = 2,
    EAthenaLightIntensityOverride__Intensity2 = 3,
    EAthenaLightIntensityOverride__Intensity3 = 4,
    EAthenaLightIntensityOverride__Intensity4 = 5,
    EAthenaLightIntensityOverride__Intensity5 = 6,
    EAthenaLightIntensityOverride__Intensity6 = 7,
    EAthenaLightIntensityOverride__Intensity7 = 8,
    EAthenaLightIntensityOverride__Intensity8 = 9,
    EAthenaLightIntensityOverride__Intensity9 = 10,
    EAthenaLightIntensityOverride__Intensity10 = 11
};

enum EAthenaFogDensityOverride : uint8_t
{
    EAthenaFogDensityOverride__NoOverride = 0,
    EAthenaFogDensityOverride__Fog0 = 1,
    EAthenaFogDensityOverride__Fog1 = 2,
    EAthenaFogDensityOverride__Fog2 = 3,
    EAthenaFogDensityOverride__Fog3 = 4,
    EAthenaFogDensityOverride__Fog4 = 5,
    EAthenaFogDensityOverride__Fog5 = 6,
    EAthenaFogDensityOverride__Fog6 = 7,
    EAthenaFogDensityOverride__Fog7 = 8,
    EAthenaFogDensityOverride__Fog8 = 9,
    EAthenaFogDensityOverride__Fog9 = 10,
    EAthenaFogDensityOverride__Fog10 = 11
};

enum EAthenaTODColor : uint8_t
{
    EAthenaTODColor__NoOverride = 0,
    EAthenaTODColor__Black = 1,
    EAthenaTODColor__White = 2,
    EAthenaTODColor__Red = 3,
    EAthenaTODColor__Green = 4,
    EAthenaTODColor__Blue = 5,
    EAthenaTODColor__Yellow = 6,
    EAthenaTODColor__Magenta = 7,
    EAthenaTODColor__Cyan = 8
};

enum EUraniumGameEndedReason : uint8_t
{
    EUraniumGameEndedReason__GameIsStillInProgress = 0,
    EUraniumGameEndedReason__AllRoundsPlayed = 1,
    EUraniumGameEndedReason__EarlyGameEnd_BlowOut = 2,
    EUraniumGameEndedReason__EarlyGameEnd_OutNumbered = 3
};

enum EFortAthenaMutator_VoiceChatChannelType : uint8_t
{
    EFortAthenaMutator_VoiceChatChannelType__Default = 0,
    EFortAthenaMutator_VoiceChatChannelType__None = 1,
    EFortAthenaMutator_VoiceChatChannelType__SquadOnly = 2,
    EFortAthenaMutator_VoiceChatChannelType__TeamOnly = 3,
    EFortAthenaMutator_VoiceChatChannelType__WholeServer = 4,
    EFortAthenaMutator_VoiceChatChannelType__ScopeOnly = 5,
    EFortAthenaMutator_VoiceChatChannelType__ScopeSquadOnly = 6,
    EFortAthenaMutator_VoiceChatChannelType__ScopeTeamOnly = 7
};

enum EWaxMinimapDrawMode : uint8_t
{
    EWaxMinimapDrawMode__NoDrawing = 0,
    EWaxMinimapDrawMode__DrawCloseAndMoveOrShoot = 1,
    EWaxMinimapDrawMode__DrawMoveOrShoot = 2,
    EWaxMinimapDrawMode__DrawAlways = 3
};

enum EWaxState : uint8_t
{
    EWaxState__None = 0,
    EWaxState__SomewhatVisible = 1,
    EWaxState__ModeratelyVisible = 2,
    EWaxState__VeryVisible = 3,
    EWaxState__Undeniable = 4
};

enum ESpecialRelevancyMode : uint8_t
{
    ESpecialRelevancyMode__NormalRelevancy = 0,
    ESpecialRelevancyMode__SoloRelevancy = 1,
    ESpecialRelevancyMode__SquadRelevancy = 2,
    ESpecialRelevancyMode__MultiSquad = 3,
    ES______j_dz_________5_r_____ = 4
};

enum EPlateHawkInputEvents : uint8_t
{
    EPlateHawkInputEvents__PrimaryFire = 0,
    EPlateHawkInputEvents__SecondaryFire = 1,
    EPlateHawkInputEvents__Sprint = 2,
    EPlateHawkInputEvents__Reload = 3
};

enum EBuildingTickReason : uint8_t
{
    EBuildingTickReason__Dynamic = 0,
    EBuildingTickReason__Damaged = 1,
    EBuildingTickReason__GameplayCue_Damage = 2,
    EBuildingTickReason__GameplayCue_Healing = 3
};

enum EBuildingAttachmentSlot : uint8_t
{
    SLOT_Floor = 0,
    SLOT_Wall = 1,
    SLOT_Ceiling = 2,
    SLOT_None = 3
};

enum ECalendarDrivenState : uint8_t
{
    ECalendarDrivenState__ForceEnable = 0,
    ECalendarDrivenState__ForceDisable = 1
};

enum EBuildingFoundationType : uint8_t
{
    BFT_3x3 = 0,
    BFT_5x5 = 1,
    BFT_5x10 = 2,
    BFT_None = 3
};

enum EDynamicFoundationType : uint8_t
{
    EDynamicFoundationType__Static = 0,
    EDynamicFoundationType__StartEnabled_Stationary = 1,
    EDynamicFoundationType__StartEnabled_Dynamic = 2,
    EDynamicFoundationType__StartDisabled = 3
};

enum ESpawnMachineState : uint8_t
{
    ESpawnMachineState__Default = 0,
    ESpawnMachineState__WaitingForUse = 1,
    ESpawnMachineState__BeingUsed = 2,
    ESpawnMachineState__Active = 3,
    ESpawnMachineState__Complete = 4,
    ESpawnMachineState__OnCooldown = 5
};

enum ESpawnMachineSubTextState : uint8_t
{
    ESpawnMachineSubTextState__NoCards = 0,
    ESpawnMachineSubTextState__VanInUse = 1,
    ESpawnMachineSubTextState__TeamOnOtherVan = 2,
    ESpawnMachineSubTextState__None = 3,
    ESpawnMachineSubTextState__HasResource = 4,
    ESpawnMachineSubTextState__NoResource = 5,
    ESpawnMachineSubTextState__NotEnabledForPlayer = 6
};

enum EFortItemCollectorState : uint8_t
{
    EFortItemCollectorState__CanInteract = 0,
    EFortItemCollectorState__Active = 1,
    EFortItemCollectorState__Inactive = 2,
    EFortItemCollectorState__Captured = 3,
    EFortItemCollectorState__Invalid = 4
};

enum EFortItemCollectorTrackingType : uint8_t
{
    EFortItemCollectorTrackingType__Player = 0,
    EFortItemCollectorTrackingType__Team = 1
};

enum EMusicTrackPlayback : uint8_t
{
    EMusicTrackPlayback__Disabled = 0,
    EMusicTrackPlayback__Enabled = 1
};

enum EPlayerCaptureKnobOptions : uint8_t
{
    EPlayerCaptureKnobOptions__Off = 0,
    EPlayerCaptureKnobOptions__EachPlayer = 1,
    EPlayerCaptureKnobOptions__OnePlayerPerTeam = 2,
    EPlayerCaptureKnobOptions__OwningTeam = 3
};

enum ECaptureAreaItemFilters : uint8_t
{
    ECaptureAreaItemFilters__None = 0,
    ECaptureAreaItemFilters__Both = 1,
    ECaptureAreaItemFilters__ForPeriodicScoring = 2,
    ECaptureAreaItemFilters__ToTakeControl = 3
};

enum ECreativeVendingMachineState : uint8_t
{
    ECreativeVendingMachineState__DisplayingItem = 0,
    ECreativeVendingMachineState__AcceptingItem = 1,
    ECreativeVendingMachineState__AcceptedItem = 2,
    ECreativeVendingMachineState__RejectedItem = 3
};

enum ERiftCosmeticState : uint8_t
{
    ERiftCosmeticState__None = 0,
    ERiftCosmeticState__Intro = 1,
    ERiftCosmeticState__Idle = 2,
    ERiftCosmeticState__RampUp = 3,
    ERiftCosmeticState__ShouldDie = 4
};

enum EBuildingAnim : uint8_t
{
    EBuildingAnim__EBA_None = 0,
    EBuildingAnim__EBA_Building = 1,
    EBuildingAnim__EBA_Breaking = 2,
    EBuildingAnim__EBA_Constructed = 3,
    EBuildingAnim__EBA_Destruction = 4,
    EBuildingAnim__EBA_Placement = 5,
    EBuildingAnim__EBA_DynamicLOD = 6,
    EBuildingAnim__EBA_DynamicShrink = 7
};

enum EBuildingNavObstacleType : uint8_t
{
    EBuildingNavObstacleType__UnwalkableAll = 0,
    EBuildingNavObstacleType__UnwalkableHuskOnly = 1,
    EBuildingNavObstacleType__SmashWhenLowHeight = 2,
    EBuildingNavObstacleType__SmashOnlyLowHeight = 3,
    EBuildingNavObstacleType__SmashSmasherOnly = 4,
    EBuildingNavObstacleType__SmashAll = 5
};

enum EFortTextureDataType : uint8_t
{
    EFortTextureDataType__Any = 0,
    EFortTextureDataType__OuterWall = 1,
    EFortTextureDataType__InnerWall = 2,
    EFortTextureDataType__Corner = 3,
    EFortTextureDataType__Floor = 4,
    EFortTextureDataType__Ceiling = 5,
    EFortTextureDataType__Trim = 6,
    EFortTextureDataType__Roof = 7,
    EFortTextureDataType__Pillar = 8,
    EFortTextureDataType__Shingle = 9,
    EFortTextureDataType__None = 10
};

enum EFortTextureDataSlot : uint8_t
{
    EFortTextureDataSlot__Primary = 0,
    EFortTextureDataSlot__Secondary = 1,
    EFortTextureDataSlot__Tertiary = 2,
    EFortTextureDataSlot__Fourth = 3,
    EFortTextureDataSlot__NumSlots = 4
};

enum EFortStructuralGridQueryResults : uint8_t
{
    EFortStructuralGridQueryResults__CanAdd = 0,
    EFortStructuralGridQueryResults__ExistingActor = 1,
    EFortStructuralGridQueryResults__Obstructed = 2,
    EFortStructuralGridQueryResults__NoStructuralSupport = 3,
    EFortStructuralGridQueryResults__InvalidActor = 4,
    EFortStructuralGridQueryResults__ReachedLimit = 5,
    EFortStructuralGridQueryResults__NoEditPermission = 6,
    EFortStructuralGridQueryResults__PatternNotPermittedByLayoutRequirement = 7,
    EFortStructuralGridQueryResults__ResourceTypeNotPermittedByLayoutRequirement = 8,
    EFortStructuralGridQueryResults__BuildingAtRequirementsDisabled = 9,
    EFortStructuralGridQueryResults__BuildingOtherThanRequirementsDisabled = 10
};

enum EFortDecoPlacementQueryResults : uint8_t
{
    EFortDecoPlacementQueryResults__CanAdd = 0,
    EFortDecoPlacementQueryResults__ExistingTrap = 1,
    EFortDecoPlacementQueryResults__ExistingObject = 2,
    EFortDecoPlacementQueryResults__Obstructed = 3,
    EFortDecoPlacementQueryResults__NoLocation = 4,
    EFortDecoPlacementQueryResults__WrongType = 5,
    EFortDecoPlacementQueryResults__WrongShape = 6,
    EFortDecoPlacementQueryResults__BeingModified = 7,
    EFortDecoPlacementQueryResults__WrongTeam = 8,
    EFortDecoPlacementQueryResults__BlueprintFailure = 9,
    EFortDecoPlacementQueryResults__AbilityFailure = 10,
    EFortDecoPlacementQueryResults__RequiresPlayerBuildableActor = 11,
    EFortDecoPlacementQueryResults__NoEditPermission = 12,
    EFortDecoPlacementQueryResults__WrongZone = 13
};

enum EFortConnectivityCubeFace : uint8_t
{
    EFortConnectivityCubeFace__Front = 0,
    EFortConnectivityCubeFace__Left = 1,
    EFortConnectivityCubeFace__Back = 2,
    EFortConnectivityCubeFace__Right = 3,
    EFortConnectivityCubeFace__Upper = 4,
    EFortConnectivityCubeFace__Lower = 5
};

enum EFortBuildingDestroyedReason : uint8_t
{
    EFortBuildingDestroyedReason__Unknown = 0,
    EFortBuildingDestroyedReason__WeaponDamage = 1,
    EFortBuildingDestroyedReason__LostSupport = 2,
    EFortBuildingDestroyedReason__Edit = 3,
    EFortBuildingDestroyedReason__FireDirect = 4,
    EFortBuildingDestroyedReason__FireIndirect = 5
};

enum EDoorOpenStyle : uint8_t
{
    EDoorOpenStyle__Open = 0,
    EDoorOpenStyle__SlamOpen = 1,
    EDoorOpenStyle__SmashOpen = 2,
    EDoorOpenStyle__Close = 3
};

enum EDeployableBaseBoxType : uint8_t
{
    EDeployableBaseBoxType__BuildSpace = 0,
    EDeployableBaseBoxType__SaveSpace = 1,
    EDeployableBaseBoxType__PlotSpace = 2,
    EDeployableBaseBoxType__NumSpaceTypes = 3
};

enum EDeployableBaseBuildingState : uint8_t
{
    EDeployableBaseBuildingState__Empty = 0,
    EDeployableBaseBuildingState__Built = 1,
    EDeployableBaseBuildingState__Unoccupied = 2,
    EDeployableBaseBuildingState__WaitingToBuild = 3,
    EDeployableBaseBuildingState__Building = 4,
    EDeployableBaseBuildingState__WaitingToDestroy = 5,
    EDeployableBaseBuildingState__Destroying = 6,
    EDeployableBaseBuildingState__WaitingToReset = 7,
    EDeployableBaseBuildingState__Resetting = 8
};

enum FDynamicBuildOrder : uint8_t
{
    FDynamicBuildOrder__X = 0,
    FDynamicBuildOrder__Y = 1,
    FDynamicBuildOrder__Z = 2,
    FDynamicBuildOrder__None = 3
};

enum EFloorPatternType : uint8_t
{
    EFloorPatternType__None = 0,
    EFloorPatternType__DefaultPiece = 1,
    EFloorPatternType__LPiece = 2,
    EFloorPatternType__HalfPiece = 3,
    EFloorPatternType__DiagonalPiece = 4,
    EFloorPatternType__CornerPiece = 5
};

enum EAuxIndicatorStates : uint8_t
{
    AIS_GuidingArrow = 0,
    AIS_ConfirmedArrow = 1,
    AIS_Inactive = 2,
    AIS_Active = 3
};

enum EGravityGunHolderState : uint8_t
{
    EGravityGunHolderState__Invalid = 0,
    EGravityGunHolderState__Unrooting = 1,
    EGravityGunHolderState__Catching = 2,
    EGravityGunHolderState__Holding = 3,
    EGravityGunHolderState__Detached = 4
};

enum EGravityGunHolderObjectType : uint8_t
{
    EGravityGunHolderObjectType__Invalid = 0,
    EGravityGunHolderObjectType__PhysicsObject = 1,
    EGravityGunHolderObjectType__Vehicle = 2,
    EGravityGunHolderObjectType__Projectile = 3,
    EGravityGunHolderObjectType__PickUp = 4
};

enum EStructuralWallPosition : uint8_t
{
    EStructuralWallPosition__Left = 0,
    EStructuralWallPosition__Right = 1,
    EStructuralWallPosition__Front = 2,
    EStructuralWallPosition__Back = 3
};

enum EModifierPriority : uint8_t
{
    EModifierPriority__Min = 0,
    EModifierPriority__VeryLow = 1,
    EModifierPriority__Low = 2,
    EModifierPriority__Default = 3,
    EModifierPriority__High = 4,
    EModifierPriority__VeryHigh = 5,
    EModifierPriority__Max = 6
};

enum ESineWaveTarget : uint8_t
{
    ESineWaveTarget__TranslationX = 0,
    ESineWaveTarget__TranslationY = 1,
    ESineWaveTarget__TranslationZ = 2,
    ESineWaveTarget__RotationPitch = 3,
    ESineWaveTarget__RotationRoll = 4,
    ESineWaveTarget__RotationYaw = 5
};

enum EBlendState : uint8_t
{
    EBlendState__Out = 0,
    EBlendState__BlendingIn = 1,
    EBlendState__In = 2,
    EBlendState__BlendingOut = 3
};

enum EFortCameraAxisConstraintRule : uint8_t
{
    EFortCameraAxisConstraintRule__None = 0,
    EFortCameraAxisConstraintRule__LockedTo = 1,
    EFortCameraAxisConstraintRule__LessThan = 2,
    EFortCameraAxisConstraintRule__GreaterThan = 3
};

enum EChallengeBundleQuestUnlockType : uint8_t
{
    EChallengeBundleQuestUnlockType__Manually = 0,
    EChallengeBundleQuestUnlockType__GrantWithBundle = 1,
    EChallengeBundleQuestUnlockType__RequiresBattlePass = 2,
    EChallengeBundleQuestUnlockType__DaysFromEventStart = 3,
    EChallengeBundleQuestUnlockType__ChallengesCompletedToUnlock = 4,
    EChallengeBundleQuestUnlockType__BundleLevelup = 5
};

enum ECreativeBotIslandLoadingState : uint8_t
{
    ECreativeBotIslandLoadingState__ILS_NONE = 0,
    ECreativeBotIslandLoadingState__ILS_LoadNotStarted = 1,
    ECreativeBotIslandLoadingState__ILS_GrantPlotItem = 2,
    ECreativeBotIslandLoadingState__ILS_WaitingUserPlotReady = 3,
    ECreativeBotIslandLoadingState__ILS_LoadInProgress = 4,
    ECreativeBotIslandLoadingState__ILS_LoadComplete = 5,
    ECreativeBotIslandLoadingState__ILS_Teleporting = 6,
    ECreativeBotIslandLoadingState__ILS_Returning = 7,
    ECreativeBotIslandLoadingState__ILS_Items = 8
};

enum ECreativeBotItemTestingState : uint8_t
{
    ECreativeBotItemTestingState__ITS_NONE = 0,
    ECreativeBotItemTestingState__ITS_Teleporting = 1,
    ECreativeBotItemTestingState__ITS_Landing = 2,
    ECreativeBotItemTestingState__ITS_Grant = 3,
    ECreativeBotItemTestingState__ITS_Equip = 4,
    ECreativeBotItemTestingState__ITS_Place = 5,
    ECreativeBotItemTestingState__ITS_Cleanup = 6
};

enum EInteractProgressDecay : uint8_t
{
    EInteractProgressDecay__EInteractDecay_Multi = 0,
    EInteractProgressDecay__EInteractDecay_Reset = 1,
    EInteractProgressDecay__EInteractDecay_Pause = 2,
    EInteractProgressDecay__EInteractDecay_BR = 3
};

enum EContextualContext : uint8_t
{
    EContextualContext__DoNotShow = 0,
    EContextualContext__BusPhase = 1,
    EContextualContext__Skydiving = 2,
    EContextualContext__Gameplay = 3
};

enum EContextualEvent : uint8_t
{
    EContextualEvent__Generic = 0,
    EContextualEvent__Location = 1,
    EContextualEvent__InventoryAdded = 2,
    EContextualEvent__InventoryRemoved = 3,
    EContextualEvent__StartSkydiving = 4,
    EContextualEvent__NewQuests = 5
};

enum EIndicatorStateImage : uint8_t
{
    EIndicatorStateImage__FIRST_FRIENDLY_STATE = 0,
    EIndicatorStateImage__Default = 0,
    EIndicatorStateImage__InCombat = 1,
    EIndicatorStateImage__DBNO = 2,
    EIndicatorStateImage__BeingRevived = 3,
    EIndicatorStateImage__Dead = 4,
    EIndicatorStateImage__LAST_FRIENDLY_STATE = 4,
    EIndicatorStateImage__FIRST_CHAT_MESSAGE = 5,
    EIndicatorStateImage__NeedAmmoHeavy = 5,
    EIndicatorStateImage__NeedAmmoLight = 6,
    EIndicatorStateImage__NeedAmmoMedium = 7,
    EIndicatorStateImage__NeedAmmoShells = 8,
    EIndicatorStateImage__NeedAmmoRocket = 9,
    EIndicatorStateImage__ChatBubble = 10,
    EIndicatorStateImage__EnemySpotted = 11,
    EIndicatorStateImage__NeedBandages = 12,
    EIndicatorStateImage__NeedMaterials = 13,
    EIndicatorStateImage__NeedShields = 14,
    EIndicatorStateImage__NeedWeapon = 15,
    EIndicatorStateImage__ThankYou = 16,
    EIndicatorStateImage__LAST_CHAT_MESSAGE = 16,
    EIndicatorStateImage__FIRST_MATE_STATE = 17,
    EIndicatorStateImage__Squadmate = 17,
    EIndicatorStateImage__Teammate = 18,
    EIndicatorStateImage__LAST_MATE_STATE = 18,
    EIndicatorStateImage__FIRST_ENEMY_STATE = 19,
    EIndicatorStateImage__Enemy = 19,
    EIndicatorStateImage__LAST_ENEMY_STATE = 19,
    EIndicatorStateImage__FIRST_NPC_STATE = 20,
    EIndicatorStateImage__FriendlyNPC = 20,
    EIndicatorStateImage__EnemyNPC = 21,
    EIndicatorStateImage__EliteFriendlyNPC = 22,
    EIndicatorStateImage__EliteEnemyNPC = 23,
    EIndicatorStateImage__LAST_NPC_STATE = 23,
    EIndicatorStateImage__FIRST_WORLDITEM_STATE = 24,
    EIndicatorStateImage__Interactable = 24,
    EIndicatorStateImage__InteractableLarge = 25,
    EIndicatorStateImage__GameplayItem = 26,
    EIndicatorStateImage__TreasureChest = 27,
    EIndicatorStateImage__LAST_WORLDITEM_STATE = 27,
    EIndicatorStateImage__FIRST_HARDCORE_S____ = 28,
    EIndicatorStateImage__HardCoreBeacon = 28,
    EIndicatorStateImage__LAST_HARDCORE_STATE = 28,
    EIndicatorStateImage__LAST_STATE = 28,
    EIndicatorStateImage__None = 29
};

enum EShareActorWithMask : uint8_t
{
    EShareActorWithMask__None = 0,
    EShareActorWithMask__SquadOnTeam = 1,
    EShareActorWithMask__AllTeam = 2,
    EShareActorWithMask__Target = 4
};

enum EMinigameActivityStat : uint8_t
{
    EMinigameActivityStat__Score = 0,
    EMinigameActivityStat__Time = 1,
    EMinigameActivityStat__Distance = 2,
    EMinigameActivityStat__RaceProgress = 3,
    EMinigameActivityStat__CurrentLap = 4,
    EMinigameActivityStat__MaxLaps = 5,
    EMinigameActivityStat__BestLapTime = 6,
    EMinigameActivityStat__COUNT = 7
};

enum ESpectatorMode : uint8_t
{
    ESpectatorMode__None = 0,
    ESpectatorMode__FreeCamera = 1,
    ESpectatorMode__DeviceCamera = 2,
    ESpectatorMode__DeadLocation = 3,
    ESpectatorMode__PawnWithLocalRotation = 4,
    ESpectatorMode__Pawn = 5
};

enum EFortEntitlementState : uint8_t
{
    EFortEntitlementState__NotRequested = 0,
    EFortEntitlementState__Requesting = 1,
    EFortEntitlementState__RequestError = 2,
    EFortEntitlementState__NotGranted = 3,
    EFortEntitlementState__Granted = 4,
    EFortEntitlementState__DevGranted = 5
};

enum EFortFootstepPlayerRelation : uint8_t
{
    EFortFootstepPlayerRelation__LocalPlayer = 0,
    EFortFootstepPlayerRelation__Friendly = 1,
    EFortFootstepPlayerRelation__Enemy = 2,
    EFortFootstepPlayerRelation__Max_None = 3
};

enum EFortFootstepStanceType : uint8_t
{
    EFortFootstepStanceType__Walk = 0,
    EFortFootstepStanceType__Run = 1,
    EFortFootstepStanceType__Sprint = 2,
    EFortFootstepStanceType__CrouchWalk = 3,
    EFortFootstepStanceType__CrouchRun = 4,
    EFortFootstepStanceType__Max_None = 5
};

enum EFortFootstepVerticalPosition : uint8_t
{
    EFortFootstepVerticalPosition__Parallel = 0,
    EFortFootstepVerticalPosition__Above = 1,
    EFortFootstepVerticalPosition__Below = 2,
    EFortFootstepVerticalPosition__Max_None = 3
};

enum EFortFootstepSurface : uint8_t
{
    EFortFootstepSurface__Dirt = 0,
    EFortFootstepSurface__Grass = 1,
    EFortFootstepSurface__Metal = 2,
    EFortFootstepSurface__Sand = 3,
    EFortFootstepSurface__Snow = 4,
    EFortFootstepSurface__Ice = 5,
    EFortFootstepSurface__Stone = 6,
    EFortFootstepSurface__Water = 7,
    EFortFootstepSurface__Wood = 8,
    EFortFootstepSurface__Chrome = 9,
    EFortFootstepSurface__ChromePetrified = 10,
    EFortFootstepSurface__Mud = 11,
    EFortFootstepSurface__WetConcrete = 12,
    EFortFootstepSurface__TreeCanopy = 13,
    EFortFootstepSurface__Max_None = 14
};

enum EUnableToLoadReason : uint8_t
{
    EUnableToLoadReason__None = 0,
    EUnableToLoadReason__PackageDoesNotExist = 1,
    EUnableToLoadReason__EndPlay = 2,
    EUnableToLoadReason__UnableToUnload = 3
};

enum EAIPingCommandType : uint8_t
{
    EAIPingCommandType__None = 0,
    EAIPingCommandType__PingGoTo = 1,
    EAIPingCommandType__PingHoldPosition = 2,
    EAIPingCommandType__PingBackToMe = 3
};

enum EUpdateCustomDepthOptimDirtyFlags : uint8_t
{
    EUpdateCustomDepthOptimDirtyFlags__None = 0,
    EUpdateCustomDepthOptimDirtyFlags__CharacterParts = 1,
    EUpdateCustomDepthOptimDirtyFlags__Weapon = 2,
    EUpdateCustomDepthOptimDirtyFlags__PossessedProp = 4
};

enum EFortPawnComponent_DisguiseRevealReason : uint8_t
{
    EFortPawnComponent_DisguiseRevealReason__ByDamage = 0,
    EFortPawnComponent_DisguiseRevealReason__ByConversation = 1,
    EFortPawnComponent_DisguiseRevealReason__ByProximity = 2,
    EFortPawnComponent_DisguiseRevealReason__Unknown = 3
};

enum EFortSnapOnSurfaceBehavior : uint8_t
{
    EFortSnapOnSurfaceBehavior__None = 0,
    EFortSnapOnSurfaceBehavior__Landscape = 1,
    EFortSnapOnSurfaceBehavior__Navmesh = 2,
    EFortSnapOnSurfaceBehavior__Trace = 3,
    EFortSnapOnSurfaceBehavior__AttachTo = 4,
    EFortSnapOnSurfaceBehavior__SphereTrace = 5
};

enum EPreventAbilityUseReason : uint8_t
{
    EPreventAbilityUseReason__CannotAfford = 0,
    EPreventAbilityUseReason__AlreadyActive = 1,
    EPreventAbilityUseReason__AbilityActivationBlocked = 2,
    EPreventAbilityUseReason__None = 3,
    EPreventAbilityUseReason__Count = 4
};

enum EPreventUseStormCircleServiceReason : uint8_t
{
    EPreventUseStormCircleServiceReason__CannotAfford = 0,
    EPreventUs____Q____W_____R_____u__m__G________L___ = 1,
    EPreventUseStormCircleServiceReason__StormLocationsAlreadyRevealed = 2,
    EPreventUseStormCircleServiceReason__None = 3
};

enum EPreventSupplyDropUseReason : uint8_t
{
    EPreventSupplyDropUseReason__CannotAfford = 0,
    EPreventSupplyDropUseReason__OutOfStock = 1,
    EPreventSupplyDropUseReason__None = 2,
    EPreventSupplyDropUseReason__Count = 3
};

enum EFortDebugInfoCategory : uint8_t
{
    EFortDebugInfoCategory__Info = 0,
    EFortDebugInfoCategory__Positive = 1,
    EFortDebugInfoCategory__Negative = 2,
    EFortDebugInfoCategory__Warning = 3,
    EFortDebugInfoCategory__Deemphasize = 4
};

enum EThresholdRequirement : uint8_t
{
    EThresholdRequirement__LessThan = 0,
    EThresholdRequirement__LessThanOrEqual = 1,
    EThresholdRequirement__Equal = 2,
    EThresholdRequirement__GreaterThan = 3,
    EThresholdRequirement__GreaterThanOrEqual = 4
};

enum EFortBadMatchTriggerOperation : uint8_t
{
    EFortBadMatchTriggerOperation__LessThan = 0,
    EFortBadMatchTriggerOperation__LessThanOrEqual = 1,
    EFortBadMatchTriggerOperation__Equal = 2,
    EFortBadMatchTriggerOperation__GreaterThan = 3,
    EFortBadMatchTriggerOperation__GreaterThanOrEqual = 4
};

enum EFortBadMatchTriggerType : uint8_t
{
    EFortBadMatchTriggerType__Unspecified = 0,
    EFortBadMatchTriggerType__SmallTeam = 1,
    EFortBadMatchTriggerType__LargeTeam = 2,
    EFortBadMatchTriggerType__LetoTeam = 3
};

enum EQualitativePerfMetricIndex : uint8_t
{
    EQualitativePerfMetricIndex__Excellent = 0,
    EQualitativePerfMetricIndex__Good = 1,
    EQualitativePerfMetricIndex__Average = 2,
    EQualitativePerfMetricIndex__Poor = 3,
    EQualitativePerfMetricIndex__Terrible = 4,
    EQualitativePerfMetricIndex__Count = 5
};

enum ECosmeticStepOrdinality : uint8_t
{
    ECosmeticStepOrdinality__PreStep = 0,
    ECosmeticStepOrdinality__Default = 1,
    ECosmeticStepOrdinality__PostStep = 2,
    ECosmeticStepOrdinality__NumPhases = 3
};

enum EFortLockerAnalyticAction : uint8_t
{
    EFortLockerAnalyticAction__Locker_SaveChanges = 0,
    EFortLockerAnalyticAction__Locker_CreateNew = 1,
    EFortLockerAnalyticAction__Locker_Clear = 2,
    EFortLockerAnalyticAction__Locker_Revert = 3,
    EFortLockerAnalyticAction__Locker_Randomize = 4,
    EFortLockerAnalyticAction__Preset_Delete = 5,
    EFortLockerAnalyticAction__Preset_ChangeActive = 6,
    EFortLockerAnalyticAction__Preset_ChangeName = 7,
    EFortLockerAnalyticAction__InGame_Warmup = 8
};

enum EMontageSelectionPredicateType : uint8_t
{
    EMontageSelectionPredicateType__NotSet = 0,
    EMontageSelectionPredicateType__MetaTags = 1,
    EMontageSelectionPredicateType__CharacterParts = 2,
    EMontageSelectionPredicateType__ActiveSwapPresence = 3,
    EMontageSelectionPredicateType__Invalid = 4
};

enum ELayeredAudioTriggerDirection : uint8_t
{
    ELayeredAudioTriggerDirection__AnyDirection = 0,
    ELayeredAudioTriggerDirection__Forwards = 1,
    ELayeredAudioTriggerDirection__Sideways = 2,
    ELayeredAudioTriggerDirection__Backwards = 3,
    ELayeredAudioTriggerDirection__Count = 4
};

enum EBannerUsageContext : uint8_t
{
    EBannerUsageContext__Unknown = 0,
    EBannerUsageContext__BannerIcon = 1,
    EBannerUsageContext__PhysicalBanner = 2,
    EBannerUsageContext__Spray = 3
};

enum EFortCosmeticHabaneroDateType : uint8_t
{
    EFortCosmeticHabaneroDateType__SingleDate = 0,
    EFortCosmeticHabaneroDateType__UpToDate = 1,
    EFortCosmeticHabaneroDateType__FromDate = 2
};

enum ECosmeticMetaTagRequirementCategory : uint8_t
{
    ECosmeticMetaTagRequirementCategory__None = 0,
    ECosmeticMetaTagRequirementCategory__Glider = 1,
    ECosmeticMetaTagRequirementCategory__Pickaxe = 2,
    ECosmeticMetaTagRequirementCategory__Backpack = 3,
    ECosmeticMetaTagRequirementCategory__Character = 4,
    ECosmeticMetaTagRequirementCategory__FullLoadout = 5
};

enum ERankedVariantRank : uint8_t
{
    ERankedVariantRank__Bronze = 0,
    ERankedVariantRank__Silver = 1,
    ERankedVariantRank__Gold = 2,
    ERankedVariantRank__Platinum = 3,
    ERankedVariantRank__Diamond = 4,
    ERankedVariantRank__Elite = 5,
    ERankedVariantRank__Champion = 6,
    ERankedVariantRank__Unreal = 7,
    ERankedVariantRank__MAX_None = 8
};

enum EFortRichColorConflictResolutionRules : uint8_t
{
    EFortRichColorConflictResolutionRules__NoConflictsAllowed = 0,
    EFortRichColorConflictResolutionRules__BlackOrWhiteCannotConflict = 1,
    EFortRichColorConflictResolutionRules__MinimumDistanceBlackOrWhite = 2,
    EFortRichColorConflictResolutionRules__MinimumContrast = 3,
    EFortRichColorConflictResolutionRules__MinimumContrastOrHueSaturationShift = 4,
    EFortRichColorConflictResolutionRules__MinimumContrastGrayscale = 5
};

enum EShowOnHudMode : uint8_t
{
    EShowOnHudMode__No = 0,
    EShowOnHudMode__Detailed = 1,
    EShowOnHudMode__List = 2,
    EShowOnHudMode__Both = 3
};

enum EFortCreativeLinearMoverCollisionBehavior : uint8_t
{
    EFortCreativeLinearMoverCollisionBehavior__EFCLMCB_None = 0,
    EFortCreativeLinearMoverCollisionBehavior__EFCLMCB_Stop = 1,
    EFortCreativeLinearMoverCollisionBehavior__EFCLMCB_Reverse = 2,
    EFortCreativeLinearMoverCollisionBehavior__EFCLMCB_Push = 3
};

enum EFortCreativeResourceNodeDepletionMode : uint8_t
{
    EFortCreativeResourceNodeDepletionMode__Destroy = 0,
    EFortCreativeResourceNodeDepletionMode__RestockOnDelay = 1,
    EFortCreativeResourceNodeDepletionMode__RestockOverTime = 2,
    EFortCreativeResourceNodeDepletionMode__StayEmpty = 3,
    EFortCreativeResourceNodeDepletionMode__None = 4
};

enum EDeviceTrackingFilterType : uint8_t
{
    EDeviceTrackingFilterType__Undefined = 0,
    EDeviceTrackingFilterType__Unfiltered = 1,
    EDeviceTrackingFilterType__WithEventsOrFunctions = 2,
    EDeviceTrackingFilterType__WithFunctions = 3,
    EDeviceTrackingFilterType__WithEvents = 4,
    EDeviceTrackingFilterType__WithOnlyFunctions = 5,
    EDeviceTrackingFilterType__WithOnlyEvents = 6,
    EDeviceTrackingFilterType__WithBindings = 7,
    EDeviceTrackingFilterType__Favorites = 8
};

enum EDeviceTrackingSortingType : uint8_t
{
    EDeviceTrackingSortingType__Undefined = 0,
    EDeviceTrackingSortingType__Default = 1,
    EDeviceTrackingSortingType__Alphabetical = 2,
    EDeviceTrackingSortingType__ReverseAlphabetical = 3,
    EDeviceTrackingSortingType__Favorites = 4,
    EDeviceTrackingSortingType__MostBindingsToLeast = 5,
    EDeviceTrackingSortingType__LeastBindingsToMost = 6
};

enum EFortCreativeDiscoveryDeterminism : uint8_t
{
    EFortCreativeDiscoveryDeterminism__Always = 0,
    EFortCreativeDiscoveryDeterminism__Random = 1,
    EFortCreativeDiscoveryDeterminism__PlayerDeterministic = 2,
    EFortCreativeDiscoveryDeterminism__PartyDeterministic = 3,
    EFortCreativeDiscoveryDeterminism__EpicEmployee = 4,
    EFortCreativeDiscoveryDeterminism__Never = 5
};

enum EFortCreativeDiscoveryPanelType : uint8_t
{
    EFortCreativeDiscoveryPanelType__CuratedList = 0,
    EFortCreativeDiscoveryPanelType__MetricDriven = 1,
    EFortCreativeDiscoveryPanelType__Recommendations = 2,
    EFortCreativeDiscoveryPanelType__PlayHistory = 3,
    EFortCreativeDiscoveryPanelType__AnalyticsList = 4,
    EFortCreativeDiscoveryPanelType__Tournaments = 5
};

enum EFortCreativeDiscoveryPlayHistoryType : uint8_t
{
    EFortCreativeDiscoveryPlayHistoryType__RecentlyPlayed = 0,
    EFortCreativeDiscoveryPlayHistoryType__Favorites = 1,
    EFortCreativeDiscoveryPlayHistoryType__RecentlyPlayedAndFavorites = 2,
    EFortCreativeDiscoveryPlayHistoryType__Queued = 3
};

enum EFortCreativeDiscoverySkippedEntries : uint8_t
{
    EFortCreativeDiscoverySkippedEntries__None = 0,
    EFortCreativeDiscoverySkippedEntries__ByCount = 1,
    EFortCreativeDiscoverySkippedEntries__ByPercent = 2
};

enum EFortLockDeviceVisibilityDuringGames : uint8_t
{
    EFortLockDeviceVisibilityDuringGames__No = 0,
    EFortLockDeviceVisibilityDuringGames__Yes = 1,
    EFortLockDeviceVisibilityDuringGames__HologramOnly = 2
};

enum ETimerDeviceState : uint8_t
{
    ETimerDeviceState__Enabled = 0,
    ETimerDeviceState__Activated = 1,
    ETimerDeviceState__Paused = 2,
    ETimerDeviceState__Completed = 3,
    ETimerDeviceState__Disabled = 4
};

enum ECreativeClassType : uint8_t
{
    ECreativeClassType__ClassSlot = 0,
    ECreat__________j__gy__N___ = 1,
    ECreativeClassType__All = 2,
    ECreativeClassType__Any = 3
};

enum EFortCreativeItemDropAmount : uint8_t
{
    EFortCreativeItemDropAmount__All = 0,
    EFortCreativeItemDropAmount__FlatAmount = 1,
    EFortCreativeItemDropAmount__Percentage = 2
};

enum ECreativeLinkPreviewSize : uint8_t
{
    ECreativeLinkPreviewSize__Small = 0,
    ECreativeLinkPreviewSize__Medium = 1,
    ECreativeLinkPreviewSize__Large = 2,
    ECreativeLinkPreviewSize__Extra_Small = 3,
    ECreativeLinkPreviewSize__NUM_SIZES = 4
};

enum EFortCreativeTeleporterGroup : uint8_t
{
    EFortCreativeTeleporterGroup__Group_A = 0,
    EFortCreativeTeleporterGroup__Group_B = 1,
    EFortCreativeTeleporterGroup__Group_C = 2,
    EFortCreativeTeleporterGroup__Group_D = 3,
    EFortCreativeTeleporterGroup__Group_E = 4,
    EFortCreativeTeleporterGroup__Group_F = 5,
    EFortCreativeTeleporterGroup__Group_G = 6,
    EFortCreativeTeleporterGroup__Group_H = 7,
    EFortCreativeTeleporterGroup__Group_I = 8,
    EFortCreativeTeleporterGroup__Group_J = 9,
    EFortCreativeTeleporterGroup__Group_K = 10,
    EFortCreativeTeleporterGroup__Group_L = 11,
    EFortCreativeTeleporterGroup__Group_M = 12,
    EFortCreativeTeleporterGroup__Group_N = 13,
    EFortCreativeTeleporterGroup__Group_O = 14,
    EFortCreativeTeleporterGroup__Group_P = 15,
    EFortCreativeTeleporterGroup__Group_Q = 16,
    EFortCreativeTeleporterGroup__Group_R = 17,
    EFortCreativeTeleporterGroup__Group_S = 18,
    EFortCreativeTeleporterGroup__Group_T = 19,
    EFortCreativeTeleporterGroup__Group_U = 20,
    EFortCreativeTeleporterGroup__Group_V = 21,
    EFortCreativeTeleporterGroup__Group_W = 22,
    EFortCreativeTeleporterGroup__Group_X = 23,
    EFortCreativeTeleporterGroup__Group_Y = 24,
    EFortCreativeTeleporterGroup__Group_Z = 25,
    EFortCreativeTeleporterGroup__Group_None = 26
};

enum EFortCreativeTeleporterEvent : uint8_t
{
    EFortCreativeTeleporterEvent__Entered = 0,
    EFortCreativeTeleporterEvent__Exited = 1,
    EFortCreativeTeleporterEvent__Enabled = 2,
    EFortCreativeTeleporterEvent__Disabled = 3,
    EFortCreativeTeleporterEvent__None = 4
};

enum EMMSRulePreset : uint8_t
{
    EMMSRulePreset__RespectParties = 0,
    EMMSRulePreset__KeepFull = 1,
    EMMSRulePreset__Off = 2
};

enum EMMSPlayersPerTeamPreset : uint8_t
{
    EMMSPlayersPerTeamPreset__Solos = 1,
    EMMSPlayersPerTeamPreset__Duos = 2,
    EMMSPlayersPerTeamPreset__Trios = 3,
    EMMSPlayersPerTeamPreset__Squads = 4,
    EMMSPlayersPerTeamPreset__Quintet = 7,
    EMMSPlayersPerTeamPreset__SplitEvenly = 5,
    EMMSPlayersPerTeamPreset__Dynamic = 6
};

enum ECreativePublishedIslandCodeDisplay : uint8_t
{
    ECreativePublishedIslandCodeDisplay__Off = 0,
    ECreativePublishedIslandCodeDisplay__ShowWit_______u_P = 1,
    ECreativePublishedIslandCodeDisplay__ShowWithoutWatermark = 2
};

enum EWidgetInterfaceTimerStatus : uint8_t
{
    EWidgetInterfaceTimerStatus__None = 0,
    EWidgetInterfaceTimerStatus__Active = 1,
    EWidgetInterfaceTimerStatus__Paused = 2,
    EWidgetInterfaceTimerStatus__Inactive = 3
};

enum EFortCurieNativeFXType : uint8_t
{
    EFortCurieNativeFXType__None = 0,
    EFortCurieNativeFXType__Electricity = 1,
    EFortCurieNativeFXType__Fire = 2,
    EFortCurieNativeFXType__Charred = 4,
    EFortCurieNativeFXType__Max = 8
};

enum EFortCurieApplicationEvent : uint8_t
{
    EFortCurieApplicationEvent__OnHit = 0,
    EFortCurieApplicationEvent__OnBeginOverlap = 1,
    EFortCurieApplicationEvent__OnEndOverlap = 2,
    EFortCurieApplicationEvent__MaxValue = 3
};

enum EFortNativeCurieFXCueResponse : uint8_t
{
    EFortNativeCurieFXCueResponse__IgnoreCue = 0,
    EFortNativeCurieFXCueResponse__AllowCue = 1,
    EFortNativeCurieFXCueResponse__OverrideCue = 2
};

enum EFortCurieToggleComponentActivationBehavior : uint8_t
{
    EFortCurieToggleComponentActivationBehavior__OnValidAttachment = 0
};

enum EFortCurieToggleComponentDeactivationBehavior : uint8_t
{
    EFortCurieToggleComponentDeactivationBehavior__NeverDeactivate = 0,
    EFortCurieToggleComponentDeactivationBehavior__TimedDeactivationAllowRefresh = 1,
    EFortCurieToggleComponentDeactivationBehavior__TimedDeactivationNoRefresh = 2
};

enum EAccessoryColorName : uint8_t
{
    EAccessoryColorName_AccessoryColor1 = 0,
    EAccessoryColorName_AccessoryColor2 = 1,
    EAccessoryColorName_AccessoryColor3 = 2,
    EAccessoryColorName_NumTypes = 3
};

enum EClothingColorName : uint8_t
{
    EClothingColorName_AccessoryColor1 = 0,
    EClothingColorName_AccessoryColor2 = 1,
    EClothingColorName_NumTypes = 2
};

enum EVehicleEnteredCosmeticReaction : uint8_t
{
    EVehicleEnteredCosmeticReaction__Driver = 0,
    EVehicleEnteredCosmeticReaction__Passenger = 1,
    EVehicleEnteredCosmeticReaction__Both = 2
};

enum ECosmeticBudgetMultiplierMode : uint8_t
{
    ECosmeticBudgetMultiplierMode__Default = 0,
    ECosmeticBudgetMultiplierMode__Increased = 1,
    ECosmeticBudgetMultiplierMode__Reduced = 2
};

enum EManagedCosmeticType : uint8_t
{
    EManagedCosmeticType__Glider = 0,
    EManagedCosmeticType__GliderAnimSet = 1,
    EManagedCosmeticType__Pickaxe = 2,
    EManagedCosmeticType__Pet = 3,
    EManagedCosmeticType__ItemWrap = 4,
    EManagedCosmeticType__MAX_COUNT = 5
};

enum ECosmeticBudgetState : uint8_t
{
    ECosmeticBudgetState__Invalid = 0,
    ECosmeticBudgetState__InBudget = 1,
    ECosmeticBudgetState__OutOfBudget = 2
};

enum EDynam_S__H_J_i_y_______ : uint8_t
{
    EDynamicRebudgetingState__Inactive = 0,
    EDynamicRebudgetingState__GenerateCandidateList = 1,
    EDynamicRebudgetingState__SortCandidateList = 2,
    EDynamicRebudgetingState__RebudgetCandidates = 3
};

enum EFortCustomizationAssetLoaderFlags : uint16_t
{
    EFortCustomizationAssetLoaderFlags__None = 1,
    EFortCustomizationAssetLoaderFlags__ForceSynchronousLoad = 2,
    EFortCustomizationAssetLoaderFlags__CustomizationDestroy = 4,
    EFortCustomizationAssetLoaderFlags__CustomizationStart = 8,
    EFortCustomizationAssetLoaderFlags__LoadNewAssets = 16,
    EFortCustomizationAssetLoaderFlags__EndPlay = 32,
    EFortCustomizationAssetLoaderFlags__Destroyed = 64,
    EFortCustomizationAssetLoaderFlags__LevelTransition = 128,
    EFortCustomizationAssetLoaderFlags__EndPlayInEditor = 256,
    EFortCustomizationAssetLoaderFlags__RemovedFromWorld = 512,
    EFortCustomizationAssetLoaderFlags__Quit = 1024
};

enum EAssetLoadHistoryState : uint8_t
{
    EAssetLoadHistoryState__None = 0,
    EAssetLoadHistoryState__Requested = 1,
    EAssetLoadHistoryState__Cancelled = 2,
    EAssetLoadHistoryState__Finished = 3,
    EAssetLoadHistoryState__Removed = 4
};

enum EFortniteAnimationType : uint8_t
{
    EFortniteAnimationType__FN_Legacy = 0,
    EFortniteAnimationType__FN_3L = 1,
    EFortniteAnimationType__MHFDS_Version = 2
};

enum ETimespanAsTextFormat : uint8_t
{
    ETimespanAsTextFormat__DaysHoursMinutesSeconds = 0,
    ETimespanAsTextFormat__Colons = 1,
    ETimespanAsTextFormat__ColonsWithMilliseconds = 2,
    ETimespanAsTextFormat__Approximate = 3,
    ETimespanAsTextFormat__ApproximateWithWeeks = 4,
    ETimespanAsTextFormat__ApproximateWithMonths = 5,
    ETimespanAsTextFormat__ApproximateWithYears = 6
};

enum EDynamicDestructionResourceType : uint8_t
{
    EDynamicDestructionResourceType__Invalid = 0,
    EDynamicDestructionResourceType__Wood = 1,
    EDynamicDestructionResourceType__Stone = 2,
    EDynamicDestructionResourceType__Metal = 3,
    EDynamicDestructionResourceType__Foliage = 4,
    EDynamicDestructionResourceType__Unused = 5,
    EDynamicDestructionResourceType__Unused = 6,
    EDynamicDestructionResourceType__Unused = 7,
    EDynamicDestructionResourceType__Unused = 8
};

enum EFortEventRepeat : uint8_t
{
    EFortEventRepeat__EFER_InactO__ = 0,
    EFortEventRepeat__EFER_Always = 1,
    EFortEventRepeat__EFER_OncePerPlayer = 2,
    EFortEventRepeat__EFER_OncePerCampaign = 3,
    EFortEventRepeat__EFER_OncePerMap = 4
};

enum EFortCompare : uint8_t
{
    EFortCompare__EFC_LessThan = 0,
    EFortCompare__EFC_LessThanOrEqual = 1,
    EFortCompare__EFC_GreaterThan = 2,
    EFortCompare__EFC_GreaterThanOrEqual = 3,
    EFortCompare__EFC_Equals = 4
};

enum EFortEventConditionType : uint8_t
{
    EFortEventConditionType__EFEC_StatCompare = 0
};

enum EExperimentBucket : uint8_t
{
    EExperimentBucket__Baseline = 0,
    EExperimentBucket__Variation1 = 1,
    EExperimentBucket__NotInExperiment = 2
};

enum EClientSettingsSaveType : uint8_t
{
    EClientSettingsSaveType__Unknown = 0,
    EClientSettingsSaveType__LocalDisk = 1,
    EClientSettingsSaveType__CloudStorage = 2
};

enum EFortAmmoType : uint8_t
{
    EFortAmmoType__Pistol = 0,
    EFortAmmoType__Shotgun = 1,
    EFortAmmoType__Assault = 2,
    EFortAmmoType__Sniper = 3,
    EFortAmmoType__Energy = 4
};

enum EFortWeaponSoundChannel : uint8_t
{
    EFortWeaponSoundChannel__NormalA = 0,
    EFortWeaponSoundChannel__NormalB = 1,
    EFortWeaponSoundChannel__LowAmmo = 2,
    EFortWeaponSoundChannel__Degraded = 3,
    EFortWeaponSoundChannel__Max_None = 4
};

enum EFortTargetingFXState : uint8_t
{
    EFortTargetingFXState__TargetingStart = 0,
    EFortTargetingFXState__TargetingEnd = 1,
    EFortTargetingFXState__Max_None = 2
};

enum EFortCombatThresholds : uint8_t
{
    EFortCombatThresholds__Low = 0,
    EFortCombatThresholds__Medium = 1,
    EFortCombatThresholds__High = 2,
    EFortCombatThresholds__Extreme = 3,
    EFortCombatThresholds__Max_None = 4
};

enum EFortAIDirectorEventParticipant : uint8_t
{
    EFortAIDirectorEventParticipant__Target = 0,
    EFortAIDirectorEventParticipant__Source = 1,
    EFortAIDirectorEventParticipant__Either = 2,
    EFortAIDirectorEventParticipant__Max_None = 3
};

enum EFortCombatEventContribution : uint8_t
{
    EFortCombatEventContribution__Linear = 0,
    EFortCombatEventContribution__Inverse = 1,
    EFortCombatEventContribution__Accumulator = 2,
    EFortCombatEventContribution__Max_None = 3
};

enum EFortCombatFactors : uint8_t
{
    EFortCombatFactors__PlayerDamageThreat = 0,
    EFortCombatFactors__ObjectiveDamageThreat = 1,
    EFortCombatFactors__ObjectivePathCost = 2,
    EFortCombatFactors__PlayerPathCost = 3,
    EFortCombatFactors__PlayerMovement = 4,
    EFortCombatFactors__TrapsEffective = 5,
    EFortCombatFactors__PlayerWander = 6,
    EFortCombatFactors__NearbyEnemyPresence = 7,
    EFortCombatFactors__OffensiveResources = 8,
    EFortCombatFactors__DefensiveResources = 9,
    EFortCombatFactors__Boredom = 10,
    EFortCombatFactors__ArtilleryVulnerability = 11,
    EFortCombatFactors__Max_None = 12
};

enum EFortAIDirectorFactor : uint8_t
{
    EFortAIDirectorFactor__PlayerDamageThreat = 0,
    EFortAIDirectorFactor__ObjectiveDamageThreat = 1,
    EFortAIDirectorFactor__ObjectivePathCost = 2,
    EFortAIDirectorFactor__PlayerPathCost = 3,
    EFortAIDirectorFactor__PlayerMovement = 4,
    EFortAIDirectorFactor__TrapsEffective = 5,
    EFortAIDirectorFactor__PlayerWander = 6,
    EFortAIDirectorFactor__NearbyEnemyPresence = 7,
    EFortAIDirectorFactor__OffensiveResources = 8,
    EFortAIDirectorFactor__DefensiveResources = 9,
    EFortAIDirectorFactor__Boredom = 10,
    EFortAIDirectorFactor__ArtilleryVulnerability = 11,
    EFortAIDirectorFactor__Max_None = 12
};

enum EFortFactorContributionType : uint8_t
{
    EFortFactorContributionType__CurrentValue_Direct = 0,
    EFortFactorContributionType__CurrentValue_Inverse = 1,
    EFortFactorContributionType__AverageValue_Direct = 2,
    EFortFactorContributionType__AverageValue_Inverse = 3
};

enum EFortContributionGraphElements : uint8_t
{
    EFortContributionGraphElements__ProportionalLine = 0,
    EFortContributionGraphElements__IntegralLine = 1,
    EFortContributionGraphElements__TotalLine = 2,
    EFortContributionGraphElements__PendingLine = 3,
    EFortContributionGraphElements__ActionLine = 4,
    EFortContributionGraphElements__Max_None = 5
};

enum EFortIntensityGraphElements : uint8_t
{
    EFortIntensityGraphElements__ActualIntensity = 0,
    EFortIntensityGraphElements__DesiredIntensity = 1,
    EFortIntensityGraphElements__Max_None = 2
};

enum EFortPIDValueGraphElements : uint8_t
{
    EFortPIDValueGraphElements__Proportional = 0,
    EFortPIDValueGraphElements__Integral = 1,
    EFortPIDValueGraphElements__Max_None = 2
};

enum EFortGameActivityType : uint8_t
{
    EFortGameActivityType__Undefined = 0,
    EFortGameActivityType__STW = 1,
    EFortGameActivityType__BR = 2,
    EFortGameActivityType__CreativePublishedIsland = 3,
    EFortGameActivityType__Valkyrie = 4,
    EFortGameActivityType__ModeSet = 5,
    EFortGameActivityType__Reference = 6
};

enum EActivityCheckSolution : uint8_t
{
    EActivityCheckSolution__None = 0,
    EActivityCheckSolution__Purchase = 1,
    EActivityCheckSolution__Install = 2,
    EActivityCheckSolution__Settings = 3,
    EActivityCheckSolution__LeaveP3_____2J____DV_____ = 4
};

enum EFortDiscoveryOptionsOverride : uint8_t
{
    EFortDiscoveryOptionsOverride__Undefined = 0,
    EFortDiscoveryOptionsOverride__Privacy = 1,
    EFortDiscoveryOptionsOverride__FillOnly = 2,
    EFortDiscoveryOptionsOverride__OnlyFillSolo = 3
};

enum EFortDiscoveryDisabledFeatures : uint8_t
{
    EFortDiscoveryDisabledFeatures__Undefined = 0,
    EFortDiscoveryDisabledFeatures__AllWrites = 1,
    EFortDiscoveryDisabledFeatures__Favorites = 2,
    EFortDiscoveryDisabledFeatures__PlayHistory = 3,
    EFortDiscoveryDisabledFeatures__Queues = 4,
    EFortDiscoveryDisabledFeatures__ForCabin = 5,
    EFortDiscoveryDisabledFeatures__DiscoverySurface = 6
};

enum EFortActivityLockStatusReason : uint8_t
{
    EFortActivityLockStatusReason__None = 0,
    EFortActivityLockStatusReason__RatingThreshold = 1,
    EFortActivityLockStatusReason__Override = 2,
    EFortActivityLockStatusReason__Legacy = 3,
    EFortActivityLockStatusReason__Invalidated = 4,
    EFortActivityLockStatusReason__Unrated = 5,
    EFortActivityLockStatusReason__FailedToCheckContentGating = 6
};

enum EFortActivityIsLockedReason : uint8_t
{
    EFortActivityIsLockedReason__None = 0,
    EFortActivityIsLockedReason__AgeRating = 1,
    EFortActivityIsLockedReason__ActivityNotStarted = 2,
    EFortActivityIsLockedReason__ActivityEnded = 3,
    EFortActivityIsLockedReason__OutsideActivityWindow = 4,
    EFortActivityIsLockedReason__K3SAllowCreateSetting = 5,
    EFortActivityIsLockedReason__K3SOtherSetting = 6
};

enum EFortActivityLinkCategory : uint8_t
{
    EFortActivityLinkCategory__None = 0,
    EFortActivityLinkCategory__LEGO = 1,
    EFortActivityLinkCategory__RocketRacing = 2,
    EFortActivityLinkCategory__FallGuys = 3,
    EFortActivityLinkCategory__TMNT = 4
};

enum ESubGameAccessReason : uint8_t
{
    ESubGameAccessReason__NoAccess = 0,
    ESubGameAccessReason__OpenAccess = 1,
    ESubGameAccessReason__TokenItemAccess = 2,
    ESubGameAccessReason__XboxHomeSharingAccess = 3,
    ESubGameAccessReason__XboxServiceOutageAccess = 4,
    ESubGameAccessReason__LimitedAccess = 5
};

enum EDynamicSoundOverride : uint8_t
{
    EDynamicSoundOverride__Cue = 0,
    EDynamicSoundOverride__Wave = 1,
    EDynamicSoundOverride__Class = 2
};

enum EFortInputFilterLevel : uint8_t
{
    EFortInputFilterLevel__None = 0,
    EFortInputFilterLevel__Touch = 1,
    EFortInputFilterLevel__Gamepad = 2,
    EFortInputFilterLevel__Mouse = 3
};

enum ETeamChatRoomState : uint8_t
{
    ETeamChatRoomState__NotCreated = 0,
    ETeamChatRoomState__Creating = 1,
    ETeamChatRoomState__Created = 2,
    ETeamChatRoomState__Timeout = 3
};

enum EFortOfferSeenLevel : uint8_t
{
    EFortOfferSeenLevel__Unseen = 0,
    EFortOfferSeenLevel__Notification = 1,
    EFortOfferSeenLevel__ItemShopVisited = 2,
    EFortOfferSeenLevel__OfferSectionVisited = 3,
    EFortOfferSeenLevel__Purchased = 4
};

enum EFortMobileFPSMode : uint8_t
{
    EFortMobileFPSMode__Mode_20Fps = 0,
    EFortMobileFPSMode__Mode_30Fps = 1,
    EFortMobileFPSMode__Mode_45Fps = 2,
    EFortMobileFPSMode__Mode_60Fps = 3,
    EFortMobileFPSMode__Mode_90Fps = 4,
    EFortMobileFPSMode__Mode_120Fps = 5,
    EFortMobileFPSMode__Num = 6
};

enum EFortContentQualityLevel : uint8_t
{
    EFortContentQualityLevel__Unset = 0,
    EFortContentQualityLevel__Quality_Base = 1,
    EFortContentQualityLevel__Quality_Medium = 2,
    EFortContentQualityLevel__Quality_Hi__ = 3,
    EFortContentQualityLevel__Num = 4
};

enum EParsleyIdleTime : uint8_t
{
    EParsleyIdleTime__Minutes = 0,
    EParsleyIdleTime__Minutes = 1,
    EParsleyIdleTime__Minutes = 2,
    EParsleyIdleTime__Minutes = 3,
    EParsleyIdleTime__Minutes = 4,
    EParsleyIdleTime__Minutes = 5,
    EParsleyIdleTime__Never = 6
};

enum EFortAllowDownloadHighResMipsBehavior : uint8_t
{
    EFortAllowDownloadHighResMipsBehavior__Disabled_Permanent = 0,
    EFortAllowDownloadHighResMipsBehavior__Disabled_Temp = 1,
    EFortAllowDownloadHighResMipsBehavior__Enabled = 2
};

enum EFortAllowCosmeticStreaming : uint8_t
{
    EFortAllowCosmeticStreaming__CodeSet_Enabled = 0,
    EFortAllowCosmeticStreaming__CodeSet_Disabled = 1,
    EFortAllowCosmeticStreaming__UserSet_Enabled = 2,
    EFortAllowCosmeticStreaming__UserSet_Disabled = 3,
    EFortAllowCosmeticStreaming__Default = 0
};

enum ESavedAccountType : uint8_t
{
    ESavedAccountType__None = 0,
    ESavedAccountType__Facebook = 1,
    ESavedAccountType__Google = 2,
    ESavedAccountType__Epic = 3,
    ESavedAccountType__Device = 4,
    ESavedAccountType__Headless = 5,
    ESavedAccountType__Refresh = 6
};

enum EShowInGamePictureInPicture : uint8_t
{
    EShowInGamePictureInPicture__Default = 0,
    EShowInGamePictureInPicture__Hide = 1,
    EShowInGamePictureInPicture__Show = 2
};

enum ERHIType : uint8_t
{
    ERHIType__D3D11 = 0,
    ERHIType__D3D12 = 1,
    ERHIType__Performance = 2
};

enum EFortAntiAliasingMethod : uint8_t
{
    EFortAntiAliasingMethod__Disabled = 0,
    EFortAntiAliasingMethod__FXAA = 1,
    EFortAntiAliasingMethod__TAA = 2,
    EFortAntiAliasingMethod__TSRLow = 3,
    EFortAntiAliasingMethod__TSRMedium = 4,
    EFortAntiAliasingMethod__TSRHigh = 5,
    EFortAntiAliasingMethod__TSREpic = 6,
    EFortAntiAliasingMethod__TSR = 6,
    EFortAntiAliasingMethod__DLSS = 7,
    EFortAntiAliasingMethod__XeSS = 8,
    EFortAntiAliasingMethod__Num = 9
};

enum EFortTemporalSuperResolutionSetting : uint8_t
{
    EFortTemporalSuperResolutionSetting__Recommended = 0,
    EFortTemporalSuperResolutionSetting__Performance = 1,
    EFortTemporalSuperResolutionSetting__Balanced = 2,
    EFortTemporalSuperResolutionSetting__Quality = 3,
    EFortTemporalSuperResolutionSetting__Native = 4,
    EFortTemporalSuperResolutionSetting__Custom = 5,
    EFortTemporalSuperResolutionSetting__Num = 6,
    EFortTemporalSuperResolutionSetting__Default = 0
};

enum ELastLaunchPushNotificationState : uint8_t
{
    ELastLaunchPushNotificationState__NotSet = 0,
    ELastLaunchPushNotificationState__Disabled = 1,
    ELastLaunchPushNotificationState__Enabled = 2
};

enum EFortAccountLinkingUIConfig : uint8_t
{
    EFortAccountLinkingUIConfig__Disabled = 0,
    EFortAccountLinkingUIConfig__Default = 1,
    EFortAccountLinkingUIConfig__ExternalViewerOnly = 2,
    EFortAccountLinkingUIConfig__FullExternal = 3
};

enum EContentInstallState : uint8_t
{
    EContentInstallState__NotInstalled = 0,
    EContentInstallState__Pending = 1,
    EContentInstallState__Installed = 2,
    EContentInstallState__Unknown = 3,
    EContentInstallState__Error = 4
};

enum ETimeLimitForReplayCinematic : uint8_t
{
    ETimeLimitForReplayCinematic__OpenTimeLimit = 0,
    ETimeLimitForReplayCinematic__DurationTimeLimit = 1,
    ETimeLimitForReplayCinematic__DurationExtraTime = 2
};

enum EMapCaptureMethod : uint8_t
{
    EMapCaptureMethod__None = 0,
    EMapCaptureMethod__LiveCapture = 1,
    EMapCaptureMethod__StaticCapture = 2
};

enum EFortMiniMapDrawCategory : uint8_t
{
    EFortMiniMapDrawCategory__AthenaBackground = 0,
    EFortMiniMapDrawCategory__MapLocation = 1,
    EFortMiniMapDrawCategory__SafeZone = 2,
    EFortMiniMapDrawCategory__BusPath = 3,
    EFortMiniMapDrawCategory__SpecialActorIcon = 4,
    EFortMiniMapDrawCategory__SquadPin = 5,
    EFortMiniMapDrawCategory__MapIndicator = 6,
    EFortMiniMapDrawCategory__MapCursor = 7,
    EFortMiniMapDrawCategory__Elimination = 8
};

enum ETimerOverrideSetting : uint8_t
{
    ETimerOverrideSetting__DefaultBehavior = 0,
    ETimerOverrideSetting__ForceShow = 1,
    ETimerOverrideSetting__ForceHide = 2,
    ETimerOverrideSetting__ShowAtEnd = 3
};

enum EFortNearbyActorsTypes : uint8_t
{
    EFortNearbyActorsTypes__None = 0,
    EFortNearbyActorsTypes__RealPlayers = 1,
    EFortNearbyActorsTypes__Bots = 2,
    EFortNearbyActorsTypes__NPCs = 4,
    EFortNearbyActorsTypes__AIPawns = 8,
    EFortNearbyActorsTypes__All = 15
};

enum EActionStatus : uint8_t
{
    EActionStatus__Pending = 0,
    EActionStatus__Running = 1,
    EActionStatus__Completed = 2
};

enum EFortRewardType : uint8_t
{
    EFortRewardType__Default = 0,
    EFortRewardType__Missed = 1,
    EFortRewardType__Max_None = 2
};

enum EFortPlayerWorkOverFramesMode : uint8_t
{
    EFortPlayerWorkOverFramesMode__NotProcessing = 0,
    EFortPlayerWorkOverFramesMode__PreInitializeComponents = 1,
    EFortPlayerWorkOverFramesMode__DefaultPartsWhileWaiting = 2,
    EFortPlayerWorkOverFramesMode__UpdateCharacterCustomization = 3,
    EFortPlayerWorkOverFramesMode__NumTypes = 4
};

enum EFortPlayerWorkOverFramesStage : uint8_t
{
    EFortPlayerWorkOverFramesStage__NotProcessing = 0,
    EFortPlayerWorkOverFramesStage__PreloadingParts = 1,
    EFortPlayerWorkOverFramesStage__QueuePostLoad = 2,
    EFortPlayerWorkOverFramesStage__PostLoad = 3,
    EFortPlayerWorkOverFramesStage__InitializeCharacterParts = 4,
    EFortPlayerWorkOverFramesStage__FinishUpdatingParts = 5,
    EFortPlayerWorkO_____F_2S___________s____f___ = 6,
    EFortPlayerWorkOverFramesStage__NumTypes = 7
};

enum EFortPlayerPartState : uint8_t
{
    EFortPlayerPartState__NeverInitalized = 0,
    EFortPlayerPartState__AssetsPreloading = 1,
    EFortPlayerPartState__QueuedForInitialization = 2,
    EFortPlayerPartState__CurrentlyInitializing = 3,
    EFortPlayerPartState__InitializationComplete = 4,
    EFortPlayerPartState__InitializationComplete_EmptyPart = 5,
    EFortPlayerPartState__InitializationComplete_Cancelled = 6,
    EFortPlayerPartState__InitializationFailed_NoParts = 7,
    EFortPlayerPartState__NumTypes = 8
};

enum EPartsShowingMode : uint8_t
{
    EPartsShowingMode__NeverInitalized = 0,
    EPartsShowingMode__ShowingTemporaryDefaultParts = 1,
    EPartsShowingMode__ShowingTemporaryFallbackParts = 2,
    EPartsShowingMode__ShowingDefaultParts = 3,
    EPartsShowingMode__ShowingFallbackParts = 4,
    EPartsShowingMode__ShowingDesiredParts = 5
};

enum EDBNOType : uint8_t
{
    EDBNOType__On = 0,
    EDBNOType__Off = 1,
    EDBNOType__NotWhenRespawning = 2
};

enum EFortGameType : uint8_t
{
    EFortGameType__BR = 0,
    EFortGameType__ZeroBuild = 1,
    EFortGameType__Creative = 2,
    EFortGameType__CreativeLTM = 3,
    EFortGameType__Playground = 4,
    EFortGameType__STW = 5,
    EFortGameType__BRArena = 6,
    EFortGameType__BRLTM = 7,
    EFortGameType__Social = 8,
    EFortGameType__VKEdit = 9,
    EFortGameType__VKPlay = 10,
    EFortGameType__DelMar = 11,
    EFortGameType__Festival = 12,
    EFortGameType__FestivalMainStage = 13,
    EFortGameType__FestivalJamStage = 14,
    EFortGameType__Juno = 15,
    EFortGameType__FestivalBattleStage = 16,
    EFortGameType__BlastBerry = 17,
    EFortGameType__Figment = 18
};

enum EPortalLinkCodeLockMode : uint8_t
{
    EPortalLinkCodeLockMode__NeverLocked = 0,
    EPortalLinkCodeLockMode__WindowLocked = 1,
    EPortalLinkCodeLockMode__AlwaysLocked = 2
};

enum ERegisteredPlayerUnregistrationStatus : uint8_t
{
    ERegisteredPlayerUnregistrationStatus__Registered = 0,
    ERegisteredPlayerUnregistrationStatus__UnregistrationStarting = 1,
    ERegisteredPlayerUnregistrationStatus__UnregistrationWaitingForInitialLock = 2,
    ERegisteredPlayerUnregistrationStatus__UnregistrationWaitingForScoreSave = 3,
    ERegisteredPlayerUnregistrationStatus__UnregistrationWaitingForFinalSave = 4,
    ERegisteredPlayerUnregistrationStatus__UnregistrationWaitingForProfileUnlock = 5,
    ERegisteredPlayerUnregistrationStatus__UnregistrationComplete = 6
};

enum EFortSoundIndicatorTypes : uint8_t
{
    EFortSoundIndicatorTypes__Generic = 0,
    EFortSoundIndicatorTypes__FootStep = 1,
    EFortSoundIndicatorTypes__Gunshot = 2,
    EFortSoundIndicatorTypes__Chest = 3,
    EFortSoundIndicatorTypes__Glider = 4,
    EFortSoundIndicatorTypes__Vehicle = 5,
    EFortSoundIndicatorTypes__Infected = 6,
    EFortSoundIndicatorTypes__Healing = 7,
    EFortSoundIndicatorTypes__COUNT = 8
};

enum EFortStreamLimits : uint8_t
{
    EFortStreamLimits__None = 0,
    EFortStreamLimits__Discovery = 1,
    EFortStreamLimits__InWorld = 2,
    EFortStreamLimits__Creative = 3,
    EFortStreamLimits__PiP = 4,
    EFortStreamLimits__FNEvents = 5
};

enum EFortTODMPostProcess : uint8_t
{
    EFortTODMPostProcess__Morning = 0,
    EFortTODMPostProcess__Day = 1,
    EFortTODMPostProcess__Evening = 2,
    EFortTODMPostProcess__Night = 3,
    EFortTODMPostProcess__Classic = 4,
    EFortTODMPostProcess__NumPostprocess = 5,
    EFortTODMPostProcess__EFortTOD________f_WA____ = 6
};

enum ESettingTab : uint8_t
{
    ESettingTab__None = 0,
    ESettingTab__Video = 1,
    ESettingTab__Game = 2,
    ESettingTab__GameUI = 3,
    ESettingTab__Brightness = 4,
    ESettingTab__Audio = 5,
    ESettingTab__Accessibility = 6,
    ESettingTab__Input = 7,
    ESettingTab__MouseAndKeyboard = 8,
    ESettingTab__Controller = 9,
    ESettingTab__ControllerSensitivity = 10,
    ESettingTab__TouchAndMotion = 11,
    ESettingTab__TouchWeapon = 12,
    ESettingTab__Account = 13,
    ESettingTab__CreativeWorld = 14,
    ESettingTab__CreativePlayer = 15,
    ESettingTab__Communication = 16
};

enum EFortItemCategoryOrdinal : uint8_t
{
    EFortItemCategoryOrdinal__Primary = 0,
    EFortItemCategoryOrdinal__Secondary = 1,
    EFortItemCategoryOrdinal__Tertiary = 2
};

enum EFortItemViewRotationMode : uint8_t
{
    EFortItemViewRotationMode__None = 0,
    EFortItemViewRotationMode__BoundsPivot = 1,
    EFortItemViewRotationMode__World = 2,
    EFortItemViewRotationMode__Relative = 3,
    EFortItemViewRotationMode__Self = 4
};

enum EFortTileEdgeType : uint8_t
{
    EFortTileEdgeType__Undefined = 0,
    EFortTileEdgeType__Outer = 1,
    EFortTileEdgeType__Transition = 2,
    EFortTileEdgeType__Inner = 3,
    EFortTileEdgeType__Border = 4,
    EFortTileEdgeType__BorderTransitionSingle = 5,
    EFortTileEdgeType__BorderTransitionDouble = 6
};

enum EFortIndicatorState : uint8_t
{
    EFortIndicatorState__Hidden = 0,
    EFortIndicatorState__OnlyFriendsVisible = 1,
    EFortIndicatorState__Visible = 2
};

enum EKeepContainerType : uint8_t
{
    EKeepContainerType__Base = 0,
    EKeepContainerType__Storeroom = 1,
    EKeepContainerType__FirstAid = 2,
    EKeepContainerType__Armory = 3,
    EKeepContainerType__Workshop = 4,
    EKeepContainerType__AmmoStash = 5,
    EKeepContainerType__Max = 6
};

enum EKeepDefenseState : uint8_t
{
    EKeepDefenseState__Inactive = 0,
    EKeepDefenseState__Warmup = 1,
    EKeepDefenseState__Defense = 2,
    EKeepDefenseState__LastAlive = 3,
    EKeepDefenseState__Max = 4
};

enum EFortCraftFailCause : uint8_t
{
    EFortCraftFailCause__Unknown = 0,
    EFortCraftFailCause__NotEnoughResources = 1,
    EFortCraftFailCause__InventoryFull = 2,
    EFortCraftFailCause__InsufficientTeamLevel = 3,
    EFortCraftFailCause__CraftingQueueFull = 4,
    EFortCraftFailCause__CurrentlyLocked = 5,
    EFortCraftFailCause__OverflowSchematic = 6
};

enum ECraftingUpgradeDataFlags : uint16_t
{
    ECraftingUpgradeDataFlags__None = 0,
    ECraftingUpgradeDataFlags__OverrideWrap = 1,
    ECraftingUpgradeDataFlags__Durability = 2,
    ECraftingUpgradeDataFlags__PhantomAmmo = 4,
    ECraftingUpgradeDataFlags__LoadedAmmo = 8,
    ECraftingUpgradeDataFlags__ModSlots = 16,
    ECraftingUpgradeDataFlags__All = 255
};

enum EFortBangType : uint8_t
{
    EFortBangType__Invalid = 0,
    EFortBangType__Custom = 1,
    EFortBangType__PlayTab = 2,
    EFortBangType__VaultTab = 3,
    EFortBangType__StoreTab = 4,
    EFortBangType__QuestsTab = 5,
    EFortBangType__SubGameAccessChanged = 6,
    EFortBangType__QuestsButton = 7,
    EFortBangType__MainMenu = 8,
    EFortBangType__VaultSchematics = 9,
    EFortBangType__VaultLeadSurvivors = 10,
    EFortBangType__VaultSurvivors = 11,
    EFortBangType__VaultHeroes = 12,
    EFortBangType__VaultDefenders = 13,
    EFortBangType__VaultResources = 14,
    EFortBangType__VaultMelee = 15,
    EFortBangType__VaultRanged = 16,
    EFortBangType__VaultConsumables = 17,
    EFortBangType__VaultIngredients = 18,
    EFortBangType__VaultTraps = 19,
    EFortBangType__BattlePassTab = 20,
    EFortBangType__SpecialEventTab = 21,
    EFortBangType__WinterfestTab = 22,
    EFortBangType__CosmeticsTab = 23,
    EFortBangType__AthenaDirectedAcquisitionTab = 24,
    EFortBangType__MultiProductItemShop = 25,
    EFortBangType__AthenaChallengesTab = 26,
    EFortBangType__AthenaCareerTab = 27,
    EFortBangType__STWCommand = 28,
    EFortBangType__STWCommand_Heroes = 29,
    EFortBangType__STWCommand_Heroes_Manage = 30,
    EFortBangType__STWCommand_Heroes_HeroLoadout = 31,
    EFortBangType__STWCommand_Heroes_Defenders = 32,
    EFortBangType__STWCommand_Heroes_Expeditions = 33,
    EFortBangType__STWCommand_Survivors = 34,
    EFortBangType__STWCommand_Survivors_Manage = 35,
    EFortBangType_____HC_____C____Bz____v_____ = 36,
    EFortBangType__STWCommand_Upgrades = 37,
    EFortBangType__STWCommand_Research = 38,
    EFortBangType__STWCommand_AccountXP = 39,
    EFortBangType__STWArmory = 40,
    EFortBangType__STWArmory_Schematics = 41,
    EFortBangType__STWArmory_Backpack = 42,
    EFortBangType__STWArmory_Storage = 43,
    EFortBangType__STWArmory_CollectionBook = 44,
    EFortBangType__STWArmory_Transform = 45,
    EFortBangType__STWArmory_Resources = 46,
    EFortBangType__STWLocker = 47,
    EFortBangType__SocialButton = 48
};

enum ETutorialType : uint8_t
{
    ETutorialType__None = 0,
    ETutorialType__Callout = 1,
    ETutorialType__GuardScreen = 2,
    ETutorialType__WidgetIntro = 3,
    ETutorialType__Highlight = 4
};

enum EStormShieldDefense : uint8_t
{
    EStormShieldDefense__NotSSD = 0,
    EStormShieldDefense__StormShieldExpansion = 1,
    EStormShieldDefense__WargameSimulation = 2
};

enum EItemListViewDisplayType : uint8_t
{
    EItemListViewDisplayType__World = 0,
    EItemListViewDisplayType__Outpost = 1,
    EItemListViewDisplayType__Account = 2,
    EItemListViewDisplayType__DeployableBase = 3,
    EItemListViewDisplayType__Max = 4
};

enum EPTTState : uint8_t
{
    EPTTState__Enabled = 0,
    EPTTState__MicDisabled = 1,
    EPTTState__AllSoundDisabled = 2
};

enum EFortMatchmakingViolatorStyle : uint8_t
{
    EFortMatchmakingViolatorStyle__None = 0,
    EFortMatchmakingViolatorStyle__Basic = 1,
    EFortMatchmakingViolatorStyle__HighStakes = 2,
    EFortMatchmakingViolatorStyle__Showdown = 3,
    EFortMatchmakingViolatorStyle__FirstTimeUser = 4
};

enum EFortCreativeAdType : uint8_t
{
    EFortCreativeAdType__Default = 0,
    EFortCreativeAdType__Playset = 1,
    EFortCreativeAdType__Toy = 2,
    EFortCreativeAdType__Game = 3,
    EFortCreativeAdType__Island = 4,
    EFortCreativeAdType__Knob = 5
};

enum EFortCreativeAdColorPreset : uint8_t
{
    EFortCreativeAdColorPreset__Default = 0,
    EFortCreativeAdColorPreset__Emphasized = 1,
    EFortCreativeAdColorPreset__Common = 2,
    EFortCreativeAdColorPreset__Uncommon = 3,
    EFortCreativeAdColorPreset__Rare = 4,
    EFortCreativeAdColorPreset__Epic = 5,
    EFortCreativeAdColorPreset__Legendary = 6
};

enum EFortStartupPhase : uint8_t
{
    EFortStartupPhase__InitializingEngine = 0,
    EFortStartupPhase__EarlyStartupLoading = 1,
    EFortStartupPhase__EarlyStartupFinished = 2,
    EFortStartupPhase__GameStartupLoading = 3,
    EFortStartupPhase__GameStartupFinished = 4,
    EFortStartupPhase__Invalid = 5,
    EFortStartupPhase__Count = 5
};

enum EFortQuickTimeEventResult : uint8_t
{
    EFortQuickTimeEventResult__None = 0,
    EFortQuickTimeEventResult__Miss = 1,
    EFortQuickTimeEventResult__Good = 2,
    EFortQuickTimeEventResult__Great = 3,
    EFortQuickTimeEventResult__Perfect = 4
};

enum EHighResTexturesChangeReason : uint8_t
{
    EHighResTexturesChangeReason__UserGameSettings = 0,
    EHighResTexturesChangeReason__QualityLevelSelectScreenSettings = 1,
    EHighResTexturesChangeReason__ContentOnDemandFreedUpMemorySelection = 2,
    EHighResTexturesChangeReason__ContentOnDemandDisplayOutOfMemory = 3,
    EHighResTexturesChangeReason__ContentOnDemandOutOfMemoryErrorClosed = 4
};

enum EFortItemInspectionMode : uint8_t
{
    EFortItemInspectionMode__Overview = 0,
    EFortItemInspectionMode__Details = 1,
    EFortItemInspectionMode__View = 2,
    EFortItemInspectionMode__Evolution = 3,
    EFortItemInspectionMode__Upgrade = 4,
    EFortItemInspectionMode__UpgradeRarity = 5,
    EFortItemInspectionMode__Promotion = 6
};

enum EFortContentRating : uint8_t
{
    EFortContentRating__IARC_Everyone = 0,
    EFortContentRating__IARC_TenPlus = 1,
    EFortContentRating__IARC_Teen = 2
};

enum EFortUserCloudRequestResult : uint8_t
{
    EFortUserCloudRequestResult__Success = 0,
    EFortUserCloudRequestResult__Failure_CloudStorageDisabled = 1,
    EFortUserCloudRequestResult__Failure_CloudStorageError = 2,
    EFortUserCloudRequestResult__Failure_FileNotFoundInUserFileList = 3,
    EFortUserCloudRequestResult__Failure_SavingNotAllowedForSpecifiedUser = 4
};

enum EUserOptionDefinitionGenerationFlags : uint8_t
{
    EUserOptionDefinitionGenerationFlags__None = 0,
    EUserOptionDefinitionGenerationFlags__AutoAdded = 1,
    EUserOptionDefinitionGenerationFlags__Inherited = 2
};

enum EVehicleFuelState : uint8_t
{
    EVehicleFuelState__Uninitialized = 0,
    EVehicleFuelState__UsingVehicleFuel = 1,
    EVehicleFuelState__NotUsingVehicleFuel = 2
};

enum ETryExitVehicleBehavior : uint8_t
{
    ETryExitVehicleBehavior__DoNotForce = 0,
    ETryExitVehicleBehavior__ForceOnBlocking = 1,
    ETryExitVehicleBehavior__ForceAlways = 2,
    ETryExitVehicleBehavior__ETryExi__XE__o1q__9_r___b__ = 3
};

enum EFortWorldRecordAction : uint8_t
{
    EFortWorldRecordAction__LoadWorldOnly = 0,
    EFortWorldRecordAction__SaveWorldOnly = 1,
    EFortWorldRecordAction__SaveZoneAndWorld = 2,
    EFortWorldRecordAction__LoadZoneAndWorld = 3,
    EFortWorldRecordAction__SaveDeployableBasesAndWorld = 4,
    EFortWorldRecordAction__Max_None = 5
};

enum EFortWorldRecordState : uint8_t
{
    EFortWorldRecordState__StartProcessing = 0,
    EFortWorldRecordState__WaitingForResponse = 1,
    EFortWorldRecordState__RetrievingTheaterInformation = 2,
    EFortWorldRecordState__RetrievingZoneInformation = 3,
    EFortWorldRecordState__LoadingWorldRecord = 4,
    EFortWorldRecordState__LoadingZoneRecord = 5,
    EFortWorldRecordState__SavingZoneRecord = 6,
    EFortWorldRecordState__SavingPlayerProfiles = 7,
    EFortWorldRecordState__SavingPlayerDeployableBases = 8,
    EFortWorldRecordState__Succeeded = 9,
    EFortWorldRecordState__Failed = 10,
    EFortWorldRecordState__Max_None = 11
};

enum EFortQueuedActionUserStatus : uint8_t
{
    EFortQueuedActionUserStatus__Succeeded = 0,
    EFortQueuedActionUserStatus__Failed = 1,
    EFortQueuedActionUserStatus__WaitingForCloudRequest = 2,
    EFortQueuedActionUserStatus__WaitingForProfileSave = 3
};

enum EFortLevelStreamingState : uint8_t
{
    LSS_Unloaded = 0,
    LSS_Loaded = 1,
    LSS_UnconditionalFoundationsUpdated = 2,
    LSS_AllFoundationsUpdated = 3,
    LSS_NewActorsCreatedButNotUpdated = 4,
    LSS_AllUpdated = 5,
    LSS_Ready = 6
};

enum EFortWorldManagerState : uint8_t
{
    WMS_Created = 0,
    WMS_QueryingWorld = 1,
    WMS_WorldQueryComplete = 2,
    WMS_CreatingNewWorld = 3,
    WMS_LoadingExistingWorld = 4,
    WMS_Running = 5,
    WMS_Failed = 6
};

enum EMutatorAddTarget : uint8_t
{
    EMutatorAddTarget__FortGameStateAthena = 0,
    EMutatorAddTarget__FortMinigame = 1,
    EMutatorAddTarget__FortGameModeAthena = 2
};

enum EFortGameFeatureActionAddComponentMode : uint8_t
{
    EFortGameFeatureActionAddComponentMode__None = 0,
    EFortGameFeatureActionAddComponentMode__Game = 1,
    EFortGameFeatureActionAddComponentMode__Editor = 2
};

enum EKeyboardMouseKeybindingsAtRegistrationTime : uint8_t
{
    EKeyboardMouseKeybindingsAtRegistrationTime__Invalid = 0,
    EKeyboardMouseKeybindingsAtRegistrationTime__GameFeatureRegistrationTime = 1,
    EKeyboardMouseKeybindingsAtRegistrationTime__GameFeatureActivationTime = 2
};

enum EFrontendRequirement : uint8_t
{
    EFrontendRequirement__None = 0,
    EFrontendRequirement__RequireFrontend = 1,
    EFrontendRequirement__RequireNotFrontend = 2
};

enum EMapCursorHoverTarget : uint8_t
{
    EMapCursorHoverTarget__None = 0,
    EMapCursorHoverTarget__Marker = 1,
    EMapCursorHo_______ = 2
};

enum EQuickHealingRequirementFlags : uint8_t
{
    EQuickHealingRequirementFlags__Nothing = 0,
    EQuickHealingRequirementFlags__NeedsHealing = 1,
    EQuickHealingRequirementFlags__NeedsShields = 2,
    EQuickHealingRequirementFlags__NeedsBoth = 3,
    EQuickHealingRequirementFlags__Invalid = 4
};

enum EPageItemTileSize : uint8_t
{
    EPageItemTileSize__Size_1_x = 0,
    EPageItemTileSize__Size_2_x = 1,
    EPageItemTileSize__Size_2_x = 2,
    EPageItemTileSize__Size_3_x = 3,
    EPageItemTileSize__Size_3_x = 4,
    EPageItemTileSize__Count = 5
};

enum ESmartBuildMode : uint8_t
{
    ESmartBuildMode__None = 0,
    ESmartBuildMode__Auto = 1,
    ESmartBuildMode__Box = 2,
    ESmartBuildMode__Bridge = 3,
    ESmartBuildMode__Tower = 4,
    ESmartBuildMode__ProtectedRamp = 5
};

enum ESmartBuildPlayerLocationInCell : uint8_t
{
    ESmartBuildPlayerLocationInCell__Anywhere = 0,
    ESmartBuildPlayerLocationInCell__Forward = 1,
    ESmartBuildPlayerLocationInCell__Back = 2
};

enum ECodeTokenPlatform : uint8_t
{
    ECodeTokenPlatform__PC = 0,
    ECodeTokenPlatform__PS4 = 1,
    ECodeTokenPlatform__XBOX = 2
};

enum EFortConditionalResourceItemTest : uint8_t
{
    EFortConditionalResourceItemTest__CanEarnMtx = 0
};

enum EFortGiftWrapType : uint8_t
{
    EFortGiftWrapType__System = 0,
    EFortGiftWrapType__UserFree = 1,
    EFortGiftWrapType__UserUnlock = 2,
    EFortGiftWrapType__UserConsumable = 3,
    EFortGiftWrapType__Message = 4,
    EFortGiftWrapType__Ungift = 5
};

enum EFortHardcoreModifierTier : uint8_t
{
    EFortHardcoreModifierTier__Bronze = 0,
    EFortHardcoreModifierTier__Silver = 1,
    EFortHardcoreModifierTier__Gold = 2,
    EFortHardcoreModifierTier__Platinum = 3,
    EFortHardcoreModifierTier__Diamond = 4
};

enum EItemUpgradeRestrictionReason : uint8_t
{
    EItemUpgradeRestrictionReason__NoAdditionalLevels = 0,
    EItemUpgradeRestrictionReason__MaximumLevelAchieved = 1,
    EItemUpgradeRestrictionReason__VaultOverflow = 2
};

enum EItemEvolutionRestrictionReason : uint8_t
{
    EItemEvolutionRestrictionReason__NoEvolutions = 0,
    EItemEvolutionRestrictionReason__BelowMaximumLevel = 1,
    EItemEvolutionRestrictionReason__VaultOverflow = 2,
    EItemEvolutionRestrictionReason__MissingCatalyst = 3,
    EItemEvolutionRestrictionReason__MissingCosts = 4,
    EItemEvolutionRestrictionReason__NoRarityUpgrade = 5,
    EItemEvolutionRestrictionReason__InUseByCrafting = 6
};

enum EFortTemplateAccess : uint8_t
{
    EFortTemplateAccess__Normal = 0,
    EFortTemplateAccess__Trusted = 1,
    EFortTemplateAccess__Private = 2
};

enum ELootQuotaLevel : uint8_t
{
    ELootQuotaLevel__Unlimited = 0,
    ELootQuotaLevel__Level1 = 1,
    ELootQuotaLevel__Level2 = 2,
    ELootQuotaLevel__Level3 = 3,
    ELootQuotaLevel__Level4 = 4,
    ELootQuotaLevel__Level5 = 5,
    ELootQuotaLevel__Level6 = 6,
    ELootQuotaLevel__Level7 = 7,
    ELootQuotaLevel__Level8 = 8,
    ELootQuotaLevel__Level9 = 9,
    ELootQuotaLevel__Level10 = 10,
    ELootQuotaLevel__Level11 = 11,
    ELootQuotaLevel__Level12 = 12,
    ELootQuotaLevel__Level13 = 13,
    ELootQuotaLevel__Level14 = 14,
    ELootQuotaLevel__Level15 = 15,
    ELootQuotaLevel__Level16 = 16,
    ELootQuotaLevel__Level17 = 17,
    ELootQuotaLevel__NumLevels = 18
};

enum EFortPickupTossState : uint8_t
{
    EFortPickupTossState__NotTossed = 0,
    EFortPickupTossState__InProgress = 1,
    EFortPickupTossState__AtRest = 2
};

enum EManagedPickupBucket : uint8_t
{
    EManagedPickupBucket__Default = 0,
    EManagedPickupBucket__Junk = 1,
    EManagedPickupBucket__Normal = 2,
    EManagedPickupBucket__Important = 3
};

enum EManagedPickupContext : uint8_t
{
    EManagedPickupContext__Unknown = 0,
    EManagedPickupContext__PlayerDropped = 1,
    EManagedPickupContext__Overflow = 2,
    EManagedPickupContext__Spawned = 3
};

enum ESeasonPassPurchaseContext : uint8_t
{
    ESeasonPassPurchaseContext__None = 0,
    ESeasonPassPurchaseContext__Purchase = 1,
    ESeasonPassPurchaseContext__Subscription = 2
};

enum ENavigationSupport : uint8_t
{
    ENavigationSupport__Unknown = 0,
    ENavigationSupport__NavigationSupported = 1,
    ENavigationSupport__NavigationDisabled = 2
};

enum ELevelSaveRecordThumbnailTextureCreationMode : uint8_t
{
    ELevelSaveRecordThumbnailTextureCreationMode__TransientTextureOnGPU = 0,
    ELevelSaveRecordThumbnailTextureCreationMode__SaveableTexture = 1,
    ELevelSaveRecordThumbnailTextureCreationMode__PNGImage = 2,
    ELevelSaveRecordThumbnailTextureCreationMode__SceneImage = 3
};

enum EMaterialStyleParameterType : uint8_t
{
    EMaterialStyleParameterType__Scalar = 0,
    EMaterialStyleParameterType__Vector = 1,
    EMaterialStyleParameterType__Texture = 2
};

enum EStyleRequestArbitrationPolicy : uint8_t
{
    EStyleRequestArbitrationPolicy__ReplaceActive = 0,
    ESty__N____Xx____O__8_____P____1_____xy__ = 1,
    EStyleRequestArbitrationPolicy__QueueFront = 2
};

enum EJamEnabledOptions : uint8_t
{
    EJamEnabledOptions__Off = 0,
    EJamEnabledOptions__On = 1,
    EJamEnabledOptions__Default = 2
};

enum EMinigameTeamStructurePreset : uint8_t
{
    EMinigameTeamStructurePreset__Legacy = 0,
    EMinigameTeamStructurePreset__Custom = 1,
    EMinigameTeamStructurePreset__SinglePlayer = 2,
    EMinigameTeamStructurePreset__Cooperative = 3,
    EMinigameTeamStructurePreset__FreeForAll = 4,
    EMinigameTeamStructurePreset__TeamPvP = 5
};

enum EFortCheatMissionGenType : uint8_t
{
    EFortCheatMissionGenType__NewGeneration = 0,
    EFortCheatMissionGenType__OldGeneration = 1,
    EFortCheatMissionGenType__Max_None = 2
};

enum EFortOptionGenerationResult : uint8_t
{
    EFortOptionGenerationResult__NoOptionsGenerated = 0,
    EFortOptionGenerationResult__NewOptionsGenerated = 1,
    EFortOptionGenerationResult__ExistingOptionsGenerated = 2
};

enum EFortObjectiveConversationPlayType : uint8_t
{
    EFortObjectiveConversationPlayType__PlayOnce = 0,
    EFortObjectiveConversationPlayType__Sequential = 1,
    EFortObjectiveConversationPlayType__SequentialLoop = 2,
    EFortObjectiveConversationPlayType__Random = 3
};

enum EPollActorsInVolumeTypes : uint8_t
{
    EPollActorsInVolumeTypes__DesignerPlacedOnly = 0,
    EPollActorsInVolumeTypes__PlayerBuiltOnly = 1,
    EPollActorsInVolumeTypes__All = 2
};

enum EFortEncounterPacingMode : uint8_t
{
    EFortEncounterPacingMode__SpawnPointsPercentageCurve = 0,
    EFortEncounterPacingMode__IntensityCurve = 1,
    EFortEncounterPacingMode__Burst = 2,
    EFortEncounterPacingMode__Fixed = 3
};

enum EFortEncounterSpawnLimitType : uint8_t
{
    EFortEncounterSpawnLimitType__NoLimit = 0,
    EFortEncounterSpawnLimitType__NumPawnsLimit = 1,
    EFortEncounterSpawnLim______r_Vz_o______E____ = 2,
    EFortEncounterSpawnLimitType__UserDefined = 3
};

enum EFortMissionStatus : uint8_t
{
    EFortMissionStatus__Created = 0,
    EFortMissionStatus__InProgress = 1,
    EFortMissionStatus__Succeeded = 2,
    EFortMissionStatus__Failed = 3,
    EFortMissionStatus__NeutralCompletion = 4,
    EFortMissionStatus__Quit = 5,
    EFortMissionStatus__Max_None = 6
};

enum EFortObjectiveRequirement : uint8_t
{
    EFortObjectiveRequirement__Optional = 0,
    EFortObjectiveRequirement__Required = 1,
    EFortObjectiveRequirement__RequiredButCanFail = 2
};

enum EFortMissionType : uint8_t
{
    EFortMissionType__Primary = 0,
    EFortMissionType__Secondary = 1,
    EFortMissionType__Max_None = 2
};

enum EFortMissionAudibility : uint8_t
{
    EFortMissionAudibility__UseVisibility = 0,
    EFortMissionAudibility__Audible = 1,
    EFortMissionAudibility__Inaudible = 2
};

enum ECharacterEncounterType : uint8_t
{
    ECharacterEncounterType__Converstation = 0,
    ECharacterEncounterType__Attack = 1,
    ECharacterEncounterType__Count = 2
};

enum EClientContentReadinessV2 : uint8_t
{
    EClientContentReadinessV2__NotConnected = 0,
    EClientContentReadinessV2__AwaitingServerResponse = 1,
    EClientContentReadinessV2__GeneratingManifests = 2,
    EClientContentReadinessV2__MountingContent = 3,
    EClientContentReadinessV2__LoadedContent = 4,
    EClientContentReadinessV2__ReadyToJoin = 5,
    EClientContentReadinessV2__AllRequestsComplete = 6,
    EClientContentReadinessV2__Disconnecting = 7,
    EClientContentReadinessV2__None = 8
};

enum EServerContentReadinessV2 : uint8_t
{
    EServerContentReadinessV2__Initializing = 0,
    EServerContentReadinessV2__GeneratingManifests = 1,
    EServerContentReadinessV2__WaitingForClient = 2,
    EServerContentReadinessV2__ReadyToJoin = 3,
    EServerContentReadinessV2__Disconnecting = 4
};

enum EContentBeaconHostGlobalState : uint8_t
{
    EContentBeaconHostGlobalState__Initializing = 0,
    EContentBeaconHostGlobalState__Running = 1
};

enum EContentRequestInstallState : uint8_t
{
    EContentRequestInstallState__None = 0,
    EContentRequestInstallState__Initialized = 1,
    EContentRequestInstallState__ManifestsBuilt = 2,
    EContentRequestInstallState__Retrying = 3,
    EContentRequestInstallState__Installed = 4,
    EContentRequestInstallState__HostLoadedClientsInstalled = 5,
    EContentRequestInstallState__HostRootActiveClientsInstalled = 6,
    EContentRequestInstallState__HostActiveClientsInstalled = 7,
    EContentRequestInstallState__Loaded = 8,
    EContentRequestInstallState__RootActive = 9,
    EContentRequestInstallState__Active = 10,
    EContentRequestInstallState__ClientsUninstalled = 11,
    EContentRequestInstallState__Uninstalled = 12,
    EContentRequestInstallState__COMPLETELYLOADED = 10
};

enum EContentBeaconClientState : uint8_t
{
    EContentBeaconClientState__Idl_ = 0,
    EContentBeaconClientState__Cooking = 1,
    EContentBeaconClientState__Downloading = 2
};

enum EInnerErrorType : uint8_t
{
    EInnerErrorType__None = 0,
    EInnerErrorType__ContentServiceError = 1,
    EInnerErrorType__ContentServiceInvalidSourceVersionError = 2,
    EInnerErrorType__ContentSentryUnknownError = 3,
    EInnerErrorType__ProjectDuplicationError = 4,
    EInnerErrorType__CookFailure = 5,
    EInnerErrorType__CookFailureOutOfMemory = 6,
    EInnerErrorType__CookUnknownError = 7,
    EInnerErrorType__CookBadInput = 8,
    EInnerErrorType__StagingFailure = 9,
    EInnerErrorType__Unknown = 10
};

enum EContentBeaconErrorSource : uint8_t
{
    EContentBeaconErrorSource__Unknown = 0,
    EContentBeaconErrorSource__Host = 1,
    EContentBeaconErrorSource__Client = 2
};

enum EContentBeaconErrorResponse : uint8_t
{
    EContentBeaconErrorResponse__None = 0,
    EContentBeaconErrorResponse__DisconnectClient = 1,
    EContentBeaconErrorResponse__CancelRequest = 2,
    EContentBeaconErrorResponse__Shutdown = 3
};

enum EClientsReadyToJoinPhase : uint8_t
{
    EClientsReadyToJoinPhase__Uninitialized = 0,
    EClientsReadyToJoinPhase__WaitingForPlaylistInitialize = 1,
    EClientsReadyToJoinPhase__WaitingForPartyLeader = 2,
    EClientsReadyToJoinPhase__WaitingForLoadContentCall = 3,
    EClientsReadyToJoinPhase__ReadyToJoin = 4
};

enum EFortServerStatus : uint8_t
{
    EFortServerStatus__Launching = 0,
    EFortServerStatus__Idle = 1,
    EFortServerStatus__StartingMode = 2,
    EFortServerStatus__Running = 3,
    EFortServerStatus__ServerTravel = 4,
    EFortServerStatus__ShuttingDown = 5,
    EFortServerStatus__Restarting = 6,
    EFortServerStatus__UpdateCheck = 7
};

enum EFortServerGameMode : uint8_t
{
    EFortServerGameMode__Idle = 0,
    EFortServerGameMode__LobbyPvE = 1,
    EFortServerGameMode__LobbyPvP = 2,
    EFortServerGameMode__ZonePvP = 3,
    EFortServerGameMode__ZonePvE = 4
};

enum EServerRestartReason : uint8_t
{
    EServerRestartReason__HotfixApplied = 0,
    EServerRestartReason__GracefulShutdown = 1,
    EServerRestartReason__BeaconJoinDelayRestart = 2,
    EServerRestartReason__Other = 3
};

enum EFortServerContentRestartReason : uint8_t
{
    EFortServerContentRestartReason__None = 0,
    EFortServerContentRestartReason__CreativeCuratedHubChanged = 1,
    EFortServerContentRestartReason__CreativeFeaturedIslandsChanged = 2,
    EFortServerContentRestartReason__CreativePreloadRevisionChanged = 4,
    EFortServerContentRestartReason__CreativePlaylistConditionalFlagsChanged = 8,
    EFortServerContentRestartReason__GameFeaturePluginDisabled = 16,
    EFortServerContentRestartReason__ForceRestartEventFlagsChanged = 32,
    EFortServerContentRestartReason__ForceRestartFlagActiveStateChanged = 64,
    EFortServerContentRestartReason__PlaylistPreloadHotfixVersionChanged = 128
};

enum EFortGameServiceHotConfigResult : uint8_t
{
    EFortGameServiceHotConfigResult__Success_ReplacedDomain = 0,
    EFortGameServiceHotConfigResult__Success_DomainAlreadySet = 1,
    EFortGameServiceHotConfigResult__Failure_ConfigSectionNotFound = 2,
    EFortGameServiceHotConfigResult__Failure_PlatformNotFound = 3,
    EFortGameServiceHotConfigResult__Failure_GameServiceNotFound = 4,
    EFortGameServiceHotConfigResult__Failure_EpicAppNotFound = 5,
    EFortGameServiceHotConfigResult__Failure_ConfigParsingFailed = 6,
    EFortGameServiceHotConfigResult__Unknown = 7
};

enum ELobbyMissionGeneratorDetailsRequirement : uint8_t
{
    ELobbyMissionGeneratorDetailsRequirement__Unknown = 0,
    ELobbyMissionGeneratorDetailsRequirement__NotRequired = 1,
    ELobbyMissionGeneratorDetailsRequirement__Required = 2
};

enum EFortMatchmakingType : uint8_t
{
    EFortMatchmakingType__Gathering = 0,
    EFortMatchmakingType__CriticalMission = 1,
    EFortMatchmakingType__QuickPlay = 2,
    EFortMatchmakingType__Session = 3
};

enum EFortSTWMatchmakingPrivacyType : uint8_t
{
    EFortSTWMatchmakingPrivacyType__Public = 0,
    EFortSTWMatchmakingPrivacyType__FriendsOnly = 1,
    EFortSTWMatchmakingPrivacyType__Private = 2
};

enum EMatchmakingStartLocation : uint8_t
{
    EMatchmakingStartLocation__Lobby = 0,
    EMatchmakingStartLocation__Game = 1,
    EMatchmakingStartLocation__CreateNew = 2,
    EMatchmakingStartLocation__FindSingle = 3
};

enum EMatchmakingFlags : uint8_t
{
    EMatchmakingFlags__None = 0,
    EMatchmakingFlags__CreateNewOnly = 1,
    EMatchmakingFlags__NoReservation = 2,
    EMatchmakingFlags__Private = 4,
    EMatchmakingFlags__UseWorldDataOwner = 8
};

enum EFortMatchmakingPrivacyConfiguration : uint8_t
{
    EFortMatchmakingPrivacyConfiguration__UserPartyConfigured = 0,
    EFortMatchmakingPrivacyConfiguration__ForcePrivate = 1,
    EFortMatchmakingPrivacyConfiguration__ForcePublic = 2
};

enum EFortMatchmakingPool : uint8_t
{
    EFortMatchmakingPool__Any = 0,
    EFortMatchmakingPool__Desktop = 1,
    EFortMatchmakingPool__PS4 = 2,
    EFortMatchmakingPool__XboxOne = 3,
    EFortMatchmakingPool__Mobile = 4,
    EFortMatchmakingPool__Test = 5,
    EFortMatchmakingPool__Switch = 6,
    EFortMatchmakingPool__Console = 7,
    EFortMatchmakingPool__All = 8
};

enum EIslandQueuePrivacy : uint8_t
{
    EIslandQueuePrivacy__Unrestricted = 0,
    EIslandQueuePrivacy__Public = 1,
    EIslandQueuePrivacy__Private = 2
};

enum EBadMatchType : uint8_t
{
    EBadMatchType__None = 0,
    EBadMatchType__Ping = 1,
    EBadMatchType__Pack_f__H_ = 2,
    EBadMatchType__NotMonitored = 3
};

enum ESocialImportPanelPlatform : uint8_t
{
    ESocialImportPanelPlatform__Facebook = 0,
    ESocialImportPanelPlatform__VK = 1,
    ESocialImportPanelPlatform__Steam = 2,
    ESocialImportPanelPlatform__Xbox = 3,
    ESocialImportPanelPlatform__Playstation = 4,
    ESocialImportPanelPlatform__Switch = 5,
    ESocialImportPanelPlatform__None = 6
};

enum EMcpSubscriptionState : uint8_t
{
    EMcpSubscriptionState__Inactive = 0,
    EMcpSubscriptionState__Active = 1,
    EMcpSubscriptionState__NotAutoRenewable = 2,
    EMcpSubscriptionState__Canceled = 3,
    EMcpSubscriptionState__PaymentProcessError = 4,
    EMcpSubscriptionState__PlatformAuthError = 5,
    EMcpSubscriptionState__RewardsDelayed = 6,
    EMcpSubscriptionState__Unknown = 7
};

enum EPublishStatus : uint8_t
{
    EPublishStatus__Banned = 0,
    EPublishStatus__CannotPublish = 1,
    EPublishStatus__NeedsCreatorName = 2,
    EPublishStatus__CanPublishProvisionally = 3,
    EPublishStatus__CanPublish = 4
};

enum EFortMtxPlatform : uint8_t
{
    EFortMtxPlatform__Epic = 0,
    EFortMtxPlatform__PSN = 1,
    EFortMtxPlatform__Live = 2,
    EFortMtxPlatform__Shared = 3,
    EFortMtxPlatform__EpicPC = 4,
    EFortMtxPlatform__EpicPCKorea = 5,
    EFortMtxPlatform__IOSAppStore = 6,
    EFortMtxPlatform__EpicAndroid = 7,
    EFortMtxPlatform__Nintendo = 8,
    EFortMtxPlatform__WeGame = 9,
    EFortMtxPlatform__Samsung = 10,
    EFortMtxPlatform__GooglePlay = 11,
    EFortMtxPlatform__EpicIOS = 12
};

enum EServerInitializationState : uint8_t
{
    EServerInitializationState__UNINITIALIZED = 0,
    EServerInitializationState__STARTING_UP = 1,
    EServerInitializationState__READY_FOR_PLAYERS = 2
};

enum EFortPartyMemberInGameMode : uint8_t
{
    EFortPartyMemberInGameMode__None = 0,
    EFortPartyMemberInGameMode__InBattleRoyale = 1,
    EFortPartyMemberInGameMode__InCreative = 2,
    EFortPartyMemberInGameMode__InSaveTheWorld = 3
};

enum EFortPartyMemberReadyCheckStatus : uint8_t
{
    EFortPartyMemberReadyCheckStatus__None = 0,
    EFortPartyMemberReadyCheckStatus__InProgress = 1,
    EFortPartyMemberReadyCheckStatus__Complete = 2,
    EFortPartyMemberReadyCheckStatus__Canceled = 3
};

enum ESquadChangeType : uint8_t
{
    ESquadChangeType__JoinSquad = 0,
    ESquadChangeType__BenchSelf = 1,
    ESquadChangeType__UnbenchSelf = 2,
    ESquadChangeType__Swap = 3,
    ESquadChangeType__None = 4
};

enum EPartyMemberVoiceChatStatus : uint8_t
{
    EPartyMemberVoiceChatStatus__Disabled = 0,
    EPartyMemberVoiceChatStatus__Enabled = 1,
    EPartyMemberVoiceChatStatus__PartyVoice = 2,
    EPartyMemberVoiceChatStatus__GameVoice = 3,
    EPartyMemberVoiceChatStatus__PlatformVoice = 4
};

enum EJoinServerState : uint8_t
{
    EJoinServerState__Inactive = 0,
    EJoinServerState__Rejoin = 1,
    EJoinServerState__Tutorial = 2,
    EJoinServerState__Abandon = 3
};

enum EClassRepNodeMapping : uint8_t
{
    NotRouted = 0,
    RelevantAllConnections = 1,
    RelevantAllInsideFortVolume = 2,
    Custom = 3,
    Spatialize_Static = 4,
    Spatialize_Dynamic = 5,
    Spatialize_Dormancy = 6,
    Instance_Dynamic = 7
};

enum EFortDynamicNodeType : uint8_t
{
    EFortDynamicNodeType__AI = 0,
    EFortDynamicNodeType__PhysicsObject = 1,
    EFortDynamicNodeType__Vehicle = 2,
    EFortDynamicNodeType__NumTypes = 3
};

enum ENewsExternalURLMode : uint8_t
{
    ENewsExternalURLMode__PatchNotes = 0,
    ENewsExternalURLMode__UpdateNotes = 1,
    ENewsExternalURLMode__MoreInformation = 2
};

enum EFortRuntimeOptionTabState : uint8_t
{
    EFortRuntimeOptionTabState__Default = 0,
    EFortRuntimeOptionTabState__Disabled = 1,
    EFortRuntimeOptionTabState__Hidden = 2
};

enum EFortRuntimeOptionTabStateTarget : uint8_t
{
    EFortRuntimeOptionTabStateTarget__All = 0,
    EFortRunti_NC____U________h___________q__ = 1,
    EFortRuntimeOptionTabStateTarget__Secondary = 2
};

enum ECrucibleWhitelistOverride : uint8_t
{
    ECrucibleWhitelistOverride__DoNothing = 0,
    ECrucibleWhitelistOverride__ForceOn = 1,
    ECrucibleWhitelistOverride__ForceOff = 2
};

enum EMobileScreenAllowedOrientation : uint8_t
{
    EMobileScreenAllowedOrientation__All = 0,
    EMobileScreenAllowedOrientation__PortraitOnly = 1,
    EMobileScreenAllowedOrientation__LandscapeOnly = 2
};

enum EFortSessionHelperJoinState : uint8_t
{
    EFortSessionHelperJoinState__NotJoining = 0,
    EFortSessionHelperJoinState__RequestingReservation = 1,
    EFortSessionHelperJoinState__FailedReservation = 2,
    EFortSessionHelperJoinState__WaitingOnGame = 3,
    EFortSessionHelperJoinState__AttemptingJoin = 4,
    EFortSessionHelperJoinState__JoiningSession = 5,
    EFortSessionHelperJoinState__FailedJoin = 6,
    EFortSessionHelperJoinState__CanceledJoin = 7
};

enum EJoinPartySource : uint8_t
{
    EJoinPartySource__Sidebar = 0,
    EJoinPartySource__Toast = 1,
    EJoinPartySource__Lobby = 2,
    EJoinPartySource__Discovery = 3,
    EJoinPartySource__RequestToJoin = 4,
    EJoinPartySource__RichPresence = 5,
    EJoinPartySource__RiftPortal = 6,
    EJoinPartySource__CommandLine = 7,
    EJoinPartySource__MAX_NUM = 8
};

enum EInGameReadyCheckStatus : uint8_t
{
    EInGameReadyCheckStatus__None = 0,
    EInGameReadyCheckStatus__Initiated = 1,
    EInGameReadyCheckStatus__Finished = 2
};

enum EFortInvalidActivityReason : uint8_t
{
    EFortInvalidActivityReason__None = 0,
    EFortInvalidActivityReason__PartyTooBig = 1,
    EFortInvalidActivityReason__NotPartyLeader = 2,
    EFortInvalidActivityReason__MatchmakingAlready = 3,
    EFortInvalidActivityReason__PlaylistDisabled = 4,
    EFortInvalidActivityReason__PlayerIsLfg = 5,
    EFortInvalidActivityReason__InvalidData = 6
};

enum EFortPowerRatingComparison : uint8_t
{
    EFortPowerRatingComparison__InRange = 0,
    EFortPowerRatingComparison__OverLevel = 1,
    EFortPowerRatingComparison__UnderLevel = 2,
    EFortPowerRatingComparison__Unknown = 3
};

enum ESendFriendInviteFailureReason : uint8_t
{
    ESendFriendInviteFailureReason__NotFound = 0,
    ESendFriendInviteFailureReason__AlreadyFriends = 1,
    ESendFriendInviteFailureReason__InvitePending = 2,
    ESendFriendInviteFailureReason__AddingSelfFail = 3,
    ESendFriendInviteFailureReason__AddingBlockedFail = 4,
    ESendFriendInviteFailureReason__AutoDeclined = 5,
    ESendFriendInviteFailureReason__BlockedByTarget = 6,
    ESendFriendInviteFailureReason__InviteeInboxFull = 7,
    ESendFriendInviteFailureReason__SelfOutboxFull = 8,
    ESendFriendInviteFailureReason__MissingPin = 9,
    ESendFriendInviteFailureReason__InvalidPin = 10,
    ESendFriendInviteFailureReason__PinAttemptsExceeded = 11,
    ESendFriendInviteFailureReason__UnknownError = 12
};

enum EAcceptFriendInviteFailureReason : uint8_t
{
    EAcceptFriendInviteFailureReason__InviterTooManyFriends = 0,
    EAcceptFriendInviteFailureReason__SelfTooManyFriends = 1,
    EAcceptFriendInviteFailureReason__MissingPin = 2,
    EAcceptFriendInviteFailureReason__InvalidPin = 3,
    EAcceptFriendInviteFailureReason__PinAttemptsExceeded = 4,
    EAcceptFriendInviteFailureReason__UnknownError = 5
};

enum EUnlockGameModeFailureReason : uint8_t
{
    EUnlockGameModeFailureReason__InvalidPin = 0,
    EUnlockGameModeFailureReason__PinAttemptsExceeded = 1,
    EUnlockGameModeFailureReason__UnknownError = 2
};

enum EGenericPinFailureReason : uint8_t
{
    EGenericPinFailureReason__InvalidPin = 0,
    EGenericPinFailureReason__PinAttemptsExceeded = 1,
    EGenericPinFailureReason__UnknownError = 2
};

enum EFortSocialFriendRequestMethod : uint8_t
{
    EFortSocialFriendRequestMethod__LobbySuggestion = 0,
    EFortSocialFriendRequestMethod__LobbyPlayerPanel = 1,
    EFortSocialFriendRequestMethod__MassImportPlatformFriends = 2,
    EFortSocialFriendRequestMethod__AutoImportPlatformFriends = 3,
    EFortSocialFriendRequestMethod__PartyContextRewriteHelper = 4,
    EFortSocialFriendRequestMethod__SocialInteraction_AddFriend = 5,
    EFortSocialFriendRequestMethod__SocialInteraction_AddPlatformFriend = 6
};

enum ERatingsBoard : uint8_t
{
    ERatingsBoard__ESRB = 0,
    ERatingsBoard__PEGI = 1,
    ERatingsBoard__USK = 2,
    ERatingsBoard__GRAC = 3,
    ERatingsBoard__IARC = 4,
    ERatingsBoard__ACB = 5,
    ERatingsBoard__ClassInd = 6,
    ERatingsBoard__Russia = 7,
    ERatingsBoard__CERO = 8,
    ERatingsBoard__FPB = 9,
    ERatingsBoard__GCAM = 10,
    ERatingsBoard__MRO = 11,
    ERatingsBoard__None = 12
};

enum ESupervisedSettingRestrictionReason : uint8_t
{
    ESupervisedSettingRestrictionReason__ParentalLimit = 0,
    ESupervisedSettingRestrictionReason__EnforcedLimit = 1,
    ESupervisedSettingRestrictionReason__None = 2
};

enum ESupervisedSettingScheduleCadence : uint8_t
{
    ESupervisedSettingScheduleCadence__SameWindowsEveryDay = 0,
    ESupervisedSettingScheduleCadence__WindowsByDayOfWeek = 1,
    ESupervisedSettingScheduleCadence__None = 2,
    ESupervisedSettingScheduleCadence__MAX_NUM = 3
};

enum EScoreMatchOperator : uint8_t
{
    EScoreMatchOperator__Invalid = 0,
    EScoreMatchOperator__LessThan = 1,
    EScoreMatchOperator__LessThanOrEqual = 2,
    EScoreMatchOperator__Equal = 3,
    EScoreMatchOperator__GreaterThan = 4,
    EScoreMatchOperator__GreaterThanOrEqual = 5
};

enum EPayoutRewardType : uint8_t
{
    EPayoutRewardType__Invalid = 0,
    EPayoutRewardType__Commerce = 1,
    EPayoutRewardType__GameRelated = 2,
    EPayoutRewardType__Token = 3,
    EPayoutRewardType__Score = 4
};

enum EPayoutScoringType : uint8_t
{
    EPayoutScoringType__Invalid = 0,
    EPayoutScoringType__Points = 1,
    EPayoutScoringType__Ranking = 2,
    EPayoutScoringType__Percentile = 3,
    EPayoutScoringType__Persistent = 4
};

enum EFortressAIType : uint8_t
{
    EFortressAIType__FAT_Dormant = 0,
    EFortressAIType__FAT_Cleaner = 1,
    EFortressAIType__FAT_DayWanderer = 2,
    EFortressAIType__FAT_NightWanderer = 3,
    EFortressAIType__FAT_DebugOnly = 4,
    EFortressAIType__FAT_Encounter = 5
};

enum EFortAILevelRatingDisplayType : uint8_t
{
    EFortAILevelRatingDisplayType__DisplayRatingBasedOnDifficulty = 0,
    EFortAILevelRatingDisplayType__DisplayAIDifficultyAsRating = 1,
    EFortAILevelRatingDisplayType__DontDisplayRating = 2
};

enum EFortPawnStasisMode : uint8_t
{
    EFortPawnStasisMode__None = 0,
    EFortPawnStasisMode__NoMovement = 1,
    EFortPawnStasisMode__NoMovem_____u___s__ = 2,
    EFortPawnStasisMode__NoMovementOrFalling = 3,
    EFortPawnStasisMode__NoMovement_EmotesEnabled = 4,
    EFortPawnStasisMode__NoMovementOrTurning_EmotesEnabled = 5,
    EFortPawnStasisMode__NoMovementOrFalling_EmotesEnabled = 6
};

enum EBodyPartVisibilityGrouping : uint8_t
{
    EBodyPartVisibilityGrouping__AllParts = 0,
    EBodyPartVisibilityGrouping__AllButHead = 1,
    EBodyPartVisibilityGrouping__OnlyBackBling = 2,
    EBodyPartVisibilityGrouping__BackBlingAndCharm = 3,
    EBodyPartVisibilityGrouping__OnlyBody = 4,
    EBodyPartVisibilityGrouping__OnlyHead = 5,
    EBodyPartVisibilityGrouping__OnlyTail = 6
};

enum EFortPartVisibility : uint8_t
{
    EFortPartVisibility__Visible = 0,
    EFortPartVisibility__Hidden = 1,
    EFortPartVisibility__HiddenCastShadow = 2,
    EFortPartVisibility__HiddenFirstPerson = 3
};

enum EZiplineMovementDirection : uint8_t
{
    EZiplineMovementDirection__Unset = 0,
    EZiplineMovementDirection__Forward = 1,
    EZiplineMovementDirection__Backward = 2
};

enum EItemInteractionType : uint8_t
{
    EItemInteractionType__Search = 0,
    EItemInteractionType__LockOnSearch = 1,
    EItemInteractionType__None = 2
};

enum EItemInteractionStatus : uint8_t
{
    EItemInteractionStatus__Interrupted = 0,
    EItemInteractionStatus__Completed = 1,
    EItemInteractionStatus__TimedOut = 2
};

enum EStateOfGetPersistence : uint8_t
{
    EStateOfGetPersistence__NotStarted = 0,
    EStateOfGetPersistence__Failed = 1,
    EStateOfGetPersistence__WaitingToRetry = 2,
    EStateOfGetPersistence__Success = 3,
    EStateOfGetPersistence__InProgress = 4
};

enum EDamageCauserType : uint8_t
{
    Undefined = 0,
    Pickaxe = 1,
    RangedWeapon = 2,
    Fire = 3,
    Vehicle = 4,
    Vehicle_Empty = 5,
    IndirectCauser = 6,
    Inactivation = 7,
    EnteringWater = 8,
    ShockwaveMace = 9,
    Katana = 10,
    ForcePower = 11,
    ODMGear = 12
};

enum EFortPhysicsObjectAwakeState : uint8_t
{
    EFortPhysicsObjectAwakeState__Invalid = 0,
    EFortPhysicsObjectAwakeState__Awake = 1,
    EFortPhysicsObjectAwakeState__Asleep = 2
};

enum EFortPhysicsObjectImpactDamageType : uint8_t
{
    EFortPhysicsObjectImpactDamageType__Environment = 0,
    EFortPhysicsObjectImpactDamageType__Pawn = 1,
    EFortPhysicsObjectImpactDamageType__Vehicle = 2,
    EFortPhysicsObjectImpactDamageType__Wildlife = 3
};

enum EFortPhysicsObjectMovementState : uint8_t
{
    EFortPhysicsObjectMovementState__None = 0,
    EFortPhysicsObjectMovementState__Flying = 1,
    EFortPhysicsObjectMovementState__Rolling = 2,
    EFortPhysicsObjectMovementState__Sliding = 3,
    EFortPhysicsObjectMovementState__Floating = 4
};

enum EFortPhysicsObjectType : uint8_t
{
    EFortPhysicsObjectType__Invalid = 0,
    EFortPhysicsObjectType__StaticObject = 1,
    EFortPhysicsObjectType__PhysicsObject = 2,
    EFortPhysicsObjectType__Vehicle = 3,
    EFortPhysicsObjectType__Pawn = 4,
    EFortPhysicsObjectType__Projectile = 5,
    EFortPhysicsObjectType__Player = 6
};

enum ERepositionAllPlayers : uint8_t
{
    ERepositionAllPlayers__HumanPlayers = 0,
    ERepositionAllPlayers__HumanPlayersAndPlayerBots = 1,
    ERepositionAllPlayers__HumanPlayersAndPlayerBotsAndNPCs = 2,
    ERepositionAllPlayers__AllControllers = 3
};

enum ETestPlayersSetting : uint8_t
{
    ETestPlayersSetting__None = 0,
    ETestPlayersSetting__Fill = 1,
    ETestPlayersSetting__Custom = 2
};

enum ECameraStateRestoreReason : uint8_t
{
    ECameraStateRestoreReason__Unknown = 0,
    ECameraStateRestoreReason__ChangedFollowTarget = 1,
    ECameraStateRestoreReason__ChangedCameraType = 2,
    ECameraStateRestoreReason__InvokedHotKey = 3,
    ECameraStateRestoreReason__Scrubbed = 4,
    ECameraStateRestoreReason__Restored = 5,
    ECameraStateRestoreReason__SpecialAction = 6
};

enum EHighlightReelTypes : uint8_t
{
    EHighlightReelTypes__Generic = 0,
    EHighlightReelTypes__GameSummary = 1,
    EHighlightReelTypes__ExtendedGameSummary = 2,
    EHighlightReelTypes__Builder = 3,
    EHighlightReelTypes__FastMover = 4,
    EHighlightReelTypes__LongDistance = 5,
    EHighlightReelTypes__Multikill = 6,
    EHighlightReelTypes__StormCloud = 7
};

enum EVehicleTrickAxis : uint8_t
{
    EVehicleTrickAxis__X = 0,
    EVehicleTrickAxis__XNeg = 1,
    EVehicleTrickAxis__Y = 2,
    EVehicleTrickAxis__YNeg = 3,
    EVehicleTrickAxis__Z = 4,
    EVehicleTrickAxis__ZNeg = 5,
    EVehicleTrickAxis__Count = 6
};

enum EVehicleTrickType : uint8_t
{
    EVehicleTrickType__None = 0,
    EVehicleTrickType__RollIncrement = 1,
    EVehicleTrickType__ReverseRollIncrement = 2,
    EVehicleTrickType__YawIncrement = 3,
    EVehicleTrickType__ReverseYawIncrement = 4,
    EVehicleTrickType__PitchIncrement = 5,
    EVehicleTrickType__ReversePitchIncrement = 6,
    EVehicleTrickType__HeightIncrement = 7,
    EVehicleTrickType__DistanceIncrement = 8,
    EVehicleTrickType__AirTimeIncrement = 9,
    EVehicleTrickType__ShoppingCart_Flying = 10,
    EVehicleTrickType__ShoppingCart_Stooping = 11,
    EVehicleTrickType__StartedLanding = 12,
    EVehicleTrickType__FailedLanding = 13,
    EVehicleTrickType__Cancelled = 14,
    EVehicleTrickType__StuckLanding = 15,
    EVehicleTrickType__GenericTrick1 = 16,
    EVehicleTrickType__GenericTrick2 = 17,
    EVehicleTrickType__GenericTrick3 = 18,
    EVehicleTrickType__GenericTrick4 = 19,
    EVehicleTrickType__IncrementGenericTrick1 = 20,
    EVehicleTrickType__IncrementGenericTrick2 = 21,
    EVehicleTrickType__IncrementGenericTrick3 = 22,
    EVehicleTrickType__IncrementGenericTrick4 = 23,
    EVehicleTrickType__Count = 24
};

enum ESceneQueryShape : uint8_t
{
    ESceneQueryShape__Sphere = 0,
    ESceneQueryShape__Box = 1,
    ESceneQueryShape__Capsule = 2,
    ESceneQueryShape__VolumeBounds = 3
};

enum EFortPlayspaceUserAcceptanceType : uint8_t
{
    EFortPlayspaceUserAcceptanceType__CustomLogic = 0,
    EFortPlayspaceUserAcceptanceType__Matchmaking = 1,
    EFortPlayspaceUserAcceptanceTyhj______0_I__A_ = 2
};

enum EFortQuestMapNodeType : uint8_t
{
    EFortQuestMapNodeType__MandatoryQuest = 0,
    EFortQuestMapNodeType__SideQuest = 1
};

enum EFortQuestMapNodeLabelPosition : uint8_t
{
    EFortQuestMapNodeLabelPosition__Top = 0,
    EFortQuestMapNodeLabelPosition__Bottom = 1
};

enum ECosmeticType : uint8_t
{
    ECosmeticType__Image = 0,
    ECosmeticType__Widget = 1
};

enum EFortChallengeBundleInfoLockedReasonCode : uint8_t
{
    EFortChallengeBundleInfoLockedReasonCode__Unlocked = 0,
    EFortChallengeBundleInfoLockedReasonCode__NoKnownUnlockMethod = 1,
    EFortChallengeBundleInfoLockedReasonCode__PurchaseTheBattlePass = 2,
    EFortChallengeBundleInfoLockedReasonCode__ReachSpecificTier = 3,
    EFortChallengeBundleInfoLockedReasonCode__TimeLeftBeforeUnlock = 4
};

enum EAcquireIncrementType : uint8_t
{
    EAcquireIncrementType__Single = 0,
    EAcquireIncrementType__HighestMatchingItemCount = 1,
    EAcquireIncrementType__TotalMatchingItemCounts = 2,
    EAcquireIncrementType__UniqueMatchingItems = 3,
    EAcquireIncrementType__TotalItemCount = 4,
    EAcquireIncrementType__UniqueItemCount = 5
};

enum EAcquireProgressType : uint8_t
{
    EAcquireProgressType__ServerOnly = 0,
    EAcquireProgressType__ServerPlusRetroactive = 1,
    EAcquireProgressType__McpEnabled = 2
};

enum EInventoryGatherType : uint8_t
{
    EInventoryGatherType__BrandNew = 0,
    EInventoryGatherType__OldNotPreviouslyGathered = 1,
    EInventoryGatherType__PreviouslyGathered = 2
};

enum EFortCraftObjectiveIncrementType : uint8_t
{
    EFortCraftObjectiveIncrementType__Single = 0,
    EFortCraftObjectiveIncrementType__MatchingIngredientCount = 1,
    EFortCraftObjectiveIncrementType__ItemCount = 2
};

enum EFortInstigatorOwnerHandlingHandling : uint8_t
{
    EFortInstigatorOwnerHandlingHandling__Allowed = 0,
    EFortInstigatorOwnerHandlingHandling__Required = 1,
    EFortInstigatorOwnerHandlingHandling__Prohibited = 2
};

enum EFortShieldGainIncrementType : uint8_t
{
    EFortShieldGainIncrementType__Single = 0,
    EFortShieldGainIncrementType__ShieldGainAmount = 1,
    EFortShieldGainIncrementType__ShieldGainedOverFull = 2,
    EFortShieldGainIncrementType__ShieldGainPercent = 3,
    EFortShieldGainIncrementType__TotalShieldGained = 4
};

enum EFinalBlowAllowance : uint8_t
{
    EFinalBlowAllowance__WhenPassingFilter = 0,
    EFinalBlowAllowance__Always = 1,
    EFinalBlowAllowance__Never = 2
};

enum EFortTrickIncrementType : uint8_t
{
    EFortTrickIncrementType__Single = 0,
    EFortTrickIncrementType__AirDistance = 1,
    EFortTrickIncrementType__AirHeight = 2,
    EFortTrickIncrementType__AirTime = 3,
    EFortTrickIncrementType__TrickCount = 4,
    EFortTrickIncrementType__TrickPoints = 5
};

enum EEliminationKillType : uint8_t
{
    EEliminationKillType__Player = 0,
    EEliminationKillType__NPC = 1,
    EEliminationKillType__Wildlife = 2
};

enum EPlacementAuthorHandling : uint8_t
{
    EPlacementAuthorHandling__Any = 0,
    EPlacementAuthorHandling__RequireAuthorSetPlacement = 1,
    EPlacementAuthorHandling__ProhibitAuthorSetPlacement = 2
};

enum EFortRepairIncrementType : uint8_t
{
    EFortRepairIncrementType__Single = 0,
    EFortRepairIncrementType__RepairAmount = 1,
    EFortRepairIncrementType__PercentRepaired = 2
};

enum EFortMarkerIncrementType : uint8_t
{
    EFortMarkerIncrementType__Single = 0,
    EFortMarkerIncrementType__Distance = 1,
    EFortMarkerIncrementType__StackSize = 2
};

enum EStormStepVerbRequirement : uint8_t
{
    EStormStepVerbRequirement__Any = 0,
    EStormStepVerbRequirement__OnlyStormHolding = 1,
    EStormStepVerbRequirement__OnlyStormShrinking = 2
};

enum EQuestCategorySize : uint8_t
{
    EQuestCategorySize__Small = 0,
    EQuestCategorySize__Wide = 1,
    EQuestCategorySize__Large = 2
};

enum EQuestCategoryProgressReportType : uint8_t
{
    EQuestCategoryProgressReportType__DoNotShow = 0,
    EQuestCategoryProgressReportType__Icons = 1,
    EQuestCategoryProgressReportType__ProgressBar = 2
};

enum ERebootRallyQuestType : uint8_t
{
    ERebootRallyQuestType__Other = 0,
    ERebootRallyQuestType__QRQuest = 1,
    ERebootRallyQuestType__RewardQuest = 2
};

enum EUefnPlaytimeQuestType : uint8_t
{
    EUefnPlaytimeQuestType__Other = 0,
    EUefnPlaytimeQuestType__XP = 1,
    EUefnPlaytimeQuestType__LevelUp = 2
};

enum EAthenaChallengeTimerState : uint8_t
{
    EAthenaChallengeTimerState__Hidden = 0,
    EAthenaChallengeTimerState__WeeksRemaining = 1,
    EAthenaChallengeTimerState__DaysRemaining = 2,
    EAthenaChallengeTimerState__HoursRemaining = 3,
    EAthenaChallengeTimerState__MinutesRemaining = 4,
    EAthenaChallengeTimerState__Urgent = 5
};

enum EAutoFrameMode : uint8_t
{
    EAutoFrameMode__Off = 0,
    EAutoFrameMode__ManualOverride = 1,
    EAutoFrameMode__AutoFrame = 2
};

enum EPegasusTimelineCategories : uint8_t
{
    EPegasusTimelineCategories__Unassigned = 0,
    EPegasusTimelineCategories__Player = 1,
    EPegasusTimelineCategories__Combat = 2,
    EPegasusTimelineCategories__Building = 3,
    EPegasusTimelineCategories__Inventory = 4,
    EPegasusTimelineCategories__Social = 5,
    EPegasusTimelineCategories__Resources = 6
};

enum EVideoManagerStates : uint8_t
{
    EVideoManagerStates__INVALID = 0,
    EVideoManagerStates__LoadingReplay = 1,
    EVideoManagerStates__ScrubbingReplay = 2,
    EVideoManagerStates__WaitingForShotSetup = 3,
    EVideoManagerStates__WatchingShot = 4,
    EVideoManagerStates__ExportingShot = 5,
    EVideoManagerStates__PostExportedShot = 6
};

enum EHighlightSignificances : uint8_t
{
    EHighlightSignificances__NotSignificant = 0,
    EHighlightSignificances__SomewhatSignificant = 1,
    EHighlightSignificances__Significant = 21,
    EHighlightSignificances__VerySignificant = 31,
    EHighlightSignificances__Critical = 41
};

enum EDroneFollowMode : uint8_t
{
    EDroneFollowMode__None = 0,
    EDroneFollowMode__ForceFacingLocation = 1,
    EDroneFollowMode__ForceFacingFollowedPlayer = 2,
    EDroneFollowMode__TetherToFollowedPlayer = 3
};

enum EEventMatchScreen : uint8_t
{
    EEventMatchScreen__None = 0,
    EEventMatchScreen__MatchStatus = 1,
    EEventMatchScreen__Scoreboard = 2
};

enum EDroneFacingLocationMode : uint8_t
{
    EDroneFacingLocationMode__NotFacingLocation = 0,
    EDroneFacingLocationMode__FindingPoint = 1,
    EDroneFacingLocationMode__TrackingPoint = 2
};

enum EDroneFocusActorMode : uint8_t
{
    EDroneFocusActorMode__NoActor = 0,
    EDroneFocusActorMode__FindingActor = 1,
    EDroneFocusActorMode__TrackingActor = 2
};

enum ESaveLocation : uint8_t
{
    ESaveLocation__Local_ForDevice = 0
};

enum EScriptedActionStatus : uint8_t
{
    EScriptedActionStatus__Pending = 0,
    EScriptedActionStatus__Running = 1,
    EScriptedActionStatus__Completed = 2
};

enum EAudioAnalysisParameterType : uint8_t
{
    EAudioAnalysisParameterType__Scalar = 0,
    EAudioAnalysisParameterType__Vector4 = 1,
    EAudioAnalysisParameterType__Count = 2
};

enum EVectorCurveFloat : uint8_t
{
    EVectorCurveFloat__VectorCurve_X = 0,
    EVectorCurveFloat__VectorCurve_Y = 1,
    EVectorCurveFloat__VectorCurve_Z = 2
};

enum EFortFeedbackContext : uint8_t
{
    FFC_Instigator = 0,
    FFC_Recipient = 1,
    FFC_TeamWitness = 2,
    FFC_EnemyWitness = 3,
    FFC_AllPawns = 4,
    FFC_Announcer = 5,
    FFC_None_Max = 6
};

enum EFortFeedbackAddressee : uint8_t
{
    FFA_Instigator = 0,
    FFA_Recipient = 1,
    FFA_All = 2
};

enum EFortFeedbackSelectionMethod : uint8_t
{
    FFSM_Instigator = 0,
    FFSM_Recipient = 1,
    FFSM_TeamWitness = 2,
    FFSM_E__i4_g___ = 3,
    FFSM_Random = 4,
    FFSM_Priority_IRTE = 5,
    FFSM_AllPawns = 6,
    FFSM_Announcer = 7
};

enum EFortFeedbackBroadcastFilter : uint8_t
{
    FFBF_Speaker = 0,
    FFBF_SpeakerTeam = 1,
    FFBF_SpeakerAdressee = 2,
    FFBF_HumanPvP_Team1 = 3,
    FFBF_HumanPvP_Team2 = 4,
    FFBF_None_Max = 5
};

enum EFortFootstepAudioType : uint8_t
{
    EFortFootstepAudioType__Crouch = 0,
    EFortFootstepAudioType__CrouchSprint = 1,
    EFortFootstepAudioType__Walk = 2,
    EFortFootstepAudioType__Sprint = 3,
    EFortFootstepAudioType__Jump = 4,
    EFortFootstepAudioType__Land = 5,
    EFortFootstepAudioType__LandHard = 6,
    EFortFootstepAudioType__Max_None = 7
};

enum EFortFootstepPosition : uint8_t
{
    EFortFootstepPosition__Parallel = 0,
    EFortFootstepPosition__Above = 1,
    EFortFootstepPosition__Below = 2,
    EFortFootstepPosition__AboveOrBelowAndVisible = 3,
    EFortFootstepPosition__Max_None = 4
};

enum ELayeredAudioInterpolationType : uint8_t
{
    ELayeredAudioInterpolationType__None = 0,
    ELayeredAudioInterpolationType__CustomCurve = 1,
    ELayeredAudioInterpolationType__Linear = 2
};

enum EFortAnnouncerTeamVocalChords : uint8_t
{
    EFortAnnouncerTeamVocalChords__Team1 = 0,
    EFortAnnouncerTeamVocalChords__Team2 = 1,
    EFortAnnouncerTeamVocalChords__Max_None = 2
};

enum ESkeletalAudioBoneEvent : uint8_t
{
    ESkeletalAudioBoneEvent__None = 0,
    ESkeletalAudioBoneEvent__SlowThresholdStart = 1,
    ESkeletalAudioBoneEvent__SlowThresholdStop = 2,
    ESkeletalAudioBoneEvent__MediumThreshold = 3,
    ESkeletalAudioBoneEvent__FastThreshold = 4
};

enum ESkeletalAudioBoneSpace : uint8_t
{
    ESkeletalAudioBoneSpace__Relative = 0,
    ESkeletalAudioBoneSpace__World = 1
};

enum ESkeletalAudioBoneVelocityType : uint8_t
{
    ESkeletalAudioBoneVelocityType__Linear = 0,
    ESkeletalAudioBoneVelocityType__Rotational = 1,
    ESkeletalAudioBoneVelocityType__Custom = 2
};

enum EFortHitNotifyAudioType : uint8_t
{
    EFortHitNotifyAudioType__Invalid = 0,
    EFortHitNotifyAudioType__Body = 1,
    EFortHitNotifyAudioType__BodyCrit = 2,
    EFortHitNotifyAudioType__Shield = 3,
    EFortHitNotifyAudioType__ShieldCrit = 4,
    EFortHitNotifyAudioType__Death = 5,
    EFortHitNotifyAudioType__DeathCrit = 6,
    EFortHitNotifyAudioType__Fall = 7,
    EFortHitNotifyAudioType__FallDeath = 8
};

enum ESplineWaterAudioWindingOrder : uint8_t
{
    ESplineWaterAudioWindingOrder__Clockwise = 0,
    ESplineWaterAudioWindingOrder__Counterclockwise = 1
};

enum ESplineWaterAudioFacingDirection : uint8_t
{
    ESplineWaterAudioFacingDirection__None = 0,
    ESplineWaterAudioFacingDirection__Inwards = 1,
    ESplineWaterAudioFacingDirection__Outwards = 2
};

enum EFortSwimmingAudioType : uint8_t
{
    EFortSwimmingAudioType__Normal = 0,
    EFortSwimmingAudioType__Sprint = 1,
    EFortSwimmingAudioType__SprintStart = 2,
    EFortSwimmingAudioType__PickaxeSwing = 3,
    EFortSwimmingAudioType__NormalDBNO = 4,
    EFortSwimmingAudioType__SprintBoostStart = 5,
    EFortSwimmingAudioType__SwimStart = 6,
    EFortSwimmingAudioType__SwimEnd = 7,
    EFortSwimmingAudioType__Max_None = 8
};

enum EVehicleAudioInterpolationType : uint8_t
{
    EVehicleAudioInterpolationType__None = 0,
    EVehicleAudioInterpolationType__CustomCurve = 1,
    EVehicleAudioInterpolationType__Linear = 2
};

enum EVehicleAudioTriggerDir : uint8_t
{
    EVehicleAudioTriggerDir__Forward = 0,
    EVehicleAudioTriggerDir__Backward = 1
};

enum EFortMusicSectionStopBehavior : uint8_t
{
    EFortMusicSectionStopBehavior__Crossfade = 0,
    EFortMusicSectionStopBehavior__AllowFadeOut = 1
};

enum EFortMusicCombatIntensity : uint8_t
{
    EFortMusicCombatIntensity__Low = 0,
    EFortMusicCombatIntensity__Medium = 1,
    EFortMusicCombatIntensity__High = 2,
    EFortMusicCombatIntensity__VeryHigh = 3,
    EFortMusicCombatIntensity__Max_None = 4
};

enum EMusicFadeStyles : uint8_t
{
    EMusicFadeStyles__CrossFade = 0,
    EMusicFadeStyles__FadeOutThenIn = 1,
    EMusicFadeStyles__Max_None = 2
};

enum EMusicChannel : uint8_t
{
    EMusicChannel__VoiceA = 0,
    EMusicChannel__VoiceB = 1,
    EMusicChannel__Max_None = 2
};

enum EStatTeamAggregateFunction : uint8_t
{
    EStatTeamAggregateFunction__Add = 0,
    EStatTeamAggregateFunction__Max = 1,
    EStatTeamAggregateFunction__Min = 2
};

enum EQueueActionType : uint8_t
{
    EQueueActionType__Plot = 0,
    EQueueActionType__ZoneCleanup = 1,
    EQueueActionType__EnvironmentActorRestoration = 2
};

enum EDefenderSpawnFailureReason : uint8_t
{
    EDefenderSpawnFailureReason__None = 0,
    EDefenderSpawnFailureReason__AllPlayerSlotsFull = 1,
    EDefenderSpawnFailureReason__DefendersNotUnlocked = 2,
    EDefenderSpawnFailureReason__CurrentlySimulatingDefender = 3,
    EDefenderSpawnFailureReason__NotOutpostOwner = 4
};

enum ECollectionSelectionMethod : uint8_t
{
    ECollectionSelectionMethod__TierAsIndex = 0,
    ECollectionSelectionMethod__TierAsIndexOverflowToLastValid = 1,
    ECollectionSelectionMethod__Modulo = 2,
    ECollectionSelectionMethod__Random = 3,
    ECollectionSelectionMethod__None = 4
};

enum ESpecializationType : uint8_t
{
    ESpecializationType__Tier1 = 0,
    ESpecializationType__Tier2 = 1,
    ESpecializationType__Tier3 = 2,
    ESpecializationType__Tier4 = 3,
    ESpecializationType__NumTiers = 4
};

enum EFortHeroLoadoutPerkType : uint8_t
{
    EFortHeroLoadoutPerkType__Commander = 0,
    EFortHeroLoadoutPerkType__Standard = 1
};

enum EFortSupportBonusType : uint8_t
{
    EFortSupportBonusType__Normal = 0,
    EFortSupportBonusType__Tactical = 1,
    EFortSupportBonusType__Max_None = 2
};

enum EFortHomebaseSquadType : uint8_t
{
    EFortHomebaseSquadType__AttributeSquad = 0,
    EFortHomebaseSquadType__CombatSquad = 1,
    EFortHomebaseSquadType__DefenderSquad = 2,
    EFortHomebaseSquadType__ExpeditionSquad = 3,
    EFortHomebaseSquadType__Max_None = 4
};

enum ESquadSlotType : uint8_t
{
    ESquadSlotType__HeroSquadMissionDefender = 0,
    ESquadSlotType__SurvivorSquadLeadSurvivor = 1,
    ESquadSlotType__SurvivorSquadSurvivor = 2,
    ESquadSlotType__DefenderSquadMember = 3,
    ESquadSlotType__ExpeditionSquadMember = 4
};

enum EFortDefenderSubtype : uint8_t
{
    EFortDefenderSubtype__AssaultRifle = 0,
    EFortDefenderSubtype__Pistol = 1,
    EFortDefenderSubtype__Melee = 2,
    EFortDefenderSubtype__Sniper = 3,
    EFortDefenderSubtype__Shotgun = 4,
    EFortDefenderSubtype__Invalid = 5
};

enum EHomebaseNodeType : uint8_t
{
    EHomebaseNodeType__Gadget = 0,
    EHomebaseNodeType__Utility = 1,
    EHomebaseNodeType__Hidden = 2
};

enum EFortStatType : uint8_t
{
    EFortStatType__Fortitude = 0,
    EFortStatType__Offense = 1,
    EFortStatType__Resistance = 2,
    EFortStatType__Technology = 3,
    EFortStatType__Fortitude_Team = 4,
    EFortStatType__Offense_Team = 5,
    EFortStatType__Resistance_Team = 6,
    EFortStatType__Technology_Team = 7,
    EFortStatType__Invalid = 8
};

enum EFortUIScoreType : uint8_t
{
    EFortUIScoreType__Combat = 0,
    EFortUIScoreType__Building = 1,
    EFortUIScoreType__Utility = 2,
    EFortUIScoreType__Badges = 3,
    EFortUIScoreType__Bonus = 4,
    EFortUIScoreType__Total = 5,
    EFortUIScoreType__Max_None = 6
};

enum EFortHexTileAdjacency : uint8_t
{
    EFortHexTileAdjacency__North = 0,
    EFortHexTileAdjacency__NorthEast = 1,
    EFortHexTileAdjacency__SouthEast = 2,
    EFortHexTileAdjacency__South = 3,
    EFortHexTileAdjacency__SouthWest = 4,
    EFortHexTileAdjacency__NorthWest = 5,
    EFortHexTileAdjacency__Max_None = 6
};

enum EFortTheaterMapTileType : uint8_t
{
    EFortTheaterMapTileType__Normal = 0,
    EFortTheaterMapTileType__CriticalMission = 1,
    EFortTheaterMapTileType__AlwaysActive = 2,
    EFortTheaterMapTileType__Outpost = 3,
    EFortTheaterMapTileType__NonMission = 4,
    EFortTheaterMapTileType__PvPFOB = 5
};

enum EFortMissionQuestValidityResult : uint8_t
{
    EFortMissionQuestValidityResult__Invalid = 0,
    EFortMissionQuestValidityResult__InvalidNotPlayable = 1,
    EFortMissionQuestValidityResult__ValidLinked = 2,
    EFortMissionQuestValidityResult__ValidObjectiveCondition = 3,
    EFortMissionQuestValidityResult__ValidFallback = 4
};

enum EFortMapNavigationDirection : uint8_t
{
    EFortMapNavigationDirection__North = 0,
    EFortMapNavigationDirection__NorthEast = 1,
    EFortMapNavigationDirection__East = 2,
    EFortMapNavigationDirection__SouthEast = 3,
    EFortMapNavigationDirection__South = 4,
    EFortMapNavigationDirection__SouthWest = 5,
    EFortMapNavigationDirection__West = 6,
    EFortMapNavigationDirection__NorthWest = 7,
    EFortMapNavigationDirection__Invalid = 8
};

enum ETasksOverFramesSchedulePriorityCategory : uint8_t
{
    ETasksOverFramesSchedulePriorityCategory__Default = 0,
    ETasksOverFramesSchedulePriorityCategory__CharacterCustomization = 1
};

enum EFortAutoTestState : uint8_t
{
    EFortAutoTestState__InitialLoad = 0,
    EFortAutoTestState__Login = 1,
    EFortAutoTestState__FrontendLoad = 2,
    EFortAutoTestState__FrontendPvELoad = 3,
    EFortAutoTestState__FrontendPvETest = 4,
    EFortAutoTestState__PvEMatchmaking = 5,
    EFortAutoTestState__ZoneLoad = 6,
    EFortAutoTestState__ZoneTest = 7,
    EFortAutoTestState__Finished = 8
};

enum EProfileGoState : uint8_t
{
    EProfileGoState__None = 0,
    EProfileGoState__StartingRequest = 1,
    EProfileGoState__SettlingLocation = 2,
    EProfileGoState__RunningCommands = 3,
    EProfileGoState__CompletedScenario = 4,
    EProfileGoState__Summary = 5,
    EProfileGoState__Completed = 6
};

enum ETrackDirection : uint8_t
{
    ETrackDirection__YNegative = 0,
    ETrackDirection__XPositive = 1,
    ETrackDirection__YPositive = 2,
    ETrackDirection__XNegative = 3,
    ETrackDirection__Max_None = 4
};

enum ETrackPieceType : uint8_t
{
    ETrackPieceType__None = 0,
    ETrackPieceType__Straight = 1,
    ETrackPieceType__Turn = 2,
    ETrackPieceType__TShape = 3,
    ETrackPieceType__Cross = 4,
    ETrackPieceType__Max_None = 5
};

enum ETrackIncline : uint8_t
{
    ETrackIncline__NoNeighbor = 0,
    ETrackIncline__Flat = 1,
    ETrackIncline__Up = 2,
    ETrackIncline__Down = 3,
    ETrackIncline__GradualUp = 4,
    ETrackIncline__GradualDown = 5,
    ETrackIncline__Max_None = 6
};

enum EFortStatDisplayType : uint8_t
{
    EFortStatDisplayType__Category = 0,
    EFortStatDisplayType__Buff = 1,
    EFortStatDisplayType__Debuff = 2,
    EFortStatDisplayType__Neutral = 3,
    EFortStatDisplayType__DoNotDisplay = 4
};

enum EFortActorIndicatorContainerWidget : uint8_t
{
    EFortActorIndicatorContainerWidget__Top = 0,
    EFortActorIndicatorContainerWidget__Middle = 1,
    EFortActorIndicatorContainerWidget__Bottom = 2
};

enum EPinModalType : uint8_t
{
    EPinModalType__AcceptFriendRequest = 0,
    EPinModalType__SendFriendRequest = 1,
    EPinModalType__UnlockGameModeRequest = 2,
    EPinModalType__OpenParentalControlsRequest = 3,
    EPinModalType__PurchaseRequest = 4,
    EPinModalType__AddCilantroRequest = 5
};

enum EFortTipDisplayPlatformGroup : uint8_t
{
    EFortTipDisplayPlatformGroup__None = 0,
    EFortTipDisplayPlatformGroup__Desktop = 1,
    EFortTipDisplayPlatformGroup__Console = 2,
    EFortTipDisplayPlatformGroup__Switch = 4,
    EFortTipDisplayPlatformGroup__Mobile = 8,
    EFortTipDisplayPk_C__b_______j_O______b_4Dwt____c_T_________N_ = 9
};

enum EFortUIFriendNotificationType : uint8_t
{
    EFortUIFriendNotificationType__Default = 0,
    EFortUIFriendNotificationType__FriendRequest = 1,
    EFortUIFriendNotificationType__PartyInviteSent = 2,
    EFortUIFriendNotificationType__PartyInvite = 3,
    EFortUIFriendNotificationType__InviteFriendToParty = 4,
    EFortUIFriendNotificationType__PartyRequest = 5,
    EFortUIFriendNotificationType__AutoImportFriendSuggestion = 6,
    EFortUIFriendNotificationType__PartyMemberCreated = 7,
    EFortUIFriendNotificationType__PartyMemberLeft = 8
};

enum EFortUIManagerFeatureRequest : uint8_t
{
    EFortUIManagerFeatureRequest__TimeLimitsSidebar = 0,
    EFortUIManagerFeatureRequest__None = 1
};

enum EFortContextualReticleTypes : uint8_t
{
    FCR_GenericFailure = 0,
    FCR_Upgrade = 1,
    FCR_Repair = 2,
    FCR_Locked = 3,
    FCR_Placement = 4,
    FCR_Edit = 5,
    FCR_NoTarget = 6,
    FCR_InProgress = 7,
    FCR_None = 8
};

enum EForLockerCategorySlotPriority : uint8_t
{
    EForLockerCategorySlotPriority__Primary = 0,
    EForLockerCategorySlotPriority__Secondary = 1,
    EForLockerCategorySlotPriority__Tertiary = 2
};

enum EFortItemShopTileImageRuleset : uint8_t
{
    EFortItemShopTileImageRuleset__Default = 0,
    EFortItemShopTileImageRuleset__ScaledStandard = 1,
    EFortItemShopTileImageRuleset__ScaledHalfStep = 2,
    EFortItemShopTileImageRuleset__Bundle = 3,
    EFortItemShopTileImageRuleset__FullSquare = 4,
    EFortItemShopTileImageRuleset__Basic = 5,
    EFortItemShopTileImageRuleset__ScaledFull = 6
};

enum EDeployableBaseUseType : uint8_t
{
    EDeployableBaseUseType__Neighborhood = 0,
    EDeployableBaseUseType__PvECombat = 1
};

enum EFortMiniMapHeight : uint8_t
{
    EFMH_Equal = 0,
    EFMH_Below = 1,
    EFMH_Above = 2
};

enum EFortMiniMapContext : uint8_t
{
    EFMC_MiniMap = 0,
    EFMC_FullScreenMap = 1
};

enum EFortMiniMapIconRotation : uint8_t
{
    EFMMIR_None = 0,
    EFMMIR_Absolute = 1,
    EFMMIR_Relative = 2
};

enum ELayoutDataType : uint8_t
{
    ELayoutDataType__Custom = 0,
    ELayoutDataType__DefaultToolLayout = 1,
    ELayoutDataType__DefaultGameLayout = 2,
    ELayoutDataType__MAX_Local = 3,
    ELayoutDataType__CustomCloudLayout = 4
};

enum EUnicornSocialFeatures : uint8_t
{
    EUnicornSocialFeatures__INVALID = 0,
    EUnicornSocialFeatures__FriendPlay = 1,
    EUnicornSocialFeatures__DancePartyManpower = 2,
    EUnicornSocialFeatures__CongaLineManpower = 3,
    EUnicornSocialFeatures__SocialPartyDuration = 4,
    EUnicornSocialFeatures__COUNT = 5
};

enum EHighlightReelIds : uint8_t
{
    EHighlightReelIds__INVALID = 0,
    EHighlightReelIds__MainHighlightReel = 1,
    EHighlightReelIds__ShortHighlightReel = 2,
    EHighlightReelIds__MicroHighlights = 3,
    EHighlightReelIds__EntireGameReel = 4,
    EHighlightReelIds__ShortExtendedHighlightReel = 5,
    EHighlightReelIds__MediumHighlightReel = 6,
    EHighlightReelIds__MediumExtendedHighlightReel = 7,
    EHighlightReelIds__ShorterHighlightReel = 8,
    EHighlightReelIds__PlayerSpotlightReel = 9,
    EHighlightReelIds__PlayerSpotlightNoDeathsReel = 10,
    EHighlightReelIds__VATReel = 11,
    EHighlightReelIds__COUNT = 12
};

enum EFortExposedAssetPathCustomizationType : uint8_t
{
    EFortExposedAssetPathCustomizationType__FullPath = 0,
    EFortExposedAssetPathCustomizationType__RelativeTo = 1,
    EFortExposedAssetPathCustomizationType__NameOnly = 2
};

enum ETreadSide : uint8_t
{
    ETreadSide__Invalid = 0,
    ETreadSide__Left = 1,
    ETreadSide__Right = 2
};

enum EVelocityUnits : uint8_t
{
    EVelocityUnits__CentimetersPerSecond = 0,
    EVelocityUnits__KilometersPerHour = 1
};

enum EModExecResult : uint8_t
{
    EModExecResult__Valid = 0,
    EModExecResult__Invalid = 1
};

enum EModDependantBGAUpdate : uint8_t
{
    EModDependantBGAUpdate__None = 0,
    EModDependantBGAUpdate__Add = 1,
    EModDependantBGAUpdate__Remove = 2
};

enum EWrapPreviewCamera : uint8_t
{
    EWrapPreviewCamera__Weapon = 0,
    EWrapPreviewCamera__LargeWeapon = 1,
    EWrapPreviewCamera__Vehicle = 2
};

enum EFortDisplayTier : uint8_t
{
    EFortDisplayTier__Invalid = 0,
    EFortDisplayTier__Handmade = 1,
    EFortDisplayTier__Copper = 2,
    EFortDisplayTier__Silver = 3,
    EFortDisplayTier__Malachite = 4,
    EFortDisplayTier__Obsidian = 5,
    EFortDisplayTier__Brightcore = 6,
    EFortDisplayTier__Spectrolite = 7,
    EFortDisplayTier__Shadowshard = 8,
    EFortDisplayTier__Sunbeam = 9,
    EFortDisplayTier__Moonglow = 10
};

enum EFortMeleeFX : uint8_t
{
    EFortMeleeFX__Idle = 0,
    EFortMeleeFX__Swing = 1,
    EFortMeleeFX__AnimTrail = 2
};

enum EHitTraceType : uint8_t
{
    EHitTraceType__Single = 0,
    EHitTraceType__Multi = 1
};

enum EBuildingAsPropSetting : uint8_t
{
    EBuildingAsPropSetting__None = 0,
    EBuildingAsPropSetting__SnapToEdge = 1,
    EBuildingAsPropSetting__SnapToCenter = 2
};

enum EFortReloadMontageSection : uint8_t
{
    EFortReloadMontageSection__Intro = 0,
    EFortReloadMontageSection__Loop = 1,
    EFortReloadMontageSection__Outro = 2
};

enum EProjectileWaterHitBehavior : uint8_t
{
    EProjectileWaterHitBehavior__Overlap = 0,
    EProjectileWaterHitBehavior__StopIfStopSimulatingOnHit = 1,
    EProjectileWaterHitBehavior__StopOnOverlap = 2
};

enum EDefaultCharacterSelection : uint8_t
{
    EDefaultCharacterSelection__Random = 0,
    EDefaultCharacterSelection__DefaultBase = 1,
    EDefaultCharacterSelection__EDefaultCharacterS________4_Ta = 2
};

enum EAIVisibilityOptions : uint8_t
{
    EAIVisibilityOptions__None = 0,
    EAIVisibilityOptions__AlwaysHidden = 1,
    EAIVisibilityOptions__AlwaysVisible = 2,
    EAIVisibilityOptions__HiddenWhenIdle = 4,
    EAIVisibilityOptions__HiddenWhenCrouched = 8,
    EAIVisibilityOptions__HiddenWhenIdleAndCrouched = 12,
    EAIVisibilityOptions__VisibleWhenOverlappingPerceivedActor = 16,
    EAIVisibilityOptions__CheckPriorVisibility = 32
};

enum EBotNamingMode : uint8_t
{
    EBotNamingMode__RealName = 0,
    EBotNamingMode__SkinName = 1,
    EBotNamingMode__Anonymous = 2,
    EBotNamingMode__Custom = 3,
    EBotNamingMode__CharacterDataDisplayName = 4,
    EBotNamingMode__CustomIncremental = 5
};

enum ECustomNavLinkProcessorResult : uint8_t
{
    ECustomNavLinkProcessorResult__Unhandled = 0,
    ECustomNavLinkProcessorResult__Success = 1,
    ECustomNavLinkProcessorResult__Failure = 2
};

enum EFortEncounterUtilityDesire : uint8_t
{
    EFortEncounterUtilityDesire__Low = 0,
    EFortEncounterUtilityDesire__Medium = 1,
    EFortEncounterUtilityDesire__High = 2,
    EFortEncounterUtilityDesire__VeryHigh = 3,
    EFortEncounterUtilityDesire__Max_None = 4
};

enum EPawnBindingType : uint8_t
{
    EPawnBindingType__None = 0,
    EPawnBindingType__AISpawnerDevice = 1,
    EPawnBindingType__NPCCharacterDefinitionReplaceable = 2
};

enum EAIHotSpotSlotFilter : uint8_t
{
    EAIHotSpotSlotFilter__All = 0,
    EAIHotSpotSlotFilter__AvailableOnly = 1,
    EAIHotSpotSlotFilter__UnavailableOnly = 2
};

enum EAIHotSpotAssignmentFilter : uint8_t
{
    EAIHotSpotAssignmentFilter__All = 0,
    EAIHotSpotAssignmentFilter__WithSlots = 1,
    EAIHotSpotAssignmentFilter__WaitingList = 2
};

enum EAIHotSpotSlot : uint8_t
{
    EAIHotSpotSlot__Free = 0,
    EAIHotSpotSlot__Claimed = 1,
    EAIHotSpotSlot__Occupied = 2,
    EAIHotSpotSlot__Blocked = 3,
    EAIHotSpotSlot__Disabled = 4
};

enum EAthenaPathFollowingFocus : uint8_t
{
    EAthenaPathFollowingFocus__TowardsNextPathPoint = 0,
    EAthenaPathFollowingFocus__AlignWithSmoothedVelocity = 1
};

enum EAthenaAITelemetryEventType : uint8_t
{
    EAthenaAITelemetryEventType__Spawn = 0,
    EAthenaAITelemetryEventType__Despawn = 1
};

enum EAICustomTargetRequestType : uint8_t
{
    EAICustomTargetRequestType__Movement = 1,
    EAICustomTargetRequestType__MeleeAttack = 2,
    EAICustomTargetRequestType__RangedAttack = 4
};

enum EDespawnAIType : uint8_t
{
    EDespawnAIType__Relevancy = 0,
    EDespawnAIType__Distance = 1
};

enum EFortAIDirectorEventContribution : uint8_t
{
    EFortAIDirectorEventContribution__Increment = 0,
    EFortAIDirectorEventContribution__Set = 1
};

enum EFortAIDirectorFactorContribution : uint8_t
{
    EFortAIDirectorFactorContribution__Direct = 0,
    EFortAIDirectorFactorContribution__Inverse = 1
};

enum EFortEncounterPacingState : uint8_t
{
    EFortEncounterPacingState__Ramp = 0,
    EFortEncounterPacingState__Peak = 1,
    EFortEncounterPacingState__Fade = 2,
    EFortEncounterPacingState__Rest = 3,
    EFortEncounterPacingState__Max_None = 4
};

enum EFortEncounterState : uint8_t
{
    EFortEncounterState__Uninitialized = 0,
    EFortEncounterState__InitializingProperties = 1,
    EFortEncounterState__InitializingRiftManager = 2,
    EFortEncounterState__AwaitingActivation = 3,
    EFortEncounterState__Active = 4,
    EFortEncounterState__ReplacingRifts = 5,
    EFortEncounterState__Max_None = 6
};

enum EFortAIWaveProgressSection : uint8_t
{
    EFortAIWaveProgressSection__SectionOne = 0,
    EFortAIWaveProgressSection__SectionTwo = 1,
    EFortAIWaveProgressSection__Max_None = 2,
    EFortAIWaveProgressSection__EFortAIWaveProgr_______Y_____C = 3
};

enum EFortEncounterSequenceResult : uint8_t
{
    EFortEncounterSequenceResult__Success = 0,
    EFortEncounterSequenceResult__FailedEncounterInProgress = 1,
    EFortEncounterSequenceResult__Failed = 2
};

enum EAssignmentCreationResult : uint8_t
{
    EAssignmentCreationResult__AssignmentNotFoundOrCreated = 0,
    EAssignmentCreationResult__AssignmentCreated = 1,
    EAssignmentCreationResult__AssignmentFound = 2
};

enum ECorePerceptionTypes : uint8_t
{
    ECorePerceptionTypes__Sight = 0,
    ECorePerceptionTypes__Hearing = 1,
    ECorePerceptionTypes__Damage = 2,
    ECorePerceptionTypes__Touch = 3,
    ECorePerceptionTypes__Team = 4,
    ECorePerceptionTypes__Prediction = 5
};

enum ECorePerceptionTypesBitmask : uint8_t
{
    ECorePerceptionTypesBitmask__Sight = 1,
    ECorePerceptionTypesBitmask__Hearing = 2,
    ECorePerceptionTypesBitmask__Damage = 4,
    ECorePerceptionTypesBitmask__Touch = 8,
    ECorePerceptionTypesBitmask__Team = 16,
    ECorePerceptionTypesBitmask__Prediction = 32,
    ECorePerceptionTypesBitmask__All = -1
};

enum EAssignmentType : uint8_t
{
    EAssignmentType__Invalid = 0,
    EAssignmentType__Encounter = 1,
    EAssignmentType__World = 2,
    EAssignmentType__Enemy = 3,
    EAssignmentType__NumAssignmentTypes = 4
};

enum EBuildingWallArea : uint8_t
{
    EBuildingWallArea__Regular = 0,
    EBuildingWallArea__Flat = 1,
    EBuildingWallArea__Special = 2
};

enum EBuildingStairsRailing : uint8_t
{
    EBuildingStairsRailing__None = 0,
    EBuildingStairsRailing__Partial = 1,
    EBuildingStairsRailing__Full = 2
};

enum EBuildingFloorRailing : uint8_t
{
    EBuildingFloorRailing__None = 0,
    EBuildingFloorRailing__Balcony = 1
};

enum EFortHotSpotSlot : uint8_t
{
    EFortHotSpotSlot__Melee = 0,
    EFortHotSpotSlot__MeleeHuge = 1,
    EFortHotSpotSlot__Ranged = 2,
    EFortHotSpotSlot__None = 3
};

enum EFortHotSpotDirection : uint8_t
{
    EFortHotSpotDirection__PositiveX = 0,
    EFortHotSpotDirection__NegativeX = 1,
    EFortHotSpotDirection__PositiveY = 2,
    EFortHotSpotDirection__NegativeY = 3,
    EFortHotSpotDirection__PositiveZ = 4,
    EFortHotSpotDirection__NegativeZ = 5,
    EFortHotSpotDirection__Any = 6
};

enum EFortHotSpotPreview : uint8_t
{
    EFortHotSpotPreview__None = 0,
    EFortHotSpotPreview__Smashing = 1,
    EFortHotSpotPreview__Shooting = 2
};

enum EHotspotTypeConfigMode : uint8_t
{
    EHotspotTypeConfigMode__AlwaysAdd = 0,
    EHotspotTypeConfigMode__WhenNotDefined = 1,
    EHotspotTypeConfigMode__WhenNotValid = 2
};

enum EFortPartialPathUsage : uint8_t
{
    EFortPartialPathUsage__Always = 0,
    EFortPartialPathUsage__OnlyGoalsOnDestructible = 1,
    EFortPartialPathUsage__Never = 2
};

enum ETargetDistanceComparisonType : uint8_t
{
    ETargetDistanceComparisonType__TwoDimensions = 0,
    ETargetDistanceComparisonType__ThreeDimensions = 1,
    ETargetDistanceComparisonType__CollisionHalfHeightMultiplier = 2
};

enum EAIScalableFloatScalingType : uint8_t
{
    EAIScalableFloatScalingType__Disabled = 0,
    EAIScalableFloatScalingType__ReceivedDamageByTarget = 1
};

enum ETeleportReason : uint8_t
{
    ETeleportReason__AgentNotOnNavmesh = 0,
    ETeleportReason__AgentDestinationNotOnNavMesh = 1,
    ETeleportReason__AgentStuckInRepetitivePartialPaths = 2,
    ETeleportReason__AgentBlocked = 3,
    ETeleportReason__AgentNoPathFound = 4,
    ETeleportReason__Unknown = 5
};

enum EObstacleType : uint8_t
{
    EObstacleType__IncomingSmashable = 0,
    EObstacleType__BlockingSmashable = 1,
    EObstacleType__BlockingDetectedTrap = 2,
    EObstacleType__Unknown = 3,
    EObstacleType__Count = 3
};

enum EHarvestResult : uint8_t
{
    EHarvestResult__None = 0,
    EHarvestResult__InProgress = 1,
    EHarvestResult__Success = 2,
    EHarvestResult__Fail = 3
};

enum EReachLocationValidationMode : uint8_t
{
    EReachLocationValidationMode__None = 0,
    EReachLocationValidationMode__Storm = 1,
    EReachLocationValidationMode__Leash = 2,
    EReachLocationValidationMode__SoftLeash = 3,
    EReachLocationValidationMo___j_O_________B_i____s_D_3i________ = 4
};

enum EBlackboardUpdateType : uint8_t
{
    EBlackboardUpdateType__NoUpdate = 0,
    EBlackboardUpdateType__UpdateNow = 1,
    EBlackboardUpdateType__UpdateNextTick = 2
};

enum EDefensivePlayerStyleSource : uint8_t
{
    EDefensivePlayerStyleSource__Unknown = 0,
    EDefensivePlayerStyleSource__Escape = 1
};

enum ETwoPointSolverRotationA : uint8_t
{
    ETwoPointSolverRotationA__PointAToQuerier = 0,
    ETwoPointSolverRotationA__QuerierToPointA = 1,
    ETwoPointSolverRotationA__PointAToQuerierWithRandomOffset = 2,
    ETwoPointSolverRotationA__QuerierToPointAWithRandomOffset = 3,
    ETwoPointSolverRotationA__Custom = 4
};

enum EFortIntensityCurveSequenceType : uint8_t
{
    EFortIntensityCurveSequenceType__Sequence = 0,
    EFortIntensityCurveSequenceType__Loop = 1,
    EFortIntensityCurveSequenceType__Random = 2,
    EFortIntensityCurveSequenceType__Max_None = 3
};

enum EFortNavLinkPattern : uint8_t
{
    EFortNavLinkPattern__Floor = 0,
    EFortNavLinkPattern__Stairs = 1,
    EFortNavLinkPattern__Roof = 2,
    EFortNavLinkPattern__Manual = 3
};

enum EFortNamedNavmesh : uint8_t
{
    EFortNamedNavmesh__Husk = 0,
    EFortNamedNavmesh__Smasher = 1
};

enum EPathObstacleAction : uint8_t
{
    EPathObstacleAction__Melee = 0,
    EPathObstacleAction__Ignore = 1,
    EPathObstacleAction__AbortMoveAsFailed = 2,
    EPathObstacleAction__FinishMoveAsSucceeded = 3
};

enum EPathUndermineEvent : uint8_t
{
    EPathUndermineEvent__Predicted = 0,
    EPathUndermineEvent__Started = 1,
    EPathUndermineEvent__Finished = 2
};

enum EWardAffectType : uint8_t
{
    EWardAffectType__AffectsBothStartAndEndPoints = 0,
    EWardAffectType__AffectsOnlyStartPoints = 1,
    EWardAffectType__AffectsOnlyEndPoints = 2
};

enum ETagGoalScoringCategory : uint8_t
{
    ETagGoalScoringCategory__Ignore = 0,
    ETagGoalScoringCategory__HighInterest = 1,
    ETagGoalScoringCategory__NumCategories = 2
};

enum EBoundingBoxSlotDirectionCalculation : uint8_t
{
    EBoundingBoxSlotDirectionCalculation__Auto = 0,
    EBoundingBoxSlotDirectionCalculation__FaceWall = 1,
    EBoundingBoxSlotDirectionCalculation__FaceAwayFromWall = 2,
    EBoundingBoxSlotDirectionCalculation__FaceCenter = 3
};

enum EFortAreaFlag : uint8_t
{
    EFortAreaFlag__Default = 0,
    EFortAreaFlag__Obstacle = 1,
    EFortAreaFlag__Smashable = 2,
    EFortAreaFlag__Unwalkable = 3,
    EFortAreaFlag__Interactable = 4
};

enum EAthenaNavDetectorDataSelectionMode : uint8_t
{
    EAthenaNavDetectorDataSelectionMode__FromName = 0,
    EAthenaNavDetectorDataSelectionMode__FromAgentProperties = 1
};

enum EInBoundsState : uint8_t
{
    EInBoundsState__NoBounds = 0,
    EInBoundsState__NotInBounds = 1,
    EInBoundsState__InBounds = 2
};

enum ENavPathRendererStatus : uint8_t
{
    ENavPathRendererStatus__INVALID = 0,
    ENavPathRendererStatus__CALCULATING = 1,
    ENavPathRendererStatus__SUCCESS = 2,
    ENavPathRendererStatus__FAILED = 3
};

enum EFortThreatDeactivationType : uint8_t
{
    EFortThreatDeactivationType__Off = 0,
    EFortThreatDeactivationType__Dormant = 1
};

enum ETokenState : uint8_t
{
    ETokenState__Owned = 0,
    ETokenState__Awaiting = 1,
    ETokenState__Invalid = 2
};

enum EPositionSelectionMode : uint8_t
{
    EPositionSelectionMode__Reserved = 0,
    EPositionSelectionMode__Unreserved = 1,
    EPositionSelectionMode__All = 2
};

enum EAIEnergyThresholdEventType : uint8_t
{
    EAIEnergyThresholdEventType__OnDecrease = 0,
    EAIEnergyThresholdEventType__OnIncrease = 1,
    EAIEnergyThresholdEventType__E_WG___h________kf__v___7__6___ = 2
};

enum EFortCreativePatrolPathGroup : uint8_t
{
    EFortCreativePatrolPathGroup__Group_None = 0,
    EFortCreativePatrolPathGroup__Group = 1,
    EFortCreativePatrolPathGroup__Group = 2,
    EFortCreativePatrolPathGroup__Group = 3,
    EFortCreativePatrolPathGroup__Group = 4,
    EFortCreativePatrolPathGroup__Group = 5,
    EFortCreativePatrolPathGroup__Group = 6,
    EFortCreativePatrolPathGroup__Group = 7,
    EFortCreativePatrolPathGroup__Group = 8,
    EFortCreativePatrolPathGroup__Group = 9,
    EFortCreativePatrolPathGroup__Group = 10,
    EFortCreativePatrolPathGroup__Group = 11,
    EFortCreativePatrolPathGroup__Group = 12,
    EFortCreativePatrolPathGroup__Group = 13,
    EFortCreativePatrolPathGroup__Group = 14,
    EFortCreativePatrolPathGroup__Group = 15,
    EFortCreativePatrolPathGroup__Group = 16,
    EFortCreativePatrolPathGroup__Group = 17,
    EFortCreativePatrolPathGroup__Group = 18,
    EFortCreativePatrolPathGroup__Group = 19,
    EFortCreativePatrolPathGroup__Group = 20,
    EFortCreativePatrolPathGroup__Group = 21,
    EFortCreativePatrolPathGroup__Group = 22,
    EFortCreativePatrolPathGroup__Group = 23,
    EFortCreativePatrolPathGroup__Group = 24,
    EFortCreativePatrolPathGroup__Group = 25,
    EFortCreativePatrolPathGroup__Group = 26,
    EFortCreativePatrolPathGroup__Group = 27,
    EFortCreativePatrolPathGroup__Group = 28,
    EFortCreativePatrolPathGroup__Group = 29,
    EFortCreativePatrolPathGroup__Group = 30,
    EFortCreativePatrolPathGroup__Group = 31,
    EFortCreativePatrolPathGroup__Group = 32,
    EFortCreativePatrolPathGroup__Group = 33,
    EFortCreativePatrolPathGroup__Group = 34,
    EFortCreativePatrolPathGroup__Group = 35,
    EFortCreativePatrolPathGroup__Group = 36,
    EFortCreativePatrolPathGroup__Group = 37,
    EFortCreativePatrolPathGroup__Group = 38,
    EFortCreativePatrolPathGroup__Group = 39,
    EFortCreativePatrolPathGroup__Group = 40,
    EFortCreativePatrolPathGroup__Group = 41,
    EFortCreativePatrolPathGroup__Group = 42,
    EFortCreativePatrolPathGroup__Group = 43,
    EFortCreativePatrolPathGroup__Group = 44,
    EFortCreativePatrolPathGroup__Group = 45,
    EFortCreativePatrolPathGroup__Group = 46,
    EFortCreativePatrolPathGroup__Group = 47,
    EFortCreativePatrolPathGroup__Group = 48,
    EFortCreativePatrolPathGroup__Group = 49,
    EFortCreativePatrolPathGroup__Group = 50,
    EFortCreativePatrolPathGroup__Group = 51,
    EFortCreativePatrolPathGroup__Group = 52,
    EFortCreativePatrolPathGroup__Group = 53,
    EFortCreativePatrolPathGroup__Group = 54,
    EFortCreativePatrolPathGroup__Group = 55,
    EFortCreativePatrolPathGroup__Group = 56,
    EFortCreativePatrolPathGroup__Group = 57,
    EFortCreativePatrolPathGroup__Group = 58,
    EFortCreativePatrolPathGroup__Group = 59,
    EFortCreativePatrolPathGroup__Group = 60,
    EFortCreativePatrolPathGroup__Group = 61,
    EFortCreativePatrolPathGroup__Group = 62,
    EFortCreativePatrolPathGroup__Group = 63,
    EFortCreativePatrolPathGroup__Group = 64,
    EFortCreativePatrolPathGroup__Group = 65,
    EFortCreativePatrolPathGroup__Group = 66,
    EFortCreativePatrolPathGroup__Group = 67,
    EFortCreativePatrolPathGroup__Group = 68,
    EFortCreativePatrolPathGroup__Group = 69,
    EFortCreativePatrolPathGroup__Group = 70,
    EFortCreativePatrolPathGroup__Group = 71,
    EFortCreativePatrolPathGroup__Group = 72,
    EFortCreativePatrolPathGroup__Group = 73,
    EFortCreativePatrolPathGroup__Group = 74,
    EFortCreativePatrolPathGroup__Group = 75,
    EFortCreativePatrolPathGroup__Group = 76,
    EFortCreativePatrolPathGroup__Group = 77,
    EFortCreativePatrolPathGroup__Group = 78,
    EFortCreativePatrolPathGroup__Group = 79,
    EFortCreativePatrolPathGroup__Group = 80,
    EFortCreativePatrolPathGroup__Group = 81,
    EFortCreativePatrolPathGroup__Group = 82,
    EFortCreativePatrolPathGroup__Group = 83,
    EFortCreativePatrolPathGroup__Group = 84,
    EFortCreativePatrolPathGroup__Group = 85,
    EFortCreativePatrolPathGroup__Group = 86,
    EFortCreativePatrolPathGroup__Group = 87,
    EFortCreativePatrolPathGroup__Group = 88,
    EFortCreativePatrolPathGroup__Group = 89,
    EFortCreativePatrolPathGroup__Group = 90,
    EFortCreativePatrolPathGroup__Group = 91,
    EFortCreativePatrolPathGroup__Group = 92,
    EFortCreativePatrolPathGroup__Group = 93,
    EFortCreativePatrolPathGroup__Group = 94,
    EFortCreativePatrolPathGroup__Group = 95,
    EFortCreativePatrolPathGroup__Group = 96,
    EFortCreativePatrolPathGroup__Group = 97,
    EFortCreativePatrolPathGroup__Group = 98,
    EFortCreativePatrolPathGroup__Group = 99,
    EFortCreativePatrolPathGroup__Group = 100
};

enum EAIBotBuildingTemplate : uint8_t
{
    EAIBotBuildingTemplate__SingleWall = 0,
    EAIBotBuildingTemplate__SingleRamp = 1,
    EAIBotBuildingTemplate__SingleRoof = 2,
    EAIBotBuildingTemplate__SingleBrace = 3,
    EAIBotBuildingTemplate__SingleWallWindow = 4
};

enum BotDataOverrideCosmeticMode : uint8_t
{
    BotDataOverrideCosmeticMode__SpecificLoadout = 0,
    BotDataOverrideCosmeticMode__CosmeticLibrary = 1
};

enum EAILootExcludeListReason : uint8_t
{
    EAILootExcludeListReason__Invalid = 0,
    EAILootExcludeListReason__ExecutionError = 1,
    EAILootExcludeListReason__CannotReachLootLocation = 2,
    EAILootExcludeListReason__OutsideSafeZoneRadius = 3,
    EAILootExcludeListReason__NoInventorySpace = 4,
    EAILootExcludeListReason__LootStateUnavailable = 5,
    EAILootExcludeListReason__PathNotFound = 6,
    EAILootExcludeListReason__GoalOffNavmesh = 7,
    EAILootExcludeListReason__AgentBlocked = 8,
    EAILootExcludeListReason__IsolatedIsland = 9,
    EAILootExcludeListReason__UnsupportedItem = 10,
    EAILootExcludeListReason__Count = 11
};

enum EExecutionStatus : uint8_t
{
    EExecutionStatus__ExecutionError = 0,
    EExecutionStatus__ExecutionDenied = 1,
    EExecutionStatus__ExecutionSuccess = 2,
    EExecutionStatus__ExecutionPending = 3,
    EExecutionStatus__ExecutionAllowed = 4
};

enum EBotMovementState : uint8_t
{
    EBotMovementState__None = 0,
    EBotMovementState__InProgress = 1,
    EBotMovementState__Failed_NoPathFound = 2,
    EBotMovementState__Failed_Aborted = 3,
    EBotMovementState__Failed_AgentOffNavmesh = 4,
    EBotMovementState__Failed_GoalOffNavmesh = 5,
    EBotMovementState__Failed_Blocked = 6,
    EBotMovementState__Failed_OffPath = 7,
    EBotMovementState__Failed_Falling = 8,
    EBotMovementState__Success = 9,
    EBotMovementState__Success_Partial = 10,
    EBotMovementState__Success_AlreadyAtGoal = 11
};

enum EUnstuckSteeringReason : uint8_t
{
    EUnstuckSteeringReason__Unknown = 0,
    EUnstuckSteeringReason__OffNavMesh = 1,
    EUnstuckSteeringReason__IsolatedIsland = 2,
    EUnstuckSteeringReason__AgentBlocked = 3,
    EUnstuckSteeringReason__NoPathFound = 4
};

enum EFortAthenaAIObjectTrackerQueryOrder : uint8_t
{
    EFortAthenaAIObjectTrackerQueryOrder__None = 0,
    EFortAthenaAIObjectTrackerQueryOrder__Distance = 1
};

enum EFortAthenaSmartObjectPriority : uint8_t
{
    EFortAthenaSmartObjectPriority__Lowest = 0,
    EFortAthenaSmartObjectPriority__Lower = 1,
    EFortAthenaSmartObjectPriority__Low = 2,
    EFortAthenaSmartObjectPriority__BelowNormal = 3,
    EFortAthenaSmartObjectPriority__Normal = 4,
    EFortAthenaSmartObjectPriority__AboveNormal = 5,
    EFortAthenaSmartObjectPriority__High = 6,
    EFortAthenaSmartObjectPriority__Higher = 7,
    EFortAthenaSmartObjectPriority__Highest = 8,
    EFortAthen_________ = 0
};

enum EFortAthenaSmartObjectUrgency : uint8_t
{
    EFortAthenaSmartObjectUrgency__Low = 0,
    EFortAthenaSmartObjectUrgency__Normal = 1,
    EFortAthenaSmartObjectUrgency__High = 2
};

enum EFortAthenaAISpawnerDataComponentTriBool : uint8_t
{
    EFortAthenaAISpawnerDataComponentTriBool__Yes = 0,
    EFortAthenaAISpawnerDataComponentTriBool__No = 1,
    EFortAthenaAISpawnerDataComponentTriBool__DoNotModify = 2
};

enum EBehaviorTreeBranches : uint8_t
{
    EBehaviorTreeBranches__CanUseDiving = 0,
    EBehaviorTreeBranches__CanUseGliding = 1,
    EBehaviorTreeBranches__CanReactToProjectile = 2,
    EBehaviorTreeBranches__CanReactToTraps = 3,
    EBehaviorTreeBranches__CanAvoidDangerArea = 4,
    EBehaviorTreeBranches__CanBeConverted = 5,
    EBehaviorTreeBranches__CanPropagateAwareness = 6,
    EBehaviorTreeBranches__CanUseThreatenedBehaviors = 7,
    EBehaviorTreeBranches__CanUseLastKnownPositionBehavior = 8,
    EBehaviorTreeBranches__CanUseAlertedBehavior = 9,
    EBehaviorTreeBranches__CanUseSmartObjects = 10,
    EBehaviorTreeBranches__CanReviveDBNOTeammates = 11,
    EBehaviorTreeBranches__CanPlayEmote = 12,
    EBehaviorTreeBranches__CanConverse = 13,
    EBehaviorTreeBranches__CanPatrolOnPath = 14,
    EBehaviorTreeBranches__CanPatrolAround = 15,
    EBehaviorTreeBranches__CanTeleportWhenStuck = 16,
    EBehaviorTreeBranches__CanEmoteWhenStuck = 17,
    EBehaviorTreeBranches__CanUseZiplines = 18,
    EBehaviorTreeBranches__CanMoveAway = 19,
    EBehaviorTreeBranches__CanReturnToLeash = 20,
    EBehaviorTreeBranches__Count = 21
};

enum EBehaviorTreeBranchesBitmask : uint8_t
{
    EBehaviorTreeBranchesBitmask__CanUseDiving = 0,
    EBehaviorTreeBranchesBitmask__CanUseGliding = 1,
    EBehaviorTreeBranchesBitmask__CanReactToProjectile = 2,
    EBehaviorTreeBranchesBitmask__CanReactToTraps = 3,
    EBehaviorTreeBranchesBitmask__CanAvoidDangerArea = 4,
    EBehaviorTreeBranchesBitmask__CanBeConverted = 5,
    EBehaviorTreeBranchesBitmask__CanPropagateAwareness = 6,
    EBehaviorTreeBranchesBitmask__CanUseThreatenedBehaviors = 7,
    EBehaviorTreeBranchesBitmask__CanUseLastKnownPositionBehavior = 8,
    EBehaviorTreeBranchesBitmask__CanUseAlertedBehavior = 9,
    EBehaviorTreeBranchesBitmask__CanUseSmartObjects = 10,
    EBehaviorTreeBranchesBitmask__CanReviveDBNOTeammates = 11,
    EBehaviorTreeBranchesBitmask__CanPlayEmote = 12,
    EBehaviorTreeBranchesBitmask__CanConverse = 13,
    EBehaviorTreeBranchesBitmask__CanPatrolOnPath = 14,
    EBehaviorTreeBranchesBitmask__CanPatrolAround = 15,
    EBehaviorTreeBranchesBitmask__CanTeleportWhenStuck = 16,
    EBehaviorTreeBranchesBitmask__CanEmoteWhenStuck = 17,
    EBehaviorTreeBranchesBitmask__CanUseZiplines = 18,
    EBehaviorTreeBranchesBitmask__CanMoveAway = 19,
    EBehaviorTreeBranchesBitmask__CanReturnToLeash = 20,
    EBehaviorTreeBranchesBitmask__Count = 21
};

enum EPatrollingMode : uint8_t
{
    EPatrollingMode__BackAndForth = 0,
    EPatrollingMode__Loop = 1,
    EPatrollingMode__StopAtEnd = 2
};

enum EDBNOPlayStyle : uint8_t
{
    EDBNOPlayStyle__Thirsty = 0,
    EDBNOPlayStyle__Default = 1,
    EDBNOPlayStyle__Passive = 2,
    EDBNOPlayStyle__ThristyButPassiveOnPlayers = 3,
    EDBNOPlayStyle__DefaultButPassiveOnPlayers = 4
};

enum EPerceptionState : uint8_t
{
    EPerceptionState__Threat_Seeing = 0,
    EPerceptionState__Threat_LKP = 1,
    EPerceptionState__Threat_Alerted = 2,
    EPerceptionState__ObstacleIncoming = 3,
    EPerceptionState__ObstacleBlockedBy = 4,
    EPerceptionState__ObstacleDetectedTrap = 5,
    EPerceptionState__Unknown = 6,
    EPerceptionState__Count = 6,
    EPerceptionState__Threat_Count = 3
};

enum EPerceptionSoundType : uint8_t
{
    EPerceptionSoundType__Default = 0,
    EPerceptionSoundType__Explosion = 1,
    EPerceptionSoundType__ProjectileFlyBy = 2,
    EPerceptionSoundType__ProjectileImpact = 3,
    EPerceptionSoundType__Weap6_w__a_9 = 4,
    EPerceptionSoundType__Building = 5,
    EPerceptionSoundType__MeleeImpact = 6,
    EPerceptionSoundType__PawnDeath = 7
};

enum ELookAtType : uint8_t
{
    ELookAtType__ScanAround = 0,
    ELookAtType__Investigate = 1,
    ELookAtType__HeardSound = 2,
    ELookAtType__Ambush = 3
};

enum ELeashReturnLocationMode : uint8_t
{
    ELeashReturnLocationMode__Closest = 0,
    ELeashReturnLocationMode__Random = 1,
    ELeashReturnLocationMode__ReturnToCenter = 2,
    ELeashReturnLocationMode__ReturnToCenterAvoidObstacle = 3
};

enum EOrientedConstructionBuildingType : uint8_t
{
    EOrientedConstructionBuildingType__WallX = 0,
    EOrientedConstructionBuildingType__WallY = 1,
    EOrientedConstructionBuildingType__Floor = 2,
    EOrientedConstructionBuildingType__StairsUpX = 3,
    EOrientedConstructionBuildingType__StairsUpY = 4,
    EOrientedConstructionBuildingType__StairsDownX = 5,
    EOrientedConstructionBuildingType__StairsDownY = 6,
    EOrientedConstructionBuildingType__Roof = 7,
    EOrientedConstructionBuildingType__BraceLeftX = 8,
    EOrientedConstructionBuildingType__BraceRightX = 9,
    EOrientedConstructionBuildingType__BraceLeftY = 10,
    EOrientedConstructionBuildingType__BraceRightY = 11,
    EOrientedConstructionBuildingType__WallWindowX = 12,
    EOrientedConstructionBuildingType__WallWindowY = 13,
    EOrientedConstructionBuildingType__Count = 14
};

enum EConstructionBuildingType : uint8_t
{
    EConstructionBuildingType__Wall = 0,
    EConstructionBuildingType__Floor = 1,
    EConstructionBuildingType__Stairs = 2,
    EConstructionBuildingType__Roof = 3,
    EConstructionBuildingType__Brace = 4,
    EConstructionBuildingType__WallWindow = 5,
    EConstructionBuildingType__Count = 6
};

enum EAthenaAIServicePOIList : uint8_t
{
    MainBusDrop = 0,
    SecondaryBusDrop = 1,
    OnGround = 2
};

enum ECheatBotTargetingCategory : uint8_t
{
    ECheatBotTargetingCategory__Player = 0,
    ECheatBotTargetingCategory__NPC = 1,
    ECheatBotTargetingCategory__Other = 2,
    ECheatBotTargetingCategory__COUNT = 3
};

enum EAthenaAITrackedZoneType : uint8_t
{
    EAthenaAITrackedZoneType__Occluder = 0,
    EAthenaAITrackedZoneType__Danger = 1
};

enum EBotPOIType : uint8_t
{
    EBotPOIType__Unknown = 0,
    EBotPOIType__ClusterLoot = 1,
    EBotPOIType__MidMatchObjective = 2
};

enum EBotPOIUsageBitmask : uint8_t
{
    EBotPOIUsageBitmask__None = 0,
    EBotPOIUsageBitmask__BotJumpOffBus = 1,
    EBotPOIUsageBitmask__BotNavigation = 2
};

enum ERatingsEnforcementType : uint8_t
{
    ERatingsEnforcementType__Default = 0,
    ERatingsEnforcementType__IgnoreMaximums = 1,
    ERatingsEnforcementType__IgnoreParty = 2,
    ERatingsEnforcementType__IgnorePartyMaximum = 3
};

enum EClampType : uint8_t
{
    EClampType__Minimum = 0,
    EClampType__Maximum = 1
};

enum ETargetContext : uint8_t
{
    ETargetContext__Default = 0,
    ETargetContext__Unreachable = 1,
    ETargetContext__OutsideOfLeash = 2
};

enum EFortAthenaBTServiceTokenQueryAction : uint8_t
{
    EFortAthenaBTServiceTokenQueryAction__None = 0,
    EFortAthenaBTServiceTokenQueryAction__RequestToken = 1,
    EFortAthenaBTServiceTokenQueryAction__ReleaseToken = 2
};

enum SwitchSeatType : uint8_t
{
    ToDriver = 0,
    ToPassenger = 1,
    ToGunner = 2,
    ToSpotter = 3
};

enum EFortAthenaStateTreeTaskFeatureExecutionMode : uint8_t
{
    EFortAthenaStateTreeTaskFeatureExecutionMode__DoNotExecute = 0,
    EFortAthenaStateTreeTaskFeatureExecutionMode__ExecuteOnEnter = 1,
    EFortAthenaStateTreeTaskFeatureExecutionMode__ExecuteOnExit = 2
};

enum SeatStatusType : uint8_t
{
    Driver = 0,
    Passenger = 1,
    Gunner = 2,
    Spotter = 3
};

enum EFortQueryGeneratorFloodfillBehavior : uint8_t
{
    EFortQueryGeneratorFloodfillBehavior__PolyCenter = 0,
    EFortQueryGeneratorFloodfillBehavior__RandomPositionOnPoly = 1,
    EFortQueryGeneratorFloodfillBehavior__DistributedByPolyArea = 2,
    EFortQueryGeneratorFloodfillBehavior__EFortQueryGeneratorF__c__B_e____A_V4_b__ = 3
};

enum EQueryGeneratorRectSpacingMethod : uint8_t
{
    EQueryGeneratorRectSpacingMethod__BySpaceBetween = 0,
    EQueryGeneratorRectSpacingMethod__ByNumberOfPoints = 1
};

enum EForstStateTreeFireWeaponBehavior : uint8_t
{
    EForstStateTreeFireWeaponBehavior__HoldFire = 0,
    EForstStateTreeFireWeaponBehavior__HoldFireForPattern = 1,
    EForstStateTreeFireWeaponBehavior__FireSingleAndSucceed = 2,
    EForstStateTreeFireWeaponBehavior__FireSingleAndRun = 3
};

enum EFortWorldConditionPlayerHasConvertedNPCCondition : uint8_t
{
    EFortWorldConditionPlayerHasConvertedNPCCondition__HasReachedConvertedNPCLimit = 0,
    EFortWorldConditionPlayerHasConvertedNPCCondition__HasAnotherConvertedNPC = 1
};

enum EFortDayOfWeek : uint8_t
{
    EFortDayOfWeek__None = 0,
    EFortDayOfWeek__Monday = 1,
    EFortDayOfWeek__Tuesday = 2,
    EFortDayOfWeek__Wednesday = 4,
    EFortDayOfWeek__Thursday = 8,
    EFortDayOfWeek__Friday = 16,
    EFortDayOfWeek__Saturday = 32,
    EFortDayOfWeek__Sunday = 64,
    EFortDayOfWeek__All = 255
};

enum EFortPointsFromNavGraphGoalPathDistanceFilterOperator : uint8_t
{
    EFortPointsFromNavGraphGoalPathDistanceFilterOperator__AllGoalsInRange = 0,
    EFortPointsFromNavGraphGoalPathDistanceFilterOperator__AnyGoalInRange = 1
};

enum EFortTestGoalActorDot : uint8_t
{
    EFortTestGoalActorDot__Dot3D = 0,
    EFortTestGoalActorDot__Dot2D = 1
};

enum EDistanceMode : uint8_t
{
    EDistanceMode__DistItemToContext = 0,
    EDistanceMode__DistItemGoalActorToContext = 1,
    EDistanceMode__DistItemToItemGoalActor = 2
};

enum ECountAIAssignedToType : uint8_t
{
    ECountAIAssignedToType__Goal = 0,
    ECountAIAssignedToType__Actor = 1,
    ECountAIAssignedToType__Assignment = 2
};

enum EFortAthenaAICanMoveState : uint8_t
{
    EFortAthenaAICanMoveState__None = 0,
    EFortAthenaAICanMoveState__Failed_AgentOffNavmesh = 1,
    EFortAthenaAICanMoveState__Failed_GoalOffNavmesh = 2,
    EFortAthenaAICanMoveState__Failed_Falling = 3,
    EFortAthenaAICanMoveState__Success = 4,
    EFortAthenaAICanMoveState__Success_Partial = 5
};

enum EEvasiveManeuverType : uint8_t
{
    EEvasiveManeuverType__Crouch = 0,
    EEvasiveManeuverType__Dodge = 1,
    EEvasiveManeuverType__Jump = 2,
    EEvasiveManeuverType__JetpackStrafe = 3,
    EEvasiveManeuverType__None = 4
};

enum EFreeFallingMode : uint8_t
{
    EFreeFallingMode__Idle = 0,
    EFreeFallingMode__Random = 1,
    EFreeFallingMode__TowardNearestAlly = 2,
    EFreeFallingMode__PatrolPath = 3
};

enum ECannotMeleeAttackReason : uint8_t
{
    ECannotMeleeAttackReason__None = 0,
    ECannotMeleeAttackReason__CooldownActive = 1,
    ECannotMeleeAttackReason__Other = 2,
    ECannotMeleeAttackReason__AttackDestinationNotValid = 3,
    ECannotMeleeAttackReason__TargetOutsideLeash = 4
};

enum ECooldownType : uint8_t
{
    OnActionTriggered = 0,
    OnActionFinished = 1,
    OnActionSucceeded = 2
};

enum EBTServiceSetAIFocusPriority : uint8_t
{
    EBTServiceSetAIFocusPriority__Default = 0,
    EBTServiceSetAIFocusPriority__Move = 1,
    EBTServiceSetAIFocusPriority__Gameplay = 2
};

enum EBTSetBlackboardBoolExitActions : uint8_t
{
    EBTSetBlackboardBoolExitActions__Invert = 0,
    EBTSetBlackboardBoolExitActions__Revert = 1,
    EBTSetBlackboardBoolExitActions__Keep = 2
};

enum EGlideBehavior : uint8_t
{
    EGlideBehavior__GlideFocusOnDestination = 0,
    EGlideBehavior__GlideSurveyArea = 1
};

enum EGlideMovementType : uint8_t
{
    EGlideMovementType__GlideMovementLinear = 0,
    EGlideMovementType__GlideMovementSpiral = 1,
    EGlideMovementType__GlideMovementSerpentine = 2,
    EGlideMovementType__GlideAroundThreat = 3,
    EGlideMovementType__GlideBackAndForth = 4
};

enum EActionState : uint8_t
{
    EActionState__TryingToEquip = 0,
    EActionState__EquippingItem = 1,
    EActionState__UsingItem = 2,
    EActionState__WaitingItemTermination = 3,
    EActionState__WaitBeforeEquippingNextItem = 4,
    EActionState__ActionEndedWithNoError = 5,
    EActionState__ActionEndedWithError = 6
};

enum EEncampmentRole : uint8_t
{
    EEncampmentRole__Guard = 0,
    EEncampmentRole__Build = 1,
    EEncampmentRole__Count = 2
};

enum EHasMatchingGameplayTagContainerTestType : uint8_t
{
    EHasMatchingGameplayTagContainerTestType__Any = 0,
    EHasMatchingGameplayTagContainerTestType__All = 1
};

enum EFortAthenaArithmeticOperation : uint8_t
{
    EFortAthenaArithmeticOperation__Add = 0,
    EFortAthenaArithmeticOperation__Subtract = 1,
    EFortAthenaArithmeticOperation__Multiply = 2,
    EFortAthenaArithmeticOperation__Divide = 3
};

enum EFortAthenaPlayContextualAnimExecutionMethod : uint8_t
{
    EFortAthenaPlayContextualAnimExecutionMethod__StartInteraction = 0,
    EFortAthenaPlayContextualAnimExecutionMethod__JoinInteraction = 1,
    EFortAthenaPlayContextualAnimExecutionMethod__TransitionAllActors = 2,
    EFortAthenaPlayContextualAnimExecutionMethod__TransitionSingleActor = 3
};

enum ESTFortAthenaPlayMontageExecMode : uint8_t
{
    ESTFortAthenaPlayMontageExecMode__NewMontage = 0,
    ESTFortAthenaPlayMontageExecMode__SetNextSection = 1,
    ESTFortAthenaPlayMontageExecMode__JumpToSection = 2
};

enum ESTFortAthenaPlayMontageLoopMode : uint8_t
{
    ESTFortAthenaPlayMontageLoopMode__Task = 0,
    ESTFortAthenaPlayMontageLoopMode__Montage = 1
};

enum ETweenSplineAlignmentOption : uint8_t
{
    ETweenSplineAlignmentOption__NoAlignment = 0,
    ETweenSplineAlignmentOption__AlignWithSpline = 1,
    ETweenSplineAlignmentOption__AlignWithTween = 2
};

enum ETweenPlayDirection : uint8_t
{
    ETweenPlayDirection__Forward = 0,
    ETweenPlayDirection__Backward = 1
};

enum ETweenInitializationPoint : uint8_t
{
    ETweenInitializationPoint__AfterDelay = 0,
    ETweenInitializationPoint__OnPlay = 1
};

enum ETweenLoopType : uint8_t
{
    ETweenLoopType__None = 0,
    ETweenLoopType__Repeat = 1,
    ETweenLoopType__PingPong = 2
};

enum ETweenResetDestination : uint8_t
{
    ETweenResetDestination__Beginning = 0,
    ETweenResetDestination__End = 1
};

enum EWidgetStateComponentUnloadDefaultBehavior : uint8_t
{
    EWidgetStateComponentUnloadDefaultBehavior__WaitForAnimations = 0,
    EWidgetStateComponentUnloadDefaultBehavior__DoNotWaitForAnimations = 1
};

enum EUIStateTransitionUrgency : uint8_t
{
    EUIStateTransitionUrgency__Normal = 0,
    EUIStateTransitionUrgency__High = 1
};

enum EUIStateAutomationType : uint8_t
{
    EUIStateAutomationType__Initial = 0,
    EUIStateAutomationType__Continual = 1
};

enum EUIStateChartContextConditionType : uint8_t
{
    EUIStateChartContextConditionType__IsEmpty = 0,
    EUIStateChartContextConditionType__IsNotEmpty = 1,
    EUIStateChartContextConditionType__IsEqualTo = 2,
    EUIStateChartContextConditionType__IsNotEqualTo = 3,
    EUIStateChartContextConditionType__IsGreaterThan = 4,
    EUIStateChartContextConditionType__IsGreaterThanOrEqualTo = 5,
    EUIStateChartContextConditionType__IsLessThan = 6,
    EUIStateChartContextConditionType__IsLessThanOrEqualTo = 7,
    EUIStateChartContextConditionType__IsTrue = 8,
    EUIStateChartContextConditionType__IsNotTrue = 9,
    EUIStateChartContextConditionType__StartsWith = 10,
    EUIStateChartContextConditionType__EndsWith = 11,
    EUIStateChartContextConditionType__Contains = 12
};

enum EUIChartRegionTransitionScope : uint8_t
{
    EUIChartRegionTransitionScope__ThisRegionOnly = 0,
    EUIChartRegionTransitionScope__ThisRegionOrChildRegions = 1
};

enum EStateComponentStatus : uint8_t
{
    EStateComponentStatus__Inactive = 0,
    EStateComponentStatus__PreparingForLoad = 1,
    EStateComponentStatus__Loading = 2,
    EStateComponentStatus__DoneLoading = 3,
    EStateComponentStatus__Operational = 4,
    EStateComponentStatus__PreparingForUnload = 5,
    EStateComponentStatus__Unloading = 6,
    EStateComponentStatus__DoneUnloading = 7
};

enum EStateChartResourceScope : uint8_t
{
    EStateChartResourceScope__StateChart = 0,
    EStateChartResourceScope__Player = 1,
    EStateChartResourceScope__Global = 2
};

enum VideoWidgetPerfControl : uint8_t
{
    VideoWidgetPerfControl__None = 0,
    VideoWidgetPerfControl__WorldRendering = 1,
    VideoWidgetPerfControl__ShaderCache = 2,
    VideoWidgetPerfControl__PhysicalSizeLimit = 4,
    VideoWidgetPerfControl__GarbageCollection = 8
};

enum EMotdCloseReason : uint8_t
{
    EMotdCloseReason__Unknown = 0,
    EMotdCloseReason__NoMotds = 1,
    EMotdCloseReason__NullPrm = 2,
    EMotdCloseReason__PrmParsingFailed = 3,
    EMotdCloseReason__User = 4,
    EMotdCloseReason__Action = 5,
    EMotdCloseReason__DeepLink = 6
};

enum EBackgroundSource : uint8_t
{
    EBackgroundSource__CMS = 0,
    EBackgroundSource__LobbyData = 1,
    EBackgroundSource__URL = 2
};

enum EFrontendLobbyLocationOrigin : uint8_t
{
    EFrontendLobbyLocationOrigin__Pedestal = 0
};

enum EFortUIFeature : uint8_t
{
    EFortUIFeature__ShowHome = 0,
    EFortUIFeature__ShowPlay = 1,
    EFortUIFeature__ShowCommand = 2,
    EFortUIFeature__ShowHeros = 3,
    EFortUIFeature__ShowSquads = 4,
    EFortUIFeature__ShowArmory = 5,
    EFortUIFeature__ShowLocker = 6,
    EFortUIFeature__ShowMultiProductLocker = 7,
    EFortUIFeature__ShowMyLoadout = 8,
    EFortUIFeature__ShowSkillTree = 9,
    EFortUIFeature__ShowStore = 10,
    EFortUIFeature__ShowQuests = 11,
    EFortUIFeature__ShowMainStore = 12,
    EFortUIFeature__ShowContextHelpMenu = 13,
    EFortUIFeature__ShowCampaign = 14,
    EFortUIFeature__ShowActiveBoost = 15,
    EFortUIFeature__ShowJournal = 16,
    EFortUIFeature__ShowPartyBar = 17,
    EFortUIFeature__ShowChatWindow = 18,
    EFortUIFeature__ShowFriendsMenu = 19,
    EFortUIFeature__ShowObjectives = 20,
    EFortUIFeature__ShowRatingIconsInTopbar = 21,
    EFortUIFeature__ShowAntiAddictionMessage = 22,
    EFortUIFeature__ShowMinorShutdownMessage = 23,
    EFortUIFeature__ShowHealthWarningScreen = 24,
    EFortUIFeature__ShowSimplifiedHUD = 25,
    EFortUIFeature__LargeHeaderFooterButtons = 26,
    EFortUIFeature__ShowAthenaFavoriting = 27,
    EFortUIFeature__ShowAthenaItemRandomization = 28,
    EFortUIFeature__ShowAthenaQuests = 29,
    EFortUIFeature__ShowBattlePass = 30,
    EFortUIFeature__ShowNewBattlePass = 31,
    EFortUIFeature__ShowDynamicBattlePass = 32,
    EFortUIFeature__ShowBattlePassFAQ = 33,
    EFortUIFeature__ShowPoblano = 34,
    EFortUIFeature__ShowReplays = 35,
    EFortUIFeature__ShowProfileStatsUI = 36,
    EFortUIFeature__ShowAthenaItemShop = 37,
    EFortUIFeature__ShowMultiProductItemShop = 38,
    EFortUIFeature__ShowShowdown = 39,
    EFortUIFeature__SpecialEventsStart = 40,
    EFortUIFeature__ShowSpecialEvent = 41,
    EFortUIFeature__ShowSpecialEventTeaser = 42,
    EFortUIFeature__ShowSparksSpecialEvent = 43,
    EFortUIFeature__ShowJunoSpecialEvent = 44,
    EFortUIFeature__ShowDelMarSpecialEvent = 45,
    EFortUIFeature__ShowWinterfest = 46,
    EFortUIFeature__SpecialEventsEnd = 47,
    EFortUIFeature__ShowSpatialUI = 48,
    EFortUIFeature__ShowSocial = 49,
    EFortUIFeature__ShowAccountBoosts = 50,
    EFortUIFeature__ShowCustomerSupport = 51,
    EFortUIFeature__ShowGlobalChat = 52,
    EFortUIFeature__ShowEULA = 53,
    EFortUIFeature__ShowEndOfZoneCinematic = 54,
    EFortUIFeature__ShowOnboardingCinematics = 55,
    EFortUIFeature__ShowFounderB___aq_____ = 56,
    EFortUIFeature__ShowCurrentRegionInLobby = 57,
    EFortUIFeature__ShowPrerollLlamas = 58,
    EFortUIFeature__EnableFoundersDailyRewards = 59,
    EFortUIFeature__EnableMatchmakingRegionSetting = 60,
    EFortUIFeature__EnableLanguageSetting = 61,
    EFortUIFeature__EnableFriendCodeSetting = 62,
    EFortUIFeature__EnableEarlyAccessLoadingScreenBanner = 63,
    EFortUIFeature__EnableAlterationModifications = 64,
    EFortUIFeature__EnableSchematicRarityUpgrade = 65,
    EFortUIFeature__EnableMissionActivationVote = 66,
    EFortUIFeature__EnableLtmRetrieveTheData = 67,
    EFortUIFeature__EnableUpgradesVideos = 68,
    EFortUIFeature__ShowPreviewTestTab = 69,
    EFortUIFeature__EnableSearchTabInTopNavigationBar = 70,
    EFortUIFeature__EnableDiscoverTabInTopNavigationBar = 71,
    EFortUIFeature__EnableLibraryTabInTopNavigationBar = 72,
    EFortUIFeature__PlaceholderUIFeature1 = 73,
    EFortUIFeature__PlaceholderUIFeature2 = 74,
    EFortUIFeature__PlaceholderUIFeature3 = 75,
    EFortUIFeature__PlaceholderUIFeature4 = 76,
    EFortUIFeature__PlaceholderUIFeature5 = 77,
    EFortUIFeature__Max_None = 78
};

enum EFortFrontEndFeatureStateReason : uint8_t
{
    EFortFrontEndFeatureStateReason__Default = 0,
    EFortFrontEndFeatureStateReason__NoHeroes = 1,
    EFortFrontEndFeatureStateReason__Tutorial = 2,
    EFortFrontEndFeatureStateReason__BROnly = 3,
    EFortFrontEndFeatureStateReason__NoPlayerController = 4,
    EFortFrontEndFeatureStateReason__UnexpectedFeature = 5,
    EFortFrontEndFeatureStateReason__Invalid = 6
};

enum EFortFrontEndFeatureState : uint8_t
{
    EFortFrontEndFeatureState__Enabled = 0,
    EFortFrontEndFeatureState__Disabled = 1,
    EFortFrontEndFeatureState__Hidden = 2,
    EFortFrontEndFeatureState__Invalid = 3
};

enum EFortFrontEndFeature : uint8_t
{
    EFortFrontEndFeature__ShowHomeBase = 0,
    EFortFrontEndFeature__ShowHeroList = 1,
    EFortFrontEndFeature__ShowVault = 2,
    EFortFrontEndFeature__ShowStore = 3,
    EFortFrontEndFeature__PlayZone = 4,
    EFortFrontEndFeature__ShowHeroSelect = 5,
    EFortFrontEndFeature__RecruitHero = 6,
    EFortFrontEndFeature__ShowHomeBaseOverview = 7,
    EFortFrontEndFeature__STWArmory_Transform = 8,
    EFortFrontEndFeature__STWArmory_CollectionBook = 9,
    EFortFrontEndFeature__MAX_None = 10
};

enum EFortItemCooldownType : uint8_t
{
    EFortItemCooldownType__None = 0,
    EFortItemCooldownType__AmmoRegeneration = 1,
    EFortItemCooldownType__ItemActivation = 2,
    EFortItemCooldownType__WeaponReloading = 3,
    EFortItemCooldownType__Death = 4,
    EFortItemCooldownType__AthenaWeaponFireCooldown = 5,
    EFortItemCooldownType__AbilitySetActivateByInputAbility = 6,
    EFortItemCooldownType__DirectProgressUpdate = 7
};

enum EFortBuildingInteraction : uint8_t
{
    EFortBuildingInteraction__None = 0,
    EFortBuildingInteraction__Build = 1,
    EFortBuildingInteraction__Repair = 2,
    EFortBuildingInteraction__Upgrade = 3,
    EFortBuildingInteraction__Edit = 4,
    EFortBuildingInteraction__BeingModified = 5,
    EFortBuildingInteraction__ConfirmEdit = 6,
    EFortBuildingInteraction__Creative = 7
};

enum EFortBuildingH__B_6C______R__B : uint8_t
{
    EFortBuildingHealthDisplayRule__Never = 0,
    EFortBuildingHealthDisplayRule__Allowed = 1,
    EFortBuildingHealthDisplayRule__Always = 2
};

enum EFortHitPointModificationReason : uint8_t
{
    EFortHitPointModificationReason__Invalid = 0,
    EFortHitPointModificationReason__InitalSet = 1,
    EFortHitPointModificationReason__AutoRegen = 2,
    EFortHitPointModificationReason__ItemRegen = 3,
    EFortHitPointModificationReason__DamageOverTime = 4,
    EFortHitPointModificationReason__DamageReceived = 5
};

enum EFortStoreState : uint8_t
{
    EFortStoreState__Error = 0,
    EFortStoreState__Closed = 1,
    EFortStoreState__CardPackStore = 2,
    EFortStoreState__CurrencyStore = 3,
    EFortStoreState__WebPayment = 4,
    EFortStoreState__PurchaseOpen = 5,
    EFortStoreState__PackOpen = 6,
    EFortStoreState__CardEnter = 7,
    EFortStoreState__CardBackReveal = 8,
    EFortStoreState__CardFlip = 9,
    EFortStoreState__CardFrontReveal = 10,
    EFortStoreState__CardExit = 11,
    EFortStoreState__SummaryAdd = 12,
    EFortStoreState__PackDestroy = 13,
    EFortStoreState__Summary = 14,
    EFortStoreState__PresentChoice = 15,
    EFortStoreState__ChoiceMade = 16,
    EFortStoreState__SummaryAddTransition = 17,
    EFortStoreState__MAX_None = 18
};

enum EFortUIFeatureState : uint8_t
{
    EFortUIFeatureState__Enabled = 0,
    EFortUIFeatureState__Disabled = 1,
    EFortUIFeatureState__Hidden = 2,
    EFortUIFeatureState__Invalid = 3
};

enum EPostGameHUDMode : uint8_t
{
    EPostGameHUDMode__None = 0,
    EPostGameHUDMode__AllHidden = 1,
    EPostGameHUDMode__Spectating = 2,
    EPostGameHUDMode__AllHiddenExceptXP = 3
};

enum EPostGameClickCatcherMode : uint8_t
{
    EPostGameClickCatcherMode__Catch_None = 0,
    EPostGameClickCatcherMode__Catch_MobileOnly = 1,
    EPostGameClickCatcherMode__Catch_MouseOnly = 2,
    EPostGameClickCatcherMode__Catch_All = 3
};

enum EInputPriority : uint8_t
{
    EInputPriority__Normal = 0,
    EInputPriority__Menu = 1,
    EInputPriority__Chat = 2,
    EInputPriority__Modal = 3,
    EInputPriority__Confirmation = 4,
    EInputPriority__Error = 5,
    EInputPriority__HUD = 6
};

enum ECollabDialogExitResult : uint8_t
{
    ECollabDialogExitResult__None = 0,
    ECollabDialo____S_2S______x__0 = 1,
    ECollabDialogExitResult__Continue = 2
};

enum EFortPrioritizedWidgetContestedBehavior : uint8_t
{
    EFortPrioritizedWidgetContestedBehavior__QueueBehind = 0,
    EFortPrioritizedWidgetContestedBehavior__StompOther = 1
};

enum EFortPrioritizedWidgetPriority : uint8_t
{
    EFortPrioritizedWidgetPriority__Priority = 0,
    EFortPrioritizedWidgetPriority__Priority = 1,
    EFortPrioritizedWidgetPriority__Priority = 2,
    EFortPrioritizedWidgetPriority__Priority = 3,
    EFortPrioritizedWidgetPriority__Priority = 4,
    EFortPrioritizedWidgetPriority__Priority = 5,
    EFortPrioritizedWidgetPriority__NumberOfPrios = 6
};

enum EFlagStatus : uint8_t
{
    EFlagStatus__FlagPresent = 0,
    EFlagStatus__FlagNotPresent = 1
};

enum EFortInputMode : uint8_t
{
    EFortInputMode__Frontend = 0,
    EFortInputMode__InGame = 1,
    EFortInputMode__InGameCursor = 2
};

enum EFortUrlType : uint8_t
{
    EFortUrlType__NormalWebLink = 0,
    EFortUrlType__AccountCreationLink = 1,
    EFortUrlType__HelpLink = 2,
    EFortUrlType__EULALink = 3
};

enum EGridSortKind : uint8_t
{
    EGridSortKind__None = 0,
    EGridSortKind__ByNumber = 1,
    EGridSortKind__ByString = 2,
    EGridSortKind__ByNumberThenString = 3,
    EGridSortKind__ByStringThenNumber = 4
};

enum EItemShopTileSize : uint8_t
{
    EItemShopTileSize__Size_1_x = 0,
    EItemShopTileSize__Size_2_x = 1,
    EItemShopTileSize__Size_3_x = 2,
    EItemShopTileSize__Size_4_x = 3,
    EItemShopTileSize__Size_5_x = 4,
    EItemShopTileSize__Size_1_x = 5,
    EItemShopTileSize__Size_2_x = 6,
    EItemShopTileSize__Size_3_x = 7,
    EItemShopTileSize__Size_4_x = 8,
    EItemShopTileSize__Size_5_x = 9,
    EItemShopTileSize__Max = 10
};

enum EFortItemShopOfferType : uint8_t
{
    EFortItemShopOfferType__LevelBundle = 0,
    EFortItemShopOfferType__BattlePass = 1,
    EFortItemShopOfferType__ProgressiveCosmetic = 2,
    EFortItemShopOfferType__Crew = 3,
    EFortItemShopOfferType__Special = 4,
    EFortItemShopOfferType__Bundle = 5,
    EFortItemShopOfferType__Regular = 6,
    EFortItemShopOfferType__None = 7
};

enum EViolatorIntensity : uint8_t
{
    EViolatorIntensity__Low = 0,
    EViolatorIntensity__Medium = 1,
    EViolatorIntensity__High = 2
};

enum EItemShopCurrency : uint8_t
{
    EItemShopCurrency__VBucks = 0,
    EItemShopCurrency__RealMoney = 1
};

enum EFortItemShopLoadingState : uint8_t
{
    EFortItemShopLoadingState__Ready = 0,
    EFortItemShopLoadingState__CatalogRefreshing = 1,
    EFortItemShopLoadingState__ContentUpdating = 2
};

enum EFortItemCardSize : uint8_t
{
    EFortItemCardSize__XXS = 0,
    EFortItemCardSize__XS = 1,
    EFortItemCardSize__Wide_S = 2,
    EFortItemCardSize__S = 3,
    EFortItemCardSize__M = 4,
    EFortItemCardSize__L = 5,
    EFortItemCardSize__Wide_L = 6,
    EFortItemCardSize__XL = 7,
    EFortItemCardSize__XXL = 8
};

enum ESocialLinkType : uint8_t
{
    ESocialLinkType__X = 0,
    ESocialLinkType__TikTok = 1,
    ESocialLinkType__Instagram = 2,
    ESocialLinkType__Discord = 3,
    ESocialLinkType__YouTube = 4,
    ESocialLinkType__Max = 5
};

enum EActivityImageLoadingState : uint8_t
{
    EActivityImageLoadingState__Unset = 0,
    EActivityImageLoadingState__Loading = 1,
    EActivityImageLoadingState__Loaded = 2,
    EActivityImageLoadingState__Error = 3,
    EActivityImageLoadingState__Max = 4
};

enum EFortPlayerPowerRatingType : uint8_t
{
    EFortPlayerPowerRatingType__Auto = 0,
    EFortPlayerPowerRatingType__Campaign = 1,
    EFortPlayerPowerRatingType__Phoenix = 2,
    EFortPlayerPowerRatingType__Max_None = 3
};

enum EPreviousNextButtonType : uint8_t
{
    EPreviousNextButtonType__Previous = 0,
    EPreviousNextButtonType__Next = 1
};

enum EIsLegacyUIManagerResult : uint8_t
{
    EIsLegacyUIManagerResult__Yes = 1,
    EIsLegacyUIManagerResult__No = 0
};

enum EActivatePanelOption : uint8_t
{
    EActivatePanelOption__Show = 0,
    EActivatePanelOption__Hide = 1,
    EActivatePanelOption__PlatformDefault = 2
};

enum EFortUISpecialEvents : uint8_t
{
    NoEvent = 0,
    FritTemp = 1
};

enum ECountdownDisplay : uint8_t
{
    ECountdownDisplay__EventEndTime = 0,
    ECountdownDisplay__ChallengeUnlockTime = 1,
    ECountdownDisplay__ChallengeBundleUnlockTime = 2,
    ECountdownDisplay__UnlockAlreadySet = 3
};

enum EAthenaEventMatchInfoSortMethod : uint8_t
{
    EAthenaEventMatchInfoSortMethod__Eliminations = 0,
    EAthenaEventMatchInfoSortMethod__Place = 1,
    EAthenaEventMatchInfoSortMethod__Count = 2
};

enum EFrontendVisibilityMode : uint8_t
{
    EFrontendVisibilityMode__Normal = 0,
    EFrontendVisibilityMode__HideTopTabsOnly = 1,
    EFrontendVisibilityMode__HideTopTabsOnlyWithoutBottomBar = 2,
    EFrontendVisibilityMode__OnlyBottom = 3,
    EFrontendVisibilityMode__OnlyTop = 4,
    EFrontendVisibilityMode__OnlyTitleBar = 5,
    EFrontendVisibilityMode__Empty = 6
};

enum EBattlePassInputs : uint8_t
{
    EBattlePassInputs__Back = 0,
    EBattlePassInputs__ViewItem = 1,
    EBattlePassInputs__PreviewAction = 2,
    EBattlePassInputs__ReplayTrailer = 3,
    EBattlePassInputs__ShowAbout = 4,
    EBattlePassInputs__BulkBuyRewards = 5,
    EBattlePassInputs__PageComplete = 6,
    EBattlePassInputs__ShowAboutCustomization = 7,
    EBattlePassInputs__GiftBattlePass = 8,
    EBattlePassInputs__SwipeLeft = 9,
    EBattlePassInputs__SwipeRight = 10,
    EBattlePassInputs__RewardDetails = 11,
    EBattlePassInputs__COUNT = 12
};

enum EMotdButtonStyle : uint8_t
{
    EMotdButtonStyle__Main = 0,
    EMotdButtonStyle__Secondary = 1,
    EMotdButtonStyle__None = 2,
    EM_______wa_K____b_G_______h_K_fo____5 = 3
};

enum EFortActivityDetailsModalExitPath : uint8_t
{
    EFortActivityDetailsModalExitPath__Undefined = 0,
    EFortActivityDetailsModalExitPath__Discover = 1,
    EFortActivityDetailsModalExitPath__Lobby = 2,
    EFortActivityDetailsModalExitPath__Creator = 3,
    EFortActivityDetailsModalExitPath__Attributions = 4,
    EFortActivityDetailsModalExitPath__MAX_NUM = 5
};

enum EFortAthenaSurvivorTierBadgeSize : uint8_t
{
    EFortAthenaSurvivorTierBadgeSize__Small = 0,
    EFortAthenaSurvivorTierBadgeSize__Large = 1,
    EFortAthenaSurvivorTierBadgeSize__Count = 2
};

enum ECabinEmailViewState : uint8_t
{
    ECabinEmailViewState__Initial = 0,
    ECabinEmailViewState__Sending = 1,
    ECabinEmailViewState__Sent = 2,
    ECabinEmailViewState__SendFailed = 3
};

enum EColorPickerType : uint8_t
{
    EColorPickerType__Swatches = 0,
    EColorPickerType__CustomColor = 1,
    EColorPickerType__Both = 2
};

enum EColorPickerColorRepresentation : uint8_t
{
    EColorPickerColorRepresentation__HSV = 0,
    EColorPickerColorRepresentation__RGB = 1,
    EColorPickerColorRepresentation__Max_NONE = 2
};

enum ECountdownTimerState : uint8_t
{
    ECountdownTimerState__None = 0,
    ECountdownTimerState__Countdown = 1,
    ECountdownTimerState__Live = 2
};

enum EFortCreativeItemType : uint8_t
{
    EFortCreativeItemType__Chest = 0,
    EFortCreativeItemType__Item = 1,
    EFortCreativeItemType__Collection = 2,
    EFortCreativeItemType__SubItems = 3,
    EFortCreativeItemType__NoCreativeItems = 4
};

enum EProcessingInterestsState : uint8_t
{
    EProcessingInterestsState__None = 0,
    EProcessingInterestsState__Loading = 1,
    EProcessingInterestsState__Completed = 2,
    EProcessingInterestsState__Failed = 3
};

enum EDiscoverSearchMode : uint8_t
{
    EDiscoverSearchMode__Island = 0,
    EDiscoverSearchMode__Creator = 1,
    EDiscoverSearchMode__Unset = 2
};

enum EFortEarnedSubRewardType : uint8_t
{
    EFortEarnedSubRewardType__XP = 0,
    EFortEarnedSubRewardType__Bars = 1
};

enum EFortItemManagementMode : uint8_t
{
    EFortItemManagementMode__Details = 0,
    EFortItemManagementMode__Comparison = 1,
    EFortItemManagementMode__Mulch = 2
};

enum EFortCosmeticPreviewActionState : uint8_t
{
    EFortCosmeticPreviewActionState__CurrentActionState = 0,
    EFortCosmeticPreviewActionState__NextActionState = 1
};

enum ELibraryStorageItemViewModelType : uint8_t
{
    ELibraryStorageItemViewModelType__StorageItemId = 0,
    ELibraryStorageItemViewModelType__CurrentLinkCode = 1,
    ELibraryStorageItemViewModelType__CurrentDownload = 2
};

enum EFortUIMatchmakingStatus : uint8_t
{
    EFortUIMatchmakingStatus__Unready = 0,
    EFortUIMatchmakingStatus__WaitingForPlayersReadyUp = 1,
    EFortUIMatchmakingStatus__FindingServer = 2,
    EFortUIMatchmakingStatus__DownloadingContent = 3,
    EFortUIMatchmakingStatus__MatchFound = 4
};

enum ETagComparisonType : uint8_t
{
    ETagComparisonType__HasAny = 0,
    ETagComparisonType__HasAll = 1,
    ETagComparisonType__HasNone = 2,
    ETagComparisonType__HasAnyExact = 3,
    ETagComparisonType__HasAllExact = 4
};

enum EInteractionComparisonType : uint8_t
{
    EInteractionComparisonType__HasAny = 0,
    EInteractionComparisonType__HasNone = 1
};

enum EFortMtxStoreOfferType : uint8_t
{
    EFortMtxStoreOfferType__FoundersPack = 0,
    EFortMtxStoreOfferType__CurrencyPack = 1,
    EFor__r__EI_______2_____U__SS__ = 2,
    EFortMtxStoreOfferType__Max_None = 3
};

enum EPresenceIndicatorState : uint8_t
{
    EPresenceIndicatorState__Online = 0,
    EPresenceIndicatorState__Away = 1,
    EPresenceIndicatorState__Offline = 2,
    EPresenceIndicatorState__Blocked = 3
};

enum EFortPerksWidgetState : uint8_t
{
    EFortPerksWidgetState__Normal = 0,
    EFortPerksWidgetState__Upgrade = 1,
    EFortPerksWidgetState__Evolution = 2
};

enum EFortPlayerSurveyQuestionType : uint8_t
{
    EFortPlayerSurveyQuestionType__SingleChoice = 0,
    EFortPlayerSurveyQuestionType__MultipleChoice = 1,
    EFortPlayerSurveyQuestionType__Rating = 2
};

enum EFortPlayerSurveyResponseChoiceType : uint8_t
{
    CheckBox = 0,
    Radio = 1
};

enum EFortLoadoutActionType : uint8_t
{
    EFortLoadoutActionType__Rename = 0,
    EFortLoadoutActionType__Overwrite = 1,
    EFortLoadoutActionType__SaveNew = 2,
    EFortLoadoutActionType__Clear = 3,
    EFortLoadoutActionType__Delete = 4
};

enum EFortServerBrowserAction : uint8_t
{
    EFortServerBrowserAction__BattleLabServerCreate = 0,
    EFortServerBrowserAction__PlaygroundServerCreate = 1,
    EFortServerBrowserAction__CreativeServerCreate = 2,
    EFortServerBrowserAction__Play = 3,
    EFortServerBrowserAction__CreativeIslandCode = 4,
    EFortServerBrowserAction__CreativeDiscovery = 5
};

enum EFortSettingGameVisibility : uint8_t
{
    EFortSettingGameVisibility__None = 0,
    EFortSettingGameVisibility__Campaign = 1,
    EFortSettingGameVisibility__Athena = 2
};

enum EFortSidebarSpecialNavType : uint8_t
{
    EFortSidebarSpecialNavType__None = 0,
    EFortSidebarSpecialNavType__GoPrevious = 1,
    EFortSidebarSpecialNavType__GoRebootRally = 2,
    EFortSidebarSpecialNavType__GoPartyUp = 3,
    EFortSidebarSpecialNavType__GoFocusCilantro = 4,
    EFortSidebarSpecialNavType__GoCilantro = 5,
    EFortSidebarSpecialNavType__MaxNum = 6
};

enum ELocalUserOnlineStatus : uint8_t
{
    ELocalUserOnlineStatus__Online = 0,
    ELocalUserOnlineStatus__Offline = 1,
    ELocalUserOnlineStatus______ = 2,
    ELocalUserOnlineStatus__ExtendedAway = 3,
    ELocalUserOnlineStatus__DoNotDisturb = 4,
    ELocalUserOnlineStatus__Chat = 5
};

enum ELfgState : uint8_t
{
    ELfgState__NoResults = 0,
    ELfgState__Shuffling = 1,
    ELfgState__NoSocialTagsAdded = 2,
    ELfgState__LfgOff = 3,
    ELfgState__LfgUnavailable = 4,
    ELfgState__LfgOffNoSocialTags = 5,
    ELfgState__NoSocialTagsSelected = 6,
    ELfgState__NoFriendsSuggestLFG = 7,
    ELfgState__RebootInvitePlayerButton = 8,
    ELfgState__RebootInviteAllRallied = 9,
    ELfgState__ChangeTagsButton = 10,
    ELfgState__ApplyButton = 11,
    ELfgState__ShuffleButton = 12,
    ELfgState__LfgOffSocialBan = 13
};

enum EMultiFriendAction : uint8_t
{
    EMultiFriendAction__AcceptFriendRequest = 0
};

enum EFortSquadSlottingRestrictionReason : uint8_t
{
    EFortSquadSlottingRestrictionReason__ItemIsInInventoryOverflow = 0,
    EFortSquadSlottingRestrictionReason__MandatorySlotWouldBeEmptied = 1,
    EFortSquadSlottingRestrictionReason__ItemIsOnActiveExpedition = 2,
    EFortSquadSlottingRestrictionReason__HeroRequiresMissingGameplayTag = 3,
    EFortSquadSlottingRestrictionReason__HeroAlreadyEquippedInLoadout = 4
};

enum EPedestalNameplateAction : uint8_t
{
    EPedestalNameplateAction__None = 0,
    EPedestalNameplateAction__SendFriendRequest = 1,
    EPedestalNameplateAction__AcceptFriendRequest = 2
};

enum EPedestalNameplateMatchmakingStatus : uint8_t
{
    EPedestalNameplateMatchmakingStatus__None = 0,
    EPedestalNameplateMatchmakingStatus__Ready = 1,
    EPedestalNameplateMatchmakingStatus__NotReady = 2,
    EPedestalNameplateMatchmakingStatus__Playing = 3,
    EPedestalNameplateMatchmakingStatus__Disconnected = 4,
    EPedestalNameplateMatchmakingStatus__Downloading = 5
};

enum EPedestalSocialNudgeAction : uint8_t
{
    EPedestalSocialNudgeAction__None = 0,
    EPedestalSocialNudgeAction__Join = 1,
    EPedestalSocialNudgeAction__RequestToJoin = 2,
    EPedestalSocialNudgeAction__Invite = 3,
    EPedestalSocialNudgeAction__AcceptInvite = 4
};

enum EFortToastType : uint8_t
{
    EFortToastType__Default = 0,
    EFortToastType__Subdued = 1,
    EFortToastType__Impactful = 2
};

enum EFortUIState : uint8_t
{
    EFortUIState__Invalid = 0,
    EFortUIState__Login = 1,
    EFortUIState__JoinServer = 2,
    EFortUIState__SubgameSelect = 3,
    EFortUIState__FrontEnd = 4,
    EFortUIState__InGame_Custom = 5,
    EFortUIState__UNUSED = 6,
    EFortUIState__InGame_STW = 7,
    EFortUIState__Cinematic = 8,
    EFortUIState__InGame_BR = 9,
    EFortUIState__AthenaSpectator = 10,
    EFortUIState__Replay = 11,
    EFortUIState__InGame_STW_Custom = 12
};

enum EFortInventoryContext : uint8_t
{
    EFortInventoryContext__Game = 0,
    EFortInventoryContext__Lobby = 1,
    EFortInventoryContext__FrontEnd = 2,
    EFortInventoryContext__Pickup = 3
};

enum ENotificationResult : uint8_t
{
    ENotificatio____R_________e___ = 0,
    ENotificationResult__Declined = 1,
    ENotificationResult__Unknown = 2
};

enum EModalContainerSize : uint8_t
{
    EModalContainerSize__ExtraSmall = 0,
    EModalContainerSize__Small = 1,
    EModalContainerSize__Medium = 2,
    EModalContainerSize__Large = 3,
    EModalContainerSize__Max = 4
};

enum EFortBangSize : uint8_t
{
    EFortBangSize__XXS = 0,
    EFortBangSize__XS = 1,
    EFortBangSize__S = 2,
    EFortBangSize__M = 3,
    EFortBangSize__L = 4,
    EFortBangSize__XL = 5
};

enum EFortTutorialGlowType : uint8_t
{
    EFortTutorialGlowType__None = 0,
    EFortTutorialGlowType__Look = 1,
    EFortTutorialGlowType__Click = 2
};

enum EFortAnimSpeed : uint8_t
{
    EFortAnimSpeed__Instant = 0,
    EFortAnimSpeed__Fast = 1,
    EFortAnimSpeed__Normal = 2
};

enum EFortStatValueDisplayType : uint8_t
{
    EFortStatValueDisplayType__BasicPaired = 0,
    EFortStatValueDisplayType__BasicSingle = 1,
    EFortStatValueDisplayType__Unique = 2,
    EFortStatValueDisplayType__ElementalFire = 3,
    EFortStatValueDisplayType__ElementalIce = 4,
    EFortStatValueDisplayType__ElementalElectric = 5
};

enum EFortBuffState : uint8_t
{
    EFortBuffState__NoChange = 0,
    EFortBuffState__Better = 1,
    EFortBuffState__Worse = 2
};

enum EFortClampState : uint8_t
{
    EFortClampState__NoClamp = 0,
    EFortClampState__MinClamp = 1,
    EFortClampState__MaxClamp = 2
};

enum EFortComparisonType : uint8_t
{
    EFortComparisonType__None = 0,
    EFortComparisonType__HigherValue = 1,
    EFortComparisonType__LowerValue = 2,
    EFortComparisonType__Upgrade = 3
};

enum ESubscriptionContentTab : uint8_t
{
    ESubscriptionContentTab__SubscriptionManagementScreen = 0,
    ESubscriptionContentTab__ProgressiveItemScreen = 1,
    ESubscriptionContentTab__TemporaryItemsScreen = 2
};

enum EItemShopNavigationAction : uint8_t
{
    EItemShopNavigationAction__None = 0,
    EItemShopNavigationAction__ShowOfferDetails = 1,
    EItemShopNavigationAction__NavigateToOffer = 2
};

enum EButtonAction : uint8_t
{
    EButtonAction__NextTile = 0,
    EButtonAction__PreviousTile = 1,
    EButtonAction__Close = 2,
    EButtonAction__ActionButton = 3,
    EButtonAction__Unknown = 4
};

enum EMotdInteractionType : uint8_t
{
    EMotdInteractionType__SeenTeaser = 0,
    EMotdInteractionType__SeenFullScreen = 1,
    EMotdInteractionType__ButtonPressed = 2,
    EMotdInteractionType__Unknown = 3
};

enum EResponseActions : uint8_t
{
    EResponseActions__Seen = 0,
    EResponseActions__LeftFrontend = 1,
    EResponseActions__LogOut = 2,
    EResponseActions__Refreshed = 3,
    EResponseActions__ContentCleared = 4
};

enum EUIKitBlockVisualState : uint8_t
{
    EUIKitBlockVisualState__Invalid = 0,
    EUIKitBlockVisualState__Hovered = 1,
    EUIKitBlockVisualState__Unhovered = 2,
    EUIKitBlockVisualState__Focused = 3,
    EUIKitBlockVisualState__Unfocused = 4,
    EUIKitBlockVisualState__Pressed = 5,
    EUIKitBlockVisualState__Released = 6,
    EUIKitBlockVisualState__Disabled = 7,
    EUIKitBlockVisualState__Enabled = 8,
    EUIKitBlockVisualState__Selected = 9,
    EUIKitBlockVisualState__DeselectedIdle = 10,
    EUIKitBlockVisualState__DeselectedFocused = 11
};

enum EUIKitBlockInstantTransitionState : uint8_t
{
    EUIKitBlockInstantTransitionState__Invalid = 0,
    EUIKitBlockInstantTransitionState__InstantEnabled = 1,
    EUIKitBlockInstantTransitionState__InstantDisabled = 2,
    EUIKitBlockInstantTransitionState__InstantSelected = 3,
    EUIKitBlockInstantTransitionState__InstantDeselected = 4,
    EUIKitBlockInstantTransitionState__InstantLocked = 5,
    EUIKitBlockInstantTransitionState__InstantUnlocked = 6
};

enum ETrackedInputPointerStartType : uint8_t
{
    ETrackedInputPointerStartType__Invalid = 0,
    ETrackedInputPointerStartType__Pressed = 1,
    ETrackedInputPointerStartType__EnterBounds = 2
};

enum ETrackedInputPointerEndType : uint8_t
{
    ETrackedInputPointerEndType__Unknown = 0,
    ETrackedInputPointerEndType__Released = 1,
    ETrackedInputPointerEndType__Cancelled = 2,
    ETrackedInputPointerEndType__ExitBounds = 3
};

enum EFortServerItemIneligibleReason : uint8_t
{
    EFortServerItemIneligibleReason__None = 0,
    EFortServerItemIneligibleReason__PartyTooBig = 1,
    EFortServerItemIneligibleReason__PartyTooSmall = 2,
    EFortServerItemIneligibleReason__NotPartyLeader = 3,
    EFortServerItemIneligibleReason__MatchmakingAlready = 4,
    EFortServerItemIneligibleReason__NotSupportedByLeto = 5,
    EFortServerItemIneligibleReason__InvalidData = 6
};

enum EAthenaConfirmationResult : uint8_t
{
    EAthenaConfirmationResult__Confirmed = 0,
    EAthenaConfirmationResult__Declined = 1,
    EAthenaConfirmationResult__Canceled = 2,
    EAthenaConfirmationResult__Max_NONE = 3
};

enum EEquippedWeaponDisplay : uint8_t
{
    EEquippedWeaponDisplay__None = 0,
    EEquippedWeaponDisplay__Resource = 1,
    EEquippedWeaponDisplay__Magazine = 2,
    EEquippedWeaponDisplay__Utility = 3,
    EEquippedWeaponDisplay__Chargeable = 4
};

enum EAthenaPlayerActionAlert : uint8_t
{
    EAthenaPlayerActionAMS____ = 0,
    EAthenaPlayerActionAlert__PlayerKill = 1,
    EAthenaPlayerActionAlert__EnteredStorm = 2,
    EAthenaPlayerActionAlert__NewZebulonDrone = 3,
    EAthenaPlayerActionAlert__NewZebulonDroneYou = 4
};

enum EFortAthenaPlaylist : uint8_t
{
    EFortAthenaPlaylist__AthenaSolo = 0,
    EFortAthenaPlaylist__AthenaDuo = 1,
    EFortAthenaPlaylist__AthenaSquad = 2
};

enum EAthenaLockerInfoRestrictionWarning : uint8_t
{
    EAthenaLockerInfoRestrictionWarning__UnsatisfiedExclusiveItem = 0,
    EAthenaLockerInfoRestrictionWarning__LockedEmote = 1,
    EAthenaLockerInfoRestrictionWarning__CosmeticRestriction = 2,
    EAthenaLockerInfoRestrictionWarning__AllItemsAreArchived = 3,
    EAthenaLockerInfoRestrictionWarning__Unknown = 4
};

enum EFortMarkerActions : uint8_t
{
    EFortMarkerActions__None = 0,
    EFortMarkerActions__Cancel = 1,
    EFortMarkerActions__Confirm = 2,
    EFortMarkerActions__CancelAndReturnNPC = 3,
    EFortMarkerActions__Unconfirm = 4
};

enum EHealthBarType : uint8_t
{
    EHealthBarType__Health = 0,
    EHealthBarType__Shield = 1,
    EHealthBarType__Overshield = 2,
    EHealthBarType__Armor = 3,
    EHealthBarType__Stamina = 4,
    EHealthBarType__VehicleHealth = 5,
    EHealthBarType__SignalInStorm = 6
};

enum EAthenaSquadListUpdateType : uint8_t
{
    EAthenaSquadListUpdateType__None = 0,
    EAthenaSquadListUpdateType__CanResurrect = 1,
    EAthenaSquadListUpdateType__FindResurrectChip = 2
};

enum ERespawnUIState : uint8_t
{
    ERespawnUIState__Hidden = 0,
    ERespawnUIState__ShowRespawnEnabled = 1,
    ERespawnUIState__ShowRespawnDisabled = 2
};

enum EStormSurgeThresholdType : uint8_t
{
    EStormSurgeThresholdType__None = 0,
    EStormSurgeThresholdType__Above = 1,
    EStormSurgeThresholdType__Below = 2,
    EStormSurgeThresholdType__Equal = 3
};

enum EWinConditionParentType : uint8_t
{
    EWinConditionParentType__None = 0,
    EWinConditionParentType__Desktop = 1,
    EWinConditionParentType__Mobile = 2
};

enum ELocationEntryState : uint8_t
{
    ELocationEntryState__Found = 0,
    ELocationEntryState__NotFound = 1,
    ELocationEntryState__Unused = 2
};

enum EMinigameActivityWidgetStatFormat : uint8_t
{
    EMinigameActivityWidgetStatFormat__Score = 0,
    EMinigameActivityWidgetStatFormat__Time = 1,
    EMinigameActivityWidgetStatFormat__AddTime = 2,
    EMinigameActivityWidgetStatFormat__Distance = 3,
    EMinigameActivityWidgetStatFormat__Laps = 4
};

enum EFlowRiderElement : uint8_t
{
    EFlowRiderElement__AutoReadyUp = 0,
    EFlowRiderElement__Button_NextMatch = 1,
    EFlowRiderElement__Button_PlayWithNewTeam = 2,
    EFlowRiderElement__Button_PlayWithNewSquad = 3,
    EFlowRiderElement__Button_ReadyUp = 4
};

enum EPostGamePlacement : uint8_t
{
    EPostGamePlacement__Win = 0,
    EPostGamePlacement__Lose = 1,
    EPostGamePlacement__Tie = 2,
    EPostGamePlacement__NoPlacement = 3
};

enum ENumberOfSlots : uint8_t
{
    ENumberOfSlots__OneSlot = 0,
    ENumberOfSlots__TwoSlots = 1,
    ENumberOfSlots__ThreeSlots = 2,
    ENumberOfSlots__FourSlots = 3,
    ENumberOfSlots__FiveSlots = 4,
    ENumberOfSlots__SixSlots = 5,
    ENumberOfSlots__SevenSlots = 6,
    ENumberOfSlots__EightSlots = 7,
    ENumberOfSlots__NineSlots = 8,
    ENumberOfSlots__TenSlots = 9,
    ENumberOfSlots__ElevenSlots = 10,
    ENumberOfSlots__TwelveSlots = 11,
    ENumberOfSlots__ThirteenSlots = 12,
    ENumberOfSlots__FourteenSlots = 13,
    ENumberOfSlots__FifteenSlots = 14,
    ENumberOfSlots__SixteenSlots = 15,
    ENumberOfSlots__Num = 16
};

enum EBattleLabAlertType : uint8_t
{
    EBattleLabAlertType__QuestComplete = 0,
    EBattleLabAlertType__QuestGranted = 1,
    EBattleLabAlertType__Reward = 2
};

enum EBracketNodeState : uint8_t
{
    EBracketNodeState__LocalTeam = 0,
    EBracketNodeState__EnemyTeam = 1,
    EBracketNodeState__Neutral = 2
};

enum ESurvivalObjectiveIconState : uint8_t
{
    ESurvivalObjectiveIconState__None = 0,
    ESurvivalObjectiveIconState__Spawned = 1,
    ESurvivalObjectiveIconState__Destroyed = 2
};

enum EDiscoCaptureUIState : uint8_t
{
    EDiscoCaptureUIState__None = 0,
    EDiscoCaptureUIState__Hidden = 1,
    EDiscoCaptureUIState__Dance = 2,
    EDiscoCaptureUIState__Capturing = 3,
    EDiscoCaptureUIState__Contested = 4
};

enum EDiscoCaptureIconState : uint8_t
{
    EDiscoCaptureIconState__None = 0,
    EDiscoCaptureIconState__Hidden = 1,
    EDiscoCaptureIconState__Neutral = 2,
    EDiscoCaptureIconState__AllyCaptured = 3,
    EDiscoCaptureIconState__EnemyCaptured = 4
};

enum EDiscoCaptureProgressState : uint8_t
{
    EDiscoCaptureProgressState__None = 0,
    EDiscoCaptureProgressState__AllyProgress = 1,
    EDiscoCaptureProgressState__EnemyProgress = 2
};

enum EDiscoScoreProgressTypes : uint8_t
{
    EDiscoScoreProgressTypes__None = 0,
    EDiscoScoreProgressTypes__ProgressSoundMild = 1,
    EDiscoScoreProgressTypes__ProgressSoundMedium = 2,
    EDiscoScoreProgressTypes__ProgressSoundStrong = 3,
    EDiscoScoreProgressTypes__CountdownSoundNormal = 4,
    EDiscoScoreProgressTypes__CountdownSoundStrong = 5
};

enum EHeistExitCraftUIState : uint8_t
{
    EHeistExitCraftUIState__None = 0,
    EHeistExitCraftUIState__OnTheWay = 1,
    EHeistExitCraftUIState__Incoming = 2,
    EHeistExitCraftUIState__Arrived = 3
};

enum EHeistBlingIconState : uint8_t
{
    EHeistBlingIconState__None = 0,
    EHeistBlingIconState__SupplyDrop = 1,
    EHeistBlingIconState__PickupItem = 2,
    EHeistBlingIconState__CarriedEnemy = 3,
    EHeistBlingIconState__CarriedAlly = 4
};

enum EHeistExitCrafs_y_______ : uint8_t
{
    EHeistExitCraftIconState__None = 0,
    EHeistExitCraftIconState__Incoming = 1,
    EHeistExitCraftIconState__Spawned = 2,
    EHeistExitCraftIconState__Exited = 3
};

enum ETDMScoreProgressTypes : uint8_t
{
    ETDMScoreProgressTypes__None = 0,
    ETDMScoreProgressTypes__ProgressSoundMild = 1,
    ETDMScoreProgressTypes__ProgressSoundMedium = 2,
    ETDMScoreProgressTypes__ProgressSoundStrong = 3,
    ETDMScoreProgressTypes__CountdownSoundNormal = 4,
    ETDMScoreProgressTypes__CountdownSoundStrong = 5
};

enum EQuestCategoryButtonTimerState : uint8_t
{
    EQuestCategoryButtonTimerState__Countdown = 0,
    EQuestCategoryButtonTimerState__Custom = 1,
    EQuestCategoryButtonTimerState__Disabled = 2,
    EQuestCategoryButtonTimerState__None = 3
};

enum EComboSlotType : uint8_t
{
    EComboSlotType__Primary = 0,
    EComboSlotType__Secondary = 1,
    EComboSlotType__Combo = 2,
    EComboSlotType__Creative = 3,
    EComboSlotType__COUNT = 4
};

enum EBacchusSignalQuality : uint8_t
{
    EBacchusSignalQuality__None = 0,
    EBacchusSignalQuality__Low = 1,
    EBacchusSignalQuality__Medium = 2,
    EBacchusSignalQuality__High = 3
};

enum EBehaviorTrackingType : uint8_t
{
    EBehaviorTrackingType__Cue = 0,
    EBehaviorTrackingType__AbilityCooldownTags = 1,
    EBehaviorTrackingType__COUNT = 2
};

enum EBlurState : uint8_t
{
    EBlurState__Disabled = 0,
    EBlurState__PartlyEnabled = 1,
    EBlurState__Enabled = 2
};

enum EAthenaSpectatorNameplateDistanceState : uint8_t
{
    EAthenaSpectatorNameplateDistanceState__Near = 0,
    EAthenaSpectatorNameplateDistanceState__MidDistance = 1,
    EAthenaSpectatorNameplateDistanceState__FurtherThanMaxDistance = 2
};

enum EAthenaSpectatorNameplateDetailState : uint8_t
{
    EAthenaSpectatorNameplateDetailState__High = 0,
    EAthenaSpectatorNameplateDetailState__Low = 1,
    EAthenaSpectatorNameplateDetailState__Arrow = 2,
    EAthenaSpectatorNameplateDetailState__Off = 3
};

enum EBattleMapTimelineWidgetState : uint8_t
{
    EBattleMapTimelineWidgetState__None = 0,
    EBattleMapTimelineWidgetState__HasNext = 1,
    EBattleMapTimelineWidgetState__HasPrevious = 2,
    EBattleMapTimelineWidgetState__IsInReplay = 4,
    EBattleMapTimelineWidgetState__CanBeScrubbed = 8,
    EBattleMapTimelineWidgetState__IsStreaming = 16,
    EBattleMapTimelineWidgetState__Invalid = 32
};

enum ESpectatorBuildCountType : uint8_t
{
    ESpectatorBuildCountType__BuildCount = 0,
    ESpectatorBuildCountType__Wood = 1,
    ESpectatorBuildCountType__Stone = 2,
    ESpectatorBuildCountType__Metal = 3,
    ESpectatorBuildCountType__Gold = 4
};

enum ESpectatorLeaderboardEntryType : uint8_t
{
    ESpectatorLeaderboardEntryType__ScoreWithEndScore = 0,
    ESpectatorLeaderboardEntryType__NoEndScore = 1
};

enum ESpectatorMapPlayerListState : uint8_t
{
    ESpectatorMapPlayerListState__Default = 0,
    ESpectator__m_a________________o___F____ = 1,
    ESpectatorMapPlayerListState__Eliminated = 2
};

enum ESpectatorPlayerListSortMethod : uint8_t
{
    ESpectatorPlayerListSortMethod__SquadId = 0,
    ESpectatorPlayerListSortMethod__PlayerName = 1,
    ESpectatorPlayerListSortMethod__Eliminations = 2,
    ESpectatorPlayerListSortMethod__EventScore = 3,
    ESpectatorPlayerListSortMethod__State = 4,
    ESpectatorPlayerListSortMethod__Count = 5
};

enum EOptionalFlowSteps : uint8_t
{
    EOptionalFlowSteps__TryShowMobileGuidedTutorial = 0,
    EOptionalFlowSteps__TryShowMOTDs = 1,
    EOptionalFlowSteps__TryShowNormalBanModal = 2,
    EOptionalFlowSteps__TryShowSocialBanModal = 3,
    EOptionalFlowSteps__TryShowMFAModal = 4,
    EOptionalFlowSteps__TryShowCrossplayDialog = 5,
    EOptionalFlowSteps__TryShowSocialImport = 6,
    EOptionalFlowSteps__TryShowSurveys = 7,
    EOptionalFlowSteps__TryShowBadMatchPopup = 8,
    EOptionalFlowSteps__TryShowMobileInGameAppRating = 9,
    EOptionalFlowSteps__TryShowSamsungSensorWarning = 10,
    EOptionalFlowSteps__TryShowBattlePassPurchaseScreen = 11,
    EOptionalFlowSteps__TryShowMultipleSubscriptionsAlert = 12,
    EOptionalFlowSteps__TryPushGiftingScreen = 13,
    EOptionalFlowSteps__TryPushMessagingScreen = 14,
    EOptionalFlowSteps__TryGoToBattlePassTab = 15,
    EOptionalFlowSteps__TryShowRefundTokenNotification = 16,
    EOptionalFlowSteps__TryShowPriceChangeAcknowledgeNotification = 17,
    EOptionalFlowSteps__TryShowSettingsChangeAcknowledgementScreen = 18,
    EOptionalFlowSteps__TryShowEnterCabinModeScreen = 19,
    EOptionalFlowSteps__TryShowVoiceReportingIntroModal = 20,
    EOptionalFlowSteps__TryShowContentGatingIntroModal = 21,
    EOptionalFlowSteps__TryShowInterestsSelectionModal = 22,
    EOptionalFlowSteps__TryPlayEcosystemTrailer = 23,
    EOptionalFlowSteps__TryShowPlaytimeExpiredModal = 24
};

enum EFuelTankState : uint8_t
{
    EFuelTankState__Empty = 0,
    EFuelTankState__LowFuel = 1,
    EFuelTankState__RegularFuel = 2,
    EFuelTankState__TankFull = 3
};

enum EActionBindingComparisonType : uint8_t
{
    EActionBindingComparisonType__NoneBound = 0,
    EActionBindingComparisonType__AnyBound = 1,
    EActionBindingComparisonType__AllBound = 2
};

enum ENumericalIndicatorActionType : uint8_t
{
    ENumericalIndicatorActionType__Adding = 0,
    ENumericalIndicatorActionType__Removing = 1,
    ENumericalIndicatorActionType__Nothing = 2
};

enum ELinkAcrossSimpleAction : uint8_t
{
    ELinkAcrossSimpleAction__AddToAll = 0,
    ELinkAcrossSimpleAction__RemovedFromAll = 1,
    ELinkAcrossSimpleAction__Custom = 2,
    ELinkAcrossSimpleAction__Nothing = 3
};

enum EHUDLayoutToolToasterType : uint8_t
{
    EHUDLayoutToolToasterType__Success = 0,
    EHUDLayoutToolToasterType__Failure = 1,
    EHUDLayoutToolToasterType__LocalFailure = 2,
    EHUDLayoutToolToasterType__CloudFailure = 3
};

enum EFortMaterialProgressBarSection : uint8_t
{
    EFortMaterialProgressBarSection__Primary = 0,
    EFortMaterialProgressBarSection__Secondary = 1,
    EFortMaterialProgressBarSection__Tertiary = 2,
    EFortMaterialProgressBarSection__Negative = 3,
    EFortMaterialProgressBarSection__MAX_PROGRESS_BAR_SECTIO_U = 4
};

enum ECrewDetailsTag : uint8_t
{
    ECrewDetailsTag__SeasonLaunchBenefit = 0,
    ECrewDetailsTag__MonthlyBenefit = 1,
    ECrewDetailsTag__CrewMonthBenefit = 2,
    ECrewDetailsTag__AvailableUntilBenefit = 3,
    ECrewDetailsTag__MonthlySubscription = 4,
    ECrewDetailsTag__None = 5
};

enum ECrewTileType : uint8_t
{
    ECrewTileType__None = 0,
    ECrewTileType__Basic = 1,
    ECrewTileType__BattlePass = 2,
    ECrewTileType__CrewPack = 3,
    ECrewTileType__ProgressiveCosmetic = 4,
    ECrewTileType__TemporaryItems = 5
};

enum ECrewItemShopTileType : uint8_t
{
    ECrewItemShopTileType__None = 0,
    ECrewItemShopTileType__Subscription = 1,
    ECrewItemShopTileType__ProgressiveCosmetic = 2
};

enum EAthenaNewsStyle : uint8_t
{
    EAthenaNewsStyle__None = 0,
    EAthenaNewsStyle__SpecialEvent = 1,
    EAthenaNewsStyle__SpecialEvent2 = 2
};

enum EBuildingFocusType : uint8_t
{
    EBuildingFocusType__Contextual = 0,
    EBuildingFocusType__Interactable = 1,
    EBuildingFocusType__Normal = 2,
    EBuildingFocusType__Count = 3
};

enum EVaultItemLimitStatus : uint8_t
{
    EVaultItemLimitStatus__WellBelowCapacity = 0,
    EVaultItemLimitStatus__NearCapacity = 1,
    EVaultItemLimitStatus__AtCapacity = 2,
    EVaultItemLimitStatus__OverCapacity = 3
};

enum EItemRecyclingRestrictionReason : uint8_t
{
    EItemRecyclingRestrictionReason__InnatelyUnrecyclable = 0,
    EItemRecyclingRestrictionReason__IsSlottedGroundOperative = 1,
    EItemRecyclingRestrictionReason__MissingCatalyst = 2,
    EItemRecyclingRestrictionReason__ItemOutOnExpedition = 3,
    EItemRecyclingRestrictionReason__InUseByCrafting = 4,
    EItemRecyclingRestrictionReason__MulchingNotAllowed = 5,
    EItemRecyclingRestrictionReason__IsSlottedAttributeWorker = 6
};

enum EItemRecyclingWarning : uint8_t
{
    EItemRecyclingWarning__HighLevel = 0,
    EItemRecyclingWarning__HighRarity = 1,
    EItemRecyclingWarning__CanSlotInCollectionBook = 2
};

enum EConversionControlKeyRequest : uint8_t
{
    EConversionControlKeyRequest__AllKeys = 0,
    EConversionControlKeyRequest__NonConsumableKeys = 1,
    EConversionControlKeyRequest__ConsumableKeys = 2
};

enum ECardPackPurchaseError : uint8_t
{
    ECardPackPurchaseError__PendingServerConfirmation = 0,
    ECardPackPurchaseError__CannotAffordItem = 1,
    ECardPackPurchaseError__NoneLeft = 2,
    ECardPackPurchaseError__PurchaseAlreadyPending = 3,
    ECardPackPurchaseError__NoConnection = 4
};

enum EPauseType : uint8_t
{
    EPauseType__NoPause = 0,
    EPauseType__Rare = 1,
    EPauseType__New = 2,
    EPauseType__NewAndRare = 3
};

enum EShowChannelDetails : uint8_t
{
    EShowChannelDetails__FromMinigameSettings = 0,
    EShowChannelDetails__ForceShow = 1,
    EShowChannelDetails__ForceHide = 2
};

enum EFortCreativeIslandLinkCategory : uint8_t
{
    EFortCreativeIslandLinkCategory__Default = 0,
    EFortCreativeIslandLinkCategory__Favorite = 1,
    EFortCreativeIslandLinkCategory__Published = 2,
    EFortCreativeIslandLinkCategory__Recent = 3
};

enum ECreativePublishError : uint8_t
{
    ECreativePublishError__None = 0,
    ECreativePublishError__RateLimited = 1,
    ECreativePublishError__PlotOverBudget = 2,
    ECreativePublishError__LinkCodeInvalid = 3,
    ECreativePublishError__SanitizationFiltered = 4,
    ECreativePublishError__Other = 5
};

enum EConfirmDialogType : uint8_t
{
    EConfirmDialogType__CancelChanges = 0,
    EConfirmDialogType__CharLimitExceeded = 1,
    EConfirmDialogType__MarkupWarning = 2
};

enum EButtonContext : uint8_t
{
    EButtonContext__NoButtonSelected = 0,
    EButtonContext__ButtonSelected = 1,
    EButtonContext__StylingButtons = 2
};

enum EFortCreativeServerPrivacySetting : uint8_t
{
    EFortCreativeServerPrivacySetting__Unknown = 0,
    EFortCreativeServerPrivacySetting__Private = 1,
    EFortCreativeServerPrivacySetting__Public = 2
};

enum EFortDiscoverLabelStyle : uint8_t
{
    EFortDiscoverLabelStyle__Utility = 0,
    EFortDiscoverLabelStyle__Attention = 1,
    EFortDiscoverLabelStyle__Social = 2,
    EFortDiscoverLabelStyle__Deal = 3,
    EFortDiscoverLabelStyle__Quiet = 4,
    EFortDiscoverLabelStyle__Max_NONE = 5
};

enum EActivityItemType : uint8_t
{
    EActivityItemType__Island = 0,
    EActivityItemType__Creator = 1,
    EActivityItemType__PlayingNow = 2,
    EActivityItemType__SurfaceTile = 3,
    EActivityItemType__IPTile = 4,
    EActivityItemType__Max = 5
};

enum EDiscoverLoadingState : uint8_t
{
    EDiscoverLoadingState__Unset = 0,
    EDiscoverLoadingState__Loading = 1,
    EDiscoverLoadingState__Loaded = 2,
    EDiscove______7__zX_________ = 3,
    EDiscoverLoadingState__Max = 4
};

enum EHabaneroDisplayState : uint8_t
{
    EHabaneroDisplayState__Solo = 0,
    EHabaneroDisplayState__Party = 1,
    EHabaneroDisplayState__Hidden = 2
};

enum EChatMessageOrigin : uint8_t
{
    EChatMessageOrigin__Local = 0,
    EChatMessageOrigin__Remote = 1,
    EChatMessageOrigin__System = 2,
    EChatMessageOrigin__Unknown = 3
};

enum ECollabIPGatingContext : uint8_t
{
    ECollabIPGatingContext__Edit = 0,
    ECollabIPGatingContext__CreateButton = 1,
    ECollabIPGatingContext__JoinProgramButton = 2,
    ECollabIPGatingContext__ReviewTermsButton = 3,
    ECollabIPGatingContext__ProgramDetailsButton = 4,
    ECollabIPGatingContext__NameIslandDialog = 5,
    ECollabIPGatingContext__Disclaimer = 6,
    ECollabIPGatingContext__Icon = 7,
    ECollabIPGatingContext__BrandAndICPDialog = 8,
    ECollabIPGatingContext__BrandOnlyDialog = 9
};

enum ECollabIPGatingStatus : uint8_t
{
    ECollabIPGatingStatus__Pending = 0,
    ECollabIPGatingStatus__None = 2,
    ECollabIPGatingStatus__ICP = 4,
    ECollabIPGatingStatus__IP = 8,
    ECollabIPGatingStatus__ICP_and_IP = 12,
    ECollabIPGatingStatus__LIME = 16
};

enum ECollabIPGatingType : uint8_t
{
    ECollabIPGatingType__None = 0,
    ECollabIPGatingType__ICP_and_IP = 1,
    ECollabIPGatingType__Lime = 2
};

enum EFortKeybindForcedHoldStatus : uint8_t
{
    EFortKeybindForcedHoldStatus__NoForcedHold = 0,
    EFortKeybindForcedHoldStatus__ForcedHold = 1,
    EFortKeybindForcedHoldStatus__NeverShowHold = 2
};

enum EFortModifiedStatus : uint8_t
{
    EFortModifiedStatus__IsDefault = 0,
    EFortModifiedStatus__IsModified = 1,
    EFortModifiedStatus__Unsupported = 2
};

enum EModalContainerSlot : uint8_t
{
    EModalContainerSlot__Top = 0,
    EModalContainerSlot__Middle = 1,
    EModalContainerSlot__Bottom = 2,
    EModalContainerSlot__Background = 3,
    EModalContainerSlot__Max = 4
};

enum EPinGrantState : uint8_t
{
    EPinGrantState__Initial = 0,
    EPinGrantState__Error = 1,
    EPinGrantState__Downloading = 2,
    EPinGrantState__Granted = 3
};

enum ERedeemCodeFailureReason : uint8_t
{
    ERedeemCodeFailureReason__InvalidCode = 0,
    ERedeemCodeFailureReason__CodeAlreadyUsed = 1,
    ERedeemCodeFailureReason__AlreadyHasAccess = 2,
    ERedeemCodeFailureReason__FailedToGetItem = 3,
    ERedeemCodeFailureReason__Unknown = 4
};

enum EFortRewardItemType : uint8_t
{
    EFortRewardItemType__RewardedBadges = 0,
    EFortRewardItemType__MissedBadges = 1,
    EFortRewardItemType__RewardedItems = 2,
    EFortRewardItemType__RewardedAccountItems = 3
};

enum EFortTouchControlRegion : uint8_t
{
    EFortTouchControlRegion__MovePlayer = 0,
    EFortTouchControlRegion__RotateCamera = 1,
    EFortTouchControlRegion__NoRegion = 2,
    EFortTouchControlRegion__COUNT = 3
};

enum EFortControlType : uint8_t
{
    EFortControlType__None = 0,
    EFortControlType__CameraAndMovement = 1,
    EFortControlType__Picking = 2,
    EFortControlType__COUNT = 3
};

enum ETouchState : uint8_t
{
    ETouchState__None = 0,
    ETouchState__WaitingForStart = 1,
    ETouchState__Started = 2,
    ETouchState__Active = 3,
    ETouchState__COUNT = 4
};

enum EForcedIntroTextDisplayState : uint8_t
{
    EForcedIntroTextDisplayState__Initialized = 0,
    EForcedIntroTextDisplayState__WaitingForPlaylistPlugin = 1,
    EForcedIntroTextDisplayState__WaitingForMatchmakingStartTime = 2,
    EForcedIntroTextDisplayState__InitialDelay = 3,
    EForcedIntroTextDisplayState__Matchmaking = 4,
    EForcedIntroTextDisplayState__Success = 5,
    EForcedIntroTextDisplayState__Failure = 6
};

enum EFortAthenaRewardState : uint8_t
{
    EFortAthenaRewardState__LevelAchieved = 0,
    EFortAthenaRewardState__Claimed = 1,
    EFortAthenaRewardState__ForceLocked = 2,
    EFortAthenaRewardState__Owned = 3,
    EFortAthenaRewardState__Max_None = 4
};

enum ECosmeticCompatibleMode : uint8_t
{
    ECosmeticCompatibleMode__BattleRoyale = 0,
    ECosmeticCompatibleMode__Juno = 1,
    ECosmeticCompatibleMode__DelMar = 2,
    ECosmeticCompatibleMode__Sparks = 3
};

enum ESceneTransitionType : uint8_t
{
    ESceneTransitionType__NoTransition = 0,
    ESceneTransitionType__Clockwise = 1,
    ESceneTransitionType__CounterClockwise = 2
};

enum EVaultWorldTransitionDirection : uint8_t
{
    EVaultWorldTransitionDirection__Forward = 0,
    EVaultWorldTransitionDirection__Backward = 1,
    EVaultWorldTransitionDirection__None = 2
};

enum EShareButtonType : uint8_t
{
    EShareButtonType__IOS = 0,
    EShareButtonType__Android = 1,
    EShareButtonType__Generic = 2
};

enum ESidebarExitActions : uint8_t
{
    ESidebarExitActions__None = 0,
    ESidebarExitActions__LeaveExperience = 1,
    ESidebarExitActions__AthenaLeaveAction = 2,
    ESidebarExitActions__LogOut = 3,
    ESidebarExitActions__QuitGame = 4
};

enum ESidebarExitConfirmationNavBehavior : uint8_t
{
    ESidebarExitConfirmationNavBehavior__None = 0,
    ESidebarExitConfirmationNavBehavior__ButtonYesFocus = 1,
    ESidebarExitConfirmationNavBehavior__ButtonYesSelection = 2,
    ESidebarExitConfirmationNavBehavior__ButtonYesFocusSelection = 3,
    ESidebarExitConfirmationNavBehavior__ButtonNoFocus = 4,
    ESidebarExitConfirmationNavBehavior__ButtonNoSelection = 5,
    ESidebarExitConfirmationNavBehavior__ButtonNoFocusSelection = 6
};

enum ESocialTutorialType : uint8_t
{
    ESocialTutorialType__None = 0,
    ESocialTutorialType__TagsEditor = 1,
    ESocialTutorialType__LookingForParty = 2,
    ESocialTutorialType__LikeIsland = 3,
    ESocialTutorialType__RebootRallyUsers = 4,
    ESocialTutoria___3____q1_l__e_8j____7_____VR____P = 5,
    ESocialTutorialType__KWSVoiceChannelPanelSupervisedSettings = 6,
    ESocialTutorialType__VoiceReport = 7,
    ESocialTutorialType__ContentRatingSettings = 8,
    ESocialTutorialType__ContentUnlockedSettings = 9,
    ESocialTutorialType__CreativeContentSettings = 10,
    ESocialTutorialType__FollowThisCreatorInFortnite = 11,
    ESocialTutorialType__FollowedYourFirstCreator = 12,
    ESocialTutorialType__SearchForCreators = 13,
    ESocialTutorialType__ShareActivitySetting = 14,
    ESocialTutorialType__FavoriteCollection = 15,
    ESocialTutorialType__Cilantro = 16,
    ESocialTutorialType__LibraryInHomebar = 17,
    ESocialTutorialType__PresetCountIncreaseCoachMark = 18,
    ESocialTutorialType__DownloadStarted = 19,
    ESocialTutorialType__MusicPassUniversalXp = 20,
    ESocialTutorialType__SeasonPassClaimReward = 21,
    ESocialTutorialType__SeasonPassClaimAllRewards = 22,
    ESocialTutorialType__MaxNum = 23
};

enum EFortSidebarSocialInteractionArrow : uint8_t
{
    EFortSidebarSocialInteractionArrow__None = 0,
    EFortSidebarSocialInteractionArrow__Up = 1,
    EFortSidebarSocialInteractionArrow__Down = 2,
    EFortSidebarSocialInteractionArrow__Left = 3,
    EFortSidebarSocialInteractionArrow__Right = 4
};

enum EFriendLinkShareButtonType : uint8_t
{
    EFriendLinkShareButtonType__IOS = 0,
    EFriendLinkShareButtonType__Android = 1,
    EFriendLinkShareButtonType__Generic = 2
};

enum ESidebarState : uint8_t
{
    ESidebarState__TabButtons = 0,
    ESidebarState__UserListPanels = 1,
    ESidebarState__ExitPopup = 2
};

enum EFortSocialUserEntryType : uint8_t
{
    EFortSocialUserEntryType__None = 0,
    EFortSocialUserEntryType__PartyMember = 1,
    EFortSocialUserEntryType__TeamMember = 2,
    EFortSocialUserEntryType__VoiceChatMember = 3,
    EFortSocialUserEntryType__UserSearchResult = 4,
    EFortSocialUserEntryType__SuggestedFriend = 5,
    EFortSocialUserEntryType__JoinRequest = 6,
    EFortSocialUserEntryType__RecentPlayer = 7,
    EFortSocialUserEntryType__SocialUser = 8,
    EFortSocialUserEntryType__FriendInvite = 9,
    EFortSocialUserEntryType__JoinableParty = 10
};

enum ESocialTagListHighlightPolicy : uint8_t
{
    ESocialTagListHighlightPolicy__All = 0,
    ESocialTagListHighlightPolicy__TagList = 1,
    ESocialTagListHighlightPolicy__LocalUser = 2,
    ESocialTagListHighlightPolicy__FullColor = 3
};

enum ESocialTagCategory : uint8_t
{
    ESocialTagCategory__GameModes = 0,
    ESocialTagCategory__Mood = 1,
    ESocialTagCategory__Utility = 2,
    ESocialTagCategory__Competitive = 3,
    ESocialTagCategory__Other = 4
};

enum EFortLoginInteraction : uint8_t
{
    EFortLoginInteraction__Begin = 0,
    EFortLoginInteraction__StartLogin = 1,
    EFortLoginInteraction__CredentialSelect = 2,
    EFortLoginInteraction__NamePassword = 3,
    EFortLoginInteraction__AccountNotFound = 4,
    EFortLoginInteraction__CreateDisplayName = 5,
    EFortLoginInteraction__MultiFactorAuth = 6,
    EFortLoginInteraction__EULA = 7,
    EFortLoginInteraction__AccountLink = 8,
    EFortLoginInteraction__AccountPinLink = 9,
    EFortLoginInteraction__WebLogi_ = 10,
    EFortLoginInteraction__WebAccountCreation = 11,
    EFortLoginInteraction__AgeGateHeadless = 12,
    EFortLoginInteraction__CorrectiveAction = 13
};

enum EParentalControlsViewState : uint8_t
{
    EParentalControlsViewState__Invalid = 0,
    EParentalControlsViewState__EnterPin = 1,
    EParentalControlsViewState__AskToEnableControls = 2,
    EParentalControlsViewState__VerifyEmail = 3,
    EParentalControlsViewState__SetupEmail = 4,
    EParentalControlsViewState__SetupPin = 5,
    EParentalControlsViewState__DisplaySettings = 6,
    EParentalControlsViewState__DisableParentalControls = 7,
    EParentalControlsViewState__AskToReEnable = 8,
    EParentalControlsViewState__ReEnabling = 9,
    EParentalControlsViewState__CabinModeEmailChange = 10
};

enum ESpatialCustomizationRoomState : uint8_t
{
    ESpatialCustomizationRoomState__None = 0,
    ESpatialCustomizationRoomState__CategorySelection = 1,
    ESpatialCustomizationRoomState__CustomizationSelection = 2
};

enum ESpatialCustomizationCategoryState : uint8_t
{
    ESpatialCustomizationCategoryState__LockedByBattlePass = 0,
    ESpatialCustomizationCategoryState__LockedByChallenge = 1,
    ESpatialCustomizationCategoryState__LockedByChallengeCompletion = 2,
    ESpatialCustomizationCategoryState__UnlockAvailable = 3,
    ESpatialCustomizationCategoryState__UnlockUsed = 4,
    ESpatialCustomizationCategoryState__Max_NONE = 5
};

enum EFortTopBarTabButtonGroup : uint8_t
{
    EFortTopBarTabButtonGroup__Discover = 0,
    EFortTopBarTabButtonGroup__Core = 1,
    EFortTopBarTabButtonGroup__Game = 2,
    EFortTopBarTabButtonGroup__PinnedRight = 3
};

enum ETooltipAlignment : uint8_t
{
    ETooltipAlignment__Up = 0,
    ETooltipAlignment__Down = 1,
    ETooltipAlignment__Left = 2,
    ETooltipAlignment__Right = 3
};

enum EMainMenuButtons : uint8_t
{
    EMainMenuButtons__Cilantro = 0,
    EMainMenuButtons__BackToHub = 1,
    EMainMenuButtons__Settings = 2,
    EMainMenuButtons__Subscription = 3,
    EMainMenuButtons__MobileBack = 4,
    EMainMenuButtons__SubgameSelection = 5,
    EMainMenuButtons__LeaveExperience = 6,
    EMainMenuButtons__Store = 7,
    EMainMenuButtons__Locker = 8,
    EMainMenuButtons__CodeOfConduct = 9,
    EMainMenuButtons__Support = 10,
    EMainMenuButtons__MaxNum = 11
};

enum EItemContextAction : uint8_t
{
    EItemContextAction__Equip = 0,
    EItemContextAction__GoToBattlePassRewards = 1,
    EItemContextAction__GoToBattlePassCustomization = 2,
    EItemContextAction__GoToSpecialCollection = 3,
    EItemContextAction__Count = 4
};

enum EFortItemCountStyle : uint8_t
{
    EFortItemCountStyle__StackCount = 0,
    EFortItemCountStyle__OverrideCount = 1,
    EFortItemCountStyle__StackCountOverOverride = 2
};

enum ELiveStreamStandaloneBlocked : uint8_t
{
    ELiveStreamStandaloneBlocked__StreamInWorldActive = 0
};

enum EMatchmakingInputSource : uint8_t
{
    EMatchmakingInputSource__Local = 0,
    EMatchmakingInputSource__Remote = 1,
    EMatchmakingInputSource__Pool = 2
};

enum EFortMissionActivationWidgetState : uint8_t
{
    EFortMissionActivationWidgetState__Default = 0,
    EFortMissionActivationWidgetState__StartObjective = 1,
    EFortMissionActivationWidgetState__IncreaseDifficulty = 2,
    EFortMissionActivationWidgetState__Invalid = 3
};

enum EFortMtxOfferDisplaySize : uint8_t
{
    EFortMtxOfferDisplaySize__Small = 0,
    EFortMtxOfferDisplaySize__Medium = 1,
    EFortMtxOfferDisplaySize__Large = 2
};

enum EFortItemShopOfferDisplayType : uint8_t
{
    EFortItemShopOfferDisplayType__TileGrid = 0,
    EFortItemShopOfferDisplayType__ExpandableList = 1,
    EFortItemShopOfferDisplayType__Billboard = 2
};

enum EFortItemShopShowIneligibleOffers : uint8_t
{
    EFortItemShopShowIneligibleOffers__Always = 0
};

enum EPlayerFeedbackSubmitState : uint8_t
{
    EPlayerFeedbackSubmitState__Start = 0,
    EPlayerFeedbackSubmitState__Submitting = 1,
    EPlayerFeedbackSubmitState__SubmitFailed = 2,
    EPlayerFeedbackSubmitState__SubmitSucceeded = 3
};

enum EPlayerFeedback_EpicQAState : uint8_t
{
    EPlayerFeedback_EpicQAState__SignInPage = 0,
    EPlayerFeedback_EpicQAState__SigningInFailed = 1,
    EPlayerFeedback_EpicQAState__SigningIn = 2,
    EPlayerFeedback_EpicQAState__SelectBugComponent = 3
};

enum EFortPlayerFeedbackFlags : uint8_t
{
    EFortPlayerFeedbackFlags__SubscreenFlow_ForceDisplayFreeText = 0,
    EFortPlayerFeedbackFlags__SubscreenFlow_IncludeScreenshotSubscreen = 1,
    EFortPlayerFeedbackFlags__SubscreenFlow_VoiceReportSubmit = 2,
    EFortPlayerFeedbackFlags__SubscreenFlow_OverlandNavigator = 3,
    EFortPlayerFeedbackFlags__DoNotDisplay_SaveTheWorld = 4,
    EFortPlayerFeedbackFlags__DoNotDisplay_Athena = 5,
    EFortPlayerFeedbackFlags__DoNotDisplay_Creative = 6,
    EFortPlayerFeedbackFlags__DoNotDisplay_Juno = 7,
    EFortPlayerFeedbackFlags__Submit_TryDisplayBlockUser = 8,
    EFortPlayerFeedbackFlags__Submit_TryDisplayCommunityRulesURL = 9,
    EFortPlayerFeedbackFlags__Submit_TryDisplayUnfollowCreator = 10
};

enum ECardinalPoint : uint8_t
{
    ECardinalPoint__E = 0,
    ECardinalPoint__ENE = 1,
    ECardinalPoint__NE = 2,
    ECardinalPoint__NNE = 3,
    ECardinalPoint__N = 4,
    ECardinalPoint__NNW = 5,
    ECardinalPoint__NW = 6,
    ECardinalPoint__WNW = 7,
    ECardinalPoint__W = 8,
    ECardinalPoint__WSW = 9,
    ECardinalPoint__SW = 10,
    ECardinalPoint__SSW = 11,
    ECardinalPoint__S = 12,
    ECardinalPoint__SSE = 13,
    ECardinalPoint__SE = 14,
    ECardinalPoint__ESE = 15,
    ECardinalPoint__None = 16
};

enum ERadialOrderingMode : uint8_t
{
    ERadialOrderingMode__CounterClockwise = 0,
    ERadialOrderingMode__Clockwise = 1,
    ERadialOrderingMode__Cardinal = 2,
    ERadialOrderingMode__Custom = 3
};

enum EBattlePassView : uint8_t
{
    EBattlePassView__None = 0,
    EBattlePassView__LandingPage = 1,
    EBattlePassView__RewardOverview = 2,
    EBattlePassView__ItemDetails = 3,
    EBattlePassView__BulkBuyRewards = 4,
    EBattlePassView__CharacterCustomizer = 5,
    EBattlePassView__BonusRewards = 6,
    EBattlePassView__Weekly = 7,
    EBattlePassView__Quests = 8,
    EBattlePassView__ItemDetailsSecondLayer = 9
};

enum EBattlePassCurrencyType : uint8_t
{
    EBattlePassCurrencyType__BattleStar = 0,
    EBattlePassCurrencyType__CustomSkin = 1,
    EBattlePassCurrencyType__TOTAL_CURRENCIES = 2
};

enum EBattlePassRewardPrerequisiteType : uint8_t
{
    EBattlePassRewardPrerequisiteType__RewardCount = 0,
    EBattlePassRewardPrerequisiteType__RequiredItems = 1,
    EBattlePassRewardPrerequisiteType__Quest = 2,
    EBattlePassRewardPrerequisiteType__NeededLevels = 3,
    EBattlePassRewardPrerequisiteType__NONE = 4
};

enum ERewardPageType : uint8_t
{
    ERewardPageType__Reward = 0,
    ERewardPageType__Quest = 1,
    ERewardPageType__Bonus = 2,
    ERewardPageType__Customization = 3,
    ERewardPageType__Weekly = 4
};

enum EFortSettingChangeReason : uint8_t
{
    EFortSettingChangeReason__Change = 0,
    EFortSettingChangeReason__DependencyChanged = 1,
    EFortSettingChangeReason__ResetToDefault = 2,
    EFortSettingChangeReason__RestoreToInitial = 3,
    EFortSettingChangeReason__Refresh = 4
};

enum EFortDateTimeStyle : uint8_t
{
    EFortDateTimeStyle__Default = 0,
    EFortDateTimeStyle__Short = 1,
    EFortDateTimeStyle__Medium = 2,
    EFortDateTimeStyle__Long = 3,
    EFortDateTimeStyle__Full = 4
};

enum EFortShowdownMatchType : uint8_t
{
    EFortShowdownMatchType__Unknown = 0,
    EFortShowdownMatchType__Solo = 1,
    EFortShowdownMatchType__Duos = 2,
    EFortShowdownMatchType__Squads = 3
};

enum EFortShowdownEventState : uint8_t
{
    EFortShowdownEventState__Unknown = 0,
    EFortShowdownEventState__FutureTBD = 1,
    EFortShowdownEventState__FutureScheduled = 2,
    EFortShowdownEventState__FutureNext = 3,
    EFortShowdownEventState__Live = 4,
    EFortShowdownEventState__LiveParticipating = 5,
    EFortShowdownEventState__LiveNotParticipating = 6,
    EFortShowdownEventState__Completed = 7,
    EFortShowdownEventState__CompletedParticipated = 8,
    EFortShowdownEventState__CompletedNotPartipated = 9,
    EFortShowdownEventState__Cancelled = 10
};

enum EFortEventWindowEligibility : uint8_t
{
    EFortEventWindowEligibility__Unknown = 0,
    EFortEventWindowEligibility__Public = 1
};

enum EFortShowdownPinState : uint8_t
{
    EFortShowdownPinState__None = 0,
    EFortShowdownPinState__Locked = 1,
    EFortShowdownPinState__Unlocked = 2
};

enum EFortAlterationWidgetState : uint8_t
{
    EFortAlterationWidgetState__Normal = 0,
    EFortAlterationWidgetState__Upgrade = 1,
    EFortAlterationWidgetState__Evolution = 2
};

enum EFortDefenderSlotType : uint8_t
{
    EFortDefenderSlotType__Invalid = 0,
    EFortDefenderSlotType__Defender = 1,
    EFortDefenderSlotT1__5_______ = 2
};

enum ESubgameTileType : uint8_t
{
    ESubgameTileType__Campaign = 0,
    ESubgameTileType__Athena = 1,
    ESubgameTileType__Creative = 2
};

enum EProgressiveSetProgress : uint8_t
{
    EProgressiveSetProgress__NoProgress = 0,
    EProgressiveSetProgress__PartialProgress = 1,
    EProgressiveSetProgress__Completed = 2,
    EProgressiveSetProgress__Expired = 3
};

enum EFortMemberConnectionState : uint8_t
{
    EFortMemberConnectionState__Open = 0,
    EFortMemberConnectionState__Connecting = 1,
    EFortMemberConnectionState__Connected = 2,
    EFortMemberConnectionState__Invalid = 3
};

enum ETournmentPosterViolatorState : uint8_t
{
    ETournmentPosterViolatorState__Hidden = 0,
    ETournmentPosterViolatorState__Live = 1,
    ETournmentPosterViolatorState__Countdown = 2,
    ETournmentPosterViolatorState__Info = 3
};

enum EFortAthenaTutorialStep : uint8_t
{
    EFortAthenaTutorialStep__Look = 0,
    EFortAthenaTutorialStep__Move = 1,
    EFortAthenaTutorialStep__Harvest = 2,
    EFortAthenaTutorialStep__Clamber = 3,
    EFortAthenaTutorialStep__Pickup = 4,
    EFortAthenaTutorialStep__Shoot = 5,
    EFortAthenaTutorialStep__Ambush = 6,
    EFortAthenaTutorialStep__Heal = 7,
    EFortAthenaTutorialStep__Build = 8,
    EFortAthenaTutorialStep__Chest = 9,
    EFortAthenaTutorialStep__Scoping = 10,
    EFortAthenaTutorialStep__Completed = 11,
    EFortAthenaTutorialStep__Count = 12
};

enum EFortAthenaTutorialSubstep : uint8_t
{
    EFortAthenaTutorialSubstep__ScreenSwipeToLook = 0,
    EFortAthenaTutorialSubstep__ScreenFindMarker = 1,
    EFortAthenaTutorialSubstep__ScreenUseLeftStick = 2,
    EFortAthenaTutorialSubstep__ScreenMoveToBuilding = 3,
    EFortAthenaTutorialSubstep__ScreenJump = 4,
    EFortAthenaTutorialSubstep__ScreenCrouch = 5,
    EFortAthenaTutorialSubstep__ScreenReachMarker = 6,
    EFortAthenaTutorialSubstep__ScreenUsePickaxe = 7,
    EFortAthenaTutorialSubstep__ScreenReachClamber = 8,
    EFortAthenaTutorialSubstep__ScreenClamber = 9,
    EFortAthenaTutorialSubstep__ScreenReachPickUp = 10,
    EFortAthenaTutorialSubstep__ScreenPickUpItems = 11,
    EFortAthenaTutorialSubstep__ScreenEquipItem = 12,
    EFortAthenaTutorialSubstep__ScreenShootTargets = 13,
    EFortAthenaTutorialSubstep__ScreenReload = 14,
    EFortAthenaTutorialSubstep__ScreenReachLocation = 15,
    EFortAthenaTutorialSubstep__ScreenDefendYourself = 16,
    EFortAthenaTutorialSubstep__ScreenHealthAlert = 17,
    EFortAthenaTutorialSubstep__ScreenDestroyEnemies = 18,
    EFortAthenaTutorialSubstep__ScreenCollectLoot = 19,
    EFortAthenaTutorialSubstep__ScreenUseMedkit = 20,
    EFortAthenaTutorialSubstep__ScreenUseShield = 21,
    EFortAthenaTutorialSubstep__ScreenShieldInfo = 22,
    EFortAthenaTutorialSubstep__ScreenLookForChest = 23,
    EFortAthenaTutorialSubstep__ScreenChestFound = 24,
    EFortAthenaTutorialSubstep__ScreenSelectBuildMode = 25,
    EFortAthenaTutorialSubstep__ScreenShowMaterials = 26,
    EFortAthenaTutorialSubstep__ScreenShowBuildPieces = 27,
    EFortAthenaTutorialSubstep__ScreenSelectStairs = 28,
    EFortAthenaTutorialSubstep__ScreenPlaceStairs = 29,
    EFortAthenaTutorialSubstep__ScreenReachChest = 30,
    EFortAthenaTutorialSubstep__ScreenExitBuildMode = 31,
    EFortAthenaTutorialSubstep__ScreenLootChest = 32,
    EFortAthenaTutorialSubstep__ScreenCollectLootChest = 33,
    EFortAthenaTutorialSubstep__ScreenEquipRifle = 34,
    EFortAthenaTutorialSubstep__ScreenUseScope = 35,
    EFortAthenaTutorialSubstep__ScreenShootTargetsScoping = 36,
    EFortAthenaTutorialSubstep__ScreenCompleted = 37,
    EFortAthenaTutorialSubstep__HealingInterrupted = 38,
    EFortAthenaTutorialSubstep__Count = 39
};

enum EFortAthenaTutorialScreenExtraWidget : uint8_t
{
    EFortAthenaTutorialScreenExtraWidget__None = 0,
    EFortAthenaTutorialScreenExtraWidget__DragToTurn = 1,
    EFortAthenaTutorialScreenExtraWidget__Completed = 2,
    EFortAthenaTutorialScreenExtraWidget__Count = 3,
    EFortAthenaTutor__K_4R______e__Y_g____D_B_________T_2P______H__hwy____F_7_gH__ = 4
};

enum ELetoDisplayMode : uint8_t
{
    ELetoDisplayMode__PrimaryOnly = 0,
    ELetoDisplayMode__SingleToggle = 1,
    ELetoDisplayMode__Simultaneous = 2
};

enum EYieldReason : uint8_t
{
    EYieldReason__PlayerLoggedIn = 0,
    EYieldReason__PlayerLoggedOut = 1,
    EYieldReason__PlayerCanceledLogin = 2,
    EYieldReason__PlayerYielded = 3,
    EYieldReason__ControllerDisconnect = 4
};

enum EFortLoginDisplay : uint8_t
{
    EFortLoginDisplay__LoginStatus = 0,
    EFortLoginDisplay__SplashScreen = 1,
    EFortLoginDisplay__LoginInteractions = 2,
    EFortLoginDisplay__PushNotificationSelector = 3,
    EFortLoginDisplay__SafeZoneEditor = 4,
    EFortLoginDisplay__HealthWarning = 5,
    EFortLoginDisplay__QualityPresetSelection = 6
};

enum EActorUnderReticleType : uint8_t
{
    EActorUnderReticleType__None = 0,
    EActorUnderReticleType__Enemy = 1,
    EActorUnderReticleType__Ally = 2,
    EActorUnderReticleType__World = 3
};

enum EFortItemShopScrollDirection : uint8_t
{
    EFortItemShopScrollDirection__NoScroll = 0,
    EFortItemShopScrollDirection__ScrolledDown = 1,
    EFortItemShopScrollDirection__ScrolledUp = 2
};

enum ELoadoutPresetLinkState : uint8_t
{
    ELoadoutPresetLinkState__UNSET = 0,
    ELoadoutPresetLinkState__LINKED = 1,
    ELoadoutPresetLinkState__UNLINKED = 2
};

enum EFortSocialPlatformTagDisplayRule : uint8_t
{
    EFortSocialPlatformTagDisplayRule__Never = 0,
    EFortSocialPlatformTagDisplayRule__OnlyIfDifferent = 1,
    EFortSocialPlatformTagDisplayRule__Always = 2
};

enum EHighlightType : uint8_t
{
    EHighlightType__ESquareHighlight = 0,
    EHighlightType__ECircleHighlight_Big = 1,
    EHighlightType__ECircleHighlight_Small = 2
};

enum ENPCCharacterMovement : uint8_t
{
    ENPCCharacterMovement__Default = 0,
    ENPCCharacterMovement__RetargetFromFortniteCharacter = 1,
    ENPCCharacterMovement__AnimationPreset = 2
};

enum ETeamOption : uint8_t
{
    ETeamOption__Index = 0,
    ETeamOption__WildlifeAndCreature = 1,
    ETeamOption__Neutral = 2
};

enum ENPCIndicatorCondition : uint8_t
{
    ENPCIndicatorCondition__Never = 0,
    ENPCIndicatorCondition__Allies = 1,
    ENPCIndicatorCondition__Hostiles = 2,
    ENPCIndicatorCondition__Always = 3
};

enum EZoneLaneTagMaskComparison : uint8_t
{
    EZoneLaneTagMaskComparison__Any = 0,
    EZoneLaneTagMaskComparison__All = 1,
    EZoneLaneTagMaskComparison__Not = 2
};

enum EZoneLaneDirection : uint8_t
{
    EZoneLaneDirection__None = 0,
    EZoneLaneDirection__Forward = 1,
    EZoneLaneDirection__Backward = 2
};

enum EZoneLaneLinkType : uint16_t
{
    EZoneLaneLinkType__None = 0,
    EZoneLaneLinkType__All = 255,
    EZoneLaneLinkType__Outgoing = 1,
    EZoneLaneLinkType__Incoming = 2,
    EZoneLaneLinkType__Adjacent = 4
};

enum EZoneLaneLinkFlags : uint16_t
{
    EZoneLaneLinkFlags__None = 0,
    EZoneLaneLinkFlags__All = 255,
    EZoneLaneLinkFlags__Left = 1,
    EZoneLaneLinkFlags__Right = 2,
    EZoneLaneLinkFlags__Splitting = 4,
    EZoneLaneLinkFlags__Merging = 8,
    EZoneLaneLinkFlags__OppositeDirection = 16
};

enum EZoneGraphLaneRoutingCountRule : uint8_t
{
    EZoneGraphLaneRoutingCountRule__Any = 0,
    EZoneGraphLaneRoutingCountRule__One = 1,
    EZoneGraphLaneRoutingCountRule__Many = 2
};

enum EMassLOD : uint8_t
{
    EMassLOD__High = 0,
    EMassLOD__Medium = 1,
    EMassLOD__Low = 2,
    EMassLOD__Off = 3,
    EMassLOD__Max = 4
};

enum EMassEntityTagsTestMode : uint8_t
{
    EMassEntityTagsTestMode__Any = 0,
    EMassEntityTagsTestMode__All = 1,
    EMassEntityTagsTestMode__None = 2
};

enum EMassSmartObjectInteractionStatus : uint8_t
{
    EMassSmartObjectInteractionStatus__Unset = 0,
    EMassSmartObjectInteractionStatus__InProgress = 1,
    EMassSmartObjectInteractionStatus__BehaviorCompleted = 2,
    EMassSmartObjectInteractionStatus__TaskCompleted = 3,
    EMassSmartObjectInteractionStatus__Aborted = 4
};

enum EMassEntityDebugShape : uint8_t
{
    EMassEntityDebugShape__Box = 0,
    EMassEntityDebugShape__Cone = 1,
    EMassEntityDebugShape__Cylinder = 2,
    EMassEntityDebugShape__Capsule = 3
};

enum EFBIKBoneLimitType : uint8_t
{
    EFBIKBoneLimitType__Free = 0,
    EFBIKBoneLimitType__Limit = 1,
    EFBIKBoneLimitType__Locked = 2
};

enum EAIDebuggerVisualization : uint8_t
{
    EAIDebuggerVisualization__INVALID = 0,
    EAIDebuggerVisualization__NavMesh = 1
};

enum EFortAthenaLivingWorldEventRuntimeDeactivationReason : uint8_t
{
    EFortAthenaLivingWorldEventRuntimeDeactivationReason__None = 0,
    EFortAthenaLivingWorldEventRuntimeDeactivationReason__NoValidEventData = 1,
    EFortAthenaLivingWorldEventRuntimeDeactivationReason__RandomDeactivation = 2,
    EFortAthenaLivingWorldEventRuntimeDeactivationReason__CalendarEvent = 3,
    EFortAthenaLivingWorldEventRuntimeDeactivationReason__MatchedPrefabAndNormalActor = 4,
    EFortAthenaLivingWorldEventRuntimeDeactivationReason__ActorDescDoesntMatchAnySpawnerData = 5
};

enum EAIRuntimePatrolPathPointProviderAttributeSource : uint8_t
{
    EAIRuntimePatrolPathPointProviderAttributeSource__RuntimeComponent = 0,
    EAIRuntimePatrolPathPointProviderAttributeSource__PatrolPath = 1,
    EAIRuntimePatrolPathPointProviderAttributeSource__SourceClass = 2
};

enum ELivingWorldCalendarEventConditionRatioBehavior : uint8_t
{
    ELivingWorldCalendarEventConditionRatioBehavior__Less = 0,
    ELivingWorldCalendarEventConditionRatioBehavior__LessOrEqual = 1,
    ELivingWorldCalendarEventConditionRatioBehavior__Greater = 2,
    ELivingWorldCalendarEventConditionRatioBehavior__GreaterOrEqual = 3,
    ELivingWorldCalendarEventConditionRatioBehavior__InBetween = 4
};

enum EAudioGameplayBehaviorPlayState : uint8_t
{
    EAudioGameplayBehaviorPlayState__Stopped = 0,
    EAudioGameplayBehaviorPlayState__Playing = 1,
    EAudioGameplayBehaviorPlayState__TickingWhileStopped = 2
};

enum EVehicleCosmeticsFailureReason : uint8_t
{
    EVehicleCosmeticsFailureReason__BodyTypeMismatch = 0,
    EVehicleCosmeticsFailureReason__NoBodyEquipped = 1,
    EVehicleCosmeticsFailureReason__ActiveArchetypeNoBodyEquipped = 2,
    EVehicleCosmeticsFailureReason__NoOwningVehicle = 3,
    EVehicleCosmeticsFailureReason__NoLoadoutComponent = 4,
    EVehicleCosmeticsFailureReason__CustomizationDisabled = 5,
    EVehicleCosmeticsFailureReason__LoadoutIsTheSame = 6,
    EVehicleCosmeticsFailureReason__UsingDefaultItem = 7,
    EVehicleCosmeticsFailureReason__NumAllowedIsZero = 8,
    EVehicleCosmeticsFailureReason__Unknown = 9
};

enum EPoppedTireReactionStates : uint8_t
{
    EPoppedTireReactionStates__None = 0,
    EPoppedTireReactionStates__VeerLeft = 1,
    EPoppedTireReactionStates__VeerRight = 2,
    EPoppedTireReactionStates__Wiggle = 3,
    EPoppedTireReactionStates__Yaw90 = 4,
    EPoppedTireReactionStates__FlipPitch = 5,
    EPoppedTireReactionStates__FlipRoll = 6
};

enum EVehicleWheelAndTireNiagaraParams : uint32_t
{
    Sparks_Wheel_FL = 1,
    Sparks_Wheel_FR = 2,
    Sparks_Wheel_ML = 4,
    Sparks_Wheel_MR = 8,
    Sparks_Wheel_RL = 16,
    Sparks_Wheel_RR = 32,
    UNUSED = 64,
    UNUSED = 128,
    Dust_Wheel_FL = 256,
    Dust_Wheel_FR = 512,
    Dust_Wheel_ML = 1024,
    Dust_Wheel_MR = 2048,
    Dust_Wheel_RL = 4096,
    Dust_Wheel_RR = 8192,
    UNUSED = 16384,
    UNUSED = 32768,
    TireIntactFL = 65536,
    TireIntactFR = 131072,
    TireIntactRL = 262144,
    TireIntactRR = 524288,
    TireIntactML = 1048576,
    TireIntactMR = 2097152,
    IsShifting = 4194304,
    UNUSED = 8388608,
    PeelOut_Wheel_RL = 16777216,
    PeelOut_Wheel_RR = 33554432,
    IsBigRig = 67108864,
    IsWaterDeep = 134217728,
    VehicleHasDriver = 268435456,
    VehicleHasFuel = 536870912,
    Downshifting = 1073741824,
    UNUSED = -2147483648
};

enum ESoundContainerType : uint8_t
{
    ESoundContainerType__Concatenate = 0,
    ESoundContainerType__Randomize = 1,
    ESoundContainerType__Mix = 2
};

enum EStateTreeQuestGrantType : uint8_t
{
    EStateTreeQuestGrantType__GrantToParticipants = 0,
    EStateTreeQuestGrantType__GrantToPlayspace = 1,
    EStateTreeQuestGrantType__GrantToTarget = 2
};

enum EAlertLevelComparisonOperator : uint8_t
{
    EAlertLevelComparisonOperator__GreaterThan = 0,
    EAlertLevelComparisonOperator__LessThan = 1,
    EAlertLevelComparisonOperator__EqualTo = 2,
    EAlertLevelComparisonOperator__NotEqualTo = 3,
    EAlertLevelComparisonOperator__GreaterThanOrEqualTo = 4,
    EAlertLevelComparisonOperator__LessThanOrEqualTo = 5
};

enum ETargetInfoBehavior : uint8_t
{
    ETargetInfoBehavior__OneTime = 0,
    ETargetInfoBehavior__UntilTaskFinished = 1,
    ETargetInfoBehavior__UntilEncounterFinished = 2
};

enum EEncounterComparisonOperator : uint8_t
{
    EEncounterComparisonOperator__GreaterThan = 0,
    EEncounterComparisonOperator__LessThan = 1,
    EEncounterComparisonOperator__EqualTo = 2,
    EEncounterComparisonOperator__NotEqualTo = 3,
    EEncounterComparisonOperator__GreaterThanOrEqualTo = 4,
    EEncounterComparisonOperator__LessThanOrEqualTo = 5
};

enum EPersistentValueScope : uint8_t
{
    EPersistentValueScope__Encounter = 0,
    EPersistentValueScope__Sequence = 1,
    EPersistentValueScope__Always = 2
};

enum ESpawnActorPersistenceBehavior : uint8_t
{
    ESpawnActorPersistenceBehavior__Destroy = 0,
    ESpawnActorPersistenceBehavior__Transient = 1,
    ESpawnActorPersistenceBehavior__Persistent = 2
};

enum EEncounterSuccessState : uint8_t
{
    EEncounterSuccessState__Passed = 0,
    EEncounterSuccessState__Failed = 1,
    EEncounterSuccessState__Any = 2
};

enum EStreamingRadioSourceState : uint8_t
{
    EStreamingRadioSourceState__None = 0,
    EStreamingRadioSourceState__LoadingPlayer = 1,
    EStreamingRadioSourceState__LoadedPlayer = 2,
    EStreamingRadioSourceState__Playing = 3
};

enum EOnlineRadioSourceType : uint8_t
{
    EOnlineRadioSourceType__Epic = 0
};

enum EEpicMediaScheduleRepeat : uint8_t
{
    EEpicMediaScheduleRepeat__None = 0,
    EEpicMediaScheduleRepeat__Hourly = 1,
    EEpicMediaScheduleRepeat__Daily = 2
};

enum ESprintLoggingVerbosityLevel : uint8_t
{
    ESprintLoggingVerbosityLevel__Error = 0,
    ESprintLoggingVerbosityLevel__Warning = 1,
    ESprintLoggingVerbosityLevel__Display = 2,
    ESprintLoggingVerbosityLevel__Log = 3,
    ESprintLoggingVerbosityLevel__Verbose = 4,
    ESprintLoggingVerbosityLevel__VeryVerbose = 5
};

enum EBallisticShieldPlayerActionState : uint8_t
{
    EBallisticShieldPlayerActionState__Idling = 0,
    EBallisticShieldPlayerActionState__Blocking = 1,
    EBallisticShieldPlayerActionState__Charging = 2
};

enum EBattlePassLandingPageSpecialEntryType : uint8_t
{
    EBattlePassLandingPageSpecialEntryType__None = 0,
    EBattlePassLandingPageSpecialEntryType__Subscription = 1,
    EBattlePassLandingPageSpecialEntryType__CharacterCustomizer = 2,
    EBattlePassLandingPageSpecialEntryType__SpecialCharacter = 3,
    EBattlePassLandingPageSpecialEntryType__Weekly = 4,
    EBattlePassLandingPageSpecialEntryType__COUNT = 5
};

enum FBattlePassLandingPageButtonDisplayBehavior : uint8_t
{
    FBattlePassLandingPageButtonDisplayBehavior__None = 0,
    FBattlePassLandingPageButtonDisplayBehavior__MainRewards = 1,
    FBattlePassLandingPageButtonDisplayBehavior__BonusRewards = 2,
    FBattlePassLandingPageButtonDisplayBehavior__WeeklyRewards = 3,
    FBattlePassLandingPageButtonDisplayBehavior__QuestRewards = 4,
    FBattlePassLandingPageButtonDisplayBehavior__Subscription = 5,
    FBattlePassLandingPageButtonDisplayBehavior__Customization = 6
};

enum BattlePassTileAvailabilityStates : uint8_t
{
    BattlePassTileAvailabilityStates__Invalid = 0,
    BattlePassTileAvailabilityStates__Available = 1,
    BattlePassTileAvailabilityStates__Owned = 2,
    BattlePassTileAvailabilityStates__Locked = 3
};

enum EOptionalBattleRoyaleFrontendExperienceFlowSteps : uint8_t
{
    EOptionalBattleRoyaleFrontendExperienceFlowSteps__TryPlaySeasonTrailer = 0,
    EOptionalBattleRoyaleFrontendExperienceFlowSteps__TryPlayBattlePassTrailer = 1,
    EOptionalBattleRoyaleFrontendExperienceFlowSteps__TryShowHabaneroIntroModal = 2,
    EOptionalBattleRoyaleFrontendExperienceFlowSteps__TryShowFireModeSelectionReminderModal = 3,
    EOptionalBattleRoyaleFrontendExperienceFlowSteps__TryShowFireModeModal = 4,
    EOptionalBattleRoyaleFrontendExperienceFlowSteps__TryShowSimpleBuildAndEditModal = 5
};

enum EPlaytimeRequestState : uint8_t
{
    EPlaytimeRequestState__None = 0,
    EPlaytimeRequestState__Waiting = 1,
    EPlaytimeRequestState__Success = 2,
    EPlaytimeRequestState__Failure = 3
};

enum EBattlePassCrewContentState : uint8_t
{
    EBattlePassCrewContentState__BattlePass = 0,
    EBattlePassCrewContentState__Crew = 1,
    EBattlePassCrewContentState__CrewSubscribed = 2
};

enum EBattlePassPurchaseButtonCurrencyType : uint8_t
{
    EBattlePassPurchaseButtonCurrencyType__None = 0,
    EBattlePassPurchaseButtonCurrencyType__Mtx = 1,
    EBattlePassPurchaseButtonCurrencyType__RealMoney = 2
};

enum ESubscriptionCancellability : uint8_t
{
    ESubscriptionCancellability__NotCancellable = 0,
    ESubscriptionCancellability__CancellabeOnPlatform = 1,
    ESubscriptionCancellability__CancellableAnywhere = 2
};

enum EEventScreenRewardPreviewType : uint8_t
{
    EEventScreenRewardPreviewType__None = 0,
    EEventScreenRewardPreviewType__RewardTrack = 1,
    EEventScreenRewardPreviewType__SpecialItem = 2,
    EEventScreenRewardPreviewType__SpecialPremiumItem = 3
};

enum ESeasonPassRewardHeader : uint8_t
{
    ESeasonPassRewardHeader__None = 0,
    ESeasonPassRewardHea_r___9o____B5A__d = 1,
    ESeasonPassRewardHeader__SeasonPassRequired = 2,
    ESeasonPassRewardHeader__ComingSoon = 4
};

enum EActivityBrowserTileStyle : uint8_t
{
    EActivityBrowserTileStyle__Default = 0,
    EActivityBrowserTileStyle__Minimal = 1,
    EActivityBrowserTileStyle__Detailed = 2
};

enum EGizmoElementState : uint8_t
{
    EGizmoElementState__None = 0,
    EGizmoElementState__Visible = 2,
    EGizmoElementState__Hittable = 4,
    EGizmoElementState__VisibleAndHittable = 6
};

enum EGizmoElementInteractionState : uint8_t
{
    EGizmoElementInteractionState__None = 0,
    EGizmoElementInteractionState__Hovering = 1,
    EGizmoElementInteractionState__Interacting = 2
};

enum EGizmoElementViewDependentType : uint8_t
{
    EGizmoElementViewDependentType__None = 0,
    EGizmoElementViewDependentType__Axis = 1,
    EGizmoElementViewDependentType__Plane = 2
};

enum EGizmoElementViewAlignType : uint8_t
{
    EGizmoElementViewAlignType__None = 0,
    EGizmoElementViewAlignType__PointOnly = 1,
    EGizmoElementViewAlignType__PointEye = 2,
    EGizmoElementViewAlignType__PointScreen = 3,
    EGizmoElementViewAlignType__Axial = 4
};

enum EGizmoElementPartialType : uint8_t
{
    EGizmoElementPartialType__None = 0,
    EGizmoElementPartialType__Partial = 1,
    EGizmoElementPartialType__PartialViewDependent = 2
};

enum EStandardToolContextMaterials : uint8_t
{
    EStandardToolContextMaterials__VertexColorMaterial = 1
};

enum EToolContextTransformGizmoMode : uint8_t
{
    EToolContextTransformGizmoMode__NoGizmo = 0,
    EToolContextTransformGizmoMode__Translation = 1,
    EToolContextTransformGizmoMode__Rotation = 2,
    EToolContextTransformGizmoMode__Scale = 3,
    EToolContextTransformGizmoMode__Combined = 8
};

enum EToolMessageLevel : uint8_t
{
    EToolMessageLevel__Internal = 0,
    EToolMessageLeveKjmi_________U = 1,
    EToolMessageLevel__UserNotification = 2,
    EToolMessageLevel__UserWarning = 3,
    EToolMessageLevel__UserError = 4
};

enum ESelectedObjectsModificationType : uint8_t
{
    ESelectedObjectsModificationType__Replace = 0,
    ESelectedObjectsModificationType__Add = 1,
    ESelectedObjectsModificationType__Remove = 2,
    ESelectedObjectsModificationType__Clear = 3
};

enum EViewInteractionState : uint8_t
{
    EViewInteractionState__None = 0,
    EViewInteractionState__Hovered = 1,
    EViewInteractionState__Focused = 2
};

enum EInputCaptureSide : uint8_t
{
    EInputCaptureSide__None = 0,
    EInputCaptureSide__Left = 1,
    EInputCaptureSide__Right = 2,
    EInputCaptureSide__Both = 3,
    EInputCaptureSide__Any = 99
};

enum EInputCaptureState : uint8_t
{
    EInputCaptureState__Begin = 1,
    EInputCaptureState__Continue = 2,
    EInputCaptureState__End = 3,
    EInputCaptureState__Ignore = 4
};

enum EToolShutdownType : uint8_t
{
    EToolShutdownType__Completed = 0,
    EToolShutdownType__Accept = 1,
    EToolShutdownType__Cancel = 2
};

enum EToolSide : uint8_t
{
    EToolSide__Left = 1,
    EToolSide__Mouse = 1,
    EToolSide__Right = 2
};

enum EToolChangeTrackingMode : uint8_t
{
    EToolChangeTrackingMode__NoChangeTracking = 1,
    EToolChangeTrackingMode__UndoToExit = 2,
    EToolChangeTrackingMode__FullUndoRedo = 3
};

enum EToolManagerToolSwitchMode : uint8_t
{
    EToolManagerToolSwitchMode__AcceptIfAble = 0,
    EToolManagerToolSwitchMode__CancelIfAble = 1,
    EToolManagerToolSwitchMode__CustomizableAcceptIfAble = 2,
    EToolManagerToolSwitchMode__CustomizableCancelIfAble = 3
};

enum ESceneSnapQueryTargetType : uint8_t
{
    ESceneSnapQueryTargetType__None = 0,
    ESceneSnapQueryTargetType__MeshVertex = 1,
    ESceneSnapQuer_____ = 2,
    ESceneSnapQueryTargetType__Grid = 4,
    ESceneSnapQueryTargetType__All = 7
};

enum EDynamicMeshComponentTangentsMode : uint16_t
{
    EDynamicMeshComponentTangentsMode__NoTangents = 0,
    EDynamicMeshComponentTangentsMode__AutoCalculated = 1,
    EDynamicMeshComponentTangentsMode__ExternallyProvided = 2,
    EDynamicMeshComponentTangentsMode__Default = 255
};

enum EDynamicMeshComponentColorOverrideMode : uint8_t
{
    EDynamicMeshComponentColorOverrideMode__None = 0,
    EDynamicMeshComponentColorOverrideMode__VertexColors = 1,
    EDynamicMeshComponentColorOverrideMode__Polygroups = 2,
    EDynamicMeshComponentColorOverrideMode__Constant = 3
};

enum EDynamicMeshVertexColorTransformMode : uint8_t
{
    EDynamicMeshVertexColorTransformMode__NoTransform = 0,
    EDynamicMeshVertexColorTransformMode__LinearToSRGB = 1,
    EDynamicMeshVertexColorTransformMode__SRGBToLinear = 2
};

enum EDynamicMeshComponentRenderUpdateMode : uint8_t
{
    EDynamicMeshComponentRenderUpdateMode__NoUpdate = 0,
    EDynamicMeshComponentRenderUpdateMode__FullUpdate = 1,
    EDynamicMeshComponentRenderUpdateMode__FastUpdate = 2
};

enum EDynamicMeshChangeType : uint8_t
{
    EDynamicMeshChangeType__GeneralEdit = 0,
    EDynamicMeshChangeType__MeshChange = 1,
    EDynamicMeshChangeType__MeshReplacementChange = 2,
    EDynamicMeshChangeType__MeshVertexChange = 3,
    EDynamicMeshChangeType__DeformationEdit = 4,
    EDynamicMeshChangeType__AttributeEdit = 5
};

enum EDynamicMeshAttributeChangeFlags : uint8_t
{
    EDynamicMeshAttributeChangeFlags__Unknown = 0,
    EDynamicMeshAttributeChangeFlags__MeshTopology = 1,
    EDynamicMeshAttributeChangeFlags__VertexPositions = 2,
    EDynamicMeshAttributeChangeFlags__NormalsTangents = 4,
    EDynamicMeshAttributeChangeFlags__VertexColors = 8,
    EDynamicMeshAttributeChangeFlags__UVs = 16,
    EDynamicMeshAttributeChangeFlags__TriangleGroups = 32
};

enum EAtomModelMergedMeshSelection : uint8_t
{
    EAtomModelMergedMeshSelection__AllMeshes = 0,
    EAtomModelMergedMeshSelection__OnlyOpaqueMeshes = 1,
    EAtomModelMergedMeshSelection__OnlyTransparentMeshes = 2
};

enum EAtomMaterialType : uint8_t
{
    EAtomMaterialType__None = 0,
    EAtomMaterialType__Standard = 1,
    EAtomMaterialType__Transparent = 2,
    EAtomMaterialType__Glitter = 3,
    EAtomMaterialType__Opalescent = 4,
    EAtomMaterialType__Metallic = 5
};

enum EAtomAssemblyMode : uint8_t
{
    EAtomAssemblyMode__InstantProgress = 0,
    EAtomAssemblyMode__AdvanceProgress = 1,
    EAtomAssemblyMode__ResetProgress = 2
};

enum EAtomAssemblyCollisionMode : uint8_t
{
    EAtomAssemblyCollisionMode__AlwaysOn = 0,
    EAtomAssemblyCollisionMode__OffIfDisassembled = 1,
    EAtomAssemblyCollisionMode__OnIfAssembled = 2
};

enum EAtomMaterialColorSource : uint8_t
{
    EAtomMaterialColorSource__VertexColor = 0,
    EAtomMaterialColorSource__InstanceCustomData = 1,
    EAtomMaterialColorSource__Material = 2,
    EAtomMaterialColorSource__LUTVertexColor = 3,
    EAtomMaterialColorSource__LUTInstanceCustomData = 4,
    EAtomMaterialColorSource__LUTMaterial = 5
};

enum EAtomPrimitiveCollisionVolumeType : uint8_t
{
    EAtomPrimitiveCollisionVolumeType__Box = 0,
    EAtomPrimitiveCollisionVolumeType__Sphere = 1,
    EAtomPrimitiveCollisionVolumeType__Capsule = 2,
    EAtomPrimitiveCollisionVolumeType__Cylinder = 3,
    EAtomPrimitiveCollisionVolumeType__Tube = 4,
    EAtomPrimitiveCollisionVolumeType__Crate = 5
};

enum EPrimitiveAutoCollisionType : uint8_t
{
    EPrimitiveAutoCollisionType__Box = 0,
    EPrimitiveAutoCollisionType__Sphere = 1,
    EPrimitiveAutoCollisionType__NDOP10_X = 2,
    EPrimitiveAutoCollisionType__NDOP10_Y = 3,
    EPrimitiveAutoCollisionType__NDOP10_Z = 4,
    EPrimitiveAutoCollisionType__NDOP18 = 5,
    EPrimitiveAutoCollisionType__NDOP26 = 6
};

enum EPrimitiveGeometryComplexity : uint8_t
{
    EPrimitiveGeometryComplexity__JustShell = 0,
    EPrimitiveGeometryComplexity__ShellAndUncommonParts = 1,
    EPrimitiveGeometryComplexity__ShellWithInsideDetailsAndUncommonParts = 2,
    EPrimitiveGeometryComplexity__ShellWithInsideDetails = 3,
    EPrimitiveGeometryComplexity__ShellWithFlatCapAndUncommonParts = 4,
    EPrimitiveGeometryComplexity__ShellWithFlatCap = 5
};

enum EAtomShaderType : uint8_t
{
    EAtomShaderType__Unknown = 0,
    EAtomShaderType__ShinyPlastic = 1,
    EAtomShaderType__MattePlastic = 2,
    EAtomShaderType__Rubber = 3,
    EAtomShaderType__ShinySteel = 4,
    EAtomShaderType__BrushedSteel = 5,
    EAtomShaderType__MatteSteel = 6,
    EAtomShaderType__Glitter = 7,
    EAtomShaderType__Metallic = 8,
    EAtomShaderType__Opalescence = 9
};

enum EColorEffects : uint8_t
{
    EColorEffects__None = 0,
    EColorEffects__Metallic = 1,
    EColorEffects__Glitter = 2,
    EColorEffects__Opalescent = 3
};

enum EAtomModelCommonPartOptimizationFlag : uint8_t
{
    EAtomModelCommonPartOptimizationFlag__None = 0,
    EAtomModelCommonPartOptimizationFlag__RemoveConnected = 1,
    EAtomModelCommonPartOptimizationFlag__RemoveKnobs = 2,
    EAtomModelCommonPartOptimizationFlag__RemoveTubes = 4,
    EAtomModelCommonPartOptimizationFlag__RemovePins = 8,
    EAtomModelCommonPartOptimizationFlag__All = 15
};

enum EAtomModelPivotAnchor : uint8_t
{
    EAtomModelPivotAnchor__Original = 0,
    EAtomModelPivotAnchor__TopCenter = 1,
    EAtomModelPivotAnchor__Center = 2,
    EAtomModelPivotAnchor__BottomCenter = 3
};

enum EAtomPlatform : uint8_t
{
    EAtomPlatform__NA = 0,
    EAtomPlatform__Duplo = 1,
    EAtomPlatform__Atom = 2,
    EAtomPlatform__Technic = 3,
    EAtomPlatform__Clickits = 4,
    EAtomPlatform__ActionFigures = 5,
    EAtomPlatform__Outdoor = 6,
    EAtomPlatform__SoftPrimitives = 7,
    EAtomPlatform__ExtendedLine = 8,
    EAtomPlatform__Scala = 9,
    EAtomPlatform__Znap = 10,
    EAtomPlatform__Toolo = 11,
    EAtomPlatform__Storage = 12,
    EAtomPlatform__MusicBuilder = 13,
    EAtomPlatform__StoryBuilder = 14,
    EAtomPlatform__Quatro = 15,
    EAtomPlatform__Ccbs = 16,
    EAtomPlatform__Primo1 = 17,
    EAtomPlatform__AtomFoundation = 18,
    EAtomPlatform__DieCutToStickers = 98,
    EAtomPlatform__GeneralPlatform = 99
};

enum EAtomCommonPartCategory : uint8_t
{
    EAtomCommonPartCategory__None = 0,
    EAtomCommonPartCategory__Knob = 1,
    EAtomCommonPartCategory__Pin = 2,
    EAtomCommonPartCategory__Tube = 3
};

enum EAtomPrimitiveGeoOptimization : uint8_t
{
    EAtomPrimitiveGeoOptimization__Default = 0,
    EAtomPrimitiveGeoOptimization__UseForDetailOnly = 1,
    EAtomPrimitiveGeoOptimization__UseApproximationForLODs = 2
};

enum EAtomPrimitiveGeoOptimization_Old : uint8_t
{
    EAtomPrimitiveGeoOptimization_Old__Default = 0,
    EAtomPrimitiveGeoOptimization_Old__UseForDetailOnly = 1,
    EAtomPrimitiveGeoOptimization_Old__UseApproximationForLODs = 2
};

enum EAtomPrimitiveDetailTextureType : uint8_t
{
    EAtomPrimitiveDetailTextureType__None = 0,
    EAtomPrimitiveDetailTextureType__NormalMap = 1,
    EAtomPrimitiveDetailTextureType__AlphaMask = 2
};

enum EConnectionFieldType : uint8_t
{
    EConnectionFieldType__Planar = 0,
    EConnectionFieldType__Hinge = 1,
    EConnectionFieldType__Axle = 2,
    EConnectionFieldType__Ball = 3,
    EConnectionFieldType__Cardan = 4,
    EConnectionFieldType__Fixed = 5,
    EConnectionFieldType__Rail = 6,
    EConnectionFieldType__Slider = 7,
    EConnectionFieldType__Gear = 8,
    EConnectionFieldType__User = 9
};

enum EConnectionFieldSuperType : uint8_t
{
    EConnectionFieldSuperType__Planar = 0,
    EConnectionFieldSuperType__Line = 1,
    EConnectionFieldSuperType__Point = 2
};

enum EConnectionFieldGender : uint8_t
{
    EConnectionFieldGender__Receptor = 0,
    EConnectionFieldGender__Connector = 1,
    EConnectionFieldGender__Any = 2
};

enum EFieldConnectResult : uint8_t
{
    EFieldConnectResult__NoConnection = 0,
    EFieldConnectResult__Rejection = 1,
    EFieldConnectResult__FixedConnection = 2,
    EFieldConnectResult__FreeConnection = 3,
    EFieldConnectResult__HingeConnection = 4,
    EFieldConnectResult__CardanConnection = 5,
    EFieldConnectResult__BallConnection = 6,
    EFieldConnectResult__PrismaticConnection = 7,
    EFieldConnectResult__CylindricalConnection = 8,
    EFieldConnectResult__PrismaticAPerpendicularHingeConnection = 9,
    EFieldConnectResult__PrismaticBPerpendicularHingeConnection = 10,
    EFieldConnectResult__ConnectResultMax = 11,
    EFieldConnectResult__FirstConnection = 2,
    EFieldConnectResult__LastConnection = 10
};

enum EAxleDiameter : uint8_t
{
    EAxleDiameter__Tiny = 0,
    EAxleDiameter__Medium = 1,
    EAxleDiameter__Large = 2
};

enum EConnectionAxleType : uint8_t
{
    EConnectionAxleType__UnusedReceptor = 0,
    EConnectionAxleType__UnusedConnector = 1,
    EConnectionAxleType__RoundAxleReceptor = 2,
    EConnectionAxleType__RoundAxleConnector = 3,
    EConnectionAxleType__CrossAxleReceptor = 4,
    EConnectionAxleType__CrossAxleConnector = 5,
    EConnectionAxleType__SecondaryPinReceptor = 6,
    EConnectionAxleType__SecondaryPinConnector = 7,
    EConnectionAxleType__PlateRoundCrossAxleReceptor = 8,
    EConnectionAxleType__UnusedPlateRoundCrossAxleConnector = 9,
    EConnectionAxleType__MiniFigNeckReceptor = 10,
    EConnectionAxleType__MiniFigNeckConnector = 11,
    EConnectionAxleType__RoundCrossAxleReceptor = 12,
    EConnectionAxleType__RoundCrossAxleConnector = 13,
    EConnectionAxleType__TinyPinReceptor = 14,
    EConnectionAxleType__TinyPinConnector = 15,
    EConnectionAxleType__UnusedCrossAxlePegHoleCapAlignmentReceptor = 16,
    EConnectionAxleType__CrossAxlePegHoleCapAlignmentConnector = 17,
    EConnectionAxleType__UnusedRoundAxleReceptorDontRejectSecondaryPinConnector = 18,
    EConnectionAxleType__RoundAxleConnectorDontRejectSecondaryPinConnector = 19,
    EConnectionAxleType__UnusedSecondaryPinReceptorDontRejectTinyPinConnector = 20,
    EConnectionAxleType__SecondaryPinConnectorDontRejectTinyPinConnector = 21,
    EConnectionAxleType__SubTypeSize = 22
};

enum EConnectionPointType : uint8_t
{
    EConnectionPointType__Knob = 0,
    EConnectionPointType__HollowKnob = 1,
    EConnectionPointType__KnobFitInPegHole = 2,
    EConnectionPointType__HollowKnobFitInPegHole = 3,
    EConnectionPointType__SquareKnob = 4,
    EConnectionPointType__Tube = 5,
    EConnectionPointType__TubeWithRib = 6,
    EConnectionPointType__BottomTube = 7,
    EConnectionPointType__BottomTubeWithRib = 8,
    EConnectionPointType__SecondaryPin = 9,
    EConnectionPointType__SecondaryPinWithRib = 10,
    EConnectionPointType__SecondaryPinWithTinyPinReceptor = 11,
    EConnectionPointType__SecondaryP_c__________________hmD_j__ = 12,
    EConnectionPointType__FixedTube = 13,
    EConnectionPointType__FixedTubeWithAntiKnob = 14,
    EConnectionPointType__AntiKnob = 15,
    EConnectionPointType__PegHole = 16,
    EConnectionPointType__SquareAntiKnob = 17,
    EConnectionPointType__TubeGap = 18,
    EConnectionPointType__TubeGrabber = 19,
    EConnectionPointType__TinyPin = 20,
    EConnectionPointType__TinyPinReceptor = 21,
    EConnectionPointType__Edge = 22,
    EConnectionPointType__EdgeGap = 23,
    EConnectionPointType__KnobReject = 24,
    EConnectionPointType__PowerFuncLeftTop = 25,
    EConnectionPointType__PowerFuncRightTop = 26,
    EConnectionPointType__PowerFuncLeftBottom = 27,
    EConnectionPointType__PowerFuncRightBottom = 28,
    EConnectionPointType__VoidFeature = 29,
    EConnectionPointType__DuploKnob = 30,
    EConnectionPointType__DuploHollowKnob = 31,
    EConnectionPointType__DuploAntiKnob = 32,
    EConnectionPointType__DuploTube = 33,
    EConnectionPointType__DuploFixedTube = 34,
    EConnectionPointType__DuploTubeGap = 35,
    EConnectionPointType__DuploAnimalKnob = 36,
    EConnectionPointType__DuploAnimalTube = 37,
    EConnectionPointType__SecondaryPinReceptor = 38,
    EConnectionPointType__DuploFixedAnimalTube = 39,
    EConnectionPointType__DuploSecondaryPinWithRib = 40,
    EConnectionPointType__DuploSecondaryPin = 41,
    EConnectionPointType__DuploKnobReject = 42,
    EConnectionPointType__RejectAll = 43,
    EConnectionPointType___size = 44,
    EConnectionPointType___duploBegin = 30,
    EConnectionPointType___duploEnd = 42
};

enum ETextureImportFloatingPointFormat : uint8_t
{
    ETextureImportFloatingPointFormat__HDR_F16 = 0,
    ETextureImportFloatingPointFormat__HDRCompressed_BC6 = 1,
    ETextureImportFloatingPointFormat__HDR_F32_or_F16 = 2,
    ETextureImportFloatingPointFormat__PreviousDefault = 0
};

enum ETextureImportPNGInfill : uint8_t
{
    ETextureImportPNGInfill__Default = 0,
    ETextureImportPNGInfill__Never = 1,
    ETextureImportPNGInfill__OnlyOnBinaryTransparency = 2,
    ETextureImportPNGInfill__Always = 3
};

enum ERecomputeUVsPropertiesUnwrapType : uint8_t
{
    ERecomputeUVsPropertiesUnwrapType__ExpMap = 0,
    ERecomputeUVsPropertiesUnwrapType__Conformal = 1,
    ERecomputeUVsPropertiesUnwrapType__SpectralConformal = 2,
    ERecomputeUVsPropertiesUnwrapType__IslandMerging = 3
};

enum ERecomputeUVsPropertiesLayoutType : uint8_t
{
    ERecomputeUVsPropertiesLayoutType__None = 0,
    ERecomputeUVsPropertiesLayoutType__Repack = 1,
    ERecomputeUVsPropertiesLayoutType__NormalizeToExistingBounds = 2,
    ERecomputeUVsPropertiesLayoutType__NormalizeToBounds = 3,
    ERecomputeUVsPropertiesLayoutType__NM_______6_0____ = 4
};

enum EOffsetClosedCurvesMethod : uint8_t
{
    EOffsetClosedCurvesMethod__DoNotOffset = 0,
    EOffsetClosedCurvesMethod__OffsetOuterSide = 1,
    EOffsetClosedCurvesMethod__OffsetBothSides = 2
};

enum EOffsetJoinMethod : uint8_t
{
    EOffsetJoinMethod__Square = 0,
    EOffsetJoinMethod__Miter = 1,
    EOffsetJoinMethod__Round = 2
};

enum EOpenCurveEndShapes : uint8_t
{
    EOpenCurveEndShapes__Square = 0,
    EOpenCurveEndShapes__Round = 1,
    EOpenCurveEndShapes__Butt = 2
};

enum EUVLayoutType : uint8_t
{
    EUVLayoutType__Transform = 0,
    EUVLayoutType__Stack = 1,
    EUVLayoutType__Repack = 2,
    EUVLayoutType__Normalize = 3
};

enum ENormalCalculationMethod : uint8_t
{
    ENormalCalculationMethod__AreaWeighted = 0,
    ENormalCalculationMethod__AngleWeighted = 1,
    ENormalCalculationMethod__AreaAngleWeighting = 2
};

enum ERemeshType : uint8_t
{
    ERemeshType__Standard = 0,
    ERemeshType__FullPass = 1,
    ERemeshType__NormalFlow = 2
};

enum ERemeshSmoothingType : uint8_t
{
    ERemeshSmoothingType__Uniform = 0,
    ERemeshSmoothingType__Cotangent = 1,
    ERemeshSmoothingType__MeanValue = 2
};

enum ECSGOperation : uint8_t
{
    ECSGOperation__DifferenceAB = 0,
    ECSGOperation__DifferenceBA = 1,
    ECSGOperation__Intersect = 2,
    ECSGOperation__Union = 3
};

enum ETexelDensityToolMode : uint8_t
{
    ETexelDensityToolMode__ApplyToIslands = 0,
    ETexelDensityToolMode__ApplyToWhole = 1,
    ETexelDensityToolMode__Normalize = 2
};

enum EBakeTextureResolution : uint8_t
{
    EBakeTextureResolution__Resolution16 = 16,
    EBakeTextureResolution__Resolution32 = 32,
    EBakeTextureResolution__Resolution64 = 64,
    EBakeTextureResolution__Resolution128 = 128
};

enum EGeometrySelectionElementType : uint8_t
{
    EGeometrySelectionElementType__Vertex = 1,
    EGeometrySelectionElementType__Edge = 2,
    EGeometrySelectionElementType__Face = 4
};

enum EMarqueeSelectionUpdateType : uint8_t
{
    EMarqueeSelectionUpdateType__OnDrag = 0,
    EMarqueeSelectionUpdateType__OnTickAndRelease = 1,
    EMarqueeSelectionUpdateType__OnRelease = 2
};

enum EBaseCreateFromSelectedTargetType : uint8_t
{
    EBaseCreateFromSelectedTargetType__NewObject = 0,
    EBaseCreateFromSelectedTargetType__FirstInputObject = 1,
    EBaseCreateFromSelectedTargetType__LastInputObject = 2
};

enum ESpaceCurveControlPointOriginMode : uint8_t
{
    ESpaceCurveControlPointOriginMode__Shared = 0,
    ESpaceCurveControlPointOriginMode__First = 1,
    ESpaceCurveControlPointOriginMode__Last = 2
};

enum EModelingComponentsPlaneVisualizationMode : uint8_t
{
    EModelingComponentsPlaneVisualizationMode__SimpleGrid = 0,
    EModelingComponentsPlaneVisualizationMode__HierarchicalGrid = 1,
    EModelingComponentsPlaneVisualizationMode__FixedScreenAreaGrid = 2
};

enum ECreateModelingObjectResult : uint8_t
{
    ECreateModelingObjectResult__Ok = 0,
    ECreateModelingObjectResult__Cancelled = 1,
    ECreateModelingObjectResult__Failed_Unknown = 2,
    ECreateModelingObjectResult__Failed_NoAPIFound = 3,
    ECreateModelingObjectResult__Failed_InvalidWorld = 4,
    ECreateModelingObjectResult__Failed_InvalidMesh = 5,
    ECreateModelingObjectResult__Failed_InvalidTexture = 6,
    ECreateModelingObjectResult__Failed_AssetCreationFailed = 7,
    ECreateModelingObjectResult__Failed_ActorCreationFailed = 8,
    ECreateModelingObjectResult__Failed_InvalidMaterial = 9
};

enum EGeometryScriptAxis : uint8_t
{
    EGeometryScriptAxis__X = 0,
    EGeometryScriptAxis__Y = 1,
    EGeometryScriptAxis__Z = 2
};

enum EGeometryScriptIndexType : uint8_t
{
    EGeometryScriptIndexType__Any = 0,
    EGeometryScriptIndexType__Triangle = 1,
    EGeometryScriptIndexType__Edge = 2,
    EGeometryScriptIndexType__Vertex = 3,
    EGeometryScriptIndexType__MaterialID = 4,
    EGeometryScriptIndexType__PolygroupID = 5
};

enum ENegativeSpaceSampleMethod : uint8_t
{
    ENegativeSpaceSampleMethod__Uniform = 0,
    ENegativeSpaceSampleMethod__VoxelSearch = 1,
    ENegativeSpaceSampleMethod__NavigableVoxelSearch = 2
};

enum EGeometryScriptCombineSelectionMode : uint8_t
{
    EGeometryScriptCombineSelectionMode__Add = 0,
    EGeometryScriptCombineSelectionMode__Subtract = 1,
    EGeometryScriptCombineSelectionMode__Intersection = 2
};

enum EGeometryScriptBakeResolution : uint8_t
{
    EGeometryScriptBakeResolution__Resolution16 = 0,
    EGeometryScriptBakeResolution__Resolution32 = 1,
    EGeometryScriptBakeResolution__Resolution64 = 2,
    EGeometryScriptBakeResolution__Resolution128 = 3,
    EGeometryScriptBakeResolution__Resolution256 = 4,
    EGeometryScriptBakeResolution__Resolution512 = 5,
    EGeometryScriptBakeResolution__Resolution1024 = 6,
    EGeometryScriptBakeResolution__Resolution2048 = 7,
    EGeometryScriptBakeResolution__Resolution4096 = 8,
    EGeometryScriptBakeResolution__Resolution8192 = 9
};

enum EGeometryScriptBakeTypes : uint8_t
{
    EGeometryScriptBakeTypes__None = 0,
    EGeometryScriptBakeTypes__TangentSpaceNormal = 1,
    EGeometryScriptBakeTypes__ObjectSpaceNormal = 2,
    EGeometryScriptBakeTypes__FaceNormal = 3,
    EGeometryScriptBakeTypes__BentNormal = 4,
    EGeometryScriptBakeTypes__Position = 5,
    EGeometryScriptBakeTypes__Curvature = 6,
    EGeometryScriptBakeTypes__AmbientOcclusion = 7,
    EGeometryScriptBakeTypes__Texture = 8,
    EGeometryScriptBakeTypes__MultiTexture = 9,
    EGeometryScriptBakeTypes__VertexColor = 10,
    EGeometryScriptBakeTypes__MaterialID = 11,
    EGeometryScriptBakeTypes__Constant = 12,
    EGeometryScriptBakeTypes__UVShell = 13
};

enum EGeometryScriptBakeCurvatureTypeMode : uint8_t
{
    EGeometryScriptBakeCurvatureTypeMode__Mean = 0,
    EGeometryScriptBakeCurvatureTypeMode__Max = 1,
    EGeometryScriptBakeCurvatureTypeMode__Min = 2,
    EGeometryScriptBakeCurvatureTypeMode__Gaussi__ = 3
};

enum EGeometryScriptBakeCurvatureColorMode : uint8_t
{
    EGeometryScriptBakeCurvatureColorMode__Grayscale = 0,
    EGeometryScriptBakeCurvatureColorMode__RedBlue = 1,
    EGeometryScriptBakeCurvatureColorMode__RedGreenBlue = 2
};

enum EGeometryScriptBakeCurvatureClampMode : uint8_t
{
    EGeometryScriptBakeCurvatureClampMode__None = 0,
    EGeometryScriptBakeCurvatureClampMode__OnlyPositive = 1,
    EGeometryScriptBakeCurvatureClampMode__OnlyNegative = 2
};

enum EGeometryScriptCombineAttributesMode : uint8_t
{
    EGeometryScriptCombineAttributesMode__EnableAllMatching = 0,
    EGeometryScriptCombineAttributesMode__UseTarget = 1,
    EGeometryScriptCombineAttributesMode__UseSource = 2
};

enum EBonesToCopyFromSource : uint8_t
{
    EBonesToCopyFromSource__AllBones = 0,
    EBonesToCopyFromSource__OnlyBoundAndParents = 1,
    EBonesToCopyFromSource__OnlyBoundAndRoot = 2
};

enum EGeometryScriptBooleanOperation : uint8_t
{
    EGeometryScriptBooleanOperation__Union = 0,
    EGeometryScriptBooleanOperation__Intersection = 1,
    EGeometryScriptBooleanOperation__Subtract = 2
};

enum EGeometryScriptMeshDifferenceReason : uint8_t
{
    EGeometryScriptMeshDifferenceReason__Unknown = 0,
    EGeometryScriptMeshDifferenceReason__VertexCount = 1,
    EGeometryScriptMeshDifferenceReason__TriangleCount = 2,
    EGeometryScriptMeshDifferenceReason__EdgeCount = 3,
    EGeometryScriptMeshDifferenceReason__Vertex = 4,
    EGeometryScriptMeshDifferenceReason__Triangle = 5,
    EGeometryScriptMeshDifferenceReason__Edge = 6,
    EGeometryScriptMeshDifferenceReason__Connectivity = 7,
    EGeometryScriptMeshDifferenceReason__Normal = 8,
    EGeometryScriptMeshDifferenceReason__Color = 9
};

enum EGeometryScriptFlareType : uint8_t
{
    EGeometryScriptFlareType__SinMode = 0,
    EGeometryScriptFlareType__SinSquaredMode = 1,
    EGeometryScriptFlareType__TriangleMode = 2
};

enum EGeometryScriptMathWarpType : uint8_t
{
    EGeometryScriptMathWarpType__SinWave1D = 0,
    EGeometryScriptMathWarpType__SinWave2D = 1,
    EGeometryScriptMathWarpType__SinWave3D = 2
};

enum EGeometryScriptMeshEditPolygroupMode : uint8_t
{
    EGeometryScriptMeshEditPolygroupMode__PreserveExisting = 0,
    EGeometryScriptMeshEditPolygroupMode__AutoGenerateNew = 1,
    EGeometryScriptMeshEditPolygroupMode__SetConstant = 2
};

enum EGeometryScriptPolyOperationArea : uint8_t
{
    EGeometryScriptPolyOpef2_j__E_1r__________YV____G = 0,
    EGeometryScriptPolyOperationArea__PerPolygroup = 1,
    EGeometryScriptPolyOperationArea__PerTriangle = 2
};

enum EGeometryScriptOffsetFacesType : uint8_t
{
    EGeometryScriptOffsetFacesType__VertexNormal = 0,
    EGeometryScriptOffsetFacesType__FaceNormal = 1,
    EGeometryScriptOffsetFacesType__ParallelFaceOffset = 2
};

enum EGeometryScriptPrimitivePolygroupMode : uint8_t
{
    EGeometryScriptPrimitivePolygroupMode__SingleGroup = 0,
    EGeometryScriptPrimitivePolygroupMode__PerFace = 1,
    EGeometryScriptPrimitivePolygroupMode__PerQuad = 2
};

enum EGeometryScriptPolygonFillMode : uint8_t
{
    EGeometryScriptPolygonFillMode__All = 0,
    EGeometryScriptPolygonFillMode__Solid = 1,
    EGeometryScriptPolygonFillMode__PositiveWinding = 2,
    EGeometryScriptPolygonFillMode__NonZeroWinding = 3,
    EGeometryScriptPolygonFillMode__NegativeWinding = 4,
    EGeometryScriptPolygonFillMode__OddWinding = 5
};

enum EGeometryScriptRemeshSmoothingType : uint8_t
{
    EGeometryScriptRemeshSmoothingType__Uniform = 0,
    EGeometryScriptRemeshSmoothingType__UVPreserving = 1,
    EGeometryScriptRemeshSmoothingType__Mixed = 2
};

enum EGeometryScriptRepairMeshMode : uint8_t
{
    EGeometryScriptRepairMeshMode__DeleteOnly = 0,
    EGeometryScriptRepairMeshMode__RepairOrDelete = 1,
    EGeometryScriptRepairMeshMode__RepairOrSkip = 2
};

enum EGeometryScriptSamplingWeightMode : uint8_t
{
    EGeometryScriptSamplingWeightMode__WeightToRadius = 0,
    EGeometryScriptSamplingWeightMode__FilledWeightToRadius = 1,
    EGeometryScriptSamplingWeightMode__WeightedRandom = 2
};

enum EGeometryScriptSamplingDistributionMode : uint8_t
{
    EGeometryScriptSamplingDistributionMode__Uniform = 0,
    EGeometryScriptSamplingDistributionMode__Smaller = 1,
    EGeometryScriptSamplingDistributionMode__Larger = 2
};

enum EGeometryScriptTopologyConnectionType : uint8_t
{
    EGeometryScriptTopologyConnectionType__Geometric = 0,
    EGeometryScriptTopologyConnectionType__Polygroup = 1,
    EGeometryScriptTopologyConnectionType__MaterialID = 2
};

enum EGeometryScriptRemoveMeshSimplificationType : uint8_t
{
    EGeometryScriptRemoveMeshSimplificationType__StandardQEM = 0,
    EGeometryScriptRemoveMeshSimplificationType__VolumePreserving = 1,
    EGeometryScriptRemoveMeshSimplificationType__AttributeAware = 2
};

enum ESelectiveTessellatePatternType : uint8_t
{
    ESelectiveTessellatePatternType__ConcentricRings = 0
};

enum EGeometryScriptUVLayoutType : uint8_t
{
    EGeometryScriptUVLayoutType__Transform = 0,
    EGeometryScriptUVLayoutType__Stack = 1,
    EGeometryScriptUVLayoutType__Repack = 2,
    EGeometryScriptUVLayoutType__Normalize = 3
};

enum EGeometryScriptUVFlattenMethod : uint8_t
{
    EGeometryScriptUVFlattenMethod__ExpMap = 0,
    EGeometryScriptUVFlattenMethod__Conformal = 1,
    EGeometryScriptUVFlattenMethod__SpectralConformal = 2
};

enum EGeometryScriptTexelDensityMode : uint8_t
{
    EGeometryScriptTexelDensityMode__ApplyToIslands = 0,
    EGeometryScriptTexelDensityMode__ApplyToWhole = 1,
    EGeometryScriptTexelDensityMode__Normalize = 2
};

enum EGeometryScriptBlurColorMode : uint8_t
{
    EGeometryScriptBlurColorMode__Uniform = 0,
    EGeometryScriptBlurColorMode__EdgeLength = 1,
    EGeometryScriptBlurColorMode__CotanWeights = 2
};

enum EGeometryScriptPolyOffsetJoinType : uint8_t
{
    EGeometryScriptPolyOffsetJoinType__Square = 0,
    EGeometryScriptPolyOffsetJoinType__Round = 1,
    EGeometryScriptPolyOffsetJoinType__Miter = 2
};

enum EGeometryScriptPathOffsetEndType : uint8_t
{
    EGeometryScriptPathOffsetEndType__Butt = 0,
    EGeometryScriptPathOffsetEndType__Square = 1,
    EGeometryScriptPathOffsetEndType__Round = 2
};

enum EGeometryScriptSampleSpacing : uint8_t
{
    EGeometryScriptSampleSpacing__UniformDistance = 0,
    EGeometryScriptSampleSpacing__UniformTime = 1,
    EGeometryScriptSampleSpacing__ErrorTolerance = 2
};

enum EGeometryScriptEvaluateSplineRange : uint8_t
{
    EGeometryScriptEvaluateSplineRange__FullSpline = 0,
    EGeometryScriptEvaluateSplineRange__DistanceRange = 1,
    EGeometryScriptEvaluateSplineRange__TimeRange_ConstantSpeed = 2,
    EGeometryScriptEvaluateSplineRange__TimeRange_VariableSpeed = 3
};

enum ECraftingIngredientReqError : uint8_t
{
    ECraftingIngredientReqError__None = 0,
    ECraftingIngredientReqError__NoItem = 1,
    ECraftingIngredientReqError__NotEnough = 2
};

enum EMusicKeyMode : uint8_t
{
    EMusicKeyMode__Major = 0,
    EMusicKeyMode__Minor = 1,
    EMusicKeyMode__Num = 2
};

enum EMusicKey : uint8_t
{
    EMusicKey__C = 0,
    EMusicKey__Db = 1,
    EMusicKey__D = 2,
    EMusicKey__Eb = 3,
    EMusicKey__E = 4,
    EMusicKey__F = 5,
    EMusicKey__Gb = 6,
    EMusicKey__G = 7,
    EMusicKey__Ab = 8,
    EMusicKey__A = 9,
    EMusicKey__Bb = 10,
    EMusicKey__B = 11,
    EMusicKey__Num = 12
};

enum EMusicInterval : uint8_t
{
    EMusicInterval__P1 = 0,
    EMusicInterval__Min2 = 1,
    EMusicInterval__Maj2 = 2,
    EMusicInterval__Min3 = 3,
    EMusicInterval__Maj3 = 4,
    EMusicInterval__P4 = 5,
    EMusicInterval__TT = 6,
    EMusicInterval__P5 = 7,
    EMusicInterval__Min6 = 8,
    EMusicInterval__Maj6 = 9,
    EMusicInterval__Min7 = 10,
    EMusicInterval__Maj7 = 11,
    EMusicInterval__Num = 12
};

enum EFMJamLoopType : uint8_t
{
    EFMJamLoopType__Lead = 0,
    EFMJamLoopType__Misc = 1,
    EFMJamLoopType__Bass = 2,
    EFMJamLoopType__Beat = 3,
    EFMJamLoopType__Num = 4
};

enum EMusicBattleClientUpdate : uint8_t
{
    EMusicBattleClientUpdate__PilgrimGameCreated = 0,
    EMusicBattleClientUpdate__SongFinished = 1,
    EMusicBattleClientUpdate__TearDownFinished = 2,
    EMusicBattleClientUpdate__StopAndSkipPostGame = 3,
    EMusicBattleClientUpdate__StopAndRestartSong = 4
};

enum EMusicBattleEndReason : uint8_t
{
    EMusicBattleEndReason__NoReason = 0,
    EMusicBattleEndReason__CompletedNormally = 1,
    EMusicBattleEndReason__HardStopAndSkipPostGame = 2,
    EMusicBattleEndReason__HardStopAndContinueFlow = 3,
    EMusicBattleEndReason__RestartingSong = 4
};

enum EMusicBattleType : uint8_t
{
    EMusicBattleType__None = 0,
    EMusicBattleType__SinglePlayerLocalVs = 1,
    EMusicBattleType__MultiplayerVs = 2,
    EMusicBattleType__SinglePlayerSparks = 3,
    EMusicBattleType__TeamQuickplay = 4
};

enum EPilgrimSongDifficulty : uint8_t
{
    EPilgrimSongDifficulty__DifficultyEasy = 0,
    EPilgrimSongDifficulty__DifficultyMedium = 1,
    EPilgrimSongDifficulty__DifficultyHard = 2,
    EPilgrimSongDifficulty__DifficultyExpert = 3,
    EPilgrimSongDifficulty__None = 4,
    EPilgrimSongDifficulty__NumDifficulties = 5
};

enum EPilgrimGemType : uint8_t
{
    EPilgrimGemType__Normal = 0,
    EPilgrimGemTypx_7_______ = 1,
    EPilgrimGemType__HOPO = 2
};

enum EPilgrimTrackType : uint8_t
{
    EPilgrimTrackType__TrackGuitar = 0,
    EPilgrimTrackType__TrackBass = 1,
    EPilgrimTrackType__TrackVocals = 2,
    EPilgrimTrackType__TrackDrum = 3,
    EPilgrimTrackType__TrackPlasticGuitar = 4,
    EPilgrimTrackType__TrackPlasticBass = 5,
    EPilgrimTrackType__TrackPlasticDrum = 6,
    EPilgrimTrackType__TrackEvents = 7,
    EPilgrimTrackType__TrackNone = 8,
    EPilgrimTrackType__NumTrackTypes = 8
};

enum EBeatMarkerType : uint8_t
{
    EBeatMarkerType__None = 0,
    EBeatMarkerType__OnBeat = 1,
    EBeatMarkerType__OnDownbeat = 2
};

enum ESongShortNameMatchType : uint8_t
{
    ESongShortNameMatchType__AlwaysMatch = 0,
    ESongShortNameMatchType__MatchAny = 1,
    ESongShortNameMatchType__MatchAll = 2,
    ESongShortNameMatchType__MatchNone = 3
};

enum ESparksInstrumentType : uint8_t
{
    ESparksInstrumentType__Guitar = 0,
    ESparksInstrumentType__Bass = 1,
    ESparksInstrumentType__Vocals = 2,
    ESparksInstrumentType__Drum = 3,
    ESparksInstrumentType__Keyboard = 4,
    ESparksInstrumentType__None = 5,
    ESparksInstrumentType__NumInstrumentTypes = 5
};

enum ESparksAccountItemSubtype : uint8_t
{
    ESparksAccountItemSubtype__Aura = 0,
    ESparksAccountItemSubtype__Guitar = 1,
    ESparksAccountItemSubtype__Bass = 2,
    ESparksAccountItemSubtype__Keyboard = 3,
    ESparksAccountItemSubtype__Microphone = 4,
    ESparksAccountItemSubtype__Drums = 5,
    ESparksAccountItemSubtype__SpotlightAnim = 6,
    ESparksAccountItemSubtype__Song = 7,
    ESparksAccountItemSubtype__None = 8,
    ESparksAccountItemSubtype__NumAccountItemTypes = 8
};

enum EBassMidiNoteEvent : uint8_t
{
    EBassMidiNoteEvent__None = 0,
    EBassMidiNoteEvent__FretPosition1 = 1,
    EBassMidiNoteEvent__FretPosition2 = 2,
    EBassMidiNoteEvent__FretPosition3 = 3,
    EBassMidiNoteEvent__FretPosition4 = 4,
    EBassMidiNoteEvent__FretPosition5 = 5,
    EBassMidiNoteEvent__FretPosition6 = 6,
    EBassMidiNoteEvent__FretPosition7 = 7,
    EBassMidiNoteEvent__FretPosition8 = 8,
    EBassMidiNoteEvent__FretPosition9 = 9,
    EBassMidiNoteEvent__FretPosition10 = 10,
    EBassMidiNoteEvent__FretPosition11 = 11,
    EBassMidiNoteEvent__FretPosition12 = 12,
    EBassMidiNoteEvent__FretPosition13 = 13,
    EBassMidiNoteEvent__FretPosition14 = 14,
    EBassMidiNoteEvent__FretPosition15 = 15,
    EBassMidiNoteEvent__FretPosition16 = 16,
    EBassMidiNoteEvent__FretPosition17 = 17,
    EBassMidiNoteEvent__FretPosition18 = 18,
    EBassMidiNoteEvent__FretPosition19 = 19,
    EBassMidiNoteEvent__FretPosition20 = 20,
    EBassMidiNoteEvent__StrumDown = 21,
    EBassMidiNoteEvent__StrumUp = 22,
    EBassMidiNoteEvent__ChordShape = 23
};

enum EDrumMidiNoteEvent : uint8_t
{
    EDrumMidiNoteEvent__None = 0,
    EDrumMidiNoteEvent__KickHit_RightFoot = 1,
    EDrumMidiNoteEvent__HiHatPedalUp_LeftFoot = 2,
    EDrumMidiNoteEvent__SnareHit_LeftHand = 3,
    EDrumMidiNoteEvent__SnareHit_RightHand = 4,
    EDrumMidiNoteEvent__HiHatHit_LeftHand = 5,
    EDrumMidiNoteEvent__HiHatHit_RightHand = 6,
    EDrumMidiNoteEvent__Percussion_RightHand = 7,
    EDrumMidiNoteEvent__Crash1HardHit_LeftHand = 8,
    EDrumMidiNoteEvent__Crash1SoftHit_LeftHand = 9,
    EDrumMidiNoteEvent__Crash1Hardhit_RightHand = 10,
    EDrumMidiNoteEvent__Crash1SoftHit_RightHand = 11,
    EDrumMidiNoteEvent__Crash2HardHit_RightHand = 12,
    EDrumMidiNoteEvent__Crash2SoftHit_RightHand = 13,
    EDrumMidiNoteEvent__Crash1Choke = 14,
    EDrumMidiNoteEvent_____2___IY__ = 15,
    EDrumMidiNoteEvent__RideCymbalHit_RightHand = 16,
    EDrumMidiNoteEvent__RideCymbalHit_LeftHand = 17,
    EDrumMidiNoteEvent__Crash2Hit_LeftHand = 18,
    EDrumMidiNoteEvent__Crash2SoftHit_LeftHand = 19,
    EDrumMidiNoteEvent__Tom1Hit_LeftHand = 20,
    EDrumMidiNoteEvent__Tom1Hit_RightHand = 21,
    EDrumMidiNoteEvent__Tom2Hit_LeftHand = 22,
    EDrumMidiNoteEvent__Tom2Hit_RightHand = 23,
    EDrumMidiNoteEvent__FloorTomHit_LeftHand = 24,
    EDrumMidiNoteEvent__FloorTomHit_RightHand = 25,
    EDrumMidiNoteEvent__SticksHeld = 26,
    EDrumMidiNoteEvent__SnareHit_LeftHand_Soft = 27,
    EDrumMidiNoteEvent__SnareHit_RightHand_Soft = 28
};

enum EGuitarMidiNoteEvent : uint8_t
{
    EGuitarMidiNoteEvent__None = 0,
    EGuitarMidiNoteEvent__FretPosition1 = 1,
    EGuitarMidiNoteEvent__FretPosition2 = 2,
    EGuitarMidiNoteEvent__FretPosition3 = 3,
    EGuitarMidiNoteEvent__FretPosition4 = 4,
    EGuitarMidiNoteEvent__FretPosition5 = 5,
    EGuitarMidiNoteEvent__FretPosition6 = 6,
    EGuitarMidiNoteEvent__FretPosition7 = 7,
    EGuitarMidiNoteEvent__FretPosition8 = 8,
    EGuitarMidiNoteEvent__FretPosition9 = 9,
    EGuitarMidiNoteEvent__FretPosition10 = 10,
    EGuitarMidiNoteEvent__FretPosition11 = 11,
    EGuitarMidiNoteEvent__FretPosition12 = 12,
    EGuitarMidiNoteEvent__FretPosition13 = 13,
    EGuitarMidiNoteEvent__FretPosition14 = 14,
    EGuitarMidiNoteEvent__FretPosition15 = 15,
    EGuitarMidiNoteEvent__FretPosition16 = 16,
    EGuitarMidiNoteEvent__FretPosition17 = 17,
    EGuitarMidiNoteEvent__FretPosition18 = 18,
    EGuitarMidiNoteEvent__FretPosition19 = 19,
    EGuitarMidiNoteEvent__FretPosition20 = 20,
    EGuitarMidiNoteEvent__StrumDown = 21,
    EGuitarMidiNoteEvent__StrumUp = 22,
    EGuitarMidiNoteEvent__ChordShape = 23
};

enum EGuitarMidiTextEvent : uint8_t
{
    EGuitarMidiTextEvent__None = 0,
    EGuitarMidiTextEvent__PlayingMellow = 1,
    EGuitarMidiTextEvent__PlayingStandard = 2,
    EGuitarMidiTextEvent__PlayingIntense = 3,
    EGuitarMidiTextEvent__IdleRhythmMellow = 4,
    EGuitarMidiTextEvent__IdleRhythmStandard = 5,
    EGuitarMidiTextEvent__IdleRhythmIntense = 6,
    EGuitarMidiTextEvent__IdleRealtime = 7,
    EGuitarMidiTextEvent__UsingInstrumentGuitar = 8,
    EGuitarMidiTextEvent__UsingInstrumentKeytar = 9,
    EGuitarMidiTextEvent__Pickup = 10
};

enum EVocalsMidiNoteEvent : uint8_t
{
    EVocalsMidiNoteEvent__None = 0
};

enum EMidiEventListenerInitBroadcast : uint8_t
{
    EMidiEventListenerInitBroadcast__NoPreviousEvents = 0,
    EMidiEventListenerInitBroadcast__MostRecentEvent = 1,
    EMidiEventListenerInitBroadcast__AllPreviousEvents = 2
};

enum EDatasmithLightShape : uint8_t
{
    EDatasmithLightShape__Rectangle = 0,
    EDatasmithLightShaky_V__Hx = 1,
    EDatasmithLightShape__Sphere = 2,
    EDatasmithLightShape__Cylinder = 3,
    EDatasmithLightShape__None = 4
};

enum EDatasmithTextureFilter : uint8_t
{
    EDatasmithTextureFilter__Nearest = 0,
    EDatasmithTextureFilter__Bilinear = 1,
    EDatasmithTextureFilter__Trilinear = 2,
    EDatasmithTextureFilter__Default = 3
};

enum EDatasmithTextureAddress : uint8_t
{
    EDatasmithTextureAddress__Wrap = 0,
    EDatasmithTextureAddress__Clamp = 1,
    EDatasmithTextureAddress__Mirror = 2
};

enum EDatasmithColorSpace : uint8_t
{
    EDatasmithColorSpace__Default = 0,
    EDatasmithColorSpace__sRGB = 1,
    EDatasmithColorSpace__Linear = 2
};

enum EDatasmithKeyValuePropertyType : uint8_t
{
    EDatasmithKeyValuePropertyType__String = 0,
    EDatasmithKeyValuePropertyType__Color = 1,
    EDatasmithKeyValuePropertyType__Float = 2,
    EDatasmithKeyValuePropertyType__Bool = 3,
    EDatasmithKeyValuePropertyType__Texture = 4,
    EDatasmithKeyValuePropertyType__Vector = 5,
    EDatasmithKeyValuePropertyType__Integer = 6
};

enum EDatasmithCompletionMode : uint8_t
{
    EDatasmithCompletionMode__KeepState = 0,
    EDatasmithCompletionMode__RestoreState = 1,
    EDatasmithCompletionMode__ProjectDefault = 2
};

enum ESparksSongAgeRating : uint8_t
{
    ESparksSongAgeRating__None = 0,
    ESparksSongAgeRating__E = 1,
    ESparksSongAgeRating__E10p = 2,
    ESparksSongAgeRating__T = 3
};

enum ESparksGenre : uint8_t
{
    ESparksGenre__None = 0,
    ESparksGenre__RapHipHop = 1,
    ESparksGenre__RnB = 2,
    ESparksGenre__Pop = 3,
    ESparksGenre__Rock = 4,
    ESparksGenre__DanceElectronic = 5,
    ESparksGenre__Country = 6,
    ESparksGenre__LatinCarribean = 7,
    ESparksGenre__Other = 8,
    ESparksGenre__Count = 9
};

enum ESongSortMethod : uint8_t
{
    ESongSortMethod__Title = 0,
    ESongSortMethod__Shortname = 1,
    ESongSortMethod__Artist = 2,
    ESongSortMethod__Album = 3,
    ESongSortMethod__Genre = 4,
    ESongSortMethod__ReleaseYear = 5,
    ESongSortMethod__None = 6,
    ESongSortMethod__ESongSortMethQh__VC = 7
};

enum ESongSortDirection : uint8_t
{
    ESongSortDirection__Ascending = 0,
    ESongSortDirection__Descending = 1,
    ESongSortDirection__None = 2
};

enum EShaderFundamentalType : uint16_t
{
    EShaderFundamentalType__Bool = 0,
    EShaderFundamentalType__Int = 1,
    EShaderFundamentalType__Uint = 2,
    EShaderFundamentalType__Float = 3,
    EShaderFundamentalType__Struct = 4,
    EShaderFundamentalType__None = 255
};

enum EShaderParamBindingType : uint8_t
{
    EShaderParamBindingType__None = 0,
    EShaderParamBindingType__ConstantParameter = 1,
    EShaderParamBindingType__ReadOnlyResource = 2,
    EShaderParamBindingType__ReadWriteResource = 3
};

enum EShaderParamModifier : uint8_t
{
    EShaderParamModifier__None = 0,
    EShaderParamModifier__In = 1,
    EShaderParamModifier__Out = 2,
    EShaderParamModifier__InOut = 3
};

enum EPCGAttributeAccessorFlags : uint8_t
{
    EPCGAttributeAccessorFlags__StrictType = 1,
    EPCGAttributeAccessorFlags__AllowBroadcast = 2,
    EPCGAttributeAccessorFlags__AllowConstructible = 4,
    EPCGAttributeAccessorFlags__AllowSetDefaultValue = 8,
    EPCGAttributeAccessorFlags__AllowReuseMetadataEntryKey = 16,
    EPCGAttributeAccessorFlags__AllowBroadcastAndConstructible = 6
};

enum EPCGAttractMode : uint8_t
{
    EPCGAttractMode__Closest = 0,
    EPCGAttractMode__MinAttribute = 1,
    EPCGAttractMode__MaxAttribute = 2,
    EPCGAttractMode__FromIndex = 3
};

enum EPCGAttributePropertySelection : uint8_t
{
    EPCGAttributePropertySelection__Attribute = 0,
    EPCGAttributePropertySelection__PointProperty = 1,
    EPCGAttributePropertySelection__ExtraProperty = 2
};

enum EPCGExtraProperties : uint8_t
{
    EPCGExtraProperties__Index = 0
};

enum EPCGControlPointFuseMode : uint8_t
{
    EPCGControlPointFuseMode__KeepFirst = 0,
    EPCGControlPointFuseMode__KeepSecond = 1,
    EPCGControlPointFuseMode__Merge = 2,
    EPCGControlPointFuseMode__Auto = 3
};

enum EPCGCollapseVisitOrder : uint8_t
{
    EPCGCollapseVisitOrder__Ordered = 0,
    EPCGCollapseVisitOrder__Random = 1,
    EPCGCollapseVisitOrder__MinAttribute = 2,
    EPCGCollapseVisitOrder__MaxAttribute = 3
};

enum EPCGDensityMergeOperation : uint8_t
{
    EPCGDensityMergeOperation__Set = 0,
    EPCGDensityMergeOperation__Ignore = 1
};

enum EPCGReadbackMode : uint8_t
{
    EPCGReadbackMode__None = 0,
    EPCGReadbackMode__GraphOutput = 2,
    EPCGReadbackMode__Inspection = 4,
    EPCGReadbackMode__DebugVisualization = 8
};

enum EPCGKernelAttributeType : uint16_t
{
    EPCGKernelAttributeType__None = 0,
    EPCGKernelAttributeType__Bool = 1,
    EPCGKernelAttributeType__Int = 2,
    EPCGKernelAttributeType__Float = 3,
    EPCGKernelAttributeType__Float2 = 4,
    EPCGKernelAttributeType__Float3 = 5,
    EPCGKernelAttributeType__Float4 = 6,
    EPCGKernelAttributeType__Rotator = 7,
    EPCGKernelAttributeType__Quat = 8,
    EPCGKernelAttributeType__Transform = 9,
    EPCGKernelAttributeType__StringKey = 10,
    EPCGKernelAttributeType__Name = 11,
    EPCGKernelAttributeType__Invalid = 255
};

enum EPCGMetadataTypes : uint16_t
{
    EPCGMetadataTypes__Float = 0,
    EPCGMetadataTypes__Double = 1,
    EPCGMetadataTypes__Integer32 = 2,
    EPCGMetadataTypes__Integer64 = 3,
    EPCGMetadataTypes__Vector2 = 4,
    EPCGMetadataTypes__Vector = 5,
    EPCGMetadataTypes__Vector4 = 6,
    EPCGMetadataTypes__Quaternion = 7,
    EPCGMetadataTypes__Transform = 8,
    EPCGMetadataTypes__String = 9,
    EPCGMetadataTypes__Boolean = 10,
    EPCGMetadataTypes__Rotator = 11,
    EPCGMetadataTypes__Name = 12,
    EPCGMetadataTypes__SoftObjectPath = 13,
    EPCGMetadataTypes__SoftClassPath = 14,
    EPCGMetadataTypes__Count = 15,
    EPCGMetadataTypes__Unknown = 255
};

enum EPCGMetadataOp : uint8_t
{
    EPCGMetadataOp__Min = 0,
    EPCGMetadataOp__Max = 1,
    EPCGMetadataOp__Sub = 2,
    EPCGMetadataOp__Add = 3,
    EPCGMetadataOp__Mul = 4,
    EPCGMetadataOp__Div = 5,
    EPCGMetadataOp__So__j__p_Y_ = 6,
    EPCGMetadataOp__TargetValue = 7
};

enum EPCGMetadataMakeRotatorOp : uint8_t
{
    EPCGMetadataMakeRotatorOp__MakeRotFromX = 0,
    EPCGMetadataMakeRotatorOp__MakeRotFromY = 1,
    EPCGMetadataMakeRotatorOp__MakeRotFromZ = 2,
    EPCGMetadataMakeRotatorOp__MakeRotFromXY = 3,
    EPCGMetadataMakeRotatorOp__MakeRotFromYX = 4,
    EPCGMetadataMakeRotatorOp__MakeRotFromXZ = 5,
    EPCGMetadataMakeRotatorOp__MakeRotFromZX = 6,
    EPCGMetadataMakeRotatorOp__MakeRotFromYZ = 7,
    EPCGMetadataMakeRotatorOp__MakeRotFromZY = 8,
    EPCGMetadataMakeRotatorOp__MakeRotFromAxes = 9,
    EPCGMetadataMakeRotatorOp__MakeRotFromAngles = 10
};

enum PCGNormalToDensityMode : uint8_t
{
    PCGNormalToDensityMode__Set = 0,
    PCGNormalToDensityMode__Minimum = 1,
    PCGNormalToDensityMode__Maximum = 2,
    PCGNormalToDensityMode__Add = 3,
    PCGNormalToDensityMode__Subtract = 4,
    PCGNormalToDensityMode__Multiply = 5,
    PCGNormalToDensityMode__Divide = 6
};

enum EPCGSelectGrammarComparator : uint8_t
{
    EPCGSelectGrammarComparator__BinaryOps = 32,
    EPCGSelectGrammarComparator__Select = 33,
    EPCGSelectGrammarComparator__LessThan = 34,
    EPCGSelectGrammarComparator__LessThanEqualTo = 35,
    EPCGSelectGrammarComparator__EqualTo = 36,
    EPCGSelectGrammarComparator__GreaterThanEqualTo = 37,
    EPCGSelectGrammarComparator__GreaterThan = 38,
    EPCGSelectGrammarComparator__TernaryOps = 64,
    EPCGSelectGrammarComparator__RangeExclusive = 65,
    EPCGSelectGrammarComparator__RangeInclusive = 66
};

enum EPCGWorldRaycastMode : uint8_t
{
    EPCGWorldRaycastMode__Infinite = 0,
    EPCGWorldRaycastMode__ScaledVector = 1,
    EPCGWorldRaycastMode__NormalizedWithLength = 2,
    EPCGWorldRaycastMode__Segments = 3
};

enum EPCGCollisionQueryFlag : uint8_t
{
    EPCGCollisionQueryFlag__Simple = 0,
    EPCGCollisionQueryFlag__Complex = 1,
    EPCGCollisionQueryFlag__SimpleFirst = 2,
    EPCGCollisionQueryFlag__ComplexFirst = 3
};

enum EPCGTextureColorChannel : uint8_t
{
    EPCGTextureColorChannel__Red = 0,
    EPCGTextureColorChannel__Green = 1,
    EPCGTextureColorChannel__Blue = 2,
    EPCGTextureColorChannel__Alpha = 3
};

enum EPCGWorldQueryFilter : uint8_t
{
    EPCGWorldQueryFilter__None = 0,
    EPCGWorldQueryFilter__Include = 1,
    EPCGWorldQueryFilter__Exclude = 2,
    EPCGWorldQueryFilter__Require = 3,
    EPCGWorldQueryFilter__NoTagFilter = 0,
    EPCGWorldQueryFilter__IncludeTagged = 1,
    EPCGWorldQueryFilter__ExcludeTagged = 2
};

enum EPCGMetadataBitwiseOperation : uint8_t
{
    EPCGMetadataBitwiseOperation__And = 0,
    EPCGMetadataBitwiseOperation__Not = 1,
    EPCGMetadataBitwiseOperation__Or = 2,
    EPCGMetadataBitwiseOperation__Xor = 3
};

enum EPCGMetadataBooleanOperation : uint8_t
{
    EPCGMetadataBooleanOperation__And = 0,
    EPCGMetadataBooleanOperation__Not = 1,
    EPCGMetadataBooleanOperation__Or = 2,
    EPCGMetadataBooleanOperation__Xor = 3
};

enum EPCGMetadataCompareOperation : uint8_t
{
    EPCGMetadataCompareOperation__Equal = 0,
    EPCGMetadataCompareOperation__NotEqual = 1,
    EPCGMetadataCompareOperation__Greater = 2,
    EPCGMetadataCompareOperation__GreaterOrEqual = 3,
    EPCGMetadataCompareOperation__Less = 4,
    EPCGMetadataCompareOperation__LessOrEqual = 5
};

enum EPCGMetadataMakeVector4 : uint8_t
{
    EPCGMetadataMakeVector4__FourValues = 0,
    EPCGMetadataMakeVector4__Vector2AndTwoValues = 1,
    EPCGMetadataMakeVector4__TwoVector2 = 2,
    EPCGMetadataMakeVector4__Vector3AndValue = 3
};

enum EPCGMetadataVectorOperation : uint8_t
{
    EPCGMetadataVectorOperation__VectorOp = 0,
    EPCGMetadataVectorOperation__Cross = 1,
    EPCGMetadataVectorOperation__Dot = 2,
    EPCGMetadataVectorOperation__Distance = 3,
    EPCGMetadataVectorOperation__Normalize = 4,
    EPCGMetadataVectorOperation__Length = 5,
    EPCGMetadataVectorOperation__RotateAroundAxis = 6,
    EPCGMetadataVectorOperation__TransformOp = 100,
    EPCGMetadataVectorOperation__TransformDirection = 101,
    EPCGMetadataVectorOperation__TransformLocation = 102,
    EPCGMetadataVectorOperation__InverseTransformDirection = 103,
    EPCGMetadataVectorOperation__InverseTransformLocation = 104
};

enum EPCGActorFilter : uint8_t
{
    EPCGActorFilter__Self = 0,
    EPCGActorFilter__Parent = 1,
    EPCGActorFilter__Root = 2,
    EPCGActorFilter__AllWorldActors = 3,
    EPCGActorFilter__Original = 4,
    EPCGActorFilter__FromInput = 5
};

enum EPCGAttributeReduceOperation : uint8_t
{
    EPCGAttributeReduceOperation__Average = 0,
    EPCGAttributeReduceOperation__Max = 1,
    EPCGAttributeReduceOperation__Min = 2,
    EPCGAttributeReduceOperation__Sum = 3,
    EPCGAttributeReduceOperation__Join = 4
};

enum EPCGCopyPointsInheritanceMode : uint8_t
{
    EPCGCopyPointsInheritanceMode__Relative = 0,
    EPCGCopyPointsInheritanceMode__Source = 1,
    EPCGCopyPointsInheritanceMode__Target = 2
};

enum EPCGCopyPointsTagInheritanceMode : uint8_t
{
    EPCGCopyPointsTagInheritanceMode__Both = 0,
    EPCGCopyPointsTagInheritanceMode__Source = 1,
    EPCGCopyPointsTagInheritanceMode__Target = 2
};

enum EPCGGeodesicSphereRepresentation : uint8_t
{
    EPCGGeodesicSphereRepresentation__Icosahedron = 0
};

enum EPCGSpherePointOrientation : uint8_t
{
    EPCGSpherePointOrientation__Radial = 0,
    EPCGSpherePointOrientation__Centric = 1,
    EPCGSpherePointOrientation__None = 2
};

enum EPCGGetDataFromActorMode : uint8_t
{
    EPCGGetDataFromActorMode__ParseActorComponents = 0,
    EPCGGetDataFromActorMode__GetSinglePoint = 1,
    EPCGGetDataFromActorMode__GetDataFromProperty = 2,
    EPCGGetDataFromActorMode__GetDataFromPCGComponent = 3,
    EPCGGetDataFromActorMode__GetDataFromPCGComponentOrParseComponents = 4,
    EPCGGetDataFromActorMode__GetActorReference = 5,
    EPCGGetDataFromActorMode__GetComponentsReference = 6
};

enum EPCGProxyInterfaceMode : uint8_t
{
    EPCGProxyInterfaceMode__ByNativeElement = 0,
    EPCGProxyInterfaceMode__ByBlueprintElement = 1,
    EPCGProxyInterfaceMode__BySettings = 2
};

enum EPCGMatchMaxDistanceMode : uint8_t
{
    EPCGMatchMaxDistanceMode__NoMaxDistance = 0,
    EPCGMatchMaxDistanceMode__UseConstantMaxDistance = 1,
    EPCGMatchMaxDistanceMode__AttributeMaxDistance = 2
};

enum PCGSpatialNoiseMask2DMode : uint8_t
{
    PCGSpatialNoiseMask2DMode__Perlin = 0,
    PCGSpatialNoiseMask2DMode__Caustic = 1,
    PCGSpatialNoiseMask2DMode__FractionalBrownian = 2
};

enum EPCGSpawnActorOption : uint8_t
{
    EPCGSpawnActorOption__CollapseActors = 0,
    EPCGSpawnActorOption__MergePCGOnly = 1,
    EPCGSpawnActorOption__NoMerging = 2
};

enum EPCGSpawnActorGenerationTrigger : uint8_t
{
    EPCGSpawnActorGenerationTrigger__Default = 0,
    EPCGSpawnActorGenerationTrigger__ForceGenerate = 1,
    EPCGSpawnActorGenerationTrigger__DoNotGenerateInEditor = 2,
    EPCGSpawnActorGenerationTrigger__DoNotGenerate = 3
};

enum EPCGSplineMeshForwardAxis : uint8_t
{
    EPCGSplineMeshForwardAxis__X = 0,
    EPCGSplineMeshForwardAxis__Y = 1,
    EPCGSplineMeshForwardAxis__Z = 2,
    EPCGSplineMeshForwardAxis__EPCGSplineMeshFory___________ = 3
};

enum EPCGSplineSamplingMode : uint8_t
{
    EPCGSplineSamplingMode__Subdivision = 0,
    EPCGSplineSamplingMode__Distance = 1,
    EPCGSplineSamplingMode__NumberOfSamples = 2
};

enum EPCGLandscapeCacheSerializationMode : uint8_t
{
    EPCGLandscapeCacheSerializationMode__SerializeOnlyAtCook = 0,
    EPCGLandscapeCacheSerializationMode__NeverSerialize = 1,
    EPCGLandscapeCacheSerializationMode__AlwaysSerialize = 2
};

enum EPCGComponentDirtyFlag : uint8_t
{
    EPCGComponentDirtyFlag__None = 0,
    EPCGComponentDirtyFlag__Actor = 1,
    EPCGComponentDirtyFlag__Landscape = 2,
    EPCGComponentDirtyFlag__Input = 4,
    EPCGComponentDirtyFlag__Data = 8,
    EPCGComponentDirtyFlag__All = 15
};

enum EPCGPinUsage : uint8_t
{
    EPCGPinUsage__Normal = 0,
    EPCGPinUsage__Loop = 1,
    EPCGPinUsage__Feedback = 2,
    EPCGPinUsage__DependencyOnly = 3
};

enum EPCGPinStatus : uint8_t
{
    EPCGPinStatus__Normal = 0,
    EPCGPinStatus__Required = 1,
    EPCGPinStatus__Advanced = 2,
    EPCGPinStatus__OverrideOrUserParam = 3
};

enum EPCGTypeConvery1__ : uint8_t
{
    EPCGTypeConversion__NoConversionRequired = 0,
    EPCGTypeConversion__CollapseToPoint = 1,
    EPCGTypeConversion__Filter = 2,
    EPCGTypeConversion__MakeConcrete = 3,
    EPCGTypeConversion__SplineToSurface = 4,
    EPCGTypeConversion__Failed = 5
};

enum EPCGSettingsExecutionMode : uint8_t
{
    EPCGSettingsExecutionMode__Enabled = 0,
    EPCGSettingsExecutionMode__Debug = 1,
    EPCGSettingsExecutionMode__Isolated = 2,
    EPCGSettingsExecutionMode__Disabled = 3
};

enum EDeterminismLevel : uint8_t
{
    EDeterminismLevel__None = 0,
    EDeterminismLevel__NoDeterminism = 0,
    EDeterminismLevel__Basic = 1,
    EDeterminismLevel__OrderOrthogonal = 2,
    EDeterminismLevel__OrderConsistent = 3,
    EDeterminismLevel__OrderIndependent = 4,
    EDeterminismLevel__Deterministic = 4
};

enum EGraphElementType : uint8_t
{
    EGraphElementType__Node = 0,
    EGraphElementType__Edge = 1,
    EGraphElementType__Island = 2,
    EGraphElementType__Unknown = 3
};

enum EGraphIslandOperations : uint8_t
{
    EGraphIslandOperations__None = 0,
    EGraphIslandOperations__Add = 1,
    EGraphIslandOperations__Split = 2,
    EGraphIslandOperations__Merge = 4,
    EGraphIslandOperations__Destroy = 8,
    EGraphIslandOperations__All = 15
};

enum EGraphIslandConnectivityChange : uint8_t
{
    EGraphIslandConnectivityChange__VertexAdd = 0,
    EGraphIslandConnectivityChange__SplitFrom = 1,
    EGraphIslandConnectivityChange__SplitTo = 2,
    EGraphIslandConnectivityChange__Other = 3
};

enum EJunoWorldOccupantKind : uint8_t
{
    EJunoWorldOccupantKind__Owner = 0,
    EJunoWorldOccupantKind__Keyholder = 1,
    EJunoWorldOccupantKind__Guest = 2,
    EJunoWorldOccupantKind__Count = 3
};

enum EJunoWorldSettingOptions_BuildMode : uint8_t
{
    EJunoWorldSettingOptions_BuildMode__Survival = 0,
    EJunoWorldSettingOptions_BuildMode__Sandbox = 1,
    EJunoWorldSettingOptions_BuildMode__Hardcore = 2,
    EJunoWorldSettingOptions_BuildMode__Cozy = 3
};

enum EJunoWorldSettingOptions_Difficulty : uint8_t
{
    EJunoWorldSettingOptions_Difficulty__Normal = 0,
    EJunoWorldSettingOptions_Difficulty__Hardcore = 1,
    EJunoWorldSettingOptions_Difficulty__Easy = 2
};

enum EFortMantisTechniqueActivationInputType : uint8_t
{
    EFortMantisTechniqueActivationInputType__None = 0,
    EFortMantisTechniqueActivationInputType__Primary = 1,
    EFortMantisTechniqueActivationInputType__Secondary = 2,
    EFortMantisTechniqueActivationInputType__Max_Invalid = 3
};

enum EFortMantisBranchRule : uint8_t
{
    EFortMantisBranchRule__Off = 0,
    EFortMantisBranchRule__Any = 1,
    EFortMantisBranchRule__Starter = 2
};

enum EFortMantisBranchPath : uint8_t
{
    EFortMantisBranchPath__Default = 0,
    EFortMantisBranchPath__Path = 1,
    EFortMantisBranchPath__Path = 2,
    EFortMantisBranchPath__Path = 3,
    EFortMantisBranchPath__Path = 4,
    EFortMantisBranchPath__Path = 5,
    EFortMantisBranchPath__Blocked = 6
};

enum EFortMantisWarpTranslationMethod : uint8_t
{
    EFortMantisWarpTranslationMethod__None = 0,
    EFortMantisWarpTranslationMethod__OffsetFromTargetActor = 1,
    EFortMantisWarpTranslationMethod__StaticLocation = 2,
    EFortMantisWarpTranslationMethod__Reorient = 3,
    EFortMantisWarpTranslationMethod__ScaledBasedOnInput = 4,
    EFortMantisWarpTranslationMethod__ReorientAndScaledBasedOnInput = 5
};

enum EJunoBuildingPlacementType : uint8_t
{
    EJunoBuildingPlacementType__GuidedSnapping = 0,
    EJunoBuildingPlacementType__Connectivity = 1,
    EJunoBuildingPlacementType__SnapPlacement = 2,
    EJunoBuildingPlacementType__NoTarget = 3
};

enum EJunoBiome : uint8_t
{
    EJunoBiome__Unknown = 0,
    EJunoBiome__Grasslands = 1,
    EJunoBiome__DarkForest = 2,
    EJunoBiome__Desert = 3,
    EJunoBiome__Tropical = 4,
    EJunoBiome__Alpine = 5,
    EJunoBiome__Water = 6,
    EJunoBiome__Jungle = 7,
    EJunoBiome__Mountain = 8,
    EJunoBiome__Reserved = 9,
    EJunoBiome__Max = 10
};

enum ECampRemovalStatus : uint8_t
{
    ECampRemovalStatus__NotRemoved = 0,
    ECampRemovalStatus__SoftRemoved = 1,
    ECampRemovalStatus__HardRemoved = 2
};

enum EJunoCaveType : uint8_t
{
    EJunoCaveType__Unknown = 0,
    EJunoCaveType__Surface = 1,
    EJunoCaveType__Lava = 2,
    EJunoCaveType__Rift = 3,
    EJunoCaveType__Ruins = 4,
    EJunoCaveType__SurfaceMines = 5,
    EJunoCaveType__Pirate = 6,
    EJunoCaveType__Bear = 7,
    EJunoCaveType__Treasure = 8,
    EJunoCaveType__BossRoom = 9,
    EJunoCaveType__Max = 10
};

enum EJunoCustomIndicatorState : uint8_t
{
    EJunoCustomIndicatorState__None = 0,
    EJunoCustomIndicatorState__Hidden = 1,
    EJunoCustomIndicatorState__Shown = 2
};

enum EAIRangedWeaponMultiFireAbilityDirectionType : uint8_t
{
    EAIRangedWeaponMultiFireAbilityDirectionType__PositiveX = 0,
    EAIRangedWeaponMultiFireAbilityDirectionType__InitialTargetDirection = 1,
    EAIRangedWeaponMultiFireAbilityDirectionType__CurrentTargetDirection = 2,
    EAIRangedWeaponMultiFireAbilityDirectionType__EAIRangedWeaponMultiFireAbilityDirectiG0w = 3
};

enum EJunoAwesomeUpgradeRecruitmentRequirementType : uint8_t
{
    EJunoAwesomeUpgradeRecruitmentRequirementType__Villager = 0,
    EJunoAwesomeUpgradeRecruitmentRequirementType__Creature = 1,
    EJunoAwesomeUpgradeRecruitmentRequirementType__Any = 2
};

enum EJunoAwesomeUpgradeStepType : uint8_t
{
    EJunoAwesomeUpgradeStepType__BuiltObjects = 0,
    EJunoAwesomeUpgradeStepType__PersistantTag = 1,
    EJunoAwesomeUpgradeStepType__WorldReaction = 2,
    EJunoAwesomeUpgradeStepType__RecruitedCount = 3
};

enum EJunoCompassDirection : uint8_t
{
    EJunoCompassDirection__Unknown = 0,
    EJunoCompassDirection__North = 1,
    EJunoCompassDirection__NorthEast = 2,
    EJunoCompassDirection__East = 3,
    EJunoCompassDirection__SouthEast = 4,
    EJunoCompassDirection__South = 5,
    EJunoCompassDirection__SouthWest = 6,
    EJunoCompassDirection__West = 7,
    EJunoCompassDirection__NorthWest = 8,
    EJunoCompassDirection__Max = 9
};

enum EJunoTrackedActorRefreshReason : uint8_t
{
    EJunoTrackedActorRefreshReason__LocationChanged = 0,
    EJunoTrackedActorRefreshReason__NetRelDistanceChanged = 1,
    EJunoTrackedActorRefreshReason__NumberOfRelevantActorsChanged = 2,
    EJunoTrackedActorRefreshReason__Unknown = 3
};

enum EJunoCampUpgradeRewardFilters : uint8_t
{
    EJunoCampUpgradeRewardFilters__None = 0,
    EJunoCampUpgradeRewardFilters__General = 1,
    EJunoCampUpgradeRewardFilters__BiomeSpecific = 2,
    EJunoCampUpgradeRewardFilters__GenericEvent = 4
};

enum EJunoRecruitmentObjectAcceptedPawnType : uint8_t
{
    EJunoRecruitmentObjectAcceptedPawnType__None = 0,
    EJunoRecruitmentObjectAcceptedPawnType__Player = 1,
    EJunoRecruitmentObjectAcceptedPawnType__NPC = 2,
    EJunoRecruitmentObjectAcceptedPawnType__Creature = 4
};

enum EJunoDumpWorldPersistentContentsVerbosity : uint8_t
{
    EJunoDumpWorldPersistentContentsVerbosity__Compact = 0,
    EJunoDumpWorldPersistentContentsVerbosity__Default = 1,
    EJunoDumpWorldPersistentContentsVerbosity__Verbose = 2
};

enum EJunoGeneratePersistenceAssetsReportCommandletAction : uint8_t
{
    EJunoGeneratePersistenceAssetsReportCommandletAction__None = 0,
    EJunoGeneratePersistenceAssetsReportCommandletAction__GeneratePersistenceSchema = 1,
    EJunoGeneratePersistenceAssetsReportCommandletAction__GeneratePersistenceAssetsReport = 2,
    EJunoGeneratePersistenceAssetsReportCommandletAction__GeneratePersistenceAssetsBackwardCompatibiliyReport = 3
};

enum EJunoGeometryCollectionAssemblerDurationType : uint8_t
{
    EJunoGeometryCollectionAssemblerDurat_____ = 0,
    EJunoGeometryCollectionAssemblerDurationType__CalculateLayerCount = 1,
    EJunoGeometryCollectionAssemblerDurationType__SpecifyLayerCount = 2
};

enum EJunoKnowledgeState : uint8_t
{
    EJunoKnowledgeState__Hidden = 0,
    EJunoKnowledgeState__Revealed = 1,
    EJunoKnowledgeState__Acquired = 2
};

enum EJunoPersistenceAssetBackwardCompatibilityIssueType : uint8_t
{
    EJunoPersistenceAssetBackwardCompatibilityIssueType__None = 0,
    EJunoPersistenceAssetBackwardCompatibilityIssueType__Missing = 1,
    EJunoPersistenceAssetBackwardCompatibilityIssueType__NoLongerCooked = 2,
    EJunoPersistenceAssetBackwardCompatibilityIssueType__IncompatibleContents = 3
};

enum EJunoGeneratePersistenceAssetCustomDumpMode : uint8_t
{
    EJunoGeneratePersistenceAssetCustomDumpMode__None = 0,
    EJunoGeneratePersistenceAssetCustomDumpMode__InCookOnly = 1,
    EJunoGeneratePersistenceAssetCustomDumpMode__All = 2
};

enum EJunoPersistenceUnrecoverableErrorResponse : uint8_t
{
    EJunoPersistenceUnrecoverableErrorResponse__CrashServer = 0,
    EJunoPersistenceUnrecoverableErrorResponse__ShutdownServer = 1,
    EJunoPersistenceUnrecoverableErrorResponse__Ignore = 2
};

enum EJunoPersistenceFeatureCheckoutState : uint8_t
{
    EJunoPersistenceFeatureCheckoutState__None = 0,
    EJunoPersistenceFeatureCheckoutState__CheckedOut = 1,
    EJunoPersistenceFeatureCheckoutState__CheckedIn = 2
};

enum EJunoWorldConditionAICampChecksIsAssigned : uint8_t
{
    EJunoWorldConditionAICampChecksIsAssigned__None = 0,
    EJunoWorldConditionAICampChecksIsAssigned__Assigned = 1,
    EJunoWorldConditionAICampChecksIsAssigned__Unassigned = 2
};

enum EJunoWorldConditionMustHaveLastUsedGatheringActor : uint8_t
{
    EJunoWorldConditionMustHaveLastUsedGatheringActor__None = 0,
    EJunoWorldConditionMustHaveLastUsedGatheringActor__IsValid = 1,
    EJunoWorldConditionMustHaveLastUsedGatheringActor__IsNotValid = 2
};

enum EJunoWorldConditionHasFollower : uint8_t
{
    EJunoWorldConditionHasFollower__Unset = 0,
    EJunoWorldConditionHasFollower__Zero = 1,
    EJunoWorldConditionHasFollower__OneOrMore = 2
};

enum EJunoEquipmentChangedFilterState : uint8_t
{
    EJunoEquipmentChangedFilterState__Equipped = 0,
    EJunoEquipmentChangedFilterState__UnEquipped = 1,
    EJunoEquipmentChangedFilterState__Any = 2
};

enum EJunoPartAttachmentDynamicFilter : uint8_t
{
    EJunoPartAttachmentDynamicFilter__IgnoreDynamicRequirements = 0,
    EJunoPartAttachmentDynamicFilter__RequireDynamicStructure = 1,
    EJunoP_______mQ___m_____ = 2
};

enum EJunoPartAttachmentToysFilter : uint8_t
{
    EJunoPartAttachmentToysFilter__IgnoreToysAttachedRequirements = 0,
    EJunoPartAttachmentToysFilter__RequireToysAttached = 1,
    EJunoPartAttachmentToysFilter__RequireNoToysAttached = 2
};

enum EJunoPartAttachmentTypeFilter : uint8_t
{
    EJunoPartAttachmentTypeFilter__IgnoreAttachmentType = 0,
    EJunoPartAttachmentTypeFilter__RequireAttached = 1,
    EJunoPartAttachmentTypeFilter__RequireDetached = 2
};

enum EEditMeshPolygonsToolActions : uint8_t
{
    EEditMeshPolygonsToolActions__NoAction = 0,
    EEditMeshPolygonsToolActions__AcceptCurrent = 1,
    EEditMeshPolygonsToolActions__CancelCurrent = 2,
    EEditMeshPolygonsToolActions__Extrude = 3,
    EEditMeshPolygonsToolActions__PushPull = 4,
    EEditMeshPolygonsToolActions__Offset = 5,
    EEditMeshPolygonsToolActions__Inset = 6,
    EEditMeshPolygonsToolActions__Outset = 7,
    EEditMeshPolygonsToolActions__BevelFaces = 8,
    EEditMeshPolygonsToolActions__InsertEdge = 9,
    EEditMeshPolygonsToolActions__InsertEdgeLoop = 10,
    EEditMeshPolygonsToolActions__Complete = 11,
    EEditMeshPolygonsToolActions__PlaneCut = 12,
    EEditMeshPolygonsToolActions__Merge = 13,
    EEditMeshPolygonsToolActions__Delete = 14,
    EEditMeshPolygonsToolActions__CutFaces = 15,
    EEditMeshPolygonsToolActions__RecalculateNormals = 16,
    EEditMeshPolygonsToolActions__FlipNormals = 17,
    EEditMeshPolygonsToolActions__Retriangulate = 18,
    EEditMeshPolygonsToolActions__Decompose = 19,
    EEditMeshPolygonsToolActions__Disconnect = 20,
    EEditMeshPolygonsToolActions__Duplicate = 21,
    EEditMeshPolygonsToolActions__CollapseEdge = 22,
    EEditMeshPolygonsToolActions__WeldEdges = 23,
    EEditMeshPolygonsToolActions__WeldEdgesCentered = 24,
    EEditMeshPolygonsToolActions__StraightenEdge = 25,
    EEditMeshPolygonsToolActions__FillHole = 26,
    EEditMeshPolygonsToolActions__BridgeEdges = 27,
    EEditMeshPolygonsToolActions__ExtrudeEdges = 28,
    EEditMeshPolygonsToolActions__BevelEdges = 29,
    EEditMeshPolygonsToolActions__SimplifyAlongEdges = 30,
    EEditMeshPolygonsToolActions__PlanarProjectionUV = 31,
    EEditMeshPolygonsToolActions__SimplifyByGroups = 32,
    EEditMeshPolygonsToolActions__RegenerateExtraCorners = 33,
    EEditMeshPolygonsToolActions__PokeSingleFace = 34,
    EEditMeshPolygonsToolActions__SplitSingleEdge = 35,
    EEditMeshPolygonsToo__j__1__cD__U___p_______ = 36,
    EEditMeshPolygonsToolActions__CollapseSingleEdge = 37,
    EEditMeshPolygonsToolActions__BevelAuto = 38
};

enum ERevolvePropertiesCapFillMode : uint8_t
{
    ERevolvePropertiesCapFillMode__None = 0,
    ERevolvePropertiesCapFillMode__CenterFan = 1,
    ERevolvePropertiesCapFillMode__Delaunay = 2,
    ERevolvePropertiesCapFillMode__EarClipping = 3
};

enum ERevolvePropertiesPolygroupMode : uint8_t
{
    ERevolvePropertiesPolygroupMode__PerShape = 0,
    ERevolvePropertiesPolygroupMode__PerFace = 1,
    ERevolvePropertiesPolygroupMode__PerRevolveStep = 2,
    ERevolvePropertiesPolygroupMode__PerPathSegment = 3
};

enum EPolyEditExtrudeDirection : uint8_t
{
    EPolyEditExtrudeDirection__SelectionNormal = 0,
    EPolyEditExtrudeDirection__WorldX = 1,
    EPolyEditExtrudeDirection__WorldY = 2,
    EPolyEditExtrudeDirection__WorldZ = 3,
    EPolyEditExtrudeDirection__LocalX = 4,
    EPolyEditExtrudeDirection__LocalY = 5,
    EPolyEditExtrudeDirection__LocalZ = 6
};

enum EPolyEditPushPullModeOptions : uint8_t
{
    EPolyEditPushPullModeOptions__SelectedTriangleNormals = 0,
    EPolyEditPushPullModeOptions__SelectedTriangleNormalsEven = 1,
    EPolyEditPushPullModeOptions__SingleDirection = 3,
    EPolyEditPushPullModeOptions__VertexNormals = 2
};

enum EUVProjectionToolActions : uint8_t
{
    EUVProjectionToolActions__NoAction = 0,
    EUVProjectionToolActions__AutoFit = 1,
    EUVProjectionToolActions__AutoFitAlign = 2,
    EUVProjectionToolActions__Reset = 3
};

enum EUVProjectionToolInitializationMode : uint8_t
{
    EUVProjectionToolInitializationMode__Default = 0,
    EUVProjectionToolInitializationMode__UsePrevious = 1,
    EUVProjectionToolInitializationMode__AutoFit = 2,
    EUVProjectionToolInitializationMode__AutoFitAlign = 3
};

enum EVertexColorPaintBrushOpBlendMode : uint8_t
{
    EVertexColorPaintBrushOpBlendMode__Lerp = 0
};

enum EOffsetMeshSelectionInteractionMode : uint8_t
{
    EOffsetMeshSelectionInteractionMode__Fixed = 0
};

enum EOffsetMeshSelectionDirectionMode : uint8_t
{
    EOffsetMeshSelectionDirectionMode__VertexNormals = 0,
    EOffsetMeshSelectionDirectionMode__FaceNormals = 1,
    EOffsetMeshSelectionDirectionMode__ConstantWidth = 2
};

enum EPatternToolShape : uint8_t
{
    EPatternToolShape__Line = 0,
    EPatternToolShape__Grid = 1,
    EPatternToolShape__Circle = 2
};

enum EPatternToolSingleAxis : uint8_t
{
    EPatternToolSingleAxis__XAxis = 0,
    EPatternToolSingleAxis__YAxis = 1,
    EPatternToolSingleAxis__ZAxis = 2
};

enum EPatternToolSinglePlane : uint8_t
{
    EPatternToolSinglePlane__XYPlane = 0,
    EPatternToolSinglePlane__XZPlane = 1,
    EPatternToolSinglePlane__YZPlane = 2
};

enum EPatternToolAxisSpacingMode : uint8_t
{
    EPatternToolAxisSpacingMode__ByCount = 0,
    EPatternToolAxisSpacingMode__StepSize = 1,
    EPatternToolAxisSpacingMode__Packed = 2,
    EPatternToolAxisSpacingMode__EPatternToolAxisSpacing____ = 3
};

enum EMeshBoundaryConstraint : uint8_t
{
    EMeshBoundaryConstraint__Fixed = 7,
    EMeshBoundaryConstraint__Refine = 5,
    EMeshBoundaryConstraint__Free = 1
};

enum EGroupBoundaryConstraint : uint8_t
{
    EGroupBoundaryConstraint__Fixed = 7,
    EGroupBoundaryConstraint__Refine = 5,
    EGroupBoundaryConstraint__Free = 1,
    EGroupBoundaryConstraint__Ignore = 0
};

enum EMaterialBoundaryConstraint : uint8_t
{
    EMaterialBoundaryConstraint__Fixed = 7,
    EMaterialBoundaryConstraint__Refine = 5,
    EMaterialBoundaryConstraint__Free = 1,
    EMaterialBoundaryConstraint__Ignore = 0
};

enum ERevolveSplineSampleMode : uint8_t
{
    ERevolveSplineSampleMode__ControlPointsOnly = 0,
    ERevolveSplineSampleMode__PolyLineMaxError = 1,
    ERevolveSplineSampleMode__UniformSpacingAlongCurve = 2
};

enum EAlignObjectsAlignToOptions : uint8_t
{
    EAlignObjectsAlignToOptions__FirstSelected = 0,
    EAlignObjectsAlignToOptions__LastSelected = 1,
    EAlignObjectsAlignToOptions__Combined = 2
};

enum EAlignObjectsBoxPoint : uint8_t
{
    EAlignObjectsBoxPoint__Center = 0,
    EAlignObjectsBoxPoint__Bottom = 1,
    EAlignObjectsBoxPoint__Top = 2,
    EAlignObjectsBoxPoint__Left = 3,
    EAlignObjectsBoxPoint__Right = 4,
    EAlignObjectsBoxPoint__Front = 5,
    EAlignObjectsBoxPoint__Back = 6,
    EAlignObjectsBoxPoint__Min = 7,
    EAlignObjectsBoxPoint__Max = 8
};

enum EBakeMapType : uint16_t
{
    EBakeMapType__None = 0,
    EBakeMapType__TangentSpaceNormal = 1,
    EBakeMapType__ObjectSpaceNormal = 2,
    EBakeMapType__FaceNormal = 4,
    EBakeMapType__BentNormal = 8,
    EBakeMapType__Position = 16,
    EBakeMapType__Curvature = 32,
    EBakeMapType__AmbientOcclusion = 64,
    EBakeMapType__Texture = 128,
    EBakeMapType__MultiTexture = 256,
    EBakeMapType__VertexColor = 512,
    EBakeMapType__MaterialID = 1024,
    EBakeMapType__PolyGroupID = 2048,
    EBakeMapType__One = 4096,
    EBakeMapType__Zero = 8192,
    EBakeMapType__UVShell = 16384,
    EBakeMapType__All = 16383
};

enum EBakeScaleMethod : uint8_t
{
    EBakeScaleMethod__BakeFullScale = 0,
    EBakeScaleMethod__BakeNonuniformScale = 1,
    EBakeScaleMethod__DoNotBakeScale = 2
};

enum EConvertToPolygonsMode : uint8_t
{
    EConvertToPolygonsMode__FaceNormalDeviation = 0,
    EConvertToPolygonsMode__FindPolygons = 1,
    EConvertToPolygonsMode__FromUVIslands = 2,
    EConvertToPolygonsMode__FromNormalSeams = 3,
    EConvertToPolygonsMode__FromConnectedTris = 4,
    EConvertToPolygonsMode__FromFurthestPointSampling = 5,
    EConvertToPolygonsMode__CopyFromLayer = 6
};

enum ECubeGridToolFaceSelectionMode : uint8_t
{
    ECubeGridToolFaceSelectionMode__OutsideBasedOnNormal = 0,
    ECubeGridToolFaceSelectionMode__InsideBasedOnNormal = 1,
    ECubeGridToolFaceSelectionMode__OutsideBasedOnViewRay = 2,
    ECubeGridToolFaceSelectionMode__InsideBasedOnViewRay = 3
};

enum ECubeGridToolAction : uint8_t
{
    ECubeGridToolAction__NoAction = 0,
    ECubeGridToolAction__Push = 1,
    ECubeGridToolAction__Pull = 2,
    ECubeGridToolAction__Flip = 3,
    ECubeGridToolAction__SlideForward = 4,
    ECubeGridToolAction__SlideBack = 5,
    ECubeGridToolAction__DecreaseGridPower = 6,
    ECubeGridToolAction__IncreaseGridPower = 7,
    ECubeGridToolAction__CornerMode = 8,
    ECubeGridToolAction__ResetFromActor = 9,
    ECubeGridToolAction__AcceptAndStartNew = 10
};

enum EWeightScheme : uint8_t
{
    EWeightScheme__Uniform = 0,
    EWeightScheme__Umbrella = 1,
    EWeightScheme__Valence = 2,
    EWeightScheme__MeanValue = 3,
    EWeightScheme__Cotangent = 4,
    EWeightScheme__ClampedCotangent = 5,
    EWeightScheme__IDTCotangent = 6
};

enum EDisplaceMeshToolChannelType : uint8_t
{
    EDisplaceMeshToolChannelType__Red = 0,
    EDisplaceMeshToolChannelType__Green = 1,
    EDisplaceMeshToolChannelType__Blue = 2,
    EDisplaceMeshToolChannelType__Alpha = 3
};

enum EDrawPolyPathExtrudeDirection : uint8_t
{
    EDrawPolyPathExtrudeDirection__SelectionNormal = 0,
    EDrawPolyPathExtrudeDirection__WorldX = 1,
    EDrawPolyPathExtrudeDirection__WorldY = 2,
    EDrawPolyPathExtrudeDirection__WorldZ = 3,
    EDrawPolyPathExtrudeDirection__LocalX = 4,
    EDrawPolyPathExtrudeDirection__LocalY = 5,
    EDrawPolyPathExtrudeDirection__LocalZ = 6
};

enum EDynamicMeshSculptBrushType : uint8_t
{
    EDynamicMeshSculptBrushType__Move = 0,
    EDynamicMeshSculptBrushType__PullKelvin = 1,
    EDynamicMeshSculptBrushType__PullSharpKelvin = 2,
    EDynamicMeshSculptBrushType__Smooth = 3,
    EDynamicMeshSculptBrushType__Offset = 4,
    EDynamicMeshSculptBrushType__SculptView = 5,
    EDynamicMeshSculptBrushType__SculptMax = 6,
    EDynamicMeshSculptBrushType__Inflate = 7,
    EDynamicMeshSculptBrushType__ScaleKelvin = 8,
    EDynamicMeshSculptBrushType__Pinch = 9,
    EDynamicMeshSculptBrushType__TwistKelvin = 10,
    EDynamicMeshSculptBrushType__Flatten = 11,
    EDynamicMeshSculptBrushType__Plane = 12,
    EDynamicMeshSculptBrushType__PlaneViewAligned = 13,
    EDynamicMeshSculptBrushType__FixedPlane = 14,
    EDynamicMeshSculptBrushType__Resample = 15,
    EDynamicMeshSculptBrushType__LastValue = 16
};

enum EEditPivotToolActions : uint8_t
{
    EEditPivotToolActions__NoAction = 0,
    EEditPivotToolActions__Center = 1,
    EEditPivotToolActions__Bottom = 2,
    EEditPivotToolActions__Top = 3
};

enum ELatticeDeformerToolAction : uint8_t
{
    ELatticeDeformerToolAction__NoAction = 0,
    ELatticeDeformerToolAction__Constrain = 1,
    ELatticeDeformerToolAction__ClearConstraints = 2
};

enum EMeshAttributePaintToolActions : uint8_t
{
    EMeshAttributePaintToolActions__NoAction = 0
};

enum EMeshInspectorMaterialMode : uint8_t
{
    EMeshInspectorMaterialMode__Original = 0,
    EMeshInspectorMaterialMode__FlatShaded = 1,
    EMeshInspectorMaterialMode__Grey = 2,
    EMeshInspectorMaterialMode__Transparent = 3,
    EMeshInspectorMaterialMode__TangentNormal = 4,
    EMeshInspectorMaterialMode__VertexColor = 5,
    EMeshInspectorMaterialMode__GroupColor = 6,
    EMeshInspectorMaterialMode__Checkerboard = 7,
    EMeshInspectorMaterialMode__Override = 8
};

enum EMeshSelectionToolActions : uint8_t
{
    EMeshSelectionToolActions__NoAction = 0,
    EMeshSelectionToolActions__SelectAll = 1,
    EMeshSelectionToolActions__SelectAllByMaterial = 2,
    EMeshSelectionToolActions__ClearSelection = 3,
    EMeshSelectionToolActions__InvertSelection = 4,
    EMeshSelectionToolActions__GrowSelection = 5,
    EMeshSelectionToolActions__ShrinkSelection = 6,
    EMeshSelectionToolActions__ExpandToConnected = 7,
    EMeshSelectionToolActions__SelectLargestComponentByTriCount = 8,
    EMeshSelectionToolActions__SelectLargestComponentByArea = 9,
    EMeshSelectionToolActions__OptimizeSelection = 10,
    EMeshSelectionToolActions__DeleteSelected = 11,
    EMeshS__M__F_1____y__v___EB______l______L__A_ = 12,
    EMeshSelectionToolActions__SeparateSelected = 13,
    EMeshSelectionToolActions__DuplicateSelected = 14,
    EMeshSelectionToolActions__FlipSelected = 15,
    EMeshSelectionToolActions__CreateGroup = 16,
    EMeshSelectionToolActions__SmoothBoundary = 17,
    EMeshSelectionToolActions__CycleSelectionMode = 18,
    EMeshSelectionToolActions__CycleViewMode = 19
};

enum EMeshSelectionToolPrimaryMode : uint8_t
{
    EMeshSelectionToolPrimaryMode__Brush = 0,
    EMeshSelectionToolPrimaryMode__VolumetricBrush = 1,
    EMeshSelectionToolPrimaryMode__AngleFiltered = 2,
    EMeshSelectionToolPrimaryMode__Visible = 3,
    EMeshSelectionToolPrimaryMode__AllConnected = 4,
    EMeshSelectionToolPrimaryMode__AllInGroup = 5,
    EMeshSelectionToolPrimaryMode__ByMaterial = 6,
    EMeshSelectionToolPrimaryMode__ByMaterialAll = 7,
    EMeshSelectionToolPrimaryMode__ByUVIsland = 8,
    EMeshSelectionToolPrimaryMode__AllWithinAngle = 9
};

enum EMeshFacesColorMode : uint8_t
{
    EMeshFacesColorMode__None = 0,
    EMeshFacesColorMode__ByGroup = 1,
    EMeshFacesColorMode__ByMaterialID = 2,
    EMeshFacesColorMode__ByUVIsland = 3
};

enum EMeshVertexPaintColorChannel : uint8_t
{
    EMeshVertexPaintColorChannel__Red = 0,
    EMeshVertexPaintColorChannel__Green = 1,
    EMeshVertexPaintColorChannel__Blue = 2,
    EMeshVertexPaintColorChannel__Alpha = 3
};

enum EMeshVertexPaintToolUtilityOperations : uint8_t
{
    EMeshVertexPaintToolUtilityOperations__BlendAllSeams = 0,
    EMeshVertexPaintToolUtilityOperations__FillChannels = 1,
    EMeshVertexPaintToolUtilityOperations__InvertChannels = 2,
    EMeshVertexPaintToolUtilityOperations__CopyChannelToChannel = 3,
    EMeshVertexPaintToolUtilityOperations__SwapChannels = 4,
    EMeshVertexPaintToolUtilityOperations__CopyFromWeightMap = 5,
    EMeshVertexPaintToolUtilityOperations__CopyToOtherLODs = 6,
    EMeshVertexPaintToolUtilityOperations__CopyToSingleLOD = 7
};

enum EMeshVertexSculptBrushType : uint8_t
{
    EMeshVertexSculptBrushType__Move = 0,
    EMeshVertexSculptBrushType__PullKelvin = 1,
    EMeshVertexSculptBrushType__PullSharpKelvin = 2,
    EMeshVertexSculptBrushType__Smooth = 3,
    EMeshVertexSculptBrushType__SmoothFill = 4,
    EMeshVertexSculptBrushType__Offset = 5,
    EMeshVertexSculptBrushType__SculptView = 6,
    EMeshVertexSculptBrushType__SculptMax = 7,
    EMeshVertexSculptBrushType__Inflate = 8,
    EMeshVertexSculptBrushType__ScaleKelvin = 9,
    EMeshVertexSculptBrushType__Pinch = 10,
    EMeshVertexSculptBrushType__TwistKelvin = 11,
    EMeshVertexSculptBrushType__Flatten = 12,
    EMeshVertexSculptBrushType__Plane = 13,
    EMeshVertexSculptBrushType__PlaneViewAligned = 14,
    EMeshVertexSculptBrushType__FixedPlane = 15,
    EMeshVertexSculptBrushType__LastValue = 16
};

enum EMirrorToolAction : uint8_t
{
    EMirrorToolAction__NoAction = 0,
    EMirrorToolAction__ShiftToCenter = 1,
    EMirrorToolAction__Left = 2,
    EMirrorToolAction__Right = 3,
    EMirrorToolAction__Up = 4,
    EMirrorToolAction__Down = 5,
    EMirrorToolAction__Forward = 6,
    EMirrorToolAction__Backward = 7
};

enum ECollisionGeometryMode : uint8_t
{
    ECollisionGeometryMode__Default = 0,
    ECollisionGeometryMode__SimpleAndComplex = 1,
    ECollisionGeometryMode__UseSimpleAsComplex = 2,
    ECollisionGeometryMode__UseComplexAsSimple = 3
};

enum ESetCollisionGeometryInputMode : uint8_t
{
    ESetCollisionGeometryInputMode__CombineAll = 0,
    ESetCollisionGeometryInputMode__PerInputObject = 1,
    ESetCollisionGeometryInputMode__PerMeshComponent = 2,
    ESetCollisionGeometryInputMode__PerMeshGroup = 3
};

enum ESimpleCollisionEditorToolAction : uint8_t
{
    ESimpleCollisionEditorToolAction__NoAction = 0,
    ESimpleCollisionEditorToolAction__AddSphere = 1,
    ESimpleCollisionEditorToolAction__AddBox = 2,
    ESimpleCollisionEditorToolAction__AddCapsule = 3,
    ESimpleCollisionEditorToolAction__Duplicate = 4,
    ESimpleCollisionEditorToolAction__DeleteSelected = 5,
    ESimpleCollisionEditorToolAction__DeleteAll = 6
};

enum ESplitMeshesMethod : uint8_t
{
    ESplitMeshesMethod__ByMeshTopology = 0,
    ESplitMeshesMethod__ByVertexOverlap = 1,
    ESplitMeshesMethod__ByMaterialID = 2,
    ESplitMeshesMethod__ByPolyGroup = 3
};

enum ETransformMeshesTransformMode : uint8_t
{
    ETransformMeshesTransformMode__SharedGizmo = 0,
    ETransformMeshesTransformMode__SharedGizmoLocal = 1,
    ETransformMeshesTransformMode__PerObjectGizmo = 2,
    ETransformMeshesTransformMode__LastValue = 3
};

enum ETransformMeshesSnapDragRotationMode : uint8_t
{
    ETransformMeshesSnapDragRotationMode__Ignore = 0,
    ETransformMeshesSnapDragRotationMode__Align = 1,
    ETransformMeshesSnapDragRotationMode__AlignFlipped = 2,
    ETransformMeshesSnapDragRotationMode__LastValue = 3
};

enum ERedirectorTileDisplayMode : uint8_t
{
    ERedirectorTileDisplayMode__DisplaySprayTexture = 0,
    ERedirectorTileDisplayMode__ChangeOpacity = 1,
    ERedirectorTileDisplayMode__SwitchTextures = 2
};

enum ESyncAnimBeatTo : uint8_t
{
    ESyncAnimBeatTo__None = 0,
    ESyncAnimBeatTo__Now = 1,
    ESyncAnimBeatTo__PrevBeat = 2,
    ESyncAnimBeatTo__Num = 3
};

enum EBeatSyncAnimNodeLogging : uint8_t
{
    EBeatSyncAnimNodeLogging__Enabled = 0,
    EBeatSyncAnimNodeLogging__Disabled = 1,
    EBeatSyncAnimNodeLogging__Default = 2
};

enum EGotBeatAndTimeFrom : uint8_t
{
    EGotBeatAndTimeFrom__Invalid = 0,
    EGotBeatAndTimeFrom__None = 1,
    EGotBeatAndTimeFrom__PreviewBPM = 2,
    EGotBeatAndTimeFrom__MusicClock = 3
};

enum EUserEmoteBeatSyncingPermission : uint8_t
{
    EUserEmoteBeatSyncingPermission__Invalid = 0,
    EUserEmoteBeatSyncingPermission__Allowed = 1,
    EUserEmoteBeatSyncingPermission__Blocked = 2
};

enum ESparksCameraConfigType : uint8_t
{
    ESparksCameraConfigType__Main = 0,
    ESparksCameraConfigType__QA = 1,
    ESparksCameraConfigType__Perf = 2,
    ESparksCameraConfigType__Custom = 3
};

enum ESparksCameraLogType : uint8_t
{
    ESparksCameraLogType__ShotGenerator = 0,
    ESparksCameraLogType__ShotName = 1,
    ESparksCameraLogType__SectionName = 2,
    ESparksCameraLogType__Unknown = 3
};

enum ESparksFilterResult : uint8_t
{
    ESparksFilterResult__Match = 0,
    ESparksFilterResult__FailedRequired = 1,
    ESparksFilterResult__FailedExcluded = 2
};

enum ESparksSectionGeneratorResult : uint8_t
{
    ESparksSectionGeneratorResult__Success = 0,
    ESparksSectionGeneratorResult__SuccessTooShort = 1,
    ESparksSectionGeneratorResult__SuccessTooLong = 2,
    ESparksSectionGeneratorResult__Failed = 3
};

enum ESparksCameraShotSource : uint8_t
{
    ESparksCameraShotSource__Dynamic = 0,
    ESparksCameraShotSource__Scripted = 1,
    ESparksCameraShotSource__Intermission = 2,
    ESparksCameraShotSource__Unknown = 3
};

enum ESparksAnimatableState : uint8_t
{
    ESparksAnimatableState__None = 0,
    ESparksAnimatableState__AnimatableWithoutBeat = 1,
    ESparksAnimatableState__Animatable = 2,
    ESparksAnimatableState__AnimatableAndPlayable = 3,
    ESparksA______A____UG____J_____v__B__T_5j____D____ = 4
};

enum EHarmonixAudioAnalysisType : uint8_t
{
    EHarmonixAudioAnalysisType__FFT = 0,
    EHarmonixAudioAnalysisType__Arbitrary = 1,
    EHarmonixAudioAnalysisType__Count = 2
};

enum EHarmonixTextureFilterMode : uint8_t
{
    EHarmonixTextureFilterMode__Point = 0,
    EHarmonixTextureFilterMode__Linear = 1,
    EHarmonixTextureFilterMode__Count = 2,
    EHarmonixTextureFilterMode__Invalid = 3
};

enum ESparksStreamerStatus : uint8_t
{
    ESparksStreamerStatus__Idle = 0,
    ESparksStreamerStatus__DownloadingMidi = 1,
    ESparksStreamerStatus__Preparing = 2,
    ESparksStreamerStatus__Opening = 3,
    ESparksStreamerStatus__Ready = 4,
    ESparksStreamerStatus__Streaming = 5,
    ESparksStreamerStatus__Errored = 6
};

enum ACLRotationFormat : uint8_t
{
    ACLRF_Quat = 0,
    ACLRF_QuatDropW = 1,
    ACLRF_QuatDropW_Variable = 2
};

enum ACLVisualFidelity : uint8_t
{
    ACLVisualFidelity__Highest = 0,
    ACLVisualFidelity__Medium = 1,
    ACLVisualFidelity__Lowest = 2
};

enum ACLVisualFidelityChangeResult : uint8_t
{
    ACLVisualFidelityChangeResult__Dispatched = 0,
    ACLVisualFidelityChangeResult__Completed = 1,
    ACLVisualFidelityChangeResult__Failed = 2
};

enum EJamSongDownloadResult : uint8_t
{
    EJamSongDownloadResult__Failed = 0,
    EJamSongDownloadResult__Success = 1,
    EJamSongDownloadResult__SuccessCached = 2
};

enum EFMJamSongCatalogSortMethod : uint8_t
{
    EFMJamSongCatalogSortMethod__Artist = 0,
    EFMJamSongCatalogSortMethod__Title = 1,
    EFMJamSongCatalogSortMethod__Year = 2,
    EFMJamSongCatalogSortMethod__Num = 3
};

enum EFMJamSongCatalogSortDirection : uint8_t
{
    EFMJamSongCatalogSortDirection__Ascending = 0,
    EFMJamSongCatalogSortDirection__Descending = 1,
    EFMJamSongCatalogSortDirection__Num = 2
};

enum EPilgrimAccumulateStarsMessageType : uint8_t
{
    EPilgrimAccumulateStarsMessageType__BandStars = 0,
    EPilgrimAccumulateStarsMessageType__SoloStars = 1,
    EPilgrimAccumulateStarsMessageType__Count = 2
};

enum EPilgrimAccumulateStarTypes : uint8_t
{
    EPilgrimAccumulateStarTypes__None = 0,
    EPilgrimAccumulateStarTypes__Regular = 1,
    EPilgrimAccumulateStarTypes__Golden = 2
};

enum EPilgrimNoteEventMessageIncrementType : uint8_t
{
    EPilgrimNoteEventMessageIncrementType__ByTime = 0,
    EPilgrimNoteEventMessageIncrementType__ByValue = 1,
    EPilgrimNoteEventMessageIncrementType__Count = 2
};

enum EPilgrimScoreEventMessageType : uint8_t
{
    EPilgrimScoreEventMessageType__BandScore = 0,
    EPilgrimScoreEventMessageType__SoloScore = 1,
    EPilgrimScoreEventMessageType__Count = 2,
    EPilgrimScoreEventMessageType__EPi_6______________0_3___h_fqdu_k = 3
};

enum EPilgrimScoreEventMessageIncrementType : uint8_t
{
    EPilgrimScoreEventMessageIncrementType__ByScore = 0,
    EPilgrimScoreEventMessageIncrementType__ByStars = 1,
    EPilgrimScoreEventMessageIncrementType__ByValue = 2,
    EPilgrimScoreEventMessageIncrementType__Count = 3
};

enum EComboType : uint8_t
{
    EComboType__None = 0,
    EComboType__Full = 1,
    EComboType__Perfect = 2
};

enum EGiftingPricePresentationMode : uint8_t
{
    EGiftingPricePresentationMode__MtxCurrency = 0,
    EGiftingPricePresentationMode__RealMoney = 1,
    EGiftingPricePresentationMode__Hidden = 2
};

enum ERecipientPresentationMode : uint8_t
{
    ERecipientPresentationMode__Loading = 0,
    ERecipientPresentationMode__GiftPrice = 1,
    ERecipientPresentationMode__AlreadyOwned = 2,
    ERecipientPresentationMode__Unavailable = 3
};

enum EJunoCraftingCategoryFilteringUIEntryType : uint8_t
{
    EJunoCraftingCategoryFilteringUIEntryType__Unknown = 0,
    EJunoCraftingCategoryFilteringUIEntryType__Tab = 1,
    EJunoCraftingCategoryFilteringUIEntryType__Header = 2,
    EJunoCraftingCategoryFilteringUIEntryType__Filter = 3
};

enum EJunoRecipeSortType : uint8_t
{
    EJunoRecipeSortType__BySet = 0,
    EJunoRecipeSortType__ByName = 1,
    EJunoRecipeSortType__BySortPriority = 2,
    EJunoRecipeSortType__MAX_None = 3
};

enum EJunoPlayerCardStatus : uint8_t
{
    EJunoPlayerCardStatus__InWorld = 0,
    EJunoPlayerCardStatus__NotInWorld = 1,
    EJunoPlayerCardStatus__Count = 2
};

enum EMatchmakingErrorType : uint8_t
{
    EMatchmakingErrorType__NotEnoughWorldSpotsForParty = 0,
    EMatchmakingErrorType__NotAllPartyMembersHaveWorldAccess = 1,
    EMatchmakingErrorType__LookingForPartyIsEnabled = 2,
    EMat__________x_h9S__wpq5B_ = 3
};

enum EJunoContextMenuAction : uint8_t
{
    EJunoContextMenuAction__None = 0,
    EJunoContextMenuAction__Swap = 1,
    EJunoContextMenuAction__Drop = 2,
    EJunoContextMenuAction__Craft = 3,
    EJunoContextMenuAction__Equip = 4,
    EJunoContextMenuAction__Unequip = 5,
    EJunoContextMenuAction__Split = 6,
    EJunoContextMenuAction__DepositStack = 7,
    EJunoContextMenuAction__Deposit = 8,
    EJunoContextMenuAction__TakeStack = 9,
    EJunoContextMenuAction__Take = 10,
    EJunoContextMenuAction__MoveToInventory = 11,
    EJunoContextMenuAction__MoveToMainHand = 12,
    EJunoContextMenuAction__MoveToOffHand = 13,
    EJunoContextMenuAction__SmartTransfer = 14,
    EJunoContextMenuAction__OpenInventory = 15,
    EJunoContextMenuAction__Spawn = 16,
    EJunoContextMenuAction__SpawnMultiple = 17,
    EJunoContextMenuAction__TrackRecipe = 18,
    EJunoContextMenuAction__UntrackRecipe = 19
};

enum EJunoContextMenuActionState : uint8_t
{
    EJunoContextMenuActionState__Shown = 0,
    EJunoContextMenuActionState__Disabled = 1,
    EJunoContextMenuActionState__Hidden = 2
};

enum EJunoWorldSanctionType : uint8_t
{
    EJunoWorldSanctionType__MultiplayerBan = 0,
    EJunoWorldSanctionType__CompleteBan = 1,
    EJunoWorldSanctionType__None = 2
};

enum EOptionalJunoFrontendExperienceFlowSteps : uint8_t
{
    EOptionalJunoFrontendExperienceFlowSteps__TryShowCinematicTrailer = 0
};

enum EMatchmakingJunoErrors : uint8_t
{
    EMatchmakingJunoErrors__YouMustSelectWorldFirst = 0,
    EMatchmakingJunoErrors__YouMustWaitForWorldToBeSelected = 1,
    EMatchmakingJunoErrors__WorldUnavailable = 2,
    EMatchmakingJunoErrors__Num = 3
};

enum EKoalaClipEventType : uint8_t
{
    EKoalaClipEventType__Manual = 0
};

enum EKoalaAvailability : uint8_t
{
    EKoalaAvailability__Pending = 0,
    EKoalaAvailability__NotAvailable = 1,
    EKoalaAvailability__Available = 2,
    EKoalaAvailability__COUNT = 3
};

enum EKoalaRecording : uint8_t
{
    EKoalaRecording__Pending = 0,
    EKoalaRecording__NotRecording = 1,
    EKoalaRecording__Recording = 2,
    EKoalaRecording__COUNT = 3
};

enum EKoalaConnectionStatus : uint8_t
{
    EKoalaConnectionStatus__Pending = 0,
    EKoalaConnectionStatus__NotConnected = 1,
    EKoalaConnectionStatus__Connected = 2,
    EKoalaConnectionStatus__COUNT = 3
};

enum EKoalaClipStatus : uint8_t
{
    EKoalaClipStatus__None = 0,
    EKoalaClipStatus__Creating = 1,
    EKoalaClipStatus__Uploading = 2,
    EKoalaClipStatus__Completed = 3,
    EKoalaClipStatus__Failed = 4,
    EKoalaClipStatus__COUNT = 5
};

enum EKoalaMockClipMode : uint8_t
{
    EKoalaMockClipMode__None = 0,
    EKoalaMockClipMode__ShortSuccess = 1,
    EKoalaMockClipMode__ShortFailure = 2,
    EKoalaMockClipMode__LongSuccess = 3,
    EKoalaMockClipMode__LongFailure = 4,
    EKoalaMockClipMode__COUNT = 5
};

enum EFortContentManagementState : uint8_t
{
    EFortContentManagementState__Locked = 0,
    EFortContentManagementState__Unlocked = 1,
    EFortContentManagementState__WaitingForResponse = 2
};

enum EPlayerBuiltWallType : uint8_t
{
    EPlayerBuiltWallType__Solid = 0,
    EPlayerBuiltWallType__Windows = 1,
    EPlayerBuiltWallType__WindowC = 2,
    EPlayerBuiltWallType__WindowSide = 3,
    EPlayerBuiltWallType__DoorC = 4,
    EPlayerBuiltWallType__DoorS = 5,
    EPlayerBuiltWallType__DoorSide = 6,
    EPlayerBuiltWallType__Archway = 7,
    EPlayerBuiltWallType__ArchwayLarge = 8,
    EPlayerBuiltWallType__ArchwayLargeSupport = 9,
    EPlayerBuiltWallType__EPlayerBuiltWallTy______ = 10
};

enum EPlayerBuiltWallMaterialType : uint8_t
{
    EPlayerBuiltWallMaterialType__Wood = 0,
    EPlayerBuiltWallMaterialType__Metal = 1,
    EPlayerBuiltWallMaterialType__Stone = 2
};

enum EClamberingType : uint8_t
{
    EClamberingType__Invalid = 0,
    EClamberingType__Ledge = 1,
    EClamberingType__Window = 2
};

enum EClamberingFailedReason : uint8_t
{
    EClamberingFailedReason__None = 0,
    EClamberingFailedReason__Unknown = 1,
    EClamberingFailedReason__DebugForced = 2,
    EClamberingFailedReason__OwnerDied = 3,
    EClamberingFailedReason__OwnerDBNO = 4,
    EClamberingFailedReason__OwnerLaunched = 5,
    EClamberingFailedReason__SynchedActionNotStarted = 6,
    EClamberingFailedReason__OwnerTeleported = 7,
    EClamberingFailedReason__Ledge_PlayerTooFar = 8,
    EClamberingFailedReason__Ledge_TargetLocationInvalid = 9,
    EClamberingFailedReason__Ledge_TargetActorInvalid = 10,
    EClamberingFailedReason__Ledge_TargetActorDestroyed = 11,
    EClamberingFailedReason__Ledge_BlockerEncountered = 12
};

enum EClamberingActivationMode : uint8_t
{
    EClamberingActivationMode__ClientPreference = 0,
    EClamberingActivationMode__ForceAutoClambering = 1,
    EClamberingActivationMode__ForceManualClambering = 2
};

enum EClamberingDebugTextAlign : uint8_t
{
    EClamberingDebugTextAlign__Left = 0,
    EClamberingDebugTextAlign__Right = 1,
    EClamberingDebugTextAlign__Center = 2
};

enum EBattlePassStatusBarTypeS33 : uint8_t
{
    EBattlePassStatusBarTypeS33__Hidden = 0,
    EBattlePassStatusBarTypeS33__Prerequisite = 1,
    EBattlePassStatusBarTypeS33__Delayed = 2,
    EBattlePassStatusBarTypeS33__Unclaimable = 3,
    EBattlePassStatusBarTypeS33__Claimable = 4,
    EBattlePassStatusBarTypeS33__Special = 5,
    EBattlePassStatusBarTypeS33__Owned = 6
};

enum EHoagieBoostState : uint8_t
{
    EHoagieBoostState__Unknown = 0,
    EHoagieBoostState__Ready = 1,
    EHoagieBoostState__Started = 2,
    EHoagieBoostState__Finished = 3,
    EHoagieBoostState__Failed = 4
};

enum EHoagieState : uint8_t
{
    EHoagieState__STARTUP = 0,
    EHoagieState__STARTUP_LIFT = 1,
    EHoagieState__FLIGHT = 2,
    EHoagieState__AUTO_LANDING = 3,
    EHoagieState__SPIN_CRASHING = 4,
    EHoagieState__CRASHING_NO_SPIN = 5,
    EHoagieState__CRASH_LANDED = 6,
    EHoagieState__LANDED = 7,
    EHoagieState__EXPLODING = 8,
    EHoagieState__NONE = 9
};

enum EStateDrivenStateID : uint8_t
{
    EStateDrivenStateID__Invalid = 0,
    EStateDrivenStateID__Success = 1,
    EStateDrivenStateID__Failure = 2,
    EStateDrivenStateID__State_A = 3,
    EStateDrivenStateID__State_B = 4,
    EStateDrivenStateID__State_C = 5,
    EStateDrivenStateID__State_D = 6,
    EStateDrivenStateID__State_E = 7,
    EStateDrivenStateID__State_F = 8,
    EStateDrivenStateID__State_G = 9,
    EStateDrivenStateID__State_H = 10,
    EStateDrivenStateID__State_I = 11,
    EStateDrivenStateID__State_J = 12
};

enum ERollModifierOperation : uint8_t
{
    ERollModifierOperation__Add = 0,
    ERollModifierOperation__Multiply = 1,
    ERollModifierOperation__Zero = 2
};

enum EWarEffortFundingStationType : uint8_t
{
    Final = 0,
    Tower = 1,
    Choice = 2
};

enum EPowerupHeatState : uint8_t
{
    EPowerupHeatState__Normal = 0,
    EPowerupHeatState__Superheated = 1,
    EPowerupHeatState__Overheated = 2
};

enum EFortMotorcycleAirTrickType : uint8_t
{
    EFortMotorcycleAirTrickType__None = 0,
    EFortMotorcycleAirTrickType__Default = 1,
    EFortMotorcycleAirTrickType__Left = 2,
    EFortMotorcycleAirTrickType__Right = 3
};

enum EFortMotorcycleWheelTraceMode : uint8_t
{
    EFortMotorcycleWheelTraceMode__None = 0,
    EFortMotorcycleWheelTraceMode__BoxSweep = 1,
    EFortMotorcycleWheelTraceMode__LineTrace = 2
};

enum EFortSawBladeSpinningDirection : uint8_t
{
    EFortSawBladeSpinningDirection__Clockwise = 0,
    EFortSawBladeSpinningDirection__Counterclockwise = 1,
    EFortSawBladeSpinningDirection__SnapToCustomDirections = 2
};

enum EFortKatanaPrimaryAttackVariation : uint8_t
{
    EFortKatanaPrimaryAttackVariation__OnGroundFirst = 0,
    EFortKatanaPrimaryAttackVariation__OnGroundSecond = 1,
    EFortKatanaPrimaryAttackVariation__InAir = 2
};

enum ETeamEliminatedKillerHandling : uint8_t
{
    ETeamEliminatedKillerHandling__Ignored = 0,
    ETeamEliminatedKillerHandling__Require = 1,
    ETeamEliminatedKillerHandling__Prohibited = 2
};

enum ETankAimingMode : uint8_t
{
    CameraRotationNoTrace = 0,
    CameraTraceFromPivotSocket = 1,
    CameraTraceFromDistanceScalar = 2
};

enum EBoostedJumpTrackingState : uint8_t
{
    EBoostedJumpTrackingState__None = 0,
    EBoostedJumpTrackingState__ActivelyTracking = 1,
    EBoostedJumpTrackingState__BoostedJumpWillBeSuccessful = 2
};

enum EBeanAudioCategories : uint8_t
{
    EBeanAudioCategories__NONE = 0,
    EBeanAudioCategories__SFX = 1,
    EBeanAudioCategories__VO = 2
};

enum EBeanAudioEventTypes : uint8_t
{
    EBeanAudioEventTypes__NONE = 0,
    EBeanAudioEventTypes__JumpStart = 1,
    EBeanAudioEventTypes__Emote = 2,
    EBeanAudioEventTypes__DiveStart = 3
};

enum EBeanCharKnockbackType : uint8_t
{
    EBeanCharKnockbackType__Additive = 0,
    EBeanCharKnockbackType__Impulse = 1,
    EBeanCharKnockbackType__Absolute = 2
};

enum EBeanImpactAnimType : uint8_t
{
    EBeanImpactAnimType__None = 0,
    EBeanImpactAnimType__Low = 1,
    EBeanImpactAnimType__Medium = 2,
    EBeanImpactAnimType__High = 3
};

enum EBeanCharMantleFailedReason : uint8_t
{
    EBeanCharMantleFailedReason__Non_ = 0,
    EBeanCharMantleFailedReason__CharacterIsGrounded = 1,
    EBeanCharMantleFailedReason__InvalidState = 2,
    EBeanCharMantleFailedReason__NoSpaceAboveWall = 3,
    EBeanCharMantleFailedReason__WallTopTooSlanted = 4,
    EBeanCharMantleFailedReason__CharacterTravelingTooFast = 5,
    EBeanCharMantleFailedReason__CouldNotFindWallTop = 6,
    EBeanCharMantleFailedReason__CouldNotFindWall = 7,
    EBeanCharMantleFailedReason__WallAngleTooHigh = 8,
    EBeanCharMantleFailedReason__CouldNotFindLedge = 9,
    EBeanCharMantleFailedReason__LedgeInclineTooHigh = 10,
    EBeanCharMantleFailedReason__NoSpaceToHang = 11,
    EBeanCharMantleFailedReason__UnacceptedComponentMobility = 12,
    EBeanCharMantleFailedReason__PlayerNotAlignedEnoughToWall = 13
};

enum EBeanCharTurn180State : uint8_t
{
    EBeanCharTurn180State__None = 0,
    EBeanCharTurn180State__Left = 1,
    EBeanCharTurn180State__Right = 2
};

enum EBeanDebugForceCorrectionMode : uint8_t
{
    EBeanDebugForceCorrectionMode__Disabled = 0,
    EBeanDebugForceCorrectionMode__Enabled = 1,
    EBeanDebugForceCorrectionMode__Once = 2
};

enum EBeanCharRemoteRagdollSimMode : uint8_t
{
    EBeanCharRemoteRagdollSimMode__Disabled = 0,
    EBeanCharRemoteRagdollSimMode__PendingEnable = 1,
    EBeanCharRemoteRagdollSimMode__Enabled = 2,
    EBeanCharRemoteRagdollSimMode__KeepEnabled = 3
};

enum EBeanCharStateID : uint8_t
{
    EBeanCharStateID__Null = 0,
    EBeanCharStateID__Grounded = 1,
    EBeanCharStateID__Jostle = 2,
    EBeanCharStateID__Emote = 3,
    EBeanCharStateID__Staggered = 4,
    EBeanCharStateID__Grab = 5,
    EBeanCharStateID__GrabStumble = 6,
    EBeanCharStateID__Falling = 7,
    EBeanCharStateID__Jump = 8,
    EBeanCharStateID__Dive = 9,
    EBeanCharStateID__Mantle = 10,
    EBeanCharStateID__Getup = 11,
    EBeanCharStateID__GetupRoll = 12,
    EBeanCharStateID__Roll = 13,
    EBeanCharStateID__SurfaceSwimming = 14,
    EBeanCharStateID__WaterJump = 15,
    EBeanCharStateID__Ragdoll = 16,
    EBeanCharStateID__Zipline = 17,
    EBeanCharStateID__Flying = 18,
    EBeanCharStateID__Count = 19
};

enum EBeanCharStateLayerID : uint8_t
{
    EBeanCharStateLayerID__Lower = 0,
    EBeanCharStateLayerID__Upper = 1,
    EBeanCharStateLayerID__Count = 2
};

enum EBeanCharStateLayerMask : uint8_t
{
    EBeanCharStateLayerMask__None = 0,
    EBeanCharStateLayerMask__Lower = 1,
    EBeanCharStateLayerMask__Upper = 2,
    EBeanCharStateLayerMask__All = 3
};

enum EBeanParticleVfxTypes : uint8_t
{
    EBeanParticleVl_N_Z8IM_N5Cj = 0,
    EBeanParticleVfxTypes__JumpStart = 1,
    EBeanParticleVfxTypes__ImpactSmall = 2,
    EBeanParticleVfxTypes__ImpactMedium = 3,
    EBeanParticleVfxTypes__ImpactLarge = 4,
    EBeanParticleVfxTypes__DiveStart = 5,
    EBeanParticleVfxTypes__GrabStart = 6,
    EBeanParticleVfxTypes__GrabBreak = 7
};

enum ETractorBeamState : uint8_t
{
    TBS_Inactive = 0,
    TBS_Charging = 1,
    TBS_Active = 2
};

enum ENevadaFlightStates : uint8_t
{
    ENevadaFlightStates__FLIGHT = 0,
    ENevadaFlightStates__CRASHING = 1,
    ENevadaFlightStates__CRASHED = 2,
    ENevadaFlightStates__REBOOTING = 3,
    ENevadaFlightStates__LANDING = 4,
    ENevadaFlightStates__LANDED = 5,
    ENevadaFlightStates__IDLE = 6,
    ENevadaFlightStates__NONE = 7
};

enum EGrindRailBoosterMode : uint8_t
{
    EGrindRailBoosterMode__SpeedUp = 0,
    EGrindRailBoosterMode__SlowDown = 1,
    EGrindRailBoosterMode__NoEffect = 2
};

enum EVolumeEnableOverlapBehavior : uint8_t
{
    EVolumeEnableOverlapBehavior__Never = 0,
    EVolumeEnableOverlapBehavior__Game = 1,
    EVolumeEnableOverlapBehavior__Always = 2
};

enum EAbandonedCampsiteSpawnType : uint8_t
{
    EAbandonedCampsiteSpawnType__None = 0,
    EAbandonedCampsiteSpawnType__PlacedInLevel = 1,
    EAbandonedCampsiteSpawnType__EnvironmentalQuery = 2,
    EAbandonedCampsiteSpawnType__FromPlayerProfile = 3,
    EAbandonedCampsiteSpawnType__Max = 4
};

enum MapConstraintsBehaviorType : uint8_t
{
    MapConstraintsBehaviorType__AuthoredSkeleton = 0,
    MapConstraintsBehaviorType__DefaultTransform = 1,
    MapConstraintsBehaviorType__None = 2
};

enum ESideScrollerJump : uint8_t
{
    ESideScrollerJump__Disabled = 0,
    ESideScrollerJump__Dedicated = 1,
    ESideScrollerJump__Movement = 2
};

enum ESideScrollerCrouch : uint8_t
{
    ESideScrollerCrouch__Disabled = 0,
    ESideScrollerCrouch__Dedicated = 1,
    ESideScrollerCrouch__Movement = 2
};

enum ECustomControlsFacingMode : uint8_t
{
    ECustomControlsFacingMode__Movement = 0,
    ECustomControlsFacingMode__TwinStick = 1,
    ECustomControlsFacingMode__Fixed = 2
};

enum EDelMarTrackPropPlacementSpread : uint8_t
{
    EDelMarTrackPropPlacementSpread__UseDistanceBetween = 0,
    EDelMarTrackPropPlacementSpread__UseNumberOfProps = 1,
    EDelMarTrackPropPlacementSpread__UseBothDi_______K__c____ = 2
};

enum EDelMarTrackSplinePointSnapMode : uint8_t
{
    EDelMarTrackSplinePointSnapMode__StartingPoint = 0,
    EDelMarTrackSplinePointSnapMode__EndingPoint = 1,
    EDelMarTrackSplinePointSnapMode__CustomPoint = 2
};

enum EDelMarTrackType : uint8_t
{
    EDelMarTrackType__Primary = 0,
    EDelMarTrackType__Secondary = 1,
    EDelMarTrackType__Cosmetic = 2
};

enum EDelMarVehicleDriftState : uint8_t
{
    EDelMarVehicleDriftState__NotDrifting = 0,
    EDelMarVehicleDriftState__Drifting = 1,
    EDelMarVehicleDriftState__InitialKick = 2,
    EDelMarVehicleDriftState__SwapKick = 3,
    EDelMarVehicleDriftState__ExitVelocity = 4,
    EDelMarVehicleDriftState__ExitForward = 5,
    EDelMarVehicleDriftState__ForcedDrift = 6
};

enum EDelMarSplineMovementType : uint8_t
{
    EDelMarSplineMovementType__OneShot = 0,
    EDelMarSplineMovementType__Repeat = 1,
    EDelMarSplineMovementType__PingPong = 2
};

enum EDelMarModifierStackingPolicy : uint8_t
{
    DMSP_Allow = 0,
    DMSP_DontAdd = 1,
    DMSP_ClearOthers = 2
};

enum EDelMarGlobalLeaderboardType : uint8_t
{
    EDelMarGlobalLeaderboardType__Top = 0,
    EDelMarGlobalLeaderboardType__Focused = 1,
    EDelMarGlobalLeaderboardType__Friend = 2
};

enum EDelMarJellyHazardProcessorInfo : uint8_t
{
    EDelMarJellyHazardProcessorInfo__None = 0,
    EDelMarJellyHazardProcessorInfo__WithoutJellyHazardHit = 1,
    EDelMarJellyHazardProcessorInfo__WithJellyHazardHit = 2
};

enum EDelMarDemolishedProcessorInfo : uint8_t
{
    EDelMarDemolishedProcessorInfo__None = 0,
    EDelMarDemolishedProcessorInfo__WithoutDemolish = 1,
    EDelMarDemolishedProcessorInfo__WithDemolish = 2
};

enum EDelMarPositionChangeInfo : uint8_t
{
    EDelMarPositionChangeInfo__None = 0,
    EDelMarPositionChangeInfo__PassPlayer = 1,
    EDelMarPositionChangeInfo__PassedByPlayer = 2
};

enum EDelMarPlaylistTypeInfo : uint8_t
{
    EDelMarPlaylistTypeInfo__Any = 0,
    EDelMarPlaylistTypeInfo__Casual = 1,
    EDelMarPlaylistTypeInfo__Ranked = 2
};

enum EDelMarPhysicsRate : uint8_t
{
    EDelMarPhysicsRate__ThirtyHz = 0,
    EDelMarPhysicsRate__SixtyHz = 1,
    EDelMarPhysicsRate__OneHundredTwentyHz = 2
};

enum EMixModifierTarget : uint8_t
{
    EMixModifierTarget__Volume = 0,
    EMixModifierTarget__Pitch = 1,
    EMixModifierTarget__LowpassFrequency = 2
};

enum EDelMarCheckpointMeshType : uint8_t
{
    EDelMarCheckpointMeshType__Default = 0,
    EDelMarCheckpointMeshType__StartLine = 1,
    EDelMarCheckpointMeshType__FinishLine = 2
};

enum EDelMarRaceSpawnMode : uint8_t
{
    EDelMarRaceSpawnMode__SpawnAtMostRecentSplinePoint = 0,
    EDelMarRaceSpawnMode__SpawnAtMostRecentCheckpoint = 1,
    EDelMarRaceSpawnMode__SpawnAtRaceStart = 2,
    EDelMarRaceSpawnMode__NoAutomaticRespawn = 3
};

enum EDelMarPostMatchFlows : uint8_t
{
    EDelMarPostMatchFlows__PlayNowFlow = 0,
    EDelMarPostMatchFlows__PlayTogetherFlow = 1,
    EDelMarPostMatchFlows__PlayTrackFlow = 2
};

enum EDelMarPostMatchState : uint8_t
{
    EDelMarPostMatchState__WaitingForLocalPlayers = 0,
    EDelMarPostMatchState__WaitingForParty = 1,
    EDelMarPostMatchState__WaitingForLobby = 2,
    EDelMarPostMatchState__StartingNextRace = 3,
    EDelMarPostMatchState__MatchmakingStarted = 4,
    EDelMarPostMatchState__MatchmakingSucceeded = 5,
    EDelMarPostMatchState__MatchmakingFailed = 6,
    EDelMarPostMatchState__MatchmakingCancelled = 7,
    EDelMarPostMatchState__Idle = 8,
    EDelMarPostMatchState__Failed = 9,
    EDelMarPostMatchState__Completed = 10,
    EDelMarPostMatchState__INVALID = 11
};

enum EDelMarVehicleBoosterFlags : uint16_t
{
    EDelMarVehicleBoosterFlags__None = 0,
    EDelMarVehicleBoosterFlags__Side = 2,
    EDelMarVehicleBoosterFlags__Down = 4,
    EDelMarVehicleBoosterFlags__Front = 8,
    EDelMarVehicleBoosterFlags__Back = 16,
    EDelMarVehicleBoosterFlags__Left = 32,
    EDelMarVehicleBoosterFlags__Right = 64,
    EDelMarVehicleBoosterFlags__All = 255
};

enum EDelMarWheelMirrorType : uint8_t
{
    EDelMarWheelMirrorType__Scale = 0,
    EDelMarWheelMirrorType__Rotate = 1,
    EDelMarWheelMirrorType__None = 2
};

enum EDelMarPreviewCameraType : uint8_t
{
    EDelMarPreviewCameraType__None = 0,
    EDelMarPreviewCameraType__ZoomIn = 1,
    EDelMarPreviewCameraType__ZoomOut = 2
};

enum EDelMarWheelAttachPoint : uint8_t
{
    EDelMarWheelAttachPoint__Spin = 0,
    EDelMarWheelAttachPoint__Pivot = 1,
    EDelMarWheelAttachPoint__Contact = 2
};

enum EWidgetTransitionerStatus : uint8_t
{
    EWidgetTransitionerStatus__Hidden = 0,
    EWidgetTransitionerStatus__AnimatingIn = 1,
    EWidgetTransitionerStatus__Shown = 2,
    EWidgetTransitionerStatus__AnimatingOut = 3
};

enum EDelMarRearAlertVerticalHint : uint8_t
{
    EDelMarRearAlertVerticalHint__Level = 0,
    EDelMarRearAlertVerticalHint__Up = 1,
    EDelMarRearAlertVerticalHint__Down = 2
};

enum EDelMarTouchActionButtonState : uint8_t
{
    EDelMarTouchActionButtonState__None = 0,
    EDelMarTouchActionButtonState__FullyDisabled = 1,
    EDelMarTouchActionButtonState__Disabled = 2,
    EDelMarTouchActionButtonState__Enabled = 3,
    EDelMarTouchActionButtonState__Ready = 4,
    EDelMarTouchActionButtonState__Pressed = 5,
    EDelMarTouchActionButtonState__Supercharged = 6
};

enum EDelMarTouchInputTrackingState : uint8_t
{
    EDelMarTouchInputTrackingState__NOT_TRACKING = 0,
    EDelMarTouchInputTrackingState__TRACKING_WITH_INJECTION = 1,
    EDelMarTouchInputTrackingState__TRACKING_WITHOUT_INJECTION = 2
};

enum EDelMarDriftSteerState : uint8_t
{
    EDelMarDriftSteerState__None = 0,
    EDelMarDriftSteerState__Controlled = 1,
    EDelMarDriftSteerState__DriftBoost = 2,
    EDelMarDriftSteerState__Uncontrolled = 3
};

enum EDelMarSpeedometerState : uint8_t
{
    EDelMarSpeedometerState__Normal = 0,
    EDelMarSpeedometerState__SlowingDown = 1,
    EDelMarSpeedometerState__BonusSpeed = 2
};

enum EWallJumpState : uint8_t
{
    EWallJumpState__Launching = 0,
    EWallJumpState__Falling = 1
};

enum EWallJumpInitiatorType : uint8_t
{
    EWallJumpInitiatorType__None = 0,
    EWallJumpInitiatorType__WallRunning_Default = 1,
    EWallJumpInitiatorType__WallRunning_Launch = 2,
    EWallJumpInitiatorType__WallStick_Default = 3,
    EWallJumpInitiatorType__WallStick_Upward = 4,
    EWallJumpInitiatorType__WallJump_Default = 5
};

enum EFortMovementMode_WallStickState : uint8_t
{
    EFortMovementMode_WallStickState__None = 0,
    EFortMovementMode_WallStickState__RunUp = 1,
    EFortMovementMode_WallStickState__PushFromWall = 2,
    EFortMovementMode_WallStickState__Falling = 3
};

enum EDeployableTurretState : uint8_t
{
    EDeployableTurretState__Collapsed = 0,
    EDeployableTurretState__Transforming = 1,
    EDeployableTurretState__Scanning = 2,
    EDeployableTurretState__Tracking = 3,
    EDeployableTurretState__Attacking = 4,
    EDeployableTurretState__Deactivated = 5,
    EDeployableTurretState__WindUp = 6,
    EDeployableTurretState__WindDown = 7
};

enum ENyxGlassState : uint8_t
{
    ENyxGlassState__Off = 0,
    ENyxGlassState__Swinging = 1,
    ENyxGlassState__AimingFromGround = 2,
    ENyxGlassState__Hovering = 3,
    ENyxGlassState__Attacking = 4,
    ENyxGlassState__Slashing = 5
};

enum ENyxGlassSlashSubstate : uint8_t
{
    ENyxGlassSlashSubstate__MovingToTarget = 0,
    ENyxGlassSlashSubstate__StoppedAtTarget = 1,
    ENyxGlassSlashSubstate__LeapingBack = 2
};

enum EFortEventModeEmoteToPlay : uint8_t
{
    EFortEventModeEmoteToPlay__Emote1 = 0,
    EFortEventModeEmoteToPlay__Emote2 = 1,
    EFortEventModeEmoteToPlay__Emote3 = 2,
    EFortEventModeEmoteToPlay__RandomEmote = 3,
    EFortEventModeEmoteToPlay__QuickEmotes = 4
};

enum EFortMovementMode_SlidingActivationType : uint8_t
{
    EFortMovementMode_SlidingActivationType__Instant = 0,
    EFortMovementMode_SlidingActivationType__Landing = 1,
    EFortMovementMode_SlidingActivationType__DelayedTag = 2
};

enum ERollLandingTrackingState : uint8_t
{
    ERollLandingTrackingState__None = 0,
    ERollLandingTrackingState__ActivelyTracking = 1,
    ERollLandingTrackingState__CanBeTriggered = 2
};

enum ERollLandingState : uint8_t
{
    ERollLandingState__WaitingToLand = 0,
    ERollLandingState__Rolling = 1,
    ERollLandingState__WaitToStartAnim = 2,
    ERollLandingState__PostRollingAnimDelay = 3,
    ERollLandingState__RequestToEnd = 4
};

enum EHurdleType : uint8_t
{
    EHurdleType__Invalid = 0,
    EHurdleType__HurdleOver = 1,
    EHurdleType__HurdleOnTop = 2
};

enum EHurdleState : uint8_t
{
    EHurdleState__Inactive = 0,
    EHurdleState__Targeting = 1,
    EHurdleState__HurdleOver = 2,
    EHurdleState__HurdleOn = 3
};

enum EWingedFlyingStatus : uint8_t
{
    EWingedFlyingStatus__Default = 0,
    EWingedFlyingStatus__Boosting = 1,
    EWingedFlyingStatus__Ascending = 2,
    EWingedFlyingStatus__Crashing = 4,
    EWingedFlyingStatus__DodgingLeft = 8,
    EWingedFlyingStatus__DodgingRight = 16,
    EWingedFlyingStatus__Charging = 32
};

enum EFortRandomSource : uint8_t
{
    EFortRandomSource__Instance = 0
};

enum EShallowWaterRenderState : uint8_t
{
    WaterComponent = 0,
    WaterComponentWithBakedSim = 1,
    LiveSim = 2,
    BakedSim = 3
};

enum EShallowWaterCollisionContextType : uint8_t
{
    EShallowWaterCollisionContextType__Pawn = 0,
    EShallowWaterCollisionContextType__Vehicle = 1,
    EShallowWaterCollisionContextType__Custom = 2
};

enum EHomerClipEventType : uint8_t
{
    EHomerClipEventType__Emote = 0,
    EHomerClipEventType__Elimination = 1,
    EHomerClipEventType__COUNT = 2
};

enum EItemizedPropSpawnerTargetingFailedReason : uint8_t
{
    EItemizedPropSpawnerTargetingFailedReason__None = 0,
    EItemizedPropSpawnerTargetingFailedReason__TooHigh = 1,
    EItemizedPropSpawnerTargetingFailedReason__TooClose = 2,
    EItemizedPropSpawnerTargetingFailedReason__Obstructed = 3,
    EItemizedPropSpawnerTargetingFailedReason__TargetNotWalkable = 4,
    EItemizedPropSpawnerTargetingFailedReason__TargetBlocksSpawn = 5,
    EItemizedPropSpawnerTargetingFailedReason__TooCloseForHeight = 6,
    EItemizedPropSpawnerTargetingFailedReason__InvalidIndestructible = 7,
    EItemizedPropSpawnerTargetingFailedReason__NoValidTargetsFound = 8,
    EItemizedPropSpawnerTargetingFailedReason__Unknown = 9
};

enum EItemizedPropSpawnerChunkLocation : uint8_t
{
    EItemizedPropSpawnerChunkLocation__Left = 0,
    EItemizedPropSpawnerChunkLocation__CenterLeft = 1,
    EItemizedPropSpawnerChunkLocation__Center = 2,
    EItemizedPropSpawnerChunkLocation__CenterRight = 3,
    EItemizedPropSpawnerChunkLocation__Right = 4
};

enum ELaserConnectionState : uint8_t
{
    ELaserConnectionState__Off = 0,
    ELaserConnectionState__TransitionOn = 1,
    ELaserConnectionState__On = 2,
    ELaserConnectionState__TransitionOff = 3
};

enum ESupplyDropRadioBalloonState : uint8_t
{
    ESupplyDropRadioBalloonState__Invalid = 0,
    ESupplyDropRadioBalloonState__Closed = 1,
    ESupplyDropRadioBalloonState__Opened = 2,
    ESupplyDropRadioBalloonState__Destroyed = 3
};

enum ETempestMovementMode : uint8_t
{
    ETempestMovementMode__EnvQuery = 0,
    ETempestMovementMode__Path = 1
};

enum EMatchObjectivesSelectorState : uint8_t
{
    EMatchObjectivesSelectorState__EMinimized = 0,
    EMatchObjectivesSelectorState__EOpen = 1,
    EMatchObjectivesSelectorState__EMinimizing = 2
};

enum EOptimusDefaultDeformerMode : uint8_t
{
    EOptimusDefaultDeformerMode__Never = 0,
    EOptimusDefaultDeformerMode__OptIn = 1,
    EOptimusDefaultDeformerMode__Always = 2
};

enum EOptimusPinMutability : uint8_t
{
    EOptimusPinMutability__Undefined = 0,
    EOptimusPinMutability__Immutable = 1,
    EOptimusPinMutability__Mutable = 2
};

enum EOptimusDeformerExecutionPhase : uint8_t
{
    EOptimusDeformerExecutionPhase__AfterDefaultDeformer = 0,
    EOptimusDeformerExecutionPhase__OverrideDefaultDeformer = 1,
    EOptimusDeformerExecutionPhase__BeforeDefaultDeformer = 2
};

enum EOptimusDiagnosticLevel : uint8_t
{
    EOptimusDiagnosticLevel__None = 0,
    EOptimusDiagnosticLevel__Info = 1,
    EOptimusDiagnosticLevel__Warning = 2,
    EOptimusDiagnosticLevel__Error = 3
};

enum EOptimusValueUsage : uint8_t
{
    EOptimusValueUsage__None = 0,
    EOptimusValueUsage__CPU = 1,
    EOptimusValueUsage__GPU = 2
};

enum EOptimusValueType : uint8_t
{
    EOptimusValueType__Invalid = 0,
    EOptimusValueType__Constant = 1,
    EOptimusValueType__Variable = 2
};

enum EOptimusSkinnedMeshExecDomain : uint8_t
{
    EOptimusSkinnedMeshExecDomain__None = 0,
    EOptimusSkinnedMeshExecDomain__Vertex = 1,
    EOptimusSkinnedMeshExecDomain__Triangle = 2
};

enum EOptimusTerminalType : uint8_t
{
    EOptimusTerminalType__Unknown = 0,
    EOptimusTerminalType__Entry = 1,
    EOptimusTerminalType__Return = 2
};

enum EOptimusDataDomainType : uint8_t
{
    EOptimusDataDomainType__Dimensional = 0,
    EOptimusDataDomainType__Expression = 1
};

enum EOptimusDataTypeUsageFlags : uint8_t
{
    EOptimusDataTypeUsageFlags__None = 0,
    EOptimusDataTypeUsageFlags__Resource = 1,
    EOptimusDataTypeUsageFlags__Variable = 2,
    EOptimusDataTypeUsageFlags__AnimAttributes = 4,
    EOptimusDataTypeUsageFlags__DataInterfaceOutput = 8,
    EOptimusDataTypeUsageFlags__PinType = 16,
    EOptimusDataTypeUsageFlags__PerBoneAnimAttribute = 32,
    EOptimusDataTypeUsageFlags__Property = 64
};

enum EOptimusDataTypeFlags : uint8_t
{
    EOptimusDataTypeFlags__None = 0,
    EOptimusDataTypeFlags__IsStructType = 1,
    EOptimusDataTypeFlags__ShowElements = 2
};

enum EOptimusDeformerStatus : uint8_t
{
    EOptimusDeformerStatus__Compiled = 0,
    EOptimusDeformerStatus__CompiledWithWarnings = 1,
    EOptimusDeformerStatus__Modified = 2,
    EOptimusDeformerStatus__HasErrors = 3
};

enum EOptimusExecutionDomainType : uint8_t
{
    EOptimusExecutionDomainType__DomainName = 0,
    EOptimusExecutionDomainType__Expression = 1
};

enum EOptimusNodeGraphType : uint8_t
{
    EOptimusNodeGraphType__Setup = 0,
    EOptimusNodeGraphType__Update = 1,
    EOptimusNodeGraphType__ExternalTrigger = 2,
    EOptimusNodeGraphType__Function = 3,
    EOptimusNodeGraphType__SubGraph = 4,
    EOptimusNodeGraphType__Transient = 5
};

enum EOptimusNodePinStorageType : uint8_t
{
    EOptimusNodePinStorageType__Value = 0,
    EOptimusNodePinStorageType__Resource = 1
};

enum EOptimusNodePinDirection : uint8_t
{
    EOptimusNodePinDirection__Unknown = 0,
    EOptimusNodePinDirection__Input = 1,
    EOptimusNodePinDirection__Output = 2
};

enum EMLDeformerMaskingMode : uint8_t
{
    EMLDeformerMaskingMode__Generated = 0,
    EMLDeformerMaskingMode__VertexAttribute = 1
};

enum EMLDeformerVizMode : uint8_t
{
    EMLDeformerVizMode__TrainingData = 0,
    EMLDeford________k____x_____ = 1
};

enum EMLDeformerHeatMapMode : uint8_t
{
    EMLDeformerHeatMapMode__Activations = 0,
    EMLDeformerHeatMapMode__GroundTruth = 1
};

enum EMLDeformerMaskChannel : uint8_t
{
    EMLDeformerMaskChannel__Disabled = 0,
    EMLDeformerMaskChannel__VertexColorRed = 1,
    EMLDeformerMaskChannel__VertexColorGreen = 2,
    EMLDeformerMaskChannel__VertexColorBlue = 3,
    EMLDeformerMaskChannel__VertexColorAlpha = 4,
    EMLDeformerMaskChannel__VertexAttribute = 5
};

enum ENeuralMorphMode : uint8_t
{
    ENeuralMorphMode__Local = 0,
    ENeuralMorphMode__Global = 1
};

enum ENeuralMorphMaskVizMode : uint8_t
{
    ENeuralMorphMaskVizMode__Off = 0,
    ENeuralMorphMaskVizMode__WhenInFocus = 1,
    ENeuralMorphMaskVizMode__Always = 2
};

enum PictureInPictureSourceType : uint8_t
{
    PictureInPictureSourceType__NONE = 0,
    PictureInPictureSourceType__URL = 1
};

enum PictureInPictureAuthState : uint8_t
{
    UNKNOWN = 0,
    NOT_AUTHORIZED = 1,
    AUTHORIZED = 2
};

enum PictureInPictureAuthType : uint8_t
{
    AUTH_NONE = 0,
    AUTH_USER_PASS = 1,
    AUTH_QR_CODE = 2
};

enum ERockBoostLogic : uint8_t
{
    ERockBoostLogic__Standard = 0,
    ERockBoostLogic__Recharge = 1,
    ERockBoostLogic__Infinite = 2
};

enum EDestroyActorsAndComponentsMutator_ComponentNameComparisonType : uint8_t
{
    EDestroyActorsAndComponentsMutator_ComponentNameComparisonType__NameEquals = 0,
    EDestroyActorsAndComponentsMutator_ComponentNameComparisonType__NameStartsWith = 1,
    EDestroyActorsAndComponentsMutator_ComponentNameComparisonType__NameContains = 2,
    EDestroyActorsAndComponentsMutator_ComponentNameComparisonType__AdditionalStatNameEquals = 3,
    EDestroyActorsAndComponentsMutator_ComponentNameComparisonType__AdditionalStatNameStartsWith = 4,
    EDestroyActorsAndComponentsMutator_ComponentNameComparisonType__AdditionalStatNameContains = 5
};

enum EFakeKillRelevancyPlayerKillStep : uint8_t
{
    EFakeKillRelevancyPlayerKillStep__Initiated = 0,
    EFakeKillRelevancyPlayerKillStep__BlueprintNotified = 1,
    EFakeKillRelevancyPlayerKillStep__VisualsPerformed = 2
};

enum EMutatorMovementMode : uint8_t
{
    EMutatorMovementMode__None = 0,
    EMutatorMovementMode__BuffetBubbles = 25,
    EMutatorMovementMode__BuffetBubblesIntro = 26,
    EMutatorMovementMode__BuffetFlying = 27,
    EMutatorMovementMode__BuffetFlyingRicochet = 28,
    EMutatorMovementMode__Rewind = 29
};

enum ESpecialEventGameUserSettingsResult : uint8_t
{
    ESpecialEventGameUserSettingsResult__Success = 0,
    ESpecialEventGameUserSettingsResult__Failure = 1
};

enum ESpecialEventPhaseState : uint8_t
{
    ESpecialEventPhaseState__Unregistered = 0,
    ESpecialEventPhaseState__Registered = 1,
    ESpecialEventPhaseState__Active = 2,
    ESpecialEventPhaseState__Deactivated = 3
};

enum ESpecialEventPhaseComponentNetModeType : uint8_t
{
    ESpecialEventPhaseComponentNetModeType__ClientControlled = 0,
    ESpecialEventPhaseComponentNetModeType__Client = 1,
    ESpecialEventPhaseComponentNetModeType__DedicatedServer = 2
};

enum ESpecialEventRewindComponentState : uint8_t
{
    ESpecialEventRewindComponentState__Stop = 0,
    ESpecialEventRewindComponentState__Record = 1,
    ESpecialEventRewindComponentState__Rewind = 2
};

enum ESplitStormProxyPhase : uint8_t
{
    ESplitStormProxyPhase__None = 0,
    ESplitStormProxyPhase__MovingToHold = 1,
    ESplitStormProxyPhase__MovingToEnd = 2
};

enum ECreativeMannequinAnalyticsInteractType : uint8_t
{
    ECreativeMannequinAnalyticsInteractType__Equip = 0,
    ECreativeMannequinAnalyticsInteractType__OpenStore = 1
};

enum ECreativeAudioPlayerTargetLocation : uint8_t
{
    ECreativeAudioPlayerTargetLocation__None = 0,
    ECreativeAudioPlayerTargetLocation__Device = 1,
    ECreativeAudioPlayerTargetLocation__LocalPlayer = 2,
    ECreativeAudioPlayerTargetLocation__RegisteredPlayers = 4,
    ECreativeAudioPlayerTargetLocation__InstigatingPlayer = 8,
    ECreativeAudioPlayerTargetLocation__All = 15
};

enum EAutoplayOptions : uint8_t
{
    EAutoplayOptions__None = 0,
    EAutoplayOptions__Create = 1,
    EAutoplayOptions__WaitingForPlayer = 2,
    EAutoplayOptions__Countdown = 4,
    EAutoplayOptions__Gameplay = 8,
    EAutoplayOptions__RoundEnd = 16,
    EAutoplayOptions__GameEnd = 32
};

enum ECinematicSequenceVisibility : uint8_t
{
    ECinematicSequenceVisibility__InstigatorOnly = 0,
    ECinematicSequenceVisibility__InstigatingTeam = 1,
    ECinematicSequenceVisibility__Everyone = 2
};

enum EClassSelectorDisplayMode : uint8_t
{
    EClassSelectorDisplayMode__ClassesOnly = 0,
    EClassSelectorDisplayMode__TeamsOnly = 1,
    EClassSelectorDisplayMode__TeamsAndClasses = 2
};

enum ECreativeModalBackActionBoundButtonOption : uint8_t
{
    ECreativeModalBackActionBoundButtonOption__None = 0,
    ECreativeModalBackActionBoundButtonOption__LastButton = 1,
    ECreativeModalBackActionBoundButtonOption__Button1 = 2,
    ECreativeModalBackActionBoundButtonOption__Button2 = 3,
    ECreativeModalBackActionBoundButtonOption__Button3 = 4,
    ECreativeModalBackActionBoundButtonOption__Button4 = 5,
    ECreativeModalBackActionBoundButtonOption__Button5 = 6,
    ECreativeModalBackActionBoundButtonOption__Button6 = 7
};

enum ECreativeModalDialogTimerOption : uint8_t
{
    ECreativeModalDialogTimerOption__None = 0,
    ECreativeModalDialogTimerOption__Countdown = 1
};

enum ECreativeModalDialogAlignmentOption : uint8_t
{
    ECreativeModalDialogAlignmentOption__TopLeft = 0,
    ECreativeModalDialogAlignmentOption__TopCenter = 1,
    ECreativeModalDialogAlignmentOption__TopRight = 2,
    ECreativeModalDialogAlignmentOption__MiddleLeft = 3,
    ECreativeModalDialogAlignmentOption__Centered = 4,
    ECreativeModalDialogAlignmentOption__MiddleRight = 5,
    ECreativeModalDialogAlignmentOption__BottomLeft = 6,
    ECreativeModalDialogAlignmentOption__BottomCenter = 7,
    ECreativeModalDialogAlignmentOption__BottomRight = 8,
    ECreativeModalDialogAlignmentOption__CenteredFull = 9,
    ECreativeModalDialogAlignmentOption__LeftTall = 10,
    ECreativeModalDialogAlignmentOption__CenteredTall = 11,
    ECreativeModalDialogAlignmentOption__RightTall = 12,
    ECreativeModalDialogAlignmentOption__TopWide = 13,
    ECreativeModalDialogAlignmentOption__CenteredWide = 14,
    ECreativeModalDialogAlignmentOption__BottomWide = 15
};

enum ECreativeModalDialogViewmodelResponse : uint8_t
{
    ECreativeModalDialogViewmodelResponse__None = 0,
    ECreativeModalDialogViewmodelResponse__Button1 = 1,
    ECreativeModalDialogViewmodelResponse__Button2 = 2,
    ECreativeModalDialogViewmodelResponse__Button3 = 3,
    ECreativeModalDialogViewmodelResponse__Button4 = 4,
    ECreativeModalDialogViewmodelResponse__Button5 = 5,
    ECreativeModalDialogViewmodelResponse__Button6 = 6
};

enum EDanceBeatSyncMode : uint8_t
{
    EDanceBeatSyncMode__Off = 0,
    EDanceBeatSyncMode__Tempo = 1,
    EDanceBeatSyncMode__Music = 2
};

enum EFabricUserOptionType : uint8_t
{
    EFabricUserOptionType__Boolean = 0,
    EFabricUserOptionType__Integer = 1,
    EFabricUserOptionType__Float = 2,
    EFabricUserOptionType__String = 3,
    EFabricUserOptionType__Enum = 4,
    EFabricUserOptionType__None = 5
};

enum EFabricUserOptionConversionType : uint8_t
{
    EFabricUserOptionConversionType__Linear = 0,
    EFabricUserOptionConversionType__Exponential = 1,
    EFabricUserOptionConversionType__Lookup = 2
};

enum EFabricContinuousInteractionDirection : uint8_t
{
    EFabricContinuousInteractionDirection__Vertical = 0,
    EFabricContinuousInteractionDirection__Horizontal = 1
};

enum EFabricInteractionToolStates : uint8_t
{
    EFabricInteractionToolStates__Equipped = 0,
    EFabricInteractionToolStates__HoveredControl = 1,
    EFabricInteractionToolStates__HoveredValidCablePort = 2,
    EFabricInteractionToolStates__HoveredInvalid = 3,
    EFabricInteractionToolStates__ContinuousSelected = 4,
    EFabricInteractionToolStates__MomentarySelected = 5,
    EFabricInteractionToolStates__CableSelected = 6,
    EFabricInteractionToolStates__None = 7
};

enum EFabricMetasoundPlayState : uint8_t
{
    EFabricMetasoundPlayState__Playing = 0,
    EFabricMetasoundPlayState__Rebuilding = 1,
    EFabricMetasoundPlayState__Paused = 2,
    EFabricMetasoundPlayState__Stopped = 3
};

enum EFabricMetasoundClock : uint8_t
{
    EFabricMetasoundClock__Metronome = 0,
    EFabricMetasoundClock__MidiTempoMap = 1
};

enum EFabricNoteStyle : uint8_t
{
    EFabricNoteStyle__Straight = 0,
    EFabricNoteStyle__Triplet = 1,
    EFabricNoteStyle__Dotted = 2
};

enum EFabricMetasoundMusicEventPriority : uint8_t
{
    EFabricMetasoundMusicEventPriority__AboveEmotes = 0,
    EFabricMetasoundMusicEventPriority__BelowEmotes = 1
};

enum EFabricFloatProviderType : uint8_t
{
    EFabricFloatProviderType__Continuous = 0,
    EFabricFloatProviderType__Instantaneous = 1
};

enum EFabricAnalyticsSongEndReason : uint8_t
{
    EFabricAnalyticsSongEndReason__SongFinished = 0,
    EFabricAnalyticsSongEndReason__SongRestarted = 1,
    EFabricAnalyticsSongEndReason__SongStopped = 2,
    EFabricAnalyticsSongEndReason__PlayerLeft = 3,
    EFabricAnalyticsSongEndReason__ListeningModeParameterChanged = 4,
    EFabricAnalyticsSongEndReason__AudibleParameterChanged = 5
};

enum EFabricAnalyticsSongAccessScope : uint8_t
{
    EFabricAnalyticsSongAccessScope__None = 0,
    EFabricAnalyticsSongAccessScope__Player = 1,
    EFabricAnalyticsSongAccessScope__Party = 2,
    EFabricAnalyticsSongAccessScope__All = 3
};

enum EFabricAnalyticsUEFNMode : uint8_t
{
    EFabricAnalyticsUEFNMode__Play = 0,
    EFabricAnalyticsUEFNMode__Create = 1,
    EFabricAnalyticsUEFNMode__Invalid = 2
};

enum EFabricAnalyticsListeningMode : uint8_t
{
    EFabricAnalyticsListeningMode__Unknown = 0,
    EFabricAnalyticsListeningMode__MusicalGameplay = 1,
    EFabricAnalyticsListeningMode__PassiveListening = 2
};

enum EFabricWaveSyncType : uint8_t
{
    EFabricWaveSyncType__Free = 0,
    EFabricWaveSyncType__BeatSync = 1
};

enum EFabricValueSetterTransitionTiming : uint8_t
{
    Immediate = 0,
    NextBeat = 1,
    NextBar = 2,
    NextPhrase = 3
};

enum EFabricMetasoundPlayStrategy : uint8_t
{
    EFabricMetasoundPlayStrategy__Delayed = 0,
    EFabricMetasoundPlayStrategy__Instant = 1
};

enum EFabricMetasoundPlayPriority : uint8_t
{
    EFabricMetasoundPlayPriority__Normal = 0,
    EFabricMetasoundPlayPriority__High = 1,
    EFabricMetasoundPlayPriority__Highest = 2,
    EFabricMetasoundPlayPriority__EFabricMetasoundPlayd4_q______f_ = 3
};

enum EJamFabricSyncType : uint8_t
{
    EJamFabricSyncType__Disconnected = 0,
    EJamFabricSyncType__FabricControlsJam = 1,
    EJamFabricSyncType__Bidirectional = 2
};

enum EFabricMetasoundUtilityLoadedBroadcastBy : uint8_t
{
    EFabricMetasoundUtilityLoadedBroadcastBy__Never = 0,
    EFabricMetasoundUtilityLoadedBroadcastBy__UtilityPatchAsyncLoad = 1,
    EFabricMetasoundUtilityLoadedBroadcastBy__LiveUpdateGraphInit = 2,
    EFabricMetasoundUtilityLoadedBroadcastBy__AddMusicProviderPatch = 3,
    EFabricMetasoundUtilityLoadedBroadcastBy__AddTempoClockProviderPatch = 4,
    EFabricMetasoundUtilityLoadedBroadcastBy__AddMetronomeClockPatch = 5,
    EFabricMetasoundUtilityLoadedBroadcastBy__AddHarmonixTransportPatch = 6
};

enum EFabricMetaSoundPinDirection : uint8_t
{
    EFabricMetaSoundPinDirection__Input = 0,
    EFabricMetaSoundPinDirection__Output = 1
};

enum EFabricMetasoundInputType : uint8_t
{
    EFabricMetasoundInputType__ModulatedUserOption = 0,
    EFabricMetasoundInputType__NonModulatedUserOption = 1,
    EFabricMetasoundInputType__DirectInput = 2
};

enum EFabricMetaSoundPatchWrapperQuality : uint8_t
{
    EFabricMetaSoundPatchWrapperQuality__High = 0,
    EFabricMetaSoundPatchWrapperQuality__Low = 1
};

enum EFabricMidiPlayerLoopType : uint8_t
{
    EFabricMidiPlayerLoopType__None = 0,
    EFabricMidiPlayerLoopType__MidiLength = 1,
    EFabricMidiPlayerLoopType__SequenceLength = 2
};

enum ESequencerType : uint8_t
{
    ESequencerType__MultiTrack = 0,
    ESequencerType__SingleTrack = 1
};

enum EFabricIslandSettingsMemoryModeType : uint8_t
{
    EFabricIslandSettingsMemoryModeType__Cables = 0,
    EFabricIslandSettingsMemoryModeType__SequencerSquares = 1,
    EFabricIslandSettingsMemoryModeType__TopperVFX = 2
};

enum EDeviceCableActivatedState : uint8_t
{
    EDeviceCableActivatedState__Active = 0,
    EDeviceCableActivatedState__Dormant = 1
};

enum EDeviceCablePortAnimationSyncType : uint8_t
{
    EDeviceCablePortAnimationSyncType__Follower = 0,
    EDeviceCablePortAnimationSyncType__Authority = 1,
    EDeviceCablePortAnimationSyncType__Independent = 2
};

enum EDeviceCablePortFlowType : uint8_t
{
    EDeviceCablePortFlowType__Input = 0,
    EDeviceCablePortFlowType__Output = 1,
    EDeviceCablePortFlowType__An_ = 2
};

enum EDeviceCablePortSelectableState : uint8_t
{
    EDeviceCablePortSelectableState__Selectable = 0,
    EDeviceCablePortSelectableState__Unselectable = 1
};

enum EFMDeviceCablePortComponentAllowMultipleConnections : uint8_t
{
    EFMDeviceCablePortComponentAllowMultipleConnections__NoPreference = 0,
    EFMDeviceCablePortComponentAllowMultipleConnections__ForceMultiple = 1,
    EFMDeviceCablePortComponentAllowMultipleConnections__ForceSingle = 2
};

enum EDeviceCableLoadableState : uint8_t
{
    EDeviceCableLoadableState__Loadable = 0,
    EDeviceCableLoadableState__NotLoadable = 1
};

enum EFMDeviceCableAnimationQuality : uint8_t
{
    EFMDeviceCableAnimationQuality__High = 0,
    EFMDeviceCableAnimationQuality__Med = 1,
    EFMDeviceCableAnimationQuality__Low = 2
};

enum EFMDeviceCableWildcardOrderingState : uint8_t
{
    EFMDeviceCableWildcardOrderingState__Inactive = 0,
    EFMDeviceCableWildcardOrderingState__Pending = 1,
    EFMDeviceCableWildcardOrderingState__Active = 2
};

enum EDeviceCableInteractionType : uint8_t
{
    EDeviceCableInteractionType__Free = 0,
    EDeviceCableInteractionType__StaticOutput = 1
};

enum EFabricSongSyncTimingType : uint8_t
{
    EFabricSongSyncTimingType__Immediate = 0,
    EFabricSongSyncTimingType__NextBeat = 1,
    EFabricSongSyncTimingType__NextBar = 2
};

enum EFabricSongSyncPlaybackType : uint8_t
{
    EFabricSongSyncP7_rN__ = 0,
    EFabricSongSyncPlaybackType__FromCurrentTime = 1,
    EFabricSongSyncPlaybackType__FromStart = 2
};

enum EFabricSongSyncClockState : uint8_t
{
    EFabricSongSyncClockState__Playing = 0,
    EFabricSongSyncClockState__WillRestartInitiator = 1,
    EFabricSongSyncClockState__WillRestartFollower = 2
};

enum EFabricSongSyncSequenceState : uint8_t
{
    EFabricSongSyncSequenceState__UnInitialized = 0,
    EFabricSongSyncSequenceState__NoAssignedSequence = 1,
    EFabricSongSyncSequenceState__AssignedSequence = 2
};

enum EFabricMidiSourceType : uint8_t
{
    EFabricMidiSourceType__MidiFile = 0,
    EFabricMidiSourceType__JamTrackPlayer = 1
};

enum EPointLightDeviceModes : uint8_t
{
    EPointLightDeviceModes__Constant = 0,
    EPointLightDeviceModes__Flicker = 1,
    EPointLightDeviceModes__Wave = 2,
    EPointLightDeviceModes__ShortCircuit = 3,
    EPointLightDeviceModes__Party = 4,
    EPointLightDeviceModes__Windy = 5,
    EPointLightDeviceModes__Flash = 6
};

enum EPointLightDeviceLightType : uint8_t
{
    EPointLightDeviceLightType__Point = 0,
    EPointLightDeviceLightType__Spot = 1
};

enum EThrowingToyItemRemovedReason : uint8_t
{
    EThrowingToyItemRemovedReason__None = 0,
    EThrowingToyItemRemovedReason__ManuallyDropped = 1,
    EThrowingToyItemRemovedReason__DeviceForcedDropped = 2,
    EThrowingToyItemRemovedReason__DeviceForcedDeleted = 3
};

enum EFortStreamingVideoDeviceState : uint8_t
{
    EFortStreamingVideoDeviceState__No_Stream = 0,
    EFortStreamingVideoDeviceState__Controller = 1,
    EFortStreamingVideoDeviceState__Listener = 2
};

enum EFortStreamingVideoSelectionMode : uint8_t
{
    EFortStreamingVideoSelectionMode__Priority = 0,
    EFortStreamingVideoSelectionMode__Device_Override = 1,
    EFortStreamingVideoSelectionMode__Mirror = 2
};

enum EVideoScheduleDeviceRepeat : uint8_t
{
    EVideoScheduleDeviceRepeat__None = 0,
    EVideoScheduleDeviceRepeat__Hourly = 1,
    EVideoScheduleDeviceRepeat__Daily = 2
};

enum ECreativeDynamicUIAspectRatioType : uint8_t
{
    ECreativeDynamicUIAspectRatioType__None = 0,
    ECreativeDynamicUIAspectRatioType__AspectRatio_1 = 1,
    ECreativeDynamicUIAspectRatioType__AspectRatio_4 = 2,
    ECreativeDynamicUIAspectRatioType__AspectRatio_5 = 3,
    ECreativeDynamicUIAspectRatioType__AspectRatio_16 = 4,
    ECreativeDynamicUIAspectRatioType__AspectRatio_16 = 5
};

enum ECreativeDynamicUILayoutConstraintType : uint8_t
{
    ECreativeDynamicUILayoutConstraintType__None = 0,
    ECreativeDynamicUILayoutConstraintType__Alignment = 1
};

enum ECreativeDynamicUISizeModifierType : uint8_t
{
    ECreativeDynamicUISizeModifierType__None = 0,
    ECreativeDynamicUISizeModifierType__Fixed = 1,
    ECreativeDynamicUISizeModifierType__Scale = 2
};

enum EFortEmporiumLayoutVersion : uint8_t
{
    EFortEmporiumLayoutVersion__Original = 0,
    EFortEmporiumLayoutVersion__Version = 2
};

enum EFortEmporiumItemTagFilterMode : uint8_t
{
    EFortEmporiumItemTagFilterMode__MatchAny = 0,
    EFortEmporiumItemTagFilterMode__MatchAll = 1
};

enum EFortEmporiumItemPriceFilter : uint16_t
{
    EFortEmporiumItemPriceFilter__Invalid = 0,
    EFortEmporiumItemPriceFilter__Free = 1,
    EFortEmporiumItemPriceFilter__Premium = 2,
    EFortEmporiumItemPriceFilter__All = 255
};

enum EFortEmporiumItemFilterMode : uint8_t
{
    EFortEmporiumItemFilterMode__Price = 0,
    EFortEmporiumItemFilterMode__License = 1
};

enum EFortEmporiumItemSortMode : uint8_t
{
    EFortEmporiumItemSortMode__MCP = 0,
    EFortEmporiumItemSortMode__AtoZ = 1,
    EFortEmporiumItemSortMode__ZtoA = 2,
    EFortEmporiumItemSortMode__PriceLowToHigh = 3,
    EFortEmporiumItemSortMode__PriceHighToLow = 4,
    EFortEmporiumItemSortMode__SizeLowToHigh = 5,
    EFortEmporiumItemSortMode__SizeHighToLow = 6
};

enum EFortEmporiumItemLicense : uint16_t
{
    EFortEmporiumItemLicense__Invalid = 0,
    EFortEmporiumItemLicense__CC0 = 1,
    EFortEmporiumItemLicense__CC_BY = 2,
    EFortEmporiumItemLicense__CC_BY_SA = 4,
    EFor___4L_____G____G____________0_ = 8,
    EFortEmporiumItemLicense__CC_BY_NC_SA = 16,
    EFortEmporiumItemLicense__CC_BY_ND = 32,
    EFortEmporiumItemLicense__CC_BY_NC_ND = 64,
    EFortEmporiumItemLicense__Standard = 128,
    EFortEmporiumItemLicense__All = 255
};

enum EFNE_UIBlockInstantTransitionState : uint8_t
{
    EFNE_UIBlockInstantTransitionState__Invalid = 0,
    EFNE_UIBlockInstantTransitionState__InstantEnabled = 1,
    EFNE_UIBlockInstantTransitionState__InstantDisabled = 2,
    EFNE_UIBlockInstantTransitionState__InstantSelected = 3,
    EFNE_UIBlockInstantTransitionState__InstantDeselected = 4,
    EFNE_UIBlockInstantTransitionState__InstantLocked = 5,
    EFNE_UIBlockInstantTransitionState__InstantUnlocked = 6
};

enum EMetaHumanBodyType : uint8_t
{
    EMetaHumanBodyType__f_med_nrw = 0,
    EMetaHumanBodyType__f_med_ovw = 1,
    EMetaHumanBodyType__f_med_unw = 2,
    EMetaHumanBodyType__f_srt_nrw = 3,
    EMetaHumanBodyType__f_srt_ovw = 4,
    EMetaHumanBodyType__f_srt_unw = 5,
    EMetaHumanBodyType__f_tal_nrw = 6,
    EMetaHumanBodyType__f_tal_ovw = 7,
    EMetaHumanBodyType__f_tal_unw = 8,
    EMetaHumanBodyType__m_med_nrw = 9,
    EMetaHumanBodyType__m_med_ovw = 10,
    EMetaHumanBodyType__m_med_unw = 11,
    EMetaHumanBodyType__m_srt_nrw = 12,
    EMetaHumanBodyType__m_srt_ovw = 13,
    EMetaHumanBodyType__m_srt_unw = 14,
    EMetaHumanBodyType__m_tal_nrw = 15
};

enum EGroomBindingAssetBuildResult : uint8_t
{
    EGroomBindingAssetBuildResult__Succeeded = 0,
    EGroomBindingAssetBuildResult__Failed = 1
};

enum EGroomCacheImportType : uint8_t
{
    EGroomCacheImportType__None = 0,
    EGroomCacheImportType__Strands = 1,
    EGroomCacheImportType__Guides = 2,
    EGroomCacheImportType__All = 3
};

enum EHairCardsSourceType : uint8_t
{
    EHairCardsSourceType__Procedural = 0,
    EHairCardsSourceType__Imported = 1
};

enum EHairCardsGuideType : uint8_t
{
    EHairCardsGuideType__Generated = 0,
    EHairCardsGuideType__GuideBased = 1
};

enum EHairTextureLayout : uint8_t
{
    EHairTextureLayout__Layout0 = 0,
    EHairTextureLayout__Layout1 = 1,
    EHairTextureLayout__Layout2 = 2,
    EHairTextureLayout__Layout3 = 3
};

enum EHairInterpolationQuality : uint8_t
{
    EHairInterpolationQuality__Low = 0,
    EHairInterpolationQuality__Medium = 1,
    EHairInterpolationQuality__High = 2,
    EHairInterpolationQuality__Unknown = 3
};

enum EGroomGeometryType : uint8_t
{
    EGroomGeometryType__Strands = 0,
    EGroomGeometryType__Cards = 1,
    EGroomGeometryType__Meshes = 2
};

enum EGroomBindingType : uint8_t
{
    EGroomBindingType__NoneBinding = 0,
    EGroomBindingType__Rigid = 1,
    EGroomBindingType__Skinning = 2
};

enum EGroomOverrideType : uint8_t
{
    EGroomOverrideType__Auto = 0,
    EGroomOverrideType__Enable = 1,
    EGroomOverrideType__Disable = 2
};

enum EGroomGuideType : uint8_t
{
    EGroomGuideType__Imported = 0,
    EGroomGuideType__Generated = 1,
    EGroomGuideType__Rigged = 2
};

enum EGroomLODMode : uint8_t
{
    EGroomLODMode__Default = 0,
    EGroomLODMode__Manual = 1,
    EGroomLODMode__Auto = 2
};

enum EGroomNiagaraSolvers : uint8_t
{
    EGroomNiagaraSolvers__None = 0,
    EGroomNiagaraSolvers__CosseratRods = 2,
    EGroomNiagaraSolvers__AngularSprings = 4,
    EGroomNiagaraSolvers__CustomSolver = 8
};

enum EGroomInterpolationType : uint8_t
{
    EGroomInterpolationType__None = 0,
    EGroomInterpolationType__RigidTransform = 2,
    EGroomInterpolationType__OffsetTransform = 4,
    EGroomInterpolationType__SmoothTransform = 8
};

enum EGroomBindingMeshType : uint8_t
{
    EGroomBindingMeshType__SkeletalMesh = 0,
    EGroomBindingMeshType__GeometryCache = 1
};

enum EGroomBindingAsyncProperties : uint16_t
{
    EGroomBindingAsyncProperties__None = 0,
    EGroomBindingAsyncProperties__GroomBindingType = 1,
    EGroomBindingAsyncProperties__Groom = 2,
    EGroomBindingAsyncProperties__SourceSkeletalMesh = 4,
    EGroomBindingAsyncProperties__SourceMeshRequestedLOD = 8,
    EGroomBindingAsyncProperties__SourceMeshUsedLOD = 16,
    EGroomBindingAsyncProperties__TargetSkeletalMesh = 32,
    EGroomBindingAsyncProperties__TargetMeshRequestedMinLOD = 64,
    EGroomBindingAsyncProperties__TargetMeshUsedMinLOD = 128,
    EGroomBindingAsyncProperties__SourceGeometryCache = 256,
    EGroomBindingAsyncProperties__TargetGeometryCache = 512,
    EGroomBindingAsyncProperties__NumInterpolationPoints = 1024,
    EGroomBindingAsyncProperties__MatchingSection = 2048,
    EGroomBindingAsyncProperties__GroupInfos = 4096,
    EGroomBindingAsyncProperties__HairGroupResources = 8192,
    EGroomBindingAsyncProperties__HairGroupPlatformData = 16384,
    EGroomBindingAsyncProperties__All = -1
};

enum EGroomCacheAttributes : uint8_t
{
    EGroomCacheAttributes__None = 0,
    EGroomCacheAttributes__Position = 1,
    EGroomCacheAttributes__Width = 2,
    EGroomCacheAttributes__Color = 4,
    EGroomCacheAttributes__PositionWidth = 3,
    EGroomCacheAttributes__PositionColor = 5,
    EGroomCacheAttributes__WidthColor = 5,
    EGroomCa___jx____N________H__4_d_____rr__ = 7
};

enum EGroomCacheType : uint8_t
{
    EGroomCacheType__None = 0,
    EGroomCacheType__Strands = 1,
    EGroomCacheType__Guides = 2
};

enum EGroomCurveType : uint8_t
{
    EGroomCurveType__Cubic = 0,
    EGroomCurveType__Linear = 1,
    EGroomCurveType__VariableOrder = 2
};

enum EFollicleMaskChannel : uint8_t
{
    EFollicleMaskChannel__R = 0,
    EFollicleMaskChannel__G = 1,
    EFollicleMaskChannel__B = 2,
    EFollicleMaskChannel__A = 3
};

enum EStrandsTexturesTraceType : uint8_t
{
    EStrandsTexturesTraceType__TraceInside = 0,
    EStrandsTexturesTraceType__TraceOuside = 1,
    EStrandsTexturesTraceType__TraceBidirectional = 2
};

enum EStrandsTexturesMeshType : uint8_t
{
    EStrandsTexturesMeshType__Static = 0,
    EStrandsTexturesMeshType__Skeletal = 1
};

enum EGroomInterpolationQuality : uint8_t
{
    EGroomInterpolationQuality__Low = 0,
    EGroomInterpolationQuality__Medium = 1,
    EGroomInterpolationQuality__High = 2,
    EGroomInterpolationQuality__Unknown = 3
};

enum EGroomInterpolationWeight : uint8_t
{
    EGroomInterpolationWeight__Parametric = 0,
    EGroomInterpolationWeight__Root = 1,
    EGroomInterpolationWeight__Index = 2,
    EGroomInterpolationWeight__Unknown = 3
};

enum EOptimusGroomExecDomain : uint8_t
{
    EOptimusGroomExecDomain__None = 0,
    EOptimusGroomExecDomain__ControlPoint = 1,
    EOptimusGroomExecDomain__Curve = 2
};

enum EGender : uint8_t
{
    EGender__Male = 0,
    EGender__Female = 1,
    EGender__Other = 2
};

enum ETranslationUnit : uint8_t
{
    ETranslationUnit__CM = 0,
    ETranslationUnit__M = 1
};

enum ERotationUnit : uint8_t
{
    ERotationUnit__Degrees = 0,
    ERotationUnit__Radians = 1
};

enum ETranslationRepresentation : uint8_t
{
    ETranslationRepresentation__Vector = 0
};

enum ERotationRepresentation : uint8_t
{
    ERotationRepresentation__EulerAngles = 0,
    ERotationRepresentation__Quaternion = 1
};

enum EScaleRepresentation : uint8_t
{
    EScaleRepresentation__Vector = 0
};

enum EAutomaticRadius : uint8_t
{
    EAutomaticRadius__On = 0,
    EAutomaticRadius__Off = 1
};

enum ETwistAxis : uint8_t
{
    ETwistAxis__X = 0,
    ETwistAxis__Y = 1,
    ETwistAxis__Z = 2
};

enum ERigLogicTranslationType : uint8_t
{
    ERigLogicTranslationType__None = 0,
    ERigLogicTranslationType__Vector = 3
};

enum ERigLogicRotationType : uint8_t
{
    ERigLogicRotationType__None = 0,
    ERigLogicRotationType__EulerAngles = 3,
    ERigLogicRotationType__Quaternions = 4
};

enum ERigLogicScaleType : uint8_t
{
    ERigLogicScaleType__None = 0,
    ERigLogicScaleType__Vector = 3
};

enum ELodUpdateOption : uint8_t
{
    ELodUpdateOption__LOD0Only = 0,
    ELodUpdateOption__LOD1AndHigher = 1,
    ELodUpdateOption__All = 2
};

enum ELiquidRibbonDetachmentReason : uint8_t
{
    ELiquidRibbonDetachmentReason__NotDetached = 0,
    ELiquidRibbonDetachmentReason__ByDistance = 1,
    ELiquidRibbonDetachmentReason__ByAngle = 2
};

enum ECalibrationState : uint8_t
{
    ECalibrationState__TooFewSamples = 0,
    ECalibrationState__InputTooErratic = 1,
    ECalibrationState__TightResult = 2,
    ECalibrationState__LooseResult = 3
};

enum EPilgrimSongPlayMethod : uint8_t
{
    EPilgrimSongPlayMethod__Invalid = 0,
    EPilgrimSongPlayMethod__Streaming = 1,
    EPilgrimSongPlayMethod__LocalMetasounds = 2
};

enum EPilgrimTimedInputType : uint8_t
{
    EPilgrimTimedInputType__None = 0,
    EPilgrimTimedInputType__Lane = 1,
    EPilgrimTimedInputType__DeployOverdrive = 2,
    EPilgrimTimedInputType__Strum = 3,
    EPilgrimTimedInputType__Modulate = 4,
    EPilgrimTimedInputType__DrainOverdrive = 5,
    EPilgrimTimedInputType__OverdriveItemActivated = 6,
    EPilgrimTimedInputType__OverdriveItemGrantedNotActivated = 7
};

enum EPilgrimLeaderboardType : uint8_t
{
    EPilgrimLeaderboardType__SoloGuitar = 0,
    EPilgrimLeaderboardType__SoloBass = 1,
    EPilgrimLeaderboardType__SoloVocals = 2,
    EPilgrimLeaderboardType__SoloDrum = 3,
    EPilgrimLeaderboardType__BandDuo = 4,
    EPilgrimLeaderboardType__BandTrio = 5,
    EPilgrimLeaderboardType__BandQuad = 6,
    EPilgrimLeaderboardType__SoloPeripheralGuitar = 7,
    EPilgrimLeaderboardType__SoloPeripheralBass = 8,
    EPilgrimLeaderboardType__SoloPeripheralDrum = 9,
    EPilgrimLeaderboardType__Invalid = 10
};

enum EPilgrimPlayerFeedSortType : uint8_t
{
    EPilgrimPlayerFeedSortType__NewestScore = 0,
    EPilgrimPlayerFeedSortType__OldestScore = 1,
    EPilgrimPlayerFeedSortType__HighestScore = 2,
    EPilgrimPlayerFeedSortType__LowestScore = 3
};

enum EPilgrimPeripheralInputMode : uint8_t
{
    EPilgrimPeripheralInputMode__None = 0,
    EPilgrimPeripheralInputMode__Guitar = 1
};

enum EPilgrimCantAddSongReason : uint8_t
{
    EPilgrimCantAddSongReason__None = 0,
    EPilgrimCantAddSongReason__SetlistLocked = 1,
    EPilgrimCantAddSongReason__SongAlreadyAdded = 2,
    EPilgrimCantAddSongReason__PlayerHasAddedMaxSongs = 3,
    EPilgrimCantAddSongReason__InvalidSongShortName = 4,
    EPilgrimCantAddSongReason__MissingSong = 5,
    EPilgrimCantAddSongReason__SongNotAvailable = 6
};

enum EPilgrimPlayerHistoryScoreParam : uint8_t
{
    EPilgrimPlayerHistoryScoreParam__AllScores = 0,
    EPilgrimPlayerHistoryScoreParam__HigherScores = 1,
    EPilgrimPlayerHistoryScoreParam__LowerScores = 2
};

enum EPilgrimStateMachineMessage : uint8_t
{
    EPilgrimStateMachineMessage__None = 0,
    EPilgrimStateMachineMessage__Solo_PlayPreviousSong = 1,
    EPilgrimStateMachineMessage__Solo_PlayNextSong = 2,
    EPilgrimStateMachineMessage__Solo_LeaveStage = 3,
    EPilgrimStateMachineMessage__Multiplayer_LeaveStage = 4
};

enum EPilgrimAnalyticsSongEndReason : uint8_t
{
    EPilgrimAnalyticsSongEndReason__SongFinished = 0,
    EPilgrimAnalyticsSongEndReason__SongRestarted = 1,
    EPilgrimAnalyticsSongEndReason__PlayerDisconnected = 2
};

enum EPilgrimAnalyticsSongAccessScope : uint8_t
{
    EPilgrimAnalyticsSongAccessScope__None = 0,
    EPilgrimAnalyticsSongAccessScope__Player = 1,
    EPilgrimAnalyticsSongAccessScope__Party = 2,
    EPilgrimAnalyticsSongAccessScope__All = 3
};

enum EPilgrimAnalyticsResultsReturn : uint8_t
{
    EPilgrimAnalyticsResultsReturn__None = 0,
    EPilgrimAnalyticsResultsReturn__LeaveToLobby = 1,
    EPilgrimAnalyticsResultsIy_____6_9_____ = 2,
    EPilgrimAnalyticsResultsReturn__LeaveStage_Timer = 3
};

enum EPilgrimAutoCalibrationSampleFlatteningMode : uint8_t
{
    EPilgrimAutoCalibrationSampleFlatteningMode__None = -1,
    EPilgrimAutoCalibrationSampleFlatteningMode__Logarithm = 1,
    EPilgrimAutoCalibrationSampleFlatteningMode__Normalize = 2
};

enum EPresetLanesDifficulty : uint8_t
{
    EPresetLanesDifficulty__General = 4,
    EPresetLanesDifficulty__Expert = 5
};

enum EPilgrimEvaluatorRuleSet : uint8_t
{
    standard = 0,
    StrummedGuitar = 1
};

enum EPilgrimInputCategory : uint8_t
{
    EPilgrimInputCategory__Lane = 0,
    EPilgrimInputCategory__Overdrive = 1,
    EPilgrimInputCategory__Strum = 2
};

enum EPilgrimGemInputState : uint8_t
{
    EPilgrimGemInputState__GemHit = 0,
    EPilgrimGemInputState__UserSwingAndMiss = 1,
    EPilgrimGemInputState__GemPassed = 2,
    EPilgrimGemInputState__NumGemInputStates = 3
};

enum EPilgrimPersonalBestType : uint8_t
{
    EPilgrimPersonalBestType__SoloScore = 0,
    EPilgrimPersonalBestType__BandScore = 1,
    EPilgrimPersonalBestType__SpotlightScore = 2,
    EPilgrimPersonalBestType__Invalid = 3
};

enum EPilgrimMultiplayerState : uint8_t
{
    EPilgrimMultiplayerState__Solo = 0,
    EPilgrimMultiplayerState__Local = 1,
    EPilgrimMultiplayerState__Hybrid = 2,
    EPilgrimMultiplayerState__FullRemote = 3
};

enum EScoringMistakeType : uint8_t
{
    EScoringMistakeType__Miss = 0,
    EScoringMistakeType__Pass = 1
};

enum EPilgrimScoringMode : uint8_t
{
    EPilgrimScoringMode__IncludeModifiers = 0,
    EPilgrimScoringMode__ExcludeModifiers = 1
};

enum EPilgrimScoringTarget : uint8_t
{
    EPilgrimScoringTarget__None = 0,
    EPilgrimScoringTarget__BaseGem = 1,
    EPilgrimScoringTarget__StreakMultiplier = 2,
    EPilgrimScoringTarget__OverdriveMultiplier = 3,
    EPilgrimScoringTarget__SustainPerBeat = 4,
    EPilgrimScoringTarget__AccuracyMultiplier = 5
};

enum EPilgrimSongSortMethod : uint8_t
{
    EPilgrimSongSortMethod__Artist = 0,
    EPilgrimSongSortMethod__Title = 1,
    EPilgrimSongSortMethod__Year = 2
};

enum EPilgrimSongSortDirection : uint8_t
{
    EPilgrimSongSortDirection__Ascending = 0,
    EPilgrimSongSortDirection__Descending = 1
};

enum EPilgrimSongVoting_CastVoteResponse : uint8_t
{
    EPilgrimSongVoting_CastVoteResponse__Success = 0,
    EPilgrimSongVoting_CastVoteResponse__Failed_MissingPlayerState = 1,
    EPilgrimSongVoting_CastVoteResponse__Failed_MissingSongVotingComponent = 2,
    EPilgrimSongVoting_CastVoteResponse__Failed_NoAuthority = 3
};

enum EPilgrimSongVoting_CancelVoteResponse : uint8_t
{
    EPilgrimSongVoting_CancelVoteResponse__Success = 0,
    EPilgrimSongVoting_CancelVoteResponse__Failed_MissingPlayerState = 1,
    EPilgrimSongVoting_CancelVoteResponse__Failed_MissingSongVotingComponent = 2,
    EPilgrimSongVoting_CancelVoteResponse__Failed_NoAuthority = 3
};

enum EWidgetTouchKbmControllerTransitionType : uint8_t
{
    EWidgetTouchKbmControllerTransitionType__Opacity = 0,
    EWidgetTouchKbmControllerTransitionType__Collapse = 1,
    EWidgetTouchKbmControllerTransitionType__DoNothing = 2,
    EWidgetTouchKbmControllerTransitionType__Count = 3
};

enum EGemReleaseHandlingBehavior : uint8_t
{
    DefaultProcessing = 0,
    ForceRelease = 1
};

enum EPilgrimIMCPriority : uint8_t
{
    EPilgrimIMCPriority__Low = 0,
    EPilgrimIMCPriority__Medium = 1,
    EPilgrimIMCPriority__High = 2,
    EPilgrimIMCPriority__Highest = 3
};

enum EPilgrimPreloaderSongPosition : uint8_t
{
    EPilgrimPreloaderSongPosition__Current = 0,
    EPilgrimPreloaderSongPosition__Next = 1
};

enum EPilgrimStagePos : uint8_t
{
    EPilgrimStagePos__Back = 0,
    EPilgrimStagePos__Front = 1,
    EPilgrimStagePos__Left = 2,
    EPilgrimStagePos__Right = 3,
    EPilgrimStagePos__None = 4
};

enum EPilgrimTrackSlateTransformMode : uint8_t
{
    EPilgrimTrackSlateTransformMode__None = 0,
    EPilgrimTrackSlateTransformMode__Translation = 1,
    EPilgrimTrackSlateTransformMode__Rotation = 2,
    EPilgrimTrackSlateTransformMode__RotationTranslation = 3,
    EPilgrimTrackSlateTransformMode__Scale = 4,
    EPilgrimTrackSlateTransformMode__ScaleTranslation = 5,
    EPilgrimTrackSlateTransformMode__ScaleRotation = 6,
    EPilgrimTrackSlateTransformMode__ScaleRotationTranslation = 7
};

enum EBeanObstacleMotionMovementState : uint8_t
{
    EBeanObstacleMotionMovementState__Idle = 0,
    EBeanObstacleMotionMovementState__MovingOutward = 1,
    EBeanObstacleMotionMovementState__MovingInward = 2
};

enum EBeanObstacleImpactForceApplication : uint8_t
{
    EBeanObstacleImpactForceApplication__Absolute = 0,
    EBeanObstacleImpactForceApplication__Deflective = 1,
    EBeanObstacleImpactForceApplication__Additive = 2
};

enum EBeanObstacleImpactForceCalculatorType : uint8_t
{
    EBeanObstacleImpactForceCalculatorType__OutwardHorizontalAndVerticalStrength = 0,
    EBeanObstacleImpactForceCalculatorType__OutwardStrengthAndVerticalAngle = 1,
    EBeanObstacleImpactForceCalculatorType__GetDirectionFromSourceToTarget = 2
};

enum EObstacleMotionLockedState : uint8_t
{
    EObstacleMotionLockedState__None = 0,
    EObstacleMotionLockedState__Locked = 1,
    EObstacleMotionLockedState__ResetToInitial = 2
};

enum ELimeAssemblyEvent : uint8_t
{
    ELimeAssemblyEvent__Unknown = 0,
    ELimeAssemblyEvent__BeginAssemble = 1,
    ELimeAssemblyEvent__BeginDisassemble = 2,
    ELimeAssemblyEvent__FullyAssembled = 3,
    ELimeAssemblyEvent__FullyDisassembled = 4
};

enum EFortLimeUefnAnalyticsEvents : uint8_t
{
    EFortLimeUefnAnalyticsEvents__None = 0,
    EFortLimeUefnAnalyticsEvents__UEFN_Heartbeat = 1,
    EFortLimeUefnAnalyticsEvents__UEFN_ProjectSessionSummary = 2
};

enum EFortLimeGameplayAnalyticsEvents : uint8_t
{
    EFortLimeGameplayAnalyticsEvents__None = 0,
    EFortLimeGameplayAnalyticsEvents__Core_StartZone = 1,
    EFortLimeGameplayAnalyticsEvents__PlayerContextLocationPerMinute = 2
};

enum ELimePawnEmotionalStateMappingTest : uint8_t
{
    ELimePawnEmotionalStateMappingTest__LessOrEqual = 0,
    ELimePawnEmotionalStateMappingTest__GreaterOrEqual = 1
};

enum EJunoAIFriendshipVerbPawnCategory : uint8_t
{
    EJunoAIFriendshipVerbPawnCategory__None = 0,
    EJunoAIFriendshipVerbPawnCategory__Self = 1,
    EJunoAIFriendshipVerbPawnCategory__Players = 2
};

enum EJunoAIFriendshipVerbPawnSubjectRequirement : uint8_t
{
    EJunoAIFriendshipVerbPawnSubjectRequirement__None = 0,
    EJunoAIFriendshipVerbPawnSubjectRequirement__NoSelf = 1,
    EJunoAIFriendshipVerbPawnSubjectRequirement__RequireSelf = 2
};

enum EJunoNPCJobEndReason : uint8_t
{
    EJunoNPCJobEndReason__ManualPlayerUnassignment = 0,
    EJunoNPCJobEndReason__AutoUnassigmentViaFollowerAssignment = 1,
    EJunoNPCJobEndReason__AutoUnassignmentViaCampHardRemoval = 2
};

enum EJunoNPCFollowEndReason : uint8_t
{
    EJunoNPCFollowEndReason__ManualPlayerUnassignment = 0,
    EJunoNPCFollowEndReason__AutoUnassigmentViaRecruitment = 1,
    EJunoNPCFollowEndReason__AutoUnassignmentDueToStaleFollower = 2
};

enum ENPCRewardType : uint8_t
{
    ENPCRewardType__LootTier = 0,
    ENPCRewardType__Recipe = 1
};

enum EJunoWorldConditionNPCSlotsLimit : uint8_t
{
    EJunoWorldConditionNPCSlotsLimit__Unset = 0,
    EJunoWorldConditionNPCSlotsLimit__ReachedMaxCap = 1,
    EJunoWorldConditionNPCSlotsLimit__CanIncrease = 2
};

enum EJunoWorldCondition_AIWorldSettingsExpectedValue : uint8_t
{
    EJunoWorldCondition_AIWorldSettingsExpectedValue__Any = 0,
    EJunoWorldCondition_AIWorldSettingsExpectedValue__On = 1,
    EJunoWorldCondition_AIWorldSettingsExpectedValue__Off = 2
};

enum EJunoNPCJoinReason : uint8_t
{
    EJunoNPCJoinReason__StandardRecruitment = 0,
    EJunoNPCJoinReason__RemoteRecruitment = 1,
    EJunoNPCJoinReason__BarnRecruitment = 2
};

enum EJunoLnFContinueConversationMode : uint8_t
{
    EJunoLnFContinueConversationMode__StopOnDrop = 0,
    EJunoLnFContinueConversationMode__OnSingleDrop = 1,
    EJunoLnFContinueConversationMode__OnDropAll = 2,
    EJunoLnFContinueConversationMode__OnDropAny = 3
};

enum EJunoTokenReceiverType : uint8_t
{
    EJunoTokenReceiverType__QuestGiver = 0,
    EJunoTokenReceiverType__QuestGiverBoundPlayspace = 1
};

enum EJunoInsertItemType : uint8_t
{
    EJunoInsertItemType__Equipped = 0,
    EJunoInsertItemType__OffHand = 1,
    EJunoInsertItemType__Any = 2
};

enum EJunoAIGrantNPCDirectRewardCondition : uint8_t
{
    EJunoAIGrantNPCDirectRewardCondition__NPCTags = 0,
    EJunoAIGrantNPCDirectRewardCondition__CampTags = 1
};

enum EJunoQuestState : uint8_t
{
    EJunoQuestState__Invalid = 0,
    EJunoQuestState__Available = 1,
    EJunoQuestState__Rolled = 2,
    EJunoQuestState__InProgress = 3,
    EJunoQuestState__Completed = 4
};

enum EJunoLivingWorldModifierChangeType : uint8_t
{
    EJunoLivingWorldModifierChangeType__Added = 0,
    EJunoLivingWorldModifierChangeType__Removed = 1
};

enum EJunoCaveTeleporterFloor : uint8_t
{
    EJunoCaveTeleporterFloor__Above = 0,
    EJunoCaveTeleporterFloor__Below = 1
};

enum EJunoGetMergedCaveDataRegistryDataResult : uint8_t
{
    EJunoGetMergedCaveDataRegistryDataResult__Success = 0,
    EJunoGetMergedCaveDataRegistryDataResult__Failure = 1
};

enum EJunoCaveGeneratorShellType : uint8_t
{
    EJunoCaveGeneratorShellType__Room = 0,
    EJunoCaveGeneratorShellType__Connector = 1,
    EJunoCaveGeneratorShellType__Entrance = 2,
    EJunoCaveGeneratorShellType__Hero = 3,
    EJunoCaveGeneratorShellType__FeatureRoom = 4
};

enum EJunoCaveGeneratorShellSize : uint8_t
{
    EJunoCaveGeneratorShellSize__Small = 0,
    EJunoCaveGeneratorShellSize__Medium = 1,
    EJunoCaveGeneratorShellSize__Large = 2,
    EJunoCaveGeneratorShellSize__Hallway = 3,
    EJunoCaveGeneratorJ_____ = 4
};

enum EJunoCaveGeneratorLayoutTags : uint8_t
{
    EJunoCaveGeneratorLayoutTags__OroMine = 0
};

enum EJunoCaveGeneratorRuleMode : uint8_t
{
    EJunoCaveGeneratorRuleMode__Basic = 0,
    EJunoCaveGeneratorRuleMode__Template = 1
};

enum EJunoCaveGeneratorTypeMode : uint8_t
{
    EJunoCaveGeneratorTypeMode__Single = 0,
    EJunoCaveGeneratorTypeMode__Sequence = 1
};

enum EJunoCaveGeneratorTypeTeleporterRuleType : uint8_t
{
    EJunoCaveGeneratorTypeTeleporterRuleType__Disabled = 0,
    EJunoCaveGeneratorTypeTeleporterRuleType__MarkerShortcut = 1,
    EJunoCaveGeneratorTypeTeleporterRuleType__UpOneFloor = 2,
    EJunoCaveGeneratorTypeTeleporterRuleType__DownOneFloor = 3
};

enum EAddChainResult : uint8_t
{
    EAddChainResult__Success = 0,
    EAddChainResult__NoMatchingShell = 1,
    EAddChainResult__InvalidAttachIndex = 2,
    EAddChainResult__NoExitsLeft = 3,
    EAddChainResult__CannotFitShell = 4,
    EAddChainResult__NoShellsGenerated = 5
};

enum EJunoCaveTheme_DEPRECATED : uint8_t
{
    EJunoCaveTheme_DEPRECATED__Grassland = 0,
    EJunoCaveTheme_DEPRECATED__DarkForest = 1,
    EJunoCaveTheme_DEPRECATED__Tropical = 2,
    EJunoCaveTheme_DEPRECATED__Alpine = 3,
    EJunoCaveTheme_DEPRECATED__Dx__m_ = 4
};

enum EJunoCreateCaveResult : uint8_t
{
    EJunoCreateCaveResult__Success = 0,
    EJunoCreateCaveResult__Failure = 1,
    EJunoCreateCaveResult__Disabled = 2
};

enum EJunoQueryCaveDataResult : uint8_t
{
    EJunoQueryCaveDataResult__NotReady = 0,
    EJunoQueryCaveDataResult__NotAllowed = 1,
    EJunoQueryCaveDataResult__Cached = 2,
    EJunoQueryCaveDataResult__NoEntry = 3
};

enum EJunoQueryCaveSurfaceDataStateResult : uint8_t
{
    EJunoQueryCaveSurfaceDataStateResult__NotReady = 0,
    EJunoQueryCaveSurfaceDataStateResult__NotAllowed = 1,
    EJunoQueryCaveSurfaceDataStateResult__Cached = 2,
    EJunoQueryCaveSurfaceDataStateResult__NoEntry = 3
};

enum EJunoGetCaveSurfaceDataForEntranceResult : uint8_t
{
    EJunoGetCaveSurfaceDataForEntranceResult__NotReady = 0,
    EJunoGetCaveSurfaceDataForEntranceResult__NotAllowed = 1,
    EJunoGetCaveSurfaceDataForEntranceResult__IsACave = 2,
    EJunoGetCaveSurfaceDataForEntranceResult__NotACave = 3
};

enum EJunoGetCaveShellInstanceDataResult : uint8_t
{
    EJunoGetCaveShellInstanceDataResult__Success = 0,
    EJunoGetCaveShellInstanceDataResult__Failure = 1
};

enum EJunoGetBestCaveResult : uint8_t
{
    EJunoGetBestCaveResult__Success = 0,
    EJunoGetBestCaveResult__Failure = 1
};

enum EJunoCalculateCaveDistanceResult : uint8_t
{
    EJunoCalculateCaveDistanceResult__Success = 0,
    EJunoCalculateCaveDistanceResult__ParentIDsNotCorrect = 1,
    EJunoCalculateCaveDistanceResult__ShellsAreNotConnected = 2
};

enum EJunoGetCaveDataCollectionsFromRegistryResult : uint8_t
{
    EJunoGetCaveDataCollectionsFromRegistryResult__Success = 0,
    EJunoGetCaveDataCollectionsFromRegistryResult__Failure = 1,
    EJunoGetCaveDataCollectionsFromRegistryResult__EJunoGetCaveDataCollectionsFre_____j_d________2_B = 2
};

enum EJunoHLODMapActorsPersistenceMigrationLevel : uint8_t
{
    EJunoHLODMapActorsPersistenceMigrationLevel__None = 0,
    EJunoHLODMapActorsPersistenceMigrationLevel__NonHLOD = 1,
    EJunoHLODMapActorsPersistenceMigrationLevel__HLOD = 2
};

enum EJunoLifecycleApplyMeshScale : uint8_t
{
    EJunoLifecycleApplyMeshScale__RelativeToFinalLifecycle = 0,
    EJunoLifecycleApplyMeshScale__RelativeToWorld = 1
};

enum EJunoPCGVolumeSource : uint8_t
{
    EJunoPCGVolumeSource__Transient = 0,
    EJunoPCGVolumeSource__Persistent = 1
};

enum EJunoFindNextMatchingPOIResourceResult : uint8_t
{
    EJunoFindNextMatchingPOIResourceResult__Found = 0,
    EJunoFindNextMatchingPOIResourceResult__NotFound = 1
};

enum EJunoCompareTagSetsResult : uint8_t
{
    EJunoCompareTagSetsResult__NoMatch = 0,
    EJunoCompareTagSetsResult__PartialMatch = 1,
    EJunoCompareTagSetsResult__FullMatch = 2
};

enum EJunoResolveWorldSoftObjectPathResult : uint8_t
{
    EJunoResolveWorldSoftObjectPathResult__Success = 0,
    EJunoResolveWorldSoftObjectPathResult__NotAWorldObject = 1,
    EJunoResolveWorldSoftObjectPathResult__InvalidPath = 2
};

enum EJunoLevelInstanceMode : uint8_t
{
    EJunoLevelInstanceMode__Disabled = 0,
    EJunoLevelInstanceMode__StreamingWP = 1,
    EJunoLevelInstanceMode__CellInjection = 2
};

enum EPCGJunoPersistenceMigrationResultFlags : uint8_t
{
    EPCGJunoPersistenceMigrationResultFlags__None = 0,
    EPCGJunoPersistenceMigrationResultFlags__MigrationApplied = 1,
    EPCGJunoPersistenceMigrationResultFlags__PersistentDataReset = 2
};

enum EJunoWorldPartitionRuntimeHashType : uint8_t
{
    EJunoWorldPartitionRuntimeHashType__WorldPartitionSpatialHash = 0,
    EJunoWorldPartitionRuntimeHashType__WorldPartitionHashSet = 1,
    EJunoWorldPartitionRuntimeHashType__VersionPlusOne = 2,
    EJunoWorldPartitionRuntimeHashType__LatestVersion = 1,
    EJunoWorldPartitionRuntimeHashType__Invalid = 2
};

enum EJunoWorldRegistryType : uint8_t
{
    EJunoWorldRegistryType__Invalid = 0,
    EJunoWorldRegistryType__POI = 1,
    EJunoWorldRegistryType__Enemy = 2
};

enum EJunoTileStatus : uint8_t
{
    EJunoTileStatus__Disabled = 0,
    EJunoTileStatus__Enabled = 1,
    EJunoTileStatus__Deprecated = 2,
    EJunoTileStatus__Instantiated = 3,
    EJunoTileStatus__Reserved = 4,
    EJunoTileStatus__OutOfBounds = 5
};

enum EJunoWorldTilePOIType : uint8_t
{
    EJunoWorldTilePOIType__Overworld = 0,
    EJunoWorldTilePOIType__Cave = 1,
    EJunoWorldTilePOIType__CaveEntrance = 2,
    EJunoWorldTilePOIType__Bridge = 3,
    EJunoWorldTilePOIType__FishingSpot = 4
};

enum EJunoPOIDistributionMethod : uint8_t
{
    EJunoPOIDistributionMethod__Random = 0,
    EJunoPOIDistributionMethod__AdditionalPOI = 1,
    EJunoPOIDistributionMethod__CaveGeneratorRule = 2
};

enum EJunoPOITileQuadrantCorner : uint8_t
{
    EJunoPOITileQuadrantCorner__NorthEast = 0,
    EJunoPOITileQuadrantCorner__NorthWest = 1,
    EJunoPOITileQuadrantCorner__SouthEast = 2,
    EJunoPOITileQuadrantCorner__SouthWest = 3,
    EJunoPOITileQuadrantCorner__Count = 4
};

enum EPCGJunoPO____8__oW__Ak_____ : uint8_t
{
    EPCGJunoPOIIAMPreferredLevel__None = 0,
    EPCGJunoPOIIAMPreferredLevel__Default = 1,
    EPCGJunoPOIIAMPreferredLevel__NonHLOD = 2,
    EPCGJunoPOIIAMPreferredLevel__HLOD = 3
};

enum EJunoWorldTileAdditionalPOIPlacement : uint8_t
{
    EJunoWorldTileAdditionalPOIPlacement__Random = 0,
    EJunoWorldTileAdditionalPOIPlacement__NearEventTile = 1,
    EJunoWorldTileAdditionalPOIPlacement__WorldOriginTile = 2,
    EJunoWorldTileAdditionalPOIPlacement__TaggedTileAndSlot = 3,
    EJunoWorldTileAdditionalPOIPlacement__SessionOriginTile = 4,
    EJunoWorldTileAdditionalPOIPlacement__SessionOriginTileFallback = 5
};

enum EJunoAdditionalPOIWorldMode : uint8_t
{
    EJunoAdditionalPOIWorldMode__AllWorlds = 0,
    EJunoAdditionalPOIWorldMode__NewWorldsOnly = 1,
    EJunoAdditionalPOIWorldMode__OldWorldsOnly = 2
};

enum EJunoPOISlotState : uint8_t
{
    EJunoPOISlotState__Normal = 0,
    EJunoPOISlotState__Unused = 1,
    EJunoPOISlotState__Cosmetic = 2,
    EJunoPOISlotState__CaveEntrance = 3,
    EJunoPOISlotState__UnusedNearWorldStart = 4
};

enum EPathfinderNodeState : uint8_t
{
    EPathfinderNodeState__Normal = 0,
    EPathfinderNodeState__Snap = 1,
    EPathfinderNodeState__Warp = 2,
    EPathfinderNodeState__Invalid = 3
};

enum EJunoRepresentation : uint8_t
{
    EJunoRepresentation__None = 0,
    EJunoRepresentation__Actor = 1,
    EJunoRepresentation__Instance = 2
};

enum PCGJunoApplyMaskNodeMode : uint8_t
{
    PCGJunoApplyMaskNodeMode__Subtract = 0,
    PCGJunoApplyMaskNodeMode__Intersect = 1,
    PCGJunoApplyMaskNodeMode__SubtractSmaller = 2,
    PCGJunoApplyMaskNodeMode__SubtractLarger = 3
};

enum ELandmassRiverTier : uint8_t
{
    ELandmassRiverTier__Default = 0
};

enum EQueryPOIStateResult : uint8_t
{
    EQueryPOIStateResult__NotReady = 0,
    EQueryPOIStateResult__NotAllowed = 1,
    EQueryPOIStateResult__Cached = 2,
    EQueryPOIStateResult__NoEntry = 3
};

enum EJunoMarkSlotPOIUnusedResult : uint8_t
{
    EJunoMarkSlotPOIUnusedResult__Success = 0,
    EJunoMarkSlotPOIUnusedResult__Failure = 1
};

enum EJunoGetMatchingPOIsFromDataRegistryResult : uint8_t
{
    EJunoGetMatchingPOIsFromDataRegistryResult__Success = 0,
    EJunoGetMatchingPOIsFromDataRegistryResult__Failure = 1
};

enum EJunoPOISlotSelectionMode : uint8_t
{
    EJunoPOISlotSelectionMode__Default = 0,
    EJunoPOISlotSelectionMode__EncounterPOI = 1,
    EJunoPOISlotSelectionMode__CosmeticPOI = 2
};

enum EVerticalDirection : uint8_t
{
    EVerticalDirection__Both = 0,
    EVerticalDirection__DownwardOnly = 1,
    EVerticalDirection__UpwardOnly = 2
};

enum ELandmassRoadTier : uint8_t
{
    ELandmassRoadTier__Default = 0,
    ELandmassRoadTier__Dirt = 1,
    ELandmassRoadTier__Rural = 2,
    ELandmassRoadTier__Metropolitan = 3,
    ELandmassRoadTier__Suburban = 4,
    ELandmassRoadTier__Highway = 5,
    ELandmassRoadTier__BreadCrumbs = 6,
    ELandmassRoadTier__Hidden = 7
};

enum ERouteGenerationState : uint8_t
{
    ERouteGenerationState__Inactive = 0,
    ERouteGenerationState__Active = 1,
    ERouteGenerationState__Dormant = 2
};

enum ERouteAvoidancePrimitiveType : uint8_t
{
    ERouteAvoidancePrimitiveType__Disc = 0,
    ERouteAvoidancePrimitiveType__Curve = 1,
    ERouteAvoidancePrimitiveType__ProceduralRoutes = 2
};

enum EProceduralRouteGuideSetSelectMethod : uint8_t
{
    EProceduralRouteGuideSetSelectMethod__UseTileId = 0,
    EProceduralRouteGuideSetSelectMethod__UseTileIndex = 1
};

enum EProceduralRiverAnchorType : uint8_t
{
    EProceduralRiverAnchorType__Source = 0,
    EProceduralRiverAnchorType__Lake = 1,
    EProceduralRiverAnchorType__Coastline = 2,
    EProceduralRiverAnchorType__DeepSea = 3
};

enum PCGJunoFractalNoise2DMode : uint8_t
{
    PCGJunoFractalNoise2DMode__Perlin = 0,
    PCGJunoFractalNoise2DMode__Caustic = 1,
    PCGJunoFractalNoise2DMode__Voronoi = 2,
    PCGJunoFractalNoise2DMode__TiledVoronoi = 3,
    PCGJunoFractalNoise2DMode__Brownian = 4,
    PCGJunoFractalNoise2DMode__EdgeMask = 5
};

enum PCGJunoFractalNoise2DEdgeMode : uint8_t
{
    PCGJunoFractalNoise2DEdgeMode__Perlin = 0,
    PCGJunoFractalNoise2DEdgeMode__Caustic = 1,
    PCGJunoFractalNoise2DEdgeMode__Brownian = 2
};

enum PCGJunoFractalDensityMode : uint8_t
{
    PCGJunoFractalDensityMode__Ignore = 0,
    PCGJunoFractalDensityMode__Set = 1,
    PCGJunoFractalDensityMode__Add = 2,
    PCGJunoFractalDensityMode__Multiply = 3
};

enum EJunoPOIEncounterState : uint8_t
{
    EJunoPOIEncounterState__Invalid = 0,
    EJunoPOIEncounterState__Initialized = 1,
    EJunoPOIEncounterState__PersistentDataReady = 2,
    EJunoPOIEncounterState__Idle = 3,
    EJunoPOIEncounterState__Ready = 4,
    EJunoPOIEncounterState__Active = 5
};

enum EHLODActorDestructionScope : uint8_t
{
    EHLODActorDestructionScope__Visit = 0,
    EHLODActorDestructionScope__EncounterFinished = 1,
    EHLODActorDestructionScope__Never = 2
};

enum EJunoMusicCueSelectionBehavior : uint8_t
{
    EJunoMusicCueSelectionBehavior__Sequential = 0,
    EJunoMusicCueSelectionBehavior__Shuffle = 1,
    EJunoMusicCueSelectionBehavior__Random = 2,
    EJunoMusicCueSelectionBehavior__Count = 3
};

enum EJunoMusicCombatProbeConflictingStateResolution : uint8_t
{
    EJunoMusicCombatProbeConflictingStateResolution__Push = 0,
    EJunoMusicCombatProbeConflictingStateResolution__Remove = 1,
    EJunoMusicCombatProbeConflictingStateResolution__Count = 2
};

enum EFortRigUnitTraceType : uint8_t
{
    EFortRigUnitTraceType__SingleTrace = 0,
    EFortRigUnitTraceType__MultiTrace = 1
};

enum EJunoBattleBusStopType : uint8_t
{
    EJunoBattleBusStopType__Discovered = 0,
    EJunoBattleBusStopType__Special = 1,
    EJunoBattleBusStopType__PlayerPlaced = 2
};

enum EJunoBattleBusState : uint8_t
{
    EJunoBattleBusState__PickDestination = 0,
    EJunoBattleBusState__NowBoarding = 1,
    EJunoBattleBusState__BusRouteInProgress = 2
};

enum EJunoLowMemoryState : uint8_t
{
    EJunoLowMemoryState__Unset = 0,
    EJunoLowMemoryState__Good = 1,
    EJunoLowMemoryState__Low = 2,
    EJunoLowMemoryState__VeryLow = 3,
    EJunoLowMemoryState__Critical = 4
};

enum EJunoBangType : uint8_t
{
    EJunoBangType__Basic = 0,
    EJunoBangType__Number = 1,
    EJunoBangType__Minimal = 2
};

enum EJunoBangVisibility : uint8_t
{
    EJunoBangVisibility__Hidden = 0,
    EJunoBangVisibility__UnviewedBang = 1,
    EJunoBangVisibility__UnacquiredBang = 2
};

enum EStationInventoryState : uint8_t
{
    EStationInventoryState__CanCraft = 0,
    EStationInventoryState__InputIsEmpty = 1,
    EStationInventoryState__InputAndProcessingEmpty = 2,
    EStationInventoryState__Processing = 3,
    EStationInventoryState__OutputFull = 4
};

enum EJunoEnchantmentScreenState : uint8_t
{
    EJunoEnchantmentScreenState__WeaponSelection = 0,
    EJunoEnchantmentScreenState__EnchantmentSelection = 1,
    EJunoEnchantmentScreenState__Count = 2
};

enum EJunoEnchantButtonState : uint8_t
{
    EJunoEnchantButtonState__CanEnchant = 0,
    EJunoEnchantButtonState__NotEnoughResources = 1,
    EJunoEnchantButtonState__NoAvailableEnchantments = 2,
    EJunoEnchantButtonState__SlotsFull = 3,
    EJunoEnchantButtonState__CanCancelEnchant = 4
};

enum EJunoHudMenuScreen : uint8_t
{
    EJunoHudMenuScreen__InventoryScreen = 0,
    EJunoHudMenuScreen__CraftingScreen = 1,
    EJunoHudMenuScreen__CollectionScreen = 2,
    EJunoHudMenuScreen__BuildingScreen = 3,
    EJunoHudMenuScreen__Max_None = 4
};

enum EJunoSwapItemType : uint8_t
{
    EJunoSwapItemType__None = 0,
    EJunoSwapItemType__Source = 1,
    EJunoSwapItemType__SelectedDestination = 2,
    EJunoSwapItemType__PotentialDestination = 3,
    EJunoSwapItemType__GearDestinationInvalid = 4
};

enum EJunoCraftButtonState : uint8_t
{
    EJunoCraftButtonState__CanCraft = 0,
    EJunoCraftButtonState__CannotCraft = 1,
    EJunoCraftButtonState__StopCraft = 2
};

enum ESelectRecipeButtonState : uint8_t
{
    ESelectRecipeButtonState__SelectRecipeHeroState = 0,
    ESelectRecipeButtonState__SelectRecipeCommonState = 1,
    ESelectRecipeButtonState__DepositState = 2
};

enum ECraftingStationsInventoryState : uint8_t
{
    ECraftingStationsInventoryState__CanCraft = 0,
    ECraftingStationsInventoryState__MissingIngredients = 1,
    ECraftingStationsInventoryState__OutputFull = 2
};

enum EJunoPickupStreamAnim : uint8_t
{
    EJunoPickupStreamAnim__None = 0,
    EJunoPickupStreamAnim__Intro = 1,
    EJunoPickupStreamAnim__Update = 2
};

enum EJunoGrantedTomeRewardType : uint8_t
{
    EJunoGrantedTomeRewardType__None = 0,
    EJunoGrantedTomeRewardType__TomeReward = 1,
    EJunoGrantedTomeRewardType__FallbackReward = 2,
    EJunoGrantedTomeRewardType__EJunoGrantedTo______K__R__5_d_ = 3
};

enum EFortCollectionBookPopupButtonType : uint8_t
{
    EFortCollectionBookPopupButtonType__Invalid = 0,
    EFortCollectionBookPopupButtonType__SelectItem = 1,
    EFortCollectionBookPopupButtonType__Preview = 2,
    EFortCollectionBookPopupButtonType__Purchase = 3,
    EFortCollectionBookPopupButtonType__Unslot = 4,
    EFortCollectionBookPopupButtonType__Back = 5
};

enum ESquadSlotSortType : uint8_t
{
    ESquadSlotSortType__ByRating = 0,
    ESquadSlotSortType__ByLevel = 1,
    ESquadSlotSortType__ByRarity = 2,
    ESquadSlotSortType__ByBonus = 3,
    ESquadSlotSortType__ByMatch = 4
};

enum EFrontEndRewardType : uint8_t
{
    EFrontEndRewardType__Mission = 0,
    EFrontEndRewardType__Quest = 1,
    EFrontEndRewardType__EpicNewQuest = 2,
    EFrontEndRewardType__Expedition = 3,
    EFrontEndRewardType__CollectionBook = 4,
    EFrontEndRewardType__MissionAlert = 5,
    EFrontEndRewardType__DifficultyIncrease = 6,
    EFrontEndRewardType__GiftBox = 7,
    EFrontEndRewardType__ItemCache = 8,
    EFrontEndRewardType__PhoenixLevelUp = 9
};

enum ECollectionBookRewardStatus : uint8_t
{
    ECollectionBookRewardStatus__Unknown = 0,
    ECollectionBookRewardStatus__Available = 1,
    ECollectionBookRewardStatus__Claimed = 2
};

enum ECollectionBookPrimaryNavTarget : uint8_t
{
    ECollectionBookPrimaryNavTarget__Overview = 0,
    ECollectionBookPrimaryNavTarget__SectionTileView = 1
};

enum EFortExpeditionListSort : uint8_t
{
    EFortExpeditionListSort__ByRating = 0,
    EFortExpeditionListSort__ByDuration = 1,
    EFortExpeditionListSort__ByName = 2
};

enum EFortAlterationOptionType : uint8_t
{
    EFortAlterationOptionType__Upgrade = 0,
    EFortAlterationOptionType__Replacement = 1,
    EFortAlterationOptionType__Max_NONE = 2
};

enum EOodleNetResult : uint8_t
{
    EOodleNetResult__Unknown = 0,
    EOodleNetResult__Success = 1,
    EOodleNetResult__OodleDecodeFailed = 2,
    EOodleNetResult__OodleSerializePayloadFail = 3,
    EOodleNetResult__OodleBadDecompressedLength = 4,
    EOodleNetResult__OodleNoDictionary = 5
};

enum ERemapCurvesExpressionSource : uint8_t
{
    ERemapCurvesExpressionSource__ExpressionList = 0,
    ERemapCurvesExpressionSource__DataAsset = 1,
    ERemapCurvesExpressionSource__ExpressionMap = 2
};

enum ELearningAgentsActivationFunction : uint8_t
{
    ELearningAgentsActivationFunction__ReLU = 0,
    ELearningAgentsActivationFunction__ELU = 1,
    ELearningAgentsActivationFunction__TanH = 2
};

enum ELearningAgentsCompletion : uint8_t
{
    ELearningAgentsCompletion__Running = 0,
    ELearningAgentsCompletion__Truncation = 1,
    ELearningAgentsCompletion__Termination = 2
};

enum EBoneTransformResolution : uint8_t
{
    EBoneTransformResolution__KeepParent = 0,
    EBoneTransformResolution__KeepChild = 1,
    EBoneTransformResolution__Combine = 2
};

enum ELiveLinkTimecodeProviderEvaluationType : uint8_t
{
    ELiveLinkTimecodeProviderEvaluationType__Lerp = 0,
    ELiveLinkTimecodeProviderEvaluationType__Nearest = 1,
    ELiveLinkTimecodeProviderEvaluationType__Latest = 2
};

enum ELiveLinkAxis : uint8_t
{
    ELiveLinkAxis__X = 0,
    ELiveLinkAxis__Y = 1,
    ELiveLinkAxis__Z = 2,
    ELiveLinkAxis__XNeg = 3,
    ELiveLinkAxis__YNeg = 4,
    ELiveLinkAxis__ZNeg = 5
};

enum ELiveLinkHubTimecodeSource : uint8_t
{
    ELiveLinkHubTimecodeSource__NotDefined = 0,
    ELiveLinkHubTimecodeSource__SystemTimeEditor = 1,
    ELiveLinkHubTimecodeSource__UseSubjectName = 2
};

enum ELiveLinkClientStatus : uint8_t
{
    ELiveLinkClientStatus__Connected = 0,
    ELiveLinkClientStatus__Disconnected = 1,
    ELiveLinkClientStatus__Recording = 2
};

enum EVoteSessionNetworkType : uint8_t
{
    EVoteSessionNetworkType__NotDetermined = 0,
    EVoteSessionNetworkType__DedicatedServer = 1
};

enum EProcMeshSliceCapOption : uint8_t
{
    EProcMeshSliceCapOption__NoCap = 0,
    EProcMeshSliceCapOption__CreateNewSectionForCap = 1,
    EProcMeshSliceCapOption__UseLastSectionForCap = 2
};

enum ERazerChromaDeviceTypes : uint8_t
{
    ERazerChromaDeviceTypes__None = 0,
    ERazerChromaDeviceTypes__Keyboards = 1,
    ERazerChromaDeviceTypes__Mice = 2,
    ERazerChromaDeviceTypes__Headset = 4,
    ERazerChromaDeviceTypes__Mousepads = 8,
    ERazerChromaDeviceTypes__Keypads = 16,
    ERazerChromaDeviceTypes__ChromaLink = 32,
    ERazerChromaDeviceTypes__All = 63
};

enum EReflexMode : uint8_t
{
    EReflexMode__Disabled = 0,
    EReflexMode__Enabled = 1,
    EReflexMode__EnabledPlusBoost = 3
};

enum EMIDIEventType : uint8_t
{
    EMIDIEventType__Unknown = 0,
    EMIDIEventType__NoteOff = 8,
    EMIDIEventType__NoteOn = 9,
    EMIDIEventType__NoteAfterTouch = 10,
    EMIDIEventType__ControlChange = 11,
    EMIDIEventType__ProgramChange = 12,
    EMIDIEventType__ChannelAfterTouch = 13,
    EMIDIEventType__PitchBend = 14
};

enum ERaDistanceRolloffModel : uint8_t
{
    ERaDistanceRolloffModel__LOGARITHMIC = 0,
    ERaDistanceRolloffModel__LINEAR = 1,
    ERaDistanceRolloffModel__NONE = 2
};

enum ERaMaterialName : uint8_t
{
    ERaMaterialName__TRANSPARENT = 0,
    ERaMaterialName__ACOUSTIC_CEILING_TILES = 1,
    ERaMaterialName__BRICK_BARE = 2,
    ERaMaterialName__BRICK_PAINTED = 3,
    ERaMaterialName__CONCRETE_BLOCK_COARSE = 4,
    ERaMaterialName__CONCRETE_BLOCK_PAINTED = 5,
    ERaMaterialName__CURTAIN_HEAVY = 6,
    ERaMaterialName__FIBER_GLASS_INSULATION = 7,
    ERaMaterialName__GLASS_THIN = 8,
    ERaMaterialName__GLASS_THICK = 9,
    ERaMaterialName__GRASS = 10,
    ERaMaterialName__LINOLEUM_ON_CONCRETE = 11,
    ERaMaterialName__MARBLE = 12,
    ERaMaterialName__METAL = 13,
    ERaMaterialName__PARQUET_ONCONCRETE = 14,
    ERaMaterialName__PLASTER_ROUGH = 15,
    ERaMaterialName__PLASTER_SMOOTH = 16,
    ERaMaterialName__PLYWOOD_PANEL = 17,
    ERaMaterialName__POLISHED_CONCRETE_OR_TILE = 18,
    ERaMaterialName__SHEETROCK = 19,
    ERaMaterialName__WATER_OR_ICE_SURFACE = 20,
    ERaMaterialName__WOOD_CEILING = 21,
    ERaMaterialName__WOOD_PANEL = 22,
    ERaMaterialName__UNIFORM = 23
};

enum EResonanceRenderMode : uint8_t
{
    EResonanceRenderMode__StereoPanning = 0,
    EResonanceRenderMode__BinauralLowQuality = 1,
    EResonanceRenderMode__BinauralMediumQuality = 2,
    EResonanceRenderMode__BinauralHighQuality = 3,
    EResonanceRenderMode__RoomEffectsOnly = 4
};

enum EProceduralRotationFormat : uint8_t
{
    EProceduralRotationFormat__VectorXAxis = 0,
    EProceduralRotationFormat__VectorXAxisNegative = 1,
    EProceduralRotationFormat__VectorYAxis = 2,
    EProceduralRotationFormat__VectorYAxisNegative = 3,
    EProceduralRotationFormat__VectorZAxis = 4,
    EProceduralRotationFormat__VectorZAxisNegative = 5,
    EProceduralRotationFormat__Vector2DXAxis = 6,
    EProceduralRotationFormat__Vector2DXAxisNegative = 7,
    EProceduralRotationFormat__Vector2DYAxis = 8,
    EProceduralRotationFormat__Vector2DYAxisNegative = 9,
    EProceduralRotationFormat__Vector2DZAxis = 10,
    EProceduralRotationFormat__Vector2DZAxisNegative = 11,
    EProceduralRotationFormat__RangedRotator = 12
};

enum EProceduralScatterMethod : uint8_t
{
    EProceduralScatterMethod__Density = 0,
    EProceduralScatterMethod__SourcePoints = 1,
    EProceduralScatterMethod__Grid = 2
};

enum UStreamlineFeature : uint8_t
{
    UStreamlineFeature__DLSSG = 0,
    UStreamlineFeature__Reflex = 1,
    UStreamlineFeature__Count = 2
};

enum UStreamlineFeatureRequirementsFlags : uint8_t
{
    UStreamlineFeatureRequ_9__Y____gM__k__C__ = 0,
    UStreamlineFeatureRequirementsFlags__D3D11Supported = 1,
    UStreamlineFeatureRequirementsFlags__D3D12Supported = 2,
    UStreamlineFeatureRequirementsFlags__VulkanSupported = 4,
    UStreamlineFeatureRequirementsFlags__VSyncOffRequired = 8,
    UStreamlineFeatureRequirementsFlags__HardwareSchedulingRequired = 16
};

enum UStreamlineDLSSGMode : uint8_t
{
    UStreamlineDLSSGMode__Off = 0,
    UStreamlineDLSSGMode__On = 1
};

enum UStreamlineReflexMode : uint8_t
{
    UStreamlineReflexMode__Disabled = 0,
    UStreamlineReflexMode__Enabled = 1,
    UStreamlineReflexMode__EnabledPlusBoost = 3
};

enum ELandscapePatchPriorityInitialization : uint8_t
{
    ELandscapePatchPriorityInitialization__AcquireHighest = 0,
    ELandscapePatchPriorityInitialization__KeepOriginal = 1,
    ELandscapePatchPriorityInitialization__SmallIncrement = 2
};

enum ELandscapeTexturePatchBlendMode : uint8_t
{
    ELandscapeTexturePatchBlendMode__AlphaBlend = 0,
    ELandscapeTexturePatchBlendMode__Additive = 1,
    ELandscapeTexturePatchBlendMode__Min = 2,
    ELandscapeTexturePatchBlendMode__Max = 3
};

enum ELandscapeTextureHeightPatchEncoding : uint8_t
{
    ELandscapeTextureHeightPatchEncoding__ZeroToOne = 0,
    ELandscapeTextureHeightPatchEncoding__WorldUnits = 1,
    ELandscapeTextureHeightPatchEncoding__NativePackedHeight = 2
};

enum ELandscapeTextureHeightPatchZeroHeightMeaning : uint8_t
{
    ELandscapeTextureHeightPatchZeroHeightMeaning__PatchZ = 0,
    ELandscapeTextureHeightPatchZeroHeightMeaning__LandscapeZ = 1,
    ELandscapeTextureHeightPatchZeroHeightMeaning__WorldZero = 2
};

enum EMassMovementAction : uint8_t
{
    EMassMovementAction__Stand = 0,
    EMassMovementAction__Move = 1,
    EMassMovementAction__Animate = 2
};

enum EMassLookAtMode : uint8_t
{
    EMassLookAtMode__LookForward = 0,
    EMassLookAtMode__LookAlongPath = 1,
    EMassLookAtMode__LookAtEntity = 2
};

enum EMassLookAtGazeMode : uint8_t
{
    EMassLookAtGazeMode__None = 0,
    EMassLookAtGazeMode__Constant = 1,
    EMassLookAtGazeMode__Glance = 2
};

enum EPelvisHeightMode : uint8_t
{
    EPelvisHeightMode__AllLegs = 0,
    EPelvisHeightMode__AllPlantedFeet = 1,
    EPelvisHeightMode__FrontPlantedFeetUphill_FrontFeetDownhill = 2
};

enum EActorMovementCompensationMode : uint8_t
{
    EActorMovementCompensationMode__ComponentSpace = 0,
    EActorMovementCompensationMode__WorldSpace = 1,
    EActorMovementCompensationMode__SuddenMotionOnly = 2
};

enum EOffsetRootBoneMode : uint8_t
{
    EOffsetRootBoneMode__Accumulate = 0,
    EOffsetRootBoneMode__Interpolate = 1,
    EOffsetRootBoneMode__LockOffsetAndConsumeAnimation = 2,
    EOffsetRootBoneMode__LockOffsetIncreaseAndConsumeAnimation = 3,
    EOffsetRootBoneMode__LockOffsetAndIgnoreAnimation = 4,
    EOffsetRootBoneMode__Release = 5
};

enum EOffsetRootBone_CollisionTestingMode : uint8_t
{
    EOffsetRootBone_CollisionTestingMode__Disabled = 0,
    EOffsetRootBone_CollisionTestingMode__ShrinkMaxTranslation = 1,
    EOffsetRootBone_CollisionTestingMode__PlanarCollision = 2
};

enum EOrientationWarpingSpace : uint8_t
{
    EOrientationWarpingSpace__ComponentTransform = 0,
    EOrientationWarpingSpace__RootBoneTransform = 1,
    EOrientationWarpingSpace__CustomTransform = 2
};

enum EGLTFTextureImageFormat : uint8_t
{
    EGLTFTextureImageFormat__None = 0,
    EGLTFTextureImageFormat__PNG = 1,
    EGLTFTextureImageFormat__JPEG = 2
};

enum EGLTFMaterialVariantMode : uint8_t
{
    EGLTFMaterialVariantMode__None = 0,
    EGLTFMaterialVariantMode__Simple = 1,
    EGLTFMaterialVariantMode__UseMeshData = 2
};

enum EGLTFMaterialBakeMode : uint8_t
{
    EGLTFMaterialBakeMode__Disabled = 0,
    EGLTFMaterialBakeMode__Simple = 1,
    EGLTFMaterialBakeMode__UseMeshData = 2
};

enum EGLTFMaterialPropertyGroup : uint8_t
{
    EGLTFMaterialPropertyGroup__None = 0,
    EGLTFMaterialPropertyGroup__BaseColorOpacity = 1,
    EGLTFMaterialPropertyGroup__MetallicRoughness = 2,
    EGLTFMaterialPropertyGroup__EmissiveColor = 3,
    EGLTFMaterialPropertyGroup__Normal = 4,
    EGLTFMaterialPropertyGroup__AmbientOcclusion = 5,
    EGLTFMaterialPropertyGroup__ClearCoatRoughness = 6,
    EGLTFMaterialPropertyGroup__ClearCoatBottomNormal = 7
};

enum EInterchangeFactoryAssetType : uint8_t
{
    EInterchangeFactoryAssetType__None = 0,
    EInterchangeFactoryAssetType__Textures = 1,
    EInterchangeFactoryAssetType__Materials = 2,
    EInterchangeFactoryAssetType__Meshes = 3,
    EInterchangeFactoryAssetType__Animations = 4,
    EInterchangeFactoryAssetType__Physics = 5
};

enum EInterchangePipelineContext : uint8_t
{
    EInterchangePipelineContext__None = 0,
    EInterchangePipelineContext__AssetImport = 1,
    EInterchangePipelineContext__AssetReimport = 2,
    EInterchangePipelineContext__SceneImport = 3,
    EInterchangePipelineContext__SceneReimport = 4,
    EInterchangePipelineContext__AssetCustomLODImport = 5,
    EInterchangePipelineContext__AssetCustomLODReimport = 6,
    EInterchangePipelineContext__AssetAlternateSkinningImport = 7,
    EInterchangePipelineContext__AssetAlternateSkinningReimport = 8,
    EInterchangePipelineContext__AssetCustomMorphTargetImport = 9,
    EInterchangePipelineContext__AssetCustomMorphTargetReImport = 10
};

enum EInterchangeResultType : uint8_t
{
    EInterchangeResultType__Success = 0,
    EInterch__A__t5___2_____E__BS__ = 1,
    EInterchangeResultType__Error = 2
};

enum EReimportStrategyFlags : uint8_t
{
    EReimportStrategyFlags__ApplyNoProperties = 0,
    EReimportStrategyFlags__ApplyPipelineProperties = 1,
    EReimportStrategyFlags__ApplyEditorChangedProperties = 2
};

enum EInterchangePropertyTracks : uint8_t
{
    EInterchangePropertyTracks__AffectDistanceFieldLighting = 0,
    EInterchangePropertyTracks__AffectDynamicIndirectLighting = 1,
    EInterchangePropertyTracks__AffectIndirectLightingWhileHidden = 2,
    EInterchangePropertyTracks__AutoActivate = 3,
    EInterchangePropertyTracks__BodyInstanceAngularDamping = 4,
    EInterchangePropertyTracks__BodyInstancebEnableGravity = 5,
    EInterchangePropertyTracks__BodyInstancebNotifyRigidBodyCollision = 6,
    EInterchangePropertyTracks__BodyInstancebSimulatePhysics = 7,
    EInterchangePropertyTracks__BodyInstancebUpdateKinematicFromSimulation = 8,
    EInterchangePropertyTracks__BodyInstancebUseCCD = 9,
    EInterchangePropertyTracks__BodyInstanceLinearDamping = 10,
    EInterchangePropertyTracks__BodyInstanceMassScale = 11,
    EInterchangePropertyTracks__BoundsScale = 12,
    EInterchangePropertyTracks__CastContactShadow = 13,
    EInterchangePropertyTracks__CastHiddenShadow = 14,
    EInterchangePropertyTracks__CastInsetShadow = 15,
    EInterchangePropertyTracks__CastShadow = 16,
    EInterchangePropertyTracks__CustomDepthStencilValue = 17,
    EInterchangePropertyTracks__CustomDepthStencilWriteMask = 18,
    EInterchangePropertyTracks__DefaultUpVector = 19,
    EInterchangePropertyTracks__DrawDebug = 20,
    EInterchangePropertyTracks__EmissiveLightSource = 21,
    EInterchangePropertyTracks__ExcludeFromLightAttachmentGroup = 22,
    EInterchangePropertyTracks__HiddenInGame = 23,
    EInterchangePropertyTracks__HiddenInSceneCapture = 24,
    EInterchangePropertyTracks__Holdout = 25,
    EInterchangePropertyTracks__LightAttachmentsAsGroup = 26,
    EInterchangePropertyTracks__Mobility = 27,
    EInterchangePropertyTracks__OnlyOwnerSee = 28,
    EInterchangePropertyTracks__OwnerNoSee = 29,
    EInterchangePropertyTracks__ReceivesDecals = 30,
    EInterchangePropertyTracks__RenderCustomDepth = 31,
    EInterchangePropertyTracks__RenderInDepthPass = 32,
    EInterchangePropertyTracks__RenderInMainPass = 33,
    EInterchangePropertyTracks__SingleSampleShadowFromStationaryLights = 34,
    EInterchangePropertyTracks__TranslucencySortDistanceOffset = 35,
    EInterchangePropertyTracks__VisibleInRayTracing = 36,
    EInterchangePropertyTracks__VisibleInSceneCaptureOnly = 37,
    EInterchangePropertyTracks__Visibility = 38,
    EInterchangePropertyTracks__LightAffectGlobalIllumination = 39,
    EInterchangePropertyTracks__LightAffectReflection = 40,
    EInterchangePropertyTracks__LightAffectTranslucentLighting = 41,
    EInterchangePropertyTracks__LightAtmosphereSunDiskColorScale = 42,
    EInterchangePropertyTracks__LightAtmosphereSunLight = 43,
    EInterchangePropertyTracks__LightAtmosphereSunLightIndex = 44,
    EInterchangePropertyTracks__LightAttenuationRadius = 45,
    EInterchangePropertyTracks__LightBarnDoorAngle = 46,
    EInterchangePropertyTracks__LightBarnDoorLength = 47,
    EInterchangePropertyTracks__LightBloomMaxBrightness = 48,
    EInterchangePropertyTracks__LightBloomScale = 49,
    EInterchangePropertyTracks__LightBloomThreshold = 50,
    EInterchangePropertyTracks__LightBloomTint = 51,
    EInterchangePropertyTracks__LightCascadeDistributionExponent = 52,
    EInterchangePropertyTracks__LightCascadeTransitionFraction = 53,
    EInterchangePropertyTracks__LightCastDeepShadow = 54,
    EI_Z_____________l___Lh________fM___m_______ = 55,
    EInterchangePropertyTracks__LightCastVolumetricShadow = 56,
    EInterchangePropertyTracks__LightCloudAmbientOcclusionStrength = 57,
    EInterchangePropertyTracks__LightCloudScatteredLuminanceScale = 58,
    EInterchangePropertyTracks__LightCloudShadowOnAtmosphereStrength = 59,
    EInterchangePropertyTracks__LightCloudShadowOnSurfaceStrength = 60,
    EInterchangePropertyTracks__LightCloudShadowStrength = 61,
    EInterchangePropertyTracks__LightColor = 62,
    EInterchangePropertyTracks__LightDynamicShadowCascades = 63,
    EInterchangePropertyTracks__LightDynamicShadowDistanceMovableLight = 64,
    EInterchangePropertyTracks__LightDynamicShadowDistanceStationaryLight = 65,
    EInterchangePropertyTracks__LightEnableLightShaftBloom = 66,
    EInterchangePropertyTracks__LightEnableLightShaftOcclusion = 67,
    EInterchangePropertyTracks__LightFalloffExponent = 68,
    EInterchangePropertyTracks__LightForceCachedShadowsForMovablePrimitives = 69,
    EInterchangePropertyTracks__LightForwardShadingPriority = 70,
    EInterchangePropertyTracks__LightFunctionFadeDistance = 71,
    EInterchangePropertyTracks__LightFunctionScale = 72,
    EInterchangePropertyTracks__LightIESBrightnessScale = 73,
    EInterchangePropertyTracks__LightIndirectLightingIntensity = 74,
    EInterchangePropertyTracks__LightInnerConeAngle = 75,
    EInterchangePropertyTracks__LightIntensity = 76,
    EInterchangePropertyTracks__LightIntensityUnits = 77,
    EInterchangePropertyTracks__LightInverseExposureBlend = 78,
    EInterchangePropertyTracks__LightLowerHemisphereColor = 79,
    EInterchangePropertyTracks__LightmassSettingsLightSourceAngle = 80,
    EInterchangePropertyTracks__LightMinOcclusion = 81,
    EInterchangePropertyTracks__LightModulatedShadowColor = 82,
    EInterchangePropertyTracks__LightOcclusionDepthRange = 83,
    EInterchangePropertyTracks__LightOcclusionExponent = 84,
    EInterchangePropertyTracks__LightOcclusionMaskDarkness = 85,
    EInterchangePropertyTracks__LightOcclusionTint = 86,
    EInterchangePropertyTracks__LightOuterConeAngle = 87,
    EInterchangePropertyTracks__LightSamplesPerPixel = 88,
    EInterchangePropertyTracks__LightShadowAmount = 89,
    EInterchangePropertyTracks__LightShadowBias = 90,
    EInterchangePropertyTracks__LightShadowCascadeBiasDistribution = 91,
    EInterchangePropertyTracks__LightShadowDistanceFadeoutFraction = 92,
    EInterchangePropertyTracks__LightShadowSlopeBias = 93,
    EInterchangePropertyTracks__LightShadowSourceAngleFactor = 94,
    EInterchangePropertyTracks__LightShaftOverrideDirection = 95,
    EInterchangePropertyTracks__LightSoftSourceRadius = 96,
    EInterchangePropertyTracks__LightSourceAngle = 97,
    EInterchangePropertyTracks__LightSourceCubemapAngle = 98,
    EInterchangePropertyTracks__LightSourceHeight = 99,
    EInterchangePropertyTracks__LightSourceLength = 100,
    EInterchangePropertyTracks__LightSourceRadius = 101,
    EInterchangePropertyTracks__LightSourceSoftAngle = 102,
    EInterchangePropertyTracks__LightSourceWidth = 103,
    EInterchangePropertyTracks__LightSpecularScale = 104,
    EInterchangePropertyTracks__LightDiffuseScale = 105,
    EInterchangePropertyTracks__LightTemperature = 106,
    EInterchangePropertyTracks__LightTransmission = 107,
    EInterchangePropertyTracks__LightUseIESBrightness = 108,
    EInterchangePropertyTracks__LightUseInverseSquaredFalloff = 109,
    EInterchangePropertyTracks__LightUseTemperature = 110,
    EInterchangePropertyTracks__LightVolumetricScatteringIntensity = 111,
    EInterchangePropertyTracks__CameraAspectRatio = 112,
    EInterchangePropertyTracks__CameraAspectRatioAxisConstraint = 113,
    EInterchangePropertyTracks__CameraAutoCalculateOrthoPlanes = 114,
    EInterchangePropertyTracks__CameraAutoPlaneShift = 115,
    EInterchangePropertyTracks__CameraConstrainAspectRatio = 116,
    EInterchangePropertyTracks__CameraCurrentAperture = 117,
    EInterchangePropertyTracks__CameraCurrentFocalLength = 118,
    EInterchangePropertyTracks__CameraCustomNearClippingPlane = 119,
    EInterchangePropertyTracks__CameraFieldOfView = 120,
    EInterchangePropertyTracks__CameraFilmbackSensorAspectRatio = 121,
    EInterchangePropertyTracks__CameraFilmbackSensorHeight = 122,
    EInterchangePropertyTracks__CameraFilmbackSensorWidth = 123,
    EInterchangePropertyTracks__CameraFocusSettingsFocusOffset = 124,
    EInterchangePropertyTracks__CameraFocusSettingsManualFocusDistance = 125,
    EInterchangePropertyTracks__CameraFocusSettingsTrackingFocusSettingsRelativeOffset = 126,
    EInterchangePropertyTracks__CameraOrthoFarClipPlane = 127,
    EInterchangePropertyTracks__CameraOrthoNearClipPlane = 128,
    EInterchangeProper___Lh________kK___m__ = 129,
    EInterchangePropertyTracks__CameraOverrideAspectRatioAxisConstraint = 130,
    EInterchangePropertyTracks__CameraPostProcessBlendWeight = 131,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientCubemapIntensity = 132,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientCubemapTint = 133,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionBias = 134,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionFadeDistance = 135,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionFadeRadius = 136,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionIntensity = 137,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionMipBlend = 138,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionMipScale = 139,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionMipThreshold = 140,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionPower = 141,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionQuality = 142,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionRadius = 143,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionStaticFraction = 144,
    EInterchangePropertyTracks__CameraPostProcessSettingsAmbientOcclusionTemporalBlendWeight = 145,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureBias = 146,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureHighPercent = 147,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureLowPercent = 148,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureMaxBrightness = 149,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureMinBrightness = 150,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureSpeedDown = 151,
    EInterchangePropertyTracks__CameraPostProcessSettingsAutoExposureSpeedUp = 152,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom1Size = 153,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom1Tint = 154,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom2Size = 155,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom2Tint = 156,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom3Size = 157,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom3Tint = 158,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom4Size = 159,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom4Tint = 160,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom5Size = 161,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom5Tint = 162,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom6Size = 163,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloom6Tint = 164,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionBufferScale = 165,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionCenterUV = 166,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionPreFilterMax = 167,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionPreFilterMin = 168,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionPreFilterMult = 169,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionScatterDispersion = 170,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomConvolutionSize = 171,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomDirtMaskIntensity = 172,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomDirtMaskTint = 173,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomIntensity = 174,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomSizeScale = 175,
    EInterchangePropertyTracks__CameraPostProcessSettingsBloomThreshold = 176,
    EInterchangePropertyTracks__CameraPostProcessSettingsBlueCorrection = 177,
    EInterchangePropertyTracks__CameraPostProcessSettingsChromaticAberrationStartOffset = 178,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorContrast = 179,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorContrastHighlights = 180,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorContrastMidtones = 181,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorContrastShadows = 182,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorCorrectionHighlightsMax = 183,
    EInterch__s64q__a__j_____P____YV____W7____q__P__p__t_____Q____QP____l_____s__p___ = 184,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorCorrectionShadowsMax = 185,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGain = 186,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGainHighlights = 187,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGainMidtones = 188,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGainShadows = 189,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGamma = 190,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGammaHighlights = 191,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGammaMidtones = 192,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGammaShadows = 193,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorGradingIntensity = 194,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorOffset = 195,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorOffsetHighlights = 196,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorOffsetMidtones = 197,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorOffsetShadows = 198,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorSaturation = 199,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorSaturationHighlights = 200,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorSaturationMidtones = 201,
    EInterchangePropertyTracks__CameraPostProcessSettingsColorSaturationShadows = 202,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldBladeCount = 203,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldDepthBlurAmount = 204,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldDepthBlurRadius = 205,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldFarBlurSize = 206,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldFarTransitionRegion = 207,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldFocalDistance = 208,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldFocalRegion = 209,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldFstop = 210,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldMinFstop = 211,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldNearBlurSize = 212,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldNearTransitionRegion = 213,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldOcclusion = 214,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldScale = 215,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldSkyFocusDistance = 216,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldUseHairDepth = 217,
    EInterchangePropertyTracks__CameraPostProcessSettingsDepthOfFieldVignetteSize = 218,
    EInterchangePropertyTracks__CameraPostProcessSettingsDynamicGlobalIlluminationMethod = 219,
    EInterchangePropertyTracks__CameraPostProcessSettingsExpandGamut = 220,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmBlackClip = 221,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainHighlightsMax = 222,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainHighlightsMin = 223,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainIntensity = 224,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainIntensityHighlights = 225,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainIntensityMidtones = 226,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainIntensityShadows = 227,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainShadowsMax = 228,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmGrainTexelSize = 229,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmShoulder = 230,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmSlope = 231,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmToe = 232,
    EInterchangePropertyTracks__CameraPostProcessSettingsFilmWhiteClip = 233,
    EInterchangePropertyTracks__CameraPostProcessSettingsHistogramLogMax = 234,
    EInterchangePropertyTracks__CameraPostProcessSettingsHistogramLogMin = 235,
    EInterchangePropertyTracks__CameraPostProcessSettingsIndirectLightingColor = 236,
    EInterchangePropertyTracks__CameraPostProcessSettingsIndirectLightingIntensity = 237,
    EInterchangePropertyTrac___s__sL__nf_________j__Zp____________wN__Wg_00 = 238,
    EInterchangePropertyTracks__CameraPostProcessSettingsLensFlareIntensity = 239,
    EInterchangePropertyTracks__CameraPostProcessSettingsLensFlareThreshold = 240,
    EInterchangePropertyTracks__CameraPostProcessSettingsLensFlareTint = 241,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureBlurredLuminanceBlend = 242,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureBlurredLuminanceKernelSizePercent = 243,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureDetailStrength = 244,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureHighlightContrastScale = 245,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureHighlightThreshold = 246,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureMiddleGreyBias = 247,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureShadowContrastScale = 248,
    EInterchangePropertyTracks__CameraPostProcessSettingsLocalExposureShadowThreshold = 249,
    EInterchangePropertyTracks__CameraPostProcessSettingsLumenDiffuseColorBoost = 250,
    EInterchangePropertyTracks__CameraPostProcessSettingsLumenFinalGatherLightingUpdateSpeed = 251
};

enum EInterchangeAnimationPayLoadType : uint8_t
{
    EInterchangeAnimationPayLoadType__NONE = 0,
    EInterchangeAnimationPayLoadType__CURVE = 1,
    EInterchangeAnimationPayLoadType__MORPHTARGETCURVE = 2,
    EInterchangeAnimationPayLoadType__STEPCURVE = 3,
    EInterchangeAnimationPayLoadType__BAKED = 4,
    EInterchangeAnimationPayLoadType__MORPHTARGETCURVEWEIGHTINSTANCE = 5
};

enum EInterchangeTextureWrapMode : uint8_t
{
    EInterchangeTextureWrapMode__Wrap = 0,
    EInterchangeTextureWrapMode__Clamp = 1,
    EInterchangeTextureWrapMode__Mirror = 2
};

enum EInterchangePipelineConfigurationDialogResult : uint8_t
{
    EInterchangePipelineConfigurationDialogResult__Cancel = 0,
    EInterchangePipelineConfigurationDialogResult__Import = 1,
    EInterchangePipelineConfigurationDialogResult__ImportAll = 2
};

enum EInterchangeMaterialXBSDF : uint8_t
{
    EInterchangeMaterialXBSDF__OrenNayarDiffuse = 0,
    EInterchangeMaterialXBSDF__BurleyDiffuse = 1,
    EInterchangeMaterialXBSDF__Translucent = 2,
    EInterchangeMaterialXBSDF__Dielectric = 3,
    EInterchangeMaterialXBSDF__Conductor = 4,
    EInterchangeMaterialXBSDF__GeneralizedSchlick = 5,
    EInterchangeMaterialXBSDF__Subsurface = 6,
    EInterchangeMaterialXBSDF__Sheen = 7,
    EInterchangeMaterialXBSDF__ThinFilm = 8,
    EInterchangeMaterialXBSDF__MaxBSDFCount = 9
};

enum EInterchangeMaterialXVDF : uint8_t
{
    EInterchangeMaterialXVDF__Absorption = 0,
    EInterchangeMaterialXVDF__Anisotropic = 1,
    EInterchangeMaterialXVDF__MaxVDFCount = 2
};

enum EUsdModelCardGeometry : uint8_t
{
    EUsdModelCardGeometry__Cross = 0,
    EUsdModelCardGeometry__Box = 1,
    EUsdModelCardGeometry__FromTexture = 2
};

enum EUsdModelCardFace : uint8_t
{
    EUsdModelCardFace__None = 0,
    EUsdModelCardFace__XPos = 1,
    EUsdModelCardFace__YPos = 2,
    EUsdModelCardFace__ZPos = 4,
    EUsdModelCardFace__XNeg = 8,
    EUsdModelCardFace__YNeg = 16,
    EUsdModelCardFace__ZNeg = 32
};

enum EUsdDuplicateType : uint8_t
{
    EUsdDuplicateType__FlattenComposedPrim = 0,
    EUsdDuplicateType__SingleLayerSpecs = 1,
    EUsdDuplicateType__AllLocalLayerSpecs = 2
};

enum EUsdSaveDialogBehavior : uint8_t
{
    EUsdSaveDialogBehavior__NeverSave = 0,
    EUsdSaveDialogBehavior__AlwaysSave = 1,
    EUsdSaveDialogBehavior__ShowPrompt = 2
};

enum EUsdEditInInstanceBehavior : uint8_t
{
    EUsdEditInInstanceBehavior__Ignore = 0,
    EUsdEditInInstanceBehavior__RemoveInstanceable = 1,
    EUsdEditInInstanceBehavior__ShowPrompt = 2
};

enum EUsdDefaultKind : uint8_t
{
    EUsdDefaultKind__None = 0,
    EUsdDefaultKind__Model = 1,
    EUsdDefaultKind__Component = 2,
    EUsdDefaultKind__Group = 4,
    EUsdDefaultKind__Assembly = 8,
    EUsdDefaultKind__Subcomponent = 16
};

enum EUsdRootMotionHandling : uint8_t
{
    EUsdRootMotionHandling__NoAdditionalRootMotion = 0,
    EUsdRootMotionHandling__UseMotionFromSkelRoot = 1,
    EUsdRootMotionHandling__UseMotionFromSkeleton = 2
};

enum EGeometryCacheImport : uint8_t
{
    EGeometryCacheImport__Never = 0,
    EGeometryCacheImport__OnLoad = 1,
    EGeometryCacheImport__OnSave = 2
};

enum EDataSortTypeEnum : uint8_t
{
    EDataSortTypeEnum__ChaosNiagara_DataSortType_NoSorting = 0,
    EDataSortTypeEnum__ChaosNiagara_DataSortType_RandomShuffle = 1,
    EDataSortTypeEnum__ChaosNiagara_DataSortType_SortByMassMaxToMin = 2,
    EDataSortTypeEnum__ChaosNiagara_DataSortType_SortByMassMinToMax = 3,
    EDataSortTypeEnum__ChaosNiagara_Max = 4
};

enum ELocationXToSpawnEnum : uint8_t
{
    ELocationXToSpawnEnum__ChaosNiagara_LocationXToSpawn_None = 0,
    ELocationXToSpawnEnum__ChaosNiagara_LocationXToSpawn_Min = 1,
    ELocationXToSpawnEnum__ChaosNiagara_LocationXToSpawn_Max = 2,
    ELocationXToSpawnEnum__ChaosNiagara_LocationXToSpawn_MinMax = 3,
    ELocationXToSpawnEnum__ChaosNiagara_Max = 4
};

enum ELocationYToSpawnEnum : uint8_t
{
    ELocationYToSpawnEnum__ChaosNiagara_LocationYToSpawn_None = 0,
    ELocationYToSpawnEnum__ChaosNiagara_LocationYToSpawn_Min = 1,
    ELocationYToSpawnEnum__ChaosNiagara_LocationYToSpawn_Max = 2,
    ELocationYToSpawnEnum__ChaosNiagara_LocationYToSpawn_MinMax = 3,
    ELocationYToSpawnEnum__ChaosNiagara_Max = 4
};

enum ELocationZToSpawnEnum : uint8_t
{
    ELocationZToSpawnEnum__ChaosNiagara_LocationZToSpawn_None = 0,
    ELocationZToSpawnEnum__ChaosNiagara_LocationZToSpawn_Min = 1,
    ELocationZToSpawnEnum__ChaosNiagara_LocationZToSpawn_Max = 2,
    ELocationZToSpawnEnum__ChaosNiagara_LocationZToSpawn_MinMax = 3,
    ELocationZToSpawnEnum__ChaosNiagara_Max = 4
};

enum EMediaPlateResourceType : uint8_t
{
    EMediaPlateResourceType__Playlist = 0,
    EMediaPlateResourceType__External = 1,
    EMediaPlateResourceType__Asset = 2
};

enum EMediaPlateEventState : uint8_t
{
    EMediaPlateEventState__Play = 0,
    EMediaPlateEventState__Open = 1,
    EMediaPlateEventState__Close = 2,
    EMediaPlateEventState__Pause = 3,
    EMediaPlateEventState__Reverse = 4,
    EMediaPlateEventState__Forward = 5,
    EMediaPlateEventState__Rewind = 6,
    EMediaPlateEventState__Next = 7,
    EMediaPlateEventState__Previous = 8
};

enum EOutputResourceName : uint8_t
{
    EOutputResourceName__Output = 0
};

enum ETemporalOutputResourceName : uint8_t
{
    ETemporalOutputResourceName__Outg_A = 0
};

enum EDenoiserRuntimeType : uint8_t
{
    CPU = 0,
    GPU = 1,
    RDG = 2
};

enum EExecutionMode : uint8_t
{
    SEQUENTIAL = 0,
    PARALLEL = 1
};

enum ECollectionScriptingShareType : uint8_t
{
    ECollectionScriptingShareType__Local = 0,
    ECollectionScriptingShareType__Private = 1,
    ECollectionScriptingShareType__Shared = 2
};

enum Tags_tag_search_sort_type : uint8_t
{
    Tags_tag_search_sort_type__Unsorted = 0,
    Tags_tag_search_sort_type__Sorted = 1
};

enum ControlInput_dead_zone_type : uint8_t
{
    ControlInput_dead_zone_type__Radial = 0,
    ControlInput_dead_zone_type__Axial = 1
};

enum ControlInput_swizzle_order : uint8_t
{
    ControlInput_swizzle_order__XZY = 0,
    ControlInput_swizzle_order__YXZ = 1,
    ControlInput_swizzle_order__YZX = 2,
    ControlInput_swizzle_order__ZYX = 3,
    ControlInput_swizzle_order__ZXY = 4
};

enum VerseWorldPartition_data_layer_runtime_state : uint8_t
{
    VerseWorldPartition_data_layer_runtime_state__Unloaded = 0,
    VerseWorldPartition_data_layer_runtime_state__Loaded = 1,
    VerseWorldPartition_data_layer_runtime_state__Activated = 2
};

enum Devices_CreativeAnimation_animation_controller_state : uint8_t
{
    Devices_CreativeAnimation_animation_controller_state__InvalidObject = 0,
    Devices_CreativeAnimation_animation_cont_x__U______bJ___f______M54T__ = 1,
    Devices_CreativeAnimation_animation_controller_state__Stopped = 2,
    Devices_CreativeAnimation_animation_controller_state__Playing = 3,
    Devices_CreativeAnimation_animation_controller_state__Paused = 4
};

enum Devices_CreativeAnimation_animation_mode : uint8_t
{
    Devices_CreativeAnimation_animation_mode__OneShot = 0,
    Devices_CreativeAnimation_animation_mode__PingPong = 1,
    Devices_CreativeAnimation_animation_mode__Loop = 2
};

enum Devices_CreativeAnimation_await_next_keyframe_result : uint8_t
{
    Devices_CreativeAnimation_await_next_keyframe_result__KeyframeReached = 0,
    Devices_CreativeAnimation_await_next_keyframe_result__NotPlaying = 1,
    Devices_CreativeAnimation_await_next_keyframe_result__AnimationAborted = 2
};

enum Devices_CreativeAnimation_get_animation_controller_result : uint8_t
{
    Devices_CreativeAnimation_get_animation_controller_result__Ok = 0,
    Devices_CreativeAnimation_get_animation_controller_result__UnknownError = 1,
    Devices_CreativeAnimation_get_animation_controller_result__InvalidObject = 2
};

enum Devices_CreativeAnimation_playstoppause_result : uint8_t
{
    Devices_CreativeAnimation_playstoppause_result__Ok = 0,
    Devices_CreativeAnimation_playstoppause_result__AnimationNotSet = 1,
    Devices_CreativeAnimation_playstoppause_result__InvalidObject = 2
};

enum Devices_CreativeAnimation_set_animation_result : uint8_t
{
    Devices_CreativeAnimation_set_animation_result__Ok = 0,
    Devices_CreativeAnimation_set_animation_result__UnknownError = 1,
    Devices_CreativeAnimation_set_animation_result__NoKeyframes = 2,
    Devices_CreativeAnimation_set_animation_result__LoopingAnimationDoesNotLoop = 3,
    Devices_CreativeAnimation_set_animation_result__KeyframeOutOfBounds = 4,
    Devices_CreativeAnimation_set_animation_result__InvalidLocation = 5,
    Devices_CreativeAnimation_set_animation_result__InvalidTime = 6,
    Devices_CreativeAnimation_set_animation_result__InvalidInterpolationParameters = 7,
    Devices_CreativeAnimation_set_animation_result__ScaleNotAllowed = 8,
    Devices_CreativeAnimation_set_animation_result__InvalidObject = 9
};

enum Devices_move_to_result : uint8_t
{
    Devices_move_to_result__Dn_______1__R_____ = 0,
    Devices_move_to_result__WillNotReachDestination = 1
};

enum dynamic_ui_anchor : uint8_t
{
    dynamic_ui_anchor__TopLeft = 0,
    dynamic_ui_anchor__TopCenter = 1,
    dynamic_ui_anchor__TopRight = 2,
    dynamic_ui_anchor__CenterLeft = 3,
    dynamic_ui_anchor__CenterCenter = 4,
    dynamic_ui_anchor__CenterRight = 5,
    dynamic_ui_anchor__BottomLeft = 6,
    dynamic_ui_anchor__BottomCenter = 7,
    dynamic_ui_anchor__BottomRight = 8
};

enum dynamic_ui_z_order : uint8_t
{
    dynamic_ui_z_order__Back = 0,
    dynamic_ui_z_order__Middle = 1,
    dynamic_ui_z_order__Front = 2,
    dynamic_ui_z_order__Custom = 3
};

enum E_UI_CTAButtonType : uint8_t
{
    E_UI_CTAButtonType__NewEnumerator0 = 0,
    E_UI_CTAButtonType__NewEnumerator1 = 1
};

enum E_UI_BackplateBrightness : uint8_t
{
    E_UI_BackplateBrightness__NewEnumerator0 = 0,
    E_UI_BackplateO____________________K_U_z = 1,
    E_UI_BackplateBrightness__NewEnumerator2 = 2,
    E_UI_BackplateBrightness__NewEnumerator3 = 3
};

enum E_UI_ButtonSize : uint8_t
{
    E_UI_ButtonSize__NewEnumerator0 = 0,
    E_UI_ButtonSize__NewEnumerator1 = 1,
    E_UI_ButtonSize__NewEnumerator2 = 2
};

enum E_UI_StatusIndicator_Size : uint8_t
{
    E_UI_StatusIndicator_Size__NewEnumerator2 = 0,
    E_UI_StatusIndicator_Size__NewEnumerator3 = 1
};

enum E_UI_StatusIndicator_Type : uint8_t
{
    E_UI_StatusIndicator_Type__NewEnumerator0 = 0,
    E_UI_StatusIndicator_Type__NewEnumerator2 = 1,
    E_UI_StatusIndicator_Type__NewEnumerator3 = 2,
    E_UI_StatusIndicator_Type__NewEnumerator4 = 3
};

enum E_UI_StatusIndicator_Configuration : uint8_t
{
    E_UI_StatusIndicator_Configuration__NewEnumerator0 = 0,
    E_UI_StatusIndicator_Configuration__NewEnumerator2 = 1,
    E_UI_StatusIndicator_Configuration__NewEnumerator3 = 2
};

enum E_UI_Alignment : uint8_t
{
    E_UI_Alignment__NewEnumerator0 = 0,
    E_UI_Alignment__NewEnumerator1 = 1,
    E_UI_Alignment__NewEnumerator2 = 2,
    E_UI_Alignment__NewEnumerator3 = 3
};

enum E_UI_BackplateCornerRadius : uint8_t
{
    E_UI_BackplateCornerRadius__NewEnumerator0 = 0,
    E_UI_BackplateCornerRadius__NewEnumerator1 = 1,
    E_UI_BackplateCornerRadius__NewEnumeI_____ = 2,
    E_UI_BackplateCornerRadius__NewEnumerator6 = 3,
    E_UI_BackplateCornerRadius__NewEnumerator4 = 4
};

enum Enum_NPC_TargetSlots : uint8_t
{
    Enum_NPC_TargetSlots__NewEnumerator0 = 0,
    Enum_NPC_TargetSlots__NewEnumerator1 = 1
};

enum Enum_NPC_AlertLevel : uint8_t
{
    Enum_NPC_AlertLevel__NewEnumerator4 = 0,
    Enum_NPC_AlertLevel__NewEnumerator0 = 1,
    Enum_NPC_AlertLevel__NewEnumerator1 = 2,
    Enum_NPC_AlertLevel__NewEnumerator2 = 3,
    Enum_NPC_AlertLevel__NewEnumerator3 = 4
};

enum PlayerWindParticleEmitters : uint8_t
{
    PlayerWindParticleEmitters__NewEnumerator0 = 0,
    PlayerWindParticleEmitters__NewEnumerator1 = 1,
    PlayerWindParticleEmitters__NewEnumerator3 = 2,
    PlayerWindParticleEmitters__NewEnumerator2 = 3
};

enum Enum_NPC_ModifyAlertLevelReason : uint8_t
{
    Enum_NPC_ModifyAlertLevelReason__NewEnumerator4 = 0,
    Enum_NPC_ModifyAlertLevelReason__NewEnumerator0 = 1,
    Enum_NPC_ModifyAlertLevelReason__NewEnumerator5 = 2
};

enum PreExplodeRampType : uint8_t
{
    PreExplodeRampType__NewEnumerator0 = 0,
    PreExplodeRampType__NewEnumerator1 = 1,
    PreExplodeRampType__NewEnumerator3 = 2,
    PreExplodeRampType__NewEnumerator2 = 3
};

enum EnumEventWorldItemDrop : uint8_t
{
    EnumEventWorldItemDrop__NewEnumerator0 = 0,
    EnumEventWorldItemDrop__NewEnumerator1 = 1,
    EnumEventWorldItemDrop__NewEnumerator2 = 2,
    EnumEventWorldItemDrop__NewEnumerator3 = 3
};

enum ECardinalDirection : uint8_t
{
    ECardinalDirection__NewEnumerator0 = 0,
    ECardinalDirection__NewEnumerator2 = 1,
    ECardinalDirection__NewEnumerator1 = 2,
    ECardinalDirection__NewEnumerator3 = 3
};

enum FluidDynamicForceMeshType : uint8_t
{
    FluidDynamicForceMeshType__NewEnumerator0 = 0,
    FluidDynamicForceMeshType__NewEnumerator1 = 1
};

enum FluidBoundary : uint8_t
{
    FluidBoundary__NewEnumerator0 = 0,
    FluidBoundary__NewEnumerator1 = 1
};

enum EIntTypes : uint8_t
{
    EIntTypes__NewEnumerator4 = 0,
    EIntTypes__NewEnumerator5 = 1,
    EIntTypes__NewEnumerator6 = 2,
    EIntTypes__NewEnumerator7 = 3
};

enum Enum_BoostJumpStates : uint8_t
{
    Enum_BoostJumpStates__NewEnumerator3 = 0,
    Enum_BoostJumpStates__NewEnumerator0 = 1,
    Enum_BoostJumpStates__NewEnumerator1 = 2,
    Enum_BoostJumpStates__NewEnumerator2 = 3,
    Enum_BoostJumpStates__NewEnumerator4 = 4
};

enum BlueprintLogLevel : uint8_t
{
    BlueprintLogLevel__NewEnumerator0 = 0,
    BlueprintLogLevel__NewEnumerator1 = 1,
    BlueprintLogLevel__NewEnumerator2 = 2,
    BlueprintLogLevel__NewEnumerator3 = 3,
    BlueprintLogLevel__NewEnumerator4 = 4,
    BlueprintLogLevel__NewEnumerator5 = 5
};

enum E_UI_DialogTextType : uint8_t
{
    E_UI_DialogTextType__NewEnumerator0 = 0,
    E_UI_DialogTextType__NewEnumerator1 = 1,
    E_UI_DialogTextType__NewEnumerator2 = 2
};

enum E_UI_ButtonVisualType : uint8_t
{
    E_UI_ButtonVisualType__NewEnumerator0 = 0,
    E_UI_ButtonVisualType__NewEnumerator1 = 1,
    E_UI_ButtonVisualType__NewEnumerator2 = 2
};

enum E_UI_InputField_State : uint8_t
{
    E_UI_InputField_State__NewEnumerator0 = 0,
    E_UI_InputField_State__NewEnumerator1 = 1,
    E_UI_InputField_State__NewEnumerator2 = 2
};

enum E_UI_InputField_ContentSize : uint8_t
{
    E_UI_InputField_ContentSize__NewEnumerator0 = 0,
    E_UI_InputField_ContentSize__NewEnumerator1 = 1,
    E_UI_InputField_ContentSize__NewEnumerator2 = 2
};

enum E_PositiveNegativeNeutral : uint8_t
{
    E_PositiveNegativeNeutral__NewEnumerator0 = 0,
    E_PositiveNegativeNeutral__NewEnumerator1 = 1,
    E_PositiveNegativeNeutral__NewEnumerator2 = 2
};

enum E_UI_TagSize : uint8_t
{
    E_UI_TagSize__NewEnumerator0 = 0,
    E_UI_TagSize__NewEnumerator1 = 1
};

enum E_UI_TagType : uint8_t
{
    E_UI_TagType__NewEnumerator0 = 0,
    E_UI_TagType__NewEnumerator1 = 1,
    E_UI_TagType__NewEnumerator2 = 2,
    E_UI_TagType__NewEnumerator3 = 3
};

enum E_UI_ThrobberType : uint8_t
{
    E_UI_ThrobberType__NewEnumerator0 = 0
};

enum E_UI_ThrobberSize : uint8_t
{
    E_UI_ThrobberSize__NewEnumerator0 = 0,
    E_UI_ThrobberSize__NewEnumerator1 = 1,
    E_UI_ThrobberSize__NewEnumerator2 = 2
};

enum E_UI_BadgeSize : uint8_t
{
    E_UI_BadgeSize__NewEnumerator0 = 0,
    E_UI_BadgeSize__NewEnumerator1 = 1
};

enum E_UI_BadgeType : uint8_t
{
    E_UI_BadgeType__NewEnumerator0 = 0,
    E_UI_BadgeType__NewEnumerator1 = 1
};

enum E_UI_BadgeIndicatorType : uint8_t
{
    E_UI_BadgeIndicatorType__NewEnumerator3 = 0,
    E_UI_BadgeIndicatorType__NewEnumerator0 = 1,
    E_UI_BadgeIndicatorType__NewEnumerator1 = 2
};

enum ECreativeColorSetType : uint8_t
{
    ECreativeColorSetType__NewEnumerator0 = 0,
    ECreativeColorSetType__NewEnumerator1 = 1,
    ECreativeColorSetType__NewEnumerator2 = 2,
    ECreativeColorSetType__NewEnumerator3 = 3
};

enum EAwardScoreType : uint8_t
{
    EAwardScoreType__NewEnumerator0 = 0,
    EAwardScoreType__NewEnumerator1 = 1,
    EAwardScoreType__NewEnumerator2 = 2,
    EAwardScoreType__NewEnumerator3 = 3
};

enum ECreativeTeamColor : uint8_t
{
    ECreativeTeamColor__NewEnumerator0 = 0,
    ECreativeTeamColor__NewEnumerator1 = 1,
    ECreativF____w___________a__q__k_e = 2,
    ECreativeTeamColor__NewEnumerator3 = 3,
    ECreativeTeamColor__NewEnumerator4 = 4,
    ECreativeTeamColor__NewEnumerator5 = 5,
    ECreativeTeamColor__NewEnumerator6 = 6,
    ECreativeTeamColor__NewEnumerator7 = 7,
    ECreativeTeamColor__NewEnumerator8 = 8,
    ECreativeTeamColor__NewEnumerator9 = 9,
    ECreativeTeamColor__NewEnumerator10 = 10,
    ECreativeTeamColor__NewEnumerator11 = 11
};

enum EBoolWithUnset : uint8_t
{
    EBoolWithUnset__NewEnumerator0 = 0,
    EBoolWithUnset__NewEnumerator1 = 1,
    EBoolWithUnset__NewEnumerator2 = 2
};

enum SocialNudgeFocusState : uint8_t
{
    SocialNudgeFocusState__NewEnumerator0 = 0,
    SocialNudgeFocusState__NewEnumerator1 = 1,
    SocialNudgeFocusState__NewEnumerator2 = 2
};

enum ENameplateVoiceState : uint8_t
{
    ENameplateVoiceState__NewEnumerator0 = 0,
    ENameplateVoiceState__NewEnumerator1 = 1,
    ENameplateVoiceState__NewEnumerator2 = 2
};

enum PhysicsLogAnalytics_DamageCategory : uint8_t
{
    PhysicsLogAnalytics_DamageCategory__NewEnumerator0 = 0,
    PhysicsLogAnalytics_DamageCategory__NewEnumerator1 = 1,
    PhysicsLogAnalytics_DamageCategory__NewEnumerator2 = 2,
    PhysicsLogAnalytics_DamageCategory__NewEnumerator3 = 3
};

enum E_UI_TabsInputActionType : uint8_t
{
    E_UI_TabsInputActionType__NewEnumerator2 = 0,
    E_UI_TabsInputActionType__NewEnumerator0 = 1,
    E_UI_TabsInputActionType__NewEnumerator1 = 2,
    E_UI_TabsInputActionType__NewEnumerator3 = 3
};

enum MinigameButtonsState : uint8_t
{
    MinigameButtonsState__NewEnumerator6 = 0,
    MinigameButtonsState__NewEnumerator0 = 1,
    MinigameButtonsState__NewEnumerator1 = 2,
    MinigameButtonsState__NewEnumerator2 = 3,
    MinigameButtonsState__NewEnumerator3 = 4,
    MinigameButtonsState__NewEnumerator4 = 5,
    MinigameButtonsState__NewEnumerator5 = 6
};

enum E_UI_StepWizard_Type : uint8_t
{
    E_UI_StepWizard_Type__NewEnumerator0 = 0,
    E_UI_StepWizard_Type__NewEnumerator1 = 1,
    E_UI_StepWizard_Type__NewEnumerator2 = 2
};

enum E_UI_DirectionLeftRightNone : uint8_t
{
    E_UI_DirectionLeftRightNone__NewEnumerator0 = 0,
    E_UI_DirectionLeftRightNone__NewEnumerator1 = 1,
    E_UI_DirectionLeftRightNone__NewEnumerator2 = 2
};

enum E_UI_OutBoardPosition : uint8_t
{
    E_UI_OutBoardPosition__NewEnumerator3 = 0,
    E_UIO______U4_O_______Z_U = 1,
    E_UI_OutBoardPosition__NewEnumerator1 = 2,
    E_UI_OutBoardPosition__NewEnumerator2 = 3,
    E_UI_OutBoardPosition__NewEnumerator4 = 4,
    E_UI_OutBoardPosition__NewEnumerator5 = 5,
    E_UI_OutBoardPosition__NewEnumerator6 = 6,
    E_UI_OutBoardPosition__NewEnumerator7 = 7,
    E_UI_OutBoardPosition__NewEnumerator8 = 8,
    E_UI_OutBoardPosition__NewEnumerator9 = 9,
    E_UI_OutBoardPosition__NewEnumerator10 = 10,
    E_UI_OutBoardPosition__NewEnumerator11 = 11,
    E_UI_OutBoardPosition__NewEnumerator12 = 12
};

enum PlayerWaterDepthEnum : uint8_t
{
    PlayerWaterDepthEnum__NewEnumerator5 = 0,
    PlayerWaterDepthEnum__NewEnumerator4 = 1,
    PlayerWaterDepthEnum__NewEnumerator3 = 2,
    PlayerWaterDepthEnum__NewEnumerator2 = 3,
    PlayerWaterDepthEnum__NewEnumerator1 = 4
};

enum ENiagara_CurieAudioType : uint8_t
{
    ENiagara_CurieAudioType__NewEnumerator0 = 0,
    ENiagara_CurieAudioType__NewEnumerator1 = 1,
    ENiagara_CurieAudioType__NewEnumerator2 = 2,
    ENiagara_CurieAudioType__NewEnumerator3 = 3
};

enum ENiagara_CurieVoxelFireType : uint8_t
{
    ENiagara_CurieVoxelFireType__NewEnumerator0 = 0,
    ENiagara_CurieVoxelFireType__NewEnumerator1 = 1,
    ENiagara_CurieVoxelFireType_PS_z___________ = 2,
    ENiagara_CurieVoxelFireType__NewEnumerator3 = 3
};

enum E_FirePetal_ExtraTeamIndicators : uint8_t
{
    E_FirePetal_ExtraTeamIndicators__NewEnumerator0 = 0,
    E_FirePetal_ExtraTeamIndicators__NewEnumerator1 = 1
};

enum E_UIKit_StatusIndicatorPlacement : uint8_t
{
    E_UIKit_StatusIndicatorPlacement__NewEnumerator0 = 0,
    E_UIKit_StatusIndicatorPlacement__NewEnumerator1 = 1,
    E_UIKit_StatusIndicatorPlacement__NewEnumerator2 = 2
};

enum E_UIKit_ItemCardStatusIndicator : uint8_t
{
    E_UIKit_ItemCardStatusIndicator__NewEnumerator0 = 0,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator1 = 1,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator2 = 2,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator3 = 3,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator4 = 4,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator5 = 5,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator6 = 6,
    E_UIKit_ItemCardStatusIndicator__NewEnumerator7 = 7
};

enum E_UIKit_ItemDescription_TextWrapType : uint8_t
{
    E_UIKit_ItemDescription_TextWrapType__NewEnumerator0 = 0,
    E_UIKit_ItemDescription_TextWrapType__NewEnumerator1 = 1,
    E_UIKit_ItemDescription_TextWrapType__NewEnumerator2 = 2
};

enum E_UI_HighlightType : uint8_t
{
    E_UI_HighlightType__NewEnumerator3 = 0,
    E_UI_HighlightType__NewEnumerator0 = 1,
    E_UI_HighlightType__NewEnumerator1 = 2,
    E_UI_HighlightType__NewEnumerator4 = 3,
    E_UI_HighlightType__NewEnumerator5 = 4,
    E_UI_HighlightType__NewEnumerator6 = 5
};

enum E_UI_HighlightSize : uint8_t
{
    E_UI_HighlightSize__NewEnumerator0 = 0,
    E_UI_HighlightSize__NewEnumerator1 = 1
};

enum E_UI_ToggleType : uint8_t
{
    E_UI_ToggleType__NewEnumerator0 = 0,
    E_UI_ToggleType__NewEnumerator1 = 1,
    E_UI_ToggleType__NewEnumerator2 = 2
};

enum ENUM_NiagaraParameterSetup : uint8_t
{
    ENUM_NiagaraParameterSetup__NewEnumerator0 = 0,
    ENUM_NiagaraParameterSetup__NewEnumerator1 = 1,
    ENUM_NiagaraParameterSetup__NewEnumerator2 = 2,
    ENUM_NiagaraParameterSetup__NewEnumerator3 = 3
};

enum En_ShellTypes_01 : uint8_t
{
    En_ShellTypes_01__NewEnumerator0 = 0,
    En_ShellTypes_01__NewEnumerator1 = 1,
    En_ShellTypes_01__NewEnumerator2 = 2,
    En_ShellTypes_01__NewEnumerator3 = 3,
    En_ShellTypes_01__NewEnumerator4 = 4
};

enum EUI_Lobby_PlayButton_State : uint8_t
{
    EUI_Lobby_PlayButton_State__NewEnumerator1 = 0,
    EUI_Lobby_PlayButton_State__NewEnumerator2 = 1,
    EUI_Lobby_PlayButton_State__NewEnumerator3 = 2,
    EUI_Lobby_PlayButton_State__NewEnumerator4 = 3,
    EUI_Lobby_PlayButton_State__NewEnumerator5 = 4,
    EUI_Lobby_PlayButton_State__NewEnumerator6 = 5
};

enum E_BladeUIAnchor : uint8_t
{
    E_BladeUIAnchor__NewEnumerator0 = 0,
    E_BladeUIAnchor__NewEnumerator1 = 1,
    E_BladeUIAnchor__NewEnumerator2 = 2,
    E_BladeUIAnchor__NewEnumerator3 = 3
};

enum E_BladeAnimationState : uint8_t
{
    E_BladeAnimationState__NewEnumerator0 = 0,
    E_BladeAnimationState__NewEnumerator1 = 1,
    E_BladeAnimationState__NewEnumerator2 = 2,
    E_BladeAnimationState__NewEnumerator4 = 3
};

enum ERequesterType : uint8_t
{
    ERequesterType__NewEnumerator0 = 0,
    ERequesterType__NewEnumerator1 = 1
};

enum E_PriceSwitcherState : uint8_t
{
    E_PriceSwitcherState__NewEnumerator0 = 0,
    E_PriceSwitcherState__NewEnumerator1 = 1,
    E_PriceSwitcherState__NewEnumerator2 = 2
};

enum ESeasonPassCategory_ButtonSwitcher : uint8_t
{
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator0 = 0,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator1 = 1,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator2 = 2,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator3 = 3,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator4 = 4,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator5 = 5,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator6 = 6,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator7 = 7,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator8 = 8,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator9 = 9,
    ESeasonPassCategory_ButtonSwitcher__NewEnumerator10 = 10
};

enum E_VariantConflictType : uint8_t
{
    E_VariantConflictType__NewEnumerator6 = 0,
    E_VariantConflictType__NewEnumerator4 = 1,
    E_VariantConflictType__NewEnumerator3 = 2,
    E_VariantConflictType__NewEnumerator5 = 3,
    E_VariantConflictType__NewEnumerator1 = 4,
    E_VariantConflictType__NewEnumerator2 = 5,
    E_VariantConflictType__NewEnumerator0 = 6
};

enum ELockerTileSize : uint8_t
{
    ELockerTileSize__NewEnumerator0 = 0,
    ELockerTileSize__NewEnumerator1 = 1,
    ELockerTileSize__NewEnumerator3 = 2,
    ELockerTileSize__NewEnumerator2 = 3,
    ELockerTileSize__NewEnumerator4 = 4,
    ELockerTileSize__NewEnumerator5 = 5
};

enum ELockerScreenList : uint8_t
{
    ELockerScreenList__NewEnumerator0 = 0,
    ELockerScreenList__NewEnumerator1 = 1,
    ELockerScreenList__NewEnumerator2 = 2,
    ELockerScreenList__NewEnumerator3 = 3,
    ELockerScreenList__NewEnumerator4 = 4,
    ELockerScreenList__NewEnumerator5 = 5
};

// Dumped By Stern