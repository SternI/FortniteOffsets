/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioSynesthesia
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
// Size: 0x28
class UAudioSynesthesiaSettings : public UAudioAnalyzerSettings
{
public:
};

// Size: 0x28
class UAudioSynesthesiaNRTSettings : public UAudioAnalyzerNRTSettings
{
public:
};

// Size: 0x78
class UAudioSynesthesiaNRT : public UAudioAnalyzerNRT
{
public:
};

// Size: 0x48
class UConstantQSettings : public UAudioSynesthesiaSettings
{
public:
    float StartingFrequencyHz() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    int32_t NumBands() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    float NumBandsPerOctave() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float AnalysisPeriodInSeconds() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bDownmixToMono() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t FFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t WindowType() const { return Read<uint8_t>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: EnumProperty)
    uint8_t SpectrumType() const { return Read<uint8_t>(uintptr_t(this) + 0x3b); } // 0x3b (Size: 0x1, Type: EnumProperty)
    float BandWidthStretch() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t CQTNormalization() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    float NoiseFloorDb() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)

    void SET_StartingFrequencyHz(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_NumBands(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_NumBandsPerOctave(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_AnalysisPeriodInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_bDownmixToMono(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_FFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: EnumProperty)
    void SET_WindowType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: EnumProperty)
    void SET_SpectrumType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3b, Value); } // 0x3b (Size: 0x1, Type: EnumProperty)
    void SET_BandWidthStretch(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_CQTNormalization(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_NoiseFloorDb(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf8
class UConstantQAnalyzer : public UAudioAnalyzer
{
public:
    UConstantQSettings* Settings() const { return Read<UConstantQSettings*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const UConstantQSettings*& Value) { Write<UConstantQSettings*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UConstantQNRTSettings : public UAudioSynesthesiaNRTSettings
{
public:
    float StartingFrequency() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    int32_t NumBands() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    float NumBandsPerOctave() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float AnalysisPeriod() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bDownmixToMono() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t FFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t WindowType() const { return Read<uint8_t>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: EnumProperty)
    uint8_t SpectrumType() const { return Read<uint8_t>(uintptr_t(this) + 0x3b); } // 0x3b (Size: 0x1, Type: EnumProperty)
    float BandWidthStretch() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t CQTNormalization() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    float NoiseFloorDb() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)

    void SET_StartingFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_NumBands(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_NumBandsPerOctave(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_AnalysisPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_bDownmixToMono(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_FFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: EnumProperty)
    void SET_WindowType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: EnumProperty)
    void SET_SpectrumType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3b, Value); } // 0x3b (Size: 0x1, Type: EnumProperty)
    void SET_BandWidthStretch(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_CQTNormalization(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_NoiseFloorDb(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
class UConstantQNRT : public UAudioSynesthesiaNRT
{
public:
    UConstantQNRTSettings* Settings() const { return Read<UConstantQNRTSettings*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const UConstantQNRTSettings*& Value) { Write<UConstantQNRTSettings*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class ULoudnessSettings : public UAudioSynesthesiaSettings
{
public:
    float AnalysisPeriod() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumFrequency() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumFrequency() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t CurveType() const { return Read<uint8_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: EnumProperty)
    float NoiseFloorDb() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float ExpectedMaxLoudness() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_AnalysisPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_MaximumFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_CurveType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: EnumProperty)
    void SET_NoiseFloorDb(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_ExpectedMaxLoudness(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe8
class ULoudnessAnalyzer : public UAudioAnalyzer
{
public:
    ULoudnessSettings* Settings() const { return Read<ULoudnessSettings*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const ULoudnessSettings*& Value) { Write<ULoudnessSettings*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class ULoudnessNRTSettings : public UAudioSynesthesiaNRTSettings
{
public:
    float AnalysisPeriod() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumFrequency() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumFrequency() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t CurveType() const { return Read<uint8_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: EnumProperty)
    float NoiseFloorDb() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_AnalysisPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_MaximumFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_CurveType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: EnumProperty)
    void SET_NoiseFloorDb(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
class ULoudnessNRT : public UAudioSynesthesiaNRT
{
public:
    ULoudnessNRTSettings* Settings() const { return Read<ULoudnessNRTSettings*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const ULoudnessNRTSettings*& Value) { Write<ULoudnessNRTSettings*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UMeterSettings : public UAudioSynesthesiaSettings
{
public:
    float AnalysisPeriod() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t PeakMode() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)
    int32_t MeterAttackTime() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t MeterReleaseTime() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    int32_t PeakHoldTime() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    float ClippingThreshold() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_AnalysisPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_PeakMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
    void SET_MeterAttackTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_MeterReleaseTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_PeakHoldTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_ClippingThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x148
class UMeterAnalyzer : public UAudioAnalyzer
{
public:
    UMeterSettings* Settings() const { return Read<UMeterSettings*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const UMeterSettings*& Value) { Write<UMeterSettings*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UOnsetNRTSettings : public UAudioSynesthesiaNRTSettings
{
public:
    bool bDownmixToMono() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    float GranularityInSeconds() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float Sensitivity() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float MinimumFrequency() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float MaximumFrequency() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_bDownmixToMono(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_GranularityInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_Sensitivity(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
class UOnsetNRT : public UAudioSynesthesiaNRT
{
public:
    UOnsetNRTSettings* Settings() const { return Read<UOnsetNRTSettings*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const UOnsetNRTSettings*& Value) { Write<UOnsetNRTSettings*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class USynesthesiaSpectrumAnalysisSettings : public UAudioSynesthesiaSettings
{
public:
    float AnalysisPeriod() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t FFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t SpectrumType() const { return Read<uint8_t>(uintptr_t(this) + 0x2d); } // 0x2d (Size: 0x1, Type: EnumProperty)
    uint8_t WindowType() const { return Read<uint8_t>(uintptr_t(this) + 0x2e); } // 0x2e (Size: 0x1, Type: EnumProperty)
    bool bDownmixToMono() const { return Read<bool>(uintptr_t(this) + 0x2f); } // 0x2f (Size: 0x1, Type: BoolProperty)

    void SET_AnalysisPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_FFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
    void SET_SpectrumType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2d, Value); } // 0x2d (Size: 0x1, Type: EnumProperty)
    void SET_WindowType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2e, Value); } // 0x2e (Size: 0x1, Type: EnumProperty)
    void SET_bDownmixToMono(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f, Value); } // 0x2f (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf8
class USynesthesiaSpectrumAnalyzer : public UAudioAnalyzer
{
public:
    USynesthesiaSpectrumAnalysisSettings* Settings() const { return Read<USynesthesiaSpectrumAnalysisSettings*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const USynesthesiaSpectrumAnalysisSettings*& Value) { Write<USynesthesiaSpectrumAnalysisSettings*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FConstantQResults
{
public:
    float TimeSeconds() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<float> SpectrumValues() const { return Read<TArray<float>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_TimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SpectrumValues(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FLoudnessResults
{
public:
    float Loudness() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float NormalizedLoudness() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float PerceptualEnergy() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float TimeSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_Loudness(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_NormalizedLoudness(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_PerceptualEnergy(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_TimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x14
struct FMeterResults
{
public:
    float TimeSeconds() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MeterValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float PeakValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t NumSamplesClipping() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    float ClippingValue() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_TimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MeterValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_PeakValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_NumSamplesClipping(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_ClippingValue(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FSynesthesiaSpectrumResults
{
public:
    float TimeSeconds() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<float> SpectrumValues() const { return Read<TArray<float>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_TimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SpectrumValues(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

