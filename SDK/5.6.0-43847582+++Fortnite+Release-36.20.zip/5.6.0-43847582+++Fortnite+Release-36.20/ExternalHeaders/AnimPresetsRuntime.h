/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimPresetsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0xd8
class UAnimPresetComponent : public UActorComponent
{
public:
};

// Size: 0x78
class UAnimPreset_BasicLocomotion : public UAnimPreset
{
public:
    FAnimPreset_SingleAnimationData Idle() const { return Read<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveForward() const { return Read<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveBackward() const { return Read<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveLeft() const { return Read<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveRight() const { return Read<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)

    void SET_Idle(const FAnimPreset_SingleAnimationData& Value) { Write<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_MoveForward(const FAnimPreset_SingleAnimationData& Value) { Write<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_MoveBackward(const FAnimPreset_SingleAnimationData& Value) { Write<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_MoveLeft(const FAnimPreset_SingleAnimationData& Value) { Write<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_MoveRight(const FAnimPreset_SingleAnimationData& Value) { Write<FAnimPreset_SingleAnimationData>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
class UGameFeatureAction_AnimPreset : public UGameFeatureAction
{
public:
};

// Size: 0x10
struct FAnimPreset_SingleAnimationData
{
public:
    UAnimSequence* Animation() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Animation(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

