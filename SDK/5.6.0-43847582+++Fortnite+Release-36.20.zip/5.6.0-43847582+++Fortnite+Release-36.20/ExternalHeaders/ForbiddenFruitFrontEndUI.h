/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ForbiddenFruitFrontEndUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x70
class UForbiddenFruitLobbyWidgetVM : public UMVVMViewModelBase
{
public:
    bool bIsForbiddenFruitIsland() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_bIsForbiddenFruitIsland(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

