/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CorruptionGameplayCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "SOMRuntime.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "MeshNetwork.h"
#include "GameplayAbilities.h"

// Size: 0x28
class UWarEffortFundingLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x90
class UCorruptionCoverageMap : public UObject
{
public:
};

// Size: 0x50
class UFortCorruptionSequenceData : public UPrimaryDataAsset
{
public:
    TArray<FCorruptionCalendarEventData> CorruptionStartEvents() const { return Read<TArray<FCorruptionCalendarEventData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCorruptionPauseEvent> CorruptionPauseEvents() const { return Read<TArray<FCorruptionPauseEvent>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_CorruptionStartEvents(const TArray<FCorruptionCalendarEventData>& Value) { Write<TArray<FCorruptionCalendarEventData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_CorruptionPauseEvents(const TArray<FCorruptionPauseEvent>& Value) { Write<TArray<FCorruptionPauseEvent>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x530
class ACubeMovementStaticPath : public AScriptedObjectMovement_StaticPath
{
public:
    float GenerationZTraceHeight() const { return Read<float>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x4, Type: FloatProperty)
    float CubeSpacingFactor() const { return Read<float>(uintptr_t(this) + 0x4fc); } // 0x4fc (Size: 0x4, Type: FloatProperty)
    float CubeAngleLimitDegrees() const { return Read<float>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x4, Type: FloatProperty)
    UFortCorruptionSequenceData* CorruptionSequence() const { return Read<UFortCorruptionSequenceData*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    TArray<FTravelerStepCorruptionOverrideData> TravelerCorruptionStepPercentOverrides() const { return Read<TArray<FTravelerStepCorruptionOverrideData>>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x10, Type: ArrayProperty)

    void SET_GenerationZTraceHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x4, Type: FloatProperty)
    void SET_CubeSpacingFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x4fc, Value); } // 0x4fc (Size: 0x4, Type: FloatProperty)
    void SET_CubeAngleLimitDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x4, Type: FloatProperty)
    void SET_CorruptionSequence(const UFortCorruptionSequenceData*& Value) { Write<UFortCorruptionSequenceData*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_TravelerCorruptionStepPercentOverrides(const TArray<FTravelerStepCorruptionOverrideData>& Value) { Write<TArray<FTravelerStepCorruptionOverrideData>>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x518
class AFortAthenaMutator_WarEffort : public AFortAthenaMutator_GameModeBase
{
public:
    FWarEffortMutatorMetadata MeshNetworkMetadata() const { return Read<FWarEffortMutatorMetadata>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x20, Type: StructProperty)
    TArray<FWarEffortMutatorChoiceData> WeaponChoices() const { return Read<TArray<FWarEffortMutatorChoiceData>>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x10, Type: ArrayProperty)
    TArray<FPrimaryAssetId> PreloadedItemList() const { return Read<TArray<FPrimaryAssetId>>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x10, Type: ArrayProperty)
    bool bCanPreloadItems() const { return Read<bool>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x1, Type: BoolProperty)

    void SET_MeshNetworkMetadata(const FWarEffortMutatorMetadata& Value) { Write<FWarEffortMutatorMetadata>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x20, Type: StructProperty)
    void SET_WeaponChoices(const TArray<FWarEffortMutatorChoiceData>& Value) { Write<TArray<FWarEffortMutatorChoiceData>>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x10, Type: ArrayProperty)
    void SET_PreloadedItemList(const TArray<FPrimaryAssetId>& Value) { Write<TArray<FPrimaryAssetId>>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x10, Type: ArrayProperty)
    void SET_bCanPreloadItems(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x330
class AWarEffortMeshActor : public AInfo
{
public:
    UMeshNetworkComponent* MeshNetworkComponent() const { return Read<UMeshNetworkComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayTag> ActiveFundedItems() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTag> ActiveTryBeforeYouBuyItems() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<FWarEffortFundingData> CurrentFundingData() const { return Read<TArray<FWarEffortFundingData>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)

    void SET_MeshNetworkComponent(const UMeshNetworkComponent*& Value) { Write<UMeshNetworkComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveFundedItems(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveTryBeforeYouBuyItems(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentFundingData(const TArray<FWarEffortFundingData>& Value) { Write<TArray<FWarEffortFundingData>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FWarEffortFundingOptionData
{
public:
    FGameplayTag OptionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int64_t CurrentFundingAmount() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)

    void SET_OptionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_CurrentFundingAmount(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
};

// Size: 0x28
struct FWarEffortFundingChoiceData
{
public:
    FWarEffortFundingOptionData Option1() const { return Read<FWarEffortFundingOptionData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FWarEffortFundingOptionData Option2() const { return Read<FWarEffortFundingOptionData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    int64_t TargetFundingAmount() const { return Read<int64_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: Int64Property)

    void SET_Option1(const FWarEffortFundingOptionData& Value) { Write<FWarEffortFundingOptionData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Option2(const FWarEffortFundingOptionData& Value) { Write<FWarEffortFundingOptionData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_TargetFundingAmount(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: Int64Property)
};

// Size: 0x20
struct FWarEffortIndexedFundingData
{
public:
    TArray<int64_t> CurrentFundingArray() const { return Read<TArray<int64_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int64_t FinalFundingAmount() const { return Read<int64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: Int64Property)
    int64_t TowerFundingAmount() const { return Read<int64_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: Int64Property)

    void SET_CurrentFundingArray(const TArray<int64_t>& Value) { Write<TArray<int64_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_FinalFundingAmount(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: Int64Property)
    void SET_TowerFundingAmount(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: Int64Property)
};

// Size: 0x30
struct FWarEffortFundingMetadata : public FMeshMetaDataStruct
{
public:
    FWarEffortIndexedFundingData IndexedFundingData() const { return Read<FWarEffortIndexedFundingData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<FWarEffortFundingChoiceData> FundingChoices() const { return Read<TArray<FWarEffortFundingChoiceData>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_IndexedFundingData(const FWarEffortIndexedFundingData& Value) { Write<FWarEffortIndexedFundingData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_FundingChoices(const TArray<FWarEffortFundingChoiceData>& Value) { Write<TArray<FWarEffortFundingChoiceData>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FCubeMovement_CorruptionGenerationSplinePointData
{
public:
    FTransform SplinePointTransform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    float SplinePercentComplete() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)

    void SET_SplinePointTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_SplinePercentComplete(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FCubeMovement_CorruptionGenerationTravelerData
{
public:
    TArray<FCubeMovement_CorruptionGenerationSplinePointData> SplinePointData() const { return Read<TArray<FCubeMovement_CorruptionGenerationSplinePointData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    AFortScriptedObjectMovement_MovableObjectBase* PathTraveler() const { return Read<AFortScriptedObjectMovement_MovableObjectBase*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_SplinePointData(const TArray<FCubeMovement_CorruptionGenerationSplinePointData>& Value) { Write<TArray<FCubeMovement_CorruptionGenerationSplinePointData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PathTraveler(const AFortScriptedObjectMovement_MovableObjectBase*& Value) { Write<AFortScriptedObjectMovement_MovableObjectBase*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FCubeMovement_CorruptionGenerationData
{
public:
    TArray<FCubeMovement_CorruptionGenerationTravelerData> TravelerData() const { return Read<TArray<FCubeMovement_CorruptionGenerationTravelerData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_TravelerData(const TArray<FCubeMovement_CorruptionGenerationTravelerData>& Value) { Write<TArray<FCubeMovement_CorruptionGenerationTravelerData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FCorruptionCalendarEventData
{
public:
    FString EventName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    float StartPercent() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_EventName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_StartPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FCorruptionPauseEvent
{
public:
    FString EventName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    float PercentDurationToPause() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_EventName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_PercentDurationToPause(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FTravelerStepCorruptionOverrideData
{
public:
    TMap<FString, float> PointGroupStepPercentOverrides() const { return Read<TMap<FString, float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_PointGroupStepPercentOverrides(const TMap<FString, float>& Value) { Write<TMap<FString, float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x68
struct FWarEffortMutatorChoiceData
{
public:
    FGameplayTag FundingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<TSoftObjectPtr<UFortItemDefinition*>> SoftRefsToLoad() const { return Read<TArray<TSoftObjectPtr<UFortItemDefinition*>>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FScalableFloat> LootTableMods() const { return Read<TMap<FName, FScalableFloat>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x50, Type: MapProperty)

    void SET_FundingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_SoftRefsToLoad(const TArray<TSoftObjectPtr<UFortItemDefinition*>>& Value) { Write<TArray<TSoftObjectPtr<UFortItemDefinition*>>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_LootTableMods(const TMap<FName, FScalableFloat>& Value) { Write<TMap<FName, FScalableFloat>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x50, Type: MapProperty)
};

// Size: 0x20
struct FWarEffortMutatorMetadata : public FMeshMetaDataStruct
{
public:
    TArray<FGameplayTag> ActiveFundedItems() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTag> ActiveTryBeforeYouBuyItems() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ActiveFundedItems(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveTryBeforeYouBuyItems(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FWarEffortFundingData
{
public:
    FGameplayTag FundingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float FundedPercent() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_FundingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_FundedPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

