/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortSoundCueTemplates
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x578
class UEmoteBase : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x578
class UFortSoundCueTemplateBase : public USoundCueTemplate
{
public:
};

// Size: 0x578
class UEmoteFoley : public UEmoteBase
{
public:
};

// Size: 0x578
class UEmoteMusic : public UEmoteBase
{
public:
};

// Size: 0x578
class UEmoteMusic3P : public UEmoteBase
{
public:
};

// Size: 0x578
class UFootstepFoley : public UPlayerFoley
{
public:
};

// Size: 0x578
class UPlayerFoley : public UPlayerFoleyBase
{
public:
};

// Size: 0x578
class UPlayerFoleyBase : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x90
class UFortSoundCueTemplateDefaults : public UDataAsset
{
public:
    USoundClass* SoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* Attenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    USoundConcurrency* Concurrency() const { return Read<USoundConcurrency*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    float VolumeMultiplier() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float PitchMultiplier() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    TArray<FFortSubmixPair> SubmixSends() const { return Read<TArray<FFortSubmixPair>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortBusPair> PreEffectBusSends() const { return Read<TArray<FFortBusPair>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortBusPair> PostEffectBusSends() const { return Read<TArray<FFortBusPair>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    USoundWave* LicensedTrackAlternative() const { return Read<USoundWave*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* LicensedSubmix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)

    void SET_SoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_Attenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_Concurrency(const USoundConcurrency*& Value) { Write<USoundConcurrency*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_VolumeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_PitchMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_SubmixSends(const TArray<FFortSubmixPair>& Value) { Write<TArray<FFortSubmixPair>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_PreEffectBusSends(const TArray<FFortBusPair>& Value) { Write<TArray<FFortBusPair>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_PostEffectBusSends(const TArray<FFortBusPair>& Value) { Write<TArray<FFortBusPair>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_LicensedTrackAlternative(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_LicensedSubmix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x80
class UFortSoundCueTemplateDefaultSettings : public UDataAsset
{
public:
    TMap<UClass*, UFortSoundCueTemplateDefaults*> TemplateDefaults() const { return Read<TMap<UClass*, UFortSoundCueTemplateDefaults*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_TemplateDefaults(const TMap<UClass*, UFortSoundCueTemplateDefaults*>& Value) { Write<TMap<UClass*, UFortSoundCueTemplateDefaults*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
class UFortSoundCueTemplateSettings : public UDeveloperSettings
{
public:
    TSoftObjectPtr<UFortSoundCueTemplateDefaultSettings> DefaultTemplateSettings() const { return Read<TSoftObjectPtr<UFortSoundCueTemplateDefaultSettings>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)

    void SET_DefaultTemplateSettings(const TSoftObjectPtr<UFortSoundCueTemplateDefaultSettings>& Value) { Write<TSoftObjectPtr<UFortSoundCueTemplateDefaultSettings>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x578
class UFortSoundCueTemplateSimple : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x1f0
class UGliderThrustSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    FGliderThrustData Forward() const { return Read<FGliderThrustData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x58, Type: StructProperty)
    FGliderThrustData Sideways() const { return Read<FGliderThrustData>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x58, Type: StructProperty)
    FGliderThrustData Backwards() const { return Read<FGliderThrustData>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x58, Type: StructProperty)
    FGliderThrustData AnyDirection() const { return Read<FGliderThrustData>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x58, Type: StructProperty)

    void SET_Forward(const FGliderThrustData& Value) { Write<FGliderThrustData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x58, Type: StructProperty)
    void SET_Sideways(const FGliderThrustData& Value) { Write<FGliderThrustData>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x58, Type: StructProperty)
    void SET_Backwards(const FGliderThrustData& Value) { Write<FGliderThrustData>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x58, Type: StructProperty)
    void SET_AnyDirection(const FGliderThrustData& Value) { Write<FGliderThrustData>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x58, Type: StructProperty)
};

// Size: 0x578
class UGliderThrustLoop : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x578
class UGliderThrustStart : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x578
class UGliderOpen : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UGliderClose : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UMusicPack : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x2d8
class UPhysicsStateSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    FName SpeedParameterName() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)
    FPhysicsStateData Rolling() const { return Read<FPhysicsStateData>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x90, Type: StructProperty)
    FPhysicsStateData Sliding() const { return Read<FPhysicsStateData>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x90, Type: StructProperty)
    FPhysicsStateData Flying() const { return Read<FPhysicsStateData>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x90, Type: StructProperty)
    FPhysicsStateData Floating() const { return Read<FPhysicsStateData>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x90, Type: StructProperty)

    void SET_SpeedParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
    void SET_Rolling(const FPhysicsStateData& Value) { Write<FPhysicsStateData>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x90, Type: StructProperty)
    void SET_Sliding(const FPhysicsStateData& Value) { Write<FPhysicsStateData>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x90, Type: StructProperty)
    void SET_Flying(const FPhysicsStateData& Value) { Write<FPhysicsStateData>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x90, Type: StructProperty)
    void SET_Floating(const FPhysicsStateData& Value) { Write<FPhysicsStateData>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x90, Type: StructProperty)
};

// Size: 0x578
class UPhysicsStateLoop : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x1a0
class UPhysicsImpactSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    FName ImpactTypeParameterName() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)
    FName StrengthParameterName() const { return Read<FName>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: NameProperty)
    FPhysicsImpactData Light() const { return Read<FPhysicsImpactData>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x58, Type: StructProperty)
    FPhysicsImpactData Medium() const { return Read<FPhysicsImpactData>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x58, Type: StructProperty)
    FPhysicsImpactData Heavy() const { return Read<FPhysicsImpactData>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x58, Type: StructProperty)

    void SET_ImpactTypeParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
    void SET_StrengthParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: NameProperty)
    void SET_Light(const FPhysicsImpactData& Value) { Write<FPhysicsImpactData>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x58, Type: StructProperty)
    void SET_Medium(const FPhysicsImpactData& Value) { Write<FPhysicsImpactData>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x58, Type: StructProperty)
    void SET_Heavy(const FPhysicsImpactData& Value) { Write<FPhysicsImpactData>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x58, Type: StructProperty)
};

// Size: 0x578
class UPhysicsImpact : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0xb0
class UPickaxeSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    USoundAttenuation* CloseAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* DistantAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    TArray<USoundWave*> DistantVariations() const { return Read<TArray<USoundWave*>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)

    void SET_CloseAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_DistantAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_DistantVariations(const TArray<USoundWave*>& Value) { Write<TArray<USoundWave*>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x578
class UPickaxeBase : public UFortSoundCueTemplateBase
{
public:
};

// Size: 0x578
class UPickaxeSwing : public UPickaxeBase
{
public:
};

// Size: 0x578
class UPickaxeReady : public UPickaxeBase
{
public:
};

// Size: 0x578
class UPickaxeImpactEnemy : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0xd8
class UPlayerFoleyDefaults : public UFortSoundCueTemplateDefaults
{
public:
    USoundClass* LocalPlayerSoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    USoundClass* TeammateSoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    USoundClass* HostileSoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* LocalPlayerAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* AboveAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* BelowAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* ParallelAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TArray<FDistanceDatum> ElevationCrossfadeDistances() const { return Read<TArray<FDistanceDatum>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_LocalPlayerSoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_TeammateSoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_HostileSoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalPlayerAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_AboveAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_BelowAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_ParallelAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_ElevationCrossfadeDistances(const TArray<FDistanceDatum>& Value) { Write<TArray<FDistanceDatum>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x578
class UWeaponLowAmmo : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UWeaponOutOfAmmo : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UWeaponReloadStart : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UWeaponReloadInsert : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UWeaponReloadEnd : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UWeaponTargetingStart : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x578
class UWeaponTargetingEnd : public UFortSoundCueTemplateSimple
{
public:
};

// Size: 0x28
struct FFortContinuousModulatorConfig
{
public:
    FVector2D VolumeRange() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D PitchRange() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<ModulationParamMode> VolumeMode() const { return Read<TEnumAsByte<ModulationParamMode>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ModulationParamMode> PitchMode() const { return Read<TEnumAsByte<ModulationParamMode>>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: ByteProperty)

    void SET_VolumeRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_PitchRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_VolumeMode(const TEnumAsByte<ModulationParamMode>& Value) { Write<TEnumAsByte<ModulationParamMode>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: ByteProperty)
    void SET_PitchMode(const TEnumAsByte<ModulationParamMode>& Value) { Write<TEnumAsByte<ModulationParamMode>>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x10
struct FFortSubmixPair
{
public:
    USoundSubmixBase* Submix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float SendAmount() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Submix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SendAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FFortBusPair
{
public:
    USoundSourceBus* SourceBus() const { return Read<USoundSourceBus*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAudioBus* AudioBus() const { return Read<UAudioBus*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float SendAmount() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_SourceBus(const USoundSourceBus*& Value) { Write<USoundSourceBus*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioBus(const UAudioBus*& Value) { Write<UAudioBus*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_SendAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
struct FGliderThrustData
{
public:
    FName ParameterName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector2D PitchOutput() const { return Read<FVector2D>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D VolumeOutput() const { return Read<FVector2D>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    USoundWave* Sound() const { return Read<USoundWave*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FFortContinuousModulatorConfig Settings() const { return Read<FFortContinuousModulatorConfig>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)

    void SET_ParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_PitchOutput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_VolumeOutput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_Sound(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_Settings(const FFortContinuousModulatorConfig& Value) { Write<FFortContinuousModulatorConfig>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
};

// Size: 0x90
struct FPhysicsStateData
{
public:
    FName ParameterName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector2D VolumeOutput() const { return Read<FVector2D>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D PitchOutput() const { return Read<FVector2D>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FFortContinuousModulatorConfig Settings() const { return Read<FFortContinuousModulatorConfig>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    FDistanceDatum CrossfadeInputSlow() const { return Read<FDistanceDatum>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x14, Type: StructProperty)
    USoundWave* SlowLoop() const { return Read<USoundWave*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FDistanceDatum CrossfadeInputFast() const { return Read<FDistanceDatum>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x14, Type: StructProperty)
    USoundWave* FastLoop() const { return Read<USoundWave*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)

    void SET_ParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_VolumeOutput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_PitchOutput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_Settings(const FFortContinuousModulatorConfig& Value) { Write<FFortContinuousModulatorConfig>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_CrossfadeInputSlow(const FDistanceDatum& Value) { Write<FDistanceDatum>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x14, Type: StructProperty)
    void SET_SlowLoop(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_CrossfadeInputFast(const FDistanceDatum& Value) { Write<FDistanceDatum>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x14, Type: StructProperty)
    void SET_FastLoop(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
struct FPhysicsImpactData
{
public:
    FVector2D VolumeOutput() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D PitchOutput() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FFortContinuousModulatorConfig Settings() const { return Read<FFortContinuousModulatorConfig>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x28, Type: StructProperty)
    TArray<USoundWave*> Variations() const { return Read<TArray<USoundWave*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_VolumeOutput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_PitchOutput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Settings(const FFortContinuousModulatorConfig& Value) { Write<FFortContinuousModulatorConfig>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x28, Type: StructProperty)
    void SET_Variations(const TArray<USoundWave*>& Value) { Write<TArray<USoundWave*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

