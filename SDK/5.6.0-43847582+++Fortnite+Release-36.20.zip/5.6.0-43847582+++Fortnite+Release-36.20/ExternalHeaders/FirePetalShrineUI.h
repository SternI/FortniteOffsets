/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalShrineUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "SlateCore.h"

// Size: 0x1e0
class UFirePetalShrine_UIHelperComponent : public UActorComponent
{
public:
    FSlateBrush ShrineCompassBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xb0, Type: StructProperty)
    FScalableFloat CanMarkShrinesInCompass() const { return Read<FScalableFloat>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x28, Type: StructProperty)
    FScalableFloat ShrinesMarkedCompassTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x28, Type: StructProperty)
    bool bAnchorCompassIconOnEdges() const { return Read<bool>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x1, Type: BoolProperty)

    void SET_ShrineCompassBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xb0, Type: StructProperty)
    void SET_CanMarkShrinesInCompass(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x28, Type: StructProperty)
    void SET_ShrinesMarkedCompassTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x28, Type: StructProperty)
    void SET_bAnchorCompassIconOnEdges(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
};

