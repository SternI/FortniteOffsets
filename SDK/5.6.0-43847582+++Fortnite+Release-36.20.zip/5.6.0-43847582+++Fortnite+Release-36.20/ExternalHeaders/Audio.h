/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Audio
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Rock_Vehicle.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "AudioMotorSimStandardComponents.h"

// Size: 0x628
class ABP_RockVehicleAudioController_C : public ARockVehicleAudioController
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: StructProperty)
    UAudioComponent* BoostFailedSound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UVelocitySyncMotorSimComponent* VelocitySyncMotorSim() const { return Read<UVelocitySyncMotorSimComponent*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    UMotorPhysicsSimComponent* MotorPhysicsSim() const { return Read<UMotorPhysicsSimComponent*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    UReverseMotorSimComponent* ReverseMotorSim() const { return Read<UReverseMotorSimComponent*>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    URevLimiterMotorSimComponent* RevLimiterMotorSim() const { return Read<URevLimiterMotorSimComponent*>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    UResistanceMotorSimComponent* ResistanceMotorSim() const { return Read<UResistanceMotorSimComponent*>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    UThrottleStateMotorSimComponent* ThrottleStateMotorSim() const { return Read<UThrottleStateMotorSimComponent*>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    UBoostMotorSimComponent* BoostMotorSim() const { return Read<UBoostMotorSimComponent*>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* OnGround() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* Boost() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* BoostEnd() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* SuperSonicLoop() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* InAir() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    UFortLayeredAudioComponent* Engine() const { return Read<UFortLayeredAudioComponent*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    UFortCollisionAudioComponent* Collision_Body() const { return Read<UFortCollisionAudioComponent*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    ARock_Vehicle_C* RockVehicle() const { return Read<ARock_Vehicle_C*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    bool IsLocal() const { return Read<bool>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x1, Type: BoolProperty)
    double Boost_Fade_Out_Duration() const { return Read<double>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    double EngineRampVolume() const { return Read<double>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: DoubleProperty)
    UCurveFloat* WheelImpactCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* WheelImpactSkidCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EPhysicalSurface> CachedSurface() const { return Read<TEnumAsByte<EPhysicalSurface>>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x1, Type: ByteProperty)
    bool In_Air() const { return Read<bool>(uintptr_t(this) + 0x5d9); } // 0x5d9 (Size: 0x1, Type: BoolProperty)
    bool Occupied() const { return Read<bool>(uintptr_t(this) + 0x5da); } // 0x5da (Size: 0x1, Type: BoolProperty)
    bool TiresActive() const { return Read<bool>(uintptr_t(this) + 0x5db); } // 0x5db (Size: 0x1, Type: BoolProperty)
    UAudioComponent* PreDestroyAudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    double DamageValue() const { return Read<double>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: DoubleProperty)
    USoundBase* PreDestroySoundCue() const { return Read<USoundBase*>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    bool bOutOfFuel() const { return Read<bool>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x1, Type: BoolProperty)
    USoundBase* LoadedEngineSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<USoundBase> EngineSoundPath() const { return Read<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x20, Type: SoftObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: StructProperty)
    void SET_BoostFailedSound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_VelocitySyncMotorSim(const UVelocitySyncMotorSimComponent*& Value) { Write<UVelocitySyncMotorSimComponent*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    void SET_MotorPhysicsSim(const UMotorPhysicsSimComponent*& Value) { Write<UMotorPhysicsSimComponent*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    void SET_ReverseMotorSim(const UReverseMotorSimComponent*& Value) { Write<UReverseMotorSimComponent*>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    void SET_RevLimiterMotorSim(const URevLimiterMotorSimComponent*& Value) { Write<URevLimiterMotorSimComponent*>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    void SET_ResistanceMotorSim(const UResistanceMotorSimComponent*& Value) { Write<UResistanceMotorSimComponent*>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    void SET_ThrottleStateMotorSim(const UThrottleStateMotorSimComponent*& Value) { Write<UThrottleStateMotorSimComponent*>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostMotorSim(const UBoostMotorSimComponent*& Value) { Write<UBoostMotorSimComponent*>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    void SET_OnGround(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_Boost(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostEnd(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_SuperSonicLoop(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    void SET_InAir(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_Engine(const UFortLayeredAudioComponent*& Value) { Write<UFortLayeredAudioComponent*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_Collision_Body(const UFortCollisionAudioComponent*& Value) { Write<UFortCollisionAudioComponent*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_RockVehicle(const ARock_Vehicle_C*& Value) { Write<ARock_Vehicle_C*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_IsLocal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x1, Type: BoolProperty)
    void SET_Boost_Fade_Out_Duration(const double& Value) { Write<double>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    void SET_EngineRampVolume(const double& Value) { Write<double>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: DoubleProperty)
    void SET_WheelImpactCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    void SET_WheelImpactSkidCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedSurface(const TEnumAsByte<EPhysicalSurface>& Value) { Write<TEnumAsByte<EPhysicalSurface>>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x1, Type: ByteProperty)
    void SET_In_Air(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d9, Value); } // 0x5d9 (Size: 0x1, Type: BoolProperty)
    void SET_Occupied(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5da, Value); } // 0x5da (Size: 0x1, Type: BoolProperty)
    void SET_TiresActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5db, Value); } // 0x5db (Size: 0x1, Type: BoolProperty)
    void SET_PreDestroyAudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DamageValue(const double& Value) { Write<double>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: DoubleProperty)
    void SET_PreDestroySoundCue(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    void SET_bOutOfFuel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x1, Type: BoolProperty)
    void SET_LoadedEngineSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x8, Type: ObjectProperty)
    void SET_EngineSoundPath(const TSoftObjectPtr<USoundBase>& Value) { Write<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x20, Type: SoftObjectProperty)
};

