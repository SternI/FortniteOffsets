/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_AudioMixerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "AudioModulation.h"

// Size: 0xca0
class ACreativeAudioMixerDevice : public AFortCreativeDeviceProp
{
public:
    USoundControlBusMix* Mix() const { return Read<USoundControlBusMix*>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* Bus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    float FaderValue() const { return Read<float>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x4, Type: FloatProperty)
    uint8_t CanBeHeardBy() const { return Read<uint8_t>(uintptr_t(this) + 0xc2c); } // 0xc2c (Size: 0x1, Type: EnumProperty)
    bool bActivateInEditMode() const { return Read<bool>(uintptr_t(this) + 0xc2d); } // 0xc2d (Size: 0x1, Type: BoolProperty)
    bool bActivateOnGameStart() const { return Read<bool>(uintptr_t(this) + 0xc2e); } // 0xc2e (Size: 0x1, Type: BoolProperty)
    UCreativeProxyManagerComponent* CreativeProxyManagerComponent() const { return Read<UCreativeProxyManagerComponent*>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    UFortMinigameProgressComponent* FortMinigameProgressComponent() const { return Read<UFortMinigameProgressComponent*>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    UCreativeRegisteredPlayersManagerComponent* CreativeRegisteredPlayersManagerComponent() const { return Read<UCreativeRegisteredPlayersManagerComponent*>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    UFortActorOptionsComponent* FortActorOptionsComponent() const { return Read<UFortActorOptionsComponent*>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    bool bCachedIsActive() const { return Read<bool>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x1, Type: BoolProperty)
    AController* CachedInstigator() const { return Read<AController*>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: ObjectProperty)
    ACreativeAudioMixerReplicationProxy* ClientCachedProxy() const { return Read<ACreativeAudioMixerReplicationProxy*>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    USoundControlBusMix* CachedBusMix() const { return Read<USoundControlBusMix*>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    FName CachedBusMixName() const { return Read<FName>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x4, Type: NameProperty)
    TArray<FUniqueNetIdRepl> RegisteredPlayerIds() const { return Read<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x10, Type: ArrayProperty)
    TArray<FUniqueNetIdRepl> NonRegisteredPlayerIds() const { return Read<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x10, Type: ArrayProperty)
    bool bHasUpdatedStateInEditMode() const { return Read<bool>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x1, Type: BoolProperty)
    bool bHasUpdatedStateInGameplay() const { return Read<bool>(uintptr_t(this) + 0xc99); } // 0xc99 (Size: 0x1, Type: BoolProperty)

    void SET_Mix(const USoundControlBusMix*& Value) { Write<USoundControlBusMix*>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    void SET_Bus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    void SET_FaderValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x4, Type: FloatProperty)
    void SET_CanBeHeardBy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc2c, Value); } // 0xc2c (Size: 0x1, Type: EnumProperty)
    void SET_bActivateInEditMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc2d, Value); } // 0xc2d (Size: 0x1, Type: BoolProperty)
    void SET_bActivateOnGameStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc2e, Value); } // 0xc2e (Size: 0x1, Type: BoolProperty)
    void SET_CreativeProxyManagerComponent(const UCreativeProxyManagerComponent*& Value) { Write<UCreativeProxyManagerComponent*>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    void SET_FortMinigameProgressComponent(const UFortMinigameProgressComponent*& Value) { Write<UFortMinigameProgressComponent*>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeRegisteredPlayersManagerComponent(const UCreativeRegisteredPlayersManagerComponent*& Value) { Write<UCreativeRegisteredPlayersManagerComponent*>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    void SET_FortActorOptionsComponent(const UFortActorOptionsComponent*& Value) { Write<UFortActorOptionsComponent*>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    void SET_bCachedIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x1, Type: BoolProperty)
    void SET_CachedInstigator(const AController*& Value) { Write<AController*>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: ObjectProperty)
    void SET_ClientCachedProxy(const ACreativeAudioMixerReplicationProxy*& Value) { Write<ACreativeAudioMixerReplicationProxy*>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedBusMix(const USoundControlBusMix*& Value) { Write<USoundControlBusMix*>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedBusMixName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x4, Type: NameProperty)
    void SET_RegisteredPlayerIds(const TArray<FUniqueNetIdRepl>& Value) { Write<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x10, Type: ArrayProperty)
    void SET_NonRegisteredPlayerIds(const TArray<FUniqueNetIdRepl>& Value) { Write<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasUpdatedStateInEditMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x1, Type: BoolProperty)
    void SET_bHasUpdatedStateInGameplay(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc99, Value); } // 0xc99 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2c0
class ACreativeAudioMixerReplicationProxy : public ACreativePlayerReplicationProxy
{
public:
    bool bIsActive() const { return Read<bool>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x1, Type: BoolProperty)

    void SET_bIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x1, Type: BoolProperty)
};

