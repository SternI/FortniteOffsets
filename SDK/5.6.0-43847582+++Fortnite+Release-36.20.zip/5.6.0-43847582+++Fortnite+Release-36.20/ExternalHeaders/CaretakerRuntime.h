/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CaretakerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AIModule.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0x650
class AFortAthenaCaretakerAIController : public AAthenaAIController
{
public:
};

// Size: 0x160
class UFortBTTask_CaretakerMoveTo : public UBTTask_MoveTo
{
public:
    FBlackboardKeySelector FocalPointWhileMoving() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EPathObstacleAction> PathObstacleAction() const { return Read<TEnumAsByte<EPathObstacleAction>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x1, Type: ByteProperty)
    bool bEnableSlowdownAtGoal() const { return (Read<uint8_t>(uintptr_t(this) + 0x15c) >> 0x0) & 1; } // 0x15c:0 (Size: 0x1, Type: BoolProperty)
    bool bMoveDirectlyTowards() const { return (Read<uint8_t>(uintptr_t(this) + 0x15c) >> 0x1) & 1; } // 0x15c:1 (Size: 0x1, Type: BoolProperty)
    bool bStopAtGoal() const { return (Read<uint8_t>(uintptr_t(this) + 0x15c) >> 0x2) & 1; } // 0x15c:2 (Size: 0x1, Type: BoolProperty)
    bool bFinishMoveOnOverlap() const { return (Read<uint8_t>(uintptr_t(this) + 0x15c) >> 0x3) & 1; } // 0x15c:3 (Size: 0x1, Type: BoolProperty)

    void SET_FocalPointWhileMoving(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x28, Type: StructProperty)
    void SET_PathObstacleAction(const TEnumAsByte<EPathObstacleAction>& Value) { Write<TEnumAsByte<EPathObstacleAction>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x1, Type: ByteProperty)
    void SET_bEnableSlowdownAtGoal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x15c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x15c, B); } // 0x15c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bMoveDirectlyTowards(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x15c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x15c, B); } // 0x15c:1 (Size: 0x1, Type: BoolProperty)
    void SET_bStopAtGoal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x15c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x15c, B); } // 0x15c:2 (Size: 0x1, Type: BoolProperty)
    void SET_bFinishMoveOnOverlap(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x15c); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x15c, B); } // 0x15c:3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
class UFortNavigationFilter_Caretaker : public UFortNavigationFilter
{
public:
    float EndPointAcceptableRadius() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    UClass* EndPointFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    bool bEndPointReachTestIncludesAgentRadius() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x0) & 1; } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    bool bEndPointReachTestIncludesGoalRadius() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x1) & 1; } // 0x58:1 (Size: 0x1, Type: BoolProperty)

    void SET_EndPointAcceptableRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_EndPointFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_bEndPointReachTestIncludesAgentRadius(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    void SET_bEndPointReachTestIncludesGoalRadius(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1b0
class UFortAITask_CaretakerMove : public UFortAbilityTask_MoveAI
{
public:
};

// Size: 0x660
class UFortAIAnimInstance_Caretaker : public UFortAIAnimInstance
{
public:
    bool bIsMoving() const { return Read<bool>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x1, Type: BoolProperty)
    float WalkPlayrate() const { return Read<float>(uintptr_t(this) + 0x60c); } // 0x60c (Size: 0x4, Type: FloatProperty)
    float AimOffsetCurve() const { return Read<float>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x4, Type: FloatProperty)
    bool bFootPhase_StopLeftPlant() const { return Read<bool>(uintptr_t(this) + 0x614); } // 0x614 (Size: 0x1, Type: BoolProperty)
    bool bFootPhase_StopLeftPass() const { return Read<bool>(uintptr_t(this) + 0x615); } // 0x615 (Size: 0x1, Type: BoolProperty)
    bool bFootPhase_StopRightPlant() const { return Read<bool>(uintptr_t(this) + 0x616); } // 0x616 (Size: 0x1, Type: BoolProperty)
    bool bFootPhase_StopRightPass() const { return Read<bool>(uintptr_t(this) + 0x617); } // 0x617 (Size: 0x1, Type: BoolProperty)
    float BreathingCurve() const { return Read<float>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x4, Type: FloatProperty)
    float MovingTreshold() const { return Read<float>(uintptr_t(this) + 0x61c); } // 0x61c (Size: 0x4, Type: FloatProperty)
    FName CurveName_AimOffsetCurve() const { return Read<FName>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x4, Type: NameProperty)
    FName CurveName_FootPhase() const { return Read<FName>(uintptr_t(this) + 0x624); } // 0x624 (Size: 0x4, Type: NameProperty)
    FName CurveName_BreathingCurve() const { return Read<FName>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x4, Type: NameProperty)
    FName SocketName_FX_Chest() const { return Read<FName>(uintptr_t(this) + 0x62c); } // 0x62c (Size: 0x4, Type: NameProperty)
    FName ParamName_ChestSocketLocation() const { return Read<FName>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x4, Type: NameProperty)
    FName ParamName_ChestSocketVector() const { return Read<FName>(uintptr_t(this) + 0x634); } // 0x634 (Size: 0x4, Type: NameProperty)
    float FirstFootPhaseMin() const { return Read<float>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x4, Type: FloatProperty)
    float SecondFootPhaseMin() const { return Read<float>(uintptr_t(this) + 0x63c); } // 0x63c (Size: 0x4, Type: FloatProperty)
    float ThirdFootPhaseMin() const { return Read<float>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x4, Type: FloatProperty)
    float FourthFootPhaseMin() const { return Read<float>(uintptr_t(this) + 0x644); } // 0x644 (Size: 0x4, Type: FloatProperty)
    float FootPhaseMax() const { return Read<float>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x4, Type: FloatProperty)
    UFortAnimWorldStriderComponent* WorldStriderComponent() const { return Read<UFortAnimWorldStriderComponent*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)

    void SET_bIsMoving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x1, Type: BoolProperty)
    void SET_WalkPlayrate(const float& Value) { Write<float>(uintptr_t(this) + 0x60c, Value); } // 0x60c (Size: 0x4, Type: FloatProperty)
    void SET_AimOffsetCurve(const float& Value) { Write<float>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x4, Type: FloatProperty)
    void SET_bFootPhase_StopLeftPlant(const bool& Value) { Write<bool>(uintptr_t(this) + 0x614, Value); } // 0x614 (Size: 0x1, Type: BoolProperty)
    void SET_bFootPhase_StopLeftPass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x615, Value); } // 0x615 (Size: 0x1, Type: BoolProperty)
    void SET_bFootPhase_StopRightPlant(const bool& Value) { Write<bool>(uintptr_t(this) + 0x616, Value); } // 0x616 (Size: 0x1, Type: BoolProperty)
    void SET_bFootPhase_StopRightPass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x617, Value); } // 0x617 (Size: 0x1, Type: BoolProperty)
    void SET_BreathingCurve(const float& Value) { Write<float>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x4, Type: FloatProperty)
    void SET_MovingTreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x61c, Value); } // 0x61c (Size: 0x4, Type: FloatProperty)
    void SET_CurveName_AimOffsetCurve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x4, Type: NameProperty)
    void SET_CurveName_FootPhase(const FName& Value) { Write<FName>(uintptr_t(this) + 0x624, Value); } // 0x624 (Size: 0x4, Type: NameProperty)
    void SET_CurveName_BreathingCurve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x4, Type: NameProperty)
    void SET_SocketName_FX_Chest(const FName& Value) { Write<FName>(uintptr_t(this) + 0x62c, Value); } // 0x62c (Size: 0x4, Type: NameProperty)
    void SET_ParamName_ChestSocketLocation(const FName& Value) { Write<FName>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x4, Type: NameProperty)
    void SET_ParamName_ChestSocketVector(const FName& Value) { Write<FName>(uintptr_t(this) + 0x634, Value); } // 0x634 (Size: 0x4, Type: NameProperty)
    void SET_FirstFootPhaseMin(const float& Value) { Write<float>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x4, Type: FloatProperty)
    void SET_SecondFootPhaseMin(const float& Value) { Write<float>(uintptr_t(this) + 0x63c, Value); } // 0x63c (Size: 0x4, Type: FloatProperty)
    void SET_ThirdFootPhaseMin(const float& Value) { Write<float>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x4, Type: FloatProperty)
    void SET_FourthFootPhaseMin(const float& Value) { Write<float>(uintptr_t(this) + 0x644, Value); } // 0x644 (Size: 0x4, Type: FloatProperty)
    void SET_FootPhaseMax(const float& Value) { Write<float>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x4, Type: FloatProperty)
    void SET_WorldStriderComponent(const UFortAnimWorldStriderComponent*& Value) { Write<UFortAnimWorldStriderComponent*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
};

