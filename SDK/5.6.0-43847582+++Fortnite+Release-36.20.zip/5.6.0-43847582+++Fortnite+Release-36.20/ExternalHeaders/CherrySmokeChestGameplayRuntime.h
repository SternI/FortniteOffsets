/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CherrySmokeChestGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xd8
class UCherrySmokeChestInitializeComponent : public UActorComponent
{
public:
};

