/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DemonMaskFireRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0x820
class UDemonMaskFireGadgetAnimInstance : public UMaskBaseCCPAnimInstance
{
public:
    FVector Floater() const { return Read<FVector>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x18, Type: StructProperty)
    double ElapsedTime() const { return Read<double>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x8, Type: DoubleProperty)

    void SET_Floater(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x18, Type: StructProperty)
    void SET_ElapsedTime(const double& Value) { Write<double>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1330
class UDemonMaskLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    double IsPlayingFire01_Alpha() const { return Read<double>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x8, Type: DoubleProperty)
    double IsPlayingFire02_Alpha() const { return Read<double>(uintptr_t(this) + 0x1310); } // 0x1310 (Size: 0x8, Type: DoubleProperty)
    UObject* DemonMaskFirePlayerFire01MontageObject() const { return Read<UObject*>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x8, Type: ObjectProperty)
    UObject* DemonMaskFirePlayerFire02MontageObject() const { return Read<UObject*>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x8, Type: ObjectProperty)

    void SET_IsPlayingFire01_Alpha(const double& Value) { Write<double>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x8, Type: DoubleProperty)
    void SET_IsPlayingFire02_Alpha(const double& Value) { Write<double>(uintptr_t(this) + 0x1310, Value); } // 0x1310 (Size: 0x8, Type: DoubleProperty)
    void SET_DemonMaskFirePlayerFire01MontageObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x8, Type: ObjectProperty)
    void SET_DemonMaskFirePlayerFire02MontageObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd08
class AFortPrjAthenaDemonFireMask : public AFortProjectileAthena
{
public:
    TWeakObjectPtr<AFortPlayerPawn*> FortPlayerPawn() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_FortPlayerPawn(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2630
class AFortWeaponRangedDemonFireMask : public AFortWeaponRanged
{
public:
    TWeakObjectPtr<AFortPlayerPawn*> FortPlayerPawn() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0x2618); } // 0x2618 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FHitResult> OutHits() const { return Read<TArray<FHitResult>>(uintptr_t(this) + 0x2620); } // 0x2620 (Size: 0x10, Type: ArrayProperty)

    void SET_FortPlayerPawn(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0x2618, Value); } // 0x2618 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OutHits(const TArray<FHitResult>& Value) { Write<TArray<FHitResult>>(uintptr_t(this) + 0x2620, Value); } // 0x2620 (Size: 0x10, Type: ArrayProperty)
};

