/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_JunoSettingsMarkup
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x38
class UBP_JunoSettingsMarkup_C : public UFortGameSettingRegistryMarkup
{
public:
};

