/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_PlayerAugmentSystemBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x1d8
class UBP_PlayerAugmentSystemBase_C : public UFortPlayerStateComponent_PlayerAugmentSystem
{
public:
};

