/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMetadata
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "Engine.h"
#include "AudioModulation.h"

// Size: 0x50
class UAudioMetadataDeveloperSettings : public UDeveloperSettings
{
public:
    FAudioMetadataModulationSettings ModulationSettings() const { return Read<FAudioMetadataModulationSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)
    FAudioMetadataSubmixSettings SubmixSettings() const { return Read<FAudioMetadataSubmixSettings>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_ModulationSettings(const FAudioMetadataModulationSettings& Value) { Write<FAudioMetadataModulationSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
    void SET_SubmixSettings(const FAudioMetadataSubmixSettings& Value) { Write<FAudioMetadataSubmixSettings>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
class UAudioMetadataSubsystem : public UAudioEngineSubsystem
{
public:
};

// Size: 0x10
struct FAudioMetadataModulationSettings
{
public:
    USoundControlBus* ControlBusLicensedAudioMuteAll() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ControlBusLicensedAudioMuteOthers() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_ControlBusLicensedAudioMuteAll(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlBusLicensedAudioMuteOthers(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FAudioMetadataSubmixSettings
{
public:
    USoundSubmix* LicensedAudioSubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* PostPartySubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_LicensedAudioSubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PostPartySubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

