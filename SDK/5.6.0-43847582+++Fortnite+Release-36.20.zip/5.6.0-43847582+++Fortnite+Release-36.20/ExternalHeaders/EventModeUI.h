/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventModeUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Paper2D.h"
#include "UMG.h"
#include "FortniteGame.h"

// Size: 0x490
class UFocusButton : public UBacchusActionButton
{
public:
    UPaperSprite* StartFocusingSprite() const { return Read<UPaperSprite*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UPaperSprite* StopFocusingSprite() const { return Read<UPaperSprite*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)

    void SET_StartFocusingSprite(const UPaperSprite*& Value) { Write<UPaperSprite*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_StopFocusingSprite(const UPaperSprite*& Value) { Write<UPaperSprite*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3f8
class UFortEventModeEmotesWidget : public UFortHUDElementWidget
{
public:
    TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote1() const { return Read<TSoftObjectPtr<UFortMontageItemDefinitionBase>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote2() const { return Read<TSoftObjectPtr<UFortMontageItemDefinitionBase>>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote3() const { return Read<TSoftObjectPtr<UFortMontageItemDefinitionBase>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x20, Type: SoftObjectProperty)
    TArray<TSoftObjectPtr<UFortMontageItemDefinitionBase*>> RandomEmotes() const { return Read<TArray<TSoftObjectPtr<UFortMontageItemDefinitionBase*>>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    URichTextBlock* Text_Emote1() const { return Read<URichTextBlock*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_Emote2() const { return Read<URichTextBlock*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_Emote3() const { return Read<URichTextBlock*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_EmoteRandom() const { return Read<URichTextBlock*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)

    void SET_Emote1(const TSoftObjectPtr<UFortMontageItemDefinitionBase>& Value) { Write<TSoftObjectPtr<UFortMontageItemDefinitionBase>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Emote2(const TSoftObjectPtr<UFortMontageItemDefinitionBase>& Value) { Write<TSoftObjectPtr<UFortMontageItemDefinitionBase>>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Emote3(const TSoftObjectPtr<UFortMontageItemDefinitionBase>& Value) { Write<TSoftObjectPtr<UFortMontageItemDefinitionBase>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_RandomEmotes(const TArray<TSoftObjectPtr<UFortMontageItemDefinitionBase*>>& Value) { Write<TArray<TSoftObjectPtr<UFortMontageItemDefinitionBase*>>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    void SET_Text_Emote1(const URichTextBlock*& Value) { Write<URichTextBlock*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Emote2(const URichTextBlock*& Value) { Write<URichTextBlock*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Emote3(const URichTextBlock*& Value) { Write<URichTextBlock*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_EmoteRandom(const URichTextBlock*& Value) { Write<URichTextBlock*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x330
class UFortMobileActionButtonBehavior_Focus : public UFortMobileActionButtonBehavior
{
public:
    UPaperSprite* StopFocusingSprite() const { return Read<UPaperSprite*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)

    void SET_StopFocusingSprite(const UPaperSprite*& Value) { Write<UPaperSprite*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
};

