/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChatCompletion
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "JsonUtilities.h"

// Size: 0xc8
class UChatCompleter : public UObject
{
public:
    TWeakObjectPtr<UChatCompletionSubsystem*> Subsystem() const { return Read<TWeakObjectPtr<UChatCompletionSubsystem*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    bool bStripFromClientBuilds() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)

    void SET_Subsystem(const TWeakObjectPtr<UChatCompletionSubsystem*>& Value) { Write<TWeakObjectPtr<UChatCompletionSubsystem*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bStripFromClientBuilds(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
class UAsyncAction_ChatCompletionRequest : public UCancellableAsyncAction
{
public:
    UChatCompleter* ChatCompleter() const { return Read<UChatCompleter*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_ChatCompleter(const UChatCompleter*& Value) { Write<UChatCompleter*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x68
class UAsyncAction_StructuredChatCompletionRequest : public UCancellableAsyncAction
{
public:
    UChatCompleter* ChatCompleter() const { return Read<UChatCompleter*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_ChatCompleter(const UChatCompleter*& Value) { Write<UChatCompleter*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UChatCompleterBase : public UChatCompleter
{
public:
};

// Size: 0x28
class UChatCompletionCheatManager : public UCheatManagerExtension
{
public:
};

// Size: 0x28
class UChatCompletionFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xc8
class UChatCompletionSubsystem : public UEngineSubsystem
{
public:
    FString AnalyticsEventNamespace() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)

    void SET_AnalyticsEventNamespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x50
struct FChatCompletionFunctionCall
{
public:
    FString ID() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FSharedChatCompletionFunctionHandle Function() const { return Read<FSharedChatCompletionFunctionHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FChatCompletionStructuredData Arguments() const { return Read<FChatCompletionStructuredData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)

    void SET_ID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Function(const FSharedChatCompletionFunctionHandle& Value) { Write<FSharedChatCompletionFunctionHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Arguments(const FChatCompletionStructuredData& Value) { Write<FChatCompletionStructuredData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
};

// Size: 0x30
struct FChatCompletionStructuredData : public FJsonObjectWrapper
{
public:
    FInstancedStruct TypedData() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_TypedData(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FSharedChatCompletionFunctionHandle
{
public:
};

// Size: 0x10
struct FChatCompletionRequestHandle
{
public:
};

// Size: 0x8
struct FChatCompletionMessageBase
{
public:
};

// Size: 0x18
struct FChatCompletionResponseMessageBase : public FChatCompletionMessageBase
{
public:
    TArray<FChatCompletionFunctionCall> FunctionCalls() const { return Read<TArray<FChatCompletionFunctionCall>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_FunctionCalls(const TArray<FChatCompletionFunctionCall>& Value) { Write<TArray<FChatCompletionFunctionCall>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FChatCompletionResponseMessage : public FChatCompletionResponseMessageBase
{
public:
    FString Content() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_Content(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0x48
struct FChatCompletionStructuredResponseMessage : public FChatCompletionResponseMessageBase
{
public:
    FChatCompletionStructuredData StructuredContent() const { return Read<FChatCompletionStructuredData>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)

    void SET_StructuredContent(const FChatCompletionStructuredData& Value) { Write<FChatCompletionStructuredData>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
};

// Size: 0xd8
struct FChatCompletionSettings
{
public:
    FChatCompletionGenerationSettings GenerationSettings() const { return Read<FChatCompletionGenerationSettings>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x24, Type: StructProperty)
    FChatCompletionSafetySettings SafetySettings() const { return Read<FChatCompletionSafetySettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: StructProperty)
    FChatCompletionRetrySettings RetrySettings() const { return Read<FChatCompletionRetrySettings>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x60, Type: StructProperty)

    void SET_GenerationSettings(const FChatCompletionGenerationSettings& Value) { Write<FChatCompletionGenerationSettings>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x24, Type: StructProperty)
    void SET_SafetySettings(const FChatCompletionSafetySettings& Value) { Write<FChatCompletionSafetySettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: StructProperty)
    void SET_RetrySettings(const FChatCompletionRetrySettings& Value) { Write<FChatCompletionRetrySettings>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x60, Type: StructProperty)
};

// Size: 0x60
struct FChatCompletionRetrySettings
{
public:
    FChatCompletionRetryCounts RetryCounts() const { return Read<FChatCompletionRetryCounts>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x58, Type: StructProperty)
    bool bAutoRespondToMalformedFunctionCalls() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)

    void SET_RetryCounts(const FChatCompletionRetryCounts& Value) { Write<FChatCompletionRetryCounts>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x58, Type: StructProperty)
    void SET_bAutoRespondToMalformedFunctionCalls(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
struct FChatCompletionRetryCounts
{
public:
    int32_t AnyReasonRetryCount() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    TMap<EChatCompletionErrorFlags, int32_t> ErrorRetryCounts() const { return Read<TMap<EChatCompletionErrorFlags, int32_t>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: MapProperty)

    void SET_AnyReasonRetryCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_ErrorRetryCounts(const TMap<EChatCompletionErrorFlags, int32_t>& Value) { Write<TMap<EChatCompletionErrorFlags, int32_t>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
struct FChatCompletionSafetySettings
{
public:
    TMap<EChatCompletionHarmCategory, FChatCompletionSafetySetting> HarmCategorySettings() const { return Read<TMap<EChatCompletionHarmCategory, FChatCompletionSafetySetting>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_HarmCategorySettings(const TMap<EChatCompletionHarmCategory, FChatCompletionSafetySetting>& Value) { Write<TMap<EChatCompletionHarmCategory, FChatCompletionSafetySetting>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x2
struct FChatCompletionSafetySetting
{
public:
    uint8_t BlockThreshold() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t BlockMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)

    void SET_BlockThreshold(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_BlockMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x24
struct FChatCompletionGenerationSettings
{
public:
    uint8_t FunctionCallingMode() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bAllowParallelFunctionCalls() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bAutoSubstituteUndefinedFunctionCallHistory() const { return Read<bool>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x1, Type: BoolProperty)
    uint8_t ResponseFormat() const { return Read<uint8_t>(uintptr_t(this) + 0xb); } // 0xb (Size: 0x1, Type: EnumProperty)

    void SET_FunctionCallingMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_bAllowParallelFunctionCalls(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoSubstituteUndefinedFunctionCallHistory(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x1, Type: BoolProperty)
    void SET_ResponseFormat(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb, Value); } // 0xb (Size: 0x1, Type: EnumProperty)
};

// Size: 0x38
struct FChatCompletionChat
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FString SystemMessage() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FInstancedStruct> Messages() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FSharedChatCompletionFunctionHandle> Functions() const { return Read<TArray<FSharedChatCompletionFunctionHandle>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_SystemMessage(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_Messages(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Functions(const TArray<FSharedChatCompletionFunctionHandle>& Value) { Write<TArray<FSharedChatCompletionFunctionHandle>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x100
struct FChatCompletionStructuredDataSchema
{
public:
    UScriptStruct* StructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bHasCustomPropertyMetaData() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    FChatCompletionPropertyMetaData PropertyMetaData() const { return Read<FChatCompletionPropertyMetaData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xf0, Type: StructProperty)

    void SET_StructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bHasCustomPropertyMetaData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_PropertyMetaData(const FChatCompletionPropertyMetaData& Value) { Write<FChatCompletionPropertyMetaData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xf0, Type: StructProperty)
};

// Size: 0xf0
struct FChatCompletionPropertyMetaData
{
public:
    TMap<FString, FText> PropertyDescriptions() const { return Read<TMap<FString, FText>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<FString, double> PropertyClampMin() const { return Read<TMap<FString, double>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)
    TMap<FString, double> PropertyClampMax() const { return Read<TMap<FString, double>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)

    void SET_PropertyDescriptions(const TMap<FString, FText>& Value) { Write<TMap<FString, FText>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_PropertyClampMin(const TMap<FString, double>& Value) { Write<TMap<FString, double>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
    void SET_PropertyClampMax(const TMap<FString, double>& Value) { Write<TMap<FString, double>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x108
struct FChatCompletionStructuredResponseDataSchema : public FChatCompletionStructuredDataSchema
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
struct FChatCompletionAttachment
{
public:
    FString mimetype() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_mimetype(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x220
struct FChatCompletionFunction
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FChatCompletionStructuredDataSchema ArgumentsSchema() const { return Read<FChatCompletionStructuredDataSchema>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x100, Type: StructProperty)
    FChatCompletionStructuredDataSchema ResponseSchema() const { return Read<FChatCompletionStructuredDataSchema>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x100, Type: StructProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_ArgumentsSchema(const FChatCompletionStructuredDataSchema& Value) { Write<FChatCompletionStructuredDataSchema>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x100, Type: StructProperty)
    void SET_ResponseSchema(const FChatCompletionStructuredDataSchema& Value) { Write<FChatCompletionStructuredDataSchema>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x100, Type: StructProperty)
};

// Size: 0x50
struct FChatCompletionFunctionCallResult
{
public:
    FSharedChatCompletionFunctionHandle Function() const { return Read<FSharedChatCompletionFunctionHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FString FunctionCallID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FChatCompletionStructuredData Result() const { return Read<FChatCompletionStructuredData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)

    void SET_Function(const FSharedChatCompletionFunctionHandle& Value) { Write<FSharedChatCompletionFunctionHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_FunctionCallID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Result(const FChatCompletionStructuredData& Value) { Write<FChatCompletionStructuredData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
};

// Size: 0x28
struct FChatCompletionUserMessage : public FChatCompletionMessageBase
{
public:
    FString Content() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FChatCompletionAttachment> Attachments() const { return Read<TArray<FChatCompletionAttachment>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Content(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_Attachments(const TArray<FChatCompletionAttachment>& Value) { Write<TArray<FChatCompletionAttachment>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FChatCompletionFunctionResultsMessage : public FChatCompletionMessageBase
{
public:
    TArray<FChatCompletionFunctionCallResult> FunctionResults() const { return Read<TArray<FChatCompletionFunctionCallResult>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_FunctionResults(const TArray<FChatCompletionFunctionCallResult>& Value) { Write<TArray<FChatCompletionFunctionCallResult>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FChatCompletionUsage
{
public:
};

