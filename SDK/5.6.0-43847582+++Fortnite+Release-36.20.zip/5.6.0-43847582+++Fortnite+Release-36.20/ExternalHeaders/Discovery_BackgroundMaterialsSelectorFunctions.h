/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Discovery_BackgroundMaterialsSelectorFunctions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28
class UDiscovery_BackgroundMaterialsSelectorFunctions_C : public UBlueprintFunctionLibrary
{
public:
};

