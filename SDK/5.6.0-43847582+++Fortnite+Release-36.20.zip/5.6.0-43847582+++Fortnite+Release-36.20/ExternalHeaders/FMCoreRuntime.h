/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayEventRouter.h"
#include "HarmonixMidi.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0x30
class UFMCoreDeveloperSettings : public UDeveloperSettings
{
public:
};

// Size: 0x28
class UFMCoreMusicFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x148
class UFMCoreMusicManagerComponent : public UActorComponent
{
public:
    uint8_t StartingKey() const { return Read<uint8_t>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: EnumProperty)
    uint8_t StartingMode() const { return Read<uint8_t>(uintptr_t(this) + 0x109); } // 0x109 (Size: 0x1, Type: EnumProperty)
    float StartingTempo() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    float StartingSpeed() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    int32_t StartingTimeSignatureNumerator() const { return Read<int32_t>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: IntProperty)
    int32_t StartingTimeSignatureDenominator() const { return Read<int32_t>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: IntProperty)
    uint8_t CurrentKey() const { return Read<uint8_t>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x1, Type: EnumProperty)
    uint8_t CurrentMode() const { return Read<uint8_t>(uintptr_t(this) + 0x11d); } // 0x11d (Size: 0x1, Type: EnumProperty)
    float CurrentTempo() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float CurrentSpeed() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    FFMCoreTimeSignature CurrentTimeSignature() const { return Read<FFMCoreTimeSignature>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: StructProperty)
    uint8_t ServerKey() const { return Read<uint8_t>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: EnumProperty)
    uint8_t ServerMode() const { return Read<uint8_t>(uintptr_t(this) + 0x131); } // 0x131 (Size: 0x1, Type: EnumProperty)
    float ServerTempo() const { return Read<float>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: FloatProperty)
    float ServerSpeed() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    FFMCoreTimeSignature ServerTimeSignature() const { return Read<FFMCoreTimeSignature>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x8, Type: StructProperty)

    void SET_StartingKey(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: EnumProperty)
    void SET_StartingMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x109, Value); } // 0x109 (Size: 0x1, Type: EnumProperty)
    void SET_StartingTempo(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_StartingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_StartingTimeSignatureNumerator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: IntProperty)
    void SET_StartingTimeSignatureDenominator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: IntProperty)
    void SET_CurrentKey(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x1, Type: EnumProperty)
    void SET_CurrentMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x11d, Value); } // 0x11d (Size: 0x1, Type: EnumProperty)
    void SET_CurrentTempo(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentTimeSignature(const FFMCoreTimeSignature& Value) { Write<FFMCoreTimeSignature>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: StructProperty)
    void SET_ServerKey(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: EnumProperty)
    void SET_ServerMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x131, Value); } // 0x131 (Size: 0x1, Type: EnumProperty)
    void SET_ServerTempo(const float& Value) { Write<float>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: FloatProperty)
    void SET_ServerSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_ServerTimeSignature(const FFMCoreTimeSignature& Value) { Write<FFMCoreTimeSignature>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x8, Type: StructProperty)
};

// Size: 0xf8
class UFMPlayerInputDeviceManagerComponent : public UControllerComponent
{
public:
    bool bHasConnectedInputDevice() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool bIsPeripheralDeviceConnected_AnyUser() const { return Read<bool>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool bIsPeripheralDeviceConnected_OwningUser() const { return Read<bool>(uintptr_t(this) + 0xba); } // 0xba (Size: 0x1, Type: BoolProperty)

    void SET_bHasConnectedInputDevice(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPeripheralDeviceConnected_AnyUser(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPeripheralDeviceConnected_OwningUser(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba, Value); } // 0xba (Size: 0x1, Type: BoolProperty)
};

// Size: 0x148
class UFMPlayerMonitorComponent : public UGameFrameworkComponent
{
public:
    FGameplayEventListenerBackwardCompatibleHandle PlayerEnteredHandle() const { return Read<FGameplayEventListenerBackwardCompatibleHandle>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x48, Type: StructProperty)
    FGameplayEventListenerBackwardCompatibleHandle PlayerExitedHandle() const { return Read<FGameplayEventListenerBackwardCompatibleHandle>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x48, Type: StructProperty)

    void SET_PlayerEnteredHandle(const FGameplayEventListenerBackwardCompatibleHandle& Value) { Write<FGameplayEventListenerBackwardCompatibleHandle>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x48, Type: StructProperty)
    void SET_PlayerExitedHandle(const FGameplayEventListenerBackwardCompatibleHandle& Value) { Write<FGameplayEventListenerBackwardCompatibleHandle>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x48, Type: StructProperty)
};

// Size: 0xc8
class UFMPlayspaceScopedSystemComponent : public UActorComponent
{
public:
};

// Size: 0x178
class UFMPlayspaceScopedSystemManager : public UActorComponent
{
public:
    TMap<UClass*, UClass*> VKClassRedirects() const { return Read<TMap<UClass*, UClass*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    TArray<TSoftClassPtr> VKClassDenyList() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftClassPtr> UEFNNotableActors() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    TMap<AActor*, FFMPlayspaceSystemInfo> PlayspacesSystemInfo() const { return Read<TMap<AActor*, FFMPlayspaceSystemInfo>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x50, Type: MapProperty)

    void SET_VKClassRedirects(const TMap<UClass*, UClass*>& Value) { Write<TMap<UClass*, UClass*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_VKClassDenyList(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_UEFNNotableActors(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayspacesSystemInfo(const TMap<AActor*, FFMPlayspaceSystemInfo>& Value) { Write<TMap<AActor*, FFMPlayspaceSystemInfo>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x50, Type: MapProperty)
};

// Size: 0x8
struct FFMCoreTimeSignature
{
public:
    int32_t Numerator() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Denominator() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Numerator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Denominator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1
struct FFMCoreEvent_MuteJamAudioChanged
{
public:
    bool bIsMuted() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bIsMuted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FFMEvent_OnPrimaryInputDeviceChanged
{
public:
    AFortPlayerState* FortPlayer() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FInputDeviceId InputDeviceId() const { return Read<FInputDeviceId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    bool bIsUsingPeripheral() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_FortPlayer(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_InputDeviceId(const FInputDeviceId& Value) { Write<FInputDeviceId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_bIsUsingPeripheral(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FFMEvent_OnInputDeviceConnectionChanged
{
public:
    AFortPlayerState* FortPlayer() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FPlatformUserId PlatformUserId() const { return Read<FPlatformUserId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t NewConnectionState() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FInputDeviceId InputDeviceId() const { return Read<FInputDeviceId>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    bool bIsPeripheral() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bHasNoConnectedDevice() const { return Read<bool>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: BoolProperty)

    void SET_FortPlayer(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlatformUserId(const FPlatformUserId& Value) { Write<FPlatformUserId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_NewConnectionState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_InputDeviceId(const FInputDeviceId& Value) { Write<FInputDeviceId>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_bIsPeripheral(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_bHasNoConnectedDevice(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FFMEvent_OnInputDevicePairingChanged
{
public:
    FInputDeviceId InputDeviceId() const { return Read<FInputDeviceId>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FPlatformUserId NewPairedPlayerId() const { return Read<FPlatformUserId>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FPlatformUserId OldPairedPlayerId() const { return Read<FPlatformUserId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_InputDeviceId(const FInputDeviceId& Value) { Write<FInputDeviceId>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_NewPairedPlayerId(const FPlatformUserId& Value) { Write<FPlatformUserId>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_OldPairedPlayerId(const FPlatformUserId& Value) { Write<FPlatformUserId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x50
struct FFMPlayspaceSystemInfo
{
public:
};

