/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioModulation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "AudioExtensions.h"
#include "Engine.h"

// Size: 0x28
class UAudioModulationStyle : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x40
class UAudioModulationDestination : public UObject
{
public:
    USoundModulatorBase* Modulator() const { return Read<USoundModulatorBase*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Modulator(const USoundModulatorBase*& Value) { Write<USoundModulatorBase*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UAudioModulationSettings : public UDeveloperSettings
{
public:
    TArray<FSoftObjectPath> Parameters() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UAudioModulationStatics : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x48
class USoundModulationGeneratorADEnvelope : public USoundModulationGenerator
{
public:
    FSoundModulationADEnvelopeParams Params() const { return Read<FSoundModulationADEnvelopeParams>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x14, Type: StructProperty)

    void SET_Params(const FSoundModulationADEnvelopeParams& Value) { Write<FSoundModulationADEnvelopeParams>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x14, Type: StructProperty)
};

// Size: 0x30
class USoundModulationGenerator : public USoundModulatorBase
{
public:
};

// Size: 0x50
class USoundModulationGeneratorEnvelopeFollower : public USoundModulationGenerator
{
public:
    FEnvelopeFollowerGeneratorParams Params() const { return Read<FEnvelopeFollowerGeneratorParams>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_Params(const FEnvelopeFollowerGeneratorParams& Value) { Write<FEnvelopeFollowerGeneratorParams>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
class USoundModulationGeneratorLFO : public USoundModulationGenerator
{
public:
    FSoundModulationLFOParams Params() const { return Read<FSoundModulationLFOParams>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_Params(const FSoundModulationLFOParams& Value) { Write<FSoundModulationLFOParams>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x60
class USoundControlBus : public USoundModulatorBase
{
public:
    bool bBypass() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    FString address() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    TArray<USoundModulationGenerator*> Generators() const { return Read<TArray<USoundModulationGenerator*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    USoundModulationParameter* Parameter() const { return Read<USoundModulationParameter*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)

    void SET_bBypass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_address(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_Generators(const TArray<USoundModulationGenerator*>& Value) { Write<TArray<USoundModulationGenerator*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_Parameter(const USoundModulationParameter*& Value) { Write<USoundModulationParameter*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class USoundControlBusMix : public UObject
{
public:
    uint32_t ProfileIndex() const { return Read<uint32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: UInt32Property)
    double duration() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    bool bRetriggerOnActivation() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    TArray<FSoundControlBusMixStage> MixStages() const { return Read<TArray<FSoundControlBusMixStage>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_ProfileIndex(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: UInt32Property)
    void SET_duration(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_bRetriggerOnActivation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_MixStages(const TArray<FSoundControlBusMixStage>& Value) { Write<TArray<FSoundControlBusMixStage>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class USoundModulationParameter : public UObject
{
public:
    FSoundModulationParameterSettings Settings() const { return Read<FSoundModulationParameterSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)

    void SET_Settings(const FSoundModulationParameterSettings& Value) { Write<FSoundModulationParameterSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
};

// Size: 0x40
class USoundModulationParameterScaled : public USoundModulationParameter
{
public:
    float UnitMin() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float UnitMax() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_UnitMin(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_UnitMax(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class USoundModulationParameterFrequencyBase : public USoundModulationParameter
{
public:
};

// Size: 0x40
class USoundModulationParameterFrequency : public USoundModulationParameterFrequencyBase
{
public:
    float UnitMin() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float UnitMax() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_UnitMin(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_UnitMax(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class USoundModulationParameterFilterFrequency : public USoundModulationParameterFrequencyBase
{
public:
};

// Size: 0x38
class USoundModulationParameterLPFFrequency : public USoundModulationParameterFilterFrequency
{
public:
};

// Size: 0x38
class USoundModulationParameterHPFFrequency : public USoundModulationParameterFilterFrequency
{
public:
};

// Size: 0x40
class USoundModulationParameterBipolar : public USoundModulationParameter
{
public:
    float UnitRange() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_UnitRange(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
class USoundModulationParameterVolume : public USoundModulationParameter
{
public:
    float MinVolume() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_MinVolume(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
class USoundModulationParameterAdditive : public USoundModulationParameter
{
public:
    float UnitMin() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float UnitMax() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_UnitMin(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_UnitMax(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
class USoundModulationPatch : public USoundModulatorBase
{
public:
    FSoundControlModulationPatch PatchSettings() const { return Read<FSoundControlModulationPatch>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_PatchSettings(const FSoundControlModulationPatch& Value) { Write<FSoundControlModulationPatch>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x14
struct FSoundModulationADEnvelopeParams
{
public:
    float AttackTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float DecayTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float AttackCurve() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float DecayCurve() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bLooping() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bBypass() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)

    void SET_AttackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_DecayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_AttackCurve(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_DecayCurve(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bLooping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bBypass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FEnvelopeFollowerGeneratorParams
{
public:
    bool bBypass() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    UAudioBus* AudioBus() const { return Read<UAudioBus*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float Gain() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float AttackTime() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float ReleaseTime() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_bBypass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_AudioBus(const UAudioBus*& Value) { Write<UAudioBus*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Gain(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_AttackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_ReleaseTime(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FSoundModulationLFOParams
{
public:
    uint8_t Shape() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float ExponentialFactor() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Width() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Amplitude() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Offset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Phase() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bLooping() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    bool bBypass() const { return Read<bool>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: BoolProperty)

    void SET_Shape(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ExponentialFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Width(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Amplitude(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Offset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Phase(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bLooping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_bBypass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FSoundControlBusMixStage
{
public:
    USoundControlBus* Bus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FSoundModulationMixValue Value() const { return Read<FSoundModulationMixValue>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_Bus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Value(const FSoundModulationMixValue& Value) { Write<FSoundModulationMixValue>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x20
struct FSoundModulationMixValue
{
public:
    float TargetValue() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float AttackTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ReleaseTime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_TargetValue(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_AttackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ReleaseTime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FSoundModulationParameterSettings
{
public:
    float ValueNormalized() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_ValueNormalized(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb8
struct FSoundModulationTransform : public FWaveTableTransform
{
public:
};

// Size: 0xc8
struct FSoundControlModulationInput
{
public:
    bool bSampleAndHold() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    FSoundModulationTransform Transform() const { return Read<FSoundModulationTransform>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0xb8, Type: StructProperty)
    USoundControlBus* Bus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_bSampleAndHold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_Transform(const FSoundModulationTransform& Value) { Write<FSoundModulationTransform>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0xb8, Type: StructProperty)
    void SET_Bus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FSoundControlModulationPatch
{
public:
    bool bBypass() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    USoundModulationParameter* OutputParameter() const { return Read<USoundModulationParameter*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<FSoundControlModulationInput> Inputs() const { return Read<TArray<FSoundControlModulationInput>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_bBypass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_OutputParameter(const USoundModulationParameter*& Value) { Write<USoundModulationParameter*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Inputs(const TArray<FSoundControlModulationInput>& Value) { Write<TArray<FSoundControlModulationInput>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

