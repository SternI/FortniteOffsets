/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeployableTurretGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "AnimationBudgetAllocator.h"

// Size: 0x420
class UDeployableTurretAnimInstance : public UAnimInstance
{
public:
    bool bIsAttacking() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x0) & 1; } // 0x3d8:0 (Size: 0x1, Type: BoolProperty)
    bool bIsWindUp() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x1) & 1; } // 0x3d8:1 (Size: 0x1, Type: BoolProperty)
    bool bIsTracking() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x2) & 1; } // 0x3d8:2 (Size: 0x1, Type: BoolProperty)
    bool bIsWindDown() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x3) & 1; } // 0x3d8:3 (Size: 0x1, Type: BoolProperty)
    bool bIsDeactivated() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x4) & 1; } // 0x3d8:4 (Size: 0x1, Type: BoolProperty)
    bool bIsScanning() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x5) & 1; } // 0x3d8:5 (Size: 0x1, Type: BoolProperty)
    bool bIsAggro() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x6) & 1; } // 0x3d8:6 (Size: 0x1, Type: BoolProperty)
    bool bFallAndDeployToDeactivated() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d8) >> 0x7) & 1; } // 0x3d8:7 (Size: 0x1, Type: BoolProperty)
    bool bFallAndDeployToScan() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d9) >> 0x0) & 1; } // 0x3d9:0 (Size: 0x1, Type: BoolProperty)
    bool bAggroToFire() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d9) >> 0x1) & 1; } // 0x3d9:1 (Size: 0x1, Type: BoolProperty)
    bool bInterruptibleCurveOverThreshold() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d9) >> 0x2) & 1; } // 0x3d9:2 (Size: 0x1, Type: BoolProperty)
    bool bTurnEndCurveOverThreshold() const { return (Read<uint8_t>(uintptr_t(this) + 0x3d9) >> 0x3) & 1; } // 0x3d9:3 (Size: 0x1, Type: BoolProperty)
    FName InterruptibleCurveName() const { return Read<FName>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: NameProperty)
    float InterruptibleCurveThreshold() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    FName TurnEndCurveName() const { return Read<FName>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: NameProperty)
    float TurnEndCurveThreshold() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    FRotator AimRotationInComponentSpace() const { return Read<FRotator>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x18, Type: StructProperty)
    FRotator SurfaceRotation() const { return Read<FRotator>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x18, Type: StructProperty)

    void SET_bIsAttacking(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsWindUp(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTracking(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsWindDown(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsDeactivated(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsScanning(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsAggro(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:6 (Size: 0x1, Type: BoolProperty)
    void SET_bFallAndDeployToDeactivated(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d8); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x3d8, B); } // 0x3d8:7 (Size: 0x1, Type: BoolProperty)
    void SET_bFallAndDeployToScan(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d9); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x3d9, B); } // 0x3d9:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAggroToFire(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d9); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x3d9, B); } // 0x3d9:1 (Size: 0x1, Type: BoolProperty)
    void SET_bInterruptibleCurveOverThreshold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d9); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x3d9, B); } // 0x3d9:2 (Size: 0x1, Type: BoolProperty)
    void SET_bTurnEndCurveOverThreshold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3d9); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x3d9, B); } // 0x3d9:3 (Size: 0x1, Type: BoolProperty)
    void SET_InterruptibleCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: NameProperty)
    void SET_InterruptibleCurveThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    void SET_TurnEndCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: NameProperty)
    void SET_TurnEndCurveThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_AimRotationInComponentSpace(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x18, Type: StructProperty)
    void SET_SurfaceRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
class UDeployableTurretLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
struct FDeployableTurretBPAnimData
{
public:
    FRotator AimRotation() const { return Read<FRotator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    float SurfaceRollDegrees() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float SurfacePitchDegrees() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    uint8_t State() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_AimRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_SurfaceRollDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_SurfacePitchDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_State(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

