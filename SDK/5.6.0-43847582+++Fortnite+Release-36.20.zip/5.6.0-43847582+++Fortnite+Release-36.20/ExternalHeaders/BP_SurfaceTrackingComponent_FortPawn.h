/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_SurfaceTrackingComponent_FortPawn
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x1b8
class UBP_SurfaceTrackingComponent_FortPawn_C : public UFortSurfaceTrackingComponent
{
public:
};

