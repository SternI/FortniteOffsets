/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DLSSBlueprint
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28
class UDLSSLibrary : public UBlueprintFunctionLibrary
{
public:
};

