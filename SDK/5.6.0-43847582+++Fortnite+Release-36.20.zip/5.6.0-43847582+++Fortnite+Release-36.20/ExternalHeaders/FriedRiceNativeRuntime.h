/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FriedRiceNativeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x6e0
class AFriedRiceRootPlayspace : public AFortPlayspace
{
public:
};

