/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCoreDevicesUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModelViewViewModel.h"
#include "Engine.h"
#include "UMG.h"
#include "CoreUObject.h"

// Size: 0x428
class UFortCreativeTimerContainerWidget : public UFortHUDElementWidget
{
public:
    UClass* TimerViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ClassProperty)
    UClass* TimerWidgetDefaultClass() const { return Read<UClass*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ClassProperty)
    TMap<UObject*, FViewModelRelation> InterfaceViewModelMap() const { return Read<TMap<UObject*, FViewModelRelation>>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x50, Type: MapProperty)
    TScriptInterface<Class> ActiveInterface() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x10, Type: InterfaceProperty)

    void SET_TimerViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ClassProperty)
    void SET_TimerWidgetDefaultClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ClassProperty)
    void SET_InterfaceViewModelMap(const TMap<UObject*, FViewModelRelation>& Value) { Write<TMap<UObject*, FViewModelRelation>>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x50, Type: MapProperty)
    void SET_ActiveInterface(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x10
struct FViewModelRelation
{
public:
};

