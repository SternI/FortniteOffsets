/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkItems
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x108
class UCosmeticDataComponent : public UActorComponent
{
public:
    TMap<FGameplayTag, FInstancedStructContainer> PropertyContainers() const { return Read<TMap<FGameplayTag, FInstancedStructContainer>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)

    void SET_PropertyContainers(const TMap<FGameplayTag, FInstancedStructContainer>& Value) { Write<TMap<FGameplayTag, FInstancedStructContainer>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x4
struct FCosmeticPropertyBase
{
public:
    FGameplayTag PropertyTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_PropertyTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x20
struct FCosmeticProperty_Vector : public FCosmeticPropertyBase
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FCosmeticProperty_TableRow : public FCosmeticPropertyBase
{
public:
    FDataTableRowHandle TableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_TableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FCosmeticProperty_GameplayTag : public FCosmeticPropertyBase
{
public:
    FGameplayTag GameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_GameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

