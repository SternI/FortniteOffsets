/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaWorld
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xc0
class UDianaWorldTileSelection : public UJunoWorldTileSelectionBase
{
public:
};

