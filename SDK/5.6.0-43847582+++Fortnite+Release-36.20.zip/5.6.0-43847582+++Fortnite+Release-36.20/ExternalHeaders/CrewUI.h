/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CrewUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "FortniteUI.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x58
class UFortAsyncAction_CrewCancelSubscription : public UBlueprintAsyncActionBase
{
public:
};

// Size: 0x28
class UFortProgressiveContentInterface : public UInterface
{
public:
};

// Size: 0xc8
class UFortTemporaryItemsComponent : public UControllerComponent
{
public:
    UFortTemporaryItemsManager* TemporaryItemsManager() const { return Read<UFortTemporaryItemsManager*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortMcpProfileAthena*> AthenaProfile() const { return Read<TWeakObjectPtr<UFortMcpProfileAthena*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TemporaryItemsManager(const UFortTemporaryItemsManager*& Value) { Write<UFortTemporaryItemsManager*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_AthenaProfile(const TWeakObjectPtr<UFortMcpProfileAthena*>& Value) { Write<TWeakObjectPtr<UFortMcpProfileAthena*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x60
class UFortTemporaryItemsManager : public UWorldSubsystem
{
public:
};

// Size: 0x88
class UFortTemporaryItemsRewardGroupVM : public UMVVMViewModelBase
{
public:
    uint8_t Category() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    TArray<UFortTemporaryItemsRewardVM*> Rewards() const { return Read<TArray<UFortTemporaryItemsRewardVM*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_Category(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_Rewards(const TArray<UFortTemporaryItemsRewardVM*>& Value) { Write<TArray<UFortTemporaryItemsRewardVM*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
class UFortTemporaryItemsRewardVM : public UMVVMViewModelBase
{
public:
    UFortAccountItemDefinition* ItemDefinition() const { return Read<UFortAccountItemDefinition*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    bool bIsOwned() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_ItemDefinition(const UFortAccountItemDefinition*& Value) { Write<UFortAccountItemDefinition*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsOwned(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x318
class UFortTemporaryItemsRow : public UUserWidget
{
public:
};

// Size: 0x1500
class UFortTemporaryItemsTileButton : public UCommonButtonBase
{
public:
    UFortCosmeticItemCard* ItemCard() const { return Read<UFortCosmeticItemCard*>(uintptr_t(this) + 0x14f8); } // 0x14f8 (Size: 0x8, Type: ObjectProperty)

    void SET_ItemCard(const UFortCosmeticItemCard*& Value) { Write<UFortCosmeticItemCard*>(uintptr_t(this) + 0x14f8, Value); } // 0x14f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x90
class UFortTemporaryItemsVM : public UFortPerUserViewModel
{
public:
    TArray<UFortTemporaryItemsRewardGroupVM*> RewardGroups() const { return Read<TArray<UFortTemporaryItemsRewardGroupVM*>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    FDateTime ExpirationDate() const { return Read<FDateTime>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: StructProperty)
    UFortTemporaryItemsManager* TemporaryItemsManager() const { return Read<UFortTemporaryItemsManager*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)

    void SET_RewardGroups(const TArray<UFortTemporaryItemsRewardGroupVM*>& Value) { Write<TArray<UFortTemporaryItemsRewardGroupVM*>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_ExpirationDate(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: StructProperty)
    void SET_TemporaryItemsManager(const UFortTemporaryItemsManager*& Value) { Write<UFortTemporaryItemsManager*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
class UCrewAsyncActions : public UFortAsyncAction_FromFunctionBase
{
public:
};

// Size: 0x50
class UCrewShopOfferOverride : public UFortItemShopOfferInspectionScreenOverrideBase
{
public:
};

// Size: 0x530
class UCrewStandaloneSubscriptionContentContainer : public UFortStandaloneFrontend
{
public:
    UCrewSubscriptionContentContainer* Widget_CrewContentContainer() const { return Read<UCrewSubscriptionContentContainer*>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: ObjectProperty)

    void SET_Widget_CrewContentContainer(const UCrewSubscriptionContentContainer*& Value) { Write<UCrewSubscriptionContentContainer*>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4f0
class UCrewSubscriptionContentContainer : public UCommonActivatableWidget
{
public:
    TArray<FCrewSubscriptionContentTabData> TabsData() const { return Read<TArray<FCrewSubscriptionContentTabData>>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    FDataTableRowHandle NextTabInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle PreviousTabInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x10, Type: StructProperty)
    UDynamicEntryBox* EntryBox_Tabs() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonGroupBase* ButtonGroup_Tabs() const { return Read<UCommonButtonGroupBase*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UCommonActivatableWidgetSwitcher* Switcher_Tabs() const { return Read<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_TabsContainer() const { return Read<UWidget*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    float SpacingAdjustmentForTabs() const { return Read<float>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x4, Type: FloatProperty)
    FPrimaryContentSetup ContentSetup() const { return Read<FPrimaryContentSetup>(uintptr_t(this) + 0x4d4); } // 0x4d4 (Size: 0x4, Type: StructProperty)

    void SET_TabsData(const TArray<FCrewSubscriptionContentTabData>& Value) { Write<TArray<FCrewSubscriptionContentTabData>>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    void SET_NextTabInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x10, Type: StructProperty)
    void SET_PreviousTabInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x10, Type: StructProperty)
    void SET_EntryBox_Tabs(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonGroup_Tabs(const UCommonButtonGroupBase*& Value) { Write<UCommonButtonGroupBase*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Tabs(const UCommonActivatableWidgetSwitcher*& Value) { Write<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_TabsContainer(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpacingAdjustmentForTabs(const float& Value) { Write<float>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x4, Type: FloatProperty)
    void SET_ContentSetup(const FPrimaryContentSetup& Value) { Write<FPrimaryContentSetup>(uintptr_t(this) + 0x4d4, Value); } // 0x4d4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x48
class UCrewUIGameFeatureDataAction : public UFortUIGameFeatureAction
{
public:
};

// Size: 0xe8
class UCrewUIGameFeatureAction : public UFortUIGameFeatureAction
{
public:
    TArray<FFortProgressiveSet> ProgressiveCosmeticSets() const { return Read<TArray<FFortProgressiveSet>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortCosmeticPreviewData> CustomCrewPreviewData() const { return Read<TArray<FFortCosmeticPreviewData>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_ProgressiveCosmeticSets(const TArray<FFortProgressiveSet>& Value) { Write<TArray<FFortProgressiveSet>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_CustomCrewPreviewData(const TArray<FFortCosmeticPreviewData>& Value) { Write<TArray<FFortCosmeticPreviewData>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x498
class UFortProgressiveContentContainer : public UFortSubscriptionContentBase
{
public:
    UCommonActivatableWidgetSwitcher* Switcher_PrimaryContent() const { return Read<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UFortProgressiveTableOfContentsScreen* Widget_ProgressiveTableOfContentsScreen() const { return Read<UFortProgressiveTableOfContentsScreen*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UFortProgressiveItemScreen* Widget_ProgressiveItemScreen() const { return Read<UFortProgressiveItemScreen*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)

    void SET_Switcher_PrimaryContent(const UCommonActivatableWidgetSwitcher*& Value) { Write<UCommonActivatableWidgetSwitcher*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_ProgressiveTableOfContentsScreen(const UFortProgressiveTableOfContentsScreen*& Value) { Write<UFortProgressiveTableOfContentsScreen*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_ProgressiveItemScreen(const UFortProgressiveItemScreen*& Value) { Write<UFortProgressiveItemScreen*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4c8
class UFortProgressiveItemScreen : public UFortProgressiveScreenBase
{
public:
};

// Size: 0x4a8
class UFortProgressiveScreenBase : public UCommonActivatableWidget
{
public:
};

// Size: 0x4c8
class UFortProgressiveTableOfContentsScreen : public UFortProgressiveScreenBase
{
public:
};

// Size: 0x100
class UCrewBenefitVM : public UFortPerUserViewModel
{
public:
    TArray<UFortItemVM*> CrewPackItems() const { return Read<TArray<UFortItemVM*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)

    void SET_CrewPackItems(const TArray<UFortItemVM*>& Value) { Write<TArray<UFortItemVM*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
class UCrewItemShopDataVM : public UMVVMViewModelBase
{
public:
    FText HighlightText() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    uint8_t HighlightIntensity() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    FString TileImageURL() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)

    void SET_HighlightText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_HighlightIntensity(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_TileImageURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
};

// Size: 0x78
class UCrewCancellationInfoVM : public UMVVMViewModelBase
{
public:
    TArray<FText> BulletPoints() const { return Read<TArray<FText>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_BulletPoints(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x100
class UCrewPlatformAndCountriesNotificationVM : public UFortPerUserViewModel
{
public:
    FText Title() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    FText BodyText() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FText CheckboxText() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)
    FText ConfirmButtonText() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)
    FText CancelSubscriptionButtonText() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText MoreInfoText() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    FText MoreInfoUrl() const { return Read<FText>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: TextProperty)
    TArray<FCrewTableRow> TableRows() const { return Read<TArray<FCrewTableRow>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)

    void SET_Title(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_BodyText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_CheckboxText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
    void SET_ConfirmButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
    void SET_CancelSubscriptionButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_MoreInfoText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_MoreInfoUrl(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: TextProperty)
    void SET_TableRows(const TArray<FCrewTableRow>& Value) { Write<TArray<FCrewTableRow>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UCrewSubscriptionModalInfoVM : public UMVVMViewModelBase
{
public:
    FString ModalId() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    TArray<FText> Entries() const { return Read<TArray<FText>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    FString QrCodeImageUrl() const { return Read<FString>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StrProperty)

    void SET_ModalId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_Entries(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_QrCodeImageUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StrProperty)
};

// Size: 0xa8
class UCrewProgressiveItemsVM : public UFortPerUserViewModel
{
public:
    TArray<UCrewProgressiveSetVM*> AllSets() const { return Read<TArray<UCrewProgressiveSetVM*>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<UCrewProgressiveSetVM*> VisibleSets() const { return Read<TArray<UCrewProgressiveSetVM*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortCosmeticPreviewData> PreviewData() const { return Read<TArray<FFortCosmeticPreviewData>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    bool bAllSetsComplete() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_AllSets(const TArray<UCrewProgressiveSetVM*>& Value) { Write<TArray<UCrewProgressiveSetVM*>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_VisibleSets(const TArray<UCrewProgressiveSetVM*>& Value) { Write<TArray<UCrewProgressiveSetVM*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviewData(const TArray<FFortCosmeticPreviewData>& Value) { Write<TArray<FFortCosmeticPreviewData>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllSetsComplete(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
class UCrewProgressiveRewardVM : public UMVVMViewModelBase
{
public:
    FText Name() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface> TileMaterial() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x20, Type: SoftObjectProperty)
    TArray<UFortItemVM*> Items() const { return Read<TArray<UFortItemVM*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FCosmeticVariantInfo> PreviewVariants() const { return Read<TArray<FCosmeticVariantInfo>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    bool bAllowPreviewStyles() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_TileMaterial(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Items(const TArray<UFortItemVM*>& Value) { Write<TArray<UFortItemVM*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviewVariants(const TArray<FCosmeticVariantInfo>& Value) { Write<TArray<FCosmeticVariantInfo>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllowPreviewStyles(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf0
class UCrewProgressiveSelectionVM : public UFortPerUserViewModel
{
public:
    UCrewProgressiveRewardVM* SelectedReward() const { return Read<UCrewProgressiveRewardVM*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    UCrewProgressiveStageVM* SelectedStage() const { return Read<UCrewProgressiveStageVM*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    UCrewProgressiveSetVM* SelectedSet() const { return Read<UCrewProgressiveSetVM*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    UFortItemVM* PreviewItem() const { return Read<UFortItemVM*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    FFortCosmeticPreviewData PreviewData() const { return Read<FFortCosmeticPreviewData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x50, Type: StructProperty)

    void SET_SelectedReward(const UCrewProgressiveRewardVM*& Value) { Write<UCrewProgressiveRewardVM*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedStage(const UCrewProgressiveStageVM*& Value) { Write<UCrewProgressiveStageVM*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedSet(const UCrewProgressiveSetVM*& Value) { Write<UCrewProgressiveSetVM*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviewItem(const UFortItemVM*& Value) { Write<UFortItemVM*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviewData(const FFortCosmeticPreviewData& Value) { Write<FFortCosmeticPreviewData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x50, Type: StructProperty)
};

// Size: 0xe8
class UCrewProgressiveSetVM : public UMVVMViewModelBase
{
public:
    FString FulfillmentId() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FText Name() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface> TileMaterial() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    TArray<UCrewProgressiveStageVM*> Stages() const { return Read<TArray<UCrewProgressiveStageVM*>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    FDateTime CutoffDate() const { return Read<FDateTime>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: StructProperty)
    FDateTime AcquisitionCutoffDate() const { return Read<FDateTime>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: StructProperty)
    FDateTime AcquireStartDate() const { return Read<FDateTime>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: StructProperty)
    FText AcquisitionCutoffDateText() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    int32_t UnlockedStages() const { return Read<int32_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: IntProperty)
    uint8_t Progress() const { return Read<uint8_t>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x1, Type: EnumProperty)

    void SET_FulfillmentId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_Name(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_TileMaterial(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Stages(const TArray<UCrewProgressiveStageVM*>& Value) { Write<TArray<UCrewProgressiveStageVM*>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_CutoffDate(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: StructProperty)
    void SET_AcquisitionCutoffDate(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: StructProperty)
    void SET_AcquireStartDate(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: StructProperty)
    void SET_AcquisitionCutoffDateText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_UnlockedStages(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: IntProperty)
    void SET_Progress(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x98
class UCrewProgressiveStageVM : public UMVVMViewModelBase
{
public:
    TArray<UCrewProgressiveRewardVM*> Rewards() const { return Read<TArray<UCrewProgressiveRewardVM*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FText UnlockCriteria() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    int32_t StageIndex() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t RemainingMonths() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    bool bIsOwned() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)

    void SET_Rewards(const TArray<UCrewProgressiveRewardVM*>& Value) { Write<TArray<UCrewProgressiveRewardVM*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_UnlockCriteria(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_StageIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_RemainingMonths(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_bIsOwned(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UCrewSelectionVM : public UFortPerUserViewModel
{
public:
    UCrewBenefitVM* HoveredBenefit() const { return Read<UCrewBenefitVM*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    UCrewBenefitVM* SelectedBenefit() const { return Read<UCrewBenefitVM*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_HoveredBenefit(const UCrewBenefitVM*& Value) { Write<UCrewBenefitVM*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedBenefit(const UCrewBenefitVM*& Value) { Write<UCrewBenefitVM*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x270
class UCrewVM : public UFortPerUserViewModel
{
public:
    uint8_t SubscriptionState() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    bool bIsLegacySubscription() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)
    bool bCanPurchaseSubscription() const { return Read<bool>(uintptr_t(this) + 0x72); } // 0x72 (Size: 0x1, Type: BoolProperty)
    FDateTime SubscriptionStartDate() const { return Read<FDateTime>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)
    TArray<EAppStore> SubscriptionPlatforms() const { return Read<TArray<EAppStore>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    int32_t NumAutoRenewSubscriptions() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    FText Title() const { return Read<FText>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: TextProperty)
    FText Description() const { return Read<FText>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription() const { return Read<FText>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: TextProperty)
    FString BackgroundURL() const { return Read<FString>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StrProperty)
    FString SubscribedBackgroundURL() const { return Read<FString>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StrProperty)
    FString OverrideUpsellPass() const { return Read<FString>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: StrProperty)
    bool bCrewOnRightInUpsell() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    bool bCrew50PercentInUpsell() const { return Read<bool>(uintptr_t(this) + 0xf9); } // 0xf9 (Size: 0x1, Type: BoolProperty)
    bool bCrewOnlyInUpsell() const { return Read<bool>(uintptr_t(this) + 0xfa); } // 0xfa (Size: 0x1, Type: BoolProperty)
    bool bPassOnlyInUpsell() const { return Read<bool>(uintptr_t(this) + 0xfb); } // 0xfb (Size: 0x1, Type: BoolProperty)
    FCrewUpsellConfig CMSUpsellConfig() const { return Read<FCrewUpsellConfig>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x40, Type: StructProperty)
    FCrewUpsellConfig ExperimentUpsellConfig() const { return Read<FCrewUpsellConfig>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x40, Type: StructProperty)
    FText Disclaimer() const { return Read<FText>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: TextProperty)
    FText SubscriptionButtonText() const { return Read<FText>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: TextProperty)
    FText PriceText() const { return Read<FText>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: TextProperty)
    FText UserInformationTextPrimary() const { return Read<FText>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    FText UserInformationTextSecondary() const { return Read<FText>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    FText PaymentLegalText() const { return Read<FText>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    TArray<FText> ProgressiveInfoInfoModalEntries() const { return Read<TArray<FText>>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: ArrayProperty)
    FText ProgressiveInfoNewStagesUnlockFinePrint() const { return Read<FText>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: TextProperty)
    TArray<FText> TemporaryItemsInfoModalEntries() const { return Read<TArray<FText>>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortItemVM*> CrewPackItems() const { return Read<TArray<UFortItemVM*>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    UCrewCancellationInfoVM* CancellationInfo() const { return Read<UCrewCancellationInfoVM*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    UCrewItemShopDataVM* SubscriptionShopData() const { return Read<UCrewItemShopDataVM*>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: ObjectProperty)
    UCrewItemShopDataVM* CrewShopData() const { return Read<UCrewItemShopDataVM*>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x8, Type: ObjectProperty)
    TArray<UCrewBenefitVM*> RecurringBenefits() const { return Read<TArray<UCrewBenefitVM*>>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x10, Type: ArrayProperty)
    TArray<UCrewBenefitVM*> LimitedTimeBenefits() const { return Read<TArray<UCrewBenefitVM*>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x10, Type: ArrayProperty)
    TArray<UCrewSubscriptionModalInfoVM*> SubscriptionModals() const { return Read<TArray<UCrewSubscriptionModalInfoVM*>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    UCrewBenefitVM* PreviewBenefit() const { return Read<UCrewBenefitVM*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ObjectProperty)

    void SET_SubscriptionState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_bIsLegacySubscription(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
    void SET_bCanPurchaseSubscription(const bool& Value) { Write<bool>(uintptr_t(this) + 0x72, Value); } // 0x72 (Size: 0x1, Type: BoolProperty)
    void SET_SubscriptionStartDate(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
    void SET_SubscriptionPlatforms(const TArray<EAppStore>& Value) { Write<TArray<EAppStore>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_NumAutoRenewSubscriptions(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_Title(const FText& Value) { Write<FText>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: TextProperty)
    void SET_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: TextProperty)
    void SET_ShortDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: TextProperty)
    void SET_BackgroundURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StrProperty)
    void SET_SubscribedBackgroundURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StrProperty)
    void SET_OverrideUpsellPass(const FString& Value) { Write<FString>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: StrProperty)
    void SET_bCrewOnRightInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    void SET_bCrew50PercentInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf9, Value); } // 0xf9 (Size: 0x1, Type: BoolProperty)
    void SET_bCrewOnlyInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfa, Value); } // 0xfa (Size: 0x1, Type: BoolProperty)
    void SET_bPassOnlyInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfb, Value); } // 0xfb (Size: 0x1, Type: BoolProperty)
    void SET_CMSUpsellConfig(const FCrewUpsellConfig& Value) { Write<FCrewUpsellConfig>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x40, Type: StructProperty)
    void SET_ExperimentUpsellConfig(const FCrewUpsellConfig& Value) { Write<FCrewUpsellConfig>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x40, Type: StructProperty)
    void SET_Disclaimer(const FText& Value) { Write<FText>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: TextProperty)
    void SET_SubscriptionButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: TextProperty)
    void SET_PriceText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: TextProperty)
    void SET_UserInformationTextPrimary(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    void SET_UserInformationTextSecondary(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    void SET_PaymentLegalText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    void SET_ProgressiveInfoInfoModalEntries(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: ArrayProperty)
    void SET_ProgressiveInfoNewStagesUnlockFinePrint(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: TextProperty)
    void SET_TemporaryItemsInfoModalEntries(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x10, Type: ArrayProperty)
    void SET_CrewPackItems(const TArray<UFortItemVM*>& Value) { Write<TArray<UFortItemVM*>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    void SET_CancellationInfo(const UCrewCancellationInfoVM*& Value) { Write<UCrewCancellationInfoVM*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    void SET_SubscriptionShopData(const UCrewItemShopDataVM*& Value) { Write<UCrewItemShopDataVM*>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: ObjectProperty)
    void SET_CrewShopData(const UCrewItemShopDataVM*& Value) { Write<UCrewItemShopDataVM*>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x8, Type: ObjectProperty)
    void SET_RecurringBenefits(const TArray<UCrewBenefitVM*>& Value) { Write<TArray<UCrewBenefitVM*>>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x10, Type: ArrayProperty)
    void SET_LimitedTimeBenefits(const TArray<UCrewBenefitVM*>& Value) { Write<TArray<UCrewBenefitVM*>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x10, Type: ArrayProperty)
    void SET_SubscriptionModals(const TArray<UCrewSubscriptionModalInfoVM*>& Value) { Write<TArray<UCrewSubscriptionModalInfoVM*>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviewBenefit(const UCrewBenefitVM*& Value) { Write<UCrewBenefitVM*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
struct FCrewUpsellConfig
{
public:
    FString OverrideUpsellPass() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FMotdImage> PassBackgroundUrl() const { return Read<TArray<FMotdImage>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FMotdImage> CrewBackgroundUrl() const { return Read<TArray<FMotdImage>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    bool bUsePassBackgroundMaterial() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bUseCrewBackgroundMaterial() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    bool bCrewOnRightInUpsell() const { return Read<bool>(uintptr_t(this) + 0x32); } // 0x32 (Size: 0x1, Type: BoolProperty)
    bool bCrew50PercentInUpsell() const { return Read<bool>(uintptr_t(this) + 0x33); } // 0x33 (Size: 0x1, Type: BoolProperty)
    bool bCrew30PercentInUpsell() const { return Read<bool>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: BoolProperty)
    bool bCrewAsSliver() const { return Read<bool>(uintptr_t(this) + 0x35); } // 0x35 (Size: 0x1, Type: BoolProperty)
    bool bCrewOnlyInUpsell() const { return Read<bool>(uintptr_t(this) + 0x36); } // 0x36 (Size: 0x1, Type: BoolProperty)
    bool bPassOnlyInUpsell() const { return Read<bool>(uintptr_t(this) + 0x37); } // 0x37 (Size: 0x1, Type: BoolProperty)
    bool bAnimateCrewBG() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_OverrideUpsellPass(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_PassBackgroundUrl(const TArray<FMotdImage>& Value) { Write<TArray<FMotdImage>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CrewBackgroundUrl(const TArray<FMotdImage>& Value) { Write<TArray<FMotdImage>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_bUsePassBackgroundMaterial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bUseCrewBackgroundMaterial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_bCrewOnRightInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0x32, Value); } // 0x32 (Size: 0x1, Type: BoolProperty)
    void SET_bCrew50PercentInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0x33, Value); } // 0x33 (Size: 0x1, Type: BoolProperty)
    void SET_bCrew30PercentInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: BoolProperty)
    void SET_bCrewAsSliver(const bool& Value) { Write<bool>(uintptr_t(this) + 0x35, Value); } // 0x35 (Size: 0x1, Type: BoolProperty)
    void SET_bCrewOnlyInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0x36, Value); } // 0x36 (Size: 0x1, Type: BoolProperty)
    void SET_bPassOnlyInUpsell(const bool& Value) { Write<bool>(uintptr_t(this) + 0x37, Value); } // 0x37 (Size: 0x1, Type: BoolProperty)
    void SET_bAnimateCrewBG(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FCrewSubscriptionContentTabData
{
public:
    FText TabName() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    uint8_t TabType() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_TabName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_TabType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x48
struct FFortProgressiveReward
{
public:
    TSoftObjectPtr<UMaterialInterface> TileMaterial() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    bool bHidden() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bAllowPreviewStyles() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UFortItemDefinition> RewardDef() const { return Read<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_TileMaterial(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bHidden(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowPreviewStyles(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_RewardDef(const TSoftObjectPtr<UFortItemDefinition>& Value) { Write<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x48
struct FFortProgressiveStageOverrideDisplayData
{
public:
    TArray<FCosmeticVariantInfo> DefaultVariantPreviewOverrides() const { return Read<TArray<FCosmeticVariantInfo>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface> TileMaterial() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    bool bAllowPreviewStyles() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)

    void SET_DefaultVariantPreviewOverrides(const TArray<FCosmeticVariantInfo>& Value) { Write<TArray<FCosmeticVariantInfo>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_TileMaterial(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bAllowPreviewStyles(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
struct FFortProgressiveUIStage
{
public:
    TArray<FFortProgressiveReward> Rewards() const { return Read<TArray<FFortProgressiveReward>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bUseOverrideDisplayData() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FFortProgressiveStageOverrideDisplayData OverrideDisplayData() const { return Read<FFortProgressiveStageOverrideDisplayData>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x48, Type: StructProperty)

    void SET_Rewards(const TArray<FFortProgressiveReward>& Value) { Write<TArray<FFortProgressiveReward>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseOverrideDisplayData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideDisplayData(const FFortProgressiveStageOverrideDisplayData& Value) { Write<FFortProgressiveStageOverrideDisplayData>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x48, Type: StructProperty)
};

// Size: 0x50
struct FFortProgressiveSet
{
public:
    FString FulfillmentId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FText SetName() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface> TileMaterial() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FFortProgressiveUIStage> Stages() const { return Read<TArray<FFortProgressiveUIStage>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_FulfillmentId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_SetName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_TileMaterial(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Stages(const TArray<FFortProgressiveUIStage>& Value) { Write<TArray<FFortProgressiveUIStage>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

