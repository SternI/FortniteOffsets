/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DemonArenaGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0xaa8
class ADemonArenaPlayspace : public AFortPlayspace
{
public:
    UClass* WhileInsideGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x8, Type: ClassProperty)
    bool bCanBeMarked() const { return (Read<uint8_t>(uintptr_t(this) + 0x6f0) >> 0x0) & 1; } // 0x6f0:0 (Size: 0x1, Type: BoolProperty)
    bool bBlockMarking() const { return (Read<uint8_t>(uintptr_t(this) + 0x6f0) >> 0x1) & 1; } // 0x6f0:1 (Size: 0x1, Type: BoolProperty)
    FMarkedActorDisplayInfo MarkerDisplay() const { return Read<FMarkedActorDisplayInfo>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0xb0, Type: StructProperty)
    FVector MarkerPositionOffset() const { return Read<FVector>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x18, Type: StructProperty)
    FVector GameplayVolumePosition() const { return Read<FVector>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x18, Type: StructProperty)
    FDemonArenaVortexOverrideParams VortexParamsOverride() const { return Read<FDemonArenaVortexOverrideParams>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x280, Type: StructProperty)

    void SET_WhileInsideGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x8, Type: ClassProperty)
    void SET_bCanBeMarked(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x6f0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x6f0, B); } // 0x6f0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bBlockMarking(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x6f0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x6f0, B); } // 0x6f0:1 (Size: 0x1, Type: BoolProperty)
    void SET_MarkerDisplay(const FMarkedActorDisplayInfo& Value) { Write<FMarkedActorDisplayInfo>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0xb0, Type: StructProperty)
    void SET_MarkerPositionOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x18, Type: StructProperty)
    void SET_GameplayVolumePosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x18, Type: StructProperty)
    void SET_VortexParamsOverride(const FDemonArenaVortexOverrideParams& Value) { Write<FDemonArenaVortexOverrideParams>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x280, Type: StructProperty)
};

// Size: 0x280
struct FDemonArenaVortexOverrideParams
{
public:
    FAirControlParams VortexParachuteControlParamsOverride() const { return Read<FAirControlParams>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x140, Type: StructProperty)
    FAirControlParams VortexSkydivingControlParamsPassive() const { return Read<FAirControlParams>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x140, Type: StructProperty)

    void SET_VortexParachuteControlParamsOverride(const FAirControlParams& Value) { Write<FAirControlParams>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x140, Type: StructProperty)
    void SET_VortexSkydivingControlParamsPassive(const FAirControlParams& Value) { Write<FAirControlParams>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x140, Type: StructProperty)
};

