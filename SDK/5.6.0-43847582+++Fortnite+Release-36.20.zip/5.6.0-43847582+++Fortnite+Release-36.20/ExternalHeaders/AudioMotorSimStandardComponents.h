/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMotorSimStandardComponents
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0x170
class UBoostMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float ThrottleScale() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float InterpExp() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float InterpTime() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    bool ScaleThrottleWithBoostStrength() const { return Read<bool>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    bool bModifyPitch() const { return Read<bool>(uintptr_t(this) + 0xd5); } // 0xd5 (Size: 0x1, Type: BoolProperty)
    float PitchModifierInterpSpeed() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve BoostToPitchCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x88, Type: StructProperty)

    void SET_ThrottleScale(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_InterpExp(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_InterpTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleThrottleWithBoostStrength(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    void SET_bModifyPitch(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd5, Value); } // 0xd5 (Size: 0x1, Type: BoolProperty)
    void SET_PitchModifierInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_BoostToPitchCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x88, Type: StructProperty)
};

// Size: 0x130
class UMotorPhysicsSimComponent : public UAudioMotorSimComponent
{
public:
    float Weight() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float EngineTorque() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float BrakingHorsePower() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    TArray<float> GearRatios() const { return Read<TArray<float>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    float ClutchedGearRatio() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    bool bUseInfiniteGears() const { return Read<bool>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x1, Type: BoolProperty)
    bool bAlwaysDownshiftToZerothGear() const { return Read<bool>(uintptr_t(this) + 0xed); } // 0xed (Size: 0x1, Type: BoolProperty)
    float InfiniteGearRatio() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float UpShiftMaxRpm() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    float DownShiftStartRpm() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float ClutchedForceModifier() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float ClutchedDecelScale() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    float EngineGearRatio() const { return Read<float>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: FloatProperty)
    float EngineFriction() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float GroundFriction() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    float WindResistancePerVelocity() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    float ThrottleInterpolationTime() const { return Read<float>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: FloatProperty)
    float RpmInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: FloatProperty)

    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_EngineTorque(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_BrakingHorsePower(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_GearRatios(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_ClutchedGearRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_bUseInfiniteGears(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x1, Type: BoolProperty)
    void SET_bAlwaysDownshiftToZerothGear(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed, Value); } // 0xed (Size: 0x1, Type: BoolProperty)
    void SET_InfiniteGearRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_UpShiftMaxRpm(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_DownShiftStartRpm(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_ClutchedForceModifier(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_ClutchedDecelScale(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_EngineGearRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: FloatProperty)
    void SET_EngineFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_GroundFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_WindResistancePerVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_ThrottleInterpolationTime(const float& Value) { Write<float>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: FloatProperty)
    void SET_RpmInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x158
class UResistanceMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float UpSpeedMaxFriction() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SideSpeedFrictionCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x88, Type: StructProperty)

    void SET_UpSpeedMaxFriction(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_SideSpeedFrictionCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x88, Type: StructProperty)
};

// Size: 0xd0
class UReverseMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float ReverseEngineResistanceModifier() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)

    void SET_ReverseEngineResistanceModifier(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x118
class URevLimiterMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float LimitTime() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float DecelScale() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float AirMaxThrottleTime() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float SideSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    float LimiterMaxRpm() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    bool bRevLimitOnClutchEngaged() const { return Read<bool>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x1, Type: BoolProperty)
    float RecoverRPM() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)

    void SET_LimitTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_DecelScale(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_AirMaxThrottleTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_SideSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_LimiterMaxRpm(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_bRevLimitOnClutchEngaged(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x1, Type: BoolProperty)
    void SET_RecoverRPM(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x100
class URpmCurveMotorSimComponent : public UAudioMotorSimComponent
{
public:
    TArray<FMotorSimGearCurve> Gears() const { return Read<TArray<FMotorSimGearCurve>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    float InterpSpeed() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)

    void SET_Gears(const TArray<FMotorSimGearCurve>& Value) { Write<TArray<FMotorSimGearCurve>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_InterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x108
class UThrottleStateMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float BlowoffMinThrottleTime() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)

    void SET_BlowoffMinThrottleTime(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x170
class UVelocitySyncMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float NoThrottleTime() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float SpeedThreshold() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SpeedToRpmCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x88, Type: StructProperty)
    float InterpSpeed() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    float InterpTime() const { return Read<float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: FloatProperty)
    float FirstGearThrottleThreshold() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)

    void SET_NoThrottleTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_SpeedToRpmCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x88, Type: StructProperty)
    void SET_InterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_InterpTime(const float& Value) { Write<float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: FloatProperty)
    void SET_FirstGearThrottleThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FMotorPhysicsSimConfigData : public FAudioMotorSimConfigData
{
public:
    float Weight() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float EngineTorque() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float BrakingHorsePower() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EngineTorque(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_BrakingHorsePower(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FMotorSimGearCurve
{
public:
    FRuntimeFloatCurve RpmCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x88, Type: StructProperty)
    float SpeedTopThreshold() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)

    void SET_RpmCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x88, Type: StructProperty)
    void SET_SpeedTopThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
};

