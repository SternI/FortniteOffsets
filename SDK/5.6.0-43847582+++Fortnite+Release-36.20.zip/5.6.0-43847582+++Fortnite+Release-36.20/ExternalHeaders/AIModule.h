/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AIModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTasks.h"
#include "GameplayTags.h"
#include "NavigationSystem.h"

// Size: 0x68
class UAIAsyncTaskBlueprintProxy : public UObject
{
public:
};

// Size: 0x28
class UAIResourceInterface : public UInterface
{
public:
};

// Size: 0x108
class UAISenseBlueprintListener : public UUserDefinedStruct
{
public:
};

// Size: 0x48
class UAISenseConfig : public UObject
{
public:
    FColor DebugColor() const { return Read<FColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    float MaxAge() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bStartsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x30) >> 0x0) & 1; } // 0x30:0 (Size: 0x1, Type: BoolProperty)

    void SET_DebugColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_MaxAge(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bStartsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x30); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x30, B); } // 0x30:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UAISenseConfig_Blueprint : public UAISenseConfig
{
public:
    UClass* Implementation() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)

    void SET_Implementation(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x60
class UAISenseConfig_Hearing : public UAISenseConfig
{
public:
    UClass* Implementation() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)
    float HearingRange() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float LoSHearingRange() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    bool bUseLoSHearing() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x0) & 1; } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    FAISenseAffiliationFilter DetectionByAffiliation() const { return Read<FAISenseAffiliationFilter>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: StructProperty)

    void SET_Implementation(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
    void SET_HearingRange(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_LoSHearingRange(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_bUseLoSHearing(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    void SET_DetectionByAffiliation(const FAISenseAffiliationFilter& Value) { Write<FAISenseAffiliationFilter>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: StructProperty)
};

// Size: 0x48
class UAISenseConfig_Prediction : public UAISenseConfig
{
public:
};

// Size: 0x70
class UAISenseConfig_Sight : public UAISenseConfig
{
public:
    UClass* Implementation() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)
    float SightRadius() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float LoseSightRadius() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float PeripheralVisionAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FAISenseAffiliationFilter DetectionByAffiliation() const { return Read<FAISenseAffiliationFilter>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: StructProperty)
    float AutoSuccessRangeFromLastSeenLocation() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float PointOfViewBackwardOffset() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float NearClippingRadius() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)

    void SET_Implementation(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
    void SET_SightRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_LoseSightRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_PeripheralVisionAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_DetectionByAffiliation(const FAISenseAffiliationFilter& Value) { Write<FAISenseAffiliationFilter>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: StructProperty)
    void SET_AutoSuccessRangeFromLastSeenLocation(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_PointOfViewBackwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_NearClippingRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
class UAISenseConfig_Team : public UAISenseConfig
{
public:
};

// Size: 0x50
class UAISenseConfig_Touch : public UAISenseConfig
{
public:
    FAISenseAffiliationFilter DetectionByAffiliation() const { return Read<FAISenseAffiliationFilter>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: StructProperty)

    void SET_DetectionByAffiliation(const FAISenseAffiliationFilter& Value) { Write<FAISenseAffiliationFilter>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: StructProperty)
};

// Size: 0x78
class UAISenseEvent_Damage : public UAISenseEvent
{
public:
    FAIDamageEvent Event() const { return Read<FAIDamageEvent>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: StructProperty)

    void SET_Event(const FAIDamageEvent& Value) { Write<FAIDamageEvent>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: StructProperty)
};

// Size: 0x28
class UAISenseEvent : public UObject
{
public:
};

// Size: 0x60
class UAISenseEvent_Hearing : public UAISenseEvent
{
public:
    FAINoiseEvent Event() const { return Read<FAINoiseEvent>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x38, Type: StructProperty)

    void SET_Event(const FAINoiseEvent& Value) { Write<FAINoiseEvent>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x38, Type: StructProperty)
};

// Size: 0x50
class UBlackboardKeyType_Struct : public UBlackboardKeyType
{
public:
    FInstancedStruct DefaultValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)
    FInstancedStruct Value() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_DefaultValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
    void SET_Value(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
class UBlackboardKeyType : public UObject
{
public:
};

// Size: 0xa8
class UBTTask_SetKeyValueBool : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Bool Value() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
};

// Size: 0x98
class UBTTask_BlackboardBase : public UBTTaskNode
{
public:
    FBlackboardKeySelector BlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)

    void SET_BlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
};

// Size: 0x70
class UBTTaskNode : public UBTNode
{
public:
    TArray<UBTService*> Services() const { return Read<TArray<UBTService*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    bool bIgnoreRestartSelf() const { return (Read<uint8_t>(uintptr_t(this) + 0x68) >> 0x0) & 1; } // 0x68:0 (Size: 0x1, Type: BoolProperty)

    void SET_Services(const TArray<UBTService*>& Value) { Write<TArray<UBTService*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_bIgnoreRestartSelf(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x68); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x68, B); } // 0x68:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
class UBTNode : public UObject
{
public:
    FString NodeName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    UBehaviorTree* TreeAsset() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    UBTCompositeNode* ParentNode() const { return Read<UBTCompositeNode*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_NodeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_TreeAsset(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_ParentNode(const UBTCompositeNode*& Value) { Write<UBTCompositeNode*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
class UBTTask_SetKeyValueClass : public UBTTask_BlackboardBase
{
public:
    UClass* BaseClass() const { return Read<UClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ClassProperty)
    FValueOrBBKey_Class Value() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)

    void SET_BaseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ClassProperty)
    void SET_Value(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xc8
class UBTTask_SetKeyValueEnum : public UBTTask_BlackboardBase
{
public:
    UEnum* EnumType() const { return Read<UEnum*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    FValueOrBBKey_Enum Value() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)

    void SET_EnumType(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_Value(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa8
class UBTTask_SetKeyValueInt32 : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Int32 Value() const { return Read<FValueOrBBKey_Int32>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_Int32& Value) { Write<FValueOrBBKey_Int32>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
};

// Size: 0xa8
class UBTTask_SetKeyValueFloat : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Float Value() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
};

// Size: 0xa8
class UBTTask_SetKeyValueName : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Name Value() const { return Read<FValueOrBBKey_Name>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_Name& Value) { Write<FValueOrBBKey_Name>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
};

// Size: 0xb0
class UBTTask_SetKeyValueString : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_String Value() const { return Read<FValueOrBBKey_String>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_String& Value) { Write<FValueOrBBKey_String>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb8
class UBTTask_SetKeyValueObject : public UBTTask_BlackboardBase
{
public:
    UClass* BaseClass() const { return Read<UClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ClassProperty)
    FValueOrBBKey_Object Value() const { return Read<FValueOrBBKey_Object>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)

    void SET_BaseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ClassProperty)
    void SET_Value(const FValueOrBBKey_Object& Value) { Write<FValueOrBBKey_Object>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb8
class UBTTask_SetKeyValueRotator : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Rotator Value() const { return Read<FValueOrBBKey_Rotator>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_Rotator& Value) { Write<FValueOrBBKey_Rotator>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
};

// Size: 0xb8
class UBTTask_SetKeyValueStruct : public UBTTask_BlackboardBase
{
public:
    UScriptStruct* StructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    FValueOrBBKey_Struct Value() const { return Read<FValueOrBBKey_Struct>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)

    void SET_StructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_Value(const FValueOrBBKey_Struct& Value) { Write<FValueOrBBKey_Struct>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb8
class UBTTask_SetKeyValueVector : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Vector Value() const { return Read<FValueOrBBKey_Vector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_Vector& Value) { Write<FValueOrBBKey_Vector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UCrowdAgentInterface : public UInterface
{
public:
};

// Size: 0x28
class UEnvQueryTypes : public UObject
{
public:
};

// Size: 0x28
class UEQSQueryResultSourceInterface : public UInterface
{
public:
};

// Size: 0x50
class UGeneratedNavLinksProxy : public UBaseGeneratedNavLinksProxy
{
public:
};

// Size: 0x28
class UGenericTeamAgentInterface : public UInterface
{
public:
};

// Size: 0x28
class UValueOrBBKeyBlueprintUtility : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x3c8
class AAIController : public AController
{
public:
    bool bStartAILogicOnPossess() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x0) & 1; } // 0x378:0 (Size: 0x1, Type: BoolProperty)
    bool bStopAILogicOnUnposses() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x1) & 1; } // 0x378:1 (Size: 0x1, Type: BoolProperty)
    bool bLOSflag() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x2) & 1; } // 0x378:2 (Size: 0x1, Type: BoolProperty)
    bool bSkipExtraLOSChecks() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x3) & 1; } // 0x378:3 (Size: 0x1, Type: BoolProperty)
    bool bAllowStrafe() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x4) & 1; } // 0x378:4 (Size: 0x1, Type: BoolProperty)
    bool bWantsPlayerState() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x5) & 1; } // 0x378:5 (Size: 0x1, Type: BoolProperty)
    bool bSetControlRotationFromPawnOrientation() const { return (Read<uint8_t>(uintptr_t(this) + 0x378) >> 0x6) & 1; } // 0x378:6 (Size: 0x1, Type: BoolProperty)
    UPathFollowingComponent* PathFollowingComponent() const { return Read<UPathFollowingComponent*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UBrainComponent* BrainComponent() const { return Read<UBrainComponent*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UAIPerceptionComponent* PerceptionComponent() const { return Read<UAIPerceptionComponent*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UBlackboardComponent* Blackboard() const { return Read<UBlackboardComponent*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UGameplayTasksComponent* CachedGameplayTasksComponent() const { return Read<UGameplayTasksComponent*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UClass* DefaultNavigationFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ClassProperty)

    void SET_bStartAILogicOnPossess(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:0 (Size: 0x1, Type: BoolProperty)
    void SET_bStopAILogicOnUnposses(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:1 (Size: 0x1, Type: BoolProperty)
    void SET_bLOSflag(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:2 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipExtraLOSChecks(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:3 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowStrafe(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:4 (Size: 0x1, Type: BoolProperty)
    void SET_bWantsPlayerState(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:5 (Size: 0x1, Type: BoolProperty)
    void SET_bSetControlRotationFromPawnOrientation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x378); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x378, B); } // 0x378:6 (Size: 0x1, Type: BoolProperty)
    void SET_PathFollowingComponent(const UPathFollowingComponent*& Value) { Write<UPathFollowingComponent*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_BrainComponent(const UBrainComponent*& Value) { Write<UBrainComponent*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_PerceptionComponent(const UAIPerceptionComponent*& Value) { Write<UAIPerceptionComponent*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_Blackboard(const UBlackboardComponent*& Value) { Write<UBlackboardComponent*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedGameplayTasksComponent(const UGameplayTasksComponent*& Value) { Write<UGameplayTasksComponent*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultNavigationFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x38
class UAIResource_Movement : public UGameplayTaskResource
{
public:
};

// Size: 0x38
class UAIResource_Logic : public UGameplayTaskResource
{
public:
};

// Size: 0x38
class UAISubsystem : public UObject
{
public:
    UAISystem* AISystem() const { return Read<UAISystem*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_AISystem(const UAISystem*& Value) { Write<UAISystem*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x178
class UAISystem : public UAISystemBase
{
public:
    FSoftClassPath PerceptionSystemClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FSoftClassPath HotSpotManagerClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FSoftClassPath EnvQueryManagerClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    float AcceptanceRadius() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float PathfollowingRegularPathPointAcceptanceRadius() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    float PathfollowingNavLinkAcceptanceRadius() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    bool bFinishMoveOnGoalOverlap() const { return Read<bool>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x1, Type: BoolProperty)
    bool bAcceptPartialPaths() const { return Read<bool>(uintptr_t(this) + 0xad); } // 0xad (Size: 0x1, Type: BoolProperty)
    bool bAllowStrafing() const { return Read<bool>(uintptr_t(this) + 0xae); } // 0xae (Size: 0x1, Type: BoolProperty)
    bool bAllowControllersAsEQSQuerier() const { return Read<bool>(uintptr_t(this) + 0xaf); } // 0xaf (Size: 0x1, Type: BoolProperty)
    bool bEnableDebuggerPlugin() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    bool bForgetStaleActors() const { return Read<bool>(uintptr_t(this) + 0xb1); } // 0xb1 (Size: 0x1, Type: BoolProperty)
    bool bAddBlackboardSelfKey() const { return Read<bool>(uintptr_t(this) + 0xb2); } // 0xb2 (Size: 0x1, Type: BoolProperty)
    bool bClearBBEntryOnBTEQSFail() const { return Read<bool>(uintptr_t(this) + 0xb3); } // 0xb3 (Size: 0x1, Type: BoolProperty)
    bool bBlackboardKeyDecoratorAllowsNoneAsValue() const { return Read<bool>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UBlackboardData> DefaultBlackboard() const { return Read<TSoftObjectPtr<UBlackboardData>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x20, Type: SoftObjectProperty)
    TEnumAsByte<ECollisionChannel> DefaultSightCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: ByteProperty)
    UBehaviorTreeManager* BehaviorTreeManager() const { return Read<UBehaviorTreeManager*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UEnvQueryManager* EnvironmentQueryManager() const { return Read<UEnvQueryManager*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAIPerceptionSystem* PerceptionSystem() const { return Read<UAIPerceptionSystem*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    TArray<UAIAsyncTaskBlueprintProxy*> AllProxyObjects() const { return Read<TArray<UAIAsyncTaskBlueprintProxy*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    UAIHotSpotManager* HotSpotManager() const { return Read<UAIHotSpotManager*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    UNavLocalGridManager* NavLocalGrids() const { return Read<UNavLocalGridManager*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)

    void SET_PerceptionSystemClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_HotSpotManagerClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_EnvQueryManagerClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_AcceptanceRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_PathfollowingRegularPathPointAcceptanceRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_PathfollowingNavLinkAcceptanceRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_bFinishMoveOnGoalOverlap(const bool& Value) { Write<bool>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x1, Type: BoolProperty)
    void SET_bAcceptPartialPaths(const bool& Value) { Write<bool>(uintptr_t(this) + 0xad, Value); } // 0xad (Size: 0x1, Type: BoolProperty)
    void SET_bAllowStrafing(const bool& Value) { Write<bool>(uintptr_t(this) + 0xae, Value); } // 0xae (Size: 0x1, Type: BoolProperty)
    void SET_bAllowControllersAsEQSQuerier(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaf, Value); } // 0xaf (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDebuggerPlugin(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    void SET_bForgetStaleActors(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb1, Value); } // 0xb1 (Size: 0x1, Type: BoolProperty)
    void SET_bAddBlackboardSelfKey(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb2, Value); } // 0xb2 (Size: 0x1, Type: BoolProperty)
    void SET_bClearBBEntryOnBTEQSFail(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb3, Value); } // 0xb3 (Size: 0x1, Type: BoolProperty)
    void SET_bBlackboardKeyDecoratorAllowsNoneAsValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultBlackboard(const TSoftObjectPtr<UBlackboardData>& Value) { Write<TSoftObjectPtr<UBlackboardData>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DefaultSightCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: ByteProperty)
    void SET_BehaviorTreeManager(const UBehaviorTreeManager*& Value) { Write<UBehaviorTreeManager*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_EnvironmentQueryManager(const UEnvQueryManager*& Value) { Write<UEnvQueryManager*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_PerceptionSystem(const UAIPerceptionSystem*& Value) { Write<UAIPerceptionSystem*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_AllProxyObjects(const TArray<UAIAsyncTaskBlueprintProxy*>& Value) { Write<TArray<UAIAsyncTaskBlueprintProxy*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_HotSpotManager(const UAIHotSpotManager*& Value) { Write<UAIHotSpotManager*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_NavLocalGrids(const UNavLocalGridManager*& Value) { Write<UNavLocalGridManager*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x68
class UBehaviorTree : public UObject
{
public:
    UBTCompositeNode* RootNode() const { return Read<UBTCompositeNode*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UBlackboardData* BlackboardAsset() const { return Read<UBlackboardData*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    TArray<UBTDecorator*> RootDecorators() const { return Read<TArray<UBTDecorator*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FBTDecoratorLogic> RootDecoratorOps() const { return Read<TArray<FBTDecoratorLogic>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_RootNode(const UBTCompositeNode*& Value) { Write<UBTCompositeNode*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_BlackboardAsset(const UBlackboardData*& Value) { Write<UBlackboardData*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_RootDecorators(const TArray<UBTDecorator*>& Value) { Write<TArray<UBTDecorator*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_RootDecoratorOps(const TArray<FBTDecoratorLogic>& Value) { Write<TArray<FBTDecoratorLogic>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2b0
class UBehaviorTreeComponent : public UBrainComponent
{
public:
    TArray<UBTNode*> NodeInstances() const { return Read<TArray<UBTNode*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    UBehaviorTree* DefaultBehaviorTreeAsset() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)

    void SET_NodeInstances(const TArray<UBTNode*>& Value) { Write<TArray<UBTNode*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultBehaviorTreeAsset(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x110
class UBrainComponent : public UActorComponent
{
public:
    UBlackboardComponent* BlackboardComp() const { return Read<UBlackboardComponent*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    AAIController* AIOwner() const { return Read<AAIController*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_BlackboardComp(const UBlackboardComponent*& Value) { Write<UBlackboardComponent*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_AIOwner(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UBehaviorTreeManager : public UObject
{
public:
    int32_t MaxDebuggerSteps() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    TArray<FBehaviorTreeTemplateInfo> LoadedTemplates() const { return Read<TArray<FBehaviorTreeTemplateInfo>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<UBehaviorTreeComponent*> ActiveComponents() const { return Read<TArray<UBehaviorTreeComponent*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_MaxDebuggerSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_LoadedTemplates(const TArray<FBehaviorTreeTemplateInfo>& Value) { Write<TArray<FBehaviorTreeTemplateInfo>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveComponents(const TArray<UBehaviorTreeComponent*>& Value) { Write<TArray<UBehaviorTreeComponent*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UBehaviorTreeTypes : public UObject
{
public:
};

// Size: 0x28
class UBlackboardAssetProvider : public UInterface
{
public:
};

// Size: 0x1c0
class UBlackboardComponent : public UActorComponent
{
public:
    UBrainComponent* BrainComp() const { return Read<UBrainComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UBlackboardData* DefaultBlackboardAsset() const { return Read<UBlackboardData*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UBlackboardData* BlackboardAsset() const { return Read<UBlackboardData*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TArray<UBlackboardKeyType*> KeyInstances() const { return Read<TArray<UBlackboardKeyType*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)

    void SET_BrainComp(const UBrainComponent*& Value) { Write<UBrainComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultBlackboardAsset(const UBlackboardData*& Value) { Write<UBlackboardData*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_BlackboardAsset(const UBlackboardData*& Value) { Write<UBlackboardData*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_KeyInstances(const TArray<UBlackboardKeyType*>& Value) { Write<TArray<UBlackboardKeyType*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
class UBlackboardData : public UDataAsset
{
public:
    UBlackboardData* Parent() const { return Read<UBlackboardData*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    TArray<FBlackboardEntry> Keys() const { return Read<TArray<FBlackboardEntry>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    bool bHasSynchronizedKeys() const { return (Read<uint8_t>(uintptr_t(this) + 0x48) >> 0x0) & 1; } // 0x48:0 (Size: 0x1, Type: BoolProperty)

    void SET_Parent(const UBlackboardData*& Value) { Write<UBlackboardData*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_Keys(const TArray<FBlackboardEntry>& Value) { Write<TArray<FBlackboardEntry>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasSynchronizedKeys(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x48, B); } // 0x48:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UBlackboardKeyType_Bool : public UBlackboardKeyType
{
public:
    bool bDefaultValue() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_bDefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
class UBlackboardKeyType_Class : public UBlackboardKeyType
{
public:
    UClass* BaseClass() const { return Read<UClass*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ClassProperty)
    UClass* DefaultValue() const { return Read<UClass*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ClassProperty)

    void SET_BaseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultValue(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x50
class UBlackboardKeyType_Enum : public UBlackboardKeyType
{
public:
    UEnum* EnumType() const { return Read<UEnum*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FString EnumName() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    char DefaultValue() const { return Read<char>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    bool bIsEnumNameValid() const { return (Read<uint8_t>(uintptr_t(this) + 0x4c) >> 0x0) & 1; } // 0x4c:0 (Size: 0x1, Type: BoolProperty)

    void SET_EnumType(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_EnumName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_DefaultValue(const char& Value) { Write<char>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_bIsEnumNameValid(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x4c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x4c, B); } // 0x4c:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UBlackboardKeyType_Float : public UBlackboardKeyType
{
public:
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class UBlackboardKeyType_Int : public UBlackboardKeyType
{
public:
    int32_t DefaultValue() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_DefaultValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
class UBlackboardKeyType_Name : public UBlackboardKeyType
{
public:
    FName DefaultValue() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)

    void SET_DefaultValue(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
};

// Size: 0x48
class UBlackboardKeyType_NativeEnum : public UBlackboardKeyType
{
public:
    FString EnumName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    UEnum* EnumType() const { return Read<UEnum*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_EnumName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_EnumType(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UBlackboardKeyType_Object : public UBlackboardKeyType
{
public:
    UClass* BaseClass() const { return Read<UClass*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ClassProperty)
    UObject* DefaultValue() const { return Read<UObject*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_BaseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultValue(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UBlackboardKeyType_Rotator : public UBlackboardKeyType
{
public:
    FRotator DefaultValue() const { return Read<FRotator>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    bool bUseDefaultValue() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_DefaultValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_bUseDefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UBlackboardKeyType_String : public UBlackboardKeyType
{
public:
    FString StringValue() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString DefaultValue() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)

    void SET_StringValue(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_DefaultValue(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
};

// Size: 0x50
class UBlackboardKeyType_Vector : public UBlackboardKeyType
{
public:
    FVector DefaultValue() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    bool bUseDefaultValue() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_DefaultValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_bUseDefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
class UBTAuxiliaryNode : public UBTNode
{
public:
};

// Size: 0x80
class UBTCompositeNode : public UBTNode
{
public:
    TArray<FBTCompositeChild> Children() const { return Read<TArray<FBTCompositeChild>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<UBTService*> Services() const { return Read<TArray<UBTService*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    bool bApplyDecoratorScope() const { return (Read<uint8_t>(uintptr_t(this) + 0x78) >> 0x0) & 1; } // 0x78:0 (Size: 0x1, Type: BoolProperty)

    void SET_Children(const TArray<FBTCompositeChild>& Value) { Write<TArray<FBTCompositeChild>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_Services(const TArray<UBTService*>& Value) { Write<TArray<UBTService*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_bApplyDecoratorScope(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x78); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x78, B); } // 0x78:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
class UBTDecorator : public UBTAuxiliaryNode
{
public:
    bool bInverseCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x60) >> 0x7) & 1; } // 0x60:7 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EBTFlowAbortMode> FlowAbortMode() const { return Read<TEnumAsByte<EBTFlowAbortMode>>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x1, Type: ByteProperty)

    void SET_bInverseCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x60); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x60, B); } // 0x60:7 (Size: 0x1, Type: BoolProperty)
    void SET_FlowAbortMode(const TEnumAsByte<EBTFlowAbortMode>& Value) { Write<TEnumAsByte<EBTFlowAbortMode>>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x28
class UBTFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x70
class UBTService : public UBTAuxiliaryNode
{
public:
    float Interval() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float RandomDeviation() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    bool bCallTickOnSearchStart() const { return (Read<uint8_t>(uintptr_t(this) + 0x68) >> 0x0) & 1; } // 0x68:0 (Size: 0x1, Type: BoolProperty)
    bool bRestartTimerOnEachActivation() const { return (Read<uint8_t>(uintptr_t(this) + 0x68) >> 0x1) & 1; } // 0x68:1 (Size: 0x1, Type: BoolProperty)

    void SET_Interval(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_RandomDeviation(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_bCallTickOnSearchStart(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x68); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x68, B); } // 0x68:0 (Size: 0x1, Type: BoolProperty)
    void SET_bRestartTimerOnEachActivation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x68); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x68, B); } // 0x68:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UBTComposite_Selector : public UBTCompositeNode
{
public:
};

// Size: 0x80
class UBTComposite_Sequence : public UBTCompositeNode
{
public:
};

// Size: 0x88
class UBTComposite_SimpleParallel : public UBTCompositeNode
{
public:
    TEnumAsByte<EBTParallelMode> FinishMode() const { return Read<TEnumAsByte<EBTParallelMode>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: ByteProperty)

    void SET_FinishMode(const TEnumAsByte<EBTParallelMode>& Value) { Write<TEnumAsByte<EBTParallelMode>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xc0
class UBTDecorator_Blackboard : public UBTDecorator_BlackboardBase
{
public:
    int32_t IntValue() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    float FloatValue() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    FString StringValue() const { return Read<FString>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StrProperty)
    FString CachedDescription() const { return Read<FString>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StrProperty)
    char OperationType() const { return Read<char>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBTBlackboardRestart> NotifyObserver() const { return Read<TEnumAsByte<EBTBlackboardRestart>>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: ByteProperty)

    void SET_IntValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_FloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_StringValue(const FString& Value) { Write<FString>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StrProperty)
    void SET_CachedDescription(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StrProperty)
    void SET_OperationType(const char& Value) { Write<char>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: ByteProperty)
    void SET_NotifyObserver(const TEnumAsByte<EBTBlackboardRestart>& Value) { Write<TEnumAsByte<EBTBlackboardRestart>>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x90
class UBTDecorator_BlackboardBase : public UBTDecorator
{
public:
    FBlackboardKeySelector BlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)

    void SET_BlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa0
class UBTDecorator_BlueprintBase : public UBTDecorator
{
public:
    AAIController* AIOwner() const { return Read<AAIController*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorOwner() const { return Read<AActor*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> ObservedKeyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    bool bShowPropertyDetails() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x0) & 1; } // 0x98:0 (Size: 0x1, Type: BoolProperty)
    bool bCheckConditionOnlyBlackBoardChanges() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x1) & 1; } // 0x98:1 (Size: 0x1, Type: BoolProperty)

    void SET_AIOwner(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorOwner(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_ObservedKeyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_bShowPropertyDetails(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckConditionOnlyBlackBoardChanges(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc8
class UBTDecorator_CheckGameplayTagsOnActor : public UBTDecorator
{
public:
    FBlackboardKeySelector ActorToCheck() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)
    uint8_t TagsToMatch() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)
    FString CachedDescription() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)

    void SET_ActorToCheck(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
    void SET_TagsToMatch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
    void SET_CachedDescription(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
};

// Size: 0xc0
class UBTDecorator_CompareBBEntries : public UBTDecorator
{
public:
    TEnumAsByte<EBlackBoardEntryComparison> Operator() const { return Read<TEnumAsByte<EBlackBoardEntryComparison>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: ByteProperty)
    FBlackboardKeySelector BlackboardKeyA() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)

    void SET_Operator(const TEnumAsByte<EBlackBoardEntryComparison>& Value) { Write<TEnumAsByte<EBlackBoardEntryComparison>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: ByteProperty)
    void SET_BlackboardKeyA(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_BlackboardKeyB(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
};

// Size: 0xc0
class UBTDecorator_ConditionalLoop : public UBTDecorator_Blackboard
{
public:
};

// Size: 0xf0
class UBTDecorator_ConeCheck : public UBTDecorator
{
public:
    FValueOrBBKey_Float ConeHalfAngle() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0xc, Type: StructProperty)
    FBlackboardKeySelector ConeOrigin() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector ConeDirection() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector Observed() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)

    void SET_ConeHalfAngle(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0xc, Type: StructProperty)
    void SET_ConeOrigin(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_ConeDirection(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_Observed(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x78
class UBTDecorator_Cooldown : public UBTDecorator
{
public:
    FValueOrBBKey_Float CooldownTime() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0xc, Type: StructProperty)

    void SET_CooldownTime(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0xc, Type: StructProperty)
};

// Size: 0x100
class UBTDecorator_DoesPathExist : public UBTDecorator
{
public:
    FBlackboardKeySelector BlackboardKeyA() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x28, Type: StructProperty)
    bool bUseSelf() const { return (Read<uint8_t>(uintptr_t(this) + 0xb8) >> 0x0) & 1; } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Enum PathQueryType() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Class FilterClass() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)

    void SET_BlackboardKeyA(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
    void SET_BlackboardKeyB(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x28, Type: StructProperty)
    void SET_bUseSelf(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb8, B); } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    void SET_PathQueryType(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_FilterClass(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x68
class UBTDecorator_ForceSuccess : public UBTDecorator
{
public:
};

// Size: 0xf0
class UBTDecorator_IsAtLocation : public UBTDecorator_BlackboardBase
{
public:
    float AcceptableRadius() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    FAIDataProviderFloatValue ParametrizedAcceptableRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x38, Type: StructProperty)
    uint8_t GeometricDistanceType() const { return Read<uint8_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    bool bUseParametrizedRadius() const { return (Read<uint8_t>(uintptr_t(this) + 0xd4) >> 0x0) & 1; } // 0xd4:0 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Bool bUseNavAgentGoalLocation() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bPathFindingBasedTest() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0xc, Type: StructProperty)

    void SET_AcceptableRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_ParametrizedAcceptableRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x38, Type: StructProperty)
    void SET_GeometricDistanceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    void SET_bUseParametrizedRadius(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xd4, B); } // 0xd4:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseNavAgentGoalLocation(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0xc, Type: StructProperty)
    void SET_bPathFindingBasedTest(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0xc, Type: StructProperty)
};

// Size: 0xa8
class UBTDecorator_IsBBEntryOfClass : public UBTDecorator_BlackboardBase
{
public:
    FValueOrBBKey_Class TestClass() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)

    void SET_TestClass(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd0
class UBTDecorator_KeepInCone : public UBTDecorator
{
public:
    FValueOrBBKey_Float ConeHalfAngle() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0xc, Type: StructProperty)
    FBlackboardKeySelector ConeOrigin() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector Observed() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    bool bUseSelfAsOrigin() const { return (Read<uint8_t>(uintptr_t(this) + 0xc8) >> 0x0) & 1; } // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    bool bUseSelfAsObserved() const { return (Read<uint8_t>(uintptr_t(this) + 0xc8) >> 0x1) & 1; } // 0xc8:1 (Size: 0x1, Type: BoolProperty)

    void SET_ConeHalfAngle(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0xc, Type: StructProperty)
    void SET_ConeOrigin(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_Observed(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_bUseSelfAsOrigin(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc8, B); } // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSelfAsObserved(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xc8, B); } // 0xc8:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UBTDecorator_Loop : public UBTDecorator
{
public:
    FValueOrBBKey_Int32 NumLoops() const { return Read<FValueOrBBKey_Int32>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0xc, Type: StructProperty)
    bool bInfiniteLoop() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Float InfiniteLoopTimeoutTime() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0xc, Type: StructProperty)

    void SET_NumLoops(const FValueOrBBKey_Int32& Value) { Write<FValueOrBBKey_Int32>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0xc, Type: StructProperty)
    void SET_bInfiniteLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
    void SET_InfiniteLoopTimeoutTime(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0xc, Type: StructProperty)
};

// Size: 0x90
class UBTDecorator_LoopUntil : public UBTDecorator
{
public:
    FValueOrBBKey_Enum RequiredResult() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)

    void SET_RequiredResult(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
};

// Size: 0x68
class UBTDecorator_ReachedMoveGoal : public UBTDecorator
{
public:
};

// Size: 0x88
class UBTDecorator_SetTagCooldown : public UBTDecorator
{
public:
    FGameplayTag CooldownTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAddToExistingDuration() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0xc, Type: StructProperty)

    void SET_CooldownTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: StructProperty)
    void SET_CooldownDuration(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0xc, Type: StructProperty)
    void SET_bAddToExistingDuration(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0xc, Type: StructProperty)
};

// Size: 0x90
class UBTDecorator_TagCooldown : public UBTDecorator
{
public:
    FGameplayTag CooldownTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAddToExistingDuration() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bActivatesCooldown() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0xc, Type: StructProperty)

    void SET_CooldownTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: StructProperty)
    void SET_CooldownDuration(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0xc, Type: StructProperty)
    void SET_bAddToExistingDuration(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0xc, Type: StructProperty)
    void SET_bActivatesCooldown(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0xc, Type: StructProperty)
};

// Size: 0x78
class UBTDecorator_TimeLimit : public UBTDecorator
{
public:
    FValueOrBBKey_Float TimeLimit() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0xc, Type: StructProperty)

    void SET_TimeLimit(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0xc, Type: StructProperty)
};

// Size: 0x98
class UBTService_BlackboardBase : public UBTService
{
public:
    FBlackboardKeySelector BlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)

    void SET_BlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
};

// Size: 0x98
class UBTService_BlueprintBase : public UBTService
{
public:
    AAIController* AIOwner() const { return Read<AAIController*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorOwner() const { return Read<AActor*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    bool bShowPropertyDetails() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x0) & 1; } // 0x90:0 (Size: 0x1, Type: BoolProperty)
    bool bShowEventDetails() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x1) & 1; } // 0x90:1 (Size: 0x1, Type: BoolProperty)

    void SET_AIOwner(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorOwner(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_bShowPropertyDetails(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:0 (Size: 0x1, Type: BoolProperty)
    void SET_bShowEventDetails(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
class UBTService_DefaultFocus : public UBTService_BlackboardBase
{
public:
    char FocusPriority() const { return Read<char>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: ByteProperty)

    void SET_FocusPriority(const char& Value) { Write<char>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xf8
class UBTService_RunEQS : public UBTService_BlackboardBase
{
public:
    FEQSParametrizedQueryExecutionRequest EQSRequest() const { return Read<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x48, Type: StructProperty)
    bool bUpdateBBOnFail() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)

    void SET_EQSRequest(const FEQSParametrizedQueryExecutionRequest& Value) { Write<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x48, Type: StructProperty)
    void SET_bUpdateBBOnFail(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
class UBTTask_BlueprintBase : public UBTTaskNode
{
public:
    AAIController* AIOwner() const { return Read<AAIController*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorOwner() const { return Read<AActor*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    FIntervalCountdown TickInterval() const { return Read<FIntervalCountdown>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: StructProperty)
    bool bShowPropertyDetails() const { return (Read<uint8_t>(uintptr_t(this) + 0xa0) >> 0x0) & 1; } // 0xa0:0 (Size: 0x1, Type: BoolProperty)

    void SET_AIOwner(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorOwner(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_TickInterval(const FIntervalCountdown& Value) { Write<FIntervalCountdown>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: StructProperty)
    void SET_bShowPropertyDetails(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xa0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xa0, B); } // 0xa0:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UBTTask_FinishWithResult : public UBTTaskNode
{
public:
    FValueOrBBKey_Enum Result() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)

    void SET_Result(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
};

// Size: 0x80
class UBTTask_GameplayTaskBase : public UBTTaskNode
{
public:
    FValueOrBBKey_Bool bWaitForGameplayTask() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)

    void SET_bWaitForGameplayTask(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
};

// Size: 0x80
class UBTTask_MakeNoise : public UBTTaskNode
{
public:
    FValueOrBBKey_Float Loudnes() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)

    void SET_Loudnes(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
};

// Size: 0x130
class UBTTask_MoveDirectlyToward : public UBTTask_MoveTo
{
public:
};

// Size: 0x130
class UBTTask_MoveTo : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Float AcceptableRadius() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Class FilterClass() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Float ObservedBlackboardValueTolerance() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAllowStrafe() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAllowPartialPath() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bTrackMovingGoal() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bRequireNavigableEndLocation() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bProjectGoalLocation() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bReachTestIncludesAgentRadius() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bReachTestIncludesGoalRadius() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bStartFromPreviousPath() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0xc, Type: StructProperty)
    bool bObserveBlackboardValue() const { return (Read<uint8_t>(uintptr_t(this) + 0x12c) >> 0x1) & 1; } // 0x12c:1 (Size: 0x1, Type: BoolProperty)

    void SET_AcceptableRadius(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
    void SET_FilterClass(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_ObservedBlackboardValueTolerance(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xc, Type: StructProperty)
    void SET_bAllowStrafe(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0xc, Type: StructProperty)
    void SET_bAllowPartialPath(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0xc, Type: StructProperty)
    void SET_bTrackMovingGoal(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0xc, Type: StructProperty)
    void SET_bRequireNavigableEndLocation(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0xc, Type: StructProperty)
    void SET_bProjectGoalLocation(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0xc, Type: StructProperty)
    void SET_bReachTestIncludesAgentRadius(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0xc, Type: StructProperty)
    void SET_bReachTestIncludesGoalRadius(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0xc, Type: StructProperty)
    void SET_bStartFromPreviousPath(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0xc, Type: StructProperty)
    void SET_bObserveBlackboardValue(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x12c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x12c, B); } // 0x12c:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
class UBTTask_PlayAnimation : public UBTTaskNode
{
public:
    FValueOrBBKey_Object AnimationToPlay() const { return Read<FValueOrBBKey_Object>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Bool bLooping() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bNonBlocking() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0xc, Type: StructProperty)
    UBehaviorTreeComponent* MyOwnerComp() const { return Read<UBehaviorTreeComponent*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* CachedSkelMesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)

    void SET_AnimationToPlay(const FValueOrBBKey_Object& Value) { Write<FValueOrBBKey_Object>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_bLooping(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0xc, Type: StructProperty)
    void SET_bNonBlocking(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0xc, Type: StructProperty)
    void SET_MyOwnerComp(const UBehaviorTreeComponent*& Value) { Write<UBehaviorTreeComponent*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedSkelMesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UBTTask_PlaySound : public UBTTaskNode
{
public:
    FValueOrBBKey_Object SoundToPlay() const { return Read<FValueOrBBKey_Object>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_SoundToPlay(const FValueOrBBKey_Object& Value) { Write<FValueOrBBKey_Object>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa8
class UBTTask_RotateToFaceBBEntry : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Float Precision() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)

    void SET_Precision(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
};

// Size: 0x78
class UBTTask_RunBehavior : public UBTTaskNode
{
public:
    UBehaviorTree* BehaviorAsset() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)

    void SET_BehaviorAsset(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UBTTask_RunBehaviorDynamic : public UBTTaskNode
{
public:
    FGameplayTag InjectionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)
    UBehaviorTree* DefaultBehaviorAsset() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    UBehaviorTree* BehaviorAsset() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_InjectionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
    void SET_DefaultBehaviorAsset(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_BehaviorAsset(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x100
class UBTTask_RunEQSQuery : public UBTTask_BlackboardBase
{
public:
    bool bUseBBKey() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    FEQSParametrizedQueryExecutionRequest EQSRequest() const { return Read<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x48, Type: StructProperty)
    bool bUpdateBBOnFail() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)

    void SET_bUseBBKey(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_EQSRequest(const FEQSParametrizedQueryExecutionRequest& Value) { Write<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x48, Type: StructProperty)
    void SET_bUpdateBBOnFail(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
class UBTTask_SetTagCooldown : public UBTTaskNode
{
public:
    FGameplayTag CooldownTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Bool bAddToExistingDuration() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0xc, Type: StructProperty)

    void SET_CooldownTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
    void SET_bAddToExistingDuration(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0xc, Type: StructProperty)
    void SET_CooldownDuration(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0xc, Type: StructProperty)
};

// Size: 0x88
class UBTTask_Wait : public UBTTaskNode
{
public:
    FValueOrBBKey_Float WaitTime() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float RandomDeviation() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0xc, Type: StructProperty)

    void SET_WaitTime(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
    void SET_RandomDeviation(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0xc, Type: StructProperty)
};

// Size: 0xb0
class UBTTask_WaitBlackboardTime : public UBTTask_Wait
{
public:
    FBlackboardKeySelector BlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)

    void SET_BlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UAIBlueprintHelperLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UAIDataProvider : public UObject
{
public:
};

// Size: 0x38
class UAIDataProvider_QueryParams : public UAIDataProvider
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    float FloatValue() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    int32_t IntValue() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    bool BoolValue() const { return Read<bool>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: BoolProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_FloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_IntValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_BoolValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
class UAIDataProvider_Random : public UAIDataProvider_QueryParams
{
public:
    float Min() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float Max() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bInteger() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x0) & 1; } // 0x40:0 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Max(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_bInteger(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3c8
class ADetourCrowdAIController : public AAIController
{
public:
};

// Size: 0x30
class UEnvQueryContext_BlueprintBase : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UEnvQueryContext : public UObject
{
public:
};

// Size: 0x28
class UEnvQueryContext_Item : public UEnvQueryContext
{
public:
};

// Size: 0x58
class UEnvQueryContext_NavigationData : public UEnvQueryContext
{
public:
    FNavAgentProperties NavAgentProperties() const { return Read<FNavAgentProperties>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x30, Type: StructProperty)

    void SET_NavAgentProperties(const FNavAgentProperties& Value) { Write<FNavAgentProperties>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x30, Type: StructProperty)
};

// Size: 0x28
class UEnvQueryContext_Querier : public UEnvQueryContext
{
public:
};

// Size: 0x48
class UEnvQuery : public UDataAsset
{
public:
    FName QueryName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    TArray<UEnvQueryOption*> Options() const { return Read<TArray<UEnvQueryOption*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_QueryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_Options(const TArray<UEnvQueryOption*>& Value) { Write<TArray<UEnvQueryOption*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UEnvQueryDebugHelpers : public UObject
{
public:
};

// Size: 0x50
class UEnvQueryGenerator : public UEnvQueryNode
{
public:
    FString OptionName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    UClass* ItemType() const { return Read<UClass*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ClassProperty)
    bool bAutoSortTests() const { return (Read<uint8_t>(uintptr_t(this) + 0x48) >> 0x0) & 1; } // 0x48:0 (Size: 0x1, Type: BoolProperty)
    bool bCanRunAsync() const { return (Read<uint8_t>(uintptr_t(this) + 0x48) >> 0x1) & 1; } // 0x48:1 (Size: 0x1, Type: BoolProperty)

    void SET_OptionName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_ItemType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ClassProperty)
    void SET_bAutoSortTests(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x48, B); } // 0x48:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCanRunAsync(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x48, B); } // 0x48:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UEnvQueryNode : public UObject
{
public:
    int32_t VerNum() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_VerNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

// Size: 0x78
class UEnvQueryInstanceBlueprintWrapper : public UObject
{
public:
    int32_t QueryID() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    UClass* ItemType() const { return Read<UClass*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ClassProperty)
    int32_t OptionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: IntProperty)

    void SET_QueryID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_ItemType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ClassProperty)
    void SET_OptionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: IntProperty)
};

// Size: 0x158
class UEnvQueryManager : public UAISubsystem
{
public:
    TArray<FEnvQueryInstanceCache> InstanceCache() const { return Read<TArray<FEnvQueryInstanceCache>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    TArray<UEnvQueryContext*> LocalContexts() const { return Read<TArray<UEnvQueryContext*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers() const { return Read<TArray<UEnvQueryInstanceBlueprintWrapper*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    float MaxAllowedTestingTime() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bTestQueriesUsingBreadth() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)
    int32_t QueryCountWarningThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: IntProperty)
    double QueryCountWarningInterval() const { return Read<double>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    double ExecutionTimeWarningSeconds() const { return Read<double>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: DoubleProperty)
    double HandlingResultTimeWarningSeconds() const { return Read<double>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: DoubleProperty)
    double GenerationTimeWarningSeconds() const { return Read<double>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: DoubleProperty)

    void SET_InstanceCache(const TArray<FEnvQueryInstanceCache>& Value) { Write<TArray<FEnvQueryInstanceCache>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_LocalContexts(const TArray<UEnvQueryContext*>& Value) { Write<TArray<UEnvQueryContext*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_GCShieldedWrappers(const TArray<UEnvQueryInstanceBlueprintWrapper*>& Value) { Write<TArray<UEnvQueryInstanceBlueprintWrapper*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxAllowedTestingTime(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_bTestQueriesUsingBreadth(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
    void SET_QueryCountWarningThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: IntProperty)
    void SET_QueryCountWarningInterval(const double& Value) { Write<double>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    void SET_ExecutionTimeWarningSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: DoubleProperty)
    void SET_HandlingResultTimeWarningSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: DoubleProperty)
    void SET_GenerationTimeWarningSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x40
class UEnvQueryOption : public UObject
{
public:
    UEnvQueryGenerator* Generator() const { return Read<UEnvQueryGenerator*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<UEnvQueryTest*> Tests() const { return Read<TArray<UEnvQueryTest*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Generator(const UEnvQueryGenerator*& Value) { Write<UEnvQueryGenerator*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_Tests(const TArray<UEnvQueryTest*>& Value) { Write<TArray<UEnvQueryTest*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1f8
class UEnvQueryTest : public UEnvQueryNode
{
public:
    int32_t TestOrder() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EEnvTestPurpose> TestPurpose() const { return Read<TEnumAsByte<EEnvTestPurpose>>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: ByteProperty)
    FString TestComment() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<EEnvTestFilterOperator> MultipleContextFilterOp() const { return Read<TEnumAsByte<EEnvTestFilterOperator>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvTestScoreOperator> MultipleContextScoreOp() const { return Read<TEnumAsByte<EEnvTestScoreOperator>>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvTestFilterType> FilterType() const { return Read<TEnumAsByte<EEnvTestFilterType>>(uintptr_t(this) + 0x4a); } // 0x4a (Size: 0x1, Type: ByteProperty)
    FAIDataProviderBoolValue BoolValue() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue FloatValueMin() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue FloatValueMax() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EEnvTestScoreEquation> ScoringEquation() const { return Read<TEnumAsByte<EEnvTestScoreEquation>>(uintptr_t(this) + 0xf9); } // 0xf9 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvQueryTestClamping> ClampMinType() const { return Read<TEnumAsByte<EEnvQueryTestClamping>>(uintptr_t(this) + 0xfa); } // 0xfa (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvQueryTestClamping> ClampMaxType() const { return Read<TEnumAsByte<EEnvQueryTestClamping>>(uintptr_t(this) + 0xfb); } // 0xfb (Size: 0x1, Type: ByteProperty)
    uint8_t NormalizationType() const { return Read<uint8_t>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x1, Type: EnumProperty)
    FAIDataProviderFloatValue ScoreClampMin() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreClampMax() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoringFactor() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ReferenceValue() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x38, Type: StructProperty)
    bool bDefineReferenceValue() const { return Read<bool>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    bool bWorkOnFloatValues() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f0) >> 0x0) & 1; } // 0x1f0:0 (Size: 0x1, Type: BoolProperty)

    void SET_TestOrder(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_TestPurpose(const TEnumAsByte<EEnvTestPurpose>& Value) { Write<TEnumAsByte<EEnvTestPurpose>>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: ByteProperty)
    void SET_TestComment(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_MultipleContextFilterOp(const TEnumAsByte<EEnvTestFilterOperator>& Value) { Write<TEnumAsByte<EEnvTestFilterOperator>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_MultipleContextScoreOp(const TEnumAsByte<EEnvTestScoreOperator>& Value) { Write<TEnumAsByte<EEnvTestScoreOperator>>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: ByteProperty)
    void SET_FilterType(const TEnumAsByte<EEnvTestFilterType>& Value) { Write<TEnumAsByte<EEnvTestFilterType>>(uintptr_t(this) + 0x4a, Value); } // 0x4a (Size: 0x1, Type: ByteProperty)
    void SET_BoolValue(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
    void SET_FloatValueMin(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x38, Type: StructProperty)
    void SET_FloatValueMax(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x38, Type: StructProperty)
    void SET_ScoringEquation(const TEnumAsByte<EEnvTestScoreEquation>& Value) { Write<TEnumAsByte<EEnvTestScoreEquation>>(uintptr_t(this) + 0xf9, Value); } // 0xf9 (Size: 0x1, Type: ByteProperty)
    void SET_ClampMinType(const TEnumAsByte<EEnvQueryTestClamping>& Value) { Write<TEnumAsByte<EEnvQueryTestClamping>>(uintptr_t(this) + 0xfa, Value); } // 0xfa (Size: 0x1, Type: ByteProperty)
    void SET_ClampMaxType(const TEnumAsByte<EEnvQueryTestClamping>& Value) { Write<TEnumAsByte<EEnvQueryTestClamping>>(uintptr_t(this) + 0xfb, Value); } // 0xfb (Size: 0x1, Type: ByteProperty)
    void SET_NormalizationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x1, Type: EnumProperty)
    void SET_ScoreClampMin(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_ScoreClampMax(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_ScoringFactor(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x38, Type: StructProperty)
    void SET_ReferenceValue(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x38, Type: StructProperty)
    void SET_bDefineReferenceValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    void SET_bWorkOnFloatValues(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1f0, B); } // 0x1f0:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x5b0
class UEQSRenderingComponent : public UDebugDrawComponent
{
public:
};

// Size: 0x6d0
class AEQSTestingPawn : public ACharacter
{
public:
    UEnvQuery* QueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    TArray<FEnvNamedValue> QueryParams() const { return Read<TArray<FEnvNamedValue>>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x10, Type: ArrayProperty)
    TArray<FAIDynamicParam> QueryConfig() const { return Read<TArray<FAIDynamicParam>>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x10, Type: ArrayProperty)
    float TimeLimitPerStep() const { return Read<float>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x4, Type: FloatProperty)
    int32_t StepToDebugDraw() const { return Read<int32_t>(uintptr_t(this) + 0x66c); } // 0x66c (Size: 0x4, Type: IntProperty)
    uint8_t HighlightMode() const { return Read<uint8_t>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x1, Type: EnumProperty)
    bool bDrawLabels() const { return (Read<uint8_t>(uintptr_t(this) + 0x674) >> 0x0) & 1; } // 0x674:0 (Size: 0x1, Type: BoolProperty)
    bool bDrawFailedItems() const { return (Read<uint8_t>(uintptr_t(this) + 0x674) >> 0x1) & 1; } // 0x674:1 (Size: 0x1, Type: BoolProperty)
    bool bReRunQueryOnlyOnFinishedMove() const { return (Read<uint8_t>(uintptr_t(this) + 0x674) >> 0x2) & 1; } // 0x674:2 (Size: 0x1, Type: BoolProperty)
    bool bShouldBeVisibleInGame() const { return (Read<uint8_t>(uintptr_t(this) + 0x674) >> 0x3) & 1; } // 0x674:3 (Size: 0x1, Type: BoolProperty)
    bool bTickDuringGame() const { return (Read<uint8_t>(uintptr_t(this) + 0x674) >> 0x4) & 1; } // 0x674:4 (Size: 0x1, Type: BoolProperty)
    bool bRunQueryOnSelectionChanged() const { return (Read<uint8_t>(uintptr_t(this) + 0x674) >> 0x5) & 1; } // 0x674:5 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EEnvQueryRunMode> QueryingMode() const { return Read<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x1, Type: ByteProperty)
    FNavAgentProperties NavAgentProperties() const { return Read<FNavAgentProperties>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x30, Type: StructProperty)

    void SET_QueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_QueryParams(const TArray<FEnvNamedValue>& Value) { Write<TArray<FEnvNamedValue>>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x10, Type: ArrayProperty)
    void SET_QueryConfig(const TArray<FAIDynamicParam>& Value) { Write<TArray<FAIDynamicParam>>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x10, Type: ArrayProperty)
    void SET_TimeLimitPerStep(const float& Value) { Write<float>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x4, Type: FloatProperty)
    void SET_StepToDebugDraw(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x66c, Value); } // 0x66c (Size: 0x4, Type: IntProperty)
    void SET_HighlightMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x1, Type: EnumProperty)
    void SET_bDrawLabels(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x674); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x674, B); } // 0x674:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawFailedItems(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x674); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x674, B); } // 0x674:1 (Size: 0x1, Type: BoolProperty)
    void SET_bReRunQueryOnlyOnFinishedMove(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x674); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x674, B); } // 0x674:2 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldBeVisibleInGame(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x674); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x674, B); } // 0x674:3 (Size: 0x1, Type: BoolProperty)
    void SET_bTickDuringGame(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x674); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x674, B); } // 0x674:4 (Size: 0x1, Type: BoolProperty)
    void SET_bRunQueryOnSelectionChanged(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x674); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x674, B); } // 0x674:5 (Size: 0x1, Type: BoolProperty)
    void SET_QueryingMode(const TEnumAsByte<EEnvQueryRunMode>& Value) { Write<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x1, Type: ByteProperty)
    void SET_NavAgentProperties(const FNavAgentProperties& Value) { Write<FNavAgentProperties>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x30, Type: StructProperty)
};

// Size: 0xd0
class UEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator
{
public:
    UClass* SearchedActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue GenerateOnlyActorsInRadius() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SearchRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)

    void SET_SearchedActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_GenerateOnlyActorsInRadius(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_SearchRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_SearchCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x80
class UEnvQueryGenerator_BlueprintBase : public UEnvQueryGenerator
{
public:
    FText GeneratorsActionDescription() const { return Read<FText>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: TextProperty)
    UClass* Context() const { return Read<UClass*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ClassProperty)
    UClass* GeneratedItemType() const { return Read<UClass*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ClassProperty)

    void SET_GeneratorsActionDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: TextProperty)
    void SET_Context(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ClassProperty)
    void SET_GeneratedItemType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x70
class UEnvQueryGenerator_Composite : public UEnvQueryGenerator
{
public:
    TArray<UEnvQueryGenerator*> Generators() const { return Read<TArray<UEnvQueryGenerator*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    bool bAllowDifferentItemTypes() const { return (Read<uint8_t>(uintptr_t(this) + 0x60) >> 0x0) & 1; } // 0x60:0 (Size: 0x1, Type: BoolProperty)
    bool bHasMatchingItemType() const { return (Read<uint8_t>(uintptr_t(this) + 0x60) >> 0x1) & 1; } // 0x60:1 (Size: 0x1, Type: BoolProperty)
    UClass* ForcedItemType() const { return Read<UClass*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ClassProperty)

    void SET_Generators(const TArray<UEnvQueryGenerator*>& Value) { Write<TArray<UEnvQueryGenerator*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllowDifferentItemTypes(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x60); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x60, B); } // 0x60:0 (Size: 0x1, Type: BoolProperty)
    void SET_bHasMatchingItemType(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x60); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x60, B); } // 0x60:1 (Size: 0x1, Type: BoolProperty)
    void SET_ForcedItemType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x180
class UEnvQueryGenerator_Cone : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue AlignedPointsDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ConeDegrees() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue AngleStep() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue Range() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    UClass* CenterActor() const { return Read<UClass*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ClassProperty)
    bool bIncludeContextLocation() const { return (Read<uint8_t>(uintptr_t(this) + 0x178) >> 0x0) & 1; } // 0x178:0 (Size: 0x1, Type: BoolProperty)

    void SET_AlignedPointsDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_ConeDegrees(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_AngleStep(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_Range(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_CenterActor(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ClassProperty)
    void SET_bIncludeContextLocation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x178); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x178, B); } // 0x178:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
class UEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator
{
public:
    FEnvTraceData ProjectionData() const { return Read<FEnvTraceData>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)
    UClass* NavDataOverrideContext() const { return Read<UClass*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ClassProperty)

    void SET_ProjectionData(const FEnvTraceData& Value) { Write<FEnvTraceData>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
    void SET_NavDataOverrideContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x98
class UEnvQueryGenerator_CurrentLocation : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* QueryContext() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)

    void SET_QueryContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x1e0
class UEnvQueryGenerator_Donut : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue InnerRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue OuterRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumberOfRings() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue PointsPerRing() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FEnvDirection ArcDirection() const { return Read<FEnvDirection>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x20, Type: StructProperty)
    FAIDataProviderFloatValue ArcAngle() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x38, Type: StructProperty)
    bool bUseSpiralPattern() const { return Read<bool>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x1, Type: BoolProperty)
    UClass* Center() const { return Read<UClass*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ClassProperty)
    bool bDefineArc() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d8) >> 0x0) & 1; } // 0x1d8:0 (Size: 0x1, Type: BoolProperty)

    void SET_InnerRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_OuterRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_NumberOfRings(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_PointsPerRing(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_ArcDirection(const FEnvDirection& Value) { Write<FEnvDirection>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x20, Type: StructProperty)
    void SET_ArcAngle(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x38, Type: StructProperty)
    void SET_bUseSpiralPattern(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x1, Type: BoolProperty)
    void SET_Center(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ClassProperty)
    void SET_bDefineArc(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1d8, B); } // 0x1d8:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x258
class UEnvQueryGenerator_OnCircle : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue CircleRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    uint8_t PointOnCircleSpacingMethod() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumberOfPoints() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x38, Type: StructProperty)
    FEnvDirection ArcDirection() const { return Read<FEnvDirection>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x20, Type: StructProperty)
    FAIDataProviderFloatValue ArcDirectionOffsetDegrees() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ArcAngle() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x38, Type: StructProperty)
    UClass* CircleCenter() const { return Read<UClass*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ClassProperty)
    bool bIgnoreAnyContextActorsWhenGeneratingCircle() const { return Read<bool>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue CircleCenterZOffset() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x38, Type: StructProperty)
    FEnvTraceData TraceData() const { return Read<FEnvTraceData>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x38, Type: StructProperty)
    bool bDefineArc() const { return (Read<uint8_t>(uintptr_t(this) + 0x250) >> 0x0) & 1; } // 0x250:0 (Size: 0x1, Type: BoolProperty)

    void SET_CircleRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_PointOnCircleSpacingMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x38, Type: StructProperty)
    void SET_NumberOfPoints(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x38, Type: StructProperty)
    void SET_ArcDirection(const FEnvDirection& Value) { Write<FEnvDirection>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x20, Type: StructProperty)
    void SET_ArcDirectionOffsetDegrees(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x38, Type: StructProperty)
    void SET_ArcAngle(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x38, Type: StructProperty)
    void SET_CircleCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ClassProperty)
    void SET_bIgnoreAnyContextActorsWhenGeneratingCircle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x1, Type: BoolProperty)
    void SET_CircleCenterZOffset(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x38, Type: StructProperty)
    void SET_TraceData(const FEnvTraceData& Value) { Write<FEnvTraceData>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x38, Type: StructProperty)
    void SET_bDefineArc(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x250); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x250, B); } // 0x250:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x180
class UEnvQueryGenerator_PathingGrid : public UEnvQueryGenerator_SimpleGrid
{
public:
    FAIDataProviderBoolValue PathToItem() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x38, Type: StructProperty)
    UClass* NavigationFilter() const { return Read<UClass*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue ScanRangeMultiplier() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x38, Type: StructProperty)

    void SET_PathToItem(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x38, Type: StructProperty)
    void SET_NavigationFilter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ClassProperty)
    void SET_ScanRangeMultiplier(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x38, Type: StructProperty)
};

// Size: 0x108
class UEnvQueryGenerator_SimpleGrid : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue GridSize() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ClassProperty)

    void SET_GridSize(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa8
class UEnvQueryGenerator_PerceivedActors : public UEnvQueryGenerator
{
public:
    UClass* AllowedActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue SearchRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    UClass* ListenerContext() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)
    UClass* SenseToUse() const { return Read<UClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ClassProperty)
    bool bIncludeKnownActors() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_AllowedActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_SearchRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_ListenerContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
    void SET_SenseToUse(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ClassProperty)
    void SET_bIncludeKnownActors(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UEnvQueryItemType : public UObject
{
public:
};

// Size: 0x30
class UEnvQueryItemType_Actor : public UEnvQueryItemType_ActorBase
{
public:
};

// Size: 0x30
class UEnvQueryItemType_ActorBase : public UEnvQueryItemType_VectorBase
{
public:
};

// Size: 0x30
class UEnvQueryItemType_VectorBase : public UEnvQueryItemType
{
public:
};

// Size: 0x30
class UEnvQueryItemType_Direction : public UEnvQueryItemType_VectorBase
{
public:
};

// Size: 0x30
class UEnvQueryItemType_Point : public UEnvQueryItemType_VectorBase
{
public:
};

// Size: 0x208
class UEnvQueryTest_Distance : public UEnvQueryTest
{
public:
    TEnumAsByte<EEnvTestDistance> TestMode() const { return Read<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    UClass* DistanceTo() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)

    void SET_TestMode(const TEnumAsByte<EEnvTestDistance>& Value) { Write<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    void SET_DistanceTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x240
class UEnvQueryTest_Dot : public UEnvQueryTest
{
public:
    FEnvDirection LineA() const { return Read<FEnvDirection>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x20, Type: StructProperty)
    FEnvDirection LineB() const { return Read<FEnvDirection>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x20, Type: StructProperty)
    uint8_t TestMode() const { return Read<uint8_t>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: EnumProperty)
    bool bAbsoluteValue() const { return Read<bool>(uintptr_t(this) + 0x239); } // 0x239 (Size: 0x1, Type: BoolProperty)

    void SET_LineA(const FEnvDirection& Value) { Write<FEnvDirection>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x20, Type: StructProperty)
    void SET_LineB(const FEnvDirection& Value) { Write<FEnvDirection>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x20, Type: StructProperty)
    void SET_TestMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: EnumProperty)
    void SET_bAbsoluteValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x239, Value); } // 0x239 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x268
class UEnvQueryTest_GameplayTags : public UEnvQueryTest
{
public:
    FGameplayTagQuery TagQueryToMatch() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    bool bRejectIncompatibleItems() const { return Read<bool>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x1, Type: BoolProperty)
    bool bUpdatedToUseQuery() const { return Read<bool>(uintptr_t(this) + 0x241); } // 0x241 (Size: 0x1, Type: BoolProperty)
    uint8_t TagsToMatch() const { return Read<uint8_t>(uintptr_t(this) + 0x242); } // 0x242 (Size: 0x1, Type: EnumProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x20, Type: StructProperty)

    void SET_TagQueryToMatch(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    void SET_bRejectIncompatibleItems(const bool& Value) { Write<bool>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x1, Type: BoolProperty)
    void SET_bUpdatedToUseQuery(const bool& Value) { Write<bool>(uintptr_t(this) + 0x241, Value); } // 0x241 (Size: 0x1, Type: BoolProperty)
    void SET_TagsToMatch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x242, Value); } // 0x242 (Size: 0x1, Type: EnumProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x20, Type: StructProperty)
};

// Size: 0x228
class UEnvQueryTest_Overlap : public UEnvQueryTest
{
public:
    FEnvOverlapData OverlapData() const { return Read<FEnvOverlapData>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x30, Type: StructProperty)

    void SET_OverlapData(const FEnvOverlapData& Value) { Write<FEnvOverlapData>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x30, Type: StructProperty)
};

// Size: 0x280
class UEnvQueryTest_Pathfinding : public UEnvQueryTest
{
public:
    TEnumAsByte<EEnvTestPathfinding> TestMode() const { return Read<TEnumAsByte<EEnvTestPathfinding>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    UClass* Context() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue PathFromContext() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue SkipUnreachable() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x38, Type: StructProperty)
    UClass* FilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x8, Type: ClassProperty)

    void SET_TestMode(const TEnumAsByte<EEnvTestPathfinding>& Value) { Write<TEnumAsByte<EEnvTestPathfinding>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    void SET_Context(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
    void SET_PathFromContext(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x38, Type: StructProperty)
    void SET_SkipUnreachable(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x38, Type: StructProperty)
    void SET_FilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x2b8
class UEnvQueryTest_PathfindingBatch : public UEnvQueryTest_Pathfinding
{
public:
    FAIDataProviderFloatValue ScanRangeMultiplier() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x38, Type: StructProperty)

    void SET_ScanRangeMultiplier(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x38, Type: StructProperty)
};

// Size: 0x230
class UEnvQueryTest_Project : public UEnvQueryTest
{
public:
    FEnvTraceData ProjectionData() const { return Read<FEnvTraceData>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)

    void SET_ProjectionData(const FEnvTraceData& Value) { Write<FEnvTraceData>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
};

// Size: 0x1f8
class UEnvQueryTest_Random : public UEnvQueryTest
{
public:
};

// Size: 0x2e0
class UEnvQueryTest_Trace : public UEnvQueryTest
{
public:
    FEnvTraceData TraceData() const { return Read<FEnvTraceData>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue TraceFromContext() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ItemHeightOffset() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ContextHeightOffset() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    UClass* Context() const { return Read<UClass*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ClassProperty)

    void SET_TraceData(const FEnvTraceData& Value) { Write<FEnvTraceData>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    void SET_TraceFromContext(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x38, Type: StructProperty)
    void SET_ItemHeightOffset(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
    void SET_ContextHeightOffset(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    void SET_Context(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x210
class UEnvQueryTest_Volume : public UEnvQueryTest
{
public:
    UClass* VolumeContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* VolumeClass() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)
    bool bDoComplexVolumeTest() const { return (Read<uint8_t>(uintptr_t(this) + 0x208) >> 0x0) & 1; } // 0x208:0 (Size: 0x1, Type: BoolProperty)
    bool bSkipTestIfNoVolumes() const { return (Read<uint8_t>(uintptr_t(this) + 0x208) >> 0x1) & 1; } // 0x208:1 (Size: 0x1, Type: BoolProperty)

    void SET_VolumeContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_VolumeClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
    void SET_bDoComplexVolumeTest(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x208); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x208, B); } // 0x208:0 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipTestIfNoVolumes(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x208); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x208, B); } // 0x208:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3c8
class AGridPathAIController : public AAIController
{
public:
};

// Size: 0x28
class UAIHotSpotManager : public UObject
{
public:
};

// Size: 0x358
class UCrowdFollowingComponent : public UPathFollowingComponent
{
public:
    FVector CrowdAgentMoveDirection() const { return Read<FVector>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x18, Type: StructProperty)

    void SET_CrowdAgentMoveDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x18, Type: StructProperty)
};

// Size: 0x308
class UPathFollowingComponent : public UActorComponent
{
public:
    UNavMovementComponent* MovementComp() const { return Read<UNavMovementComponent*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    ANavigationData* MyNavData() const { return Read<ANavigationData*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)

    void SET_MovementComp(const UNavMovementComponent*& Value) { Write<UNavMovementComponent*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_MyNavData(const ANavigationData*& Value) { Write<ANavigationData*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf0
class UCrowdManager : public UCrowdManagerBase
{
public:
    ANavigationData* MyNavData() const { return Read<ANavigationData*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FCrowdAvoidanceConfig> AvoidanceConfig() const { return Read<TArray<FCrowdAvoidanceConfig>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCrowdAvoidanceSamplingPattern> SamplingPatterns() const { return Read<TArray<FCrowdAvoidanceSamplingPattern>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxAgents() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)
    float MaxAgentRadius() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    int32_t MaxAvoidedAgents() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)
    int32_t MaxAvoidedWalls() const { return Read<int32_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: IntProperty)
    float NavmeshCheckInterval() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float PathOptimizationInterval() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float SeparationDirClamp() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float PathOffsetRadiusMultiplier() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    bool bResolveCollisions() const { return (Read<uint8_t>(uintptr_t(this) + 0x70) >> 0x4) & 1; } // 0x70:4 (Size: 0x1, Type: BoolProperty)

    void SET_MyNavData(const ANavigationData*& Value) { Write<ANavigationData*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_AvoidanceConfig(const TArray<FCrowdAvoidanceConfig>& Value) { Write<TArray<FCrowdAvoidanceConfig>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_SamplingPatterns(const TArray<FCrowdAvoidanceSamplingPattern>& Value) { Write<TArray<FCrowdAvoidanceSamplingPattern>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxAgents(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
    void SET_MaxAgentRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAvoidedAgents(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
    void SET_MaxAvoidedWalls(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: IntProperty)
    void SET_NavmeshCheckInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_PathOptimizationInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_SeparationDirClamp(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_PathOffsetRadiusMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_bResolveCollisions(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x70); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x70, B); } // 0x70:4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x338
class UGridPathFollowingComponent : public UPathFollowingComponent
{
public:
    UNavLocalGridManager* GridManager() const { return Read<UNavLocalGridManager*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)

    void SET_GridManager(const UNavLocalGridManager*& Value) { Write<UNavLocalGridManager*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UNavFilter_AIControllerDefault : public UNavigationQueryFilter
{
public:
};

// Size: 0x2f8
class ANavLinkProxy : public AActor
{
public:
    TArray<FNavigationLink> PointLinks() const { return Read<TArray<FNavigationLink>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    TArray<FNavigationSegmentLink> SegmentLinks() const { return Read<TArray<FNavigationSegmentLink>>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    UNavLinkCustomComponent* SmartLinkComp() const { return Read<UNavLinkCustomComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    bool bSmartLinkIsRelevant() const { return Read<bool>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x1, Type: BoolProperty)

    void SET_PointLinks(const TArray<FNavigationLink>& Value) { Write<TArray<FNavigationLink>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    void SET_SegmentLinks(const TArray<FNavigationSegmentLink>& Value) { Write<TArray<FNavigationSegmentLink>>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    void SET_SmartLinkComp(const UNavLinkCustomComponent*& Value) { Write<UNavLinkCustomComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_bSmartLinkIsRelevant(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
class UNavLocalGridManager : public UObject
{
public:
};

// Size: 0x28
class UPathFollowingManager : public UObject
{
public:
};

// Size: 0x1a0
class UAIPerceptionComponent : public UActorComponent
{
public:
    TArray<UAISenseConfig*> SensesConfig() const { return Read<TArray<UAISenseConfig*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    UClass* DominantSense() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    AAIController* AIOwner() const { return Read<AAIController*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)

    void SET_SensesConfig(const TArray<UAISenseConfig*>& Value) { Write<TArray<UAISenseConfig*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_DominantSense(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    void SET_AIOwner(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UAIPerceptionListenerInterface : public UInterface
{
public:
};

// Size: 0xd0
class UAIPerceptionStimuliSourceComponent : public UActorComponent
{
public:
    bool bAutoRegisterAsSource() const { return (Read<uint8_t>(uintptr_t(this) + 0xb8) >> 0x0) & 1; } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    TArray<UClass*> RegisterAsSourceForSenses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)

    void SET_bAutoRegisterAsSource(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb8, B); } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    void SET_RegisterAsSourceForSenses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x130
class UAIPerceptionSystem : public UAISubsystem
{
public:
    TArray<UAISense*> Senses() const { return Read<TArray<UAISense*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    float PerceptionAgingRate() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)

    void SET_Senses(const TArray<UAISense*>& Value) { Write<TArray<UAISense*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_PerceptionAgingRate(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UAISense : public UObject
{
public:
    uint8_t NotifyType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    bool bWantsNewPawnNotification() const { return (Read<uint8_t>(uintptr_t(this) + 0x2c) >> 0x0) & 1; } // 0x2c:0 (Size: 0x1, Type: BoolProperty)
    bool bAutoRegisterAllPawnsAsSources() const { return (Read<uint8_t>(uintptr_t(this) + 0x2c) >> 0x1) & 1; } // 0x2c:1 (Size: 0x1, Type: BoolProperty)
    UAIPerceptionSystem* PerceptionSystemInstance() const { return Read<UAIPerceptionSystem*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_NotifyType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_bWantsNewPawnNotification(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2c, B); } // 0x2c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoRegisterAllPawnsAsSources(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x2c, B); } // 0x2c:1 (Size: 0x1, Type: BoolProperty)
    void SET_PerceptionSystemInstance(const UAIPerceptionSystem*& Value) { Write<UAIPerceptionSystem*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UAISenseConfig_Damage : public UAISenseConfig
{
public:
    UClass* Implementation() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)

    void SET_Implementation(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa0
class UAISense_Blueprint : public UAISense
{
public:
    UClass* ListenerDataType() const { return Read<UClass*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ClassProperty)
    TArray<UAIPerceptionComponent*> ListenerContainer() const { return Read<TArray<UAIPerceptionComponent*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<UAISenseEvent*> UnprocessedEvents() const { return Read<TArray<UAISenseEvent*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_ListenerDataType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ClassProperty)
    void SET_ListenerContainer(const TArray<UAIPerceptionComponent*>& Value) { Write<TArray<UAIPerceptionComponent*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_UnprocessedEvents(const TArray<UAISenseEvent*>& Value) { Write<TArray<UAISenseEvent*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
class UAISense_Damage : public UAISense
{
public:
    TArray<FAIDamageEvent> RegisteredEvents() const { return Read<TArray<FAIDamageEvent>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_RegisteredEvents(const TArray<FAIDamageEvent>& Value) { Write<TArray<FAIDamageEvent>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe0
class UAISense_Hearing : public UAISense
{
public:
    TArray<FAINoiseEvent> NoiseEvents() const { return Read<TArray<FAINoiseEvent>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    float SpeedOfSoundSq() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)

    void SET_NoiseEvents(const TArray<FAINoiseEvent>& Value) { Write<TArray<FAINoiseEvent>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_SpeedOfSoundSq(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x88
class UAISense_Prediction : public UAISense
{
public:
    TArray<FAIPredictionEvent> RegisteredEvents() const { return Read<TArray<FAIPredictionEvent>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_RegisteredEvents(const TArray<FAIPredictionEvent>& Value) { Write<TArray<FAIPredictionEvent>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1a8
class UAISense_Sight : public UAISense
{
public:
    int32_t MaxTracesPerTick() const { return Read<int32_t>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: IntProperty)
    int32_t MaxAsyncTracesPerTick() const { return Read<int32_t>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: IntProperty)
    int32_t MinQueriesPerTimeSliceCheck() const { return Read<int32_t>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: IntProperty)
    double MaxTimeSlicePerTick() const { return Read<double>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: DoubleProperty)
    float HighImportanceQueryDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: FloatProperty)
    float MaxQueryImportance() const { return Read<float>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: FloatProperty)
    float SightLimitQueryImportance() const { return Read<float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x4, Type: FloatProperty)
    float PendingQueriesBudgetReductionRatio() const { return Read<float>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: FloatProperty)
    bool bUseAsynchronousTraceForDefaultSightQueries() const { return Read<bool>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0x1, Type: BoolProperty)

    void SET_MaxTracesPerTick(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: IntProperty)
    void SET_MaxAsyncTracesPerTick(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: IntProperty)
    void SET_MinQueriesPerTimeSliceCheck(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: IntProperty)
    void SET_MaxTimeSlicePerTick(const double& Value) { Write<double>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: DoubleProperty)
    void SET_HighImportanceQueryDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: FloatProperty)
    void SET_MaxQueryImportance(const float& Value) { Write<float>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: FloatProperty)
    void SET_SightLimitQueryImportance(const float& Value) { Write<float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x4, Type: FloatProperty)
    void SET_PendingQueriesBudgetReductionRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: FloatProperty)
    void SET_bUseAsynchronousTraceForDefaultSightQueries(const bool& Value) { Write<bool>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UAISense_Team : public UAISense
{
public:
    TArray<FAITeamStimulusEvent> RegisteredEvents() const { return Read<TArray<FAITeamStimulusEvent>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_RegisteredEvents(const TArray<FAITeamStimulusEvent>& Value) { Write<TArray<FAITeamStimulusEvent>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd8
class UAISense_Touch : public UAISense
{
public:
    TArray<FAITouchEvent> RegisteredEvents() const { return Read<TArray<FAITouchEvent>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_RegisteredEvents(const TArray<FAITouchEvent>& Value) { Write<TArray<FAITouchEvent>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UAISightTargetInterface : public UInterface
{
public:
};

// Size: 0x100
class UPawnSensingComponent : public UActorComponent
{
public:
    float HearingThreshold() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float LOSHearingThreshold() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float SightRadius() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SensingInterval() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float HearingMaxSoundAge() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    bool bEnableSensingUpdates() const { return (Read<uint8_t>(uintptr_t(this) + 0xcc) >> 0x0) & 1; } // 0xcc:0 (Size: 0x1, Type: BoolProperty)
    bool bOnlySensePlayers() const { return (Read<uint8_t>(uintptr_t(this) + 0xcc) >> 0x1) & 1; } // 0xcc:1 (Size: 0x1, Type: BoolProperty)
    bool bSeePawns() const { return (Read<uint8_t>(uintptr_t(this) + 0xcc) >> 0x2) & 1; } // 0xcc:2 (Size: 0x1, Type: BoolProperty)
    bool bHearNoises() const { return (Read<uint8_t>(uintptr_t(this) + 0xcc) >> 0x3) & 1; } // 0xcc:3 (Size: 0x1, Type: BoolProperty)
    float PeripheralVisionAngle() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float PeripheralVisionCosine() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)

    void SET_HearingThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_LOSHearingThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_SightRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_SensingInterval(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_HearingMaxSoundAge(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableSensingUpdates(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xcc); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xcc, B); } // 0xcc:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlySensePlayers(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xcc); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xcc, B); } // 0xcc:1 (Size: 0x1, Type: BoolProperty)
    void SET_bSeePawns(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xcc); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xcc, B); } // 0xcc:2 (Size: 0x1, Type: BoolProperty)
    void SET_bHearNoises(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xcc); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0xcc, B); } // 0xcc:3 (Size: 0x1, Type: BoolProperty)
    void SET_PeripheralVisionAngle(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_PeripheralVisionCosine(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x68
class UAITask : public UGameplayTask
{
public:
    AAIController* OwnerController() const { return Read<AAIController*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_OwnerController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x68
class UAITask_LockLogic : public UAITask
{
public:
};

// Size: 0x130
class UAITask_MoveTo : public UAITask
{
public:
    FAIMoveRequest MoveRequest() const { return Read<FAIMoveRequest>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: StructProperty)

    void SET_MoveRequest(const FAIMoveRequest& Value) { Write<FAIMoveRequest>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: StructProperty)
};

// Size: 0xe0
class UAITask_RunEQS : public UAITask
{
public:
};

// Size: 0x28
class UVisualLoggerExtension : public UObject
{
public:
};

// Size: 0x60
struct FActorPerceptionUpdateInfo
{
public:
    int32_t TargetId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AActor*> Target() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
    FAIStimulus Stimulus() const { return Read<FAIStimulus>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: StructProperty)

    void SET_TargetId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Target(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Stimulus(const FAIStimulus& Value) { Write<FAIStimulus>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: StructProperty)
};

// Size: 0x50
struct FAIStimulus
{
public:
    float Age() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ExpirationAge() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FVector StimulusLocation() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector ReceiverLocation() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)
    bool bSuccessfullySensed() const { return (Read<uint8_t>(uintptr_t(this) + 0x4c) >> 0x1) & 1; } // 0x4c:1 (Size: 0x1, Type: BoolProperty)

    void SET_Age(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ExpirationAge(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_StimulusLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_ReceiverLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
    void SET_bSuccessfullySensed(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x4c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x4c, B); } // 0x4c:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FAIRequestID
{
public:
    uint32_t RequestID() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_RequestID(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0xc
struct FEnvNamedValue
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParamType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParamType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FAIDynamicParam
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParamType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    bool bAllowBBKey() const { return (Read<uint8_t>(uintptr_t(this) + 0x5) >> 0x0) & 1; } // 0x5:0 (Size: 0x1, Type: BoolProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FBlackboardKeySelector BBKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParamType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_bAllowBBKey(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x5); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x5, B); } // 0x5:0 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_BBKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FBlackboardKeySelector
{
public:
    TArray<UBlackboardKeyType*> AllowedTypes() const { return Read<TArray<UBlackboardKeyType*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FName SelectedKeyName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    UClass* SelectedKeyType() const { return Read<UClass*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ClassProperty)
    int32_t SelectedKeyID() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    bool bNoneIsAllowedValue() const { return (Read<uint8_t>(uintptr_t(this) + 0x24) >> 0x0) & 1; } // 0x24:0 (Size: 0x1, Type: BoolProperty)

    void SET_AllowedTypes(const TArray<UBlackboardKeyType*>& Value) { Write<TArray<UBlackboardKeyType*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectedKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_SelectedKeyType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ClassProperty)
    void SET_SelectedKeyID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_bNoneIsAllowedValue(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x24); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x24, B); } // 0x24:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FAIMoveRequest
{
public:
    TWeakObjectPtr<AActor*> GoalActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_GoalActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x8
struct FIntervalCountdown
{
public:
    float Interval() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_Interval(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FEnvDirection
{
public:
    UClass* LineFrom() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    UClass* LineTo() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    UClass* Rotation() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EEnvDirection> DirMode() const { return Read<TEnumAsByte<EEnvDirection>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: ByteProperty)

    void SET_LineFrom(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_LineTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_Rotation(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
    void SET_DirMode(const TEnumAsByte<EEnvDirection>& Value) { Write<TEnumAsByte<EEnvDirection>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x38
struct FEnvTraceData
{
public:
    int32_t VersionNum() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    UClass* NavigationFilter() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    float ProjectDown() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float ProjectUp() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float ExtentX() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float ExtentY() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float ExtentZ() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float PostProjectionVerticalOffset() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ECollisionChannel> SerializedChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: ByteProperty)
    FName TraceProfileName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EEnvTraceShape> TraceShape() const { return Read<TEnumAsByte<EEnvTraceShape>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvQueryTrace> TraceMode() const { return Read<TEnumAsByte<EEnvQueryTrace>>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: ByteProperty)
    bool bTraceComplex() const { return (Read<uint8_t>(uintptr_t(this) + 0x34) >> 0x0) & 1; } // 0x34:0 (Size: 0x1, Type: BoolProperty)
    bool bOnlyBlockingHits() const { return (Read<uint8_t>(uintptr_t(this) + 0x34) >> 0x1) & 1; } // 0x34:1 (Size: 0x1, Type: BoolProperty)
    bool bCanTraceOnNavMesh() const { return (Read<uint8_t>(uintptr_t(this) + 0x34) >> 0x2) & 1; } // 0x34:2 (Size: 0x1, Type: BoolProperty)
    bool bCanTraceOnGeometry() const { return (Read<uint8_t>(uintptr_t(this) + 0x34) >> 0x3) & 1; } // 0x34:3 (Size: 0x1, Type: BoolProperty)
    bool bCanDisableTrace() const { return (Read<uint8_t>(uintptr_t(this) + 0x34) >> 0x4) & 1; } // 0x34:4 (Size: 0x1, Type: BoolProperty)
    bool bCanProjectDown() const { return (Read<uint8_t>(uintptr_t(this) + 0x34) >> 0x5) & 1; } // 0x34:5 (Size: 0x1, Type: BoolProperty)

    void SET_VersionNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_NavigationFilter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_ProjectDown(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_ProjectUp(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_ExtentX(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_ExtentY(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_ExtentZ(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_PostProjectionVerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_TraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: ByteProperty)
    void SET_SerializedChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: ByteProperty)
    void SET_TraceProfileName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_TraceShape(const TEnumAsByte<EEnvTraceShape>& Value) { Write<TEnumAsByte<EEnvTraceShape>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: ByteProperty)
    void SET_TraceMode(const TEnumAsByte<EEnvQueryTrace>& Value) { Write<TEnumAsByte<EEnvQueryTrace>>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: ByteProperty)
    void SET_bTraceComplex(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x34); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x34, B); } // 0x34:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlyBlockingHits(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x34); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x34, B); } // 0x34:1 (Size: 0x1, Type: BoolProperty)
    void SET_bCanTraceOnNavMesh(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x34); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x34, B); } // 0x34:2 (Size: 0x1, Type: BoolProperty)
    void SET_bCanTraceOnGeometry(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x34); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x34, B); } // 0x34:3 (Size: 0x1, Type: BoolProperty)
    void SET_bCanDisableTrace(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x34); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x34, B); } // 0x34:4 (Size: 0x1, Type: BoolProperty)
    void SET_bCanProjectDown(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x34); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x34, B); } // 0x34:5 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FEnvOverlapData
{
public:
    float ExtentX() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ExtentY() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ExtentZ() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FVector ShapeOffset() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> OverlapChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvOverlapShape> OverlapShape() const { return Read<TEnumAsByte<EEnvOverlapShape>>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: ByteProperty)
    bool bOnlyBlockingHits() const { return (Read<uint8_t>(uintptr_t(this) + 0x2c) >> 0x0) & 1; } // 0x2c:0 (Size: 0x1, Type: BoolProperty)
    bool bOverlapComplex() const { return (Read<uint8_t>(uintptr_t(this) + 0x2c) >> 0x1) & 1; } // 0x2c:1 (Size: 0x1, Type: BoolProperty)
    bool bSkipOverlapQuerier() const { return (Read<uint8_t>(uintptr_t(this) + 0x2c) >> 0x2) & 1; } // 0x2c:2 (Size: 0x1, Type: BoolProperty)

    void SET_ExtentX(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ExtentY(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ExtentZ(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ShapeOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_OverlapChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: ByteProperty)
    void SET_OverlapShape(const TEnumAsByte<EEnvOverlapShape>& Value) { Write<TEnumAsByte<EEnvOverlapShape>>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: ByteProperty)
    void SET_bOnlyBlockingHits(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2c, B); } // 0x2c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverlapComplex(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x2c, B); } // 0x2c:1 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipOverlapQuerier(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x2c, B); } // 0x2c:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FEnvQueryResult
{
public:
    UClass* ItemType() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)
    int32_t OptionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t QueryID() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_ItemType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
    void SET_OptionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_QueryID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

// Size: 0x48
struct FEQSParametrizedQueryExecutionRequest
{
public:
    UEnvQuery* QueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FAIDynamicParam> QueryConfig() const { return Read<TArray<FAIDynamicParam>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FBlackboardKeySelector EQSQueryBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EEnvQueryRunMode> RunMode() const { return Read<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: ByteProperty)
    bool bUseBBKeyForQueryTemplate() const { return (Read<uint8_t>(uintptr_t(this) + 0x44) >> 0x0) & 1; } // 0x44:0 (Size: 0x1, Type: BoolProperty)

    void SET_QueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_QueryConfig(const TArray<FAIDynamicParam>& Value) { Write<TArray<FAIDynamicParam>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_EQSQueryBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x28, Type: StructProperty)
    void SET_RunMode(const TEnumAsByte<EEnvQueryRunMode>& Value) { Write<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: ByteProperty)
    void SET_bUseBBKeyForQueryTemplate(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x44); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x44, B); } // 0x44:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FGenericTeamId
{
public:
    char TeamID() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)

    void SET_TeamID(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x4
struct FSimpleIndexedHandleBase
{
public:
};

// Size: 0x8
struct FIndexedHandleBase : public FSimpleIndexedHandleBase
{
public:
};

// Size: 0x4
struct FCompactIndexedHandleBase
{
public:
};

// Size: 0x4
struct FSequentialIDBase
{
public:
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x8
struct FValueOrBlackboardKeyBase
{
public:
    FName Key() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_Key(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0xc
struct FValueOrBBKey_Bool : public FValueOrBlackboardKeyBase
{
public:
    bool DefaultValue() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_DefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FValueOrBBKey_Class : public FValueOrBlackboardKeyBase
{
public:
    UClass* DefaultValue() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    UClass* BaseClass() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)

    void SET_DefaultValue(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_BaseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
struct FValueOrBBKey_Enum : public FValueOrBlackboardKeyBase
{
public:
    char DefaultValue() const { return Read<char>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)
    UEnum* EnumType() const { return Read<UEnum*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FString NativeEnumTypeName() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_DefaultValue(const char& Value) { Write<char>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
    void SET_EnumType(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_NativeEnumTypeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0xc
struct FValueOrBBKey_Float : public FValueOrBlackboardKeyBase
{
public:
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FValueOrBBKey_Int32 : public FValueOrBlackboardKeyBase
{
public:
    int32_t DefaultValue() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_DefaultValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc
struct FValueOrBBKey_Name : public FValueOrBlackboardKeyBase
{
public:
    FName DefaultValue() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_DefaultValue(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x18
struct FValueOrBBKey_String : public FValueOrBlackboardKeyBase
{
public:
    FString DefaultValue() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_DefaultValue(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FValueOrBBKey_Object : public FValueOrBlackboardKeyBase
{
public:
    UObject* DefaultValue() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* BaseClass() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)

    void SET_DefaultValue(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_BaseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x20
struct FValueOrBBKey_Rotator : public FValueOrBlackboardKeyBase
{
public:
    FRotator DefaultValue() const { return Read<FRotator>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_DefaultValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FValueOrBBKey_Vector : public FValueOrBlackboardKeyBase
{
public:
    FVector DefaultValue() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_DefaultValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FValueOrBBKey_Struct : public FValueOrBlackboardKeyBase
{
public:
    FInstancedStruct DefaultValue() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_DefaultValue(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FBehaviorTreeTemplateInfo
{
public:
    UBehaviorTree* Asset() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UBTCompositeNode* Template() const { return Read<UBTCompositeNode*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Asset(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Template(const UBTCompositeNode*& Value) { Write<UBTCompositeNode*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FBlackboardEntry
{
public:
    FName EntryName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UBlackboardKeyType* KeyType() const { return Read<UBlackboardKeyType*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bInstanceSynced() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x0) & 1; } // 0x10:0 (Size: 0x1, Type: BoolProperty)

    void SET_EntryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_KeyType(const UBlackboardKeyType*& Value) { Write<UBlackboardKeyType*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bInstanceSynced(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FBTDecoratorLogic
{
public:
    TEnumAsByte<EBTDecoratorLogic> Operation() const { return Read<TEnumAsByte<EBTDecoratorLogic>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    uint16_t Number() const { return Read<uint16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: UInt16Property)

    void SET_Operation(const TEnumAsByte<EBTDecoratorLogic>& Value) { Write<TEnumAsByte<EBTDecoratorLogic>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Number(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x30
struct FBTCompositeChild
{
public:
    UBTCompositeNode* ChildComposite() const { return Read<UBTCompositeNode*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UBTTaskNode* ChildTask() const { return Read<UBTTaskNode*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<UBTDecorator*> Decorators() const { return Read<TArray<UBTDecorator*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FBTDecoratorLogic> DecoratorOps() const { return Read<TArray<FBTDecoratorLogic>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_ChildComposite(const UBTCompositeNode*& Value) { Write<UBTCompositeNode*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ChildTask(const UBTTaskNode*& Value) { Write<UBTTaskNode*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Decorators(const TArray<UBTDecorator*>& Value) { Write<TArray<UBTDecorator*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_DecoratorOps(const TArray<FBTDecoratorLogic>& Value) { Write<TArray<FBTDecoratorLogic>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FAIDataProviderValue
{
public:
    UAIDataProvider* DataBinding() const { return Read<UAIDataProvider*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FName DataField() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)

    void SET_DataBinding(const UAIDataProvider*& Value) { Write<UAIDataProvider*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_DataField(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
struct FAIDataProviderTypedValue : public FAIDataProviderValue
{
public:
    UClass* PropertyType() const { return Read<UClass*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ClassProperty)

    void SET_PropertyType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x30
struct FAIDataProviderStructValue : public FAIDataProviderValue
{
public:
};

// Size: 0x38
struct FAIDataProviderIntValue : public FAIDataProviderTypedValue
{
public:
    int32_t DefaultValue() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_DefaultValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FAIDataProviderFloatValue : public FAIDataProviderTypedValue
{
public:
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FAIDataProviderBoolValue : public FAIDataProviderTypedValue
{
public:
    bool DefaultValue() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_DefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FEnvQueryManagerConfig
{
public:
    float MaxAllowedTestingTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bTestQueriesUsingBreadth() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    int32_t QueryCountWarningThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    double QueryCountWarningInterval() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double ExecutionTimeWarningSeconds() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double HandlingResultTimeWarningSeconds() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    double GenerationTimeWarningSeconds() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)

    void SET_MaxAllowedTestingTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bTestQueriesUsingBreadth(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_QueryCountWarningThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_QueryCountWarningInterval(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_ExecutionTimeWarningSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_HandlingResultTimeWarningSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_GenerationTimeWarningSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x68
struct FEnvQueryRequest
{
public:
    UEnvQuery* QueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* Owner() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UWorld* World() const { return Read<UWorld*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_QueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Owner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_World(const UWorld*& Value) { Write<UWorld*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x180
struct FEnvQueryInstanceCache
{
public:
    UEnvQuery* Template() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Template(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1c
struct FCrowdAvoidanceConfig
{
public:
    float VelocityBias() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float DesiredVelocityWeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float CurrentVelocityWeight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float SideBiasWeight() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float ImpactTimeWeight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float ImpactTimeRange() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    char CustomPatternIdx() const { return Read<char>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: ByteProperty)
    char AdaptiveDivisions() const { return Read<char>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: ByteProperty)
    char AdaptiveRings() const { return Read<char>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: ByteProperty)
    char AdaptiveDepth() const { return Read<char>(uintptr_t(this) + 0x1b); } // 0x1b (Size: 0x1, Type: ByteProperty)

    void SET_VelocityBias(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredVelocityWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentVelocityWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_SideBiasWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_ImpactTimeWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_ImpactTimeRange(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CustomPatternIdx(const char& Value) { Write<char>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: ByteProperty)
    void SET_AdaptiveDivisions(const char& Value) { Write<char>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: ByteProperty)
    void SET_AdaptiveRings(const char& Value) { Write<char>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: ByteProperty)
    void SET_AdaptiveDepth(const char& Value) { Write<char>(uintptr_t(this) + 0x1b, Value); } // 0x1b (Size: 0x1, Type: ByteProperty)
};

// Size: 0x20
struct FCrowdAvoidanceSamplingPattern
{
public:
    TArray<float> Angles() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<float> Radii() const { return Read<TArray<float>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Angles(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Radii(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb8
struct FRecastGraphWrapper
{
public:
    ARecastNavMesh* RecastNavMeshActor() const { return Read<ARecastNavMesh*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_RecastNavMeshActor(const ARecastNavMesh*& Value) { Write<ARecastNavMesh*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FActorPerceptionBlueprintInfo
{
public:
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FAIStimulus> LastSensedStimuli() const { return Read<TArray<FAIStimulus>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bIsHostile() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x0) & 1; } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    bool bIsFriendly() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x1) & 1; } // 0x18:1 (Size: 0x1, Type: BoolProperty)

    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_LastSensedStimuli(const TArray<FAIStimulus>& Value) { Write<TArray<FAIStimulus>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsHostile(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFriendly(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FAISenseAffiliationFilter
{
public:
    bool bDetectEnemies() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bDetectNeutrals() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    bool bDetectFriendlies() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x2) & 1; } // 0x0:2 (Size: 0x1, Type: BoolProperty)

    void SET_bDetectEnemies(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDetectNeutrals(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bDetectFriendlies(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FAIDamageEvent
{
public:
    float Amount() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    AActor* DamagedActor() const { return Read<AActor*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    AActor* Instigator() const { return Read<AActor*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)

    void SET_Amount(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_DamagedActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_Instigator(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
};

// Size: 0x38
struct FAINoiseEvent
{
public:
    FVector NoiseLocation() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float Loudness() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    AActor* Instigator() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)

    void SET_NoiseLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Loudness(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_Instigator(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
};

// Size: 0x18
struct FAIPredictionEvent
{
public:
    AActor* Requestor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* PredictedActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Requestor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PredictedActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FAISightEvent
{
public:
    AActor* SeenActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* Observer() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_SeenActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Observer(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
struct FAITeamStimulusEvent
{
public:
    AActor* Broadcaster() const { return Read<AActor*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    AActor* Enemy() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_Broadcaster(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_Enemy(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FAITouchEvent
{
public:
    AActor* TouchReceiver() const { return Read<AActor*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    AActor* OtherActor() const { return Read<AActor*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_TouchReceiver(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

