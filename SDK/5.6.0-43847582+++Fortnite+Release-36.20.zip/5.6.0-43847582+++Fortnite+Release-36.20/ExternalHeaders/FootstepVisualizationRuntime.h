/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FootstepVisualizationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "Niagara.h"
#include "Engine.h"

// Size: 0x2a8
class UFortGameStateComponent_FootstepVisualization : public UFortGameStateComponent
{
public:
    UNiagaraDataChannelAsset* FootstepFxDataChannel() const { return Read<UNiagaraDataChannelAsset*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat EnableFootstepGeneratorDeathEvent() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    TArray<UFortPawnComponent_FootstepVisualization*> PawnComponents() const { return Read<TArray<UFortPawnComponent_FootstepVisualization*>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat SimulatedFootstepMaxTicksPerFrame() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RegisteredFootstepCapacity() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RegisteredFootstepMaxAge() const { return Read<FScalableFloat>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x28, Type: StructProperty)
    TArray<FVisualizedFootstepData> FootstepRegistry() const { return Read<TArray<FVisualizedFootstepData>>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x10, Type: ArrayProperty)

    void SET_FootstepFxDataChannel(const UNiagaraDataChannelAsset*& Value) { Write<UNiagaraDataChannelAsset*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_EnableFootstepGeneratorDeathEvent(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_PawnComponents(const TArray<UFortPawnComponent_FootstepVisualization*>& Value) { Write<TArray<UFortPawnComponent_FootstepVisualization*>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_SimulatedFootstepMaxTicksPerFrame(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_RegisteredFootstepCapacity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    void SET_RegisteredFootstepMaxAge(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x28, Type: StructProperty)
    void SET_FootstepRegistry(const TArray<FVisualizedFootstepData>& Value) { Write<TArray<FVisualizedFootstepData>>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2d0
class UFortPawnComponent_FootstepVisualization : public UFortPawnComponent
{
public:
    FName LeftFootSocket() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FTransform LeftFootSocketToFootprint() const { return Read<FTransform>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x60, Type: StructProperty)
    FName RightFootSocket() const { return Read<FName>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: NameProperty)
    FTransform RightFootSocketToFootprint() const { return Read<FTransform>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x60, Type: StructProperty)
    double FixupFootstepBelowCapsuleDistance() const { return Read<double>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    double FixupFootstepYawToleranceDegrees() const { return Read<double>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: DoubleProperty)
    FName FixupFootstepTraceProfile() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAxis> FixupFootstepMeshForwardAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x1, Type: ByteProperty)
    FScalableFloat DistanceBetweenStepsDefault() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DistanceBetweenStepsCrouching() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DistanceBetweenStepsSprinting() const { return Read<FScalableFloat>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat NextFootstepDeadzoneDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x28, Type: StructProperty)
    UDataTable* VisualizationExclusionTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x8, Type: ObjectProperty)
    UDataTable* SurfaceInclusionTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    UFortGameStateComponent_FootstepVisualization* GameStateComponent() const { return Read<UFortGameStateComponent_FootstepVisualization*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ObjectProperty)

    void SET_LeftFootSocket(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_LeftFootSocketToFootprint(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x60, Type: StructProperty)
    void SET_RightFootSocket(const FName& Value) { Write<FName>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: NameProperty)
    void SET_RightFootSocketToFootprint(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x60, Type: StructProperty)
    void SET_FixupFootstepBelowCapsuleDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    void SET_FixupFootstepYawToleranceDegrees(const double& Value) { Write<double>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: DoubleProperty)
    void SET_FixupFootstepTraceProfile(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_FixupFootstepMeshForwardAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x1, Type: ByteProperty)
    void SET_DistanceBetweenStepsDefault(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_DistanceBetweenStepsCrouching(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    void SET_DistanceBetweenStepsSprinting(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x28, Type: StructProperty)
    void SET_NextFootstepDeadzoneDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x28, Type: StructProperty)
    void SET_VisualizationExclusionTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x8, Type: ObjectProperty)
    void SET_SurfaceInclusionTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    void SET_GameStateComponent(const UFortGameStateComponent_FootstepVisualization*& Value) { Write<UFortGameStateComponent_FootstepVisualization*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FVisualizedFootstepData
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    float time() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    int32_t PawnID() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    char Team() const { return Read<char>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: ByteProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_time(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_PawnID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_Team(const char& Value) { Write<char>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FFootstepVisualizationExclusionRow : public FTableRowBase
{
public:
    FGameplayTagQuery ExclusionTestQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)

    void SET_ExclusionTestQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x10
struct FFootstepVisualizationSurfaceInclusionRow : public FTableRowBase
{
public:
    TEnumAsByte<EObjectTypeQuery> ObjectType() const { return Read<TEnumAsByte<EObjectTypeQuery>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)

    void SET_ObjectType(const TEnumAsByte<EObjectTypeQuery>& Value) { Write<TEnumAsByte<EObjectTypeQuery>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
};

