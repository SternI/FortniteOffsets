/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AutoAimWeaponRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x28
class UAutoAimWeaponKismetLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x1a0
class UAutoAimWeaponPawnComponent : public UFortPawnComponent
{
public:
    FGameplayTagContainer UseSingleLocationTargetingPawnTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer LowPriorityTargetPawnTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x20, Type: StructProperty)
    TArray<FAutoAimWeaponBoneSegmentData> MultiSocketTargetingBoneSegmentDatas() const { return Read<TArray<FAutoAimWeaponBoneSegmentData>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat LockOnTimeReticleCenter() const { return Read<FScalableFloat>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)
    FScalableFloat LockOnTimeReticleEdge() const { return Read<FScalableFloat>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxLockOns() const { return Read<FScalableFloat>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> LineOfSightTraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x1, Type: ByteProperty)
    float ProgressTowardNextLockOn() const { return Read<float>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x4, Type: FloatProperty)
    int32_t CurrentLockOnCount() const { return Read<int32_t>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x4, Type: IntProperty)
    float TargetToReticleDistanceNormalized() const { return Read<float>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<AFortPawn*> LockOnTarget() const { return Read<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: WeakObjectProperty)

    void SET_UseSingleLocationTargetingPawnTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x20, Type: StructProperty)
    void SET_LowPriorityTargetPawnTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x20, Type: StructProperty)
    void SET_MultiSocketTargetingBoneSegmentDatas(const TArray<FAutoAimWeaponBoneSegmentData>& Value) { Write<TArray<FAutoAimWeaponBoneSegmentData>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_LockOnTimeReticleCenter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
    void SET_LockOnTimeReticleEdge(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x28, Type: StructProperty)
    void SET_MaxLockOns(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x28, Type: StructProperty)
    void SET_LineOfSightTraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x1, Type: ByteProperty)
    void SET_ProgressTowardNextLockOn(const float& Value) { Write<float>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x4, Type: FloatProperty)
    void SET_CurrentLockOnCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x4, Type: IntProperty)
    void SET_TargetToReticleDistanceNormalized(const float& Value) { Write<float>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x4, Type: FloatProperty)
    void SET_LockOnTarget(const TWeakObjectPtr<AFortPawn*>& Value) { Write<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xc
struct FAutoAimWeaponBoneSegmentData
{
public:
    FName BoneName1() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName2() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    float BoneCollisionCapsuleRadiusAproximation() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_BoneName1(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BoneName2(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_BoneCollisionCapsuleRadiusAproximation(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

