/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventScreenBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "Engine.h"

// Size: 0x310
class UFortEventScreenData : public UDataAsset
{
public:
    FString EventCMSId() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString AccountResourceName() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    FString AccountResourceNameGranter() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    FString LevelOfferId() const { return Read<FString>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StrProperty)
    FString PremiumTrackOfferId() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    UFortTokenType* PremiumTrackPurchasedToken() const { return Read<UFortTokenType*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag VaultWorldTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: StructProperty)
    FVaultWorldBackgroundData PreviewScreenBackgroundData() const { return Read<FVaultWorldBackgroundData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x58, Type: StructProperty)
    TSoftObjectPtr<UFortChallengeBundleItemDefinition> QuestBundle() const { return Read<TSoftObjectPtr<UFortChallengeBundleItemDefinition>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortItemDefinition> SpecialRewardItem() const { return Read<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortItemDefinition> SpecialPremiumRewardItem() const { return Read<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FEventItemOverride> ItemOverrides() const { return Read<TArray<FEventItemOverride>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    FEventScreenTrackData FreeTrackData() const { return Read<FEventScreenTrackData>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x30, Type: StructProperty)
    FEventScreenTrackData PremiumTrackData() const { return Read<FEventScreenTrackData>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x30, Type: StructProperty)
    FGameplayTag QuestCategoryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: StructProperty)
    TArray<UClass*> RichTextDecorators() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FLinearColor> RewardTileBackgroundColors() const { return Read<TMap<FName, FLinearColor>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x50, Type: MapProperty)
    FText TimeRemainingFormat() const { return Read<FText>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: TextProperty)
    FText CurrencyFormat() const { return Read<FText>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject> MoreInfoKeyArt() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FEventScreenMoreInfoGroup> MoreInfoGroups() const { return Read<TArray<FEventScreenMoreInfoGroup>>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x10, Type: ArrayProperty)
    float RewardPreviewZoomLevel() const { return Read<float>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x4, Type: FloatProperty)
    bool bUseWidgetCameraFraming() const { return Read<bool>(uintptr_t(this) + 0x274); } // 0x274 (Size: 0x1, Type: BoolProperty)
    TArray<FString> CalendarEvents() const { return Read<TArray<FString>>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    bool bUseRewardTrackProgressInsteadOfCurrentResource() const { return Read<bool>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x1, Type: BoolProperty)

    void SET_EventCMSId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_AccountResourceName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_AccountResourceNameGranter(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_LevelOfferId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StrProperty)
    void SET_PremiumTrackOfferId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_PremiumTrackPurchasedToken(const UFortTokenType*& Value) { Write<UFortTokenType*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_VaultWorldTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: StructProperty)
    void SET_PreviewScreenBackgroundData(const FVaultWorldBackgroundData& Value) { Write<FVaultWorldBackgroundData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x58, Type: StructProperty)
    void SET_QuestBundle(const TSoftObjectPtr<UFortChallengeBundleItemDefinition>& Value) { Write<TSoftObjectPtr<UFortChallengeBundleItemDefinition>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SpecialRewardItem(const TSoftObjectPtr<UFortItemDefinition>& Value) { Write<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SpecialPremiumRewardItem(const TSoftObjectPtr<UFortItemDefinition>& Value) { Write<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ItemOverrides(const TArray<FEventItemOverride>& Value) { Write<TArray<FEventItemOverride>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    void SET_FreeTrackData(const FEventScreenTrackData& Value) { Write<FEventScreenTrackData>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x30, Type: StructProperty)
    void SET_PremiumTrackData(const FEventScreenTrackData& Value) { Write<FEventScreenTrackData>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x30, Type: StructProperty)
    void SET_QuestCategoryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: StructProperty)
    void SET_RichTextDecorators(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    void SET_RewardTileBackgroundColors(const TMap<FName, FLinearColor>& Value) { Write<TMap<FName, FLinearColor>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x50, Type: MapProperty)
    void SET_TimeRemainingFormat(const FText& Value) { Write<FText>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: TextProperty)
    void SET_CurrencyFormat(const FText& Value) { Write<FText>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x10, Type: TextProperty)
    void SET_MoreInfoKeyArt(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MoreInfoGroups(const TArray<FEventScreenMoreInfoGroup>& Value) { Write<TArray<FEventScreenMoreInfoGroup>>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x10, Type: ArrayProperty)
    void SET_RewardPreviewZoomLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x4, Type: FloatProperty)
    void SET_bUseWidgetCameraFraming(const bool& Value) { Write<bool>(uintptr_t(this) + 0x274, Value); } // 0x274 (Size: 0x1, Type: BoolProperty)
    void SET_CalendarEvents(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseRewardTrackProgressInsteadOfCurrentResource(const bool& Value) { Write<bool>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x460
class UFortEventModalBase : public UCommonActivatableWidget
{
public:
};

// Size: 0x2f8
class UFortEventMoreInfoGroup : public UUserWidget
{
public:
};

// Size: 0x488
class UFortEventMoreInfoModal : public UFortEventModalBase
{
public:
    UDynamicEntryBox* DynamicEntryBox_Groups() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* SB_Vertical() const { return Read<UScrollBox*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)

    void SET_DynamicEntryBox_Groups(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Back(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_SB_Vertical(const UScrollBox*& Value) { Write<UScrollBox*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4d0
class UFortEventPurchaseLevelsModal : public UFortEventModalBase
{
public:
    UCommonButtonBase* Button_Addition() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Subtraction() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Purchase() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_GetVBucks() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UEventScreenListView* ListView_RewardPreview() const { return Read<UEventScreenListView*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentResourceValue() const { return Read<int32_t>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x4, Type: IntProperty)
    int32_t MaxResourceValue() const { return Read<int32_t>(uintptr_t(this) + 0x49c); } // 0x49c (Size: 0x4, Type: IntProperty)
    int32_t CurrentVBucks() const { return Read<int32_t>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x4, Type: IntProperty)
    int32_t OfferResourceQuantity() const { return Read<int32_t>(uintptr_t(this) + 0x4a4); } // 0x4a4 (Size: 0x4, Type: IntProperty)
    bool bAnimateListViewFromEmpty() const { return Read<bool>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x1, Type: BoolProperty)

    void SET_Button_Addition(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Subtraction(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Purchase(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_GetVBucks(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Back(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_ListView_RewardPreview(const UEventScreenListView*& Value) { Write<UEventScreenListView*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentResourceValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x4, Type: IntProperty)
    void SET_MaxResourceValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x49c, Value); } // 0x49c (Size: 0x4, Type: IntProperty)
    void SET_CurrentVBucks(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x4, Type: IntProperty)
    void SET_OfferResourceQuantity(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4a4, Value); } // 0x4a4 (Size: 0x4, Type: IntProperty)
    void SET_bAnimateListViewFromEmpty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2f8
class UFortPurchasePremiumTrackBody : public UUserWidget
{
public:
};

// Size: 0x4d0
class UFortEventPurchasePremiumTrackModal : public UFortEventModalBase
{
public:
    UDynamicEntryBox* DynamicEntryBox_Body() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* ScrollBox_Body() const { return Read<UScrollBox*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UFortCTAButton* Button_Purchase() const { return Read<UFortCTAButton*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_GetVBucks() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PreviewReward() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentVBucks() const { return Read<int32_t>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x4, Type: IntProperty)

    void SET_DynamicEntryBox_Body(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_ScrollBox_Body(const UScrollBox*& Value) { Write<UScrollBox*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Purchase(const UFortCTAButton*& Value) { Write<UFortCTAButton*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_GetVBucks(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Back(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PreviewReward(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentVBucks(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x4, Type: IntProperty)
};

// Size: 0x300
class UFortEventListViewWidgetBase : public UUserWidget
{
public:
};

// Size: 0x350
class UFortEventRewardTracksWidget : public UFortEventListViewWidgetBase
{
public:
    UDynamicEntryBox* DynamicEntryBox_RewardTracks() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    bool bPreviewMode() const { return Read<bool>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x1, Type: BoolProperty)

    void SET_DynamicEntryBox_RewardTracks(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_bPreviewMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x300
class UFortEventSpacerWidget : public UFortEventListViewWidgetBase
{
public:
};

// Size: 0x388
class UFortEventRewardWidget : public UUserWidget
{
public:
    UCommonButtonBase* Button_RewardPreview() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UFortCosmeticItemCard* UserWidget_ItemCard() const { return Read<UFortCosmeticItemCard*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool bIsTrackOwned() const { return Read<bool>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x1, Type: BoolProperty)
    bool bPreviewMode() const { return Read<bool>(uintptr_t(this) + 0x311); } // 0x311 (Size: 0x1, Type: BoolProperty)
    bool bInPreviewSelectedState() const { return Read<bool>(uintptr_t(this) + 0x312); } // 0x312 (Size: 0x1, Type: BoolProperty)
    bool bInPremiumUpgradeState() const { return Read<bool>(uintptr_t(this) + 0x313); } // 0x313 (Size: 0x1, Type: BoolProperty)

    void SET_Button_RewardPreview(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_UserWidget_ItemCard(const UFortCosmeticItemCard*& Value) { Write<UFortCosmeticItemCard*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsTrackOwned(const bool& Value) { Write<bool>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x1, Type: BoolProperty)
    void SET_bPreviewMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x311, Value); } // 0x311 (Size: 0x1, Type: BoolProperty)
    void SET_bInPreviewSelectedState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x312, Value); } // 0x312 (Size: 0x1, Type: BoolProperty)
    void SET_bInPremiumUpgradeState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x313, Value); } // 0x313 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc08
class UFortEventScreenBase : public UFortItemPreviewScreen
{
public:
    TArray<UNamedSlot*> LayoutTemplateSlots() const { return Read<TArray<UNamedSlot*>>(uintptr_t(this) + 0x890); } // 0x890 (Size: 0x10, Type: ArrayProperty)
    UFortLazyImage* LazyImage_KeyArt() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ViewQuests() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MoreInfo() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PurchaseLevels() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Preview() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ShowInItemShop() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Previous() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8d0); } // 0x8d0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Next() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8d8); } // 0x8d8 (Size: 0x8, Type: ObjectProperty)
    UFortEventTrackerModule_CustomText* CustomText_InspectItem() const { return Read<UFortEventTrackerModule_CustomText*>(uintptr_t(this) + 0x8e0); } // 0x8e0 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_LoadError() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x8e8); } // 0x8e8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Close() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x8f8); } // 0x8f8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x900); } // 0x900 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_DebugLoadingErrorReason() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x8, Type: ObjectProperty)
    UFortEventScreenData* EventScreenData() const { return Read<UFortEventScreenData*>(uintptr_t(this) + 0x928); } // 0x928 (Size: 0x8, Type: ObjectProperty)
    uint8_t ActiveRewardPreviewType() const { return Read<uint8_t>(uintptr_t(this) + 0x930); } // 0x930 (Size: 0x1, Type: EnumProperty)
    UFortChallengeBundleItemDefinition* LoadedQuestBundle() const { return Read<UFortChallengeBundleItemDefinition*>(uintptr_t(this) + 0x938); } // 0x938 (Size: 0x8, Type: ObjectProperty)
    UFortItemVM* CachedItemVM() const { return Read<UFortItemVM*>(uintptr_t(this) + 0x940); } // 0x940 (Size: 0x8, Type: ObjectProperty)
    UEventScreenVariantManager* VariantManager() const { return Read<UEventScreenVariantManager*>(uintptr_t(this) + 0x948); } // 0x948 (Size: 0x8, Type: ObjectProperty)

    void SET_LayoutTemplateSlots(const TArray<UNamedSlot*>& Value) { Write<TArray<UNamedSlot*>>(uintptr_t(this) + 0x890, Value); } // 0x890 (Size: 0x10, Type: ArrayProperty)
    void SET_LazyImage_KeyArt(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ViewQuests(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_MoreInfo(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PurchaseLevels(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Preview(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ShowInItemShop(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Previous(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8d0, Value); } // 0x8d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Next(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8d8, Value); } // 0x8d8 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomText_InspectItem(const UFortEventTrackerModule_CustomText*& Value) { Write<UFortEventTrackerModule_CustomText*>(uintptr_t(this) + 0x8e0, Value); } // 0x8e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Panel_LoadError(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x8e8, Value); } // 0x8e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Close(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x8f8, Value); } // 0x8f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Back(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x900, Value); } // 0x900 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_DebugLoadingErrorReason(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x8, Type: ObjectProperty)
    void SET_EventScreenData(const UFortEventScreenData*& Value) { Write<UFortEventScreenData*>(uintptr_t(this) + 0x928, Value); } // 0x928 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveRewardPreviewType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x930, Value); } // 0x930 (Size: 0x1, Type: EnumProperty)
    void SET_LoadedQuestBundle(const UFortChallengeBundleItemDefinition*& Value) { Write<UFortChallengeBundleItemDefinition*>(uintptr_t(this) + 0x938, Value); } // 0x938 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedItemVM(const UFortItemVM*& Value) { Write<UFortItemVM*>(uintptr_t(this) + 0x940, Value); } // 0x940 (Size: 0x8, Type: ObjectProperty)
    void SET_VariantManager(const UEventScreenVariantManager*& Value) { Write<UEventScreenVariantManager*>(uintptr_t(this) + 0x948, Value); } // 0x948 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x478
class UEventScreenListView : public UListViewBase
{
public:
    UClass* RewardTrackWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ClassProperty)
    UClass* SpacerWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ClassProperty)
    float EntrySpacing() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    bool bCenterSelection() const { return Read<bool>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x1, Type: BoolProperty)
    float MaxItemsInView() const { return Read<float>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    bool bPreviewMode() const { return Read<bool>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x1, Type: BoolProperty)
    UCurveFloat* ProgressAnimationCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    bool bCanAnimateOnceComplete() const { return Read<bool>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x1, Type: BoolProperty)

    void SET_RewardTrackWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ClassProperty)
    void SET_SpacerWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ClassProperty)
    void SET_EntrySpacing(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_bCenterSelection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x1, Type: BoolProperty)
    void SET_MaxItemsInView(const float& Value) { Write<float>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    void SET_bPreviewMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x1, Type: BoolProperty)
    void SET_ProgressAnimationCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_bCanAnimateOnceComplete(const bool& Value) { Write<bool>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x600
class UFortEventScreenTeaser : public UFortActivatablePanel
{
public:
    FString CountdownCalendarEventFlag() const { return Read<FString>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x10, Type: StrProperty)
    TArray<FString> CalendarEvents() const { return Read<TArray<FString>>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag QuestCategoryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x4, Type: StructProperty)
    UCommonButtonBase* Button_ViewQuests() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: ObjectProperty)

    void SET_CountdownCalendarEventFlag(const FString& Value) { Write<FString>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x10, Type: StrProperty)
    void SET_CalendarEvents(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x10, Type: ArrayProperty)
    void SET_QuestCategoryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x4, Type: StructProperty)
    void SET_Button_ViewQuests(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x70
class UEventScreenVariantManager : public UObject
{
public:
};

// Size: 0x358
class UFortEventTokenCollectionWidget : public UUserWidget
{
public:
    UCommonLazyImage* LazyImage_GhostIcon() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_CompletedIcon() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Glow() const { return Read<UImage*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UTexture2D> FallbackBrush() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortTokenType> TokenDefinition() const { return Read<TSoftObjectPtr<UFortTokenType>>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x20, Type: SoftObjectProperty)

    void SET_LazyImage_GhostIcon(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_LazyImage_CompletedIcon(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Glow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_FallbackBrush(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TokenDefinition(const TSoftObjectPtr<UFortTokenType>& Value) { Write<TSoftObjectPtr<UFortTokenType>>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x300
class UFortEventTrackerModule : public UUserWidget
{
public:
};

// Size: 0x300
class UFortEventTrackerModule_EventDetails : public UFortEventTrackerModule
{
public:
};

// Size: 0x300
class UFortEventTrackerModule_Header : public UFortEventTrackerModule
{
public:
};

// Size: 0x308
class UFortEventTrackerModule_RewardDetails : public UFortEventTrackerModule
{
public:
};

// Size: 0x320
class UFortEventTrackerModule_RewardRemaining : public UFortEventTrackerModule
{
public:
    UCommonButtonBase* Button_PurchasePremium() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)

    void SET_Button_PurchasePremium(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x308
class UFortEventTrackerModule_ProgressiveRewards : public UFortEventTrackerModule
{
public:
    UEventScreenListView* ListView_Rewards() const { return Read<UEventScreenListView*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)

    void SET_ListView_Rewards(const UEventScreenListView*& Value) { Write<UEventScreenListView*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x300
class UFortEventTrackerModule_Collection : public UFortEventTrackerModule
{
public:
};

// Size: 0x308
class UFortEventTrackerModule_Banner : public UFortEventTrackerModule
{
public:
    UFortLazyImage* LazyImage_BannerArt() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)

    void SET_LazyImage_BannerArt(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class UFortEventTrackerModule_PremiumUpsell : public UFortEventTrackerModule
{
public:
    UFortCTAButton* Button_Prompt() const { return Read<UFortCTAButton*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    FText PromptTextUnowned() const { return Read<FText>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: TextProperty)
    FText PromptTextOwned() const { return Read<FText>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x10, Type: TextProperty)

    void SET_Button_Prompt(const UFortCTAButton*& Value) { Write<UFortCTAButton*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_PromptTextUnowned(const FText& Value) { Write<FText>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: TextProperty)
    void SET_PromptTextOwned(const FText& Value) { Write<FText>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x10, Type: TextProperty)
};

// Size: 0x300
class UFortEventTrackerModule_CustomText : public UFortEventTrackerModule
{
public:
};

// Size: 0x68
struct FEventItemOverride
{
public:
    TSoftObjectPtr<UFortItemDefinition> ItemDefinition() const { return Read<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> CustomItemTexture() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> CustomItemTextureMobile() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsDoubleWidth() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)

    void SET_ItemDefinition(const TSoftObjectPtr<UFortItemDefinition>& Value) { Write<TSoftObjectPtr<UFortItemDefinition>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CustomItemTexture(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CustomItemTextureMobile(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bIsDoubleWidth(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FEventScreenTrackData
{
public:
    FLinearColor TrackColorPrimary() const { return Read<FLinearColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor TrackColorSecondary() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FLinearColor TrackColorTertiary() const { return Read<FLinearColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_TrackColorPrimary(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_TrackColorSecondary(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_TrackColorTertiary(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
struct FEventScreenMoreInfoGroup
{
public:
    FText Header() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText Body() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject> Icon() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Header(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Body(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_Icon(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x30
struct FEventScreenCMSMoreInfoGroup
{
public:
    FText Header() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText Body() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FString IconURL() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_Header(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Body(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_IconURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FEventScreenCMSResourceGroupOverride
{
public:
    int32_t ResourceValue() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FString KeyArtOverrideURL() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_ResourceValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_KeyArtOverrideURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x200
struct FEventScreenCMSData
{
public:
    FString EventCMSId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FText EventName() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText EventDescription() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)
    FText ResourceHeader() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    FText StarterHeader() const { return Read<FText>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: TextProperty)
    FText CompletionHeader() const { return Read<FText>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: TextProperty)
    FText EventCTA() const { return Read<FText>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: TextProperty)
    FText EventCTACompleted() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    FText HeaderCTA() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    FText ItemShopCallout() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FString CTAIconURL() const { return Read<FString>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StrProperty)
    FString KeyArtURL() const { return Read<FString>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: StrProperty)
    FText MoreInfoHeader() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText MoreInfoSubHeader() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    FString MoreInfoKeyArtURL() const { return Read<FString>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StrProperty)
    FText MoreInfoLegal() const { return Read<FText>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: TextProperty)
    TArray<FEventScreenCMSMoreInfoGroup> MoreInfoGroups() const { return Read<TArray<FEventScreenCMSMoreInfoGroup>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    FText PurchaseLegal() const { return Read<FText>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: TextProperty)
    FText RewardTrackLegal() const { return Read<FText>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: TextProperty)
    FString ItemShopOfferId() const { return Read<FString>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: StrProperty)
    FText PremiumUpsellUnownedHeader() const { return Read<FText>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: TextProperty)
    FText PremiumUpsellUnownedBody() const { return Read<FText>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: TextProperty)
    FText PremiumUpsellOwnedHeader() const { return Read<FText>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: TextProperty)
    FText PremiumUpsellOwnedBody() const { return Read<FText>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: TextProperty)
    FString PremiumUpsellIconURL() const { return Read<FString>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: StrProperty)
    FText PurchasePremiumTrackHeader() const { return Read<FText>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: TextProperty)
    TArray<FText> PurchasePremiumTrackBodyList() const { return Read<TArray<FText>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    FText InspectSpecialItemUnowned() const { return Read<FText>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    FText InspectSpecialItemOwned() const { return Read<FText>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    FText InspectSpecialPremiumItemUnowned() const { return Read<FText>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    FText InspectSpecialPremiumItemOwned() const { return Read<FText>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: TextProperty)
    TArray<FEventScreenCMSResourceGroupOverride> ResourceGroupOverrides() const { return Read<TArray<FEventScreenCMSResourceGroupOverride>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: ArrayProperty)

    void SET_EventCMSId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_EventName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_EventDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
    void SET_ResourceHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_StarterHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: TextProperty)
    void SET_CompletionHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: TextProperty)
    void SET_EventCTA(const FText& Value) { Write<FText>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: TextProperty)
    void SET_EventCTACompleted(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_HeaderCTA(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_ItemShopCallout(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_CTAIconURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StrProperty)
    void SET_KeyArtURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: StrProperty)
    void SET_MoreInfoHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_MoreInfoSubHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_MoreInfoKeyArtURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StrProperty)
    void SET_MoreInfoLegal(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: TextProperty)
    void SET_MoreInfoGroups(const TArray<FEventScreenCMSMoreInfoGroup>& Value) { Write<TArray<FEventScreenCMSMoreInfoGroup>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_PurchaseLegal(const FText& Value) { Write<FText>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: TextProperty)
    void SET_RewardTrackLegal(const FText& Value) { Write<FText>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: TextProperty)
    void SET_ItemShopOfferId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: StrProperty)
    void SET_PremiumUpsellUnownedHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: TextProperty)
    void SET_PremiumUpsellUnownedBody(const FText& Value) { Write<FText>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: TextProperty)
    void SET_PremiumUpsellOwnedHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: TextProperty)
    void SET_PremiumUpsellOwnedBody(const FText& Value) { Write<FText>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: TextProperty)
    void SET_PremiumUpsellIconURL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: StrProperty)
    void SET_PurchasePremiumTrackHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: TextProperty)
    void SET_PurchasePremiumTrackBodyList(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    void SET_InspectSpecialItemUnowned(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    void SET_InspectSpecialItemOwned(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    void SET_InspectSpecialPremiumItemUnowned(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    void SET_InspectSpecialPremiumItemOwned(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: TextProperty)
    void SET_ResourceGroupOverrides(const TArray<FEventScreenCMSResourceGroupOverride>& Value) { Write<TArray<FEventScreenCMSResourceGroupOverride>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FEventScreenCMSGroup
{
public:
    TMap<FString, FEventScreenCMSData> EventScreens() const { return Read<TMap<FString, FEventScreenCMSData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_EventScreens(const TMap<FString, FEventScreenCMSData>& Value) { Write<TMap<FString, FEventScreenCMSData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

