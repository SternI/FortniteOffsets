/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaLocalizedOverlays
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "MediaAssets.h"

// Size: 0x90
class UEpicMediaDownloadLocalizedOverlays : public ULocalizedOverlays
{
public:
    UMediaPlayer* MediaPlayer() const { return Read<UMediaPlayer*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_MediaPlayer(const UMediaPlayer*& Value) { Write<UMediaPlayer*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

