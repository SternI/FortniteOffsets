/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomControlsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteAI.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "EnhancedInput.h"
#include "Engine.h"
#include "PlayspaceSystem.h"
#include "CoreUObject.h"
#include "TargetingSystem.h"

// Size: 0x40
class UCustomControlInputBindings_Base : public UObject
{
public:
    TWeakObjectPtr<UFortControllerComponent_CustomControls*> OwnerCustomControlsComponent() const { return Read<TWeakObjectPtr<UFortControllerComponent_CustomControls*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> OwnerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> OwnerPawn() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)

    void SET_OwnerCustomControlsComponent(const TWeakObjectPtr<UFortControllerComponent_CustomControls*>& Value) { Write<TWeakObjectPtr<UFortControllerComponent_CustomControls*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OwnerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OwnerPawn(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x70
class UCustomControlInputBindings_EnhancedInput : public UCustomControlInputBindings_Base
{
public:
    TWeakObjectPtr<UFortEnhancedInputComponent*> OwnerInputComponent() const { return Read<TWeakObjectPtr<UFortEnhancedInputComponent*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    float Priority() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    UFortInputMappingContext* InputMapping() const { return Read<UFortInputMappingContext*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    FModifyContextOptions Options() const { return Read<FModifyContextOptions>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: StructProperty)

    void SET_OwnerInputComponent(const TWeakObjectPtr<UFortEnhancedInputComponent*>& Value) { Write<TWeakObjectPtr<UFortEnhancedInputComponent*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Priority(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_InputMapping(const UFortInputMappingContext*& Value) { Write<UFortInputMappingContext*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_Options(const FModifyContextOptions& Value) { Write<FModifyContextOptions>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: StructProperty)
};

// Size: 0x48
class UCustomControlInputBindings_InputComponent : public UCustomControlInputBindings_Base
{
public:
    UInputComponent* InputComponent() const { return Read<UInputComponent*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_InputComponent(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x90
class UCustomControlInputBindings_SideScroller : public UCustomControlInputBindings_InputComponent
{
public:
    float AnalogInputDeadZone() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_AnalogInputDeadZone(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe0
class UCustomControlInputBindings_SideScrollerManual : public UCustomControlInputBindings_SideScroller
{
public:
    float AimOrbitalDistance() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float TouchDirectionClamping() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)

    void SET_AimOrbitalDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_TouchDirectionClamping(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb8
class UCustomControlInputBindings_SideScrollerMovement : public UCustomControlInputBindings_SideScroller
{
public:
    float AimOrbitalDistance() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)

    void SET_AimOrbitalDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf0
class UCustomControlInputBindings_Skydiving : public UCustomControlInputBindings_EnhancedInput
{
public:
    UInputAction* SkydivingDownInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    UInputAction* SkydivingUpInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    FName MappingNameSkydivingDown() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FText DisplayNameSkydivingDown() const { return Read<FText>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: TextProperty)
    FName MappingNameSkydivingUp() const { return Read<FName>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: NameProperty)
    FText DisplayNameSkydivingUp() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)
    float RotateStickThreshold() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer InSkydiveVolumeTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x20, Type: StructProperty)

    void SET_SkydivingDownInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_SkydivingUpInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_MappingNameSkydivingDown(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_DisplayNameSkydivingDown(const FText& Value) { Write<FText>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: TextProperty)
    void SET_MappingNameSkydivingUp(const FName& Value) { Write<FName>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: NameProperty)
    void SET_DisplayNameSkydivingUp(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
    void SET_RotateStickThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_InSkydiveVolumeTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x20, Type: StructProperty)
};

// Size: 0xf0
class UCustomControlInputBindings_TwinStickDial : public UCustomControlInputBindings_TwinStick
{
public:
    UInputAction* MouseAimAtInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_MouseAimAtInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd0
class UCustomControlInputBindings_TwinStick : public UCustomControlInputBindings_EnhancedInput
{
public:
    float InitialDialAimTargetOffsetScaleFactor() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float TargetingBreakOffsetGamepad() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float TargetingBreakOffsetMouse() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float DefaultAutoFireCooldown() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    UInputAction* GamepadLookAtInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    UInputAction* GamepadAimAtInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    UInputAction* MouseLookAtInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_InitialDialAimTargetOffsetScaleFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_TargetingBreakOffsetGamepad(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_TargetingBreakOffsetMouse(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultAutoFireCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_GamepadLookAtInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_GamepadAimAtInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_MouseLookAtInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa0
class UCustomControlOptions_Base : public UObject
{
public:
    UClass* MovementModeLogic() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)
    float RangedAttackStateDuration() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float MeleeAttackStateDuration() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> InputBindingsClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    FFortWeaponReticleData FortWeaponReticleData() const { return Read<FFortWeaponReticleData>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x14, Type: StructProperty)
    FInteractionPointOptions InteractionPointOptions() const { return Read<FInteractionPointOptions>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x10, Type: StructProperty)
    FInteractSelectionData_TargetingPreset InteractionTargetingPreset() const { return Read<FInteractSelectionData_TargetingPreset>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: StructProperty)
    float BuildingPlacementDistanceOffset() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    bool bShouldAffectNPC() const { return Read<bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: BoolProperty)

    void SET_MovementModeLogic(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
    void SET_RangedAttackStateDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_MeleeAttackStateDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_InputBindingsClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_FortWeaponReticleData(const FFortWeaponReticleData& Value) { Write<FFortWeaponReticleData>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x14, Type: StructProperty)
    void SET_InteractionPointOptions(const FInteractionPointOptions& Value) { Write<FInteractionPointOptions>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x10, Type: StructProperty)
    void SET_InteractionTargetingPreset(const FInteractSelectionData_TargetingPreset& Value) { Write<FInteractSelectionData_TargetingPreset>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: StructProperty)
    void SET_BuildingPlacementDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_bShouldAffectNPC(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x218
class UCustomControlOptions_SideScroller : public UCustomControlOptions_Targeting
{
public:
    FFortMovementMode_CCSideScrollerCreationData MovementModeCreationData() const { return Read<FFortMovementMode_CCSideScrollerCreationData>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x48, Type: StructProperty)
    FInputOptions_SideScroller InputOptions() const { return Read<FInputOptions_SideScroller>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x6, Type: StructProperty)
    bool bIsBeanstalkGFS() const { return Read<bool>(uintptr_t(this) + 0x216); } // 0x216 (Size: 0x1, Type: BoolProperty)
    bool bIsDeviceActive() const { return Read<bool>(uintptr_t(this) + 0x217); } // 0x217 (Size: 0x1, Type: BoolProperty)

    void SET_MovementModeCreationData(const FFortMovementMode_CCSideScrollerCreationData& Value) { Write<FFortMovementMode_CCSideScrollerCreationData>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x48, Type: StructProperty)
    void SET_InputOptions(const FInputOptions_SideScroller& Value) { Write<FInputOptions_SideScroller>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x6, Type: StructProperty)
    void SET_bIsBeanstalkGFS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x216, Value); } // 0x216 (Size: 0x1, Type: BoolProperty)
    void SET_bIsDeviceActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x217, Value); } // 0x217 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c8
class UCustomControlOptions_Targeting : public UCustomControlOptions_Base
{
public:
    float AngleToClampFireHorizontal() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float AngleToClampFireVertical() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    UTargetingPreset* RangedTargetingPresetTemplate() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RetentionTargetingPresetTemplate() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RangedAimingTargetingPresetTemplate() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* MeleeTargetingPresetTemplate() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RangedTargetingPreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RetentionTargetingPreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RangedAimTargetingPreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* MeleeTargetingPreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    bool bTargetingEnabled() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    FCustomControlTargetingData RangedTargetingData() const { return Read<FCustomControlTargetingData>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x48, Type: StructProperty)
    FCustomControlTargetingData MeleeTargetingData() const { return Read<FCustomControlTargetingData>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x48, Type: StructProperty)
    FCustomControlTargetingData AimingTargetingData() const { return Read<FCustomControlTargetingData>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x48, Type: StructProperty)

    void SET_AngleToClampFireHorizontal(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_AngleToClampFireVertical(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_RangedTargetingPresetTemplate(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_RetentionTargetingPresetTemplate(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_RangedAimingTargetingPresetTemplate(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_MeleeTargetingPresetTemplate(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_RangedTargetingPreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_RetentionTargetingPreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_RangedAimTargetingPreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_MeleeTargetingPreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_bTargetingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_RangedTargetingData(const FCustomControlTargetingData& Value) { Write<FCustomControlTargetingData>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x48, Type: StructProperty)
    void SET_MeleeTargetingData(const FCustomControlTargetingData& Value) { Write<FCustomControlTargetingData>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x48, Type: StructProperty)
    void SET_AimingTargetingData(const FCustomControlTargetingData& Value) { Write<FCustomControlTargetingData>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x48, Type: StructProperty)
};

// Size: 0x470
class UCustomControlOptions_ThirdPerson : public UCustomControlOptions_Targeting
{
public:
    FFortMovementMode_CCThirdPersonCreationData MovementModeCreationData() const { return Read<FFortMovementMode_CCThirdPersonCreationData>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x38, Type: StructProperty)
    FInputOptions_ThirdPerson InputOptions() const { return Read<FInputOptions_ThirdPerson>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x1, Type: StructProperty)
    FFortAnimInput_AdjustedAim AdjustedAim() const { return Read<FFortAnimInput_AdjustedAim>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x26c, Type: StructProperty)

    void SET_MovementModeCreationData(const FFortMovementMode_CCThirdPersonCreationData& Value) { Write<FFortMovementMode_CCThirdPersonCreationData>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x38, Type: StructProperty)
    void SET_InputOptions(const FInputOptions_ThirdPerson& Value) { Write<FInputOptions_ThirdPerson>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x1, Type: StructProperty)
    void SET_AdjustedAim(const FFortAnimInput_AdjustedAim& Value) { Write<FFortAnimInput_AdjustedAim>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x26c, Type: StructProperty)
};

// Size: 0x28
class UTargetingDataHelperLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x168
class UFortAIPawnComponent_CustomControls : public UFortPawnComponent_BaseCC
{
public:
};

// Size: 0x160
class UFortPawnComponent_BaseCC : public UFortPawnComponent
{
public:
    UCustomControlOptions_Base* ActiveOptions() const { return Read<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UCustomControlOptions_Base* HighestPriorityOptions() const { return Read<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    TArray<UCustomControlOptions_Base*> OwnedOptions() const { return Read<TArray<UCustomControlOptions_Base*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)

    void SET_ActiveOptions(const UCustomControlOptions_Base*& Value) { Write<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_HighestPriorityOptions(const UCustomControlOptions_Base*& Value) { Write<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnedOptions(const TArray<UCustomControlOptions_Base*>& Value) { Write<TArray<UCustomControlOptions_Base*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x160
class UFortControllerComponent_BaseCC : public UFortControllerComponent
{
public:
    UCustomControlOptions_Base* ActiveOptions() const { return Read<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UCustomControlOptions_Base* HighestPriorityOptions() const { return Read<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    TArray<UCustomControlOptions_Base*> OwnedOptions() const { return Read<TArray<UCustomControlOptions_Base*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)

    void SET_ActiveOptions(const UCustomControlOptions_Base*& Value) { Write<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_HighestPriorityOptions(const UCustomControlOptions_Base*& Value) { Write<UCustomControlOptions_Base*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnedOptions(const TArray<UCustomControlOptions_Base*>& Value) { Write<TArray<UCustomControlOptions_Base*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x250
class UFortControllerComponent_CustomControls : public UFortControllerComponent_BaseCC
{
public:
    FCustomControlsState CurrentState() const { return Read<FCustomControlsState>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: StructProperty)
    FGameplayTagQuery BlockTagsQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x48, Type: StructProperty)
    TArray<UCustomControlInputBindings_Base*> ActiveInputBindings() const { return Read<TArray<UCustomControlInputBindings_Base*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UInteractSelection_Base*> InteractSelectionPtr() const { return Read<TWeakObjectPtr<UInteractSelection_Base*>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CurrentState(const FCustomControlsState& Value) { Write<FCustomControlsState>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: StructProperty)
    void SET_BlockTagsQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x48, Type: StructProperty)
    void SET_ActiveInputBindings(const TArray<UCustomControlInputBindings_Base*>& Value) { Write<TArray<UCustomControlInputBindings_Base*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    void SET_InteractSelectionPtr(const TWeakObjectPtr<UInteractSelection_Base*>& Value) { Write<TWeakObjectPtr<UInteractSelection_Base*>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x58
class UFortMovementMode_BaseCCRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

// Size: 0x218
class UFortMovementMode_BaseCCLogic : public UFortMovementMode_BaseExtLogic
{
public:
    TWeakObjectPtr<AController*> OwnerController() const { return Read<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> FortPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortAIController*> FortAIController() const { return Read<TWeakObjectPtr<AFortAIController*>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x8, Type: WeakObjectProperty)

    void SET_OwnerController(const TWeakObjectPtr<AController*>& Value) { Write<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FortPlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FortAIController(const TWeakObjectPtr<AFortAIController*>& Value) { Write<TWeakObjectPtr<AFortAIController*>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x60
class UFortMovementMode_CCLockOnRuntimeData : public UFortMovementMode_BaseCCRuntimeData
{
public:
};

// Size: 0x218
class UFortMovementMode_CCLockOnLogic : public UFortMovementMode_BaseCCLogic
{
public:
};

// Size: 0x90
class UFortMovementMode_CCSideScrollerRuntimeData : public UFortMovementMode_CCLockOnRuntimeData
{
public:
    float DesiredRotationYaw() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)

    void SET_DesiredRotationYaw(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2c8
class UFortMovementMode_CCSideScrollerLogic : public UFortMovementMode_CCLockOnLogic
{
public:
};

// Size: 0x98
class UFortMovementMode_CCThirdPersonRuntimeData : public UFortMovementMode_CCLockOnRuntimeData
{
public:
};

// Size: 0x218
class UFortMovementMode_CCThirdPersonLogic : public UFortMovementMode_CCLockOnLogic
{
public:
};

// Size: 0xb0
class UFortMovementMode_CCThirdPersonFixedRuntimeData : public UFortMovementMode_CCThirdPersonRuntimeData
{
public:
};

// Size: 0x218
class UFortMovementMode_CCThirdPersonFixedLogic : public UFortMovementMode_CCThirdPersonLogic
{
public:
};

// Size: 0xb8
class UFortMovementMode_CCThirdPersonTwinStickRuntimeData : public UFortMovementMode_CCThirdPersonRuntimeData
{
public:
};

// Size: 0x218
class UFortMovementMode_CCThirdPersonTwinStickLogic : public UFortMovementMode_CCThirdPersonLogic
{
public:
};

// Size: 0x30
class UTargetingFilterCCFOV : public USimpleTargetingFilterTask
{
public:
    float FliedOfView() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bRequireLineOfSight() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_FliedOfView(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_bRequireLineOfSight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UTargetingFilter_CC_Base : public USimpleTargetingFilterTask
{
public:
    FCustomControlTargetingData TargetingData() const { return Read<FCustomControlTargetingData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)

    void SET_TargetingData(const FCustomControlTargetingData& Value) { Write<FCustomControlTargetingData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
};

// Size: 0x38
class UTargetingSelectionCCIdleInteract : public UTargetingSelectionCCRange
{
public:
};

// Size: 0x38
class UTargetingSelectionCCRange : public USimpleTargetingSelectionTask
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float ForwardOffset() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float VerticalOffset() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_ForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UTargetingSelection_CC_Base : public USimpleTargetingSelectionTask
{
public:
    FCustomControlTargetingData TargetingData() const { return Read<FCustomControlTargetingData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)

    void SET_TargetingData(const FCustomControlTargetingData& Value) { Write<FCustomControlTargetingData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
};

// Size: 0x80
class UTargetingSort_CC_Base : public USimpleTargetingSortTask
{
public:
    FCustomControlTargetingData TargetingData() const { return Read<FCustomControlTargetingData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x48, Type: StructProperty)

    void SET_TargetingData(const FCustomControlTargetingData& Value) { Write<FCustomControlTargetingData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x48, Type: StructProperty)
};

// Size: 0x28
class UTargetingTask_CC_DataHolder : public UInterface
{
public:
};

// Size: 0x80
class UCustomControlInputBindings_ThirdPersonSprint : public UCustomControlInputBindings_InputComponent
{
public:
    float AnalogInputDeadZone() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float RotateStickThreshold() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float CameraRotationThreshold() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float InputRateIfCameraRotationThreshold() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)

    void SET_AnalogInputDeadZone(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_RotateStickThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_CameraRotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_InputRateIfCameraRotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FInteractionPointOptions
{
public:
    uint8_t InteractionOrigin() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float InteractDistance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float InteractHighlightDistance() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float InteractExtentRadius() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_InteractionOrigin(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_InteractDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_InteractHighlightDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_InteractExtentRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x6
struct FInputOptions_SideScroller
{
public:
    bool bConstraintMovement() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bShootingLocomotionLockDirection() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bAimingLocomotionLockDirection() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t AimControls() const { return Read<uint8_t>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t SideScrollerJump() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t SideScrollerCrouch() const { return Read<uint8_t>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: EnumProperty)

    void SET_bConstraintMovement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bShootingLocomotionLockDirection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bAimingLocomotionLockDirection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_AimControls(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: EnumProperty)
    void SET_SideScrollerJump(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_SideScrollerCrouch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1
struct FInputOptions_ThirdPerson
{
public:
    bool bAutoFire() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bAutoFire(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FCustomControlsState
{
public:
    bool bHasFocusTarget() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t AttackType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t TargetingType() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t WeaponType() const { return Read<uint8_t>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: EnumProperty)

    void SET_bHasFocusTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_AttackType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_TargetingType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_WeaponType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x24
struct FCustomControlWeightingTargetingData
{
public:
    float PlayerWeight() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float CreatureWeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float VehicleWeight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float DestructiblesWeight() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float AngleWeight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bAngleWeightScaling() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    float DistanceWeight() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bDistanceWeightScaling() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    float RetainedTargetWeight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_PlayerWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_CreatureWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_DestructiblesWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_AngleWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_bAngleWeightScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_DistanceWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bDistanceWeightScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_RetainedTargetWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FCustomControlCommonTargetingData
{
public:
    FCustomControlWeightingTargetingData WeightingData() const { return Read<FCustomControlWeightingTargetingData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x24, Type: StructProperty)
    AActor* DeviceTest() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_WeightingData(const FCustomControlWeightingTargetingData& Value) { Write<FCustomControlWeightingTargetingData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x24, Type: StructProperty)
    void SET_DeviceTest(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x14
struct FCustomControlStateDependentTargetingData
{
public:
    float Distance() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Angle() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bUseAngleWhileMoving() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float AngleWhileMoving() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bRequireLineOfSight() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Angle(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bUseAngleWhileMoving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_AngleWhileMoving(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bRequireLineOfSight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
struct FCustomControlTargetingData
{
public:
    FCustomControlCommonTargetingData CommonTargetingData() const { return Read<FCustomControlCommonTargetingData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    FCustomControlStateDependentTargetingData StateDependentTargetingData() const { return Read<FCustomControlStateDependentTargetingData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x14, Type: StructProperty)

    void SET_CommonTargetingData(const FCustomControlCommonTargetingData& Value) { Write<FCustomControlCommonTargetingData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_StateDependentTargetingData(const FCustomControlStateDependentTargetingData& Value) { Write<FCustomControlStateDependentTargetingData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x14, Type: StructProperty)
};

// Size: 0x48
struct FFortMovementMode_CCSideScrollerCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
    bool bConstraintMovement() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float ForwardRotationYaw() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector DeviceForwardVector() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    float SpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenShooting() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenAiming() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t LockOnMode() const { return Read<uint8_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: EnumProperty)
    float NPCDistanceToFaceTarget() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_bConstraintMovement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_ForwardRotationYaw(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_DeviceForwardVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_SpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedMultiplierWhenShooting(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedMultiplierWhenAiming(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_LockOnMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: EnumProperty)
    void SET_NPCDistanceToFaceTarget(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FFortMovementMode_CCThirdPersonCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
    float SpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenShooting() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenAiming() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float RotationRateMultiplier() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float RotationRateWhenShootingMultiplier() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float RotationRateWhenAimingMultiplier() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t LockOnMode() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    float FixedFacingYaw() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float TacticalSprintRotationRateYaw() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float SkydivingRotationRatePitch() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_SpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedMultiplierWhenShooting(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedMultiplierWhenAiming(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_RotationRateMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_RotationRateWhenShootingMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_RotationRateWhenAimingMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_LockOnMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_FixedFacingYaw(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_TacticalSprintRotationRateYaw(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_SkydivingRotationRatePitch(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

