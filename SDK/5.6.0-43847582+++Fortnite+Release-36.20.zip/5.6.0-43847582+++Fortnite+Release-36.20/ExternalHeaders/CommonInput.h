/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonInput
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "EnhancedInput.h"
#include "CoreUObject.h"
#include "InputCore.h"
#include "DeveloperSettings.h"
#include "SlateCore.h"

// Size: 0x40
class UCommonInputActionDomain : public UDataAsset
{
public:
    bool bUseActionDomainDesiredInputConfig() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t InputMode() const { return Read<uint8_t>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseCaptureMode() const { return Read<uint8_t>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: EnumProperty)

    void SET_bUseActionDomainDesiredInputConfig(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_InputMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: EnumProperty)
    void SET_MouseCaptureMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: EnumProperty)
};

// Size: 0x48
class UCommonInputActionDomainTable : public UDataAsset
{
public:
    TArray<UCommonInputActionDomain*> ActionDomains() const { return Read<TArray<UCommonInputActionDomain*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t InputMode() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseCaptureMode() const { return Read<uint8_t>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: EnumProperty)
    bool bHideCursorDuringViewportCapture() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)

    void SET_ActionDomains(const TArray<UCommonInputActionDomain*>& Value) { Write<TArray<UCommonInputActionDomain*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_InputMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_MouseCaptureMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: EnumProperty)
    void SET_bHideCursorDuringViewportCapture(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UCommonUIInputData : public UObject
{
public:
    FDataTableRowHandle DefaultClickAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle DefaultBackAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    UInputAction* EnhancedInputClickAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    UInputAction* EnhancedInputBackAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultClickAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_DefaultBackAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_EnhancedInputClickAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_EnhancedInputBackAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UCommonUIHoldData : public UObject
{
public:
    FInputHoldData KeyboardAndMouse() const { return Read<FInputHoldData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)
    FInputHoldData Gamepad() const { return Read<FInputHoldData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: StructProperty)
    FInputHoldData Touch() const { return Read<FInputHoldData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: StructProperty)

    void SET_KeyboardAndMouse(const FInputHoldData& Value) { Write<FInputHoldData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
    void SET_Gamepad(const FInputHoldData& Value) { Write<FInputHoldData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: StructProperty)
    void SET_Touch(const FInputHoldData& Value) { Write<FInputHoldData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: StructProperty)
};

// Size: 0xd0
class UCommonInputBaseControllerData : public UObject
{
public:
    uint8_t InputType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FName GamepadName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    FText GamepadDisplayName() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    FText GamepadCategory() const { return Read<FText>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: TextProperty)
    FText GamepadPlatformName() const { return Read<FText>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: TextProperty)
    TArray<FInputDeviceIdentifierPair> GamepadHardwareIdMapping() const { return Read<TArray<FInputDeviceIdentifierPair>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UTexture2D> ControllerTexture() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FCommonInputKeyBrushConfiguration> InputBrushDataMap() const { return Read<TArray<FCommonInputKeyBrushConfiguration>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCommonInputKeySetBrushConfiguration> InputBrushKeySets() const { return Read<TArray<FCommonInputKeySetBrushConfiguration>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)

    void SET_InputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_GamepadName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_GamepadDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_GamepadCategory(const FText& Value) { Write<FText>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: TextProperty)
    void SET_GamepadPlatformName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: TextProperty)
    void SET_GamepadHardwareIdMapping(const TArray<FInputDeviceIdentifierPair>& Value) { Write<TArray<FInputDeviceIdentifierPair>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_ControllerTexture(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ControllerButtonMaskTexture(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    void SET_InputBrushDataMap(const TArray<FCommonInputKeyBrushConfiguration>& Value) { Write<TArray<FCommonInputKeyBrushConfiguration>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_InputBrushKeySets(const TArray<FCommonInputKeySetBrushConfiguration>& Value) { Write<TArray<FCommonInputKeySetBrushConfiguration>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
class UCommonInputPlatformSettings : public UPlatformSettings
{
public:
    uint8_t DefaultInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    bool bSupportsMouseAndKeyboard() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bSupportsTouch() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)
    bool bSupportsGamepad() const { return Read<bool>(uintptr_t(this) + 0x43); } // 0x43 (Size: 0x1, Type: BoolProperty)
    FName DefaultGamepadName() const { return Read<FName>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: NameProperty)
    bool bCanChangeGamepadType() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    TArray<TSoftClassPtr> ControllerData() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ControllerDataClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)

    void SET_DefaultInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_bSupportsMouseAndKeyboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_bSupportsTouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
    void SET_bSupportsGamepad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43, Value); } // 0x43 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultGamepadName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: NameProperty)
    void SET_bCanChangeGamepadType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_ControllerData(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_ControllerDataClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x158
class UCommonInputSettings : public UDeveloperSettings
{
public:
    FPerPlatformSettings PlatformInput() const { return Read<FPerPlatformSettings>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    TMap<FName, FCommonInputPlatformBaseData> CommonInputPlatformData() const { return Read<TMap<FName, FCommonInputPlatformBaseData>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: MapProperty)
    bool bEnableInputMethodThrashingProtection() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    int32_t InputMethodThrashingLimit() const { return Read<int32_t>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: IntProperty)
    double InputMethodThrashingWindowInSeconds() const { return Read<double>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: DoubleProperty)
    double InputMethodThrashingCooldownInSeconds() const { return Read<double>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: DoubleProperty)
    bool bAllowOutOfFocusDeviceInput() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bEnableDefaultInputConfig() const { return Read<bool>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: BoolProperty)
    bool bEnableEnhancedInputSupport() const { return Read<bool>(uintptr_t(this) + 0xca); } // 0xca (Size: 0x1, Type: BoolProperty)
    bool bEnableAutomaticGamepadTypeDetection() const { return Read<bool>(uintptr_t(this) + 0xcb); } // 0xcb (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UCommonInputActionDomainTable> ActionDomainTable() const { return Read<TSoftObjectPtr<UCommonInputActionDomainTable>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FName, FName> PlatformNameUpgrades() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    UClass* InputDataClass() const { return Read<UClass*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ClassProperty)
    UCommonInputActionDomainTable* ActionDomainTablePtr() const { return Read<UCommonInputActionDomainTable*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)

    void SET_PlatformInput(const FPerPlatformSettings& Value) { Write<FPerPlatformSettings>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_CommonInputPlatformData(const TMap<FName, FCommonInputPlatformBaseData>& Value) { Write<TMap<FName, FCommonInputPlatformBaseData>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: MapProperty)
    void SET_bEnableInputMethodThrashingProtection(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    void SET_InputMethodThrashingLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: IntProperty)
    void SET_InputMethodThrashingWindowInSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: DoubleProperty)
    void SET_InputMethodThrashingCooldownInSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: DoubleProperty)
    void SET_bAllowOutOfFocusDeviceInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDefaultInputConfig(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableEnhancedInputSupport(const bool& Value) { Write<bool>(uintptr_t(this) + 0xca, Value); } // 0xca (Size: 0x1, Type: BoolProperty)
    void SET_bEnableAutomaticGamepadTypeDetection(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcb, Value); } // 0xcb (Size: 0x1, Type: BoolProperty)
    void SET_ActionDomainTable(const TSoftObjectPtr<UCommonInputActionDomainTable>& Value) { Write<TSoftObjectPtr<UCommonInputActionDomainTable>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PlatformNameUpgrades(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_InputDataClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ClassProperty)
    void SET_ActionDomainTablePtr(const UCommonInputActionDomainTable*& Value) { Write<UCommonInputActionDomainTable*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x100
class UCommonInputSubsystem : public ULocalPlayerSubsystem
{
public:
    int32_t NumberOfInputMethodChangesRecently() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    double LastInputMethodChangeTime() const { return Read<double>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    double LastTimeInputMethodThrashingBegan() const { return Read<double>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: DoubleProperty)
    uint8_t RawInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t CurrentInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: EnumProperty)
    FName GamepadInputType() const { return Read<FName>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: NameProperty)
    TMap<FName, ECommonInputType> CurrentInputLocks() const { return Read<TMap<FName, ECommonInputType>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x50, Type: MapProperty)
    UCommonInputActionDomainTable* ActionDomainTable() const { return Read<UCommonInputActionDomainTable*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    bool bIsGamepadSimulatedClick() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)

    void SET_NumberOfInputMethodChangesRecently(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_LastInputMethodChangeTime(const double& Value) { Write<double>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    void SET_LastTimeInputMethodThrashingBegan(const double& Value) { Write<double>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: DoubleProperty)
    void SET_RawInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
    void SET_CurrentInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: EnumProperty)
    void SET_GamepadInputType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: NameProperty)
    void SET_CurrentInputLocks(const TMap<FName, ECommonInputType>& Value) { Write<TMap<FName, ECommonInputType>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x50, Type: MapProperty)
    void SET_ActionDomainTable(const UCommonInputActionDomainTable*& Value) { Write<UCommonInputActionDomainTable*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsGamepadSimulatedClick(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
struct FCommonInputKeyBrushConfiguration
{
public:
    FKey Key() const { return Read<FKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FSlateBrush KeyBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xb0, Type: StructProperty)

    void SET_Key(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_KeyBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xb0, Type: StructProperty)
};

// Size: 0xc0
struct FCommonInputKeySetBrushConfiguration
{
public:
    TArray<FKey> Keys() const { return Read<TArray<FKey>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FSlateBrush KeyBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xb0, Type: StructProperty)

    void SET_Keys(const TArray<FKey>& Value) { Write<TArray<FKey>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_KeyBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x18
struct FInputDeviceIdentifierPair
{
public:
    FName InputDeviceName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FString HardwareDeviceIdentifier() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_InputDeviceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_HardwareDeviceIdentifier(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FInputHoldData
{
public:
    float HoldTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float HoldRollbackTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_HoldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_HoldRollbackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FCommonInputPlatformBaseData
{
public:
    uint8_t DefaultInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bSupportsMouseAndKeyboard() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bSupportsGamepad() const { return Read<bool>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x1, Type: BoolProperty)
    FName DefaultGamepadName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    bool bCanChangeGamepadType() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bSupportsTouch() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    TArray<TSoftClassPtr> ControllerData() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ControllerDataClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_DefaultInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_bSupportsMouseAndKeyboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_bSupportsGamepad(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x1, Type: BoolProperty)
    void SET_DefaultGamepadName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_bCanChangeGamepadType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bSupportsTouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_ControllerData(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_ControllerDataClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

