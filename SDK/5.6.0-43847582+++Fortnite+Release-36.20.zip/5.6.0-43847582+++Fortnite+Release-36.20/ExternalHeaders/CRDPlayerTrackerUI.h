/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDPlayerTrackerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xc0
class UCRDPlayerTrackerUIComponent : public UActorComponent
{
public:
    UCRDPlayerTrackerWidget* SpawnedWidget() const { return Read<UCRDPlayerTrackerWidget*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_SpawnedWidget(const UCRDPlayerTrackerWidget*& Value) { Write<UCRDPlayerTrackerWidget*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x370
class UCRDPlayerTrackerWidget : public UFortHUDElementWidget
{
public:
};

