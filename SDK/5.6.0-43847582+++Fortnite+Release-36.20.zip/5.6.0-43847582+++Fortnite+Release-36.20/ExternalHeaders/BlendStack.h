/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlendStack
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"

// Size: 0x28
class UBlendStackAnimNodeLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UBlendStackInputAnimNodeLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x10
struct FBlendStackAnimNodeReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FBlendStackInputAnimNodeReference : public FAnimNodeReference
{
public:
};

// Size: 0x388
struct FBlendStackAnimPlayer
{
public:
    FAnimNode_SequencePlayer_Standalone SequencePlayerNode() const { return Read<FAnimNode_SequencePlayer_Standalone>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x90, Type: StructProperty)
    FAnimNode_BlendSpacePlayer_Standalone BlendSpacePlayerNode() const { return Read<FAnimNode_BlendSpacePlayer_Standalone>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x90, Type: StructProperty)
    FAnimNode_Mirror_Standalone MirrorNode() const { return Read<FAnimNode_Mirror_Standalone>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x60, Type: StructProperty)

    void SET_SequencePlayerNode(const FAnimNode_SequencePlayer_Standalone& Value) { Write<FAnimNode_SequencePlayer_Standalone>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x90, Type: StructProperty)
    void SET_BlendSpacePlayerNode(const FAnimNode_BlendSpacePlayer_Standalone& Value) { Write<FAnimNode_BlendSpacePlayer_Standalone>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x90, Type: StructProperty)
    void SET_MirrorNode(const FAnimNode_Mirror_Standalone& Value) { Write<FAnimNode_Mirror_Standalone>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x60, Type: StructProperty)
};

// Size: 0xc0
struct FAnimNode_BlendStack_Standalone : public FAnimNode_AssetPlayerBase
{
public:
    TArray<FPoseLink> PerSampleGraphPoseLinks() const { return Read<TArray<FPoseLink>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FBlendStackAnimPlayer> AnimPlayers() const { return Read<TArray<FBlendStackAnimPlayer>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    bool bShouldFilterNotifies() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    UObject* StitchDatabase() const { return Read<UObject*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    float StitchBlendTime() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float StitchBlendMaxCost() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxActiveBlends() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStoreBlendedPose() const { return Read<bool>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x1, Type: BoolProperty)
    float NotifyRecencyTimeOut() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    float MaxBlendInTimeToOverrideAnimation() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    float PlayerDepthBlendInTimeMultiplier() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)

    void SET_PerSampleGraphPoseLinks(const TArray<FPoseLink>& Value) { Write<TArray<FPoseLink>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_AnimPlayers(const TArray<FBlendStackAnimPlayer>& Value) { Write<TArray<FBlendStackAnimPlayer>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_bShouldFilterNotifies(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_StitchDatabase(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_StitchBlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_StitchBlendMaxCost(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveBlends(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_bStoreBlendedPose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x1, Type: BoolProperty)
    void SET_NotifyRecencyTimeOut(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxBlendInTimeToOverrideAnimation(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_PlayerDepthBlendInTimeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x138
struct FAnimNode_BlendStack : public FAnimNode_BlendStack_Standalone
{
public:
    UAnimationAsset* AnimationAsset() const { return Read<UAnimationAsset*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    float AnimationTime() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ActivationDelayTime() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bLoop() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bMirrored() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    float WantedPlayRate() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    float MaxAnimationDeltaTime() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    UBlendProfile* BlendProfile() const { return Read<UBlendProfile*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    uint8_t BlendOption() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t BlendspaceUpdateMode() const { return Read<uint8_t>(uintptr_t(this) + 0xe9); } // 0xe9 (Size: 0x1, Type: EnumProperty)
    FVector BlendParameters() const { return Read<FVector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    UMirrorDataTable* MirrorDataTable() const { return Read<UMirrorDataTable*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    float BlendParametersDeltaThreshold() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    bool bUseInertialBlend() const { return Read<bool>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x1, Type: BoolProperty)
    FName InertialBlendNodeTag() const { return Read<FName>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: NameProperty)
    bool bResetOnBecomingRelevant() const { return Read<bool>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x1, Type: BoolProperty)

    void SET_AnimationAsset(const UAnimationAsset*& Value) { Write<UAnimationAsset*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimationTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_ActivationDelayTime(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_bLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_bMirrored(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    void SET_WantedPlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAnimationDeltaTime(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_BlendProfile(const UBlendProfile*& Value) { Write<UBlendProfile*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendOption(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    void SET_BlendspaceUpdateMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe9, Value); } // 0xe9 (Size: 0x1, Type: EnumProperty)
    void SET_BlendParameters(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_MirrorDataTable(const UMirrorDataTable*& Value) { Write<UMirrorDataTable*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendParametersDeltaThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_bUseInertialBlend(const bool& Value) { Write<bool>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x1, Type: BoolProperty)
    void SET_InertialBlendNodeTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: NameProperty)
    void SET_bResetOnBecomingRelevant(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FAnimNode_BlendStackInput : public FAnimNode_Base
{
public:
    int32_t SampleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t BlendStackAllocationIndex() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    bool bOverridePlayRate() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_SampleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_BlendStackAllocationIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_bOverridePlayRate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

