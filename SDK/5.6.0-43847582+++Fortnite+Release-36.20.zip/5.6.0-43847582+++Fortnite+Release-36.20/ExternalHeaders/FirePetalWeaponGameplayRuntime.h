/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalWeaponGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x530
class UFlavorFirePetalSMGAnimInstance : public UFortWeaponAnimInstance
{
public:
    double CurrentRotation() const { return Read<double>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: DoubleProperty)
    double ScaleDupeMag() const { return Read<double>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: DoubleProperty)
    double ScaleMag() const { return Read<double>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: DoubleProperty)
    double RotationAmount() const { return Read<double>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: DoubleProperty)
    FRotator CurrentRotator() const { return Read<FRotator>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x18, Type: StructProperty)
    bool bIsCrouchWalking() const { return Read<bool>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x1, Type: BoolProperty)

    void SET_CurrentRotation(const double& Value) { Write<double>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: DoubleProperty)
    void SET_ScaleDupeMag(const double& Value) { Write<double>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: DoubleProperty)
    void SET_ScaleMag(const double& Value) { Write<double>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: DoubleProperty)
    void SET_RotationAmount(const double& Value) { Write<double>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x18, Type: StructProperty)
    void SET_bIsCrouchWalking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x1, Type: BoolProperty)
};

