/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityCategoryTilePanelBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "UMG.h"

// Size: 0x3c0
class UActivityCategoryTilePanelBase_C : public UFortActivityCategoryTilePanel
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VerticalBox_Content() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ActiveInactivate() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnMoveUpOutOfView() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    double EntryHeight() const { return Read<double>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    double EntryWidth() const { return Read<double>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
    void SET_VerticalBox_Content(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveInactivate(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnMoveUpOutOfView(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    void SET_EntryWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: DoubleProperty)
};

