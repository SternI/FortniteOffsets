/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioShapes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x280
class UAudioShapeBoxComponent : public UAudioShapePrimitiveComponent
{
public:
    FTransform BoxTransform() const { return Read<FTransform>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x60, Type: StructProperty)

    void SET_BoxTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x60, Type: StructProperty)
};

// Size: 0x220
class UAudioShapePrimitiveComponent : public UAudioShapeComponent
{
public:
    USoundBase* SoundOnEdge() const { return Read<USoundBase*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundOnInside() const { return Read<USoundBase*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    bool bUseOwningActorTransform() const { return Read<bool>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: BoolProperty)
    bool bAutoRefreshShape() const { return Read<bool>(uintptr_t(this) + 0x179); } // 0x179 (Size: 0x1, Type: BoolProperty)
    FVector ActorTransformScale() const { return Read<FVector>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x18, Type: StructProperty)

    void SET_SoundOnEdge(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundOnInside(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    void SET_bUseOwningActorTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoRefreshShape(const bool& Value) { Write<bool>(uintptr_t(this) + 0x179, Value); } // 0x179 (Size: 0x1, Type: BoolProperty)
    void SET_ActorTransformScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x18, Type: StructProperty)
};

// Size: 0x158
class UAudioShapeComponent : public UAudioGameplayComponent
{
public:
    float MaxDistanceOffset() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float SmoothingDistance() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float FadeInTime() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float FadeOutTime() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    TMap<FName, UAudioComponent*> AudioComponents() const { return Read<TMap<FName, UAudioComponent*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x50, Type: MapProperty)
    TArray<APlayerController*> LocalControllers() const { return Read<TArray<APlayerController*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)

    void SET_MaxDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_SmoothingDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_FadeInTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_FadeOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_AudioComponents(const TMap<FName, UAudioComponent*>& Value) { Write<TMap<FName, UAudioComponent*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x50, Type: MapProperty)
    void SET_LocalControllers(const TArray<APlayerController*>& Value) { Write<TArray<APlayerController*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x220
class UAudioShapeCylinderComponent : public UAudioShapePrimitiveComponent
{
public:
    float HalfHeight() const { return Read<float>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: FloatProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x21c); } // 0x21c (Size: 0x4, Type: FloatProperty)

    void SET_HalfHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: FloatProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x21c, Value); } // 0x21c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x250
class UAudioShapeLineComponent : public UAudioShapePrimitiveComponent
{
public:
    FVector StartPoint() const { return Read<FVector>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x18, Type: StructProperty)
    FVector Endpoint() const { return Read<FVector>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x18, Type: StructProperty)

    void SET_StartPoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x18, Type: StructProperty)
    void SET_Endpoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x18, Type: StructProperty)
};

// Size: 0x230
class UAudioShapeLineListComponent : public UAudioShapePrimitiveComponent
{
public:
    TArray<FVector> PointList() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    bool bClosedLoop() const { return Read<bool>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x1, Type: BoolProperty)

    void SET_PointList(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    void SET_bClosedLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x220
class UAudioShapeSphereComponent : public UAudioShapePrimitiveComponent
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: FloatProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2e0
class UAudioShapeSplineComponent : public UAudioShapeComponent
{
public:
    float TravelDistanceCrossfadeThreshold() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    float TravelDistanceCrossfadeTime() const { return Read<float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: FloatProperty)
    USoundBase* ClosestPointSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    FBox SplineAABB() const { return Read<FBox>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x38, Type: StructProperty)
    TArray<UAudioComponent*> FadingComponents() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x10, Type: ArrayProperty)
    USplineComponent* Spline() const { return Read<USplineComponent*>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    TArray<FSplineSegmentData> SplineSegments() const { return Read<TArray<FSplineSegmentData>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: ArrayProperty)

    void SET_TravelDistanceCrossfadeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_TravelDistanceCrossfadeTime(const float& Value) { Write<float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: FloatProperty)
    void SET_ClosestPointSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineAABB(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x38, Type: StructProperty)
    void SET_FadingComponents(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineSegments(const TArray<FSplineSegmentData>& Value) { Write<TArray<FSplineSegmentData>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UAudioShapeSubsystem : public UWorldSubsystem
{
public:
    TArray<UAudioShapeComponent*> PendingAudioShapes() const { return Read<TArray<UAudioShapeComponent*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<UAudioShapeComponent*> AudioShapes() const { return Read<TArray<UAudioShapeComponent*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<APlayerController*> LocalControllers() const { return Read<TArray<APlayerController*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_PendingAudioShapes(const TArray<UAudioShapeComponent*>& Value) { Write<TArray<UAudioShapeComponent*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_AudioShapes(const TArray<UAudioShapeComponent*>& Value) { Write<TArray<UAudioShapeComponent*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_LocalControllers(const TArray<APlayerController*>& Value) { Write<TArray<APlayerController*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FSplineSegmentData
{
public:
    FBoxSphereBounds Bounds() const { return Read<FBoxSphereBounds>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    int32_t PointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)

    void SET_Bounds(const FBoxSphereBounds& Value) { Write<FBoxSphereBounds>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
};

