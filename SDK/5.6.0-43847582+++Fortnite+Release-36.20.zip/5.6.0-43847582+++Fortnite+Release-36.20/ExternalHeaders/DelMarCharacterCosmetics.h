/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCharacterCosmetics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DelMarCore.h"
#include "FortniteGame.h"
#include "CosmeticsFrameworkLoadouts.h"
#include "CoreUObject.h"

// Size: 0xf8
class UDelMarDriverCosmeticPlayerComponent : public UPlayerStateComponent
{
public:
    TArray<FName> SequenceBindingTags() const { return Read<TArray<FName>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    FDelMarDriverCosmeticData CosmeticData() const { return Read<FDelMarDriverCosmeticData>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)

    void SET_SequenceBindingTags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_CosmeticData(const FDelMarDriverCosmeticData& Value) { Write<FDelMarDriverCosmeticData>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x48
class UDelMarCharacterCosmeticsSettings : public UPrimaryDataAsset
{
public:
    TArray<FPrimaryAssetId> RandomCharacters() const { return Read<TArray<FPrimaryAssetId>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_RandomCharacters(const TArray<FPrimaryAssetId>& Value) { Write<TArray<FPrimaryAssetId>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarDriverCosmeticData
{
public:
    UAthenaCharacterItemDefinition* CharacterDefinition() const { return Read<UAthenaCharacterItemDefinition*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FMcpVariantChannelInfo> CharacterVariantChannels() const { return Read<TArray<FMcpVariantChannelInfo>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_CharacterDefinition(const UAthenaCharacterItemDefinition*& Value) { Write<UAthenaCharacterItemDefinition*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CharacterVariantChannels(const TArray<FMcpVariantChannelInfo>& Value) { Write<TArray<FMcpVariantChannelInfo>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

