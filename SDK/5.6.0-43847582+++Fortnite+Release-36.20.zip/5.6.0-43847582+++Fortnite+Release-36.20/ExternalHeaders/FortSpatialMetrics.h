/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortSpatialMetrics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x488
class UFortSpatialMetricsActorCount : public USpatialMetricsQuantityMetric
{
public:
};

// Size: 0x488
class UFortSpatialMetricsBuildingCount : public UFortSpatialMetricsActorCount
{
public:
};

// Size: 0x488
class UFortSpatialMetricsLootContainerCount : public UFortSpatialMetricsActorCount
{
public:
};

// Size: 0x488
class UFortSpatialMetricsPickupCount : public UFortSpatialMetricsActorCount
{
public:
};

