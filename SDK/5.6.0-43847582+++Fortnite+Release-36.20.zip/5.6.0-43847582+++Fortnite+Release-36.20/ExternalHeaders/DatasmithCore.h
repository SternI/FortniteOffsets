/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DatasmithCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x28
class UDatasmithClothAssetFactory : public UObject
{
public:
};

// Size: 0x28
class UDatasmithClothComponentFactory : public UObject
{
public:
};

// Size: 0x50
class UDatasmithMesh : public UObject
{
public:
    FString MeshName() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    bool bIsCollisionMesh() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    TArray<FDatasmithMeshSourceModel> SourceModels() const { return Read<TArray<FDatasmithMeshSourceModel>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_MeshName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_bIsCollisionMesh(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_SourceModels(const TArray<FDatasmithMeshSourceModel>& Value) { Write<TArray<FDatasmithMeshSourceModel>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FDatasmithMeshSourceModel
{
public:
};

