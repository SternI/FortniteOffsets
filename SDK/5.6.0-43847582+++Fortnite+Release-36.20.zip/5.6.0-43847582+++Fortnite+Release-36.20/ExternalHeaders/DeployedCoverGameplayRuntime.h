/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeployedCoverGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ItemizedPropSpawnerParentRuntime.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28
class UDeployedCoverFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x50
struct FDeployedCoverSpawnerData
{
public:
    bool bLineTraceForSpawnRot() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAdjustAttachBase() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bDontSpawnOnPlayers() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bDontSpawnOnPhysicsSim() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    float TraceCapsuleRadius() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float TraceCapsuleHalfHeightCenter() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float TraceCapsuleHalfHeightSide() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float BuildingPropMaxHealth() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    double MinDotWithUp() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ZOffsetTolerance() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    FName VolumeBlockTag() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: ByteProperty)
    TArray<FNativeItemizedPropSpawner_PropSpawnData> SpawnData() const { return Read<TArray<FNativeItemizedPropSpawner_PropSpawnData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ClassesToBlockSpawn() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_bLineTraceForSpawnRot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bAdjustAttachBase(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bDontSpawnOnPlayers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bDontSpawnOnPhysicsSim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_TraceCapsuleRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TraceCapsuleHalfHeightCenter(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_TraceCapsuleHalfHeightSide(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_BuildingPropMaxHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MinDotWithUp(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_ZOffsetTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_VolumeBlockTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_TraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: ByteProperty)
    void SET_SpawnData(const TArray<FNativeItemizedPropSpawner_PropSpawnData>& Value) { Write<TArray<FNativeItemizedPropSpawner_PropSpawnData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ClassesToBlockSpawn(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FDeployedCoverSpawnInfo
{
public:
    bool bIsValid() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TArray<AActor*> OverlappingActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    AActor* BaseActor() const { return Read<AActor*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_bIsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_OverlappingActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_BaseActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

