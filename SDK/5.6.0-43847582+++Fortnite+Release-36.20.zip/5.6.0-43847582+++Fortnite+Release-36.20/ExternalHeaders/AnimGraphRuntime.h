/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimGraphRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "AnimationCore.h"
#include "CoreUObject.h"

// Size: 0x28
class UAnimNodeRigidBodyLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UBlendSpaceLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class USequencerAnimationOverride : public UInterface
{
public:
};

// Size: 0x28
class UAnimationStateMachineLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UAnimExecutionContextLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x40
class UAnimNotify_PlayMontageNotify : public UAnimNotify
{
public:
    FName NotifyName() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)

    void SET_NotifyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
};

// Size: 0x38
class UAnimNotify_PlayMontageNotifyWindow : public UAnimNotifyState
{
public:
    FName NotifyName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)

    void SET_NotifyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
};

// Size: 0x3e0
class UAnimSequencerInstance : public UAnimInstance
{
public:
};

// Size: 0x28
class UBlendListBaseLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UBlendSpacePlayerLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UKismetAnimationLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class ULayeredBoneBlendLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class ULinkedAnimGraphLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UMirrorAnimLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UModifyCurveAnimLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xa8
class UPlayMontageCallbackProxy : public UObject
{
public:
};

// Size: 0x28
class USequenceEvaluatorLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class USequencePlayerLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class USequencerAnimationSupport : public UInterface
{
public:
};

// Size: 0x28
class USkeletalControlLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x60
struct FAnimNode_BlendSpaceGraphBase : public FAnimNode_Base
{
public:
    float X() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FName GroupName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: ByteProperty)
    UBlendSpace* BlendSpace() const { return Read<UBlendSpace*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    TArray<FPoseLink> SamplePoseLinks() const { return Read<TArray<FPoseLink>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_GroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_GroupRole(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: ByteProperty)
    void SET_BlendSpace(const UBlendSpace*& Value) { Write<UBlendSpace*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_SamplePoseLinks(const TArray<FPoseLink>& Value) { Write<TArray<FPoseLink>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
struct FAnimNode_BlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
{
public:
};

// Size: 0x20
struct FAnimNode_BlendSpaceSampleResult : public FAnimNode_Root
{
public:
};

// Size: 0xc8
struct FAnimNode_SkeletalControlBase : public FAnimNode_Base
{
public:
    FComponentSpacePoseLink ComponentPose() const { return Read<FComponentSpacePoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    float ActualAlpha() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t AlphaInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend() const { return Read<FInputAlphaBoolBlend>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x30, Type: StructProperty)

    void SET_ComponentPose(const FComponentSpacePoseLink& Value) { Write<FComponentSpacePoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_ActualAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_bAlphaBoolEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: StructProperty)
    void SET_AlphaBoolBlend(const FInputAlphaBoolBlend& Value) { Write<FInputAlphaBoolBlend>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x48, Type: StructProperty)
    void SET_AlphaCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_AlphaScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x30, Type: StructProperty)
};

// Size: 0x128
struct FAnimNode_ModifyBone : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference BoneToModify() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FVector Translation() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FVector Scale() const { return Read<FVector>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EBoneModificationMode> TranslationMode() const { return Read<TEnumAsByte<EBoneModificationMode>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneModificationMode> RotationMode() const { return Read<TEnumAsByte<EBoneModificationMode>>(uintptr_t(this) + 0x121); } // 0x121 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneModificationMode> ScaleMode() const { return Read<TEnumAsByte<EBoneModificationMode>>(uintptr_t(this) + 0x122); } // 0x122 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> TranslationSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x123); } // 0x123 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> RotationSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> ScaleSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x125); } // 0x125 (Size: 0x1, Type: ByteProperty)

    void SET_BoneToModify(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_Translation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_TranslationMode(const TEnumAsByte<EBoneModificationMode>& Value) { Write<TEnumAsByte<EBoneModificationMode>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: ByteProperty)
    void SET_RotationMode(const TEnumAsByte<EBoneModificationMode>& Value) { Write<TEnumAsByte<EBoneModificationMode>>(uintptr_t(this) + 0x121, Value); } // 0x121 (Size: 0x1, Type: ByteProperty)
    void SET_ScaleMode(const TEnumAsByte<EBoneModificationMode>& Value) { Write<TEnumAsByte<EBoneModificationMode>>(uintptr_t(this) + 0x122, Value); } // 0x122 (Size: 0x1, Type: ByteProperty)
    void SET_TranslationSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x123, Value); } // 0x123 (Size: 0x1, Type: ByteProperty)
    void SET_RotationSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: ByteProperty)
    void SET_ScaleSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x125, Value); } // 0x125 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x10
struct FAnimNode_RefPose : public FAnimNode_Base
{
public:
};

// Size: 0x10
struct FAnimNode_MeshSpaceRefPose : public FAnimNode_Base
{
public:
};

// Size: 0x10
struct FRigidBodyAnimNodeReference : public FAnimNodeReference
{
public:
};

// Size: 0xe8
struct FAnimNode_RotationMultiplier : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0xc, Type: StructProperty)
    float Multiplier() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EBoneAxis> RotationAxisToRefer() const { return Read<TEnumAsByte<EBoneAxis>>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x1, Type: ByteProperty)
    bool bIsAdditive() const { return Read<bool>(uintptr_t(this) + 0xe5); } // 0xe5 (Size: 0x1, Type: BoolProperty)

    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0xc, Type: StructProperty)
    void SET_Multiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_RotationAxisToRefer(const TEnumAsByte<EBoneAxis>& Value) { Write<TEnumAsByte<EBoneAxis>>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x1, Type: ByteProperty)
    void SET_bIsAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe5, Value); } // 0xe5 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FBlendSpaceReference : public FAnimNodeReference
{
public:
};

// Size: 0x1a0
struct FRotationRetargetingInfo
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FTransform Source() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Target() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    uint8_t RotationComponent() const { return Read<uint8_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    FVector TwistAxis() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    bool bUseAbsoluteAngle() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    float SourceMinimum() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    float SourceMaximum() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float TargetMinimum() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float TargetMaximum() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    uint8_t EasingType() const { return Read<uint8_t>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x1, Type: EnumProperty)
    FRuntimeFloatCurve CustomCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x88, Type: StructProperty)
    bool bFlipEasing() const { return Read<bool>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: BoolProperty)
    float EasingWeight() const { return Read<float>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x4, Type: FloatProperty)
    bool bClamp() const { return Read<bool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: BoolProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Source(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Target(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_RotationComponent(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    void SET_TwistAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_bUseAbsoluteAngle(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_SourceMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_SourceMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_TargetMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_TargetMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_EasingType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x1, Type: EnumProperty)
    void SET_CustomCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x88, Type: StructProperty)
    void SET_bFlipEasing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: BoolProperty)
    void SET_EasingWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x4, Type: FloatProperty)
    void SET_bClamp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FPositionHistory
{
public:
    TArray<FVector> Positions() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    float Range() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_Positions(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Range(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FAnimationStateResultReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FAnimationStateMachineReference : public FAnimNodeReference
{
public:
};

// Size: 0x68
struct FAnimNode_BlendSpacePlayerBase : public FAnimNode_AssetPlayerBase
{
public:
    UBlendSpace* PreviousBlendSpace() const { return Read<UBlendSpace*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_PreviousBlendSpace(const UBlendSpace*& Value) { Write<UBlendSpace*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x70
struct FAnimNode_BlendSpacePlayer : public FAnimNode_BlendSpacePlayerBase
{
public:
    UBlendSpace* BlendSpace() const { return Read<UBlendSpace*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_BlendSpace(const UBlendSpace*& Value) { Write<UBlendSpace*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1c0
struct FAnimNode_AimOffsetLookAt : public FAnimNode_BlendSpacePlayer
{
public:
    FPoseLink BasePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: IntProperty)
    FName SourceSocketName() const { return Read<FName>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: NameProperty)
    FName PivotSocketName() const { return Read<FName>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: NameProperty)
    FVector LookAtLocation() const { return Read<FVector>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x18, Type: StructProperty)
    FVector SocketAxis() const { return Read<FVector>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x18, Type: StructProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x4, Type: FloatProperty)

    void SET_BasePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: StructProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: IntProperty)
    void SET_SourceSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: NameProperty)
    void SET_PivotSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: NameProperty)
    void SET_LookAtLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x18, Type: StructProperty)
    void SET_SocketAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x18, Type: StructProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc8
struct FAnimNode_ApplyAdditive : public FAnimNode_Base
{
public:
    FPoseLink base() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink Additive() const { return Read<FPoseLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x8, Type: StructProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    FInputAlphaBoolBlend AlphaBoolBlend() const { return Read<FInputAlphaBoolBlend>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x30, Type: StructProperty)
    uint8_t AlphaInputType() const { return Read<uint8_t>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled() const { return Read<bool>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: BoolProperty)

    void SET_base(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Additive(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x8, Type: StructProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_AlphaBoolBlend(const FInputAlphaBoolBlend& Value) { Write<FInputAlphaBoolBlend>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x48, Type: StructProperty)
    void SET_AlphaCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_AlphaScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x30, Type: StructProperty)
    void SET_AlphaInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: EnumProperty)
    void SET_bAlphaBoolEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c
struct FBlendBoneByChannelEntry
{
public:
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    bool bBlendTranslation() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bBlendRotation() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bBlendScale() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)

    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_bBlendTranslation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bBlendRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_bBlendScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
struct FAnimNode_BlendBoneByChannel : public FAnimNode_Base
{
public:
    FPoseLink A() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink B() const { return Read<FPoseLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    TArray<FBlendBoneByChannelEntry> BoneDefinitions() const { return Read<TArray<FBlendBoneByChannelEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> TransformsSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: ByteProperty)

    void SET_A(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_B(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_BoneDefinitions(const TArray<FBlendBoneByChannelEntry>& Value) { Write<TArray<FBlendBoneByChannelEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
    void SET_TransformsSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FAnimNode_BlendListBase : public FAnimNode_Base
{
public:
    TArray<FPoseLink> BlendPose() const { return Read<TArray<FPoseLink>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_BlendPose(const TArray<FPoseLink>& Value) { Write<TArray<FPoseLink>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FAnimNode_BlendListByBool : public FAnimNode_BlendListBase
{
public:
};

// Size: 0x50
struct FAnimNode_BlendListByEnum : public FAnimNode_BlendListBase
{
public:
};

// Size: 0x50
struct FAnimNode_BlendListByInt : public FAnimNode_BlendListBase
{
public:
};

// Size: 0x78
struct FAnimNode_BlendSpaceEvaluator : public FAnimNode_BlendSpacePlayer
{
public:
    float NormalizedTime() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    bool bTeleportToNormalizedTime() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)

    void SET_NormalizedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_bTeleportToNormalizedTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FAnimNode_BlendSpacePlayer_Standalone : public FAnimNode_BlendSpacePlayerBase
{
public:
    FName GroupName() const { return Read<FName>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x1, Type: ByteProperty)
    bool bOverridePositionWhenJoiningSyncGroupAsLeader() const { return Read<bool>(uintptr_t(this) + 0x6d); } // 0x6d (Size: 0x1, Type: BoolProperty)
    uint8_t Method() const { return Read<uint8_t>(uintptr_t(this) + 0x6e); } // 0x6e (Size: 0x1, Type: EnumProperty)
    bool bIgnoreForRelevancyTest() const { return Read<bool>(uintptr_t(this) + 0x6f); } // 0x6f (Size: 0x1, Type: BoolProperty)
    float X() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    bool bLoop() const { return Read<bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: BoolProperty)
    bool bResetPlayTimeWhenBlendSpaceChanges() const { return Read<bool>(uintptr_t(this) + 0x7d); } // 0x7d (Size: 0x1, Type: BoolProperty)
    float StartPosition() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    UBlendSpace* BlendSpace() const { return Read<UBlendSpace*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)

    void SET_GroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: NameProperty)
    void SET_GroupRole(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x1, Type: ByteProperty)
    void SET_bOverridePositionWhenJoiningSyncGroupAsLeader(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6d, Value); } // 0x6d (Size: 0x1, Type: BoolProperty)
    void SET_Method(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6e, Value); } // 0x6e (Size: 0x1, Type: EnumProperty)
    void SET_bIgnoreForRelevancyTest(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6f, Value); } // 0x6f (Size: 0x1, Type: BoolProperty)
    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_bLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: BoolProperty)
    void SET_bResetPlayTimeWhenBlendSpaceChanges(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7d, Value); } // 0x7d (Size: 0x1, Type: BoolProperty)
    void SET_StartPosition(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_BlendSpace(const UBlendSpace*& Value) { Write<UBlendSpace*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FAnimNode_CallFunction : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x150
struct FAnimNode_CopyPoseFromMesh : public FAnimNode_Base
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> SourceMeshComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    bool bUseAttachedParent() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x0) & 1; } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    bool bCopyCurves() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x1) & 1; } // 0x18:1 (Size: 0x1, Type: BoolProperty)
    bool bCopyCustomAttributes() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bUseMeshPose() const { return (Read<uint8_t>(uintptr_t(this) + 0x1a) >> 0x0) & 1; } // 0x1a:0 (Size: 0x1, Type: BoolProperty)
    FName RootBoneToCopy() const { return Read<FName>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: NameProperty)

    void SET_SourceMeshComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bUseAttachedParent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyCurves(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:1 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyCustomAttributes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_bUseMeshPose(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1a); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1a, B); } // 0x1a:0 (Size: 0x1, Type: BoolProperty)
    void SET_RootBoneToCopy(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: NameProperty)
};

// Size: 0x38
struct FAnimNode_CurveSource : public FAnimNode_Base
{
public:
    FPoseLink SourcePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FName SourceBinding() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    TScriptInterface<Class> CurveSource() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: InterfaceProperty)

    void SET_SourcePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_SourceBinding(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_CurveSource(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0xe8
struct FAnimNode_LayeredBoneBlend : public FAnimNode_Base
{
public:
    FPoseLink BasePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FPoseLink> BlendPoses() const { return Read<TArray<FPoseLink>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t BlendMode() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    TArray<UBlendProfile*> BlendMasks() const { return Read<TArray<UBlendProfile*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FInputBlendPose> LayerSetup() const { return Read<TArray<FInputBlendPose>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<float> BlendWeights() const { return Read<TArray<float>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FPerBoneBlendWeight> PerBoneBlendWeights() const { return Read<TArray<FPerBoneBlendWeight>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    FGuid SkeletonGuid() const { return Read<FGuid>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    FGuid VirtualBoneGuid() const { return Read<FGuid>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: IntProperty)
    bool bMeshSpaceRotationBlend() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bRootSpaceRotationBlend() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    bool bMeshSpaceScaleBlend() const { return Read<bool>(uintptr_t(this) + 0xe2); } // 0xe2 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ECurveBlendOption> CurveBlendOption() const { return Read<TEnumAsByte<ECurveBlendOption>>(uintptr_t(this) + 0xe3); } // 0xe3 (Size: 0x1, Type: ByteProperty)
    bool bBlendRootMotionBasedOnRootBone() const { return Read<bool>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x1, Type: BoolProperty)

    void SET_BasePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_BlendPoses(const TArray<FPoseLink>& Value) { Write<TArray<FPoseLink>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_BlendMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_BlendMasks(const TArray<UBlendProfile*>& Value) { Write<TArray<UBlendProfile*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_LayerSetup(const TArray<FInputBlendPose>& Value) { Write<TArray<FInputBlendPose>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_BlendWeights(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_PerBoneBlendWeights(const TArray<FPerBoneBlendWeight>& Value) { Write<TArray<FPerBoneBlendWeight>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletonGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_VirtualBoneGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StructProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: IntProperty)
    void SET_bMeshSpaceRotationBlend(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_bRootSpaceRotationBlend(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    void SET_bMeshSpaceScaleBlend(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe2, Value); } // 0xe2 (Size: 0x1, Type: BoolProperty)
    void SET_CurveBlendOption(const TEnumAsByte<ECurveBlendOption>& Value) { Write<TEnumAsByte<ECurveBlendOption>>(uintptr_t(this) + 0xe3, Value); } // 0xe3 (Size: 0x1, Type: ByteProperty)
    void SET_bBlendRootMotionBasedOnRootBone(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FAnimNode_MakeDynamicAdditive : public FAnimNode_Base
{
public:
    FPoseLink base() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink Additive() const { return Read<FPoseLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    bool bMeshSpaceAdditive() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_base(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Additive(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_bMeshSpaceAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
struct FAnimNode_MirrorBase : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
struct FAnimNode_Mirror : public FAnimNode_MirrorBase
{
public:
};

// Size: 0x60
struct FAnimNode_Mirror_Standalone : public FAnimNode_MirrorBase
{
public:
    bool bMirror() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    UMirrorDataTable* MirrorDataTable() const { return Read<UMirrorDataTable*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    bool bResetChild() const { return Read<bool>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: BoolProperty)
    bool bBoneMirroring() const { return Read<bool>(uintptr_t(this) + 0x5d); } // 0x5d (Size: 0x1, Type: BoolProperty)
    bool bCurveMirroring() const { return Read<bool>(uintptr_t(this) + 0x5e); } // 0x5e (Size: 0x1, Type: BoolProperty)
    bool bAttributeMirroring() const { return Read<bool>(uintptr_t(this) + 0x5f); } // 0x5f (Size: 0x1, Type: BoolProperty)

    void SET_bMirror(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_MirrorDataTable(const UMirrorDataTable*& Value) { Write<UMirrorDataTable*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_bResetChild(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: BoolProperty)
    void SET_bBoneMirroring(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d, Value); } // 0x5d (Size: 0x1, Type: BoolProperty)
    void SET_bCurveMirroring(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5e, Value); } // 0x5e (Size: 0x1, Type: BoolProperty)
    void SET_bAttributeMirroring(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5f, Value); } // 0x5f (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FAnimNode_ModifyCurve : public FAnimNode_Base
{
public:
    FPoseLink SourcePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    TMap<FName, float> CurveMap() const { return Read<TMap<FName, float>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: MapProperty)
    TArray<float> CurveValues() const { return Read<TArray<float>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> CurveNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: FloatProperty)
    uint8_t ApplyMode() const { return Read<uint8_t>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x1, Type: EnumProperty)

    void SET_SourcePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_CurveMap(const TMap<FName, float>& Value) { Write<TMap<FName, float>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: MapProperty)
    void SET_CurveValues(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_CurveNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: FloatProperty)
    void SET_ApplyMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x1, Type: EnumProperty)
};

// Size: 0x50
struct FAnimNode_MultiWayBlend : public FAnimNode_Base
{
public:
    TArray<FPoseLink> Poses() const { return Read<TArray<FPoseLink>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<float> DesiredAlphas() const { return Read<TArray<float>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: StructProperty)
    bool bAdditiveNode() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bNormalizeAlpha() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)

    void SET_Poses(const TArray<FPoseLink>& Value) { Write<TArray<FPoseLink>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_DesiredAlphas(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: StructProperty)
    void SET_bAdditiveNode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_bNormalizeAlpha(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
struct FAnimNode_PoseHandler : public FAnimNode_AssetPlayerBase
{
public:
    UPoseAsset* PoseAsset() const { return Read<UPoseAsset*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_PoseAsset(const UPoseAsset*& Value) { Write<UPoseAsset*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
struct FAnimNode_PoseBlendNode : public FAnimNode_PoseHandler
{
public:
    FPoseLink SourcePose() const { return Read<FPoseLink>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)
    uint8_t BlendOption() const { return Read<uint8_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: EnumProperty)
    UCurveFloat* CustomCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_SourcePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
    void SET_BlendOption(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: EnumProperty)
    void SET_CustomCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb0
struct FAnimNode_PoseByName : public FAnimNode_PoseHandler
{
public:
    FName PoseName() const { return Read<FName>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: NameProperty)
    float PoseWeight() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)

    void SET_PoseName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: NameProperty)
    void SET_PoseWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FPoseDriverTransform
{
public:
    FVector TargetTranslation() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator TargetRotation() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_TargetTranslation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_TargetRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0xc0
struct FPoseDriverTarget
{
public:
    TArray<FPoseDriverTransform> BoneTransforms() const { return Read<TArray<FPoseDriverTransform>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FRotator TargetRotation() const { return Read<FRotator>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    float TargetScale() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t DistanceMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t FunctionType() const { return Read<uint8_t>(uintptr_t(this) + 0x2d); } // 0x2d (Size: 0x1, Type: EnumProperty)
    bool bApplyCustomCurve() const { return Read<bool>(uintptr_t(this) + 0x2e); } // 0x2e (Size: 0x1, Type: BoolProperty)
    FRichCurve CustomCurve() const { return Read<FRichCurve>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x80, Type: StructProperty)
    FName DrivenName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    bool bIsHidden() const { return Read<bool>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x1, Type: BoolProperty)

    void SET_BoneTransforms(const TArray<FPoseDriverTransform>& Value) { Write<TArray<FPoseDriverTransform>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_TargetRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_TargetScale(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
    void SET_FunctionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2d, Value); } // 0x2d (Size: 0x1, Type: EnumProperty)
    void SET_bApplyCustomCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e, Value); } // 0x2e (Size: 0x1, Type: BoolProperty)
    void SET_CustomCurve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x80, Type: StructProperty)
    void SET_DrivenName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_bIsHidden(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1a0
struct FAnimNode_PoseDriver : public FAnimNode_PoseHandler
{
public:
    FPoseLink SourcePose() const { return Read<FPoseLink>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)
    TArray<FBoneReference> SourceBones() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    FBoneReference EvalSpaceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xc, Type: StructProperty)
    bool bEvalFromRefPose() const { return Read<bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: BoolProperty)
    TArray<FBoneReference> OnlyDriveBones() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FPoseDriverTarget> PoseTargets() const { return Read<TArray<FPoseDriverTarget>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    FRBFParams RBFParams() const { return Read<FRBFParams>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x38, Type: StructProperty)
    uint8_t DriveSource() const { return Read<uint8_t>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: EnumProperty)
    uint8_t DriveOutput() const { return Read<uint8_t>(uintptr_t(this) + 0x129); } // 0x129 (Size: 0x1, Type: EnumProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x4, Type: IntProperty)

    void SET_SourcePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
    void SET_SourceBones(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_EvalSpaceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xc, Type: StructProperty)
    void SET_bEvalFromRefPose(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: BoolProperty)
    void SET_OnlyDriveBones(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_PoseTargets(const TArray<FPoseDriverTarget>& Value) { Write<TArray<FPoseDriverTarget>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_RBFParams(const FRBFParams& Value) { Write<FRBFParams>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x38, Type: StructProperty)
    void SET_DriveSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: EnumProperty)
    void SET_DriveOutput(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x129, Value); } // 0x129 (Size: 0x1, Type: EnumProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FRBFParams
{
public:
    int32_t TargetDimensions() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t SolverType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bAutomaticRadius() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Function() const { return Read<uint8_t>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: EnumProperty)
    uint8_t DistanceMethod() const { return Read<uint8_t>(uintptr_t(this) + 0xe); } // 0xe (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EBoneAxis> TwistAxis() const { return Read<TEnumAsByte<EBoneAxis>>(uintptr_t(this) + 0xf); } // 0xf (Size: 0x1, Type: ByteProperty)
    float WeightThreshold() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t NormalizeMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    FVector MedianReference() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    float MedianMin() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float MedianMax() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_TargetDimensions(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SolverType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bAutomaticRadius(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_Function(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: EnumProperty)
    void SET_DistanceMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe, Value); } // 0xe (Size: 0x1, Type: EnumProperty)
    void SET_TwistAxis(const TEnumAsByte<EBoneAxis>& Value) { Write<TEnumAsByte<EBoneAxis>>(uintptr_t(this) + 0xf, Value); } // 0xf (Size: 0x1, Type: ByteProperty)
    void SET_WeightThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_NormalizeMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_MedianReference(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_MedianMin(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_MedianMax(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
struct FAnimNode_PoseSnapshot : public FAnimNode_Base
{
public:
    FName SnapshotName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FPoseSnapshot Snapshot() const { return Read<FPoseSnapshot>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)

    void SET_SnapshotName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Snapshot(const FPoseSnapshot& Value) { Write<FPoseSnapshot>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x50
struct FRandomPlayerSequenceEntry
{
public:
    UAnimSequenceBase* Sequence() const { return Read<UAnimSequenceBase*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float ChanceToPlay() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t MinLoopCount() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MaxLoopCount() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    float MinPlayRate() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxPlayRate() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    FAlphaBlend BlendIn() const { return Read<FAlphaBlend>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)

    void SET_Sequence(const UAnimSequenceBase*& Value) { Write<UAnimSequenceBase*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ChanceToPlay(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinLoopCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_MaxLoopCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_MinPlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_MaxPlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_BlendIn(const FAlphaBlend& Value) { Write<FAlphaBlend>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
};

// Size: 0x78
struct FAnimNode_RandomPlayer : public FAnimNode_AssetPlayerRelevancyBase
{
public:
    TArray<FRandomPlayerSequenceEntry> Entries() const { return Read<TArray<FRandomPlayerSequenceEntry>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float BlendWeight() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    bool bShuffleMode() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)

    void SET_Entries(const TArray<FRandomPlayerSequenceEntry>& Value) { Write<TArray<FRandomPlayerSequenceEntry>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_BlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_bShuffleMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
struct FAnimNode_RotateRootBone : public FAnimNode_Base
{
public:
    FPoseLink BasePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    float pitch() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float Yaw() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    FInputScaleBiasClamp PitchScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x30, Type: StructProperty)
    FInputScaleBiasClamp YawScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x30, Type: StructProperty)
    FRotator MeshToComponent() const { return Read<FRotator>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    bool bRotateRootMotionAttribute() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_BasePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_pitch(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Yaw(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_PitchScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x30, Type: StructProperty)
    void SET_YawScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x30, Type: StructProperty)
    void SET_MeshToComponent(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_bRotateRootMotionAttribute(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x118
struct FAnimNode_RotationOffsetBlendSpace : public FAnimNode_BlendSpacePlayer
{
public:
    FPoseLink BasePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: IntProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend() const { return Read<FInputAlphaBoolBlend>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName() const { return Read<FName>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x30, Type: StructProperty)
    uint8_t AlphaInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled() const { return Read<bool>(uintptr_t(this) + 0x111); } // 0x111 (Size: 0x1, Type: BoolProperty)

    void SET_BasePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StructProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: IntProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: StructProperty)
    void SET_AlphaBoolBlend(const FInputAlphaBoolBlend& Value) { Write<FInputAlphaBoolBlend>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x48, Type: StructProperty)
    void SET_AlphaCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: NameProperty)
    void SET_AlphaScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x30, Type: StructProperty)
    void SET_AlphaInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: EnumProperty)
    void SET_bAlphaBoolEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x111, Value); } // 0x111 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x108
struct FAnimNode_RotationOffsetBlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
{
public:
    FPoseLink BasePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend() const { return Read<FInputAlphaBoolBlend>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x30, Type: StructProperty)
    uint8_t AlphaInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled() const { return Read<bool>(uintptr_t(this) + 0x101); } // 0x101 (Size: 0x1, Type: BoolProperty)

    void SET_BasePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
    void SET_AlphaBoolBlend(const FInputAlphaBoolBlend& Value) { Write<FInputAlphaBoolBlend>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x48, Type: StructProperty)
    void SET_AlphaCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_AlphaScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x30, Type: StructProperty)
    void SET_AlphaInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: EnumProperty)
    void SET_bAlphaBoolEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x101, Value); } // 0x101 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FAnimNode_SequenceEvaluatorBase : public FAnimNode_AssetPlayerBase
{
public:
};

// Size: 0x40
struct FAnimNode_SequenceEvaluator : public FAnimNode_SequenceEvaluatorBase
{
public:
};

// Size: 0x68
struct FAnimNode_SequenceEvaluator_Standalone : public FAnimNode_SequenceEvaluatorBase
{
public:
    FName GroupName() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: ByteProperty)
    uint8_t Method() const { return Read<uint8_t>(uintptr_t(this) + 0x45); } // 0x45 (Size: 0x1, Type: EnumProperty)
    bool bIgnoreForRelevancyTest() const { return Read<bool>(uintptr_t(this) + 0x46); } // 0x46 (Size: 0x1, Type: BoolProperty)
    UAnimSequenceBase* Sequence() const { return Read<UAnimSequenceBase*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    float ExplicitTime() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bUseExplicitFrame() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    int32_t ExplicitFrame() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)
    bool bShouldLoop() const { return Read<bool>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: BoolProperty)
    bool bTeleportToExplicitTime() const { return Read<bool>(uintptr_t(this) + 0x5d); } // 0x5d (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ESequenceEvalReinit> ReinitializationBehavior() const { return Read<TEnumAsByte<ESequenceEvalReinit>>(uintptr_t(this) + 0x5e); } // 0x5e (Size: 0x1, Type: ByteProperty)
    float StartPosition() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)

    void SET_GroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
    void SET_GroupRole(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: ByteProperty)
    void SET_Method(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x45, Value); } // 0x45 (Size: 0x1, Type: EnumProperty)
    void SET_bIgnoreForRelevancyTest(const bool& Value) { Write<bool>(uintptr_t(this) + 0x46, Value); } // 0x46 (Size: 0x1, Type: BoolProperty)
    void SET_Sequence(const UAnimSequenceBase*& Value) { Write<UAnimSequenceBase*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_ExplicitTime(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_bUseExplicitFrame(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_ExplicitFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
    void SET_bShouldLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: BoolProperty)
    void SET_bTeleportToExplicitTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d, Value); } // 0x5d (Size: 0x1, Type: BoolProperty)
    void SET_ReinitializationBehavior(const TEnumAsByte<ESequenceEvalReinit>& Value) { Write<TEnumAsByte<ESequenceEvalReinit>>(uintptr_t(this) + 0x5e, Value); } // 0x5e (Size: 0x1, Type: ByteProperty)
    void SET_StartPosition(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
struct FAnimNode_Slot : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FName SlotName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    bool bAlwaysUpdateSourcePose() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_SlotName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_bAlwaysUpdateSourcePose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FAnimNode_Sync : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FName GroupName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: ByteProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_GroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_GroupRole(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xc0
struct FAnimNode_TwoWayBlend : public FAnimNode_Base
{
public:
    FPoseLink A() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink B() const { return Read<FPoseLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    uint8_t AlphaInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x31) >> 0x0) & 1; } // 0x31:0 (Size: 0x1, Type: BoolProperty)
    bool bResetChildOnActivation() const { return (Read<uint8_t>(uintptr_t(this) + 0x31) >> 0x3) & 1; } // 0x31:3 (Size: 0x1, Type: BoolProperty)
    bool bAlwaysUpdateChildren() const { return (Read<uint8_t>(uintptr_t(this) + 0x31) >> 0x4) & 1; } // 0x31:4 (Size: 0x1, Type: BoolProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend() const { return Read<FInputAlphaBoolBlend>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x30, Type: StructProperty)

    void SET_A(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_B(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_AlphaInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_bAlphaBoolEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x31); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x31, B); } // 0x31:0 (Size: 0x1, Type: BoolProperty)
    void SET_bResetChildOnActivation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x31); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x31, B); } // 0x31:3 (Size: 0x1, Type: BoolProperty)
    void SET_bAlwaysUpdateChildren(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x31); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x31, B); } // 0x31:4 (Size: 0x1, Type: BoolProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: StructProperty)
    void SET_AlphaBoolBlend(const FInputAlphaBoolBlend& Value) { Write<FInputAlphaBoolBlend>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x48, Type: StructProperty)
    void SET_AlphaCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_AlphaScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x30, Type: StructProperty)
};

// Size: 0xbf0
struct FAnimSequencerInstanceProxy : public FAnimInstanceProxy
{
public:
};

// Size: 0x10
struct FBlendListBaseReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FBlendSpacePlayerReference : public FAnimNodeReference
{
public:
};

// Size: 0x88
struct FAnimPhysConstraintSetup
{
public:
    uint8_t LinearXLimitType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LinearYLimitType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t LinearZLimitType() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    FVector LinearAxesMin() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector LinearAxesMax() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t AngularConstraintType() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t TwistAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t AngularTargetAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: EnumProperty)
    float ConeAngle() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FVector AngularLimitsMin() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector AngularLimitsMax() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FVector AngularTarget() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_LinearXLimitType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_LinearYLimitType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_LinearZLimitType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_LinearAxesMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_LinearAxesMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_AngularConstraintType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_TwistAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: EnumProperty)
    void SET_AngularTargetAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: EnumProperty)
    void SET_ConeAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_AngularLimitsMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_AngularLimitsMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_AngularTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FAnimPhysPlanarLimit
{
public:
    FBoneReference DrivingBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FTransform PlaneTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_DrivingBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_PlaneTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x30
struct FAnimPhysSphericalLimit
{
public:
    FBoneReference DrivingBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector SphereLocalOffset() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    float LimitRadius() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t LimitType() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)

    void SET_DrivingBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_SphereLocalOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_LimitRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_LimitType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
};

// Size: 0xd0
struct FAnimPhysBodyDefinition
{
public:
    FBoneReference BoundBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector BoxExtents() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector LocalJointOffset() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FAnimPhysConstraintSetup ConstraintSetup() const { return Read<FAnimPhysConstraintSetup>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x88, Type: StructProperty)
    uint8_t CollisionType() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    float SphereCollisionRadius() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)

    void SET_BoundBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_BoxExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_LocalJointOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_ConstraintSetup(const FAnimPhysConstraintSetup& Value) { Write<FAnimPhysConstraintSetup>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x88, Type: StructProperty)
    void SET_CollisionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_SphereCollisionRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x510
struct FAnimNode_AnimDynamics : public FAnimNode_SkeletalControlBase
{
public:
    float LinearDampingOverride() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float AngularDampingOverride() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    FBoneReference RelativeSpaceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0xc, Type: StructProperty)
    FBoneReference BoundBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0xc, Type: StructProperty)
    FBoneReference ChainEnd() const { return Read<FBoneReference>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0xc, Type: StructProperty)
    TArray<FAnimPhysBodyDefinition> PhysicsBodyDefinitions() const { return Read<TArray<FAnimPhysBodyDefinition>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    float GravityScale() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    FVector GravityOverride() const { return Read<FVector>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x18, Type: StructProperty)
    float LinearSpringConstant() const { return Read<float>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x4, Type: FloatProperty)
    float AngularSpringConstant() const { return Read<float>(uintptr_t(this) + 0x1ec); } // 0x1ec (Size: 0x4, Type: FloatProperty)
    float WindScale() const { return Read<float>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x4, Type: FloatProperty)
    FVector ComponentLinearAccScale() const { return Read<FVector>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearVelScale() const { return Read<FVector>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x18, Type: StructProperty)
    FVector ComponentAppliedLinearAccClamp() const { return Read<FVector>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x18, Type: StructProperty)
    float AngularBiasOverride() const { return Read<float>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: FloatProperty)
    int32_t NumSolverIterationsPreUpdate() const { return Read<int32_t>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: IntProperty)
    int32_t NumSolverIterationsPostUpdate() const { return Read<int32_t>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: IntProperty)
    TArray<FAnimPhysSphericalLimit> SphericalLimits() const { return Read<TArray<FAnimPhysSphericalLimit>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x10, Type: ArrayProperty)
    FVector ExternalForce() const { return Read<FVector>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x18, Type: StructProperty)
    TArray<FAnimPhysPlanarLimit> PlanarLimits() const { return Read<TArray<FAnimPhysPlanarLimit>>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x10, Type: ArrayProperty)
    uint8_t SimulationSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x1, Type: EnumProperty)
    bool bUseSphericalLimits() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x0) & 1; } // 0x28b:0 (Size: 0x1, Type: BoolProperty)
    bool bUsePlanarLimit() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x1) & 1; } // 0x28b:1 (Size: 0x1, Type: BoolProperty)
    bool bDoUpdate() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x2) & 1; } // 0x28b:2 (Size: 0x1, Type: BoolProperty)
    bool bDoEval() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x3) & 1; } // 0x28b:3 (Size: 0x1, Type: BoolProperty)
    bool bOverrideLinearDamping() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x4) & 1; } // 0x28b:4 (Size: 0x1, Type: BoolProperty)
    bool bOverrideAngularBias() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x5) & 1; } // 0x28b:5 (Size: 0x1, Type: BoolProperty)
    bool bOverrideAngularDamping() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x6) & 1; } // 0x28b:6 (Size: 0x1, Type: BoolProperty)
    bool bEnableWind() const { return (Read<uint8_t>(uintptr_t(this) + 0x28b) >> 0x7) & 1; } // 0x28b:7 (Size: 0x1, Type: BoolProperty)
    bool bUseGravityOverride() const { return (Read<uint8_t>(uintptr_t(this) + 0x28c) >> 0x1) & 1; } // 0x28c:1 (Size: 0x1, Type: BoolProperty)
    bool bGravityOverrideInSimSpace() const { return (Read<uint8_t>(uintptr_t(this) + 0x28c) >> 0x2) & 1; } // 0x28c:2 (Size: 0x1, Type: BoolProperty)
    bool bLinearSpring() const { return (Read<uint8_t>(uintptr_t(this) + 0x28c) >> 0x3) & 1; } // 0x28c:3 (Size: 0x1, Type: BoolProperty)
    bool bAngularSpring() const { return (Read<uint8_t>(uintptr_t(this) + 0x28c) >> 0x4) & 1; } // 0x28c:4 (Size: 0x1, Type: BoolProperty)
    bool bChain() const { return (Read<uint8_t>(uintptr_t(this) + 0x28c) >> 0x5) & 1; } // 0x28c:5 (Size: 0x1, Type: BoolProperty)
    FRotationRetargetingInfo RetargetingSettings() const { return Read<FRotationRetargetingInfo>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x1a0, Type: StructProperty)

    void SET_LinearDampingOverride(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_AngularDampingOverride(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_RelativeSpaceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0xc, Type: StructProperty)
    void SET_BoundBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0xc, Type: StructProperty)
    void SET_ChainEnd(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0xc, Type: StructProperty)
    void SET_PhysicsBodyDefinitions(const TArray<FAnimPhysBodyDefinition>& Value) { Write<TArray<FAnimPhysBodyDefinition>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    void SET_GravityScale(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    void SET_GravityOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x18, Type: StructProperty)
    void SET_LinearSpringConstant(const float& Value) { Write<float>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x4, Type: FloatProperty)
    void SET_AngularSpringConstant(const float& Value) { Write<float>(uintptr_t(this) + 0x1ec, Value); } // 0x1ec (Size: 0x4, Type: FloatProperty)
    void SET_WindScale(const float& Value) { Write<float>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x4, Type: FloatProperty)
    void SET_ComponentLinearAccScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x18, Type: StructProperty)
    void SET_ComponentLinearVelScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x18, Type: StructProperty)
    void SET_ComponentAppliedLinearAccClamp(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x18, Type: StructProperty)
    void SET_AngularBiasOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: FloatProperty)
    void SET_NumSolverIterationsPreUpdate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: IntProperty)
    void SET_NumSolverIterationsPostUpdate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: IntProperty)
    void SET_SphericalLimits(const TArray<FAnimPhysSphericalLimit>& Value) { Write<TArray<FAnimPhysSphericalLimit>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x18, Type: StructProperty)
    void SET_PlanarLimits(const TArray<FAnimPhysPlanarLimit>& Value) { Write<TArray<FAnimPhysPlanarLimit>>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x10, Type: ArrayProperty)
    void SET_SimulationSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x1, Type: EnumProperty)
    void SET_bUseSphericalLimits(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUsePlanarLimit(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:1 (Size: 0x1, Type: BoolProperty)
    void SET_bDoUpdate(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:2 (Size: 0x1, Type: BoolProperty)
    void SET_bDoEval(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:3 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideLinearDamping(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:4 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideAngularBias(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:5 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideAngularDamping(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:6 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableWind(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28b); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x28b, B); } // 0x28b:7 (Size: 0x1, Type: BoolProperty)
    void SET_bUseGravityOverride(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x28c, B); } // 0x28c:1 (Size: 0x1, Type: BoolProperty)
    void SET_bGravityOverrideInSimSpace(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x28c, B); } // 0x28c:2 (Size: 0x1, Type: BoolProperty)
    void SET_bLinearSpring(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28c); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x28c, B); } // 0x28c:3 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularSpring(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28c); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x28c, B); } // 0x28c:4 (Size: 0x1, Type: BoolProperty)
    void SET_bChain(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28c); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x28c, B); } // 0x28c:5 (Size: 0x1, Type: BoolProperty)
    void SET_RetargetingSettings(const FRotationRetargetingInfo& Value) { Write<FRotationRetargetingInfo>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x1a0, Type: StructProperty)
};

// Size: 0x40
struct FAngularRangeLimit
{
public:
    FVector LimitMin() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector LimitMax() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FBoneReference bone() const { return Read<FBoneReference>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xc, Type: StructProperty)

    void SET_LimitMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_LimitMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_bone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xc, Type: StructProperty)
};

// Size: 0xe8
struct FAnimNode_ApplyLimits : public FAnimNode_SkeletalControlBase
{
public:
    TArray<FAngularRangeLimit> AngularRangeLimits() const { return Read<TArray<FAngularRangeLimit>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> AngularOffsets() const { return Read<TArray<FVector>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_AngularRangeLimits(const TArray<FAngularRangeLimit>& Value) { Write<TArray<FAngularRangeLimit>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_AngularOffsets(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x120
struct FAnimNode_BoneDrivenController : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    UCurveFloat* DrivingCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    float Multiplier() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    double RangeMin() const { return Read<double>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    double RangeMax() const { return Read<double>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    double RemappedMin() const { return Read<double>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
    double RemappedMax() const { return Read<double>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: DoubleProperty)
    FName ParameterName() const { return Read<FName>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: NameProperty)
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0xc, Type: StructProperty)
    uint8_t DestinationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: EnumProperty)
    uint8_t ModificationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x119); } // 0x119 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EComponentType> SourceComponent() const { return Read<TEnumAsByte<EComponentType>>(uintptr_t(this) + 0x11a); } // 0x11a (Size: 0x1, Type: ByteProperty)
    bool bUseRange() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x0) & 1; } // 0x11b:0 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetTranslationX() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x1) & 1; } // 0x11b:1 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetTranslationY() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x2) & 1; } // 0x11b:2 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetTranslationZ() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x3) & 1; } // 0x11b:3 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetRotationX() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x4) & 1; } // 0x11b:4 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetRotationY() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x5) & 1; } // 0x11b:5 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetRotationZ() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x6) & 1; } // 0x11b:6 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetScaleX() const { return (Read<uint8_t>(uintptr_t(this) + 0x11b) >> 0x7) & 1; } // 0x11b:7 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetScaleY() const { return (Read<uint8_t>(uintptr_t(this) + 0x11c) >> 0x0) & 1; } // 0x11c:0 (Size: 0x1, Type: BoolProperty)
    bool bAffectTargetScaleZ() const { return (Read<uint8_t>(uintptr_t(this) + 0x11c) >> 0x1) & 1; } // 0x11c:1 (Size: 0x1, Type: BoolProperty)

    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_DrivingCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_Multiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_RangeMin(const double& Value) { Write<double>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    void SET_RangeMax(const double& Value) { Write<double>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    void SET_RemappedMin(const double& Value) { Write<double>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
    void SET_RemappedMax(const double& Value) { Write<double>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: DoubleProperty)
    void SET_ParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: NameProperty)
    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0xc, Type: StructProperty)
    void SET_DestinationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: EnumProperty)
    void SET_ModificationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x119, Value); } // 0x119 (Size: 0x1, Type: EnumProperty)
    void SET_SourceComponent(const TEnumAsByte<EComponentType>& Value) { Write<TEnumAsByte<EComponentType>>(uintptr_t(this) + 0x11a, Value); } // 0x11a (Size: 0x1, Type: ByteProperty)
    void SET_bUseRange(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetTranslationX(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:1 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetTranslationY(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:2 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetTranslationZ(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:3 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetRotationX(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:4 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetRotationY(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:5 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetRotationZ(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:6 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetScaleX(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11b); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x11b, B); } // 0x11b:7 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetScaleY(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x11c, B); } // 0x11c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectTargetScaleZ(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x11c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x11c, B); } // 0x11c:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1b0
struct FAnimNode_CCDIK : public FAnimNode_SkeletalControlBase
{
public:
    FVector EffectorLocation() const { return Read<FVector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> EffectorLocationSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: ByteProperty)
    FBoneSocketTarget EffectorTarget() const { return Read<FBoneSocketTarget>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x80, Type: StructProperty)
    FBoneReference TipBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xc, Type: StructProperty)
    FBoneReference RootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0xc, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x4, Type: IntProperty)
    bool bStartFromTail() const { return Read<bool>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bEnableRotationLimit() const { return Read<bool>(uintptr_t(this) + 0x191); } // 0x191 (Size: 0x1, Type: BoolProperty)
    TArray<float> RotationLimitPerJoints() const { return Read<TArray<float>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)

    void SET_EffectorLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x18, Type: StructProperty)
    void SET_EffectorLocationSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: ByteProperty)
    void SET_EffectorTarget(const FBoneSocketTarget& Value) { Write<FBoneSocketTarget>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x80, Type: StructProperty)
    void SET_TipBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xc, Type: StructProperty)
    void SET_RootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0xc, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x4, Type: IntProperty)
    void SET_bStartFromTail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableRotationLimit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x191, Value); } // 0x191 (Size: 0x1, Type: BoolProperty)
    void SET_RotationLimitPerJoints(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FConstraint
{
public:
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t OffsetOption() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t TransformType() const { return Read<uint8_t>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: EnumProperty)
    FFilterOptionPerAxis PerAxis() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0xe); } // 0xe (Size: 0x3, Type: StructProperty)

    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_OffsetOption(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_TransformType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: EnumProperty)
    void SET_PerAxis(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0xe, Value); } // 0xe (Size: 0x3, Type: StructProperty)
};

// Size: 0x108
struct FAnimNode_Constraint : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference BoneToModify() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    TArray<FConstraint> ConstraintSetup() const { return Read<TArray<FConstraint>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ConstraintWeights() const { return Read<TArray<float>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)

    void SET_BoneToModify(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_ConstraintSetup(const TArray<FConstraint>& Value) { Write<TArray<FConstraint>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_ConstraintWeights(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe8
struct FAnimNode_CopyBone : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0xc, Type: StructProperty)
    bool bCopyTranslation() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bCopyRotation() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    bool bCopyScale() const { return Read<bool>(uintptr_t(this) + 0xe2); } // 0xe2 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EBoneControlSpace> ControlSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0xe3); } // 0xe3 (Size: 0x1, Type: ByteProperty)

    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0xc, Type: StructProperty)
    void SET_bCopyTranslation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe2, Value); } // 0xe2 (Size: 0x1, Type: BoolProperty)
    void SET_ControlSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0xe3, Value); } // 0xe3 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xf0
struct FAnimNode_CopyBoneDelta : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0xc, Type: StructProperty)
    bool bCopyTranslation() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bCopyRotation() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    bool bCopyScale() const { return Read<bool>(uintptr_t(this) + 0xe2); } // 0xe2 (Size: 0x1, Type: BoolProperty)
    uint8_t CopyMode() const { return Read<uint8_t>(uintptr_t(this) + 0xe3); } // 0xe3 (Size: 0x1, Type: EnumProperty)
    float TranslationMultiplier() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float RotationMultiplier() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float ScaleMultiplier() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)

    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0xc, Type: StructProperty)
    void SET_bCopyTranslation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe2, Value); } // 0xe2 (Size: 0x1, Type: BoolProperty)
    void SET_CopyMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe3, Value); } // 0xe3 (Size: 0x1, Type: EnumProperty)
    void SET_TranslationMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_RotationMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1e0
struct FAnimNode_Fabrik : public FAnimNode_SkeletalControlBase
{
public:
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x60, Type: StructProperty)
    FBoneSocketTarget EffectorTarget() const { return Read<FBoneSocketTarget>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x80, Type: StructProperty)
    FBoneReference TipBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0xc, Type: StructProperty)
    FBoneReference RootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0xc, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EBoneControlSpace> EffectorTransformSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneRotationSource> EffectorRotationSource() const { return Read<TEnumAsByte<EBoneRotationSource>>(uintptr_t(this) + 0x1d1); } // 0x1d1 (Size: 0x1, Type: ByteProperty)

    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x60, Type: StructProperty)
    void SET_EffectorTarget(const FBoneSocketTarget& Value) { Write<FBoneSocketTarget>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x80, Type: StructProperty)
    void SET_TipBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0xc, Type: StructProperty)
    void SET_RootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0xc, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: IntProperty)
    void SET_EffectorTransformSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: ByteProperty)
    void SET_EffectorRotationSource(const TEnumAsByte<EBoneRotationSource>& Value) { Write<TEnumAsByte<EBoneRotationSource>>(uintptr_t(this) + 0x1d1, Value); } // 0x1d1 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x128
struct FAnimNode_HandIKRetargeting : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference RightHandFK() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference LeftHandFK() const { return Read<FBoneReference>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0xc, Type: StructProperty)
    FBoneReference RightHandIK() const { return Read<FBoneReference>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0xc, Type: StructProperty)
    FBoneReference LeftHandIK() const { return Read<FBoneReference>(uintptr_t(this) + 0xec); } // 0xec (Size: 0xc, Type: StructProperty)
    TArray<FBoneReference> IKBonesToMove() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    FVector PerAxisAlpha() const { return Read<FVector>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    float HandFKWeight() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)

    void SET_RightHandFK(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_LeftHandFK(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0xc, Type: StructProperty)
    void SET_RightHandIK(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0xc, Type: StructProperty)
    void SET_LeftHandIK(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0xc, Type: StructProperty)
    void SET_IKBonesToMove(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_PerAxisAlpha(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_HandFKWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x70
struct FIKChainLink
{
public:
};

// Size: 0x50
struct FIKChain
{
public:
};

// Size: 0x28
struct FAnimLegIKDefinition
{
public:
    FBoneReference IKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference FKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    int32_t NumBonesInLimb() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    float MinRotationAngle() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAxis> FootBoneForwardAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EAxis> HingeRotationAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: ByteProperty)
    bool bEnableRotationLimit() const { return Read<bool>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bEnableKneeTwistCorrection() const { return Read<bool>(uintptr_t(this) + 0x23); } // 0x23 (Size: 0x1, Type: BoolProperty)
    FName TwistOffsetCurveName() const { return Read<FName>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: NameProperty)

    void SET_IKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_FKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_NumBonesInLimb(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_MinRotationAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_FootBoneForwardAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: ByteProperty)
    void SET_HingeRotationAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: ByteProperty)
    void SET_bEnableRotationLimit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableKneeTwistCorrection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23, Value); } // 0x23 (Size: 0x1, Type: BoolProperty)
    void SET_TwistOffsetCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: NameProperty)
};

// Size: 0xf0
struct FAnimLegIKData
{
public:
};

// Size: 0x100
struct FAnimNode_LegIK : public FAnimNode_SkeletalControlBase
{
public:
    float ReachPrecision() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: IntProperty)
    float SoftPercentLength() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float SoftAlpha() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    TArray<FAnimLegIKDefinition> LegsDefinition() const { return Read<TArray<FAnimLegIKDefinition>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_ReachPrecision(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: IntProperty)
    void SET_SoftPercentLength(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_SoftAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_LegsDefinition(const TArray<FAnimLegIKDefinition>& Value) { Write<TArray<FAnimLegIKDefinition>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x240
struct FAnimNode_LookAt : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference BoneToModify() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneSocketTarget LookAtTarget() const { return Read<FBoneSocketTarget>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x80, Type: StructProperty)
    FVector LookAtLocation() const { return Read<FVector>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x18, Type: StructProperty)
    FAxis LookAt_Axis() const { return Read<FAxis>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x20, Type: StructProperty)
    bool bUseLookUpAxis() const { return Read<bool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EInterpolationBlend> InterpolationType() const { return Read<TEnumAsByte<EInterpolationBlend>>(uintptr_t(this) + 0x199); } // 0x199 (Size: 0x1, Type: ByteProperty)
    FAxis LookUp_Axis() const { return Read<FAxis>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x20, Type: StructProperty)
    float LookAtClamp() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float InterpolationTime() const { return Read<float>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    float InterpolationTriggerThreashold() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)

    void SET_BoneToModify(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_LookAtTarget(const FBoneSocketTarget& Value) { Write<FBoneSocketTarget>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x80, Type: StructProperty)
    void SET_LookAtLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x18, Type: StructProperty)
    void SET_LookAt_Axis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x20, Type: StructProperty)
    void SET_bUseLookUpAxis(const bool& Value) { Write<bool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: BoolProperty)
    void SET_InterpolationType(const TEnumAsByte<EInterpolationBlend>& Value) { Write<TEnumAsByte<EInterpolationBlend>>(uintptr_t(this) + 0x199, Value); } // 0x199 (Size: 0x1, Type: ByteProperty)
    void SET_LookUp_Axis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x20, Type: StructProperty)
    void SET_LookAtClamp(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_InterpolationTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    void SET_InterpolationTriggerThreashold(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x120
struct FAnimNode_ObserveBone : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference BoneToObserve() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> DisplaySpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x1, Type: ByteProperty)
    bool bRelativeToRefPose() const { return Read<bool>(uintptr_t(this) + 0xd5); } // 0xd5 (Size: 0x1, Type: BoolProperty)
    FVector Translation() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FVector Scale() const { return Read<FVector>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)

    void SET_BoneToObserve(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_DisplaySpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x1, Type: ByteProperty)
    void SET_bRelativeToRefPose(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd5, Value); } // 0xd5 (Size: 0x1, Type: BoolProperty)
    void SET_Translation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd8
struct FAnimNode_ResetRoot : public FAnimNode_SkeletalControlBase
{
public:
};

// Size: 0x68
struct FSimSpaceSettings
{
public:
    float WorldAlpha() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float VelocityScaleZ() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float DampingAlpha() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxLinearVelocity() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxAngularVelocity() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxLinearAcceleration() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxAngularAcceleration() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    FVector ExternalLinearDragV() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector ExternalLinearVelocity() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector ExternalAngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)

    void SET_WorldAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_VelocityScaleZ(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_DampingAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLinearVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxAngularVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLinearAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAngularAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_ExternalLinearDragV(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_ExternalLinearVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_ExternalAngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
};

// Size: 0x920
struct FAnimNode_RigidBody : public FAnimNode_SkeletalControlBase
{
public:
    UPhysicsAsset* OverridePhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    bool bDefaultToSkeletalMeshPhysicsAsset() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bUseLocalLODThresholdOnly() const { return Read<bool>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x1, Type: BoolProperty)
    FVector OverrideWorldGravity() const { return Read<FVector>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x18, Type: StructProperty)
    FVector ExternalForce() const { return Read<FVector>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearAccScale() const { return Read<FVector>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearVelScale() const { return Read<FVector>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x18, Type: StructProperty)
    FVector ComponentAppliedLinearAccClamp() const { return Read<FVector>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x18, Type: StructProperty)
    FSimSpaceSettings SimSpaceSettings() const { return Read<FSimSpaceSettings>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x68, Type: StructProperty)
    float CachedBoundsScale() const { return Read<float>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    FBoneReference BaseBoneRef() const { return Read<FBoneReference>(uintptr_t(this) + 0x2f4); } // 0x2f4 (Size: 0xc, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> OverlapChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x1, Type: ByteProperty)
    uint8_t SimulationSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x301); } // 0x301 (Size: 0x1, Type: EnumProperty)
    bool bForceDisableCollisionBetweenConstraintBodies() const { return Read<bool>(uintptr_t(this) + 0x302); } // 0x302 (Size: 0x1, Type: BoolProperty)
    bool bUseExternalClothCollision() const { return Read<bool>(uintptr_t(this) + 0x303); } // 0x303 (Size: 0x1, Type: BoolProperty)
    bool bEnableWorldGeometry() const { return (Read<uint8_t>(uintptr_t(this) + 0x305) >> 0x0) & 1; } // 0x305:0 (Size: 0x1, Type: BoolProperty)
    bool bOverrideWorldGravity() const { return (Read<uint8_t>(uintptr_t(this) + 0x305) >> 0x1) & 1; } // 0x305:1 (Size: 0x1, Type: BoolProperty)
    bool bTransferBoneVelocities() const { return (Read<uint8_t>(uintptr_t(this) + 0x305) >> 0x2) & 1; } // 0x305:2 (Size: 0x1, Type: BoolProperty)
    bool bFreezeIncomingPoseOnStart() const { return (Read<uint8_t>(uintptr_t(this) + 0x305) >> 0x3) & 1; } // 0x305:3 (Size: 0x1, Type: BoolProperty)
    bool bClampLinearTranslationLimitToRefPose() const { return (Read<uint8_t>(uintptr_t(this) + 0x305) >> 0x4) & 1; } // 0x305:4 (Size: 0x1, Type: BoolProperty)
    float WorldSpaceMinimumScale() const { return Read<float>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: FloatProperty)
    float EvaluationResetTime() const { return Read<float>(uintptr_t(this) + 0x30c); } // 0x30c (Size: 0x4, Type: FloatProperty)
    uint8_t SimulationTiming() const { return Read<uint8_t>(uintptr_t(this) + 0x311); } // 0x311 (Size: 0x1, Type: EnumProperty)

    void SET_OverridePhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_bDefaultToSkeletalMeshPhysicsAsset(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseLocalLODThresholdOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideWorldGravity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x18, Type: StructProperty)
    void SET_ExternalForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x18, Type: StructProperty)
    void SET_ComponentLinearAccScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x18, Type: StructProperty)
    void SET_ComponentLinearVelScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x18, Type: StructProperty)
    void SET_ComponentAppliedLinearAccClamp(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x18, Type: StructProperty)
    void SET_SimSpaceSettings(const FSimSpaceSettings& Value) { Write<FSimSpaceSettings>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x68, Type: StructProperty)
    void SET_CachedBoundsScale(const float& Value) { Write<float>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    void SET_BaseBoneRef(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x2f4, Value); } // 0x2f4 (Size: 0xc, Type: StructProperty)
    void SET_OverlapChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x1, Type: ByteProperty)
    void SET_SimulationSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x301, Value); } // 0x301 (Size: 0x1, Type: EnumProperty)
    void SET_bForceDisableCollisionBetweenConstraintBodies(const bool& Value) { Write<bool>(uintptr_t(this) + 0x302, Value); } // 0x302 (Size: 0x1, Type: BoolProperty)
    void SET_bUseExternalClothCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x303, Value); } // 0x303 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableWorldGeometry(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x305); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x305, B); } // 0x305:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideWorldGravity(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x305); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x305, B); } // 0x305:1 (Size: 0x1, Type: BoolProperty)
    void SET_bTransferBoneVelocities(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x305); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x305, B); } // 0x305:2 (Size: 0x1, Type: BoolProperty)
    void SET_bFreezeIncomingPoseOnStart(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x305); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x305, B); } // 0x305:3 (Size: 0x1, Type: BoolProperty)
    void SET_bClampLinearTranslationLimitToRefPose(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x305); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x305, B); } // 0x305:4 (Size: 0x1, Type: BoolProperty)
    void SET_WorldSpaceMinimumScale(const float& Value) { Write<float>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: FloatProperty)
    void SET_EvaluationResetTime(const float& Value) { Write<float>(uintptr_t(this) + 0x30c, Value); } // 0x30c (Size: 0x4, Type: FloatProperty)
    void SET_SimulationTiming(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x311, Value); } // 0x311 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x80
struct FAnimNode_ScaleChainLength : public FAnimNode_Base
{
public:
    FPoseLink InputPose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    float DefaultChainLength() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FBoneReference ChainStartBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0xc, Type: StructProperty)
    FBoneReference ChainEndBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xc, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)
    uint8_t ChainInitialLength() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)

    void SET_InputPose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_DefaultChainLength(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_ChainStartBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0xc, Type: StructProperty)
    void SET_ChainEndBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xc, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
    void SET_ChainInitialLength(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FSplineIKCachedBoneData
{
public:
    FBoneReference bone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    int32_t RefSkeletonIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_bone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_RefSkeletonIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x258
struct FAnimNode_SplineIK : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference StartBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference EndBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0xc, Type: StructProperty)
    uint8_t BoneAxis() const { return Read<uint8_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    bool bAutoCalculateSpline() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    int32_t PointCount() const { return Read<int32_t>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: IntProperty)
    TArray<FTransform> ControlPoints() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    float Roll() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float TwistStart() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float TwistEnd() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    FAlphaBlend TwistBlend() const { return Read<FAlphaBlend>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x30, Type: StructProperty)
    float Stretch() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    float Offset() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)

    void SET_StartBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_EndBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0xc, Type: StructProperty)
    void SET_BoneAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    void SET_bAutoCalculateSpline(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    void SET_PointCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: IntProperty)
    void SET_ControlPoints(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_Roll(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_TwistStart(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_TwistEnd(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_TwistBlend(const FAlphaBlend& Value) { Write<FAlphaBlend>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x30, Type: StructProperty)
    void SET_Stretch(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_Offset(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x180
struct FAnimNode_SpringBone : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference SpringBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    double MaxDisplacement() const { return Read<double>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double SpringStiffness() const { return Read<double>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    double SpringDamping() const { return Read<double>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    double ErrorResetThresh() const { return Read<double>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    bool bLimitDisplacement() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x0) & 1; } // 0x164:0 (Size: 0x1, Type: BoolProperty)
    bool bTranslateX() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x1) & 1; } // 0x164:1 (Size: 0x1, Type: BoolProperty)
    bool bTranslateY() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x2) & 1; } // 0x164:2 (Size: 0x1, Type: BoolProperty)
    bool bTranslateZ() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x3) & 1; } // 0x164:3 (Size: 0x1, Type: BoolProperty)
    bool bRotateX() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x4) & 1; } // 0x164:4 (Size: 0x1, Type: BoolProperty)
    bool bRotateY() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x5) & 1; } // 0x164:5 (Size: 0x1, Type: BoolProperty)
    bool bRotateZ() const { return (Read<uint8_t>(uintptr_t(this) + 0x164) >> 0x6) & 1; } // 0x164:6 (Size: 0x1, Type: BoolProperty)
    bool bOverrideOwnerVelocity() const { return (Read<uint8_t>(uintptr_t(this) + 0x165) >> 0x0) & 1; } // 0x165:0 (Size: 0x1, Type: BoolProperty)
    FVector OwnerVelocityOverride() const { return Read<FVector>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x18, Type: StructProperty)

    void SET_SpringBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_MaxDisplacement(const double& Value) { Write<double>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringStiffness(const double& Value) { Write<double>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringDamping(const double& Value) { Write<double>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    void SET_ErrorResetThresh(const double& Value) { Write<double>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    void SET_bLimitDisplacement(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:0 (Size: 0x1, Type: BoolProperty)
    void SET_bTranslateX(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:1 (Size: 0x1, Type: BoolProperty)
    void SET_bTranslateY(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:2 (Size: 0x1, Type: BoolProperty)
    void SET_bTranslateZ(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:3 (Size: 0x1, Type: BoolProperty)
    void SET_bRotateX(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:4 (Size: 0x1, Type: BoolProperty)
    void SET_bRotateY(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:5 (Size: 0x1, Type: BoolProperty)
    void SET_bRotateZ(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x164); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x164, B); } // 0x164:6 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideOwnerVelocity(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x165); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x165, B); } // 0x165:0 (Size: 0x1, Type: BoolProperty)
    void SET_OwnerVelocityOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRotationLimit
{
public:
    FVector LimitMin() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector LimitMax() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_LimitMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_LimitMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x2a0
struct FAnimNode_Trail : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference TrailBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0xc, Type: StructProperty)
    int32_t ChainLength() const { return Read<int32_t>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EAxis> ChainBoneAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: ByteProperty)
    bool bInvertChainBoneAxis() const { return (Read<uint8_t>(uintptr_t(this) + 0x141) >> 0x0) & 1; } // 0x141:0 (Size: 0x1, Type: BoolProperty)
    bool bLimitStretch() const { return (Read<uint8_t>(uintptr_t(this) + 0x141) >> 0x1) & 1; } // 0x141:1 (Size: 0x1, Type: BoolProperty)
    bool bLimitRotation() const { return (Read<uint8_t>(uintptr_t(this) + 0x141) >> 0x2) & 1; } // 0x141:2 (Size: 0x1, Type: BoolProperty)
    bool bUsePlanarLimit() const { return (Read<uint8_t>(uintptr_t(this) + 0x141) >> 0x3) & 1; } // 0x141:3 (Size: 0x1, Type: BoolProperty)
    bool bActorSpaceFakeVel() const { return (Read<uint8_t>(uintptr_t(this) + 0x141) >> 0x4) & 1; } // 0x141:4 (Size: 0x1, Type: BoolProperty)
    bool bReorientParentToChild() const { return (Read<uint8_t>(uintptr_t(this) + 0x141) >> 0x5) & 1; } // 0x141:5 (Size: 0x1, Type: BoolProperty)
    float MaxDeltaTime() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float RelaxationSpeedScale() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve TrailRelaxationSpeed() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x88, Type: StructProperty)
    FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x30, Type: StructProperty)
    TArray<FRotationLimit> RotationLimits() const { return Read<TArray<FRotationLimit>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> RotationOffsets() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    TArray<FAnimPhysPlanarLimit> PlanarLimits() const { return Read<TArray<FAnimPhysPlanarLimit>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    float StretchLimit() const { return Read<float>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x4, Type: FloatProperty)
    FVector FakeVelocity() const { return Read<FVector>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x18, Type: StructProperty)
    FBoneReference BaseJoint() const { return Read<FBoneReference>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0xc, Type: StructProperty)
    float LastBoneRotationAnimAlphaBlend() const { return Read<float>(uintptr_t(this) + 0x264); } // 0x264 (Size: 0x4, Type: FloatProperty)

    void SET_TrailBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0xc, Type: StructProperty)
    void SET_ChainLength(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: IntProperty)
    void SET_ChainBoneAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: ByteProperty)
    void SET_bInvertChainBoneAxis(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x141); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x141, B); } // 0x141:0 (Size: 0x1, Type: BoolProperty)
    void SET_bLimitStretch(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x141); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x141, B); } // 0x141:1 (Size: 0x1, Type: BoolProperty)
    void SET_bLimitRotation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x141); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x141, B); } // 0x141:2 (Size: 0x1, Type: BoolProperty)
    void SET_bUsePlanarLimit(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x141); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x141, B); } // 0x141:3 (Size: 0x1, Type: BoolProperty)
    void SET_bActorSpaceFakeVel(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x141); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x141, B); } // 0x141:4 (Size: 0x1, Type: BoolProperty)
    void SET_bReorientParentToChild(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x141); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x141, B); } // 0x141:5 (Size: 0x1, Type: BoolProperty)
    void SET_MaxDeltaTime(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_RelaxationSpeedScale(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_TrailRelaxationSpeed(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x88, Type: StructProperty)
    void SET_RelaxationSpeedScaleInputProcessor(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x30, Type: StructProperty)
    void SET_RotationLimits(const TArray<FRotationLimit>& Value) { Write<TArray<FRotationLimit>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationOffsets(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    void SET_PlanarLimits(const TArray<FAnimPhysPlanarLimit>& Value) { Write<TArray<FAnimPhysPlanarLimit>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    void SET_StretchLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x4, Type: FloatProperty)
    void SET_FakeVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x18, Type: StructProperty)
    void SET_BaseJoint(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0xc, Type: StructProperty)
    void SET_LastBoneRotationAnimAlphaBlend(const float& Value) { Write<float>(uintptr_t(this) + 0x264, Value); } // 0x264 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FReferenceBoneFrame
{
public:
    FBoneReference bone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FAxis Axis() const { return Read<FAxis>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)

    void SET_bone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_Axis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
};

// Size: 0x160
struct FAnimNode_TwistCorrectiveNode : public FAnimNode_SkeletalControlBase
{
public:
    FReferenceBoneFrame BaseFrame() const { return Read<FReferenceBoneFrame>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x30, Type: StructProperty)
    FReferenceBoneFrame TwistFrame() const { return Read<FReferenceBoneFrame>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x30, Type: StructProperty)
    FAxis TwistPlaneNormalAxis() const { return Read<FAxis>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x20, Type: StructProperty)
    float RangeMax() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    float RemappedMin() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    float RemappedMax() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    FName CurveName() const { return Read<FName>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: NameProperty)

    void SET_BaseFrame(const FReferenceBoneFrame& Value) { Write<FReferenceBoneFrame>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x30, Type: StructProperty)
    void SET_TwistFrame(const FReferenceBoneFrame& Value) { Write<FReferenceBoneFrame>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x30, Type: StructProperty)
    void SET_TwistPlaneNormalAxis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x20, Type: StructProperty)
    void SET_RangeMax(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_RemappedMin(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_RemappedMax(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: NameProperty)
};

// Size: 0x260
struct FAnimNode_TwoBoneIK : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference IKBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    double StartStretchRatio() const { return Read<double>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double MaxStretchScale() const { return Read<double>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    FVector EffectorLocation() const { return Read<FVector>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)
    FBoneSocketTarget EffectorTarget() const { return Read<FBoneSocketTarget>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x80, Type: StructProperty)
    FVector JointTargetLocation() const { return Read<FVector>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x18, Type: StructProperty)
    FBoneSocketTarget JointTarget() const { return Read<FBoneSocketTarget>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x80, Type: StructProperty)
    FAxis TwistAxis() const { return Read<FAxis>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> EffectorLocationSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> JointTargetLocationSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x251); } // 0x251 (Size: 0x1, Type: ByteProperty)
    bool bAllowStretching() const { return (Read<uint8_t>(uintptr_t(this) + 0x252) >> 0x0) & 1; } // 0x252:0 (Size: 0x1, Type: BoolProperty)
    bool bTakeRotationFromEffectorSpace() const { return (Read<uint8_t>(uintptr_t(this) + 0x252) >> 0x1) & 1; } // 0x252:1 (Size: 0x1, Type: BoolProperty)
    bool bMaintainEffectorRelRot() const { return (Read<uint8_t>(uintptr_t(this) + 0x252) >> 0x2) & 1; } // 0x252:2 (Size: 0x1, Type: BoolProperty)
    bool bAllowTwist() const { return (Read<uint8_t>(uintptr_t(this) + 0x252) >> 0x3) & 1; } // 0x252:3 (Size: 0x1, Type: BoolProperty)

    void SET_IKBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_StartStretchRatio(const double& Value) { Write<double>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxStretchScale(const double& Value) { Write<double>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    void SET_EffectorLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
    void SET_EffectorTarget(const FBoneSocketTarget& Value) { Write<FBoneSocketTarget>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x80, Type: StructProperty)
    void SET_JointTargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x18, Type: StructProperty)
    void SET_JointTarget(const FBoneSocketTarget& Value) { Write<FBoneSocketTarget>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x80, Type: StructProperty)
    void SET_TwistAxis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x20, Type: StructProperty)
    void SET_EffectorLocationSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x1, Type: ByteProperty)
    void SET_JointTargetLocationSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x251, Value); } // 0x251 (Size: 0x1, Type: ByteProperty)
    void SET_bAllowStretching(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x252); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x252, B); } // 0x252:0 (Size: 0x1, Type: BoolProperty)
    void SET_bTakeRotationFromEffectorSpace(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x252); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x252, B); } // 0x252:1 (Size: 0x1, Type: BoolProperty)
    void SET_bMaintainEffectorRelRot(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x252); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x252, B); } // 0x252:2 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowTwist(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x252); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x252, B); } // 0x252:3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FIKFootPelvisPullDownSolver
{
public:
    FVectorRK4SpringInterpolator PelvisAdjustmentInterp() const { return Read<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    double PelvisAdjustmentInterpAlpha() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    double PelvisAdjustmentMaxDistance() const { return Read<double>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    double PelvisAdjustmentErrorTolerance() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    int32_t PelvisAdjustmentMaxIter() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)

    void SET_PelvisAdjustmentInterp(const FVectorRK4SpringInterpolator& Value) { Write<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_PelvisAdjustmentInterpAlpha(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_PelvisAdjustmentMaxDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    void SET_PelvisAdjustmentErrorTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    void SET_PelvisAdjustmentMaxIter(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FWarpingVectorValue
{
public:
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x10
struct FLayeredBoneBlendReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FLinkedAnimGraphReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FMirrorAnimNodeReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FModifyCurveAnimNodeReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FRBFEntry
{
public:
    TArray<float> Values() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Values(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FRBFTarget : public FRBFEntry
{
public:
    float ScaleFactor() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bApplyCustomCurve() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    FRichCurve CustomCurve() const { return Read<FRichCurve>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x80, Type: StructProperty)
    uint8_t DistanceMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t FunctionType() const { return Read<uint8_t>(uintptr_t(this) + 0x99); } // 0x99 (Size: 0x1, Type: EnumProperty)

    void SET_ScaleFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_bApplyCustomCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_CustomCurve(const FRichCurve& Value) { Write<FRichCurve>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x80, Type: StructProperty)
    void SET_DistanceMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: EnumProperty)
    void SET_FunctionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x99, Value); } // 0x99 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FSequenceEvaluatorReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FSequencePlayerReference : public FAnimNodeReference
{
public:
};

// Size: 0x10
struct FSkeletalControlReference : public FAnimNodeReference
{
public:
};

