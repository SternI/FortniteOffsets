/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortNPCCharacterMovieSceneBindings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "VerseFortniteAI.h"
#include "CoreUObject.h"

// Size: 0x68
class UFortGameFeatureAction_SetSeqNPCClasses : public UGameFeatureAction
{
public:
};

// Size: 0x48
class UFortNPCCharacterMovieSceneReplaceableBinding : public UMovieSceneReplaceableActorBinding
{
public:
    TSoftObjectPtr<UNPCCharacterDefinition> CharacterDefinition() const { return Read<TSoftObjectPtr<UNPCCharacterDefinition>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_CharacterDefinition(const TSoftObjectPtr<UNPCCharacterDefinition>& Value) { Write<TSoftObjectPtr<UNPCCharacterDefinition>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0xa8
class UFortNPCCharacterMovieSceneSpawnableBinding : public UMovieSceneSpawnableActorBindingBase
{
public:
    TSoftObjectPtr<UNPCCharacterDefinition> CharacterDefinition() const { return Read<TSoftObjectPtr<UNPCCharacterDefinition>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    UClass* SpawnableActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ClassProperty)
    TArray<UObject*> LoadedObjects() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)

    void SET_CharacterDefinition(const TSoftObjectPtr<UNPCCharacterDefinition>& Value) { Write<TSoftObjectPtr<UNPCCharacterDefinition>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SpawnableActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ClassProperty)
    void SET_LoadedObjects(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
};

