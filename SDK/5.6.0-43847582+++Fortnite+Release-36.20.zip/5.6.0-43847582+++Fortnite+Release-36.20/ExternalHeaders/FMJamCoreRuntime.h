/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0xc8
class UJamControllerComponent_QuestPersistence : public UFortControllerComponent_QuestPersistence
{
public:
};

// Size: 0xc0
class UJamOverrides : public UGameStateComponent
{
public:
    UClass* JamVolume() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)

    void SET_JamVolume(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
class UJamCoreBPFL : public UBlueprintFunctionLibrary
{
public:
};

