/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EnergyRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0xa8
class UFortEnergyAttrSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData MaxEnergy() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData RechargeAmountPerSecond() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData EnergyUsageMultiplier() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)

    void SET_MaxEnergy(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_RechargeAmountPerSecond(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
    void SET_EnergyUsageMultiplier(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
};

// Size: 0x3e8
class UFortComponent_Energy : public UPawnComponent
{
public:
    FGameplayAttribute MaxEnergyAttribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x38, Type: StructProperty)
    FScalableFloat MaxEnergy() const { return Read<FScalableFloat>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery RechargeDisabledQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery EnergyUseDisabledQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x48, Type: StructProperty)
    FTimerHandle BeginRechargeTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer EnergyTypeIdentifierTagContainer() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x20, Type: StructProperty)
    float CurrentEnergy() const { return Read<float>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: FloatProperty)
    float CachedMaxEnergy() const { return Read<float>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: FloatProperty)
    float NetEnergyDeltaPerSecond() const { return Read<float>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: FloatProperty)
    FScalableFloat MinEnergyForUsing() const { return Read<FScalableFloat>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x28, Type: StructProperty)
    FGameplayAttribute RechargeAmountPerSecondAttribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x38, Type: StructProperty)
    FScalableFloat RechargeAmountPerSecond() const { return Read<FScalableFloat>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x28, Type: StructProperty)
    FScalableFloat RechargeDelayInSeconds() const { return Read<FScalableFloat>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x28, Type: StructProperty)
    FScalableFloat RechargePercentageLimit() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x28, Type: StructProperty)
    FGameplayAttribute EnergyUsageMultiplierAttribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x38, Type: StructProperty)
    FScalableFloat EnergyUsageMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x28, Type: StructProperty)
    bool bRemoveEnergyUsersWhenEmpty() const { return Read<bool>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: BoolProperty)
    TArray<FEnergyChannelingData> ActiveEnergyChannels() const { return Read<TArray<FEnergyChannelingData>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    TArray<FEnergyChannelingData> NewActiveEnergyChannels() const { return Read<TArray<FEnergyChannelingData>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: ArrayProperty)
    TArray<FEnergyRegenOverrideData> EnergyRegenOverrides() const { return Read<TArray<FEnergyRegenOverrideData>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x10, Type: ArrayProperty)
    bool bRechargingEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x3e0) >> 0x0) & 1; } // 0x3e0:0 (Size: 0x1, Type: BoolProperty)
    bool bIsRecharging() const { return (Read<uint8_t>(uintptr_t(this) + 0x3e0) >> 0x1) & 1; } // 0x3e0:1 (Size: 0x1, Type: BoolProperty)
    bool bIsUsingEnergy() const { return (Read<uint8_t>(uintptr_t(this) + 0x3e0) >> 0x2) & 1; } // 0x3e0:2 (Size: 0x1, Type: BoolProperty)
    bool bAllowEditMaxEnergyScalableFloat() const { return (Read<uint8_t>(uintptr_t(this) + 0x3e0) >> 0x4) & 1; } // 0x3e0:4 (Size: 0x1, Type: BoolProperty)
    bool bAllowEditRechargeAmountPerSecondScalableFloat() const { return (Read<uint8_t>(uintptr_t(this) + 0x3e0) >> 0x5) & 1; } // 0x3e0:5 (Size: 0x1, Type: BoolProperty)
    bool bAllowEditEnergyUsageMultiplierScalableFloat() const { return (Read<uint8_t>(uintptr_t(this) + 0x3e0) >> 0x6) & 1; } // 0x3e0:6 (Size: 0x1, Type: BoolProperty)

    void SET_MaxEnergyAttribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x38, Type: StructProperty)
    void SET_MaxEnergy(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
    void SET_RechargeDisabledQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x48, Type: StructProperty)
    void SET_EnergyUseDisabledQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x48, Type: StructProperty)
    void SET_BeginRechargeTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: StructProperty)
    void SET_EnergyTypeIdentifierTagContainer(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x20, Type: StructProperty)
    void SET_CurrentEnergy(const float& Value) { Write<float>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: FloatProperty)
    void SET_CachedMaxEnergy(const float& Value) { Write<float>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: FloatProperty)
    void SET_NetEnergyDeltaPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: FloatProperty)
    void SET_MinEnergyForUsing(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x28, Type: StructProperty)
    void SET_RechargeAmountPerSecondAttribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x38, Type: StructProperty)
    void SET_RechargeAmountPerSecond(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x28, Type: StructProperty)
    void SET_RechargeDelayInSeconds(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x28, Type: StructProperty)
    void SET_RechargePercentageLimit(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x28, Type: StructProperty)
    void SET_EnergyUsageMultiplierAttribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x38, Type: StructProperty)
    void SET_EnergyUsageMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x28, Type: StructProperty)
    void SET_bRemoveEnergyUsersWhenEmpty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: BoolProperty)
    void SET_ActiveEnergyChannels(const TArray<FEnergyChannelingData>& Value) { Write<TArray<FEnergyChannelingData>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    void SET_NewActiveEnergyChannels(const TArray<FEnergyChannelingData>& Value) { Write<TArray<FEnergyChannelingData>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: ArrayProperty)
    void SET_EnergyRegenOverrides(const TArray<FEnergyRegenOverrideData>& Value) { Write<TArray<FEnergyRegenOverrideData>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x10, Type: ArrayProperty)
    void SET_bRechargingEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3e0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x3e0, B); } // 0x3e0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsRecharging(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3e0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x3e0, B); } // 0x3e0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsUsingEnergy(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3e0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x3e0, B); } // 0x3e0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowEditMaxEnergyScalableFloat(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3e0); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x3e0, B); } // 0x3e0:4 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowEditRechargeAmountPerSecondScalableFloat(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3e0); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x3e0, B); } // 0x3e0:5 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowEditEnergyUsageMultiplierScalableFloat(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x3e0); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x3e0, B); } // 0x3e0:6 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FEnergyChannelingData
{
public:
    float EnergyPerSecond() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FGameplayTag EnergyChannelingPurposeIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    UObject* OptionalEnergyChannelingSource() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bShouldStopApplyingNextTick() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_EnergyPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EnergyChannelingPurposeIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_OptionalEnergyChannelingSource(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldStopApplyingNextTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FEnergyRegenOverrideData
{
public:
    FGameplayTag EnergyRegenIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float RechargeAmountPerSecond() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float RechargeDelayInSeconds() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float RechargePercentageLimit() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_EnergyRegenIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_RechargeAmountPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_RechargeDelayInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_RechargePercentageLimit(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

