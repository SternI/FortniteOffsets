/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityRegistry
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xc8
class UEntityContainer : public UObject
{
public:
};

// Size: 0x30
class UEntityRegistry : public UEntityRegistryBase
{
public:
};

