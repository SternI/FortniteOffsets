/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicBacchusHUD
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DynamicUI.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "FortniteUI.h"

// Size: 0xd8
class UAthenaTouchHUDDirectorComponent : public UDynamicBacchusHUDDirectorComponent
{
public:
};

// Size: 0xd8
class UDynamicBacchusHUDDirectorComponent : public UActorComponent
{
public:
};

// Size: 0x520
class ADynamicBacchusHUDDirector : public ADynamicUIDirectorBase
{
public:
    FDynamicUIAllowed TouchControlRegionAllowed() const { return Read<FDynamicUIAllowed>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x78, Type: StructProperty)
    UDynamicUIExcludeInputType* HUDSwitchExcludeConditions() const { return Read<UDynamicUIExcludeInputType*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UFortMobileHUDWidgetRegistry* BaseHUDWidgetRegistry() const { return Read<UFortMobileHUDWidgetRegistry*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayTag, UDynamicUIMobileScene*> ScenesPool() const { return Read<TMap<FGameplayTag, UDynamicUIMobileScene*>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x50, Type: MapProperty)
    UFortMobileHUDWidgetRegistry* HUDWidgetRegistry() const { return Read<UFortMobileHUDWidgetRegistry*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayTagQuery> UnallowedHUDWidgetTagQueries() const { return Read<TArray<FGameplayTagQuery>>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer CurrentContextTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x20, Type: StructProperty)
    FFortMobileHUDLayoutProfile LayoutProfile() const { return Read<FFortMobileHUDLayoutProfile>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x38, Type: StructProperty)
    FGameplayTagContainer UnallowedHUDContextTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x20, Type: StructProperty)
    FText ForcedPresetName() const { return Read<FText>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x10, Type: TextProperty)
    FGameplayTag ForcedProfile() const { return Read<FGameplayTag>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x4, Type: StructProperty)
    FGameplayTag ForcedProfileContainer() const { return Read<FGameplayTag>(uintptr_t(this) + 0x51c); } // 0x51c (Size: 0x4, Type: StructProperty)

    void SET_TouchControlRegionAllowed(const FDynamicUIAllowed& Value) { Write<FDynamicUIAllowed>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x78, Type: StructProperty)
    void SET_HUDSwitchExcludeConditions(const UDynamicUIExcludeInputType*& Value) { Write<UDynamicUIExcludeInputType*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_BaseHUDWidgetRegistry(const UFortMobileHUDWidgetRegistry*& Value) { Write<UFortMobileHUDWidgetRegistry*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_ScenesPool(const TMap<FGameplayTag, UDynamicUIMobileScene*>& Value) { Write<TMap<FGameplayTag, UDynamicUIMobileScene*>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x50, Type: MapProperty)
    void SET_HUDWidgetRegistry(const UFortMobileHUDWidgetRegistry*& Value) { Write<UFortMobileHUDWidgetRegistry*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_UnallowedHUDWidgetTagQueries(const TArray<FGameplayTagQuery>& Value) { Write<TArray<FGameplayTagQuery>>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentContextTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x20, Type: StructProperty)
    void SET_LayoutProfile(const FFortMobileHUDLayoutProfile& Value) { Write<FFortMobileHUDLayoutProfile>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x38, Type: StructProperty)
    void SET_UnallowedHUDContextTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x20, Type: StructProperty)
    void SET_ForcedPresetName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x10, Type: TextProperty)
    void SET_ForcedProfile(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x4, Type: StructProperty)
    void SET_ForcedProfileContainer(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x51c, Value); } // 0x51c (Size: 0x4, Type: StructProperty)
};

// Size: 0x130
class UDynamicUIMobileScene : public UDynamicUIScene
{
public:
};

