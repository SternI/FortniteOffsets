/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnnoyedMopGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"
#include "Niagara.h"

// Size: 0x1350
class UAnnoyedMopPlayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bIsActionInput() const { return (Read<uint8_t>(uintptr_t(this) + 0x1308) >> 0x0) & 1; } // 0x1308:0 (Size: 0x1, Type: BoolProperty)
    bool bIsJumpAOELand() const { return (Read<uint8_t>(uintptr_t(this) + 0x1308) >> 0x1) & 1; } // 0x1308:1 (Size: 0x1, Type: BoolProperty)
    bool bIsJumpAOEStart() const { return (Read<uint8_t>(uintptr_t(this) + 0x1308) >> 0x2) & 1; } // 0x1308:2 (Size: 0x1, Type: BoolProperty)
    bool bIsInAirAttack() const { return (Read<uint8_t>(uintptr_t(this) + 0x1308) >> 0x3) & 1; } // 0x1308:3 (Size: 0x1, Type: BoolProperty)
    bool bIsCombo04() const { return (Read<uint8_t>(uintptr_t(this) + 0x1308) >> 0x4) & 1; } // 0x1308:4 (Size: 0x1, Type: BoolProperty)
    bool bIsInAirAttackLanding() const { return (Read<uint8_t>(uintptr_t(this) + 0x1308) >> 0x5) & 1; } // 0x1308:5 (Size: 0x1, Type: BoolProperty)
    float Combo04AOAlpha() const { return Read<float>(uintptr_t(this) + 0x130c); } // 0x130c (Size: 0x4, Type: FloatProperty)
    FName CurveName_UserCurve01() const { return Read<FName>(uintptr_t(this) + 0x1310); } // 0x1310 (Size: 0x4, Type: NameProperty)
    FName CurveName_UserCurve02() const { return Read<FName>(uintptr_t(this) + 0x1314); } // 0x1314 (Size: 0x4, Type: NameProperty)
    FString MontageName_AnnoyedMop_InAirAttack_M() const { return Read<FString>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x10, Type: StrProperty)
    FString MontageName_Combo_04() const { return Read<FString>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x10, Type: StrProperty)
    FGameplayTag Granted_Athena_Power_ActivePower_IsActive_Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x4, Type: StructProperty)
    FGameplayTag MovementMode_Falling_Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x133c); } // 0x133c (Size: 0x4, Type: StructProperty)

    void SET_bIsActionInput(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1308); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1308, B); } // 0x1308:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsJumpAOELand(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1308); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1308, B); } // 0x1308:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsJumpAOEStart(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1308); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1308, B); } // 0x1308:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInAirAttack(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1308); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1308, B); } // 0x1308:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCombo04(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1308); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1308, B); } // 0x1308:4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInAirAttackLanding(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1308); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x1308, B); } // 0x1308:5 (Size: 0x1, Type: BoolProperty)
    void SET_Combo04AOAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x130c, Value); } // 0x130c (Size: 0x4, Type: FloatProperty)
    void SET_CurveName_UserCurve01(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1310, Value); } // 0x1310 (Size: 0x4, Type: NameProperty)
    void SET_CurveName_UserCurve02(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1314, Value); } // 0x1314 (Size: 0x4, Type: NameProperty)
    void SET_MontageName_AnnoyedMop_InAirAttack_M(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x10, Type: StrProperty)
    void SET_MontageName_Combo_04(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x10, Type: StrProperty)
    void SET_Granted_Athena_Power_ActivePower_IsActive_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x4, Type: StructProperty)
    void SET_MovementMode_Falling_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x133c, Value); } // 0x133c (Size: 0x4, Type: StructProperty)
};

// Size: 0xb88
class AFortProjectileAnnoyedMop : public AFortProjectileBase
{
public:
    float currentScale() const { return Read<float>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x4, Type: FloatProperty)

    void SET_currentScale(const float& Value) { Write<float>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x4, Type: FloatProperty)
};

