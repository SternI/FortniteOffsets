/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCommunicationUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CreativeCommunicationRuntime.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "FortniteUI.h"

// Size: 0xe8
class UCreativeBubbleChatMessageViewModel : public UFortTextChatMessageVM
{
public:
    bool IsWhisper() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)

    void SET_IsWhisper(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb8
class UCreativeBubbleChatViewModel : public UFortTextChatPlayerBaseVM
{
public:
    TWeakObjectPtr<AFortPlayerStateAthena*> TargetPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerStateAthena*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: WeakObjectProperty)
    TArray<UCreativeBubbleChatMessageViewModel*> Messages() const { return Read<TArray<UCreativeBubbleChatMessageViewModel*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    FText Message() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)

    void SET_TargetPlayerState(const TWeakObjectPtr<AFortPlayerStateAthena*>& Value) { Write<TWeakObjectPtr<AFortPlayerStateAthena*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Messages(const TArray<UCreativeBubbleChatMessageViewModel*>& Value) { Write<TArray<UCreativeBubbleChatMessageViewModel*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_Message(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
};

// Size: 0x108
class UCreativePlayerStateComponent_UIViewModels : public UPlayerStateComponent
{
public:
};

// Size: 0x428
class UCreativeIndicatorLayerManagerWidget : public UFortHUDElementWidget
{
public:
    int32_t PlayerIndicatorPoolSize() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)
    FUserWidgetPool IndicatorPool() const { return Read<FUserWidgetPool>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x88, Type: StructProperty)
    UCreativeLocalPlayerViewModel* LocalPlayerViewModel() const { return Read<UCreativeLocalPlayerViewModel*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    UClass* PlayerIndicatorClass() const { return Read<UClass*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ClassProperty)
    UFortActorCanvas* PlayerIndicators() const { return Read<UFortActorCanvas*>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    bool ShowIndicatorForLocalPlayer() const { return Read<bool>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x1, Type: BoolProperty)

    void SET_PlayerIndicatorPoolSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
    void SET_IndicatorPool(const FUserWidgetPool& Value) { Write<FUserWidgetPool>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x88, Type: StructProperty)
    void SET_LocalPlayerViewModel(const UCreativeLocalPlayerViewModel*& Value) { Write<UCreativeLocalPlayerViewModel*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerIndicatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ClassProperty)
    void SET_PlayerIndicators(const UFortActorCanvas*& Value) { Write<UFortActorCanvas*>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    void SET_ShowIndicatorForLocalPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd8
class UCreativeLocalPlayerViewModel : public UFortPerUserViewModel
{
public:
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedGameMemberPlayerStates() const { return Read<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedTeammatePlayerStates() const { return Read<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedSquadMemberPlayerStates() const { return Read<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedPartyMemberPlayerStates() const { return Read<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedGameMemberPlayerStates(const TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedTeammatePlayerStates(const TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedSquadMemberPlayerStates(const TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedPartyMemberPlayerStates(const TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerStateAthena*>>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x460
class UCreativePlayerIndicatorWidget : public UFortActorIndicatorWidget
{
public:
    float MinDistanceToDisplayInfo() const { return Read<float>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x4, Type: FloatProperty)
    UCommonTextBlock* Text_Distance() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCreativeGameStateComponent_CommunicationOverride* CachedCreativeCommunicationOverride() const { return Read<UCreativeGameStateComponent_CommunicationOverride*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)

    void SET_MinDistanceToDisplayInfo(const float& Value) { Write<float>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x4, Type: FloatProperty)
    void SET_Text_Distance(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedCreativeCommunicationOverride(const UCreativeGameStateComponent_CommunicationOverride*& Value) { Write<UCreativeGameStateComponent_CommunicationOverride*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
};

