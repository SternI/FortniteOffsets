/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowSimulation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DataflowEngine.h"

// Size: 0x28
class UDataflowCollisionObjectInterface : public UDataflowSimulationInterface
{
public:
};

// Size: 0x28
class UDataflowSimulationInterface : public UInterface
{
public:
};

// Size: 0x28
class UDataflowConstraintObjectInterface : public UDataflowSimulationInterface
{
public:
};

// Size: 0x28
class UDataflowGeometryCachable : public UInterface
{
public:
};

// Size: 0x28
class UDataflowPhysicsObjectInterface : public UDataflowSimulationInterface
{
public:
};

// Size: 0x28
class UDataflowPhysicsSolverInterface : public UDataflowSimulationInterface
{
public:
};

// Size: 0xa8
class UDataflowSimulationManager : public UTickableWorldSubsystem
{
public:
};

// Size: 0x28
class UDataflowSimulationActor : public UInterface
{
public:
};

// Size: 0x78
struct FDataflowSimulationProxy
{
public:
};

// Size: 0x78
struct FDataflowCollisionObjectProxy : public FDataflowSimulationProxy
{
public:
};

// Size: 0x78
struct FDataflowConstraintObjectProxy : public FDataflowSimulationProxy
{
public:
};

// Size: 0x78
struct FDataflowPhysicsObjectProxy : public FDataflowSimulationProxy
{
public:
};

// Size: 0x78
struct FDataflowPhysicsSolverProxy : public FDataflowSimulationProxy
{
public:
};

// Size: 0x58
struct FDataflowSimulationAsset
{
public:
    UDataflow* DataflowAsset() const { return Read<UDataflow*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TSet<FString> SimulationGroups() const { return Read<TSet<FString>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: SetProperty)

    void SET_DataflowAsset(const UDataflow*& Value) { Write<UDataflow*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SimulationGroups(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: SetProperty)
};

// Size: 0x8
struct FDataflowSimulationProperty
{
public:
};

// Size: 0x280
struct FDataflowSimulationNode : public FDataflowNode
{
public:
};

// Size: 0x280
struct FDataflowInvalidNode : public FDataflowSimulationNode
{
public:
};

// Size: 0x280
struct FDataflowExecutionNode : public FDataflowSimulationNode
{
public:
};

// Size: 0xc
struct FDataflowSimulationTime
{
public:
    float DeltaTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float CurrentTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float TimeOffset() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_DeltaTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TimeOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x290
struct FGetSimulationTimeDataflowNode : public FDataflowInvalidNode
{
public:
    FDataflowSimulationTime SimulationTime() const { return Read<FDataflowSimulationTime>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0xc, Type: StructProperty)

    void SET_SimulationTime(const FDataflowSimulationTime& Value) { Write<FDataflowSimulationTime>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0xc, Type: StructProperty)
};

// Size: 0x2a0
struct FGetPhysicsSolversDataflowNode : public FDataflowInvalidNode
{
public:
    TArray<FDataflowSimulationProperty> PhysicsSolvers() const { return Read<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SimulationGroups() const { return Read<TArray<FString>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: ArrayProperty)

    void SET_PhysicsSolvers(const TArray<FDataflowSimulationProperty>& Value) { Write<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    void SET_SimulationGroups(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2a0
struct FAdvancePhysicsSolversDataflowNode : public FDataflowSimulationNode
{
public:
    FDataflowSimulationTime SimulationTime() const { return Read<FDataflowSimulationTime>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0xc, Type: StructProperty)
    TArray<FDataflowSimulationProperty> PhysicsSolvers() const { return Read<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: ArrayProperty)

    void SET_SimulationTime(const FDataflowSimulationTime& Value) { Write<FDataflowSimulationTime>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0xc, Type: StructProperty)
    void SET_PhysicsSolvers(const TArray<FDataflowSimulationProperty>& Value) { Write<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2b0
struct FFilterSimulationProxiesDataflowNode : public FDataflowSimulationNode
{
public:
    TArray<FDataflowSimulationProperty> SimulationProxies() const { return Read<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    TArray<FDataflowSimulationProperty> FilteredProxies() const { return Read<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SimulationGroups() const { return Read<TArray<FString>>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x10, Type: ArrayProperty)

    void SET_SimulationProxies(const TArray<FDataflowSimulationProperty>& Value) { Write<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    void SET_FilteredProxies(const TArray<FDataflowSimulationProperty>& Value) { Write<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: ArrayProperty)
    void SET_SimulationGroups(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x290
struct FSimulationProxiesTerminalDataflowNode : public FDataflowExecutionNode
{
public:
    TArray<FDataflowSimulationProperty> SimulationProxies() const { return Read<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)

    void SET_SimulationProxies(const TArray<FDataflowSimulationProperty>& Value) { Write<TArray<FDataflowSimulationProperty>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
};

