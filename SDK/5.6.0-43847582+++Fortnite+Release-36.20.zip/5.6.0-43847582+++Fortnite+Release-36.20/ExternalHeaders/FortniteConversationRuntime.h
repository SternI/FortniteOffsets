/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteConversationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonConversationRuntime.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "PlayspaceSystem.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28
class UFortConversationGetGraphInterface : public UInterface
{
public:
};

// Size: 0x28
class UFortConversationMarkerInterface : public UInterface
{
public:
};

// Size: 0x1a8
class UFortConversationParticipantComponent : public UConversationParticipantComponent
{
public:
};

// Size: 0x28
class UFortConversationContextCondition : public UObject
{
public:
};

// Size: 0x40
class UFortConversationContextCondition_ParticipantHasCID : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    TArray<FSoftObjectPath> AllowedCIDs() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_ParticipantID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_AllowedCIDs(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
class UFortConversationContextCondition_ParticipantHasMetaTag : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FGameplayTag MetaTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)

    void SET_ParticipantID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_MetaTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
};

// Size: 0x30
class UFortConversationContextCondition_ParticipantHasOwnedTag : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FGameplayTag OwnedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)

    void SET_ParticipantID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_OwnedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
class UFortConversationContextCondition_ParticipantControllerMeetsRequirement : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    UFortControllerRequirement* Requirement() const { return Read<UFortControllerRequirement*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_ParticipantID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_Requirement(const UFortControllerRequirement*& Value) { Write<UFortControllerRequirement*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UFortConversationContextConditionHelpers : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UFortConversationParamLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UFortniteConversationGlobals : public UObject
{
public:
};

// Size: 0x3f0
class UFortPlayerConversationComponent : public UFortConversationParticipantComponent
{
public:
    TArray<UFortNonPlayerConversationParticipantComponent*> ConversationParticipantsInRange() const { return Read<TArray<UFortNonPlayerConversationParticipantComponent*>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    float GreetSphereRadius() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float IconVisibilityRadius() const { return Read<float>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    float AbortConversationRange() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    FGameplayTag RidingOnActorTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: StructProperty)
    float RidingOnActorRangeMultiplierSquared() const { return Read<float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    TSet<UFortNonPlayerConversationParticipantComponent*> IndicatedNPCConversationComponents() const { return Read<TSet<UFortNonPlayerConversationParticipantComponent*>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x50, Type: SetProperty)
    bool bMoveShouldAbortConversation() const { return Read<bool>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: BoolProperty)
    bool bCachedDefaultMoveShouldAbortConverationValue() const { return Read<bool>(uintptr_t(this) + 0x269); } // 0x269 (Size: 0x1, Type: BoolProperty)
    FClientConversationMessagePayload LastSanitizationMessage() const { return Read<FClientConversationMessagePayload>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x68, Type: StructProperty)

    void SET_ConversationParticipantsInRange(const TArray<UFortNonPlayerConversationParticipantComponent*>& Value) { Write<TArray<UFortNonPlayerConversationParticipantComponent*>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    void SET_GreetSphereRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_IconVisibilityRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    void SET_AbortConversationRange(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    void SET_RidingOnActorTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: StructProperty)
    void SET_RidingOnActorRangeMultiplierSquared(const float& Value) { Write<float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    void SET_IndicatedNPCConversationComponents(const TSet<UFortNonPlayerConversationParticipantComponent*>& Value) { Write<TSet<UFortNonPlayerConversationParticipantComponent*>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x50, Type: SetProperty)
    void SET_bMoveShouldAbortConversation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: BoolProperty)
    void SET_bCachedDefaultMoveShouldAbortConverationValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x269, Value); } // 0x269 (Size: 0x1, Type: BoolProperty)
    void SET_LastSanitizationMessage(const FClientConversationMessagePayload& Value) { Write<FClientConversationMessagePayload>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x68, Type: StructProperty)
};

// Size: 0x8
struct FFortConversationEnterEvent
{
public:
    APlayerController* PlayerController() const { return Read<APlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FFortConversationLeaveEvent
{
public:
    APlayerController* PlayerController() const { return Read<APlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1
struct FFortConversation_Spectator_EnterConversation
{
public:
};

// Size: 0x1
struct FFortConversation_Spectator_LeaveConversation
{
public:
};

// Size: 0x1
struct FFortConversation_SetDialogMarkerClassEvent
{
public:
};

// Size: 0x8
struct FNPCConversationIndicatorMessage
{
public:
    UFortNonPlayerConversationParticipantComponent* NPCConversationComponent() const { return Read<UFortNonPlayerConversationParticipantComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_NPCConversationComponent(const UFortNonPlayerConversationParticipantComponent*& Value) { Write<UFortNonPlayerConversationParticipantComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FFortConversation_NPC_AddIndicator : public FNPCConversationIndicatorMessage
{
public:
};

// Size: 0x8
struct FFortConversation_NPC_RemoveIndicator : public FNPCConversationIndicatorMessage
{
public:
};

// Size: 0x20
struct FConversationSettingDialogMarkerData
{
public:
};

// Size: 0x18
struct FFortConversationConditionalMessage
{
public:
    UFortConversationContextCondition* Condition() const { return Read<UFortConversationContextCondition*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FText Message() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)

    void SET_Condition(const UFortConversationContextCondition*& Value) { Write<UFortConversationContextCondition*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Message(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
};

// Size: 0x10
struct FFortConversationNodeConditionalMessages
{
public:
    TArray<FFortConversationConditionalMessage> Messages() const { return Read<TArray<FFortConversationConditionalMessage>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Messages(const TArray<FFortConversationConditionalMessage>& Value) { Write<TArray<FFortConversationConditionalMessage>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

