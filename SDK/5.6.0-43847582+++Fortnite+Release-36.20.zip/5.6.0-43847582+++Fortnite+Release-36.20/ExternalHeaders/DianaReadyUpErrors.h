/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaReadyUpErrors
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x38
class UDianaPlayerWarning : public UFortLocalPlayerSubsystem
{
public:
};

// Size: 0x30
class UDianaReadyUpErrorsExtension : public UReadyUpErrorsExtension
{
public:
};

