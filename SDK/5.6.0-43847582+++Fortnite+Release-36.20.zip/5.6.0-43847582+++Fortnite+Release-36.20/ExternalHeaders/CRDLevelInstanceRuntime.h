/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDLevelInstanceRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x368
class AFortAthenaMutator_LevelInstanceDevice : public AFortAthenaMutator
{
public:
    TWeakObjectPtr<ALevelInstanceGameplayVolume*> CachedGameplayVolume() const { return Read<TWeakObjectPtr<ALevelInstanceGameplayVolume*>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedGameplayVolume(const TWeakObjectPtr<ALevelInstanceGameplayVolume*>& Value) { Write<TWeakObjectPtr<ALevelInstanceGameplayVolume*>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x500
class ALevelInstanceGameplayVolume : public AGameplayVolume
{
public:
    bool bEditMode() const { return Read<bool>(uintptr_t(this) + 0x3e1); } // 0x3e1 (Size: 0x1, Type: BoolProperty)
    bool bDisabled() const { return Read<bool>(uintptr_t(this) + 0x3e2); } // 0x3e2 (Size: 0x1, Type: BoolProperty)
    uint8_t LoadingState() const { return Read<uint8_t>(uintptr_t(this) + 0x3e3); } // 0x3e3 (Size: 0x1, Type: EnumProperty)
    FString LevelInstanceName() const { return Read<FString>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x10, Type: StrProperty)
    bool bInstanceLoaded() const { return Read<bool>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x1, Type: BoolProperty)
    bool bWantsLevelLoaded() const { return Read<bool>(uintptr_t(this) + 0x3f9); } // 0x3f9 (Size: 0x1, Type: BoolProperty)
    bool bConvertStructuresToProps() const { return Read<bool>(uintptr_t(this) + 0x3fb); } // 0x3fb (Size: 0x1, Type: BoolProperty)
    AFortMinigame* CachedMinigame() const { return Read<AFortMinigame*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    UFortMutatorListComponent* MutatorListComponent() const { return Read<UFortMutatorListComponent*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    UFortClassTrackerComponent* ClassFilterComponent() const { return Read<UFortClassTrackerComponent*>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> BlacklistedClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x10, Type: ArrayProperty)
    FGuid LevelInstanceSaveActorGuid() const { return Read<FGuid>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x10, Type: StructProperty)
    AFortLevelInstanceSaveActor* LevelInstanceSaveActor() const { return Read<AFortLevelInstanceSaveActor*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)

    void SET_bEditMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e1, Value); } // 0x3e1 (Size: 0x1, Type: BoolProperty)
    void SET_bDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e2, Value); } // 0x3e2 (Size: 0x1, Type: BoolProperty)
    void SET_LoadingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3e3, Value); } // 0x3e3 (Size: 0x1, Type: EnumProperty)
    void SET_LevelInstanceName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x10, Type: StrProperty)
    void SET_bInstanceLoaded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x1, Type: BoolProperty)
    void SET_bWantsLevelLoaded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f9, Value); } // 0x3f9 (Size: 0x1, Type: BoolProperty)
    void SET_bConvertStructuresToProps(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3fb, Value); } // 0x3fb (Size: 0x1, Type: BoolProperty)
    void SET_CachedMinigame(const AFortMinigame*& Value) { Write<AFortMinigame*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_MutatorListComponent(const UFortMutatorListComponent*& Value) { Write<UFortMutatorListComponent*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_ClassFilterComponent(const UFortClassTrackerComponent*& Value) { Write<UFortClassTrackerComponent*>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    void SET_BlacklistedClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x10, Type: ArrayProperty)
    void SET_LevelInstanceSaveActorGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x10, Type: StructProperty)
    void SET_LevelInstanceSaveActor(const AFortLevelInstanceSaveActor*& Value) { Write<AFortLevelInstanceSaveActor*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x148
class ULevelInstanceItemListComponent : public UFortMinigameItemContainerComponent
{
public:
};

