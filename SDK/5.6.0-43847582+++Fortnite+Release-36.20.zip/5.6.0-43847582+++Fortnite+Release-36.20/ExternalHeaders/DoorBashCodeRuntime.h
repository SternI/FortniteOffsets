/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DoorBashCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0xd68
class UFortGameplayAbility_DoorBash : public UFortGameplayAbility
{
public:
    FScalableFloat HF_DoorBashEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_ForwardDoorCheckMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_LaunchPawnImpulseMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_PawnVelocityMinThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_EndAbilityGracePeriod() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_DoorCheckPeriod() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_PawnLaunchOverlapRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_DelayNewDoorCheckTimerAfterSuccess() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x28, Type: StructProperty)
    UAnimMontage* DoorBashMale() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DoorBashFemale() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GC_DoorImpact() const { return Read<FGameplayTag>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x4, Type: StructProperty)
    FGameplayTag GC_LaunchPlayer() const { return Read<FGameplayTag>(uintptr_t(this) + 0xcbc); } // 0xcbc (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer AdditionalQuestSourceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x20, Type: StructProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> DoorCheckQueryTypes() const { return Read<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x10, Type: ArrayProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> PawnObjectQueryTypes() const { return Read<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag SkipAnimationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x4, Type: StructProperty)
    FGameplayTag AllowActionWithoutSprintTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd04); } // 0xd04 (Size: 0x4, Type: StructProperty)
    FGameplayTag EventDoorBashSuccessTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x4, Type: StructProperty)

    void SET_HF_DoorBashEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x28, Type: StructProperty)
    void SET_HF_ForwardDoorCheckMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x28, Type: StructProperty)
    void SET_HF_LaunchPawnImpulseMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    void SET_HF_PawnVelocityMinThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x28, Type: StructProperty)
    void SET_HF_EndAbilityGracePeriod(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x28, Type: StructProperty)
    void SET_HF_DoorCheckPeriod(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x28, Type: StructProperty)
    void SET_HF_PawnLaunchOverlapRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x28, Type: StructProperty)
    void SET_HF_DelayNewDoorCheckTimerAfterSuccess(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x28, Type: StructProperty)
    void SET_DoorBashMale(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    void SET_DoorBashFemale(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    void SET_GC_DoorImpact(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x4, Type: StructProperty)
    void SET_GC_LaunchPlayer(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xcbc, Value); } // 0xcbc (Size: 0x4, Type: StructProperty)
    void SET_AdditionalQuestSourceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x20, Type: StructProperty)
    void SET_DoorCheckQueryTypes(const TArray<TEnumAsByte<EObjectTypeQuery>>& Value) { Write<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnObjectQueryTypes(const TArray<TEnumAsByte<EObjectTypeQuery>>& Value) { Write<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x10, Type: ArrayProperty)
    void SET_SkipAnimationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x4, Type: StructProperty)
    void SET_AllowActionWithoutSprintTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd04, Value); } // 0xd04 (Size: 0x4, Type: StructProperty)
    void SET_EventDoorBashSuccessTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x4, Type: StructProperty)
};

