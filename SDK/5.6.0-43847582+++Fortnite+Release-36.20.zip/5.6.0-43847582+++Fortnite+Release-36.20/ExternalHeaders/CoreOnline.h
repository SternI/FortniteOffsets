/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoreOnline
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x10
struct FJoinabilitySettings
{
public:
    FName SessionName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bPublicSearchable() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bAllowInvites() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bJoinViaPresence() const { return Read<bool>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bJoinViaPresenceFriendsOnly() const { return Read<bool>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x1, Type: BoolProperty)
    int32_t MaxPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MaxPartySize() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_SessionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bPublicSearchable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowInvites(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_bJoinViaPresence(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: BoolProperty)
    void SET_bJoinViaPresenceFriendsOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x1, Type: BoolProperty)
    void SET_MaxPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_MaxPartySize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x1
struct FUniqueNetIdWrapper
{
public:
};

