/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicBacchusHUDCreativeComponentsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"

// Size: 0x100
class UDynamicBacchusHUDDirectorComponent_PlayerInfoOverride : public UDynamicBacchusHUDDirectorComponent
{
public:
    FGameplayTagContainer LocalPlayerInfoTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x20, Type: StructProperty)

    void SET_LocalPlayerInfoTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x20, Type: StructProperty)
};

