/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_SparksSettingsMarkup
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x38
class UBP_SparksSettingsMarkup_C : public UFortGameSettingRegistryMarkup
{
public:
};

