/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_HUDController
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DynamicUI.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "SlateCore.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayEventRouter.h"

// Size: 0xe0
class UCustomHUDLayoutComponent : public UActorComponent
{
public:
    char DynamicUISceneLayerID() const { return Read<char>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: ByteProperty)
    FGameplayEventListenerHandle LayoutChangeListenerHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x1c, Type: StructProperty)
    UDynamicUIScene* CachedScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)

    void SET_DynamicUISceneLayerID(const char& Value) { Write<char>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: ByteProperty)
    void SET_LayoutChangeListenerHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x1c, Type: StructProperty)
    void SET_CachedScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

