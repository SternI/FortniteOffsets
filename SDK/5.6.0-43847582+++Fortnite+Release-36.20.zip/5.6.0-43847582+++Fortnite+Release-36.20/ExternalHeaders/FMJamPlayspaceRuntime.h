/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamPlayspaceRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "PlayspaceSystem.h"
#include "FMJamCatalogRuntime.h"
#include "SparksMidiParser.h"
#include "GameplayAbilities.h"
#include "FMJamSessionRuntime.h"
#include "GameplayEventRouter.h"
#include "SparksCMS.h"
#include "SparksCoreCosmeticsRuntime.h"
#include "FMJamContentResolver.h"
#include "HarmonixDsp.h"
#include "Niagara.h"
#include "HarmonixMidi.h"
#include "SparksMusicPlayspaceRuntime.h"

// Size: 0x100
class UAddAbilitySetToOverlappingActorsComponent : public UActorComponent
{
public:
    TArray<TSoftObjectPtr<UFortAbilitySet*>> AbilitySetsToAdd() const { return Read<TArray<TSoftObjectPtr<UFortAbilitySet*>>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)

    void SET_AbilitySetsToAdd(const TArray<TSoftObjectPtr<UFortAbilitySet*>>& Value) { Write<TArray<TSoftObjectPtr<UFortAbilitySet*>>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UEnhancedInputHelpers : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xf8
class UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers : public UGameFeatureAction
{
public:
    FGameplayTagQuery PlayspaceTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x48, Type: StructProperty)
    TArray<TSoftObjectPtr<UFortAbilitySet*>> AbilitySetsToAdd() const { return Read<TArray<TSoftObjectPtr<UFortAbilitySet*>>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_PlayspaceTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x48, Type: StructProperty)
    void SET_AbilitySetsToAdd(const TArray<TSoftObjectPtr<UFortAbilitySet*>>& Value) { Write<TArray<TSoftObjectPtr<UFortAbilitySet*>>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x180
class UJamAnalytics : public UFortControllerComponent
{
public:
    FScalableFloat MinLoopLength() const { return Read<FScalableFloat>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x28, Type: StructProperty)
    AJamPlayspace* JamPlayspace() const { return Read<AJamPlayspace*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    TMap<int32_t, float> LoopStartTimes() const { return Read<TMap<int32_t, float>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x50, Type: MapProperty)

    void SET_MinLoopLength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x28, Type: StructProperty)
    void SET_JamPlayspace(const AJamPlayspace*& Value) { Write<AJamPlayspace*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_LoopStartTimes(const TMap<int32_t, float>& Value) { Write<TMap<int32_t, float>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x50, Type: MapProperty)
};

// Size: 0x48
class UJamMidiEventDriver : public UObject
{
public:
    TWeakObjectPtr<UJamMusicSlot*> WeakOwningMusicSlotPtr() const { return Read<TWeakObjectPtr<UJamMusicSlot*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    UParsedMidiEventData* ParsedMidiEventData() const { return Read<UParsedMidiEventData*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_WeakOwningMusicSlotPtr(const TWeakObjectPtr<UJamMusicSlot*>& Value) { Write<TWeakObjectPtr<UJamMusicSlot*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ParsedMidiEventData(const UParsedMidiEventData*& Value) { Write<UParsedMidiEventData*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UJamPlayParamsUtilities : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x830
class AJamPlayspace : public ASparksMusicPlayspace
{
public:
    UJamPlayspaceComponent_MusicManager* MusicManager() const { return Read<UJamPlayspaceComponent_MusicManager*>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x8, Type: ObjectProperty)
    UJamPlayspaceComponent_ReactiveFX* ReactiveFXComponent() const { return Read<UJamPlayspaceComponent_ReactiveFX*>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x8, Type: ObjectProperty)
    UPlayspaceComponent_DispatchExternallyReachable* ExternalReachabilityComponent() const { return Read<UPlayspaceComponent_DispatchExternallyReachable*>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    FGuid JamSessionGuid() const { return Read<FGuid>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x10, Type: StructProperty)

    void SET_MusicManager(const UJamPlayspaceComponent_MusicManager*& Value) { Write<UJamPlayspaceComponent_MusicManager*>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x8, Type: ObjectProperty)
    void SET_ReactiveFXComponent(const UJamPlayspaceComponent_ReactiveFX*& Value) { Write<UJamPlayspaceComponent_ReactiveFX*>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExternalReachabilityComponent(const UPlayspaceComponent_DispatchExternallyReachable*& Value) { Write<UPlayspaceComponent_DispatchExternallyReachable*>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    void SET_JamSessionGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
class UJamPlayspaceBlockerInterface : public UInterface
{
public:
};

// Size: 0x28
class UJamPlayspaceBPFL : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x1f0
class UJamPlayspaceComponent_AutojammerProxyRegistry : public UActorComponent
{
public:
    FAutojammerProxyList AutojammerProxyList() const { return Read<FAutojammerProxyList>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x120, Type: StructProperty)

    void SET_AutojammerProxyList(const FAutojammerProxyList& Value) { Write<FAutojammerProxyList>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x120, Type: StructProperty)
};

// Size: 0x140
class UJamPlayspaceComponent_JamCompanion : public UPlayspaceComponent
{
public:
    bool bOverrideShouldPlaySongAlone() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bForceShouldPlaySongAlone() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)

    void SET_bOverrideShouldPlaySongAlone(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_bForceShouldPlaySongAlone(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c0
class UJamMusicSlot : public UObject
{
public:
    UMidiFile* CurrentMidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UFusionPatch* CurrentFusionPatch() const { return Read<UFusionPatch*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    UObject* CurrentSongPart() const { return Read<UObject*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    UJamMidiEventDriver* MidiEventDriver() const { return Read<UJamMidiEventDriver*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    bool bAttemptingResolveAndLoad() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    FJamPlayParams CurrentPlayParams() const { return Read<FJamPlayParams>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: StructProperty)
    FJamPlayParams LastStartedPlayParams() const { return Read<FJamPlayParams>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x50, Type: StructProperty)
    UJamPlayspaceComponent_MusicManager* JamMusicManager() const { return Read<UJamPlayspaceComponent_MusicManager*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    int32_t NthSlot() const { return Read<int32_t>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: IntProperty)
    FGameplayTagContainer OwnedGameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x20, Type: StructProperty)

    void SET_CurrentMidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentFusionPatch(const UFusionPatch*& Value) { Write<UFusionPatch*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentSongPart(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_MidiEventDriver(const UJamMidiEventDriver*& Value) { Write<UJamMidiEventDriver*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_bAttemptingResolveAndLoad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentPlayParams(const FJamPlayParams& Value) { Write<FJamPlayParams>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: StructProperty)
    void SET_LastStartedPlayParams(const FJamPlayParams& Value) { Write<FJamPlayParams>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x50, Type: StructProperty)
    void SET_JamMusicManager(const UJamPlayspaceComponent_MusicManager*& Value) { Write<UJamPlayspaceComponent_MusicManager*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    void SET_NthSlot(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: IntProperty)
    void SET_OwnedGameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x20, Type: StructProperty)
};

// Size: 0x218
class UJamPlayspaceComponent_MusicManager : public UPlayspaceComponent
{
public:
    TArray<UJamMusicSlot*> MusicSlots() const { return Read<TArray<UJamMusicSlot*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    FGameplayEventListenerHandle KeyChangedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle ModeChangedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle TempoChangedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1c, Type: StructProperty)
    float LocalPlayerGainParam() const { return Read<float>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x4, Type: FloatProperty)
    float StandardGainParam() const { return Read<float>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer MutingTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer MetasoundStoppingTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x20, Type: StructProperty)

    void SET_MusicSlots(const TArray<UJamMusicSlot*>& Value) { Write<TArray<UJamMusicSlot*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_KeyChangedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1c, Type: StructProperty)
    void SET_ModeChangedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x1c, Type: StructProperty)
    void SET_TempoChangedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1c, Type: StructProperty)
    void SET_LocalPlayerGainParam(const float& Value) { Write<float>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x4, Type: FloatProperty)
    void SET_StandardGainParam(const float& Value) { Write<float>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x4, Type: FloatProperty)
    void SET_MutingTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x20, Type: StructProperty)
    void SET_MetasoundStoppingTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x238
class UJamPlayspaceComponent_PlayerManager : public UPlayspaceComponent_SparksPlayerManager
{
public:
};

// Size: 0x288
class UJamPlayspaceComponent_ReactiveFX : public UPlayspaceComponent
{
public:
    FJamReactiveFXState ReactiveFXState() const { return Read<FJamReactiveFXState>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    bool bSetReactivityUpdateRateToTargetFPS() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    float ReactivityUpdateRate() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float PeakTamerValueReleaseTimeSec() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    TMap<int32_t, FJamLoopReactiveFX> LoopReactiveFX() const { return Read<TMap<int32_t, FJamLoopReactiveFX>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FTimerHandle> PendingVFXHandles() const { return Read<TMap<int32_t, FTimerHandle>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x50, Type: MapProperty)
    UNiagaraSystem* DefaultPlayerFXToSpawn() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* DefaultPlayerDropFXToSpawn() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: ObjectProperty)
    TMap<EFMJamLoopType, float> DefaultLoopFXAmplitude() const { return Read<TMap<EFMJamLoopType, float>>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x50, Type: MapProperty)
    UJamPlayspaceComponent_AutojammerProxyRegistry* BoundAutojammerRegistry() const { return Read<UJamPlayspaceComponent_AutojammerProxyRegistry*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)

    void SET_ReactiveFXState(const FJamReactiveFXState& Value) { Write<FJamReactiveFXState>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_bSetReactivityUpdateRateToTargetFPS(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_ReactivityUpdateRate(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_PeakTamerValueReleaseTimeSec(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_LoopReactiveFX(const TMap<int32_t, FJamLoopReactiveFX>& Value) { Write<TMap<int32_t, FJamLoopReactiveFX>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_PendingVFXHandles(const TMap<int32_t, FTimerHandle>& Value) { Write<TMap<int32_t, FTimerHandle>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x50, Type: MapProperty)
    void SET_DefaultPlayerFXToSpawn(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultPlayerDropFXToSpawn(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultLoopFXAmplitude(const TMap<EFMJamLoopType, float>& Value) { Write<TMap<EFMJamLoopType, float>>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x50, Type: MapProperty)
    void SET_BoundAutojammerRegistry(const UJamPlayspaceComponent_AutojammerProxyRegistry*& Value) { Write<UJamPlayspaceComponent_AutojammerProxyRegistry*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3a8
class AJamPlayspaceVolume : public AGameplayVolume
{
public:
    TArray<EFMJamLoopType> PriorityFillOrder() const { return Read<TArray<EFMJamLoopType>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UTexture2D> AutoJammerProfilePic() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x20, Type: SoftObjectProperty)
    FName JamCompanionSong() const { return Read<FName>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x4, Type: NameProperty)
    bool bShouldJamCompanionStaggerAutoJammers() const { return Read<bool>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x1, Type: BoolProperty)
    FGameplayTag TooCloseToJamErrorMessage() const { return Read<FGameplayTag>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x4, Type: StructProperty)

    void SET_PriorityFillOrder(const TArray<EFMJamLoopType>& Value) { Write<TArray<EFMJamLoopType>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    void SET_AutoJammerProfilePic(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x20, Type: SoftObjectProperty)
    void SET_JamCompanionSong(const FName& Value) { Write<FName>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x4, Type: NameProperty)
    void SET_bShouldJamCompanionStaggerAutoJammers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x1, Type: BoolProperty)
    void SET_TooCloseToJamErrorMessage(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x4, Type: StructProperty)
};

// Size: 0x110
class UJamPlayspaceVolumeComponent_ProvideTransforms : public UActorComponent
{
public:
    FComponentReference TransformsBaseComponent() const { return Read<FComponentReference>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    TArray<FTransform> SignificantTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ProviderTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: StructProperty)

    void SET_TransformsBaseComponent(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_SignificantTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_ProviderTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: StructProperty)
};

// Size: 0xe8
class UJamQuickplayPlayerSpawningComponent : public UPlayspaceComponent_PlayerSpawning
{
public:
    FGameplayTagContainer PregameSpawnTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x20, Type: StructProperty)

    void SET_PregameSpawnTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x20, Type: StructProperty)
};

// Size: 0xc8
class UPlayspaceComponent_AddGameFeatureAbilitiesToUsers : public UPlayspaceComponent
{
public:
};

// Size: 0x108
class UJamPlayspaceComponent_LipSyncAssetManager : public UPlayspaceComponent_LipSyncAssetManager
{
public:
};

// Size: 0x50
struct FJamPlayParams
{
public:
    FName SongShortname() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t LoopType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    FUniqueNetIdRepl PlayerNetId() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x30, Type: StructProperty)
    int32_t LoopInstanceId() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    bool bIsAutoJammer() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t SlotStartMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x3d); } // 0x3d (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<UCatalogData*> CMSCatalogEntry() const { return Read<TWeakObjectPtr<UCatalogData*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFMJamSong*> Song() const { return Read<TWeakObjectPtr<UFMJamSong*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)

    void SET_SongShortname(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_LoopType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_PlayerNetId(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x30, Type: StructProperty)
    void SET_LoopInstanceId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_bIsAutoJammer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_SlotStartMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3d, Value); } // 0x3d (Size: 0x1, Type: EnumProperty)
    void SET_CMSCatalogEntry(const TWeakObjectPtr<UCatalogData*>& Value) { Write<TWeakObjectPtr<UCatalogData*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Song(const TWeakObjectPtr<UFMJamSong*>& Value) { Write<TWeakObjectPtr<UFMJamSong*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x18
struct FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition
{
public:
    FString CVarName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t RequiredValue() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_CVarName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_RequiredValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc
struct FJammerTypeBreakdown
{
public:
    int32_t TotalNumPlayerJammers() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TotalNumHoloJammers() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t TotalNumAutoJammers() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_TotalNumPlayerJammers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_TotalNumHoloJammers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_TotalNumAutoJammers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FJamLoadResult
{
public:
    UJamMusicSlot* Slot() const { return Read<UJamMusicSlot*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFusionPatch* FusionPatch() const { return Read<UFusionPatch*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMidiFile* MidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UObject* SongPart() const { return Read<UObject*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bSuccess() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bWasCancelled() const { return Read<bool>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: BoolProperty)

    void SET_Slot(const UJamMusicSlot*& Value) { Write<UJamMusicSlot*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_FusionPatch(const UFusionPatch*& Value) { Write<UFusionPatch*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_MidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_SongPart(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_bWasCancelled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
struct FJamEvent_JamLoopBase
{
public:
    FName SongShortname() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    UCatalogData* CatalogEntry() const { return Read<UCatalogData*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t LoopType() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    FUniqueNetIdRepl PlayerNetId() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)
    int32_t LoopInstanceId() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)
    bool bIsAutoJammer() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    bool bChangedLoop() const { return Read<bool>(uintptr_t(this) + 0x55); } // 0x55 (Size: 0x1, Type: BoolProperty)
    FJamPlayParams SlotParams() const { return Read<FJamPlayParams>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: StructProperty)

    void SET_SongShortname(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_CatalogEntry(const UCatalogData*& Value) { Write<UCatalogData*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_LoopType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_PlayerNetId(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
    void SET_LoopInstanceId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
    void SET_bIsAutoJammer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_bChangedLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x55, Value); } // 0x55 (Size: 0x1, Type: BoolProperty)
    void SET_SlotParams(const FJamPlayParams& Value) { Write<FJamPlayParams>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: StructProperty)
};

// Size: 0xa8
struct FJamEvent_JamLoopStarted : public FJamEvent_JamLoopBase
{
public:
};

// Size: 0xa8
struct FJamEvent_JamLoopStopped : public FJamEvent_JamLoopBase
{
public:
};

// Size: 0x1
struct FJamEvent_LoopsChangedThisFrame
{
public:
};

// Size: 0x1
struct FJamEvent_OnPrimaryPlayerPresenceChanged
{
public:
    bool bPrimaryPlayerInPlayspace() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bPrimaryPlayerInPlayspace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FAutojammerProxyData
{
public:
    int32_t LoopInstanceId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    UJamMusicSlot* MusicSlot() const { return Read<UJamMusicSlot*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* ProxyActor() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_LoopInstanceId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_MusicSlot(const UJamMusicSlot*& Value) { Write<UJamMusicSlot*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ProxyActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
struct FAutojammerProxyEntry : public FFastArraySerializerItem
{
public:
    FAutojammerProxyData Data() const { return Read<FAutojammerProxyData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FAutojammerProxyData LastData() const { return Read<FAutojammerProxyData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Data(const FAutojammerProxyData& Value) { Write<FAutojammerProxyData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_LastData(const FAutojammerProxyData& Value) { Write<FAutojammerProxyData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x120
struct FAutojammerProxyList : public FFastArraySerializer
{
public:
    TArray<FAutojammerProxyEntry> Proxies() const { return Read<TArray<FAutojammerProxyEntry>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)

    void SET_Proxies(const TArray<FAutojammerProxyEntry>& Value) { Write<TArray<FAutojammerProxyEntry>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FJamReactiveFXState
{
public:
    float OverallAmplitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<float> LoopAmplitudes() const { return Read<TArray<float>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector4f> LoopBandValues() const { return Read<TArray<FVector4f>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_OverallAmplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LoopAmplitudes(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_LoopBandValues(const TArray<FVector4f>& Value) { Write<TArray<FVector4f>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FJamLoopReactiveFX
{
public:
    TArray<TWeakObjectPtr<UNiagaraComponent*>> NiagaraComponents() const { return Read<TArray<TWeakObjectPtr<UNiagaraComponent*>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_NiagaraComponents(const TArray<TWeakObjectPtr<UNiagaraComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UNiagaraComponent*>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

