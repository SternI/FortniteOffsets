/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDynamicUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x18
struct FCreativeDynamicUIAlignmentConstraint
{
public:
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Anchor() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t AspectRatio() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    FVector2D Offset() const { return Read<FVector2D>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Anchor(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_AspectRatio(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_Offset(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0xc
struct FCreativeDynamicUIFixedSizeModifier
{
public:
    FVector2f Size() const { return Read<FVector2f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    bool bUseRenderTransform() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Size(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_bUseRenderTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FCreativeDynamicUIScaleSizeModifier
{
public:
    FVector2f Scale() const { return Read<FVector2f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    bool bUseRenderTransform() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Scale(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_bUseRenderTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

