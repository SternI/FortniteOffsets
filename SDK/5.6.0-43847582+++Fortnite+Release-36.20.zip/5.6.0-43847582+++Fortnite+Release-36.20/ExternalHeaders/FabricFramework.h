/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0xf8
class UFabricDeviceComponentBase : public UActorComponent
{
public:
    AFabricGlobalSystem* ServerFabricGlobalSystem() const { return Read<AFabricGlobalSystem*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFabricGlobalSystem*> LocalFabricGlobalSystem() const { return Read<TWeakObjectPtr<AFabricGlobalSystem*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    AFabricZoneSystem* ServerFabricZoneSystem() const { return Read<AFabricZoneSystem*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFabricZoneSystem*> LocalFabricZoneSystem() const { return Read<TWeakObjectPtr<AFabricZoneSystem*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ServerFabricGlobalSystem(const AFabricGlobalSystem*& Value) { Write<AFabricGlobalSystem*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalFabricGlobalSystem(const TWeakObjectPtr<AFabricGlobalSystem*>& Value) { Write<TWeakObjectPtr<AFabricGlobalSystem*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ServerFabricZoneSystem(const AFabricZoneSystem*& Value) { Write<AFabricZoneSystem*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalFabricZoneSystem(const TWeakObjectPtr<AFabricZoneSystem*>& Value) { Write<TWeakObjectPtr<AFabricZoneSystem*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2a8
class AFabricGlobalSystem : public AActor
{
public:
};

// Size: 0x758
class AFabricMusicRandomizer : public ABuildingActor
{
public:
    int32_t RandomSeed() const { return Read<int32_t>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x4, Type: IntProperty)
    AFabricZoneSystem* OwnerZoneSystem() const { return Read<AFabricZoneSystem*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)

    void SET_RandomSeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x4, Type: IntProperty)
    void SET_OwnerZoneSystem(const AFabricZoneSystem*& Value) { Write<AFabricZoneSystem*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UFabricZoneComponent : public UPlayspaceComponent
{
public:
    TWeakObjectPtr<AFabricZoneSystem*> ZoneSystem() const { return Read<TWeakObjectPtr<AFabricZoneSystem*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPlayspaceComponent_Fabric*> FabricPlayspaceComponent() const { return Read<TWeakObjectPtr<UPlayspaceComponent_Fabric*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>> DevicesInZone() const { return Read<TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)

    void SET_ZoneSystem(const TWeakObjectPtr<AFabricZoneSystem*>& Value) { Write<TWeakObjectPtr<AFabricZoneSystem*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FabricPlayspaceComponent(const TWeakObjectPtr<UPlayspaceComponent_Fabric*>& Value) { Write<TWeakObjectPtr<UPlayspaceComponent_Fabric*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_DevicesInZone(const TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2c0
class AFabricZoneSystem : public AActor
{
public:
    bool bAllowRandomization() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    UFabricZoneComponent* OwnerZoneComponent() const { return Read<UFabricZoneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    AFabricMusicRandomizer* MusicRandomizer() const { return Read<AFabricMusicRandomizer*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)

    void SET_bAllowRandomization(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_OwnerZoneComponent(const UFabricZoneComponent*& Value) { Write<UFabricZoneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicRandomizer(const AFabricMusicRandomizer*& Value) { Write<AFabricMusicRandomizer*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
class UFabricGlobalVariablesSubsystem : public UWorldSubsystem
{
public:
    FGameplayTag FabricPlayspaceGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    UClass* FabricPlayspaceComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ClassProperty)
    UClass* FabricGlobalSystemClass() const { return Read<UClass*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ClassProperty)
    UClass* FabricZoneSystemClass() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)
    UClass* FabricMusicRandomizerClass() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)

    void SET_FabricPlayspaceGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_FabricPlayspaceComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ClassProperty)
    void SET_FabricGlobalSystemClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ClassProperty)
    void SET_FabricZoneSystemClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
    void SET_FabricMusicRandomizerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xf8
class UPlayspaceComponent_Fabric : public UPlayspaceComponent
{
public:
    TWeakObjectPtr<AFabricGlobalSystem*> GlobalSystem() const { return Read<TWeakObjectPtr<AFabricGlobalSystem*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFabricZoneSystem*> GlobalZoneSystem() const { return Read<TWeakObjectPtr<AFabricZoneSystem*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>> RegisteredDevices() const { return Read<TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>> GlobalDevices() const { return Read<TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<UFabricZoneComponent*>> RegisteredZoneSystems() const { return Read<TArray<TWeakObjectPtr<UFabricZoneComponent*>>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)

    void SET_GlobalSystem(const TWeakObjectPtr<AFabricGlobalSystem*>& Value) { Write<TWeakObjectPtr<AFabricGlobalSystem*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_GlobalZoneSystem(const TWeakObjectPtr<AFabricZoneSystem*>& Value) { Write<TWeakObjectPtr<AFabricZoneSystem*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RegisteredDevices(const TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalDevices(const TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_RegisteredZoneSystems(const TArray<TWeakObjectPtr<UFabricZoneComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UFabricZoneComponent*>>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
};

