/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamCatalogRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "HarmonixDsp.h"
#include "HarmonixMidi.h"
#include "GameplayTags.h"
#include "SparksCMS.h"

// Size: 0x48
class UFMJamCatalogDeveloperSettings : public UDeveloperSettings
{
public:
    bool bAddDebugJamSongLoadoutWheel() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bOverrideJamSongLoadout() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    TArray<FName> JamSongLoadout() const { return Read<TArray<FName>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_bAddDebugJamSongLoadoutWheel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideJamSongLoadout(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_JamSongLoadout(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x128
class UFMJamLoop : public UPrimaryDataAsset
{
public:
    TSoftObjectPtr<UMidiFile> MidiFileMajor() const { return Read<TSoftObjectPtr<UMidiFile>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMidiFile> MidiFileMinor() const { return Read<TSoftObjectPtr<UMidiFile>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFusionPatch> FusionPatchMajor() const { return Read<TSoftObjectPtr<UFusionPatch>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFusionPatch> FusionPatchMinor() const { return Read<TSoftObjectPtr<UFusionPatch>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    bool bOverrideDefaultTransposition() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    TMap<EMusicKey, int32_t> Transposes() const { return Read<TMap<EMusicKey, int32_t>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    TSoftObjectPtr<UFMJamSong> Song() const { return Read<TSoftObjectPtr<UFMJamSong>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)

    void SET_MidiFileMajor(const TSoftObjectPtr<UMidiFile>& Value) { Write<TSoftObjectPtr<UMidiFile>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MidiFileMinor(const TSoftObjectPtr<UMidiFile>& Value) { Write<TSoftObjectPtr<UMidiFile>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    void SET_FusionPatchMajor(const TSoftObjectPtr<UFusionPatch>& Value) { Write<TSoftObjectPtr<UFusionPatch>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: SoftObjectProperty)
    void SET_FusionPatchMinor(const TSoftObjectPtr<UFusionPatch>& Value) { Write<TSoftObjectPtr<UFusionPatch>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bOverrideDefaultTransposition(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    void SET_Transposes(const TMap<EMusicKey, int32_t>& Value) { Write<TMap<EMusicKey, int32_t>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_Song(const TSoftObjectPtr<UFMJamSong>& Value) { Write<TSoftObjectPtr<UFMJamSong>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0xd8
class UFMJamSong : public USparksSongData
{
public:
    int32_t Tempo() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    UFMJamLoop* Lead() const { return Read<UFMJamLoop*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFMJamLoop* Misc() const { return Read<UFMJamLoop*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UFMJamLoop* Bass() const { return Read<UFMJamLoop*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UFMJamLoop* Beat() const { return Read<UFMJamLoop*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_Tempo(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_Lead(const UFMJamLoop*& Value) { Write<UFMJamLoop*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_Misc(const UFMJamLoop*& Value) { Write<UFMJamLoop*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_Bass(const UFMJamLoop*& Value) { Write<UFMJamLoop*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Beat(const UFMJamLoop*& Value) { Write<UFMJamLoop*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x178
class UFMJamSongCatalog : public UGameStateComponent
{
public:
    TMap<FName, UFMJamSong*> SongsByShortName() const { return Read<TMap<FName, UFMJamSong*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x50, Type: MapProperty)
    USparksSongCatalog* CachedCMSCatalog() const { return Read<USparksSongCatalog*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    int32_t NumCMSRetries() const { return Read<int32_t>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: IntProperty)
    bool bHaveSongCatalog() const { return Read<bool>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x1, Type: BoolProperty)

    void SET_SongsByShortName(const TMap<FName, UFMJamSong*>& Value) { Write<TMap<FName, UFMJamSong*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x50, Type: MapProperty)
    void SET_CachedCMSCatalog(const USparksSongCatalog*& Value) { Write<USparksSongCatalog*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    void SET_NumCMSRetries(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: IntProperty)
    void SET_bHaveSongCatalog(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x1, Type: BoolProperty)
};

