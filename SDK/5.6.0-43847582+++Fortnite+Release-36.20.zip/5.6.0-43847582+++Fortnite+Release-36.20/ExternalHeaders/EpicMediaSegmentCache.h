/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaSegmentCache
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x40
class UEpicMediaSegmentCacheInit : public UObject
{
public:
    FEpicMediaSegmentCacheConfig CacheConfig() const { return Read<FEpicMediaSegmentCacheConfig>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_CacheConfig(const FEpicMediaSegmentCacheConfig& Value) { Write<FEpicMediaSegmentCacheConfig>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FEpicMediaSegmentCacheConfig
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bResetCache() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bPersistentCache() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAllowPersistentCacheAsTemporary() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bClearCache() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    int32_t CacheSizeMaxFiles() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int64_t CacheSizeOnDiskMaxBytes() const { return Read<int64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: Int64Property)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bResetCache(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bPersistentCache(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowPersistentCacheAsTemporary(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_bClearCache(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_CacheSizeMaxFiles(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_CacheSizeOnDiskMaxBytes(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: Int64Property)
};

