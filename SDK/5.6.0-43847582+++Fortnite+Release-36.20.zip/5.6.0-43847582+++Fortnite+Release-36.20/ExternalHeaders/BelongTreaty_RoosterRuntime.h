/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BelongTreaty_RoosterRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x780
class UFortBelongTreaty_Rooster_ItemLayerAnimInstance : public UFortItemLayerAnimInstance
{
public:
    bool bIsStopping() const { return Read<bool>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x1, Type: BoolProperty)
    bool bIsSwinging() const { return Read<bool>(uintptr_t(this) + 0x769); } // 0x769 (Size: 0x1, Type: BoolProperty)
    bool bIsRidingOnActor() const { return Read<bool>(uintptr_t(this) + 0x76a); } // 0x76a (Size: 0x1, Type: BoolProperty)
    int32_t AmmoCount() const { return Read<int32_t>(uintptr_t(this) + 0x76c); } // 0x76c (Size: 0x4, Type: IntProperty)
    bool bIsEquipping() const { return Read<bool>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x1, Type: BoolProperty)
    bool bInVehicle() const { return Read<bool>(uintptr_t(this) + 0x771); } // 0x771 (Size: 0x1, Type: BoolProperty)

    void SET_bIsStopping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSwinging(const bool& Value) { Write<bool>(uintptr_t(this) + 0x769, Value); } // 0x769 (Size: 0x1, Type: BoolProperty)
    void SET_bIsRidingOnActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x76a, Value); } // 0x76a (Size: 0x1, Type: BoolProperty)
    void SET_AmmoCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x76c, Value); } // 0x76c (Size: 0x4, Type: IntProperty)
    void SET_bIsEquipping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x1, Type: BoolProperty)
    void SET_bInVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x771, Value); } // 0x771 (Size: 0x1, Type: BoolProperty)
};

