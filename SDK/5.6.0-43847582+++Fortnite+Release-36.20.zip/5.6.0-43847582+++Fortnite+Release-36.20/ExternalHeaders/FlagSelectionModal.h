/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FlagSelectionModal
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CareerUI.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "Systems.h"
#include "UIKit.h"

// Size: 0x1578
class UWBP_Flag_C : public UUIKitModularButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x8, Type: StructProperty)
    UImage* SelectionIndicator() const { return Read<UImage*>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    UFortFlagImage* Flag() const { return Read<UFortFlagImage*>(uintptr_t(this) + 0x1520); } // 0x1520 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Block_Outline_C* Block_Outline() const { return Read<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x1528); } // 0x1528 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnSelected() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1530); } // 0x1530 (Size: 0x8, Type: ObjectProperty)
    UFortCareerChangeFlagModalItemVM* FortCareerChangeFlagModalItemVM() const { return Read<UFortCareerChangeFlagModalItemVM*>(uintptr_t(this) + 0x1538); } // 0x1538 (Size: 0x8, Type: ObjectProperty)
    FUIKitBlockTiming BlocksTiming() const { return Read<FUIKitBlockTiming>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x2c, Type: StructProperty)
    UMaterialInstanceDynamic* FlagMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x8, Type: StructProperty)
    void SET_SelectionIndicator(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    void SET_Flag(const UFortFlagImage*& Value) { Write<UFortFlagImage*>(uintptr_t(this) + 0x1520, Value); } // 0x1520 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_Outline(const UWBP_UIKit_Block_Outline_C*& Value) { Write<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x1528, Value); } // 0x1528 (Size: 0x8, Type: ObjectProperty)
    void SET_OnSelected(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1530, Value); } // 0x1530 (Size: 0x8, Type: ObjectProperty)
    void SET_FortCareerChangeFlagModalItemVM(const UFortCareerChangeFlagModalItemVM*& Value) { Write<UFortCareerChangeFlagModalItemVM*>(uintptr_t(this) + 0x1538, Value); } // 0x1538 (Size: 0x8, Type: ObjectProperty)
    void SET_BlocksTiming(const FUIKitBlockTiming& Value) { Write<FUIKitBlockTiming>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x2c, Type: StructProperty)
    void SET_FlagMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4d0
class UWBP_FlagSelection_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: StructProperty)
    UCommonVisibilitySwitcher* VisibilitySwitcher() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCommonTileView* TileView() const { return Read<UCommonTileView*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UImage* Throbber() const { return Read<UImage*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* SelectedFlag() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UWBP_Flag_C* PreviousFlag() const { return Read<UWBP_Flag_C*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UFortFlagImage* Image_YourFlag() const { return Read<UFortFlagImage*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWBP_Flag_C* FutureFlag() const { return Read<UWBP_Flag_C*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Dialog_Internal_C* Dialog_Internal() const { return Read<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CurrentInfo() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ConfirmationText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ChangeWarning() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UImage* Arrow() const { return Read<UImage*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UFortCareerChangeFlagModalVM* FortCareerChangeFlagModalVM() const { return Read<UFortCareerChangeFlagModalVM*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    FName FutureSelectedFlag() const { return Read<FName>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x4, Type: NameProperty)
    UFortCareerChangeFlagModalItemVM* PickedFlag() const { return Read<UFortCareerChangeFlagModalItemVM*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: StructProperty)
    void SET_VisibilitySwitcher(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_TileView(const UCommonTileView*& Value) { Write<UCommonTileView*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Throbber(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedFlag(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousFlag(const UWBP_Flag_C*& Value) { Write<UWBP_Flag_C*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_YourFlag(const UFortFlagImage*& Value) { Write<UFortFlagImage*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_FutureFlag(const UWBP_Flag_C*& Value) { Write<UWBP_Flag_C*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Dialog_Internal(const UWBP_UIKit_Dialog_Internal_C*& Value) { Write<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentInfo(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_ConfirmationText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ChangeWarning(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Arrow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_FortCareerChangeFlagModalVM(const UFortCareerChangeFlagModalVM*& Value) { Write<UFortCareerChangeFlagModalVM*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_FutureSelectedFlag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x4, Type: NameProperty)
    void SET_PickedFlag(const UFortCareerChangeFlagModalItemVM*& Value) { Write<UFortCareerChangeFlagModalItemVM*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UVM_Dialog_FlagSelectionModal_C : public UUIKitDialogViewModel
{
public:
};

