/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticItemFlowgraphRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x80
class UCosmeticItemStep_GliderLoadAssets : public UFortCosmeticStep
{
public:
};

// Size: 0x80
class UCosmeticItemStep_GliderPostLoad : public UFortCosmeticStep
{
public:
};

// Size: 0x10
struct FGliderFlowCommonData
{
public:
};

