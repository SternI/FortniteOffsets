/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EnhancedInput
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DeveloperSettings.h"
#include "GameplayTags.h"
#include "InputCore.h"
#include "Slate.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0xa8
class UEnhancedPlayerMappableKeyProfile : public UObject
{
public:
    FGameplayTag ProfileIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FString ProfileIdentifierString() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FPlatformUserId OwningUserId() const { return Read<FPlatformUserId>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: StructProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: TextProperty)
    TMap<FName, FKeyMappingRow> PlayerMappedKeys() const { return Read<TMap<FName, FKeyMappingRow>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)

    void SET_ProfileIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_ProfileIdentifierString(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_OwningUserId(const FPlatformUserId& Value) { Write<FPlatformUserId>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: StructProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: TextProperty)
    void SET_PlayerMappedKeys(const TMap<FName, FKeyMappingRow>& Value) { Write<TMap<FName, FKeyMappingRow>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
};

// Size: 0x180
class UEnhancedInputUserSettings : public USaveGame
{
public:
    FGameplayTag CurrentProfileIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)
    FString CurrentProfileIdentifierString() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    TMap<FGameplayTag, UEnhancedPlayerMappableKeyProfile*> SavedKeyProfiles() const { return Read<TMap<FGameplayTag, UEnhancedPlayerMappableKeyProfile*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x50, Type: MapProperty)
    TMap<FString, UEnhancedPlayerMappableKeyProfile*> SavedKeyProfilesMap() const { return Read<TMap<FString, UEnhancedPlayerMappableKeyProfile*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x50, Type: MapProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer() const { return Read<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    TSet<UInputMappingContext*> RegisteredMappingContexts() const { return Read<TSet<UInputMappingContext*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x50, Type: SetProperty)

    void SET_CurrentProfileIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
    void SET_CurrentProfileIdentifierString(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_SavedKeyProfiles(const TMap<FGameplayTag, UEnhancedPlayerMappableKeyProfile*>& Value) { Write<TMap<FGameplayTag, UEnhancedPlayerMappableKeyProfile*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x50, Type: MapProperty)
    void SET_SavedKeyProfilesMap(const TMap<FString, UEnhancedPlayerMappableKeyProfile*>& Value) { Write<TMap<FString, UEnhancedPlayerMappableKeyProfile*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x50, Type: MapProperty)
    void SET_OwningLocalPlayer(const TWeakObjectPtr<ULocalPlayer*>& Value) { Write<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RegisteredMappingContexts(const TSet<UInputMappingContext*>& Value) { Write<TSet<UInputMappingContext*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x50, Type: SetProperty)
};

// Size: 0x38
class UEnhancedInputActionDelegateBinding : public UInputDelegateBinding
{
public:
    TArray<FBlueprintEnhancedInputActionBinding> InputActionDelegateBindings() const { return Read<TArray<FBlueprintEnhancedInputActionBinding>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_InputActionDelegateBindings(const TArray<FBlueprintEnhancedInputActionBinding>& Value) { Write<TArray<FBlueprintEnhancedInputActionBinding>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UEnhancedInputActionValueBinding : public UInputDelegateBinding
{
public:
    TArray<FBlueprintEnhancedInputActionBinding> InputActionValueBindings() const { return Read<TArray<FBlueprintEnhancedInputActionBinding>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_InputActionValueBindings(const TArray<FBlueprintEnhancedInputActionBinding>& Value) { Write<TArray<FBlueprintEnhancedInputActionBinding>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x178
class UEnhancedInputComponent : public UInputComponent
{
public:
};

// Size: 0x140
class UEnhancedInputDeveloperSettings : public UDeveloperSettingsBackedByCVars
{
public:
    TArray<FDefaultContextSetting> DefaultMappingContexts() const { return Read<TArray<FDefaultContextSetting>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FDefaultContextSetting> DefaultWorldSubsystemMappingContexts() const { return Read<TArray<FDefaultContextSetting>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FPerPlatformSettings PlatformSettings() const { return Read<FPerPlatformSettings>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    FString InputSettingsSaveSlotName() const { return Read<FString>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StrProperty)
    bool bSendTriggeredEventsWhenInputIsFlushed() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x0) & 1; } // 0xd0:0 (Size: 0x1, Type: BoolProperty)
    bool bEnableUserSettings() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x1) & 1; } // 0xd0:1 (Size: 0x1, Type: BoolProperty)
    bool bEnableDefaultMappingContexts() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x2) & 1; } // 0xd0:2 (Size: 0x1, Type: BoolProperty)
    bool bShouldOnlyTriggerLastActionInChord() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x3) & 1; } // 0xd0:3 (Size: 0x1, Type: BoolProperty)
    bool bEnableInputModeFiltering() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x4) & 1; } // 0xd0:4 (Size: 0x1, Type: BoolProperty)
    bool bEnableWorldSubsystem() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x5) & 1; } // 0xd0:5 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery DefaultMappingContextInputModeQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer DefaultInputMode() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x20, Type: StructProperty)

    void SET_DefaultMappingContexts(const TArray<FDefaultContextSetting>& Value) { Write<TArray<FDefaultContextSetting>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultWorldSubsystemMappingContexts(const TArray<FDefaultContextSetting>& Value) { Write<TArray<FDefaultContextSetting>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_PlatformSettings(const FPerPlatformSettings& Value) { Write<FPerPlatformSettings>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_InputSettingsSaveSlotName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StrProperty)
    void SET_bSendTriggeredEventsWhenInputIsFlushed(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableUserSettings(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDefaultMappingContexts(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldOnlyTriggerLastActionInChord(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:3 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableInputModeFiltering(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:4 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableWorldSubsystem(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:5 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultMappingContextInputModeQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x48, Type: StructProperty)
    void SET_DefaultInputMode(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UEnhancedInputLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x78
class UEnhancedInputPlatformData : public UObject
{
public:
    TMap<UInputMappingContext*, UInputMappingContext*> MappingContextRedirects() const { return Read<TMap<UInputMappingContext*, UInputMappingContext*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_MappingContextRedirects(const TMap<UInputMappingContext*, UInputMappingContext*>& Value) { Write<TMap<UInputMappingContext*, UInputMappingContext*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x68
class UEnhancedInputPlatformSettings : public UPlatformSettings
{
public:
    TArray<TSoftClassPtr> InputData() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> InputDataClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    bool bShouldLogMappingContextRedirects() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)

    void SET_InputData(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_InputDataClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_bShouldLogMappingContextRedirects(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UEnhancedInputSubsystemInterface : public UInterface
{
public:
};

// Size: 0x208
class UEnhancedInputLocalPlayerSubsystem : public ULocalPlayerSubsystem
{
public:
    UEnhancedInputUserSettings* UserSettings() const { return Read<UEnhancedInputUserSettings*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    TMap<UInputAction*, FInjectedInput> ContinuouslyInjectedInputs() const { return Read<TMap<UInputAction*, FInjectedInput>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x50, Type: MapProperty)

    void SET_UserSettings(const UEnhancedInputUserSettings*& Value) { Write<UEnhancedInputUserSettings*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ContinuouslyInjectedInputs(const TMap<UInputAction*, FInjectedInput>& Value) { Write<TMap<UInputAction*, FInjectedInput>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x1f8
class UEnhancedInputWorldSubsystem : public UWorldSubsystem
{
public:
    UEnhancedPlayerInput* PlayerInput() const { return Read<UEnhancedPlayerInput*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    TArray<TWeakObjectPtr<UInputComponent*>> CurrentInputStack() const { return Read<TArray<TWeakObjectPtr<UInputComponent*>>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    TMap<UInputAction*, FInjectedInput> ContinuouslyInjectedInputs() const { return Read<TMap<UInputAction*, FInjectedInput>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x50, Type: MapProperty)

    void SET_PlayerInput(const UEnhancedPlayerInput*& Value) { Write<UEnhancedPlayerInput*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentInputStack(const TArray<TWeakObjectPtr<UInputComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UInputComponent*>>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    void SET_ContinuouslyInjectedInputs(const TMap<UInputAction*, FInjectedInput>& Value) { Write<TMap<UInputAction*, FInjectedInput>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x8a8
class UEnhancedPlayerInput : public UPlayerInput
{
public:
    TMap<UInputAction*, FKeyConsumptionOptions> KeyConsumptionData() const { return Read<TMap<UInputAction*, FKeyConsumptionOptions>>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x50, Type: MapProperty)
    TMap<UInputAction*, FInputActionInstance> ActionInstanceData() const { return Read<TMap<UInputAction*, FInputActionInstance>>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x50, Type: MapProperty)
    TMap<UInputMappingContext*, FAppliedInputContextData> AppliedInputContextData() const { return Read<TMap<UInputMappingContext*, FAppliedInputContextData>>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x50, Type: MapProperty)
    TMap<UInputMappingContext*, int32_t> AppliedInputContexts() const { return Read<TMap<UInputMappingContext*, int32_t>>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x50, Type: MapProperty)
    TArray<FEnhancedActionKeyMapping> EnhancedActionMappings() const { return Read<TArray<FEnhancedActionKeyMapping>>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer CurrentInputMode() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x20, Type: StructProperty)
    TMap<FKey, FVector> KeysPressedThisTick() const { return Read<TMap<FKey, FVector>>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x50, Type: MapProperty)
    TMap<UInputAction*, FInjectedInputArray> InputsInjectedThisTick() const { return Read<TMap<UInputAction*, FInjectedInputArray>>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x50, Type: MapProperty)
    TSet<UInputAction*> LastInjectedActions() const { return Read<TSet<UInputAction*>>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x50, Type: SetProperty)

    void SET_KeyConsumptionData(const TMap<UInputAction*, FKeyConsumptionOptions>& Value) { Write<TMap<UInputAction*, FKeyConsumptionOptions>>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x50, Type: MapProperty)
    void SET_ActionInstanceData(const TMap<UInputAction*, FInputActionInstance>& Value) { Write<TMap<UInputAction*, FInputActionInstance>>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x50, Type: MapProperty)
    void SET_AppliedInputContextData(const TMap<UInputMappingContext*, FAppliedInputContextData>& Value) { Write<TMap<UInputMappingContext*, FAppliedInputContextData>>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x50, Type: MapProperty)
    void SET_AppliedInputContexts(const TMap<UInputMappingContext*, int32_t>& Value) { Write<TMap<UInputMappingContext*, int32_t>>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x50, Type: MapProperty)
    void SET_EnhancedActionMappings(const TArray<FEnhancedActionKeyMapping>& Value) { Write<TArray<FEnhancedActionKeyMapping>>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentInputMode(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x20, Type: StructProperty)
    void SET_KeysPressedThisTick(const TMap<FKey, FVector>& Value) { Write<TMap<FKey, FVector>>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x50, Type: MapProperty)
    void SET_InputsInjectedThisTick(const TMap<UInputAction*, FInjectedInputArray>& Value) { Write<TMap<UInputAction*, FInjectedInputArray>>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x50, Type: MapProperty)
    void SET_LastInjectedActions(const TSet<UInputAction*>& Value) { Write<TSet<UInputAction*>>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x50, Type: SetProperty)
};

// Size: 0x78
class UInputAction : public UDataAsset
{
public:
    FText ActionDescription() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    bool bTriggerWhenPaused() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bConsumeInput() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bConsumesActionAndAxisMappings() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)
    bool bReserveAllMappings() const { return Read<bool>(uintptr_t(this) + 0x43); } // 0x43 (Size: 0x1, Type: BoolProperty)
    int32_t TriggerEventsThatConsumeLegacyKeys() const { return Read<int32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: IntProperty)
    uint8_t ValueType() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t AccumulationBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: EnumProperty)
    TArray<UInputTrigger*> Triggers() const { return Read<TArray<UInputTrigger*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers() const { return Read<TArray<UInputModifier*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    UPlayerMappableKeySettings* PlayerMappableKeySettings() const { return Read<UPlayerMappableKeySettings*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)

    void SET_ActionDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_bTriggerWhenPaused(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bConsumeInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_bConsumesActionAndAxisMappings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
    void SET_bReserveAllMappings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43, Value); } // 0x43 (Size: 0x1, Type: BoolProperty)
    void SET_TriggerEventsThatConsumeLegacyKeys(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: IntProperty)
    void SET_ValueType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
    void SET_AccumulationBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: EnumProperty)
    void SET_Triggers(const TArray<UInputTrigger*>& Value) { Write<TArray<UInputTrigger*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_Modifiers(const TArray<UInputModifier*>& Value) { Write<TArray<UInputModifier*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayerMappableKeySettings(const UPlayerMappableKeySettings*& Value) { Write<UPlayerMappableKeySettings*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UInputDebugKeyDelegateBinding : public UInputDelegateBinding
{
public:
    TArray<FBlueprintInputDebugKeyDelegateBinding> InputDebugKeyDelegateBindings() const { return Read<TArray<FBlueprintInputDebugKeyDelegateBinding>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_InputDebugKeyDelegateBindings(const TArray<FBlueprintInputDebugKeyDelegateBinding>& Value) { Write<TArray<FBlueprintInputDebugKeyDelegateBinding>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa8
class UInputMappingContext : public UDataAsset
{
public:
    TArray<FEnhancedActionKeyMapping> Mappings() const { return Read<TArray<FEnhancedActionKeyMapping>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t InputModeFilterOptions() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    FGameplayTagQuery InputModeQueryOverride() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x48, Type: StructProperty)
    uint8_t RegistrationTrackingMode() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)
    FText ContextDescription() const { return Read<FText>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: TextProperty)

    void SET_Mappings(const TArray<FEnhancedActionKeyMapping>& Value) { Write<TArray<FEnhancedActionKeyMapping>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_InputModeFilterOptions(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_InputModeQueryOverride(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x48, Type: StructProperty)
    void SET_RegistrationTrackingMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
    void SET_ContextDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: TextProperty)
};

// Size: 0x28
class UInputModifier : public UObject
{
public:
};

// Size: 0x68
class UInputModifierSmoothDelta : public UInputModifier
{
public:
    uint8_t SmoothingMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    float Speed() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float EasingExponent() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_SmoothingMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_Speed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_EasingExponent(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class UInputModifierDeadZone : public UInputModifier
{
public:
    float LowerThreshold() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float UpperThreshold() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)

    void SET_LowerThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_UpperThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x40
class UInputModifierScalar : public UInputModifier
{
public:
    FVector Scalar() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Scalar(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
class UInputModifierScaleByDeltaTime : public UInputModifier
{
public:
};

// Size: 0x30
class UInputModifierNegate : public UInputModifier
{
public:
    bool bX() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bY() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bZ() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)

    void SET_bX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bY(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_bZ(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
class UInputModifierSmooth : public UInputModifier
{
public:
};

// Size: 0x40
class UInputModifierResponseCurveExponential : public UInputModifier
{
public:
    FVector CurveExponent() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_CurveExponent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
class UInputModifierResponseCurveUser : public UInputModifier
{
public:
    UCurveFloat* ResponseX() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ResponseY() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ResponseZ() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ResponseX(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_ResponseY(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_ResponseZ(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UInputModifierFOVScaling : public UInputModifier
{
public:
    float FOVScale() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t FOVScalingType() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)

    void SET_FOVScale(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_FOVScalingType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
class UInputModifierToWorldSpace : public UInputModifier
{
public:
};

// Size: 0x30
class UInputModifierSwizzleAxis : public UInputModifier
{
public:
    uint8_t Order() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)

    void SET_Order(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x50
class UInputTrigger : public UObject
{
public:
    float ActuationThreshold() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bShouldAlwaysTick() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)
    FInputActionValue LastValue() const { return Read<FInputActionValue>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_ActuationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_bShouldAlwaysTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
    void SET_LastValue(const FInputActionValue& Value) { Write<FInputActionValue>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x58
class UInputTriggerTimedBase : public UInputTrigger
{
public:
    float HeldDuration() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bAffectedByTimeDilation() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)

    void SET_HeldDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_bAffectedByTimeDilation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UInputTriggerDown : public UInputTrigger
{
public:
};

// Size: 0x50
class UInputTriggerPressed : public UInputTrigger
{
public:
};

// Size: 0x50
class UInputTriggerReleased : public UInputTrigger
{
public:
};

// Size: 0x68
class UInputTriggerHold : public UInputTriggerTimedBase
{
public:
    float HoldTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    bool bIsOneShot() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)

    void SET_HoldTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_bIsOneShot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
class UInputTriggerHoldAndRelease : public UInputTriggerTimedBase
{
public:
    float HoldTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)

    void SET_HoldTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
class UInputTriggerTap : public UInputTriggerTimedBase
{
public:
    float TapReleaseTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)

    void SET_TapReleaseTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UInputTriggerRepeatedTap : public UInputTriggerTimedBase
{
public:
    double RepeatDelay() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double RepeatTime() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    int32_t NumberOfTapsWhichTriggerRepeat() const { return Read<int32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: IntProperty)
    float TapReleaseTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    int32_t NumberOfTapsSinceLastTrigger() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)

    void SET_RepeatDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_RepeatTime(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_NumberOfTapsWhichTriggerRepeat(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: IntProperty)
    void SET_TapReleaseTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_NumberOfTapsSinceLastTrigger(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
};

// Size: 0x68
class UInputTriggerPulse : public UInputTriggerTimedBase
{
public:
    bool bTriggerOnStart() const { return Read<bool>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: BoolProperty)
    float Interval() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    int32_t TriggerLimit() const { return Read<int32_t>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: IntProperty)

    void SET_bTriggerOnStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: BoolProperty)
    void SET_Interval(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_TriggerLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
class UInputTriggerChordAction : public UInputTrigger
{
public:
    UInputAction* ChordAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_ChordAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
class UInputTriggerChordBlocker : public UInputTriggerChordAction
{
public:
};

// Size: 0x78
class UInputTriggerCombo : public UInputTrigger
{
public:
    int32_t CurrentComboStepIndex() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)
    float CurrentTimeBetweenComboSteps() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    TArray<FInputComboStepData> ComboActions() const { return Read<TArray<FInputComboStepData>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FInputCancelAction> InputCancelActions() const { return Read<TArray<FInputCancelAction>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_CurrentComboStepIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
    void SET_CurrentTimeBetweenComboSteps(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_ComboActions(const TArray<FInputComboStepData>& Value) { Write<TArray<FInputComboStepData>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_InputCancelActions(const TArray<FInputCancelAction>& Value) { Write<TArray<FInputCancelAction>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa8
class UPlayerMappableInputConfig : public UPrimaryDataAsset
{
public:
    FName ConfigName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    FText ConfigDisplayName() const { return Read<FText>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: TextProperty)
    bool bIsDeprecated() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    UObject* MetaData() const { return Read<UObject*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    TMap<UInputMappingContext*, int32_t> Contexts() const { return Read<TMap<UInputMappingContext*, int32_t>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)

    void SET_ConfigName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_ConfigDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: TextProperty)
    void SET_bIsDeprecated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_MetaData(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_Contexts(const TMap<UInputMappingContext*, int32_t>& Value) { Write<TMap<UInputMappingContext*, int32_t>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
};

// Size: 0x88
class UPlayerMappableKeySettings : public UObject
{
public:
    UObject* MetaData() const { return Read<UObject*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: TextProperty)
    FText DisplayCategory() const { return Read<FText>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer SupportedKeyProfiles() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    TArray<FString> SupportedKeyProfileIds() const { return Read<TArray<FString>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_MetaData(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: TextProperty)
    void SET_DisplayCategory(const FText& Value) { Write<FText>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: TextProperty)
    void SET_SupportedKeyProfiles(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_SupportedKeyProfileIds(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FInputActionValue
{
public:
};

// Size: 0x40
struct FInjectedInput
{
public:
    TArray<UInputTrigger*> Triggers() const { return Read<TArray<UInputTrigger*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers() const { return Read<TArray<UInputModifier*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Triggers(const TArray<UInputTrigger*>& Value) { Write<TArray<UInputTrigger*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Modifiers(const TArray<UInputModifier*>& Value) { Write<TArray<UInputModifier*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FPlayerMappableKeyProfileCreationArgs
{
public:
    UClass* ProfileType() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTag ProfileIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FString ProfileStringIdentifier() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FPlatformUserId UserId() const { return Read<FPlatformUserId>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)
    bool bSetAsCurrentProfile() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x0) & 1; } // 0x38:0 (Size: 0x1, Type: BoolProperty)

    void SET_ProfileType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_ProfileIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_ProfileStringIdentifier(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_UserId(const FPlatformUserId& Value) { Write<FPlatformUserId>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
    void SET_bSetAsCurrentProfile(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
struct FPlayerKeyMapping
{
public:
    FName MappingName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText DisplayCategory() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    uint8_t Slot() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    bool bIsDirty() const { return (Read<uint8_t>(uintptr_t(this) + 0x29) >> 0x0) & 1; } // 0x29:0 (Size: 0x1, Type: BoolProperty)
    FKey DefaultKey() const { return Read<FKey>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FKey CurrentKey() const { return Read<FKey>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FHardwareDeviceIdentifier HardwareDeviceId() const { return Read<FHardwareDeviceIdentifier>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)
    UInputAction* AssociatedInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UInputAction> AssociatedInputActionSoft() const { return Read<TSoftObjectPtr<UInputAction>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x20, Type: SoftObjectProperty)

    void SET_MappingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_DisplayCategory(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_Slot(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_bIsDirty(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x29); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x29, B); } // 0x29:0 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_CurrentKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_HardwareDeviceId(const FHardwareDeviceIdentifier& Value) { Write<FHardwareDeviceIdentifier>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
    void SET_AssociatedInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_AssociatedInputActionSoft(const TSoftObjectPtr<UInputAction>& Value) { Write<TSoftObjectPtr<UInputAction>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x40
struct FMapPlayerKeyArgs
{
public:
    FName MappingName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Slot() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    FKey NewKey() const { return Read<FKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FName HardwareDeviceId() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    FGameplayTag ProfileId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)
    FString ProfileIdString() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    bool bCreateMatchingSlotIfNeeded() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x0) & 1; } // 0x38:0 (Size: 0x1, Type: BoolProperty)
    bool bDeferOnSettingsChangedBroadcast() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x1) & 1; } // 0x38:1 (Size: 0x1, Type: BoolProperty)

    void SET_MappingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Slot(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_NewKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_HardwareDeviceId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_ProfileId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
    void SET_ProfileIdString(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_bCreateMatchingSlotIfNeeded(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDeferOnSettingsChangedBroadcast(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
struct FInputActionInstance
{
public:
    UInputAction* SourceAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t TriggerEvent() const { return Read<uint8_t>(uintptr_t(this) + 0x13); } // 0x13 (Size: 0x1, Type: EnumProperty)
    float LastTriggeredWorldTime() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    TArray<UInputTrigger*> Triggers() const { return Read<TArray<UInputTrigger*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers() const { return Read<TArray<UInputModifier*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    float ElapsedProcessedTime() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float ElapsedTriggeredTime() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)

    void SET_SourceAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TriggerEvent(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x13, Value); } // 0x13 (Size: 0x1, Type: EnumProperty)
    void SET_LastTriggeredWorldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Triggers(const TArray<UInputTrigger*>& Value) { Write<TArray<UInputTrigger*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Modifiers(const TArray<UInputModifier*>& Value) { Write<TArray<UInputModifier*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ElapsedProcessedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_ElapsedTriggeredTime(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FKeyMappingRow
{
public:
    TSet<FPlayerKeyMapping> Mappings() const { return Read<TSet<FPlayerKeyMapping>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: SetProperty)

    void SET_Mappings(const TSet<FPlayerKeyMapping>& Value) { Write<TSet<FPlayerKeyMapping>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: SetProperty)
};

// Size: 0x28
struct FPlayerMappableKeyQueryOptions
{
public:
    FName MappingName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FKey KeyToMatch() const { return Read<FKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t SlotToMatch() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bMatchBasicKeyTypes() const { return (Read<uint8_t>(uintptr_t(this) + 0x21) >> 0x0) & 1; } // 0x21:0 (Size: 0x1, Type: BoolProperty)
    bool bMatchKeyAxisType() const { return (Read<uint8_t>(uintptr_t(this) + 0x21) >> 0x1) & 1; } // 0x21:1 (Size: 0x1, Type: BoolProperty)
    uint8_t RequiredDeviceType() const { return Read<uint8_t>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: EnumProperty)
    int32_t RequiredDeviceFlags() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)

    void SET_MappingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_KeyToMatch(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_SlotToMatch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bMatchBasicKeyTypes(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x21); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x21, B); } // 0x21:0 (Size: 0x1, Type: BoolProperty)
    void SET_bMatchKeyAxisType(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x21); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x21, B); } // 0x21:1 (Size: 0x1, Type: BoolProperty)
    void SET_RequiredDeviceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: EnumProperty)
    void SET_RequiredDeviceFlags(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FMappingQueryIssue
{
public:
    uint8_t Issue() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    UInputMappingContext* BlockingContext() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UInputAction* BlockingAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Issue(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_BlockingContext(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_BlockingAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
struct FEnhancedActionKeyMapping
{
public:
    TArray<UInputTrigger*> Triggers() const { return Read<TArray<UInputTrigger*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers() const { return Read<TArray<UInputModifier*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    UInputAction* Action() const { return Read<UInputAction*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    FKey Key() const { return Read<FKey>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    bool bShouldBeIgnored() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x0) & 1; } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    bool bHasAlwaysTickTrigger() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x1) & 1; } // 0x40:1 (Size: 0x1, Type: BoolProperty)
    uint8_t SettingBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: EnumProperty)
    UPlayerMappableKeySettings* PlayerMappableKeySettings() const { return Read<UPlayerMappableKeySettings*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_Triggers(const TArray<UInputTrigger*>& Value) { Write<TArray<UInputTrigger*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Modifiers(const TArray<UInputModifier*>& Value) { Write<TArray<UInputModifier*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Action(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_Key(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_bShouldBeIgnored(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    void SET_bHasAlwaysTickTrigger(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:1 (Size: 0x1, Type: BoolProperty)
    void SET_SettingBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: EnumProperty)
    void SET_PlayerMappableKeySettings(const UPlayerMappableKeySettings*& Value) { Write<UPlayerMappableKeySettings*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FBlueprintEnhancedInputActionBinding
{
public:
    UInputAction* InputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t TriggerEvent() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    FName FunctionNameToBind() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)

    void SET_InputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TriggerEvent(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_FunctionNameToBind(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
struct FDefaultContextSetting
{
public:
    TSoftObjectPtr<UInputMappingContext> InputMappingContext() const { return Read<TSoftObjectPtr<UInputMappingContext>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    bool bAddImmediately() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bRegisterWithUserSettings() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)

    void SET_InputMappingContext(const TSoftObjectPtr<UInputMappingContext>& Value) { Write<TSoftObjectPtr<UInputMappingContext>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_bAddImmediately(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_bRegisterWithUserSettings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FModifyContextOptions
{
public:
    bool bIgnoreAllPressedKeysUntilRelease() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bForceImmediately() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    bool bNotifyUserSettings() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x2) & 1; } // 0x0:2 (Size: 0x1, Type: BoolProperty)

    void SET_bIgnoreAllPressedKeysUntilRelease(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bForceImmediately(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bNotifyUserSettings(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FKeyConsumptionOptions
{
public:
};

// Size: 0x10
struct FInjectedInputArray
{
public:
    TArray<FInjectedInput> Injected() const { return Read<TArray<FInjectedInput>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Injected(const TArray<FInjectedInput>& Value) { Write<TArray<FInjectedInput>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FAppliedInputContextData
{
public:
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RegistrationCount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_RegistrationCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FBlueprintInputDebugKeyDelegateBinding
{
public:
    FInputChord InputChord() const { return Read<FInputChord>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<EInputEvent> InputKeyEvent() const { return Read<TEnumAsByte<EInputEvent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: ByteProperty)
    FName FunctionNameToBind() const { return Read<FName>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: NameProperty)
    bool bExecuteWhenPaused() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_InputChord(const FInputChord& Value) { Write<FInputChord>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_InputKeyEvent(const TEnumAsByte<EInputEvent>& Value) { Write<TEnumAsByte<EInputEvent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: ByteProperty)
    void SET_FunctionNameToBind(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: NameProperty)
    void SET_bExecuteWhenPaused(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FInputComboStepData
{
public:
    UInputAction* ComboStepAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    char ComboStepCompletionStates() const { return Read<char>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)
    float TimeToPressKey() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_ComboStepAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ComboStepCompletionStates(const char& Value) { Write<char>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
    void SET_TimeToPressKey(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FInputCancelAction
{
public:
    UInputAction* CancelAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    char CancellationStates() const { return Read<char>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)

    void SET_CancelAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CancellationStates(const char& Value) { Write<char>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
};

