/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Damage
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa68
class UGE_Rock_Explode_VehicleDamage_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Rock_Explode_BuildingDamage_C : public UGET_DirectDamage_LootOnDestroy_C
{
public:
};

// Size: 0xa68
class UGE_Rock_Explode_PlayerDamage_C : public UGet_DirectDamageParent_C
{
public:
};

