/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AndroidFileServer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UAndroidFileServerBPLibrary : public UBlueprintFunctionLibrary
{
public:
};

