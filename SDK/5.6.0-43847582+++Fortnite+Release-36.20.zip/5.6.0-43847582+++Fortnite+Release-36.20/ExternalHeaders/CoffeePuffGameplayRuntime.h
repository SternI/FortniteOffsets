/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoffeePuffGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0x1360
class UCoffeePuffLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    TSoftObjectPtr<UAnimMontage> HookShotMontage() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x20, Type: SoftObjectProperty)
    float EquipBlendOut() const { return Read<float>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x4, Type: FloatProperty)
    double IdleAdditiveAlpha() const { return Read<double>(uintptr_t(this) + 0x1330); } // 0x1330 (Size: 0x8, Type: DoubleProperty)
    double HipOffsetVertical() const { return Read<double>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x8, Type: DoubleProperty)
    double LowerBodyAdditiveLoopSlopeDampFactor() const { return Read<double>(uintptr_t(this) + 0x1340); } // 0x1340 (Size: 0x8, Type: DoubleProperty)
    double CustomPelvisTwist() const { return Read<double>(uintptr_t(this) + 0x1348); } // 0x1348 (Size: 0x8, Type: DoubleProperty)
    bool bHookShot_PullFail() const { return Read<bool>(uintptr_t(this) + 0x1350); } // 0x1350 (Size: 0x1, Type: BoolProperty)
    bool bHookShot_PullSuccess() const { return Read<bool>(uintptr_t(this) + 0x1351); } // 0x1351 (Size: 0x1, Type: BoolProperty)
    bool bApplyLowerBodyCorrective() const { return Read<bool>(uintptr_t(this) + 0x1352); } // 0x1352 (Size: 0x1, Type: BoolProperty)
    bool bIsFiring() const { return Read<bool>(uintptr_t(this) + 0x1353); } // 0x1353 (Size: 0x1, Type: BoolProperty)
    bool bHookShot_Throw() const { return Read<bool>(uintptr_t(this) + 0x1354); } // 0x1354 (Size: 0x1, Type: BoolProperty)
    bool bHookShot_HitSuccess() const { return Read<bool>(uintptr_t(this) + 0x1355); } // 0x1355 (Size: 0x1, Type: BoolProperty)
    bool bAdditiveLoopBlend() const { return Read<bool>(uintptr_t(this) + 0x1356); } // 0x1356 (Size: 0x1, Type: BoolProperty)
    bool bEquipAdditiveToPassThrough() const { return Read<bool>(uintptr_t(this) + 0x1357); } // 0x1357 (Size: 0x1, Type: BoolProperty)
    bool bEquipAdditiveToCorrectiveAdditive() const { return Read<bool>(uintptr_t(this) + 0x1358); } // 0x1358 (Size: 0x1, Type: BoolProperty)
    bool bPassThroughToEquipCorrective() const { return Read<bool>(uintptr_t(this) + 0x1359); } // 0x1359 (Size: 0x1, Type: BoolProperty)
    bool bEquipCorrectiveToPassThrough() const { return Read<bool>(uintptr_t(this) + 0x135a); } // 0x135a (Size: 0x1, Type: BoolProperty)

    void SET_HookShotMontage(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x20, Type: SoftObjectProperty)
    void SET_EquipBlendOut(const float& Value) { Write<float>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x4, Type: FloatProperty)
    void SET_IdleAdditiveAlpha(const double& Value) { Write<double>(uintptr_t(this) + 0x1330, Value); } // 0x1330 (Size: 0x8, Type: DoubleProperty)
    void SET_HipOffsetVertical(const double& Value) { Write<double>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x8, Type: DoubleProperty)
    void SET_LowerBodyAdditiveLoopSlopeDampFactor(const double& Value) { Write<double>(uintptr_t(this) + 0x1340, Value); } // 0x1340 (Size: 0x8, Type: DoubleProperty)
    void SET_CustomPelvisTwist(const double& Value) { Write<double>(uintptr_t(this) + 0x1348, Value); } // 0x1348 (Size: 0x8, Type: DoubleProperty)
    void SET_bHookShot_PullFail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1350, Value); } // 0x1350 (Size: 0x1, Type: BoolProperty)
    void SET_bHookShot_PullSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1351, Value); } // 0x1351 (Size: 0x1, Type: BoolProperty)
    void SET_bApplyLowerBodyCorrective(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1352, Value); } // 0x1352 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFiring(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1353, Value); } // 0x1353 (Size: 0x1, Type: BoolProperty)
    void SET_bHookShot_Throw(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1354, Value); } // 0x1354 (Size: 0x1, Type: BoolProperty)
    void SET_bHookShot_HitSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1355, Value); } // 0x1355 (Size: 0x1, Type: BoolProperty)
    void SET_bAdditiveLoopBlend(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1356, Value); } // 0x1356 (Size: 0x1, Type: BoolProperty)
    void SET_bEquipAdditiveToPassThrough(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1357, Value); } // 0x1357 (Size: 0x1, Type: BoolProperty)
    void SET_bEquipAdditiveToCorrectiveAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1358, Value); } // 0x1358 (Size: 0x1, Type: BoolProperty)
    void SET_bPassThroughToEquipCorrective(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1359, Value); } // 0x1359 (Size: 0x1, Type: BoolProperty)
    void SET_bEquipCorrectiveToPassThrough(const bool& Value) { Write<bool>(uintptr_t(this) + 0x135a, Value); } // 0x135a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
class UFortMovementMode_CoffeePuffPullRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
    TWeakObjectPtr<AActor*> NetPullingActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    bool bNetPullStarted() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    float LocalStartElapsedTime() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float LocalEndElapsedTime() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float LocalKnockbackSpeed() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float LocalInvalidPullStartTime() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    bool bLocalLineOfSight() const { return Read<bool>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: BoolProperty)
    bool bLocalMovementBlocked() const { return Read<bool>(uintptr_t(this) + 0x5d); } // 0x5d (Size: 0x1, Type: BoolProperty)

    void SET_NetPullingActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bNetPullStarted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_LocalStartElapsedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_LocalEndElapsedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_LocalKnockbackSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_LocalInvalidPullStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_bLocalLineOfSight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: BoolProperty)
    void SET_bLocalMovementBlocked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d, Value); } // 0x5d (Size: 0x1, Type: BoolProperty)
};

// Size: 0x640
class UFortMovementMode_ExtCoffeePuffPull : public UFortMovementMode_BaseExtLogic
{
public:
    FFortCachedScalableFloat IgnorePendingLaunchForInitialDuration() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackDuration() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackDistance() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PostKnockbackDelay() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackGravityMultiplier() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackKickUpStrength() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackKickUpDuration() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullSpeed() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullTargetOffset() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat bForceOffsetDistance() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullTargetOffsetMargin() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullMaxDuration() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullMinDuration() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat MinImpactDotProduct() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat SurfaceSlideUnderOverForce() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat MaxInvalidPullTime() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat InterruptClampedSpeed() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat LineOfSightDelay() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat bCheckLineOfSight() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat LineOfSightHeightOffset() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat DisconnectProtectionUpdateRate() const { return Read<FFortCachedScalableFloat>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x30, Type: StructProperty)
    FGameplayTag KnockbackEndEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x4, Type: StructProperty)
    FGameplayTag PullStartEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5f4); } // 0x5f4 (Size: 0x4, Type: StructProperty)
    FGameplayTag PullInvalidatedEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x4, Type: StructProperty)
    FGameplayTag HookshotActiveTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5fc); } // 0x5fc (Size: 0x4, Type: StructProperty)
    FCollisionProfileName LineOfSightCollisionProfile() const { return Read<FCollisionProfileName>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer LineOfSightIgnoreTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x20, Type: StructProperty)

    void SET_IgnorePendingLaunchForInitialDuration(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x30, Type: StructProperty)
    void SET_KnockbackDuration(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x30, Type: StructProperty)
    void SET_KnockbackDistance(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x30, Type: StructProperty)
    void SET_PostKnockbackDelay(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x30, Type: StructProperty)
    void SET_KnockbackGravityMultiplier(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x30, Type: StructProperty)
    void SET_KnockbackKickUpStrength(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x30, Type: StructProperty)
    void SET_KnockbackKickUpDuration(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x30, Type: StructProperty)
    void SET_PullSpeed(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x30, Type: StructProperty)
    void SET_PullTargetOffset(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x30, Type: StructProperty)
    void SET_bForceOffsetDistance(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x30, Type: StructProperty)
    void SET_PullTargetOffsetMargin(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x30, Type: StructProperty)
    void SET_PullMaxDuration(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x30, Type: StructProperty)
    void SET_PullMinDuration(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x30, Type: StructProperty)
    void SET_MinImpactDotProduct(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x30, Type: StructProperty)
    void SET_SurfaceSlideUnderOverForce(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x30, Type: StructProperty)
    void SET_MaxInvalidPullTime(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x30, Type: StructProperty)
    void SET_InterruptClampedSpeed(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x30, Type: StructProperty)
    void SET_LineOfSightDelay(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x30, Type: StructProperty)
    void SET_bCheckLineOfSight(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x30, Type: StructProperty)
    void SET_LineOfSightHeightOffset(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x30, Type: StructProperty)
    void SET_DisconnectProtectionUpdateRate(const FFortCachedScalableFloat& Value) { Write<FFortCachedScalableFloat>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x30, Type: StructProperty)
    void SET_KnockbackEndEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x4, Type: StructProperty)
    void SET_PullStartEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5f4, Value); } // 0x5f4 (Size: 0x4, Type: StructProperty)
    void SET_PullInvalidatedEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x4, Type: StructProperty)
    void SET_HookshotActiveTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5fc, Value); } // 0x5fc (Size: 0x4, Type: StructProperty)
    void SET_LineOfSightCollisionProfile(const FCollisionProfileName& Value) { Write<FCollisionProfileName>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x4, Type: StructProperty)
    void SET_LineOfSightIgnoreTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x20, Type: StructProperty)
};

// Size: 0x18
struct FFortMovementMode_CoffeePuffPullCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
    TWeakObjectPtr<AActor*> PullingActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)

    void SET_PullingActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
};

