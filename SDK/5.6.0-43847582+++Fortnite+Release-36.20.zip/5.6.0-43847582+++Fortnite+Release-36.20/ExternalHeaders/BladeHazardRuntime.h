/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BladeHazardRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x9d8
class AFortBladeHazard : public ABuildingGameplayActor
{
public:
    uint8_t SpinningDirection() const { return Read<uint8_t>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x1, Type: EnumProperty)
    TArray<FTransform> CustomForceDirections() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x10, Type: ArrayProperty)

    void SET_SpinningDirection(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x1, Type: EnumProperty)
    void SET_CustomForceDirections(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x10, Type: ArrayProperty)
};

