/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattleRoyaleFrontend
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x160
class UBattleRoyaleFrontendExperienceFlow : public UObject
{
public:
    TArray<FString> DefaultFlowStepArray() const { return Read<TArray<FString>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> FirstTimeSeasonFlowStepArray() const { return Read<TArray<FString>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> BRVideoRating() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x50, Type: MapProperty)
    TArray<FBattleRoyaleFrontendProductVideoOverride> ProductVideoOverrides() const { return Read<TArray<FBattleRoyaleFrontendProductVideoOverride>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    UClass* HabaneroIntroModalClass() const { return Read<UClass*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ClassProperty)
    UClass* SimpleBuildAndEditModalHelper() const { return Read<UClass*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ClassProperty)

    void SET_DefaultFlowStepArray(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_FirstTimeSeasonFlowStepArray(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_BRVideoRating(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x50, Type: MapProperty)
    void SET_ProductVideoOverrides(const TArray<FBattleRoyaleFrontendProductVideoOverride>& Value) { Write<TArray<FBattleRoyaleFrontendProductVideoOverride>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_HabaneroIntroModalClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ClassProperty)
    void SET_SimpleBuildAndEditModalHelper(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x20
struct FBattleRoyaleFrontendProductVideoOverride
{
public:
    FGameplayTag ProductTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FString MediaID() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FName MediaName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)

    void SET_ProductTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_MediaID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_MediaName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
};

