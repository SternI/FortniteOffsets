/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkLoadouts
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x30
class UBasicCosmeticLoadoutContext : public UObject
{
public:
};

// Size: 0x28
class UCosmeticCustomizableItemDefinition : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticLoadoutContext : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticLoadoutItemDefinition : public UInterface
{
public:
};

// Size: 0x80
class UCosmeticLoadoutSchema : public UPrimaryDataAsset
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> Icon() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag ArchetypeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: StructProperty)
    TArray<UCosmeticLoadoutSlotTemplate*> Slots() const { return Read<TArray<UCosmeticLoadoutSlotTemplate*>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: TextProperty)
    void SET_Icon(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ArchetypeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: StructProperty)
    void SET_Slots(const TArray<UCosmeticLoadoutSlotTemplate*>& Value) { Write<TArray<UCosmeticLoadoutSlotTemplate*>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd0
class UCosmeticLoadoutSlotTemplate : public UPrimaryDataAsset
{
public:
    FGameplayTag SlotTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer MetaTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FCosmeticLoadoutSlotRequirements Requirements() const { return Read<FCosmeticLoadoutSlotRequirements>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: StructProperty)
    FString ShortName() const { return Read<FString>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: StrProperty)
    FPrimaryAssetId DefaultCosmeticItemId() const { return Read<FPrimaryAssetId>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: StructProperty)
    bool bAlwaysUseDefaultCosmeticItemId() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bIsEquippable() const { return Read<bool>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: BoolProperty)

    void SET_SlotTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: StructProperty)
    void SET_MetaTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_Requirements(const FCosmeticLoadoutSlotRequirements& Value) { Write<FCosmeticLoadoutSlotRequirements>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: StructProperty)
    void SET_ShortName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: StrProperty)
    void SET_DefaultCosmeticItemId(const FPrimaryAssetId& Value) { Write<FPrimaryAssetId>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: StructProperty)
    void SET_bAlwaysUseDefaultCosmeticItemId(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEquippable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UCosmeticLoadoutArchetype : public UPrimaryDataAsset
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> Icon() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag ArchetypeGroupTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: StructProperty)
    TArray<UCosmeticLoadoutSchema*> Schemas() const { return Read<TArray<UCosmeticLoadoutSchema*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_Icon(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ArchetypeGroupTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: StructProperty)
    void SET_Schemas(const TArray<UCosmeticLoadoutSchema*>& Value) { Write<TArray<UCosmeticLoadoutSchema*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
class UCosmeticLoadoutSubsystem : public UGameInstanceSubsystem
{
public:
};

// Size: 0x8
struct FCosmeticLoadoutActiveArchetype
{
public:
    FGameplayTag ArchetypeGroupTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ArchetypeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_ArchetypeGroupTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ArchetypeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FCosmeticLoadout
{
public:
    TArray<FCosmeticLoadoutSlot> Slots() const { return Read<TArray<FCosmeticLoadoutSlot>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Slots(const TArray<FCosmeticLoadoutSlot>& Value) { Write<TArray<FCosmeticLoadoutSlot>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FCosmeticLoadoutSlot
{
public:
    UCosmeticLoadoutSlotTemplate* SlotTemplate() const { return Read<UCosmeticLoadoutSlotTemplate*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* EquippedItemDefinitionObject() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<FCosmeticCustomizationInfo> CustomizationInfo() const { return Read<TArray<FCosmeticCustomizationInfo>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_SlotTemplate(const UCosmeticLoadoutSlotTemplate*& Value) { Write<UCosmeticLoadoutSlotTemplate*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_EquippedItemDefinitionObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomizationInfo(const TArray<FCosmeticCustomizationInfo>& Value) { Write<TArray<FCosmeticCustomizationInfo>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FCosmeticCustomizationInfo
{
public:
    FGameplayTag ChannelTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag VariantTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FString AdditionalData() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_ChannelTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_VariantTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_AdditionalData(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0xc0
struct FCosmeticBackendLoadoutGroup
{
public:
    TMap<FString, FCosmeticBackendLoadoutGroupSlot> Slots() const { return Read<TMap<FString, FCosmeticBackendLoadoutGroupSlot>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    FString ShuffleType() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    FString FavoriteStatus() const { return Read<FString>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StrProperty)
    FString DisplayName() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    FString ItemId() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)
    FString LinkedPresetId() const { return Read<FString>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StrProperty)
    FString PresetId() const { return Read<FString>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StrProperty)
    int32_t PresetIndex() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    FDateTime CreationTime() const { return Read<FDateTime>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: StructProperty)

    void SET_Slots(const TMap<FString, FCosmeticBackendLoadoutGroupSlot>& Value) { Write<TMap<FString, FCosmeticBackendLoadoutGroupSlot>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_ShuffleType(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_FavoriteStatus(const FString& Value) { Write<FString>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StrProperty)
    void SET_DisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_ItemId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
    void SET_LinkedPresetId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StrProperty)
    void SET_PresetId(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StrProperty)
    void SET_PresetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_CreationTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x30
struct FCosmeticBackendLoadoutGroupSlot
{
public:
    FString LinkedPresetId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FCosmeticBackendLoadoutSlot> Slots() const { return Read<TArray<FCosmeticBackendLoadoutSlot>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString ShuffleType() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_LinkedPresetId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Slots(const TArray<FCosmeticBackendLoadoutSlot>& Value) { Write<TArray<FCosmeticBackendLoadoutSlot>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ShuffleType(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FCosmeticBackendLoadoutSlot
{
public:
    FPrimaryAssetId SlotTemplate() const { return Read<FPrimaryAssetId>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FPrimaryAssetId EquippedItem() const { return Read<FPrimaryAssetId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FCosmeticCustomizationInfo> CustomizationInfo() const { return Read<TArray<FCosmeticCustomizationInfo>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_SlotTemplate(const FPrimaryAssetId& Value) { Write<FPrimaryAssetId>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_EquippedItem(const FPrimaryAssetId& Value) { Write<FPrimaryAssetId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_CustomizationInfo(const TArray<FCosmeticCustomizationInfo>& Value) { Write<TArray<FCosmeticCustomizationInfo>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FCosmeticLoadoutSlotRequirements
{
public:
    FGameplayTagContainer RequiredTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DeniedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    TArray<FPrimaryAssetType> AllowedItemTypes() const { return Read<TArray<FPrimaryAssetType>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_RequiredTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_DeniedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_AllowedItemTypes(const TArray<FPrimaryAssetType>& Value) { Write<TArray<FPrimaryAssetType>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
struct FCosmeticBackendLoadout
{
public:
    FString ItemId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString PresetId() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t PresetIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    FDateTime CreationTime() const { return Read<FDateTime>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)
    TArray<FCosmeticBackendLoadoutSlot> Slots() const { return Read<TArray<FCosmeticBackendLoadoutSlot>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer UserTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FString DisplayName() const { return Read<FString>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StrProperty)
    FString FavoriteStatus() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)

    void SET_ItemId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_PresetId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_PresetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_CreationTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
    void SET_Slots(const TArray<FCosmeticBackendLoadoutSlot>& Value) { Write<TArray<FCosmeticBackendLoadoutSlot>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_UserTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_DisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StrProperty)
    void SET_FavoriteStatus(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
};

