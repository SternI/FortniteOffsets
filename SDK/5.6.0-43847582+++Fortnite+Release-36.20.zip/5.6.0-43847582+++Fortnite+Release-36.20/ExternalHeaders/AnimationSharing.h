/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationSharing
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x48
class UAnimationSharingStateProcessor : public UObject
{
public:
    TSoftObjectPtr<UEnum> AnimationStateEnum() const { return Read<TSoftObjectPtr<UEnum>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_AnimationStateEnum(const TSoftObjectPtr<UEnum>& Value) { Write<TSoftObjectPtr<UEnum>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x400
class UAnimSharingStateInstance : public UAnimInstance
{
public:
    UAnimSequence* AnimationToPlay() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    float PermutationTimeOffset() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    bool bStateBool() const { return Read<bool>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x1, Type: BoolProperty)
    UAnimSharingInstance* Instance() const { return Read<UAnimSharingInstance*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)

    void SET_AnimationToPlay(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_PermutationTimeOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    void SET_bStateBool(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x1, Type: BoolProperty)
    void SET_Instance(const UAnimSharingInstance*& Value) { Write<UAnimSharingInstance*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3f0
class UAnimSharingTransitionInstance : public UAnimInstance
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> FromComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> ToComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    bool bBlendBool() const { return Read<bool>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x1, Type: BoolProperty)

    void SET_FromComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ToComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_bBlendBool(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3f0
class UAnimSharingAdditiveInstance : public UAnimInstance
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> BaseComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAnimSequence*> AdditiveAnimation() const { return Read<TWeakObjectPtr<UAnimSequence*>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    bool bStateBool() const { return Read<bool>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x1, Type: BoolProperty)

    void SET_BaseComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AdditiveAnimation(const TWeakObjectPtr<UAnimSequence*>& Value) { Write<TWeakObjectPtr<UAnimSequence*>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_bStateBool(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
class UAnimSharingInstance : public UObject
{
public:
    TArray<AActor*> RegisteredActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    UAnimationSharingStateProcessor* StateProcessor() const { return Read<UAnimationSharingStateProcessor*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    TArray<UAnimSequence*> UsedAnimationSequences() const { return Read<TArray<UAnimSequence*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    UEnum* StateEnum() const { return Read<UEnum*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    AActor* SharingActor() const { return Read<AActor*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)

    void SET_RegisteredActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_StateProcessor(const UAnimationSharingStateProcessor*& Value) { Write<UAnimationSharingStateProcessor*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_UsedAnimationSequences(const TArray<UAnimSequence*>& Value) { Write<TArray<UAnimSequence*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_StateEnum(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_SharingActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UAnimationSharingManager : public UObject
{
public:
    TArray<USkeleton*> Skeletons() const { return Read<TArray<USkeleton*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UAnimSharingInstance*> PerSkeletonData() const { return Read<TArray<UAnimSharingInstance*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Skeletons(const TArray<USkeleton*>& Value) { Write<TArray<USkeleton*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_PerSkeletonData(const TArray<UAnimSharingInstance*>& Value) { Write<TArray<UAnimSharingInstance*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x48
class UAnimationSharingSetup : public UObject
{
public:
    TArray<FPerSkeletonAnimationSharingSetup> SkeletonSetups() const { return Read<TArray<FPerSkeletonAnimationSharingSetup>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FAnimationSharingScalability ScalabilitySettings() const { return Read<FAnimationSharingScalability>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_SkeletonSetups(const TArray<FPerSkeletonAnimationSharingSetup>& Value) { Write<TArray<FPerSkeletonAnimationSharingSetup>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ScalabilitySettings(const FAnimationSharingScalability& Value) { Write<FAnimationSharingScalability>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FAnimationSetup
{
public:
    UAnimSequence* AnimSequence() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UClass* AnimBlueprint() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    FPerPlatformInt NumRandomizedInstances() const { return Read<FPerPlatformInt>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    FPerPlatformBool Enabled() const { return Read<FPerPlatformBool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: StructProperty)

    void SET_AnimSequence(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimBlueprint(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_NumRandomizedInstances(const FPerPlatformInt& Value) { Write<FPerPlatformInt>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_Enabled(const FPerPlatformBool& Value) { Write<FPerPlatformBool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: StructProperty)
};

// Size: 0x30
struct FAnimationStateEntry
{
public:
    char State() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    TArray<FAnimationSetup> AnimationSetups() const { return Read<TArray<FAnimationSetup>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bOnDemand() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bAdditive() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bReturnToPreviousState() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bSetNextState() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    char NextState() const { return Read<char>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: ByteProperty)
    FPerPlatformInt MaximumNumberOfConcurrentInstances() const { return Read<FPerPlatformInt>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)
    float WiggleTimePercentage() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bRequiresCurves() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_State(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_AnimationSetups(const TArray<FAnimationSetup>& Value) { Write<TArray<FAnimationSetup>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_bOnDemand(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_bReturnToPreviousState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bSetNextState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_NextState(const char& Value) { Write<char>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: ByteProperty)
    void SET_MaximumNumberOfConcurrentInstances(const FPerPlatformInt& Value) { Write<FPerPlatformInt>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
    void SET_WiggleTimePercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_bRequiresCurves(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FPerSkeletonAnimationSharingSetup
{
public:
    USkeleton* Skeleton() const { return Read<USkeleton*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* BlendAnimBlueprint() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)
    UClass* AdditiveAnimBlueprint() const { return Read<UClass*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ClassProperty)
    UClass* StateProcessorClass() const { return Read<UClass*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ClassProperty)
    bool bEnableMaterialParameterCaching() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TArray<FAnimationStateEntry> AnimationStates() const { return Read<TArray<FAnimationStateEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Skeleton(const USkeleton*& Value) { Write<USkeleton*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendAnimBlueprint(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
    void SET_AdditiveAnimBlueprint(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ClassProperty)
    void SET_StateProcessorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ClassProperty)
    void SET_bEnableMaterialParameterCaching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_AnimationStates(const TArray<FAnimationStateEntry>& Value) { Write<TArray<FAnimationStateEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAnimationSharingScalability
{
public:
    FPerPlatformBool UseBlendTransitions() const { return Read<FPerPlatformBool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: StructProperty)
    FPerPlatformFloat BlendSignificanceValue() const { return Read<FPerPlatformFloat>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FPerPlatformInt MaximumNumberConcurrentBlends() const { return Read<FPerPlatformInt>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FPerPlatformFloat TickSignificanceValue() const { return Read<FPerPlatformFloat>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)

    void SET_UseBlendTransitions(const FPerPlatformBool& Value) { Write<FPerPlatformBool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: StructProperty)
    void SET_BlendSignificanceValue(const FPerPlatformFloat& Value) { Write<FPerPlatformFloat>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_MaximumNumberConcurrentBlends(const FPerPlatformInt& Value) { Write<FPerPlatformInt>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_TickSignificanceValue(const FPerPlatformFloat& Value) { Write<FPerPlatformFloat>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
};

// Size: 0x30
struct FTickAnimationSharingFunction : public FTickFunction
{
public:
};

