/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DirectLink
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x8
struct FDirectLinkMsg_EndpointLifecycle
{
public:
    char LifecycleState() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    uint32_t EndpointStateRevision() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)

    void SET_LifecycleState(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_EndpointStateRevision(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x28
struct FNamedId
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    bool bIsPublic() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_bIsPublic(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
struct FDirectLinkMsg_EndpointState
{
public:
    uint32_t StateRevision() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t MinProtocolVersion() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t ProtocolVersion() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)
    FString UEVersion() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString ComputerName() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FString UserName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    uint32_t ProcessId() const { return Read<uint32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: UInt32Property)
    FString ExecutableName() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    FString NiceName() const { return Read<FString>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StrProperty)
    TArray<FNamedId> Destinations() const { return Read<TArray<FNamedId>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FNamedId> Sources() const { return Read<TArray<FNamedId>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_StateRevision(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_MinProtocolVersion(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_ProtocolVersion(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
    void SET_UEVersion(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_ComputerName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_UserName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_ProcessId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: UInt32Property)
    void SET_ExecutableName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_NiceName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StrProperty)
    void SET_Destinations(const TArray<FNamedId>& Value) { Write<TArray<FNamedId>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_Sources(const TArray<FNamedId>& Value) { Write<TArray<FNamedId>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FDirectLinkMsg_QueryEndpointState
{
public:
};

// Size: 0x28
struct FDirectLinkMsg_OpenStreamRequest
{
public:
    bool bRequestFromSource() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    int32_t RequestFromStreamPort() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FGuid SourceGuid() const { return Read<FGuid>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FGuid DestinationGuid() const { return Read<FGuid>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_bRequestFromSource(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_RequestFromStreamPort(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_SourceGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_DestinationGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FDirectLinkMsg_OpenStreamAnswer
{
public:
    int32_t RecipientStreamPort() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    bool bAccepted() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FString Error() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t OpenedStreamPort() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_RecipientStreamPort(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_bAccepted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_Error(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_OpenedStreamPort(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x4
struct FDirectLinkMsg_CloseStreamRequest
{
public:
    int32_t RecipientStreamPort() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_RecipientStreamPort(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FDirectLinkMsg_DeltaMessage
{
public:
    int32_t DestinationStreamPort() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int8_t BatchCode() const { return Read<int8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: Int8Property)
    int32_t MessageCode() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    char Kind() const { return Read<char>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: ByteProperty)
    bool CompressedPayload() const { return Read<bool>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: BoolProperty)
    TArray<char> Payload() const { return Read<TArray<char>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_DestinationStreamPort(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_BatchCode(const int8_t& Value) { Write<int8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: Int8Property)
    void SET_MessageCode(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Kind(const char& Value) { Write<char>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: ByteProperty)
    void SET_CompressedPayload(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: BoolProperty)
    void SET_Payload(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FDirectLinkMsg_HaveListMessage
{
public:
    int32_t SourceStreamPort() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SyncCycle() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MessageCode() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    char Kind() const { return Read<char>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: ByteProperty)
    TArray<char> Payload() const { return Read<TArray<char>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> NodeIds() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> Hashes() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_SourceStreamPort(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SyncCycle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_MessageCode(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Kind(const char& Value) { Write<char>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: ByteProperty)
    void SET_Payload(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_NodeIds(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Hashes(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

