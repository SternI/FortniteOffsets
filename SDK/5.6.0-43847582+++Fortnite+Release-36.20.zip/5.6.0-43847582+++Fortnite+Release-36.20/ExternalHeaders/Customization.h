/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Customization
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "Engine.h"
#include "UIKit.h"
#include "CommonUI.h"

// Size: 0x2f8
class UWBP_CustomItemDetailsBase_C : public UUserWidget
{
public:
};

// Size: 0x310
class UWBP_CustomItemDetailsContainer_C : public UUserWidget
{
public:
    UNamedSlot* NamedSlot_CustomDetails() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)

    void SET_NamedSlot_CustomDetails(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x520
class UWBP_UIKit_ItemDescription_MPL_C : public UWBP_UIKit_ItemDescription_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_InfoBox_C* AccessRestriction_Warning() const { return Read<UWBP_UIKit_InfoBox_C*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UFortItemDetailsVM* FortItemDetailsVM() const { return Read<UFortItemDetailsVM*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryItemVM* FortLockerCategoryItemVM() const { return Read<UFortLockerCategoryItemVM*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: StructProperty)
    void SET_AccessRestriction_Warning(const UWBP_UIKit_InfoBox_C*& Value) { Write<UWBP_UIKit_InfoBox_C*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_FortItemDetailsVM(const UFortItemDetailsVM*& Value) { Write<UFortItemDetailsVM*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_FortLockerCategoryItemVM(const UFortLockerCategoryItemVM*& Value) { Write<UFortLockerCategoryItemVM*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x311
class UWBP_MPLocker_Heading_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SubHeader() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Header() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool Show_Sub_Heading_() const { return Read<bool>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    void SET_Text_SubHeader(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Header(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_Show_Sub_Heading_(const bool& Value) { Write<bool>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x1, Type: BoolProperty)
};

