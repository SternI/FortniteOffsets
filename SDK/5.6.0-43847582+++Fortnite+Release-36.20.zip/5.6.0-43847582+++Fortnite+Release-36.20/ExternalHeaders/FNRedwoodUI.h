/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNRedwoodUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x1590
class UFNRedwoodFeedbackInjector : public USocialListEntryBase
{
public:
    FName ReportId() const { return Read<FName>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x4, Type: NameProperty)
    FName ReportInjectCategoryName() const { return Read<FName>(uintptr_t(this) + 0x155c); } // 0x155c (Size: 0x4, Type: NameProperty)
    FText ReportOption() const { return Read<FText>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x10, Type: TextProperty)
    FText ReportOptionSummary() const { return Read<FText>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x10, Type: TextProperty)
    FText ReportOptionDescription() const { return Read<FText>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x10, Type: TextProperty)

    void SET_ReportId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x4, Type: NameProperty)
    void SET_ReportInjectCategoryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x155c, Value); } // 0x155c (Size: 0x4, Type: NameProperty)
    void SET_ReportOption(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x10, Type: TextProperty)
    void SET_ReportOptionSummary(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x10, Type: TextProperty)
    void SET_ReportOptionDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x10, Type: TextProperty)
};

