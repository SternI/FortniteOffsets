/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayBehaviorSmartObjectsModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayBehaviorsModule.h"
#include "Engine.h"
#include "AIModule.h"
#include "SmartObjectsModule.h"
#include "GameplayTags.h"

// Size: 0x30
class UGameplayBehaviorSmartObjectBehaviorDefinition : public USmartObjectBehaviorDefinition
{
public:
    UGameplayBehaviorConfig* GameplayBehaviorConfig() const { return Read<UGameplayBehaviorConfig*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayBehaviorConfig(const UGameplayBehaviorConfig*& Value) { Write<UGameplayBehaviorConfig*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UAITask_UseGameplayBehaviorSmartObject : public UAITask
{
public:
    UAITask_MoveTo* MoveToTask() const { return Read<UAITask_MoveTo*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    UGameplayBehavior* GameplayBehavior() const { return Read<UGameplayBehavior*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_MoveToTask(const UAITask_MoveTo*& Value) { Write<UAITask_MoveTo*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayBehavior(const UGameplayBehavior*& Value) { Write<UGameplayBehavior*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x120
class UBTTask_FindAndUseGameplayBehaviorSmartObject : public UBTTaskNode
{
public:
    FGameplayTagQuery ActivityRequirements() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x48, Type: StructProperty)
    uint8_t ClaimPriority() const { return Read<uint8_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: EnumProperty)
    FEQSParametrizedQueryExecutionRequest EQSRequest() const { return Read<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x48, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)

    void SET_ActivityRequirements(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x48, Type: StructProperty)
    void SET_ClaimPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: EnumProperty)
    void SET_EQSRequest(const FEQSParametrizedQueryExecutionRequest& Value) { Write<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x48, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UGameplayBehaviorSmartObjectsBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

