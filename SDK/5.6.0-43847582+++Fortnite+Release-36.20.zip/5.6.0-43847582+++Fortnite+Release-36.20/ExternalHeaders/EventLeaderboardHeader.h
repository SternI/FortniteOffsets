/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventLeaderboardHeader
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CommonUI.h"

// Size: 0x788
class UEventLeaderboardHeader_C : public UFortShowdownDetailView
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_RoundTitle() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* CommonBorder_ScoringTitleBG() const { return Read<UCommonBorder*>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x8, Type: StructProperty)
    void SET_Text_RoundTitle(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x8, Type: ObjectProperty)
    void SET_CommonBorder_ScoringTitleBG(const UCommonBorder*& Value) { Write<UCommonBorder*>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x8, Type: ObjectProperty)
};

