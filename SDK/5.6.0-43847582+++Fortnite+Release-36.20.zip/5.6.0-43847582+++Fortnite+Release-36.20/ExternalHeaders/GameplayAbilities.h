/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayAbilities
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "DataRegistry.h"
#include "MovieScene.h"
#include "PhysicsCore.h"
#include "GameplayTasks.h"
#include "Niagara.h"

// Size: 0xf0
class UB_BRAccoladesPlayerComponent_C : public UFortControllerComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* Player_Pawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Gameplay_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: StructProperty)
    void SET_Player_Pawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Gameplay_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x398
class AAbilitySystemDebugHUD : public AHUD
{
public:
};

// Size: 0x38
class UAbilitiesGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<FGameplayAbilitySpecConfig> GrantAbilityConfigs() const { return Read<TArray<FGameplayAbilitySpecConfig>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_GrantAbilityConfigs(const TArray<FGameplayAbilitySpecConfig>& Value) { Write<TArray<FGameplayAbilitySpecConfig>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa68
class UGameplayEffect : public UObject
{
public:
    uint8_t DurationPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FGameplayEffectModifierMagnitude DurationMagnitude() const { return Read<FGameplayEffectModifierMagnitude>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1d8, Type: StructProperty)
    FScalableFloat Period() const { return Read<FScalableFloat>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x28, Type: StructProperty)
    bool bExecutePeriodicEffectOnApplication() const { return Read<bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: BoolProperty)
    uint8_t PeriodicInhibitionPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x239); } // 0x239 (Size: 0x1, Type: EnumProperty)
    TArray<FGameplayModifierInfo> Modifiers() const { return Read<TArray<FGameplayModifierInfo>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayEffectExecutionDefinition> Executions() const { return Read<TArray<FGameplayEffectExecutionDefinition>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat ChanceToApplyToTarget() const { return Read<FScalableFloat>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x28, Type: StructProperty)
    TArray<UClass*> ApplicationRequirements() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    TArray<FConditionalGameplayEffect> ConditionalGameplayEffects() const { return Read<TArray<FConditionalGameplayEffect>>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OverflowEffects() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    bool bDenyOverflowApplication() const { return Read<bool>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x1, Type: BoolProperty)
    bool bClearStackOnOverflow() const { return Read<bool>(uintptr_t(this) + 0x2b9); } // 0x2b9 (Size: 0x1, Type: BoolProperty)
    TArray<UClass*> PrematureExpirationEffectClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> RoutineExpirationEffectClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    bool bRequireModifierSuccessToTriggerCues() const { return Read<bool>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x1, Type: BoolProperty)
    bool bSuppressStackingCues() const { return Read<bool>(uintptr_t(this) + 0x2e1); } // 0x2e1 (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayEffectCue> GameplayCues() const { return Read<TArray<FGameplayEffectCue>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    UGameplayEffectUIData* UIData() const { return Read<UGameplayEffectUIData*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    FInheritedTagContainer InheritableGameplayEffectTags() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x60, Type: StructProperty)
    FInheritedTagContainer InheritableOwnedTagsContainer() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x60, Type: StructProperty)
    FInheritedTagContainer InheritableBlockedAbilityTagsContainer() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x60, Type: StructProperty)
    FGameplayTagRequirements OngoingTagRequirements() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements ApplicationTagRequirements() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements RemovalTagRequirements() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x88, Type: StructProperty)
    FInheritedTagContainer RemoveGameplayEffectsWithTags() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x60, Type: StructProperty)
    FGameplayTagRequirements GrantedApplicationImmunityTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x88, Type: StructProperty)
    FGameplayEffectQuery GrantedApplicationImmunityQuery() const { return Read<FGameplayEffectQuery>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x198, Type: StructProperty)
    FGameplayEffectQuery RemoveGameplayEffectQuery() const { return Read<FGameplayEffectQuery>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x198, Type: StructProperty)
    uint8_t StackingType() const { return Read<uint8_t>(uintptr_t(this) + 0x9d9); } // 0x9d9 (Size: 0x1, Type: EnumProperty)
    int32_t StackLimitCount() const { return Read<int32_t>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x4, Type: IntProperty)
    uint8_t StackDurationRefreshPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x1, Type: EnumProperty)
    uint8_t StackPeriodResetPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x9e1); } // 0x9e1 (Size: 0x1, Type: EnumProperty)
    uint8_t StackExpirationPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x9e2); } // 0x9e2 (Size: 0x1, Type: EnumProperty)
    bool bFactorInStackCount() const { return Read<bool>(uintptr_t(this) + 0x9e3); } // 0x9e3 (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayAbilitySpecDef> GrantedAbilities() const { return Read<TArray<FGameplayAbilitySpecDef>>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x10, Type: ArrayProperty)
    TArray<UGameplayEffectComponent*> GEComponents() const { return Read<TArray<UGameplayEffectComponent*>>(uintptr_t(this) + 0xa58); } // 0xa58 (Size: 0x10, Type: ArrayProperty)

    void SET_DurationPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_DurationMagnitude(const FGameplayEffectModifierMagnitude& Value) { Write<FGameplayEffectModifierMagnitude>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1d8, Type: StructProperty)
    void SET_Period(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x28, Type: StructProperty)
    void SET_bExecutePeriodicEffectOnApplication(const bool& Value) { Write<bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: BoolProperty)
    void SET_PeriodicInhibitionPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x239, Value); } // 0x239 (Size: 0x1, Type: EnumProperty)
    void SET_Modifiers(const TArray<FGameplayModifierInfo>& Value) { Write<TArray<FGameplayModifierInfo>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x10, Type: ArrayProperty)
    void SET_Executions(const TArray<FGameplayEffectExecutionDefinition>& Value) { Write<TArray<FGameplayEffectExecutionDefinition>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x10, Type: ArrayProperty)
    void SET_ChanceToApplyToTarget(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x28, Type: StructProperty)
    void SET_ApplicationRequirements(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    void SET_ConditionalGameplayEffects(const TArray<FConditionalGameplayEffect>& Value) { Write<TArray<FConditionalGameplayEffect>>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x10, Type: ArrayProperty)
    void SET_OverflowEffects(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_bDenyOverflowApplication(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x1, Type: BoolProperty)
    void SET_bClearStackOnOverflow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b9, Value); } // 0x2b9 (Size: 0x1, Type: BoolProperty)
    void SET_PrematureExpirationEffectClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    void SET_RoutineExpirationEffectClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    void SET_bRequireModifierSuccessToTriggerCues(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x1, Type: BoolProperty)
    void SET_bSuppressStackingCues(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e1, Value); } // 0x2e1 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayCues(const TArray<FGameplayEffectCue>& Value) { Write<TArray<FGameplayEffectCue>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    void SET_UIData(const UGameplayEffectUIData*& Value) { Write<UGameplayEffectUIData*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_InheritableGameplayEffectTags(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x60, Type: StructProperty)
    void SET_InheritableOwnedTagsContainer(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x60, Type: StructProperty)
    void SET_InheritableBlockedAbilityTagsContainer(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x60, Type: StructProperty)
    void SET_OngoingTagRequirements(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x88, Type: StructProperty)
    void SET_ApplicationTagRequirements(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x88, Type: StructProperty)
    void SET_RemovalTagRequirements(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x88, Type: StructProperty)
    void SET_RemoveGameplayEffectsWithTags(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x60, Type: StructProperty)
    void SET_GrantedApplicationImmunityTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x88, Type: StructProperty)
    void SET_GrantedApplicationImmunityQuery(const FGameplayEffectQuery& Value) { Write<FGameplayEffectQuery>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x198, Type: StructProperty)
    void SET_RemoveGameplayEffectQuery(const FGameplayEffectQuery& Value) { Write<FGameplayEffectQuery>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x198, Type: StructProperty)
    void SET_StackingType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9d9, Value); } // 0x9d9 (Size: 0x1, Type: EnumProperty)
    void SET_StackLimitCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x4, Type: IntProperty)
    void SET_StackDurationRefreshPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x1, Type: EnumProperty)
    void SET_StackPeriodResetPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9e1, Value); } // 0x9e1 (Size: 0x1, Type: EnumProperty)
    void SET_StackExpirationPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9e2, Value); } // 0x9e2 (Size: 0x1, Type: EnumProperty)
    void SET_bFactorInStackCount(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9e3, Value); } // 0x9e3 (Size: 0x1, Type: BoolProperty)
    void SET_GrantedAbilities(const TArray<FGameplayAbilitySpecDef>& Value) { Write<TArray<FGameplayAbilitySpecDef>>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x10, Type: ArrayProperty)
    void SET_GEComponents(const TArray<UGameplayEffectComponent*>& Value) { Write<TArray<UGameplayEffectComponent*>>(uintptr_t(this) + 0xa58, Value); } // 0xa58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UGameplayEffectComponent : public UObject
{
public:
};

// Size: 0x58
class UAbilityAsync_WaitGameplayTagCountChanged : public UAbilityAsync
{
public:
};

// Size: 0x38
class UAbilityAsync : public UCancellableAsyncAction
{
public:
};

// Size: 0x28
class UAbilitySystemCheatManagerExtension : public UCheatManagerExtension
{
public:
};

// Size: 0x128
class UAbilityTask_PlayAnimAndWait : public UAbilityTask
{
public:
    UAnimSequence* AnimSequenceToPlay() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)

    void SET_AnimSequenceToPlay(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
class UAbilityTask : public UGameplayTask
{
public:
    UGameplayAbility* ability() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> AbilitySystemComponent() const { return Read<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ability(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilitySystemComponent(const TWeakObjectPtr<UAbilitySystemComponent*>& Value) { Write<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xa0
class UAbilityTask_WaitGameplayTagCountChanged : public UAbilityTask
{
public:
    UAbilitySystemComponent* OptionalExternalTarget() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_OptionalExternalTarget(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x70
class UAdditionalEffectsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    bool bOnApplicationCopyDataFromOriginalSpec() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TArray<FConditionalGameplayEffect> OnApplicationGameplayEffects() const { return Read<TArray<FConditionalGameplayEffect>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OnCompleteAlways() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OnCompleteNormal() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OnCompletePrematurely() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)

    void SET_bOnApplicationCopyDataFromOriginalSpec(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_OnApplicationGameplayEffects(const TArray<FConditionalGameplayEffect>& Value) { Write<TArray<FConditionalGameplayEffect>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_OnCompleteAlways(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_OnCompleteNormal(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_OnCompletePrematurely(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
class UAssetTagsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FInheritedTagContainer InheritableAssetTags() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x60, Type: StructProperty)

    void SET_InheritableAssetTags(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x60, Type: StructProperty)
};

// Size: 0x88
class UBlockAbilityTagsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FInheritedTagContainer InheritableBlockedAbilityTagsContainer() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x60, Type: StructProperty)

    void SET_InheritableBlockedAbilityTagsContainer(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x60, Type: StructProperty)
};

// Size: 0x50
class UChanceToApplyGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FScalableFloat ChanceToApplyToTarget() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)

    void SET_ChanceToApplyToTarget(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
};

// Size: 0x38
class UCustomCanApplyGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<UClass*> ApplicationRequirements() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ApplicationRequirements(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x138
class UGameplayAbilitiesDeveloperSettings : public UDeveloperSettings
{
public:
    FSoftClassPath AbilitySystemGlobalsClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    bool bUseDebugTargetFromHud() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    TArray<FSoftObjectPath> GlobalAttributeSetDefaultsTableNames() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GlobalAttributeMetaDataTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FSoftClassPath GlobalGameplayCueManagerClass() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath GlobalGameplayCueManagerName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    TArray<FString> GameplayCueNotifyPaths() const { return Read<TArray<FString>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GlobalCurveTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    bool PredictTargetGameplayEffects() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool ReplicateActivationOwnedTags() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    FGameplayTag ActivateFailCanActivateAbilityTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailCooldownTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailCostTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailNetworkingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailTagsBlockedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailTagsMissingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: StructProperty)
    FSoftObjectPath GameplayTagResponseTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    bool bAllowGameplayModEvaluationChannels() const { return Read<bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: BoolProperty)
    uint8_t DefaultGameplayModEvaluationChannel() const { return Read<uint8_t>(uintptr_t(this) + 0x109); } // 0x109 (Size: 0x1, Type: EnumProperty)
    FName GameplayModEvaluationChannelAliases() const { return Read<FName>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x28, Type: NameProperty)
    int32_t MinimalReplicationTagCountBits() const { return Read<int32_t>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: IntProperty)

    void SET_AbilitySystemGlobalsClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_bUseDebugTargetFromHud(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_GlobalAttributeSetDefaultsTableNames(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalAttributeMetaDataTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_GlobalGameplayCueManagerClass(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_GlobalGameplayCueManagerName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_GameplayCueNotifyPaths(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalCurveTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_PredictTargetGameplayEffects(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_ReplicateActivationOwnedTags(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    void SET_ActivateFailCanActivateAbilityTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailCooldownTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailCostTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailNetworkingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailTagsBlockedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailTagsMissingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: StructProperty)
    void SET_GameplayTagResponseTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_bAllowGameplayModEvaluationChannels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultGameplayModEvaluationChannel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x109, Value); } // 0x109 (Size: 0x1, Type: EnumProperty)
    void SET_GameplayModEvaluationChannelAliases(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x28, Type: NameProperty)
    void SET_MinimalReplicationTagCountBits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: IntProperty)
};

// Size: 0x40
class UGameplayAbilitiesEditorDeveloperSettings : public UDeveloperSettingsBackedByCVars
{
public:
    bool bIgnoreCooldowns() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreCosts() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    float AbilitySystemGlobalScaler() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float DebugDrawMaxDistance() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_bIgnoreCooldowns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreCosts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_AbilitySystemGlobalScaler(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_DebugDrawMaxDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
class UGameplayCueNotify_UnitTest : public UGameplayCueNotify_Static
{
public:
};

// Size: 0x38
class UGameplayCueNotify_Static : public UObject
{
public:
    FGameplayTag GameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FName GameplayCueName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    bool IsOverride() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_GameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_GameplayCueName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_IsOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UGameplayEffectUIData : public UGameplayEffectComponent
{
public:
};

// Size: 0x38
class UGameplayEffectUIData_TextOnly : public UGameplayEffectUIData
{
public:
    FText Description() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)

    void SET_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
};

// Size: 0x38
class UImmunityGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<FGameplayEffectQuery> ImmunityQueries() const { return Read<TArray<FGameplayEffectQuery>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ImmunityQueries(const TArray<FGameplayEffectQuery>& Value) { Write<TArray<FGameplayEffectQuery>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class URemoveOtherGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<FGameplayEffectQuery> RemoveGameplayEffectQueries() const { return Read<TArray<FGameplayEffectQuery>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_RemoveGameplayEffectQueries(const TArray<FGameplayEffectQuery>& Value) { Write<TArray<FGameplayEffectQuery>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1c0
class UTargetTagRequirementsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FGameplayTagRequirements ApplicationTagRequirements() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements OngoingTagRequirements() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements RemovalTagRequirements() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x88, Type: StructProperty)

    void SET_ApplicationTagRequirements(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x88, Type: StructProperty)
    void SET_OngoingTagRequirements(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x88, Type: StructProperty)
    void SET_RemovalTagRequirements(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x88, Type: StructProperty)
};

// Size: 0x88
class UTargetTagsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FInheritedTagContainer InheritableGrantedTagsContainer() const { return Read<FInheritedTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x60, Type: StructProperty)

    void SET_InheritableGrantedTagsContainer(const FInheritedTagContainer& Value) { Write<FInheritedTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x60, Type: StructProperty)
};

// Size: 0x90
class UAbilityAsync_WaitAttributeChanged : public UAbilityAsync
{
public:
};

// Size: 0x188
class UAbilityAsync_WaitGameplayEffectApplied : public UAbilityAsync
{
public:
};

// Size: 0x58
class UAbilityAsync_WaitGameplayEvent : public UAbilityAsync
{
public:
};

// Size: 0x50
class UAbilityAsync_WaitGameplayTag : public UAbilityAsync
{
public:
};

// Size: 0x60
class UAbilityAsync_WaitGameplayTagAdded : public UAbilityAsync_WaitGameplayTag
{
public:
};

// Size: 0x60
class UAbilityAsync_WaitGameplayTagRemoved : public UAbilityAsync_WaitGameplayTag
{
public:
};

// Size: 0x108
class UAbilityAsync_WaitGameplayTagQuery : public UAbilityAsync
{
public:
};

// Size: 0x3a8
class UGameplayAbility : public UObject
{
public:
    FGameplayTagContainer AbilityTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: StructProperty)
    bool bReplicateInputDirectly() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool RemoteInstanceEnded() const { return Read<bool>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EGameplayAbilityReplicationPolicy> ReplicationPolicy() const { return Read<TEnumAsByte<EGameplayAbilityReplicationPolicy>>(uintptr_t(this) + 0xce); } // 0xce (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EGameplayAbilityInstancingPolicy> InstancingPolicy() const { return Read<TEnumAsByte<EGameplayAbilityInstancingPolicy>>(uintptr_t(this) + 0xcf); } // 0xcf (Size: 0x1, Type: ByteProperty)
    bool bServerRespectsRemoteAbilityCancellation() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bRetriggerInstancedAbility() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    FGameplayAbilityActivationInfo CurrentActivationInfo() const { return Read<FGameplayAbilityActivationInfo>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x14, Type: StructProperty)
    FGameplayEventData CurrentEventData() const { return Read<FGameplayEventData>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0xb0, Type: StructProperty)
    TEnumAsByte<EGameplayAbilityNetExecutionPolicy> NetExecutionPolicy() const { return Read<TEnumAsByte<EGameplayAbilityNetExecutionPolicy>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EGameplayAbilityNetSecurityPolicy> NetSecurityPolicy() const { return Read<TEnumAsByte<EGameplayAbilityNetSecurityPolicy>>(uintptr_t(this) + 0x199); } // 0x199 (Size: 0x1, Type: ByteProperty)
    UClass* CostGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ClassProperty)
    TArray<FAbilityTriggerData> AbilityTriggers() const { return Read<TArray<FAbilityTriggerData>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    UClass* CooldownGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer CancelAbilitiesWithTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockAbilitiesWithTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActivationOwnedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActivationRequiredTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActivationBlockedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SourceRequiredTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SourceBlockedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetRequiredTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetBlockedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x20, Type: StructProperty)
    TArray<UGameplayTask*> ActiveTasks() const { return Read<TArray<UGameplayTask*>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    UAnimMontage* CurrentMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    bool bIsActive() const { return Read<bool>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x1, Type: BoolProperty)
    bool bIsAbilityEnding() const { return Read<bool>(uintptr_t(this) + 0x389); } // 0x389 (Size: 0x1, Type: BoolProperty)
    bool bIsCancelable() const { return Read<bool>(uintptr_t(this) + 0x38a); } // 0x38a (Size: 0x1, Type: BoolProperty)
    bool bIsBlockingOtherAbilities() const { return Read<bool>(uintptr_t(this) + 0x38b); } // 0x38b (Size: 0x1, Type: BoolProperty)
    bool bMarkPendingKillOnAbilityEnd() const { return Read<bool>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x1, Type: BoolProperty)

    void SET_AbilityTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: StructProperty)
    void SET_bReplicateInputDirectly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_RemoteInstanceEnded(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: BoolProperty)
    void SET_ReplicationPolicy(const TEnumAsByte<EGameplayAbilityReplicationPolicy>& Value) { Write<TEnumAsByte<EGameplayAbilityReplicationPolicy>>(uintptr_t(this) + 0xce, Value); } // 0xce (Size: 0x1, Type: ByteProperty)
    void SET_InstancingPolicy(const TEnumAsByte<EGameplayAbilityInstancingPolicy>& Value) { Write<TEnumAsByte<EGameplayAbilityInstancingPolicy>>(uintptr_t(this) + 0xcf, Value); } // 0xcf (Size: 0x1, Type: ByteProperty)
    void SET_bServerRespectsRemoteAbilityCancellation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_bRetriggerInstancedAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentActivationInfo(const FGameplayAbilityActivationInfo& Value) { Write<FGameplayAbilityActivationInfo>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x14, Type: StructProperty)
    void SET_CurrentEventData(const FGameplayEventData& Value) { Write<FGameplayEventData>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0xb0, Type: StructProperty)
    void SET_NetExecutionPolicy(const TEnumAsByte<EGameplayAbilityNetExecutionPolicy>& Value) { Write<TEnumAsByte<EGameplayAbilityNetExecutionPolicy>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: ByteProperty)
    void SET_NetSecurityPolicy(const TEnumAsByte<EGameplayAbilityNetSecurityPolicy>& Value) { Write<TEnumAsByte<EGameplayAbilityNetSecurityPolicy>>(uintptr_t(this) + 0x199, Value); } // 0x199 (Size: 0x1, Type: ByteProperty)
    void SET_CostGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ClassProperty)
    void SET_AbilityTriggers(const TArray<FAbilityTriggerData>& Value) { Write<TArray<FAbilityTriggerData>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_CooldownGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    void SET_CancelAbilitiesWithTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x20, Type: StructProperty)
    void SET_BlockAbilitiesWithTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x20, Type: StructProperty)
    void SET_ActivationOwnedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x20, Type: StructProperty)
    void SET_ActivationRequiredTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x20, Type: StructProperty)
    void SET_ActivationBlockedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x20, Type: StructProperty)
    void SET_SourceRequiredTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x20, Type: StructProperty)
    void SET_SourceBlockedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_TargetRequiredTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    void SET_TargetBlockedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x20, Type: StructProperty)
    void SET_ActiveTasks(const TArray<UGameplayTask*>& Value) { Write<TArray<UGameplayTask*>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x1, Type: BoolProperty)
    void SET_bIsAbilityEnding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x389, Value); } // 0x389 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCancelable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38a, Value); } // 0x38a (Size: 0x1, Type: BoolProperty)
    void SET_bIsBlockingOtherAbilities(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38b, Value); } // 0x38b (Size: 0x1, Type: BoolProperty)
    void SET_bMarkPendingKillOnAbilityEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
class UGameplayAbilitySet : public UDataAsset
{
public:
    TArray<FGameplayAbilityBindInfo> Abilities() const { return Read<TArray<FGameplayAbilityBindInfo>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Abilities(const TArray<FGameplayAbilityBindInfo>& Value) { Write<TArray<FGameplayAbilityBindInfo>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3e0
class AGameplayAbilityTargetActor : public AActor
{
public:
    bool ShouldProduceTargetDataOnServer() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    FGameplayAbilityTargetingLocationInfo StartLocation() const { return Read<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x90, Type: StructProperty)
    APlayerController* PrimaryPC() const { return Read<APlayerController*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UGameplayAbility* OwningAbility() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    bool bDestroyOnConfirmation() const { return Read<bool>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x1, Type: BoolProperty)
    AActor* SourceActor() const { return Read<AActor*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    FWorldReticleParameters ReticleParams() const { return Read<FWorldReticleParameters>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x18, Type: StructProperty)
    UClass* ReticleClass() const { return Read<UClass*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ClassProperty)
    FGameplayTargetDataFilterHandle Filter() const { return Read<FGameplayTargetDataFilterHandle>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: StructProperty)
    bool bDebug() const { return Read<bool>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    UAbilitySystemComponent* GenericDelegateBoundASC() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)

    void SET_ShouldProduceTargetDataOnServer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_StartLocation(const FGameplayAbilityTargetingLocationInfo& Value) { Write<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x90, Type: StructProperty)
    void SET_PrimaryPC(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_OwningAbility(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_bDestroyOnConfirmation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x1, Type: BoolProperty)
    void SET_SourceActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_ReticleParams(const FWorldReticleParameters& Value) { Write<FWorldReticleParameters>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x18, Type: StructProperty)
    void SET_ReticleClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ClassProperty)
    void SET_Filter(const FGameplayTargetDataFilterHandle& Value) { Write<FGameplayTargetDataFilterHandle>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: StructProperty)
    void SET_bDebug(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    void SET_GenericDelegateBoundASC(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x430
class AGameplayAbilityTargetActor_ActorPlacement : public AGameplayAbilityTargetActor_GroundTrace
{
public:
    UClass* PlacedActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ClassProperty)
    UMaterialInterface* PlacedActorMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x8, Type: ObjectProperty)

    void SET_PlacedActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ClassProperty)
    void SET_PlacedActorMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x420
class AGameplayAbilityTargetActor_GroundTrace : public AGameplayAbilityTargetActor_Trace
{
public:
    float CollisionRadius() const { return Read<float>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    float CollisionHeight() const { return Read<float>(uintptr_t(this) + 0x3fc); } // 0x3fc (Size: 0x4, Type: FloatProperty)

    void SET_CollisionRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x3fc, Value); } // 0x3fc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x400
class AGameplayAbilityTargetActor_Trace : public AGameplayAbilityTargetActor
{
public:
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    FCollisionProfileName TraceProfile() const { return Read<FCollisionProfileName>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: StructProperty)
    bool bTraceAffectsAimPitch() const { return Read<bool>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x1, Type: BoolProperty)

    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    void SET_TraceProfile(const FCollisionProfileName& Value) { Write<FCollisionProfileName>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: StructProperty)
    void SET_bTraceAffectsAimPitch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3f0
class AGameplayAbilityTargetActor_Radius : public AGameplayAbilityTargetActor
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x400
class AGameplayAbilityTargetActor_SingleLineTrace : public AGameplayAbilityTargetActor_Trace
{
public:
};

// Size: 0x2d8
class AGameplayAbilityWorldReticle : public AActor
{
public:
    FWorldReticleParameters Parameters() const { return Read<FWorldReticleParameters>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x18, Type: StructProperty)
    bool bFaceOwnerFlat() const { return Read<bool>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bSnapToTargetedActor() const { return Read<bool>(uintptr_t(this) + 0x2c1); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
    bool bIsTargetValid() const { return Read<bool>(uintptr_t(this) + 0x2c2); } // 0x2c2 (Size: 0x1, Type: BoolProperty)
    bool bIsTargetAnActor() const { return Read<bool>(uintptr_t(this) + 0x2c3); } // 0x2c3 (Size: 0x1, Type: BoolProperty)
    APlayerController* PrimaryPC() const { return Read<APlayerController*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    AGameplayAbilityTargetActor* TargetingActor() const { return Read<AGameplayAbilityTargetActor*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)

    void SET_Parameters(const FWorldReticleParameters& Value) { Write<FWorldReticleParameters>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x18, Type: StructProperty)
    void SET_bFaceOwnerFlat(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    void SET_bSnapToTargetedActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c1, Value); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTargetValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c2, Value); } // 0x2c2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTargetAnActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c3, Value); } // 0x2c3 (Size: 0x1, Type: BoolProperty)
    void SET_PrimaryPC(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetingActor(const AGameplayAbilityTargetActor*& Value) { Write<AGameplayAbilityTargetActor*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2f0
class AGameplayAbilityWorldReticle_ActorVisualization : public AGameplayAbilityWorldReticle
{
public:
    UCapsuleComponent* CollisionComponent() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    TArray<UActorComponent*> VisualizationComponents() const { return Read<TArray<UActorComponent*>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)

    void SET_CollisionComponent(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_VisualizationComponents(const TArray<UActorComponent*>& Value) { Write<TArray<UActorComponent*>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3a8
class UGameplayAbility_CharacterJump : public UGameplayAbility
{
public:
};

// Size: 0x3d8
class UGameplayAbility_Montage : public UGameplayAbility
{
public:
    UAnimMontage* MontageToPlay() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x4, Type: FloatProperty)
    FName SectionName() const { return Read<FName>(uintptr_t(this) + 0x3b4); } // 0x3b4 (Size: 0x4, Type: NameProperty)
    TArray<UClass*> GameplayEffectClassesWhileAnimating() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x10, Type: ArrayProperty)
    TArray<UGameplayEffect*> GameplayEffectsWhileAnimating() const { return Read<TArray<UGameplayEffect*>>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x10, Type: ArrayProperty)

    void SET_MontageToPlay(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x4, Type: FloatProperty)
    void SET_SectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3b4, Value); } // 0x3b4 (Size: 0x4, Type: NameProperty)
    void SET_GameplayEffectClassesWhileAnimating(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayEffectsWhileAnimating(const TArray<UGameplayEffect*>& Value) { Write<TArray<UGameplayEffect*>>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf8
class UAbilityTask_ApplyRootMotionConstantForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    FVector WorldDirection() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    bool bIsAdditive() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    UCurveFloat* StrengthOverTime() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    bool bEnableGravity() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)

    void SET_WorldDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_bIsAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_StrengthOverTime(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableGravity(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UAbilityTask_ApplyRootMotion_Base : public UAbilityTask
{
public:
    FName ForceName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t FinishVelocityMode() const { return Read<uint8_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: EnumProperty)
    FVector FinishSetVelocity() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    float FinishClampVelocity() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UCharacterMovementComponent*> MovementComponent() const { return Read<TWeakObjectPtr<UCharacterMovementComponent*>>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x8, Type: WeakObjectProperty)

    void SET_ForceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_FinishVelocityMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: EnumProperty)
    void SET_FinishSetVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_FinishClampVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_MovementComponent(const TWeakObjectPtr<UCharacterMovementComponent*>& Value) { Write<TWeakObjectPtr<UCharacterMovementComponent*>>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x118
class UAbilityTask_ApplyRootMotionJumpForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float MinimumLandedTriggerTime() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    bool bFinishOnLanded() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    UCurveVector* PathOffsetCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TimeMappingCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)

    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumLandedTriggerTime(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_bFinishOnLanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    void SET_PathOffsetCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_TimeMappingCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x178
class UAbilityTask_ApplyRootMotionMoveToActorForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    FVector StartLocation() const { return Read<FVector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* TargetComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    FVector TargetComponentRelativeLocation() const { return Read<FVector>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    FVector TargetLocationOffset() const { return Read<FVector>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x18, Type: StructProperty)
    uint8_t OffsetAlignment() const { return Read<uint8_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: EnumProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    bool bDisableDestinationReachedInterrupt() const { return Read<bool>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: BoolProperty)
    float ReachedDestinationDistance() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    bool bSetNewMovementMode() const { return Read<bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> NewMovementMode() const { return Read<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x149); } // 0x149 (Size: 0x1, Type: ByteProperty)
    bool bRestrictSpeedToExpected() const { return Read<bool>(uintptr_t(this) + 0x14a); } // 0x14a (Size: 0x1, Type: BoolProperty)
    UCurveVector* PathOffsetCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TimeMappingCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TargetLerpSpeedHorizontalCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TargetLerpSpeedVerticalCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ObjectProperty)

    void SET_StartLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x18, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetComponentRelativeLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_TargetLocationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x18, Type: StructProperty)
    void SET_OffsetAlignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: EnumProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_bDisableDestinationReachedInterrupt(const bool& Value) { Write<bool>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: BoolProperty)
    void SET_ReachedDestinationDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_bSetNewMovementMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: BoolProperty)
    void SET_NewMovementMode(const TEnumAsByte<EMovementMode>& Value) { Write<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x149, Value); } // 0x149 (Size: 0x1, Type: ByteProperty)
    void SET_bRestrictSpeedToExpected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14a, Value); } // 0x14a (Size: 0x1, Type: BoolProperty)
    void SET_PathOffsetCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    void SET_TimeMappingCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetLerpSpeedHorizontalCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetLerpSpeedVerticalCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x118
class UAbilityTask_ApplyRootMotionMoveToForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    FVector StartLocation() const { return Read<FVector>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    bool bSetNewMovementMode() const { return Read<bool>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> NewMovementMode() const { return Read<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x105); } // 0x105 (Size: 0x1, Type: ByteProperty)
    bool bRestrictSpeedToExpected() const { return Read<bool>(uintptr_t(this) + 0x106); } // 0x106 (Size: 0x1, Type: BoolProperty)
    UCurveVector* PathOffsetCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)

    void SET_StartLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_bSetNewMovementMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x1, Type: BoolProperty)
    void SET_NewMovementMode(const TEnumAsByte<EMovementMode>& Value) { Write<TEnumAsByte<EMovementMode>>(uintptr_t(this) + 0x105, Value); } // 0x105 (Size: 0x1, Type: ByteProperty)
    void SET_bRestrictSpeedToExpected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x106, Value); } // 0x106 (Size: 0x1, Type: BoolProperty)
    void SET_PathOffsetCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x120
class UAbilityTask_ApplyRootMotionRadialForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    AActor* LocationActor() const { return Read<AActor*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    bool bIsPush() const { return Read<bool>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x1, Type: BoolProperty)
    bool bIsAdditive() const { return Read<bool>(uintptr_t(this) + 0xed); } // 0xed (Size: 0x1, Type: BoolProperty)
    bool bNoZForce() const { return Read<bool>(uintptr_t(this) + 0xee); } // 0xee (Size: 0x1, Type: BoolProperty)
    UCurveFloat* StrengthDistanceFalloff() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* StrengthOverTime() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bUseFixedWorldDirection() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)
    FRotator FixedWorldDirection() const { return Read<FRotator>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_LocationActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_bIsPush(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x1, Type: BoolProperty)
    void SET_bIsAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed, Value); } // 0xed (Size: 0x1, Type: BoolProperty)
    void SET_bNoZForce(const bool& Value) { Write<bool>(uintptr_t(this) + 0xee, Value); } // 0xee (Size: 0x1, Type: BoolProperty)
    void SET_StrengthDistanceFalloff(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_StrengthOverTime(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_bUseFixedWorldDirection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
    void SET_FixedWorldDirection(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
};

// Size: 0xe0
class UAbilityTask_MoveToLocation : public UAbilityTask
{
public:
    FVector StartLocation() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    float DurationOfMovement() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    UCurveFloat* LerpCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UCurveVector* LerpCurveVector() const { return Read<UCurveVector*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)

    void SET_StartLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_DurationOfMovement(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_LerpCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_LerpCurveVector(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x90
class UAbilityTask_NetworkSyncPoint : public UAbilityTask
{
public:
};

// Size: 0x120
class UAbilityTask_PlayMontageAndWait : public UAbilityTask
{
public:
    UAnimMontage* MontageToPlay() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    float Rate() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    FName StartSection() const { return Read<FName>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: NameProperty)
    float AnimRootMotionTranslationScale() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    float StartTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: FloatProperty)
    bool bStopWhenAbilityEnds() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    bool bAllowInterruptAfterBlendOut() const { return Read<bool>(uintptr_t(this) + 0x119); } // 0x119 (Size: 0x1, Type: BoolProperty)

    void SET_MontageToPlay(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_Rate(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_StartSection(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: NameProperty)
    void SET_AnimRootMotionTranslationScale(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_StartTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: FloatProperty)
    void SET_bStopWhenAbilityEnds(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowInterruptAfterBlendOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x119, Value); } // 0x119 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UAbilityTask_Repeat : public UAbilityTask
{
public:
};

// Size: 0xc0
class UAbilityTask_SpawnActor : public UAbilityTask
{
public:
};

// Size: 0xb0
class UAbilityTask_StartAbilityState : public UAbilityTask
{
public:
};

// Size: 0xa0
class UAbilityTask_VisualizeTargeting : public UAbilityTask
{
public:
};

// Size: 0x170
class UAbilityTask_WaitAbilityActivate : public UAbilityTask
{
public:
};

// Size: 0xe8
class UAbilityTask_WaitAbilityCommit : public UAbilityTask
{
public:
};

// Size: 0xe8
class UAbilityTask_WaitAttributeChange : public UAbilityTask
{
public:
    UAbilitySystemComponent* ExternalOwner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_ExternalOwner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x138
class UAbilityTask_WaitAttributeChangeRatioThreshold : public UAbilityTask
{
public:
    UAbilitySystemComponent* ExternalOwner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)

    void SET_ExternalOwner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe8
class UAbilityTask_WaitAttributeChangeThreshold : public UAbilityTask
{
public:
    UAbilitySystemComponent* ExternalOwner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_ExternalOwner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x90
class UAbilityTask_WaitCancel : public UAbilityTask
{
public:
};

// Size: 0x98
class UAbilityTask_WaitConfirm : public UAbilityTask
{
public:
};

// Size: 0xa0
class UAbilityTask_WaitConfirmCancel : public UAbilityTask
{
public:
};

// Size: 0x90
class UAbilityTask_WaitDelay : public UAbilityTask
{
public:
};

// Size: 0x240
class UAbilityTask_WaitGameplayEffectApplied : public UAbilityTask
{
public:
    UAbilitySystemComponent* ExternalOwner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x8, Type: ObjectProperty)

    void SET_ExternalOwner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x260
class UAbilityTask_WaitGameplayEffectApplied_Self : public UAbilityTask_WaitGameplayEffectApplied
{
public:
};

// Size: 0x260
class UAbilityTask_WaitGameplayEffectApplied_Target : public UAbilityTask_WaitGameplayEffectApplied
{
public:
};

// Size: 0x1b0
class UAbilityTask_WaitGameplayEffectBlockedImmunity : public UAbilityTask
{
public:
    UAbilitySystemComponent* ExternalOwner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)

    void SET_ExternalOwner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
class UAbilityTask_WaitGameplayEffectRemoved : public UAbilityTask
{
public:
};

// Size: 0xb0
class UAbilityTask_WaitGameplayEffectStackChange : public UAbilityTask
{
public:
};

// Size: 0xa8
class UAbilityTask_WaitGameplayEvent : public UAbilityTask
{
public:
    UAbilitySystemComponent* OptionalExternalTarget() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_OptionalExternalTarget(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa8
class UAbilityTask_WaitGameplayTagAdded : public UAbilityTask_WaitGameplayTag
{
public:
};

// Size: 0x98
class UAbilityTask_WaitGameplayTag : public UAbilityTask
{
public:
    UAbilitySystemComponent* OptionalExternalTarget() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_OptionalExternalTarget(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa8
class UAbilityTask_WaitGameplayTagRemoved : public UAbilityTask_WaitGameplayTag
{
public:
};

// Size: 0x158
class UAbilityTask_WaitGameplayTagQuery : public UAbilityTask
{
public:
    UAbilitySystemComponent* OptionalExternalTarget() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)

    void SET_OptionalExternalTarget(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x98
class UAbilityTask_WaitInputPress : public UAbilityTask
{
public:
};

// Size: 0x98
class UAbilityTask_WaitInputRelease : public UAbilityTask
{
public:
};

// Size: 0x98
class UAbilityTask_WaitMovementModeChange : public UAbilityTask
{
public:
};

// Size: 0x88
class UAbilityTask_WaitOverlap : public UAbilityTask
{
public:
};

// Size: 0xb8
class UAbilityTask_WaitTargetData : public UAbilityTask
{
public:
    UClass* TargetClass() const { return Read<UClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ClassProperty)
    AGameplayAbilityTargetActor* TargetActor() const { return Read<AGameplayAbilityTargetActor*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ClassProperty)
    void SET_TargetActor(const AGameplayAbilityTargetActor*& Value) { Write<AGameplayAbilityTargetActor*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb0
class UAbilityTask_WaitVelocityChange : public UAbilityTask
{
public:
    TWeakObjectPtr<UMovementComponent*> CachedMovementComponent() const { return Read<TWeakObjectPtr<UMovementComponent*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedMovementComponent(const TWeakObjectPtr<UMovementComponent*>& Value) { Write<TWeakObjectPtr<UMovementComponent*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x28
class UAbilitySystemBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x1250
class UAbilitySystemComponent : public UGameplayTasksComponent
{
public:
    TArray<FAttributeDefaults> DefaultStartingData() const { return Read<TArray<FAttributeDefaults>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    FName AffectedAnimInstanceTag() const { return Read<FName>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: NameProperty)
    float OutgoingDuration() const { return Read<float>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float IncomingDuration() const { return Read<float>(uintptr_t(this) + 0x2fc); } // 0x2fc (Size: 0x4, Type: FloatProperty)
    TArray<FString> ClientDebugStrings() const { return Read<TArray<FString>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ServerDebugStrings() const { return Read<TArray<FString>>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: ArrayProperty)
    bool UserAbilityActivationInhibited() const { return Read<bool>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x1, Type: BoolProperty)
    bool ReplicationProxyEnabled() const { return Read<bool>(uintptr_t(this) + 0x399); } // 0x399 (Size: 0x1, Type: BoolProperty)
    bool bSuppressGrantAbility() const { return Read<bool>(uintptr_t(this) + 0x39a); } // 0x39a (Size: 0x1, Type: BoolProperty)
    bool bSuppressGameplayCues() const { return Read<bool>(uintptr_t(this) + 0x39b); } // 0x39b (Size: 0x1, Type: BoolProperty)
    TArray<AGameplayAbilityTargetActor*> SpawnedTargetActors() const { return Read<TArray<AGameplayAbilityTargetActor*>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    AActor* OwnerActor() const { return Read<AActor*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    AActor* AvatarActor() const { return Read<AActor*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    FGameplayAbilitySpecContainer ActivatableAbilities() const { return Read<FGameplayAbilitySpecContainer>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x120, Type: StructProperty)
    TArray<UGameplayAbility*> AllReplicatedInstancedAbilities() const { return Read<TArray<UGameplayAbility*>>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x10, Type: ArrayProperty)
    FGameplayAbilityRepAnimMontage RepAnimMontageInfo() const { return Read<FGameplayAbilityRepAnimMontage>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x38, Type: StructProperty)
    bool bCachedIsNetSimulated() const { return Read<bool>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x1, Type: BoolProperty)
    bool bPendingMontageRep() const { return Read<bool>(uintptr_t(this) + 0x7b1); } // 0x7b1 (Size: 0x1, Type: BoolProperty)
    FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo() const { return Read<FGameplayAbilityLocalAnimMontage>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x28, Type: StructProperty)
    FActiveGameplayEffectsContainer ActiveGameplayEffects() const { return Read<FActiveGameplayEffectsContainer>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x300, Type: StructProperty)
    FActiveGameplayCueContainer ActiveGameplayCues() const { return Read<FActiveGameplayCueContainer>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x128, Type: StructProperty)
    FActiveGameplayCueContainer MinimalReplicationGameplayCues() const { return Read<FActiveGameplayCueContainer>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x128, Type: StructProperty)
    TArray<char> BlockedAbilityBindings() const { return Read<TArray<char>>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x10, Type: ArrayProperty)
    FMinimalReplicationTagCountMap MinimalReplicationTags() const { return Read<FMinimalReplicationTagCountMap>(uintptr_t(this) + 0x1030); } // 0x1030 (Size: 0x68, Type: StructProperty)
    TArray<UAttributeSet*> SpawnedAttributes() const { return Read<TArray<UAttributeSet*>>(uintptr_t(this) + 0x1098); } // 0x1098 (Size: 0x10, Type: ArrayProperty)
    FMinimalReplicationTagCountMap ReplicatedLooseTags() const { return Read<FMinimalReplicationTagCountMap>(uintptr_t(this) + 0x10b8); } // 0x10b8 (Size: 0x68, Type: StructProperty)
    FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap() const { return Read<FReplicatedPredictionKeyMap>(uintptr_t(this) + 0x1128); } // 0x1128 (Size: 0x118, Type: StructProperty)

    void SET_DefaultStartingData(const TArray<FAttributeDefaults>& Value) { Write<TArray<FAttributeDefaults>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_AffectedAnimInstanceTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: NameProperty)
    void SET_OutgoingDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x4, Type: FloatProperty)
    void SET_IncomingDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x2fc, Value); } // 0x2fc (Size: 0x4, Type: FloatProperty)
    void SET_ClientDebugStrings(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerDebugStrings(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: ArrayProperty)
    void SET_UserAbilityActivationInhibited(const bool& Value) { Write<bool>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x1, Type: BoolProperty)
    void SET_ReplicationProxyEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x399, Value); } // 0x399 (Size: 0x1, Type: BoolProperty)
    void SET_bSuppressGrantAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39a, Value); } // 0x39a (Size: 0x1, Type: BoolProperty)
    void SET_bSuppressGameplayCues(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39b, Value); } // 0x39b (Size: 0x1, Type: BoolProperty)
    void SET_SpawnedTargetActors(const TArray<AGameplayAbilityTargetActor*>& Value) { Write<TArray<AGameplayAbilityTargetActor*>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    void SET_OwnerActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_AvatarActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivatableAbilities(const FGameplayAbilitySpecContainer& Value) { Write<FGameplayAbilitySpecContainer>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x120, Type: StructProperty)
    void SET_AllReplicatedInstancedAbilities(const TArray<UGameplayAbility*>& Value) { Write<TArray<UGameplayAbility*>>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x10, Type: ArrayProperty)
    void SET_RepAnimMontageInfo(const FGameplayAbilityRepAnimMontage& Value) { Write<FGameplayAbilityRepAnimMontage>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x38, Type: StructProperty)
    void SET_bCachedIsNetSimulated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x1, Type: BoolProperty)
    void SET_bPendingMontageRep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7b1, Value); } // 0x7b1 (Size: 0x1, Type: BoolProperty)
    void SET_LocalAnimMontageInfo(const FGameplayAbilityLocalAnimMontage& Value) { Write<FGameplayAbilityLocalAnimMontage>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x28, Type: StructProperty)
    void SET_ActiveGameplayEffects(const FActiveGameplayEffectsContainer& Value) { Write<FActiveGameplayEffectsContainer>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x300, Type: StructProperty)
    void SET_ActiveGameplayCues(const FActiveGameplayCueContainer& Value) { Write<FActiveGameplayCueContainer>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x128, Type: StructProperty)
    void SET_MinimalReplicationGameplayCues(const FActiveGameplayCueContainer& Value) { Write<FActiveGameplayCueContainer>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x128, Type: StructProperty)
    void SET_BlockedAbilityBindings(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x10, Type: ArrayProperty)
    void SET_MinimalReplicationTags(const FMinimalReplicationTagCountMap& Value) { Write<FMinimalReplicationTagCountMap>(uintptr_t(this) + 0x1030, Value); } // 0x1030 (Size: 0x68, Type: StructProperty)
    void SET_SpawnedAttributes(const TArray<UAttributeSet*>& Value) { Write<TArray<UAttributeSet*>>(uintptr_t(this) + 0x1098, Value); } // 0x1098 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedLooseTags(const FMinimalReplicationTagCountMap& Value) { Write<FMinimalReplicationTagCountMap>(uintptr_t(this) + 0x10b8, Value); } // 0x10b8 (Size: 0x68, Type: StructProperty)
    void SET_ReplicatedPredictionKeyMap(const FReplicatedPredictionKeyMap& Value) { Write<FReplicatedPredictionKeyMap>(uintptr_t(this) + 0x1128, Value); } // 0x1128 (Size: 0x118, Type: StructProperty)
};

// Size: 0x28
class UAbilitySystemDebugHUDExtension : public UObject
{
public:
};

// Size: 0x80
class UAbilitySystemDebugHUDExtension_Tags : public UAbilitySystemDebugHUDExtension
{
public:
};

// Size: 0x80
class UAbilitySystemDebugHUDExtension_Attributes : public UAbilitySystemDebugHUDExtension
{
public:
};

// Size: 0x80
class UAbilitySystemDebugHUDExtension_BlockedAbilityTags : public UAbilitySystemDebugHUDExtension
{
public:
};

// Size: 0x268
class UAbilitySystemGlobals : public UObject
{
public:
    FSoftClassPath AbilitySystemGlobalsClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FGameplayTag ActivateFailIsDeadTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: StructProperty)
    FName ActivateFailIsDeadName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailCooldownTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: StructProperty)
    FName ActivateFailCooldownName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailCostTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: StructProperty)
    FName ActivateFailCostName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailTagsBlockedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: StructProperty)
    FName ActivateFailTagsBlockedName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailTagsMissingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: StructProperty)
    FName ActivateFailTagsMissingName() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailNetworkingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: StructProperty)
    FName ActivateFailNetworkingName() const { return Read<FName>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: NameProperty)
    int32_t MinimalReplicationTagCountBits() const { return Read<int32_t>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: IntProperty)
    FNetSerializeScriptStructCache TargetDataStructCache() const { return Read<FNetSerializeScriptStructCache>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)
    FNetSerializeScriptStructCache EffectContextStructCache() const { return Read<FNetSerializeScriptStructCache>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: StructProperty)
    bool bAllowGameplayModEvaluationChannels() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t DefaultGameplayModEvaluationChannel() const { return Read<uint8_t>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: EnumProperty)
    FName GameplayModEvaluationChannelAliases() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x28, Type: NameProperty)
    FSoftObjectPath GlobalCurveTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    UCurveTable* GlobalCurveTable() const { return Read<UCurveTable*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    FSoftObjectPath GlobalAttributeMetaDataTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x18, Type: StructProperty)
    UDataTable* GlobalAttributeMetaDataTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    FSoftObjectPath GlobalAttributeSetDefaultsTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x18, Type: StructProperty)
    TArray<FSoftObjectPath> GlobalAttributeSetDefaultsTableNames() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    TArray<UCurveTable*> GlobalAttributeDefaultsTables() const { return Read<TArray<UCurveTable*>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GlobalGameplayCueManagerClass() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath GlobalGameplayCueManagerName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x18, Type: StructProperty)
    TArray<FString> GameplayCueNotifyPaths() const { return Read<TArray<FString>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GameplayTagResponseTableName() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x18, Type: StructProperty)
    UGameplayTagReponseTable* GameplayTagResponseTable() const { return Read<UGameplayTagReponseTable*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    bool PredictTargetGameplayEffects() const { return Read<bool>(uintptr_t(this) + 0x1c9); } // 0x1c9 (Size: 0x1, Type: BoolProperty)
    bool ReplicateActivationOwnedTags() const { return Read<bool>(uintptr_t(this) + 0x1ca); } // 0x1ca (Size: 0x1, Type: BoolProperty)
    UGameplayCueManager* GlobalGameplayCueManager() const { return Read<UGameplayCueManager*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)

    void SET_AbilitySystemGlobalsClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_ActivateFailIsDeadTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailIsDeadName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ActivateFailCooldownTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailCooldownName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_ActivateFailCostTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailCostName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_ActivateFailTagsBlockedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailTagsBlockedName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_ActivateFailTagsMissingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailTagsMissingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
    void SET_ActivateFailNetworkingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: StructProperty)
    void SET_ActivateFailNetworkingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: NameProperty)
    void SET_MinimalReplicationTagCountBits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: IntProperty)
    void SET_TargetDataStructCache(const FNetSerializeScriptStructCache& Value) { Write<FNetSerializeScriptStructCache>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
    void SET_EffectContextStructCache(const FNetSerializeScriptStructCache& Value) { Write<FNetSerializeScriptStructCache>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: StructProperty)
    void SET_bAllowGameplayModEvaluationChannels(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultGameplayModEvaluationChannel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: EnumProperty)
    void SET_GameplayModEvaluationChannelAliases(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x28, Type: NameProperty)
    void SET_GlobalCurveTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_GlobalCurveTable(const UCurveTable*& Value) { Write<UCurveTable*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_GlobalAttributeMetaDataTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x18, Type: StructProperty)
    void SET_GlobalAttributeMetaDataTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_GlobalAttributeSetDefaultsTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x18, Type: StructProperty)
    void SET_GlobalAttributeSetDefaultsTableNames(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalAttributeDefaultsTables(const TArray<UCurveTable*>& Value) { Write<TArray<UCurveTable*>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalGameplayCueManagerClass(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x18, Type: StructProperty)
    void SET_GlobalGameplayCueManagerName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x18, Type: StructProperty)
    void SET_GameplayCueNotifyPaths(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayTagResponseTableName(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x18, Type: StructProperty)
    void SET_GameplayTagResponseTable(const UGameplayTagReponseTable*& Value) { Write<UGameplayTagReponseTable*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    void SET_PredictTargetGameplayEffects(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c9, Value); } // 0x1c9 (Size: 0x1, Type: BoolProperty)
    void SET_ReplicateActivationOwnedTags(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1ca, Value); } // 0x1ca (Size: 0x1, Type: BoolProperty)
    void SET_GlobalGameplayCueManager(const UGameplayCueManager*& Value) { Write<UGameplayCueManager*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UAbilitySystemInterface : public UInterface
{
public:
};

// Size: 0x28
class UAbilitySystemReplicationProxyInterface : public UInterface
{
public:
};

// Size: 0x80
class UAbilitySystemTestAttributeSet : public UAttributeSet
{
public:
    float MaxHealth() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float Health() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FGameplayAttributeData Mana() const { return Read<FGameplayAttributeData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    float MaxMana() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float Damage() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float SpellDamage() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float PhysicalDamage() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float CritChance() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float CritMultiplier() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float ArmorDamageReduction() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float DodgeChance() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float LifeSteal() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float StackingAttribute1() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float StackingAttribute2() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float NoStackAttribute() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)

    void SET_MaxHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_Health(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_Mana(const FGameplayAttributeData& Value) { Write<FGameplayAttributeData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_MaxMana(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_Damage(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_SpellDamage(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_PhysicalDamage(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_CritChance(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_CritMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_ArmorDamageReduction(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_DodgeChance(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_LifeSteal(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_StackingAttribute1(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_StackingAttribute2(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_NoStackAttribute(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
class UAttributeSet : public UObject
{
public:
};

// Size: 0x370
class AAbilitySystemTestPawn : public ADefaultPawn
{
public:
    UAbilitySystemComponent* AbilitySystemComponent() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)

    void SET_AbilitySystemComponent(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UAnimNotify_GameplayCue : public UAnimNotify
{
public:
    FGameplayCueTag GameplayCue() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: StructProperty)

    void SET_GameplayCue(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
class UAnimNotify_GameplayCueState : public UAnimNotifyState
{
public:
    FGameplayCueTag GameplayCue() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)

    void SET_GameplayCue(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa8
class UGameplayAbilityBlueprint : public UBlueprint
{
public:
};

// Size: 0x28
class UGameplayCueFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UGameplayCueInterface : public UInterface
{
public:
};

// Size: 0x310
class UGameplayCueManager : public UDataAsset
{
public:
    FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary() const { return Read<FGameplayCueObjectLibrary>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: StructProperty)
    FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary() const { return Read<FGameplayCueObjectLibrary>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x50, Type: StructProperty)
    TArray<UClass*> LoadedGameplayCueNotifyClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> GameplayCueClassesForPreallocation() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayCuePendingExecute> PendingExecuteCues() const { return Read<TArray<FGameplayCuePendingExecute>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    int32_t GameplayCueSendContextCount() const { return Read<int32_t>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: IntProperty)
    TArray<FPreallocationInfo> PreallocationInfoList_Internal() const { return Read<TArray<FPreallocationInfo>>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x10, Type: ArrayProperty)

    void SET_RuntimeGameplayCueObjectLibrary(const FGameplayCueObjectLibrary& Value) { Write<FGameplayCueObjectLibrary>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: StructProperty)
    void SET_EditorGameplayCueObjectLibrary(const FGameplayCueObjectLibrary& Value) { Write<FGameplayCueObjectLibrary>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x50, Type: StructProperty)
    void SET_LoadedGameplayCueNotifyClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayCueClassesForPreallocation(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x10, Type: ArrayProperty)
    void SET_PendingExecuteCues(const TArray<FGameplayCuePendingExecute>& Value) { Write<TArray<FGameplayCuePendingExecute>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayCueSendContextCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: IntProperty)
    void SET_PreallocationInfoList_Internal(const TArray<FPreallocationInfo>& Value) { Write<TArray<FPreallocationInfo>>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x310
class AGameplayCueNotify_Actor : public AActor
{
public:
    bool bAutoDestroyOnRemove() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    float AutoDestroyDelay() const { return Read<float>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    bool WarnIfTimelineIsStillRunning() const { return Read<bool>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    bool WarnIfLatentActionIsStillRunning() const { return Read<bool>(uintptr_t(this) + 0x2b1); } // 0x2b1 (Size: 0x1, Type: BoolProperty)
    FGameplayTag GameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: StructProperty)
    FName GameplayCueName() const { return Read<FName>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x4, Type: NameProperty)
    bool bAutoAttachToOwner() const { return Read<bool>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x1, Type: BoolProperty)
    bool IsOverride() const { return Read<bool>(uintptr_t(this) + 0x2bd); } // 0x2bd (Size: 0x1, Type: BoolProperty)
    bool bUniqueInstancePerInstigator() const { return Read<bool>(uintptr_t(this) + 0x2be); } // 0x2be (Size: 0x1, Type: BoolProperty)
    bool bUniqueInstancePerSourceObject() const { return Read<bool>(uintptr_t(this) + 0x2bf); } // 0x2bf (Size: 0x1, Type: BoolProperty)
    bool bAllowMultipleOnActiveEvents() const { return Read<bool>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bAllowMultipleWhileActiveEvents() const { return Read<bool>(uintptr_t(this) + 0x2c1); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
    int32_t NumPreallocatedInstances() const { return Read<int32_t>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x4, Type: IntProperty)

    void SET_bAutoDestroyOnRemove(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_AutoDestroyDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    void SET_WarnIfTimelineIsStillRunning(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    void SET_WarnIfLatentActionIsStillRunning(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b1, Value); } // 0x2b1 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: StructProperty)
    void SET_GameplayCueName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x4, Type: NameProperty)
    void SET_bAutoAttachToOwner(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x1, Type: BoolProperty)
    void SET_IsOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2bd, Value); } // 0x2bd (Size: 0x1, Type: BoolProperty)
    void SET_bUniqueInstancePerInstigator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2be, Value); } // 0x2be (Size: 0x1, Type: BoolProperty)
    void SET_bUniqueInstancePerSourceObject(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2bf, Value); } // 0x2bf (Size: 0x1, Type: BoolProperty)
    void SET_bAllowMultipleOnActiveEvents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowMultipleWhileActiveEvents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c1, Value); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
    void SET_NumPreallocatedInstances(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x348
class UGameplayCueNotify_Burst : public UGameplayCueNotify_Static
{
public:
    FGameplayCueNotify_SpawnCondition DefaultSpawnCondition() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo DefaultPlacementInfo() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x40, Type: StructProperty)
    FGameplayCueNotify_BurstEffects BurstEffects() const { return Read<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x298, Type: StructProperty)

    void SET_DefaultSpawnCondition(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x38, Type: StructProperty)
    void SET_DefaultPlacementInfo(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x40, Type: StructProperty)
    void SET_BurstEffects(const FGameplayCueNotify_BurstEffects& Value) { Write<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x298, Type: StructProperty)
};

// Size: 0x678
class AGameplayCueNotify_BurstLatent : public AGameplayCueNotify_Actor
{
public:
    FGameplayCueNotify_SpawnCondition DefaultSpawnCondition() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo DefaultPlacementInfo() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x40, Type: StructProperty)
    FGameplayCueNotify_BurstEffects BurstEffects() const { return Read<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult BurstSpawnResults() const { return Read<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x58, Type: StructProperty)

    void SET_DefaultSpawnCondition(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x38, Type: StructProperty)
    void SET_DefaultPlacementInfo(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x40, Type: StructProperty)
    void SET_BurstEffects(const FGameplayCueNotify_BurstEffects& Value) { Write<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x298, Type: StructProperty)
    void SET_BurstSpawnResults(const FGameplayCueNotify_SpawnResult& Value) { Write<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x58, Type: StructProperty)
};

// Size: 0x48
class UGameplayCueNotify_HitImpact : public UGameplayCueNotify_Static
{
public:
    USoundBase* Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* ParticleSystem() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_ParticleSystem(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xea8
class AGameplayCueNotify_Looping : public AGameplayCueNotify_Actor
{
public:
    FGameplayCueNotify_SpawnCondition DefaultSpawnCondition() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo DefaultPlacementInfo() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x40, Type: StructProperty)
    FGameplayCueNotify_BurstEffects ApplicationEffects() const { return Read<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult ApplicationSpawnResults() const { return Read<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x58, Type: StructProperty)
    FGameplayCueNotify_LoopingEffects LoopingEffects() const { return Read<FGameplayCueNotify_LoopingEffects>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x1f0, Type: StructProperty)
    FGameplayCueNotify_SpawnResult LoopingSpawnResults() const { return Read<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x58, Type: StructProperty)
    FGameplayCueNotify_BurstEffects RecurringEffects() const { return Read<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult RecurringSpawnResults() const { return Read<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x58, Type: StructProperty)
    FGameplayCueNotify_BurstEffects RemovalEffects() const { return Read<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult RemovalSpawnResults() const { return Read<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0xe48); } // 0xe48 (Size: 0x58, Type: StructProperty)

    void SET_DefaultSpawnCondition(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x38, Type: StructProperty)
    void SET_DefaultPlacementInfo(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x40, Type: StructProperty)
    void SET_ApplicationEffects(const FGameplayCueNotify_BurstEffects& Value) { Write<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x298, Type: StructProperty)
    void SET_ApplicationSpawnResults(const FGameplayCueNotify_SpawnResult& Value) { Write<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x58, Type: StructProperty)
    void SET_LoopingEffects(const FGameplayCueNotify_LoopingEffects& Value) { Write<FGameplayCueNotify_LoopingEffects>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x1f0, Type: StructProperty)
    void SET_LoopingSpawnResults(const FGameplayCueNotify_SpawnResult& Value) { Write<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x58, Type: StructProperty)
    void SET_RecurringEffects(const FGameplayCueNotify_BurstEffects& Value) { Write<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x298, Type: StructProperty)
    void SET_RecurringSpawnResults(const FGameplayCueNotify_SpawnResult& Value) { Write<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x58, Type: StructProperty)
    void SET_RemovalEffects(const FGameplayCueNotify_BurstEffects& Value) { Write<FGameplayCueNotify_BurstEffects>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x298, Type: StructProperty)
    void SET_RemovalSpawnResults(const FGameplayCueNotify_SpawnResult& Value) { Write<FGameplayCueNotify_SpawnResult>(uintptr_t(this) + 0xe48, Value); } // 0xe48 (Size: 0x58, Type: StructProperty)
};

// Size: 0x90
class UGameplayCueSet : public UDataAsset
{
public:
    TArray<FGameplayCueNotifyData> GameplayCueData() const { return Read<TArray<FGameplayCueNotifyData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_GameplayCueData(const TArray<FGameplayCueNotifyData>& Value) { Write<TArray<FGameplayCueNotifyData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UGameplayCueTranslator : public UObject
{
public:
};

// Size: 0x28
class UGameplayCueTranslator_Test : public UGameplayCueTranslator
{
public:
};

// Size: 0x38
class UGameplayEffectCalculation : public UObject
{
public:
    TArray<FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture() const { return Read<TArray<FGameplayEffectAttributeCaptureDefinition>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_RelevantAttributesToCapture(const TArray<FGameplayEffectAttributeCaptureDefinition>& Value) { Write<TArray<FGameplayEffectAttributeCaptureDefinition>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UGameplayEffectCustomApplicationRequirement : public UObject
{
public:
};

// Size: 0x40
class UGameplayEffectExecutionCalculation : public UGameplayEffectCalculation
{
public:
    bool bRequiresPassedInTags() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_bRequiresPassedInTags(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
class UGameplayModMagnitudeCalculation : public UGameplayEffectCalculation
{
public:
    bool bAllowNonNetAuthorityDependencyRegistration() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_bAllowNonNetAuthorityDependencyRegistration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x230
class UGameplayTagReponseTable : public UDataAsset
{
public:
    TArray<FGameplayTagResponseTableEntry> Entries() const { return Read<TArray<FGameplayTagResponseTableEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FGameplayTagResponseTableEntry>& Value) { Write<TArray<FGameplayTagResponseTableEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x218
class UMovieSceneGameplayCueTriggerSection : public UMovieSceneHookSection
{
public:
    FMovieSceneGameplayCueChannel Channel() const { return Read<FMovieSceneGameplayCueChannel>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0xf8, Type: StructProperty)

    void SET_Channel(const FMovieSceneGameplayCueChannel& Value) { Write<FMovieSceneGameplayCueChannel>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0xf8, Type: StructProperty)
};

// Size: 0x1a8
class UMovieSceneGameplayCueSection : public UMovieSceneHookSection
{
public:
    FMovieSceneGameplayCueKey Cue() const { return Read<FMovieSceneGameplayCueKey>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x88, Type: StructProperty)

    void SET_Cue(const FMovieSceneGameplayCueKey& Value) { Write<FMovieSceneGameplayCueKey>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x88, Type: StructProperty)
};

// Size: 0x120
class UMovieSceneGameplayCueTrack : public UMovieSceneNameableTrack
{
public:
    TArray<UMovieSceneSection*> Sections() const { return Read<TArray<UMovieSceneSection*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)

    void SET_Sections(const TArray<UMovieSceneSection*>& Value) { Write<TArray<UMovieSceneSection*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UTickableAttributeSetInterface : public UInterface
{
public:
};

// Size: 0x360
struct FActiveGameplayEffect : public FFastArraySerializerItem
{
public:
    FGameplayEffectSpec Spec() const { return Read<FGameplayEffectSpec>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x298, Type: StructProperty)
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: StructProperty)
    TArray<FGameplayAbilitySpecHandle> GrantedAbilityHandles() const { return Read<TArray<FGameplayAbilitySpecHandle>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    float StartServerWorldTime() const { return Read<float>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x4, Type: FloatProperty)
    float CachedStartServerWorldTime() const { return Read<float>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x4, Type: FloatProperty)
    float StartWorldTime() const { return Read<float>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    bool bIsInhibited() const { return Read<bool>(uintptr_t(this) + 0x2dc); } // 0x2dc (Size: 0x1, Type: BoolProperty)

    void SET_Spec(const FGameplayEffectSpec& Value) { Write<FGameplayEffectSpec>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x298, Type: StructProperty)
    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: StructProperty)
    void SET_GrantedAbilityHandles(const TArray<FGameplayAbilitySpecHandle>& Value) { Write<TArray<FGameplayAbilitySpecHandle>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    void SET_StartServerWorldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x4, Type: FloatProperty)
    void SET_CachedStartServerWorldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x4, Type: FloatProperty)
    void SET_StartWorldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    void SET_bIsInhibited(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2dc, Value); } // 0x2dc (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FGameplayAbilitySpecHandle
{
public:
    int32_t Handle() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Handle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FPredictionKey
{
public:
    int16_t Current() const { return Read<int16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t base() const { return Read<int16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: Int16Property)
    bool bIsServerInitiated() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_Current(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: Int16Property)
    void SET_base(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: Int16Property)
    void SET_bIsServerInitiated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x298
struct FGameplayEffectSpec
{
public:
    UGameplayEffect* Def() const { return Read<UGameplayEffect*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayEffectModifiedAttribute> ModifiedAttributes() const { return Read<TArray<FGameplayEffectModifiedAttribute>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FGameplayEffectAttributeCaptureSpecContainer CapturedRelevantAttributes() const { return Read<FGameplayEffectAttributeCaptureSpecContainer>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x28, Type: StructProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float Period() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float ChanceToApplyToTarget() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FTagContainerAggregator CapturedSourceTags() const { return Read<FTagContainerAggregator>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x88, Type: StructProperty)
    FTagContainerAggregator CapturedTargetTags() const { return Read<FTagContainerAggregator>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x88, Type: StructProperty)
    FGameplayTagContainer DynamicGrantedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DynamicAssetTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)
    TArray<FModifierSpec> Modifiers() const { return Read<TArray<FModifierSpec>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    int32_t StackCount() const { return Read<int32_t>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: IntProperty)
    bool bCompletedSourceAttributeCapture() const { return (Read<uint8_t>(uintptr_t(this) + 0x1c4) >> 0x0) & 1; } // 0x1c4:0 (Size: 0x1, Type: BoolProperty)
    bool bCompletedTargetAttributeCapture() const { return (Read<uint8_t>(uintptr_t(this) + 0x1c4) >> 0x1) & 1; } // 0x1c4:1 (Size: 0x1, Type: BoolProperty)
    bool bDurationLocked() const { return (Read<uint8_t>(uintptr_t(this) + 0x1c4) >> 0x2) & 1; } // 0x1c4:2 (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayAbilitySpecDef> GrantedAbilitySpecs() const { return Read<TArray<FGameplayAbilitySpecDef>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    FGameplayEffectContextHandle EffectContext() const { return Read<FGameplayEffectContextHandle>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x18, Type: StructProperty)
    float Level() const { return Read<float>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: FloatProperty)

    void SET_Def(const UGameplayEffect*& Value) { Write<UGameplayEffect*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ModifiedAttributes(const TArray<FGameplayEffectModifiedAttribute>& Value) { Write<TArray<FGameplayEffectModifiedAttribute>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_CapturedRelevantAttributes(const FGameplayEffectAttributeCaptureSpecContainer& Value) { Write<FGameplayEffectAttributeCaptureSpecContainer>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x28, Type: StructProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_Period(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_ChanceToApplyToTarget(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_CapturedSourceTags(const FTagContainerAggregator& Value) { Write<FTagContainerAggregator>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x88, Type: StructProperty)
    void SET_CapturedTargetTags(const FTagContainerAggregator& Value) { Write<FTagContainerAggregator>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x88, Type: StructProperty)
    void SET_DynamicGrantedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x20, Type: StructProperty)
    void SET_DynamicAssetTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
    void SET_Modifiers(const TArray<FModifierSpec>& Value) { Write<TArray<FModifierSpec>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    void SET_StackCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: IntProperty)
    void SET_bCompletedSourceAttributeCapture(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1c4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1c4, B); } // 0x1c4:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCompletedTargetAttributeCapture(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1c4); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1c4, B); } // 0x1c4:1 (Size: 0x1, Type: BoolProperty)
    void SET_bDurationLocked(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1c4); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1c4, B); } // 0x1c4:2 (Size: 0x1, Type: BoolProperty)
    void SET_GrantedAbilitySpecs(const TArray<FGameplayAbilitySpecDef>& Value) { Write<TArray<FGameplayAbilitySpecDef>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    void SET_EffectContext(const FGameplayEffectContextHandle& Value) { Write<FGameplayEffectContextHandle>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x18, Type: StructProperty)
    void SET_Level(const float& Value) { Write<float>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FGameplayEffectContextHandle
{
public:
};

// Size: 0x98
struct FGameplayAbilitySpecDef
{
public:
    UClass* ability() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat LevelScalableFloat() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    int32_t InputID() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t RemovalPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<UObject*> SourceObject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayAbilitySpecHandle AssignedHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: StructProperty)

    void SET_ability(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_LevelScalableFloat(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_InputID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_RemovalPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: EnumProperty)
    void SET_SourceObject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AssignedHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: StructProperty)
};

// Size: 0x28
struct FScalableFloat
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FCurveTableRowHandle Curve() const { return Read<FCurveTableRowHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FDataRegistryType RegistryType() const { return Read<FDataRegistryType>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Curve(const FCurveTableRowHandle& Value) { Write<FCurveTableRowHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_RegistryType(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FModifierSpec
{
public:
    float EvaluatedMagnitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_EvaluatedMagnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x88
struct FTagContainerAggregator
{
public:
    FGameplayTagContainer CapturedActorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer CapturedSpecTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ScopedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)

    void SET_CapturedActorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_CapturedSpecTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_ScopedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FGameplayEffectAttributeCaptureSpecContainer
{
public:
    TArray<FGameplayEffectAttributeCaptureSpec> SourceAttributes() const { return Read<TArray<FGameplayEffectAttributeCaptureSpec>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayEffectAttributeCaptureSpec> TargetAttributes() const { return Read<TArray<FGameplayEffectAttributeCaptureSpec>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bHasNonSnapshottedAttributes() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_SourceAttributes(const TArray<FGameplayEffectAttributeCaptureSpec>& Value) { Write<TArray<FGameplayEffectAttributeCaptureSpec>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_TargetAttributes(const TArray<FGameplayEffectAttributeCaptureSpec>& Value) { Write<TArray<FGameplayEffectAttributeCaptureSpec>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasNonSnapshottedAttributes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FGameplayEffectAttributeCaptureSpec
{
public:
    FGameplayEffectAttributeCaptureDefinition BackingDefinition() const { return Read<FGameplayEffectAttributeCaptureDefinition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x40, Type: StructProperty)

    void SET_BackingDefinition(const FGameplayEffectAttributeCaptureDefinition& Value) { Write<FGameplayEffectAttributeCaptureDefinition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x40, Type: StructProperty)
};

// Size: 0x40
struct FGameplayEffectAttributeCaptureDefinition
{
public:
    FGameplayAttribute AttributeToCapture() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    uint8_t AttributeSource() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    bool bSnapshot() const { return Read<bool>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: BoolProperty)

    void SET_AttributeToCapture(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_AttributeSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_bSnapshot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FGameplayAttribute
{
public:
    FString AttributeName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    UStruct* AttributeOwner() const { return Read<UStruct*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_AttributeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_AttributeOwner(const UStruct*& Value) { Write<UStruct*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
struct FGameplayEffectModifiedAttribute
{
public:
    FGameplayAttribute Attribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    float TotalMagnitude() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_Attribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_TotalMagnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FActiveGameplayEffectHandle
{
public:
    int32_t Handle() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    bool bPassedFiltersAndWasExecuted() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_Handle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_bPassedFiltersAndWasExecuted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FGameplayEffectSpecHandle
{
public:
};

// Size: 0xd0
struct FGameplayCueParameters
{
public:
    float NormalizedMagnitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float RawMagnitude() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FGameplayEffectContextHandle EffectContext() const { return Read<FGameplayEffectContextHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FGameplayTag MatchedTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTag OriginalTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer AggregatedSourceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AggregatedTargetTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    FVector_NetQuantize10 Location() const { return Read<FVector_NetQuantize10>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantizeNormal Normal() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<AActor*> Instigator() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> EffectCauser() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UObject*> SourceObject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPhysicalMaterial*> PhysicalMaterial() const { return Read<TWeakObjectPtr<UPhysicalMaterial*>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: WeakObjectProperty)
    int32_t GameplayEffectLevel() const { return Read<int32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t AbilityLevel() const { return Read<int32_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<USceneComponent*> TargetAttachComponent() const { return Read<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    bool bReplicateLocationWhenUsingMinimalRepProxy() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)

    void SET_NormalizedMagnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_RawMagnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_EffectContext(const FGameplayEffectContextHandle& Value) { Write<FGameplayEffectContextHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_MatchedTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_OriginalTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
    void SET_AggregatedSourceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_AggregatedTargetTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_Location(const FVector_NetQuantize10& Value) { Write<FVector_NetQuantize10>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_Instigator(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EffectCauser(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SourceObject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PhysicalMaterial(const TWeakObjectPtr<UPhysicalMaterial*>& Value) { Write<TWeakObjectPtr<UPhysicalMaterial*>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_GameplayEffectLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: IntProperty)
    void SET_AbilityLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: IntProperty)
    void SET_TargetAttachComponent(const TWeakObjectPtr<USceneComponent*>& Value) { Write<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bReplicateLocationWhenUsingMinimalRepProxy(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FGameplayEffectRemovalInfo
{
public:
    bool bPrematureRemoval() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    int32_t StackCount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FGameplayEffectContextHandle EffectContext() const { return Read<FGameplayEffectContextHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_bPrematureRemoval(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_StackCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_EffectContext(const FGameplayEffectContextHandle& Value) { Write<FGameplayEffectContextHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb0
struct FGameplayEventData
{
public:
    FGameplayTag EventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* Instigator() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UObject* OptionalObject() const { return Read<UObject*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    UObject* OptionalObject2() const { return Read<UObject*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    FGameplayEffectContextHandle ContextHandle() const { return Read<FGameplayEffectContextHandle>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer InstigatorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)
    float EventMagnitude() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    FGameplayAbilityTargetDataHandle TargetData() const { return Read<FGameplayAbilityTargetDataHandle>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)

    void SET_EventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Instigator(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_OptionalObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_OptionalObject2(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_ContextHandle(const FGameplayEffectContextHandle& Value) { Write<FGameplayEffectContextHandle>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_InstigatorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_TargetTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
    void SET_EventMagnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_TargetData(const FGameplayAbilityTargetDataHandle& Value) { Write<FGameplayAbilityTargetDataHandle>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FGameplayAbilityTargetDataHandle
{
public:
};

// Size: 0x88
struct FGameplayTagRequirements
{
public:
    FGameplayTagContainer RequireTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer IgnoreTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagQuery TagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x48, Type: StructProperty)

    void SET_RequireTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_IgnoreTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_TagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x48, Type: StructProperty)
};

// Size: 0x10
struct FGameplayTargetDataFilterHandle
{
public:
};

// Size: 0x14
struct FGameplayAbilityActivationInfo
{
public:
    TEnumAsByte<EGameplayAbilityActivationMode> ActivationMode() const { return Read<TEnumAsByte<EGameplayAbilityActivationMode>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    bool bCanBeEndedByOtherInstance() const { return (Read<uint8_t>(uintptr_t(this) + 0x1) >> 0x0) & 1; } // 0x1:0 (Size: 0x1, Type: BoolProperty)
    FPredictionKey PredictionKeyWhenActivated() const { return Read<FPredictionKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)

    void SET_ActivationMode(const TEnumAsByte<EGameplayAbilityActivationMode>& Value) { Write<TEnumAsByte<EGameplayAbilityActivationMode>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_bCanBeEndedByOtherInstance(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1, B); } // 0x1:0 (Size: 0x1, Type: BoolProperty)
    void SET_PredictionKeyWhenActivated(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
};

// Size: 0x198
struct FGameplayEffectQuery
{
public:
    FGameplayTagQuery OwningTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery EffectTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery SourceTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery SourceAggregateTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x48, Type: StructProperty)
    FGameplayAttribute ModifyingAttribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x38, Type: StructProperty)
    UObject* EffectSource() const { return Read<UObject*>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    UClass* EffectDefinition() const { return Read<UClass*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ClassProperty)

    void SET_OwningTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x48, Type: StructProperty)
    void SET_EffectTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x48, Type: StructProperty)
    void SET_SourceTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x48, Type: StructProperty)
    void SET_SourceAggregateTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x48, Type: StructProperty)
    void SET_ModifyingAttribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x38, Type: StructProperty)
    void SET_EffectSource(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    void SET_EffectDefinition(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x78
struct FGameplayEffectSpecForRPC
{
public:
    UGameplayEffect* Def() const { return Read<UGameplayEffect*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayEffectModifiedAttribute> ModifiedAttributes() const { return Read<TArray<FGameplayEffectModifiedAttribute>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FGameplayEffectContextHandle EffectContext() const { return Read<FGameplayEffectContextHandle>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer AggregatedSourceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AggregatedTargetTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)
    float Level() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float AbilityLevel() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)

    void SET_Def(const UGameplayEffect*& Value) { Write<UGameplayEffect*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ModifiedAttributes(const TArray<FGameplayEffectModifiedAttribute>& Value) { Write<TArray<FGameplayEffectModifiedAttribute>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_EffectContext(const FGameplayEffectContextHandle& Value) { Write<FGameplayEffectContextHandle>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_AggregatedSourceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_AggregatedTargetTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
    void SET_Level(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_AbilityLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
struct FServerAbilityRPCBatch
{
public:
    FGameplayAbilitySpecHandle AbilitySpecHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    FGameplayAbilityTargetDataHandle TargetData() const { return Read<FGameplayAbilityTargetDataHandle>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x28, Type: StructProperty)
    bool InputPressed() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool Ended() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool Started() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)

    void SET_AbilitySpecHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_TargetData(const FGameplayAbilityTargetDataHandle& Value) { Write<FGameplayAbilityTargetDataHandle>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x28, Type: StructProperty)
    void SET_InputPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_Ended(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_Started(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x118
struct FReplicatedPredictionKeyMap : public FFastArraySerializer
{
public:
    TArray<FReplicatedPredictionKeyItem> PredictionKeys() const { return Read<TArray<FReplicatedPredictionKeyItem>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)

    void SET_PredictionKeys(const TArray<FReplicatedPredictionKeyItem>& Value) { Write<TArray<FReplicatedPredictionKeyItem>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1c
struct FReplicatedPredictionKeyItem : public FFastArraySerializerItem
{
public:
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)

    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
};

// Size: 0x68
struct FMinimalReplicationTagCountMap
{
public:
    UAbilitySystemComponent* Owner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_Owner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x128
struct FActiveGameplayCueContainer : public FFastArraySerializer
{
public:
    TArray<FActiveGameplayCue> GameplayCues() const { return Read<TArray<FActiveGameplayCue>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    UAbilitySystemComponent* Owner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayCues(const TArray<FActiveGameplayCue>& Value) { Write<TArray<FActiveGameplayCue>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_Owner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf8
struct FActiveGameplayCue : public FFastArraySerializerItem
{
public:
    FGameplayTag GameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FGameplayCueParameters Parameters() const { return Read<FGameplayCueParameters>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xd0, Type: StructProperty)
    bool bPredictivelyRemoved() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)

    void SET_GameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Parameters(const FGameplayCueParameters& Value) { Write<FGameplayCueParameters>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xd0, Type: StructProperty)
    void SET_bPredictivelyRemoved(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x300
struct FActiveGameplayEffectsContainer : public FFastArraySerializer
{
public:
    TArray<FActiveGameplayEffect> GameplayEffects_Internal() const { return Read<TArray<FActiveGameplayEffect>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: ArrayProperty)

    void SET_GameplayEffects_Internal(const TArray<FActiveGameplayEffect>& Value) { Write<TArray<FActiveGameplayEffect>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FGameplayAbilityLocalAnimMontage
{
public:
    UAnimMontage* AnimMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    char PlayInstanceId() const { return Read<char>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)
    TWeakObjectPtr<UGameplayAbility*> AnimatingAbility() const { return Read<TWeakObjectPtr<UGameplayAbility*>>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: WeakObjectProperty)

    void SET_AnimMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayInstanceId(const char& Value) { Write<char>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
    void SET_AnimatingAbility(const TWeakObjectPtr<UGameplayAbility*>& Value) { Write<TWeakObjectPtr<UGameplayAbility*>>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x38
struct FGameplayAbilityRepAnimMontage
{
public:
    UAnimSequenceBase* Animation() const { return Read<UAnimSequenceBase*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName SlotName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Position() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float BlendOutTime() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float PlayCount() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    char NextSectionID() const { return Read<char>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: ByteProperty)
    char PlayInstanceId() const { return Read<char>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: ByteProperty)
    bool bRepPosition() const { return (Read<uint8_t>(uintptr_t(this) + 0x22) >> 0x0) & 1; } // 0x22:0 (Size: 0x1, Type: BoolProperty)
    bool IsStopped() const { return (Read<uint8_t>(uintptr_t(this) + 0x22) >> 0x1) & 1; } // 0x22:1 (Size: 0x1, Type: BoolProperty)
    bool SkipPositionCorrection() const { return (Read<uint8_t>(uintptr_t(this) + 0x22) >> 0x2) & 1; } // 0x22:2 (Size: 0x1, Type: BoolProperty)
    bool bSkipPlayRate() const { return (Read<uint8_t>(uintptr_t(this) + 0x22) >> 0x3) & 1; } // 0x22:3 (Size: 0x1, Type: BoolProperty)
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x10, Type: StructProperty)
    char SectionIdToPlay() const { return Read<char>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: ByteProperty)

    void SET_Animation(const UAnimSequenceBase*& Value) { Write<UAnimSequenceBase*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SlotName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Position(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_BlendOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_PlayCount(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_NextSectionID(const char& Value) { Write<char>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: ByteProperty)
    void SET_PlayInstanceId(const char& Value) { Write<char>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: ByteProperty)
    void SET_bRepPosition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x22); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x22, B); } // 0x22:0 (Size: 0x1, Type: BoolProperty)
    void SET_IsStopped(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x22); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x22, B); } // 0x22:1 (Size: 0x1, Type: BoolProperty)
    void SET_SkipPositionCorrection(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x22); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x22, B); } // 0x22:2 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipPlayRate(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x22); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x22, B); } // 0x22:3 (Size: 0x1, Type: BoolProperty)
    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x10, Type: StructProperty)
    void SET_SectionIdToPlay(const char& Value) { Write<char>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x120
struct FGameplayAbilitySpecContainer : public FFastArraySerializer
{
public:
    TArray<FGameplayAbilitySpec> Items() const { return Read<TArray<FGameplayAbilitySpec>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    UAbilitySystemComponent* Owner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)

    void SET_Items(const TArray<FGameplayAbilitySpec>& Value) { Write<TArray<FGameplayAbilitySpec>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_Owner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf0
struct FGameplayAbilitySpec : public FFastArraySerializerItem
{
public:
    FGameplayAbilitySpecHandle Handle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    UGameplayAbility* ability() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    int32_t Level() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t InputID() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UObject*> SourceObject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    char ActiveCount() const { return Read<char>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: ByteProperty)
    bool InputPressed() const { return (Read<uint8_t>(uintptr_t(this) + 0x29) >> 0x0) & 1; } // 0x29:0 (Size: 0x1, Type: BoolProperty)
    bool RemoveAfterActivation() const { return (Read<uint8_t>(uintptr_t(this) + 0x29) >> 0x1) & 1; } // 0x29:1 (Size: 0x1, Type: BoolProperty)
    bool PendingRemove() const { return (Read<uint8_t>(uintptr_t(this) + 0x29) >> 0x2) & 1; } // 0x29:2 (Size: 0x1, Type: BoolProperty)
    bool bActivateOnce() const { return (Read<uint8_t>(uintptr_t(this) + 0x29) >> 0x3) & 1; } // 0x29:3 (Size: 0x1, Type: BoolProperty)
    FGameplayAbilityActivationInfo ActivationInfo() const { return Read<FGameplayAbilityActivationInfo>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x14, Type: StructProperty)
    FGameplayTagContainer DynamicAbilityTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    TArray<UGameplayAbility*> NonReplicatedInstances() const { return Read<TArray<UGameplayAbility*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<UGameplayAbility*> ReplicatedInstances() const { return Read<TArray<UGameplayAbility*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    FActiveGameplayEffectHandle GameplayEffectHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)

    void SET_Handle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_ability(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_Level(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_InputID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_SourceObject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActiveCount(const char& Value) { Write<char>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: ByteProperty)
    void SET_InputPressed(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x29); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x29, B); } // 0x29:0 (Size: 0x1, Type: BoolProperty)
    void SET_RemoveAfterActivation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x29); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x29, B); } // 0x29:1 (Size: 0x1, Type: BoolProperty)
    void SET_PendingRemove(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x29); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x29, B); } // 0x29:2 (Size: 0x1, Type: BoolProperty)
    void SET_bActivateOnce(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x29); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x29, B); } // 0x29:3 (Size: 0x1, Type: BoolProperty)
    void SET_ActivationInfo(const FGameplayAbilityActivationInfo& Value) { Write<FGameplayAbilityActivationInfo>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x14, Type: StructProperty)
    void SET_DynamicAbilityTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_NonReplicatedInstances(const TArray<UGameplayAbility*>& Value) { Write<TArray<UGameplayAbility*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedInstances(const TArray<UGameplayAbility*>& Value) { Write<TArray<UGameplayAbility*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayEffectHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FAttributeDefaults
{
public:
    UClass* Attributes() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    UDataTable* DefaultStartingTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Attributes(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultStartingTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4
struct FGameplayCueTag
{
public:
    FGameplayTag GameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_GameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x48
struct FGameplayAbilityActorInfo
{
public:
    TWeakObjectPtr<AActor*> OwnerActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> AvatarActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerController*> PlayerController() const { return Read<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> AbilitySystemComponent() const { return Read<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> SkeletalMeshComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAnimInstance*> AnimInstance() const { return Read<TWeakObjectPtr<UAnimInstance*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMovementComponent*> MovementComponent() const { return Read<TWeakObjectPtr<UMovementComponent*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    FName AffectedAnimInstanceTag() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)

    void SET_OwnerActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AvatarActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerController(const TWeakObjectPtr<APlayerController*>& Value) { Write<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AbilitySystemComponent(const TWeakObjectPtr<UAbilitySystemComponent*>& Value) { Write<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SkeletalMeshComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AnimInstance(const TWeakObjectPtr<UAnimInstance*>& Value) { Write<TWeakObjectPtr<UAnimInstance*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MovementComponent(const TWeakObjectPtr<UMovementComponent*>& Value) { Write<TWeakObjectPtr<UMovementComponent*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AffectedAnimInstanceTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
};

// Size: 0x90
struct FGameplayAbilityTargetingLocationInfo
{
public:
    AActor* SourceActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMeshComponent* SourceComponent() const { return Read<UMeshComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UGameplayAbility* SourceAbility() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    FTransform LiteralTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FName SourceSocketName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EGameplayAbilityTargetingLocationType> LocationType() const { return Read<TEnumAsByte<EGameplayAbilityTargetingLocationType>>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: ByteProperty)

    void SET_SourceActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_SourceComponent(const UMeshComponent*& Value) { Write<UMeshComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_SourceAbility(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_LiteralTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_SourceSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_LocationType(const TEnumAsByte<EGameplayAbilityTargetingLocationType>& Value) { Write<TEnumAsByte<EGameplayAbilityTargetingLocationType>>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x8
struct FAbilityTriggerData
{
public:
    FGameplayTag TriggerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TEnumAsByte<EGameplayAbilityTriggerSource> TriggerSource() const { return Read<TEnumAsByte<EGameplayAbilityTriggerSource>>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: ByteProperty)

    void SET_TriggerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_TriggerSource(const TEnumAsByte<EGameplayAbilityTriggerSource>& Value) { Write<TEnumAsByte<EGameplayAbilityTriggerSource>>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FGameplayModifierEvaluatedData
{
public:
    FGameplayAttribute Attribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EGameplayModOp> ModifierOp() const { return Read<TEnumAsByte<EGameplayModOp>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FActiveGameplayEffectHandle Handle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: StructProperty)
    bool IsValid() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_Attribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_ModifierOp(const TEnumAsByte<EGameplayModOp>& Value) { Write<TEnumAsByte<EGameplayModOp>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Handle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: StructProperty)
    void SET_IsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x338
struct FGameplayEffectExecutionScopedModifierInfo
{
public:
    FGameplayEffectAttributeCaptureDefinition CapturedAttribute() const { return Read<FGameplayEffectAttributeCaptureDefinition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x40, Type: StructProperty)
    FGameplayTag TransientAggregatorIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: StructProperty)
    uint8_t AggregatorType() const { return Read<uint8_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EGameplayModOp> ModifierOp() const { return Read<TEnumAsByte<EGameplayModOp>>(uintptr_t(this) + 0x45); } // 0x45 (Size: 0x1, Type: ByteProperty)
    FGameplayEffectModifierMagnitude ModifierMagnitude() const { return Read<FGameplayEffectModifierMagnitude>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1d8, Type: StructProperty)
    FGameplayModEvaluationChannelSettings EvaluationChannelSettings() const { return Read<FGameplayModEvaluationChannelSettings>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x1, Type: StructProperty)
    FGameplayTagRequirements SourceTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements TargetTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x88, Type: StructProperty)

    void SET_CapturedAttribute(const FGameplayEffectAttributeCaptureDefinition& Value) { Write<FGameplayEffectAttributeCaptureDefinition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x40, Type: StructProperty)
    void SET_TransientAggregatorIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: StructProperty)
    void SET_AggregatorType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: EnumProperty)
    void SET_ModifierOp(const TEnumAsByte<EGameplayModOp>& Value) { Write<TEnumAsByte<EGameplayModOp>>(uintptr_t(this) + 0x45, Value); } // 0x45 (Size: 0x1, Type: ByteProperty)
    void SET_ModifierMagnitude(const FGameplayEffectModifierMagnitude& Value) { Write<FGameplayEffectModifierMagnitude>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1d8, Type: StructProperty)
    void SET_EvaluationChannelSettings(const FGameplayModEvaluationChannelSettings& Value) { Write<FGameplayModEvaluationChannelSettings>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x1, Type: StructProperty)
    void SET_SourceTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x88, Type: StructProperty)
    void SET_TargetTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x88, Type: StructProperty)
};

// Size: 0x1
struct FGameplayModEvaluationChannelSettings
{
public:
    uint8_t Channel() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_Channel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1d8
struct FGameplayEffectModifierMagnitude
{
public:
    uint8_t MagnitudeCalculationType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FScalableFloat ScalableFloatMagnitude() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    FAttributeBasedFloat AttributeBasedMagnitude() const { return Read<FAttributeBasedFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x110, Type: StructProperty)
    FCustomCalculationBasedFloat CustomMagnitude() const { return Read<FCustomCalculationBasedFloat>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x90, Type: StructProperty)
    FSetByCallerFloat SetByCallerMagnitude() const { return Read<FSetByCallerFloat>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: StructProperty)

    void SET_MagnitudeCalculationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ScalableFloatMagnitude(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_AttributeBasedMagnitude(const FAttributeBasedFloat& Value) { Write<FAttributeBasedFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x110, Type: StructProperty)
    void SET_CustomMagnitude(const FCustomCalculationBasedFloat& Value) { Write<FCustomCalculationBasedFloat>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x90, Type: StructProperty)
    void SET_SetByCallerMagnitude(const FSetByCallerFloat& Value) { Write<FSetByCallerFloat>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FSetByCallerFloat
{
public:
    FName DataName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FGameplayTag DataTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_DataName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_DataTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x90
struct FCustomCalculationBasedFloat
{
public:
    UClass* CalculationClassMagnitude() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat Coefficient() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PreMultiplyAdditiveValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FScalableFloat PostMultiplyAdditiveValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)
    FCurveTableRowHandle FinalLookupCurve() const { return Read<FCurveTableRowHandle>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)

    void SET_CalculationClassMagnitude(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_Coefficient(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_PreMultiplyAdditiveValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_PostMultiplyAdditiveValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
    void SET_FinalLookupCurve(const FCurveTableRowHandle& Value) { Write<FCurveTableRowHandle>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
};

// Size: 0x110
struct FAttributeBasedFloat
{
public:
    FScalableFloat Coefficient() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat PreMultiplyAdditiveValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat PostMultiplyAdditiveValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    FGameplayEffectAttributeCaptureDefinition BackingAttribute() const { return Read<FGameplayEffectAttributeCaptureDefinition>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x40, Type: StructProperty)
    FCurveTableRowHandle AttributeCurve() const { return Read<FCurveTableRowHandle>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    uint8_t AttributeCalculationType() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t FinalChannel() const { return Read<uint8_t>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    FGameplayTagContainer SourceTagFilter() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetTagFilter() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: StructProperty)

    void SET_Coefficient(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_PreMultiplyAdditiveValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_PostMultiplyAdditiveValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_BackingAttribute(const FGameplayEffectAttributeCaptureDefinition& Value) { Write<FGameplayEffectAttributeCaptureDefinition>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x40, Type: StructProperty)
    void SET_AttributeCurve(const FCurveTableRowHandle& Value) { Write<FCurveTableRowHandle>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_AttributeCalculationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_FinalChannel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    void SET_SourceTagFilter(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_TargetTagFilter(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x38
struct FGameplayAbilitySpecConfig
{
public:
    UClass* ability() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat LevelScalableFloat() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    int32_t InputID() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t RemovalPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: EnumProperty)

    void SET_ability(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_LevelScalableFloat(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_InputID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_RemovalPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FGameplayAbilityTargetingLocationInfoNetSerializerConfig : public FNetSerializerConfig
{
public:
};

// Size: 0x180
struct FGameplayCuePendingExecute
{
public:
    FPredictionKey PredictionKey() const { return Read<FPredictionKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    uint8_t PayloadType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    UAbilitySystemComponent* OwningComponent() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FGameplayEffectSpecForRPC FromSpec() const { return Read<FGameplayEffectSpecForRPC>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x78, Type: StructProperty)
    FGameplayCueParameters CueParameters() const { return Read<FGameplayCueParameters>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0xd0, Type: StructProperty)

    void SET_PredictionKey(const FPredictionKey& Value) { Write<FPredictionKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_PayloadType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_OwningComponent(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_FromSpec(const FGameplayEffectSpecForRPC& Value) { Write<FGameplayEffectSpecForRPC>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x78, Type: StructProperty)
    void SET_CueParameters(const FGameplayCueParameters& Value) { Write<FGameplayCueParameters>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0xd0, Type: StructProperty)
};

// Size: 0x10
struct FGameplayCueNotifyActorArray
{
public:
    TArray<AGameplayCueNotify_Actor*> Actors() const { return Read<TArray<AGameplayCueNotify_Actor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Actors(const TArray<AGameplayCueNotify_Actor*>& Value) { Write<TArray<AGameplayCueNotify_Actor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x68
struct FPreallocationInfo
{
public:
    TMap<UClass*, FGameplayCueNotifyActorArray> PreallocatedInstances() const { return Read<TMap<UClass*, FGameplayCueNotifyActorArray>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<UClass*> ClassesNeedingPreallocation() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_PreallocatedInstances(const TMap<UClass*, FGameplayCueNotifyActorArray>& Value) { Write<TMap<UClass*, FGameplayCueNotifyActorArray>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_ClassesNeedingPreallocation(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FMinimalGameplayCueReplicationProxyForNetSerializer
{
public:
    TArray<FGameplayTag> Tags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector_NetQuantize> Locations() const { return Read<TArray<FVector_NetQuantize>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Tags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Locations(const TArray<FVector_NetQuantize>& Value) { Write<TArray<FVector_NetQuantize>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FMinimalReplicationTagCountMapForNetSerializer
{
public:
    TArray<FGameplayTag> Tags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Tags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FGameplayAbilityBindInfo
{
public:
    TEnumAsByte<EGameplayAbilityInputBinds> Command() const { return Read<TEnumAsByte<EGameplayAbilityInputBinds>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    UClass* GameplayAbilityClass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)

    void SET_Command(const TEnumAsByte<EGameplayAbilityInputBinds>& Value) { Write<TEnumAsByte<EGameplayAbilityInputBinds>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_GameplayAbilityClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x20
struct FGameplayTargetDataFilter
{
public:
    AActor* SelfActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* RequiredActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<ETargetDataFilterSelf> SelfFilter() const { return Read<TEnumAsByte<ETargetDataFilterSelf>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: ByteProperty)
    bool bReverseFilter() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)

    void SET_SelfActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_RequiredActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
    void SET_SelfFilter(const TEnumAsByte<ETargetDataFilterSelf>& Value) { Write<TEnumAsByte<ETargetDataFilterSelf>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: ByteProperty)
    void SET_bReverseFilter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FWorldReticleParameters
{
public:
    FVector AOEScale() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_AOEScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x10
struct FGameplayTagChangedEventWrapperSpecHandle
{
public:
};

// Size: 0x10
struct FNetSerializeScriptStructCache
{
public:
    TArray<UScriptStruct*> ScriptStructs() const { return Read<TArray<UScriptStruct*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ScriptStructs(const TArray<UScriptStruct*>& Value) { Write<TArray<UScriptStruct*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FGameplayAttributeData
{
public:
    float BaseValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float CurrentValue() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_BaseValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FAttributeMetaData : public FTableRowBase
{
public:
    float BaseValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinValue() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxValue() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FString DerivedAttributeInfo() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    bool bCanStack() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_BaseValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxValue(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_DerivedAttributeInfo(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_bCanStack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FGameplayAbilityTargetData
{
public:
};

// Size: 0x130
struct FGameplayAbilityTargetData_LocationInfo : public FGameplayAbilityTargetData
{
public:
    FGameplayAbilityTargetingLocationInfo SourceLocation() const { return Read<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x90, Type: StructProperty)
    FGameplayAbilityTargetingLocationInfo TargetLocation() const { return Read<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x90, Type: StructProperty)

    void SET_SourceLocation(const FGameplayAbilityTargetingLocationInfo& Value) { Write<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x90, Type: StructProperty)
    void SET_TargetLocation(const FGameplayAbilityTargetingLocationInfo& Value) { Write<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x90, Type: StructProperty)
};

// Size: 0xb0
struct FGameplayAbilityTargetData_ActorArray : public FGameplayAbilityTargetData
{
public:
    FGameplayAbilityTargetingLocationInfo SourceLocation() const { return Read<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x90, Type: StructProperty)
    TArray<TWeakObjectPtr<AActor*>> TargetActorArray() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)

    void SET_SourceLocation(const FGameplayAbilityTargetingLocationInfo& Value) { Write<FGameplayAbilityTargetingLocationInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x90, Type: StructProperty)
    void SET_TargetActorArray(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x108
struct FGameplayAbilityTargetData_SingleTargetHit : public FGameplayAbilityTargetData
{
public:
    FHitResult HitResult() const { return Read<FHitResult>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0xf8, Type: StructProperty)
    bool bHitReplaced() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_HitResult(const FHitResult& Value) { Write<FHitResult>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0xf8, Type: StructProperty)
    void SET_bHitReplaced(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FAbilityEndedData
{
public:
    UGameplayAbility* AbilityThatEnded() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayAbilitySpecHandle AbilitySpecHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    bool bReplicateEndAbility() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    bool bWasCancelled() const { return Read<bool>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: BoolProperty)

    void SET_AbilityThatEnded(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilitySpecHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_bReplicateEndAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_bWasCancelled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FAbilityTaskDebugMessage
{
public:
    UGameplayTask* FromTask() const { return Read<UGameplayTask*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FString Message() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_FromTask(const UGameplayTask*& Value) { Write<UGameplayTask*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Message(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FGameplayAbilitySpecHandleAndPredictionKey
{
public:
    FGameplayAbilitySpecHandle AbilityHandle() const { return Read<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t PredictionKeyAtCreation() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_AbilityHandle(const FGameplayAbilitySpecHandle& Value) { Write<FGameplayAbilitySpecHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_PredictionKeyAtCreation(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x2c0
struct FMinimalGameplayCueReplicationProxy
{
public:
    UAbilitySystemComponent* Owner() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_Owner(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
struct FGameplayCueObjectLibrary
{
public:
    TArray<FString> Paths() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    UObjectLibrary* ActorObjectLibrary() const { return Read<UObjectLibrary*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UObjectLibrary* StaticObjectLibrary() const { return Read<UObjectLibrary*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UGameplayCueSet* CueSet() const { return Read<UGameplayCueSet*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSyncScan() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bShouldAsyncLoad() const { return Read<bool>(uintptr_t(this) + 0x4d); } // 0x4d (Size: 0x1, Type: BoolProperty)
    bool bShouldSyncLoad() const { return Read<bool>(uintptr_t(this) + 0x4e); } // 0x4e (Size: 0x1, Type: BoolProperty)
    bool bHasBeenInitialized() const { return Read<bool>(uintptr_t(this) + 0x4f); } // 0x4f (Size: 0x1, Type: BoolProperty)

    void SET_Paths(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ActorObjectLibrary(const UObjectLibrary*& Value) { Write<UObjectLibrary*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticObjectLibrary(const UObjectLibrary*& Value) { Write<UObjectLibrary*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_CueSet(const UGameplayCueSet*& Value) { Write<UGameplayCueSet*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldSyncScan(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_bShouldAsyncLoad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d, Value); } // 0x4d (Size: 0x1, Type: BoolProperty)
    void SET_bShouldSyncLoad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e, Value); } // 0x4e (Size: 0x1, Type: BoolProperty)
    void SET_bHasBeenInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f, Value); } // 0x4f (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FGameplayCueNotify_SpawnCondition
{
public:
    uint8_t LocallyControlledSource() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LocallyControlledPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    float ChanceToPlay() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    TArray<TEnumAsByte<EPhysicalSurface>> AllowedSurfaceTypes() const { return Read<TArray<TEnumAsByte<EPhysicalSurface>>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<TEnumAsByte<EPhysicalSurface>> RejectedSurfaceTypes() const { return Read<TArray<TEnumAsByte<EPhysicalSurface>>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_LocallyControlledSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_LocallyControlledPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_ChanceToPlay(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_AllowedSurfaceTypes(const TArray<TEnumAsByte<EPhysicalSurface>>& Value) { Write<TArray<TEnumAsByte<EPhysicalSurface>>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_RejectedSurfaceTypes(const TArray<TEnumAsByte<EPhysicalSurface>>& Value) { Write<TArray<TEnumAsByte<EPhysicalSurface>>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FGameplayCueNotify_PlacementInfo
{
public:
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t AttachPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t AttachmentRule() const { return Read<uint8_t>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: EnumProperty)
    bool bOverrideRotation() const { return (Read<uint8_t>(uintptr_t(this) + 0x8) >> 0x0) & 1; } // 0x8:0 (Size: 0x1, Type: BoolProperty)
    bool bOverrideScale() const { return (Read<uint8_t>(uintptr_t(this) + 0x8) >> 0x1) & 1; } // 0x8:1 (Size: 0x1, Type: BoolProperty)
    FRotator RotationOverride() const { return Read<FRotator>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector ScaleOverride() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AttachPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_AttachmentRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: EnumProperty)
    void SET_bOverrideRotation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x8, B); } // 0x8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideScale(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x8, B); } // 0x8:1 (Size: 0x1, Type: BoolProperty)
    void SET_RotationOverride(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_ScaleOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FGameplayCueNotify_SpawnResult
{
public:
    TArray<UFXSystemComponent*> FxSystemComponents() const { return Read<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UAudioComponent*> AudioComponents() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraShakeBase*> CameraShakes() const { return Read<TArray<UCameraShakeBase*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<TScriptInterface<Class>> CameraLensEffects() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    UForceFeedbackComponent* ForceFeedbackComponent() const { return Read<UForceFeedbackComponent*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    APlayerController* ForceFeedbackTargetPC() const { return Read<APlayerController*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UDecalComponent* DecalComponent() const { return Read<UDecalComponent*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_FxSystemComponents(const TArray<UFXSystemComponent*>& Value) { Write<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_AudioComponents(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CameraShakes(const TArray<UCameraShakeBase*>& Value) { Write<TArray<UCameraShakeBase*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_CameraLensEffects(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ForceFeedbackComponent(const UForceFeedbackComponent*& Value) { Write<UForceFeedbackComponent*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_ForceFeedbackTargetPC(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_DecalComponent(const UDecalComponent*& Value) { Write<UDecalComponent*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
struct FGameplayCueNotify_ParticleInfo
{
public:
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    UNiagaraSystem* NiagaraSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    bool bOverrideSpawnCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x80) >> 0x0) & 1; } // 0x80:0 (Size: 0x1, Type: BoolProperty)
    bool bOverridePlacementInfo() const { return (Read<uint8_t>(uintptr_t(this) + 0x80) >> 0x1) & 1; } // 0x80:1 (Size: 0x1, Type: BoolProperty)
    bool bCastShadow() const { return (Read<uint8_t>(uintptr_t(this) + 0x80) >> 0x2) & 1; } // 0x80:2 (Size: 0x1, Type: BoolProperty)

    void SET_SpawnConditionOverride(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlacementInfoOverride(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_NiagaraSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_bOverrideSpawnCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x80); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x80, B); } // 0x80:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverridePlacementInfo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x80); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x80, B); } // 0x80:1 (Size: 0x1, Type: BoolProperty)
    void SET_bCastShadow(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x80); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x80, B); } // 0x80:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FGameplayCueNotify_SoundParameterInterfaceInfo
{
public:
    FName StopTriggerName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_StopTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x98
struct FGameplayCueNotify_SoundInfo
{
public:
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    USoundBase* Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundCue() const { return Read<USoundBase*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    float LoopingFadeOutDuration() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float LoopingFadeVolumeLevel() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    FGameplayCueNotify_SoundParameterInterfaceInfo SoundParameterInterfaceInfo() const { return Read<FGameplayCueNotify_SoundParameterInterfaceInfo>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: StructProperty)
    bool bOverrideSpawnCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x94) >> 0x0) & 1; } // 0x94:0 (Size: 0x1, Type: BoolProperty)
    bool bOverridePlacementInfo() const { return (Read<uint8_t>(uintptr_t(this) + 0x94) >> 0x1) & 1; } // 0x94:1 (Size: 0x1, Type: BoolProperty)
    bool bUseSoundParameterInterface() const { return (Read<uint8_t>(uintptr_t(this) + 0x94) >> 0x2) & 1; } // 0x94:2 (Size: 0x1, Type: BoolProperty)

    void SET_SpawnConditionOverride(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlacementInfoOverride(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundCue(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_LoopingFadeOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_LoopingFadeVolumeLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_SoundParameterInterfaceInfo(const FGameplayCueNotify_SoundParameterInterfaceInfo& Value) { Write<FGameplayCueNotify_SoundParameterInterfaceInfo>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: StructProperty)
    void SET_bOverrideSpawnCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x94); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x94, B); } // 0x94:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverridePlacementInfo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x94); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x94, B); } // 0x94:1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSoundParameterInterface(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x94); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x94, B); } // 0x94:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
struct FGameplayCueNotify_CameraShakeInfo
{
public:
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    UClass* CameraShake() const { return Read<UClass*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ClassProperty)
    float ShakeScale() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    uint8_t Playspace() const { return Read<uint8_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: EnumProperty)
    bool bOverrideSpawnCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x88) >> 0x0) & 1; } // 0x88:0 (Size: 0x1, Type: BoolProperty)
    bool bOverridePlacementInfo() const { return (Read<uint8_t>(uintptr_t(this) + 0x88) >> 0x1) & 1; } // 0x88:1 (Size: 0x1, Type: BoolProperty)
    bool bPlayInWorld() const { return (Read<uint8_t>(uintptr_t(this) + 0x88) >> 0x2) & 1; } // 0x88:2 (Size: 0x1, Type: BoolProperty)
    float WorldInnerRadius() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    float WorldOuterRadius() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float WorldFalloffExponent() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)

    void SET_SpawnConditionOverride(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlacementInfoOverride(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_CameraShake(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ClassProperty)
    void SET_ShakeScale(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Playspace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: EnumProperty)
    void SET_bOverrideSpawnCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x88); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x88, B); } // 0x88:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverridePlacementInfo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x88); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x88, B); } // 0x88:1 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayInWorld(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x88); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x88, B); } // 0x88:2 (Size: 0x1, Type: BoolProperty)
    void SET_WorldInnerRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_WorldOuterRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_WorldFalloffExponent(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FGameplayCueNotify_CameraLensEffectInfo
{
public:
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    UClass* CameraLensEffect() const { return Read<UClass*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ClassProperty)
    bool bOverrideSpawnCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x80) >> 0x0) & 1; } // 0x80:0 (Size: 0x1, Type: BoolProperty)
    bool bOverridePlacementInfo() const { return (Read<uint8_t>(uintptr_t(this) + 0x80) >> 0x1) & 1; } // 0x80:1 (Size: 0x1, Type: BoolProperty)
    bool bPlayInWorld() const { return (Read<uint8_t>(uintptr_t(this) + 0x80) >> 0x2) & 1; } // 0x80:2 (Size: 0x1, Type: BoolProperty)
    float WorldInnerRadius() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float WorldOuterRadius() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)

    void SET_SpawnConditionOverride(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlacementInfoOverride(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_CameraLensEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ClassProperty)
    void SET_bOverrideSpawnCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x80); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x80, B); } // 0x80:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverridePlacementInfo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x80); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x80, B); } // 0x80:1 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayInWorld(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x80); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x80, B); } // 0x80:2 (Size: 0x1, Type: BoolProperty)
    void SET_WorldInnerRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_WorldOuterRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x98
struct FGameplayCueNotify_ForceFeedbackInfo
{
public:
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    UForceFeedbackEffect* ForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    FName ForceFeedbackTag() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    bool bIsLooping() const { return (Read<uint8_t>(uintptr_t(this) + 0x84) >> 0x0) & 1; } // 0x84:0 (Size: 0x1, Type: BoolProperty)
    bool bOverrideSpawnCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x84) >> 0x1) & 1; } // 0x84:1 (Size: 0x1, Type: BoolProperty)
    bool bOverridePlacementInfo() const { return (Read<uint8_t>(uintptr_t(this) + 0x84) >> 0x2) & 1; } // 0x84:2 (Size: 0x1, Type: BoolProperty)
    bool bPlayInWorld() const { return (Read<uint8_t>(uintptr_t(this) + 0x84) >> 0x3) & 1; } // 0x84:3 (Size: 0x1, Type: BoolProperty)
    float WorldIntensity() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    UForceFeedbackAttenuation* WorldAttenuation() const { return Read<UForceFeedbackAttenuation*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_SpawnConditionOverride(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlacementInfoOverride(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_ForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_ForceFeedbackTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_bIsLooping(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x84); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x84, B); } // 0x84:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideSpawnCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x84); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x84, B); } // 0x84:1 (Size: 0x1, Type: BoolProperty)
    void SET_bOverridePlacementInfo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x84); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x84, B); } // 0x84:2 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayInWorld(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x84); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x84, B); } // 0x84:3 (Size: 0x1, Type: BoolProperty)
    void SET_WorldIntensity(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_WorldAttenuation(const UForceFeedbackAttenuation*& Value) { Write<UForceFeedbackAttenuation*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FGameplayCueNotify_InputDevicePropertyInfo
{
public:
    TArray<UClass*> DeviceProperties() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_DeviceProperties(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa8
struct FGameplayCueNotify_DecalInfo
{
public:
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride() const { return Read<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride() const { return Read<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    UMaterialInterface* DecalMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    FVector DecalSize() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    bool bOverrideSpawnCondition() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x0) & 1; } // 0x98:0 (Size: 0x1, Type: BoolProperty)
    bool bOverridePlacementInfo() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x1) & 1; } // 0x98:1 (Size: 0x1, Type: BoolProperty)
    bool bOverrideFadeOut() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x2) & 1; } // 0x98:2 (Size: 0x1, Type: BoolProperty)
    float FadeOutStartDelay() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)

    void SET_SpawnConditionOverride(const FGameplayCueNotify_SpawnCondition& Value) { Write<FGameplayCueNotify_SpawnCondition>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlacementInfoOverride(const FGameplayCueNotify_PlacementInfo& Value) { Write<FGameplayCueNotify_PlacementInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_DecalMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_DecalSize(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_bOverrideSpawnCondition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverridePlacementInfo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:1 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideFadeOut(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:2 (Size: 0x1, Type: BoolProperty)
    void SET_FadeOutStartDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_FadeOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x298
struct FGameplayCueNotify_BurstEffects
{
public:
    TArray<FGameplayCueNotify_ParticleInfo> BurstParticles() const { return Read<TArray<FGameplayCueNotify_ParticleInfo>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayCueNotify_SoundInfo> BurstSounds() const { return Read<TArray<FGameplayCueNotify_SoundInfo>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FGameplayCueNotify_CameraShakeInfo BurstCameraShake() const { return Read<FGameplayCueNotify_CameraShakeInfo>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_CameraLensEffectInfo BurstCameraLensEffect() const { return Read<FGameplayCueNotify_CameraLensEffectInfo>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x90, Type: StructProperty)
    FGameplayCueNotify_ForceFeedbackInfo BurstForceFeedback() const { return Read<FGameplayCueNotify_ForceFeedbackInfo>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_InputDevicePropertyInfo BurstDevicePropertyEffect() const { return Read<FGameplayCueNotify_InputDevicePropertyInfo>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: StructProperty)
    FGameplayCueNotify_DecalInfo BurstDecal() const { return Read<FGameplayCueNotify_DecalInfo>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0xa8, Type: StructProperty)

    void SET_BurstParticles(const TArray<FGameplayCueNotify_ParticleInfo>& Value) { Write<TArray<FGameplayCueNotify_ParticleInfo>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_BurstSounds(const TArray<FGameplayCueNotify_SoundInfo>& Value) { Write<TArray<FGameplayCueNotify_SoundInfo>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_BurstCameraShake(const FGameplayCueNotify_CameraShakeInfo& Value) { Write<FGameplayCueNotify_CameraShakeInfo>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x98, Type: StructProperty)
    void SET_BurstCameraLensEffect(const FGameplayCueNotify_CameraLensEffectInfo& Value) { Write<FGameplayCueNotify_CameraLensEffectInfo>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x90, Type: StructProperty)
    void SET_BurstForceFeedback(const FGameplayCueNotify_ForceFeedbackInfo& Value) { Write<FGameplayCueNotify_ForceFeedbackInfo>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x98, Type: StructProperty)
    void SET_BurstDevicePropertyEffect(const FGameplayCueNotify_InputDevicePropertyInfo& Value) { Write<FGameplayCueNotify_InputDevicePropertyInfo>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: StructProperty)
    void SET_BurstDecal(const FGameplayCueNotify_DecalInfo& Value) { Write<FGameplayCueNotify_DecalInfo>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0xa8, Type: StructProperty)
};

// Size: 0x1f0
struct FGameplayCueNotify_LoopingEffects
{
public:
    TArray<FGameplayCueNotify_ParticleInfo> LoopingParticles() const { return Read<TArray<FGameplayCueNotify_ParticleInfo>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayCueNotify_SoundInfo> LoopingSounds() const { return Read<TArray<FGameplayCueNotify_SoundInfo>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FGameplayCueNotify_CameraShakeInfo LoopingCameraShake() const { return Read<FGameplayCueNotify_CameraShakeInfo>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_CameraLensEffectInfo LoopingCameraLensEffect() const { return Read<FGameplayCueNotify_CameraLensEffectInfo>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x90, Type: StructProperty)
    FGameplayCueNotify_ForceFeedbackInfo LoopingForceFeedback() const { return Read<FGameplayCueNotify_ForceFeedbackInfo>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_InputDevicePropertyInfo LoopingInputDevicePropertyEffect() const { return Read<FGameplayCueNotify_InputDevicePropertyInfo>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: StructProperty)

    void SET_LoopingParticles(const TArray<FGameplayCueNotify_ParticleInfo>& Value) { Write<TArray<FGameplayCueNotify_ParticleInfo>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_LoopingSounds(const TArray<FGameplayCueNotify_SoundInfo>& Value) { Write<TArray<FGameplayCueNotify_SoundInfo>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_LoopingCameraShake(const FGameplayCueNotify_CameraShakeInfo& Value) { Write<FGameplayCueNotify_CameraShakeInfo>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x98, Type: StructProperty)
    void SET_LoopingCameraLensEffect(const FGameplayCueNotify_CameraLensEffectInfo& Value) { Write<FGameplayCueNotify_CameraLensEffectInfo>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x90, Type: StructProperty)
    void SET_LoopingForceFeedback(const FGameplayCueNotify_ForceFeedbackInfo& Value) { Write<FGameplayCueNotify_ForceFeedbackInfo>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x98, Type: StructProperty)
    void SET_LoopingInputDevicePropertyEffect(const FGameplayCueNotify_InputDevicePropertyInfo& Value) { Write<FGameplayCueNotify_InputDevicePropertyInfo>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
struct FGameplayCueNotifyData
{
public:
    FGameplayTag GameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FSoftObjectPath GameplayCueNotifyObj() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    UClass* LoadedGameplayCueClass() const { return Read<UClass*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ClassProperty)

    void SET_GameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_GameplayCueNotifyObj(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_LoadedGameplayCueClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x4
struct FGameplayCueTranslatorNodeIndex
{
public:
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FGameplayCueTranslationLink
{
public:
    UGameplayCueTranslator* RulesCDO() const { return Read<UGameplayCueTranslator*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_RulesCDO(const UGameplayCueTranslator*& Value) { Write<UGameplayCueTranslator*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x70
struct FGameplayCueTranslatorNode
{
public:
    TArray<FGameplayCueTranslationLink> Links() const { return Read<TArray<FGameplayCueTranslationLink>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FGameplayCueTranslatorNodeIndex CachedIndex() const { return Read<FGameplayCueTranslatorNodeIndex>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    FGameplayTag CachedGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: StructProperty)
    FName CachedGameplayTagName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)

    void SET_Links(const TArray<FGameplayCueTranslationLink>& Value) { Write<TArray<FGameplayCueTranslationLink>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedIndex(const FGameplayCueTranslatorNodeIndex& Value) { Write<FGameplayCueTranslatorNodeIndex>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_CachedGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: StructProperty)
    void SET_CachedGameplayTagName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
};

// Size: 0x80
struct FGameplayCueTranslationManager
{
public:
    TArray<FGameplayCueTranslatorNode> TranslationLUT() const { return Read<TArray<FGameplayCueTranslatorNode>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FGameplayCueTranslatorNodeIndex> TranslationNameToIndexMap() const { return Read<TMap<FName, FGameplayCueTranslatorNodeIndex>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)
    UGameplayTagsManager* TagManager() const { return Read<UGameplayTagsManager*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_TranslationLUT(const TArray<FGameplayCueTranslatorNode>& Value) { Write<TArray<FGameplayCueTranslatorNode>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_TranslationNameToIndexMap(const TMap<FName, FGameplayCueTranslatorNodeIndex>& Value) { Write<TMap<FName, FGameplayCueTranslatorNodeIndex>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
    void SET_TagManager(const UGameplayTagsManager*& Value) { Write<UGameplayTagsManager*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FConditionalGameplayEffect
{
public:
    UClass* EffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer RequiredSourceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_EffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_RequiredSourceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x48
struct FGameplayEffectExecutionDefinition
{
public:
    UClass* CalculationClass() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer PassedInTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    TArray<FGameplayEffectExecutionScopedModifierInfo> CalculationModifiers() const { return Read<TArray<FGameplayEffectExecutionScopedModifierInfo>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FConditionalGameplayEffect> ConditionalGameplayEffects() const { return Read<TArray<FConditionalGameplayEffect>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_CalculationClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_PassedInTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_CalculationModifiers(const TArray<FGameplayEffectExecutionScopedModifierInfo>& Value) { Write<TArray<FGameplayEffectExecutionScopedModifierInfo>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ConditionalGameplayEffects(const TArray<FConditionalGameplayEffect>& Value) { Write<TArray<FConditionalGameplayEffect>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x330
struct FGameplayModifierInfo
{
public:
    FGameplayAttribute Attribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EGameplayModOp> ModifierOp() const { return Read<TEnumAsByte<EGameplayModOp>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    FGameplayEffectModifierMagnitude ModifierMagnitude() const { return Read<FGameplayEffectModifierMagnitude>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1d8, Type: StructProperty)
    FGameplayModEvaluationChannelSettings EvaluationChannelSettings() const { return Read<FGameplayModEvaluationChannelSettings>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x1, Type: StructProperty)
    FGameplayTagRequirements SourceTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements TargetTags() const { return Read<FGameplayTagRequirements>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x88, Type: StructProperty)

    void SET_Attribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_ModifierOp(const TEnumAsByte<EGameplayModOp>& Value) { Write<TEnumAsByte<EGameplayModOp>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_ModifierMagnitude(const FGameplayEffectModifierMagnitude& Value) { Write<FGameplayEffectModifierMagnitude>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1d8, Type: StructProperty)
    void SET_EvaluationChannelSettings(const FGameplayModEvaluationChannelSettings& Value) { Write<FGameplayModEvaluationChannelSettings>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x1, Type: StructProperty)
    void SET_SourceTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x88, Type: StructProperty)
    void SET_TargetTags(const FGameplayTagRequirements& Value) { Write<FGameplayTagRequirements>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x88, Type: StructProperty)
};

// Size: 0x60
struct FGameplayEffectCue
{
public:
    FGameplayAttribute MagnitudeAttribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    float MinLevel() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float MaxLevel() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer GameplayCueTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)

    void SET_MagnitudeAttribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_MinLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_GameplayCueTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
};

// Size: 0x60
struct FInheritedTagContainer
{
public:
    FGameplayTagContainer CombinedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Added() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Removed() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)

    void SET_CombinedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Added(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Removed(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
};

// Size: 0x88
struct FActiveGameplayEffectQuery
{
public:
};

// Size: 0x1
struct FGameplayEffectVersion
{
public:
};

// Size: 0xf0
struct FGameplayEffectCustomExecutionParameters
{
public:
};

// Size: 0x18
struct FGameplayEffectCustomExecutionOutput
{
public:
    TArray<FGameplayModifierEvaluatedData> OutputModifiers() const { return Read<TArray<FGameplayModifierEvaluatedData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bTriggerConditionalGameplayEffects() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x0) & 1; } // 0x10:0 (Size: 0x1, Type: BoolProperty)
    bool bHandledStackCountManually() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x1) & 1; } // 0x10:1 (Size: 0x1, Type: BoolProperty)
    bool bHandledGameplayCuesManually() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x2) & 1; } // 0x10:2 (Size: 0x1, Type: BoolProperty)

    void SET_OutputModifiers(const TArray<FGameplayModifierEvaluatedData>& Value) { Write<TArray<FGameplayModifierEvaluatedData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bTriggerConditionalGameplayEffects(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:0 (Size: 0x1, Type: BoolProperty)
    void SET_bHandledStackCountManually(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:1 (Size: 0x1, Type: BoolProperty)
    void SET_bHandledGameplayCuesManually(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FGameplayEffectContext
{
public:
    TWeakObjectPtr<AActor*> Instigator() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> EffectCauser() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UGameplayAbility*> AbilityCDO() const { return Read<TWeakObjectPtr<UGameplayAbility*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UGameplayAbility*> AbilityInstanceNotReplicated() const { return Read<TWeakObjectPtr<UGameplayAbility*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    int32_t AbilityLevel() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UObject*> SourceObject() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> InstigatorAbilitySystemComponent() const { return Read<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AActor*>> Actors() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FVector WorldOrigin() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    bool bHasWorldOrigin() const { return (Read<uint8_t>(uintptr_t(this) + 0x78) >> 0x0) & 1; } // 0x78:0 (Size: 0x1, Type: BoolProperty)
    bool bReplicateSourceObject() const { return (Read<uint8_t>(uintptr_t(this) + 0x78) >> 0x1) & 1; } // 0x78:1 (Size: 0x1, Type: BoolProperty)
    bool bReplicateInstigator() const { return (Read<uint8_t>(uintptr_t(this) + 0x78) >> 0x2) & 1; } // 0x78:2 (Size: 0x1, Type: BoolProperty)
    bool bReplicateEffectCauser() const { return (Read<uint8_t>(uintptr_t(this) + 0x78) >> 0x3) & 1; } // 0x78:3 (Size: 0x1, Type: BoolProperty)

    void SET_Instigator(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EffectCauser(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AbilityCDO(const TWeakObjectPtr<UGameplayAbility*>& Value) { Write<TWeakObjectPtr<UGameplayAbility*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AbilityInstanceNotReplicated(const TWeakObjectPtr<UGameplayAbility*>& Value) { Write<TWeakObjectPtr<UGameplayAbility*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AbilityLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_SourceObject(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    void SET_InstigatorAbilitySystemComponent(const TWeakObjectPtr<UAbilitySystemComponent*>& Value) { Write<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Actors(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_WorldOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_bHasWorldOrigin(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x78); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x78, B); } // 0x78:0 (Size: 0x1, Type: BoolProperty)
    void SET_bReplicateSourceObject(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x78); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x78, B); } // 0x78:1 (Size: 0x1, Type: BoolProperty)
    void SET_bReplicateInstigator(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x78); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x78, B); } // 0x78:2 (Size: 0x1, Type: BoolProperty)
    void SET_bReplicateEffectCauser(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x78); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x78, B); } // 0x78:3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
struct FGameplayTagBlueprintPropertyMapping
{
public:
    FGameplayTag TagToMap() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    FGuid PropertyGuid() const { return Read<FGuid>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)

    void SET_TagToMap(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_PropertyGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FGameplayTagBlueprintPropertyMap
{
public:
    TArray<FGameplayTagBlueprintPropertyMapping> PropertyMappings() const { return Read<TArray<FGameplayTagBlueprintPropertyMapping>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyMappings(const TArray<FGameplayTagBlueprintPropertyMapping>& Value) { Write<TArray<FGameplayTagBlueprintPropertyMapping>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FGameplayTagReponsePair
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UClass* ResponseGameplayEffect() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> ResponseGameplayEffects() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t SoftCountCap() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ResponseGameplayEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_ResponseGameplayEffects(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_SoftCountCap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x50
struct FGameplayTagResponseTableEntry
{
public:
    FGameplayTagReponsePair Positive() const { return Read<FGameplayTagReponsePair>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FGameplayTagReponsePair Negative() const { return Read<FGameplayTagReponsePair>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)

    void SET_Positive(const FGameplayTagReponsePair& Value) { Write<FGameplayTagReponsePair>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_Negative(const FGameplayTagReponsePair& Value) { Write<FGameplayTagReponsePair>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
};

// Size: 0x88
struct FMovieSceneGameplayCueKey
{
public:
    FGameplayCueTag Cue() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FName AttachSocketName() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    float NormalizedMagnitude() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FMovieSceneObjectBindingID Instigator() const { return Read<FMovieSceneObjectBindingID>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FMovieSceneObjectBindingID EffectCauser() const { return Read<FMovieSceneObjectBindingID>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    UPhysicalMaterial* PhysicalMaterial() const { return Read<UPhysicalMaterial*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    int32_t GameplayEffectLevel() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t AbilityLevel() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)
    bool bAttachToBinding() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_Cue(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_AttachSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_NormalizedMagnitude(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Instigator(const FMovieSceneObjectBindingID& Value) { Write<FMovieSceneObjectBindingID>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_EffectCauser(const FMovieSceneObjectBindingID& Value) { Write<FMovieSceneObjectBindingID>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_PhysicalMaterial(const UPhysicalMaterial*& Value) { Write<UPhysicalMaterial*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayEffectLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_AbilityLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
    void SET_bAttachToBinding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf8
struct FMovieSceneGameplayCueChannel : public FMovieSceneChannel
{
public:
    TArray<FFrameNumber> KeyTimes() const { return Read<TArray<FFrameNumber>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FMovieSceneGameplayCueKey> KeyValues() const { return Read<TArray<FMovieSceneGameplayCueKey>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)

    void SET_KeyTimes(const TArray<FFrameNumber>& Value) { Write<TArray<FFrameNumber>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_KeyValues(const TArray<FMovieSceneGameplayCueKey>& Value) { Write<TArray<FMovieSceneGameplayCueKey>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FGameplayAbilityRepAnimMontageNetSerializerConfig : public FNetSerializerConfig
{
public:
};

// Size: 0x28
struct FGameplayEffectContextHandleNetSerializerConfig : public FPolymorphicStructNetSerializerConfig
{
public:
};

// Size: 0x10
struct FGameplayEffectContextNetSerializerConfig : public FNetSerializerConfig
{
public:
};

// Size: 0x10
struct FMinimalGameplayCueReplicationProxyNetSerializerConfig : public FNetSerializerConfig
{
public:
};

// Size: 0x10
struct FMinimalReplicationTagCountMapNetSerializerConfig : public FNetSerializerConfig
{
public:
};

// Size: 0x10
struct FPredictionKeyNetSerializerConfig : public FNetSerializerConfig
{
public:
};

