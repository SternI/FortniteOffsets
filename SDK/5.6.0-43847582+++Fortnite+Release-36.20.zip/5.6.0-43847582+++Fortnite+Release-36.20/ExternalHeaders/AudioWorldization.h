/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioWorldization
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "AudioGameplayVolume.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "AudioExtensions.h"
#include "AudioModulation.h"

// Size: 0x300
class AAudioWorldizationReflectionProbe : public AActor
{
public:
    USubmixSendVolumeComponent* SubmixSends() const { return Read<USubmixSendVolumeComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USubmixOverrideVolumeComponent* SubmixEffects() const { return Read<USubmixOverrideVolumeComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UAudioGameplayVolumeComponent* AGVComponent() const { return Read<UAudioGameplayVolumeComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)

    void SET_SubmixSends(const USubmixSendVolumeComponent*& Value) { Write<USubmixSendVolumeComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_SubmixEffects(const USubmixOverrideVolumeComponent*& Value) { Write<USubmixOverrideVolumeComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_AGVComponent(const UAudioGameplayVolumeComponent*& Value) { Write<UAudioGameplayVolumeComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UAudioWorldizationSendsVolumeComponent : public UAudioGameplayVolumeComponentBase
{
public:
    FName Identifier() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    TArray<FAudioWorldizationSend> Sends() const { return Read<TArray<FAudioWorldizationSend>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)

    void SET_Identifier(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_Sends(const TArray<FAudioWorldizationSend>& Value) { Write<TArray<FAudioWorldizationSend>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb0
class UAudioWorldizationData : public UDataAsset
{
public:
    FAudioWorldizationSettings Settings() const { return Read<FAudioWorldizationSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x80, Type: StructProperty)

    void SET_Settings(const FAudioWorldizationSettings& Value) { Write<FAudioWorldizationSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x80, Type: StructProperty)
};

// Size: 0xf0
class UAudioWorldizationDefaultSettings : public UDeveloperSettings
{
public:
    FAudioWorldizationGlobalSettings GlobalSettings() const { return Read<FAudioWorldizationGlobalSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x30, Type: StructProperty)
    FAudioWorldizationSettings DefaultSettings() const { return Read<FAudioWorldizationSettings>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x80, Type: StructProperty)
    TArray<FSoftObjectPath> ModulationParameters() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)

    void SET_GlobalSettings(const FAudioWorldizationGlobalSettings& Value) { Write<FAudioWorldizationGlobalSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x30, Type: StructProperty)
    void SET_DefaultSettings(const FAudioWorldizationSettings& Value) { Write<FAudioWorldizationSettings>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x80, Type: StructProperty)
    void SET_ModulationParameters(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x470
class UAudioWorldizationSubsystem : public UTickableWorldSubsystem
{
public:
    USoundControlBus* EnclosureBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* WallDistanceBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ListenerAzimuthBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    FAudioWorldizationSettings CurrentSettings() const { return Read<FAudioWorldizationSettings>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x80, Type: StructProperty)
    AAudioWorldizationReflectionProbe* VolumeActor() const { return Read<AAudioWorldizationReflectionProbe*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UAudioWorldizationTracePolicyBase* TracePolicy() const { return Read<UAudioWorldizationTracePolicyBase*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAudioWorldizationTraceDirectionPolicyBase* TraceDirectionPolicy() const { return Read<UAudioWorldizationTraceDirectionPolicyBase*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    TArray<FAudioWorldizationSettings> SettingsStack() const { return Read<TArray<FAudioWorldizationSettings>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundControlBus*> QuadrantEnclosureBuses() const { return Read<TArray<USoundControlBus*>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundControlBus*> QuadrantWallDistanceBuses() const { return Read<TArray<USoundControlBus*>>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x10, Type: ArrayProperty)
    FTransform CachedTraceOrigin() const { return Read<FTransform>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x60, Type: StructProperty)

    void SET_EnclosureBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_WallDistanceBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_ListenerAzimuthBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentSettings(const FAudioWorldizationSettings& Value) { Write<FAudioWorldizationSettings>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x80, Type: StructProperty)
    void SET_VolumeActor(const AAudioWorldizationReflectionProbe*& Value) { Write<AAudioWorldizationReflectionProbe*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_TracePolicy(const UAudioWorldizationTracePolicyBase*& Value) { Write<UAudioWorldizationTracePolicyBase*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_TraceDirectionPolicy(const UAudioWorldizationTraceDirectionPolicyBase*& Value) { Write<UAudioWorldizationTraceDirectionPolicyBase*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_SettingsStack(const TArray<FAudioWorldizationSettings>& Value) { Write<TArray<FAudioWorldizationSettings>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    void SET_QuadrantEnclosureBuses(const TArray<USoundControlBus*>& Value) { Write<TArray<USoundControlBus*>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    void SET_QuadrantWallDistanceBuses(const TArray<USoundControlBus*>& Value) { Write<TArray<USoundControlBus*>>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedTraceOrigin(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x60, Type: StructProperty)
};

// Size: 0x30
class UAudioWorldizationTraceDirectionPolicyBase : public UObject
{
public:
};

// Size: 0x30
class UAudioWorldizationTraceDirectionPolicyDefault : public UAudioWorldizationTraceDirectionPolicyBase
{
public:
};

// Size: 0x28
class UAudioWorldizationTracePolicyBase : public UObject
{
public:
};

// Size: 0x28
class UAudioWorldizationTracePolicyDefault : public UAudioWorldizationTracePolicyBase
{
public:
};

// Size: 0xd0
class UAudioWorldizationVolumeComponent : public UAudioGameplayVolumeComponentBase
{
public:
    UAudioWorldizationData* Settings() const { return Read<UAudioWorldizationData*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const UAudioWorldizationData*& Value) { Write<UAudioWorldizationData*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x90
class UGameFeatureAction_SetAudioWorldizationEffectSends : public UGameFeatureAction
{
public:
    FName Identifier() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    TArray<FAudioWorldizationSend> Sends() const { return Read<TArray<FAudioWorldizationSend>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Identifier(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_Sends(const TArray<FAudioWorldizationSend>& Value) { Write<TArray<FAudioWorldizationSend>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf8
class UGameFeatureAction_SetAudioWorldizationSettings : public UGameFeatureAction
{
public:
    FAudioWorldizationSettings Settings() const { return Read<FAudioWorldizationSettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x80, Type: StructProperty)

    void SET_Settings(const FAudioWorldizationSettings& Value) { Write<FAudioWorldizationSettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x80, Type: StructProperty)
};

// Size: 0x80
struct FAudioWorldizationSend
{
public:
    TSoftObjectPtr<USoundSubmix> Submix() const { return Read<TSoftObjectPtr<USoundSubmix>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSet<TSoftObjectPtr<USoundModulatorBase*>> VolumeModulators() const { return Read<TSet<TSoftObjectPtr<USoundModulatorBase*>>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: SetProperty)
    TArray<TSoftObjectPtr<USoundEffectSubmixPreset*>> EffectChain() const { return Read<TArray<TSoftObjectPtr<USoundEffectSubmixPreset*>>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_Submix(const TSoftObjectPtr<USoundSubmix>& Value) { Write<TSoftObjectPtr<USoundSubmix>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_VolumeModulators(const TSet<TSoftObjectPtr<USoundModulatorBase*>>& Value) { Write<TSet<TSoftObjectPtr<USoundModulatorBase*>>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: SetProperty)
    void SET_EffectChain(const TArray<TSoftObjectPtr<USoundEffectSubmixPreset*>>& Value) { Write<TArray<TSoftObjectPtr<USoundEffectSubmixPreset*>>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
struct FAudioWorldizationSettings
{
public:
    FName Identifier() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FAudioWorldizationSend> Sends() const { return Read<TArray<FAudioWorldizationSend>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    float EnclosureSmoothSpeed() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float WallDistanceSmoothSpeed() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float TraceRadius() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float CrossfadeTime() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    int32_t TracePoints() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t TracesPerFrame() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    float SideQuadrantDegrees() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float UpQuadrantDegrees() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FVector TraceOrigin() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> TraceChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: ByteProperty)
    TArray<TEnumAsByte<ECollisionChannel>> ResponseChannels() const { return Read<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    UClass* TracePolicy() const { return Read<UClass*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ClassProperty)
    UClass* TraceDirectionPolicy() const { return Read<UClass*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ClassProperty)
    bool bCollectActorAssetTags() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_Identifier(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Sends(const TArray<FAudioWorldizationSend>& Value) { Write<TArray<FAudioWorldizationSend>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_EnclosureSmoothSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_WallDistanceSmoothSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_TraceRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CrossfadeTime(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_TracePoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_TracesPerFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_SideQuadrantDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_UpQuadrantDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_TraceOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_TraceChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: ByteProperty)
    void SET_ResponseChannels(const TArray<TEnumAsByte<ECollisionChannel>>& Value) { Write<TArray<TEnumAsByte<ECollisionChannel>>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_TracePolicy(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ClassProperty)
    void SET_TraceDirectionPolicy(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ClassProperty)
    void SET_bCollectActorAssetTags(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FAudioWorldizationQuadrantSettings
{
public:
    USoundControlBus* WallDistanceBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* EnclosureBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_WallDistanceBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_EnclosureBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FAudioWorldizationGlobalSettings
{
public:
    float EffectCrossfadeTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FName IgnoreTraceActorTag() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    USoundControlBus* EnclosureBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* WallDistanceBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ListenerAzimuthBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    TArray<FAudioWorldizationQuadrantSettings> Quadrants() const { return Read<TArray<FAudioWorldizationQuadrantSettings>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_EffectCrossfadeTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_IgnoreTraceActorTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_EnclosureBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_WallDistanceBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ListenerAzimuthBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_Quadrants(const TArray<FAudioWorldizationQuadrantSettings>& Value) { Write<TArray<FAudioWorldizationQuadrantSettings>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FAudioSphereTraceResult
{
public:
    bool bBlocking() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bBlocking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

