/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContextualTraversalRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0xf8
class UFortContextualTraversalComponent : public UFortPawnComponent
{
public:
    UCurveFloat* ScoringDistanceCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ScoringAngleCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    float LockedInteractionTime() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)

    void SET_ScoringDistanceCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_ScoringAngleCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_LockedInteractionTime(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x100
class UFortMovementMode_TraversalBaseRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
    UAnimMontage* AnimMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName MontageStartSectionName() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    FName MontageMiddleSectionName() const { return Read<FName>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: NameProperty)
    FSynchedActionWarpPointInfo_Replicated SynchedActionWarpPointInfo() const { return Read<FSynchedActionWarpPointInfo_Replicated>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0xa0, Type: StructProperty)

    void SET_AnimMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_MontageStartSectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET_MontageMiddleSectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: NameProperty)
    void SET_SynchedActionWarpPointInfo(const FSynchedActionWarpPointInfo_Replicated& Value) { Write<FSynchedActionWarpPointInfo_Replicated>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x240
class UFortMovementMode_ExtLogicTraversalBase : public UFortMovementMode_BaseExtLogic
{
public:
    FGameplayTag SynchedActionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: StructProperty)
    FGameplayTag PreventWeaponHolsterTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x22c); } // 0x22c (Size: 0x4, Type: StructProperty)
    FName MontageStartSectionName() const { return Read<FName>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x4, Type: NameProperty)
    bool bUseNextSectionAnimName() const { return Read<bool>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x1, Type: BoolProperty)
    float OverrideServerAllowablePositionError() const { return Read<float>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x4, Type: FloatProperty)
    float OverrideAnimBlendOutTimeWhenLanding() const { return Read<float>(uintptr_t(this) + 0x23c); } // 0x23c (Size: 0x4, Type: FloatProperty)

    void SET_SynchedActionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: StructProperty)
    void SET_PreventWeaponHolsterTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x22c, Value); } // 0x22c (Size: 0x4, Type: StructProperty)
    void SET_MontageStartSectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x4, Type: NameProperty)
    void SET_bUseNextSectionAnimName(const bool& Value) { Write<bool>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideServerAllowablePositionError(const float& Value) { Write<float>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x4, Type: FloatProperty)
    void SET_OverrideAnimBlendOutTimeWhenLanding(const float& Value) { Write<float>(uintptr_t(this) + 0x23c, Value); } // 0x23c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
struct FContextualTraversalTargetingData
{
public:
    float ScoringModifier() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: StructProperty)

    void SET_ScoringModifier(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: StructProperty)
};

// Size: 0x130
struct FFortMovementMode_TraversalBaseCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
    FSynchedActionInfo SynchedActionInfo() const { return Read<FSynchedActionInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x30, Type: StructProperty)
    FSynchedActionWarpPointInfo_Replicated SynchedActionWarpPointInfo() const { return Read<FSynchedActionWarpPointInfo_Replicated>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xa0, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)
    FRotator TargetRotation() const { return Read<FRotator>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<AActor*> RefActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPrimitiveComponent*> RefActorComponent() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    FName RefActorBoneName() const { return Read<FName>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: NameProperty)
    uint8_t EndMovementMode() const { return Read<uint8_t>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: EnumProperty)
    bool bIsWindow() const { return Read<bool>(uintptr_t(this) + 0x125); } // 0x125 (Size: 0x1, Type: BoolProperty)

    void SET_SynchedActionInfo(const FSynchedActionInfo& Value) { Write<FSynchedActionInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x30, Type: StructProperty)
    void SET_SynchedActionWarpPointInfo(const FSynchedActionWarpPointInfo_Replicated& Value) { Write<FSynchedActionWarpPointInfo_Replicated>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xa0, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
    void SET_TargetRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x18, Type: StructProperty)
    void SET_RefActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RefActorComponent(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RefActorBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: NameProperty)
    void SET_EndMovementMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: EnumProperty)
    void SET_bIsWindow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x125, Value); } // 0x125 (Size: 0x1, Type: BoolProperty)
};

