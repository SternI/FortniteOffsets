/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterDynamicsControlRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CharacterDynamicsControlCore.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "PhysicsControl.h"

// Size: 0x28
class UCharacterDynamicsControlBPLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x500
class UCharacterDynamicsControlGameFeatureData : public UFortGameFeatureData
{
public:
    UFortCharacterDynamicsStateLogic* DefaultStateLogic() const { return Read<UFortCharacterDynamicsStateLogic*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UFortCharacterDynamicsParameters* DefaultParameters() const { return Read<UFortCharacterDynamicsParameters*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultStateLogic(const UFortCharacterDynamicsStateLogic*& Value) { Write<UFortCharacterDynamicsStateLogic*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultParameters(const UFortCharacterDynamicsParameters*& Value) { Write<UFortCharacterDynamicsParameters*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x170
class UFortCharacterDynamicsComponent : public UFortCharacterDynamicsComponentInterface
{
public:
    UFortCharacterDynamicsStateLogic* DefaultStateLogic() const { return Read<UFortCharacterDynamicsStateLogic*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFortCharacterDynamicsParameters* DefaultParameters() const { return Read<UFortCharacterDynamicsParameters*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultStateLogic(const UFortCharacterDynamicsStateLogic*& Value) { Write<UFortCharacterDynamicsStateLogic*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultParameters(const UFortCharacterDynamicsParameters*& Value) { Write<UFortCharacterDynamicsParameters*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

