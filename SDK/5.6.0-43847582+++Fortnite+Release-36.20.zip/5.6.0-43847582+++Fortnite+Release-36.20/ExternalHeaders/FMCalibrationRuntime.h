/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMCalibrationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0xd0
class UBeatmatchCalibrationHelper : public UActorComponent
{
public:
    float TightCalWindowMs() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    int32_t MinTightCalSamples() const { return Read<int32_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: IntProperty)
    float LooseCalWindowMs() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    int32_t MinLooseCalSamples() const { return Read<int32_t>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: IntProperty)
    int32_t MaxSamplesBeforeFail() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)

    void SET_TightCalWindowMs(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_MinTightCalSamples(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: IntProperty)
    void SET_LooseCalWindowMs(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_MinLooseCalSamples(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: IntProperty)
    void SET_MaxSamplesBeforeFail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x148
class UFMCalibrationControllerComponent : public UControllerComponent
{
public:
    UFMCalibrationSaveData* CalibrationSaveData() const { return Read<UFMCalibrationSaveData*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)

    void SET_CalibrationSaveData(const UFMCalibrationSaveData*& Value) { Write<UFMCalibrationSaveData*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x58
class UFMCalibrationSaveData : public UObject
{
public:
    int32_t CalibrationProfileIndex() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    float AudioLatencyMs() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float VideoLatencyMs() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    bool IsCalibrated() const { return Read<bool>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: BoolProperty)
    int32_t SaveVersion() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    int32_t FormatVersion() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    bool bHasBeenOfferedCalibration() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    TArray<FFMCalibrationProfileData> CalibrationProfiles() const { return Read<TArray<FFMCalibrationProfileData>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_CalibrationProfileIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_AudioLatencyMs(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_VideoLatencyMs(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_IsCalibrated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: BoolProperty)
    void SET_SaveVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_FormatVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_bHasBeenOfferedCalibration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_CalibrationProfiles(const TArray<FFMCalibrationProfileData>& Value) { Write<TArray<FFMCalibrationProfileData>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FFMEvent_Calibration_ToggleModal
{
public:
};

// Size: 0x1
struct FFMEvent_Calibration_ModalOpened
{
public:
};

// Size: 0x1
struct FFMEvent_Calibration_ModalClosed
{
public:
};

// Size: 0x1
struct FFMEvent_Calibration_ModalCloseToQuest
{
public:
};

// Size: 0x1
struct FFMEvent_Calibration_ModalSkipped
{
public:
};

// Size: 0x1
struct FFMEvent_Calibration_ForceClose
{
public:
    bool IsClosed() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_IsClosed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FFMCalibrationProfileData
{
public:
    float InputLatencyMs() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t InputLatencySource() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    float AudioVideoOffsetMs() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t AudioVideoOffsetSource() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)

    void SET_InputLatencyMs(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_InputLatencySource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_AudioVideoOffsetMs(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AudioVideoOffsetSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
};

