/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterCollectionMapScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"
#include "GameplayTags.h"
#include "FortniteUI.h"

// Size: 0x748
class UAthenaCollectionScreenMapCharacter : public UAthenaCollectionScreenMapBase
{
public:
    UCollectionScreenServiceVisualData* SharedServiceVisualData() const { return Read<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer ExcludedProducts() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x20, Type: StructProperty)

    void SET_SharedServiceVisualData(const UCollectionScreenServiceVisualData*& Value) { Write<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x8, Type: ObjectProperty)
    void SET_ExcludedProducts(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x20, Type: StructProperty)
};

// Size: 0x520
class UCollectionNPCServiceInfoOverlay : public UAthenaCollectionScreenInfoOverlay
{
public:
    UCollectionNPCServiceContainer* Services() const { return Read<UCollectionNPCServiceContainer*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_ServiceIcon() const { return Read<UImage*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    UCollectionScreenServiceVisualData* SharedServiceVisualData() const { return Read<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)

    void SET_Services(const UCollectionNPCServiceContainer*& Value) { Write<UCollectionNPCServiceContainer*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_ServiceIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_SharedServiceVisualData(const UCollectionScreenServiceVisualData*& Value) { Write<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
};

