/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_FabricMIDIPlayerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FabricLevelSequencer.h"

// Size: 0x618
class UFabricCreativePropertyEditWidgetMidiSourceBase : public UCreativePropertyEditWidgetUserOptionBase
{
public:
    FMidiSource MidiSourceOptionValue() const { return Read<FMidiSource>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x18, Type: StructProperty)

    void SET_MidiSourceOptionValue(const FMidiSource& Value) { Write<FMidiSource>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x18, Type: StructProperty)
};

