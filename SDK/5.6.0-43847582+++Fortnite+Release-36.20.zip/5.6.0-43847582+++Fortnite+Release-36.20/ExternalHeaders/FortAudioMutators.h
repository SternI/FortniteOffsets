/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortAudioMutators
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
#include "Engine.h"

// Size: 0x80
class USoundClassGraphMapping : public UDataAsset
{
public:
    TMap<USoundClass*, USoundClass*> SoundClassMap() const { return Read<TMap<USoundClass*, USoundClass*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_SoundClassMap(const TMap<USoundClass*, USoundClass*>& Value) { Write<TMap<USoundClass*, USoundClass*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FSoundActionSwapSoundClassGraph : public FAudioMutatorAction
{
public:
    USoundClassGraphMapping* SoundClassMapping() const { return Read<USoundClassGraphMapping*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_SoundClassMapping(const USoundClassGraphMapping*& Value) { Write<USoundClassGraphMapping*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FSoundSelectorAffiliation : public FAudioMutatorSelector
{
public:
    uint8_t Affiliation() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_Affiliation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

