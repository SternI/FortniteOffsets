/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_FabricJamTrackPlayerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FabricRuntime.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "PlayspaceSystem.h"
#include "FabricFramework.h"
#include "FMDeviceCablesRuntime.h"
#include "HarmonixMetasound.h"
#include "SparksMidiParser.h"
#include "MetasoundEngine.h"
#include "SparksSongPlayerRuntime.h"

// Size: 0x1c0
class UFabricJamTrackPlayerAnalyticsComponent : public UPlayspaceComponent
{
public:
    UClass* SongPlayCoordinatorClass() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    UClass* PlayspaceComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)

    void SET_SongPlayCoordinatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_PlayspaceComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x1d8
class UFabricJamTrackPlayerCustomSetlist : public USparksCustomSetlist
{
public:
    UClass* JTPPlayspaceComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ClassProperty)
    uint8_t SongsPerPlayer() const { return Read<uint8_t>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x1, Type: EnumProperty)
    int32_t SetlistLength() const { return Read<int32_t>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: IntProperty)

    void SET_JTPPlayspaceComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ClassProperty)
    void SET_SongsPerPlayer(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x1, Type: EnumProperty)
    void SET_SetlistLength(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: IntProperty)
};

// Size: 0x1d8
class UFabricJamTrackPlayerDeviceComponent : public UActorComponent
{
public:
    FGameplayTag PlayspaceTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: StructProperty)
    UClass* PlayspaceComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    UClass* PlayCoordinatorClass() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    UClass* SetlistClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    FName SelectionControlPropertyName() const { return Read<FName>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: NameProperty)
    FName SetlistLengthPropertyName() const { return Read<FName>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: NameProperty)
    FName SelectionLimitPropertyName() const { return Read<FName>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: NameProperty)
    FName PlaybackBehaviorPropertyName() const { return Read<FName>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: NameProperty)
    FName CountInAudioPropertyName() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    FName VocalsGainInputName() const { return Read<FName>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: NameProperty)
    FName MuteInputName() const { return Read<FName>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: NameProperty)
    FText FirstJTPDialogHeader() const { return Read<FText>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: TextProperty)
    FText FirstJTPDialogMessage() const { return Read<FText>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: TextProperty)
    TWeakObjectPtr<UPlayspaceComponent_FabricJamTrackPlayer*> PlayspaceComponent() const { return Read<TWeakObjectPtr<UPlayspaceComponent_FabricJamTrackPlayer*>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricJamTrackPlayerSongPlayCoordinator*> PlayCoordinator() const { return Read<TWeakObjectPtr<UFabricJamTrackPlayerSongPlayCoordinator*>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricJamTrackPlayerCustomSetlist*> Setlist() const { return Read<TWeakObjectPtr<UFabricJamTrackPlayerCustomSetlist*>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: WeakObjectProperty)
    TArray<UFMDeviceCablePortComponent*> OutputPorts() const { return Read<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    bool bHasShownInitialDialog() const { return Read<bool>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: BoolProperty)

    void SET_PlayspaceTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: StructProperty)
    void SET_PlayspaceComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_PlayCoordinatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    void SET_SetlistClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_SelectionControlPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: NameProperty)
    void SET_SetlistLengthPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: NameProperty)
    void SET_SelectionLimitPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: NameProperty)
    void SET_PlaybackBehaviorPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: NameProperty)
    void SET_CountInAudioPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET_VocalsGainInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: NameProperty)
    void SET_MuteInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: NameProperty)
    void SET_FirstJTPDialogHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: TextProperty)
    void SET_FirstJTPDialogMessage(const FText& Value) { Write<FText>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: TextProperty)
    void SET_PlayspaceComponent(const TWeakObjectPtr<UPlayspaceComponent_FabricJamTrackPlayer*>& Value) { Write<TWeakObjectPtr<UPlayspaceComponent_FabricJamTrackPlayer*>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayCoordinator(const TWeakObjectPtr<UFabricJamTrackPlayerSongPlayCoordinator*>& Value) { Write<TWeakObjectPtr<UFabricJamTrackPlayerSongPlayCoordinator*>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Setlist(const TWeakObjectPtr<UFabricJamTrackPlayerCustomSetlist*>& Value) { Write<TWeakObjectPtr<UFabricJamTrackPlayerCustomSetlist*>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OutputPorts(const TArray<UFMDeviceCablePortComponent*>& Value) { Write<TArray<UFMDeviceCablePortComponent*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasShownInitialDialog(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb8
class UFabricJamTrackPlayerInteractionComponent : public UActorComponent
{
public:
};

// Size: 0x48
class UFabricJamTrackPlayerMidiEventDriver : public UObject
{
public:
    UParsedMidiEventData* ParsedMidiEventData() const { return Read<UParsedMidiEventData*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ParsedMidiEventData(const UParsedMidiEventData*& Value) { Write<UParsedMidiEventData*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x280
class UFabricJamTrackPlayerSongPlayCoordinator : public USparksSongPlayerPlayCoordinator
{
public:
    FFabricJamTrackPlayerSong SongToPlay() const { return Read<FFabricJamTrackPlayerSong>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0xc, Type: StructProperty)
    UClass* UtilityProviderPatchClass() const { return Read<UClass*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ClassProperty)
    UFabricJamTrackPlayerUtilityProviderPatchWrapper* UtilityProviderPatchInstance() const { return Read<UFabricJamTrackPlayerUtilityProviderPatchWrapper*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    float DelayBeforeForcePreloadInSeconds() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    TSet<FUniqueNetIdRepl> PlayersLoadingSong() const { return Read<TSet<FUniqueNetIdRepl>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x50, Type: SetProperty)
    bool bShouldSkipCountIn() const { return Read<bool>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x1, Type: BoolProperty)

    void SET_SongToPlay(const FFabricJamTrackPlayerSong& Value) { Write<FFabricJamTrackPlayerSong>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0xc, Type: StructProperty)
    void SET_UtilityProviderPatchClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ClassProperty)
    void SET_UtilityProviderPatchInstance(const UFabricJamTrackPlayerUtilityProviderPatchWrapper*& Value) { Write<UFabricJamTrackPlayerUtilityProviderPatchWrapper*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_DelayBeforeForcePreloadInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_PlayersLoadingSong(const TSet<FUniqueNetIdRepl>& Value) { Write<TSet<FUniqueNetIdRepl>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x50, Type: SetProperty)
    void SET_bShouldSkipCountIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
class UFabricJamTrackPlayerSongPreloadController : public USparksSongPlayerPreloadControllerComponent
{
public:
};

// Size: 0xc0
class UFabricJamTrackPlayerTimelineSyncComponent : public UActorComponent
{
public:
};

// Size: 0x218
class UFabricJamTrackPlayerUtilityProviderPatchWrapper : public UFabricMetaSoundUtilityProviderPatchWrapper
{
public:
    FName StemsAssetInputName() const { return Read<FName>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: NameProperty)
    FName OnMidiFinishedTriggerOutputName() const { return Read<FName>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: NameProperty)

    void SET_StemsAssetInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: NameProperty)
    void SET_OnMidiFinishedTriggerOutputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
class UInterface_FabricJamTrackPlayerAnalyticsProvider : public UInterface
{
public:
};

// Size: 0x288
class UPlayspaceComponent_FabricJamTrackPlayer : public UPlayspaceComponent
{
public:
    UClass* AnalyticsClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    UClass* SongPlayCoordinatorClass() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    UClass* CustomSetlistClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    float RestartOrPreviousTimeSecs() const { return Read<float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    int32_t RegistrationLimit() const { return Read<int32_t>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: IntProperty)
    bool bOwnedSongsAvailable() const { return Read<bool>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
    bool bPublishedIsland() const { return Read<bool>(uintptr_t(this) + 0x1c1); } // 0x1c1 (Size: 0x1, Type: BoolProperty)
    bool bIsPlaying() const { return Read<bool>(uintptr_t(this) + 0x1c2); } // 0x1c2 (Size: 0x1, Type: BoolProperty)
    bool bAdvanceOnNextPlay() const { return Read<bool>(uintptr_t(this) + 0x1c3); } // 0x1c3 (Size: 0x1, Type: BoolProperty)
    bool bMuteLicensedAudio() const { return Read<bool>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x1, Type: BoolProperty)
    uint8_t SelectionType() const { return Read<uint8_t>(uintptr_t(this) + 0x1c5); } // 0x1c5 (Size: 0x1, Type: EnumProperty)
    uint8_t PlaybackBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x1c6); } // 0x1c6 (Size: 0x1, Type: EnumProperty)
    UFabricJamTrackPlayerAnalyticsComponent* AnalyticsComponent() const { return Read<UFabricJamTrackPlayerAnalyticsComponent*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    UFabricJamTrackPlayerSongPlayCoordinator* SongPlayCoordinator() const { return Read<UFabricJamTrackPlayerSongPlayCoordinator*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFabricJamTrackPlayerCustomSetlist* CustomSetlist() const { return Read<UFabricJamTrackPlayerCustomSetlist*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentSetlistTrackIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AActor*> PlayspaceGameplayVolume() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortClientSettingsRecord*> Settings() const { return Read<TWeakObjectPtr<UFortClientSettingsRecord*>>(uintptr_t(this) + 0x1ec); } // 0x1ec (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> CachedMusicClock() const { return Read<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> CachedMetaSoundManager() const { return Read<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AController*> LastPlayInstigator() const { return Read<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x27c); } // 0x27c (Size: 0x8, Type: WeakObjectProperty)

    void SET_AnalyticsClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_SongPlayCoordinatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    void SET_CustomSetlistClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_RestartOrPreviousTimeSecs(const float& Value) { Write<float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    void SET_RegistrationLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: IntProperty)
    void SET_bOwnedSongsAvailable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
    void SET_bPublishedIsland(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c1, Value); } // 0x1c1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPlaying(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c2, Value); } // 0x1c2 (Size: 0x1, Type: BoolProperty)
    void SET_bAdvanceOnNextPlay(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c3, Value); } // 0x1c3 (Size: 0x1, Type: BoolProperty)
    void SET_bMuteLicensedAudio(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x1, Type: BoolProperty)
    void SET_SelectionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c5, Value); } // 0x1c5 (Size: 0x1, Type: EnumProperty)
    void SET_PlaybackBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c6, Value); } // 0x1c6 (Size: 0x1, Type: EnumProperty)
    void SET_AnalyticsComponent(const UFabricJamTrackPlayerAnalyticsComponent*& Value) { Write<UFabricJamTrackPlayerAnalyticsComponent*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SongPlayCoordinator(const UFabricJamTrackPlayerSongPlayCoordinator*& Value) { Write<UFabricJamTrackPlayerSongPlayCoordinator*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomSetlist(const UFabricJamTrackPlayerCustomSetlist*& Value) { Write<UFabricJamTrackPlayerCustomSetlist*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentSetlistTrackIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: IntProperty)
    void SET_PlayspaceGameplayVolume(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Settings(const TWeakObjectPtr<UFortClientSettingsRecord*>& Value) { Write<TWeakObjectPtr<UFortClientSettingsRecord*>>(uintptr_t(this) + 0x1ec, Value); } // 0x1ec (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedMusicClock(const TWeakObjectPtr<UMusicClockComponent*>& Value) { Write<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedMetaSoundManager(const TWeakObjectPtr<UFabricMetaSoundManagerComponent*>& Value) { Write<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x8, Type: WeakObjectProperty)
    void SET_LastPlayInstigator(const TWeakObjectPtr<AController*>& Value) { Write<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x27c, Value); } // 0x27c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xc
struct FFabricJamTrackPlayerSong
{
public:
    FName ShortName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float ServerWorldTimeSentInSeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bIsRestart() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_ShortName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ServerWorldTimeSentInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bIsRestart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FSetlistEditorsChanged
{
public:
    bool bHasEditors() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bHasEditors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FFabricJamTrackPlayerCoordinatorStateChanged
{
public:
    uint8_t State() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<USparksMediaStreamer*> MediaStreamer() const { return Read<TWeakObjectPtr<USparksMediaStreamer*>>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_State(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_MediaStreamer(const TWeakObjectPtr<USparksMediaStreamer*>& Value) { Write<TWeakObjectPtr<USparksMediaStreamer*>>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
};

