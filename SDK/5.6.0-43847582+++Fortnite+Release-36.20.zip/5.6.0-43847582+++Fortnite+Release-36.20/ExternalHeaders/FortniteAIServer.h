/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteAIServer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "FortniteAI.h"
#include "GameplayAbilities.h"
#include "AIModule.h"
#include "Engine.h"
#include "DataRegistry.h"
#include "CoreUObject.h"
#include "SmartObjectsModule.h"
#include "WorldConditions.h"
#include "NavigationSystem.h"
#include "GameplayBehaviorsModule.h"
#include "PhysicsCore.h"
#include "ContextualAnimation.h"
#include "StateTreeModule.h"

// Size: 0x2c0
class UFortAthenaAIBotEvaluator_ApproachNearbyPawns : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat MaxApproaches() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration() const { return Read<FFortNearbyActorsPerceptionConfiguration>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0xc0, Type: StructProperty)
    FName EnableKeyName() const { return Read<FName>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: NameProperty)

    void SET_MaxApproaches(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    void SET_PerceptionConfiguration(const FFortNearbyActorsPerceptionConfiguration& Value) { Write<FFortNearbyActorsPerceptionConfiguration>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0xc0, Type: StructProperty)
    void SET_EnableKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x228
class UFortAthenaAIBotEvaluator_Disengagement : public UFortAthenaAIBotEvaluator
{
public:
    FName TargetActorKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName DisengagementReasonKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FScalableFloat TargetInterestEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestInitialDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestOnDamageDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestStartingMinDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestOngoingMinDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestCanBeTriggeredInsideLeash() const { return Read<FScalableFloat>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x28, Type: StructProperty)
    float TargetInterestStartingMinDistanceSqr() const { return Read<float>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float TargetInterestOngoingMinDistanceSqr() const { return Read<float>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: FloatProperty)
    FScalableFloat TargetReachabilityEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x28, Type: StructProperty)
    FName TargetIsReachableKeyName() const { return Read<FName>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: NameProperty)
    FScalableFloat TargetReachabilityMaxDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    float TargetReachabilityMaxDistanceSqr() const { return Read<float>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: FloatProperty)
    UFortAthenaLeashComponent* CachedLeashComponent() const { return Read<UFortAthenaLeashComponent*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_DisengagementReasonKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_TargetInterestEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x28, Type: StructProperty)
    void SET_TargetInterestInitialDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x28, Type: StructProperty)
    void SET_TargetInterestOnDamageDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x28, Type: StructProperty)
    void SET_TargetInterestStartingMinDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x28, Type: StructProperty)
    void SET_TargetInterestOngoingMinDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x28, Type: StructProperty)
    void SET_TargetInterestCanBeTriggeredInsideLeash(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x28, Type: StructProperty)
    void SET_TargetInterestStartingMinDistanceSqr(const float& Value) { Write<float>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    void SET_TargetInterestOngoingMinDistanceSqr(const float& Value) { Write<float>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: FloatProperty)
    void SET_TargetReachabilityEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x28, Type: StructProperty)
    void SET_TargetIsReachableKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: NameProperty)
    void SET_TargetReachabilityMaxDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    void SET_TargetReachabilityMaxDistanceSqr(const float& Value) { Write<float>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: FloatProperty)
    void SET_CachedLeashComponent(const UFortAthenaLeashComponent*& Value) { Write<UFortAthenaLeashComponent*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x340
class UFortAthenaAIBotEvaluator_Harvest : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UClass* ProjectionNavigationQueryFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: ClassProperty)
    UClass* ValidNavigationQueryFilterClassOverride() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FScalableFloat MaximumTimeToHelpFromLastPlayerDamage() const { return Read<FScalableFloat>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x28, Type: StructProperty)
    FScalableFloat KeepTargetTimeOnWeaponTrigger() const { return Read<FScalableFloat>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x28, Type: StructProperty)
    FScalableFloat AmountOfTimesPlayerBuiltStructuresNeedToBeDamaged() const { return Read<FScalableFloat>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeToTrackDamagedActors() const { return Read<FScalableFloat>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDistanceFromActorForFallbackNoHarvestBehaviour() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ExtraExtentForPlayerHitChecks() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x28, Type: StructProperty)
    TArray<UClass*> GEsToApplyOnFallbackBehaviorTrigger() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> GEsToApplyOnCannotDamageBehaviorTrigger() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    FName HarvestTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x4, Type: NameProperty)
    FName HarvestTargetHitPointKeyName() const { return Read<FName>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x4, Type: NameProperty)
    FName HarvestDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x4, Type: NameProperty)
    FName FallbackBehaviorKeyName() const { return Read<FName>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: NameProperty)
    FName CannotDamageKeyName() const { return Read<FName>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeKeyName() const { return Read<FName>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: NameProperty)

    void SET_ProjectionNavigationQueryFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: ClassProperty)
    void SET_ValidNavigationQueryFilterClassOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_MaximumTimeToHelpFromLastPlayerDamage(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x28, Type: StructProperty)
    void SET_KeepTargetTimeOnWeaponTrigger(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x28, Type: StructProperty)
    void SET_AmountOfTimesPlayerBuiltStructuresNeedToBeDamaged(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x28, Type: StructProperty)
    void SET_TimeToTrackDamagedActors(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_MaxDistanceFromActorForFallbackNoHarvestBehaviour(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x28, Type: StructProperty)
    void SET_ExtraExtentForPlayerHitChecks(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x28, Type: StructProperty)
    void SET_GEsToApplyOnFallbackBehaviorTrigger(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    void SET_GEsToApplyOnCannotDamageBehaviorTrigger(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    void SET_HarvestTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x4, Type: NameProperty)
    void SET_HarvestTargetHitPointKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x4, Type: NameProperty)
    void SET_HarvestDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x4, Type: NameProperty)
    void SET_FallbackBehaviorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: NameProperty)
    void SET_CannotDamageKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: NameProperty)
};

// Size: 0x2a8
class UFortAthenaAIBotEvaluator_MoveAway : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat MaxSecondsToReactToBump() const { return Read<FScalableFloat>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSecondsToReactToBox() const { return Read<FScalableFloat>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSecondsBetweenInstantReactions() const { return Read<FScalableFloat>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x28, Type: StructProperty)
    UEnvQuery* FindAwayLocationFromPawnQueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> FindAwayLocationFromPawnRunMode() const { return Read<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x1, Type: ByteProperty)
    UEnvQuery* FindAwayLocationFromBoxQueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> FindAwayLocationFromBoxRunMode() const { return Read<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x1, Type: ByteProperty)

    void SET_MaxSecondsToReactToBump(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x28, Type: StructProperty)
    void SET_MaxSecondsToReactToBox(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x28, Type: StructProperty)
    void SET_MinSecondsBetweenInstantReactions(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x28, Type: StructProperty)
    void SET_FindAwayLocationFromPawnQueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    void SET_FindAwayLocationFromPawnRunMode(const TEnumAsByte<EEnvQueryRunMode>& Value) { Write<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x1, Type: ByteProperty)
    void SET_FindAwayLocationFromBoxQueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    void SET_FindAwayLocationFromBoxRunMode(const TEnumAsByte<EEnvQueryRunMode>& Value) { Write<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x240
class UFortAthenaAIBotEvaluator_SmartObjectCommand : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem() const { return Read<USmartObjectSubsystem*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    FFortAIActiveCommandSOUsageData RunningCommandData() const { return Read<FFortAIActiveCommandSOUsageData>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: StructProperty)
    FBotEvaluatorCommandCooldown CommandOnCooldown() const { return Read<FBotEvaluatorCommandCooldown>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x14, Type: StructProperty)
    FGameplayTag EvaluationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen() const { return Read<bool>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport() const { return Read<bool>(uintptr_t(this) + 0x1e1); } // 0x1e1 (Size: 0x1, Type: BoolProperty)
    FScalableFloat SingleCommandCooldown() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    UClass* OverridenFilterClassForEntryPoints() const { return Read<UClass*>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x8, Type: ClassProperty)
    FName SmartObjectExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x21c); } // 0x21c (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName() const { return Read<FName>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName() const { return Read<FName>(uintptr_t(this) + 0x22c); } // 0x22c (Size: 0x4, Type: NameProperty)

    void SET_SmartObjectRuntimeParameters(const UFortAthenaAIRuntimeParameters_SmartObjectBase*& Value) { Write<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_SmartObjectSubsystem(const USmartObjectSubsystem*& Value) { Write<USmartObjectSubsystem*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_RunningCommandData(const FFortAIActiveCommandSOUsageData& Value) { Write<FFortAIActiveCommandSOUsageData>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: StructProperty)
    void SET_CommandOnCooldown(const FBotEvaluatorCommandCooldown& Value) { Write<FBotEvaluatorCommandCooldown>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x14, Type: StructProperty)
    void SET_EvaluationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0x4, Type: StructProperty)
    void SET_bEvaluateSOValidityAfterChosen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableEntryLocationsSupport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e1, Value); } // 0x1e1 (Size: 0x1, Type: BoolProperty)
    void SET_SingleCommandCooldown(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    void SET_OverridenFilterClassForEntryPoints(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x8, Type: ClassProperty)
    void SET_SmartObjectExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x21c, Value); } // 0x21c (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationRotationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectShouldMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectUrgencyKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x22c, Value); } // 0x22c (Size: 0x4, Type: NameProperty)
};

// Size: 0x1f8
class UFortAthenaAIBotEvaluator_SmartObjectConverted : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem() const { return Read<USmartObjectSubsystem*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    FBotEvaluatorSmartObjectConvertedData RunningData() const { return Read<FBotEvaluatorSmartObjectConvertedData>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: StructProperty)
    FGameplayTag EvaluationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen() const { return Read<bool>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport() const { return Read<bool>(uintptr_t(this) + 0x1c5); } // 0x1c5 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreCooldowns() const { return Read<bool>(uintptr_t(this) + 0x1c6); } // 0x1c6 (Size: 0x1, Type: BoolProperty)
    UClass* OverridenFilterClassForEntryPoints() const { return Read<UClass*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ClassProperty)
    FName SmartObjectExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName() const { return Read<FName>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x4, Type: NameProperty)

    void SET_SmartObjectRuntimeParameters(const UFortAthenaAIRuntimeParameters_SmartObjectBase*& Value) { Write<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_SmartObjectSubsystem(const USmartObjectSubsystem*& Value) { Write<USmartObjectSubsystem*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_RunningData(const FBotEvaluatorSmartObjectConvertedData& Value) { Write<FBotEvaluatorSmartObjectConvertedData>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: StructProperty)
    void SET_EvaluationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: StructProperty)
    void SET_bEvaluateSOValidityAfterChosen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableEntryLocationsSupport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c5, Value); } // 0x1c5 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreCooldowns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c6, Value); } // 0x1c6 (Size: 0x1, Type: BoolProperty)
    void SET_OverridenFilterClassForEntryPoints(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ClassProperty)
    void SET_SmartObjectExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationRotationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectShouldMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectUrgencyKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x150
class UFortAthenaAIBotEvaluator_TargetContext : public UFortAthenaAIBotEvaluator
{
public:
    FGameplayTagQuery TokenPositionTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x48, Type: StructProperty)
    FName TargetContextReachableKeyName() const { return Read<FName>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: NameProperty)
    FName TargetContextReachableInStraightLineKeyName() const { return Read<FName>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: NameProperty)
    FName TargetContextInsideLeashKeyName() const { return Read<FName>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: NameProperty)
    FName TargetContextLeashExitTimeKeyName() const { return Read<FName>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: NameProperty)
    FName LastRangedWeaponFireAbilityAgainstTimeKeyName() const { return Read<FName>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: NameProperty)
    UFortAthenaLeashComponent* CachedLeashComponent() const { return Read<UFortAthenaLeashComponent*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    float HorizontalProjectionForReachability() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    float VerticalProjectionForReachability() const { return Read<float>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: FloatProperty)
    FValueOrBBKey_Float TimeToConsiderUnreachable() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0xc, Type: StructProperty)
    bool bUseTargetNavAgentLocation() const { return Read<bool>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: BoolProperty)
    bool bTargetInterpenetrationTestEnabled() const { return Read<bool>(uintptr_t(this) + 0x125); } // 0x125 (Size: 0x1, Type: BoolProperty)
    FName TargetContextInterpenetratedKeyName() const { return Read<FName>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: NameProperty)
    FName TargetContextInAirForAimingKeyName() const { return Read<FName>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: NameProperty)

    void SET_TokenPositionTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x48, Type: StructProperty)
    void SET_TargetContextReachableKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: NameProperty)
    void SET_TargetContextReachableInStraightLineKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: NameProperty)
    void SET_TargetContextInsideLeashKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: NameProperty)
    void SET_TargetContextLeashExitTimeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: NameProperty)
    void SET_LastRangedWeaponFireAbilityAgainstTimeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: NameProperty)
    void SET_CachedLeashComponent(const UFortAthenaLeashComponent*& Value) { Write<UFortAthenaLeashComponent*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalProjectionForReachability(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalProjectionForReachability(const float& Value) { Write<float>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: FloatProperty)
    void SET_TimeToConsiderUnreachable(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0xc, Type: StructProperty)
    void SET_bUseTargetNavAgentLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: BoolProperty)
    void SET_bTargetInterpenetrationTestEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x125, Value); } // 0x125 (Size: 0x1, Type: BoolProperty)
    void SET_TargetContextInterpenetratedKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: NameProperty)
    void SET_TargetContextInAirForAimingKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: NameProperty)
};

// Size: 0x2e0
class UFortAthenaAIBotEvaluator_TokenPosition : public UFortAthenaAIEvaluator_Movement
{
public:
    FName QueryResultKeyName() const { return Read<FName>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x4, Type: NameProperty)
    TArray<FPositioningEQS> EQSs() const { return Read<TArray<FPositioningEQS>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    float TokenPositionCooldown() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float TokenPositionCooldownVariation() const { return Read<float>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    FValueOrBBKey_Float NewTokenPositionCooldown() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float NewTokenPositionCooldownVariation() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float DistanceToleranceForReturningToPosition() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CanAcquirePositionInEnter() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float DistanceForDestinationAsTarget() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool DestinationAsTargetOnceOnly() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CanAddNewPositionToProvider() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ShouldCheckIfPositionIsReachable() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MarkPositionAsDeniedIfNoVisibilityOnTarget() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float AcceptableDistanceForReservation() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0xc, Type: StructProperty)
    FGameplayTagQuery GeneratedTokenPositionTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x48, Type: StructProperty)
    UFortAICombatTokenConsumerComponent* CachedTokenConsumerComponent() const { return Read<UFortAICombatTokenConsumerComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortAICombatTokenProviderComponent*> CachedTokenProviderComponent() const { return Read<TWeakObjectPtr<UFortAICombatTokenProviderComponent*>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    int32_t RunningEQSRequestID() const { return Read<int32_t>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x4, Type: IntProperty)
    bool bPositionRequested() const { return Read<bool>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x1, Type: BoolProperty)
    bool bPositionAcquiredInEnter() const { return Read<bool>(uintptr_t(this) + 0x2c5); } // 0x2c5 (Size: 0x1, Type: BoolProperty)
    bool bMoveToTargetFinished() const { return Read<bool>(uintptr_t(this) + 0x2c6); } // 0x2c6 (Size: 0x1, Type: BoolProperty)
    float PositionAcquiredFromQueryTimestamp() const { return Read<float>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: NameProperty)

    void SET_QueryResultKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x4, Type: NameProperty)
    void SET_EQSs(const TArray<FPositioningEQS>& Value) { Write<TArray<FPositioningEQS>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    void SET_TokenPositionCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    void SET_TokenPositionCooldownVariation(const float& Value) { Write<float>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    void SET_NewTokenPositionCooldown(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0xc, Type: StructProperty)
    void SET_NewTokenPositionCooldownVariation(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0xc, Type: StructProperty)
    void SET_DistanceToleranceForReturningToPosition(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0xc, Type: StructProperty)
    void SET_CanAcquirePositionInEnter(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0xc, Type: StructProperty)
    void SET_DistanceForDestinationAsTarget(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0xc, Type: StructProperty)
    void SET_DestinationAsTargetOnceOnly(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0xc, Type: StructProperty)
    void SET_CanAddNewPositionToProvider(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0xc, Type: StructProperty)
    void SET_ShouldCheckIfPositionIsReachable(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0xc, Type: StructProperty)
    void SET_MarkPositionAsDeniedIfNoVisibilityOnTarget(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0xc, Type: StructProperty)
    void SET_AcceptableDistanceForReservation(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0xc, Type: StructProperty)
    void SET_GeneratedTokenPositionTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x48, Type: StructProperty)
    void SET_CachedTokenConsumerComponent(const UFortAICombatTokenConsumerComponent*& Value) { Write<UFortAICombatTokenConsumerComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedTokenProviderComponent(const TWeakObjectPtr<UFortAICombatTokenProviderComponent*>& Value) { Write<TWeakObjectPtr<UFortAICombatTokenProviderComponent*>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RunningEQSRequestID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x4, Type: IntProperty)
    void SET_bPositionRequested(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x1, Type: BoolProperty)
    void SET_bPositionAcquiredInEnter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c5, Value); } // 0x2c5 (Size: 0x1, Type: BoolProperty)
    void SET_bMoveToTargetFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c6, Value); } // 0x2c6 (Size: 0x1, Type: BoolProperty)
    void SET_PositionAcquiredFromQueryTimestamp(const float& Value) { Write<float>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: NameProperty)
};

// Size: 0xf0
class UFortAthenaAIBotEvaluator_UseAugmentMovementItem : public UFortAthenaAIBotEvaluator
{
public:
    FName MovementItemObjectKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName UseSecondaryFireKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName CanUseInputToDeactivateKeyName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName CanUseWhilePathFollowingKeyName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FName HealingExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    UAthenaAIServicePlayerBots* CachedAIServicePlayerBots() const { return Read<UAthenaAIServicePlayerBots*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotPathFollowingComponent* CachedPathFollowingComponent() const { return Read<UFortAthenaAIBotPathFollowingComponent*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TArray<FAIMovementItemData> CachedMovementItemData() const { return Read<TArray<FAIMovementItemData>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)

    void SET_MovementItemObjectKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_UseSecondaryFireKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_CanUseInputToDeactivateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_CanUseWhilePathFollowingKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_HealingExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_CachedAIServicePlayerBots(const UAthenaAIServicePlayerBots*& Value) { Write<UAthenaAIServicePlayerBots*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedPathFollowingComponent(const UFortAthenaAIBotPathFollowingComponent*& Value) { Write<UFortAthenaAIBotPathFollowingComponent*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedMovementItemData(const TArray<FAIMovementItemData>& Value) { Write<TArray<FAIMovementItemData>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
class UFortAthenaAIEvaluator_AbovePhysicsObject : public UFortAthenaAIEvaluator
{
public:
};

// Size: 0x188
class UFortAthenaAIEvaluator_LookAt : public UFortAthenaAIEvaluator
{
public:
    TArray<FFortAthenaAIEvaluator_LookAt_PawnConfiguration> PawnConfigurations() const { return Read<TArray<FFortAthenaAIEvaluator_LookAt_PawnConfiguration>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAthenaAIEvaluator_LookAt_SOConfiguration> SOConfigurations() const { return Read<TArray<FFortAthenaAIEvaluator_LookAt_SOConfiguration>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    UCurveFloat* UtilityWeightBaseDistanceCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* UtilityWeightBaseDotCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> ExecutionStatusesToCheckForNonPendingNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    bool bForceEvaluationOnNearbyPawnChange() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)

    void SET_PawnConfigurations(const TArray<FFortAthenaAIEvaluator_LookAt_PawnConfiguration>& Value) { Write<TArray<FFortAthenaAIEvaluator_LookAt_PawnConfiguration>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_SOConfigurations(const TArray<FFortAthenaAIEvaluator_LookAt_SOConfiguration>& Value) { Write<TArray<FFortAthenaAIEvaluator_LookAt_SOConfiguration>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_UtilityWeightBaseDistanceCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_UtilityWeightBaseDotCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_ExecutionStatusesToCheckForNonPendingNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_bForceEvaluationOnNearbyPawnChange(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
class UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* SmartObjectActor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FSoftDataRegistryOrTable UIOptionsDataTable() const { return Read<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x30, Type: StructProperty)
    FFortUISmartObjectUIPayloadOptions UIOptions() const { return Read<FFortUISmartObjectUIPayloadOptions>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)
    FFortUISmartObjectUIPayloadOptions UIOptionsResult() const { return Read<FFortUISmartObjectUIPayloadOptions>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)

    void SET_SmartObjectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_UIOptionsDataTable(const FSoftDataRegistryOrTable& Value) { Write<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x30, Type: StructProperty)
    void SET_UIOptions(const FFortUISmartObjectUIPayloadOptions& Value) { Write<FFortUISmartObjectUIPayloadOptions>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
    void SET_UIOptionsResult(const FFortUISmartObjectUIPayloadOptions& Value) { Write<FFortUISmartObjectUIPayloadOptions>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x88
class UFortAthenaBTService_ApplySkillSet : public UBTService
{
public:
    FValueOrBBKey_Class SkillSetClass() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_SkillSetClass(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xe0
class UFortAthenaBTService_ModifyTokenNumber : public UBTService
{
public:
    FGameplayTagQuery TokenTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x48, Type: StructProperty)
    FScalableFloat NewTokenAmount() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)

    void SET_TokenTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x48, Type: StructProperty)
    void SET_NewTokenAmount(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x98
class UFortAthenaBTService_ModulateSpeedOnDistance : public UBTService
{
public:
    FName TooFarFromLeaderKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName FollowGroupLeaderDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Float TargetSpeed() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MaxSpeed() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0xc, Type: StructProperty)

    void SET_TooFarFromLeaderKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_FollowGroupLeaderDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_TargetSpeed(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0xc, Type: StructProperty)
    void SET_MaxSpeed(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0xc, Type: StructProperty)
};

// Size: 0x140
class UFortAthenaBTService_MovementStyle : public UBTService
{
public:
    TEnumAsByte<EFortMovementStyle> MovementStyle() const { return Read<TEnumAsByte<EFortMovementStyle>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: ByteProperty)
    FValueOrBBKey_Enum NewMovementStyle() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery TagCondition() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x48, Type: StructProperty)
    FBlackboardKeySelector BlackboardCondition() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool InvertBlackboardCondition() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0xc, Type: StructProperty)

    void SET_MovementStyle(const TEnumAsByte<EFortMovementStyle>& Value) { Write<TEnumAsByte<EFortMovementStyle>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: ByteProperty)
    void SET_NewMovementStyle(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_TagCondition(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x48, Type: StructProperty)
    void SET_BlackboardCondition(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
    void SET_InvertBlackboardCondition(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0xc, Type: StructProperty)
};

// Size: 0x80
class UFortAthenaBTService_SetInTacticalAction : public UBTService
{
public:
    FValueOrBBKey_Bool ShouldSetInTacticalAction() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)

    void SET_ShouldSetInTacticalAction(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
};

// Size: 0xe0
class UFortAthenaBTService_TokenPositionReservation : public UBTService
{
public:
    FBlackboardKeySelector TokenProviderTargetKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Vector TokenDestinationKey() const { return Read<FValueOrBBKey_Vector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)
    FBlackboardKeySelector HasTokenReservedPositionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)

    void SET_TokenProviderTargetKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_TokenDestinationKey(const FValueOrBBKey_Vector& Value) { Write<FValueOrBBKey_Vector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
    void SET_HasTokenReservedPositionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
};

// Size: 0xd8
class UFortAthenaBTService_TokenQuery : public UBTService
{
public:
    TArray<FEquippedItemTagAssociationData> EquippedItemTagAssociationDatas() const { return Read<TArray<FEquippedItemTagAssociationData>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagQuery DefaultTokenSystemTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x48, Type: StructProperty)
    uint8_t BecomeRelevantTokenAction() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t CeaseRelevantTokenAction() const { return Read<uint8_t>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    uint8_t WeaponChangeTokenAction() const { return Read<uint8_t>(uintptr_t(this) + 0xca); } // 0xca (Size: 0x1, Type: EnumProperty)
    uint8_t TargetChangeTokenAction() const { return Read<uint8_t>(uintptr_t(this) + 0xcb); } // 0xcb (Size: 0x1, Type: EnumProperty)
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: NameProperty)

    void SET_EquippedItemTagAssociationDatas(const TArray<FEquippedItemTagAssociationData>& Value) { Write<TArray<FEquippedItemTagAssociationData>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultTokenSystemTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x48, Type: StructProperty)
    void SET_BecomeRelevantTokenAction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_CeaseRelevantTokenAction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    void SET_WeaponChangeTokenAction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xca, Value); } // 0xca (Size: 0x1, Type: EnumProperty)
    void SET_TargetChangeTokenAction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xcb, Value); } // 0xcb (Size: 0x1, Type: EnumProperty)
    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x50
class UFortBTWorldConditionSchema : public UWorldConditionSchema
{
public:
};

// Size: 0xe0
class UFortAthenaBTService_WorldCondition : public UBTService
{
public:
    FWorldConditionQueryDefinition Conditions() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FName ConditionsResultName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FWorldConditionQueryState QueryState() const { return Read<FWorldConditionQueryState>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x30, Type: StructProperty)
    AAIController* CachedOwnerController() const { return Read<AAIController*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    AActor* CachedOwnerPawn() const { return Read<AActor*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_Conditions(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_ConditionsResultName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_QueryState(const FWorldConditionQueryState& Value) { Write<FWorldConditionQueryState>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x30, Type: StructProperty)
    void SET_CachedOwnerController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedOwnerPawn(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x98
class UFortAthenaBTTask_SetDefendSpotPenalized : public UBTTaskNode
{
public:
    FBlackboardKeySelector DefendSpotBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)

    void SET_DefendSpotBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
};

// Size: 0x98
class UFortAthenaBTTask_SetDefendSpotReached : public UBTTaskNode
{
public:
    FBlackboardKeySelector DefendSpotBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)

    void SET_DefendSpotBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
};

// Size: 0xe8
class UFortAthenaBTTask_GetDefendSpotShootSpot : public UBTTaskNode
{
public:
    FBlackboardKeySelector DefendSpotBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector ShootSpotPositionBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector AllowCrouchBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)

    void SET_DefendSpotBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_ShootSpotPositionBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_AllowCrouchBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
};

// Size: 0xc8
class UFortAthenaBTTask_Harvest : public UBTTaskNode
{
public:
    FName HarvestExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName HarvestTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName HarvestTargetHitPointKeyName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FName HarvestDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeKeyName() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)
    FScalableFloat MeleeSwingDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FGameplayTag HarvestAbilityTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: StructProperty)

    void SET_HarvestExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_HarvestTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_HarvestTargetHitPointKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_HarvestDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
    void SET_MeleeSwingDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_HarvestAbilityTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x88
class UFortAthenaBTTask_ReactToVerb : public UBTTaskNode
{
public:
    FName ReactToVerbTargetActorKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ReactToVerbExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName ExtraStructDataKeyName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)

    void SET_ReactToVerbTargetActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ReactToVerbExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_ExtraStructDataKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
};

// Size: 0x78
class UFortAthenaBTTask_VehicleSwitchSeat : public UBTTaskNode
{
public:
    TEnumAsByte<SwitchSeatType> SwitchSeatType() const { return Read<TEnumAsByte<SwitchSeatType>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: ByteProperty)

    void SET_SwitchSeatType(const TEnumAsByte<SwitchSeatType>& Value) { Write<TEnumAsByte<SwitchSeatType>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
class UFortStateTreeConditionSchema : public UWorldConditionSchema
{
public:
};

// Size: 0x70
class UFortBTDecorator_AIBotVehicleSeatStatus : public UBTDecorator
{
public:
    TEnumAsByte<SeatStatusType> SeatType() const { return Read<TEnumAsByte<SeatStatusType>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: ByteProperty)

    void SET_SeatType(const TEnumAsByte<SeatStatusType>& Value) { Write<TEnumAsByte<SeatStatusType>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xc0
class UFortBTDecorator_CanDoInjectedBehavior : public UBTDecorator_Blackboard
{
public:
};

// Size: 0xd0
class UFortBTDecorator_ExecutionStatus : public UBTDecorator_Blackboard
{
public:
    FValueOrBBKey_Bool ShouldUpdateExecutionStatus() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xc, Type: StructProperty)

    void SET_ShouldUpdateExecutionStatus(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xc, Type: StructProperty)
};

// Size: 0xd8
class UFortBTDecorator_HasToken : public UBTDecorator_BlackboardBase
{
public:
    FGameplayTagQuery TokenQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x48, Type: StructProperty)

    void SET_TokenQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x48, Type: StructProperty)
};

// Size: 0x88
class UFortBTService_AIEvaluatorsInjector : public UBTService
{
public:
    TArray<FFortBTService_InjectionTagKey> InjectionTagsKeys() const { return Read<TArray<FFortBTService_InjectionTagKey>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_InjectionTagsKeys(const TArray<FFortBTService_InjectionTagKey>& Value) { Write<TArray<FFortBTService_InjectionTagKey>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UFortBTService_ApplyGameplayEffect : public UBTService
{
public:
    FValueOrBBKey_Class GameplayEffectBehaviorValue() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Float GameplayEffectLevel() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0xc, Type: StructProperty)

    void SET_GameplayEffectBehaviorValue(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_GameplayEffectLevel(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0xc, Type: StructProperty)
};

// Size: 0x70
class UFortBTService_ClearGoalAndAssignment : public UBTService
{
public:
};

// Size: 0x88
class UFortBTService_Crouch : public UBTService
{
public:
    FValueOrBBKey_Bool EnterShouldCrouch() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ExitShouldCrouch() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0xc, Type: StructProperty)

    void SET_EnterShouldCrouch(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
    void SET_ExitShouldCrouch(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0xc, Type: StructProperty)
};

// Size: 0x70
class UFortBTTask_AlwaysSucceed : public UBTTaskNode
{
public:
};

// Size: 0x70
class UFortBTTask_AlwaysFail : public UBTTaskNode
{
public:
};

// Size: 0x70
class UFortBTTask_InProgress : public UBTTaskNode
{
public:
};

// Size: 0x90
class UFortBTTask_InjectionPoint : public UBTTaskNode
{
public:
    FGameplayTag InjectionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Object InjectedAction() const { return Read<FValueOrBBKey_Object>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)

    void SET_InjectionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
    void SET_InjectedAction(const FValueOrBBKey_Object& Value) { Write<FValueOrBBKey_Object>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb0
class UFortBTTask_RandomInt : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Int32 MinimumValue() const { return Read<FValueOrBBKey_Int32>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Int32 MaximumValue() const { return Read<FValueOrBBKey_Int32>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0xc, Type: StructProperty)

    void SET_MinimumValue(const FValueOrBBKey_Int32& Value) { Write<FValueOrBBKey_Int32>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
    void SET_MaximumValue(const FValueOrBBKey_Int32& Value) { Write<FValueOrBBKey_Int32>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0xc, Type: StructProperty)
};

// Size: 0x108
class UFortEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator_ActorsOfClass
{
public:
    FAIDataProviderBoolValue bRandomizeResults() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x38, Type: StructProperty)

    void SET_bRandomizeResults(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x38, Type: StructProperty)
};

// Size: 0x48
class UFortGameFeatureAction_AddInjectionSupportingBehavior : public UFortGameInstanceGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UBehaviorTree*>> InjectionSupportingBehaviors() const { return Read<TArray<TSoftObjectPtr<UBehaviorTree*>>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_InjectionSupportingBehaviors(const TArray<TSoftObjectPtr<UBehaviorTree*>>& Value) { Write<TArray<TSoftObjectPtr<UBehaviorTree*>>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x48
class UFortGameFeatureAction_InjectAIBehavior : public UFortGameInstanceGameFeatureAction
{
public:
    TArray<FFortAISpawnerTagQueryInjectedBehavior> InjectedBehaviors() const { return Read<TArray<FFortAISpawnerTagQueryInjectedBehavior>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_InjectedBehaviors(const TArray<FFortAISpawnerTagQueryInjectedBehavior>& Value) { Write<TArray<FFortAISpawnerTagQueryInjectedBehavior>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x108
class UFortInjectedBehaviorsComponent : public UFortGameStateComponent
{
public:
};

// Size: 0x28
class UFortQueryContext_AthenaSafeZoneCenterIndex : public UEnvQueryContext
{
public:
};

// Size: 0x38
class UFortQueryContext_ClosestLocationInsideLeash : public UEnvQueryContext
{
public:
    UClass* NavFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)
    bool bUseInnerRadius() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bForcePositionOnLeash() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)

    void SET_NavFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
    void SET_bUseInnerRadius(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bForcePositionOnLeash(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UFortQueryContext_NearbyFactionMembers : public UEnvQueryContext
{
public:
    FScalableFloat NearbyFactionMemberDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)

    void SET_NearbyFactionMemberDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
};

// Size: 0x30
class UFortQueryContext_PlayspaceVolume : public UEnvQueryContext
{
public:
    UClass* QueryActorContext() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)

    void SET_QueryActorContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
class UFortQueryContext_QuerierController : public UEnvQueryContext
{
public:
};

// Size: 0x30
class UFortQueryContext_TokenReservedPosition : public UEnvQueryContext
{
public:
    UClass* TokenProviderContext() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)

    void SET_TokenProviderContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x58
class UFortQueryGenerator_CoverPositionProvider : public UEnvQueryGenerator
{
public:
    UClass* CoverPositionProviderContext() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)

    void SET_CoverPositionProviderContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x58
class UFortQueryGenerator_DefendSpots : public UEnvQueryGenerator
{
public:
    UClass* QueryExtents() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)

    void SET_QueryExtents(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x160
class UFortQueryGenerator_Floodfill : public UEnvQueryGenerator
{
public:
    UClass* CenterContext() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderIntValue MaximumNodeSearchProvider() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaximumSearchRadiusProvider() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PointDensityProvider() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue MaximumNumberOfPointProvider() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    UClass* FilterOverride() const { return Read<UClass*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ClassProperty)
    FVector ProjectExtent() const { return Read<FVector>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x18, Type: StructProperty)
    FNavigationFilterFlags ExtraExcludeFlags() const { return Read<FNavigationFilterFlags>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: StructProperty)

    void SET_CenterContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_MaximumNodeSearchProvider(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_MaximumSearchRadiusProvider(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_PointDensityProvider(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_MaximumNumberOfPointProvider(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_FilterOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ClassProperty)
    void SET_ProjectExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x18, Type: StructProperty)
    void SET_ExtraExcludeFlags(const FNavigationFilterFlags& Value) { Write<FNavigationFilterFlags>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: StructProperty)
};

// Size: 0x148
class UFortQueryGenerator_GridInBox : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue BoxWidth() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue BoxLength() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ClassProperty)
    UClass* BoxExtentsContext() const { return Read<UClass*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ClassProperty)

    void SET_BoxWidth(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_BoxLength(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ClassProperty)
    void SET_BoxExtentsContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xd0
class UFortQueryGenerator_GridInVolume : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    UClass* GenerateInVolume() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)

    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_GenerateInVolume(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x1c0
class UFortQueryGenerator_OnRectangle : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue RectangleWidth() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RectangleLength() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    uint8_t SpacingMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: EnumProperty)
    FAIDataProviderIntValue NumberOfPointsOnWidth() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumberOfPointsOnLength() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x38, Type: StructProperty)
    UClass* LocationContext() const { return Read<UClass*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ClassProperty)
    UClass* RotationContext() const { return Read<UClass*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ClassProperty)

    void SET_RectangleWidth(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_RectangleLength(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_SpacingMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: EnumProperty)
    void SET_NumberOfPointsOnWidth(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x38, Type: StructProperty)
    void SET_NumberOfPointsOnLength(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x38, Type: StructProperty)
    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x38, Type: StructProperty)
    void SET_LocationContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ClassProperty)
    void SET_RotationContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x1f0
class UFortQueryGenerator_OnSphere : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue Radius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue SliceCount() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue StackCount() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScaleX() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScaleY() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScaleZ() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x38, Type: StructProperty)
    UClass* LocationContext() const { return Read<UClass*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
    UClass* RotationContext() const { return Read<UClass*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ClassProperty)

    void SET_Radius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_SliceCount(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_StackCount(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_ScaleX(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_ScaleY(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x38, Type: StructProperty)
    void SET_ScaleZ(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x38, Type: StructProperty)
    void SET_LocationContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ClassProperty)
    void SET_RotationContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x178
class UFortQueryGenerator_PointsOnLine : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateFrom() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue DistanceToFirstPoint() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DistanceBetweenPoints() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x38, Type: StructProperty)
    FEnvTraceData TraceData() const { return Read<FEnvTraceData>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x38, Type: StructProperty)

    void SET_GenerateFrom(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
    void SET_DistanceToFirstPoint(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x38, Type: StructProperty)
    void SET_DistanceBetweenPoints(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x38, Type: StructProperty)
    void SET_MaxDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x38, Type: StructProperty)
    void SET_TraceData(const FEnvTraceData& Value) { Write<FEnvTraceData>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x38, Type: StructProperty)
};

// Size: 0x1b8
class UFortQueryGenerator_PointsOutsideBox : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue NumberOfRingsAroundVolume() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExtraXExtent() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExtraYExtent() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExtraZExtent() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x38, Type: StructProperty)
    UClass* GenerateInBoxCenter() const { return Read<UClass*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ClassProperty)
    UClass* GenerateInBoxExtent() const { return Read<UClass*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ClassProperty)

    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_NumberOfRingsAroundVolume(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_ExtraXExtent(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_ExtraYExtent(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_ExtraZExtent(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x38, Type: StructProperty)
    void SET_GenerateInBoxCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ClassProperty)
    void SET_GenerateInBoxExtent(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa0
class UFortQueryGenerator_TokenDefendSpots : public UEnvQueryGenerator
{
public:
    UClass* TokenProviderContext() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FGameplayTagQuery GameplayTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x48, Type: StructProperty)

    void SET_TokenProviderContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_GameplayTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x48, Type: StructProperty)
};

// Size: 0x160
class UFortTokenGenerator_TokenHintPositions : public UEnvQueryGenerator
{
public:
    UClass* Center() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue MaximumDistanceProvider() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue HintPositionVerticalOffsetProvider() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FGameplayTagQuery RequiredTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x48, Type: StructProperty)
    FScalableFloat MaximumDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)
    FScalableFloat HintPositionVerticalOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x28, Type: StructProperty)

    void SET_Center(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_MaximumDistanceProvider(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_HintPositionVerticalOffsetProvider(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_RequiredTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x48, Type: StructProperty)
    void SET_MaximumDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
    void SET_HintPositionVerticalOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa0
class UFortQueryGenerator_TokenProviderPositions : public UEnvQueryGenerator
{
public:
    UClass* TokenProviderContext() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FGameplayTagQuery GameplayTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x48, Type: StructProperty)

    void SET_TokenProviderContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_GameplayTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x48, Type: StructProperty)
};

// Size: 0x100
class UFortQueryGenerator_TokenReservedPositions : public UEnvQueryGenerator
{
public:
    UClass* ActorContext() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FGameplayTagQuery GameplayTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x48, Type: StructProperty)
    FAIDataProviderFloatValue MaximumDistanceFromQueryActorProvider() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x38, Type: StructProperty)
    FScalableFloat MaximumDistanceFromQueryActor() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x28, Type: StructProperty)

    void SET_ActorContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_GameplayTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x48, Type: StructProperty)
    void SET_MaximumDistanceFromQueryActorProvider(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x38, Type: StructProperty)
    void SET_MaximumDistanceFromQueryActor(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x270
class UFortQueryTest_ActorWithinMeleeRange : public UEnvQueryTest
{
public:
    UClass* TargetContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue RequireAllTargets() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TargetBoundsHeightBias() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x38, Type: StructProperty)

    void SET_TargetContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_RequireAllTargets(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
    void SET_TargetBoundsHeightBias(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x38, Type: StructProperty)
};

// Size: 0x208
class UFortQueryTest_CoverPosition : public UEnvQueryTest
{
public:
    UClass* CoverPositionProviderContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* TargetContext() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)

    void SET_CoverPositionProviderContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_TargetContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x240
class UFortQueryTest_DefendSpotCanShoot : public UEnvQueryTest
{
public:
    UClass* TargetActorContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue TraceCloseEnoughDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> TraceType() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: ByteProperty)

    void SET_TargetActorContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_TraceCloseEnoughDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
    void SET_TraceType(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x1f8
class UFortQueryTest_DefendSpotPenalized : public UEnvQueryTest
{
public:
};

// Size: 0x1f8
class UFortQueryTest_DefendSpotOccupied : public UEnvQueryTest
{
public:
};

// Size: 0x1f8
class UFortQueryTest_DefendSpotAlreadyReserved : public UEnvQueryTest
{
public:
};

// Size: 0x1f8
class UFortQueryTest_DefendSpotPreviouslyOccupied : public UEnvQueryTest
{
public:
};

// Size: 0x238
class UFortQueryTest_DefendSpotPathfindLength : public UEnvQueryTest
{
public:
    FAIDataProviderFloatValue NavmeshNodeSearchDistanceScale() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    UClass* PathfindNavigationQueryFilter() const { return Read<UClass*>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x8, Type: ClassProperty)

    void SET_NavmeshNodeSearchDistanceScale(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    void SET_PathfindNavigationQueryFilter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x200
class UFortQueryTest_DefendSpotProtectionDot : public UEnvQueryTest
{
public:
    UClass* TargetActorContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)

    void SET_TargetActorContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x280
class UFortQueryTest_DistanceBounded : public UEnvQueryTest
{
public:
    uint8_t MeasurementType() const { return Read<uint8_t>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: EnumProperty)
    bool bEnableUpperBound() const { return Read<bool>(uintptr_t(this) + 0x1f9); } // 0x1f9 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue UpperBound() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)
    bool bEnableLowerBound() const { return Read<bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue LowerBound() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x38, Type: StructProperty)
    UClass* ContextLocation() const { return Read<UClass*>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x8, Type: ClassProperty)

    void SET_MeasurementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: EnumProperty)
    void SET_bEnableUpperBound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f9, Value); } // 0x1f9 (Size: 0x1, Type: BoolProperty)
    void SET_UpperBound(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
    void SET_bEnableLowerBound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: BoolProperty)
    void SET_LowerBound(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x38, Type: StructProperty)
    void SET_ContextLocation(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x2a0
class UFortQueryTest_LocationSynchronizer_IsLocationOccupied : public UEnvQueryTest
{
public:
    FAIDataProviderFloatValue BoxExtentX() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue BoxExtentY() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue BoxExtentZ() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)

    void SET_BoxExtentX(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    void SET_BoxExtentY(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x38, Type: StructProperty)
    void SET_BoxExtentZ(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
};

// Size: 0x240
class UFortQueryTest_NavmeshRaycast : public UEnvQueryTest
{
public:
    FAIDataProviderBoolValue ShouldRaycastToContext() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    UClass* RaycastContext() const { return Read<UClass*>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x8, Type: ClassProperty)
    UClass* NavigationFilterOverride() const { return Read<UClass*>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x8, Type: ClassProperty)

    void SET_ShouldRaycastToContext(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    void SET_RaycastContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x8, Type: ClassProperty)
    void SET_NavigationFilterOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x60
class UFortWorldConditionTimeOfDayState : public UObject
{
public:
};

// Size: 0x168
class UPFWNPCReactions_Container : public UPersistenceFrameworkContainer
{
public:
};

// Size: 0xe0
class UPFWNPCReactions_Module : public UPersistenceFrameworkModule
{
public:
};

// Size: 0xa0
class UPFWNPCReactions_Trigger : public UPersistenceFrameworkSaveTrigger_Manual
{
public:
};

// Size: 0x1d0
class UPFWNPCReactions_FilteredListContainer : public UPersistenceFrameworkFilteredListContainer
{
public:
};

// Size: 0x38
class UFortGameFeatureAction_InjectAIEvaluators : public UGameFeatureAction
{
public:
    TArray<FGameFeatureFortAIEvaluatorEntry> AIEvaluatorList() const { return Read<TArray<FGameFeatureFortAIEvaluatorEntry>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_AIEvaluatorList(const TArray<FGameFeatureFortAIEvaluatorEntry>& Value) { Write<TArray<FGameFeatureFortAIEvaluatorEntry>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UFortEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FName OverridenAgentNameForNavmesh() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)

    void SET_OverridenAgentNameForNavmesh(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
};

// Size: 0x148
class UFortEnvQueryGenerator_SimpleGrid : public UFortEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue GridSize() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RandomDisplacementRatio() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ClassProperty)

    void SET_GridSize(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x38, Type: StructProperty)
    void SET_SpaceBetween(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x38, Type: StructProperty)
    void SET_RandomDisplacementRatio(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x38, Type: StructProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xb0
class UFortBTContext_MoveUrgency : public UFortBTService_ContextOverride
{
public:
    FValueOrBBKey_Enum MoveUrgencyValue() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EFortMovementUrgency> MoveUrgency() const { return Read<TEnumAsByte<EFortMovementUrgency>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: ByteProperty)

    void SET_MoveUrgencyValue(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
    void SET_MoveUrgency(const TEnumAsByte<EFortMovementUrgency>& Value) { Write<TEnumAsByte<EFortMovementUrgency>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x80
class UFortBTService_ContextOverride : public UBTService
{
public:
    FValueOrBBKey_Bool Enabled() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)

    void SET_Enabled(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
};

// Size: 0x80
class UFortBTContext_SkipNotPerceivedGoals : public UFortBTService_ContextOverride
{
public:
};

// Size: 0x88
class UFortBTContext_SuppressGoalUpdate : public UFortBTService_ContextOverride
{
public:
    bool bUnregisterFromGoalManager() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_bUnregisterFromGoalManager(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
class UFortBTDecorator_Affiliation : public UBTDecorator
{
public:
    FBlackboardKeySelector FirstActorKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector SecondActorKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x28, Type: StructProperty)
    uint32_t AcceptedAffiliations() const { return Read<uint32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: UInt32Property)

    void SET_FirstActorKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
    void SET_SecondActorKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x28, Type: StructProperty)
    void SET_AcceptedAffiliations(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x90
class UFortBTDecorator_CanBeConsideredAirborne : public UBTDecorator_BlackboardBase
{
public:
};

// Size: 0xe8
class UFortBTDecorator_DistanceBetween : public UBTDecorator
{
public:
    TEnumAsByte<EArithmeticKeyOperation> Operator() const { return Read<TEnumAsByte<EArithmeticKeyOperation>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: ByteProperty)
    FBlackboardKeySelector BlackboardKeyA() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Float SpecifiedDistance() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xc, Type: StructProperty)
    bool bUseSelf() const { return (Read<uint8_t>(uintptr_t(this) + 0xcc) >> 0x0) & 1; } // 0xcc:0 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Bool bCalculateAs2D() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float DistanceCalculationUpdateRate() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0xc, Type: StructProperty)

    void SET_Operator(const TEnumAsByte<EArithmeticKeyOperation>& Value) { Write<TEnumAsByte<EArithmeticKeyOperation>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: ByteProperty)
    void SET_BlackboardKeyA(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_BlackboardKeyB(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_SpecifiedDistance(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xc, Type: StructProperty)
    void SET_bUseSelf(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xcc); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xcc, B); } // 0xcc:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCalculateAs2D(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0xc, Type: StructProperty)
    void SET_DistanceCalculationUpdateRate(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0xc, Type: StructProperty)
};

// Size: 0x168
class UFortBTDecorator_GameplayAbility_CanActivate : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

// Size: 0x178
class UFortBTDecorator_GameplayAbility_CanHitTarget : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Bool UseIdealYawRotationToTargetValue() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0xc, Type: StructProperty)
    bool UseIdealYawRotationToTarget() const { return (Read<uint8_t>(uintptr_t(this) + 0x174) >> 0x0) & 1; } // 0x174:0 (Size: 0x1, Type: BoolProperty)

    void SET_UseIdealYawRotationToTargetValue(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0xc, Type: StructProperty)
    void SET_UseIdealYawRotationToTarget(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x174); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x174, B); } // 0x174:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x178
class UFortBTDecorator_GameplayAbility_CompareDistance : public UFortBTDecorator_QueryGameplayAbility
{
public:
    TArray<FDistanceToTargetComparison> DistanceComparisons() const { return Read<TArray<FDistanceToTargetComparison>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: ArrayProperty)

    void SET_DistanceComparisons(const TArray<FDistanceToTargetComparison>& Value) { Write<TArray<FDistanceToTargetComparison>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x168
class UFortBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

// Size: 0x130
class UFortBTDecorator_GameplayAbility_HasGameplayAbility : public UBTDecorator
{
public:
    FValueOrBBKey_Object AbilityOwningActor() const { return Read<FValueOrBBKey_Object>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_GameplayTagContainer GameplayAbilityTagContainer() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool OnlyTestActiveAbility() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0xc, Type: StructProperty)
    FBlackboardKeySelector AbilityOwningActorKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer GameplayAbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x20, Type: StructProperty)
    FBlackboardKeySelector GameplayAbilityTagBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x28, Type: StructProperty)
    bool bOnlyTestActiveAbility() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)

    void SET_AbilityOwningActor(const FValueOrBBKey_Object& Value) { Write<FValueOrBBKey_Object>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_GameplayAbilityTagContainer(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
    void SET_OnlyTestActiveAbility(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0xc, Type: StructProperty)
    void SET_AbilityOwningActorKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_GameplayAbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x20, Type: StructProperty)
    void SET_GameplayAbilityTagBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x28, Type: StructProperty)
    void SET_bOnlyTestActiveAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x198
class UFortBTDecorator_GameplayAbility_HasNearbyPawns : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Float NearbyPawnDistanceValue() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterAIPawns() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterPlayerPawns() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0xc, Type: StructProperty)
    float NearbyPawnDistance() const { return Read<float>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x4, Type: FloatProperty)
    bool bFilterAIPawns() const { return Read<bool>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bFilterPlayerPawns() const { return Read<bool>(uintptr_t(this) + 0x191); } // 0x191 (Size: 0x1, Type: BoolProperty)

    void SET_NearbyPawnDistanceValue(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0xc, Type: StructProperty)
    void SET_FilterAIPawns(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0xc, Type: StructProperty)
    void SET_FilterPlayerPawns(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0xc, Type: StructProperty)
    void SET_NearbyPawnDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x4, Type: FloatProperty)
    void SET_bFilterAIPawns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterPlayerPawns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x191, Value); } // 0x191 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x198
class UFortBTDecorator_GameplayAbility_IsClosestPawnInRange : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Float NearbyPawnDistanceValue() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterAIPawns() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterPlayerPawns() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0xc, Type: StructProperty)
    float NearbyPawnDistance() const { return Read<float>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x4, Type: FloatProperty)
    bool bFilterAIPawns() const { return Read<bool>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bFilterPlayerPawns() const { return Read<bool>(uintptr_t(this) + 0x191); } // 0x191 (Size: 0x1, Type: BoolProperty)

    void SET_NearbyPawnDistanceValue(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0xc, Type: StructProperty)
    void SET_FilterAIPawns(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0xc, Type: StructProperty)
    void SET_FilterPlayerPawns(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0xc, Type: StructProperty)
    void SET_NearbyPawnDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x4, Type: FloatProperty)
    void SET_bFilterAIPawns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterPlayerPawns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x191, Value); } // 0x191 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x168
class UFortBTDecorator_GameplayAbility_IsOnCooldown : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

// Size: 0x168
class UFortBTDecorator_GameplayAbility_IsRotatedToAttackTarget : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

// Size: 0x168
class UFortBTDecorator_GameplayAbility_IsWithinMaxTargetSelectionRange : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

// Size: 0x90
class UFortBTDecorator_IsGoalPawn : public UBTDecorator_BlackboardBase
{
public:
};

// Size: 0x68
class UFortBTDecorator_IsInBotEndGame : public UBTDecorator
{
public:
};

// Size: 0x1d8
class UFortBTDecorator_IsMoving : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Float UpdateIntervalValue() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MinTimeValue() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0xc, Type: StructProperty)
    bool bUseMinDist() const { return Read<bool>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Float UseMinDistToTargetTime() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x184); } // 0x184 (Size: 0xc, Type: StructProperty)
    FDistanceToTargetComparison MinDistanceComparison() const { return Read<FDistanceToTargetComparison>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x38, Type: StructProperty)
    float UpdateInterval() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    float MinTime() const { return Read<float>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    float MinDistMinTime() const { return Read<float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: FloatProperty)

    void SET_UpdateIntervalValue(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0xc, Type: StructProperty)
    void SET_MinTimeValue(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0xc, Type: StructProperty)
    void SET_bUseMinDist(const bool& Value) { Write<bool>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x1, Type: BoolProperty)
    void SET_UseMinDistToTargetTime(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x184, Value); } // 0x184 (Size: 0xc, Type: StructProperty)
    void SET_MinDistanceComparison(const FDistanceToTargetComparison& Value) { Write<FDistanceToTargetComparison>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x38, Type: StructProperty)
    void SET_UpdateInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    void SET_MinTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    void SET_MinDistMinTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x68
class UFortBTDecorator_IsTakerAirborne : public UBTDecorator
{
public:
};

// Size: 0x98
class UFortBTDecorator_WeaponStatus : public UBTDecorator
{
public:
    float WeaponStatusUpdateRate() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    bool bTestIfCurrentWeaponIsValid() const { return (Read<uint8_t>(uintptr_t(this) + 0x6c) >> 0x0) & 1; } // 0x6c:0 (Size: 0x1, Type: BoolProperty)
    bool bCurrentWeaponShouldBeValid() const { return (Read<uint8_t>(uintptr_t(this) + 0x6c) >> 0x1) & 1; } // 0x6c:1 (Size: 0x1, Type: BoolProperty)
    bool bTestAllowedCurrentWeaponTags() const { return (Read<uint8_t>(uintptr_t(this) + 0x6c) >> 0x2) & 1; } // 0x6c:2 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer AllowedCurrentWeaponTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: StructProperty)
    bool bTestIfCurrentWeaponIsReloading() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x0) & 1; } // 0x90:0 (Size: 0x1, Type: BoolProperty)
    bool bCurrentWeaponShouldBeReloading() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x1) & 1; } // 0x90:1 (Size: 0x1, Type: BoolProperty)
    bool bTestIfCurrentWeaponHasAmmoInMagazine() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x2) & 1; } // 0x90:2 (Size: 0x1, Type: BoolProperty)
    bool bCurrentWeaponShouldHaveAmmoInMagazine() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x3) & 1; } // 0x90:3 (Size: 0x1, Type: BoolProperty)
    bool bTestIfCurrentWeaponHasExtraAmmo() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x4) & 1; } // 0x90:4 (Size: 0x1, Type: BoolProperty)
    bool bCurrentWeaponShouldHaveExtraAmmo() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x5) & 1; } // 0x90:5 (Size: 0x1, Type: BoolProperty)
    bool bAllInterestedTestsMustPass() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x6) & 1; } // 0x90:6 (Size: 0x1, Type: BoolProperty)

    void SET_WeaponStatusUpdateRate(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_bTestIfCurrentWeaponIsValid(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x6c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x6c, B); } // 0x6c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCurrentWeaponShouldBeValid(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x6c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x6c, B); } // 0x6c:1 (Size: 0x1, Type: BoolProperty)
    void SET_bTestAllowedCurrentWeaponTags(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x6c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x6c, B); } // 0x6c:2 (Size: 0x1, Type: BoolProperty)
    void SET_AllowedCurrentWeaponTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: StructProperty)
    void SET_bTestIfCurrentWeaponIsReloading(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCurrentWeaponShouldBeReloading(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:1 (Size: 0x1, Type: BoolProperty)
    void SET_bTestIfCurrentWeaponHasAmmoInMagazine(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:2 (Size: 0x1, Type: BoolProperty)
    void SET_bCurrentWeaponShouldHaveAmmoInMagazine(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:3 (Size: 0x1, Type: BoolProperty)
    void SET_bTestIfCurrentWeaponHasExtraAmmo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:4 (Size: 0x1, Type: BoolProperty)
    void SET_bCurrentWeaponShouldHaveExtraAmmo(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:5 (Size: 0x1, Type: BoolProperty)
    void SET_bAllInterestedTestsMustPass(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:6 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x158
class UFortBTService_ActivateAbility : public UBTService_BlueprintBase
{
public:
    FValueOrBBKey_GameplayTagContainer AbilityTags() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector TargetActorKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    bool bRequireCanHitTargetWithAbility() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    bool bPawnTargetsOnly() const { return Read<bool>(uintptr_t(this) + 0xe9); } // 0xe9 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer ProhibitedTargetTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: StructProperty)
    FValueOrBBKey_Bool bCanActivateWhenMoving() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0xc, Type: StructProperty)
    TArray<FDistanceToTargetComparison> DistanceChecks() const { return Read<TArray<FDistanceToTargetComparison>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    FValueOrBBKey_Float InitialDelayTime() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float InitialDelayRandomDeviation() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool WantsReceiveActivatedAbilityEnded() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0xc, Type: StructProperty)

    void SET_AbilityTags(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_TargetActorKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_bRequireCanHitTargetWithAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_bPawnTargetsOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe9, Value); } // 0xe9 (Size: 0x1, Type: BoolProperty)
    void SET_ProhibitedTargetTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: StructProperty)
    void SET_bCanActivateWhenMoving(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0xc, Type: StructProperty)
    void SET_DistanceChecks(const TArray<FDistanceToTargetComparison>& Value) { Write<TArray<FDistanceToTargetComparison>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_InitialDelayTime(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0xc, Type: StructProperty)
    void SET_InitialDelayRandomDeviation(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0xc, Type: StructProperty)
    void SET_WantsReceiveActivatedAbilityEnded(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0xc, Type: StructProperty)
};

// Size: 0xc0
class UFortBTService_UpdateBotMissionBuilding : public UBTService
{
public:
    FBlackboardKeySelector InterestLocationKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BuildOrderKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)

    void SET_InterestLocationKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_BuildOrderKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa0
class UFortBTService_UpdateBotMissionGoal : public UBTService_BlackboardBase
{
public:
    bool bRequireInteraction() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x0) & 1; } // 0x98:0 (Size: 0x1, Type: BoolProperty)
    bool bRequireInteractionOrLocator() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x1) & 1; } // 0x98:1 (Size: 0x1, Type: BoolProperty)
    bool bRequireEncounter() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x2) & 1; } // 0x98:2 (Size: 0x1, Type: BoolProperty)
    bool bPickClosest() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x3) & 1; } // 0x98:3 (Size: 0x1, Type: BoolProperty)

    void SET_bRequireInteraction(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:0 (Size: 0x1, Type: BoolProperty)
    void SET_bRequireInteractionOrLocator(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:1 (Size: 0x1, Type: BoolProperty)
    void SET_bRequireEncounter(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:2 (Size: 0x1, Type: BoolProperty)
    void SET_bPickClosest(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UFortBTTask_BotMissionBuild : public UBTTask_BlackboardBase
{
public:
};

// Size: 0x98
class UFortBTTask_BotMissionInteract : public UBTTask_BlackboardBase
{
public:
};

// Size: 0xf0
class UFortBTTask_ExecuteGameplayAbility : public UBTTask_GameplayTaskBase
{
public:
    FValueOrBBKey_GameplayTagContainer GameplayAbilityTagContainer() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer GameplayAbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: StructProperty)
    FBlackboardKeySelector GameplayAbilityTagBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)

    void SET_GameplayAbilityTagContainer(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
    void SET_GameplayAbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: StructProperty)
    void SET_GameplayAbilityTagBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x1a0
class UFortBTTask_GameMoveDirectlyToward : public UFortBTTask_GameMoveTo
{
public:
};

// Size: 0x1a0
class UFortBTTask_GameMoveTo : public UBTTask_MoveTo
{
public:
    FBlackboardKeySelector FocalPointWhileMoving() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EPathObstacleAction> PathObstacleAction() const { return Read<TEnumAsByte<EPathObstacleAction>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x1, Type: ByteProperty)
    UClass* PushBumpedPawnClass() const { return Read<UClass*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ClassProperty)
    FGameplayTag NavFilterTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: StructProperty)
    bool bDetectUnexpectedPathBlockingObstacles() const { return (Read<uint8_t>(uintptr_t(this) + 0x16c) >> 0x0) & 1; } // 0x16c:0 (Size: 0x1, Type: BoolProperty)
    bool bEnableSlowdownAtGoal() const { return (Read<uint8_t>(uintptr_t(this) + 0x16c) >> 0x1) & 1; } // 0x16c:1 (Size: 0x1, Type: BoolProperty)
    bool bStopAtGoal() const { return (Read<uint8_t>(uintptr_t(this) + 0x16c) >> 0x2) & 1; } // 0x16c:2 (Size: 0x1, Type: BoolProperty)
    bool bFinishMoveOnOverlap() const { return (Read<uint8_t>(uintptr_t(this) + 0x16c) >> 0x3) & 1; } // 0x16c:3 (Size: 0x1, Type: BoolProperty)
    bool bUpdateMoveOnBlackboardKeyChanges() const { return (Read<uint8_t>(uintptr_t(this) + 0x16c) >> 0x4) & 1; } // 0x16c:4 (Size: 0x1, Type: BoolProperty)
    FBlackboardKeySelector AcceptableRadiusKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x28, Type: StructProperty)
    bool bDeimosFlavor() const { return (Read<uint8_t>(uintptr_t(this) + 0x198) >> 0x0) & 1; } // 0x198:0 (Size: 0x1, Type: BoolProperty)

    void SET_FocalPointWhileMoving(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x28, Type: StructProperty)
    void SET_PathObstacleAction(const TEnumAsByte<EPathObstacleAction>& Value) { Write<TEnumAsByte<EPathObstacleAction>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x1, Type: ByteProperty)
    void SET_PushBumpedPawnClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ClassProperty)
    void SET_NavFilterTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: StructProperty)
    void SET_bDetectUnexpectedPathBlockingObstacles(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x16c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x16c, B); } // 0x16c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableSlowdownAtGoal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x16c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x16c, B); } // 0x16c:1 (Size: 0x1, Type: BoolProperty)
    void SET_bStopAtGoal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x16c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x16c, B); } // 0x16c:2 (Size: 0x1, Type: BoolProperty)
    void SET_bFinishMoveOnOverlap(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x16c); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x16c, B); } // 0x16c:3 (Size: 0x1, Type: BoolProperty)
    void SET_bUpdateMoveOnBlackboardKeyChanges(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x16c); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x16c, B); } // 0x16c:4 (Size: 0x1, Type: BoolProperty)
    void SET_AcceptableRadiusKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x28, Type: StructProperty)
    void SET_bDeimosFlavor(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x198); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x198, B); } // 0x198:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
class UFortBTTask_RequestUndermining : public UBTTaskNode
{
public:
};

// Size: 0xc8
class UFortBTTask_RotateToFaceBBEntryWithTags : public UBTTask_RotateToFaceBBEntry
{
public:
    FGameplayTagContainer TagsToApply() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: StructProperty)

    void SET_TagsToApply(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: StructProperty)
};

// Size: 0xc8
class UFortBTTask_RunDynamicStateTree : public UBTTask_RunDynamicStateTree
{
public:
};

// Size: 0x78
class UFortBTTask_SetFrustrationDiscouragement : public UBTTaskNode
{
public:
    float DiscouragementDuration() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)

    void SET_DiscouragementDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x70
class UFortBTTask_Sleep : public UBTTaskNode
{
public:
};

// Size: 0x130
class UFortBTTask_TakerMoveToNavmesh : public UBTTask_MoveTo
{
public:
};

// Size: 0x2e0
class AFortEQSPrevisActor : public AActor
{
public:
    USceneComponent* SceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x20, Type: StructProperty)

    void SET_SceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x3d8
class AFortEQSTestingController : public AAIController
{
public:
};

// Size: 0x6e0
class AFortEQSTestingPawn : public AEQSTestingPawn
{
public:
    bool bUseDoorNavLinks() const { return Read<bool>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x1, Type: BoolProperty)
    bool bUseClamberNavLinks() const { return Read<bool>(uintptr_t(this) + 0x6d1); } // 0x6d1 (Size: 0x1, Type: BoolProperty)
    bool bUseHurdleNavLinks() const { return Read<bool>(uintptr_t(this) + 0x6d2); } // 0x6d2 (Size: 0x1, Type: BoolProperty)

    void SET_bUseDoorNavLinks(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseClamberNavLinks(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6d1, Value); } // 0x6d1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseHurdleNavLinks(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6d2, Value); } // 0x6d2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UFortQueryContext_AIPawnSpawnLocation : public UEnvQueryContext
{
public:
};

// Size: 0x78
class UFortQueryContext_AllBots : public UEnvQueryContext
{
public:
    bool bIncludeOnlyAthenaGameParticipantBots() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery BotTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)

    void SET_bIncludeOnlyAthenaGameParticipantBots(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_BotTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
};

// Size: 0x28
class UFortQueryContext_AllEnemies : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_AllGoals : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_AllPlayers : public UEnvQueryContext
{
public:
};

// Size: 0x70
class UFortQueryContext_AllPOIVolumes : public UEnvQueryContext
{
public:
    FGameplayTagQuery VolumeLocationTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x48, Type: StructProperty)

    void SET_VolumeLocationTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x48, Type: StructProperty)
};

// Size: 0x28
class UFortQueryContext_AthenaCurrentSafeZoneCenter : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_AthenaCurrentSafeZoneIndicatorCenter : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_AthenaSafeZonePredictedLocation : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_BlackboardKeyLeader : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_BuildingRifts : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterFallbackTarget : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterGoalsCenterLocation : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterGoalsOnGround : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterPrimaryAssignmentGoals : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterProvidedQueryLocations : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterQueryActor : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterRandomDirection : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_EncounterTargetObjective : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_Goal : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_GoalProviderRootAssignmentGoals : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_Goal_SpawnLocation : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_NearbyAIPawns : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_NearbyAIPawnsMoveDestinations : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_NearbyFriendlyAIPawns : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_NearbyFriendlyAIPawnsAndPlayerPawns : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_NearbyFriends : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_PlayerSpawnPad : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_RandomDirectionXY : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_SpawnSpotActorLocationOrAIPawnSpawnLocation : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_StWStormShield : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_TwoPointSolverPointA : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_TwoPointSolverRotationA : public UEnvQueryContext
{
public:
};

// Size: 0x90
class UFortQueryData_CurvesAroundLine : public UDataAsset
{
public:
    FFortPointsOnCurve PointsOnSideA() const { return Read<FFortPointsOnCurve>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x30, Type: StructProperty)
    FFortPointsOnCurve PointsOnSideB() const { return Read<FFortPointsOnCurve>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_PointsOnSideA(const FFortPointsOnCurve& Value) { Write<FFortPointsOnCurve>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x30, Type: StructProperty)
    void SET_PointsOnSideB(const FFortPointsOnCurve& Value) { Write<FFortPointsOnCurve>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0xd0
class UFortQueryGenerator_ActorsAround : public UEnvQueryGenerator_ActorsOfClass
{
public:
};

// Size: 0x50
class UFortQueryGenerator_Allies : public UEnvQueryGenerator
{
public:
};

// Size: 0x50
class UFortQueryGenerator_AssignmentGoal : public UEnvQueryGenerator
{
public:
};

// Size: 0x50
class UFortQueryGenerator_BuildingRifts : public UEnvQueryGenerator
{
public:
};

// Size: 0x228
class UFortQueryGenerator_Buildings : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x30, Type: StructProperty)
    UFortAIAssignmentSettings* AssignmentSettings() const { return Read<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    UClass* BuildingGridVolumeCenter() const { return Read<UClass*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderIntValue HorizontalBuildingCellRadius() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue BuildingCellsAbove() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue BuildingCellsBelow() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeWalls() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeFloors() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x38, Type: StructProperty)
    TArray<EFloorPatternType> FloorPatternsToIgnore() const { return Read<TArray<EFloorPatternType>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    FAIDataProviderBoolValue bIncludeCenterCell() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue MaxBuildingActorsPerVolumeCenterToCollect() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x38, Type: StructProperty)

    void SET_AssignmentIdentifier(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x30, Type: StructProperty)
    void SET_AssignmentSettings(const UFortAIAssignmentSettings*& Value) { Write<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_BuildingGridVolumeCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ClassProperty)
    void SET_HorizontalBuildingCellRadius(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_BuildingCellsAbove(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_BuildingCellsBelow(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_bIncludeWalls(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_bIncludeFloors(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x38, Type: StructProperty)
    void SET_FloorPatternsToIgnore(const TArray<EFloorPatternType>& Value) { Write<TArray<EFloorPatternType>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_bIncludeCenterCell(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x38, Type: StructProperty)
    void SET_MaxBuildingActorsPerVolumeCenterToCollect(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x38, Type: StructProperty)
};

// Size: 0x100
class UFortQueryGenerator_BuildingsOnCachedPath : public UEnvQueryGenerator
{
public:
    UClass* CachedPathSource() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue bIncludeWalls() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeFloors() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeCenterCell() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)

    void SET_CachedPathSource(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_bIncludeWalls(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_bIncludeFloors(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_bIncludeCenterCell(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
};

// Size: 0x50
class UFortQueryGenerator_EncounterTargets : public UEnvQueryGenerator
{
public:
};

// Size: 0xd0
class UFortQueryGenerator_Enemies : public UEnvQueryGenerator
{
public:
    bool bPerceivedEnemiesOnly() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bSleepCapableAIUsePerceivedEnemiesOnly() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreDBNOPawns() const { return Read<bool>(uintptr_t(this) + 0x52); } // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreSleepingAIs() const { return Read<bool>(uintptr_t(this) + 0x53); } // 0x53 (Size: 0x1, Type: BoolProperty)
    bool bAddEnemiesFromAbilityRange() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer AbilityTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DistanceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x20, Type: StructProperty)
    FAIDataProviderFloatValue MaxTimeSincePerceived() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x38, Type: StructProperty)

    void SET_bPerceivedEnemiesOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bSleepCapableAIUsePerceivedEnemiesOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreDBNOPawns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x52, Value); } // 0x52 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreSleepingAIs(const bool& Value) { Write<bool>(uintptr_t(this) + 0x53, Value); } // 0x53 (Size: 0x1, Type: BoolProperty)
    void SET_bAddEnemiesFromAbilityRange(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_AbilityTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_DistanceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x20, Type: StructProperty)
    void SET_MaxTimeSincePerceived(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x38, Type: StructProperty)
};

// Size: 0x98
class UFortQueryGenerator_GoalActorsOfClass : public UEnvQueryGenerator
{
public:
    UClass* SearchedActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue SearchRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)

    void SET_SearchedActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_SearchRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_SearchCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x298
class UFortQueryGenerator_GoalOnCircle : public UEnvQueryGenerator_OnCircle
{
public:
    bool bIncludeCenterActorInGeneratedGoals() const { return Read<bool>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x1, Type: BoolProperty)
    UFortAIAssignmentSettings* OptionalAssignmentSettings() const { return Read<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    FFortAIAssignmentIdentifier OptionalAssignmentIdentifier() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x30, Type: StructProperty)

    void SET_bIncludeCenterActorInGeneratedGoals(const bool& Value) { Write<bool>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x1, Type: BoolProperty)
    void SET_OptionalAssignmentSettings(const UFortAIAssignmentSettings*& Value) { Write<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    void SET_OptionalAssignmentIdentifier(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x30, Type: StructProperty)
};

// Size: 0x58
class UFortQueryGenerator_GoalPlayerPawns : public UEnvQueryGenerator
{
public:
    bool bOnlyAthenaGameParticipants() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)

    void SET_bOnlyAthenaGameParticipants(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
class UFortQueryGenerator_GoalTrackableAIObjects : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x30, Type: StructProperty)
    UClass* SearchedActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ClassProperty)
    FGameplayTag RequiredTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: StructProperty)
    FAIDataProviderFloatValue SearchRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)

    void SET_AssignmentIdentifier(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x30, Type: StructProperty)
    void SET_SearchedActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ClassProperty)
    void SET_RequiredTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: StructProperty)
    void SET_SearchRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_SearchCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa0
class UFortQueryGenerator_HotspotSlots : public UEnvQueryGenerator
{
public:
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue Radius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    bool bUseTetherZone() const { return (Read<uint8_t>(uintptr_t(this) + 0x90) >> 0x0) & 1; } // 0x90:0 (Size: 0x1, Type: BoolProperty)
    UClass* HotspotClass() const { return Read<UClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ClassProperty)

    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_Radius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_bUseTetherZone(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x90); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x90, B); } // 0x90:0 (Size: 0x1, Type: BoolProperty)
    void SET_HotspotClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xd8
class UFortQueryGenerator_InfluenceMapPoints : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderIntValue Density() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    bool bOnlyFlatSurface() const { return (Read<uint8_t>(uintptr_t(this) + 0xc8) >> 0x0) & 1; } // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)

    void SET_Density(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_bOnlyFlatSurface(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc8, B); } // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x128
class UFortQueryGenerator_LootGoalsAthena : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x30, Type: StructProperty)
    UFortAIAssignmentSettings* AssignmentSettings() const { return Read<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    FAIDataProviderFloatValue HorizontalHalfExtents() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue VerticalHalfExtents() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter() const { return Read<UClass*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ClassProperty)
    bool bAvailableLootOnly() const { return (Read<uint8_t>(uintptr_t(this) + 0x100) >> 0x0) & 1; } // 0x100:0 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer ExcludedAILootGameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: StructProperty)

    void SET_AssignmentIdentifier(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x30, Type: StructProperty)
    void SET_AssignmentSettings(const UFortAIAssignmentSettings*& Value) { Write<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalHalfExtents(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x38, Type: StructProperty)
    void SET_VerticalHalfExtents(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x38, Type: StructProperty)
    void SET_SearchCenter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ClassProperty)
    void SET_bAvailableLootOnly(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x100); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x100, B); } // 0x100:0 (Size: 0x1, Type: BoolProperty)
    void SET_ExcludedAILootGameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: StructProperty)
};

// Size: 0x98
class UFortQueryGenerator_MissionPlacementActors : public UEnvQueryGenerator
{
public:
    FGameplayTagQuery MissionPlacementActorTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x48, Type: StructProperty)

    void SET_MissionPlacementActorTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x48, Type: StructProperty)
};

// Size: 0x50
class UFortQueryGenerator_MutatorActorQueryResults : public UEnvQueryGenerator
{
public:
};

// Size: 0x50
class UFortQueryGenerator_MutatorBaseQueryResults : public UEnvQueryGenerator
{
public:
};

// Size: 0x128
class UFortQueryGenerator_PerceivedActors : public UEnvQueryGenerator
{
public:
    bool bGenerateHostileActorGoal() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FFortQueryGenerator_PerceivedActors_Settings HostileActorSettings() const { return Read<FFortQueryGenerator_PerceivedActors_Settings>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x40, Type: StructProperty)
    bool bGenerateNeutralActorGoal() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    FFortQueryGenerator_PerceivedActors_Settings NeutralActorSettings() const { return Read<FFortQueryGenerator_PerceivedActors_Settings>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x40, Type: StructProperty)
    bool bGenerateFriendlyActorGoal() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    FFortQueryGenerator_PerceivedActors_Settings FriendlyActorSettings() const { return Read<FFortQueryGenerator_PerceivedActors_Settings>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x40, Type: StructProperty)

    void SET_bGenerateHostileActorGoal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_HostileActorSettings(const FFortQueryGenerator_PerceivedActors_Settings& Value) { Write<FFortQueryGenerator_PerceivedActors_Settings>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x40, Type: StructProperty)
    void SET_bGenerateNeutralActorGoal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_NeutralActorSettings(const FFortQueryGenerator_PerceivedActors_Settings& Value) { Write<FFortQueryGenerator_PerceivedActors_Settings>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x40, Type: StructProperty)
    void SET_bGenerateFriendlyActorGoal(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_FriendlyActorSettings(const FFortQueryGenerator_PerceivedActors_Settings& Value) { Write<FFortQueryGenerator_PerceivedActors_Settings>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x40, Type: StructProperty)
};

// Size: 0x128
class UFortQueryGenerator_PointsAroundLine : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderIntValue MaxPointsPerClusterLocation() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ClusterRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x38, Type: StructProperty)
    TSoftObjectPtr<UFortQueryData_CurvesAroundLine> CurvesAroundLineAsset() const { return Read<TSoftObjectPtr<UFortQueryData_CurvesAroundLine>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)

    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
    void SET_MaxPointsPerClusterLocation(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x38, Type: StructProperty)
    void SET_ClusterRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x38, Type: StructProperty)
    void SET_CurvesAroundLineAsset(const TSoftObjectPtr<UFortQueryData_CurvesAroundLine>& Value) { Write<TSoftObjectPtr<UFortQueryData_CurvesAroundLine>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x1e0
class UFortQueryGenerator_PointsFromNavGraph : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue MinPathDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxPathDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue Density() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExploreDirectionYaw() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FEnvDirection ExploreDirection() const { return Read<FEnvDirection>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x20, Type: StructProperty)
    float ExploreAngleDot() const { return Read<float>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x4, Type: FloatProperty)
    FAIDataProviderFloatValue ExploreInnerRadius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x38, Type: StructProperty)
    bool bLimitExplorationDirection() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x0) & 1; } // 0x1d0:0 (Size: 0x1, Type: BoolProperty)
    bool bOnlyFlatSurface() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x1) & 1; } // 0x1d0:1 (Size: 0x1, Type: BoolProperty)
    bool bUseParameterizedDirection() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x2) & 1; } // 0x1d0:2 (Size: 0x1, Type: BoolProperty)
    bool bUseHeightCheck() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x3) & 1; } // 0x1d0:3 (Size: 0x1, Type: BoolProperty)
    bool bFilterAllowTerrain() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x4) & 1; } // 0x1d0:4 (Size: 0x1, Type: BoolProperty)
    bool bFilterAllowBuildings() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x5) & 1; } // 0x1d0:5 (Size: 0x1, Type: BoolProperty)
    bool bFilterAllowDropdown() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x6) & 1; } // 0x1d0:6 (Size: 0x1, Type: BoolProperty)
    bool bFilterAllowClimbup() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x7) & 1; } // 0x1d0:7 (Size: 0x1, Type: BoolProperty)
    bool bFilterAllowSmash() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d1) >> 0x0) & 1; } // 0x1d1:0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EFortPointsFromNavGraphGoalPathDistanceFilterOperator> PathDistanceFilterOperator() const { return Read<TEnumAsByte<EFortPointsFromNavGraphGoalPathDistanceFilterOperator>>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x1, Type: ByteProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ClassProperty)

    void SET_MinPathDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_MaxPathDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_Density(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_ExploreDirectionYaw(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_ExploreDirection(const FEnvDirection& Value) { Write<FEnvDirection>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x20, Type: StructProperty)
    void SET_ExploreAngleDot(const float& Value) { Write<float>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x4, Type: FloatProperty)
    void SET_ExploreInnerRadius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x38, Type: StructProperty)
    void SET_bLimitExplorationDirection(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlyFlatSurface(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseParameterizedDirection(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bUseHeightCheck(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:3 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterAllowTerrain(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:4 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterAllowBuildings(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:5 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterAllowDropdown(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:6 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterAllowClimbup(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:7 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterAllowSmash(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d1); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1d1, B); } // 0x1d1:0 (Size: 0x1, Type: BoolProperty)
    void SET_PathDistanceFilterOperator(const TEnumAsByte<EFortPointsFromNavGraphGoalPathDistanceFilterOperator>& Value) { Write<TEnumAsByte<EFortPointsFromNavGraphGoalPathDistanceFilterOperator>>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x1, Type: ByteProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x288
class UFortQueryGenerator_PointsInCylinder : public UEnvQueryGenerator_Donut
{
public:
    FAIDataProviderFloatValue CylinderHeightMin() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue CylinderHeightMax() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetweenSlices() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x38, Type: StructProperty)

    void SET_CylinderHeightMin(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x38, Type: StructProperty)
    void SET_CylinderHeightMax(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x38, Type: StructProperty)
    void SET_SpaceBetweenSlices(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x38, Type: StructProperty)
};

// Size: 0x98
class UFortQueryGenerator_PointsInVolume : public UEnvQueryGenerator
{
public:
    FAIDataProviderIntValue NumberOfPoints() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EFortNamedNavmesh> NavMeshToUse() const { return Read<TEnumAsByte<EFortNamedNavmesh>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: ByteProperty)
    UClass* GenerateIn() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)

    void SET_NumberOfPoints(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
    void SET_NavMeshToUse(const TEnumAsByte<EFortNamedNavmesh>& Value) { Write<TEnumAsByte<EFortNamedNavmesh>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: ByteProperty)
    void SET_GenerateIn(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x258
class UFortQueryGenerator_PointsOnBuildingActors : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue BoundingBoxExtentXY() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue BoundingBoxExtentZ() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PointDensity() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue MaxGeneratedPoints() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x38, Type: StructProperty)
    FFortTaggedActorOctreeFilter ActorLookupFilter() const { return Read<FFortTaggedActorOctreeFilter>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xa8, Type: StructProperty)
    FAIDataProviderFloatValue RandomChanceToSkip() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x8, Type: ClassProperty)

    void SET_BoundingBoxExtentXY(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_BoundingBoxExtentZ(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_PointDensity(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_MaxGeneratedPoints(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x38, Type: StructProperty)
    void SET_ActorLookupFilter(const FFortTaggedActorOctreeFilter& Value) { Write<FFortTaggedActorOctreeFilter>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xa8, Type: StructProperty)
    void SET_RandomChanceToSkip(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x38, Type: StructProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x110
class UFortQueryGenerator_PointsOnBuildingGrid : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderIntValue HorizontalGridSize() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue VerticalGridSize() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    bool bStartGridFromBottom() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)
    bool bUsePointInVerticalCenterOfCell() const { return Read<bool>(uintptr_t(this) + 0x101); } // 0x101 (Size: 0x1, Type: BoolProperty)
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ClassProperty)

    void SET_HorizontalGridSize(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_VerticalGridSize(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_bStartGridFromBottom(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
    void SET_bUsePointInVerticalCenterOfCell(const bool& Value) { Write<bool>(uintptr_t(this) + 0x101, Value); } // 0x101 (Size: 0x1, Type: BoolProperty)
    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xf0
class UFortQueryGenerator_PointsOnWaterShoreLine : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateAround() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UFortQueryData_CurvesAroundLine> CurvesAroundLineAsset() const { return Read<TSoftObjectPtr<UFortQueryData_CurvesAroundLine>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: SoftObjectProperty)
    FAIDataProviderFloatValue SegmentMaximumVerticalDegreeAngle() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x38, Type: StructProperty)

    void SET_GenerateAround(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
    void SET_CurvesAroundLineAsset(const TSoftObjectPtr<UFortQueryData_CurvesAroundLine>& Value) { Write<TSoftObjectPtr<UFortQueryData_CurvesAroundLine>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SegmentMaximumVerticalDegreeAngle(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x38, Type: StructProperty)
};

// Size: 0xd0
class UFortQueryGenerator_RandomPointsInBoundingVolume : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateIn() const { return Read<UClass*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue RandomPointsCount() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x38, Type: StructProperty)

    void SET_GenerateIn(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ClassProperty)
    void SET_RandomPointsCount(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x38, Type: StructProperty)
};

// Size: 0x90
class UFortQueryGenerator_SpecificAssignmentGoals : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x30, Type: StructProperty)
    UFortAIAssignmentSettings* AssignmentSettings() const { return Read<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    UClass* GoalProvider() const { return Read<UClass*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ClassProperty)

    void SET_AssignmentIdentifier(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x30, Type: StructProperty)
    void SET_AssignmentSettings(const UFortAIAssignmentSettings*& Value) { Write<UFortAIAssignmentSettings*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_GoalProvider(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x168
class UFortQueryGenerator_SquadMembers : public UEnvQueryGenerator
{
public:
    FAIDataProviderBoolValue LookingForHumanPlayers() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LookingForPlayerBots() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LookingForNpcs() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LookingForAiPawns() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue IncludeSelf() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x38, Type: StructProperty)

    void SET_LookingForHumanPlayers(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
    void SET_LookingForPlayerBots(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x38, Type: StructProperty)
    void SET_LookingForNpcs(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x38, Type: StructProperty)
    void SET_LookingForAiPawns(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x38, Type: StructProperty)
    void SET_IncludeSelf(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x38, Type: StructProperty)
};

// Size: 0x140
class UFortQueryGenerator_TerrainDonut : public UEnvQueryGenerator
{
public:
    UClass* Center() const { return Read<UClass*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue Radius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RadiusWidth() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpacingArc() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumRings() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    bool bFilterAllowTerrain() const { return (Read<uint8_t>(uintptr_t(this) + 0x138) >> 0x0) & 1; } // 0x138:0 (Size: 0x1, Type: BoolProperty)
    bool bFilterAllowBuildings() const { return (Read<uint8_t>(uintptr_t(this) + 0x138) >> 0x1) & 1; } // 0x138:1 (Size: 0x1, Type: BoolProperty)

    void SET_Center(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ClassProperty)
    void SET_Radius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_RadiusWidth(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_SpacingArc(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_NumRings(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_bFilterAllowTerrain(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x138); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x138, B); } // 0x138:0 (Size: 0x1, Type: BoolProperty)
    void SET_bFilterAllowBuildings(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x138); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x138, B); } // 0x138:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UFortQueryGenerator_ValidSpawnRiftActors : public UEnvQueryGenerator
{
public:
    FAIDataProviderIntValue NumAIForGroup() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)

    void SET_NumAIForGroup(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
};

// Size: 0x30
class UFortQueryItemType_PointOrSlot : public UEnvQueryItemType_Point
{
public:
};

// Size: 0x428
class UFortQueryTest_AssignmentTypeInterest : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue InvalidTypeStartInterest() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue InvalidTypeEndInterest() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue InvalidTypeTimeBeforeLerp() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue InvalidTypeLerpDuration() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeStartInterest() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeEndInterest() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeTimeBeforeLerp() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeLerpDuration() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x38, Type: StructProperty)

    void SET_InvalidTypeStartInterest(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
    void SET_InvalidTypeEndInterest(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    void SET_InvalidTypeTimeBeforeLerp(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    void SET_InvalidTypeLerpDuration(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x38, Type: StructProperty)
    void SET_ValidTypeStartInterest(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x38, Type: StructProperty)
    void SET_ValidTypeEndInterest(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x38, Type: StructProperty)
    void SET_ValidTypeTimeBeforeLerp(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x38, Type: StructProperty)
    void SET_ValidTypeLerpDuration(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x38, Type: StructProperty)
};

// Size: 0x268
class UFortQueryTest_GoalBase : public UEnvQueryTest
{
public:
    bool bScoreEnemies() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x0) & 1; } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    bool bScoreEncounterGoals() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x1) & 1; } // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    bool bScoreWorldGoals() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x2) & 1; } // 0x1f8:2 (Size: 0x1, Type: BoolProperty)
    bool bScoreSpecificAssignments() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x3) & 1; } // 0x1f8:3 (Size: 0x1, Type: BoolProperty)
    TArray<FFortAIAssignmentIdentifier> AssignmentIDs() const { return Read<TArray<FFortAIAssignmentIdentifier>>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAIAssignmentIdentifier> ProhibitedAssignmentIDs() const { return Read<TArray<FFortAIAssignmentIdentifier>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagQuery GoalActorTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x48, Type: StructProperty)

    void SET_bScoreEnemies(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bScoreEncounterGoals(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    void SET_bScoreWorldGoals(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:2 (Size: 0x1, Type: BoolProperty)
    void SET_bScoreSpecificAssignments(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:3 (Size: 0x1, Type: BoolProperty)
    void SET_AssignmentIDs(const TArray<FFortAIAssignmentIdentifier>& Value) { Write<TArray<FFortAIAssignmentIdentifier>>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x10, Type: ArrayProperty)
    void SET_ProhibitedAssignmentIDs(const TArray<FFortAIAssignmentIdentifier>& Value) { Write<TArray<FFortAIAssignmentIdentifier>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    void SET_GoalActorTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x48, Type: StructProperty)
};

// Size: 0x8b8
class UFortQueryTest_BuildingCriteria : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue ScoreForGroundSupportedFloor() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForBeingGroundSupported() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForTraps() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForWalls() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForNavigableOpening() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x38, Type: StructProperty)
    FFortAIAssignmentIdentifier RootAssignmentID() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x30, Type: StructProperty)
    FAIDataProviderBoolValue bPreferCloserToRootAssignment() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForDistanceFromClosestRootAssignmentGoal() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MinDistanceForDistanceScoring() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxDistanceForDistanceScoring() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxHealthScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bPreferHigherHealth() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ClampMaxHealthValue() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ClampMinHealthValue() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bPreferHigherHealthPercentage() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxHealthPercentageScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bWantsBuildingRepairableByOwner() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RepairableBuildingScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue NotRepairableBuildingScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue NeedsRepairBuildingScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DoesntNeedsRepairBuildingScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bWantsDamagedByFriendly() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByFriendlyMaxLifespan() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByFriendlyMinDamage() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByFriendlyScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bWantsDamagedByEnemy() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByEnemyMaxLifespan() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByEnemyMinDamage() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x848); } // 0x848 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByEnemyScore() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x38, Type: StructProperty)

    void SET_ScoreForGroundSupportedFloor(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
    void SET_ScoreForBeingGroundSupported(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    void SET_ScoreForTraps(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    void SET_ScoreForWalls(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x38, Type: StructProperty)
    void SET_ScoreForNavigableOpening(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x38, Type: StructProperty)
    void SET_RootAssignmentID(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x30, Type: StructProperty)
    void SET_bPreferCloserToRootAssignment(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x38, Type: StructProperty)
    void SET_ScoreForDistanceFromClosestRootAssignmentGoal(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x38, Type: StructProperty)
    void SET_MinDistanceForDistanceScoring(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x38, Type: StructProperty)
    void SET_MaxDistanceForDistanceScoring(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x38, Type: StructProperty)
    void SET_MaxHealthScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x38, Type: StructProperty)
    void SET_bPreferHigherHealth(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x38, Type: StructProperty)
    void SET_ClampMaxHealthValue(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x38, Type: StructProperty)
    void SET_ClampMinHealthValue(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x38, Type: StructProperty)
    void SET_bPreferHigherHealthPercentage(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x38, Type: StructProperty)
    void SET_MaxHealthPercentageScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x38, Type: StructProperty)
    void SET_bWantsBuildingRepairableByOwner(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x38, Type: StructProperty)
    void SET_RepairableBuildingScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x38, Type: StructProperty)
    void SET_NotRepairableBuildingScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x38, Type: StructProperty)
    void SET_NeedsRepairBuildingScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x38, Type: StructProperty)
    void SET_DoesntNeedsRepairBuildingScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x38, Type: StructProperty)
    void SET_bWantsDamagedByFriendly(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x38, Type: StructProperty)
    void SET_DamagedByFriendlyMaxLifespan(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x38, Type: StructProperty)
    void SET_DamagedByFriendlyMinDamage(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x38, Type: StructProperty)
    void SET_DamagedByFriendlyScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x38, Type: StructProperty)
    void SET_bWantsDamagedByEnemy(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x38, Type: StructProperty)
    void SET_DamagedByEnemyMaxLifespan(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x38, Type: StructProperty)
    void SET_DamagedByEnemyMinDamage(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x848, Value); } // 0x848 (Size: 0x38, Type: StructProperty)
    void SET_DamagedByEnemyScore(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x38, Type: StructProperty)
};

// Size: 0x268
class UFortQueryTest_CanAttackTarget : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x268
class UFortQueryTest_CanBeDamaged : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x228
class UFortQueryTest_CanHitWithGameplayAbility : public UEnvQueryTest
{
public:
    UClass* AIsUsingAbility() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* AbilityTargets() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer GameplayAbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x20, Type: StructProperty)

    void SET_AIsUsingAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_AbilityTargets(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
    void SET_GameplayAbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x20, Type: StructProperty)
};

// Size: 0x240
class UFortQueryTest_CurieState : public UEnvQueryTest
{
public:
    FGameplayTagQuery CurieStateQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)

    void SET_CurieStateQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x200
class UFortQueryTest_DecoyDistance : public UEnvQueryTest
{
public:
    UClass* DistanceTo() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)

    void SET_DistanceTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x208
class UFortQueryTest_DeltaDistance : public UEnvQueryTest
{
public:
    UClass* LocationProviderContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    bool bUseDistance2D() const { return Read<bool>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x1, Type: BoolProperty)

    void SET_LocationProviderContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_bUseDistance2D(const bool& Value) { Write<bool>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x208
class UFortQueryTest_DistanceToActorBound : public UEnvQueryTest
{
public:
    UClass* DistanceTo() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    bool bUse2DDistance() const { return Read<bool>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x1, Type: BoolProperty)

    void SET_DistanceTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_bUse2DDistance(const bool& Value) { Write<bool>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1f8
class UFortQueryTest_DistanceToIndestructibleBuilding : public UEnvQueryTest
{
public:
};

// Size: 0x200
class UFortQueryTest_EnvironmentalDanger : public UEnvQueryTest
{
public:
    bool bUse3DBoundsCheck() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    FGameplayTag DangerSourceActorRegistryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: StructProperty)

    void SET_bUse3DBoundsCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    void SET_DangerSourceActorRegistryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: StructProperty)
};

// Size: 0x208
class UFortQueryTest_GameplayTagsPerDifficulty : public UEnvQueryTest
{
public:
    TArray<FFortGameplayTagQueryPerDifficulty> TagQueriesPerDifficulty() const { return Read<TArray<FFortGameplayTagQueryPerDifficulty>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)

    void SET_TagQueriesPerDifficulty(const TArray<FFortGameplayTagQueryPerDifficulty>& Value) { Write<TArray<FFortGameplayTagQueryPerDifficulty>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x280
class UFortQueryTest_GoalActorDot : public UFortQueryTest_GoalBase
{
public:
    UClass* LineATo() const { return Read<UClass*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ClassProperty)
    UClass* LineBTo() const { return Read<UClass*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ClassProperty)
    uint8_t TestMode() const { return Read<uint8_t>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x1, Type: EnumProperty)
    bool bAbsoluteValue() const { return Read<bool>(uintptr_t(this) + 0x279); } // 0x279 (Size: 0x1, Type: BoolProperty)

    void SET_LineATo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ClassProperty)
    void SET_LineBTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ClassProperty)
    void SET_TestMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x1, Type: EnumProperty)
    void SET_bAbsoluteValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x279, Value); } // 0x279 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x268
class UFortQueryTest_GoalActorTimeSinceSpawn : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x2a0
class UFortQueryTest_GoalDiscouragement : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderBoolValue DisableDiscouragementWhenUndermining() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)

    void SET_DisableDiscouragementWhenUndermining(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
};

// Size: 0x280
class UFortQueryTest_GoalDistance : public UFortQueryTest_GoalBase
{
public:
    uint8_t DistanceMode() const { return Read<uint8_t>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: EnumProperty)
    UClass* DistanceTo() const { return Read<UClass*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EEnvTestDistance> TestMode() const { return Read<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x1, Type: ByteProperty)

    void SET_DistanceMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: EnumProperty)
    void SET_DistanceTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ClassProperty)
    void SET_TestMode(const TEnumAsByte<EEnvTestDistance>& Value) { Write<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x290
class UFortQueryTest_GoalDistanceRanges : public UFortQueryTest_GoalBase
{
public:
    uint8_t DistanceMode() const { return Read<uint8_t>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: EnumProperty)
    UClass* DistanceTo() const { return Read<UClass*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EEnvTestDistance> ScreeningTestMode() const { return Read<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvTestDistance> TestMode() const { return Read<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x279); } // 0x279 (Size: 0x1, Type: ByteProperty)
    TArray<FGoalDistanceData> GoalDistanceDataRanges() const { return Read<TArray<FGoalDistanceData>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)

    void SET_DistanceMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: EnumProperty)
    void SET_DistanceTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ClassProperty)
    void SET_ScreeningTestMode(const TEnumAsByte<EEnvTestDistance>& Value) { Write<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x1, Type: ByteProperty)
    void SET_TestMode(const TEnumAsByte<EEnvTestDistance>& Value) { Write<TEnumAsByte<EEnvTestDistance>>(uintptr_t(this) + 0x279, Value); } // 0x279 (Size: 0x1, Type: ByteProperty)
    void SET_GoalDistanceDataRanges(const TArray<FGoalDistanceData>& Value) { Write<TArray<FGoalDistanceData>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x268
class UFortQueryTest_GoalFrustrationDiscouragement : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x2c0
class UFortQueryTest_GoalGameplayTags : public UFortQueryTest_GoalBase
{
public:
    bool bShouldLookupQueryByTag() const { return Read<bool>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery TagQueryToMatch() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x48, Type: StructProperty)
    FGameplayTag QueryLookupTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x4, Type: StructProperty)
    bool bShouldPassWhenQueryNotFound() const { return Read<bool>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x1, Type: BoolProperty)
    bool bRequireAllProvidedTagQueriesPass() const { return Read<bool>(uintptr_t(this) + 0x2bd); } // 0x2bd (Size: 0x1, Type: BoolProperty)

    void SET_bShouldLookupQueryByTag(const bool& Value) { Write<bool>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: BoolProperty)
    void SET_TagQueryToMatch(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x48, Type: StructProperty)
    void SET_QueryLookupTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x4, Type: StructProperty)
    void SET_bShouldPassWhenQueryNotFound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x1, Type: BoolProperty)
    void SET_bRequireAllProvidedTagQueriesPass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2bd, Value); } // 0x2bd (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2e8
class UFortQueryTest_GoalMarkedByPlayer : public UFortQueryTest_GoalBase
{
public:
    FGameplayTagQuery OwnerTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x48, Type: StructProperty)
    FAIDataProviderBoolValue OnlyConverterMarkedTargets() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x38, Type: StructProperty)

    void SET_OwnerTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x48, Type: StructProperty)
    void SET_OnlyConverterMarkedTargets(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x38, Type: StructProperty)
};

// Size: 0x270
class UFortQueryTest_GoalNumberOfAIAssigned : public UFortQueryTest_GoalBase
{
public:
    uint8_t TypeOfMatchToCount() const { return Read<uint8_t>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: EnumProperty)

    void SET_TypeOfMatchToCount(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x268
class UFortQueryTest_GoalOverallDamageCaused : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x270
class UFortQueryTest_GoalPickupFilter : public UFortQueryTest_GoalBase
{
public:
    float MaxLifetime() const { return Read<float>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x4, Type: FloatProperty)
    uint8_t RequiredPickupSpawnSource() const { return Read<uint8_t>(uintptr_t(this) + 0x26c); } // 0x26c (Size: 0x1, Type: EnumProperty)

    void SET_MaxLifetime(const float& Value) { Write<float>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x4, Type: FloatProperty)
    void SET_RequiredPickupSpawnSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x26c, Value); } // 0x26c (Size: 0x1, Type: EnumProperty)
};

// Size: 0x2a0
class UFortQueryTest_GoalProject : public UFortQueryTest_GoalBase
{
public:
    FEnvTraceData ProjectionData() const { return Read<FEnvTraceData>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)

    void SET_ProjectionData(const FEnvTraceData& Value) { Write<FEnvTraceData>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
};

// Size: 0x380
class UFortQueryTest_GoalStickiness : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue StartValueForGoal() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue EndValueForGoal() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TimeBeforeValueLerp() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValueLerpDuration() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue ApplyStickinessToAllGoalsWithSameActor() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x38, Type: StructProperty)

    void SET_StartValueForGoal(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
    void SET_EndValueForGoal(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    void SET_TimeBeforeValueLerp(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    void SET_ValueLerpDuration(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x38, Type: StructProperty)
    void SET_ApplyStickinessToAllGoalsWithSameActor(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x38, Type: StructProperty)
};

// Size: 0x268
class UFortQueryTest_GoalType : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x268
class UFortQueryTest_GoalWithinTetheredBounds : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x208
class UFortQueryTest_HasNearbyBuildings : public UEnvQueryTest
{
public:
    bool bIncludeCenter() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x0) & 1; } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    bool bIncludeFloors() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x1) & 1; } // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    bool bIncludeFloorsAbove() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x2) & 1; } // 0x1f8:2 (Size: 0x1, Type: BoolProperty)
    bool bIncludeWalls() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x3) & 1; } // 0x1f8:3 (Size: 0x1, Type: BoolProperty)
    int32_t ExtentXY() const { return Read<int32_t>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: IntProperty)
    int32_t ExtentZ() const { return Read<int32_t>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: IntProperty)

    void SET_bIncludeCenter(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeFloors(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeFloorsAbove(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeWalls(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:3 (Size: 0x1, Type: BoolProperty)
    void SET_ExtentXY(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: IntProperty)
    void SET_ExtentZ(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: IntProperty)
};

// Size: 0x238
class UFortQueryTest_HasNearbyEncounterGoals : public UEnvQueryTest
{
public:
    bool bOnlyActiveEncounters() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x0) & 1; } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue TestDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)

    void SET_bOnlyActiveEncounters(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    void SET_TestDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
};

// Size: 0x200
class UFortQueryTest_Health : public UEnvQueryTest
{
public:
    bool bUsePercentHealth() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)

    void SET_bUsePercentHealth(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2f0
class UFortQueryTest_HealthAndShield : public UEnvQueryTest
{
public:
    bool bConsiderHealth() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue HealthMin() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue HealthMax() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x38, Type: StructProperty)
    bool bHealthAsPercent() const { return Read<bool>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x1, Type: BoolProperty)
    bool bConsiderShield() const { return Read<bool>(uintptr_t(this) + 0x271); } // 0x271 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue ShieldMin() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ShieldMax() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x38, Type: StructProperty)
    bool bShieldAsPercent() const { return Read<bool>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x1, Type: BoolProperty)

    void SET_bConsiderHealth(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    void SET_HealthMin(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
    void SET_HealthMax(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x38, Type: StructProperty)
    void SET_bHealthAsPercent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x1, Type: BoolProperty)
    void SET_bConsiderShield(const bool& Value) { Write<bool>(uintptr_t(this) + 0x271, Value); } // 0x271 (Size: 0x1, Type: BoolProperty)
    void SET_ShieldMin(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x38, Type: StructProperty)
    void SET_ShieldMax(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x38, Type: StructProperty)
    void SET_bShieldAsPercent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x238
class UFortQueryTest_HotspotSlotOrientation : public UEnvQueryTest
{
public:
    UClass* FaceToward() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue DotThreshold() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)

    void SET_FaceToward(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_DotThreshold(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
};

// Size: 0x200
class UFortQueryTest_HotspotSlotState : public UEnvQueryTest
{
public:
    uint8_t SlotState() const { return Read<uint8_t>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: EnumProperty)

    void SET_SlotState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1f8
class UFortQueryTest_InfluenceScore : public UEnvQueryTest
{
public:
};

// Size: 0x1f8
class UFortQueryTest_InsideAIBotLeash : public UEnvQueryTest
{
public:
};

// Size: 0x1f8
class UFortQueryTest_InsideAthenaLeash : public UEnvQueryTest
{
public:
};

// Size: 0x240
class UFortQueryTest_InsideAthenaSafeZone : public UEnvQueryTest
{
public:
    bool bUseCurrentSafeZoneIndicatorRadius() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderIntValue SafeZoneIndex() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)
    bool bNextSafeZone() const { return Read<bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: BoolProperty)

    void SET_bUseCurrentSafeZoneIndicatorRadius(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    void SET_SafeZoneIndex(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
    void SET_bNextSafeZone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1f8
class UFortQueryTest_InsideBuilding : public UEnvQueryTest
{
public:
};

// Size: 0x200
class UFortQueryTest_InsideWater : public UEnvQueryTest
{
public:
    float TestRadius() const { return Read<float>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: FloatProperty)

    void SET_TestRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x240
class UFortQueryTest_IsCloseToHotspotSlot : public UEnvQueryTest
{
public:
    UClass* HotspotClass() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue Radius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x38, Type: StructProperty)
    bool bIgnoreItemsWithSlotData() const { return Read<bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: BoolProperty)

    void SET_HotspotClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_Radius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x38, Type: StructProperty)
    void SET_bIgnoreItemsWithSlotData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x200
class UFortQueryTest_IsCloseToPatrolWard : public UEnvQueryTest
{
public:
    uint8_t WardEffectTypeFilter() const { return Read<uint8_t>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: EnumProperty)

    void SET_WardEffectTypeFilter(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x230
class UFortQueryTest_IsGoalForAssignment : public UEnvQueryTest
{
public:
    bool bRetrieveRootAssignmentFromOwner() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    FFortAIAssignmentIdentifier RootAssignmentID() const { return Read<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x30, Type: StructProperty)

    void SET_bRetrieveRootAssignmentFromOwner(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    void SET_RootAssignmentID(const FFortAIAssignmentIdentifier& Value) { Write<FFortAIAssignmentIdentifier>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x30, Type: StructProperty)
};

// Size: 0x320
class UFortQueryTest_IsGoalHostile : public UFortQueryTest_GoalBase
{
public:
    FGameplayTagQuery OwnerTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery EnemyPawnTagsToConsider() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer BuildingTagsToConsider() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x20, Type: StructProperty)
    bool bConsiderDefenders() const { return Read<bool>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x1, Type: BoolProperty)

    void SET_OwnerTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x48, Type: StructProperty)
    void SET_EnemyPawnTagsToConsider(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x48, Type: StructProperty)
    void SET_BuildingTagsToConsider(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x20, Type: StructProperty)
    void SET_bConsiderDefenders(const bool& Value) { Write<bool>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x250
class UFortQueryTest_IsInLeaderLOS : public UEnvQueryTest
{
public:
    FGameplayTagQuery OwnerTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    bool bRequireLOSRayCast() const { return Read<bool>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x1, Type: BoolProperty)
    float RayCastLeaderVerticalOffset() const { return Read<float>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: FloatProperty)
    float RayCastItemVerticalOffset() const { return Read<float>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: FloatProperty)
    float MinDotProduct() const { return Read<float>(uintptr_t(this) + 0x24c); } // 0x24c (Size: 0x4, Type: FloatProperty)

    void SET_OwnerTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    void SET_bRequireLOSRayCast(const bool& Value) { Write<bool>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x1, Type: BoolProperty)
    void SET_RayCastLeaderVerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: FloatProperty)
    void SET_RayCastItemVerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: FloatProperty)
    void SET_MinDotProduct(const float& Value) { Write<float>(uintptr_t(this) + 0x24c, Value); } // 0x24c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3c0
class UFortQueryTest_IsObstructed : public UEnvQueryTest_Trace
{
public:
    FAIDataProviderBoolValue OverrideContextLocationXWithItemLocationX() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationYWithItemLocationY() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationZWithItemLocationZ() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideItemLocationZWithContextLocationZ() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x38, Type: StructProperty)

    void SET_OverrideContextLocationXWithItemLocationX(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x38, Type: StructProperty)
    void SET_OverrideContextLocationYWithItemLocationY(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x38, Type: StructProperty)
    void SET_OverrideContextLocationZWithItemLocationZ(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x38, Type: StructProperty)
    void SET_OverrideItemLocationZWithContextLocationZ(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x38, Type: StructProperty)
};

// Size: 0x388
class UFortQueryTest_IsObstructedOverlap : public UEnvQueryTest_Trace
{
public:
    FAIDataProviderBoolValue OverrideContextLocationXWithItemLocationX() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationYWithItemLocationY() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationZWithItemLocationZ() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x38, Type: StructProperty)

    void SET_OverrideContextLocationXWithItemLocationX(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x38, Type: StructProperty)
    void SET_OverrideContextLocationYWithItemLocationY(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x38, Type: StructProperty)
    void SET_OverrideContextLocationZWithItemLocationZ(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x38, Type: StructProperty)
};

// Size: 0x260
class UFortQueryTest_MissionGameplayTagMatch : public UEnvQueryTest
{
public:
    FGameplayTagQuery MissionPlacementActorTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer GameplayTagsToMatch() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x20, Type: StructProperty)

    void SET_MissionPlacementActorTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    void SET_GameplayTagsToMatch(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x20, Type: StructProperty)
};

// Size: 0x240
class UFortQueryTest_MissionSameMap : public UEnvQueryTest
{
public:
    FGameplayTagQuery MissionPlacementActorTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)

    void SET_MissionPlacementActorTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x200
class UFortQueryTest_NavGraphDistance : public UEnvQueryTest
{
public:
    UClass* DistanceTo() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)

    void SET_DistanceTo(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x210
class UFortQueryTest_OnFlatSurface : public UEnvQueryTest
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    float ToleranceZ() const { return Read<float>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: FloatProperty)
    float TraceOffsetUp() const { return Read<float>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: FloatProperty)
    float TraceOffsetDown() const { return Read<float>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: FloatProperty)
    uint32_t NumberOfIteration() const { return Read<uint32_t>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: UInt32Property)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    void SET_ToleranceZ(const float& Value) { Write<float>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: FloatProperty)
    void SET_TraceOffsetUp(const float& Value) { Write<float>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: FloatProperty)
    void SET_TraceOffsetDown(const float& Value) { Write<float>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: FloatProperty)
    void SET_NumberOfIteration(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x218
class UFortQueryTest_OnFlatSurfaceNoNavMesh : public UEnvQueryTest
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    float ZTolerance() const { return Read<float>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: FloatProperty)
    float NormalTolerance() const { return Read<float>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: FloatProperty)
    float TraceOffset() const { return Read<float>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> ActorClassesToIgnoreInTrace() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x10, Type: ArrayProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    void SET_ZTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: FloatProperty)
    void SET_NormalTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: FloatProperty)
    void SET_TraceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: FloatProperty)
    void SET_ActorClassesToIgnoreInTrace(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2c0
class UFortQueryTest_PathfindingBatch : public UEnvQueryTest_PathfindingBatch
{
public:
    FGameplayTag NavFilterTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x4, Type: StructProperty)

    void SET_NavFilterTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x270
class UFortQueryTest_PawnHealth : public UFortQueryTest_GoalBase
{
public:
    bool bUsePercentHealth() const { return Read<bool>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: BoolProperty)

    void SET_bUsePercentHealth(const bool& Value) { Write<bool>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x268
class UFortQueryTest_PawnIsDBNO : public UFortQueryTest_GoalBase
{
public:
};

// Size: 0x208
class UFortQueryTest_PerceptionAge : public UEnvQueryTest
{
public:
    TEnumAsByte<ECorePerceptionTypes> Sense() const { return Read<TEnumAsByte<ECorePerceptionTypes>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    UClass* SenseClass() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)

    void SET_Sense(const TEnumAsByte<ECorePerceptionTypes>& Value) { Write<TEnumAsByte<ECorePerceptionTypes>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    void SET_SenseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x478
class UFortQueryTest_PerceptionAll : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue SenseScores() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x150, Type: StructProperty)
    TMap<UClass*, FAIDataProviderFloatValue> AdditionalSenseScores() const { return Read<TMap<UClass*, FAIDataProviderFloatValue>>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    FAIDataProviderFloatValue MinSenseAge() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxSenseAge() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x38, Type: StructProperty)

    void SET_SenseScores(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x150, Type: StructProperty)
    void SET_AdditionalSenseScores(const TMap<UClass*, FAIDataProviderFloatValue>& Value) { Write<TMap<UClass*, FAIDataProviderFloatValue>>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    void SET_MinSenseAge(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x38, Type: StructProperty)
    void SET_MaxSenseAge(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x38, Type: StructProperty)
};

// Size: 0x208
class UFortQueryTest_PerceptionExists : public UEnvQueryTest
{
public:
    TEnumAsByte<ECorePerceptionTypes> Sense() const { return Read<TEnumAsByte<ECorePerceptionTypes>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    UClass* SenseClass() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)

    void SET_Sense(const TEnumAsByte<ECorePerceptionTypes>& Value) { Write<TEnumAsByte<ECorePerceptionTypes>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    void SET_SenseClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x380
class UFortQueryTest_PickupDropper : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue ValueConverterDroppedPickup() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValueOtherDroppedPickupInitial() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValueOtherDroppedPickupFinal() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TimeOtherDroppedPickupFinal() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LerpFromInitialToFinal() const { return Read<FAIDataProviderBoolValue>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x38, Type: StructProperty)

    void SET_ValueConverterDroppedPickup(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
    void SET_ValueOtherDroppedPickupInitial(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x38, Type: StructProperty)
    void SET_ValueOtherDroppedPickupFinal(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x38, Type: StructProperty)
    void SET_TimeOtherDroppedPickupFinal(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x38, Type: StructProperty)
    void SET_LerpFromInitialToFinal(const FAIDataProviderBoolValue& Value) { Write<FAIDataProviderBoolValue>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x38, Type: StructProperty)
};

// Size: 0x220
class UFortQueryTest_PointInBuildingFoundation : public UEnvQueryTest
{
public:
    UClass* BuildingFoundationContext() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* BuildingFoundationClass() const { return Read<UClass*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ClassProperty)
    FVector BoundingBoxScale() const { return Read<FVector>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x18, Type: StructProperty)

    void SET_BuildingFoundationContext(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
    void SET_BuildingFoundationClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ClassProperty)
    void SET_BoundingBoxScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x18, Type: StructProperty)
};

// Size: 0x388
class UFortQueryTest_PrimaryAssignment : public UFortQueryTest_GoalBase
{
public:
    bool bUseItemActorLocation() const { return Read<bool>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue DistanceClose() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DistanceFar() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PercentValueClose() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PercentValueRegular() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PercentValueFar() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x38, Type: StructProperty)

    void SET_bUseItemActorLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: BoolProperty)
    void SET_DistanceClose(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x38, Type: StructProperty)
    void SET_DistanceFar(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x38, Type: StructProperty)
    void SET_PercentValueClose(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x38, Type: StructProperty)
    void SET_PercentValueRegular(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x38, Type: StructProperty)
    void SET_PercentValueFar(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x38, Type: StructProperty)
};

// Size: 0x1f8
class UFortQueryTest_ProjectOnNavMesh : public UEnvQueryTest
{
public:
};

// Size: 0x200
class UFortQueryTest_Random : public UEnvQueryTest
{
public:
    bool bUseRandomSeedForAI() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x0) & 1; } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    bool bUseRandomSeedForOthers() const { return (Read<uint8_t>(uintptr_t(this) + 0x1f8) >> 0x1) & 1; } // 0x1f8:1 (Size: 0x1, Type: BoolProperty)

    void SET_bUseRandomSeedForAI(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseRandomSeedForOthers(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1f8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1f8, B); } // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x250
class UFortQueryTest_TowardNextAthenaSafeZone : public UEnvQueryTest
{
public:
    FAIDataProviderIntValue SafeZoneIndex() const { return Read<FAIDataProviderIntValue>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    bool bCheckAcceptanceAngleTowardNextCenter() const { return Read<bool>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x1, Type: BoolProperty)
    float AcceptanceAngleTowardNextCenter() const { return Read<float>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x4, Type: FloatProperty)
    TArray<int32_t> ExclusionSafeZoneIndex() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x10, Type: ArrayProperty)

    void SET_SafeZoneIndex(const FAIDataProviderIntValue& Value) { Write<FAIDataProviderIntValue>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    void SET_bCheckAcceptanceAngleTowardNextCenter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x1, Type: BoolProperty)
    void SET_AcceptanceAngleTowardNextCenter(const float& Value) { Write<float>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x4, Type: FloatProperty)
    void SET_ExclusionSafeZoneIndex(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x318
class UFortQueryTest_ValidSurface : public UEnvQueryTest
{
public:
    FAIDataProviderFloatValue Radius() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TraceOffsetUp() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TraceOffsetDown() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> TraceCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x1, Type: ByteProperty)
    FAIDataProviderFloatValue FlatSurfaceToleranceZ() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x38, Type: StructProperty)
    TArray<TSoftObjectPtr<UPhysicalMaterial*>> SurfaceMaterials() const { return Read<TArray<TSoftObjectPtr<UPhysicalMaterial*>>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    bool bAreSurfaceMaterialsValid() const { return Read<bool>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x1, Type: BoolProperty)
    TArray<TSoftClassPtr> ValidHitActorClasses() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftClassPtr> InvalidHitActorClasses() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: ArrayProperty)

    void SET_Radius(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x38, Type: StructProperty)
    void SET_TraceOffsetUp(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x38, Type: StructProperty)
    void SET_TraceOffsetDown(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x38, Type: StructProperty)
    void SET_TraceCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x1, Type: ByteProperty)
    void SET_FlatSurfaceToleranceZ(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x38, Type: StructProperty)
    void SET_SurfaceMaterials(const TArray<TSoftObjectPtr<UPhysicalMaterial*>>& Value) { Write<TArray<TSoftObjectPtr<UPhysicalMaterial*>>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_bAreSurfaceMaterialsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x1, Type: BoolProperty)
    void SET_ValidHitActorClasses(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    void SET_InvalidHitActorClasses(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x220
class UFortQueryTest_WithinHotfixVolumeBounds : public UEnvQueryTest
{
public:
    UDataTable* BoundsTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    FVector BoundsExtentBuffer() const { return Read<FVector>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x18, Type: StructProperty)
    bool bXYOnly() const { return Read<bool>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x1, Type: BoolProperty)

    void SET_BoundsTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundsExtentBuffer(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x18, Type: StructProperty)
    void SET_bXYOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x260
class UFortQueryTest_WithinTaggedArea : public UEnvQueryTest
{
public:
    FGameplayTagQuery TagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    FVector AreaExtentBuffer() const { return Read<FVector>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x18, Type: StructProperty)
    bool bAssumeInfiniteHeightForArea() const { return Read<bool>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x1, Type: BoolProperty)

    void SET_TagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    void SET_AreaExtentBuffer(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x18, Type: StructProperty)
    void SET_bAssumeInfiniteHeightForArea(const bool& Value) { Write<bool>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x118
class UFortAthenaBTTask_BotAmbushPlayer : public UBTTask_Wait
{
public:
    float FacingPrecision() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float WeaponCooldown() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bClearBlackboardOnFinished() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    FBlackboardKeySelector TargetedPlayerKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector MaxLocationErrorKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector MinLocationErrorKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)

    void SET_FacingPrecision(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_WeaponCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_bClearBlackboardOnFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_TargetedPlayerKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_MaxLocationErrorKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_MinLocationErrorKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x70
class UFortAthenaBTDecorator_BehaviorControls : public UBTDecorator
{
public:
    uint8_t BehaviorTreeBranch() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)

    void SET_BehaviorTreeBranch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xd8
class UFortAthenaAIBotEvaluator_AimDownSight : public UFortAthenaAIBotEvaluator
{
public:
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName ThrowableAttacksName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName UrgentMovementName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    bool bSkipTargetChecks() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_ThrowableAttacksName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_UrgentMovementName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_bSkipTargetChecks(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x208
class UFortAthenaAIBotEvaluator_Ambush : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName LastKnownPositionName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName DestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName AggressivenessName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)

    void SET_LastKnownPositionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_DestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_MoveToDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_AggressivenessName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
};

// Size: 0x1b8
class UFortAthenaAIBotEvaluator_Attack : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)

    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_MoveToDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
};

// Size: 0x1c8
class UFortAthenaAIBotEvaluator_AvoidThreat : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName AvoidThreatKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName AvoidThreatMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName AvoidThreatDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    AActor* CurrentThreatActorAvoiding() const { return Read<AActor*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet() const { return Read<UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)

    void SET_AvoidThreatKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_AvoidThreatMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_AvoidThreatDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_CurrentThreatActorAvoiding(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheEMDigestedSkillSet(const UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*& Value) { Write<UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x258
class UFortAthenaAIBotEvaluator_Bunker : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName BuildExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName HealingStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer DangerTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x20, Type: StructProperty)

    void SET_BuildExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_HealingStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_DangerTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x20, Type: StructProperty)
};

// Size: 0xb0
class UFortAthenaAIBotEvaluator_CanMove : public UFortAthenaAIBotEvaluator
{
public:
    FName CanMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)

    void SET_CanMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
};

// Size: 0xf8
class UFortAthenaAIBotEvaluator_CharacterLaunched : public UFortAthenaAIBotEvaluator
{
public:
    bool bSteerInSameDirectionAsLaunchVelocity() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    FName CharacterLaunchedExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName SteerDirectionKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FVector LastLaunchVelocity() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_BehaviorTreeControl* CachedBehaviorControlsRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_BehaviorTreeControl*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    float LastZiplineTimestamp() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)

    void SET_bSteerInSameDirectionAsLaunchVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_CharacterLaunchedExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_SteerDirectionKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_LastLaunchVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_CachedMovementSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedBehaviorControlsRuntimeParameters(const UFortAthenaAIRuntimeParameters_BehaviorTreeControl*& Value) { Write<UFortAthenaAIRuntimeParameters_BehaviorTreeControl*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_LastZiplineTimestamp(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x310
class UFortAthenaAIBotEvaluator_Conversation : public UFortAthenaAIBotEvaluator
{
public:
    FName IsInConversationStateName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    TArray<FName> ExecutionStatusesToCheckedToAvoidStoppingWhenNearActorNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> ExecutionStatusesToCheckForAllowToAvoidStoppingWhenNearActorNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> MovementStatusesToCheckedToAvoidStoppingWhenNearActorNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    bool bForceStopIfNoPlayerNearby() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)
    bool bSetControllerFocusOnParticipantFocus() const { return Read<bool>(uintptr_t(this) + 0x111); } // 0x111 (Size: 0x1, Type: BoolProperty)
    FScalableFloat HolsterWeaponOnConversationEnter() const { return Read<FScalableFloat>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery RequiredTagQueryToStopNearActor() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x48, Type: StructProperty)
    FScalableFloat ConversationTimeout() const { return Read<FScalableFloat>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x28, Type: StructProperty)
    FScalableFloat ConversationTimeoutWithOtherPlayerNearby() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BanTimeAfterTimeout() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x28, Type: StructProperty)
    UFortAthenaAIRuntimeParameters_Conversation* ConversationRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_Conversation*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorToFocus() const { return Read<AActor*>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x8, Type: ObjectProperty)

    void SET_IsInConversationStateName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionStatusesToCheckedToAvoidStoppingWhenNearActorNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_ExecutionStatusesToCheckForAllowToAvoidStoppingWhenNearActorNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_MovementStatusesToCheckedToAvoidStoppingWhenNearActorNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_bForceStopIfNoPlayerNearby(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
    void SET_bSetControllerFocusOnParticipantFocus(const bool& Value) { Write<bool>(uintptr_t(this) + 0x111, Value); } // 0x111 (Size: 0x1, Type: BoolProperty)
    void SET_HolsterWeaponOnConversationEnter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x28, Type: StructProperty)
    void SET_RequiredTagQueryToStopNearActor(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x48, Type: StructProperty)
    void SET_ConversationTimeout(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x28, Type: StructProperty)
    void SET_ConversationTimeoutWithOtherPlayerNearby(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x28, Type: StructProperty)
    void SET_BanTimeAfterTimeout(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x28, Type: StructProperty)
    void SET_ConversationRuntimeParameters(const UFortAthenaAIRuntimeParameters_Conversation*& Value) { Write<UFortAthenaAIRuntimeParameters_Conversation*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorToFocus(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x388
class UFortAthenaAIBotEvaluator_Converted : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName ShouldMoveTowardsConverterName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName ShouldTeleportTowardsConverterName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName ConvertedAllowPatrolAroundName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName ConvertedAllowScanAroundWhenWaitingName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FName ConvertedDestinationName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName CrouchExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FVector TeleportLocationProjectionExtent() const { return Read<FVector>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x18, Type: StructProperty)
    FVector MovingFromLosLocationProjectionExtent() const { return Read<FVector>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x18, Type: StructProperty)
    FScalableFloat AmountOfTimesNonHostilePawnNeedsToBeDamagedForTargeting() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeToTrackDamagedActors() const { return Read<FScalableFloat>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat NearbyPlayerDistanceForTeleportTowardsConverter() const { return Read<FScalableFloat>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat PlayerFOVForNearbyPlayersVisibility() const { return Read<FScalableFloat>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x28, Type: StructProperty)
    UEnvQuery* TeleportToConverterQueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> TeleportToConverterRunMode() const { return Read<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x1, Type: ByteProperty)
    TArray<FMimicConverterAbilityData> AbilitiesToMimic() const { return Read<TArray<FMimicConverterAbilityData>>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagQuery RequiredTagQueryToTargetConverterDamagedPawn() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x48, Type: StructProperty)
    FValueOrBBKey_Bool UpdateConvertedDestinationWhileUsingNavLinks() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0xc, Type: StructProperty)
    AFortPawn* ConverterPawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_AIBotConvert* CachedAIBotConvertParameters() const { return Read<UFortAthenaAIRuntimeParameters_AIBotConvert*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)

    void SET_ShouldMoveTowardsConverterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_ShouldTeleportTowardsConverterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_ConvertedAllowPatrolAroundName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_ConvertedAllowScanAroundWhenWaitingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_ConvertedDestinationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_CrouchExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_TeleportLocationProjectionExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x18, Type: StructProperty)
    void SET_MovingFromLosLocationProjectionExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x18, Type: StructProperty)
    void SET_AmountOfTimesNonHostilePawnNeedsToBeDamagedForTargeting(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    void SET_TimeToTrackDamagedActors(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x28, Type: StructProperty)
    void SET_NearbyPlayerDistanceForTeleportTowardsConverter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x28, Type: StructProperty)
    void SET_PlayerFOVForNearbyPlayersVisibility(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x28, Type: StructProperty)
    void SET_TeleportToConverterQueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportToConverterRunMode(const TEnumAsByte<EEnvQueryRunMode>& Value) { Write<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x1, Type: ByteProperty)
    void SET_AbilitiesToMimic(const TArray<FMimicConverterAbilityData>& Value) { Write<TArray<FMimicConverterAbilityData>>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x10, Type: ArrayProperty)
    void SET_RequiredTagQueryToTargetConverterDamagedPawn(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x48, Type: StructProperty)
    void SET_UpdateConvertedDestinationWhileUsingNavLinks(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0xc, Type: StructProperty)
    void SET_ConverterPawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedAIBotConvertParameters(const UFortAthenaAIRuntimeParameters_AIBotConvert*& Value) { Write<UFortAthenaAIRuntimeParameters_AIBotConvert*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd0
class UFortAthenaAIBotEvaluator_DanceOnKill : public UFortAthenaAIBotEvaluator
{
public:
    FName LastKillPositionKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName LastKillTimeKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName LastKillWasABotKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName PlayEmoteExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotEmoteDigestedSkillSet* CacheEmoteDigestedSkillSet() const { return Read<UFortAthenaAIBotEmoteDigestedSkillSet*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_LastKillPositionKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_LastKillTimeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_LastKillWasABotKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_PlayEmoteExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_CacheEmoteDigestedSkillSet(const UFortAthenaAIBotEmoteDigestedSkillSet*& Value) { Write<UFortAthenaAIBotEmoteDigestedSkillSet*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x148
class UFortAthenaAIBotEvaluator_DangerDetection : public UFortAthenaAIBotEvaluator_TagQuery
{
public:
    UClass* DangerNavAreaClass() const { return Read<UClass*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ClassProperty)
    float TimeToCheckForDangerAfterValidQuery() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    float MaxRadiusToSearchForSafePlace() const { return Read<float>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: FloatProperty)
    FName DangerZoneDetectedExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: NameProperty)
    FName DangerZoneDetectedSafeLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    UAthenaAIServiceZoneManager* CacheZoneManager() const { return Read<UAthenaAIServiceZoneManager*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)

    void SET_DangerNavAreaClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ClassProperty)
    void SET_TimeToCheckForDangerAfterValidQuery(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRadiusToSearchForSafePlace(const float& Value) { Write<float>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: FloatProperty)
    void SET_DangerZoneDetectedExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: NameProperty)
    void SET_DangerZoneDetectedSafeLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: NameProperty)
    void SET_CachedMovementSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheZoneManager(const UAthenaAIServiceZoneManager*& Value) { Write<UAthenaAIServiceZoneManager*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf8
class UFortAthenaAIBotEvaluator_TagQuery : public UFortAthenaAIBotEvaluator
{
public:
    FGameplayTagQuery TagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x48, Type: StructProperty)
    UAbilitySystemComponent* CachedAbilitySystemComponent() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)

    void SET_TagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x48, Type: StructProperty)
    void SET_CachedAbilitySystemComponent(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x200
class UFortAthenaAIBotEvaluator_DBNO : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName DBNODestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    bool bAllowReachSquadmates() const { return (Read<uint8_t>(uintptr_t(this) + 0x1a6) >> 0x0) & 1; } // 0x1a6:0 (Size: 0x1, Type: BoolProperty)
    bool bAllowReachSameFactionNPCs() const { return (Read<uint8_t>(uintptr_t(this) + 0x1a6) >> 0x1) & 1; } // 0x1a6:1 (Size: 0x1, Type: BoolProperty)
    TArray<AFortPlayerPawnAthena*> AllyPawns() const { return Read<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    FVector CachedCurrentDestination() const { return Read<FVector>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIBotDBNODigestedSkillSet* DBNOSkillSet() const { return Read<UFortAthenaAIBotDBNODigestedSkillSet*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAICoverComponent* CachedCoverComponent() const { return Read<UFortAthenaAICoverComponent*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_DBNOBehavior* DBNOBehaviorRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_DBNOBehavior*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)

    void SET_DBNODestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_bAllowReachSquadmates(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1a6); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1a6, B); } // 0x1a6:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowReachSameFactionNPCs(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1a6); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1a6, B); } // 0x1a6:1 (Size: 0x1, Type: BoolProperty)
    void SET_AllyPawns(const TArray<AFortPlayerPawnAthena*>& Value) { Write<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedCurrentDestination(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x18, Type: StructProperty)
    void SET_DBNOSkillSet(const UFortAthenaAIBotDBNODigestedSkillSet*& Value) { Write<UFortAthenaAIBotDBNODigestedSkillSet*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedCoverComponent(const UFortAthenaAICoverComponent*& Value) { Write<UFortAthenaAICoverComponent*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_DBNOBehaviorRuntimeParameters(const UFortAthenaAIRuntimeParameters_DBNOBehavior*& Value) { Write<UFortAthenaAIRuntimeParameters_DBNOBehavior*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc0
class UFortAthenaAIBotEvaluator_DefensiveBuilding : public UFortAthenaAIBotEvaluator
{
public:
    UFortAthenaAIBotBuildingDigestedSkillSet* CachedBuildingDigestedSkillSet() const { return Read<UFortAthenaAIBotBuildingDigestedSkillSet*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotBuildingComponent* CachedBuildingComponent() const { return Read<UFortAthenaAIBotBuildingComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_CachedBuildingDigestedSkillSet(const UFortAthenaAIBotBuildingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotBuildingDigestedSkillSet*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedBuildingComponent(const UFortAthenaAIBotBuildingComponent*& Value) { Write<UFortAthenaAIBotBuildingComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x200
class UFortAthenaAIBotEvaluator_Escalate : public UFortAthenaAIBotEvaluator
{
public:
    UFortAthenaAIRuntimeParameters_EscalateBehavior* EscalateRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_EscalateBehavior*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    TArray<FEscalateTargetData> EscalateTargetDatas() const { return Read<TArray<FEscalateTargetData>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)

    void SET_EscalateRuntimeParameters(const UFortAthenaAIRuntimeParameters_EscalateBehavior*& Value) { Write<UFortAthenaAIRuntimeParameters_EscalateBehavior*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    void SET_EscalateTargetDatas(const TArray<FEscalateTargetData>& Value) { Write<TArray<FEscalateTargetData>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1d0
class UFortAthenaAIBotEvaluator_Escape : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FGameplayTagContainer EscapeTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x20, Type: StructProperty)
    float CooldownBetweenAggressivenessChanges() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    FName AggressivenessName() const { return Read<FName>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: NameProperty)

    void SET_EscapeTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x20, Type: StructProperty)
    void SET_CooldownBetweenAggressivenessChanges(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_AggressivenessName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x290
class UFortAthenaAIBotEvaluator_EvasiveManeuvers : public UFortAthenaAIBotEvaluator
{
public:
    FName CrouchExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: NameProperty)
    FName JetpackStrafeExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: NameProperty)
    FName DodgeName() const { return Read<FName>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: NameProperty)
    FName DestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: NameProperty)
    FName UrgentMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: NameProperty)
    bool bDoCrouching() const { return Read<bool>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x1, Type: BoolProperty)
    bool bDoDodging() const { return Read<bool>(uintptr_t(this) + 0x175); } // 0x175 (Size: 0x1, Type: BoolProperty)
    bool bDoJumping() const { return Read<bool>(uintptr_t(this) + 0x176); } // 0x176 (Size: 0x1, Type: BoolProperty)
    bool bDoJumpingDistanceCheck() const { return Read<bool>(uintptr_t(this) + 0x177); } // 0x177 (Size: 0x1, Type: BoolProperty)
    bool bDoJetpackStrafing() const { return Read<bool>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: BoolProperty)
    bool bDoJetpackStrafingDistanceCheck() const { return Read<bool>(uintptr_t(this) + 0x179); } // 0x179 (Size: 0x1, Type: BoolProperty)
    float JetpackStrafingRequiredFuelPercent() const { return Read<float>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0x4, Type: FloatProperty)
    float JetpackStrafeNavPadding() const { return Read<float>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x4, Type: FloatProperty)
    FGameplayTagQuery RequiredTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery JetpackRequiredTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery JumpRequiredTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x48, Type: StructProperty)
    UClass* ForcedPerkClass() const { return Read<UClass*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ClassProperty)
    UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet() const { return Read<UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ObjectProperty)
    UFortAIControllerPerksComponent* CachedPerksComponent() const { return Read<UFortAIControllerPerksComponent*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ObjectProperty)

    void SET_CrouchExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: NameProperty)
    void SET_JumpExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: NameProperty)
    void SET_JetpackStrafeExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: NameProperty)
    void SET_DodgeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: NameProperty)
    void SET_DestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: NameProperty)
    void SET_UrgentMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: NameProperty)
    void SET_bDoCrouching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x1, Type: BoolProperty)
    void SET_bDoDodging(const bool& Value) { Write<bool>(uintptr_t(this) + 0x175, Value); } // 0x175 (Size: 0x1, Type: BoolProperty)
    void SET_bDoJumping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x176, Value); } // 0x176 (Size: 0x1, Type: BoolProperty)
    void SET_bDoJumpingDistanceCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x177, Value); } // 0x177 (Size: 0x1, Type: BoolProperty)
    void SET_bDoJetpackStrafing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: BoolProperty)
    void SET_bDoJetpackStrafingDistanceCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x179, Value); } // 0x179 (Size: 0x1, Type: BoolProperty)
    void SET_JetpackStrafingRequiredFuelPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0x4, Type: FloatProperty)
    void SET_JetpackStrafeNavPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x4, Type: FloatProperty)
    void SET_RequiredTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x48, Type: StructProperty)
    void SET_JetpackRequiredTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x48, Type: StructProperty)
    void SET_JumpRequiredTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x48, Type: StructProperty)
    void SET_ForcedPerkClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ClassProperty)
    void SET_CacheEMDigestedSkillSet(const UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*& Value) { Write<UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedPerksComponent(const UFortAIControllerPerksComponent*& Value) { Write<UFortAIControllerPerksComponent*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
class UFortAthenaAIBotEvaluator_Flanking : public UFortAthenaAIBotEvaluator_Movement
{
public:
    AFortAIDirector* CachedAIDirector() const { return Read<AFortAIDirector*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CachedRangeAttackDigestedSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    FName FlankingExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName FlankingMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName FlankingDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    TArray<FFlankingLocationInfo> LocationsToEvaluate() const { return Read<TArray<FFlankingLocationInfo>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFlankingLocationInfo> BestLocations() const { return Read<TArray<FFlankingLocationInfo>>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AActor*>> ActorsInArea() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedAIDirector(const AFortAIDirector*& Value) { Write<AFortAIDirector*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedRangeAttackDigestedSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_FlankingExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_FlankingMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_FlankingDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_LocationsToEvaluate(const TArray<FFlankingLocationInfo>& Value) { Write<TArray<FFlankingLocationInfo>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    void SET_BestLocations(const TArray<FFlankingLocationInfo>& Value) { Write<TArray<FFlankingLocationInfo>>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x10, Type: ArrayProperty)
    void SET_ActorsInArea(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1d8
class UFortAthenaAIBotEvaluator_Flee : public UFortAthenaAIBotEvaluator_Movement
{
public:
    float MinDistanceFromTarget() const { return Read<float>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float MinValidDistanceForFleeLocation() const { return Read<float>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: FloatProperty)
    float FleeDistance() const { return Read<float>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromTargetWhenFleeing() const { return Read<float>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    float MinDistanceHysteresisWhenChangingTarget() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    FName FleeKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName FleeMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName FleeDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    FName FleeActorKeyName() const { return Read<FName>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: NameProperty)
    AActor* CurrentActorFleeingFrom() const { return Read<AActor*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)

    void SET_MinDistanceFromTarget(const float& Value) { Write<float>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    void SET_MinValidDistanceForFleeLocation(const float& Value) { Write<float>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: FloatProperty)
    void SET_FleeDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistanceFromTargetWhenFleeing(const float& Value) { Write<float>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    void SET_MinDistanceHysteresisWhenChangingTarget(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    void SET_FleeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_FleeMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_FleeDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_FleeActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: NameProperty)
    void SET_CurrentActorFleeingFrom(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1b8
class UFortAthenaAIBotEvaluator_FreeFalling : public UFortAthenaAIBotEvaluator
{
public:
    FName DiveExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName DiveDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName GlideExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName GlideDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName JumpOffBusDestinationName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName AlertLevelName() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    bool bRandomlySelectFreeFallingMode() const { return Read<bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: BoolProperty)
    FScalableFloat IdleWeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RandomWeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TowardNearestAllyWeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x28, Type: StructProperty)
    uint8_t FreeFallingMode() const { return Read<uint8_t>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: EnumProperty)
    bool bIsAlerted() const { return Read<bool>(uintptr_t(this) + 0x149); } // 0x149 (Size: 0x1, Type: BoolProperty)
    float MaxOffsetRangeFromNearestAlly() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    bool bShouldRecomputeDestinationWhenTowardNearestAlly() const { return (Read<uint8_t>(uintptr_t(this) + 0x150) >> 0x0) & 1; } // 0x150:0 (Size: 0x1, Type: BoolProperty)
    bool bShouldSearchAllyInSquad() const { return (Read<uint8_t>(uintptr_t(this) + 0x150) >> 0x1) & 1; } // 0x150:1 (Size: 0x1, Type: BoolProperty)
    bool bShouldSearchAllyInTeam() const { return (Read<uint8_t>(uintptr_t(this) + 0x150) >> 0x2) & 1; } // 0x150:2 (Size: 0x1, Type: BoolProperty)
    bool bGlideAllowed() const { return (Read<uint8_t>(uintptr_t(this) + 0x150) >> 0x3) & 1; } // 0x150:3 (Size: 0x1, Type: BoolProperty)
    float SkyTubeDivingStuckTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: FloatProperty)
    AFortPlayerStateAthena* NearestAlly() const { return Read<AFortPlayerStateAthena*>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    FVector CachedLatestDestination() const { return Read<FVector>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    AFortSkyTube* CachedSkyTube() const { return Read<AFortSkyTube*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)

    void SET_DiveExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_DiveDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_GlideExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_GlideDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_JumpOffBusDestinationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_AlertLevelName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET_bRandomlySelectFreeFallingMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: BoolProperty)
    void SET_IdleWeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x28, Type: StructProperty)
    void SET_RandomWeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x28, Type: StructProperty)
    void SET_TowardNearestAllyWeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x28, Type: StructProperty)
    void SET_FreeFallingMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: EnumProperty)
    void SET_bIsAlerted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x149, Value); } // 0x149 (Size: 0x1, Type: BoolProperty)
    void SET_MaxOffsetRangeFromNearestAlly(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_bShouldRecomputeDestinationWhenTowardNearestAlly(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x150); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x150, B); } // 0x150:0 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldSearchAllyInSquad(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x150); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x150, B); } // 0x150:1 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldSearchAllyInTeam(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x150); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x150, B); } // 0x150:2 (Size: 0x1, Type: BoolProperty)
    void SET_bGlideAllowed(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x150); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x150, B); } // 0x150:3 (Size: 0x1, Type: BoolProperty)
    void SET_SkyTubeDivingStuckTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: FloatProperty)
    void SET_NearestAlly(const AFortPlayerStateAthena*& Value) { Write<AFortPlayerStateAthena*>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedLatestDestination(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x18, Type: StructProperty)
    void SET_CacheMovementDigestedSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedSkyTube(const AFortSkyTube*& Value) { Write<AFortSkyTube*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x138
class UFortAthenaAIBotEvaluator_Ground : public UFortAthenaAIBotEvaluator
{
public:
    FVector SurfaceTypeRaycastDir() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIRuntimeParameters_Behavior* CachedBehaviorRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_Behavior*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)

    void SET_SurfaceTypeRaycastDir(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_CachedBehaviorRuntimeParameters(const UFortAthenaAIRuntimeParameters_Behavior*& Value) { Write<UFortAthenaAIRuntimeParameters_Behavior*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1f8
class UFortAthenaAIBotEvaluator_HandleFocusing : public UFortAthenaAIBotEvaluator
{
public:
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName InteractActorName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetLocationName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName FocusActorName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName FocalPointName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    FName RangeAttackIsReadyToFireName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)
    FName LastKnownPositionName() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Enum FocusingBehavior() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Enum NoRangedWeaponFocusBehavior() const { return Read<FValueOrBBKey_Enum>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool bPrioritizeThreatOverCurrentTarget() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bUseTargetActorKeyAsFocusTarget() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bFocusOnTargetLocation() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float AmbushMaxLKPLookAtAngleDegree() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bStopFocusingWhenMoving() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float ResumeFocusingWhenMovingDist() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float StopFocusingWhenMovingDist() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bResumeFocusWhileSliding() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ClearFocusOnTacticalSprint() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0xc, Type: StructProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    AActor* LastTargetedThreat() const { return Read<AActor*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    AActor* FocusActor() const { return Read<AActor*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_InteractActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_TargetLocationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_FocusActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_FocalPointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_WeaponFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET_RangeAttackIsReadyToFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
    void SET_LastKnownPositionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_TacticalSprintExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: NameProperty)
    void SET_FocusingBehavior(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
    void SET_NoRangedWeaponFocusBehavior(const FValueOrBBKey_Enum& Value) { Write<FValueOrBBKey_Enum>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
    void SET_bPrioritizeThreatOverCurrentTarget(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0xc, Type: StructProperty)
    void SET_bUseTargetActorKeyAsFocusTarget(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0xc, Type: StructProperty)
    void SET_bFocusOnTargetLocation(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0xc, Type: StructProperty)
    void SET_AmbushMaxLKPLookAtAngleDegree(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0xc, Type: StructProperty)
    void SET_bStopFocusingWhenMoving(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0xc, Type: StructProperty)
    void SET_ResumeFocusingWhenMovingDist(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0xc, Type: StructProperty)
    void SET_StopFocusingWhenMovingDist(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0xc, Type: StructProperty)
    void SET_bResumeFocusWhileSliding(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0xc, Type: StructProperty)
    void SET_ClearFocusOnTacticalSprint(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0xc, Type: StructProperty)
    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheMovementDigestedSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_LastTargetedThreat(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_FocusActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x130
class UFortAthenaAIBotEvaluator_Heal : public UFortAthenaAIBotEvaluator
{
public:
    FName HealingObjectKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName CanHealWhileMovingKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName UnstuckExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName MovementItemExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FGameplayTagQuery RequiredTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x48, Type: StructProperty)
    bool bAllowEvaluationRetry() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    UFortAthenaAIBotHealingDigestedSkillSet* HealingSkillSet() const { return Read<UFortAthenaAIBotHealingDigestedSkillSet*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_HealingObjectKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_CanHealWhileMovingKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_UnstuckExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_MovementItemExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_RequiredTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x48, Type: StructProperty)
    void SET_bAllowEvaluationRetry(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_HealingSkillSet(const UFortAthenaAIBotHealingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotHealingDigestedSkillSet*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x298
class UFortAthenaAIBotEvaluator_HitAndRun : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat AttackDurationBeforeEvade() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MeleeAttackMaxDistToEvade() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClampEvadeDistanceEnable() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDistanceToEvade() const { return Read<FScalableFloat>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDistanceToEvade() const { return Read<FScalableFloat>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x28, Type: StructProperty)
    FName EvadeKeyName() const { return Read<FName>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x4, Type: NameProperty)
    FName EvadeMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x26c); } // 0x26c (Size: 0x4, Type: NameProperty)
    FName EvadeDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName() const { return Read<FName>(uintptr_t(this) + 0x274); } // 0x274 (Size: 0x4, Type: NameProperty)
    float MeleeAttackMaxDistToEvadeSqr() const { return Read<float>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceToEvadeSqr() const { return Read<float>(uintptr_t(this) + 0x28c); } // 0x28c (Size: 0x4, Type: FloatProperty)

    void SET_AttackDurationBeforeEvade(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    void SET_MeleeAttackMaxDistToEvade(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x28, Type: StructProperty)
    void SET_ClampEvadeDistanceEnable(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x28, Type: StructProperty)
    void SET_MinDistanceToEvade(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x28, Type: StructProperty)
    void SET_MaxDistanceToEvade(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x28, Type: StructProperty)
    void SET_EvadeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x4, Type: NameProperty)
    void SET_EvadeMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x26c, Value); } // 0x26c (Size: 0x4, Type: NameProperty)
    void SET_EvadeDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x274, Value); } // 0x274 (Size: 0x4, Type: NameProperty)
    void SET_MeleeAttackMaxDistToEvadeSqr(const float& Value) { Write<float>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistanceToEvadeSqr(const float& Value) { Write<float>(uintptr_t(this) + 0x28c, Value); } // 0x28c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe8
class UFortAthenaAIBotEvaluator_HolsterWeapon : public UFortAthenaAIBotEvaluator
{
public:
    TArray<FName> ExecutionStatusesToCheckedNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    FValueOrBBKey_Bool HolsterEvenWithTarget() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    UFortAthenaAIRuntimeParameters_NPCBehavior* CachedNPCBehaviorParameters() const { return Read<UFortAthenaAIRuntimeParameters_NPCBehavior*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_AIBotConvert* CachedConvertParameters() const { return Read<UFortAthenaAIRuntimeParameters_AIBotConvert*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_ExecutionStatusesToCheckedNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_HolsterEvenWithTarget(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_CachedNPCBehaviorParameters(const UFortAthenaAIRuntimeParameters_NPCBehavior*& Value) { Write<UFortAthenaAIRuntimeParameters_NPCBehavior*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedConvertParameters(const UFortAthenaAIRuntimeParameters_AIBotConvert*& Value) { Write<UFortAthenaAIRuntimeParameters_AIBotConvert*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x260
class UFortAthenaAIBotEvaluator_Investigate : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName LastKnownPositionName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName DestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName AggressivenessName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FName CautiousKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName AlertLevelName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    UClass* SearchQueryFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet() const { return Read<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotUnstuckDigestedSkillSet* CachedUnstuckSkillSet() const { return Read<UFortAthenaAIBotUnstuckDigestedSkillSet*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> InvestigatingSupportingActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x8, Type: WeakObjectProperty)
    ABuildingSMActor* UnderminingBuildingActor() const { return Read<ABuildingSMActor*>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x8, Type: ObjectProperty)
    AActor* ExcludeReachingTarget() const { return Read<AActor*>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: ObjectProperty)

    void SET_LastKnownPositionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_DestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_MoveToDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_AggressivenessName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_CautiousKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_AlertLevelName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_SearchQueryFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheAttackingDigestedSkillSet(const UFortAthenaAIBotAttackingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedUnstuckSkillSet(const UFortAthenaAIBotUnstuckDigestedSkillSet*& Value) { Write<UFortAthenaAIBotUnstuckDigestedSkillSet*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    void SET_InvestigatingSupportingActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UnderminingBuildingActor(const ABuildingSMActor*& Value) { Write<ABuildingSMActor*>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x8, Type: ObjectProperty)
    void SET_ExcludeReachingTarget(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe8
class UFortAthenaAIBotEvaluator_JumpOffBus : public UFortAthenaAIBotEvaluator
{
public:
    FName JumpOffBusDestinationName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName JumpOffBusDestinationVolumeKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    AFortPoiVolume* BusDroppingVolume() const { return Read<AFortPoiVolume*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)

    void SET_JumpOffBusDestinationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_JumpOffBusDestinationVolumeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_BusDroppingVolume(const AFortPoiVolume*& Value) { Write<AFortPoiVolume*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheMovementDigestedSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x228
class UFortAthenaAIBotEvaluator_MeleeAttack : public UFortAthenaAIBotEvaluator_Attack
{
public:
    FName WeaponTriggerMeleeName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    FName ThrowableAttacksAllowedName() const { return Read<FName>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: NameProperty)
    FName TraversalBlockMeleeAttackName() const { return Read<FName>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: NameProperty)
    FName TargetContextReachableKeyName() const { return Read<FName>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: NameProperty)
    FName TargetContextInsideLeashKeyName() const { return Read<FName>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* AttackingSkillSet() const { return Read<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    FValueOrBBKey_Bool ShouldValidateWeaponType() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CheckMeleeHeightAligned() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool AddExtentsToMeleeAttackDistance() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool Use3DDistanceCheckForMeleeAttack() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x214); } // 0x214 (Size: 0xc, Type: StructProperty)

    void SET_WeaponTriggerMeleeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_ThrowableAttacksAllowedName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: NameProperty)
    void SET_TraversalBlockMeleeAttackName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: NameProperty)
    void SET_TargetContextReachableKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: NameProperty)
    void SET_TargetContextInsideLeashKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: NameProperty)
    void SET_AttackingSkillSet(const UFortAthenaAIBotAttackingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ShouldValidateWeaponType(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0xc, Type: StructProperty)
    void SET_CheckMeleeHeightAligned(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0xc, Type: StructProperty)
    void SET_AddExtentsToMeleeAttackDistance(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0xc, Type: StructProperty)
    void SET_Use3DDistanceCheckForMeleeAttack(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x214, Value); } // 0x214 (Size: 0xc, Type: StructProperty)
};

// Size: 0xc8
class UFortAthenaAIBotEvaluator_Observe : public UFortAthenaAIBotEvaluator
{
public:
    FName AggressivenessName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName ObserveDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    bool bContinueMovementOnStart() const { return Read<bool>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x1, Type: BoolProperty)
    float MaxMovementDuration() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)

    void SET_AggressivenessName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_ObserveDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_bContinueMovementOnStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x1, Type: BoolProperty)
    void SET_MaxMovementDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc8
class UFortAthenaAIBotEvaluator_PathExists : public UFortAthenaAIBotEvaluator
{
public:
    FName PathExistsKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName GoalKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    float AcceptableRadius() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    UClass* FilterClass() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EPathTestQueryType> PathQueryType() const { return Read<TEnumAsByte<EPathTestQueryType>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: ByteProperty)
    bool bProjectGoalLocation() const { return (Read<uint8_t>(uintptr_t(this) + 0xc4) >> 0x0) & 1; } // 0xc4:0 (Size: 0x1, Type: BoolProperty)
    bool bReachTestIncludesAgentRadius() const { return (Read<uint8_t>(uintptr_t(this) + 0xc4) >> 0x1) & 1; } // 0xc4:1 (Size: 0x1, Type: BoolProperty)
    bool bReachTestIncludesGoalRadius() const { return (Read<uint8_t>(uintptr_t(this) + 0xc4) >> 0x2) & 1; } // 0xc4:2 (Size: 0x1, Type: BoolProperty)

    void SET_PathExistsKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_GoalKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_AcceptableRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_FilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_PathQueryType(const TEnumAsByte<EPathTestQueryType>& Value) { Write<TEnumAsByte<EPathTestQueryType>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: ByteProperty)
    void SET_bProjectGoalLocation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc4, B); } // 0xc4:0 (Size: 0x1, Type: BoolProperty)
    void SET_bReachTestIncludesAgentRadius(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc4); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xc4, B); } // 0xc4:1 (Size: 0x1, Type: BoolProperty)
    void SET_bReachTestIncludesGoalRadius(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc4); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xc4, B); } // 0xc4:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x238
class UFortAthenaAIBotEvaluator_PatrolAround : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FEQSParametrizedQueryExecutionRequest EQSRequest() const { return Read<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x48, Type: StructProperty)
    UClass* NavigationQueryFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
    bool bFallbackToPointWithNoCustomNavigationQueryFilter() const { return Read<bool>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
    FName PatrolDestinationName() const { return Read<FName>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0x4, Type: NameProperty)
    FName PatrolExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: NameProperty)
    FName PatrolMovementStateName() const { return Read<FName>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: NameProperty)
    FName BestTargetActorName() const { return Read<FName>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: NameProperty)
    FName EnableKeyName() const { return Read<FName>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: NameProperty)
    AFortGameModeAthena* CacheAthenaGameMode() const { return Read<AFortGameModeAthena*>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x8, Type: ObjectProperty)

    void SET_EQSRequest(const FEQSParametrizedQueryExecutionRequest& Value) { Write<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x48, Type: StructProperty)
    void SET_NavigationQueryFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ClassProperty)
    void SET_bFallbackToPointWithNoCustomNavigationQueryFilter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
    void SET_PatrolDestinationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0x4, Type: NameProperty)
    void SET_PatrolExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: NameProperty)
    void SET_PatrolMovementStateName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: NameProperty)
    void SET_BestTargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: NameProperty)
    void SET_EnableKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: NameProperty)
    void SET_CacheAthenaGameMode(const AFortGameModeAthena*& Value) { Write<AFortGameModeAthena*>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1c0
class UFortAthenaAIBotEvaluator_PlayEmote : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName PlayEmoteExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName PlayEmoteDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    AActor* ExcludeReachingTarget() const { return Read<AActor*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayEmoteExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_PlayEmoteDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_ExcludeReachingTarget(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x130
class UFortAthenaAIBotEvaluator_PropagateAwareness : public UFortAthenaAIBotEvaluator
{
public:
    FGameplayTagQuery AwarenessTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x48, Type: StructProperty)
    UClass* AwarenessGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ClassProperty)
    TArray<AFortPlayerPawnAthena*> AwareAllyPawns() const { return Read<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<AFortPlayerPawnAthena*> AlreadyTestedPawns() const { return Read<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    UFortAthenaAIBotPropagateAwarenessDigestedSkillSet* PropagateAwarenessSkillSet() const { return Read<UFortAthenaAIBotPropagateAwarenessDigestedSkillSet*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_BehaviorTreeControl* BehaviorControlsRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_BehaviorTreeControl*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_AffiliationBase* AffiliationRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_AffiliationBase*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)

    void SET_AwarenessTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x48, Type: StructProperty)
    void SET_AwarenessGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ClassProperty)
    void SET_AwareAllyPawns(const TArray<AFortPlayerPawnAthena*>& Value) { Write<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_AlreadyTestedPawns(const TArray<AFortPlayerPawnAthena*>& Value) { Write<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_PropagateAwarenessSkillSet(const UFortAthenaAIBotPropagateAwarenessDigestedSkillSet*& Value) { Write<UFortAthenaAIBotPropagateAwarenessDigestedSkillSet*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_BehaviorControlsRuntimeParameters(const UFortAthenaAIRuntimeParameters_BehaviorTreeControl*& Value) { Write<UFortAthenaAIRuntimeParameters_BehaviorTreeControl*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_AffiliationRuntimeParameters(const UFortAthenaAIRuntimeParameters_AffiliationBase*& Value) { Write<UFortAthenaAIRuntimeParameters_AffiliationBase*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x398
class UFortAthenaAIBotEvaluator_RangeAttack : public UFortAthenaAIBotEvaluator_Attack
{
public:
    FName WeaponReloadName() const { return Read<FName>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName() const { return Read<FName>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: NameProperty)
    FName RangeAttackIsReadyToFireName() const { return Read<FName>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: NameProperty)
    FName WeaponTargetingName() const { return Read<FName>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: NameProperty)
    FName AggressivenessName() const { return Read<FName>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: NameProperty)
    FName HasLoSOnThreatName() const { return Read<FName>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x4, Type: NameProperty)
    FName UrgentMovementKeyName() const { return Read<FName>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x4, Type: NameProperty)
    FName IsManningTurretKeyName() const { return Read<FName>(uintptr_t(this) + 0x214); } // 0x214 (Size: 0x4, Type: NameProperty)
    FName BlockWeaponActionsKeyName() const { return Read<FName>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: NameProperty)
    FName CancelWeaponAutoReloadKeyName() const { return Read<FName>(uintptr_t(this) + 0x21c); } // 0x21c (Size: 0x4, Type: NameProperty)
    bool bAlwaysAllowTargetingEvaluation() const { return Read<bool>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x1, Type: BoolProperty)
    bool bSkipADSEvaluation() const { return Read<bool>(uintptr_t(this) + 0x235); } // 0x235 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Bool SkipADSEvaluation() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0xc, Type: StructProperty)
    bool bConsiderLoF() const { return Read<bool>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x1, Type: BoolProperty)
    bool bShouldValidateRangedWeapon() const { return Read<bool>(uintptr_t(this) + 0x245); } // 0x245 (Size: 0x1, Type: BoolProperty)
    float RangeReachHysteresisRatio() const { return Read<float>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: FloatProperty)
    FValueOrBBKey_Bool ResetCanFireNextTimeOnEnter() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CancelWeaponAutoReloadOnExit() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x25c); } // 0x25c (Size: 0xc, Type: StructProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotPerceptionDigestedSkillSet* CachePerceptionDigestedSkillSet() const { return Read<UFortAthenaAIBotPerceptionDigestedSkillSet*>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet() const { return Read<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAthenaAIServiceZoneManager*> CacheZoneManager() const { return Read<TWeakObjectPtr<UAthenaAIServiceZoneManager*>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAthenaAIServiceCover*> CachedAIServiceCover() const { return Read<TWeakObjectPtr<UAthenaAIServiceCover*>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    AActor* ExcludeReachingTarget() const { return Read<AActor*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)

    void SET_WeaponReloadName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: NameProperty)
    void SET_WeaponFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: NameProperty)
    void SET_RangeAttackIsReadyToFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTargetingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: NameProperty)
    void SET_AggressivenessName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: NameProperty)
    void SET_HasLoSOnThreatName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x4, Type: NameProperty)
    void SET_UrgentMovementKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x4, Type: NameProperty)
    void SET_IsManningTurretKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x214, Value); } // 0x214 (Size: 0x4, Type: NameProperty)
    void SET_BlockWeaponActionsKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: NameProperty)
    void SET_CancelWeaponAutoReloadKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x21c, Value); } // 0x21c (Size: 0x4, Type: NameProperty)
    void SET_bAlwaysAllowTargetingEvaluation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipADSEvaluation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x235, Value); } // 0x235 (Size: 0x1, Type: BoolProperty)
    void SET_SkipADSEvaluation(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0xc, Type: StructProperty)
    void SET_bConsiderLoF(const bool& Value) { Write<bool>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldValidateRangedWeapon(const bool& Value) { Write<bool>(uintptr_t(this) + 0x245, Value); } // 0x245 (Size: 0x1, Type: BoolProperty)
    void SET_RangeReachHysteresisRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: FloatProperty)
    void SET_ResetCanFireNextTimeOnEnter(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0xc, Type: StructProperty)
    void SET_CancelWeaponAutoReloadOnExit(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x25c, Value); } // 0x25c (Size: 0xc, Type: StructProperty)
    void SET_CacheRangeAttackDigestedSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    void SET_CachePerceptionDigestedSkillSet(const UFortAthenaAIBotPerceptionDigestedSkillSet*& Value) { Write<UFortAthenaAIBotPerceptionDigestedSkillSet*>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheAttackingDigestedSkillSet(const UFortAthenaAIBotAttackingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheZoneManager(const TWeakObjectPtr<UAthenaAIServiceZoneManager*>& Value) { Write<TWeakObjectPtr<UAthenaAIServiceZoneManager*>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedAIServiceCover(const TWeakObjectPtr<UAthenaAIServiceCover*>& Value) { Write<TWeakObjectPtr<UAthenaAIServiceCover*>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ExcludeReachingTarget(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1c0
class UFortAthenaAIBotEvaluator_ReachBeacon : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName ReachBeaconStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName ReachBeaconMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName ReachBeaconTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    TWeakObjectPtr<UFortAthenaBeaconComponent*> CurrentBeacon() const { return Read<TWeakObjectPtr<UFortAthenaBeaconComponent*>>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ReachBeaconStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_ReachBeaconMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_ReachBeaconTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_CurrentBeacon(const TWeakObjectPtr<UFortAthenaBeaconComponent*>& Value) { Write<TWeakObjectPtr<UFortAthenaBeaconComponent*>>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x6a0
class UFortAthenaAIBotEvaluator_ReactToVerb : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIBotReactToVerbDigestedSkillSet* CacheReactToVerbDigestedSkillSet() const { return Read<UFortAthenaAIBotReactToVerbDigestedSkillSet*>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    FSoftDataRegistryOrTable VerbReactionsMap() const { return Read<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x30, Type: StructProperty)
    FScalableFloat MinDistanceFromPlayerToReact() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDistanceFromPlayerToReactForGroupEmotes() const { return Read<FScalableFloat>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxReactionEmoteDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxReactionEmoteDurationForGroupEmotes() const { return Read<FScalableFloat>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxReactionWaitTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x28, Type: StructProperty)
    FScalableFloat DelayBeforeRunningQueuedReaction() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x28, Type: StructProperty)
    FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration() const { return Read<FFortNearbyActorsPerceptionConfiguration>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0xc0, Type: StructProperty)
    bool bIsHighPriorityEvaluator() const { return Read<bool>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x1, Type: BoolProperty)
    bool bEnableNPCReactionsPersistence() const { return Read<bool>(uintptr_t(this) + 0x4a1); } // 0x4a1 (Size: 0x1, Type: BoolProperty)
    FScalableFloat ReactToEmotes() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxNPCsReactingToEmotes() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LimitReactToGroupEmote() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteIfClosestNPCWithinDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteDelaySecondsWhenPlayersNearby() const { return Read<FScalableFloat>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDistanceOfPlayersFromPlayerToConsiderNearbyPlayer() const { return Read<FScalableFloat>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteDelayRandomDeviation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteDelayForNumPlayersNearby() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x28, Type: StructProperty)
    FGameplayTag ReactToEmoteGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x4, Type: StructProperty)
    FGameplayTagQuery ReactToEmoteRequiredTagQueryOnAI() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x48, Type: StructProperty)
    FName ReactToVerbTargetActorKeyName() const { return Read<FName>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x4, Type: NameProperty)
    FName ReactToVerbShouldMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x4, Type: NameProperty)
    FName ReactToVerbShouldMoveReachDistanceKeyName() const { return Read<FName>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x4, Type: NameProperty)
    FName ExtraStructDataKeyName() const { return Read<FName>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x4, Type: NameProperty)
    FName ReactToVerbShouldJoinGroupEmoteKeyName() const { return Read<FName>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x4, Type: NameProperty)
    FName ShouldFollowTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x4, Type: NameProperty)
    FPersistenceFrameworkSaveControl SaveControl() const { return Read<FPersistenceFrameworkSaveControl>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: StructProperty)

    void SET_CacheReactToVerbDigestedSkillSet(const UFortAthenaAIBotReactToVerbDigestedSkillSet*& Value) { Write<UFortAthenaAIBotReactToVerbDigestedSkillSet*>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    void SET_VerbReactionsMap(const FSoftDataRegistryOrTable& Value) { Write<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x30, Type: StructProperty)
    void SET_MinDistanceFromPlayerToReact(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x28, Type: StructProperty)
    void SET_MinDistanceFromPlayerToReactForGroupEmotes(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x28, Type: StructProperty)
    void SET_MaxReactionEmoteDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x28, Type: StructProperty)
    void SET_MaxReactionEmoteDurationForGroupEmotes(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x28, Type: StructProperty)
    void SET_MaxReactionWaitTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x28, Type: StructProperty)
    void SET_DelayBeforeRunningQueuedReaction(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x28, Type: StructProperty)
    void SET_PerceptionConfiguration(const FFortNearbyActorsPerceptionConfiguration& Value) { Write<FFortNearbyActorsPerceptionConfiguration>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0xc0, Type: StructProperty)
    void SET_bIsHighPriorityEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableNPCReactionsPersistence(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a1, Value); } // 0x4a1 (Size: 0x1, Type: BoolProperty)
    void SET_ReactToEmotes(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x28, Type: StructProperty)
    void SET_MaxNPCsReactingToEmotes(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x28, Type: StructProperty)
    void SET_LimitReactToGroupEmote(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x28, Type: StructProperty)
    void SET_ReactToGroupEmoteIfClosestNPCWithinDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x28, Type: StructProperty)
    void SET_ReactToGroupEmoteDelaySecondsWhenPlayersNearby(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x28, Type: StructProperty)
    void SET_MinDistanceOfPlayersFromPlayerToConsiderNearbyPlayer(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x28, Type: StructProperty)
    void SET_ReactToGroupEmoteDelayRandomDeviation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x28, Type: StructProperty)
    void SET_ReactToGroupEmoteDelayForNumPlayersNearby(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x28, Type: StructProperty)
    void SET_ReactToEmoteGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x4, Type: StructProperty)
    void SET_ReactToEmoteRequiredTagQueryOnAI(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x48, Type: StructProperty)
    void SET_ReactToVerbTargetActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x4, Type: NameProperty)
    void SET_ReactToVerbShouldMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x4, Type: NameProperty)
    void SET_ReactToVerbShouldMoveReachDistanceKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x4, Type: NameProperty)
    void SET_ExtraStructDataKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x4, Type: NameProperty)
    void SET_ReactToVerbShouldJoinGroupEmoteKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x4, Type: NameProperty)
    void SET_ShouldFollowTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x4, Type: NameProperty)
    void SET_SaveControl(const FPersistenceFrameworkSaveControl& Value) { Write<FPersistenceFrameworkSaveControl>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: StructProperty)
};

// Size: 0x208
class UFortAthenaAIBotEvaluator_RecoverLineOfSight : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat RecoveringLineOfSightMaxDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    TArray<FName> ExecutionStatusToListenKeyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    FName RecoverLineOfSightExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: NameProperty)
    FName RecoverLineOfSightMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0x4, Type: NameProperty)
    FName RecoverLineOfSightDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: NameProperty)

    void SET_RecoveringLineOfSightMaxDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    void SET_ExecutionStatusToListenKeyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    void SET_RecoverLineOfSightExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: NameProperty)
    void SET_RecoverLineOfSightMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0x4, Type: NameProperty)
    void SET_RecoverLineOfSightDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: NameProperty)
};

// Size: 0xb0
class UFortAthenaAIBotEvaluator_ReloadWeapon : public UFortAthenaAIBotEvaluator
{
public:
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    bool bCanReloadWeaponsInInventory() const { return Read<bool>(uintptr_t(this) + 0xae); } // 0xae (Size: 0x1, Type: BoolProperty)

    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_bCanReloadWeaponsInInventory(const bool& Value) { Write<bool>(uintptr_t(this) + 0xae, Value); } // 0xae (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1d0
class UFortAthenaAIBotEvaluator_Retreat : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName RetreatDestinationName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet() const { return Read<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAICoverComponent* CachedCoverComponent() const { return Read<UFortAthenaAICoverComponent*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)

    void SET_RetreatDestinationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_CacheAttackingDigestedSkillSet(const UFortAthenaAIBotAttackingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedCoverComponent(const UFortAthenaAICoverComponent*& Value) { Write<UFortAthenaAICoverComponent*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x208
class UFortAthenaAIBotEvaluator_Revive : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat LastReviveTargetExpiration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    FName ReviveTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: NameProperty)
    FName ReviveLastTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: NameProperty)
    UFortAthenaAIRuntimeParameters_ReviveBehavior* ReviveBehaviorRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_ReviveBehavior*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawnAthena* CurrentReviveTarget() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    TArray<AFortPlayerPawnAthena*> DBNOAllyPawns() const { return Read<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: ArrayProperty)
    UFortAthenaAIBotReviveDigestedSkillSet* ReviveSkillSet() const { return Read<UFortAthenaAIBotReviveDigestedSkillSet*>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: ObjectProperty)

    void SET_LastReviveTargetExpiration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    void SET_ReviveTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: NameProperty)
    void SET_ReviveLastTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: NameProperty)
    void SET_ReviveBehaviorRuntimeParameters(const UFortAthenaAIRuntimeParameters_ReviveBehavior*& Value) { Write<UFortAthenaAIRuntimeParameters_ReviveBehavior*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentReviveTarget(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_DBNOAllyPawns(const TArray<AFortPlayerPawnAthena*>& Value) { Write<TArray<AFortPlayerPawnAthena*>>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: ArrayProperty)
    void SET_ReviveSkillSet(const UFortAthenaAIBotReviveDigestedSkillSet*& Value) { Write<UFortAthenaAIBotReviveDigestedSkillSet*>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x170
class UFortAthenaAIBotEvaluator_SandTunnel : public UFortAthenaAIBotEvaluator_TagQuery
{
public:
    FName JumpExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: NameProperty)
    FName LootInteractionExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName() const { return Read<FName>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName() const { return Read<FName>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: NameProperty)
    FGameplayTagQuery BuriedTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x48, Type: StructProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)

    void SET_JumpExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: NameProperty)
    void SET_LootInteractionExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: NameProperty)
    void SET_WeaponFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: NameProperty)
    void SET_BuriedTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x48, Type: StructProperty)
    void SET_CacheMovementDigestedSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x210
class UFortAthenaAIBotEvaluator_SelectNextDynamicPOI : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName DynamicPOIExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName DynamicPOILocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    UFortGameStateComponent_BattleRoyaleGamePhaseLogic* CachedBRLogic() const { return Read<UFortGameStateComponent_BattleRoyaleGamePhaseLogic*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle NextSearchTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: StructProperty)
    TArray<FFailedToReachPOI> FailedBotPOIList() const { return Read<TArray<FFailedToReachPOI>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    int32_t CachedSelectedBotPOIID() const { return Read<int32_t>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: IntProperty)

    void SET_DynamicPOIExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_DynamicPOILocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_CachedBRLogic(const UFortGameStateComponent_BattleRoyaleGamePhaseLogic*& Value) { Write<UFortGameStateComponent_BattleRoyaleGamePhaseLogic*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_NextSearchTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: StructProperty)
    void SET_FailedBotPOIList(const TArray<FFailedToReachPOI>& Value) { Write<TArray<FFailedToReachPOI>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedSelectedBotPOIID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1d0
class UFortAthenaAIBotEvaluator_SelectNextPOI : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName NextPOIKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName MarkerLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    AFortPoiVolume* StartingGroundPOI() const { return Read<AFortPoiVolume*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    bool bCheckForStartingGroundPOI() const { return Read<bool>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x1, Type: BoolProperty)
    float CurrentPOICompletionTime() const { return Read<float>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: FloatProperty)
    float DurationInsideCurrentPOI() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    UFortAthenaAIBotLootingDigestedSkillSet* CachedLootingSkillSet() const { return Read<UFortAthenaAIBotLootingDigestedSkillSet*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)

    void SET_NextPOIKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_MarkerLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_StartingGroundPOI(const AFortPoiVolume*& Value) { Write<AFortPoiVolume*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_bCheckForStartingGroundPOI(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentPOICompletionTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: FloatProperty)
    void SET_DurationInsideCurrentPOI(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_CachedLootingSkillSet(const UFortAthenaAIBotLootingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotLootingDigestedSkillSet*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2c8
class UFortAthenaAIBotEvaluator_SelectVehicle : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName VehicleDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName SelectVehicleMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName SelectVehicleStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName SelectedVehicleKeyName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FScalableFloat Enabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    float VehicleSearchRadius() const { return Read<float>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    bool bCanEnterOnlyWithHisConverter() const { return Read<bool>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterAsDriver() const { return Read<bool>(uintptr_t(this) + 0x1e5); } // 0x1e5 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterVehiclesInWater() const { return Read<bool>(uintptr_t(this) + 0x1e6); } // 0x1e6 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterOutOfFuelVehicles() const { return Read<bool>(uintptr_t(this) + 0x1e7); } // 0x1e7 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterWithPlayerDriver() const { return Read<bool>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterWithPlayerOnAnySeat() const { return Read<bool>(uintptr_t(this) + 0x1e9); } // 0x1e9 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterOnlyMatchingPatrols() const { return Read<bool>(uintptr_t(this) + 0x1ea); } // 0x1ea (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery VehiclesFilterTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery SeatsFilterTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery OwnerFilterTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x48, Type: StructProperty)

    void SET_VehicleDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_SelectVehicleMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_SelectVehicleStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_SelectedVehicleKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_Enabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_VehicleSearchRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    void SET_bCanEnterOnlyWithHisConverter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterAsDriver(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e5, Value); } // 0x1e5 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterVehiclesInWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e6, Value); } // 0x1e6 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterOutOfFuelVehicles(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e7, Value); } // 0x1e7 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterWithPlayerDriver(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterWithPlayerOnAnySeat(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e9, Value); } // 0x1e9 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnterOnlyMatchingPatrols(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1ea, Value); } // 0x1ea (Size: 0x1, Type: BoolProperty)
    void SET_VehiclesFilterTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x48, Type: StructProperty)
    void SET_SeatsFilterTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x48, Type: StructProperty)
    void SET_OwnerFilterTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x48, Type: StructProperty)
};

// Size: 0x2b8
class UFortAthenaAIBotEvaluator_SmartObjects : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FGameplayTag EvaluationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen() const { return Read<bool>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport() const { return Read<bool>(uintptr_t(this) + 0x1a5); } // 0x1a5 (Size: 0x1, Type: BoolProperty)
    FWorldConditionQueryDefinition CanRunPrecondition() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x18, Type: StructProperty)
    FScalableFloat MaximumEntryLocationsChecksPerEvaluation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EntryLocationFailuresBlacklistedTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* DistanceToWeightCurveForSlotPicking() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x8, Type: ObjectProperty)
    UClass* OverridenFilterClassForEntryPoints() const { return Read<UClass*>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: ClassProperty)
    TArray<FName> ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: ArrayProperty)
    FName SmartObjectExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName() const { return Read<FName>(uintptr_t(this) + 0x23c); } // 0x23c (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName() const { return Read<FName>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem() const { return Read<USmartObjectSubsystem*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ObjectProperty)
    FWorldConditionQueryState CanRunPreconditionQueryState() const { return Read<FWorldConditionQueryState>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x30, Type: StructProperty)

    void SET_EvaluationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: StructProperty)
    void SET_bEvaluateSOValidityAfterChosen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableEntryLocationsSupport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a5, Value); } // 0x1a5 (Size: 0x1, Type: BoolProperty)
    void SET_CanRunPrecondition(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x18, Type: StructProperty)
    void SET_MaximumEntryLocationsChecksPerEvaluation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    void SET_EntryLocationFailuresBlacklistedTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    void SET_DistanceToWeightCurveForSlotPicking(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x8, Type: ObjectProperty)
    void SET_OverridenFilterClassForEntryPoints(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: ClassProperty)
    void SET_ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: ArrayProperty)
    void SET_SmartObjectExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationRotationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x23c, Value); } // 0x23c (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectShouldMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectUrgencyKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectRuntimeParameters(const UFortAthenaAIRuntimeParameters_SmartObjectBase*& Value) { Write<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ObjectProperty)
    void SET_SmartObjectSubsystem(const USmartObjectSubsystem*& Value) { Write<USmartObjectSubsystem*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ObjectProperty)
    void SET_CanRunPreconditionQueryState(const FWorldConditionQueryState& Value) { Write<FWorldConditionQueryState>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x30, Type: StructProperty)
};

// Size: 0x140
class UFortAthenaAIBotEvaluator_Sprinting : public UFortAthenaAIBotEvaluator
{
public:
    FName AllowSprintKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName AllowSlideKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName SlideExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName UrgentMovementKeyName() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    FName RangeAttackExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FName MeleeAttackExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)
    FName ThrowableAttackExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool ValidateSprintingBeforeTacticalSprinting() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CanTacticalSprintJump() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0xc, Type: StructProperty)
    bool bSprintOnlyInWater() const { return Read<bool>(uintptr_t(this) + 0xf6); } // 0xf6 (Size: 0x1, Type: BoolProperty)
    bool bSprintOnlyInUrgentMode() const { return Read<bool>(uintptr_t(this) + 0xf7); } // 0xf7 (Size: 0x1, Type: BoolProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* MovementSkillSet() const { return Read<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* AimingSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    float TacticalSprintTriggerChance() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float TacticalSprintTriggerChanceInUrgentMovement() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    float TacticalSprintJumpTriggerChance() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)

    void SET_AllowSprintKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_AllowSlideKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_JumpExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_TacticalSprintExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_SlideExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_UrgentMovementKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET_RangeAttackExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_MeleeAttackExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
    void SET_ThrowableAttackExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_ValidateSprintingBeforeTacticalSprinting(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0xc, Type: StructProperty)
    void SET_CanTacticalSprintJump(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0xc, Type: StructProperty)
    void SET_bSprintOnlyInWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf6, Value); } // 0xf6 (Size: 0x1, Type: BoolProperty)
    void SET_bSprintOnlyInUrgentMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf7, Value); } // 0xf7 (Size: 0x1, Type: BoolProperty)
    void SET_MovementSkillSet(const UFortAthenaAIBotMovementDigestedSkillSet*& Value) { Write<UFortAthenaAIBotMovementDigestedSkillSet*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_AimingSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_TacticalSprintTriggerChance(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_TacticalSprintTriggerChanceInUrgentMovement(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_TacticalSprintJumpTriggerChance(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x150
class UFortAthenaAIBotEvaluator_StealWall : public UFortAthenaAIBotEvaluator
{
public:
    FName StealWallBuildTypeName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName StealWallBuildGridCoordName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotBuildingDigestedSkillSet* CacheBuildingDigestedSkillSet() const { return Read<UFortAthenaAIBotBuildingDigestedSkillSet*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    ABuildingActor* CurrentBuildingTarget() const { return Read<ABuildingActor*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_StealWallBuildTypeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_StealWallBuildGridCoordName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_CacheBuildingDigestedSkillSet(const UFortAthenaAIBotBuildingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotBuildingDigestedSkillSet*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentBuildingTarget(const ABuildingActor*& Value) { Write<ABuildingActor*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1d0
class UFortAthenaAIBotEvaluator_StepBack : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CachedRangeAttackDigestedSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UAthenaAIServiceCover* CachedAIServiceCover() const { return Read<UAthenaAIServiceCover*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    FName StepBackExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName StepBackMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    FName StepBackDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: NameProperty)

    void SET_CachedRangeAttackDigestedSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedAIServiceCover(const UAthenaAIServiceCover*& Value) { Write<UAthenaAIServiceCover*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_StepBackExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_StepBackMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_StepBackDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x200
class UFortAthenaAIBotEvaluator_Storm : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName StormDestinationName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    AFortGameModeAthena* CacheAthenaGameMode() const { return Read<AFortGameModeAthena*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    UBehaviorTreeComponent* CachedBTComp() const { return Read<UBehaviorTreeComponent*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UFortGameStateComponent_BattleRoyaleGamePhaseLogic* CachedGamePhaseLogic() const { return Read<UFortGameStateComponent_BattleRoyaleGamePhaseLogic*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)

    void SET_StormDestinationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_CacheAthenaGameMode(const AFortGameModeAthena*& Value) { Write<AFortGameModeAthena*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedBTComp(const UBehaviorTreeComponent*& Value) { Write<UBehaviorTreeComponent*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedGamePhaseLogic(const UFortGameStateComponent_BattleRoyaleGamePhaseLogic*& Value) { Write<UFortGameStateComponent_BattleRoyaleGamePhaseLogic*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x100
class UFortAthenaAIBotEvaluator_TagQueryToBBKey : public UFortAthenaAIBotEvaluator_TagQuery
{
public:
    FName LinkedBBKeyName() const { return Read<FName>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: NameProperty)

    void SET_LinkedBBKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x230
class UFortAthenaAIBotEvaluator_TakeCover : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    UAthenaAIServiceCover* CachedAIServiceCover() const { return Read<UAthenaAIServiceCover*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    FName DestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    FName HealingStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName() const { return Read<FName>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: NameProperty)
    FName BunkerStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: NameProperty)
    ABuildingActor* CachedCoverBuildingActor() const { return Read<ABuildingActor*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    TArray<ABuildingActor*> ExcludedBuildingActors() const { return Read<TArray<ABuildingActor*>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)

    void SET_CacheRangeAttackDigestedSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedAIServiceCover(const UAthenaAIServiceCover*& Value) { Write<UAthenaAIServiceCover*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_DestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_MoveToDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_HealingStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: NameProperty)
    void SET_WeaponFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: NameProperty)
    void SET_BunkerStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: NameProperty)
    void SET_CachedCoverBuildingActor(const ABuildingActor*& Value) { Write<ABuildingActor*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExcludedBuildingActors(const TArray<ABuildingActor*>& Value) { Write<TArray<ABuildingActor*>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x208
class UFortAthenaAIBotEvaluator_ThrowableAttack : public UFortAthenaAIBotEvaluator_Attack
{
public:
    FName WeaponTriggerThrowableName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName ThrowableAttackIsReadyToThrowName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* AttackingSkillSet() const { return Read<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* RangeAttackSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* AimingSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UFortWorldItem* ChosenWeapon() const { return Read<UFortWorldItem*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)

    void SET_WeaponTriggerThrowableName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_ThrowableAttackIsReadyToThrowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_AttackingSkillSet(const UFortAthenaAIBotAttackingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    void SET_RangeAttackSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    void SET_AimingSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_ChosenWeapon(const UFortWorldItem*& Value) { Write<UFortWorldItem*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
class UFortAthenaAIBotEvaluator_TrapOnPathDetected : public UFortAthenaAIBotEvaluator
{
public:
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FName TrapOnPathKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName TrapActorOnPathKeyName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName AlertLevelName() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    FName RangeAttackExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    ABuildingTrap* CurrentTrapTarget() const { return Read<ABuildingTrap*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_TrapOnPathKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_TrapActorOnPathKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_AlertLevelName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET_RangeAttackExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_CurrentTrapTarget(const ABuildingTrap*& Value) { Write<ABuildingTrap*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x250
class UFortAthenaAIBotEvaluator_VehicleCombatNavigation : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FValueOrBBKey_Float ExecutionDuration() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float ExecutionDurationDeviation() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float CooldownDurationDeviation() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToStart() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToStartWhenTargetMatchesOptionalTags() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToGoOnCooldown() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToGoOnCooldownWhenTargetMatchesOptionalTags() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_GameplayTagContainer OptionalTargetTagsToMatch() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x28, Type: StructProperty)

    void SET_ExecutionDuration(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0xc, Type: StructProperty)
    void SET_ExecutionDurationDeviation(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0xc, Type: StructProperty)
    void SET_CooldownDuration(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0xc, Type: StructProperty)
    void SET_CooldownDurationDeviation(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0xc, Type: StructProperty)
    void SET_OddsToStart(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0xc, Type: StructProperty)
    void SET_OddsToStartWhenTargetMatchesOptionalTags(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0xc, Type: StructProperty)
    void SET_OddsToGoOnCooldown(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0xc, Type: StructProperty)
    void SET_OddsToGoOnCooldownWhenTargetMatchesOptionalTags(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0xc, Type: StructProperty)
    void SET_OptionalTargetTagsToMatch(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x28, Type: StructProperty)
};

// Size: 0xb0
class UFortAthenaAIBotEvaluator_VehicleEscalate : public UFortAthenaAIBotEvaluator
{
public:
};

// Size: 0xb0
class UFortAthenaAIBotEvaluator_VehicleLeaveSeat : public UFortAthenaAIBotEvaluator
{
public:
    FName LeaveSeatStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    bool bLeaveSeatWhenPlayerInVehicle() const { return Read<bool>(uintptr_t(this) + 0xae); } // 0xae (Size: 0x1, Type: BoolProperty)
    bool bLeaveSeatWhenConverterLeave() const { return Read<bool>(uintptr_t(this) + 0xaf); } // 0xaf (Size: 0x1, Type: BoolProperty)

    void SET_LeaveSeatStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_bLeaveSeatWhenPlayerInVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0xae, Value); } // 0xae (Size: 0x1, Type: BoolProperty)
    void SET_bLeaveSeatWhenConverterLeave(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaf, Value); } // 0xaf (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
class UFortAthenaAIBotEvaluator_VehicleSwitchSeat : public UFortAthenaAIBotEvaluator
{
public:
    FName SwitchSeatStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool bSwitchToDriverSeatIfEmpty() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0xc, Type: StructProperty)
    bool bSwitchToEmptyDriverSeat() const { return Read<bool>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x1, Type: BoolProperty)

    void SET_SwitchSeatStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_bSwitchToDriverSeatIfEmpty(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0xc, Type: StructProperty)
    void SET_bSwitchToEmptyDriverSeat(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UFortAthenaAIBotEvaluator_WaitForPassengers : public UFortAthenaAIBotEvaluator
{
public:
    FName WaitForPassengersStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)

    void SET_WaitForPassengersStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
};

// Size: 0xd8
class UFortAthenaAIBotEvaluator_Warmup : public UFortAthenaAIBotEvaluator
{
public:
    FName WarmupPlayEmoteExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName WarmupLootAndShootExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName WarmupIdleExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotWarmupDigestedSkillSet* CacheWarmupDigestedSkillSet() const { return Read<UFortAthenaAIBotWarmupDigestedSkillSet*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_WarmupPlayEmoteExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_WarmupLootAndShootExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_WarmupIdleExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_CacheWarmupDigestedSkillSet(const UFortAthenaAIBotWarmupDigestedSkillSet*& Value) { Write<UFortAthenaAIBotWarmupDigestedSkillSet*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe8
class UFortAthenaAIBotEvaluator_WeaponSelection : public UFortAthenaAIBotEvaluator
{
public:
    FName ThrowableAttackIsReadyToThrowName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetActorName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName IsManningTurretKeyName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName UseItemSelectNewWeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet() const { return Read<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet() const { return Read<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_ThrowableAttackIsReadyToThrowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_TargetActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_IsManningTurretKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_UseItemSelectNewWeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_CacheRangeAttackDigestedSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheAttackingDigestedSkillSet(const UFortAthenaAIBotAttackingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAttackingDigestedSkillSet*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_CacheAimingDigestedSkillSet(const UFortAthenaAIBotAimingDigestedSkillSet*& Value) { Write<UFortAthenaAIBotAimingDigestedSkillSet*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x250
class UFortAthenaAIBotEvaluator_Zipline : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName CurrentDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName ZiplineTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName LastZiplineUsedName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName ZiplineMoveExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FName ZiplineEntryLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName ZiplineExitLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName ZiplineLastUsageTimeName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName ZiplineUsageExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    FScalableFloat WaitTimeBetweenZiplineRandomChoices() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ProbabilityToUseZipline() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)

    void SET_CurrentDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_LastZiplineUsedName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineMoveExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_ZiplineEntryLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineExitLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineLastUsageTimeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineUsageExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_WaitTimeBetweenZiplineRandomChoices(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    void SET_ProbabilityToUseZipline(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x70
class UFortEvaluatorBlueprintBaseWorldConditionSchema : public UWorldConditionSchema
{
public:
};

// Size: 0x480
class UFortAthenaAIEvaluator_BlueprintBase : public UObject
{
public:
    bool bBlockWeaponActions() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bGameplayAbilityEvaluator() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    FGameplayAbilityEvaluatorModule GameplayAbilityEvaluatorModule() const { return Read<FGameplayAbilityEvaluatorModule>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x40, Type: StructProperty)
    bool bCooldownEvaluator() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    TArray<FFortEvaluatorBlueprintBaseCooldown> Cooldowns() const { return Read<TArray<FFortEvaluatorBlueprintBaseCooldown>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat Cooldown() const { return Read<FScalableFloat>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x28, Type: StructProperty)
    FScalableFloat CooldownVariation() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<ECooldownType> CooldownType() const { return Read<TEnumAsByte<ECooldownType>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: ByteProperty)
    bool bDistanceEvaluator() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    float StartDistance() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float OngoingDistance() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    FName DistanceTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: NameProperty)
    bool bDurationEvaluator() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    FScalableFloat duration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DurationVariation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x28, Type: StructProperty)
    bool bTokenEvaluator() const { return Read<bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery TokenQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x48, Type: StructProperty)
    FName TokenTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x4, Type: NameProperty)
    bool bTokenPositionEvaluator() const { return Read<bool>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x1, Type: BoolProperty)
    FEQSParametrizedQueryExecutionRequest EQSRequest() const { return Read<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x48, Type: StructProperty)
    bool bAllowStayingOnSamePosition() const { return Read<bool>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    bool bShouldCheckIfPositionIsDenied() const { return Read<bool>(uintptr_t(this) + 0x1e9); } // 0x1e9 (Size: 0x1, Type: BoolProperty)
    FName TokenPositionDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1ec); } // 0x1ec (Size: 0x4, Type: NameProperty)
    FName TokenPositionDefendSpotKeyName() const { return Read<FName>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x4, Type: NameProperty)
    FGameplayTagQuery GeneratedTokenPositioningQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    FName TokenPositioningTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: NameProperty)
    bool bWorldConditionEvaluator() const { return Read<bool>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x1, Type: BoolProperty)
    FWorldConditionQueryDefinition StartingWorldConditions() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x18, Type: StructProperty)
    FWorldConditionQueryDefinition OngoingWorldConditions() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x18, Type: StructProperty)
    FName StartingWorldConditionTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x4, Type: NameProperty)
    FName OngoingWorldConditionTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x27c); } // 0x27c (Size: 0x4, Type: NameProperty)
    FScalableFloat Interval() const { return Read<FScalableFloat>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FScalableFloat RandomVariation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    FWorldConditionQueryState StartingQueryState() const { return Read<FWorldConditionQueryState>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x30, Type: StructProperty)
    FWorldConditionQueryState OngoingQueryState() const { return Read<FWorldConditionQueryState>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x30, Type: StructProperty)
    UFortAICombatTokenConsumerComponent* CachedTokenConsumerComponent() const { return Read<UFortAICombatTokenConsumerComponent*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UBehaviorTreeComponent* CachedOwnerComponent() const { return Read<UBehaviorTreeComponent*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    AAIController* CachedController() const { return Read<AAIController*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    bool bEvaluateOnBlackboardKeyChange() const { return Read<bool>(uintptr_t(this) + 0x356); } // 0x356 (Size: 0x1, Type: BoolProperty)
    TArray<FName> ListeningBlackboardKeyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UFortAICombatTokenProviderComponent*> CachedTokenProviderComponent() const { return Read<TWeakObjectPtr<UFortAICombatTokenProviderComponent*>>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bBlockWeaponActions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bGameplayAbilityEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayAbilityEvaluatorModule(const FGameplayAbilityEvaluatorModule& Value) { Write<FGameplayAbilityEvaluatorModule>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x40, Type: StructProperty)
    void SET_bCooldownEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_Cooldowns(const TArray<FFortEvaluatorBlueprintBaseCooldown>& Value) { Write<TArray<FFortEvaluatorBlueprintBaseCooldown>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_Cooldown(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x28, Type: StructProperty)
    void SET_CooldownVariation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_CooldownType(const TEnumAsByte<ECooldownType>& Value) { Write<TEnumAsByte<ECooldownType>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: ByteProperty)
    void SET_bDistanceEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    void SET_StartDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_OngoingDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: NameProperty)
    void SET_bDurationEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_duration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x28, Type: StructProperty)
    void SET_DurationVariation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x28, Type: StructProperty)
    void SET_bTokenEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: BoolProperty)
    void SET_TokenQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x48, Type: StructProperty)
    void SET_TokenTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x4, Type: NameProperty)
    void SET_bTokenPositionEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x1, Type: BoolProperty)
    void SET_EQSRequest(const FEQSParametrizedQueryExecutionRequest& Value) { Write<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x48, Type: StructProperty)
    void SET_bAllowStayingOnSamePosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldCheckIfPositionIsDenied(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e9, Value); } // 0x1e9 (Size: 0x1, Type: BoolProperty)
    void SET_TokenPositionDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ec, Value); } // 0x1ec (Size: 0x4, Type: NameProperty)
    void SET_TokenPositionDefendSpotKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x4, Type: NameProperty)
    void SET_GeneratedTokenPositioningQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x48, Type: StructProperty)
    void SET_TokenPositioningTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: NameProperty)
    void SET_bWorldConditionEvaluator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x1, Type: BoolProperty)
    void SET_StartingWorldConditions(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x18, Type: StructProperty)
    void SET_OngoingWorldConditions(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x18, Type: StructProperty)
    void SET_StartingWorldConditionTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x4, Type: NameProperty)
    void SET_OngoingWorldConditionTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x27c, Value); } // 0x27c (Size: 0x4, Type: NameProperty)
    void SET_Interval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_RandomVariation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_StartingQueryState(const FWorldConditionQueryState& Value) { Write<FWorldConditionQueryState>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x30, Type: StructProperty)
    void SET_OngoingQueryState(const FWorldConditionQueryState& Value) { Write<FWorldConditionQueryState>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x30, Type: StructProperty)
    void SET_CachedTokenConsumerComponent(const UFortAICombatTokenConsumerComponent*& Value) { Write<UFortAICombatTokenConsumerComponent*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedOwnerComponent(const UBehaviorTreeComponent*& Value) { Write<UBehaviorTreeComponent*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_bEvaluateOnBlackboardKeyChange(const bool& Value) { Write<bool>(uintptr_t(this) + 0x356, Value); } // 0x356 (Size: 0x1, Type: BoolProperty)
    void SET_ListeningBlackboardKeyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedTokenProviderComponent(const TWeakObjectPtr<UFortAICombatTokenProviderComponent*>& Value) { Write<TWeakObjectPtr<UFortAICombatTokenProviderComponent*>>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x148
class UFortAthenaAIEvaluator_DormantUntilPhase : public UFortAthenaAIEvaluator
{
public:
    FScalableFloat bIsEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    bool bDisabledInCreative() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t RequiredGamePhaseStep() const { return Read<uint8_t>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    FScalableFloat DelayAfterPhase() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RandomDeviationAfterPhase() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x28, Type: StructProperty)

    void SET_bIsEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_bDisabledInCreative(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_RequiredGamePhaseStep(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    void SET_DelayAfterPhase(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x28, Type: StructProperty)
    void SET_RandomDeviationAfterPhase(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x28, Type: StructProperty)
};

// Size: 0xc8
class UFortAthenaAIEvaluator_FleeEnvDanger : public UFortAthenaAIEvaluator
{
public:
    float MaximumCheckDistance() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float AdditionalFleeDistance() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    FName EnvironmentalDangerExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    FName EnvironmentalDangerFleeDirectionFromKeyName() const { return Read<FName>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: NameProperty)
    FName EnvironmentalDangerFleeDirectionToKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName EnvironmentalDangerFleeDistanceKeyName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    AAIController* CachedController() const { return Read<AAIController*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_MaximumCheckDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_AdditionalFleeDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_EnvironmentalDangerExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_EnvironmentalDangerFleeDirectionFromKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: NameProperty)
    void SET_EnvironmentalDangerFleeDirectionToKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_EnvironmentalDangerFleeDistanceKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_CachedController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1d8
class UFortAthenaAIEvaluator_FollowGroupLeader : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FValueOrBBKey_Bool bBotsSkipSafeToReachLocationCheck() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0xc, Type: StructProperty)
    FName FollowGroupLeaderStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FName FollowGroupLeaderMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName FollowGroupLeaderDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName TooFarFromLeaderKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName HasLeaderToFollowKeyName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)

    void SET_bBotsSkipSafeToReachLocationCheck(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0xc, Type: StructProperty)
    void SET_FollowGroupLeaderStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_FollowGroupLeaderMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_FollowGroupLeaderDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_TooFarFromLeaderKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_HasLeaderToFollowKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
};

// Size: 0xc8
class UFortAthenaAIEvaluator_Leash : public UFortAthenaAIEvaluator
{
public:
    FName GoalIsInsideLeashKeyName() const { return Read<FName>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: NameProperty)
    FName AIIsInsideLeashKeyName() const { return Read<FName>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: NameProperty)
    FName LeashCenterLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    UFortAthenaLeashComponent* CachedLeashComponent() const { return Read<UFortAthenaLeashComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFortAIGoalComponent* CachedAIGoalComponent() const { return Read<UFortAIGoalComponent*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_GoalIsInsideLeashKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: NameProperty)
    void SET_AIIsInsideLeashKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: NameProperty)
    void SET_LeashCenterLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_CachedLeashComponent(const UFortAthenaLeashComponent*& Value) { Write<UFortAthenaLeashComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedAIGoalComponent(const UFortAIGoalComponent*& Value) { Write<UFortAIGoalComponent*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x240
class UFortAthenaAIEvaluator_NearbyActorsPerception : public UFortAthenaAIEvaluator
{
public:
    FName FoundNearbyActorKeyName() const { return Read<FName>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: NameProperty)
    FScalableFloat MinimumUpdateInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x28, Type: StructProperty)
    int32_t RequiredTypes() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)
    FScalableFloat MinimumDistanceToActors() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x28, Type: StructProperty)
    TArray<TEnumAsByte<ETeamAttitude>> RequiredAttitudes() const { return Read<TArray<TEnumAsByte<ETeamAttitude>>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    bool bRequireLoS() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery RequiredTagsQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x48, Type: StructProperty)

    void SET_FoundNearbyActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: NameProperty)
    void SET_MinimumUpdateInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x28, Type: StructProperty)
    void SET_RequiredTypes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
    void SET_MinimumDistanceToActors(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x28, Type: StructProperty)
    void SET_RequiredAttitudes(const TArray<TEnumAsByte<ETeamAttitude>>& Value) { Write<TArray<TEnumAsByte<ETeamAttitude>>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_bRequireLoS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
    void SET_RequiredTagsQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x48, Type: StructProperty)
};

// Size: 0x188
class UFortAthenaAIEvaluator_SmartObjects : public UFortAthenaAIEvaluator
{
public:
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem() const { return Read<USmartObjectSubsystem*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EvaluationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen() const { return Read<bool>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport() const { return Read<bool>(uintptr_t(this) + 0xbd); } // 0xbd (Size: 0x1, Type: BoolProperty)
    FScalableFloat MaximumEntryLocationsChecksPerEvaluation() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EntryLocationFailuresBlacklistedTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* DistanceToWeightCurveForSlotPicking() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    UClass* OverridenFilterClassForEntryPoints() const { return Read<UClass*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ClassProperty)
    TArray<FName> ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    FName SmartObjectExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName() const { return Read<FName>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName() const { return Read<FName>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer ForceDebugClosestSOTagsToRemoveOnPawn() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x20, Type: StructProperty)
    bool bFirstTimeRunForceDebugClosestSO() const { return Read<bool>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: BoolProperty)

    void SET_SmartObjectRuntimeParameters(const UFortAthenaAIRuntimeParameters_SmartObjectBase*& Value) { Write<UFortAthenaAIRuntimeParameters_SmartObjectBase*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    void SET_SmartObjectSubsystem(const USmartObjectSubsystem*& Value) { Write<USmartObjectSubsystem*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_EvaluationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: StructProperty)
    void SET_bEvaluateSOValidityAfterChosen(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x1, Type: BoolProperty)
    void SET_bEnableEntryLocationsSupport(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbd, Value); } // 0xbd (Size: 0x1, Type: BoolProperty)
    void SET_MaximumEntryLocationsChecksPerEvaluation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_EntryLocationFailuresBlacklistedTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
    void SET_DistanceToWeightCurveForSlotPicking(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_OverridenFilterClassForEntryPoints(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ClassProperty)
    void SET_ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_SmartObjectExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationRotationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectShouldMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectUrgencyKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: NameProperty)
    void SET_ForceDebugClosestSOTagsToRemoveOnPawn(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x20, Type: StructProperty)
    void SET_bFirstTimeRunForceDebugClosestSO(const bool& Value) { Write<bool>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x240
class UFortAthenaAIEvaluator_SpeechBubble : public UFortAthenaAIEvaluator_NearbyActorsPerception
{
public:
    UFortPawnComponent_SpeechBubble* CachedSpeechBubbleComponent() const { return Read<UFortPawnComponent_SpeechBubble*>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x8, Type: ObjectProperty)

    void SET_CachedSpeechBubbleComponent(const UFortPawnComponent_SpeechBubble*& Value) { Write<UFortPawnComponent_SpeechBubble*>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x80
class UFortAthenaBTContext_SuppressAutomaticAttackCheck : public UFortBTService_ContextOverride
{
public:
};

// Size: 0xa8
class UFortAthenaBTService_AgentOffNavigationData : public UBTService
{
public:
    FName AgentIsOffNavigationDataKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    bool bEvaluateOnTick() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)
    FScalableFloat TickInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    bool bEvaluateOnMoveRequestFinished() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_AgentIsOffNavigationDataKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_bEvaluateOnTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
    void SET_TickInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_bEvaluateOnMoveRequestFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
class UFortAthenaBTService_AIEvaluator : public UBTService
{
public:
    FGameplayTag InjectionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Class AIEvaluatorClass() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)

    void SET_InjectionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
    void SET_AIEvaluatorClass(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
};

// Size: 0x98
class UFortAthenaBTService_ApplyGameplayEffect : public UBTService
{
public:
    FValueOrBBKey_Class GameplayEffectClass() const { return Read<FValueOrBBKey_Class>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Float GameplayEffectLevel() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0xc, Type: StructProperty)

    void SET_GameplayEffectClass(const FValueOrBBKey_Class& Value) { Write<FValueOrBBKey_Class>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_GameplayEffectLevel(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0xc, Type: StructProperty)
};

// Size: 0xb0
class UFortAthenaBTService_ApplyGameplayTags : public UBTService
{
public:
    FValueOrBBKey_GameplayTagContainer GameplayTagsToApply() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool bReplicateTags() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool RemoveTagsOnCeaseRelevant() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0xc, Type: StructProperty)

    void SET_GameplayTagsToApply(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_bReplicateTags(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
    void SET_RemoveTagsOnCeaseRelevant(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0xc, Type: StructProperty)
};

// Size: 0x70
class UFortAthenaBTService_ApplyPatrolTags : public UBTService
{
public:
};

// Size: 0x88
class UFortAthenaBTService_BuildConstruction : public UBTService
{
public:
    FName StealWallBuildName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName StealWallBuildTypeName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName StealWallBuildGridCoordName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)

    void SET_StealWallBuildName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_StealWallBuildTypeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_StealWallBuildGridCoordName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
};

// Size: 0xa8
class UFortAthenaBTService_Clamber : public UBTService
{
public:
    FName ClamberExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ClamberOriginLocationName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName ClamberDestinationLocationName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName ClamberAbilityStatusName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FName CrouchExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: NameProperty)
    uint32_t FirstJumpRetryMaxCount() const { return Read<uint32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: UInt32Property)
    uint32_t ClamberAttemptRetryMaxCount() const { return Read<uint32_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: UInt32Property)
    float FirstJumpRetryDelay() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float FirstJumpClamberMaxStartDelay() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float ClamberRetryDelay() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)

    void SET_ClamberExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ClamberOriginLocationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_ClamberDestinationLocationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_ClamberAbilityStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_JumpExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_CrouchExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: NameProperty)
    void SET_FirstJumpRetryMaxCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: UInt32Property)
    void SET_ClamberAttemptRetryMaxCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: UInt32Property)
    void SET_FirstJumpRetryDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_FirstJumpClamberMaxStartDelay(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_ClamberRetryDelay(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe8
class UFortAthenaBTService_CopyActorLocation : public UBTService
{
public:
    FBlackboardKeySelector SourceBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DestinationBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool bCopyOnBecomeRelevant() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bCopyOnCeaseRelevant() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bCopyWhenSourceValueChange() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0xc, Type: StructProperty)

    void SET_SourceBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_DestinationBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_bCopyOnBecomeRelevant(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xc, Type: StructProperty)
    void SET_bCopyOnCeaseRelevant(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0xc, Type: StructProperty)
    void SET_bCopyWhenSourceValueChange(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0xc, Type: StructProperty)
};

// Size: 0xc8
class UFortAthenaBTService_CopyBlackboardVariable : public UBTService
{
public:
    FBlackboardKeySelector SourceBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DestinationBlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    bool bCopyOnBecomeRelevant() const { return (Read<uint8_t>(uintptr_t(this) + 0xc0) >> 0x0) & 1; } // 0xc0:0 (Size: 0x1, Type: BoolProperty)
    bool bCopyOnCeaseRelevant() const { return (Read<uint8_t>(uintptr_t(this) + 0xc0) >> 0x1) & 1; } // 0xc0:1 (Size: 0x1, Type: BoolProperty)
    bool bCopyWhenSourceValueChange() const { return (Read<uint8_t>(uintptr_t(this) + 0xc0) >> 0x2) & 1; } // 0xc0:2 (Size: 0x1, Type: BoolProperty)

    void SET_SourceBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_DestinationBlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_bCopyOnBecomeRelevant(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc0, B); } // 0xc0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyOnCeaseRelevant(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xc0, B); } // 0xc0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bCopyWhenSourceValueChange(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xc0, B); } // 0xc0:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UFortAthenaBTService_Crouch : public UBTService
{
public:
    FName CrouchExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_CrouchExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0x80
class UFortAthenaBTService_Escape : public UBTService
{
public:
    FName EscapeKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName EscapeFromStormKeyName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)

    void SET_EscapeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_EscapeFromStormKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
};

// Size: 0xf8
class UFortAthenaBTService_HeightMap : public UBTService
{
public:
    FName HeightMapAverageFloorHeightKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FScalableFloat AverageFloorHeightRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat AverageFloorHeightHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AverageFloorHeightUseLowResolution() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)

    void SET_HeightMapAverageFloorHeightKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_AverageFloorHeightRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_AverageFloorHeightHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_AverageFloorHeightUseLowResolution(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x140
class UFortAthenaBTService_Interact : public UBTService
{
public:
    FBlackboardKeySelector InteractExecutionStatusKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector InteractContextInfoKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector InteractObjectKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector ExecutionStatusKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector MovementStateKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EInteractionBeingAttempted> InteractionBeingAttempted() const { return Read<TEnumAsByte<EInteractionBeingAttempted>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: ByteProperty)
    bool bRequireDistanceCheck() const { return Read<bool>(uintptr_t(this) + 0x139); } // 0x139 (Size: 0x1, Type: BoolProperty)
    bool bRequireBlockedCheck() const { return Read<bool>(uintptr_t(this) + 0x13a); } // 0x13a (Size: 0x1, Type: BoolProperty)

    void SET_InteractExecutionStatusKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_InteractContextInfoKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_InteractObjectKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_ExecutionStatusKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
    void SET_MovementStateKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
    void SET_InteractionBeingAttempted(const TEnumAsByte<EInteractionBeingAttempted>& Value) { Write<TEnumAsByte<EInteractionBeingAttempted>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: ByteProperty)
    void SET_bRequireDistanceCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x139, Value); } // 0x139 (Size: 0x1, Type: BoolProperty)
    void SET_bRequireBlockedCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13a, Value); } // 0x13a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UFortAthenaBTService_JetpackStrafe : public UFortAthenaBTService_Jump
{
public:
    FName JetpackStrafeExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet() const { return Read<UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_JetpackStrafeExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_CacheEMDigestedSkillSet(const UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*& Value) { Write<UFortAthenaAIBotEvasiveManeuversDigestedSkillSet*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UFortAthenaBTService_Jump : public UBTService
{
public:
    FName JumpExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName CrouchExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    float JumpInputReleaseDelay() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)

    void SET_JumpExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_CrouchExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_JumpInputReleaseDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UFortAthenaBTService_JumpOffBus : public UBTService
{
public:
    FName JumpOffBusExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_JumpOffBusExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0xc8
class UFortAthenaBTService_ManageVehicleWeapon : public UFortAthenaBTService_ManageWeapon
{
public:
};

// Size: 0xc8
class UFortAthenaBTService_ManageWeapon : public UBTService
{
public:
    FName WeaponFireName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerThrowableName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName WeaponReloadName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    FName WeaponName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FName WeaponTargetingName() const { return Read<FName>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: NameProperty)
    FName SprintExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: NameProperty)
    FName HealingStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)
    FName BlockWeaponActionsKeyName() const { return Read<FName>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: NameProperty)
    FName RangedWeaponCancelAutoReloadKeyName() const { return Read<FName>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool AllowAttackingWhileSprinting() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0xc, Type: StructProperty)
    bool bEndChargeOnFireStop() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)

    void SET_WeaponFireName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerThrowableName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_WeaponReloadName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_WeaponName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTargetingName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: NameProperty)
    void SET_SprintExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_TacticalSprintExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: NameProperty)
    void SET_HealingStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
    void SET_BlockWeaponActionsKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: NameProperty)
    void SET_RangedWeaponCancelAutoReloadKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: NameProperty)
    void SET_AllowAttackingWhileSprinting(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0xc, Type: StructProperty)
    void SET_bEndChargeOnFireStop(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe0
class UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween : public UBTService
{
public:
    FBlackboardKeySelector BlackboardKeyA() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    float MinDistance() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MaxDistance() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float MinDistanceSpeed() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceSpeed() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bCalculateAs2D() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)

    void SET_BlackboardKeyA(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_BlackboardKeyB(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_MinDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_MinDistanceSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistanceSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_bCalculateAs2D(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd8
class UFortAthenaBTService_MovementListener : public UBTService
{
public:
    FName MovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName IsStuckKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    bool bSuccessPartialAsFail() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    FScalableFloat MaxFailCount() const { return Read<FScalableFloat>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDurationToFail() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x28, Type: StructProperty)

    void SET_MovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_IsStuckKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_bSuccessPartialAsFail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_MaxFailCount(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
    void SET_MaxDurationToFail(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x90
class UFortAthenaBTService_Patrolling : public UBTService
{
public:
    FName PatrollingAppendDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    float AcceptableRadius() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    UClass* FilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ClassProperty)
    bool bAllowPartialPath() const { return (Read<uint8_t>(uintptr_t(this) + 0x88) >> 0x0) & 1; } // 0x88:0 (Size: 0x1, Type: BoolProperty)
    bool bProjectGoalLocation() const { return (Read<uint8_t>(uintptr_t(this) + 0x88) >> 0x1) & 1; } // 0x88:1 (Size: 0x1, Type: BoolProperty)

    void SET_PatrollingAppendDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_AcceptableRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_FilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ClassProperty)
    void SET_bAllowPartialPath(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x88); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x88, B); } // 0x88:0 (Size: 0x1, Type: BoolProperty)
    void SET_bProjectGoalLocation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x88); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x88, B); } // 0x88:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
class UFortAthenaBTService_PauseVehicle : public UBTService
{
public:
};

// Size: 0x90
class UFortAthenaBTService_PerceptionCheck : public UBTService
{
public:
    FValueOrBBKey_Object PerceptionTargetActorKey() const { return Read<FValueOrBBKey_Object>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FName PerceptionTargetActorIsBeingSeenKeyName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)

    void SET_PerceptionTargetActorKey(const FValueOrBBKey_Object& Value) { Write<FValueOrBBKey_Object>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_PerceptionTargetActorIsBeingSeenKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
};

// Size: 0x90
class UFortAthenaBTService_PickUpLoot : public UBTService
{
public:
    FName LootObjectKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName InteractionExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName InteractionContextInfoName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    FName MovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)

    void SET_LootObjectKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_InteractionExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_InteractionContextInfoName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_MovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
};

// Size: 0x78
class UFortAthenaBTService_PropagatePatrolProgressToPassengers : public UBTService
{
public:
    FName PatrollingAppendDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_PatrollingAppendDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0x90
class UFortAthenaBTService_Revive : public UBTService
{
public:
    FName ReviveTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName MoveToPathMovementStateName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName InteractionExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    FName InteractionContextInfoName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    bool bDisableLeash() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)

    void SET_ReviveTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_MoveToPathMovementStateName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_InteractionExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_InteractionContextInfoName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_bDisableLeash(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
class UFortAthenaBTService_SetAIFocus : public UBTService_DefaultFocus
{
public:
    uint8_t FocusPriorityToSet() const { return Read<uint8_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: EnumProperty)

    void SET_FocusPriorityToSet(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xa0
class UFortAthenaBTService_SetBlackboardBool : public UBTService
{
public:
    FBlackboardKeySelector BlackboardKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    bool bBlackboardValue() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t ExitAction() const { return Read<uint8_t>(uintptr_t(this) + 0x99); } // 0x99 (Size: 0x1, Type: EnumProperty)

    void SET_BlackboardKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_bBlackboardValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_ExitAction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x99, Value); } // 0x99 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xa0
class UFortAthenaBTService_SetExecutionStatus : public UBTService_BlackboardBase
{
public:
    uint8_t ExecutionStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: EnumProperty)

    void SET_ExecutionStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x78
class UFortAthenaBTService_Slide : public UBTService
{
public:
    FName SlideExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_SlideExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0x88
class UFortAthenaBTService_SmartObject : public UBTService
{
public:
    FName SmartObjectStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FGameplayTag EvaluationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: StructProperty)

    void SET_SmartObjectStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_EvaluationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: StructProperty)
};

// Size: 0xe0
class UFortAthenaBTService_Sprinting : public UBTService
{
public:
    FName SprintExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintOverridenName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool EnableSprinting() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ValidateSprintingBeforeTacticalSprinting() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)

    void SET_SprintExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET_TacticalSprintExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET_TacticalSprintOverridenName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_EnableSprinting(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0xc, Type: StructProperty)
    void SET_ValidateSprintingBeforeTacticalSprinting(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
};

// Size: 0x70
class UFortAthenaBTService_UpdateTarget : public UBTService
{
public:
};

// Size: 0xb8
class UFortAthenaBTService_UseItem : public UBTService
{
public:
    FName ActionObjectKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName CanMoveWhileUsingItemKeyName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool bUseAlternateMode() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bCanUseInputToDeactivateKeyName() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0xc, Type: StructProperty)
    int32_t MaxEquipAttempts() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)
    float EquipRetryInterval() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float UseItemDelay() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float MinWaitTimeBetweenUses() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float MaxWaitTimeBetweenUses() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    float ItemUsageTimeout() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    bool bCanOnlyUseMobileItems() const { return Read<bool>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x1, Type: BoolProperty)
    bool bBlockWeaponActions() const { return Read<bool>(uintptr_t(this) + 0xad); } // 0xad (Size: 0x1, Type: BoolProperty)
    bool bValidateAbility() const { return Read<bool>(uintptr_t(this) + 0xae); } // 0xae (Size: 0x1, Type: BoolProperty)
    bool bResetActionObjectKey() const { return Read<bool>(uintptr_t(this) + 0xaf); } // 0xaf (Size: 0x1, Type: BoolProperty)

    void SET_ActionObjectKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_CanMoveWhileUsingItemKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_bUseAlternateMode(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0xc, Type: StructProperty)
    void SET_bCanUseInputToDeactivateKeyName(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0xc, Type: StructProperty)
    void SET_MaxEquipAttempts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
    void SET_EquipRetryInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_UseItemDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_MinWaitTimeBetweenUses(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxWaitTimeBetweenUses(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_ItemUsageTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_bCanOnlyUseMobileItems(const bool& Value) { Write<bool>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x1, Type: BoolProperty)
    void SET_bBlockWeaponActions(const bool& Value) { Write<bool>(uintptr_t(this) + 0xad, Value); } // 0xad (Size: 0x1, Type: BoolProperty)
    void SET_bValidateAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0xae, Value); } // 0xae (Size: 0x1, Type: BoolProperty)
    void SET_bResetActionObjectKey(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaf, Value); } // 0xaf (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UFortAthenaBTService_WaitForPassengers : public UBTService
{
public:
    FName WaitForPassengersStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_WaitForPassengersStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0xb8
class UFortAthenaBTService_Zipline : public UBTService
{
public:
    FName ZiplineTargetName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName InteractionExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName InteractionContextInfoName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FName UsageExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    FName ZiplineEntryLocationName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FName ZiplineExitLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: NameProperty)
    FName MoveToPathMovementStateName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    FName MoveExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: NameProperty)
    FName FocalPointName() const { return Read<FName>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: NameProperty)

    void SET_ZiplineTargetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_InteractionExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_InteractionContextInfoName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_UsageExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_ZiplineEntryLocationName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineExitLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: NameProperty)
    void SET_MoveToPathMovementStateName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_MoveExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: NameProperty)
    void SET_FocalPointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: NameProperty)
};

// Size: 0x80
class UFortAthenaBTTask_ActivateVehicleBoost : public UBTTaskNode
{
public:
    bool bActivateBoost() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    float BoostLength() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bIgnoreMinimumDistanceLeft() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_bActivateBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_BoostLength(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_bIgnoreMinimumDistanceLeft(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x170
class UFortAthenaBTTask_BotMoveTo : public UFortAthenaBTTask_MoveTo
{
public:
    FName NoSmashMoveGoalActorKeyName() const { return Read<FName>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: NameProperty)
    bool bAllowRandomWobble() const { return (Read<uint8_t>(uintptr_t(this) + 0x146) >> 0x0) & 1; } // 0x146:0 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Bool AllowRandomWobble() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0xc, Type: StructProperty)
    bool bIsUrgentMovement() const { return (Read<uint8_t>(uintptr_t(this) + 0x154) >> 0x0) & 1; } // 0x154:0 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Bool IsUrgentMovement() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool IgnoreObstaclesOnPath() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0xc, Type: StructProperty)

    void SET_NoSmashMoveGoalActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: NameProperty)
    void SET_bAllowRandomWobble(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x146); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x146, B); } // 0x146:0 (Size: 0x1, Type: BoolProperty)
    void SET_AllowRandomWobble(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0xc, Type: StructProperty)
    void SET_bIsUrgentMovement(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x154); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x154, B); } // 0x154:0 (Size: 0x1, Type: BoolProperty)
    void SET_IsUrgentMovement(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0xc, Type: StructProperty)
    void SET_IgnoreObstaclesOnPath(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0xc, Type: StructProperty)
};

// Size: 0x140
class UFortAthenaBTTask_MoveTo : public UBTTask_MoveTo
{
public:
    FName MovementResultKeyName() const { return Read<FName>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: NameProperty)
    bool bAllowRestartOnPartialSuccess() const { return (Read<uint8_t>(uintptr_t(this) + 0x13c) >> 0x0) & 1; } // 0x13c:0 (Size: 0x1, Type: BoolProperty)
    bool bAllowPartialPathToUncompleteNavigationArea() const { return (Read<uint8_t>(uintptr_t(this) + 0x13c) >> 0x1) & 1; } // 0x13c:1 (Size: 0x1, Type: BoolProperty)

    void SET_MovementResultKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: NameProperty)
    void SET_bAllowRestartOnPartialSuccess(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x13c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x13c, B); } // 0x13c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowPartialPathToUncompleteNavigationArea(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x13c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x13c, B); } // 0x13c:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe8
class UFortAthenaBTTask_BotUnstuckTeleport : public UBTTaskNode
{
public:
    FEQSParametrizedQueryExecutionRequest EQSRequest() const { return Read<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x48, Type: StructProperty)
    FName CanReachDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName TeleportExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    FName LastPartialPathTimeKeyName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FName LastPartialPathCountKeyName() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)

    void SET_EQSRequest(const FEQSParametrizedQueryExecutionRequest& Value) { Write<FEQSParametrizedQueryExecutionRequest>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x48, Type: StructProperty)
    void SET_CanReachDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_TeleportExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET_LastPartialPathTimeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_LastPartialPathCountKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
};

// Size: 0xb0
class UFortAthenaBTTask_BotWait : public UBTTask_Wait
{
public:
    FBlackboardKeySelector WaitCompleteKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)

    void SET_WaitCompleteKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
};

// Size: 0x80
class UFortAthenaBTTask_Build : public UBTTaskNode
{
public:
    FName ExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName FocalPointName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)

    void SET_ExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_FocalPointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
};

// Size: 0x78
class UFortAthenaBTTask_Conversation : public UBTTaskNode
{
public:
    FName ConversationStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    bool bResetEvaluatorStatusKeyOnFinish() const { return Read<bool>(uintptr_t(this) + 0x76); } // 0x76 (Size: 0x1, Type: BoolProperty)

    void SET_ConversationStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_bResetEvaluatorStatusKeyOnFinish(const bool& Value) { Write<bool>(uintptr_t(this) + 0x76, Value); } // 0x76 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UFortAthenaBTTask_Dive : public UBTTaskNode
{
public:
    FName ExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName DiveDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)

    void SET_ExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_DiveDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
};

// Size: 0x78
class UFortAthenaBTTask_EnterVehicle : public UBTTaskNode
{
public:
    FName SelectedVehicleKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_SelectedVehicleKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0xc0
class UFortAthenaBTTask_EquipItem : public UBTTaskNode
{
public:
    FName WeaponKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName EquipItemKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool DisableEquipAnimation() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool WaitForEquipToFinish() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_GameplayTagContainer ItemTagToEquip() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x28, Type: StructProperty)

    void SET_WeaponKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_EquipItemKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_DisableEquipAnimation(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0xc, Type: StructProperty)
    void SET_WaitForEquipToFinish(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0xc, Type: StructProperty)
    void SET_ItemTagToEquip(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x28, Type: StructProperty)
};

// Size: 0x78
class UFortAthenaBTTask_Escalate : public UBTTaskNode
{
public:
};

// Size: 0x80
class UFortAthenaBTTask_Glide : public UBTTaskNode
{
public:
    FName ExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName GlideDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)

    void SET_ExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_GlideDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
};

// Size: 0xe8
class UFortAthenaBTTask_Interact : public UBTTaskNode
{
public:
    float AttemptInterval() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    int32_t MaxInteractAttempts() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    bool bShouldFocusOnInteraction() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    FBlackboardKeySelector InteractExecutionStatusKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector InteractContextInfoKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x28, Type: StructProperty)
    FName FocalPointName() const { return Read<FName>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: NameProperty)
    FName InteractActorName() const { return Read<FName>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName() const { return Read<FName>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: NameProperty)

    void SET_AttemptInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_MaxInteractAttempts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_bShouldFocusOnInteraction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_InteractExecutionStatusKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
    void SET_InteractContextInfoKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x28, Type: StructProperty)
    void SET_FocalPointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: NameProperty)
    void SET_InteractActorName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: NameProperty)
    void SET_JumpExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: NameProperty)
    void SET_WeaponTriggerMeleeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: NameProperty)
};

// Size: 0x78
class UFortAthenaBTTask_LeaveVehicle : public UBTTaskNode
{
public:
    bool bWaitVehicleStop() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_bWaitVehicleStop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UFortAthenaBTTask_ModulateVehicleSpeed : public UBTTaskNode
{
public:
    FValueOrBBKey_Float DrivingSpeed() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)
    float NewDrivingSpeed() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    bool bResetControlPIDs() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_DrivingSpeed(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
    void SET_NewDrivingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_bResetControlPIDs(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UFortAthenaBTTask_PauseVehicle : public UBTTaskNode
{
public:
    bool bPausePathFollow() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_bPausePathFollow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UFortAthenaBTTask_PlayEmote : public UBTTaskNode
{
public:
    FName PlayEmoteExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    TArray<UAthenaDanceItemDefinition*> BespokeEmotes() const { return Read<TArray<UAthenaDanceItemDefinition*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_PlayEmoteExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_BespokeEmotes(const TArray<UAthenaDanceItemDefinition*>& Value) { Write<TArray<UAthenaDanceItemDefinition*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UFortAthenaBTTask_ReverseVehicle : public UBTTaskNode
{
public:
    bool bReverseVehicle() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_bReverseVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
class UFortAthenaBTTask_RunDynamicSubtree : public UBTTask_RunBehaviorDynamic
{
public:
    bool bCallParentOnInstanceCreated() const { return (Read<uint8_t>(uintptr_t(this) + 0x88) >> 0x0) & 1; } // 0x88:0 (Size: 0x1, Type: BoolProperty)

    void SET_bCallParentOnInstanceCreated(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x88); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x88, B); } // 0x88:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UFortAthenaBTTask_SetAggressiveDriving : public UBTTaskNode
{
public:
    bool bAggressiveDriving() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_bAggressiveDriving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb8
class UFortAthenaBTTask_ShootTrap : public UBTTask_Wait
{
public:
    FBlackboardKeySelector TargetActorKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)
    FName TrapOnPathKeyName() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)

    void SET_TargetActorKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
    void SET_TrapOnPathKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
};

// Size: 0xa0
class UFortAthenaBTTask_SteerMovement : public UBTTaskNode
{
public:
    FBlackboardKeySelector SteerDirectionKeySelector() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    bool bSetControlRotation() const { return (Read<uint8_t>(uintptr_t(this) + 0x98) >> 0x0) & 1; } // 0x98:0 (Size: 0x1, Type: BoolProperty)

    void SET_SteerDirectionKeySelector(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_bSetControlRotation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x98); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x98, B); } // 0x98:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UFortAthenaBTTask_Undermine : public UBTTaskNode
{
public:
    FName UndermineTargetKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName UndermineLocationImpactName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName UndermineExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)

    void SET_UndermineTargetKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_UndermineLocationImpactName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_UndermineExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
};

// Size: 0xf0
class UFortAthenaBTTask_UseItem : public UBTTaskNode
{
public:
    FName ActionObjectKeyName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName UseItemSelectNewWeaponName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Float MinimumWaitTimeBetweenUses() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MaximumWaitTimeBetweenUses() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ValidateAbility() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ValidateAbilityBeforeEquipping() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ResetActionObjectKey() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xac); } // 0xac (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool UseAlternateMode() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FinishAfterItemUse() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool UnequipAndRemoveAfterItemUse() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0xc, Type: StructProperty)
    float MinWaitTimeBetweenUses() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float MaxWaitTimeBetweenUses() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    bool bValidateAbility() const { return Read<bool>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x1, Type: BoolProperty)
    bool bResetActionObjectKey() const { return Read<bool>(uintptr_t(this) + 0xed); } // 0xed (Size: 0x1, Type: BoolProperty)
    bool bUseAlternateMode() const { return Read<bool>(uintptr_t(this) + 0xee); } // 0xee (Size: 0x1, Type: BoolProperty)

    void SET_ActionObjectKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_UseItemSelectNewWeaponName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_MinimumWaitTimeBetweenUses(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0xc, Type: StructProperty)
    void SET_MaximumWaitTimeBetweenUses(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0xc, Type: StructProperty)
    void SET_ValidateAbility(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0xc, Type: StructProperty)
    void SET_ValidateAbilityBeforeEquipping(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0xc, Type: StructProperty)
    void SET_ResetActionObjectKey(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0xc, Type: StructProperty)
    void SET_UseAlternateMode(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0xc, Type: StructProperty)
    void SET_FinishAfterItemUse(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0xc, Type: StructProperty)
    void SET_UnequipAndRemoveAfterItemUse(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0xc, Type: StructProperty)
    void SET_MinWaitTimeBetweenUses(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxWaitTimeBetweenUses(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_bValidateAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x1, Type: BoolProperty)
    void SET_bResetActionObjectKey(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed, Value); } // 0xed (Size: 0x1, Type: BoolProperty)
    void SET_bUseAlternateMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xee, Value); } // 0xee (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
class UFortAthenaBTTask_UseSmartObject : public UBTTaskNode
{
public:
    FGameplayTag EvaluationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Bool AddFocusAndWait() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0xc, Type: StructProperty)
    FName SmartObjectsStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    bool bHandleAbortWithSoftDisable() const { return Read<bool>(uintptr_t(this) + 0x8e); } // 0x8e (Size: 0x1, Type: BoolProperty)

    void SET_EvaluationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: StructProperty)
    void SET_AddFocusAndWait(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0xc, Type: StructProperty)
    void SET_SmartObjectsStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_SmartObjectDestinationRotationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_bHandleAbortWithSoftDisable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8e, Value); } // 0x8e (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UFortAthenaBTTask_VehicleHonk : public UBTTaskNode
{
public:
    float MaxHonkTime() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float MinHonkTime() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float MaxFlickerTime() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float MinFlickerTime() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)

    void SET_MaxHonkTime(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_MinHonkTime(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_MaxFlickerTime(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_MinFlickerTime(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xa0
class UFortAthenaBTTask_VehicleTurnTo : public UBTTask_BlackboardBase
{
public:
    float Precision() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)

    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
class UFortAthenaBTTask_Zipline : public UBTTaskNode
{
public:
    FName UsageExecutionStatusName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName ZiplineTargetName() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)

    void SET_UsageExecutionStatusName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET_ZiplineTargetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
};

// Size: 0x448
class UFortAthenaNpcEvaluator_Encampment : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat EncampmentEnable() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentTentativeDelayMin() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentTentativeDelayMax() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentDurationMin() const { return Read<FScalableFloat>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentDurationMax() const { return Read<FScalableFloat>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x28, Type: StructProperty)
    FScalableFloat BuilderPercentage() const { return Read<FScalableFloat>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x28, Type: StructProperty)
    FScalableFloat BuilderMinDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x28, Type: StructProperty)
    FScalableFloat BuilderMaxDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat GuardMinDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat GuardMaxDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x28, Type: StructProperty)
    FScalableFloat AllowInSwimming() const { return Read<FScalableFloat>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x28, Type: StructProperty)
    FScalableFloat AllowInFalling() const { return Read<FScalableFloat>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSquadMembersCountToBuild() const { return Read<FScalableFloat>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x28, Type: StructProperty)
    FName EncampmentStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x4, Type: NameProperty)
    FName EncampmentMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x4, Type: NameProperty)
    FName EncampmentCenterLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x4, Type: NameProperty)
    FName EncampmentDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: NameProperty)
    FName EncampmentAroundCampFireLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: NameProperty)
    FName EncampmentRoleKeyName() const { return Read<FName>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: NameProperty)
    FName DefensiveBuildName() const { return Read<FName>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: NameProperty)

    void SET_EncampmentEnable(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    void SET_EncampmentTentativeDelayMin(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x28, Type: StructProperty)
    void SET_EncampmentTentativeDelayMax(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x28, Type: StructProperty)
    void SET_EncampmentDurationMin(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x28, Type: StructProperty)
    void SET_EncampmentDurationMax(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x28, Type: StructProperty)
    void SET_BuilderPercentage(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x28, Type: StructProperty)
    void SET_BuilderMinDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x28, Type: StructProperty)
    void SET_BuilderMaxDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x28, Type: StructProperty)
    void SET_GuardMinDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x28, Type: StructProperty)
    void SET_GuardMaxDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x28, Type: StructProperty)
    void SET_AllowInSwimming(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x28, Type: StructProperty)
    void SET_AllowInFalling(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x28, Type: StructProperty)
    void SET_MinSquadMembersCountToBuild(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x28, Type: StructProperty)
    void SET_EncampmentStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x4, Type: NameProperty)
    void SET_EncampmentMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x4, Type: NameProperty)
    void SET_EncampmentCenterLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x4, Type: NameProperty)
    void SET_EncampmentDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: NameProperty)
    void SET_EncampmentAroundCampFireLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: NameProperty)
    void SET_EncampmentRoleKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: NameProperty)
    void SET_DefensiveBuildName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x1d8
class UFortAthenaNpcEvaluator_FollowPatrolPath : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName FollowPatrolPathKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName FollowPatrolPathMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName FollowPatrolPathDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    float ChanceToTakeABreak() const { return Read<float>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    float BreakDurationMin() const { return Read<float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    float BreakDurationMax() const { return Read<float>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: FloatProperty)

    void SET_FollowPatrolPathKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_FollowPatrolPathMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_FollowPatrolPathDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_ChanceToTakeABreak(const float& Value) { Write<float>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    void SET_BreakDurationMin(const float& Value) { Write<float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    void SET_BreakDurationMax(const float& Value) { Write<float>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2f0
class UFortAthenaNpcEvaluator_FollowSquadLeader : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat FormationOffsetRadiusMin() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat FormationOffsetRadiusMax() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TooFarFromSquadLeaderDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxNoiseRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDurationNoiseEvaluate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDurationNoiseEvaluate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x28, Type: StructProperty)
    FName FollowSquadLeaderStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: NameProperty)
    FName FollowSquadLeaderMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x4, Type: NameProperty)
    FName FollowSquadLeaderDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: NameProperty)
    FName TooFarFromLeaderKeyName() const { return Read<FName>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: NameProperty)
    FVector CachedSquadFormationOffset() const { return Read<FVector>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x18, Type: StructProperty)
    FVector CachedNoiseOffset() const { return Read<FVector>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x18, Type: StructProperty)
    float CachedTooFarFromSquadLeaderDistanceSqr() const { return Read<float>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
    float LastNoiseOffsetUpdateTime() const { return Read<float>(uintptr_t(this) + 0x2e4); } // 0x2e4 (Size: 0x4, Type: FloatProperty)
    float DurationNoiseEvaluate() const { return Read<float>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x4, Type: FloatProperty)

    void SET_FormationOffsetRadiusMin(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    void SET_FormationOffsetRadiusMax(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x28, Type: StructProperty)
    void SET_TooFarFromSquadLeaderDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x28, Type: StructProperty)
    void SET_MaxNoiseRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x28, Type: StructProperty)
    void SET_MinDurationNoiseEvaluate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x28, Type: StructProperty)
    void SET_MaxDurationNoiseEvaluate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x28, Type: StructProperty)
    void SET_FollowSquadLeaderStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: NameProperty)
    void SET_FollowSquadLeaderMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x4, Type: NameProperty)
    void SET_FollowSquadLeaderDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: NameProperty)
    void SET_TooFarFromLeaderKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: NameProperty)
    void SET_CachedSquadFormationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x18, Type: StructProperty)
    void SET_CachedNoiseOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x18, Type: StructProperty)
    void SET_CachedTooFarFromSquadLeaderDistanceSqr(const float& Value) { Write<float>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
    void SET_LastNoiseOffsetUpdateTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2e4, Value); } // 0x2e4 (Size: 0x4, Type: FloatProperty)
    void SET_DurationNoiseEvaluate(const float& Value) { Write<float>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1e0
class UFortAthenaNpcEvaluator_Leash : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName LeashKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName LeashMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName LeashDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName LeashLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FName LeashOuterRadiusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName ShouldTeleportInLeashKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName TriggerLeashBehaviorKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    bool bAlwaysForceMoveToLeashCenter() const { return Read<bool>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    bool bForcePositionOnLeash() const { return Read<bool>(uintptr_t(this) + 0x1bd); } // 0x1bd (Size: 0x1, Type: BoolProperty)
    UClass* AvoidObstaclesFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ClassProperty)
    UFortAthenaAIRuntimeParameters_Leash* LeashRuntimeParameters() const { return Read<UFortAthenaAIRuntimeParameters_Leash*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)

    void SET_LeashKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_LeashMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_LeashDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_LeashLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_LeashOuterRadiusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_ShouldTeleportInLeashKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_TriggerLeashBehaviorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_bAlwaysForceMoveToLeashCenter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    void SET_bForcePositionOnLeash(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bd, Value); } // 0x1bd (Size: 0x1, Type: BoolProperty)
    void SET_AvoidObstaclesFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ClassProperty)
    void SET_LeashRuntimeParameters(const UFortAthenaAIRuntimeParameters_Leash*& Value) { Write<UFortAthenaAIRuntimeParameters_Leash*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x268
class UFortAthenaNpcEvaluator_Patrolling : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName PatrollingKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName PatrollingMovementStateKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName PatrollingDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName DynamicBlueprintStatusKeyName() const { return Read<FName>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: NameProperty)
    FName DynamicBlueprintActorKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName PatrollingShouldMoveKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName PatrollingAppendDestinationKeyName() const { return Read<FName>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName OptionalPatrollingPrioritizeKeyName() const { return Read<FName>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x4, Type: NameProperty)
    float DistanceToTestPoint() const { return Read<float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    bool bCanDisablePatrolling() const { return Read<bool>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x1, Type: BoolProperty)
    bool bCanReenablePatrolling() const { return Read<bool>(uintptr_t(this) + 0x1d5); } // 0x1d5 (Size: 0x1, Type: BoolProperty)
    float ReenableTimer() const { return Read<float>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: FloatProperty)
    bool bCanSelectNearestPatrolPointAtStart() const { return Read<bool>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0x1, Type: BoolProperty)
    bool bCanRetryOnPartialPathSuccess() const { return Read<bool>(uintptr_t(this) + 0x1dd); } // 0x1dd (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery RequiredTagQueryOnAIForPrioritizing() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x48, Type: StructProperty)
    FScalableFloat SecondsToPrioritizeNonCompletedPatrol() const { return Read<FScalableFloat>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x28, Type: StructProperty)
    UFortAthenaNpcPatrollingComponent* CachedNpcPatrollingComponent() const { return Read<UFortAthenaNpcPatrollingComponent*>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x8, Type: ObjectProperty)

    void SET_PatrollingKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: NameProperty)
    void SET_PatrollingMovementStateKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: NameProperty)
    void SET_PatrollingDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: NameProperty)
    void SET_DynamicBlueprintStatusKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: NameProperty)
    void SET_DynamicBlueprintActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: NameProperty)
    void SET_PatrollingShouldMoveKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: NameProperty)
    void SET_PatrollingAppendDestinationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: NameProperty)
    void SET_OptionalPatrollingPrioritizeKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x4, Type: NameProperty)
    void SET_DistanceToTestPoint(const float& Value) { Write<float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    void SET_bCanDisablePatrolling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x1, Type: BoolProperty)
    void SET_bCanReenablePatrolling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d5, Value); } // 0x1d5 (Size: 0x1, Type: BoolProperty)
    void SET_ReenableTimer(const float& Value) { Write<float>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: FloatProperty)
    void SET_bCanSelectNearestPatrolPointAtStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0x1, Type: BoolProperty)
    void SET_bCanRetryOnPartialPathSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1dd, Value); } // 0x1dd (Size: 0x1, Type: BoolProperty)
    void SET_RequiredTagQueryOnAIForPrioritizing(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x48, Type: StructProperty)
    void SET_SecondsToPrioritizeNonCompletedPatrol(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x28, Type: StructProperty)
    void SET_CachedNpcPatrollingComponent(const UFortAthenaNpcPatrollingComponent*& Value) { Write<UFortAthenaNpcPatrollingComponent*>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UFortQueryContext_BotPOIVolume : public UEnvQueryContext
{
public:
    bool bSetProjectedToNavmeshLocationAsContext() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FVector ProjectionExtent() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_bSetProjectedToNavmeshLocationAsContext(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_ProjectionExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa8
class UFortAthenaAttachToActorStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bHandleAthenaMovComponent() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)
    bool bSetPhysicsToQueryOnlyWhileAttached() const { return Read<bool>(uintptr_t(this) + 0x75); } // 0x75 (Size: 0x1, Type: BoolProperty)
    bool bTryToAttachToSkeletalMeshOnTargetActor() const { return Read<bool>(uintptr_t(this) + 0x76); } // 0x76 (Size: 0x1, Type: BoolProperty)
    bool bChangeBaseToSkeletalMeshOnTargetActor() const { return Read<bool>(uintptr_t(this) + 0x77); } // 0x77 (Size: 0x1, Type: BoolProperty)
    uint8_t AttachmentLocationRule() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t AttachmentRotationRule() const { return Read<uint8_t>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: EnumProperty)
    uint8_t AttachmentScaleRule() const { return Read<uint8_t>(uintptr_t(this) + 0x7a); } // 0x7a (Size: 0x1, Type: EnumProperty)
    bool bWeldSimulatedBodiesOnAttach() const { return Read<bool>(uintptr_t(this) + 0x7b); } // 0x7b (Size: 0x1, Type: BoolProperty)
    FName AttachmentSocketName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)
    bool bForceChangeBaseOnDetach() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t DetachmentLocationRule() const { return Read<uint8_t>(uintptr_t(this) + 0x85); } // 0x85 (Size: 0x1, Type: EnumProperty)
    uint8_t DetachmentRotationRule() const { return Read<uint8_t>(uintptr_t(this) + 0x86); } // 0x86 (Size: 0x1, Type: EnumProperty)
    uint8_t DetachmentScaleRule() const { return Read<uint8_t>(uintptr_t(this) + 0x87); } // 0x87 (Size: 0x1, Type: EnumProperty)
    bool bCallModifyOnDetach() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bHandleLaunchCharacter() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)
    bool bHasHandledLaunchCharacter() const { return Read<bool>(uintptr_t(this) + 0x8a); } // 0x8a (Size: 0x1, Type: BoolProperty)
    AFortPawn* FortPawnActor() const { return Read<AFortPawn*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_bHandleAthenaMovComponent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
    void SET_bSetPhysicsToQueryOnlyWhileAttached(const bool& Value) { Write<bool>(uintptr_t(this) + 0x75, Value); } // 0x75 (Size: 0x1, Type: BoolProperty)
    void SET_bTryToAttachToSkeletalMeshOnTargetActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x76, Value); } // 0x76 (Size: 0x1, Type: BoolProperty)
    void SET_bChangeBaseToSkeletalMeshOnTargetActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x77, Value); } // 0x77 (Size: 0x1, Type: BoolProperty)
    void SET_AttachmentLocationRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_AttachmentRotationRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: EnumProperty)
    void SET_AttachmentScaleRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x7a, Value); } // 0x7a (Size: 0x1, Type: EnumProperty)
    void SET_bWeldSimulatedBodiesOnAttach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7b, Value); } // 0x7b (Size: 0x1, Type: BoolProperty)
    void SET_AttachmentSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
    void SET_bForceChangeBaseOnDetach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_DetachmentLocationRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x85, Value); } // 0x85 (Size: 0x1, Type: EnumProperty)
    void SET_DetachmentRotationRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x86, Value); } // 0x86 (Size: 0x1, Type: EnumProperty)
    void SET_DetachmentScaleRule(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x87, Value); } // 0x87 (Size: 0x1, Type: EnumProperty)
    void SET_bCallModifyOnDetach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_bHandleLaunchCharacter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
    void SET_bHasHandledLaunchCharacter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8a, Value); } // 0x8a (Size: 0x1, Type: BoolProperty)
    void SET_FortPawnActor(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x100
class UFortAthenaPlayContextualAnimTaskInstanceData : public UObject
{
public:
    AActor* PrimaryActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    AActor* SecondaryActor() const { return Read<AActor*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName SecondaryRole() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    AActor* TertiaryActor() const { return Read<AActor*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName TertiaryRole() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    UContextualAnimSceneAsset* SceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    FName SectionName() const { return Read<FName>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer PrimaryActorExternalTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SecondaryActorExternalTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TertiaryActorExternalTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x20, Type: StructProperty)
    uint8_t ExecutionMethod() const { return Read<uint8_t>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: EnumProperty)
    bool bWaitForNotifyEventToEnd() const { return Read<bool>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    FName NotifyEventNameToEnd() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)
    int32_t LoopsToRun() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)
    bool bLoopForever() const { return Read<bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: BoolProperty)
    float DelayBetweenLoops() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    TArray<FContextualAnimWarpTarget> WarpTargets() const { return Read<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    bool bFindAnimSetBasedOnWarpTargets() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)

    void SET_PrimaryActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryRole(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_TertiaryActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_TertiaryRole(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET_SceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_SectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: NameProperty)
    void SET_PrimaryActorExternalTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
    void SET_SecondaryActorExternalTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: StructProperty)
    void SET_TertiaryActorExternalTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x20, Type: StructProperty)
    void SET_ExecutionMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: EnumProperty)
    void SET_bWaitForNotifyEventToEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    void SET_NotifyEventNameToEnd(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
    void SET_LoopsToRun(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
    void SET_bLoopForever(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: BoolProperty)
    void SET_DelayBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_RandomDeviationBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_WarpTargets(const TArray<FContextualAnimWarpTarget>& Value) { Write<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_bFindAnimSetBasedOnWarpTargets(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe0
class UFortAthenaPlayInteractionStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* InteractorActor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    AActor* InteractableActor() const { return Read<AActor*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* InteractorMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* InteractableMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    bool bWaitForNotifyEventToEnd() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)
    FName NotifyEventNameToEnd() const { return Read<FName>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: NameProperty)
    bool bAddMotionWarpingTargets() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bDisableCollisionBetweenActors() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)
    bool bSetMovementModeToFlying() const { return Read<bool>(uintptr_t(this) + 0x8a); } // 0x8a (Size: 0x1, Type: BoolProperty)
    int32_t LoopsToRun() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    bool bLoopForever() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    float DelayBetweenLoops() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bStopInteractorAnimMontageOnExit() const { return Read<bool>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x1, Type: BoolProperty)
    bool bStopInteractableAnimMontageOnExit() const { return Read<bool>(uintptr_t(this) + 0x9d); } // 0x9d (Size: 0x1, Type: BoolProperty)

    void SET_InteractorActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractableActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractorMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractableMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_bWaitForNotifyEventToEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
    void SET_NotifyEventNameToEnd(const FName& Value) { Write<FName>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: NameProperty)
    void SET_bAddMotionWarpingTargets(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_bDisableCollisionBetweenActors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
    void SET_bSetMovementModeToFlying(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8a, Value); } // 0x8a (Size: 0x1, Type: BoolProperty)
    void SET_LoopsToRun(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_bLoopForever(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_DelayBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_RandomDeviationBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_bStopInteractorAnimMontageOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x1, Type: BoolProperty)
    void SET_bStopInteractableAnimMontageOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d, Value); } // 0x9d (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc8
class UFortAthenaPlayMontageStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t ExecMode() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    FName SectionName() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    uint8_t LoopMode() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    TArray<FSTFortAthenaPlayMontageWarpTarget> WarpTargets() const { return Read<TArray<FSTFortAthenaPlayMontageWarpTarget>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    bool bWaitForNotifyEventToEnd() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    FName NotifyEventNameToEnd() const { return Read<FName>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: NameProperty)
    bool bSetMovementModeToFlying() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    int32_t LoopsToRun() const { return Read<int32_t>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: IntProperty)
    bool bLoopForever() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    float DelayBetweenLoops() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    bool bStopAnimMontageOnExit() const { return Read<bool>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x1, Type: BoolProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_ExecMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_SectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET_LoopMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_WarpTargets(const TArray<FSTFortAthenaPlayMontageWarpTarget>& Value) { Write<TArray<FSTFortAthenaPlayMontageWarpTarget>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_bWaitForNotifyEventToEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_NotifyEventNameToEnd(const FName& Value) { Write<FName>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: NameProperty)
    void SET_bSetMovementModeToFlying(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_LoopsToRun(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: IntProperty)
    void SET_bLoopForever(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    void SET_DelayBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_RandomDeviationBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_bStopAnimMontageOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
class UFortWorldConditionPlaylist_State : public UObject
{
public:
};

// Size: 0x48
class UFortWorldConditionWorldState_State : public UObject
{
public:
};

// Size: 0x14
struct FBotEvaluatorCommandCooldown
{
public:
    FFortAIActiveCommandSOUsageData Command() const { return Read<FFortAIActiveCommandSOUsageData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_Command(const FFortAIActiveCommandSOUsageData& Value) { Write<FFortAIActiveCommandSOUsageData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FBotEvaluatorSmartObjectConvertedData
{
public:
    USmartObjectComponent* SmartObjectComponent() const { return Read<USmartObjectComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_SmartObjectComponent(const USmartObjectComponent*& Value) { Write<USmartObjectComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x14
struct FTokenEQSParameter
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParamType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FName BlackboardKeyName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParamType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_BlackboardKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
};

// Size: 0x80
struct FPositioningEQS
{
public:
    FGameplayTagQuery ItemTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    UEnvQuery* QueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    TArray<FTokenEQSParameter> QueryConfig() const { return Read<TArray<FTokenEQSParameter>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    bool bAllowStayingOnSamePosition() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bRequestNewPosititonOnProviderRecomputed() const { return Read<bool>(uintptr_t(this) + 0x61); } // 0x61 (Size: 0x1, Type: BoolProperty)
    FValueOrBBKey_Bool AllowStayingOnSamePosition() const { return Read<FValueOrBBKey_Bool>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float TimerForNewPositionOnProviderRecomputed() const { return Read<FValueOrBBKey_Float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xc, Type: StructProperty)

    void SET_ItemTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_QueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_QueryConfig(const TArray<FTokenEQSParameter>& Value) { Write<TArray<FTokenEQSParameter>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllowStayingOnSamePosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
    void SET_bRequestNewPosititonOnProviderRecomputed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61, Value); } // 0x61 (Size: 0x1, Type: BoolProperty)
    void SET_AllowStayingOnSamePosition(const FValueOrBBKey_Bool& Value) { Write<FValueOrBBKey_Bool>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0xc, Type: StructProperty)
    void SET_TimerForNewPositionOnProviderRecomputed(const FValueOrBBKey_Float& Value) { Write<FValueOrBBKey_Float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xc, Type: StructProperty)
};

// Size: 0x40
struct FFortAthenaAIEvaluator_LookAt_AbstractConfiguration
{
public:
    int32_t DiceRollingPercentage() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float DiceRollingFailCooldown() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float UtilityWeightMultiplier() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float UtilityWeightAddition() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    FVector2D ConfigurationCooldownRange() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D ActorCooldownRange() const { return Read<FVector2D>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FVector2D MaxDurationRange() const { return Read<FVector2D>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_DiceRollingPercentage(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_DiceRollingFailCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_UtilityWeightMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_UtilityWeightAddition(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_ConfigurationCooldownRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ActorCooldownRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_MaxDurationRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x100
struct FFortAthenaAIEvaluator_LookAt_PawnConfiguration : public FFortAthenaAIEvaluator_LookAt_AbstractConfiguration
{
public:
    FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration() const { return Read<FFortNearbyActorsPerceptionConfiguration>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xc0, Type: StructProperty)

    void SET_PerceptionConfiguration(const FFortNearbyActorsPerceptionConfiguration& Value) { Write<FFortNearbyActorsPerceptionConfiguration>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xc0, Type: StructProperty)
};

// Size: 0x48
struct FFortAthenaAIEvaluator_LookAt_SOConfiguration : public FFortAthenaAIEvaluator_LookAt_AbstractConfiguration
{
public:
    float Max2DDistance() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float MaxZDistance() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)

    void SET_Max2DDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_MaxZDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FEquippedItemTagAssociationData
{
public:
    FGameplayTagQuery ItemTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery TokenSystemTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x48, Type: StructProperty)

    void SET_ItemTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_TokenSystemTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x48, Type: StructProperty)
};

// Size: 0xa0
struct FortAthenaFindSlotEntranceLocationStateTreeTask_InstanceData : public FStateTreeTask_FindSlotEntranceLocation_InstanceData
{
public:
};

// Size: 0x48
struct FFortAthenaFindSlotEntranceLocationStateTreeTask : public FStateTreeTask_FindSlotEntranceLocation
{
public:
    bool bPreferLocationNearActorMovementInput() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)

    void SET_bPreferLocationNearActorMovementInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData
{
public:
    FStateTreeStructRef SoftDisableStateReference() const { return Read<FStateTreeStructRef>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<AActor*> ActorsToTeleportOnFailure() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_SoftDisableStateReference(const FStateTreeStructRef& Value) { Write<FStateTreeStructRef>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_ActorsToTeleportOnFailure(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFortAthenaHandleSoftDisableGuardStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x10
struct FFortAthenaSoftDisableStateTreeParameter
{
public:
    TArray<AActor*> ActorsToTeleportOnExit() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ActorsToTeleportOnExit(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FFortAthenaHandleSoftDisableStateTreeTaskInstanceData
{
public:
    AActor* SmartObjectActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> ActorsToCleanup() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bHasReceivedSoftDisableEvent() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FGameplayTag ReceivedSoftDisableEvent() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: StructProperty)
    FFortAthenaSoftDisableStateTreeParameter OutState() const { return Read<FFortAthenaSoftDisableStateTreeParameter>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_SmartObjectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorsToCleanup(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasReceivedSoftDisableEvent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_ReceivedSoftDisableEvent(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: StructProperty)
    void SET_OutState(const FFortAthenaSoftDisableStateTreeParameter& Value) { Write<FFortAthenaSoftDisableStateTreeParameter>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x58
struct FFortAthenaHandleSoftDisableStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    FGameplayTag StateTreeEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FVector TeleportOnNavmeshQueryBoxExtents() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    int32_t MaxTeleportToTryPerActor() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)
    bool bEnableNavmeshTeleportForPlayers() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    float MultiplierOnCapsuleHalfHeightForTeleportLocation() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float MultiplierOnCapsuleRadiusForFallbackTeleportSweepCastSize() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float MultiplierOnCapsuleHeightForFallbackTeleportSweepCasts() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_StateTreeEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_TeleportOnNavmeshQueryBoxExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_MaxTeleportToTryPerActor(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
    void SET_bEnableNavmeshTeleportForPlayers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_MultiplierOnCapsuleHalfHeightForTeleportLocation(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_MultiplierOnCapsuleRadiusForFallbackTeleportSweepCastSize(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_MultiplierOnCapsuleHeightForFallbackTeleportSweepCasts(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
struct FFortAthenaPickAnimByWorldConditionsConfig
{
public:
    UAnimMontage* Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* SceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FWorldConditionQueryDefinition RequiredConditions() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FWorldConditionQueryState QueryState() const { return Read<FWorldConditionQueryState>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x30, Type: StructProperty)

    void SET_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_RequiredConditions(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_QueryState(const FWorldConditionQueryState& Value) { Write<FWorldConditionQueryState>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x30, Type: StructProperty)
};

// Size: 0x38
struct FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData
{
public:
    TArray<FFortAthenaPickAnimByWorldConditionsConfig> PossibleAnims() const { return Read<TArray<FFortAthenaPickAnimByWorldConditionsConfig>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    AActor* ActorAForWorldConditions() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorBForWorldConditions() const { return Read<AActor*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorCForWorldConditions() const { return Read<AActor*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* PickedMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* PickedSceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_PossibleAnims(const TArray<FFortAthenaPickAnimByWorldConditionsConfig>& Value) { Write<TArray<FFortAthenaPickAnimByWorldConditionsConfig>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ActorAForWorldConditions(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorBForWorldConditions(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorCForWorldConditions(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_PickedMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_PickedSceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortAthenaPickAnimByWorldConditionsStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x10
struct FFortAthenaPickRandomMontageConfig
{
public:
    UAnimMontage* Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t RandomWeight() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_RandomWeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FFortAthenaPickRandomMontageStateTreeTaskInstanceData
{
public:
    TArray<FFortAthenaPickRandomMontageConfig> PossibleMontages() const { return Read<TArray<FFortAthenaPickRandomMontageConfig>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    UAnimMontage* PickedMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_PossibleMontages(const TArray<FFortAthenaPickRandomMontageConfig>& Value) { Write<TArray<FFortAthenaPickRandomMontageConfig>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PickedMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortAthenaPickRandomMontageStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x70
struct FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FFortUISmartObjectUIId UIId() const { return Read<FFortUISmartObjectUIId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag PayloadType() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)
    FGameplayTagQuery PayloadTypeQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)
    TArray<FFortUISmartObjectUIPayload> ReceivedPayloads() const { return Read<TArray<FFortUISmartObjectUIPayload>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_UIId(const FFortUISmartObjectUIId& Value) { Write<FFortUISmartObjectUIId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_PayloadType(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
    void SET_PayloadTypeQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
    void SET_ReceivedPayloads(const TArray<FFortUISmartObjectUIPayload>& Value) { Write<TArray<FFortUISmartObjectUIPayload>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFortAthenaReceivePayloadSmartObjectUIStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    FGameplayTag ReceivedUIPayloadEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    bool bSilentFailWithInvalidPayloadType() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bConnectToClientToServerPayload() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)

    void SET_ReceivedUIPayloadEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_bSilentFailWithInvalidPayloadType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_bConnectToClientToServerPayload(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData
{
public:
    AActor* SmartObjectActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag UITag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    FFortUISmartObjectUIPayloadOptions UIOptions() const { return Read<FFortUISmartObjectUIPayloadOptions>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FFortUISmartObjectUIId UIId() const { return Read<FFortUISmartObjectUIId>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    bool bIsClosed() const { return Read<bool>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: BoolProperty)
    bool bCloseResult() const { return Read<bool>(uintptr_t(this) + 0x35); } // 0x35 (Size: 0x1, Type: BoolProperty)
    bool bTaskRequestedClose() const { return Read<bool>(uintptr_t(this) + 0x36); } // 0x36 (Size: 0x1, Type: BoolProperty)

    void SET_SmartObjectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_UITag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_UIOptions(const FFortUISmartObjectUIPayloadOptions& Value) { Write<FFortUISmartObjectUIPayloadOptions>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_UIId(const FFortUISmartObjectUIId& Value) { Write<FFortUISmartObjectUIId>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_bIsClosed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: BoolProperty)
    void SET_bCloseResult(const bool& Value) { Write<bool>(uintptr_t(this) + 0x35, Value); } // 0x35 (Size: 0x1, Type: BoolProperty)
    void SET_bTaskRequestedClose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x36, Value); } // 0x36 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FFortAthenaRunSmartObjectUIStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    FGameplayTag UIClosedEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_UIClosedEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x20
struct FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FFortUISmartObjectUIId UIId() const { return Read<FFortUISmartObjectUIId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    TArray<FFortUISmartObjectUIPayload> Payloads() const { return Read<TArray<FFortUISmartObjectUIPayload>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_UIId(const FFortUISmartObjectUIId& Value) { Write<FFortUISmartObjectUIId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_Payloads(const TArray<FFortUISmartObjectUIPayload>& Value) { Write<TArray<FFortUISmartObjectUIPayload>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFortAthenaSendPayloadSmartObjectUIStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    uint8_t Trigger() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_Trigger(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FFortAthenaToggleAllowInteractStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FFortAthenaToggleAllowInteractStateTreeTaskTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x10
struct FFortAthenaTrackEventConsumeStateTreeTaskInstanceData
{
public:
    FStateTreeStructRef ReferencedEvent() const { return Read<FStateTreeStructRef>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_ReferencedEvent(const FStateTreeStructRef& Value) { Write<FStateTreeStructRef>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FFortAthenaTrackEventConsumeStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x8
struct FFortAthenaTrackEventStateTreeTaskStateTreeParameter
{
public:
    bool bHasReceivedTrackedEvent() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FGameplayTag ReceivedEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_bHasReceivedTrackedEvent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ReceivedEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FFortAthenaTrackEventStateTreeTaskInstanceData
{
public:
    FFortAthenaTrackEventStateTreeTaskStateTreeParameter OutParameter() const { return Read<FFortAthenaTrackEventStateTreeTaskStateTreeParameter>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)

    void SET_OutParameter(const FFortAthenaTrackEventStateTreeTaskStateTreeParameter& Value) { Write<FFortAthenaTrackEventStateTreeTaskStateTreeParameter>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x70
struct FFortAthenaTrackEventStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    FGameplayTagQuery EventTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x48, Type: StructProperty)
    FGameplayTag StateTreeEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: StructProperty)

    void SET_EventTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x48, Type: StructProperty)
    void SET_StateTreeEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: StructProperty)
};

// Size: 0x50
struct FFortAthenaWorldConditionInstanceData
{
public:
    AActor* ActorA() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorB() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorC() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    bool bOutResult() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FWorldConditionQueryState QueryState() const { return Read<FWorldConditionQueryState>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)

    void SET_ActorA(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorB(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorC(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_bOutResult(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_QueryState(const FWorldConditionQueryState& Value) { Write<FWorldConditionQueryState>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
};

// Size: 0x40
struct FFortAthenaWorldConditionInstanceDataStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    FWorldConditionQueryDefinition Conditions() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FGameplayTag StateTreeEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: StructProperty)

    void SET_Conditions(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_StateTreeEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FFortBTService_InjectionTagKey
{
public:
    FGameplayTag InjectionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FName InjectionKeyName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName ActionInterfaceObjectKeyName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_InjectionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_InjectionKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_ActionInterfaceObjectKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x10
struct FFortStateTreeBotCrouchTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldCrouch() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldCrouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortStateTreeBotCrouchTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x18
struct FFortStateTreeBotEquipItemTaskInstanceData
{
public:
    AFortAthenaAIBotController* Controller() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFortWorldItem* ItemToEquip() const { return Read<UFortWorldItem*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bValidateAbility() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Controller(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemToEquip(const UFortWorldItem*& Value) { Write<UFortWorldItem*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bValidateAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortStateTreeBotEquipItemTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x28
struct FFortStateTreeGetItemFromInventoryTaskInstanceData
{
public:
    AController* Controller() const { return Read<AController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FItemVariantHandle ItemVariant() const { return Read<FItemVariantHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    UFortWorldItem* Item() const { return Read<UFortWorldItem*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_Controller(const AController*& Value) { Write<AController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemVariant(const FItemVariantHandle& Value) { Write<FItemVariantHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Item(const UFortWorldItem*& Value) { Write<UFortWorldItem*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FFortStateTreeGetItemFromInventoryTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeBotSetSupportHolsteredWeaponInstanceData
{
public:
    AFortAthenaAIBotController* Controller() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bSupportHolstering() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Controller(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bSupportHolstering(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortStateTreeBotSetSupportHolsteredWeapon : public FStateTreeAITaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeBotSprintTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSprint() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldSprint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FFortStateTreeBotSprintTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x30
struct FFortStateTreeBotFireWeaponTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Behavior() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    TArray<FDigestedWeaponFiringTime> FiringTimes() const { return Read<TArray<FDigestedWeaponFiringTime>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Behavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_FiringTimes(const TArray<FDigestedWeaponFiringTime>& Value) { Write<TArray<FDigestedWeaponFiringTime>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFortStateTreeBotFireWeaponTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeBotGetCurrentWeaponTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* CurrentWeapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentWeapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeBotGetCurrentWeaponTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x68
struct FFortStateTreeBotGetFiringPatternTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* CurrentWeapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<FDigestedWeaponFiringTime> FiringTimes() const { return Read<TArray<FDigestedWeaponFiringTime>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet() const { return Read<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* LastUsedWeapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentWeapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_FiringTimes(const TArray<FDigestedWeaponFiringTime>& Value) { Write<TArray<FDigestedWeaponFiringTime>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CacheRangeAttackDigestedSkillSet(const UFortAthenaAIBotRangeAttackDigestedSkillSet*& Value) { Write<UFortAthenaAIBotRangeAttackDigestedSkillSet*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_LastUsedWeapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeBotGetFiringPatternTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x20
struct FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFortItem* Item() const { return Read<UFortItem*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    float Effectiveness() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Item(const UFortItem*& Value) { Write<UFortItem*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_Effectiveness(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortStateTreeBotGetWeaponItemEffectivenessTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x18
struct FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float Effectiveness() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Effectiveness(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortStateTreeBotGetMostEffectiveWeaponScoreTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x18
struct FFortStateTreeBotGetWeaponItemTaskInstanceData
{
public:
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFortItem* Item() const { return Read<UFortItem*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Item(const UFortItem*& Value) { Write<UFortItem*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeBotGetWeaponItemTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeGetControllerTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AController* Controller() const { return Read<AController*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Controller(const AController*& Value) { Write<AController*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeGetControllerTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeGetAIControllerTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AAIController* AIController() const { return Read<AAIController*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AIController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeGetAIControllerTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeGetBotControllerTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortAthenaAIBotController* BotController() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_BotController(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeGetBotControllerTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x40
struct FFortStateTreeExecuteAbilityTaskInstanceData
{
public:
    AAIController* Controller() const { return Read<AAIController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    UFortAITask_ExecuteAbility* ExecuteAbilityTask() const { return Read<UFortAITask_ExecuteAbility*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> TaskOwner() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: InterfaceProperty)

    void SET_Controller(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_ExecuteAbilityTask(const UFortAITask_ExecuteAbility*& Value) { Write<UFortAITask_ExecuteAbility*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_TaskOwner(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x20
struct FFortStateTreeExecuteAbilityTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x28
struct FFortGetActorLocationStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector OutVector() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FStateTreePropertyRef OutRefVector() const { return Read<FStateTreePropertyRef>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x2, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_OutVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_OutRefVector(const FStateTreePropertyRef& Value) { Write<FStateTreePropertyRef>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x2, Type: StructProperty)
};

// Size: 0x28
struct FFortGetActorLocationStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    bool bRunOnce() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bRunOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FFortStateTreeGetDistanceParameterInstanceData
{
public:
    AFortPawn* Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DistancePropertyTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    float OutDistance() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)

    void SET_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_DistancePropertyTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_OutDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortStateTreeGetDistanceParameterStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x8
struct FFortStateTreeGetTargetActorTaskInstanceData
{
public:
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FFortStateTreeGetTargetActorTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x18
struct FFortStateTreeGetHealthTaskInstanceData
{
public:
    AFortPawn* Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float CurrentHealth() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxHealth() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float HealthPercentage() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxHealth(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_HealthPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortStateTreeGetHealthTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x18
struct FFortStateTreeGetShieldTaskInstanceData
{
public:
    AFortPawn* Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float CurrentShield() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxShield() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float ShieldPercentage() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentShield(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxShield(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_ShieldPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortStateTreeGetShieldTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x28
struct FFortStateTreeIsInsideLeashConditionInstanceData
{
public:
    AAIController* AIController() const { return Read<AAIController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    bool bUseInnerRadius() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_AIController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_bUseInnerRadius(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FFortStateTreeIsInsideLeashCondition : public FStateTreeAIConditionBase
{
public:
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FFortStateTreeGetMoveStatusTaskInstanceData
{
public:
    AAIController* AIController() const { return Read<AAIController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EPathFollowingStatus> MoveStatus() const { return Read<TEnumAsByte<EPathFollowingStatus>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)

    void SET_AIController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MoveStatus(const TEnumAsByte<EPathFollowingStatus>& Value) { Write<TEnumAsByte<EPathFollowingStatus>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x20
struct FFortStateTreeGetMoveStatusTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x20
struct FFortStateTreeGetMoveDestinationTaskInstanceData
{
public:
    AAIController* AIController() const { return Read<AAIController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector MoveDestination() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_AIController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MoveDestination(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FFortStateTreeGetMoveDestinationTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x18
struct FFortStateTreeSetFrustrationDiscouragementInstanceData
{
public:
    AAIController* AIController() const { return Read<AAIController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float DiscouragementDuration() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_AIController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_DiscouragementDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortStateTreeSetFrustrationDiscouragementTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeSetInTacticalActionTaskInstanceData
{
public:
    AFortAthenaAIBotController* Controller() const { return Read<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSetInTacticalAction() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Controller(const AFortAthenaAIBotController*& Value) { Write<AFortAthenaAIBotController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldSetInTacticalAction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortStateTreeSetInTacticalActionTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x58
struct FFortStateTreeHasFreeTokenConditionInstanceData
{
public:
    APawn* ReserverPawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)

    void SET_ReserverPawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_TokenTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
};

// Size: 0x20
struct FFortStateTreeHasFreeTokenCondition : public FStateTreeAIConditionBase
{
public:
};

// Size: 0x60
struct FFortStateTreeReserveTokenTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)
    FTokenHandle GrantedToken() const { return Read<FTokenHandle>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_TokenTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
    void SET_GrantedToken(const FTokenHandle& Value) { Write<FTokenHandle>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
};

// Size: 0x20
struct FFortStateTreeReserveTokenTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x88
struct FFortStateTreeReserveTokenPositionTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FGameplayTagQuery TokenTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x48, Type: StructProperty)
    float HoldReservationAtExitDuration() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float AcceptableDistanceForPositionReservation() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bAllowAddingNewPositionToProvider() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_TokenTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x48, Type: StructProperty)
    void SET_HoldReservationAtExitDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_AcceptableDistanceForPositionReservation(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_bAllowAddingNewPositionToProvider(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortStateTreeReserveTokenPositionTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x50
struct FFortStateTreeWaitForTokenPositionTaskInstanceData
{
public:
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)

    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TokenTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x20
struct FFortStateTreeWaitForTokenPositionTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x28
struct FFortStateTreeGetReservedTokenPositionTaskInstanceData
{
public:
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector ReservedLocation() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ReservedLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FFortStateTreeGetReservedTokenPositionTask : public FStateTreeAITaskBase
{
public:
};

// Size: 0x50
struct FFortStateTreeRequestProviderPositionGenerationInstanceData
{
public:
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenPositionTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)

    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TokenPositionTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x20
struct FFortStateTreeRequestProviderPositionGeneration : public FStateTreeAITaskBase
{
public:
};

// Size: 0x8
struct FFortStateTreeReloadWeaponTaskInstanceData
{
public:
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeReloadWeaponTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData
{
public:
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t RemainingAmmo() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_RemainingAmmo(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FFortStateTreeGetWeaponRemainingAmmoTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x10
struct FFortStateTreeSetWeaponTargetingTaskInstanceData
{
public:
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldActivateTargeting() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldActivateTargeting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortStateTreeSetWeaponTargetingTask : public FStateTreeAIActionTaskBase
{
public:
};

// Size: 0x10
struct FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData
{
public:
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t AmmoInMagazine() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AmmoInMagazine(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FFortStateTreeGetWeaponMagazineAmmoTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x28
struct FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData
{
public:
    AFortPawn* Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UGameplayAbility* ability() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ability(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeWaitUntilAbilityFinishedTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x18
struct FFortStateTreeWaitUntilMantisBranchAvailableTaskInstanceData
{
public:
    AFortWeapon* Weapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Weapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortStateTreeWaitUntilMantisBranchAvailableTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x8
struct FFortWorldConditionGameplayTagActorQueryState
{
public:
};

// Size: 0x40
struct FFortWorldConditionGameplayTagActor : public FWorldConditionCommonBase
{
public:
    FWorldConditionContextDataRef ActorContextRef() const { return Read<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer TagContainerToCheck() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x20, Type: StructProperty)
    uint8_t TestType() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)

    void SET_ActorContextRef(const FWorldConditionContextDataRef& Value) { Write<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_TagContainerToCheck(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x20, Type: StructProperty)
    void SET_TestType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FFortWorldConditionNativeAction : public FWorldConditionCommonBase
{
public:
    FWorldConditionContextDataRef BotControllerRef() const { return Read<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FGameplayTag ActionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)

    void SET_BotControllerRef(const FWorldConditionContextDataRef& Value) { Write<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ActionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
};

// Size: 0x20
struct FFortWorldConditionPlayerHasConvertedNPC : public FWorldConditionCommonActorBase
{
public:
    FWorldConditionContextDataRef ActorRef() const { return Read<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t ConditionToCheck() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)

    void SET_ActorRef(const FWorldConditionContextDataRef& Value) { Write<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ConditionToCheck(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
struct FFortWorldConditionPlayerUsesCID : public FWorldConditionCommonActorBase
{
public:
    FWorldConditionContextDataRef ActorRef() const { return Read<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FPrimaryAssetId> AllowedCharacters() const { return Read<TArray<FPrimaryAssetId>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ActorRef(const FWorldConditionContextDataRef& Value) { Write<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_AllowedCharacters(const TArray<FPrimaryAssetId>& Value) { Write<TArray<FPrimaryAssetId>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFortWorldConditionRealDateTime : public FWorldConditionCommonBase
{
public:
    int32_t ValidDaysOfWeek() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t ValidMinHour() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t ValidMaxHour() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t ValidMinDayOfMonth() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t ValidMaxDayOfMonth() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_ValidDaysOfWeek(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_ValidMinHour(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_ValidMaxHour(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_ValidMinDayOfMonth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_ValidMaxDayOfMonth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FFortWorldConditionTimeOfDay : public FWorldConditionCommonBase
{
public:
    FWorldConditionContextDataRef ActorContextRef() const { return Read<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t ValidTimesOfDay() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_ActorContextRef(const FWorldConditionContextDataRef& Value) { Write<FWorldConditionContextDataRef>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ValidTimesOfDay(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FFortWorldConditionWorldStatState
{
public:
};

// Size: 0x28
struct FFortWorldConditionWorldStat : public FWorldConditionCommonBase
{
public:
    FName WorldStatRowName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FInt32Range ValueRange() const { return Read<FInt32Range>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)

    void SET_WorldStatRowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_ValueRange(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FPFWNPCReactions_TriggeredReactions_PersistentInfoData
{
public:
    TArray<FString> TriggeredReactionRowNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_TriggeredReactionRowNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FPFWNPCReactions_PersistentInfo
{
public:
    FPFWNPCReactions_TriggeredReactions_PersistentInfoData TriggeredReactions_PersistentInfoData() const { return Read<FPFWNPCReactions_TriggeredReactions_PersistentInfoData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_TriggeredReactions_PersistentInfoData(const FPFWNPCReactions_TriggeredReactions_PersistentInfoData& Value) { Write<FPFWNPCReactions_TriggeredReactions_PersistentInfoData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
struct FGameFeatureFortAIEvaluatorEntry
{
public:
    TSoftObjectPtr<UBehaviorTree> TreeAsset() const { return Read<TSoftObjectPtr<UBehaviorTree>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag InjectionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TreeAsset(const TSoftObjectPtr<UBehaviorTree>& Value) { Write<TSoftObjectPtr<UBehaviorTree>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_InjectionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FFortPointOnCurveRange
{
public:
    float MinPercentage() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxPercentage() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_MinPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FFortPointsOnCurve
{
public:
    TSoftObjectPtr<UCurveFloat> Curve() const { return Read<TSoftObjectPtr<UCurveFloat>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FFortPointOnCurveRange> RangesForPointsOnCurve() const { return Read<TArray<FFortPointOnCurveRange>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Curve(const TSoftObjectPtr<UCurveFloat>& Value) { Write<TSoftObjectPtr<UCurveFloat>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_RangesForPointsOnCurve(const TArray<FFortPointOnCurveRange>& Value) { Write<TArray<FFortPointOnCurveRange>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FFortQueryGenerator_PerceivedActors_Settings
{
public:
    bool bIgnoreDBNOPawns() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreSleepingAIs() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue MaxTimeSincePerceived() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x38, Type: StructProperty)

    void SET_bIgnoreDBNOPawns(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreSleepingAIs(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_MaxTimeSincePerceived(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x38, Type: StructProperty)
};

// Size: 0x60
struct FFortGameplayTagQueryPerDifficulty
{
public:
    FDataTableRowHandle DifficultyInfo() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FGameplayTagQuery TagQueryToMatch() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)
    float Difficulty() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)

    void SET_DifficultyInfo(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_TagQueryToMatch(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
    void SET_Difficulty(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x98
struct FGoalDistanceData
{
public:
    bool bIgnoreScreeningDistance() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FAIDataProviderFloatValue ScreeningTestMaxDistance() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x38, Type: StructProperty)
    TSoftObjectPtr<UCurveFloat> TestScoreCurve() const { return Read<TSoftObjectPtr<UCurveFloat>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    FAIDataProviderFloatValue CurveDistanceScale() const { return Read<FAIDataProviderFloatValue>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x38, Type: StructProperty)

    void SET_bIgnoreScreeningDistance(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ScreeningTestMaxDistance(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x38, Type: StructProperty)
    void SET_TestScoreCurve(const TSoftObjectPtr<UCurveFloat>& Value) { Write<TSoftObjectPtr<UCurveFloat>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CurveDistanceScale(const FAIDataProviderFloatValue& Value) { Write<FAIDataProviderFloatValue>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x38, Type: StructProperty)
};

// Size: 0x28
struct FFortStateTreeGameplayAbilityCondition : public FStateTreeConditionCommonBase
{
public:
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FFortGameplayAbilityIsOnCooldownInstanceData
{
public:
    AActor* Pawn() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_Pawn(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FFortGameplayAbilityIsOnCooldownCondition : public FFortStateTreeGameplayAbilityCondition
{
public:
};

// Size: 0x28
struct FFortGameplayAbilityCanActivateAbilityInstanceData
{
public:
    AActor* Pawn() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_Pawn(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FFortGameplayAbilityCanActivateAbilityCondition : public FFortStateTreeGameplayAbilityCondition
{
public:
};

// Size: 0x30
struct FFortGameplayAbilityCanHitTargetInstanceData
{
public:
    AFortPawn* Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)

    void SET_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
};

// Size: 0x30
struct FFortGameplayAbilityCanHitTargetCondition : public FFortStateTreeGameplayAbilityCondition
{
public:
    bool bUseIdealYawRotationToTargetValue() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_bUseIdealYawRotationToTargetValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FFortGameplayAbilityCompareDistanceInstanceData
{
public:
    AFortPawn* Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    TArray<FDistanceToTargetComparison> DistanceComparisons() const { return Read<TArray<FDistanceToTargetComparison>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_DistanceComparisons(const TArray<FDistanceToTargetComparison>& Value) { Write<TArray<FDistanceToTargetComparison>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFortGameplayAbilityCompareDistanceCondition : public FFortStateTreeGameplayAbilityCondition
{
public:
};

// Size: 0x78
struct FMimicConverterAbilityData
{
public:
    FGameplayTagQuery RequiredConverterAbilityTags() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer AbilitiesToApply() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    TArray<UClass*> GEsToApply() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_RequiredConverterAbilityTags(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_AbilitiesToApply(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_GEsToApply(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FEscalateTargetData
{
public:
    TWeakObjectPtr<AFortPlayerPawn*> Target() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Target(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x20
struct FFlankingLocationInfo
{
public:
};

// Size: 0x8
struct FFailedToReachPOI
{
public:
    int32_t BotPOIID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t FailCount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_BotPOIID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_FailCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
struct FFortEvaluatorBlueprintBaseCooldown
{
public:
    TEnumAsByte<ECooldownType> CooldownType() const { return Read<TEnumAsByte<ECooldownType>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    FScalableFloat Cooldown() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    FScalableFloat CooldownVariation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)

    void SET_CooldownType(const TEnumAsByte<ECooldownType>& Value) { Write<TEnumAsByte<ECooldownType>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Cooldown(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_CooldownVariation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
};

// Size: 0x40
struct FGameplayAbilityEvaluatorModule
{
public:
    FGameplayTagContainer GameplayAbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    bool bCheckAbilityCanActivate() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bCheckAbilityCanHitTarget() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    FName CanHitTargetActorKeyName() const { return Read<FName>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: NameProperty)
    bool bUseIdealRotationToCanHitTarget() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FName CanHitTargetProjectedSourceLocationKeyName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    UAbilitySystemComponent* CachedAbilitySystemComponent() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayAbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_bCheckAbilityCanActivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckAbilityCanHitTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_CanHitTargetActorKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: NameProperty)
    void SET_bUseIdealRotationToCanHitTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_CanHitTargetProjectedSourceLocationKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_CachedAbilitySystemComponent(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FGameplayTagActorHasMatchingGameplayTagInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TagToCheck() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TagToCheck(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x28
struct FGameplayTagActorHasMatchingGameplayTagCondition : public FStateTreeConditionCommonBase
{
public:
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FGameplayTagActorHasMatchingGameplayTagContainerInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer TagContainerToCheck() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TagContainerToCheck(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FGameplayTagActorHasMatchingGameplayContainerTagCondition : public FStateTreeConditionCommonBase
{
public:
    uint8_t TestType() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)

    void SET_TestType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FFortAthenaAddGameplayTagsStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x30
struct FFortAthenaAddGameplayTagsStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    bool bReplicateChange() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bReplicateChange(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FFortAthenaArithmeticStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    uint8_t OperationTrigger() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Operation() const { return Read<uint8_t>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: EnumProperty)

    void SET_OperationTrigger(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_Operation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FFortAthenaIntArithmeticStateTreeTaskInstanceData
{
public:
    int32_t FirstOperand() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SecondOperand() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FStateTreeStructRef ReferencedResult() const { return Read<FStateTreeStructRef>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_FirstOperand(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SecondOperand(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_ReferencedResult(const FStateTreeStructRef& Value) { Write<FStateTreeStructRef>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FFortAthenaIntArithmeticStateTreeTask : public FFortAthenaArithmeticStateTreeTask
{
public:
};

// Size: 0x40
struct FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData
{
public:
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* SmartObjectActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    UAnimMontage* PickedMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* PickedSceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SmartObjectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_PickedMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_PickedSceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortAthenaFindSmartObjectAnimForActorStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x90
struct FFortAthenaFocusAtStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* FocusActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector FocusActorOffset() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector FocusWorldPoint() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    bool bSetBackOnExit() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bShouldSetFocus() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_FocusActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_FocusActorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_FocusWorldPoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_bSetBackOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldSetFocus(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortAthenaFocusAtStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x4
struct FFortAthenaIntStateTreeParameter
{
public:
    int32_t int() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_int(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FFortAthenaMakeIntVariableStateTreeTaskInstanceData
{
public:
    int32_t DefaultIntValue() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FFortAthenaIntStateTreeParameter OutInt() const { return Read<FFortAthenaIntStateTreeParameter>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_DefaultIntValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_OutInt(const FFortAthenaIntStateTreeParameter& Value) { Write<FFortAthenaIntStateTreeParameter>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x28
struct FFortAthenaMakeIntVariableStateTreeTask : public FStateTreeTaskCommonBase
{
public:
    bool bResetOnReselect() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bResetOnReselect(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FFortAthenaPlayContextualAnimStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x24
struct FFortAthenaPlayInteractionStateTreeTaskActorInfo
{
public:
};

// Size: 0x50
struct FSTFortAthenaPlayMontageWarpTarget
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName BoneOrSocketName() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_BoneOrSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
};

// Size: 0x8
struct FFortAthenaStateTreeCrouchTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FFortAthenaStateTreeCrouchTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x20
struct FFortAthenaStateTreeInteractTaskInstanceData
{
public:
    TEnumAsByte<TInteractionType> InteractType() const { return Read<TEnumAsByte<TInteractionType>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* InteractTargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    float InteractDuration() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float Timer() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_InteractType(const TEnumAsByte<TInteractionType>& Value) { Write<TEnumAsByte<TInteractionType>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractTargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_Timer(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortAthenaStateTreeInteractTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x18
struct FFortAthenaStateTreeLookAroundTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float LookAtDurationMin() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float LookAtDurationMax() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float LookAtDuration() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Timer() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_LookAtDurationMin(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_LookAtDurationMax(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_LookAtDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Timer(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFortAthenaStateTreeLookAroundTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x18
struct FFortAthenaStateTreeSendGameplayEventTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_EventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
};

// Size: 0x20
struct FFortAthenaStateTreeSendGameplayEventTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x40
struct FFortAthenaTeleportToActorStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector TeleportRelativeLocation() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FRotator TeleportRelativeRotation() const { return Read<FRotator>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportRelativeLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_TeleportRelativeRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FFortAthenaTeleportToActorStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0xc8
struct FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> GameplayEffectClassesToAdd() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bAutomaticallyRemoveAddedEffectsOnExit() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    TArray<UClass*> GameplayEffectClassesToRemove() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer GameplayEffectsByTagsToRemove() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayEffectsBySourceTagsToRemove() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayEffectsByAppliedTagsToRemove() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayEffectsByGrantedTagsToRemove() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayEffectClassesToAdd(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bAutomaticallyRemoveAddedEffectsOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayEffectClassesToRemove(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayEffectsByTagsToRemove(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: StructProperty)
    void SET_GameplayEffectsBySourceTagsToRemove(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_GameplayEffectsByAppliedTagsToRemove(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x20, Type: StructProperty)
    void SET_GameplayEffectsByGrantedTagsToRemove(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FFortAthenaToggleGameplayEffectStateTreeTask : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x58
struct FFortWorldConditionPlaylist : public FWorldConditionCommonBase
{
public:
    FGameplayTagQuery PlaylistQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)

    void SET_PlaylistQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
};

// Size: 0x58
struct FFortWorldConditionWorldState : public FWorldConditionCommonBase
{
public:
    FGameplayTagQuery WorldStateQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)

    void SET_WorldStateQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
};

