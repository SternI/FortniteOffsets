/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Filter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CompeteUI.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "Engine.h"
#include "Systems.h"
#include "UIKit.h"

// Size: 0x4b8
class UWBP_TournamentsFilter_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_TournamentFilter() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TournamentType() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TournamentStatus() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TeamSize() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Region() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Experience() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Eligibility() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Bookmarks() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Dialog_Internal_C* Dialog_Internal() const { return Read<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Cancel() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_ApplyFilters() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarFilterVM* FortPoblanoTournamentsCalendarFilterVM() const { return Read<UFortPoblanoTournamentsCalendarFilterVM*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: StructProperty)
    void SET_Text_TournamentFilter(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_TournamentType(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_TournamentStatus(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_TeamSize(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Region(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Experience(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Eligibility(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Bookmarks(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_Dialog_Internal(const UWBP_UIKit_Dialog_Internal_C*& Value) { Write<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Cancel(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ApplyFilters(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_FortPoblanoTournamentsCalendarFilterVM(const UFortPoblanoTournamentsCalendarFilterVM*& Value) { Write<UFortPoblanoTournamentsCalendarFilterVM*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x409
class UWBP_TournamentsFilter_Section_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UUniformGridPanel* UniformGridPanel_Filters() const { return Read<UUniformGridPanel*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_SectionName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ButtonWithToggle_C* SelectedRadioToggle() const { return Read<UWBP_UIKit_ButtonWithToggle_C*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    TArray<UWBP_TournamentFilter_SortToggleButton_C*> FilterSectionEntries() const { return Read<TArray<UWBP_TournamentFilter_SortToggleButton_C*>>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x10, Type: ArrayProperty)
    bool bRadioType() const { return Read<bool>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x1, Type: BoolProperty)
    int32_t MaxElementsPerRow() const { return Read<int32_t>(uintptr_t(this) + 0x354); } // 0x354 (Size: 0x4, Type: IntProperty)
    TArray<bool> ToggleValues() const { return Read<TArray<bool>>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x10, Type: ArrayProperty)
    TMap<ETournamentType, TSoftObjectPtr<UTexture*>> TournamentTypesIcons() const { return Read<TMap<ETournamentType, TSoftObjectPtr<UTexture*>>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x50, Type: MapProperty)
    TMap<ETournamentTypeFilter, TSoftObjectPtr<UTexture*>> TournamentTypesFilterIcons() const { return Read<TMap<ETournamentTypeFilter, TSoftObjectPtr<UTexture*>>>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    bool IsShowIcons() const { return Read<bool>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_UniformGridPanel_Filters(const UUniformGridPanel*& Value) { Write<UUniformGridPanel*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_SectionName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedRadioToggle(const UWBP_UIKit_ButtonWithToggle_C*& Value) { Write<UWBP_UIKit_ButtonWithToggle_C*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_FilterSectionEntries(const TArray<UWBP_TournamentFilter_SortToggleButton_C*>& Value) { Write<TArray<UWBP_TournamentFilter_SortToggleButton_C*>>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x10, Type: ArrayProperty)
    void SET_bRadioType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x1, Type: BoolProperty)
    void SET_MaxElementsPerRow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x354, Value); } // 0x354 (Size: 0x4, Type: IntProperty)
    void SET_ToggleValues(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x10, Type: ArrayProperty)
    void SET_TournamentTypesIcons(const TMap<ETournamentType, TSoftObjectPtr<UTexture*>>& Value) { Write<TMap<ETournamentType, TSoftObjectPtr<UTexture*>>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x50, Type: MapProperty)
    void SET_TournamentTypesFilterIcons(const TMap<ETournamentTypeFilter, TSoftObjectPtr<UTexture*>>& Value) { Write<TMap<ETournamentTypeFilter, TSoftObjectPtr<UTexture*>>>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    void SET_IsShowIcons(const bool& Value) { Write<bool>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1938
class UWBP_TournamentFilter_SortToggleButton_C : public UWBP_UIKit_ButtonWithToggle_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18e0); } // 0x18e0 (Size: 0x8, Type: StructProperty)
    float MainPaddingLeft() const { return Read<float>(uintptr_t(this) + 0x18f8); } // 0x18f8 (Size: 0x4, Type: FloatProperty)
    UMaterialInstance* ToggleIconMaterial() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1920); } // 0x1920 (Size: 0x8, Type: ObjectProperty)
    FText FilterName() const { return Read<FText>(uintptr_t(this) + 0x1928); } // 0x1928 (Size: 0x10, Type: TextProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18e0, Value); } // 0x18e0 (Size: 0x8, Type: StructProperty)
    void SET_MainPaddingLeft(const float& Value) { Write<float>(uintptr_t(this) + 0x18f8, Value); } // 0x18f8 (Size: 0x4, Type: FloatProperty)
    void SET_ToggleIconMaterial(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1920, Value); } // 0x1920 (Size: 0x8, Type: ObjectProperty)
    void SET_FilterName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1928, Value); } // 0x1928 (Size: 0x10, Type: TextProperty)
};

