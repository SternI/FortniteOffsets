/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x78
class UAnimationDataSourceRegistry : public UObject
{
public:
    TMap<FName, TWeakObjectPtr<UObject*>> DataSources() const { return Read<TMap<FName, TWeakObjectPtr<UObject*>>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_DataSources(const TMap<FName, TWeakObjectPtr<UObject*>>& Value) { Write<TMap<FName, TWeakObjectPtr<UObject*>>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x20
struct FAxis
{
public:
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    bool bInLocalSpace() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_bInLocalSpace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FNodeChain
{
public:
    TArray<FName> Nodes() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Nodes(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FNodeObject
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName ParentName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ParentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x70
struct FNodeHierarchyData
{
public:
    TArray<FNodeObject> Nodes() const { return Read<TArray<FNodeObject>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, int32_t> NodeNameToIndexMapping() const { return Read<TMap<FName, int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: MapProperty)

    void SET_Nodes(const TArray<FNodeObject>& Value) { Write<TArray<FNodeObject>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_NodeNameToIndexMapping(const TMap<FName, int32_t>& Value) { Write<TMap<FName, int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: MapProperty)
};

// Size: 0x78
struct FNodeHierarchyWithUserData
{
public:
    FNodeHierarchyData Hierarchy() const { return Read<FNodeHierarchyData>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)

    void SET_Hierarchy(const FNodeHierarchyData& Value) { Write<FNodeHierarchyData>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
};

// Size: 0xe0
struct FCCDIKChainLink
{
public:
};

// Size: 0x3
struct FFilterOptionPerAxis
{
public:
    bool bX() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bY() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bZ() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)

    void SET_bX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bY(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bZ(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x9
struct FTransformFilter
{
public:
    FFilterOptionPerAxis TranslationFilter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis RotationFilter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis ScaleFilter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x3, Type: StructProperty)

    void SET_TranslationFilter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x3, Type: StructProperty)
    void SET_RotationFilter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x3, Type: StructProperty)
    void SET_ScaleFilter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x3, Type: StructProperty)
};

// Size: 0xd
struct FConstraintDescription
{
public:
    bool bTranslation() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bRotation() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bScale() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bParent() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis TranslationAxes() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis RotationAxes() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis ScaleAxes() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x3, Type: StructProperty)

    void SET_bTranslation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_TranslationAxes(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x3, Type: StructProperty)
    void SET_RotationAxes(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x3, Type: StructProperty)
    void SET_ScaleAxes(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x3, Type: StructProperty)
};

// Size: 0xc0
struct FConstraintOffset
{
public:
    FVector Translation() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FVector Scale() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FTransform Parent() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x60, Type: StructProperty)

    void SET_Translation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Parent(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x60, Type: StructProperty)
};

// Size: 0x20
struct FTransformConstraint
{
public:
    FConstraintDescription Operator() const { return Read<FConstraintDescription>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xd, Type: StructProperty)
    FName SourceNode() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName TargetNode() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_Operator(const FConstraintDescription& Value) { Write<FConstraintDescription>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xd, Type: StructProperty)
    void SET_SourceNode(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_TargetNode(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FConstraintDescriptionEx
{
public:
    FFilterOptionPerAxis AxesFilterOption() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x3, Type: StructProperty)

    void SET_AxesFilterOption(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x3, Type: StructProperty)
};

// Size: 0x18
struct FTransformConstraintDescription : public FConstraintDescriptionEx
{
public:
    uint8_t TransformType() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_TransformType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x70
struct FAimConstraintDescription : public FConstraintDescriptionEx
{
public:
    FAxis LookAt_Axis() const { return Read<FAxis>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FAxis LookUp_Axis() const { return Read<FAxis>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    bool bUseLookUp() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FVector LookUpTarget() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_LookAt_Axis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_LookUp_Axis(const FAxis& Value) { Write<FAxis>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_bUseLookUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_LookUpTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x10
struct FConstraintDescriptor
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xe0
struct FConstraintData
{
public:
    FConstraintDescriptor Constraint() const { return Read<FConstraintDescriptor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    FTransform Offset() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform CurrentTransform() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)

    void SET_Constraint(const FConstraintDescriptor& Value) { Write<FConstraintDescriptor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_Offset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_CurrentTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
};

// Size: 0x48
struct FEulerTransform
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Scale() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FFABRIKChainLink
{
public:
};

// Size: 0x40
struct FTransformNoScale
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

