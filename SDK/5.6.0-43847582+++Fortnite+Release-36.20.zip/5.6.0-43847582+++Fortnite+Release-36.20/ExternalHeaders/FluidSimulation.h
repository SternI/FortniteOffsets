/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FluidSimulation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "Water.h"
#include "Blueprints.h"

// Size: 0x28
struct FFluidForceImpulseTimedEffects
{
public:
    bool EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Strength_29_2CAA30794D1EFF60AE1C3491D011CECF() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    UMaterialInterface* MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Strength_29_2CAA30794D1EFF60AE1C3491D011CECF(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x148
struct FFluidForceDynamicPerInstanceData
{
public:
    FFluidForceDynamic ForceInfo_2_A6A35E3243FAF59D161A5FBAA2F6F2B1() const { return Read<FFluidForceDynamic>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x70, Type: StructProperty)
    FVector ComponentLocation_13_959307184C8E5CCACA55FC8378D92CFD() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FVector ComponentVelocity_5_4F6589474918826DF8A6468CF0F2C361() const { return Read<FVector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    float BoundsRadius_30_ADFF818743BE39AC4A481D995CB50D03() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float WaterLevel_34_A4E505D148073B883CA7B1B09A3E34A8() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    TMap<FName, FVector> SocketLocationMap_21_ABF6AA244A5F84728A5E83BE2328C7FA() const { return Read<TMap<FName, FVector>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x50, Type: MapProperty)
    TMap<FName, FVector> SocketVelocityMap_26_82B0E24B45935A12E1949F918A59A537() const { return Read<TMap<FName, FVector>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x50, Type: MapProperty)

    void SET_ForceInfo_2_A6A35E3243FAF59D161A5FBAA2F6F2B1(const FFluidForceDynamic& Value) { Write<FFluidForceDynamic>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x70, Type: StructProperty)
    void SET_ComponentLocation_13_959307184C8E5CCACA55FC8378D92CFD(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_ComponentVelocity_5_4F6589474918826DF8A6468CF0F2C361(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_BoundsRadius_30_ADFF818743BE39AC4A481D995CB50D03(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_WaterLevel_34_A4E505D148073B883CA7B1B09A3E34A8(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_SocketLocationMap_21_ABF6AA244A5F84728A5E83BE2328C7FA(const TMap<FName, FVector>& Value) { Write<TMap<FName, FVector>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x50, Type: MapProperty)
    void SET_SocketVelocityMap_26_82B0E24B45935A12E1949F918A59A537(const TMap<FName, FVector>& Value) { Write<TMap<FName, FVector>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x70
struct FFluidForceDynamic
{
public:
    TEnumAsByte<FluidDynamicForceMeshType> ForceType_28_DDC16EE543D2DFD3BA29C49D32198C9C() const { return Read<TEnumAsByte<FluidDynamicForceMeshType>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    float ForceRadius_32_C31B527C4C367A5CA5E1DF8E49E76234() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ForceStrength_33_2CAA30794D1EFF60AE1C3491D011CECF() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    USceneComponent* ForceComponent_34_ABF6640F40D37677EF6F809E09046055() const { return Read<USceneComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* MaterialOverride_25_5A792CE8489A59E5D9B24F9E4DCFE94A() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    FFluidForceSocketInfo SkeletalMeshSetup_31_51A4130440BAFFBA1DA0FE83E942A30A() const { return Read<FFluidForceSocketInfo>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: StructProperty)

    void SET_ForceType_28_DDC16EE543D2DFD3BA29C49D32198C9C(const TEnumAsByte<FluidDynamicForceMeshType>& Value) { Write<TEnumAsByte<FluidDynamicForceMeshType>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_ForceRadius_32_C31B527C4C367A5CA5E1DF8E49E76234(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ForceStrength_33_2CAA30794D1EFF60AE1C3491D011CECF(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ForceComponent_34_ABF6640F40D37677EF6F809E09046055(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_MaterialOverride_25_5A792CE8489A59E5D9B24F9E4DCFE94A(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_SkeletalMeshSetup_31_51A4130440BAFFBA1DA0FE83E942A30A(const FFluidForceSocketInfo& Value) { Write<FFluidForceSocketInfo>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: StructProperty)
};

// Size: 0x50
struct FFluidForceSocketInfo
{
public:
    TMap<FName, FName> SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x2b0
class ABP_FluidSimParent_C : public AActor
{
public:
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x5e8
class ABP_FluidSim_01_C : public ABP_FluidSimParent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* DebugPlane() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* RippleSimMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* RenderNormalsMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DisplayMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DisplayBottomMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* CrossSectionMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TArray<UTextureRenderTarget2D*> RippleRTs() const { return Read<TArray<UTextureRenderTarget2D*>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Display_Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    double Virtual_FPS() const { return Read<double>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: DoubleProperty)
    int32_t Passes() const { return Read<int32_t>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: IntProperty)
    double TimeAccumulator() const { return Read<double>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: DoubleProperty)
    double FixedStep() const { return Read<double>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    bool Enabled() const { return Read<bool>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x1, Type: BoolProperty)
    double Fluid_Size() const { return Read<double>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: DoubleProperty)
    int32_t Resolution() const { return Read<int32_t>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<FluidBoundary> Boundary_Condition() const { return Read<TEnumAsByte<FluidBoundary>>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x1, Type: ByteProperty)
    double Travel_Speed() const { return Read<double>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: DoubleProperty)
    double Damping() const { return Read<double>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    UTextureRenderTarget2D* NormalRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    FVector CutPos() const { return Read<FVector>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x18, Type: StructProperty)
    FVector PrevLoc() const { return Read<FVector>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x18, Type: StructProperty)
    FVector PrecLoc2() const { return Read<FVector>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x18, Type: StructProperty)
    FVector PrevOffset() const { return Read<FVector>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x18, Type: StructProperty)
    FVector PrevOffset2() const { return Read<FVector>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x18, Type: StructProperty)
    FVector GridCenter() const { return Read<FVector>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x18, Type: StructProperty)
    UTextureRenderTarget2D* TempRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* ForcesRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    double ApplyForces() const { return Read<double>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: DoubleProperty)
    ALandscapeWaterInfo_C* LandscapeWaterInfo() const { return Read<ALandscapeWaterInfo_C*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    int32_t Renders_Per_Frame() const { return Read<int32_t>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x4, Type: IntProperty)
    bool Show_Cross_Section() const { return Read<bool>(uintptr_t(this) + 0x404); } // 0x404 (Size: 0x1, Type: BoolProperty)
    bool Perf_Test_Mode() const { return Read<bool>(uintptr_t(this) + 0x405); } // 0x405 (Size: 0x1, Type: BoolProperty)
    UTextureRenderTarget2D* PerfRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    TArray<FFluidForceImpulsePerInstanceData> ImpulseForces() const { return Read<TArray<FFluidForceImpulsePerInstanceData>>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x10, Type: ArrayProperty)
    TMap<UActorComponent*, FFluidForceDynamicPerInstanceData> DynamicForces() const { return Read<TMap<UActorComponent*, FFluidForceDynamicPerInstanceData>>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x50, Type: MapProperty)
    TMap<UMaterialInterface*, UMaterialInstanceDynamic*> ForceParentAndMIDMap() const { return Read<TMap<UMaterialInterface*, UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x50, Type: MapProperty)
    bool Show_Simulation_Mesh() const { return Read<bool>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x1, Type: BoolProperty)
    UStaticMeshComponent* Fluid_Display_Mesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Cross_Section_Mesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    double FluidSizeSquared() const { return Read<double>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: DoubleProperty)
    bool LocalPawnRef() const { return Read<bool>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    bool Debug_Text() const { return Read<bool>(uintptr_t(this) + 0x4e1); } // 0x4e1 (Size: 0x1, Type: BoolProperty)
    int32_t Pawn_Check_Every_N_Frames() const { return Read<int32_t>(uintptr_t(this) + 0x4e4); } // 0x4e4 (Size: 0x4, Type: IntProperty)
    TMap<UActorComponent*, FFluidForceDynamicPerInstanceData> ProjectileForces() const { return Read<TMap<UActorComponent*, FFluidForceDynamicPerInstanceData>>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x50, Type: MapProperty)
    bool Follow_Player_() const { return Read<bool>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x1, Type: BoolProperty)
    int32_t Frames_Since_Last_Active_Force() const { return Read<int32_t>(uintptr_t(this) + 0x53c); } // 0x53c (Size: 0x4, Type: IntProperty)
    bool Use_Terrain_Water_System() const { return Read<bool>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* PhysicsForceMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    bool Add_Physics_Forces() const { return Read<bool>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x1, Type: BoolProperty)
    UTexture* WaterVelocityTexture() const { return Read<UTexture*>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<AWaterZone> WaterZone() const { return Read<TSoftObjectPtr<AWaterZone>>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x20, Type: SoftObjectProperty)
    bool UpdateForcesInFixedTimeStep() const { return Read<bool>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x1, Type: BoolProperty)
    bool UpdateSimInFixedTimeStep() const { return Read<bool>(uintptr_t(this) + 0x581); } // 0x581 (Size: 0x1, Type: BoolProperty)
    bool UpdateNormalInFixedTimeStep() const { return Read<bool>(uintptr_t(this) + 0x582); } // 0x582 (Size: 0x1, Type: BoolProperty)
    bool ShowDebugWaterPlane() const { return Read<bool>(uintptr_t(this) + 0x583); } // 0x583 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* DebugWaterPlaneMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DebugRippleRT1() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DebugRippleRT2() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DebugRippleRTCurrent() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    int32_t WaterZoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x4, Type: IntProperty)
    double MaxFlowVelocity() const { return Read<double>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    FVector2D WaterZoneExtent() const { return Read<FVector2D>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x10, Type: StructProperty)
    FVector WaterZoneLocation() const { return Read<FVector>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x18, Type: StructProperty)
    UMaterialInterface* DefaultSplashMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    void SET_DebugPlane(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_RippleSimMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_RenderNormalsMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayBottomMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_CrossSectionMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_RippleRTs(const TArray<UTextureRenderTarget2D*>& Value) { Write<TArray<UTextureRenderTarget2D*>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    void SET_Display_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Virtual_FPS(const double& Value) { Write<double>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: DoubleProperty)
    void SET_Passes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: IntProperty)
    void SET_TimeAccumulator(const double& Value) { Write<double>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: DoubleProperty)
    void SET_FixedStep(const double& Value) { Write<double>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    void SET_Enabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x1, Type: BoolProperty)
    void SET_Fluid_Size(const double& Value) { Write<double>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: DoubleProperty)
    void SET_Resolution(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: IntProperty)
    void SET_Boundary_Condition(const TEnumAsByte<FluidBoundary>& Value) { Write<TEnumAsByte<FluidBoundary>>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x1, Type: ByteProperty)
    void SET_Travel_Speed(const double& Value) { Write<double>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: DoubleProperty)
    void SET_Damping(const double& Value) { Write<double>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    void SET_NormalRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_CutPos(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x18, Type: StructProperty)
    void SET_PrevLoc(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x18, Type: StructProperty)
    void SET_PrecLoc2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x18, Type: StructProperty)
    void SET_PrevOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x18, Type: StructProperty)
    void SET_PrevOffset2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x18, Type: StructProperty)
    void SET_GridCenter(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x18, Type: StructProperty)
    void SET_TempRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ForcesRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ApplyForces(const double& Value) { Write<double>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: DoubleProperty)
    void SET_LandscapeWaterInfo(const ALandscapeWaterInfo_C*& Value) { Write<ALandscapeWaterInfo_C*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Renders_Per_Frame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x4, Type: IntProperty)
    void SET_Show_Cross_Section(const bool& Value) { Write<bool>(uintptr_t(this) + 0x404, Value); } // 0x404 (Size: 0x1, Type: BoolProperty)
    void SET_Perf_Test_Mode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x405, Value); } // 0x405 (Size: 0x1, Type: BoolProperty)
    void SET_PerfRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_ImpulseForces(const TArray<FFluidForceImpulsePerInstanceData>& Value) { Write<TArray<FFluidForceImpulsePerInstanceData>>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x10, Type: ArrayProperty)
    void SET_DynamicForces(const TMap<UActorComponent*, FFluidForceDynamicPerInstanceData>& Value) { Write<TMap<UActorComponent*, FFluidForceDynamicPerInstanceData>>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x50, Type: MapProperty)
    void SET_ForceParentAndMIDMap(const TMap<UMaterialInterface*, UMaterialInstanceDynamic*>& Value) { Write<TMap<UMaterialInterface*, UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x50, Type: MapProperty)
    void SET_Show_Simulation_Mesh(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x1, Type: BoolProperty)
    void SET_Fluid_Display_Mesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Cross_Section_Mesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_FluidSizeSquared(const double& Value) { Write<double>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: DoubleProperty)
    void SET_LocalPawnRef(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    void SET_Debug_Text(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e1, Value); } // 0x4e1 (Size: 0x1, Type: BoolProperty)
    void SET_Pawn_Check_Every_N_Frames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4e4, Value); } // 0x4e4 (Size: 0x4, Type: IntProperty)
    void SET_ProjectileForces(const TMap<UActorComponent*, FFluidForceDynamicPerInstanceData>& Value) { Write<TMap<UActorComponent*, FFluidForceDynamicPerInstanceData>>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x50, Type: MapProperty)
    void SET_Follow_Player_(const bool& Value) { Write<bool>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x1, Type: BoolProperty)
    void SET_Frames_Since_Last_Active_Force(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x53c, Value); } // 0x53c (Size: 0x4, Type: IntProperty)
    void SET_Use_Terrain_Water_System(const bool& Value) { Write<bool>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x1, Type: BoolProperty)
    void SET_PhysicsForceMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    void SET_Add_Physics_Forces(const bool& Value) { Write<bool>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x1, Type: BoolProperty)
    void SET_WaterVelocityTexture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    void SET_WaterZone(const TSoftObjectPtr<AWaterZone>& Value) { Write<TSoftObjectPtr<AWaterZone>>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UpdateForcesInFixedTimeStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x1, Type: BoolProperty)
    void SET_UpdateSimInFixedTimeStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x581, Value); } // 0x581 (Size: 0x1, Type: BoolProperty)
    void SET_UpdateNormalInFixedTimeStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x582, Value); } // 0x582 (Size: 0x1, Type: BoolProperty)
    void SET_ShowDebugWaterPlane(const bool& Value) { Write<bool>(uintptr_t(this) + 0x583, Value); } // 0x583 (Size: 0x1, Type: BoolProperty)
    void SET_DebugWaterPlaneMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugRippleRT1(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugRippleRT2(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugRippleRTCurrent(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_WaterZoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x4, Type: IntProperty)
    void SET_MaxFlowVelocity(const double& Value) { Write<double>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    void SET_WaterZoneExtent(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x10, Type: StructProperty)
    void SET_WaterZoneLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x18, Type: StructProperty)
    void SET_DefaultSplashMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x61
struct FFluidForceImpulsePerInstanceData
{
public:
    FFluidForceImpulse ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC() const { return Read<FFluidForceImpulse>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x58, Type: StructProperty)
    float ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    bool IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)

    void SET_ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC(const FFluidForceImpulse& Value) { Write<FFluidForceImpulse>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x58, Type: StructProperty)
    void SET_ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
struct FFluidForceImpulse
{
public:
    FVector WorldPosition_32_C9A94C02422D8BF40DF6B1BB2A0D8CBC() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    float ForceRadius_31_C31B527C4C367A5CA5E1DF8E49E76234() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float ForceStrength_30_2CAA30794D1EFF60AE1C3491D011CECF() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    UMaterialInterface* MaterialOverride_24_5A792CE8489A59E5D9B24F9E4DCFE94A() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    float Lifetime_34_C2749C1449C41D4F236BCBAF6ED34113() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float StrengthoverLifePower_41_85B52C994A7ED323A34BF4BBCB0DFA0F() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    FFluidForceImpulseTimedEffects TimedWaterDropSplashes_38_2CB1456B483AEF3A52677AAF4152E31E() const { return Read<FFluidForceImpulseTimedEffects>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)

    void SET_WorldPosition_32_C9A94C02422D8BF40DF6B1BB2A0D8CBC(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_ForceRadius_31_C31B527C4C367A5CA5E1DF8E49E76234(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_ForceStrength_30_2CAA30794D1EFF60AE1C3491D011CECF(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MaterialOverride_24_5A792CE8489A59E5D9B24F9E4DCFE94A(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_Lifetime_34_C2749C1449C41D4F236BCBAF6ED34113(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_StrengthoverLifePower_41_85B52C994A7ED323A34BF4BBCB0DFA0F(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_TimedWaterDropSplashes_38_2CB1456B483AEF3A52677AAF4152E31E(const FFluidForceImpulseTimedEffects& Value) { Write<FFluidForceImpulseTimedEffects>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
};

