/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowEnginePlugin
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GeometryFramework.h"

// Size: 0x2b0
class ADataflowActor : public AActor
{
public:
    UDataflowComponent* DataflowComponent() const { return Read<UDataflowComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_DataflowComponent(const UDataflowComponent*& Value) { Write<UDataflowComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x660
class UDataflowComponent : public UPrimitiveComponent
{
public:
};

// Size: 0x20
struct FCollectionAttributeKey
{
public:
    FString Attribute() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Group() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Attribute(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Group(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FDataflowDynamicMeshArray : public FDataflowAnyType
{
public:
    TArray<UDynamicMesh*> Value() const { return Read<TArray<UDynamicMesh*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<UDynamicMesh*>& Value) { Write<TArray<UDynamicMesh*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

