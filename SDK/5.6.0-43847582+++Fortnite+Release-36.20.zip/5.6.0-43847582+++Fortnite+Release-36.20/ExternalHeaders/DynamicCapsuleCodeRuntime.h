/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicCapsuleCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"

// Size: 0x110
class UDynamicCapsuleComponent : public UFortPawnComponent
{
public:
    TArray<FDynamicCapsuleEntry> DynamicCapsuleEntryStack() const { return Read<TArray<FDynamicCapsuleEntry>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    FDynamicCapsuleState ReplicatedCapsuleState() const { return Read<FDynamicCapsuleState>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)

    void SET_DynamicCapsuleEntryStack(const TArray<FDynamicCapsuleEntry>& Value) { Write<TArray<FDynamicCapsuleEntry>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedCapsuleState(const FDynamicCapsuleState& Value) { Write<FDynamicCapsuleState>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
class UAnimNotifyState_SetCapsuleSize : public UAnimNotifyState
{
public:
    float TargetCapsuleRadius() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float TargetCapsuleHalfHeight() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bAdjustRelativeMeshHeight() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    float TargetRelativeMeshHeight() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FGameplayTag CapsuleSizeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: StructProperty)

    void SET_TargetCapsuleRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_TargetCapsuleHalfHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_bAdjustRelativeMeshHeight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_TargetRelativeMeshHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_CapsuleSizeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FDynamicCapsuleState
{
public:
    float CapsuleRadius() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float CapsuleHalfHeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    double RelativeMeshHeight() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_CapsuleRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_CapsuleHalfHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_RelativeMeshHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x18
struct FDynamicCapsuleEntry
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FDynamicCapsuleState State() const { return Read<FDynamicCapsuleState>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_State(const FDynamicCapsuleState& Value) { Write<FDynamicCapsuleState>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

