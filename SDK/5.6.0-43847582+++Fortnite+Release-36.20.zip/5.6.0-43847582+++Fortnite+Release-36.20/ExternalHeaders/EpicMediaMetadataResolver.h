/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaMetadataResolver
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "EpicMediaOptions.h"
#include "EpicMediaCDNHostnames.h"

// Size: 0x198
class UEpicMediaMetadataResolver : public UObject
{
public:
    UEpicMediaCDNHostnames* CDNHostNames() const { return Read<UEpicMediaCDNHostnames*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_CDNHostNames(const UEpicMediaCDNHostnames*& Value) { Write<UEpicMediaCDNHostnames*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

