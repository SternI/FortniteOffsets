/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CowCatcherModCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x9c8
class ACowCatcherBarricadeBase : public ABuildingGameplayActor
{
public:
};

