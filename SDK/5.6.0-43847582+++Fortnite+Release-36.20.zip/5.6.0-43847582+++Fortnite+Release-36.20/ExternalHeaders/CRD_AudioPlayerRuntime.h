/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_AudioPlayerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "HarmonixMetasound.h"

// Size: 0x280
class UCreativeAudioComponent : public UActorComponent
{
public:
    float StereoSpreadScaleFactor() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float FadeInDuration() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    bool bSyncPlayerAudio() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    bool bRestartAudioOnPlay() const { return Read<bool>(uintptr_t(this) + 0xf1); } // 0xf1 (Size: 0x1, Type: BoolProperty)
    uint8_t CanBeHeardBy() const { return Read<uint8_t>(uintptr_t(this) + 0xf2); } // 0xf2 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayLocation() const { return Read<uint8_t>(uintptr_t(this) + 0xf3); } // 0xf3 (Size: 0x1, Type: EnumProperty)
    uint8_t AutoplayOptions() const { return Read<uint8_t>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x1, Type: EnumProperty)
    UFortMinigameProgressComponent* FortMinigameProgressComponent() const { return Read<UFortMinigameProgressComponent*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    UCreativeProxyManagerComponent* CreativeProxyManager() const { return Read<UCreativeProxyManagerComponent*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    UCreativeRegisteredPlayersManagerComponent* CreativeRegisteredPlayersManagerComponent() const { return Read<UCreativeRegisteredPlayersManagerComponent*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    UMusicClockComponent* MusicClockComponent() const { return Read<UMusicClockComponent*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    TMap<FUniqueNetIdRepl, UAudioComponent*> PlayerAudioComponents() const { return Read<TMap<FUniqueNetIdRepl, UAudioComponent*>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x50, Type: MapProperty)
    ACreativeAudioPlayerReplicationProxy* ClientCachedProxy() const { return Read<ACreativeAudioPlayerReplicationProxy*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    USoundBase* LastSoundPlayed() const { return Read<USoundBase*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    FCreativeAudioPlayerData ServerInstigatorData() const { return Read<FCreativeAudioPlayerData>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x40, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    bool bAudioLoaded() const { return Read<bool>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x1, Type: BoolProperty)
    FCreativeAudioPlayerData CachedInstigatorData() const { return Read<FCreativeAudioPlayerData>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x40, Type: StructProperty)
    TArray<FUniqueNetIdRepl> RegisteredPlayerIds() const { return Read<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    TArray<FUniqueNetIdRepl> NonRegisteredPlayerIds() const { return Read<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x10, Type: ArrayProperty)
    uint8_t CurrentAutoplayState() const { return Read<uint8_t>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x1, Type: EnumProperty)

    void SET_StereoSpreadScaleFactor(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_FadeInDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_FadeOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_bSyncPlayerAudio(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_bRestartAudioOnPlay(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf1, Value); } // 0xf1 (Size: 0x1, Type: BoolProperty)
    void SET_CanBeHeardBy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xf2, Value); } // 0xf2 (Size: 0x1, Type: EnumProperty)
    void SET_PlayLocation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xf3, Value); } // 0xf3 (Size: 0x1, Type: EnumProperty)
    void SET_AutoplayOptions(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x1, Type: EnumProperty)
    void SET_FortMinigameProgressComponent(const UFortMinigameProgressComponent*& Value) { Write<UFortMinigameProgressComponent*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeProxyManager(const UCreativeProxyManagerComponent*& Value) { Write<UCreativeProxyManagerComponent*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeRegisteredPlayersManagerComponent(const UCreativeRegisteredPlayersManagerComponent*& Value) { Write<UCreativeRegisteredPlayersManagerComponent*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicClockComponent(const UMusicClockComponent*& Value) { Write<UMusicClockComponent*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerAudioComponents(const TMap<FUniqueNetIdRepl, UAudioComponent*>& Value) { Write<TMap<FUniqueNetIdRepl, UAudioComponent*>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x50, Type: MapProperty)
    void SET_ClientCachedProxy(const ACreativeAudioPlayerReplicationProxy*& Value) { Write<ACreativeAudioPlayerReplicationProxy*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    void SET_LastSoundPlayed(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerInstigatorData(const FCreativeAudioPlayerData& Value) { Write<FCreativeAudioPlayerData>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x40, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    void SET_bAudioLoaded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x1, Type: BoolProperty)
    void SET_CachedInstigatorData(const FCreativeAudioPlayerData& Value) { Write<FCreativeAudioPlayerData>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x40, Type: StructProperty)
    void SET_RegisteredPlayerIds(const TArray<FUniqueNetIdRepl>& Value) { Write<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_NonRegisteredPlayerIds(const TArray<FUniqueNetIdRepl>& Value) { Write<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentAutoplayState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x2f8
class ACreativeAudioPlayerReplicationProxy : public ACreativePlayerReplicationProxy
{
public:
    FCreativeAudioPlayerData InstigatorData() const { return Read<FCreativeAudioPlayerData>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x40, Type: StructProperty)

    void SET_InstigatorData(const FCreativeAudioPlayerData& Value) { Write<FCreativeAudioPlayerData>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x40, Type: StructProperty)
};

// Size: 0x40
struct FCreativeAudioPlayerData
{
public:
    FUniqueNetIdRepl NetId() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    APawn* Pawn() const { return Read<APawn*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    float ServerAudioStartTime() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_NetId(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_Pawn(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerAudioStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FCreativeAudioPlayerMusicClockParams
{
public:
    bool bConnectToMetaSoundClock() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bRegisterWithMusicEventSubsystem() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    FGameplayTag MusicEventSubsystemEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer MusicEventSubsystemBehaviorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_bConnectToMetaSoundClock(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bRegisterWithMusicEventSubsystem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_MusicEventSubsystemEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_MusicEventSubsystemBehaviorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

