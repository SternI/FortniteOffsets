/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortWaterAdvanced
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "WaterAdvanced.h"

// Size: 0x288
class UFortShallowWaterSubsystem : public UShallowWaterSubsystem
{
public:
};

// Size: 0x48
class UFortGameFeatureAction_InitPhysicsOverrides : public UGameFeatureAction
{
public:
    TSoftObjectPtr<UShallowWaterPhysicsAssetOverridesDataAsset> PhysicsAssetOverrides() const { return Read<TSoftObjectPtr<UShallowWaterPhysicsAssetOverridesDataAsset>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_PhysicsAssetOverrides(const TSoftObjectPtr<UShallowWaterPhysicsAssetOverridesDataAsset>& Value) { Write<TSoftObjectPtr<UShallowWaterPhysicsAssetOverridesDataAsset>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

