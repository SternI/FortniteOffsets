/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClamberingCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0x130
class UFortMovementMode_ClamberingRuntimeData : public UFortMovementMode_TraversalBaseRuntimeData
{
public:
};

// Size: 0x2a8
class UFortMovementMode_ExtClambering : public UFortMovementMode_ExtLogicTraversalBase
{
public:
    UClass* LedgeLaunchCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: ClassProperty)
    UClass* WindowClamberCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer ClamberingTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x20, Type: StructProperty)
    FGameplayTag ClamberingStartedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer ClamberingFinishedTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x20, Type: StructProperty)
    UCameraShakeBase* CameraShake() const { return Read<UCameraShakeBase*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    float LedgeLaunchSyncPointInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: FloatProperty)
    float LedgeLaunchPlayerCollideBounceSpeed() const { return Read<float>(uintptr_t(this) + 0x2a4); } // 0x2a4 (Size: 0x4, Type: FloatProperty)

    void SET_LedgeLaunchCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: ClassProperty)
    void SET_WindowClamberCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x8, Type: ClassProperty)
    void SET_ClamberingTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x20, Type: StructProperty)
    void SET_ClamberingStartedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x4, Type: StructProperty)
    void SET_ClamberingFinishedTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x20, Type: StructProperty)
    void SET_CameraShake(const UCameraShakeBase*& Value) { Write<UCameraShakeBase*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    void SET_LedgeLaunchSyncPointInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: FloatProperty)
    void SET_LedgeLaunchPlayerCollideBounceSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2a4, Value); } // 0x2a4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x308
class AInstancedLedgeActor : public AFortClientOnlyActor
{
public:
    UInstancedStaticMeshComponent* InstancedStaticMeshComponent() const { return Read<UInstancedStaticMeshComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_InstancedStaticMeshComponent(const UInstancedStaticMeshComponent*& Value) { Write<UInstancedStaticMeshComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x150
class ULedgeLaunchWorldSubsystem : public UBuildingWallSubsystem
{
public:
    TSoftObjectPtr<UPBWLedgeConfigurationData> ConfigurationData() const { return Read<TSoftObjectPtr<UPBWLedgeConfigurationData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    UPBWLedgeConfigurationData* CachedConfigurationData() const { return Read<UPBWLedgeConfigurationData*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    AInstancedLedgeActor* InstancedLedgeActor() const { return Read<AInstancedLedgeActor*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    TMap<UClass*, FLedgeLaunchConfigEntry> CachedLedgeLaunchMap() const { return Read<TMap<UClass*, FLedgeLaunchConfigEntry>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)

    void SET_ConfigurationData(const TSoftObjectPtr<UPBWLedgeConfigurationData>& Value) { Write<TSoftObjectPtr<UPBWLedgeConfigurationData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CachedConfigurationData(const UPBWLedgeConfigurationData*& Value) { Write<UPBWLedgeConfigurationData*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_InstancedLedgeActor(const AInstancedLedgeActor*& Value) { Write<AInstancedLedgeActor*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedLedgeLaunchMap(const TMap<UClass*, FLedgeLaunchConfigEntry>& Value) { Write<TMap<UClass*, FLedgeLaunchConfigEntry>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
};

// Size: 0x1c0
class UPBWLedgeConfigurationData : public UDataAsset
{
public:
    TMap<EPlayerBuiltWallType, TSoftClassPtr> MetalWalls() const { return Read<TMap<EPlayerBuiltWallType, TSoftClassPtr>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<EPlayerBuiltWallType, TSoftClassPtr> StoneWalls() const { return Read<TMap<EPlayerBuiltWallType, TSoftClassPtr>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)
    TMap<EPlayerBuiltWallType, TSoftClassPtr> WoodWalls() const { return Read<TMap<EPlayerBuiltWallType, TSoftClassPtr>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)
    TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry> Transforms() const { return Read<TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x50, Type: MapProperty)
    TMap<EPlayerBuiltWallMaterialType, FLedgeLaunchTransformConfigEntry> PerMaterialTransforms() const { return Read<TMap<EPlayerBuiltWallMaterialType, FLedgeLaunchTransformConfigEntry>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x50, Type: MapProperty)

    void SET_MetalWalls(const TMap<EPlayerBuiltWallType, TSoftClassPtr>& Value) { Write<TMap<EPlayerBuiltWallType, TSoftClassPtr>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_StoneWalls(const TMap<EPlayerBuiltWallType, TSoftClassPtr>& Value) { Write<TMap<EPlayerBuiltWallType, TSoftClassPtr>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
    void SET_WoodWalls(const TMap<EPlayerBuiltWallType, TSoftClassPtr>& Value) { Write<TMap<EPlayerBuiltWallType, TSoftClassPtr>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
    void SET_Transforms(const TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry>& Value) { Write<TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x50, Type: MapProperty)
    void SET_PerMaterialTransforms(const TMap<EPlayerBuiltWallMaterialType, FLedgeLaunchTransformConfigEntry>& Value) { Write<TMap<EPlayerBuiltWallMaterialType, FLedgeLaunchTransformConfigEntry>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x50, Type: MapProperty)
};

// Size: 0x28
class UClamberingAnalytics : public UObject
{
public:
};

// Size: 0x11d0
class UClamberingComponent : public UFortPawnOverrideComponent
{
public:
    uint8_t LocalClamberingState() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t ReplicatedClamberingState() const { return Read<uint8_t>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    FClamberingTargetingData LockedTargetingData() const { return Read<FClamberingTargetingData>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x130, Type: StructProperty)
    FReplicatedClamberingTargetingData_SimClient ReplicatedTargetingData() const { return Read<FReplicatedClamberingTargetingData_SimClient>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x38, Type: StructProperty)
    FScalableFloat ClamberingEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberIndicatorEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberStartMaxFallingDamageFraction() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    bool bPerformTargetingWhileWalking() const { return Read<bool>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bPerformTargetingWhileSwimming() const { return Read<bool>(uintptr_t(this) + 0x2d1); } // 0x2d1 (Size: 0x1, Type: BoolProperty)
    FScalableFloat ServerFailDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ServerValidatePlayerMaxDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x28, Type: StructProperty)
    FClamberingInputConfig InputConfig() const { return Read<FClamberingInputConfig>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x3f0, Type: StructProperty)
    FClamberingTargetingConfig_Ledge TargetingConfig_Ledge() const { return Read<FClamberingTargetingConfig_Ledge>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x5f0, Type: StructProperty)
    FClamberingInputConfig_CachedValues InputConfigCachedValues() const { return Read<FClamberingInputConfig_CachedValues>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x6c, Type: StructProperty)
    FClamberingTargetingConfig_Ledge_CachedContextualValues TargetingConfig_Ledge_CachedContextualValues() const { return Read<FClamberingTargetingConfig_Ledge_CachedContextualValues>(uintptr_t(this) + 0xd74); } // 0xd74 (Size: 0x9c, Type: StructProperty)
    FClamberingMovementConfig_Ledge MoveConfig_Ledge() const { return Read<FClamberingMovementConfig_Ledge>(uintptr_t(this) + 0xe10); } // 0xe10 (Size: 0x50, Type: StructProperty)
    FScalableFloat ClamberSyncTargetLedgeOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe60); } // 0xe60 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberingMaxAnalyticsEvents() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe88); } // 0xe88 (Size: 0x28, Type: StructProperty)
    FScalableFloat SynchedActionFailDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0xeb0); } // 0xeb0 (Size: 0x28, Type: StructProperty)
    UClass* MovementModeExtension() const { return Read<UClass*>(uintptr_t(this) + 0xed8); } // 0xed8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SynchedActionMMETag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xee0); } // 0xee0 (Size: 0x4, Type: StructProperty)
    FGameplayTag AllowTargetingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xee4); } // 0xee4 (Size: 0x4, Type: StructProperty)
    FName LedgeLaunchSyncPointName() const { return Read<FName>(uintptr_t(this) + 0xee8); } // 0xee8 (Size: 0x4, Type: NameProperty)
    double LastTeleportTime() const { return Read<double>(uintptr_t(this) + 0xef0); } // 0xef0 (Size: 0x8, Type: DoubleProperty)
    bool bTutorialModeEnabled() const { return Read<bool>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x1, Type: BoolProperty)
    FClamberingTargetingData LocalTargetingData() const { return Read<FClamberingTargetingData>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x130, Type: StructProperty)
    FClamberingTargetingData ParallelTargetingData() const { return Read<FClamberingTargetingData>(uintptr_t(this) + 0x1030); } // 0x1030 (Size: 0x130, Type: StructProperty)
    float QueuedInputTimer() const { return Read<float>(uintptr_t(this) + 0x1160); } // 0x1160 (Size: 0x4, Type: FloatProperty)
    float InputEnabledTimer() const { return Read<float>(uintptr_t(this) + 0x1164); } // 0x1164 (Size: 0x4, Type: FloatProperty)
    bool bJumpInputPressed() const { return Read<bool>(uintptr_t(this) + 0x1168); } // 0x1168 (Size: 0x1, Type: BoolProperty)
    float JumpHeldInAirTime() const { return Read<float>(uintptr_t(this) + 0x116c); } // 0x116c (Size: 0x4, Type: FloatProperty)
    FGameplayTag Tag_DisableClambering() const { return Read<FGameplayTag>(uintptr_t(this) + 0x11c0); } // 0x11c0 (Size: 0x4, Type: StructProperty)

    void SET_LocalClamberingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_ReplicatedClamberingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: EnumProperty)
    void SET_LockedTargetingData(const FClamberingTargetingData& Value) { Write<FClamberingTargetingData>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x130, Type: StructProperty)
    void SET_ReplicatedTargetingData(const FReplicatedClamberingTargetingData_SimClient& Value) { Write<FReplicatedClamberingTargetingData_SimClient>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x38, Type: StructProperty)
    void SET_ClamberingEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x28, Type: StructProperty)
    void SET_ClamberIndicatorEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_ClamberStartMaxFallingDamageFraction(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_bPerformTargetingWhileWalking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    void SET_bPerformTargetingWhileSwimming(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d1, Value); } // 0x2d1 (Size: 0x1, Type: BoolProperty)
    void SET_ServerFailDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x28, Type: StructProperty)
    void SET_ServerValidatePlayerMaxDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x28, Type: StructProperty)
    void SET_InputConfig(const FClamberingInputConfig& Value) { Write<FClamberingInputConfig>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x3f0, Type: StructProperty)
    void SET_TargetingConfig_Ledge(const FClamberingTargetingConfig_Ledge& Value) { Write<FClamberingTargetingConfig_Ledge>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x5f0, Type: StructProperty)
    void SET_InputConfigCachedValues(const FClamberingInputConfig_CachedValues& Value) { Write<FClamberingInputConfig_CachedValues>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x6c, Type: StructProperty)
    void SET_TargetingConfig_Ledge_CachedContextualValues(const FClamberingTargetingConfig_Ledge_CachedContextualValues& Value) { Write<FClamberingTargetingConfig_Ledge_CachedContextualValues>(uintptr_t(this) + 0xd74, Value); } // 0xd74 (Size: 0x9c, Type: StructProperty)
    void SET_MoveConfig_Ledge(const FClamberingMovementConfig_Ledge& Value) { Write<FClamberingMovementConfig_Ledge>(uintptr_t(this) + 0xe10, Value); } // 0xe10 (Size: 0x50, Type: StructProperty)
    void SET_ClamberSyncTargetLedgeOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe60, Value); } // 0xe60 (Size: 0x28, Type: StructProperty)
    void SET_ClamberingMaxAnalyticsEvents(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe88, Value); } // 0xe88 (Size: 0x28, Type: StructProperty)
    void SET_SynchedActionFailDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xeb0, Value); } // 0xeb0 (Size: 0x28, Type: StructProperty)
    void SET_MovementModeExtension(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xed8, Value); } // 0xed8 (Size: 0x8, Type: ClassProperty)
    void SET_SynchedActionMMETag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xee0, Value); } // 0xee0 (Size: 0x4, Type: StructProperty)
    void SET_AllowTargetingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xee4, Value); } // 0xee4 (Size: 0x4, Type: StructProperty)
    void SET_LedgeLaunchSyncPointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xee8, Value); } // 0xee8 (Size: 0x4, Type: NameProperty)
    void SET_LastTeleportTime(const double& Value) { Write<double>(uintptr_t(this) + 0xef0, Value); } // 0xef0 (Size: 0x8, Type: DoubleProperty)
    void SET_bTutorialModeEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x1, Type: BoolProperty)
    void SET_LocalTargetingData(const FClamberingTargetingData& Value) { Write<FClamberingTargetingData>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x130, Type: StructProperty)
    void SET_ParallelTargetingData(const FClamberingTargetingData& Value) { Write<FClamberingTargetingData>(uintptr_t(this) + 0x1030, Value); } // 0x1030 (Size: 0x130, Type: StructProperty)
    void SET_QueuedInputTimer(const float& Value) { Write<float>(uintptr_t(this) + 0x1160, Value); } // 0x1160 (Size: 0x4, Type: FloatProperty)
    void SET_InputEnabledTimer(const float& Value) { Write<float>(uintptr_t(this) + 0x1164, Value); } // 0x1164 (Size: 0x4, Type: FloatProperty)
    void SET_bJumpInputPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1168, Value); } // 0x1168 (Size: 0x1, Type: BoolProperty)
    void SET_JumpHeldInAirTime(const float& Value) { Write<float>(uintptr_t(this) + 0x116c, Value); } // 0x116c (Size: 0x4, Type: FloatProperty)
    void SET_Tag_DisableClambering(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x11c0, Value); } // 0x11c0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x28
class UClamberingLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x520
class AFortAthenaMutator_LedgeLaunch : public AFortAthenaMutator
{
public:
    TArray<TWeakObjectPtr<ABuildingWall*>> CurrentWalls() const { return Read<TArray<TWeakObjectPtr<ABuildingWall*>>>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x10, Type: ArrayProperty)
    bool bShouldSpawnLedge() const { return Read<bool>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x1, Type: BoolProperty)

    void SET_CurrentWalls(const TArray<TWeakObjectPtr<ABuildingWall*>>& Value) { Write<TArray<TWeakObjectPtr<ABuildingWall*>>>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x10, Type: ArrayProperty)
    void SET_bShouldSpawnLedge(const bool& Value) { Write<bool>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x140
struct FFortMovementMode_ClamberingCreationData : public FFortMovementMode_TraversalBaseCreationData
{
public:
    TArray<FSynchedActionWarpPointInfo_Replicated> LedgeLaunchWarpPointInfos() const { return Read<TArray<FSynchedActionWarpPointInfo_Replicated>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    int32_t LedgeLaunchWarpPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: IntProperty)
    bool bCanStandOnLedge() const { return Read<bool>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x1, Type: BoolProperty)
    bool bHasFixedLedgeLaunchWarpPoint() const { return Read<bool>(uintptr_t(this) + 0x13d); } // 0x13d (Size: 0x1, Type: BoolProperty)
    bool bClamberFromFalling() const { return Read<bool>(uintptr_t(this) + 0x13e); } // 0x13e (Size: 0x1, Type: BoolProperty)
    bool bIsReachBack() const { return Read<bool>(uintptr_t(this) + 0x13f); } // 0x13f (Size: 0x1, Type: BoolProperty)

    void SET_LedgeLaunchWarpPointInfos(const TArray<FSynchedActionWarpPointInfo_Replicated>& Value) { Write<TArray<FSynchedActionWarpPointInfo_Replicated>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_LedgeLaunchWarpPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: IntProperty)
    void SET_bCanStandOnLedge(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x1, Type: BoolProperty)
    void SET_bHasFixedLedgeLaunchWarpPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13d, Value); } // 0x13d (Size: 0x1, Type: BoolProperty)
    void SET_bClamberFromFalling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13e, Value); } // 0x13e (Size: 0x1, Type: BoolProperty)
    void SET_bIsReachBack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13f, Value); } // 0x13f (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FClamberMontageInput
{
public:
    FSynchedActionInfo BaseSynchedActionInfo() const { return Read<FSynchedActionInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    FVector FutureLedgeWarpPoint() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    bool bIsLedgeLaunch() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bHasFutureLedge() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bClamberFromFalling() const { return Read<bool>(uintptr_t(this) + 0x4a); } // 0x4a (Size: 0x1, Type: BoolProperty)
    bool bWindowClamber() const { return Read<bool>(uintptr_t(this) + 0x4b); } // 0x4b (Size: 0x1, Type: BoolProperty)
    bool bIsReachBack() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)

    void SET_BaseSynchedActionInfo(const FSynchedActionInfo& Value) { Write<FSynchedActionInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_FutureLedgeWarpPoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_bIsLedgeLaunch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_bHasFutureLedge(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
    void SET_bClamberFromFalling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a, Value); } // 0x4a (Size: 0x1, Type: BoolProperty)
    void SET_bWindowClamber(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b, Value); } // 0x4b (Size: 0x1, Type: BoolProperty)
    void SET_bIsReachBack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FLedgeLaunchConfigEntry
{
public:
    TArray<FTransform> LedgeTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> WindowLedgeTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_LedgeTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_WindowLedgeTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FLedgeLaunchTransformConfigEntry
{
public:
    TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry> Transforms() const { return Read<TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Transforms(const TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry>& Value) { Write<TMap<EPlayerBuiltWallType, FLedgeLaunchConfigEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x3f0
struct FClamberingInputConfig
{
public:
    FScalableFloat ClamberActivationHorizontalRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberActivationVerticalRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberLookAtThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat EnableInputDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat QueuedInputWindow() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HeldInputDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    uint8_t ActivationMode() const { return Read<uint8_t>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: EnumProperty)
    FScalableFloat AutoStartMovementThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartLookAtThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartWallCheckCastRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartWallCheckHorizontalRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartWallCheckLookAtThresholdMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInvalidateDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetAimInvalidateAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetActorMovementInvalidateDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat LedgeLaunchEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDirectionalLedgeLaunchAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x28, Type: StructProperty)
    FScalableFloat PBWLedgeLaunchMaxHorizontalTranslation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x28, Type: StructProperty)
    FScalableFloat DefaultLedgeLaunchVerticalTranslation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat PBWLedgeLaunchVerticalTranslation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PBWNextLedgeLaunchVerticalTranslation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x28, Type: StructProperty)
    FScalableFloat LedgeLaunchWarpingWindow() const { return Read<FScalableFloat>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberExcludeLowTargetEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberLowTargetMaxHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberLowTargetMaxFallHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberDisplayPromptOnWallStickEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x28, Type: StructProperty)

    void SET_ClamberActivationHorizontalRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_ClamberActivationVerticalRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_ClamberLookAtThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_EnableInputDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_QueuedInputWindow(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_HeldInputDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_ActivationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: EnumProperty)
    void SET_AutoStartMovementThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x28, Type: StructProperty)
    void SET_AutoStartLookAtThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x28, Type: StructProperty)
    void SET_AutoStartWallCheckCastRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x28, Type: StructProperty)
    void SET_AutoStartWallCheckHorizontalRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x28, Type: StructProperty)
    void SET_AutoStartWallCheckLookAtThresholdMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x28, Type: StructProperty)
    void SET_TargetInvalidateDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x28, Type: StructProperty)
    void SET_TargetAimInvalidateAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    void SET_TargetActorMovementInvalidateDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x28, Type: StructProperty)
    void SET_LedgeLaunchEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x28, Type: StructProperty)
    void SET_MaxDirectionalLedgeLaunchAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x28, Type: StructProperty)
    void SET_PBWLedgeLaunchMaxHorizontalTranslation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x28, Type: StructProperty)
    void SET_DefaultLedgeLaunchVerticalTranslation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x28, Type: StructProperty)
    void SET_PBWLedgeLaunchVerticalTranslation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x28, Type: StructProperty)
    void SET_PBWNextLedgeLaunchVerticalTranslation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x28, Type: StructProperty)
    void SET_LedgeLaunchWarpingWindow(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x28, Type: StructProperty)
    void SET_ClamberExcludeLowTargetEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x28, Type: StructProperty)
    void SET_ClamberLowTargetMaxHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x28, Type: StructProperty)
    void SET_ClamberLowTargetMaxFallHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x28, Type: StructProperty)
    void SET_ClamberDisplayPromptOnWallStickEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x5f0
struct FClamberingTargetingConfig_Ledge
{
public:
    FScalableFloat ForwardCastDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ForwardCastRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat FowardCast2D() const { return Read<FScalableFloat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat VerticalSurfaceThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat HorizontalSurfaceThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat UpwardDistanceCapsuleHeightMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat UpwardStartDistanceCapsuleHeightMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DownwardDistanceCapsuleHeightMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeHeightWater() const { return Read<FScalableFloat>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x28, Type: StructProperty)
    FScalableFloat FallingSpeedThreshold() const { return Read<FScalableFloat>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeFallingHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeFallingWaterHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ForwardSphereCastRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat DownwardSphereCastRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat AllowNonWalkableSurfaces() const { return Read<FScalableFloat>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationCapsuleRadiusModifier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationCapsuleHalfHeightModifier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationCapsuleBottomVerticalOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat FutureLedgeLaunchMaxVerticalDetectionRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x28, Type: StructProperty)
    FScalableFloat FutureLedgeLaunchMaxHorizontalDetectionRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x28, Type: StructProperty)
    FScalableFloat LedgeExtentThresholdToUseMidpointTargeting() const { return Read<FScalableFloat>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorCheckCastWallOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorCheckDownDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorCheckMaxAllowedAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingHorizontalSweepBreadth() const { return Read<FScalableFloat>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingHorizontalSweepHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingHorizontalOpeningSweepBreadth() const { return Read<FScalableFloat>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingVerticalOffsetCheckInWindowFrame() const { return Read<FScalableFloat>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberScoringModifier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberLedgeLaunchScoringModifier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseMultiSweepCheckForSurfaces() const { return Read<FScalableFloat>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseReachBackClamber() const { return Read<FScalableFloat>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReachBackDistanceSweep() const { return Read<FScalableFloat>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x28, Type: StructProperty)
    FScalableFloat MantleHeightCheckCastWallOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x28, Type: StructProperty)
    FScalableFloat MantleHeightCapsuleRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MantleHeightMaxHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x28, Type: StructProperty)

    void SET_ForwardCastDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_ForwardCastRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_FowardCast2D(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_VerticalSurfaceThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_HorizontalSurfaceThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_UpwardDistanceCapsuleHeightMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_UpwardStartDistanceCapsuleHeightMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
    void SET_DownwardDistanceCapsuleHeightMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x28, Type: StructProperty)
    void SET_MinimumLedgeHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x28, Type: StructProperty)
    void SET_MinimumLedgeHeightWater(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x28, Type: StructProperty)
    void SET_FallingSpeedThreshold(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x28, Type: StructProperty)
    void SET_MinimumLedgeFallingHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_MinimumLedgeFallingWaterHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    void SET_ForwardSphereCastRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x28, Type: StructProperty)
    void SET_DownwardSphereCastRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x28, Type: StructProperty)
    void SET_AllowNonWalkableSurfaces(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x28, Type: StructProperty)
    void SET_TargetValidationEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_TargetValidationCapsuleRadiusModifier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_TargetValidationCapsuleHalfHeightModifier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    void SET_TargetValidationCapsuleBottomVerticalOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    void SET_FutureLedgeLaunchMaxVerticalDetectionRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x28, Type: StructProperty)
    void SET_FutureLedgeLaunchMaxHorizontalDetectionRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x28, Type: StructProperty)
    void SET_LedgeExtentThresholdToUseMidpointTargeting(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x28, Type: StructProperty)
    void SET_FloorCheckCastWallOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x28, Type: StructProperty)
    void SET_FloorCheckDownDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x28, Type: StructProperty)
    void SET_FloorCheckMaxAllowedAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x28, Type: StructProperty)
    void SET_WindowTargetingHorizontalSweepBreadth(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x28, Type: StructProperty)
    void SET_WindowTargetingHorizontalSweepHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x28, Type: StructProperty)
    void SET_WindowTargetingHorizontalOpeningSweepBreadth(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x28, Type: StructProperty)
    void SET_WindowTargetingVerticalOffsetCheckInWindowFrame(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x28, Type: StructProperty)
    void SET_ClamberScoringModifier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x28, Type: StructProperty)
    void SET_ClamberLedgeLaunchScoringModifier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x28, Type: StructProperty)
    void SET_UseMultiSweepCheckForSurfaces(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x28, Type: StructProperty)
    void SET_UseReachBackClamber(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x28, Type: StructProperty)
    void SET_ReachBackDistanceSweep(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x28, Type: StructProperty)
    void SET_MantleHeightCheckCastWallOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x28, Type: StructProperty)
    void SET_MantleHeightCapsuleRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x28, Type: StructProperty)
    void SET_MantleHeightMaxHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x6c
struct FClamberingInputConfig_CachedValues
{
public:
};

// Size: 0x9c
struct FClamberingTargetingConfig_Ledge_CachedContextualValues
{
public:
};

// Size: 0x28
struct FClamberingTargetingDebugDrawData
{
public:
};

// Size: 0x70
struct FClamberingTargetingDebugDrawData_Box : public FClamberingTargetingDebugDrawData
{
public:
};

// Size: 0x50
struct FClamberingTargetingDebugDrawData_Capsule : public FClamberingTargetingDebugDrawData
{
public:
};

// Size: 0x40
struct FClamberingTargetingDebugDrawData_Line : public FClamberingTargetingDebugDrawData
{
public:
};

// Size: 0x30
struct FClamberingTargetingDebugDrawData_Sphere : public FClamberingTargetingDebugDrawData
{
public:
};

// Size: 0x48
struct FClamberingTargetingDebugDrawData_DirectionalArrow : public FClamberingTargetingDebugDrawData
{
public:
};

// Size: 0x70
struct FClamberingTargetingDebugDrawData_CapsuleCast : public FClamberingTargetingDebugDrawData_Capsule
{
public:
};

// Size: 0x48
struct FClamberingTargetingDebugDrawData_SphereCast : public FClamberingTargetingDebugDrawData_Sphere
{
public:
};

// Size: 0x1
struct FClamberingTargetingDebugData
{
public:
};

// Size: 0x1
struct FClamberingTargetingDebugData_Ledge : public FClamberingTargetingDebugData
{
public:
};

// Size: 0x130
struct FClamberingTargetingData : public FContextualTraversalTargetingData
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)
    bool bValid() const { return (Read<uint8_t>(uintptr_t(this) + 0x49) >> 0x0) & 1; } // 0x49:0 (Size: 0x1, Type: BoolProperty)
    bool bCanStandOnLedge() const { return (Read<uint8_t>(uintptr_t(this) + 0x49) >> 0x1) & 1; } // 0x49:1 (Size: 0x1, Type: BoolProperty)
    bool bIsWindow() const { return (Read<uint8_t>(uintptr_t(this) + 0x49) >> 0x2) & 1; } // 0x49:2 (Size: 0x1, Type: BoolProperty)
    AActor* SourceActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    FVector SourceLocation() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FVector SourceAim() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FVector WallLocation() const { return Read<FVector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FVector WallNormal() const { return Read<FVector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    FVector TargetNormal() const { return Read<FVector>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* TargetActorComponent() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    FVector TargetActorComponentLocation() const { return Read<FVector>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x18, Type: StructProperty)
    FName TargetActorBoneName() const { return Read<FName>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: NameProperty)
    TArray<FVector> NextLedgeLaunchWarpPoints() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    bool bIsReachBack() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)
    float DistanceToGround() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
    void SET_bValid(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x49); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x49, B); } // 0x49:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCanStandOnLedge(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x49); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x49, B); } // 0x49:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsWindow(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x49); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x49, B); } // 0x49:2 (Size: 0x1, Type: BoolProperty)
    void SET_SourceActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_SourceLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_SourceAim(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_WallLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_WallNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
    void SET_TargetLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_TargetNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActorComponent(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActorComponentLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x18, Type: StructProperty)
    void SET_TargetActorBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: NameProperty)
    void SET_NextLedgeLaunchWarpPoints(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsReachBack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
    void SET_DistanceToGround(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
struct FReplicatedClamberingTargetingData
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FVector_NetQuantize10 SourceLocation() const { return Read<FVector_NetQuantize10>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize100 WallLocation() const { return Read<FVector_NetQuantize100>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint16_t WallNormalYawQuantized() const { return Read<uint16_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x2, Type: UInt16Property)
    uint16_t WallNormalPitchQuantized() const { return Read<uint16_t>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x2, Type: UInt16Property)
    FVector_NetQuantize100 TargetLocation() const { return Read<FVector_NetQuantize100>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    uint16_t TargetNormalYawQuantized() const { return Read<uint16_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x2, Type: UInt16Property)
    uint16_t TargetNormalPitchQuantized() const { return Read<uint16_t>(uintptr_t(this) + 0x5a); } // 0x5a (Size: 0x2, Type: UInt16Property)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* TargetActorComponent() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FName TargetActorBoneName() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_SourceLocation(const FVector_NetQuantize10& Value) { Write<FVector_NetQuantize10>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_WallLocation(const FVector_NetQuantize100& Value) { Write<FVector_NetQuantize100>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_WallNormalYawQuantized(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x2, Type: UInt16Property)
    void SET_WallNormalPitchQuantized(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x2, Type: UInt16Property)
    void SET_TargetLocation(const FVector_NetQuantize100& Value) { Write<FVector_NetQuantize100>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_TargetNormalYawQuantized(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x2, Type: UInt16Property)
    void SET_TargetNormalPitchQuantized(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x5a, Value); } // 0x5a (Size: 0x2, Type: UInt16Property)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActorComponent(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActorBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
};

// Size: 0x38
struct FReplicatedClamberingTargetingData_SimClient
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint16_t WallNormalYawQuantized() const { return Read<uint16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: UInt16Property)
    FVector_NetQuantize100 TargetLocation() const { return Read<FVector_NetQuantize100>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* TargetActorComponent() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FName TargetActorBoneName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_WallNormalYawQuantized(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: UInt16Property)
    void SET_TargetLocation(const FVector_NetQuantize100& Value) { Write<FVector_NetQuantize100>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActorComponent(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActorBoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
};

// Size: 0x50
struct FClamberingMovementConfig_Ledge
{
public:
    FScalableFloat duration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BlockCheckTickRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)

    void SET_duration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_BlockCheckTickRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FClamberingAnalytics_ClamberEvent
{
public:
    int32_t MatchTime() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t ClamberType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    FVector ClamberLocation() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t FailureReason() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_MatchTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_ClamberType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_ClamberLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_FailureReason(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FClamberingAnimationEntry : public FTableRowBase
{
public:
    UAnimMontage* Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float MinClamberHeight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bLedgeLaunch() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_MinClamberHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_bLedgeLaunch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

