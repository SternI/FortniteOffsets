/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeEditCameraModeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x548
class AFortCreativeEditCameraController : public AFortFirstPersonCameraController
{
public:
    FCreativeOptionVariableBase WantsToImmersiveEdit() const { return Read<FCreativeOptionVariableBase>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: StructProperty)

    void SET_WantsToImmersiveEdit(const FCreativeOptionVariableBase& Value) { Write<FCreativeOptionVariableBase>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: StructProperty)
};

