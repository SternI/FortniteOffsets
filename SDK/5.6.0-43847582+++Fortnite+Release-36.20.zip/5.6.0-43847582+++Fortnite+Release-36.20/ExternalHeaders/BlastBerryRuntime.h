/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlastBerryRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "AIModule.h"
#include "GameplayAbilities.h"
#include "SlateCore.h"

// Size: 0x168
class UFortControllerComponent_BlastBerry : public UFortControllerComponent
{
public:
    bool bLastTeamMemberAlive() const { return Read<bool>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: BoolProperty)

    void SET_bLastTeamMemberAlive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x270
class UFortControllerComponent_BlastBerryUI : public UFortControllerComponent
{
public:
    FScalableFloat DeathLocationIndicatorDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FSlateBrush DeathLocationIndicatorIconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0xb0, Type: StructProperty)
    FSlateBrush DeathLocationIndicatorClampedIconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0xb0, Type: StructProperty)

    void SET_DeathLocationIndicatorDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_DeathLocationIndicatorIconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0xb0, Type: StructProperty)
    void SET_DeathLocationIndicatorClampedIconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x38
class UBlastBerryVerseRespawnLogic : public UObject
{
public:
};

// Size: 0x4e0
class AFortAthenaMutator_BlastBerry : public AFortAthenaMutator_GameModeBase
{
public:
    FScalableFloat DBNOReviveTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x28, Type: StructProperty)

    void SET_DBNOReviveTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UFortCheatManager_BlastBerry : public UChildCheatManager
{
public:
};

// Size: 0x640
class UFortGameStateComponent_BlastBerryManager : public UFortGameStateComponent
{
public:
    float ServerTimeForRespawnsDisabled() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    TArray<AFortPlayerStateAthena*> RespawnPendingPlayerStates() const { return Read<TArray<AFortPlayerStateAthena*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    uint8_t CurrentGamePhaseStep() const { return Read<uint8_t>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: EnumProperty)
    int32_t CurrentSafeZonePhaseIndex() const { return Read<int32_t>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: IntProperty)
    FScalableFloat MaxTeamLives() const { return Read<FScalableFloat>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x28, Type: StructProperty)
    FScalableFloat TeamLivesRechargeDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnCameraDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseAdvancedSpawnBehavior() const { return Read<FScalableFloat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseSoloSpawnEQS() const { return Read<FScalableFloat>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x28, Type: StructProperty)
    FScalableFloat SoloDisableEQSRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FScalableFloat SoloSpawnMaxDistanceFromDeathLocation() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AdvancedSpawnSafeZonePredictionTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AdvancedSpawnSafeZoneRadiusBuffer() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AdvancedSpawnGroupProximityDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x28, Type: StructProperty)
    FScalableFloat WaveRespawnEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x28, Type: StructProperty)
    FScalableFloat WaveRespawnDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x28, Type: StructProperty)
    FScalableFloat IndividualRespawnDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnDownedTimeReward() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnEliminationTimeReward() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnTeamWipeTimeReward() const { return Read<FScalableFloat>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x28, Type: StructProperty)
    UEnvQuery* SoloRespawnLocationQueryTemplate() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: ObjectProperty)
    TArray<FBlastBerryTeamLives> TeamLives() const { return Read<TArray<FBlastBerryTeamLives>>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x10, Type: ArrayProperty)
    TArray<FBlastBerryTeamLives> PreviousTeamLives() const { return Read<TArray<FBlastBerryTeamLives>>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    TMap<AFortPlayerStateAthena*, FTimerHandle> ActiveViewTargetValidationTimersMap() const { return Read<TMap<AFortPlayerStateAthena*, FTimerHandle>>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x50, Type: MapProperty)
    TMap<AFortPlayerStateAthena*, FBlastBerrySoloRespawnData> SoloRespawnDataMap() const { return Read<TMap<AFortPlayerStateAthena*, FBlastBerrySoloRespawnData>>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x50, Type: MapProperty)
    UBlastBerryVerseRespawnLogic* RespawnLogicScript() const { return Read<UBlastBerryVerseRespawnLogic*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)

    void SET_ServerTimeForRespawnsDisabled(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_RespawnPendingPlayerStates(const TArray<AFortPlayerStateAthena*>& Value) { Write<TArray<AFortPlayerStateAthena*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentGamePhaseStep(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: EnumProperty)
    void SET_CurrentSafeZonePhaseIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: IntProperty)
    void SET_MaxTeamLives(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x28, Type: StructProperty)
    void SET_TeamLivesRechargeDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x28, Type: StructProperty)
    void SET_RespawnHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_RespawnRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    void SET_RespawnCameraDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x28, Type: StructProperty)
    void SET_UseAdvancedSpawnBehavior(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x28, Type: StructProperty)
    void SET_UseSoloSpawnEQS(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x28, Type: StructProperty)
    void SET_SoloDisableEQSRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_SoloSpawnMaxDistanceFromDeathLocation(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_AdvancedSpawnSafeZonePredictionTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    void SET_AdvancedSpawnSafeZoneRadiusBuffer(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    void SET_AdvancedSpawnGroupProximityDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x28, Type: StructProperty)
    void SET_WaveRespawnEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x28, Type: StructProperty)
    void SET_WaveRespawnDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x28, Type: StructProperty)
    void SET_IndividualRespawnDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x28, Type: StructProperty)
    void SET_RespawnDownedTimeReward(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x28, Type: StructProperty)
    void SET_RespawnEliminationTimeReward(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x28, Type: StructProperty)
    void SET_RespawnTeamWipeTimeReward(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x28, Type: StructProperty)
    void SET_SoloRespawnLocationQueryTemplate(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamLives(const TArray<FBlastBerryTeamLives>& Value) { Write<TArray<FBlastBerryTeamLives>>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviousTeamLives(const TArray<FBlastBerryTeamLives>& Value) { Write<TArray<FBlastBerryTeamLives>>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveViewTargetValidationTimersMap(const TMap<AFortPlayerStateAthena*, FTimerHandle>& Value) { Write<TMap<AFortPlayerStateAthena*, FTimerHandle>>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x50, Type: MapProperty)
    void SET_SoloRespawnDataMap(const TMap<AFortPlayerStateAthena*, FBlastBerrySoloRespawnData>& Value) { Write<TMap<AFortPlayerStateAthena*, FBlastBerrySoloRespawnData>>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x50, Type: MapProperty)
    void SET_RespawnLogicScript(const UBlastBerryVerseRespawnLogic*& Value) { Write<UBlastBerryVerseRespawnLogic*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UFortQueryContext_BlastBerryAllEnemies : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_BlastBerryDeathLocation : public UEnvQueryContext
{
public:
};

// Size: 0x28
class UFortQueryContext_BlastBerryDefaultSpawnLocation : public UEnvQueryContext
{
public:
};

// Size: 0x98
class UBlastBerryObjectiveProcessor_PlayerRespawned : public UFortObjectiveProcessor
{
public:
};

// Size: 0x98
class UBlastBerryObjectiveProcessor_RespawnsDisabled : public UFortObjectiveProcessor
{
public:
};

// Size: 0x98
class UBlastBerryObjectiveProcessor_TeamEliminated : public UFortObjectiveProcessor
{
public:
};

// Size: 0x80
struct FBlastBerryVerbMessage_PlayerRespawned : public FVerbMessage
{
public:
    int32_t TeamLivesRemaining() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)

    void SET_TeamLivesRemaining(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
struct FBlastBerryVerbMessage_RespawnsDisabled : public FVerbMessage
{
public:
    int32_t TeamLivesRemaining() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)

    void SET_TeamLivesRemaining(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
};

// Size: 0xf0
struct FBlastBerryVerbMessage_TeamEliminated : public FVerbMessage
{
public:
    FSubjectTagsPair EliminatedPlayer() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair DamageType() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x38, Type: StructProperty)
    bool bWasAuthorKiller() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)

    void SET_EliminatedPlayer(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x38, Type: StructProperty)
    void SET_DamageType(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x38, Type: StructProperty)
    void SET_bWasAuthorKiller(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FBlastBerryTeamLives
{
public:
    char TeamID() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    int8_t TeamLivesUsed() const { return Read<int8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: Int8Property)
    float ServerTimeForRecharge() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_TeamID(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_TeamLivesUsed(const int8_t& Value) { Write<int8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: Int8Property)
    void SET_ServerTimeForRecharge(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FBlastBerrySoloRespawnData
{
public:
};

// Size: 0xb0
struct FBlastBerryObjectiveFilter_PlayerRespawned : public FObjectiveFilter
{
public:
    FInt32Range TeamLivesRemaining() const { return Read<FInt32Range>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)

    void SET_TeamLivesRemaining(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
};

// Size: 0xb0
struct FBlastBerryObjectiveFilter_RespawnsDisabled : public FObjectiveFilter
{
public:
    FInt32Range TeamLivesRemaining() const { return Read<FInt32Range>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)

    void SET_TeamLivesRemaining(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x138
struct FBlastBerryObjectiveFilter_TeamEliminated : public FObjectiveFilter
{
public:
    FObjectiveSubjectTags EliminatedPlayer() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags DamageType() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x48, Type: StructProperty)
    uint8_t KillerHandling() const { return Read<uint8_t>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: EnumProperty)

    void SET_EliminatedPlayer(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x48, Type: StructProperty)
    void SET_DamageType(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x48, Type: StructProperty)
    void SET_KillerHandling(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: EnumProperty)
};

