/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: F5PlayerFactory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UF5PlayerFactorySettings : public UObject
{
public:
};

