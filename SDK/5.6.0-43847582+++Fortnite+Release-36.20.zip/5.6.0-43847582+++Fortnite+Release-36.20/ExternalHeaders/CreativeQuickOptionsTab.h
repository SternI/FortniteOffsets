/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeQuickOptionsTab
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"

// Size: 0x5d0
class UFortCreativeQuickOptionsTab : public UCommonActivatableWidget
{
public:
    FAthenaMapScreenContainerTabInfo MapScreenContainerTabInfo() const { return Read<FAthenaMapScreenContainerTabInfo>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x40, Type: StructProperty)
    FName QuickOptionsTabNameId() const { return Read<FName>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x4, Type: NameProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo() const { return Read<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0xf0, Type: StructProperty)
    bool bIsDefaultActiveTab() const { return Read<bool>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x1, Type: BoolProperty)

    void SET_MapScreenContainerTabInfo(const FAthenaMapScreenContainerTabInfo& Value) { Write<FAthenaMapScreenContainerTabInfo>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x40, Type: StructProperty)
    void SET_QuickOptionsTabNameId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x4, Type: NameProperty)
    void SET_TabButtonLabelInfo(const FFortTabButtonLabelInfo& Value) { Write<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0xf0, Type: StructProperty)
    void SET_bIsDefaultActiveTab(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x1, Type: BoolProperty)
};

