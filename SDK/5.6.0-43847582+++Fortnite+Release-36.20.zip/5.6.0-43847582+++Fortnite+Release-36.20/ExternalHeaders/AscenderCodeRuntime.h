/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AscenderCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteAI.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x28
class UFortCheatManager_AscenderZipline : public UChildCheatManager
{
public:
};

// Size: 0xd8
class UFortPawnComponent_AscenderMontageProvider : public UPawnComponent
{
public:
    UAnimMontage* M_Ascending() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* M_Descending() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* F_Ascending() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* F_Descending() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_M_Ascending(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_M_Descending(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_F_Ascending(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_F_Descending(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1038
class AFortAscenderZipline : public AFortAthenaSplineZipline
{
public:
    FName SplineTopAttachPointName() const { return Read<FName>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x4, Type: NameProperty)
    bool bAutoFindSplineEndLocation() const { return Read<bool>(uintptr_t(this) + 0xcec); } // 0xcec (Size: 0x1, Type: BoolProperty)
    float SplineOffsetFromGround() const { return Read<float>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x4, Type: FloatProperty)
    float CableOffsetFromSplineEnd() const { return Read<float>(uintptr_t(this) + 0xcf4); } // 0xcf4 (Size: 0x4, Type: FloatProperty)
    float SplineLength() const { return Read<float>(uintptr_t(this) + 0xcf8); } // 0xcf8 (Size: 0x4, Type: FloatProperty)
    UStaticMesh* SplineStaticMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ESplineMeshAxis> MeshForwardAxis() const { return Read<TEnumAsByte<ESplineMeshAxis>>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x1, Type: ByteProperty)
    bool bHandleReturning() const { return Read<bool>(uintptr_t(this) + 0xd09); } // 0xd09 (Size: 0x1, Type: BoolProperty)
    float HandleReturnSpeed() const { return Read<float>(uintptr_t(this) + 0xd0c); } // 0xd0c (Size: 0x4, Type: FloatProperty)
    bool bCableDropping() const { return Read<bool>(uintptr_t(this) + 0xd10); } // 0xd10 (Size: 0x1, Type: BoolProperty)
    float CableDropSpeed() const { return Read<float>(uintptr_t(this) + 0xd14); } // 0xd14 (Size: 0x4, Type: FloatProperty)
    float YawRotationOffsetWhileUsingHandle() const { return Read<float>(uintptr_t(this) + 0xd18); } // 0xd18 (Size: 0x4, Type: FloatProperty)
    float YawRotationOffsetWhileSlidingDown() const { return Read<float>(uintptr_t(this) + 0xd1c); } // 0xd1c (Size: 0x4, Type: FloatProperty)
    bool bUseComplexSplineCollision() const { return Read<bool>(uintptr_t(this) + 0xd20); } // 0xd20 (Size: 0x1, Type: BoolProperty)
    float SimpleSplineCollisionRadius() const { return Read<float>(uintptr_t(this) + 0xd24); } // 0xd24 (Size: 0x4, Type: FloatProperty)
    float SimpleSplineCollisionHeightExtension() const { return Read<float>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x4, Type: FloatProperty)
    FScalableFloat DescendMinDistanceFromBottom() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendReachedEndHorizontalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendReachedEndVerticalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendJumpedOffHorizontalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendJumpedOffVerticalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdd0); } // 0xdd0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendReachedEndHorizontalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdf8); } // 0xdf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendReachedEndVerticalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe20); } // 0xe20 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendJumpedOffHorizontalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe48); } // 0xe48 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendJumpedOffVerticalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe70); } // 0xe70 (Size: 0x28, Type: StructProperty)
    FScalableFloat HandleActorHitPlayerHorizontalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe98); } // 0xe98 (Size: 0x28, Type: StructProperty)
    FScalableFloat HandleActorHitPlayerVerticalLaunchSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x28, Type: StructProperty)
    FVector HandleDestroyBuildingsOverlapExtents() const { return Read<FVector>(uintptr_t(this) + 0xee8); } // 0xee8 (Size: 0x18, Type: StructProperty)
    FVector PlayerDestroyBuildingsOverlapExtents() const { return Read<FVector>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x18, Type: StructProperty)
    FVector InitialSplineEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xf18); } // 0xf18 (Size: 0x18, Type: StructProperty)
    FVector CurrentSplineEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xf30); } // 0xf30 (Size: 0x18, Type: StructProperty)
    FVector TargetSplineEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xf48); } // 0xf48 (Size: 0x18, Type: StructProperty)
    FVector CurrentHandleLocation() const { return Read<FVector>(uintptr_t(this) + 0xf60); } // 0xf60 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UPrimitiveComponent*> CurrentInteractComponent() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0xf78); } // 0xf78 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> PawnUsingHandle() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xf80); } // 0xf80 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> PreviousPawnUsingHandle() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xf88); } // 0xf88 (Size: 0x8, Type: WeakObjectProperty)
    USplineMeshComponent* SplineMesh() const { return Read<USplineMeshComponent*>(uintptr_t(this) + 0xf90); } // 0xf90 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* SimpleSplineMeshCollision() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0xf98); } // 0xf98 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ABuildingActor*> FloorActor() const { return Read<TWeakObjectPtr<ABuildingActor*>>(uintptr_t(this) + 0xfa0); } // 0xfa0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AFortPlayerPawn*>> RotationLockedPawns() const { return Read<TArray<TWeakObjectPtr<AFortPlayerPawn*>>>(uintptr_t(this) + 0xfa8); } // 0xfa8 (Size: 0x10, Type: ArrayProperty)
    UFortLinkToActorComponent* LinkToActorComponent() const { return Read<UFortLinkToActorComponent*>(uintptr_t(this) + 0x1028); } // 0x1028 (Size: 0x8, Type: ObjectProperty)
    UFortZiplineLinkComponent* ZiplineLinkComponent() const { return Read<UFortZiplineLinkComponent*>(uintptr_t(this) + 0x1030); } // 0x1030 (Size: 0x8, Type: ObjectProperty)

    void SET_SplineTopAttachPointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x4, Type: NameProperty)
    void SET_bAutoFindSplineEndLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcec, Value); } // 0xcec (Size: 0x1, Type: BoolProperty)
    void SET_SplineOffsetFromGround(const float& Value) { Write<float>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x4, Type: FloatProperty)
    void SET_CableOffsetFromSplineEnd(const float& Value) { Write<float>(uintptr_t(this) + 0xcf4, Value); } // 0xcf4 (Size: 0x4, Type: FloatProperty)
    void SET_SplineLength(const float& Value) { Write<float>(uintptr_t(this) + 0xcf8, Value); } // 0xcf8 (Size: 0x4, Type: FloatProperty)
    void SET_SplineStaticMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x8, Type: ObjectProperty)
    void SET_MeshForwardAxis(const TEnumAsByte<ESplineMeshAxis>& Value) { Write<TEnumAsByte<ESplineMeshAxis>>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x1, Type: ByteProperty)
    void SET_bHandleReturning(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd09, Value); } // 0xd09 (Size: 0x1, Type: BoolProperty)
    void SET_HandleReturnSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xd0c, Value); } // 0xd0c (Size: 0x4, Type: FloatProperty)
    void SET_bCableDropping(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd10, Value); } // 0xd10 (Size: 0x1, Type: BoolProperty)
    void SET_CableDropSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xd14, Value); } // 0xd14 (Size: 0x4, Type: FloatProperty)
    void SET_YawRotationOffsetWhileUsingHandle(const float& Value) { Write<float>(uintptr_t(this) + 0xd18, Value); } // 0xd18 (Size: 0x4, Type: FloatProperty)
    void SET_YawRotationOffsetWhileSlidingDown(const float& Value) { Write<float>(uintptr_t(this) + 0xd1c, Value); } // 0xd1c (Size: 0x4, Type: FloatProperty)
    void SET_bUseComplexSplineCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd20, Value); } // 0xd20 (Size: 0x1, Type: BoolProperty)
    void SET_SimpleSplineCollisionRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xd24, Value); } // 0xd24 (Size: 0x4, Type: FloatProperty)
    void SET_SimpleSplineCollisionHeightExtension(const float& Value) { Write<float>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x4, Type: FloatProperty)
    void SET_DescendMinDistanceFromBottom(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x28, Type: StructProperty)
    void SET_AscendReachedEndHorizontalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x28, Type: StructProperty)
    void SET_AscendReachedEndVerticalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x28, Type: StructProperty)
    void SET_AscendJumpedOffHorizontalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x28, Type: StructProperty)
    void SET_AscendJumpedOffVerticalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdd0, Value); } // 0xdd0 (Size: 0x28, Type: StructProperty)
    void SET_DescendReachedEndHorizontalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdf8, Value); } // 0xdf8 (Size: 0x28, Type: StructProperty)
    void SET_DescendReachedEndVerticalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe20, Value); } // 0xe20 (Size: 0x28, Type: StructProperty)
    void SET_DescendJumpedOffHorizontalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe48, Value); } // 0xe48 (Size: 0x28, Type: StructProperty)
    void SET_DescendJumpedOffVerticalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe70, Value); } // 0xe70 (Size: 0x28, Type: StructProperty)
    void SET_HandleActorHitPlayerHorizontalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe98, Value); } // 0xe98 (Size: 0x28, Type: StructProperty)
    void SET_HandleActorHitPlayerVerticalLaunchSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x28, Type: StructProperty)
    void SET_HandleDestroyBuildingsOverlapExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xee8, Value); } // 0xee8 (Size: 0x18, Type: StructProperty)
    void SET_PlayerDestroyBuildingsOverlapExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x18, Type: StructProperty)
    void SET_InitialSplineEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf18, Value); } // 0xf18 (Size: 0x18, Type: StructProperty)
    void SET_CurrentSplineEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf30, Value); } // 0xf30 (Size: 0x18, Type: StructProperty)
    void SET_TargetSplineEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf48, Value); } // 0xf48 (Size: 0x18, Type: StructProperty)
    void SET_CurrentHandleLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf60, Value); } // 0xf60 (Size: 0x18, Type: StructProperty)
    void SET_CurrentInteractComponent(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0xf78, Value); } // 0xf78 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PawnUsingHandle(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xf80, Value); } // 0xf80 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PreviousPawnUsingHandle(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xf88, Value); } // 0xf88 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SplineMesh(const USplineMeshComponent*& Value) { Write<USplineMeshComponent*>(uintptr_t(this) + 0xf90, Value); } // 0xf90 (Size: 0x8, Type: ObjectProperty)
    void SET_SimpleSplineMeshCollision(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0xf98, Value); } // 0xf98 (Size: 0x8, Type: ObjectProperty)
    void SET_FloorActor(const TWeakObjectPtr<ABuildingActor*>& Value) { Write<TWeakObjectPtr<ABuildingActor*>>(uintptr_t(this) + 0xfa0, Value); } // 0xfa0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RotationLockedPawns(const TArray<TWeakObjectPtr<AFortPlayerPawn*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerPawn*>>>(uintptr_t(this) + 0xfa8, Value); } // 0xfa8 (Size: 0x10, Type: ArrayProperty)
    void SET_LinkToActorComponent(const UFortLinkToActorComponent*& Value) { Write<UFortLinkToActorComponent*>(uintptr_t(this) + 0x1028, Value); } // 0x1028 (Size: 0x8, Type: ObjectProperty)
    void SET_ZiplineLinkComponent(const UFortZiplineLinkComponent*& Value) { Write<UFortZiplineLinkComponent*>(uintptr_t(this) + 0x1030, Value); } // 0x1030 (Size: 0x8, Type: ObjectProperty)
};

