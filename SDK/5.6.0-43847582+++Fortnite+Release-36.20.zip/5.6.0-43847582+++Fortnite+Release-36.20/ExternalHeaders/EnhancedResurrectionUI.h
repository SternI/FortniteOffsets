/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EnhancedResurrectionUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x360
class UEnhancedResurrectionSelectWidget : public UFortHUDElementWidget
{
public:
};

