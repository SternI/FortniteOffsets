/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Basic
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x4
struct FName
{
public:
    int32_t ComparisonIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_ComparisonIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
template <class ElementType>
struct TArray
{
public:
    ElementType* Data() const { return Read<ElementType*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t Count() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Max() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_Data(const ElementType*& Value) { Write<ElementType*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Count(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Max(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x50
template<typename ElementType>
struct TSet
{
public:
    TArray<ElementType> SparseArray() const { return Read<TArray<ElementType>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_SparseArray(const TArray<ElementType>& Value) { Write<TArray<ElementType>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
template<typename KeyType, typename ValueType>
struct TMap
{
public:
    TSet<std::pair<KeyType, ValueType>> Pairs() const { return Read<TSet<std::pair<KeyType, ValueType>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: SetProperty)

    void SET_Pairs(const TSet<std::pair<KeyType, ValueType>>& Value) { Write<TSet<std::pair<KeyType, ValueType>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: SetProperty)
};

// Size: 0x10
struct FString : public TArray<wchar_t>
{
};

// Size: 0x1
template<typename T>
class TEnumAsByte
{
public:
    uint8_t Value() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: Int8Property)

    void SET_Value(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: Int8Property)
};

// Size: 0x8
struct FWeakObjectPtr
{
public:
    int32_t ObjectIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ObjectSerialNumber() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_ObjectIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_ObjectSerialNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
template<typename T>
struct TWeakObjectPtr
{
public:
};

// Size: 0x8 + sizeof(T)
template<typename T>
struct TPersistentObjectPtr
{
public:
    FWeakObjectPtr WeakPtr() const { return Read<FWeakObjectPtr>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    T ObjectID() const { return Read<T>(uintptr_t(this) + 0x8); } // 0x8 (Size: sizeof(T), Type: ObjectProperty)

    void SET_WeakPtr(const FWeakObjectPtr& Value) { Write<FWeakObjectPtr>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ObjectID(const T& Value) { Write<T>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: sizeof(T), Type: ObjectProperty)
};

// Size: 0x10
struct FUniqueObjectGuid
{
public:
    uint32_t A() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t B() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t C() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t D() const { return Read<uint32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: UInt32Property)

    void SET_A(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_B(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_C(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
    void SET_D(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: UInt32Property)
};

// Size: 0x14
struct FLazyObjectPtr : public TPersistentObjectPtr<FUniqueObjectGuid>
{
public:
};

// Size: 0x14
class UObject;

template<class T=UObject>
struct TLazyObjectPtr
{
public:
};

// Size: 0x0
class NoClassFunctions
{
public:
};

