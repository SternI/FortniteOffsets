/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_HUDControllerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DynamicUI.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"

// Size: 0x348
class UHUDControllerContainerBase : public UUserWidget
{
public:
    UClass* SlotViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ClassProperty)
    TArray<UUserWidget*> SlotContentWidgets() const { return Read<TArray<UUserWidget*>>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    TArray<UMVVMViewModelBase*> SlotViewModels() const { return Read<TArray<UMVVMViewModelBase*>>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x10, Type: ArrayProperty)

    void SET_SlotViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ClassProperty)
    void SET_SlotContentWidgets(const TArray<UUserWidget*>& Value) { Write<TArray<UUserWidget*>>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    void SET_SlotViewModels(const TArray<UMVVMViewModelBase*>& Value) { Write<TArray<UMVVMViewModelBase*>>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2f0
class AHUDControllerDynamicUIDirector : public ADynamicUIDirectorBase
{
public:
    UDynamicUIScene* PlayerInfoWidgetOverrideScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* QuickbarWidgetOverrideScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* EquippedItemWidgetOverrideScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicUIScene*> AddedScenes() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)

    void SET_PlayerInfoWidgetOverrideScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_QuickbarWidgetOverrideScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_EquippedItemWidgetOverrideScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_AddedScenes(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x338
class UHUDControllerWidgetBase : public UUserWidget
{
public:
    UClass* ViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ClassProperty)
    UUserWidget* ContentWidget() const { return Read<UUserWidget*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    UMVVMViewModelBase* ViewModel() const { return Read<UMVVMViewModelBase*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)

    void SET_ViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ClassProperty)
    void SET_ContentWidget(const UUserWidget*& Value) { Write<UUserWidget*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewModel(const UMVVMViewModelBase*& Value) { Write<UMVVMViewModelBase*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
};

