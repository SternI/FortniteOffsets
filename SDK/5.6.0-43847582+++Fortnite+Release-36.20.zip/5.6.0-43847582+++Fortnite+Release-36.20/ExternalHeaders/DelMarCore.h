/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteAI.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "EnhancedInput.h"
#include "LinkId.h"
#include "CosmeticsFrameworkLoadouts.h"
#include "DelMarTrackRuntime.h"
#include "AIModule.h"
#include "Niagara.h"
#include "VehicleCosmeticsRuntime.h"
#include "GameplayAbilities.h"
#include "PhysicsCore.h"
#include "DelMarSettings.h"
#include "GameplayEventRouter.h"

// Size: 0x110
class UDelMarPlayerPreferencesComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t InvertSteerMethod() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    bool bPitchInverted() const { return Read<bool>(uintptr_t(this) + 0xe9); } // 0xe9 (Size: 0x1, Type: BoolProperty)
    bool bVerticalKickflipInverted() const { return Read<bool>(uintptr_t(this) + 0xea); } // 0xea (Size: 0x1, Type: BoolProperty)
    bool bAerialPitchActivationEnabled() const { return Read<bool>(uintptr_t(this) + 0xeb); } // 0xeb (Size: 0x1, Type: BoolProperty)
    bool bUseToggleOnExpandableHudWidget() const { return Read<bool>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x1, Type: BoolProperty)
    bool bUseIconOnlyPlayerNameplates() const { return Read<bool>(uintptr_t(this) + 0xed); } // 0xed (Size: 0x1, Type: BoolProperty)
    FGameplayTag TouchControlsLayout() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortClientSettingsRecord*> FortSettings() const { return Read<TWeakObjectPtr<UFortClientSettingsRecord*>>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x8, Type: WeakObjectProperty)

    void SET_InvertSteerMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    void SET_bPitchInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe9, Value); } // 0xe9 (Size: 0x1, Type: BoolProperty)
    void SET_bVerticalKickflipInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0xea, Value); } // 0xea (Size: 0x1, Type: BoolProperty)
    void SET_bAerialPitchActivationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xeb, Value); } // 0xeb (Size: 0x1, Type: BoolProperty)
    void SET_bUseToggleOnExpandableHudWidget(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x1, Type: BoolProperty)
    void SET_bUseIconOnlyPlayerNameplates(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed, Value); } // 0xed (Size: 0x1, Type: BoolProperty)
    void SET_TouchControlsLayout(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: StructProperty)
    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FortSettings(const TWeakObjectPtr<UFortClientSettingsRecord*>& Value) { Write<TWeakObjectPtr<UFortClientSettingsRecord*>>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xb8
class UDelMarPlayerStateComponent : public UPlayerStateComponent
{
public:
};

// Size: 0x4e0
class ADelMarRaceManager : public AActor
{
public:
    bool bRaceStarted() const { return Read<bool>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    bool bRaceFinished() const { return Read<bool>(uintptr_t(this) + 0x3c1); } // 0x3c1 (Size: 0x1, Type: BoolProperty)
    TArray<AFortPlayerState*> SpectatorPlayerStates() const { return Read<TArray<AFortPlayerState*>>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x10, Type: ArrayProperty)
    TArray<AFortPlayerState*> ActiveRacerPlayerStates() const { return Read<TArray<AFortPlayerState*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    UDelMarRaceConfigComponent* RaceConfig() const { return Read<UDelMarRaceConfigComponent*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarRaceLevelConfig*> ActiveRaceLevelConfig() const { return Read<TWeakObjectPtr<ADelMarRaceLevelConfig*>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarTimeManagerComponent* TimeManager() const { return Read<UDelMarTimeManagerComponent*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UDelMarRespawnManagerComponent* RespawnManager() const { return Read<UDelMarRespawnManagerComponent*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    UDelMarCheckpointManagerComponent* CheckpointManager() const { return Read<UDelMarCheckpointManagerComponent*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    UDelMarRubberbandingManagerComponent* RubberbandingManager() const { return Read<UDelMarRubberbandingManagerComponent*>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    UDelMarGameplayModifierComponent* GameplayModifierComponent() const { return Read<UDelMarGameplayModifierComponent*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ObjectProperty)
    UDelMarPositionalTrackerComponent* PositionalTracker() const { return Read<UDelMarPositionalTrackerComponent*>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    UDelMarEliminationRaceManagerComponent* EliminationManager() const { return Read<UDelMarEliminationRaceManagerComponent*>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x8, Type: ObjectProperty)
    UDelMarGlobalInputDisabler* InputDisablerComponent() const { return Read<UDelMarGlobalInputDisabler*>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x8, Type: ObjectProperty)
    UDelMarMatchEventSystemComponent* MatchEventSystemComponent() const { return Read<UDelMarMatchEventSystemComponent*>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: ObjectProperty)
    TSet<AFortPlayerState*> ManagedPlayerStates() const { return Read<TSet<AFortPlayerState*>>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x50, Type: SetProperty)
    TSet<TWeakObjectPtr<AFortPlayerState*>> InactivePlayerStates() const { return Read<TSet<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x50, Type: SetProperty)

    void SET_bRaceStarted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    void SET_bRaceFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c1, Value); } // 0x3c1 (Size: 0x1, Type: BoolProperty)
    void SET_SpectatorPlayerStates(const TArray<AFortPlayerState*>& Value) { Write<TArray<AFortPlayerState*>>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveRacerPlayerStates(const TArray<AFortPlayerState*>& Value) { Write<TArray<AFortPlayerState*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    void SET_RaceConfig(const UDelMarRaceConfigComponent*& Value) { Write<UDelMarRaceConfigComponent*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveRaceLevelConfig(const TWeakObjectPtr<ADelMarRaceLevelConfig*>& Value) { Write<TWeakObjectPtr<ADelMarRaceLevelConfig*>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TimeManager(const UDelMarTimeManagerComponent*& Value) { Write<UDelMarTimeManagerComponent*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_RespawnManager(const UDelMarRespawnManagerComponent*& Value) { Write<UDelMarRespawnManagerComponent*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_CheckpointManager(const UDelMarCheckpointManagerComponent*& Value) { Write<UDelMarCheckpointManagerComponent*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_RubberbandingManager(const UDelMarRubberbandingManagerComponent*& Value) { Write<UDelMarRubberbandingManagerComponent*>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayModifierComponent(const UDelMarGameplayModifierComponent*& Value) { Write<UDelMarGameplayModifierComponent*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ObjectProperty)
    void SET_PositionalTracker(const UDelMarPositionalTrackerComponent*& Value) { Write<UDelMarPositionalTrackerComponent*>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    void SET_EliminationManager(const UDelMarEliminationRaceManagerComponent*& Value) { Write<UDelMarEliminationRaceManagerComponent*>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x8, Type: ObjectProperty)
    void SET_InputDisablerComponent(const UDelMarGlobalInputDisabler*& Value) { Write<UDelMarGlobalInputDisabler*>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x8, Type: ObjectProperty)
    void SET_MatchEventSystemComponent(const UDelMarMatchEventSystemComponent*& Value) { Write<UDelMarMatchEventSystemComponent*>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: ObjectProperty)
    void SET_ManagedPlayerStates(const TSet<AFortPlayerState*>& Value) { Write<TSet<AFortPlayerState*>>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x50, Type: SetProperty)
    void SET_InactivePlayerStates(const TSet<TWeakObjectPtr<AFortPlayerState*>>& Value) { Write<TSet<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x50, Type: SetProperty)
};

// Size: 0x1a8
class UDelMarVehicleManager : public UWorldSubsystem
{
public:
};

// Size: 0x138
class UDelMarPreRaceControllerComponent : public UControllerComponent
{
public:
    UInputAction* NavigateAction() const { return Read<UInputAction*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ReadyUpAction() const { return Read<UInputAction*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    FViewTargetTransitionParams ViewTargetTransitionParams() const { return Read<FViewTargetTransitionParams>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StructProperty)
    float NavigateInputDeadzone() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    UClass* InputManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UDelMarPlayerInputManagerComponent*> InputManager() const { return Read<TWeakObjectPtr<UDelMarPlayerInputManagerComponent*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent() const { return Read<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionTracker() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CurrentViewTarget() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    float CellDistThreshold() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float MaxGridDim() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    FTimerHandle NavigationTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: StructProperty)

    void SET_NavigateAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_ReadyUpAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewTargetTransitionParams(const FViewTargetTransitionParams& Value) { Write<FViewTargetTransitionParams>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StructProperty)
    void SET_NavigateInputDeadzone(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_InputManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ClassProperty)
    void SET_InputManager(const TWeakObjectPtr<UDelMarPlayerInputManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerInputManagerComponent*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    void SET_InputComponent(const TWeakObjectPtr<UEnhancedInputComponent*>& Value) { Write<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PositionTracker(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentViewTarget(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CellDistThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_MaxGridDim(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_NavigationTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: StructProperty)
};

// Size: 0x830
class ADelMarPlayspace : public AFortPlayspace
{
public:
    TWeakObjectPtr<UFortPlaylistAthena*> MRSPlaylistData() const { return Read<TWeakObjectPtr<UFortPlaylistAthena*>>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x8, Type: WeakObjectProperty)
    FString MRSLinkId() const { return Read<FString>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x10, Type: StrProperty)
    UDelMarGameStateMachine* PrimaryStateMachine() const { return Read<UDelMarGameStateMachine*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    bool bShouldShowLoadingScreen() const { return Read<bool>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x1, Type: BoolProperty)
    TMap<EDelMarRaceMode, TSoftClassPtr> DefaultRaceLevelConfigs() const { return Read<TMap<EDelMarRaceMode, TSoftClassPtr>>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x50, Type: MapProperty)
    TWeakObjectPtr<ADelMarRaceManager*> ActiveRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortPlaylistAthena*> PlaylistData() const { return Read<TWeakObjectPtr<UFortPlaylistAthena*>>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarLevelManagerComponent*> LevelManager() const { return Read<TWeakObjectPtr<UDelMarLevelManagerComponent*>>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x8, Type: WeakObjectProperty)
    UFortLevelStreamComponent* LevelStreamComponent() const { return Read<UFortLevelStreamComponent*>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayspaceComponent_ServerExpiration* ServerExpirationComponent() const { return Read<UDelMarPlayspaceComponent_ServerExpiration*>(uintptr_t(this) + 0x7d0); } // 0x7d0 (Size: 0x8, Type: ObjectProperty)
    FDelMarMapSet MapSet() const { return Read<FDelMarMapSet>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer PlaylistDefinedMapTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x7f0); } // 0x7f0 (Size: 0x20, Type: StructProperty)

    void SET_MRSPlaylistData(const TWeakObjectPtr<UFortPlaylistAthena*>& Value) { Write<TWeakObjectPtr<UFortPlaylistAthena*>>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MRSLinkId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x10, Type: StrProperty)
    void SET_PrimaryStateMachine(const UDelMarGameStateMachine*& Value) { Write<UDelMarGameStateMachine*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldShowLoadingScreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultRaceLevelConfigs(const TMap<EDelMarRaceMode, TSoftClassPtr>& Value) { Write<TMap<EDelMarRaceMode, TSoftClassPtr>>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x50, Type: MapProperty)
    void SET_ActiveRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlaylistData(const TWeakObjectPtr<UFortPlaylistAthena*>& Value) { Write<TWeakObjectPtr<UFortPlaylistAthena*>>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LevelManager(const TWeakObjectPtr<UDelMarLevelManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarLevelManagerComponent*>>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LevelStreamComponent(const UFortLevelStreamComponent*& Value) { Write<UFortLevelStreamComponent*>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerExpirationComponent(const UDelMarPlayspaceComponent_ServerExpiration*& Value) { Write<UDelMarPlayspaceComponent_ServerExpiration*>(uintptr_t(this) + 0x7d0, Value); } // 0x7d0 (Size: 0x8, Type: ObjectProperty)
    void SET_MapSet(const FDelMarMapSet& Value) { Write<FDelMarMapSet>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x18, Type: StructProperty)
    void SET_PlaylistDefinedMapTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x7f0, Value); } // 0x7f0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x38
class UDelMarEvent_FinalFirstPlaceChanged : public UObject
{
public:
    TWeakObjectPtr<AFortPlayerState*> NewFirstPlace() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PrevFirstPlace() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_NewFirstPlace(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PrevFirstPlace(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xde0
class ADelMarCheckpoint : public AFortCreativeDeviceProp
{
public:
    bool bIsFinishLine() const { return (Read<uint8_t>(uintptr_t(this) + 0xc20) >> 0x0) & 1; } // 0xc20:0 (Size: 0x1, Type: BoolProperty)
    bool bIsStartingLine() const { return (Read<uint8_t>(uintptr_t(this) + 0xc20) >> 0x1) & 1; } // 0xc20:1 (Size: 0x1, Type: BoolProperty)
    bool bIsTimeTrialSectionEnd() const { return (Read<uint8_t>(uintptr_t(this) + 0xc20) >> 0x2) & 1; } // 0xc20:2 (Size: 0x1, Type: BoolProperty)
    bool bIsTeleportEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0xc20) >> 0x3) & 1; } // 0xc20:3 (Size: 0x1, Type: BoolProperty)
    TSet<ADelMarCheckpoint*> NextCheckpoints() const { return Read<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x50, Type: SetProperty)
    float DynamicSpawnOffset() const { return Read<float>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x4, Type: FloatProperty)
    float SpawnDistanceBeforeOrAfterSplineLocation() const { return Read<float>(uintptr_t(this) + 0xc7c); } // 0xc7c (Size: 0x4, Type: FloatProperty)
    float BaseRadius() const { return Read<float>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x4, Type: FloatProperty)
    FVector IntersectionTolerance() const { return Read<FVector>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x18, Type: StructProperty)
    int32_t CheckpointId() const { return Read<int32_t>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x4, Type: IntProperty)
    int32_t SplinePointIndex() const { return Read<int32_t>(uintptr_t(this) + 0xca4); } // 0xca4 (Size: 0x4, Type: IntProperty)
    ADelMarPlayerStart* SpawnPoint() const { return Read<ADelMarPlayerStart*>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackSnapToComponent* SnapToComponent() const { return Read<UDelMarTrackSnapToComponent*>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    TSet<ADelMarCheckpoint*> PreviousCheckpoints() const { return Read<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x50, Type: SetProperty)
    int32_t NearestTrackIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x4, Type: IntProperty)
    TArray<FCheckpointTrackDistance> AssociatedTracks() const { return Read<TArray<FCheckpointTrackDistance>>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x10, Type: ArrayProperty)
    int32_t ComputedCheckpointIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd40); } // 0xd40 (Size: 0x4, Type: IntProperty)
    UStaticMeshComponent* ColliderVolume() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xd48); } // 0xd48 (Size: 0x8, Type: ObjectProperty)
    UDelMarCheckpointTheme* CheckpointTheme() const { return Read<UDelMarCheckpointTheme*>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x8, Type: ObjectProperty)
    ADelMarCheckpoint* CheckpointToTeleportTo() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0xdd0); } // 0xdd0 (Size: 0x8, Type: ObjectProperty)

    void SET_bIsFinishLine(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc20); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc20, B); } // 0xc20:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsStartingLine(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc20); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xc20, B); } // 0xc20:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTimeTrialSectionEnd(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc20); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xc20, B); } // 0xc20:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTeleportEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc20); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0xc20, B); } // 0xc20:3 (Size: 0x1, Type: BoolProperty)
    void SET_NextCheckpoints(const TSet<ADelMarCheckpoint*>& Value) { Write<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x50, Type: SetProperty)
    void SET_DynamicSpawnOffset(const float& Value) { Write<float>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x4, Type: FloatProperty)
    void SET_SpawnDistanceBeforeOrAfterSplineLocation(const float& Value) { Write<float>(uintptr_t(this) + 0xc7c, Value); } // 0xc7c (Size: 0x4, Type: FloatProperty)
    void SET_BaseRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x4, Type: FloatProperty)
    void SET_IntersectionTolerance(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x18, Type: StructProperty)
    void SET_CheckpointId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x4, Type: IntProperty)
    void SET_SplinePointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xca4, Value); } // 0xca4 (Size: 0x4, Type: IntProperty)
    void SET_SpawnPoint(const ADelMarPlayerStart*& Value) { Write<ADelMarPlayerStart*>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    void SET_SnapToComponent(const UDelMarTrackSnapToComponent*& Value) { Write<UDelMarTrackSnapToComponent*>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousCheckpoints(const TSet<ADelMarCheckpoint*>& Value) { Write<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x50, Type: SetProperty)
    void SET_NearestTrackIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x4, Type: IntProperty)
    void SET_AssociatedTracks(const TArray<FCheckpointTrackDistance>& Value) { Write<TArray<FCheckpointTrackDistance>>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x10, Type: ArrayProperty)
    void SET_ComputedCheckpointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd40, Value); } // 0xd40 (Size: 0x4, Type: IntProperty)
    void SET_ColliderVolume(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xd48, Value); } // 0xd48 (Size: 0x8, Type: ObjectProperty)
    void SET_CheckpointTheme(const UDelMarCheckpointTheme*& Value) { Write<UDelMarCheckpointTheme*>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x8, Type: ObjectProperty)
    void SET_CheckpointToTeleportTo(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0xdd0, Value); } // 0xdd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x328
class ADelMarPlayerStart : public AFortPlayerStart
{
public:
    int32_t StartlinePriority() const { return Read<int32_t>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x4, Type: IntProperty)
    float IsClaimedZDistanceCheck() const { return Read<float>(uintptr_t(this) + 0x31c); } // 0x31c (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarRaceManager*> DelMarRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: WeakObjectProperty)

    void SET_StartlinePriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x4, Type: IntProperty)
    void SET_IsClaimedZDistanceCheck(const float& Value) { Write<float>(uintptr_t(this) + 0x31c, Value); } // 0x31c (Size: 0x4, Type: FloatProperty)
    void SET_DelMarRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x278
class UDelMarPlayerRaceDataComponent : public UDelMarPlayerStateComponent
{
public:
    TSet<int32_t> VisitedCheckpoints() const { return Read<TSet<int32_t>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x50, Type: SetProperty)
    TSet<ADelMarCheckpoint*> VisitedCheckpoints_ParallelPath() const { return Read<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x50, Type: SetProperty)
    double RunStartTime() const { return Read<double>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    double RunFinishTime() const { return Read<double>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: DoubleProperty)
    double CheckpointStartTime() const { return Read<double>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: DoubleProperty)
    double LapStartTime() const { return Read<double>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    float DistanceToFinishLine() const { return Read<float>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float LapDistance() const { return Read<float>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    float PrimaryTrackDistance() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float IndependentTrackDistance() const { return Read<float>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    int32_t LapsCompleted() const { return Read<int32_t>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: IntProperty)
    bool bHasStartedFirstLap() const { return Read<bool>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    bool bFinishedRace() const { return Read<bool>(uintptr_t(this) + 0x1bd); } // 0x1bd (Size: 0x1, Type: BoolProperty)
    int32_t Points() const { return Read<int32_t>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: IntProperty)
    TArray<APlayerState*> ViewingSpectators() const { return Read<TArray<APlayerState*>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    ADelMarCheckpoint* MostRecentlyVisitedCheckpoint() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager() const { return Read<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> CachedPositionalTracker() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> CachedLapTracker() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    TSet<ADelMarCheckpoint*> CheckpointsVisitedThisLap() const { return Read<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x50, Type: SetProperty)
    int32_t TimeTrialSectionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x4, Type: IntProperty)
    int32_t CheckPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x25c); } // 0x25c (Size: 0x4, Type: IntProperty)
    UDelMarEvent_PlayerPointsChanged* PointsUpdatedEvent() const { return Read<UDelMarEvent_PlayerPointsChanged*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    UDelMarEvent_PlayerFinishRace* FinishRaceEvent() const { return Read<UDelMarEvent_PlayerFinishRace*>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: ObjectProperty)
    int32_t CachedBotPenaltyCurveIndex() const { return Read<int32_t>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x4, Type: IntProperty)

    void SET_VisitedCheckpoints(const TSet<int32_t>& Value) { Write<TSet<int32_t>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x50, Type: SetProperty)
    void SET_VisitedCheckpoints_ParallelPath(const TSet<ADelMarCheckpoint*>& Value) { Write<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x50, Type: SetProperty)
    void SET_RunStartTime(const double& Value) { Write<double>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    void SET_RunFinishTime(const double& Value) { Write<double>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: DoubleProperty)
    void SET_CheckpointStartTime(const double& Value) { Write<double>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: DoubleProperty)
    void SET_LapStartTime(const double& Value) { Write<double>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    void SET_DistanceToFinishLine(const float& Value) { Write<float>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    void SET_LapDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryTrackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    void SET_IndependentTrackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    void SET_LapsCompleted(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: IntProperty)
    void SET_bHasStartedFirstLap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    void SET_bFinishedRace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bd, Value); } // 0x1bd (Size: 0x1, Type: BoolProperty)
    void SET_Points(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: IntProperty)
    void SET_ViewingSpectators(const TArray<APlayerState*>& Value) { Write<TArray<APlayerState*>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    void SET_MostRecentlyVisitedCheckpoint(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedCheckpointManager(const TWeakObjectPtr<UDelMarCheckpointManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPositionalTracker(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedLapTracker(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CheckpointsVisitedThisLap(const TSet<ADelMarCheckpoint*>& Value) { Write<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x50, Type: SetProperty)
    void SET_TimeTrialSectionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x4, Type: IntProperty)
    void SET_CheckPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x25c, Value); } // 0x25c (Size: 0x4, Type: IntProperty)
    void SET_PointsUpdatedEvent(const UDelMarEvent_PlayerPointsChanged*& Value) { Write<UDelMarEvent_PlayerPointsChanged*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
    void SET_FinishRaceEvent(const UDelMarEvent_PlayerFinishRace*& Value) { Write<UDelMarEvent_PlayerFinishRace*>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedBotPenaltyCurveIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
class UDelMarEvent_PlayerPointsChanged : public UObject
{
public:
    int32_t PreviousPoints() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPoints() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)

    void SET_PreviousPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_CurrentPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
class UDelMarEvent_AttachmentChanged : public UObject
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerAttachedTo() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PrevPlayerAttachedTo() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_PlayerAttachedTo(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PrevPlayerAttachedTo(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3d80
class ADelMarVehicle : public AFortAthenaSKVehicle
{
public:
    UClass* DefaultCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0x2208); } // 0x2208 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> SeatIndexCameraModes() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2210); } // 0x2210 (Size: 0x10, Type: ArrayProperty)
    bool bLocalDriverHasReplicatedVehicle() const { return Read<bool>(uintptr_t(this) + 0x2220); } // 0x2220 (Size: 0x1, Type: BoolProperty)
    FFortAthenaVehicleInputState PendingDriverInputState() const { return Read<FFortAthenaVehicleInputState>(uintptr_t(this) + 0x2230); } // 0x2230 (Size: 0x40, Type: StructProperty)
    uint8_t CurrentInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x2270); } // 0x2270 (Size: 0x1, Type: EnumProperty)
    float DistanceToPack() const { return Read<float>(uintptr_t(this) + 0x2290); } // 0x2290 (Size: 0x4, Type: FloatProperty)
    float DistanceFromTrackFinish() const { return Read<float>(uintptr_t(this) + 0x2294); } // 0x2294 (Size: 0x4, Type: FloatProperty)
    float RaceStatusSpeedModifier() const { return Read<float>(uintptr_t(this) + 0x2298); } // 0x2298 (Size: 0x4, Type: FloatProperty)
    float TurboBoostChanceCache() const { return Read<float>(uintptr_t(this) + 0x229c); } // 0x229c (Size: 0x4, Type: FloatProperty)
    bool ATTR_bVehicleThrottleDisabled() const { return Read<bool>(uintptr_t(this) + 0x22a0); } // 0x22a0 (Size: 0x1, Type: BoolProperty)
    FDelMarInputAction ThrottleAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x22a8); } // 0x22a8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction BrakeAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x22b8); } // 0x22b8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction SteerAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x22c8); } // 0x22c8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction SteerLeftAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x22d8); } // 0x22d8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction SteerRightAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x22e8); } // 0x22e8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction PitchAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x22f8); } // 0x22f8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction PitchUpAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2308); } // 0x2308 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction PitchDownAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2318); } // 0x2318 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction RollAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2328); } // 0x2328 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction YawAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2338); } // 0x2338 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction DriftAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2348); } // 0x2348 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction JumpAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2358); } // 0x2358 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction KickFlipAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2368); } // 0x2368 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction UnderthrustAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2378); } // 0x2378 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction TurboAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2388); } // 0x2388 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction DelMarExitAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x2398); } // 0x2398 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction ResetRunAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x23a8); } // 0x23a8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction AirFreestyleAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x23b8); } // 0x23b8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction StrafeAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x23c8); } // 0x23c8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction AerialPitchAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x23d8); } // 0x23d8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction DemolishAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0x23e8); } // 0x23e8 (Size: 0x10, Type: StructProperty)
    UClass* InputManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0x23f8); } // 0x23f8 (Size: 0x8, Type: ClassProperty)
    float IdleVelocityLengthThreshold() const { return Read<float>(uintptr_t(this) + 0x2418); } // 0x2418 (Size: 0x4, Type: FloatProperty)
    float IdleInputSecondsThreshold() const { return Read<float>(uintptr_t(this) + 0x241c); } // 0x241c (Size: 0x4, Type: FloatProperty)
    bool bIdleFromNoInput() const { return Read<bool>(uintptr_t(this) + 0x2420); } // 0x2420 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x2468); } // 0x2468 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarVehicleNetworkPhysicsComponent* NetworkPhysicsComponent() const { return Read<UDelMarVehicleNetworkPhysicsComponent*>(uintptr_t(this) + 0x2470); } // 0x2470 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleCosmeticComponent* CosmeticComponent() const { return Read<UDelMarVehicleCosmeticComponent*>(uintptr_t(this) + 0x2478); } // 0x2478 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleMovementSet* DelMarVehicleMovementSet() const { return Read<UDelMarVehicleMovementSet*>(uintptr_t(this) + 0x2480); } // 0x2480 (Size: 0x8, Type: ObjectProperty)
    UFortClientSettingsRecord* FortSettings() const { return Read<UFortClientSettingsRecord*>(uintptr_t(this) + 0x2488); } // 0x2488 (Size: 0x8, Type: ObjectProperty)
    UClass* TrackPositionComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x2490); } // 0x2490 (Size: 0x8, Type: ClassProperty)
    UDelMarTrackPositionComponent* TrackPositionComponent() const { return Read<UDelMarTrackPositionComponent*>(uintptr_t(this) + 0x2498); } // 0x2498 (Size: 0x8, Type: ObjectProperty)
    TArray<TWeakObjectPtr<USkeletalMeshComponent*>> WheelSkeletalMeshComps() const { return Read<TArray<TWeakObjectPtr<USkeletalMeshComponent*>>>(uintptr_t(this) + 0x24a8); } // 0x24a8 (Size: 0x10, Type: ArrayProperty)
    TMap<TWeakObjectPtr<AFortPlayerState*>, UDelMarEvent_PlayerInVehicle*> PlayerInVehicleEvents() const { return Read<TMap<TWeakObjectPtr<AFortPlayerState*>, UDelMarEvent_PlayerInVehicle*>>(uintptr_t(this) + 0x24b8); } // 0x24b8 (Size: 0x50, Type: MapProperty)
    int32_t NumAllowedVehicleCosmeticChanges() const { return Read<int32_t>(uintptr_t(this) + 0x2508); } // 0x2508 (Size: 0x4, Type: IntProperty)
    TArray<FDelMarVehicleCachedContact> CachedContacts() const { return Read<TArray<FDelMarVehicleCachedContact>>(uintptr_t(this) + 0x2510); } // 0x2510 (Size: 0x10, Type: ArrayProperty)
    float NearbyTrackDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x2520); } // 0x2520 (Size: 0x4, Type: FloatProperty)
    float MaxStableSpeedToUpdateWheels() const { return Read<float>(uintptr_t(this) + 0x2538); } // 0x2538 (Size: 0x4, Type: FloatProperty)
    float SecondsUntilVehicleHitVelocityClears() const { return Read<float>(uintptr_t(this) + 0x253c); } // 0x253c (Size: 0x4, Type: FloatProperty)
    bool bOverrideDamageFromInstigator() const { return Read<bool>(uintptr_t(this) + 0x2540); } // 0x2540 (Size: 0x1, Type: BoolProperty)
    FDelMarVehicleConfigOverrides ConfigOverrides() const { return Read<FDelMarVehicleConfigOverrides>(uintptr_t(this) + 0x25a0); } // 0x25a0 (Size: 0xa0, Type: StructProperty)
    float VisualSteerAngleInterpRate() const { return Read<float>(uintptr_t(this) + 0x3250); } // 0x3250 (Size: 0x4, Type: FloatProperty)
    float DriftVisualSteerAngleInterpRate() const { return Read<float>(uintptr_t(this) + 0x3254); } // 0x3254 (Size: 0x4, Type: FloatProperty)
    bool bOverrideVisualSteeringAngle() const { return Read<bool>(uintptr_t(this) + 0x3258); } // 0x3258 (Size: 0x1, Type: BoolProperty)
    float DrivingVisualSteeringDegrees() const { return Read<float>(uintptr_t(this) + 0x325c); } // 0x325c (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve DriftSteeringDegreesCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x3260); } // 0x3260 (Size: 0x90, Type: StructProperty)
    bool bShowVisualSteerAngleInAir() const { return Read<bool>(uintptr_t(this) + 0x32f0); } // 0x32f0 (Size: 0x1, Type: BoolProperty)
    UDelMarVehicleBodySetup* BodySetup() const { return Read<UDelMarVehicleBodySetup*>(uintptr_t(this) + 0x32f8); } // 0x32f8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UDelMarRaceConfigComponent*> ActiveRaceConfig() const { return Read<TWeakObjectPtr<UDelMarRaceConfigComponent*>>(uintptr_t(this) + 0x3318); } // 0x3318 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTimeManagerComponent*> RaceTimeManager() const { return Read<TWeakObjectPtr<UDelMarTimeManagerComponent*>>(uintptr_t(this) + 0x3320); } // 0x3320 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarGlobalInputDisabler*> GlobalInputDisabler() const { return Read<TWeakObjectPtr<UDelMarGlobalInputDisabler*>>(uintptr_t(this) + 0x3328); } // 0x3328 (Size: 0x8, Type: WeakObjectProperty)
    float MinNoThrottleSpeed() const { return Read<float>(uintptr_t(this) + 0x3360); } // 0x3360 (Size: 0x4, Type: FloatProperty)
    float SpeedSlowdownSpeedometerSeconds() const { return Read<float>(uintptr_t(this) + 0x3364); } // 0x3364 (Size: 0x4, Type: FloatProperty)
    TArray<FGameplayTag> SpeedSlowdownTags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x3368); } // 0x3368 (Size: 0x10, Type: ArrayProperty)
    uint8_t InvertSteerMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x3378); } // 0x3378 (Size: 0x1, Type: EnumProperty)
    bool bPitchInverted() const { return Read<bool>(uintptr_t(this) + 0x3379); } // 0x3379 (Size: 0x1, Type: BoolProperty)
    bool bVerticalKickflipInverted() const { return Read<bool>(uintptr_t(this) + 0x337a); } // 0x337a (Size: 0x1, Type: BoolProperty)
    bool bAerialPitchActivationEnabled() const { return Read<bool>(uintptr_t(this) + 0x337b); } // 0x337b (Size: 0x1, Type: BoolProperty)
    FDelMarRubberbandingConfig RubberbandingConfig() const { return Read<FDelMarRubberbandingConfig>(uintptr_t(this) + 0x381c); } // 0x381c (Size: 0x28, Type: StructProperty)
    FDelMarStartlineBoostData StartlineBoostData() const { return Read<FDelMarStartlineBoostData>(uintptr_t(this) + 0x38a8); } // 0x38a8 (Size: 0x14, Type: StructProperty)
    float TurboCharges() const { return Read<float>(uintptr_t(this) + 0x3998); } // 0x3998 (Size: 0x4, Type: FloatProperty)
    FVector ForcedReattachmentDirection() const { return Read<FVector>(uintptr_t(this) + 0x3af8); } // 0x3af8 (Size: 0x18, Type: StructProperty)
    float DemolitionRespawnSeconds() const { return Read<float>(uintptr_t(this) + 0x3bb8); } // 0x3bb8 (Size: 0x4, Type: FloatProperty)
    float HealthOverride() const { return Read<float>(uintptr_t(this) + 0x3be0); } // 0x3be0 (Size: 0x4, Type: FloatProperty)
    float MaxSpawnBroadcastSeconds() const { return Read<float>(uintptr_t(this) + 0x3c34); } // 0x3c34 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleSpawnInfo SpawnInfo() const { return Read<FDelMarVehicleSpawnInfo>(uintptr_t(this) + 0x3c38); } // 0x3c38 (Size: 0x10, Type: StructProperty)
    bool bAllowExitingVehicle() const { return Read<bool>(uintptr_t(this) + 0x3c58); } // 0x3c58 (Size: 0x1, Type: BoolProperty)
    ADelMarAudioController* CachedVehicleAudioController() const { return Read<ADelMarAudioController*>(uintptr_t(this) + 0x3ce8); } // 0x3ce8 (Size: 0x8, Type: ObjectProperty)
    bool bVehicleCollisionsEnabled() const { return Read<bool>(uintptr_t(this) + 0x3cf0); } // 0x3cf0 (Size: 0x1, Type: BoolProperty)
    bool bPawnCollisionsEnabled() const { return Read<bool>(uintptr_t(this) + 0x3cf1); } // 0x3cf1 (Size: 0x1, Type: BoolProperty)
    bool bUsePredictiveInterpolation() const { return Read<bool>(uintptr_t(this) + 0x3d00); } // 0x3d00 (Size: 0x1, Type: BoolProperty)
    UPostProcessComponent* PostProcessComp() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x3d08); } // 0x3d08 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2208, Value); } // 0x2208 (Size: 0x8, Type: ClassProperty)
    void SET_SeatIndexCameraModes(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2210, Value); } // 0x2210 (Size: 0x10, Type: ArrayProperty)
    void SET_bLocalDriverHasReplicatedVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2220, Value); } // 0x2220 (Size: 0x1, Type: BoolProperty)
    void SET_PendingDriverInputState(const FFortAthenaVehicleInputState& Value) { Write<FFortAthenaVehicleInputState>(uintptr_t(this) + 0x2230, Value); } // 0x2230 (Size: 0x40, Type: StructProperty)
    void SET_CurrentInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2270, Value); } // 0x2270 (Size: 0x1, Type: EnumProperty)
    void SET_DistanceToPack(const float& Value) { Write<float>(uintptr_t(this) + 0x2290, Value); } // 0x2290 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceFromTrackFinish(const float& Value) { Write<float>(uintptr_t(this) + 0x2294, Value); } // 0x2294 (Size: 0x4, Type: FloatProperty)
    void SET_RaceStatusSpeedModifier(const float& Value) { Write<float>(uintptr_t(this) + 0x2298, Value); } // 0x2298 (Size: 0x4, Type: FloatProperty)
    void SET_TurboBoostChanceCache(const float& Value) { Write<float>(uintptr_t(this) + 0x229c, Value); } // 0x229c (Size: 0x4, Type: FloatProperty)
    void SET_ATTR_bVehicleThrottleDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22a0, Value); } // 0x22a0 (Size: 0x1, Type: BoolProperty)
    void SET_ThrottleAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x22a8, Value); } // 0x22a8 (Size: 0x10, Type: StructProperty)
    void SET_BrakeAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x22b8, Value); } // 0x22b8 (Size: 0x10, Type: StructProperty)
    void SET_SteerAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x22c8, Value); } // 0x22c8 (Size: 0x10, Type: StructProperty)
    void SET_SteerLeftAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x22d8, Value); } // 0x22d8 (Size: 0x10, Type: StructProperty)
    void SET_SteerRightAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x22e8, Value); } // 0x22e8 (Size: 0x10, Type: StructProperty)
    void SET_PitchAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x22f8, Value); } // 0x22f8 (Size: 0x10, Type: StructProperty)
    void SET_PitchUpAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2308, Value); } // 0x2308 (Size: 0x10, Type: StructProperty)
    void SET_PitchDownAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2318, Value); } // 0x2318 (Size: 0x10, Type: StructProperty)
    void SET_RollAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2328, Value); } // 0x2328 (Size: 0x10, Type: StructProperty)
    void SET_YawAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2338, Value); } // 0x2338 (Size: 0x10, Type: StructProperty)
    void SET_DriftAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2348, Value); } // 0x2348 (Size: 0x10, Type: StructProperty)
    void SET_JumpAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2358, Value); } // 0x2358 (Size: 0x10, Type: StructProperty)
    void SET_KickFlipAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2368, Value); } // 0x2368 (Size: 0x10, Type: StructProperty)
    void SET_UnderthrustAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2378, Value); } // 0x2378 (Size: 0x10, Type: StructProperty)
    void SET_TurboAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2388, Value); } // 0x2388 (Size: 0x10, Type: StructProperty)
    void SET_DelMarExitAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x2398, Value); } // 0x2398 (Size: 0x10, Type: StructProperty)
    void SET_ResetRunAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x23a8, Value); } // 0x23a8 (Size: 0x10, Type: StructProperty)
    void SET_AirFreestyleAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x23b8, Value); } // 0x23b8 (Size: 0x10, Type: StructProperty)
    void SET_StrafeAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x23c8, Value); } // 0x23c8 (Size: 0x10, Type: StructProperty)
    void SET_AerialPitchAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x23d8, Value); } // 0x23d8 (Size: 0x10, Type: StructProperty)
    void SET_DemolishAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0x23e8, Value); } // 0x23e8 (Size: 0x10, Type: StructProperty)
    void SET_InputManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x23f8, Value); } // 0x23f8 (Size: 0x8, Type: ClassProperty)
    void SET_IdleVelocityLengthThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x2418, Value); } // 0x2418 (Size: 0x4, Type: FloatProperty)
    void SET_IdleInputSecondsThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x241c, Value); } // 0x241c (Size: 0x4, Type: FloatProperty)
    void SET_bIdleFromNoInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2420, Value); } // 0x2420 (Size: 0x1, Type: BoolProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x2468, Value); } // 0x2468 (Size: 0x8, Type: WeakObjectProperty)
    void SET_NetworkPhysicsComponent(const UDelMarVehicleNetworkPhysicsComponent*& Value) { Write<UDelMarVehicleNetworkPhysicsComponent*>(uintptr_t(this) + 0x2470, Value); } // 0x2470 (Size: 0x8, Type: ObjectProperty)
    void SET_CosmeticComponent(const UDelMarVehicleCosmeticComponent*& Value) { Write<UDelMarVehicleCosmeticComponent*>(uintptr_t(this) + 0x2478, Value); } // 0x2478 (Size: 0x8, Type: ObjectProperty)
    void SET_DelMarVehicleMovementSet(const UDelMarVehicleMovementSet*& Value) { Write<UDelMarVehicleMovementSet*>(uintptr_t(this) + 0x2480, Value); } // 0x2480 (Size: 0x8, Type: ObjectProperty)
    void SET_FortSettings(const UFortClientSettingsRecord*& Value) { Write<UFortClientSettingsRecord*>(uintptr_t(this) + 0x2488, Value); } // 0x2488 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackPositionComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2490, Value); } // 0x2490 (Size: 0x8, Type: ClassProperty)
    void SET_TrackPositionComponent(const UDelMarTrackPositionComponent*& Value) { Write<UDelMarTrackPositionComponent*>(uintptr_t(this) + 0x2498, Value); } // 0x2498 (Size: 0x8, Type: ObjectProperty)
    void SET_WheelSkeletalMeshComps(const TArray<TWeakObjectPtr<USkeletalMeshComponent*>>& Value) { Write<TArray<TWeakObjectPtr<USkeletalMeshComponent*>>>(uintptr_t(this) + 0x24a8, Value); } // 0x24a8 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayerInVehicleEvents(const TMap<TWeakObjectPtr<AFortPlayerState*>, UDelMarEvent_PlayerInVehicle*>& Value) { Write<TMap<TWeakObjectPtr<AFortPlayerState*>, UDelMarEvent_PlayerInVehicle*>>(uintptr_t(this) + 0x24b8, Value); } // 0x24b8 (Size: 0x50, Type: MapProperty)
    void SET_NumAllowedVehicleCosmeticChanges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2508, Value); } // 0x2508 (Size: 0x4, Type: IntProperty)
    void SET_CachedContacts(const TArray<FDelMarVehicleCachedContact>& Value) { Write<TArray<FDelMarVehicleCachedContact>>(uintptr_t(this) + 0x2510, Value); } // 0x2510 (Size: 0x10, Type: ArrayProperty)
    void SET_NearbyTrackDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x2520, Value); } // 0x2520 (Size: 0x4, Type: FloatProperty)
    void SET_MaxStableSpeedToUpdateWheels(const float& Value) { Write<float>(uintptr_t(this) + 0x2538, Value); } // 0x2538 (Size: 0x4, Type: FloatProperty)
    void SET_SecondsUntilVehicleHitVelocityClears(const float& Value) { Write<float>(uintptr_t(this) + 0x253c, Value); } // 0x253c (Size: 0x4, Type: FloatProperty)
    void SET_bOverrideDamageFromInstigator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2540, Value); } // 0x2540 (Size: 0x1, Type: BoolProperty)
    void SET_ConfigOverrides(const FDelMarVehicleConfigOverrides& Value) { Write<FDelMarVehicleConfigOverrides>(uintptr_t(this) + 0x25a0, Value); } // 0x25a0 (Size: 0xa0, Type: StructProperty)
    void SET_VisualSteerAngleInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x3250, Value); } // 0x3250 (Size: 0x4, Type: FloatProperty)
    void SET_DriftVisualSteerAngleInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x3254, Value); } // 0x3254 (Size: 0x4, Type: FloatProperty)
    void SET_bOverrideVisualSteeringAngle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3258, Value); } // 0x3258 (Size: 0x1, Type: BoolProperty)
    void SET_DrivingVisualSteeringDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x325c, Value); } // 0x325c (Size: 0x4, Type: FloatProperty)
    void SET_DriftSteeringDegreesCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x3260, Value); } // 0x3260 (Size: 0x90, Type: StructProperty)
    void SET_bShowVisualSteerAngleInAir(const bool& Value) { Write<bool>(uintptr_t(this) + 0x32f0, Value); } // 0x32f0 (Size: 0x1, Type: BoolProperty)
    void SET_BodySetup(const UDelMarVehicleBodySetup*& Value) { Write<UDelMarVehicleBodySetup*>(uintptr_t(this) + 0x32f8, Value); } // 0x32f8 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveRaceConfig(const TWeakObjectPtr<UDelMarRaceConfigComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRaceConfigComponent*>>(uintptr_t(this) + 0x3318, Value); } // 0x3318 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RaceTimeManager(const TWeakObjectPtr<UDelMarTimeManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTimeManagerComponent*>>(uintptr_t(this) + 0x3320, Value); } // 0x3320 (Size: 0x8, Type: WeakObjectProperty)
    void SET_GlobalInputDisabler(const TWeakObjectPtr<UDelMarGlobalInputDisabler*>& Value) { Write<TWeakObjectPtr<UDelMarGlobalInputDisabler*>>(uintptr_t(this) + 0x3328, Value); } // 0x3328 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MinNoThrottleSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3360, Value); } // 0x3360 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedSlowdownSpeedometerSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3364, Value); } // 0x3364 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedSlowdownTags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x3368, Value); } // 0x3368 (Size: 0x10, Type: ArrayProperty)
    void SET_InvertSteerMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3378, Value); } // 0x3378 (Size: 0x1, Type: EnumProperty)
    void SET_bPitchInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3379, Value); } // 0x3379 (Size: 0x1, Type: BoolProperty)
    void SET_bVerticalKickflipInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x337a, Value); } // 0x337a (Size: 0x1, Type: BoolProperty)
    void SET_bAerialPitchActivationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x337b, Value); } // 0x337b (Size: 0x1, Type: BoolProperty)
    void SET_RubberbandingConfig(const FDelMarRubberbandingConfig& Value) { Write<FDelMarRubberbandingConfig>(uintptr_t(this) + 0x381c, Value); } // 0x381c (Size: 0x28, Type: StructProperty)
    void SET_StartlineBoostData(const FDelMarStartlineBoostData& Value) { Write<FDelMarStartlineBoostData>(uintptr_t(this) + 0x38a8, Value); } // 0x38a8 (Size: 0x14, Type: StructProperty)
    void SET_TurboCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x3998, Value); } // 0x3998 (Size: 0x4, Type: FloatProperty)
    void SET_ForcedReattachmentDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3af8, Value); } // 0x3af8 (Size: 0x18, Type: StructProperty)
    void SET_DemolitionRespawnSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3bb8, Value); } // 0x3bb8 (Size: 0x4, Type: FloatProperty)
    void SET_HealthOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x3be0, Value); } // 0x3be0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpawnBroadcastSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3c34, Value); } // 0x3c34 (Size: 0x4, Type: FloatProperty)
    void SET_SpawnInfo(const FDelMarVehicleSpawnInfo& Value) { Write<FDelMarVehicleSpawnInfo>(uintptr_t(this) + 0x3c38, Value); } // 0x3c38 (Size: 0x10, Type: StructProperty)
    void SET_bAllowExitingVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c58, Value); } // 0x3c58 (Size: 0x1, Type: BoolProperty)
    void SET_CachedVehicleAudioController(const ADelMarAudioController*& Value) { Write<ADelMarAudioController*>(uintptr_t(this) + 0x3ce8, Value); } // 0x3ce8 (Size: 0x8, Type: ObjectProperty)
    void SET_bVehicleCollisionsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3cf0, Value); } // 0x3cf0 (Size: 0x1, Type: BoolProperty)
    void SET_bPawnCollisionsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3cf1, Value); } // 0x3cf1 (Size: 0x1, Type: BoolProperty)
    void SET_bUsePredictiveInterpolation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d00, Value); } // 0x3d00 (Size: 0x1, Type: BoolProperty)
    void SET_PostProcessComp(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x3d08, Value); } // 0x3d08 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x158
class UDelMarUIInputControllerComponent : public UControllerComponent
{
public:
    UInputAction* HudWidgetExpandAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ToggleQuestListAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    UClass* InputManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent() const { return Read<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> PlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerPreferencesComponent*> PlayerPreferences() const { return Read<TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: WeakObjectProperty)

    void SET_HudWidgetExpandAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_ToggleQuestListAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_InputManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ClassProperty)
    void SET_InputComponent(const TWeakObjectPtr<UEnhancedInputComponent*>& Value) { Write<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerPreferences(const TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x68
class UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved : public UObject
{
public:
    FDelMarGlobalLeaderboardEntry PersonalBest() const { return Read<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x40, Type: StructProperty)

    void SET_PersonalBest(const FDelMarGlobalLeaderboardEntry& Value) { Write<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x40, Type: StructProperty)
};

// Size: 0x28
class UDelMarEvent_GlobalLeaderboardTopLeaderboardEntriesPopulated : public UObject
{
public:
};

// Size: 0x28
class UDelMarEvent_GlobalLeaderboardFocusedLeaderboardEntriesPopulated : public UObject
{
public:
};

// Size: 0x28
class UDelMarEvent_GlobalLeaderboardFriendLeaderboardEntriesPopulated : public UObject
{
public:
};

// Size: 0x38
class UDelMarEvent_PlayerInVehicle : public UObject
{
public:
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    int32_t SeatIndex() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_DelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SeatIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

// Size: 0xe8
class UDelMarPlayerIdleComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x38
class UDelMarEvent_VehicleDemolish : public UObject
{
public:
    FGameplayTag DemolishReason() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> Vehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)

    void SET_DemolishReason(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_Vehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x38
class UDelMarEvent_PlayerFinishRace : public UObject
{
public:
    double RunTime() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    bool bValidRun() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_RunTime(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_bValidRun(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc50
class ADelMarActorMover : public AFortCreativeDeviceProp
{
public:
    UClass* ActorClass() const { return Read<UClass*>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x8, Type: ClassProperty)
    USplineComponent* MovementSpline() const { return Read<USplineComponent*>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    uint8_t MovementType() const { return Read<uint8_t>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x1, Type: EnumProperty)
    AActor* ManagedActor() const { return Read<AActor*>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x8, Type: ObjectProperty)
    UDelMarSplineActorMovementComponent* SplineMovementComponent() const { return Read<UDelMarSplineActorMovementComponent*>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    float ServerMovementStartTime() const { return Read<float>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x4, Type: FloatProperty)

    void SET_ActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x8, Type: ClassProperty)
    void SET_MovementSpline(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    void SET_MovementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x1, Type: EnumProperty)
    void SET_ManagedActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineMovementComponent(const UDelMarSplineActorMovementComponent*& Value) { Write<UDelMarSplineActorMovementComponent*>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerMovementStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x638
class ADelMarAIController : public AAIController
{
public:
    FGameplayTag DescriptorTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x4, Type: StructProperty)
    FFortAthenaLoadout CosmeticLoadoutBC() const { return Read<FFortAthenaLoadout>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x1a8, Type: StructProperty)
    FCosmeticLoadout VehicleCosmeticLoadout() const { return Read<FCosmeticLoadout>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x10, Type: StructProperty)
    FGameplayTag VehicleArchetype() const { return Read<FGameplayTag>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x4, Type: StructProperty)
    uint8_t BotSteerMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x5bc); } // 0x5bc (Size: 0x1, Type: EnumProperty)
    UBehaviorTree* BTAssetToRunOnPawnAISpawned() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    TArray<UBehaviorTree*> SkillLevelBehaviorTrees() const { return Read<TArray<UBehaviorTree*>>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x10, Type: ArrayProperty)
    int32_t MinSkillLevelForRubberbanding() const { return Read<int32_t>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x4, Type: IntProperty)
    UClass* OobTubePositionRenderingComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: WeakObjectProperty)
    int32_t DelMarBotControllerUID() const { return Read<int32_t>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x4, Type: IntProperty)
    int32_t DelMarBotSkillLevel() const { return Read<int32_t>(uintptr_t(this) + 0x604); } // 0x604 (Size: 0x4, Type: IntProperty)
    FString DelMarBotPlayerName() const { return Read<FString>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x10, Type: StrProperty)
    UDelMarAIService* DelMarAIService() const { return Read<UDelMarAIService*>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* PlayerBotPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ObjectProperty)

    void SET_DescriptorTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x4, Type: StructProperty)
    void SET_CosmeticLoadoutBC(const FFortAthenaLoadout& Value) { Write<FFortAthenaLoadout>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x1a8, Type: StructProperty)
    void SET_VehicleCosmeticLoadout(const FCosmeticLoadout& Value) { Write<FCosmeticLoadout>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x10, Type: StructProperty)
    void SET_VehicleArchetype(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x4, Type: StructProperty)
    void SET_BotSteerMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5bc, Value); } // 0x5bc (Size: 0x1, Type: EnumProperty)
    void SET_BTAssetToRunOnPawnAISpawned(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SkillLevelBehaviorTrees(const TArray<UBehaviorTree*>& Value) { Write<TArray<UBehaviorTree*>>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x10, Type: ArrayProperty)
    void SET_MinSkillLevelForRubberbanding(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x4, Type: IntProperty)
    void SET_OobTubePositionRenderingComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ClassProperty)
    void SET_DelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_DelMarBotControllerUID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x4, Type: IntProperty)
    void SET_DelMarBotSkillLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x604, Value); } // 0x604 (Size: 0x4, Type: IntProperty)
    void SET_DelMarBotPlayerName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x10, Type: StrProperty)
    void SET_DelMarAIService(const UDelMarAIService*& Value) { Write<UDelMarAIService*>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerBotPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x188
class UDelMarAIService : public UAthenaAIService
{
public:
    UClass* CosmeticComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UDelMarAIVehicleCosmeticLibraryData> VehicleCosmeticLibrary() const { return Read<TSoftObjectPtr<UDelMarAIVehicleCosmeticLibraryData>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    bool bBotsUniqueIDUseValidAccountID() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    bool bUseRegionalNameList() const { return Read<bool>(uintptr_t(this) + 0xa1); } // 0xa1 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UFortAthenaAIBotNameDataAsset> BotNameDataAsset() const { return Read<TSoftObjectPtr<UFortAthenaAIBotNameDataAsset>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    UClass* AIControllerClass() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UDataTable> MMRSpawnTablePtr() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    int32_t MaxBotFillRandomDeviation() const { return Read<int32_t>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: IntProperty)
    TArray<ADelMarAIController*> DelMarAIControllers() const { return Read<TArray<ADelMarAIController*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRespawnManagerComponent*> RespawnManagerComponent() const { return Read<TWeakObjectPtr<UDelMarRespawnManagerComponent*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackManager*> TrackManager() const { return Read<TWeakObjectPtr<UDelMarTrackManager*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<ADelMarTrack*>> SortedSecondaryTracksAlongPrimary() const { return Read<TArray<TWeakObjectPtr<ADelMarTrack*>>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    TSet<FString> ReservedPlayerNames() const { return Read<TSet<FString>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x50, Type: SetProperty)

    void SET_CosmeticComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ClassProperty)
    void SET_VehicleCosmeticLibrary(const TSoftObjectPtr<UDelMarAIVehicleCosmeticLibraryData>& Value) { Write<TSoftObjectPtr<UDelMarAIVehicleCosmeticLibraryData>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bBotsUniqueIDUseValidAccountID(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseRegionalNameList(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa1, Value); } // 0xa1 (Size: 0x1, Type: BoolProperty)
    void SET_BotNameDataAsset(const TSoftObjectPtr<UFortAthenaAIBotNameDataAsset>& Value) { Write<TSoftObjectPtr<UFortAthenaAIBotNameDataAsset>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AIControllerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    void SET_MMRSpawnTablePtr(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MaxBotFillRandomDeviation(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: IntProperty)
    void SET_DelMarAIControllers(const TArray<ADelMarAIController*>& Value) { Write<TArray<ADelMarAIController*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RespawnManagerComponent(const TWeakObjectPtr<UDelMarRespawnManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRespawnManagerComponent*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackManager(const TWeakObjectPtr<UDelMarTrackManager*>& Value) { Write<TWeakObjectPtr<UDelMarTrackManager*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SortedSecondaryTracksAlongPrimary(const TArray<TWeakObjectPtr<ADelMarTrack*>>& Value) { Write<TArray<TWeakObjectPtr<ADelMarTrack*>>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_ReservedPlayerNames(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x50, Type: SetProperty)
};

// Size: 0x58
class UDelMarAIVehicleCosmeticLibraryData : public UPrimaryDataAsset
{
public:
    TSoftObjectPtr<UDataTable> PredefineVehiclCosmeticSetsDataTable() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag CachedArchetypeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: StructProperty)

    void SET_PredefineVehiclCosmeticSetsDataTable(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CachedArchetypeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: StructProperty)
};

// Size: 0x240
class UDelMarBTService_ChooseNextTrack : public UDelMarBTService_VehicleBase
{
public:
    FBlackboardKeySelector TargetTrackDecisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsOffRoadDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsJumpDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsFullyBlockedCollisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x28, Type: StructProperty)
    float TrackDecisionMaxTrackDistanceOffset() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float TrackDecisionMinTrackDistanceOffset() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float TrackEndCheckTrackDistanceOffset() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    float BotReachedNewTrackDistanceOffset() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    float SplineResetAvailableTrackIndexThreshold() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    float AddKickflipWeightDegreeThreshold() const { return Read<float>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: FloatProperty)
    float TrackDecisionWeightMaxDistanceFromBot() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    float TrackDecisionWeightMaxHeightFromBot() const { return Read<float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: FloatProperty)
    float TrackDecisionWeightDesirableHeightFromBot() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)
    float MinDecisionDelaySecondsAfterChangingTracks() const { return Read<float>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: FloatProperty)
    float MaxDecisionDelaySecondsAfterChangingTracks() const { return Read<float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: FloatProperty)
    float ShortcutWeightLookAheadTrackDistance() const { return Read<float>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x4, Type: FloatProperty)
    float PrimaryTrackGapMinDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: FloatProperty)
    float ForceNewTrackDecisionAfterSecondsIfFullyBlocked() const { return Read<float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x4, Type: FloatProperty)
    float SwitchTrackMaxDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: FloatProperty)
    float SwitchTrackMinDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0x4, Type: FloatProperty)
    float TrackLengthRemainingPartitionAmount() const { return Read<float>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x4, Type: FloatProperty)
    float TrackLengthRemainingCap() const { return Read<float>(uintptr_t(this) + 0x184); } // 0x184 (Size: 0x4, Type: FloatProperty)
    float ValidRaycastDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x4, Type: FloatProperty)
    float OffRoadSurfaceMaxNormalToTrackAngleThreshold() const { return Read<float>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x4, Type: FloatProperty)
    float RaycastVehicleForwardOffset() const { return Read<float>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x4, Type: FloatProperty)
    float RaycastEndTrackForwardOffset() const { return Read<float>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> RaycastCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: ByteProperty)
    float TrackLengthWeightPercentage() const { return Read<float>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x4, Type: FloatProperty)
    float DistanceFromBotWeightPercentage() const { return Read<float>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float HeightFromBotWeightPercentage() const { return Read<float>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: FloatProperty)
    float TrackOrientationWeightPercentage() const { return Read<float>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float ShortcutWeightMultiplier() const { return Read<float>(uintptr_t(this) + 0x1ac); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    float AdditionalIndependentWeight() const { return Read<float>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float MaxRandomWeight() const { return Read<float>(uintptr_t(this) + 0x1b4); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    float PrimaryTrackGapStaticWeightDeduction() const { return Read<float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBlackboardComponent*> BlackboardComponent() const { return Read<TWeakObjectPtr<UBlackboardComponent*>>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> TargetTrackDecision() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> NextTrackDecision() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x8, Type: WeakObjectProperty)
    TArray<FDelMarAITrackDecision> AvailableTrackDecisions() const { return Read<TArray<FDelMarAITrackDecision>>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UDelMarAIService*> AIService() const { return Read<TWeakObjectPtr<UDelMarAIService*>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TargetTrackDecisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_IsOffRoadDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_IsJumpDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
    void SET_IsFullyBlockedCollisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x28, Type: StructProperty)
    void SET_TrackDecisionMaxTrackDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_TrackDecisionMinTrackDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_TrackEndCheckTrackDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_BotReachedNewTrackDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_SplineResetAvailableTrackIndexThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_AddKickflipWeightDegreeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: FloatProperty)
    void SET_TrackDecisionWeightMaxDistanceFromBot(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_TrackDecisionWeightMaxHeightFromBot(const float& Value) { Write<float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: FloatProperty)
    void SET_TrackDecisionWeightDesirableHeightFromBot(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
    void SET_MinDecisionDelaySecondsAfterChangingTracks(const float& Value) { Write<float>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDecisionDelaySecondsAfterChangingTracks(const float& Value) { Write<float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: FloatProperty)
    void SET_ShortcutWeightLookAheadTrackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryTrackGapMinDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: FloatProperty)
    void SET_ForceNewTrackDecisionAfterSecondsIfFullyBlocked(const float& Value) { Write<float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x4, Type: FloatProperty)
    void SET_SwitchTrackMaxDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: FloatProperty)
    void SET_SwitchTrackMinDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0x4, Type: FloatProperty)
    void SET_TrackLengthRemainingPartitionAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x4, Type: FloatProperty)
    void SET_TrackLengthRemainingCap(const float& Value) { Write<float>(uintptr_t(this) + 0x184, Value); } // 0x184 (Size: 0x4, Type: FloatProperty)
    void SET_ValidRaycastDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x4, Type: FloatProperty)
    void SET_OffRoadSurfaceMaxNormalToTrackAngleThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x4, Type: FloatProperty)
    void SET_RaycastVehicleForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x4, Type: FloatProperty)
    void SET_RaycastEndTrackForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x4, Type: FloatProperty)
    void SET_RaycastCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: ByteProperty)
    void SET_TrackLengthWeightPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x4, Type: FloatProperty)
    void SET_DistanceFromBotWeightPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: FloatProperty)
    void SET_HeightFromBotWeightPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: FloatProperty)
    void SET_TrackOrientationWeightPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    void SET_ShortcutWeightMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x1ac, Value); } // 0x1ac (Size: 0x4, Type: FloatProperty)
    void SET_AdditionalIndependentWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRandomWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x1b4, Value); } // 0x1b4 (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryTrackGapStaticWeightDeduction(const float& Value) { Write<float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    void SET_BlackboardComponent(const TWeakObjectPtr<UBlackboardComponent*>& Value) { Write<TWeakObjectPtr<UBlackboardComponent*>>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetTrackDecision(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_NextTrackDecision(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x8, Type: WeakObjectProperty)
    void SET_AvailableTrackDecisions(const TArray<FDelMarAITrackDecision>& Value) { Write<TArray<FDelMarAITrackDecision>>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x10, Type: ArrayProperty)
    void SET_AIService(const TWeakObjectPtr<UDelMarAIService*>& Value) { Write<TWeakObjectPtr<UDelMarAIService*>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackPositionComponent(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xa0
class UDelMarBTService_VehicleBase : public UBTService
{
public:
    FBlackboardKeySelector VehicleKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)

    void SET_VehicleKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_DelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x6c0
class UDelMarBTService_FindDriveGoal : public UDelMarBTService_VehicleBase
{
public:
    FBlackboardKeySelector TargetTrackDecisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalLocationKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalRotationKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsJumpDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsOffRoadDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsKickflipDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector KickflipDirectionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector HasUpcomingCollisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsFullyBlockedCollisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    float GroundedDriveGoalVehicleForwardOffset() const { return Read<float>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: FloatProperty)
    float TrackGapDriveGoalVehicleForwardOffset() const { return Read<float>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x4, Type: FloatProperty)
    float AirDriveGoalVehicleForwardOffset() const { return Read<float>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x4, Type: FloatProperty)
    float PathNoiseAmplitude() const { return Read<float>(uintptr_t(this) + 0x214); } // 0x214 (Size: 0x4, Type: FloatProperty)
    float PathNoiseFrequency() const { return Read<float>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: FloatProperty)
    int32_t MaxNumberOfCheckedTrackSegments() const { return Read<int32_t>(uintptr_t(this) + 0x21c); } // 0x21c (Size: 0x4, Type: IntProperty)
    float GroundedOffroadRaycastDistance() const { return Read<float>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x4, Type: FloatProperty)
    float GroundedOffRoadRaycastTrackForwardOffset() const { return Read<float>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0x4, Type: FloatProperty)
    float TrackGapCheckForwardOffset() const { return Read<float>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackRaycastForwardOffset() const { return Read<float>(uintptr_t(this) + 0x22c); } // 0x22c (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackRaycastDepthPadding() const { return Read<float>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackMaintainVehicleOffsetDegreeThreshold() const { return Read<float>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackRaycastMinAngleDifference() const { return Read<float>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x4, Type: FloatProperty)
    float UnsafeLandingDesiredUnderthrustHeightFactor() const { return Read<float>(uintptr_t(this) + 0x23c); } // 0x23c (Size: 0x4, Type: FloatProperty)
    float UnsafeLandingJumpGoalTrackOffsetReductionFactor() const { return Read<float>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: FloatProperty)
    float OffRoadSurfaceMaxNormalToTrackAngleThreshold() const { return Read<float>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: FloatProperty)
    float MaxVehicleAirRollAngleToReturnToTrackFromBelow() const { return Read<float>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: FloatProperty)
    int32_t NumberOfSideAvoidanceRaycasts() const { return Read<int32_t>(uintptr_t(this) + 0x24c); } // 0x24c (Size: 0x4, Type: IntProperty)
    float DegreesBetweenRaycasts() const { return Read<float>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x4, Type: FloatProperty)
    float TrackInclineMaxRaycastDirectionRotationDegrees() const { return Read<float>(uintptr_t(this) + 0x254); } // 0x254 (Size: 0x4, Type: FloatProperty)
    float DriftPrimaryTraceRotationFactor() const { return Read<float>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x4, Type: FloatProperty)
    float NonJumpableHazardMinHitNormalDegrees() const { return Read<float>(uintptr_t(this) + 0x25c); } // 0x25c (Size: 0x4, Type: FloatProperty)
    float AvoidanceTraceVerticalSpread() const { return Read<float>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> RaycastCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x264); } // 0x264 (Size: 0x1, Type: ByteProperty)
    TArray<UClass*> IgnoredActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x10, Type: ArrayProperty)
    FDelMarScaledCurve RaycastDistanceCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve RayCastDistanceContributionCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VehicleDistanceAvoidanceCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x90, Type: StructProperty)
    float DriveGoalOffsetCancelPadding() const { return Read<float>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x4, Type: FloatProperty)
    float DriveHazardOffsetCancelPadding() const { return Read<float>(uintptr_t(this) + 0x42c); } // 0x42c (Size: 0x4, Type: FloatProperty)
    float VehicleTrackOffsetCancelPadding() const { return Read<float>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x4, Type: FloatProperty)
    float DriveGoalOffsetMinTrackDepth() const { return Read<float>(uintptr_t(this) + 0x434); } // 0x434 (Size: 0x4, Type: FloatProperty)
    float DriveHazardMaxJumpDistanceFactor() const { return Read<float>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x4, Type: FloatProperty)
    float DriveHazardMinJumpDistanceFactor() const { return Read<float>(uintptr_t(this) + 0x43c); } // 0x43c (Size: 0x4, Type: FloatProperty)
    float HazardJumpGoalMaxHeightOffset() const { return Read<float>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x4, Type: FloatProperty)
    float HazardJumpGoalMinHeightOffset() const { return Read<float>(uintptr_t(this) + 0x444); } // 0x444 (Size: 0x4, Type: FloatProperty)
    float BlockedJumpTracePadding() const { return Read<float>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x4, Type: FloatProperty)
    float TrackGapJumpHeightThreshold() const { return Read<float>(uintptr_t(this) + 0x44c); } // 0x44c (Size: 0x4, Type: FloatProperty)
    float TrackGapDriveGoalHeightOffset() const { return Read<float>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x4, Type: FloatProperty)
    float VerticalTrackTransitionVehicleExtentMultiplier() const { return Read<float>(uintptr_t(this) + 0x454); } // 0x454 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> JumpableActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x10, Type: ArrayProperty)
    float SideKickflipSurfaceNormalDegreeThreshold() const { return Read<float>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x4, Type: FloatProperty)
    float UpwardKickflipMinNormalDegreesToWorldUp() const { return Read<float>(uintptr_t(this) + 0x46c); } // 0x46c (Size: 0x4, Type: FloatProperty)
    float KickflipDriveGoalTrackHeightOffset() const { return Read<float>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x4, Type: FloatProperty)
    float KickflipDriveGoalForwardDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x474); } // 0x474 (Size: 0x4, Type: FloatProperty)
    float UnderKickflipSurfaceForwardDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x4, Type: FloatProperty)
    float KickflipTraceHeightOffset() const { return Read<float>(uintptr_t(this) + 0x47c); } // 0x47c (Size: 0x4, Type: FloatProperty)
    float KickflipTraceMaximumHeightFromTrack() const { return Read<float>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x4, Type: FloatProperty)
    float KickflipMinimumDownwardDistanceFromTrack() const { return Read<float>(uintptr_t(this) + 0x484); } // 0x484 (Size: 0x4, Type: FloatProperty)
    float PercentChanceToAllowDownKickflip() const { return Read<float>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve PercentChanceToExecuteDownKickflipCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x90, Type: StructProperty)
    float SwitchTrackJumpHeightThreshold() const { return Read<float>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x4, Type: FloatProperty)
    float SwitchTrackToPipeHeightOffsetFactor() const { return Read<float>(uintptr_t(this) + 0x524); } // 0x524 (Size: 0x4, Type: FloatProperty)
    float PercentChanceToIgnoreDriveHazard() const { return Read<float>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x4, Type: FloatProperty)
    float PercentChanceToNotCheckForSafeLanding() const { return Read<float>(uintptr_t(this) + 0x52c); } // 0x52c (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBlackboardComponent*> BlackboardComponent() const { return Read<TWeakObjectPtr<UBlackboardComponent*>>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> TargetTrack() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> TargetTrackSplineComponent() const { return Read<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> ActiveTrack() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> ActiveTrackSplineComponent() const { return Read<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackOobTubePositionalRenderingComponent*> OobTubePositionalRenderingComponent() const { return Read<TWeakObjectPtr<UDelMarTrackOobTubePositionalRenderingComponent*>>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> OffRoadDriveActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> KickflipTrack() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TargetTrackDecisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_DriveGoalLocationKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_DriveGoalRotationKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
    void SET_IsJumpDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x28, Type: StructProperty)
    void SET_IsOffRoadDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x28, Type: StructProperty)
    void SET_IsKickflipDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x28, Type: StructProperty)
    void SET_KickflipDirectionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x28, Type: StructProperty)
    void SET_HasUpcomingCollisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_IsFullyBlockedCollisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x28, Type: StructProperty)
    void SET_GroundedDriveGoalVehicleForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: FloatProperty)
    void SET_TrackGapDriveGoalVehicleForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x4, Type: FloatProperty)
    void SET_AirDriveGoalVehicleForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x4, Type: FloatProperty)
    void SET_PathNoiseAmplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x214, Value); } // 0x214 (Size: 0x4, Type: FloatProperty)
    void SET_PathNoiseFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: FloatProperty)
    void SET_MaxNumberOfCheckedTrackSegments(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x21c, Value); } // 0x21c (Size: 0x4, Type: IntProperty)
    void SET_GroundedOffroadRaycastDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x4, Type: FloatProperty)
    void SET_GroundedOffRoadRaycastTrackForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0x4, Type: FloatProperty)
    void SET_TrackGapCheckForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: FloatProperty)
    void SET_ReturnToTrackRaycastForwardOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x22c, Value); } // 0x22c (Size: 0x4, Type: FloatProperty)
    void SET_ReturnToTrackRaycastDepthPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x4, Type: FloatProperty)
    void SET_ReturnToTrackMaintainVehicleOffsetDegreeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x4, Type: FloatProperty)
    void SET_ReturnToTrackRaycastMinAngleDifference(const float& Value) { Write<float>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x4, Type: FloatProperty)
    void SET_UnsafeLandingDesiredUnderthrustHeightFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x23c, Value); } // 0x23c (Size: 0x4, Type: FloatProperty)
    void SET_UnsafeLandingJumpGoalTrackOffsetReductionFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: FloatProperty)
    void SET_OffRoadSurfaceMaxNormalToTrackAngleThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: FloatProperty)
    void SET_MaxVehicleAirRollAngleToReturnToTrackFromBelow(const float& Value) { Write<float>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: FloatProperty)
    void SET_NumberOfSideAvoidanceRaycasts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24c, Value); } // 0x24c (Size: 0x4, Type: IntProperty)
    void SET_DegreesBetweenRaycasts(const float& Value) { Write<float>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x4, Type: FloatProperty)
    void SET_TrackInclineMaxRaycastDirectionRotationDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x254, Value); } // 0x254 (Size: 0x4, Type: FloatProperty)
    void SET_DriftPrimaryTraceRotationFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x4, Type: FloatProperty)
    void SET_NonJumpableHazardMinHitNormalDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x25c, Value); } // 0x25c (Size: 0x4, Type: FloatProperty)
    void SET_AvoidanceTraceVerticalSpread(const float& Value) { Write<float>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x4, Type: FloatProperty)
    void SET_RaycastCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x264, Value); } // 0x264 (Size: 0x1, Type: ByteProperty)
    void SET_IgnoredActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x10, Type: ArrayProperty)
    void SET_RaycastDistanceCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x90, Type: StructProperty)
    void SET_RayCastDistanceContributionCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x90, Type: StructProperty)
    void SET_VehicleDistanceAvoidanceCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x90, Type: StructProperty)
    void SET_DriveGoalOffsetCancelPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x4, Type: FloatProperty)
    void SET_DriveHazardOffsetCancelPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x42c, Value); } // 0x42c (Size: 0x4, Type: FloatProperty)
    void SET_VehicleTrackOffsetCancelPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x4, Type: FloatProperty)
    void SET_DriveGoalOffsetMinTrackDepth(const float& Value) { Write<float>(uintptr_t(this) + 0x434, Value); } // 0x434 (Size: 0x4, Type: FloatProperty)
    void SET_DriveHazardMaxJumpDistanceFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x4, Type: FloatProperty)
    void SET_DriveHazardMinJumpDistanceFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x43c, Value); } // 0x43c (Size: 0x4, Type: FloatProperty)
    void SET_HazardJumpGoalMaxHeightOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x4, Type: FloatProperty)
    void SET_HazardJumpGoalMinHeightOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x444, Value); } // 0x444 (Size: 0x4, Type: FloatProperty)
    void SET_BlockedJumpTracePadding(const float& Value) { Write<float>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x4, Type: FloatProperty)
    void SET_TrackGapJumpHeightThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x44c, Value); } // 0x44c (Size: 0x4, Type: FloatProperty)
    void SET_TrackGapDriveGoalHeightOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalTrackTransitionVehicleExtentMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x454, Value); } // 0x454 (Size: 0x4, Type: FloatProperty)
    void SET_JumpableActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x10, Type: ArrayProperty)
    void SET_SideKickflipSurfaceNormalDegreeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x4, Type: FloatProperty)
    void SET_UpwardKickflipMinNormalDegreesToWorldUp(const float& Value) { Write<float>(uintptr_t(this) + 0x46c, Value); } // 0x46c (Size: 0x4, Type: FloatProperty)
    void SET_KickflipDriveGoalTrackHeightOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x4, Type: FloatProperty)
    void SET_KickflipDriveGoalForwardDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x474, Value); } // 0x474 (Size: 0x4, Type: FloatProperty)
    void SET_UnderKickflipSurfaceForwardDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x4, Type: FloatProperty)
    void SET_KickflipTraceHeightOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x47c, Value); } // 0x47c (Size: 0x4, Type: FloatProperty)
    void SET_KickflipTraceMaximumHeightFromTrack(const float& Value) { Write<float>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x4, Type: FloatProperty)
    void SET_KickflipMinimumDownwardDistanceFromTrack(const float& Value) { Write<float>(uintptr_t(this) + 0x484, Value); } // 0x484 (Size: 0x4, Type: FloatProperty)
    void SET_PercentChanceToAllowDownKickflip(const float& Value) { Write<float>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x4, Type: FloatProperty)
    void SET_PercentChanceToExecuteDownKickflipCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x90, Type: StructProperty)
    void SET_SwitchTrackJumpHeightThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x4, Type: FloatProperty)
    void SET_SwitchTrackToPipeHeightOffsetFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x524, Value); } // 0x524 (Size: 0x4, Type: FloatProperty)
    void SET_PercentChanceToIgnoreDriveHazard(const float& Value) { Write<float>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x4, Type: FloatProperty)
    void SET_PercentChanceToNotCheckForSafeLanding(const float& Value) { Write<float>(uintptr_t(this) + 0x52c, Value); } // 0x52c (Size: 0x4, Type: FloatProperty)
    void SET_BlackboardComponent(const TWeakObjectPtr<UBlackboardComponent*>& Value) { Write<TWeakObjectPtr<UBlackboardComponent*>>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackPositionComponent(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetTrack(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetTrackSplineComponent(const TWeakObjectPtr<UDelMarTrackSplineComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActiveTrack(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActiveTrackSplineComponent(const TWeakObjectPtr<UDelMarTrackSplineComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OobTubePositionalRenderingComponent(const TWeakObjectPtr<UDelMarTrackOobTubePositionalRenderingComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackOobTubePositionalRenderingComponent*>>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OffRoadDriveActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_KickflipTrack(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xd0
class UDelMarBTService_ResetVehicle : public UDelMarBTService_VehicleBase
{
public:
    float CancelResetMinRequiredDistance() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float CancelResetMaxRequiredDistance() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> PlayerRaceDataComponent() const { return Read<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CancelResetMinRequiredDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_CancelResetMaxRequiredDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_PlayerRaceDataComponent(const TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackPositionComponent(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xa70
class UDelMarBTTask_DriveTrack : public UDelMarBTTask_VehicleBase
{
public:
    FBlackboardKeySelector TargetTrackDecisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalLocationKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalRotationKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsJumpDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsOffRoadDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsKickflipDriveGoalKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector KickflipDirectionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector HasUpcomingCollisionKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    FDelMarScaledCurve GroundedTrackHorizontalOffsetSteerCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AirTrackHorizontalOffsetSteerCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve CollisionAvoidanceHorizontalOffsetSteerCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AirCollisionAvoidanceHorizontalSteerDecisionCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve GroundedTurnDegreesSteerDecisionCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AirTurnDegreesSteerDecisionCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve CollisionTurnDegreesSteerDecisionCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x90, Type: StructProperty)
    float DriveThrottle() const { return Read<float>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x4, Type: FloatProperty)
    bool bCanKickDrift() const { return Read<bool>(uintptr_t(this) + 0x5d4); } // 0x5d4 (Size: 0x1, Type: BoolProperty)
    int32_t NumberOfDriftCheckSamples() const { return Read<int32_t>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x4, Type: IntProperty)
    float MinDriftSampleDistanceScaleFactor() const { return Read<float>(uintptr_t(this) + 0x5dc); } // 0x5dc (Size: 0x4, Type: FloatProperty)
    float MaxDriftSampleDistanceScaleFactor() const { return Read<float>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x4, Type: FloatProperty)
    float MinExitDriftSampleDistanceFromVehicle() const { return Read<float>(uintptr_t(this) + 0x5e4); } // 0x5e4 (Size: 0x4, Type: FloatProperty)
    float MaxExitDriftSampleDistanceFromVehicle() const { return Read<float>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x4, Type: FloatProperty)
    float MinRequiredDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x5ec); } // 0x5ec (Size: 0x4, Type: FloatProperty)
    float MaxRequiredDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x4, Type: FloatProperty)
    float MinRequiredKickDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x5f4); } // 0x5f4 (Size: 0x4, Type: FloatProperty)
    float MaxRequiredKickDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x4, Type: FloatProperty)
    float MinSecondsToUpdateRandomDriftConfigValues() const { return Read<float>(uintptr_t(this) + 0x5fc); } // 0x5fc (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve PercentChanceToKickDriftCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x90, Type: StructProperty)
    float MinDriftSlipRatioForExitKickDrift() const { return Read<float>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x4, Type: FloatProperty)
    float MinDriftSpeed() const { return Read<float>(uintptr_t(this) + 0x694); } // 0x694 (Size: 0x4, Type: FloatProperty)
    float DriftKickUnderSteerDegreesThreshold() const { return Read<float>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x4, Type: FloatProperty)
    float DriftKickOverSteerDegreesThreshold() const { return Read<float>(uintptr_t(this) + 0x69c); } // 0x69c (Size: 0x4, Type: FloatProperty)
    float DriftTapUnderSteerDegreesThreshold() const { return Read<float>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x4, Type: FloatProperty)
    float DriftTapOverSteerDegreesThreshold() const { return Read<float>(uintptr_t(this) + 0x6a4); } // 0x6a4 (Size: 0x4, Type: FloatProperty)
    float DriftCounterSteerDegreesThreshold() const { return Read<float>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve MinDriftSlipRatioCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DistanceBetweenDriftSamplesCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DriftSampleDistanceFromVehicleCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x7d0); } // 0x7d0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DriveGoalJumpHeightThresholdCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x860); } // 0x860 (Size: 0x90, Type: StructProperty)
    float JumpGoalTrackAngleDistanceOffset() const { return Read<float>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x4, Type: FloatProperty)
    float JumpMinSpeed() const { return Read<float>(uintptr_t(this) + 0x8f4); } // 0x8f4 (Size: 0x4, Type: FloatProperty)
    float MinimumUnderthrustPitch() const { return Read<float>(uintptr_t(this) + 0x8f8); } // 0x8f8 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve AirPitchAdjustmentCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x900); } // 0x900 (Size: 0x90, Type: StructProperty)
    float AirPitchAdjustmentMaxVerticalDegrees() const { return Read<float>(uintptr_t(this) + 0x990); } // 0x990 (Size: 0x4, Type: FloatProperty)
    float MinNumTurboChargesNeededToTurbo() const { return Read<float>(uintptr_t(this) + 0x994); } // 0x994 (Size: 0x4, Type: FloatProperty)
    float MaxTurboTrackCutoffAngleInDegrees() const { return Read<float>(uintptr_t(this) + 0x998); } // 0x998 (Size: 0x4, Type: FloatProperty)
    float TurboActivationBaseChance() const { return Read<float>(uintptr_t(this) + 0x99c); } // 0x99c (Size: 0x4, Type: FloatProperty)
    float SecondaryTurboBoostChance() const { return Read<float>(uintptr_t(this) + 0x9a0); } // 0x9a0 (Size: 0x4, Type: FloatProperty)
    float MinTimeBetweenTurboCheck() const { return Read<float>(uintptr_t(this) + 0x9a4); } // 0x9a4 (Size: 0x4, Type: FloatProperty)
    float MaxTimeBetweenTurboCheck() const { return Read<float>(uintptr_t(this) + 0x9a8); } // 0x9a8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x9ac); } // 0x9ac (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> TargetTrack() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x9b4); } // 0x9b4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> TargetTrackSplineComponent() const { return Read<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x9bc); } // 0x9bc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UBlackboardComponent*> BlackboardComponent() const { return Read<TWeakObjectPtr<UBlackboardComponent*>>(uintptr_t(this) + 0x9c4); } // 0x9c4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TargetTrackDecisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_DriveGoalLocationKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_DriveGoalRotationKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
    void SET_IsJumpDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x28, Type: StructProperty)
    void SET_IsOffRoadDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x28, Type: StructProperty)
    void SET_IsKickflipDriveGoalKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x28, Type: StructProperty)
    void SET_KickflipDirectionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x28, Type: StructProperty)
    void SET_HasUpcomingCollisionKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x28, Type: StructProperty)
    void SET_GroundedTrackHorizontalOffsetSteerCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x90, Type: StructProperty)
    void SET_AirTrackHorizontalOffsetSteerCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x90, Type: StructProperty)
    void SET_CollisionAvoidanceHorizontalOffsetSteerCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x90, Type: StructProperty)
    void SET_AirCollisionAvoidanceHorizontalSteerDecisionCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x90, Type: StructProperty)
    void SET_GroundedTurnDegreesSteerDecisionCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x90, Type: StructProperty)
    void SET_AirTurnDegreesSteerDecisionCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x90, Type: StructProperty)
    void SET_CollisionTurnDegreesSteerDecisionCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x90, Type: StructProperty)
    void SET_DriveThrottle(const float& Value) { Write<float>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x4, Type: FloatProperty)
    void SET_bCanKickDrift(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d4, Value); } // 0x5d4 (Size: 0x1, Type: BoolProperty)
    void SET_NumberOfDriftCheckSamples(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x4, Type: IntProperty)
    void SET_MinDriftSampleDistanceScaleFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x5dc, Value); } // 0x5dc (Size: 0x4, Type: FloatProperty)
    void SET_MaxDriftSampleDistanceScaleFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x4, Type: FloatProperty)
    void SET_MinExitDriftSampleDistanceFromVehicle(const float& Value) { Write<float>(uintptr_t(this) + 0x5e4, Value); } // 0x5e4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxExitDriftSampleDistanceFromVehicle(const float& Value) { Write<float>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x4, Type: FloatProperty)
    void SET_MinRequiredDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x5ec, Value); } // 0x5ec (Size: 0x4, Type: FloatProperty)
    void SET_MaxRequiredDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x4, Type: FloatProperty)
    void SET_MinRequiredKickDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x5f4, Value); } // 0x5f4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRequiredKickDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x4, Type: FloatProperty)
    void SET_MinSecondsToUpdateRandomDriftConfigValues(const float& Value) { Write<float>(uintptr_t(this) + 0x5fc, Value); } // 0x5fc (Size: 0x4, Type: FloatProperty)
    void SET_PercentChanceToKickDriftCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x90, Type: StructProperty)
    void SET_MinDriftSlipRatioForExitKickDrift(const float& Value) { Write<float>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x4, Type: FloatProperty)
    void SET_MinDriftSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x694, Value); } // 0x694 (Size: 0x4, Type: FloatProperty)
    void SET_DriftKickUnderSteerDegreesThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x4, Type: FloatProperty)
    void SET_DriftKickOverSteerDegreesThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x69c, Value); } // 0x69c (Size: 0x4, Type: FloatProperty)
    void SET_DriftTapUnderSteerDegreesThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x4, Type: FloatProperty)
    void SET_DriftTapOverSteerDegreesThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x6a4, Value); } // 0x6a4 (Size: 0x4, Type: FloatProperty)
    void SET_DriftCounterSteerDegreesThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x4, Type: FloatProperty)
    void SET_MinDriftSlipRatioCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x90, Type: StructProperty)
    void SET_DistanceBetweenDriftSamplesCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x90, Type: StructProperty)
    void SET_DriftSampleDistanceFromVehicleCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x7d0, Value); } // 0x7d0 (Size: 0x90, Type: StructProperty)
    void SET_DriveGoalJumpHeightThresholdCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x860, Value); } // 0x860 (Size: 0x90, Type: StructProperty)
    void SET_JumpGoalTrackAngleDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x4, Type: FloatProperty)
    void SET_JumpMinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8f4, Value); } // 0x8f4 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumUnderthrustPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x8f8, Value); } // 0x8f8 (Size: 0x4, Type: FloatProperty)
    void SET_AirPitchAdjustmentCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x900, Value); } // 0x900 (Size: 0x90, Type: StructProperty)
    void SET_AirPitchAdjustmentMaxVerticalDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x990, Value); } // 0x990 (Size: 0x4, Type: FloatProperty)
    void SET_MinNumTurboChargesNeededToTurbo(const float& Value) { Write<float>(uintptr_t(this) + 0x994, Value); } // 0x994 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTurboTrackCutoffAngleInDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x998, Value); } // 0x998 (Size: 0x4, Type: FloatProperty)
    void SET_TurboActivationBaseChance(const float& Value) { Write<float>(uintptr_t(this) + 0x99c, Value); } // 0x99c (Size: 0x4, Type: FloatProperty)
    void SET_SecondaryTurboBoostChance(const float& Value) { Write<float>(uintptr_t(this) + 0x9a0, Value); } // 0x9a0 (Size: 0x4, Type: FloatProperty)
    void SET_MinTimeBetweenTurboCheck(const float& Value) { Write<float>(uintptr_t(this) + 0x9a4, Value); } // 0x9a4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTimeBetweenTurboCheck(const float& Value) { Write<float>(uintptr_t(this) + 0x9a8, Value); } // 0x9a8 (Size: 0x4, Type: FloatProperty)
    void SET_TrackPositionComponent(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x9ac, Value); } // 0x9ac (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetTrack(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x9b4, Value); } // 0x9b4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetTrackSplineComponent(const TWeakObjectPtr<UDelMarTrackSplineComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x9bc, Value); } // 0x9bc (Size: 0x8, Type: WeakObjectProperty)
    void SET_BlackboardComponent(const TWeakObjectPtr<UBlackboardComponent*>& Value) { Write<TWeakObjectPtr<UBlackboardComponent*>>(uintptr_t(this) + 0x9c4, Value); } // 0x9c4 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xa0
class UDelMarBTTask_VehicleBase : public UBTTaskNode
{
public:
    FBlackboardKeySelector VehicleKey() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)

    void SET_VehicleKey(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_DelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xb8
class UDelMarBTTask_RaceCountdown : public UDelMarBTTask_VehicleBase
{
public:
    float MaxReactionTime() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float MinReactionTime() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)

    void SET_MaxReactionTime(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_MinReactionTime(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc0
class UDelMarCameraModeOverrideComponent : public UFortCameraModeOverrideComponent
{
public:
};

// Size: 0xf0
class UDelMarChallengeGhostSystemControllerComponent : public UControllerComponent
{
public:
    UClass* GhostPlaybackSessionComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    UClass* GhostRecordingSessionComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    double BestRunTime() const { return Read<double>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    TWeakObjectPtr<UDelMarGhostPlaybackSessionComponent*> CachedPlaybackSession() const { return Read<TWeakObjectPtr<UDelMarGhostPlaybackSessionComponent*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarGhostRecordingSessionComponent*> CachedRecordingSession() const { return Read<TWeakObjectPtr<UDelMarGhostRecordingSessionComponent*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarChallengeRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarChallengeRaceManager*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedLocalPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_GhostPlaybackSessionComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_GhostRecordingSessionComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_BestRunTime(const double& Value) { Write<double>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    void SET_CachedPlaybackSession(const TWeakObjectPtr<UDelMarGhostPlaybackSessionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarGhostPlaybackSessionComponent*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRecordingSession(const TWeakObjectPtr<UDelMarGhostRecordingSessionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarGhostRecordingSessionComponent*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarChallengeRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarChallengeRaceManager*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedLocalPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x4f0
class ADelMarChallengeRaceManager : public ADelMarRaceManager
{
public:
    bool bIsOvertime() const { return Read<bool>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    FTimerHandle OvertimeTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: StructProperty)

    void SET_bIsOvertime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    void SET_OvertimeTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x30
class UDelMarChallengeRacerState_RunActive : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

// Size: 0x1c0
class UDelMarStateMachine : public UActorComponent
{
public:
    TArray<FDelMarStateOverride> StateOverrides() const { return Read<TArray<FDelMarStateOverride>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TMap<FGameplayTag, UClass*> StateMappings() const { return Read<TMap<FGameplayTag, UClass*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x50, Type: MapProperty)
    FGameplayTag RequestedStateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: StructProperty)
    FGameplayTag CurrentStateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: StructProperty)
    FGameplayTag DefaultStateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: StructProperty)
    TArray<UDelMarState*> ActiveStates() const { return Read<TArray<UDelMarState*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarState*> ReplicatedStates() const { return Read<TArray<UDelMarState*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag WaitingForStateReplicationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: StructProperty)

    void SET_StateOverrides(const TArray<FDelMarStateOverride>& Value) { Write<TArray<FDelMarStateOverride>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_StateMappings(const TMap<FGameplayTag, UClass*>& Value) { Write<TMap<FGameplayTag, UClass*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x50, Type: MapProperty)
    void SET_RequestedStateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: StructProperty)
    void SET_CurrentStateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: StructProperty)
    void SET_DefaultStateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: StructProperty)
    void SET_ActiveStates(const TArray<UDelMarState*>& Value) { Write<TArray<UDelMarState*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedStates(const TArray<UDelMarState*>& Value) { Write<TArray<UDelMarState*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    void SET_WaitingForStateReplicationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: StructProperty)
};

// Size: 0x30
class UDelMarRacerState_WithSpectatorTransitionBase : public UDelMarRacerState
{
public:
};

// Size: 0x30
class UDelMarRacerState : public UDelMarState
{
public:
};

// Size: 0x30
class UDelMarState : public UObject
{
public:
    FGameplayTag StateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)

    void SET_StateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
};

// Size: 0x1f0
class UDelMarChallengeRacerStateMachineComponent : public UDelMarRacerStateMachineComponent
{
public:
};

// Size: 0x1f0
class UDelMarRacerStateMachineComponent : public UDelMarStateMachine
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag PreviousStateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: StructProperty)

    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PreviousStateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x118
class UDelMarChallengeSpectatorControllerComponent : public UDelMarSpectatorControllerComponent
{
public:
};

// Size: 0x118
class UDelMarSpectatorControllerComponent : public UControllerComponent
{
public:
    UInputAction* SpectateNextPlayerAction() const { return Read<UInputAction*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UInputAction* SpectatePrevPlayerAction() const { return Read<UInputAction*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ExitSpectateAction() const { return Read<UInputAction*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UClass* InputManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent() const { return Read<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRequestComponent*> SpectatorRequestComponent() const { return Read<TWeakObjectPtr<UDelMarRequestComponent*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CurrentViewTarget() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PrevValidViewTarget() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> SpectatorPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerControllerZone*> SpectatorController() const { return Read<TWeakObjectPtr<AFortPlayerControllerZone*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    bool bIsLateJoinSpectator() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)

    void SET_SpectateNextPlayerAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpectatePrevPlayerAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExitSpectateAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_InputManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_InputComponent(const TWeakObjectPtr<UEnhancedInputComponent*>& Value) { Write<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SpectatorRequestComponent(const TWeakObjectPtr<UDelMarRequestComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRequestComponent*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentViewTarget(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PrevValidViewTarget(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SpectatorPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SpectatorController(const TWeakObjectPtr<AFortPlayerControllerZone*>& Value) { Write<TWeakObjectPtr<AFortPlayerControllerZone*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bIsLateJoinSpectator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1a0
class UDelMarChallengeTimeManagerComponent : public UDelMarTimeManagerComponent
{
public:
    TSet<TWeakObjectPtr<AFortPlayerState*>> SubsequentRunStartSet() const { return Read<TSet<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x50, Type: SetProperty)

    void SET_SubsequentRunStartSet(const TSet<TWeakObjectPtr<AFortPlayerState*>>& Value) { Write<TSet<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x50, Type: SetProperty)
};

// Size: 0x150
class UDelMarTimeManagerComponent : public UDelMarRaceManagerComponent
{
public:
    double ServerCountdownStartTime() const { return Read<double>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    double ServerRaceStartTime() const { return Read<double>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
    double ServerRaceFinishTime() const { return Read<double>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double ServerCountdownIntervalTime() const { return Read<double>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    TWeakObjectPtr<UDelMarRaceConfigComponent*> RaceConfig() const { return Read<TWeakObjectPtr<UDelMarRaceConfigComponent*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceLevelConfig*> RaceLevelConfig() const { return Read<TWeakObjectPtr<ADelMarRaceLevelConfig*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    TMap<TWeakObjectPtr<AFortPlayerState*>, double> ActiveCountdownRunStartTimeMap() const { return Read<TMap<TWeakObjectPtr<AFortPlayerState*>, double>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x50, Type: MapProperty)

    void SET_ServerCountdownStartTime(const double& Value) { Write<double>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    void SET_ServerRaceStartTime(const double& Value) { Write<double>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
    void SET_ServerRaceFinishTime(const double& Value) { Write<double>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    void SET_ServerCountdownIntervalTime(const double& Value) { Write<double>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    void SET_RaceConfig(const TWeakObjectPtr<UDelMarRaceConfigComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRaceConfigComponent*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RaceLevelConfig(const TWeakObjectPtr<ADelMarRaceLevelConfig*>& Value) { Write<TWeakObjectPtr<ADelMarRaceLevelConfig*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActiveCountdownRunStartTimeMap(const TMap<TWeakObjectPtr<AFortPlayerState*>, double>& Value) { Write<TMap<TWeakObjectPtr<AFortPlayerState*>, double>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x50, Type: MapProperty)
};

// Size: 0xb8
class UDelMarRaceManagerComponent : public UGameFrameworkComponent
{
public:
};

// Size: 0x58
class UDelMarCheckpointTheme : public UPrimaryDataAsset
{
public:
    UStaticMesh* RimMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* DefaultTentMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* DefaultHoloMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* StartLineTentMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* StartLineHoloMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_RimMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultTentMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultHoloMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_StartLineTentMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_StartLineHoloMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
class UDelMarClientReplayRecordingComponent : public UControllerComponent
{
public:
};

// Size: 0x4f8
class ADelMarCompetitiveRaceManager : public ADelMarRaceManager
{
public:
    float FinishRaceAfterFirstPlayerFinishedSeconds() const { return Read<float>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x4, Type: FloatProperty)
    double FirstPlayerFinishedTimestamp() const { return Read<double>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: DoubleProperty)

    void SET_FinishRaceAfterFirstPlayerFinishedSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x4, Type: FloatProperty)
    void SET_FirstPlayerFinishedTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x30
class UDelMarCompetitiveRacerState_RunActive : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

// Size: 0x30
class UDelMarCompetitiveRacerState_RunFinished : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

// Size: 0x1f0
class UDelMarCompetitiveRacerStateMachineComponent : public UDelMarRacerStateMachineComponent
{
public:
};

// Size: 0x108
class UDelMarConnectedHintComponent : public UActorComponent
{
public:
    bool bShouldShowHint() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    UClass* VehicleActionClass() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    bool bAcceptMultipleTags() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer MultipleTagContainer() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarVehicleAction* VehicleAction() const { return Read<UDelMarVehicleAction*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)

    void SET_bShouldShowHint(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_VehicleActionClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_bAcceptMultipleTags(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_MultipleTagContainer(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_VehicleAction(const UDelMarVehicleAction*& Value) { Write<UDelMarVehicleAction*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x130
class UDelMarCoreOobTubePositionalRenderingComponent : public UDelMarTrackOobTubePositionalRenderingComponent
{
public:
    TWeakObjectPtr<APlayerState*> ViewTargetPlayerState() const { return Read<TWeakObjectPtr<APlayerState*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ViewTargetPlayerState(const TWeakObjectPtr<APlayerState*>& Value) { Write<TWeakObjectPtr<APlayerState*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x740
class UDelMarCoreSplineMeshComponent : public USplineMeshComponent
{
public:
};

// Size: 0x50
class UDelMarCosmeticsDatabase : public UPrimaryDataAsset
{
public:
    TArray<UDelMarCosmeticItemDefinition*> Items() const { return Read<TArray<UDelMarCosmeticItemDefinition*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarCosmeticSlotInfo> SlotInfos() const { return Read<TArray<FDelMarCosmeticSlotInfo>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<UDelMarCosmeticItemDefinition*>& Value) { Write<TArray<UDelMarCosmeticItemDefinition*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_SlotInfos(const TArray<FDelMarCosmeticSlotInfo>& Value) { Write<TArray<FDelMarCosmeticSlotInfo>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UDelMarDeathRacerState_ActiveRace : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
    TWeakObjectPtr<ADelMarDeathRaceManager*> DeathRaceManager() const { return Read<TWeakObjectPtr<ADelMarDeathRaceManager*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    bool bFinishedRound() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_DeathRaceManager(const TWeakObjectPtr<ADelMarDeathRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarDeathRaceManager*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bFinishedRound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UDelMarDeathRacerState_FinishedRace : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

// Size: 0x1f0
class UDelMarDeathRacerStateMachineComponent : public UDelMarRacerStateMachineComponent
{
public:
};

// Size: 0x60
class UDelMarDoubleTapInputTrigger : public UInputTrigger
{
public:
    float Delay() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_Delay(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
class UDelMarDriveParticlesPhysMatAttribute : public UDelMarPhysMatAttribute
{
public:
    UNiagaraSystem* DriveParticles() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_DriveParticles(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UDelMarPhysMatAttribute : public UObject
{
public:
};

// Size: 0x110
class UDelMarDriverInteractionComponent : public UControllerComponent
{
public:
    AFortPlayerState* ViewPlayerState() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* ViewVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    float PassEventSquareDistThreshold() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    UDelMarPlayerRaceDataComponent* RaceData() const { return Read<UDelMarPlayerRaceDataComponent*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)

    void SET_ViewPlayerState(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_PassEventSquareDistThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_RaceData(const UDelMarPlayerRaceDataComponent*& Value) { Write<UDelMarPlayerRaceDataComponent*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x330
class ADelMarEnvironmentEffectCueNotify_Actor : public AGameplayCueNotify_Actor
{
public:
    FDelMarEnvironmentVFX Effects() const { return Read<FDelMarEnvironmentVFX>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x18, Type: StructProperty)
    bool bShowOnAllClients() const { return Read<bool>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x1, Type: BoolProperty)

    void SET_Effects(const FDelMarEnvironmentVFX& Value) { Write<FDelMarEnvironmentVFX>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x18, Type: StructProperty)
    void SET_bShowOnAllClients(const bool& Value) { Write<bool>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x308
class ADelMarEnvironmentEffectsVolume : public AActor
{
public:
    UClass* AppliedEffect() const { return Read<UClass*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ClassProperty)
    UBoxComponent* BoxCollider() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_AppliedEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ClassProperty)
    void SET_BoxCollider(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UDelMarEvent_GlobalLeaderboardActive : public UObject
{
public:
    FString LeaderboardEventId() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString LeaderboardWindowId() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)

    void SET_LeaderboardEventId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_LeaderboardWindowId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
};

// Size: 0xd0
class UDelMarFlowAnalyticsControllerComponent : public UControllerComponent
{
public:
    FString FlowAnalyicsEventName() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<AFortPlayerController*> PlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_FlowAnalyicsEventName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
    void SET_PlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x130
class UDelMarGameAnalyticsComponent : public UGameStateComponent
{
public:
    TWeakObjectPtr<AFortGameState*> CachedGameState() const { return Read<TWeakObjectPtr<AFortGameState*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TMap<EDelMarRaceMode, FGameplayTagContainer> TrackQuestUsageRaceModes() const { return Read<TMap<EDelMarRaceMode, FGameplayTagContainer>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<AFortPlayerState*>> CachedOpenedQuestPlayers() const { return Read<TArray<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedGameState(const TWeakObjectPtr<AFortGameState*>& Value) { Write<TWeakObjectPtr<AFortGameState*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackQuestUsageRaceModes(const TMap<EDelMarRaceMode, FGameplayTagContainer>& Value) { Write<TMap<EDelMarRaceMode, FGameplayTagContainer>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
    void SET_CachedOpenedQuestPlayers(const TArray<TWeakObjectPtr<AFortPlayerState*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
class UDelMarGameplayState : public UDelMarState
{
public:
};

// Size: 0x40
class UDelMarGameUserSettings : public UObject
{
public:
    int32_t NuxLastViewedVideoVersion() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    bool bNuxHasPromptedToPlayTutorial() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)
    bool bHasPromptedToPlaySpeedRun() const { return Read<bool>(uintptr_t(this) + 0x2d); } // 0x2d (Size: 0x1, Type: BoolProperty)
    bool bNuxHasShownDefaultMode() const { return Read<bool>(uintptr_t(this) + 0x2e); } // 0x2e (Size: 0x1, Type: BoolProperty)
    FString LastPlayedDelMarMnemonic() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)

    void SET_NuxLastViewedVideoVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_bNuxHasPromptedToPlayTutorial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
    void SET_bHasPromptedToPlaySpeedRun(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d, Value); } // 0x2d (Size: 0x1, Type: BoolProperty)
    void SET_bNuxHasShownDefaultMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e, Value); } // 0x2e (Size: 0x1, Type: BoolProperty)
    void SET_LastPlayedDelMarMnemonic(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
};

// Size: 0x110
class UDelMarGhostPlaybackSessionComponent : public UDelMarGhostSessionComponent
{
public:
    uint8_t TeleportSetting() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    UClass* PlaybackActorClass() const { return Read<UClass*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ClassProperty)
    int32_t CurrentFrame() const { return Read<int32_t>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: IntProperty)
    UDelMarGhostReplayLog* PlaybackLog() const { return Read<UDelMarGhostReplayLog*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    AFortPhysicsPawn* PlaybackActor() const { return Read<AFortPhysicsPawn*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)

    void SET_TeleportSetting(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    void SET_PlaybackActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ClassProperty)
    void SET_CurrentFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: IntProperty)
    void SET_PlaybackLog(const UDelMarGhostReplayLog*& Value) { Write<UDelMarGhostReplayLog*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaybackActor(const AFortPhysicsPawn*& Value) { Write<AFortPhysicsPawn*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UDelMarGhostSessionComponent : public UControllerComponent
{
public:
};

// Size: 0x2d8
class ADelMarGhostPlaybackTrigger : public AActor
{
public:
    int32_t PreviewFrame() const { return Read<int32_t>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: IntProperty)
    int32_t StartFrame() const { return Read<int32_t>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: IntProperty)
    int32_t EndFrame() const { return Read<int32_t>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: IntProperty)
    int32_t MaxFrame() const { return Read<int32_t>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: IntProperty)
    UDelMarGhostReplayLog* PlaybackLog() const { return Read<UDelMarGhostReplayLog*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* BoxCollider() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UClass* PlaybackSessionClassOverride() const { return Read<UClass*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ClassProperty)
    UDelMarGhostPlaybackSessionComponent* PlaybackSession() const { return Read<UDelMarGhostPlaybackSessionComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)

    void SET_PreviewFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: IntProperty)
    void SET_StartFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: IntProperty)
    void SET_EndFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: IntProperty)
    void SET_MaxFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: IntProperty)
    void SET_PlaybackLog(const UDelMarGhostReplayLog*& Value) { Write<UDelMarGhostReplayLog*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_BoxCollider(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaybackSessionClassOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ClassProperty)
    void SET_PlaybackSession(const UDelMarGhostPlaybackSessionComponent*& Value) { Write<UDelMarGhostPlaybackSessionComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x118
class UDelMarGhostRecordingSessionComponent : public UDelMarGhostSessionComponent
{
public:
    UDelMarGhostReplayLog* RecordLog() const { return Read<UDelMarGhostReplayLog*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    bool bRecordOffPhysicsDelegate() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    int32_t CurrentFrame() const { return Read<int32_t>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)

    void SET_RecordLog(const UDelMarGhostReplayLog*& Value) { Write<UDelMarGhostReplayLog*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_bRecordOffPhysicsDelegate(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: IntProperty)
    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x40
class UDelMarGhostReplayLog : public UObject
{
public:
    TArray<FGhostReplayFrame> Frames() const { return Read<TArray<FGhostReplayFrame>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Frames(const TArray<FGhostReplayFrame>& Value) { Write<TArray<FGhostReplayFrame>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x168
class UDelMarGlobalLeaderboardControllerComponent : public UControllerComponent
{
public:
    bool bIsLeaderboardEnabled() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    TArray<FDelMarGlobalLeaderboardEntry> TopLeaderboardEntries() const { return Read<TArray<FDelMarGlobalLeaderboardEntry>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarGlobalLeaderboardEntry> FocusedLeaderboardEntries() const { return Read<TArray<FDelMarGlobalLeaderboardEntry>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarGlobalLeaderboardEntry> FriendLeaderboardEntries() const { return Read<TArray<FDelMarGlobalLeaderboardEntry>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    bool bHasRequestedLeaderboards() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    bool bHasPersonalBest() const { return Read<bool>(uintptr_t(this) + 0xf1); } // 0xf1 (Size: 0x1, Type: BoolProperty)
    FDelMarGlobalLeaderboardEntry PersonalBest() const { return Read<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x40, Type: StructProperty)
    UDelMarEvent_GlobalLeaderboardActive* GlobalLeaderboardActiveEvent() const { return Read<UDelMarEvent_GlobalLeaderboardActive*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    FDelMarLeaderboardSettings LeaderboardSettings() const { return Read<FDelMarLeaderboardSettings>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x20, Type: StructProperty)

    void SET_bIsLeaderboardEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_TopLeaderboardEntries(const TArray<FDelMarGlobalLeaderboardEntry>& Value) { Write<TArray<FDelMarGlobalLeaderboardEntry>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusedLeaderboardEntries(const TArray<FDelMarGlobalLeaderboardEntry>& Value) { Write<TArray<FDelMarGlobalLeaderboardEntry>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_FriendLeaderboardEntries(const TArray<FDelMarGlobalLeaderboardEntry>& Value) { Write<TArray<FDelMarGlobalLeaderboardEntry>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasRequestedLeaderboards(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_bHasPersonalBest(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf1, Value); } // 0xf1 (Size: 0x1, Type: BoolProperty)
    void SET_PersonalBest(const FDelMarGlobalLeaderboardEntry& Value) { Write<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x40, Type: StructProperty)
    void SET_GlobalLeaderboardActiveEvent(const UDelMarEvent_GlobalLeaderboardActive*& Value) { Write<UDelMarEvent_GlobalLeaderboardActive*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderboardSettings(const FDelMarLeaderboardSettings& Value) { Write<FDelMarLeaderboardSettings>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UGuidedZoneRequirement : public UObject
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_Drift : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_DriftKick : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_Kickflip : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_Turbo : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_TurboBonusZone : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_Underthrust : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_Jump : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_JumpOrUnderthrust : public UGuidedZoneRequirement_Jump
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_DriftActive : public UGuidedZoneRequirement
{
public:
};

// Size: 0x28
class UGuidedZoneRequirement_DriftBoostActive : public UGuidedZoneRequirement
{
public:
};

// Size: 0x38
class UGuidedZoneRequirement_MidTutorial : public UGuidedZoneRequirement
{
public:
};

// Size: 0x3c0
class ADelMarGuidedTutorialZoneActor : public AActor
{
public:
    UBoxComponent* BoxCollider() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    float FinalTimeDilation() const { return Read<float>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    float TransitionSeconds() const { return Read<float>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    float MaxTimeDilationSeconds() const { return Read<float>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x4, Type: FloatProperty)
    bool bDemoVehicleOnFail() const { return Read<bool>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x1, Type: BoolProperty)
    FDelMarEvent_SetTutorialAnnouncement ScreenMessage() const { return Read<FDelMarEvent_SetTutorialAnnouncement>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x40, Type: StructProperty)
    float HintDelaySeconds() const { return Read<float>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: FloatProperty)
    float HintRemovalDelaySeconds() const { return Read<float>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x4, Type: FloatProperty)
    UClass* ZoneRequirementClass() const { return Read<UClass*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer InputTagsToRemoveOnZoneStart() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InputTagsToAddOnZoneStart() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InputTagsToRemoveOnZoneEnd() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InputTagsToAddOnZoneEnd() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x20, Type: StructProperty)
    UGuidedZoneRequirement* ZoneRequirement() const { return Read<UGuidedZoneRequirement*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> ActiveVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> ActivePlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_BoxCollider(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_FinalTimeDilation(const float& Value) { Write<float>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    void SET_TransitionSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTimeDilationSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x4, Type: FloatProperty)
    void SET_bDemoVehicleOnFail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x1, Type: BoolProperty)
    void SET_ScreenMessage(const FDelMarEvent_SetTutorialAnnouncement& Value) { Write<FDelMarEvent_SetTutorialAnnouncement>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x40, Type: StructProperty)
    void SET_HintDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: FloatProperty)
    void SET_HintRemovalDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x4, Type: FloatProperty)
    void SET_ZoneRequirementClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ClassProperty)
    void SET_InputTagsToRemoveOnZoneStart(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x20, Type: StructProperty)
    void SET_InputTagsToAddOnZoneStart(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x20, Type: StructProperty)
    void SET_InputTagsToRemoveOnZoneEnd(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x20, Type: StructProperty)
    void SET_InputTagsToAddOnZoneEnd(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x20, Type: StructProperty)
    void SET_ZoneRequirement(const UGuidedZoneRequirement*& Value) { Write<UGuidedZoneRequirement*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActiveVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActivePlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2e8
class ADelMarInputModifierHazard : public AActor
{
public:
    TArray<FDelMarActivatedInputFrame> ActivatedInputSequence() const { return Read<TArray<FDelMarActivatedInputFrame>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarDisabledInputData> DisabledEffects() const { return Read<TArray<FDelMarDisabledInputData>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    UBoxComponent* BoxCollider() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    APlayerController* LocalController() const { return Read<APlayerController*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UEnhancedPlayerInput* LocalPlayerInput() const { return Read<UEnhancedPlayerInput*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    float StartOverlapTime() const { return Read<float>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
    float TotalActivationSequenceTime() const { return Read<float>(uintptr_t(this) + 0x2e4); } // 0x2e4 (Size: 0x4, Type: FloatProperty)

    void SET_ActivatedInputSequence(const TArray<FDelMarActivatedInputFrame>& Value) { Write<TArray<FDelMarActivatedInputFrame>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_DisabledEffects(const TArray<FDelMarDisabledInputData>& Value) { Write<TArray<FDelMarDisabledInputData>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    void SET_BoxCollider(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalPlayerInput(const UEnhancedPlayerInput*& Value) { Write<UEnhancedPlayerInput*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_StartOverlapTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
    void SET_TotalActivationSequenceTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2e4, Value); } // 0x2e4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
class UDelMarLevelDataAsset : public UPrimaryDataAsset
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    FText LevelDescription() const { return Read<FText>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> LevelBackgroundImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TArray<TSoftObjectPtr<UWorld*>> Levels() const { return Read<TArray<TSoftObjectPtr<UWorld*>>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UDataLayerAsset*>> WorldPartitionDataLayers() const { return Read<TArray<TSoftObjectPtr<UDataLayerAsset*>>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer LevelDescriptionTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x20, Type: StructProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_LevelDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: TextProperty)
    void SET_LevelBackgroundImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Levels(const TArray<TSoftObjectPtr<UWorld*>>& Value) { Write<TArray<TSoftObjectPtr<UWorld*>>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_WorldPartitionDataLayers(const TArray<TSoftObjectPtr<UDataLayerAsset*>>& Value) { Write<TArray<TSoftObjectPtr<UDataLayerAsset*>>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_LevelDescriptionTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x20, Type: StructProperty)
};

// Size: 0x78
class UDelMarLoadoutSave : public USaveGame
{
public:
    TMap<FGameplayTag, TSoftObjectPtr<UDelMarCosmeticItemDefinition*>> EquippedLoadout() const { return Read<TMap<FGameplayTag, TSoftObjectPtr<UDelMarCosmeticItemDefinition*>>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_EquippedLoadout(const TMap<FGameplayTag, TSoftObjectPtr<UDelMarCosmeticItemDefinition*>>& Value) { Write<TMap<FGameplayTag, TSoftObjectPtr<UDelMarCosmeticItemDefinition*>>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x120
class UDelMarMatchEventSystemComponent : public UDelMarRaceManagerComponent
{
public:
    TSet<FGameplayTag> EnabledMatchEventTags() const { return Read<TSet<FGameplayTag>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: SetProperty)

    void SET_EnabledMatchEventTags(const TSet<FGameplayTag>& Value) { Write<TSet<FGameplayTag>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: SetProperty)
};

// Size: 0x38
class UDelMarNetModelSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0x3c0
class ADelMarNetworkPredictionMutator : public ADelMarMutator
{
public:
};

// Size: 0x368
class ADelMarMutator : public AFortAthenaMutator
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessorBase : public UFortObjectiveProcessor
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_BeatPlayers : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_BonusTurboActivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_BoostPadBonusSpeedEnded : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_BoostPadHit : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_Demolished : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_DistanceTraveled : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_DraftActivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_DriftBoostActivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_DriftBoostDeactivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_DriftComplete : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_HighestSpeedUpdated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_InitialTurboActivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_JellyHit : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_Kickflipped : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_LapComplete : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_LapStarted : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_PlacementUpdated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_PlayedDelMarExperience : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_RaceFinished : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_RankAchieved : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_RunComplete : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_StartlineBoostActivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_StartlineBoostPercentEarned : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_UnderthrustDeactivated : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_UnderthrustPercentUsed : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_VehicleJumped : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0x98
class UDelMarObjectiveProcessor_VehicleLanded : public UDelMarObjectiveProcessorBase
{
public:
};

// Size: 0xf0
class UDelMarPedestrianComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPreRaceControllerComponent*> PreRaceControllerComponent() const { return Read<TWeakObjectPtr<UDelMarPreRaceControllerComponent*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    bool bAllowExitVehicle() const { return Read<bool>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bPlayerIsPedestrian() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)

    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PreRaceControllerComponent(const TWeakObjectPtr<UDelMarPreRaceControllerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPreRaceControllerComponent*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bAllowExitVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayerIsPedestrian(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc60
class ADelMarPhysicsRateDevice : public AFortCreativeDeviceProp
{
public:
};

// Size: 0x30
class UDelMarPhysMatAttribute_SoundTag : public UDelMarPhysMatAttribute
{
public:
    FName SoundTag() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)

    void SET_SoundTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
};

// Size: 0x48
class UDelMarPhysMatAttribute_Terrain : public UDelMarPhysMatAttribute
{
public:
    FDelMarTerrainData TerrainData() const { return Read<FDelMarTerrainData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    bool bDriveableSurface() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)

    void SET_TerrainData(const FDelMarTerrainData& Value) { Write<FDelMarTerrainData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_bDriveableSurface(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd8
class UDelMarPlayerActiveRaceManagerComponent : public UDelMarPlayerStateComponent
{
public:
    ADelMarRaceManager* ActiveRaceManager() const { return Read<ADelMarRaceManager*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_ActiveRaceManager(const ADelMarRaceManager*& Value) { Write<ADelMarRaceManager*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1b8
class UDelMarPlayerAnalyticsComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> CachedPlayerRaceData() const { return Read<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRaceInfoComponent*> CachedRaceInfo() const { return Read<TWeakObjectPtr<UDelMarRaceInfoComponent*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> CachedPositionalTracker() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*> MatchmakeRatingComponent() const { return Read<TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    FDelMarAnalyticsPlayerRaceData CurrentRaceData() const { return Read<FDelMarAnalyticsPlayerRaceData>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x40, Type: StructProperty)
    FDelMarAnalyticsPlayerRaceData CurrentRunData() const { return Read<FDelMarAnalyticsPlayerRaceData>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x40, Type: StructProperty)

    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPlayerRaceData(const TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceInfo(const TWeakObjectPtr<UDelMarRaceInfoComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRaceInfoComponent*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPositionalTracker(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MatchmakeRatingComponent(const TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*>& Value) { Write<TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentRaceData(const FDelMarAnalyticsPlayerRaceData& Value) { Write<FDelMarAnalyticsPlayerRaceData>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x40, Type: StructProperty)
    void SET_CurrentRunData(const FDelMarAnalyticsPlayerRaceData& Value) { Write<FDelMarAnalyticsPlayerRaceData>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x40, Type: StructProperty)
};

// Size: 0x278
class UDelMarPlayerChallengeRaceDataComponent : public UDelMarPlayerRaceDataComponent
{
public:
};

// Size: 0x108
class UDelMarPlayerQuestDistanceTraveledComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    FTimerHandle DistanceTraveledTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<UDelMarObjectiveProcessor_DistanceTraveled*> DistanceTravelledObjectiveProcessor() const { return Read<TWeakObjectPtr<UDelMarObjectiveProcessor_DistanceTraveled*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_DistanceTraveledTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: StructProperty)
    void SET_DistanceTravelledObjectiveProcessor(const TWeakObjectPtr<UDelMarObjectiveProcessor_DistanceTraveled*>& Value) { Write<TWeakObjectPtr<UDelMarObjectiveProcessor_DistanceTraveled*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xd8
class UDelMarPlayerQuestMatchInfoComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x140
class UDelMarPlayerWrongwayComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> CachedTrackPositionComp() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> CachedRaceData() const { return Read<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager() const { return Read<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackManager*> CachedTrackManager() const { return Read<TWeakObjectPtr<UDelMarTrackManager*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedTrackPositionComp(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceData(const TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedCheckpointManager(const TWeakObjectPtr<UDelMarCheckpointManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedTrackManager(const TWeakObjectPtr<UDelMarTrackManager*>& Value) { Write<TWeakObjectPtr<UDelMarTrackManager*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x210
class UDelMarPlayspaceComponent_ServerExpiration : public UPlayspaceComponent_ServerExpiration
{
public:
};

// Size: 0x120
class UDelMarProxyGhostVisualComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<AFortAthenaVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<AFortAthenaVehicle*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UVehicleCosmeticsAssembledMeshUserComponent*> CachedVCAMUC() const { return Read<TWeakObjectPtr<UVehicleCosmeticsAssembledMeshUserComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    UMaterialInterface* ProxyGhostMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayTag, FDelMarProxyMeshMaterialInfo> VehicleMaterialInfoMap() const { return Read<TMap<FGameplayTag, FDelMarProxyMeshMaterialInfo>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)

    void SET_CachedVehicle(const TWeakObjectPtr<AFortAthenaVehicle*>& Value) { Write<TWeakObjectPtr<AFortAthenaVehicle*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedVCAMUC(const TWeakObjectPtr<UVehicleCosmeticsAssembledMeshUserComponent*>& Value) { Write<TWeakObjectPtr<UVehicleCosmeticsAssembledMeshUserComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ProxyGhostMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_VehicleMaterialInfoMap(const TMap<FGameplayTag, FDelMarProxyMeshMaterialInfo>& Value) { Write<TMap<FGameplayTag, FDelMarProxyMeshMaterialInfo>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xc8
class UDelMarRaceInfoComponent : public UDelMarRaceManagerComponent
{
public:
    FString RaceGUID() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)

    void SET_RaceGUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
};

// Size: 0xcb0
class ADelMarRaceLevelConfig : public AFortCreativeDeviceProp
{
public:
    uint8_t RaceMode() const { return Read<uint8_t>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x1, Type: EnumProperty)
    int32_t DefaultNumRequiredLaps() const { return Read<int32_t>(uintptr_t(this) + 0xc14); } // 0xc14 (Size: 0x4, Type: IntProperty)
    int32_t NumVisibleNextCheckpoints() const { return Read<int32_t>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x4, Type: IntProperty)
    float ZKillOffsetDistanceFromLowestSplinePoint() const { return Read<float>(uintptr_t(this) + 0xc1c); } // 0xc1c (Size: 0x4, Type: FloatProperty)
    bool bShouldRunAsADelMarExperience() const { return Read<bool>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x1, Type: BoolProperty)
    int32_t OvertimeSeconds() const { return Read<int32_t>(uintptr_t(this) + 0xc24); } // 0xc24 (Size: 0x4, Type: IntProperty)
    bool bOverrideTurboChargeRegenRateSeconds() const { return Read<bool>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x1, Type: BoolProperty)
    float TurboChargeRegenRateSeconds() const { return Read<float>(uintptr_t(this) + 0xc2c); } // 0xc2c (Size: 0x4, Type: FloatProperty)
    bool bOverrideTurboRaceStartCharges() const { return Read<bool>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x1, Type: BoolProperty)
    float TurboRaceStartCharges() const { return Read<float>(uintptr_t(this) + 0xc34); } // 0xc34 (Size: 0x4, Type: FloatProperty)
    bool bOverrideTurboLapCompleteCharges() const { return Read<bool>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x1, Type: BoolProperty)
    float TurboLapCompleteCharges() const { return Read<float>(uintptr_t(this) + 0xc3c); } // 0xc3c (Size: 0x4, Type: FloatProperty)
    bool bNonTrackVelocityRedirectEnabled() const { return Read<bool>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x1, Type: BoolProperty)
    FGameplayTag LevelTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc44); } // 0xc44 (Size: 0x4, Type: StructProperty)
    bool bHasMatchTimeLimit() const { return Read<bool>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x1, Type: BoolProperty)
    int32_t MatchTimeLimitSeconds() const { return Read<int32_t>(uintptr_t(this) + 0xc4c); } // 0xc4c (Size: 0x4, Type: IntProperty)
    TMap<EDelMarRaceMode, UClass*> RaceManagerClassMap() const { return Read<TMap<EDelMarRaceMode, UClass*>>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x50, Type: MapProperty)
    TArray<FDelMarRaceCVar> RaceCVars() const { return Read<TArray<FDelMarRaceCVar>>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x10, Type: ArrayProperty)

    void SET_RaceMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x1, Type: EnumProperty)
    void SET_DefaultNumRequiredLaps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc14, Value); } // 0xc14 (Size: 0x4, Type: IntProperty)
    void SET_NumVisibleNextCheckpoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x4, Type: IntProperty)
    void SET_ZKillOffsetDistanceFromLowestSplinePoint(const float& Value) { Write<float>(uintptr_t(this) + 0xc1c, Value); } // 0xc1c (Size: 0x4, Type: FloatProperty)
    void SET_bShouldRunAsADelMarExperience(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x1, Type: BoolProperty)
    void SET_OvertimeSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc24, Value); } // 0xc24 (Size: 0x4, Type: IntProperty)
    void SET_bOverrideTurboChargeRegenRateSeconds(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x1, Type: BoolProperty)
    void SET_TurboChargeRegenRateSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc2c, Value); } // 0xc2c (Size: 0x4, Type: FloatProperty)
    void SET_bOverrideTurboRaceStartCharges(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x1, Type: BoolProperty)
    void SET_TurboRaceStartCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xc34, Value); } // 0xc34 (Size: 0x4, Type: FloatProperty)
    void SET_bOverrideTurboLapCompleteCharges(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x1, Type: BoolProperty)
    void SET_TurboLapCompleteCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xc3c, Value); } // 0xc3c (Size: 0x4, Type: FloatProperty)
    void SET_bNonTrackVelocityRedirectEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x1, Type: BoolProperty)
    void SET_LevelTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc44, Value); } // 0xc44 (Size: 0x4, Type: StructProperty)
    void SET_bHasMatchTimeLimit(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x1, Type: BoolProperty)
    void SET_MatchTimeLimitSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc4c, Value); } // 0xc4c (Size: 0x4, Type: IntProperty)
    void SET_RaceManagerClassMap(const TMap<EDelMarRaceMode, UClass*>& Value) { Write<TMap<EDelMarRaceMode, UClass*>>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x50, Type: MapProperty)
    void SET_RaceCVars(const TArray<FDelMarRaceCVar>& Value) { Write<TArray<FDelMarRaceCVar>>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd8
class UDelMarRaceManagerVerbComponent : public UDelMarRaceManagerComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTracker() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<AFortPlayerState*> PrevRacePositions() const { return Read<TArray<AFortPlayerState*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PositionalTracker(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PrevRacePositions(const TArray<AFortPlayerState*>& Value) { Write<TArray<AFortPlayerState*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UDelMarRaceMusicPlaylist : public UPrimaryDataAsset
{
public:
    TArray<FDelMarMusicTrack> Tracks() const { return Read<TArray<FDelMarMusicTrack>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Tracks(const TArray<FDelMarMusicTrack>& Value) { Write<TArray<FDelMarMusicTrack>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb8
class UDelMarRaceMusicPlaylistComponent : public UActorComponent
{
public:
};

// Size: 0x30
class UDelMarRacerState_Spectator : public UDelMarRacerState
{
public:
};

// Size: 0x38
class UDelMarRacerState_Countdown : public UDelMarRacerState
{
public:
    TWeakObjectPtr<ADelMarVehicle*> Vehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Vehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x38
class UDelMarRacerState_RunFinished : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
    TWeakObjectPtr<ADelMarVehicle*> Vehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Vehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xd08
class ADelMarSpeedUpDevice : public AFortCreativeDeviceProp
{
public:
    float SpeedAmount() const { return Read<float>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x4, Type: FloatProperty)
    float SpeedEffectDuration() const { return Read<float>(uintptr_t(this) + 0xc14); } // 0xc14 (Size: 0x4, Type: FloatProperty)
    float TurboChargesGained() const { return Read<float>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x4, Type: FloatProperty)
    float MinDotProductAngleValue() const { return Read<float>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x4, Type: FloatProperty)
    FGameplayTag SpeedSourceTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc3c); } // 0xc3c (Size: 0x4, Type: StructProperty)
    bool bApplyForce() const { return Read<bool>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x1, Type: BoolProperty)
    int32_t GroupId() const { return Read<int32_t>(uintptr_t(this) + 0xc44); } // 0xc44 (Size: 0x4, Type: IntProperty)
    FDelMarScaledCurve PowerIntensityScalarCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x90, Type: StructProperty)
    float MaxLifetimePowerIntensitySeconds() const { return Read<float>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x4, Type: FloatProperty)
    UStaticMeshComponent* Collider() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x8, Type: ObjectProperty)

    void SET_SpeedAmount(const float& Value) { Write<float>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedEffectDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xc14, Value); } // 0xc14 (Size: 0x4, Type: FloatProperty)
    void SET_TurboChargesGained(const float& Value) { Write<float>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x4, Type: FloatProperty)
    void SET_MinDotProductAngleValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedSourceTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc3c, Value); } // 0xc3c (Size: 0x4, Type: StructProperty)
    void SET_bApplyForce(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x1, Type: BoolProperty)
    void SET_GroupId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc44, Value); } // 0xc44 (Size: 0x4, Type: IntProperty)
    void SET_PowerIntensityScalarCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x90, Type: StructProperty)
    void SET_MaxLifetimePowerIntensitySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x4, Type: FloatProperty)
    void SET_Collider(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UDelMarSplineActorMovementComponent : public UActorComponent
{
public:
    TWeakObjectPtr<USplineComponent*> MovementSpline() const { return Read<TWeakObjectPtr<USplineComponent*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    float MovementSpeed() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)

    void SET_MovementSpline(const TWeakObjectPtr<USplineComponent*>& Value) { Write<TWeakObjectPtr<USplineComponent*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MovementSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2b0
class ADelMarStartLineActor : public AActor
{
public:
    ADelMarCheckpoint* Checkpoint() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_Checkpoint(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UDelMarTutorialConfigComponent : public UActorComponent
{
public:
    TArray<FDelMarTutorialSection> Sections() const { return Read<TArray<FDelMarTutorialSection>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)

    void SET_Sections(const TArray<FDelMarTutorialSection>& Value) { Write<TArray<FDelMarTutorialSection>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x308
class ADelMarTutorialInteractableSpline : public AActor
{
public:
    bool bMustTriggerInOrder() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    FVector ChildActorScaleMultiplier() const { return Read<FVector>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x18, Type: StructProperty)
    uint8_t SplineGenerationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x1, Type: EnumProperty)
    int32_t ChildActorCount() const { return Read<int32_t>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: IntProperty)
    bool bUseSplineRotationForActors() const { return Read<bool>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bShowDebugNumbers() const { return Read<bool>(uintptr_t(this) + 0x2d1); } // 0x2d1 (Size: 0x1, Type: BoolProperty)
    float DebugTextZOffset() const { return Read<float>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x4, Type: FloatProperty)
    float DebugTextSize() const { return Read<float>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    UMaterial* DebugTextMaterial() const { return Read<UMaterial*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    USplineComponent* SplineComponent() const { return Read<USplineComponent*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UClass* ChildActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ClassProperty)
    TArray<UChildActorComponent*> ChildActorComponents() const { return Read<TArray<UChildActorComponent*>>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)

    void SET_bMustTriggerInOrder(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_ChildActorScaleMultiplier(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x18, Type: StructProperty)
    void SET_SplineGenerationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x1, Type: EnumProperty)
    void SET_ChildActorCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: IntProperty)
    void SET_bUseSplineRotationForActors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    void SET_bShowDebugNumbers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d1, Value); } // 0x2d1 (Size: 0x1, Type: BoolProperty)
    void SET_DebugTextZOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x4, Type: FloatProperty)
    void SET_DebugTextSize(const float& Value) { Write<float>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    void SET_DebugTextMaterial(const UMaterial*& Value) { Write<UMaterial*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineComponent(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ChildActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ClassProperty)
    void SET_ChildActorComponents(const TArray<UChildActorComponent*>& Value) { Write<TArray<UChildActorComponent*>>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4f8
class ADelMarTutorialRaceManager : public ADelMarRaceManager
{
public:
    FDelMarVehicleAbilityConfig InitialVehicleAbilityConfig() const { return Read<FDelMarVehicleAbilityConfig>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x11, Type: StructProperty)

    void SET_InitialVehicleAbilityConfig(const FDelMarVehicleAbilityConfig& Value) { Write<FDelMarVehicleAbilityConfig>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x11, Type: StructProperty)
};

// Size: 0x2d0
class ADelMarTutorialTriggerActor : public AActor
{
public:
    UBoxComponent* BoxCollider() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_BoxCollider(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UDelMarVehicleAction : public UObject
{
public:
};

// Size: 0x40
class UDelMarVehicleAction_Jump : public UDelMarVehicleAction
{
public:
};

// Size: 0x40
class UDelMarVehicleAction_Drift : public UDelMarVehicleAction
{
public:
};

// Size: 0x40
class UDelMarVehicleAction_HazardHit : public UDelMarVehicleAction
{
public:
};

// Size: 0x40
class UDelMarVehicleAction_KickFlip : public UDelMarVehicleAction
{
public:
};

// Size: 0x40
class UDelMarVehicleAction_Turbo : public UDelMarVehicleAction
{
public:
};

// Size: 0x40
class UDelMarVehicleAction_Underthrust : public UDelMarVehicleAction
{
public:
};

// Size: 0xd8
class UDelMarVehicleAutoInputComponent : public UActorComponent
{
public:
};

// Size: 0x80
class UDelMarVehicleBodySetup : public UDataAsset
{
public:
    FDelMarVehicleAxleConfig FrontAxle() const { return Read<FDelMarVehicleAxleConfig>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleAxleConfig BackAxle() const { return Read<FDelMarVehicleAxleConfig>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)

    void SET_FrontAxle(const FDelMarVehicleAxleConfig& Value) { Write<FDelMarVehicleAxleConfig>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_BackAxle(const FDelMarVehicleAxleConfig& Value) { Write<FDelMarVehicleAxleConfig>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
};

// Size: 0xd0
class UDelMarVehicleBodySetupMap : public UDataAsset
{
public:
    TMap<FName, UDelMarVehicleBodySetup*> BodySetupNameMap() const { return Read<TMap<FName, UDelMarVehicleBodySetup*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, UDelMarVehicleBodySetup*> BodySetupArchetypeMap() const { return Read<TMap<FGameplayTag, UDelMarVehicleBodySetup*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)

    void SET_BodySetupNameMap(const TMap<FName, UDelMarVehicleBodySetup*>& Value) { Write<TMap<FName, UDelMarVehicleBodySetup*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_BodySetupArchetypeMap(const TMap<FGameplayTag, UDelMarVehicleBodySetup*>& Value) { Write<TMap<FGameplayTag, UDelMarVehicleBodySetup*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
};

// Size: 0x3420
class UDelMarVehicleCameraMode_V2 : public UFortCameraMode
{
public:
    UClass* CameraInputControllerComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ClassProperty)
    TMap<FGameplayTag, FDelMarDefaultCameraValues> VehicleArchetypeDefaults() const { return Read<TMap<FGameplayTag, FDelMarDefaultCameraValues>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x50, Type: MapProperty)
    float DefaultInterpLambda() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float FOV() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float TotalFOVInterpLambda() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalFOVClamp() const { return Read<FFloatRange>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x10, Type: StructProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    float TotalDistanceInterpLambda() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalDistanceClamp() const { return Read<FFloatRange>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x10, Type: StructProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float TotalHeightInterpLambda() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float HeightOffsetInterpLambda() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalHeightClamp() const { return Read<FFloatRange>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: StructProperty)
    float AngleToOriginDegrees() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float AngleToOriginInterpLambda() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalAngleToOriginClamp() const { return Read<FFloatRange>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: StructProperty)
    float SwivelInterpLambda() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float SwivelPitchMax() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    float SwivelYawMax() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float GroundNormalInterpLambda() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    float ForwardInterpLambda() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)
    float CarPitchInterpLambda() const { return Read<float>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: FloatProperty)
    float AerialCarPitchInterpLambda() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    float MaxAerialCarPitch() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    float PitchRotationAxisInterpLambda() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float VerticalDriftDegreeThreshold() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float MinDegreesVehicleWorldUpThreshold() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve MaxUpRotationPerSecondCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x90, Type: StructProperty)
    float MaxUpRotationPerSecondStatic() const { return Read<float>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    float WorldUpInterpRate() const { return Read<float>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x4, Type: FloatProperty)
    bool bPreventPenetration() const { return Read<bool>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    bool bDoPredictiveAvoidance() const { return Read<bool>(uintptr_t(this) + 0x1e9); } // 0x1e9 (Size: 0x1, Type: BoolProperty)
    float CollisionPushOutDistance() const { return Read<float>(uintptr_t(this) + 0x1ec); } // 0x1ec (Size: 0x4, Type: FloatProperty)
    float PenetrationBlendOutTime() const { return Read<float>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x4, Type: FloatProperty)
    float PenetrationBlendInTime() const { return Read<float>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> PenetrationTraceChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    TArray<FPenetrationAvoidanceFeeler> PenetrationAvoidanceFeelers() const { return Read<TArray<FPenetrationAvoidanceFeeler>>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x10, Type: ArrayProperty)
    FDelMarScaledCurve ForwardAirInterpLambdaCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x90, Type: StructProperty)
    FRuntimeFloatCurve ForwardAirBlendCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x88, Type: StructProperty)
    float MinForwardSpeedForAerialBlend() const { return Read<float>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: FloatProperty)
    float MinTimeInAirBeforeUsingVehicleUp() const { return Read<float>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve GroundNormalAirInterpLambdaCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x90, Type: StructProperty)
    float AirFreestyleDeactivationExtendedSeconds() const { return Read<float>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    float AirFreestyleDeactivationLambdaSeconds() const { return Read<float>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    float AirFreestyleDeactivationForwardLambda() const { return Read<float>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    float AirFreestyleDeactivationNormalLambda() const { return Read<float>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve DriftForwardBlendCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialDriftForwardBlendCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve DriftForwardInterpLambdaCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve DriftOriginOffsetCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x88, Type: StructProperty)
    FDelMarScaledCurve DriftOriginOffsetInterpLambdaCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x90, Type: StructProperty)
    float DriftOriginOffsetInactiveLambda() const { return Read<float>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x4, Type: FloatProperty)
    FDelMarCameraFloatBlendedProperty DriftKickOffsetDistance() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x1d0, Type: StructProperty)
    float DriftKickOffsetLambda() const { return Read<float>(uintptr_t(this) + 0x858); } // 0x858 (Size: 0x4, Type: FloatProperty)
    float DriftKickOffsetInactiveLambda() const { return Read<float>(uintptr_t(this) + 0x85c); } // 0x85c (Size: 0x4, Type: FloatProperty)
    bool bDeactivateKickOffsetOnKickEnd() const { return Read<bool>(uintptr_t(this) + 0x860); } // 0x860 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve DriftRollDegreesCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x88, Type: StructProperty)
    FDelMarScaledCurve DriftRollDegreesInterpLambdaCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DriftScalarCurveCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x980); } // 0x980 (Size: 0x90, Type: StructProperty)
    float GroundMaxPitchForNormalBlend() const { return Read<float>(uintptr_t(this) + 0xa10); } // 0xa10 (Size: 0x4, Type: FloatProperty)
    float GroundExtraPitchForNormalBlend() const { return Read<float>(uintptr_t(this) + 0xa14); } // 0xa14 (Size: 0x4, Type: FloatProperty)
    FDelMarCameraFloatProperty StableSpeedDistance() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty StableSpeedFOV() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xac8); } // 0xac8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty StableSpeedHeight() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty StableSpeedAngleToOrigin() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationDistance() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationFOV() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationHeight() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xe38); } // 0xe38 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationAngleToOrigin() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xee8); } // 0xee8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedDistance() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xf98); } // 0xf98 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedFOV() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1048); } // 0x1048 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedHeight() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x10f8); } // 0x10f8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedAngleToOrigin() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x11a8); } // 0x11a8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationDistance() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1258); } // 0x1258 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationFOV() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationHeight() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x13b8); } // 0x13b8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationAngleToOrigin() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1468); } // 0x1468 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboDistance() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboFOV() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x16e8); } // 0x16e8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboBonusZoneSuccessDistance() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x18b8); } // 0x18b8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboBonusZoneSuccessFOV() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1a88); } // 0x1a88 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty DriftBonusDistance() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1c58); } // 0x1c58 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty DriftBonusFOV() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1e28); } // 0x1e28 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty StartlineDistance() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1ff8); } // 0x1ff8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty StartlineFOV() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x21c8); } // 0x21c8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatProperty DraftDistance() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2398); } // 0x2398 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty DraftFOV() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2448); } // 0x2448 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty WorldBonusSpeedDistance() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x24f8); } // 0x24f8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty WorldBonusSpeedFOV() const { return Read<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x26c8); } // 0x26c8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatProperty AerialDivingBonusSpeedDistance() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2898); } // 0x2898 (Size: 0xb0, Type: StructProperty)
    float NonSkydivingDistanceScalar() const { return Read<float>(uintptr_t(this) + 0x2948); } // 0x2948 (Size: 0x4, Type: FloatProperty)
    FDelMarCameraFloatProperty AerialDivingBonusSpeedFOV() const { return Read<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2950); } // 0x2950 (Size: 0xb0, Type: StructProperty)
    float NonSkydivingFOVScalar() const { return Read<float>(uintptr_t(this) + 0x2a00); } // 0x2a00 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> VehicleTarget() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x2a04); } // 0x2a04 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCameraInputControllerComponent*> CameraInputControllerComponent() const { return Read<TWeakObjectPtr<UDelMarCameraInputControllerComponent*>>(uintptr_t(this) + 0x2a0c); } // 0x2a0c (Size: 0x8, Type: WeakObjectProperty)

    void SET_CameraInputControllerComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ClassProperty)
    void SET_VehicleArchetypeDefaults(const TMap<FGameplayTag, FDelMarDefaultCameraValues>& Value) { Write<TMap<FGameplayTag, FDelMarDefaultCameraValues>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x50, Type: MapProperty)
    void SET_DefaultInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_FOV(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_TotalFOVInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_TotalFOVClamp(const FFloatRange& Value) { Write<FFloatRange>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x10, Type: StructProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_TotalDistanceInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_TotalDistanceClamp(const FFloatRange& Value) { Write<FFloatRange>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x10, Type: StructProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_TotalHeightInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_HeightOffsetInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_TotalHeightClamp(const FFloatRange& Value) { Write<FFloatRange>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: StructProperty)
    void SET_AngleToOriginDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_AngleToOriginInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_TotalAngleToOriginClamp(const FFloatRange& Value) { Write<FFloatRange>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: StructProperty)
    void SET_SwivelInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_SwivelPitchMax(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_SwivelYawMax(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_GroundNormalInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_ForwardInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
    void SET_CarPitchInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: FloatProperty)
    void SET_AerialCarPitchInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAerialCarPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_PitchRotationAxisInterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalDriftDegreeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_MinDegreesVehicleWorldUpThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_MaxUpRotationPerSecondCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x90, Type: StructProperty)
    void SET_MaxUpRotationPerSecondStatic(const float& Value) { Write<float>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    void SET_WorldUpInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x4, Type: FloatProperty)
    void SET_bPreventPenetration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x1, Type: BoolProperty)
    void SET_bDoPredictiveAvoidance(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e9, Value); } // 0x1e9 (Size: 0x1, Type: BoolProperty)
    void SET_CollisionPushOutDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1ec, Value); } // 0x1ec (Size: 0x4, Type: FloatProperty)
    void SET_PenetrationBlendOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x4, Type: FloatProperty)
    void SET_PenetrationBlendInTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0x4, Type: FloatProperty)
    void SET_PenetrationTraceChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: ByteProperty)
    void SET_PenetrationAvoidanceFeelers(const TArray<FPenetrationAvoidanceFeeler>& Value) { Write<TArray<FPenetrationAvoidanceFeeler>>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x10, Type: ArrayProperty)
    void SET_ForwardAirInterpLambdaCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x90, Type: StructProperty)
    void SET_ForwardAirBlendCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x88, Type: StructProperty)
    void SET_MinForwardSpeedForAerialBlend(const float& Value) { Write<float>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: FloatProperty)
    void SET_MinTimeInAirBeforeUsingVehicleUp(const float& Value) { Write<float>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: FloatProperty)
    void SET_GroundNormalAirInterpLambdaCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x90, Type: StructProperty)
    void SET_AirFreestyleDeactivationExtendedSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    void SET_AirFreestyleDeactivationLambdaSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    void SET_AirFreestyleDeactivationForwardLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    void SET_AirFreestyleDeactivationNormalLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x4, Type: FloatProperty)
    void SET_DriftForwardBlendCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x88, Type: StructProperty)
    void SET_AerialDriftForwardBlendCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x88, Type: StructProperty)
    void SET_DriftForwardInterpLambdaCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x88, Type: StructProperty)
    void SET_DriftOriginOffsetCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x88, Type: StructProperty)
    void SET_DriftOriginOffsetInterpLambdaCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x90, Type: StructProperty)
    void SET_DriftOriginOffsetInactiveLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x4, Type: FloatProperty)
    void SET_DriftKickOffsetDistance(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x1d0, Type: StructProperty)
    void SET_DriftKickOffsetLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x858, Value); } // 0x858 (Size: 0x4, Type: FloatProperty)
    void SET_DriftKickOffsetInactiveLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x85c, Value); } // 0x85c (Size: 0x4, Type: FloatProperty)
    void SET_bDeactivateKickOffsetOnKickEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x860, Value); } // 0x860 (Size: 0x1, Type: BoolProperty)
    void SET_DriftRollDegreesCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x88, Type: StructProperty)
    void SET_DriftRollDegreesInterpLambdaCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x90, Type: StructProperty)
    void SET_DriftScalarCurveCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x980, Value); } // 0x980 (Size: 0x90, Type: StructProperty)
    void SET_GroundMaxPitchForNormalBlend(const float& Value) { Write<float>(uintptr_t(this) + 0xa10, Value); } // 0xa10 (Size: 0x4, Type: FloatProperty)
    void SET_GroundExtraPitchForNormalBlend(const float& Value) { Write<float>(uintptr_t(this) + 0xa14, Value); } // 0xa14 (Size: 0x4, Type: FloatProperty)
    void SET_StableSpeedDistance(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0xb0, Type: StructProperty)
    void SET_StableSpeedFOV(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xac8, Value); } // 0xac8 (Size: 0xb0, Type: StructProperty)
    void SET_StableSpeedHeight(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0xb0, Type: StructProperty)
    void SET_StableSpeedAngleToOrigin(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0xb0, Type: StructProperty)
    void SET_AccelerationDistance(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0xb0, Type: StructProperty)
    void SET_AccelerationFOV(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0xb0, Type: StructProperty)
    void SET_AccelerationHeight(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xe38, Value); } // 0xe38 (Size: 0xb0, Type: StructProperty)
    void SET_AccelerationAngleToOrigin(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xee8, Value); } // 0xee8 (Size: 0xb0, Type: StructProperty)
    void SET_BaseSpeedDistance(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0xf98, Value); } // 0xf98 (Size: 0xb0, Type: StructProperty)
    void SET_BaseSpeedFOV(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1048, Value); } // 0x1048 (Size: 0xb0, Type: StructProperty)
    void SET_BaseSpeedHeight(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x10f8, Value); } // 0x10f8 (Size: 0xb0, Type: StructProperty)
    void SET_BaseSpeedAngleToOrigin(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x11a8, Value); } // 0x11a8 (Size: 0xb0, Type: StructProperty)
    void SET_BaseAccelerationDistance(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1258, Value); } // 0x1258 (Size: 0xb0, Type: StructProperty)
    void SET_BaseAccelerationFOV(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0xb0, Type: StructProperty)
    void SET_BaseAccelerationHeight(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x13b8, Value); } // 0x13b8 (Size: 0xb0, Type: StructProperty)
    void SET_BaseAccelerationAngleToOrigin(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x1468, Value); } // 0x1468 (Size: 0xb0, Type: StructProperty)
    void SET_TurboDistance(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x1d0, Type: StructProperty)
    void SET_TurboFOV(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x16e8, Value); } // 0x16e8 (Size: 0x1d0, Type: StructProperty)
    void SET_TurboBonusZoneSuccessDistance(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x18b8, Value); } // 0x18b8 (Size: 0x1d0, Type: StructProperty)
    void SET_TurboBonusZoneSuccessFOV(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1a88, Value); } // 0x1a88 (Size: 0x1d0, Type: StructProperty)
    void SET_DriftBonusDistance(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1c58, Value); } // 0x1c58 (Size: 0x1d0, Type: StructProperty)
    void SET_DriftBonusFOV(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1e28, Value); } // 0x1e28 (Size: 0x1d0, Type: StructProperty)
    void SET_StartlineDistance(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x1ff8, Value); } // 0x1ff8 (Size: 0x1d0, Type: StructProperty)
    void SET_StartlineFOV(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x21c8, Value); } // 0x21c8 (Size: 0x1d0, Type: StructProperty)
    void SET_DraftDistance(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2398, Value); } // 0x2398 (Size: 0xb0, Type: StructProperty)
    void SET_DraftFOV(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2448, Value); } // 0x2448 (Size: 0xb0, Type: StructProperty)
    void SET_WorldBonusSpeedDistance(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x24f8, Value); } // 0x24f8 (Size: 0x1d0, Type: StructProperty)
    void SET_WorldBonusSpeedFOV(const FDelMarCameraFloatBlendedProperty& Value) { Write<FDelMarCameraFloatBlendedProperty>(uintptr_t(this) + 0x26c8, Value); } // 0x26c8 (Size: 0x1d0, Type: StructProperty)
    void SET_AerialDivingBonusSpeedDistance(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2898, Value); } // 0x2898 (Size: 0xb0, Type: StructProperty)
    void SET_NonSkydivingDistanceScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x2948, Value); } // 0x2948 (Size: 0x4, Type: FloatProperty)
    void SET_AerialDivingBonusSpeedFOV(const FDelMarCameraFloatProperty& Value) { Write<FDelMarCameraFloatProperty>(uintptr_t(this) + 0x2950, Value); } // 0x2950 (Size: 0xb0, Type: StructProperty)
    void SET_NonSkydivingFOVScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x2a00, Value); } // 0x2a00 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleTarget(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x2a04, Value); } // 0x2a04 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CameraInputControllerComponent(const TWeakObjectPtr<UDelMarCameraInputControllerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarCameraInputControllerComponent*>>(uintptr_t(this) + 0x2a0c, Value); } // 0x2a0c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xc8
class UDelMarVehicleInteractionOverrideComponent : public UFortVehicleInteractionOverrideComponent
{
public:
};

// Size: 0x80
class UDelMarVehicleLoadoutSetup : public UPrimaryDataAsset
{
public:
    FDelMarLoadout Loadout() const { return Read<FDelMarLoadout>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: StructProperty)

    void SET_Loadout(const FDelMarLoadout& Value) { Write<FDelMarLoadout>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: StructProperty)
};

// Size: 0x600
class UDelMarVehicleNetworkPhysicsComponent : public UActorComponent
{
public:
    FDelMarVehicleReplicatedState ReplicatedState() const { return Read<FDelMarVehicleReplicatedState>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x290, Type: StructProperty)

    void SET_ReplicatedState(const FDelMarVehicleReplicatedState& Value) { Write<FDelMarVehicleReplicatedState>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x290, Type: StructProperty)
};

// Size: 0xc8
class UDelMarVehicleStateTagManagerComponent : public UActorComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> CachedASC() const { return Read<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedASC(const TWeakObjectPtr<UAbilitySystemComponent*>& Value) { Write<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xe0
class UDelMarVehicleVerbComponent : public UActorComponent
{
public:
};

// Size: 0x68
class UFortAutomationRpcManager_DelMar : public UFortAutomationRpcManager
{
public:
};

// Size: 0x68
class UGameFeatureAction_MergeRankedDisplayData : public UGameFeatureAction
{
public:
    TSoftObjectPtr<UFortHabaneroDisplayData> MergeSource() const { return Read<TSoftObjectPtr<UFortHabaneroDisplayData>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortHabaneroDisplayData> MergeDestination() const { return Read<TSoftObjectPtr<UFortHabaneroDisplayData>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)

    void SET_MergeSource(const TSoftObjectPtr<UFortHabaneroDisplayData>& Value) { Write<TSoftObjectPtr<UFortHabaneroDisplayData>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MergeDestination(const TSoftObjectPtr<UFortHabaneroDisplayData>& Value) { Write<TSoftObjectPtr<UFortHabaneroDisplayData>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0xd0
class UUDelMarPlayerSuspendComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x28
class UDelMarVehicleInterface : public UVehicleCosmeticsInterface
{
public:
};

// Size: 0x400
class UDelMarAudioComponentGroup : public UAudioComponentGroup
{
public:
    UDelMarAudioMixModifierExtension* MixModifierExtension() const { return Read<UDelMarAudioMixModifierExtension*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    UDelMarSubmixSendExtension* SubmixSendExtension() const { return Read<UDelMarSubmixSendExtension*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)

    void SET_MixModifierExtension(const UDelMarAudioMixModifierExtension*& Value) { Write<UDelMarAudioMixModifierExtension*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SubmixSendExtension(const UDelMarSubmixSendExtension*& Value) { Write<UDelMarSubmixSendExtension*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x528
class ADelMarAudioController : public AFortAthenaVehicleAudioController
{
public:
    UDelMarAudioComponentGroup* ComponentGroup() const { return Read<UDelMarAudioComponentGroup*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    bool bIsLocal() const { return Read<bool>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x1, Type: BoolProperty)
    float FinishLineDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x47c); } // 0x47c (Size: 0x4, Type: FloatProperty)
    float ApproachingFinishLineMinTime() const { return Read<float>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x4, Type: FloatProperty)
    float BigAirLandingDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x484); } // 0x484 (Size: 0x4, Type: FloatProperty)
    float BigAirTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x4, Type: FloatProperty)
    float BigAirDownSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x48c); } // 0x48c (Size: 0x4, Type: FloatProperty)
    float NonLocalVelocityInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x4, Type: FloatProperty)
    float MaxAcceleration() const { return Read<float>(uintptr_t(this) + 0x494); } // 0x494 (Size: 0x4, Type: FloatProperty)
    bool bInBigAir() const { return Read<bool>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x1, Type: BoolProperty)
    ADelMarVehicle* CachedVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    bool bCanShift() const { return Read<bool>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x1, Type: BoolProperty)

    void SET_ComponentGroup(const UDelMarAudioComponentGroup*& Value) { Write<UDelMarAudioComponentGroup*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsLocal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x1, Type: BoolProperty)
    void SET_FinishLineDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x47c, Value); } // 0x47c (Size: 0x4, Type: FloatProperty)
    void SET_ApproachingFinishLineMinTime(const float& Value) { Write<float>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x4, Type: FloatProperty)
    void SET_BigAirLandingDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x484, Value); } // 0x484 (Size: 0x4, Type: FloatProperty)
    void SET_BigAirTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x4, Type: FloatProperty)
    void SET_BigAirDownSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x48c, Value); } // 0x48c (Size: 0x4, Type: FloatProperty)
    void SET_NonLocalVelocityInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x494, Value); } // 0x494 (Size: 0x4, Type: FloatProperty)
    void SET_bInBigAir(const bool& Value) { Write<bool>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x1, Type: BoolProperty)
    void SET_CachedVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_bCanShift(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe0
class UDelMarAudioMixModifierExtension : public UActorComponent
{
public:
};

// Size: 0x340
class UDelMarAudioReverbComponent : public UActorComponent
{
public:
    USoundSubmixBase* ReverbSend() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* EarlyReflectionSend() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    FRuntimeFloatCurve EnclosureReverbBlendCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WallDistanceBlendCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve EnclosureSendLevelCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WallDistanceSendLevelCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x88, Type: StructProperty)
    int32_t NumPoints() const { return Read<int32_t>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x4, Type: IntProperty)
    float TraceRadius() const { return Read<float>(uintptr_t(this) + 0x2ec); } // 0x2ec (Size: 0x4, Type: FloatProperty)
    FVector TraceOrigin() const { return Read<FVector>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x18, Type: StructProperty)
    int32_t NumTracesPerFrame() const { return Read<int32_t>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: IntProperty)
    ADelMarVehicle* CachedVehicleOwner() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)

    void SET_ReverbSend(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_EarlyReflectionSend(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_EnclosureReverbBlendCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x88, Type: StructProperty)
    void SET_WallDistanceBlendCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x88, Type: StructProperty)
    void SET_EnclosureSendLevelCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x88, Type: StructProperty)
    void SET_WallDistanceSendLevelCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x88, Type: StructProperty)
    void SET_NumPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x4, Type: IntProperty)
    void SET_TraceRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x2ec, Value); } // 0x2ec (Size: 0x4, Type: FloatProperty)
    void SET_TraceOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x18, Type: StructProperty)
    void SET_NumTracesPerFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: IntProperty)
    void SET_CachedVehicleOwner(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
class UDelMarSubmixSendExtension : public UActorComponent
{
public:
    float SendInterpTime() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)

    void SET_SendInterpTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UDelMarNuxBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x340
class UFortClientPilot_QuickSmokeDelMar : public UFortClientPilot_GameplayBase
{
public:
};

// Size: 0x28
class UDelMarBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x38
class UDelMarCheatManager : public UChildCheatManager
{
public:
    TArray<FString> SafePlayerNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_SafePlayerNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UDelMarGlobals : public UObject
{
public:
};

// Size: 0x2660
class UDelMarVehicleCameraMode : public UFortCameraMode_AthenaVehicle
{
public:
    FDelMarVehicleCameraSettings CameraSettings() const { return Read<FDelMarVehicleCameraSettings>(uintptr_t(this) + 0x2030); } // 0x2030 (Size: 0x1c, Type: StructProperty)
    FRuntimeFloatCurve VelocityViewDistance() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2050); } // 0x2050 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve VelocityFOV() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x20d8); } // 0x20d8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialViewDistance() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2160); } // 0x2160 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialFocusOffset() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x21e8); } // 0x21e8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialPitch() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2270); } // 0x2270 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AccelViewDistance() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x22f8); } // 0x22f8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AccelPitch() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2380); } // 0x2380 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AirRotationInterpRate() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x2408); } // 0x2408 (Size: 0x88, Type: StructProperty)
    float DriftSwivelSpeed() const { return Read<float>(uintptr_t(this) + 0x2490); } // 0x2490 (Size: 0x4, Type: FloatProperty)
    float ViewDistanceInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x2494); } // 0x2494 (Size: 0x4, Type: FloatProperty)
    float FOVInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x2498); } // 0x2498 (Size: 0x4, Type: FloatProperty)
    float AccelerationViewDistanceDecayRate() const { return Read<float>(uintptr_t(this) + 0x249c); } // 0x249c (Size: 0x4, Type: FloatProperty)
    float MaxAccumulatedAccelViewDistance() const { return Read<float>(uintptr_t(this) + 0x24a0); } // 0x24a0 (Size: 0x4, Type: FloatProperty)
    float MinAccumulatedAccelViewDistance() const { return Read<float>(uintptr_t(this) + 0x24a4); } // 0x24a4 (Size: 0x4, Type: FloatProperty)
    float AerialOffsetInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x24a8); } // 0x24a8 (Size: 0x4, Type: FloatProperty)
    float MaximumDownwardAerialPitch() const { return Read<float>(uintptr_t(this) + 0x24ac); } // 0x24ac (Size: 0x4, Type: FloatProperty)
    float MaximumUpwardAerialPitch() const { return Read<float>(uintptr_t(this) + 0x24b0); } // 0x24b0 (Size: 0x4, Type: FloatProperty)
    float AccelerationPitchDecayRate() const { return Read<float>(uintptr_t(this) + 0x24b4); } // 0x24b4 (Size: 0x4, Type: FloatProperty)
    float MaxAccumulatedAccelPitch() const { return Read<float>(uintptr_t(this) + 0x24b8); } // 0x24b8 (Size: 0x4, Type: FloatProperty)
    float MinAccumulatedAccelPitch() const { return Read<float>(uintptr_t(this) + 0x24bc); } // 0x24bc (Size: 0x4, Type: FloatProperty)
    bool bPreventSpeedIncreaseInAir() const { return Read<bool>(uintptr_t(this) + 0x24c0); } // 0x24c0 (Size: 0x1, Type: BoolProperty)
    float SpeedInputScalar() const { return Read<float>(uintptr_t(this) + 0x24c4); } // 0x24c4 (Size: 0x4, Type: FloatProperty)
    float SwivelPitchMax() const { return Read<float>(uintptr_t(this) + 0x24c8); } // 0x24c8 (Size: 0x4, Type: FloatProperty)
    float SwivelYawMax() const { return Read<float>(uintptr_t(this) + 0x24cc); } // 0x24cc (Size: 0x4, Type: FloatProperty)
    float GroundPitchInterpRate() const { return Read<float>(uintptr_t(this) + 0x24d0); } // 0x24d0 (Size: 0x4, Type: FloatProperty)
    float GroundMaxPitchForNormalBlend() const { return Read<float>(uintptr_t(this) + 0x24d4); } // 0x24d4 (Size: 0x4, Type: FloatProperty)
    float GroundNormalInterpRate() const { return Read<float>(uintptr_t(this) + 0x24d8); } // 0x24d8 (Size: 0x4, Type: FloatProperty)
    float GroundNormalAirInterpRate() const { return Read<float>(uintptr_t(this) + 0x24dc); } // 0x24dc (Size: 0x4, Type: FloatProperty)
    float GroundYawRateMin() const { return Read<float>(uintptr_t(this) + 0x24e0); } // 0x24e0 (Size: 0x4, Type: FloatProperty)
    float GroundYawRateMax() const { return Read<float>(uintptr_t(this) + 0x24e4); } // 0x24e4 (Size: 0x4, Type: FloatProperty)
    float WallYawRateMin() const { return Read<float>(uintptr_t(this) + 0x24e8); } // 0x24e8 (Size: 0x4, Type: FloatProperty)
    float WallYawRateMax() const { return Read<float>(uintptr_t(this) + 0x24ec); } // 0x24ec (Size: 0x4, Type: FloatProperty)
    float InterpToGroundTime() const { return Read<float>(uintptr_t(this) + 0x24f0); } // 0x24f0 (Size: 0x4, Type: FloatProperty)
    float InterpToAirTime() const { return Read<float>(uintptr_t(this) + 0x24f4); } // 0x24f4 (Size: 0x4, Type: FloatProperty)
    float AverageVelocityInterpRate() const { return Read<float>(uintptr_t(this) + 0x24f8); } // 0x24f8 (Size: 0x4, Type: FloatProperty)
    float FocusOffsetInterpRate() const { return Read<float>(uintptr_t(this) + 0x24fc); } // 0x24fc (Size: 0x4, Type: FloatProperty)
    float DistanceSpeedScale() const { return Read<float>(uintptr_t(this) + 0x2500); } // 0x2500 (Size: 0x4, Type: FloatProperty)
    float DistanceOffsetMin() const { return Read<float>(uintptr_t(this) + 0x2504); } // 0x2504 (Size: 0x4, Type: FloatProperty)
    float DistanceOffsetMax() const { return Read<float>(uintptr_t(this) + 0x2508); } // 0x2508 (Size: 0x4, Type: FloatProperty)
    float DistanceInterpRate() const { return Read<float>(uintptr_t(this) + 0x250c); } // 0x250c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedFOVOffset() const { return Read<float>(uintptr_t(this) + 0x2510); } // 0x2510 (Size: 0x4, Type: FloatProperty)
    float SupersonicFOVOffset() const { return Read<float>(uintptr_t(this) + 0x2514); } // 0x2514 (Size: 0x4, Type: FloatProperty)
    float FOVInterpRate() const { return Read<float>(uintptr_t(this) + 0x2518); } // 0x2518 (Size: 0x4, Type: FloatProperty)
    ADelMarVehicle* VehicleTarget() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x2520); } // 0x2520 (Size: 0x8, Type: ObjectProperty)

    void SET_CameraSettings(const FDelMarVehicleCameraSettings& Value) { Write<FDelMarVehicleCameraSettings>(uintptr_t(this) + 0x2030, Value); } // 0x2030 (Size: 0x1c, Type: StructProperty)
    void SET_VelocityViewDistance(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2050, Value); } // 0x2050 (Size: 0x88, Type: StructProperty)
    void SET_VelocityFOV(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x20d8, Value); } // 0x20d8 (Size: 0x88, Type: StructProperty)
    void SET_AerialViewDistance(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2160, Value); } // 0x2160 (Size: 0x88, Type: StructProperty)
    void SET_AerialFocusOffset(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x21e8, Value); } // 0x21e8 (Size: 0x88, Type: StructProperty)
    void SET_AerialPitch(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2270, Value); } // 0x2270 (Size: 0x88, Type: StructProperty)
    void SET_AccelViewDistance(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x22f8, Value); } // 0x22f8 (Size: 0x88, Type: StructProperty)
    void SET_AccelPitch(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2380, Value); } // 0x2380 (Size: 0x88, Type: StructProperty)
    void SET_AirRotationInterpRate(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x2408, Value); } // 0x2408 (Size: 0x88, Type: StructProperty)
    void SET_DriftSwivelSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2490, Value); } // 0x2490 (Size: 0x4, Type: FloatProperty)
    void SET_ViewDistanceInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2494, Value); } // 0x2494 (Size: 0x4, Type: FloatProperty)
    void SET_FOVInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2498, Value); } // 0x2498 (Size: 0x4, Type: FloatProperty)
    void SET_AccelerationViewDistanceDecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x249c, Value); } // 0x249c (Size: 0x4, Type: FloatProperty)
    void SET_MaxAccumulatedAccelViewDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x24a0, Value); } // 0x24a0 (Size: 0x4, Type: FloatProperty)
    void SET_MinAccumulatedAccelViewDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x24a4, Value); } // 0x24a4 (Size: 0x4, Type: FloatProperty)
    void SET_AerialOffsetInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x24a8, Value); } // 0x24a8 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumDownwardAerialPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x24ac, Value); } // 0x24ac (Size: 0x4, Type: FloatProperty)
    void SET_MaximumUpwardAerialPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x24b0, Value); } // 0x24b0 (Size: 0x4, Type: FloatProperty)
    void SET_AccelerationPitchDecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x24b4, Value); } // 0x24b4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAccumulatedAccelPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x24b8, Value); } // 0x24b8 (Size: 0x4, Type: FloatProperty)
    void SET_MinAccumulatedAccelPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x24bc, Value); } // 0x24bc (Size: 0x4, Type: FloatProperty)
    void SET_bPreventSpeedIncreaseInAir(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24c0, Value); } // 0x24c0 (Size: 0x1, Type: BoolProperty)
    void SET_SpeedInputScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x24c4, Value); } // 0x24c4 (Size: 0x4, Type: FloatProperty)
    void SET_SwivelPitchMax(const float& Value) { Write<float>(uintptr_t(this) + 0x24c8, Value); } // 0x24c8 (Size: 0x4, Type: FloatProperty)
    void SET_SwivelYawMax(const float& Value) { Write<float>(uintptr_t(this) + 0x24cc, Value); } // 0x24cc (Size: 0x4, Type: FloatProperty)
    void SET_GroundPitchInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x24d0, Value); } // 0x24d0 (Size: 0x4, Type: FloatProperty)
    void SET_GroundMaxPitchForNormalBlend(const float& Value) { Write<float>(uintptr_t(this) + 0x24d4, Value); } // 0x24d4 (Size: 0x4, Type: FloatProperty)
    void SET_GroundNormalInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x24d8, Value); } // 0x24d8 (Size: 0x4, Type: FloatProperty)
    void SET_GroundNormalAirInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x24dc, Value); } // 0x24dc (Size: 0x4, Type: FloatProperty)
    void SET_GroundYawRateMin(const float& Value) { Write<float>(uintptr_t(this) + 0x24e0, Value); } // 0x24e0 (Size: 0x4, Type: FloatProperty)
    void SET_GroundYawRateMax(const float& Value) { Write<float>(uintptr_t(this) + 0x24e4, Value); } // 0x24e4 (Size: 0x4, Type: FloatProperty)
    void SET_WallYawRateMin(const float& Value) { Write<float>(uintptr_t(this) + 0x24e8, Value); } // 0x24e8 (Size: 0x4, Type: FloatProperty)
    void SET_WallYawRateMax(const float& Value) { Write<float>(uintptr_t(this) + 0x24ec, Value); } // 0x24ec (Size: 0x4, Type: FloatProperty)
    void SET_InterpToGroundTime(const float& Value) { Write<float>(uintptr_t(this) + 0x24f0, Value); } // 0x24f0 (Size: 0x4, Type: FloatProperty)
    void SET_InterpToAirTime(const float& Value) { Write<float>(uintptr_t(this) + 0x24f4, Value); } // 0x24f4 (Size: 0x4, Type: FloatProperty)
    void SET_AverageVelocityInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x24f8, Value); } // 0x24f8 (Size: 0x4, Type: FloatProperty)
    void SET_FocusOffsetInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x24fc, Value); } // 0x24fc (Size: 0x4, Type: FloatProperty)
    void SET_DistanceSpeedScale(const float& Value) { Write<float>(uintptr_t(this) + 0x2500, Value); } // 0x2500 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceOffsetMin(const float& Value) { Write<float>(uintptr_t(this) + 0x2504, Value); } // 0x2504 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceOffsetMax(const float& Value) { Write<float>(uintptr_t(this) + 0x2508, Value); } // 0x2508 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x250c, Value); } // 0x250c (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpeedFOVOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x2510, Value); } // 0x2510 (Size: 0x4, Type: FloatProperty)
    void SET_SupersonicFOVOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x2514, Value); } // 0x2514 (Size: 0x4, Type: FloatProperty)
    void SET_FOVInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x2518, Value); } // 0x2518 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleTarget(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x2520, Value); } // 0x2520 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd0
class UDelMarEliminationRaceManagerComponent : public UDelMarRaceManagerComponent
{
public:
    TArray<FDelMarEliminationMMRCountPair> EliminationsConfig() const { return Read<TArray<FDelMarEliminationMMRCountPair>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    int32_t ParsedNumberOfPlayersToEliminate() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)

    void SET_EliminationsConfig(const TArray<FDelMarEliminationMMRCountPair>& Value) { Write<TArray<FDelMarEliminationMMRCountPair>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_ParsedNumberOfPlayersToEliminate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1e0
class UDelMarStateSequencerFXComponent : public UActorComponent
{
public:
    float FXSizeScalar() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    TMap<FGameplayTag, UNiagaraSystem*> ParticleClassMap() const { return Read<TMap<FGameplayTag, UNiagaraSystem*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x50, Type: MapProperty)
    FFXSystemSpawnParameters SpawnParams() const { return Read<FFXSystemSpawnParameters>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x70, Type: StructProperty)
    ADelMarTimeDelayedStateSequencer* ParentRef() const { return Read<ADelMarTimeDelayedStateSequencer*>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayTag, UNiagaraComponent*> ParticleComponentMap() const { return Read<TMap<FGameplayTag, UNiagaraComponent*>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x50, Type: MapProperty)

    void SET_FXSizeScalar(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_ParticleClassMap(const TMap<FGameplayTag, UNiagaraSystem*>& Value) { Write<TMap<FGameplayTag, UNiagaraSystem*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x50, Type: MapProperty)
    void SET_SpawnParams(const FFXSystemSpawnParameters& Value) { Write<FFXSystemSpawnParameters>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x70, Type: StructProperty)
    void SET_ParentRef(const ADelMarTimeDelayedStateSequencer*& Value) { Write<ADelMarTimeDelayedStateSequencer*>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: ObjectProperty)
    void SET_ParticleComponentMap(const TMap<FGameplayTag, UNiagaraComponent*>& Value) { Write<TMap<FGameplayTag, UNiagaraComponent*>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x50, Type: MapProperty)
};

// Size: 0x2f8
class ADelMarTimeDelayedStateSequencer : public AActor
{
public:
    bool bEnableOnSpawn() const { return Read<bool>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x1, Type: BoolProperty)
    bool bLoopSpecificAmount() const { return Read<bool>(uintptr_t(this) + 0x2c9); } // 0x2c9 (Size: 0x1, Type: BoolProperty)
    int32_t TotalLoopCount() const { return Read<int32_t>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: IntProperty)
    TArray<FDelMarTimeDelayedState> StateArray() const { return Read<TArray<FDelMarTimeDelayedState>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x2ec); } // 0x2ec (Size: 0x1, Type: BoolProperty)
    int32_t CurrentStateIndex() const { return Read<int32_t>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x4, Type: IntProperty)

    void SET_bEnableOnSpawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x1, Type: BoolProperty)
    void SET_bLoopSpecificAmount(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c9, Value); } // 0x2c9 (Size: 0x1, Type: BoolProperty)
    void SET_TotalLoopCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: IntProperty)
    void SET_StateArray(const TArray<FDelMarTimeDelayedState>& Value) { Write<TArray<FDelMarTimeDelayedState>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2ec, Value); } // 0x2ec (Size: 0x1, Type: BoolProperty)
    void SET_CurrentStateIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x2210
class ADelMarGhostVehicle : public AFortAthenaVehicle
{
public:
    UMaterial* GhostMaterial() const { return Read<UMaterial*>(uintptr_t(this) + 0x21a0); } // 0x21a0 (Size: 0x8, Type: ObjectProperty)
    int32_t NumAllowedVehicleCosmeticChanges() const { return Read<int32_t>(uintptr_t(this) + 0x21a8); } // 0x21a8 (Size: 0x4, Type: IntProperty)

    void SET_GhostMaterial(const UMaterial*& Value) { Write<UMaterial*>(uintptr_t(this) + 0x21a0, Value); } // 0x21a0 (Size: 0x8, Type: ObjectProperty)
    void SET_NumAllowedVehicleCosmeticChanges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x21a8, Value); } // 0x21a8 (Size: 0x4, Type: IntProperty)
};

// Size: 0xf0
class UDelMarGlobalInputDisabler : public UDelMarRaceManagerComponent
{
public:
    FGameplayTagContainer DisabledInputTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)

    void SET_DisabledInputTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UDelMarCosmeticActorSpawnLogic : public UObject
{
public:
};

// Size: 0x30
class UDelMarCosmeticActorSpawnLogic_AttachTo : public UDelMarCosmeticActorSpawnLogic
{
public:
    FName AttachSocket() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)

    void SET_AttachSocket(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
};

// Size: 0x38
class UDelMarCosmeticActorSpawnLogic_AttachToEach : public UDelMarCosmeticActorSpawnLogic
{
public:
    TArray<FName> AttachSockets() const { return Read<TArray<FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_AttachSockets(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2e0
class ADelMarCosmeticActor : public AActor
{
public:
    UDelMarCosmeticActorSpawnLogic* SpawnLogic() const { return Read<UDelMarCosmeticActorSpawnLogic*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> CosmeticDependencies() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TScriptInterface<Class> Vehicle() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: InterfaceProperty)
    UDelMarVehicleConfigs* VehicleConfig() const { return Read<UDelMarVehicleConfigs*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleCosmeticComponent* VehicleCosmeticComponent() const { return Read<UDelMarVehicleCosmeticComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)

    void SET_SpawnLogic(const UDelMarCosmeticActorSpawnLogic*& Value) { Write<UDelMarCosmeticActorSpawnLogic*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CosmeticDependencies(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    void SET_Vehicle(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: InterfaceProperty)
    void SET_VehicleConfig(const UDelMarVehicleConfigs*& Value) { Write<UDelMarVehicleConfigs*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_VehicleCosmeticComponent(const UDelMarVehicleCosmeticComponent*& Value) { Write<UDelMarVehicleCosmeticComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x148
class UDelMarCosmeticItemDefinition : public UFortAccountItemDefinition
{
public:
    FGameplayTag Slot() const { return Read<FGameplayTag>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: StructProperty)
    TArray<TSoftClassPtr> CosmeticActorClasses() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)

    void SET_Slot(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: StructProperty)
    void SET_CosmeticActorClasses(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x148
class UDelMarVehicleBodyItemDefinition : public UDelMarCosmeticItemDefinition
{
public:
};

// Size: 0x280
class UDelMarLeaderboardManager : public UDelMarRaceManagerComponent
{
public:
    FString CurrentSeasonIdentifier() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)
    UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved* PersonalBestRetrievedEvent() const { return Read<UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FDelMarLeaderboardConfig LeaderboardConfig() const { return Read<FDelMarLeaderboardConfig>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x20, Type: StructProperty)

    void SET_CurrentSeasonIdentifier(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
    void SET_PersonalBestRetrievedEvent(const UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved*& Value) { Write<UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderboardConfig(const FDelMarLeaderboardConfig& Value) { Write<FDelMarLeaderboardConfig>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x20, Type: StructProperty)
};

// Size: 0xb8
class UDelMarMatchmakingComponent : public UControllerComponent
{
public:
};

// Size: 0x2a8
class ADelMarGameplayModifier : public AActor
{
public:
};

// Size: 0x2b8
class ADelMarGameplayModifier_AttachmentManager : public ADelMarGameplayModifier
{
public:
};

// Size: 0x2d8
class ADelMarGameplayModifier_CVarOverride : public ADelMarGameplayModifier
{
public:
    FString VariableName() const { return Read<FString>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: StrProperty)

    void SET_VariableName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x2b0
class ADelMarGameplayModifier_FriendlyFire : public ADelMarGameplayModifier
{
public:
    uint8_t FriendlyFireType() const { return Read<uint8_t>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: EnumProperty)

    void SET_FriendlyFireType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x300
class ADelMarGameplayModifier_PlacementSpawner : public ADelMarGameplayModifier
{
public:
    UClass* ActorClassToSpawn() const { return Read<UClass*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ClassProperty)
    int32_t MaxPlacement() const { return Read<int32_t>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: IntProperty)
    float SecondsBetweenSpawns() const { return Read<float>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    float RaceStartDelaySeconds() const { return Read<float>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x4, Type: FloatProperty)
    float ActorLifespanSeconds() const { return Read<float>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x4, Type: FloatProperty)
    float ActorDisplacementUnits() const { return Read<float>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x4, Type: FloatProperty)
    int32_t MaxSpawnedActors() const { return Read<int32_t>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x4, Type: IntProperty)
    float MinSpeedForVelocityOrientation() const { return Read<float>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    int32_t SpawnPoints() const { return Read<int32_t>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: IntProperty)
    int32_t TriggerPoints() const { return Read<int32_t>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> CachedPositionComponent() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x2dc); } // 0x2dc (Size: 0x8, Type: WeakObjectProperty)

    void SET_ActorClassToSpawn(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ClassProperty)
    void SET_MaxPlacement(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: IntProperty)
    void SET_SecondsBetweenSpawns(const float& Value) { Write<float>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: FloatProperty)
    void SET_RaceStartDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x4, Type: FloatProperty)
    void SET_ActorLifespanSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x4, Type: FloatProperty)
    void SET_ActorDisplacementUnits(const float& Value) { Write<float>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpawnedActors(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x4, Type: IntProperty)
    void SET_MinSpeedForVelocityOrientation(const float& Value) { Write<float>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    void SET_SpawnPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: IntProperty)
    void SET_TriggerPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x4, Type: IntProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPositionComponent(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x2dc, Value); } // 0x2dc (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2c8
class ADelMarGameplayModifier_VehicleClassOverride : public ADelMarGameplayModifier
{
public:
};

// Size: 0x368
class ADelMarMutator_AllowSpectateOtherTeams : public AFortAthenaMutator_AllowSpectateOtherTeams
{
public:
};

// Size: 0x378
class ADelMarAsyncPhysicsTickMutator : public ADelMarMutator
{
public:
    float AsyncTickRate() const { return Read<float>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x4, Type: FloatProperty)

    void SET_AsyncTickRate(const float& Value) { Write<float>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x398
class ADelMarConsoleVariableMutator : public ADelMarMutator
{
public:
    FString VariableName() const { return Read<FString>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x10, Type: StrProperty)

    void SET_VariableName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x10, Type: StrProperty)
};

// Size: 0x80
class UDelMarPhysMatAttributeMap : public UDataAsset
{
public:
    TMap<UPhysicalMaterial*, FPhysicalMaterialAttributes_X> MaterialAttributesMap() const { return Read<TMap<UPhysicalMaterial*, FPhysicalMaterialAttributes_X>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_MaterialAttributesMap(const TMap<UPhysicalMaterial*, FPhysicalMaterialAttributes_X>& Value) { Write<TMap<UPhysicalMaterial*, FPhysicalMaterialAttributes_X>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0xc0
class UDelMarCameraComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<UDelMarVehicleManager*> VehicleManager() const { return Read<TWeakObjectPtr<UDelMarVehicleManager*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_VehicleManager(const TWeakObjectPtr<UDelMarVehicleManager*>& Value) { Write<TWeakObjectPtr<UDelMarVehicleManager*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x118
class UDelMarCameraInputControllerComponent : public UControllerComponent
{
public:
    FDelMarInputAction TurnCameraAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction LookUpCameraAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction ReverseCameraAction() const { return Read<FDelMarInputAction>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StructProperty)
    UClass* InputManagerClass() const { return Read<UClass*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent() const { return Read<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortClientSettingsRecord*> FortSettings() const { return Read<TWeakObjectPtr<UFortClientSettingsRecord*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TurnCameraAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_LookUpCameraAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StructProperty)
    void SET_ReverseCameraAction(const FDelMarInputAction& Value) { Write<FDelMarInputAction>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StructProperty)
    void SET_InputManagerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ClassProperty)
    void SET_InputComponent(const TWeakObjectPtr<UEnhancedInputComponent*>& Value) { Write<TWeakObjectPtr<UEnhancedInputComponent*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_FortSettings(const TWeakObjectPtr<UFortClientSettingsRecord*>& Value) { Write<TWeakObjectPtr<UFortClientSettingsRecord*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x1b0
class UDelMarContextualHintComponent : public UControllerComponent
{
public:
    FDelMarEvent_SetTutorialHint HazardHitHint() const { return Read<FDelMarEvent_SetTutorialHint>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x48, Type: StructProperty)
    TMap<FGameplayTag, FDelMarEvent_SetTutorialHint> DemolishedByHints() const { return Read<TMap<FGameplayTag, FDelMarEvent_SetTutorialHint>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x50, Type: MapProperty)
    FDelMarEvent_SetTutorialHint SlowerTerrainHint() const { return Read<FDelMarEvent_SetTutorialHint>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> Vehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerController*> CachedPlayerController() const { return Read<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_HazardHitHint(const FDelMarEvent_SetTutorialHint& Value) { Write<FDelMarEvent_SetTutorialHint>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x48, Type: StructProperty)
    void SET_DemolishedByHints(const TMap<FGameplayTag, FDelMarEvent_SetTutorialHint>& Value) { Write<TMap<FGameplayTag, FDelMarEvent_SetTutorialHint>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x50, Type: MapProperty)
    void SET_SlowerTerrainHint(const FDelMarEvent_SetTutorialHint& Value) { Write<FDelMarEvent_SetTutorialHint>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x48, Type: StructProperty)
    void SET_Vehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPlayerController(const TWeakObjectPtr<APlayerController*>& Value) { Write<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x130
class UDelMarLocalCheckpointVisibilityControllerComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager() const { return Read<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> ViewTargetPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedLocalPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TSet<ADelMarCheckpoint*> CurrentlyActiveCheckpoints() const { return Read<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x50, Type: SetProperty)
    bool bVisitedStartingCheckpoint() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)

    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedCheckpointManager(const TWeakObjectPtr<UDelMarCheckpointManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ViewTargetPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedLocalPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentlyActiveCheckpoints(const TSet<ADelMarCheckpoint*>& Value) { Write<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x50, Type: SetProperty)
    void SET_bVisitedStartingCheckpoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x118
class UDelMarNetworkInputComponent : public UControllerComponent
{
public:
};

// Size: 0xc0
class UDelMarPlayerAttachmentComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<AFortPlayerState*> AttachedPlayer() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_AttachedPlayer(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xd0
class UDelMarPlayerAutoThrottleComponent : public UDelMarPlayerStateComponent
{
public:
    float DelayAutoThrottle() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)

    void SET_DelayAutoThrottle(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x280
class UDelMarPlayerDeathRaceDataComponent : public UDelMarPlayerRaceDataComponent
{
public:
    int32_t Score() const { return Read<int32_t>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x4, Type: IntProperty)

    void SET_Score(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x4, Type: IntProperty)
};

// Size: 0x128
class UDelMarPlayerInputManagerComponent : public UDelMarPlayerStateComponent
{
public:
    TMap<FGameplayTag, FDelMarInputMappingContextData> InputMappingContextMap() const { return Read<TMap<FGameplayTag, FDelMarInputMappingContextData>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    UDelMarInputContextRedirectMap* PlatformDigitalRedirect() const { return Read<UDelMarInputContextRedirectMap*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)

    void SET_InputMappingContextMap(const TMap<FGameplayTag, FDelMarInputMappingContextData>& Value) { Write<TMap<FGameplayTag, FDelMarInputMappingContextData>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_PlatformDigitalRedirect(const UDelMarInputContextRedirectMap*& Value) { Write<UDelMarInputContextRedirectMap*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x1d0
class UDelMarPlayerRespawnComponent : public UDelMarPlayerStateComponent
{
public:
    float TeleportEnterPhaseSeconds() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float RespawnBackwardsRangeDistance() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float RespawnForwardRangeDistance() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float RespawnHeightStartDistance() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float RespawnHeightPenetrationDistance() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float RespawnValidTrackRadius() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bCheckForObstacles() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    float OppositeSideThreshold() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    FVector ObstacleAreaBounds() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    TArray<UClass*> ObstacleActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ObstacleActorIgnoreClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CheckpointManager() const { return Read<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> PlayerRaceData() const { return Read<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRaceConfigComponent*> RaceConfig() const { return Read<TWeakObjectPtr<UDelMarRaceConfigComponent*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> LastActiveTrack() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPosition() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: WeakObjectProperty)
    int32_t LastValidSegmentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: IntProperty)
    float LastValidDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    float LastValidFurthestDistance() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    bool bSpawnOnOppositeSide() const { return Read<bool>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x1, Type: BoolProperty)
    bool bPreviousVehicleDemolished() const { return Read<bool>(uintptr_t(this) + 0x155); } // 0x155 (Size: 0x1, Type: BoolProperty)
    bool bFirstVehicleForPlayer() const { return Read<bool>(uintptr_t(this) + 0x156); } // 0x156 (Size: 0x1, Type: BoolProperty)
    ADelMarCheckpoint* CachedTeleportCheckpoint() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)

    void SET_TeleportEnterPhaseSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_RespawnBackwardsRangeDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_RespawnForwardRangeDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_RespawnHeightStartDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_RespawnHeightPenetrationDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_RespawnValidTrackRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_bCheckForObstacles(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_OppositeSideThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_ObstacleAreaBounds(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_ObstacleActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_ObstacleActorIgnoreClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    void SET_DelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CheckpointManager(const TWeakObjectPtr<UDelMarCheckpointManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerRaceData(const TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerRaceDataComponent*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RaceConfig(const TWeakObjectPtr<UDelMarRaceConfigComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRaceConfigComponent*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LastActiveTrack(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackPosition(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LastValidSegmentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: IntProperty)
    void SET_LastValidDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_LastValidFurthestDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_bSpawnOnOppositeSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x1, Type: BoolProperty)
    void SET_bPreviousVehicleDemolished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x155, Value); } // 0x155 (Size: 0x1, Type: BoolProperty)
    void SET_bFirstVehicleForPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x156, Value); } // 0x156 (Size: 0x1, Type: BoolProperty)
    void SET_CachedTeleportCheckpoint(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x120
class UDelMarPlayerStartlineComponent : public UDelMarPlayerStateComponent
{
public:
    float FailBufferSeconds() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_FailBufferSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_DelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xe8
class UDelMarPlayerTurboManagerComponent : public UDelMarPlayerStateComponent
{
public:
    float TurboCharges() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float RechargeRateSeconds() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float AdditiveRechargeRateModifierSeconds() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float LapCompleteCharges() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float RaceStartCharges() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float MaxCharges() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TurboCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_RechargeRateSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_AdditiveRechargeRateModifierSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_LapCompleteCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_RaceStartCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xb8
class UDelMarRemoveAthenaMarkerComponent : public UControllerComponent
{
public:
};

// Size: 0x140
class UDelMarRequestComponent : public UDelMarPlayerStateComponent
{
public:
    FGameplayTagContainer MapChoice() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x20, Type: StructProperty)
    bool bIsLoadingScreenActive() const { return Read<bool>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: BoolProperty)
    bool bIsReadyToStartRace() const { return Read<bool>(uintptr_t(this) + 0x121); } // 0x121 (Size: 0x1, Type: BoolProperty)
    bool bIsReadyToJoinRace() const { return Read<bool>(uintptr_t(this) + 0x122); } // 0x122 (Size: 0x1, Type: BoolProperty)
    uint8_t PostRaceVote() const { return Read<uint8_t>(uintptr_t(this) + 0x123); } // 0x123 (Size: 0x1, Type: EnumProperty)
    bool bVotedPostRace() const { return Read<bool>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRespawnManagerComponent*> CachedRespawnManager() const { return Read<TWeakObjectPtr<UDelMarRespawnManagerComponent*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: WeakObjectProperty)

    void SET_MapChoice(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x20, Type: StructProperty)
    void SET_bIsLoadingScreenActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: BoolProperty)
    void SET_bIsReadyToStartRace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x121, Value); } // 0x121 (Size: 0x1, Type: BoolProperty)
    void SET_bIsReadyToJoinRace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x122, Value); } // 0x122 (Size: 0x1, Type: BoolProperty)
    void SET_PostRaceVote(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x123, Value); } // 0x123 (Size: 0x1, Type: EnumProperty)
    void SET_bVotedPostRace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: BoolProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRespawnManager(const TWeakObjectPtr<UDelMarRespawnManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarRespawnManagerComponent*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x128
class UDelMarRunRecordPlayerComponent : public UDelMarPlayerStateComponent
{
public:
    FDelMarRunRecord CurrentRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord BestRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord BestSectionsRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x20, Type: StructProperty)
    double BestSingleLapTime() const { return Read<double>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: DoubleProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CurrentRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x20, Type: StructProperty)
    void SET_BestRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x20, Type: StructProperty)
    void SET_BestSectionsRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x20, Type: StructProperty)
    void SET_BestSingleLapTime(const double& Value) { Write<double>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: DoubleProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xc8
class UDelMarTutorialRequestComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTutorialRaceManager*> TutorialRaceManager() const { return Read<TWeakObjectPtr<ADelMarTutorialRaceManager*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TutorialRaceManager(const TWeakObjectPtr<ADelMarTutorialRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarTutorialRaceManager*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x168
class UDelMarLevelManagerComponent : public UPlayspaceComponent
{
public:
    TWeakObjectPtr<UDelMarLevelDataAsset*> CurrentLevelData() const { return Read<TWeakObjectPtr<UDelMarLevelDataAsset*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    FOnlineLinkId CurrentLevelLinkId() const { return Read<FOnlineLinkId>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer DesiredMapDescription() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: StructProperty)
    FOnlineLinkId DesiredLinkId() const { return Read<FOnlineLinkId>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x18, Type: StructProperty)

    void SET_CurrentLevelData(const TWeakObjectPtr<UDelMarLevelDataAsset*>& Value) { Write<TWeakObjectPtr<UDelMarLevelDataAsset*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentLevelLinkId(const FOnlineLinkId& Value) { Write<FOnlineLinkId>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_DesiredMapDescription(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: StructProperty)
    void SET_DesiredLinkId(const FOnlineLinkId& Value) { Write<FOnlineLinkId>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x18, Type: StructProperty)
};

// Size: 0x370
class ADelMarLoadingScreenMutator : public AFortAthenaMutator
{
public:
};

// Size: 0x120
class UDelMarCheckpointManagerComponent : public UDelMarRaceManagerComponent
{
public:
    bool bPromptFirstPlaceEvent() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    ADelMarCheckpoint* StartingLineCheckpoint() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    ADelMarCheckpoint* FinishLineCheckpoint() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TSet<ADelMarCheckpoint*> LevelCheckpoints() const { return Read<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: SetProperty)

    void SET_bPromptFirstPlaceEvent(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_StartingLineCheckpoint(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_FinishLineCheckpoint(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_LevelCheckpoints(const TSet<ADelMarCheckpoint*>& Value) { Write<TSet<ADelMarCheckpoint*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: SetProperty)
};

// Size: 0x510
class ADelMarDeathRaceManager : public ADelMarRaceManager
{
public:
    float NextRoundSeconds() const { return Read<float>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x4, Type: FloatProperty)
    FDelMarDeathRaceConfig DeathRaceConfigData() const { return Read<FDelMarDeathRaceConfig>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x18, Type: StructProperty)
    int32_t NumPlayersFinished() const { return Read<int32_t>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x4, Type: IntProperty)

    void SET_NextRoundSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x4, Type: FloatProperty)
    void SET_DeathRaceConfigData(const FDelMarDeathRaceConfig& Value) { Write<FDelMarDeathRaceConfig>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x18, Type: StructProperty)
    void SET_NumPlayersFinished(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
class UDelMarGameplayModifierMap : public UDataAsset
{
public:
    TMap<FString, FDelMarGameplayModifierList> ModifierMap() const { return Read<TMap<FString, FDelMarGameplayModifierList>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_ModifierMap(const TMap<FString, FDelMarGameplayModifierList>& Value) { Write<TMap<FString, FDelMarGameplayModifierList>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0xe8
class UDelMarGameplayModifierComponent : public UDelMarRaceManagerComponent
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    UDelMarGameplayModifierMap* ModifierModes() const { return Read<UDelMarGameplayModifierMap*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    FString ModeName() const { return Read<FString>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StrProperty)
    TArray<ADelMarGameplayModifier*> SpawnedModifiers() const { return Read<TArray<ADelMarGameplayModifier*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_ModifierModes(const UDelMarGameplayModifierMap*& Value) { Write<UDelMarGameplayModifierMap*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_ModeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StrProperty)
    void SET_SpawnedModifiers(const TArray<ADelMarGameplayModifier*>& Value) { Write<TArray<ADelMarGameplayModifier*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb8
class UDelMarMatchmakeRatingComponentBase : public UDelMarRaceManagerComponent
{
public:
};

// Size: 0x1c0
class UDelmarCompetitiveMatchmakeRatingComponent : public UDelMarMatchmakeRatingComponentBase
{
public:
    TMap<AFortPlayerState*, int32_t> CachedPlayerRankMap() const { return Read<TMap<AFortPlayerState*, int32_t>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    TSet<FString> PlayerUniqueIdsGivenMMR() const { return Read<TSet<FString>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x50, Type: SetProperty)
    TSet<FString> PlayerUniqueIds() const { return Read<TSet<FString>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x50, Type: SetProperty)

    void SET_CachedPlayerRankMap(const TMap<AFortPlayerState*, int32_t>& Value) { Write<TMap<AFortPlayerState*, int32_t>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_PlayerUniqueIdsGivenMMR(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x50, Type: SetProperty)
    void SET_PlayerUniqueIds(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x50, Type: SetProperty)
};

// Size: 0x170
class UDelMarPositionalTrackerComponent : public UDelMarRaceManagerComponent
{
public:
    float TargetUpdateRateInSeconds() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    TMap<AFortPlayerState*, FDelMarPositionValue> SplinePositions() const { return Read<TMap<AFortPlayerState*, FDelMarPositionValue>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    TArray<AFortPlayerState*> RacePositions() const { return Read<TArray<AFortPlayerState*>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarFinalRacePositionEntry> FinalRacePositions() const { return Read<TArray<FDelMarFinalRacePositionEntry>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    float TimeSinceLastUpdate() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)
    int32_t NumLapsInRace() const { return Read<int32_t>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: IntProperty)

    void SET_TargetUpdateRateInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_SplinePositions(const TMap<AFortPlayerState*, FDelMarPositionValue>& Value) { Write<TMap<AFortPlayerState*, FDelMarPositionValue>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_RacePositions(const TArray<AFortPlayerState*>& Value) { Write<TArray<AFortPlayerState*>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_FinalRacePositions(const TArray<FDelMarFinalRacePositionEntry>& Value) { Write<TArray<FDelMarFinalRacePositionEntry>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_TimeSinceLastUpdate(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
    void SET_NumLapsInRace(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: IntProperty)
};

// Size: 0x2f8
class UDelMarRaceConfigComponent : public UDelMarRaceManagerComponent
{
public:
    bool bGhostReplayEnabled() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool bAllowExitingVehicles() const { return Read<bool>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool bResetPlayerRunOnUnregister() const { return Read<bool>(uintptr_t(this) + 0xba); } // 0xba (Size: 0x1, Type: BoolProperty)
    float MatchStartDelaySecondsOverride() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeWrongwayWarning() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeDemoWarningsAppear() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeMissedCheckpointDemo() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeReturnToTrackDemo() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    double DistanceFromTrackBeforeDemoWarning() const { return Read<double>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
    double DistanceFromVehicleBeforeReset() const { return Read<double>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    TArray<UClass*> ServerPlayerStateComponents() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ClientPlayerStateComponents() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ServerControllerComponents() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ClientControllerComponents() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    UClass* SpectatorControllerComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ClassProperty)
    FDelMarBotRuntimeConfig BotRuntimeConfig() const { return Read<FDelMarBotRuntimeConfig>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x28, Type: StructProperty)
    FDelMarMatchmakingConfig MatchmakingConfig() const { return Read<FDelMarMatchmakingConfig>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x1c, Type: StructProperty)
    FDelMarStartlineConfig StartlineConfig() const { return Read<FDelMarStartlineConfig>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleRuntimeConfig VehicleRuntimeConfig() const { return Read<FDelMarVehicleRuntimeConfig>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleAbilityConfig VehicleAbilityConfig() const { return Read<FDelMarVehicleAbilityConfig>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x11, Type: StructProperty)
    FDelMarRespawnConfig RespawnConfig() const { return Read<FDelMarRespawnConfig>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x10, Type: StructProperty)
    FDelMarRubberbandingConfig DefaultRubberbandingConfig() const { return Read<FDelMarRubberbandingConfig>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    TArray<FDelMarRubberbandingMMRConfig> RubberbandingMMRConfigs() const { return Read<TArray<FDelMarRubberbandingMMRConfig>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarRubberbandingMMRConfig> RubberbandingMMROverrideConfigs() const { return Read<TArray<FDelMarRubberbandingMMRConfig>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FDelMarRubberbandingConfig> NonMMRRubberbandingConfigs() const { return Read<TMap<FString, FDelMarRubberbandingConfig>>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x50, Type: MapProperty)
    TMap<FString, FDelMarRubberbandingConfig> NonMMRRubberbandingOverrideConfigs() const { return Read<TMap<FString, FDelMarRubberbandingConfig>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x50, Type: MapProperty)

    void SET_bGhostReplayEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowExitingVehicles(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    void SET_bResetPlayerRunOnUnregister(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba, Value); } // 0xba (Size: 0x1, Type: BoolProperty)
    void SET_MatchStartDelaySecondsOverride(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_SecondsBeforeWrongwayWarning(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_SecondsBeforeDemoWarningsAppear(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_SecondsBeforeMissedCheckpointDemo(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_SecondsBeforeReturnToTrackDemo(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_DistanceFromTrackBeforeDemoWarning(const double& Value) { Write<double>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
    void SET_DistanceFromVehicleBeforeReset(const double& Value) { Write<double>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    void SET_ServerPlayerStateComponents(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_ClientPlayerStateComponents(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerControllerComponents(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_ClientControllerComponents(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    void SET_SpectatorControllerComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ClassProperty)
    void SET_BotRuntimeConfig(const FDelMarBotRuntimeConfig& Value) { Write<FDelMarBotRuntimeConfig>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x28, Type: StructProperty)
    void SET_MatchmakingConfig(const FDelMarMatchmakingConfig& Value) { Write<FDelMarMatchmakingConfig>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x1c, Type: StructProperty)
    void SET_StartlineConfig(const FDelMarStartlineConfig& Value) { Write<FDelMarStartlineConfig>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x28, Type: StructProperty)
    void SET_VehicleRuntimeConfig(const FDelMarVehicleRuntimeConfig& Value) { Write<FDelMarVehicleRuntimeConfig>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0xc, Type: StructProperty)
    void SET_VehicleAbilityConfig(const FDelMarVehicleAbilityConfig& Value) { Write<FDelMarVehicleAbilityConfig>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x11, Type: StructProperty)
    void SET_RespawnConfig(const FDelMarRespawnConfig& Value) { Write<FDelMarRespawnConfig>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x10, Type: StructProperty)
    void SET_DefaultRubberbandingConfig(const FDelMarRubberbandingConfig& Value) { Write<FDelMarRubberbandingConfig>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x28, Type: StructProperty)
    void SET_RubberbandingMMRConfigs(const TArray<FDelMarRubberbandingMMRConfig>& Value) { Write<TArray<FDelMarRubberbandingMMRConfig>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    void SET_RubberbandingMMROverrideConfigs(const TArray<FDelMarRubberbandingMMRConfig>& Value) { Write<TArray<FDelMarRubberbandingMMRConfig>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: ArrayProperty)
    void SET_NonMMRRubberbandingConfigs(const TMap<FString, FDelMarRubberbandingConfig>& Value) { Write<TMap<FString, FDelMarRubberbandingConfig>>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x50, Type: MapProperty)
    void SET_NonMMRRubberbandingOverrideConfigs(const TMap<FString, FDelMarRubberbandingConfig>& Value) { Write<TMap<FString, FDelMarRubberbandingConfig>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x50, Type: MapProperty)
};

// Size: 0xd8
class UDelMarRequestTrackerComponent : public UDelMarRaceManagerComponent
{
public:
    FDelMarEvent_TrackedPlayerReadyStates PlayerReadyStates() const { return Read<FDelMarEvent_TrackedPlayerReadyStates>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x20, Type: StructProperty)

    void SET_PlayerReadyStates(const FDelMarEvent_TrackedPlayerReadyStates& Value) { Write<FDelMarEvent_TrackedPlayerReadyStates>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x150
class UDelMarRespawnManagerComponent : public UDelMarRaceManagerComponent
{
public:
    float RespawnRetrySeconds() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager() const { return Read<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarPlayerStart*> CachedChallengeStartSpawnPoint() const { return Read<TWeakObjectPtr<ADelMarPlayerStart*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AController*>> RespawnRetryQueue() const { return Read<TArray<TWeakObjectPtr<AController*>>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TMap<TWeakObjectPtr<AFortPlayerState*>, TWeakObjectPtr<ADelMarVehicle*>> LastSpawnedVehicleMap() const { return Read<TMap<TWeakObjectPtr<AFortPlayerState*>, TWeakObjectPtr<ADelMarVehicle*>>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x50, Type: MapProperty)

    void SET_RespawnRetrySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_CachedCheckpointManager(const TWeakObjectPtr<UDelMarCheckpointManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarCheckpointManagerComponent*>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedChallengeStartSpawnPoint(const TWeakObjectPtr<ADelMarPlayerStart*>& Value) { Write<TWeakObjectPtr<ADelMarPlayerStart*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RespawnRetryQueue(const TArray<TWeakObjectPtr<AController*>>& Value) { Write<TArray<TWeakObjectPtr<AController*>>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_LastSpawnedVehicleMap(const TMap<TWeakObjectPtr<AFortPlayerState*>, TWeakObjectPtr<ADelMarVehicle*>>& Value) { Write<TMap<TWeakObjectPtr<AFortPlayerState*>, TWeakObjectPtr<ADelMarVehicle*>>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x100
class UDelMarRubberbandingManagerComponent : public UDelMarRaceManagerComponent
{
public:
    float PackDistance() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    FDelMarRubberbandingConfig RubberbandingConfig() const { return Read<FDelMarRubberbandingConfig>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x28, Type: StructProperty)
    int32_t MMRUsed() const { return Read<int32_t>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: IntProperty)

    void SET_PackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_RubberbandingConfig(const FDelMarRubberbandingConfig& Value) { Write<FDelMarRubberbandingConfig>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x28, Type: StructProperty)
    void SET_MMRUsed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: IntProperty)
};

// Size: 0x1c0
class UDelMarGameStateMachine : public UDelMarStateMachine
{
public:
};

// Size: 0x30
class UDelMarState_Gameplay : public UDelMarState
{
public:
};

// Size: 0x30
class UDelMarState_Gameplay_ActiveRace : public UDelMarGameplayState
{
public:
};

// Size: 0x2b0
class UDelMarState_Gameplay_Postrace : public UDelMarGameplayState
{
public:
    float PostRaceDuration() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    double PostRaceEndServerTime() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    TSet<TWeakObjectPtr<AFortPlayerState*>> ReadyPlayers() const { return Read<TSet<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: SetProperty)
    TWeakObjectPtr<ADelMarPlayspace*> CachedPlayspace() const { return Read<TWeakObjectPtr<ADelMarPlayspace*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)
    FString EliminationList() const { return Read<FString>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StrProperty)

    void SET_PostRaceDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_PostRaceEndServerTime(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    void SET_ReadyPlayers(const TSet<TWeakObjectPtr<AFortPlayerState*>>& Value) { Write<TSet<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: SetProperty)
    void SET_CachedPlayspace(const TWeakObjectPtr<ADelMarPlayspace*>& Value) { Write<TWeakObjectPtr<ADelMarPlayspace*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EliminationList(const FString& Value) { Write<FString>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x48
class UDelMarState_Gameplay_Prerace : public UDelMarGameplayState
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    double PreRaceCountdownFinishServerTime() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)

    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PreRaceCountdownFinishServerTime(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x90
class UDelMarState_Gameplay_WaitingForPlayers : public UDelMarGameplayState
{
public:
    int32_t MinPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*> MatchmakeRatingComponent() const { return Read<TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    FDelMarEvent_LoadedPlayerStates LoadedPlayerStates() const { return Read<FDelMarEvent_LoadedPlayerStates>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<AFortPartyBeaconHost*> FortPartyBeacon() const { return Read<TWeakObjectPtr<AFortPartyBeaconHost*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AContentBeaconHostObjectV2*> ContentBeacon() const { return Read<TWeakObjectPtr<AContentBeaconHostObjectV2*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: WeakObjectProperty)

    void SET_MinPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MatchmakeRatingComponent(const TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*>& Value) { Write<TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LoadedPlayerStates(const FDelMarEvent_LoadedPlayerStates& Value) { Write<FDelMarEvent_LoadedPlayerStates>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: StructProperty)
    void SET_FortPartyBeacon(const TWeakObjectPtr<AFortPartyBeaconHost*>& Value) { Write<TWeakObjectPtr<AFortPartyBeaconHost*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ContentBeacon(const TWeakObjectPtr<AContentBeaconHostObjectV2*>& Value) { Write<TWeakObjectPtr<AContentBeaconHostObjectV2*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x38
class UDelMarState_LevelSetup : public UDelMarGameplayState
{
public:
    bool bVehiclesReady() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bVehiclesSpawned() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)

    void SET_bVehiclesReady(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bVehiclesSpawned(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
class UDelMarState_Loading : public UDelMarGameplayState
{
public:
    float DelayBeforeLoadingActuallyStarts() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer DesiredMap() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: StructProperty)

    void SET_DelayBeforeLoadingActuallyStarts(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredMap(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: StructProperty)
};

// Size: 0x38
class UDelMarState_Lobby : public UDelMarGameplayState
{
public:
    bool bLevelLoadRequested() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_bLevelLoadRequested(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
class UDelMarState_Setup : public UDelMarGameplayState
{
public:
    bool bHasRequestedLink() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bHasRecievedMatchAssignment() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    bool bRequiresMatchAssignmentToProceed() const { return Read<bool>(uintptr_t(this) + 0x32); } // 0x32 (Size: 0x1, Type: BoolProperty)
    bool bCalledMapRotationService() const { return Read<bool>(uintptr_t(this) + 0x33); } // 0x33 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer DebugMapToLoad() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: StructProperty)
    FOnlineLinkId DebugIslandCodeToLoad() const { return Read<FOnlineLinkId>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_bHasRequestedLink(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bHasRecievedMatchAssignment(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_bRequiresMatchAssignmentToProceed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x32, Value); } // 0x32 (Size: 0x1, Type: BoolProperty)
    void SET_bCalledMapRotationService(const bool& Value) { Write<bool>(uintptr_t(this) + 0x33, Value); } // 0x33 (Size: 0x1, Type: BoolProperty)
    void SET_DebugMapToLoad(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: StructProperty)
    void SET_DebugIslandCodeToLoad(const FOnlineLinkId& Value) { Write<FOnlineLinkId>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x588
class UDelMarCameraShakeComponent : public UControllerComponent
{
public:
    TMap<EBrelmarCameraShake, float> ShakeIntensitySettingMap() const { return Read<TMap<EBrelmarCameraShake, float>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    UClass* JumpShakeEffect() const { return Read<UClass*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ClassProperty)
    UClass* HazardShakeEffect() const { return Read<UClass*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ClassProperty)
    bool bUseVehicleLandedKickflipShake() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    UClass* VehicleLandedKickflipShake() const { return Read<UClass*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ClassProperty)
    FDelMarScaledCurve VehicleLandedKickflipShakeIntensityCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x90, Type: StructProperty)
    UClass* VehicleLandedCameraShakeEffect() const { return Read<UClass*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    FDelMarScaledCurve VehicleLandedShakeIntensityCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x90, Type: StructProperty)
    float MaxSecondsToDampenVehicleHit() const { return Read<float>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve VehicleHitShakeIntensityCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x90, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect VehicleImpactShakeEffect() const { return Read<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0xa0, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect WallImpactShakeEffect() const { return Read<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0xa0, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect WallNoRedirectImpactShakeEffect() const { return Read<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0xa0, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect BaseAccelerationShakeEffect() const { return Read<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0xa0, Type: StructProperty)
    TScriptInterface<Class> Vehicle() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x10, Type: InterfaceProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ShakeIntensitySettingMap(const TMap<EBrelmarCameraShake, float>& Value) { Write<TMap<EBrelmarCameraShake, float>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_JumpShakeEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ClassProperty)
    void SET_HazardShakeEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ClassProperty)
    void SET_bUseVehicleLandedKickflipShake(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_VehicleLandedKickflipShake(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ClassProperty)
    void SET_VehicleLandedKickflipShakeIntensityCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x90, Type: StructProperty)
    void SET_VehicleLandedCameraShakeEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    void SET_VehicleLandedShakeIntensityCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x90, Type: StructProperty)
    void SET_MaxSecondsToDampenVehicleHit(const float& Value) { Write<float>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleHitShakeIntensityCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x90, Type: StructProperty)
    void SET_VehicleImpactShakeEffect(const FDelMarDynamicCameraShakeEffect& Value) { Write<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0xa0, Type: StructProperty)
    void SET_WallImpactShakeEffect(const FDelMarDynamicCameraShakeEffect& Value) { Write<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0xa0, Type: StructProperty)
    void SET_WallNoRedirectImpactShakeEffect(const FDelMarDynamicCameraShakeEffect& Value) { Write<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0xa0, Type: StructProperty)
    void SET_BaseAccelerationShakeEffect(const FDelMarDynamicCameraShakeEffect& Value) { Write<FDelMarDynamicCameraShakeEffect>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0xa0, Type: StructProperty)
    void SET_Vehicle(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x10, Type: InterfaceProperty)
    void SET_CachedPlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x23c0
class UDelMarVehicleConfigs : public UFortPhysicsVehicleConfigs
{
public:
    FDelMarVehicleCollisionConfig Collision() const { return Read<FDelMarVehicleCollisionConfig>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x1f8, Type: StructProperty)
    UDelMarVehicleBodySetup* DefaultBodySetup() const { return Read<UDelMarVehicleBodySetup*>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleBodySetupMap* BodySetupMap() const { return Read<UDelMarVehicleBodySetupMap*>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    FDelMarVehicleDriveSetup DriveSetup() const { return Read<FDelMarVehicleDriveSetup>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x370, Type: StructProperty)
    UDelMarPhysMatAttributeMap* PhysMatAttributeMap() const { return Read<UDelMarPhysMatAttributeMap*>(uintptr_t(this) + 0xf38); } // 0xf38 (Size: 0x8, Type: ObjectProperty)
    FDelMarVehicleRigidBodyConfig RigidBody() const { return Read<FDelMarVehicleRigidBodyConfig>(uintptr_t(this) + 0xf40); } // 0xf40 (Size: 0x38, Type: StructProperty)
    FDelMarVehicleConfig_Terrain Terrain() const { return Read<FDelMarVehicleConfig_Terrain>(uintptr_t(this) + 0xf78); } // 0xf78 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleConfig_WorldBonusSpeed WorldBonusSpeed() const { return Read<FDelMarVehicleConfig_WorldBonusSpeed>(uintptr_t(this) + 0xfa8); } // 0xfa8 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleConfig_AutoAerialRotation AerialRotation() const { return Read<FDelMarVehicleConfig_AutoAerialRotation>(uintptr_t(this) + 0xfd0); } // 0xfd0 (Size: 0xa8, Type: StructProperty)
    FDelMarVehicleConfig_AirControl AirControl() const { return Read<FDelMarVehicleConfig_AirControl>(uintptr_t(this) + 0x1078); } // 0x1078 (Size: 0xd0, Type: StructProperty)
    FDelMarVehicleConfig_AirFreestyle AirFreestyle() const { return Read<FDelMarVehicleConfig_AirFreestyle>(uintptr_t(this) + 0x1148); } // 0x1148 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleConfig_AirThrottle AirThrottle() const { return Read<FDelMarVehicleConfig_AirThrottle>(uintptr_t(this) + 0x1178); } // 0x1178 (Size: 0xa0, Type: StructProperty)
    FDelMarVehicleConfig_AutoUpright AutoUpright() const { return Read<FDelMarVehicleConfig_AutoUpright>(uintptr_t(this) + 0x1218); } // 0x1218 (Size: 0x24, Type: StructProperty)
    FDelMarVehicleDraftingConfig Drafting() const { return Read<FDelMarVehicleDraftingConfig>(uintptr_t(this) + 0x1240); } // 0x1240 (Size: 0xc8, Type: StructProperty)
    FDelMarVehicleDriftConfig Drift() const { return Read<FDelMarVehicleDriftConfig>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x718, Type: StructProperty)
    FDelMarVehicleDriftBoostConfig DriftBoost() const { return Read<FDelMarVehicleDriftBoostConfig>(uintptr_t(this) + 0x1a20); } // 0x1a20 (Size: 0x1d8, Type: StructProperty)
    FDelMarVehicleConfig_Gravity Gravity() const { return Read<FDelMarVehicleConfig_Gravity>(uintptr_t(this) + 0x1bf8); } // 0x1bf8 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleConfig_Jump Jump() const { return Read<FDelMarVehicleConfig_Jump>(uintptr_t(this) + 0x1c18); } // 0x1c18 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleConfig_Kickflip Kickflip() const { return Read<FDelMarVehicleConfig_Kickflip>(uintptr_t(this) + 0x1c30); } // 0x1c30 (Size: 0x158, Type: StructProperty)
    FDelMarVehicleOversteerConfig Oversteer() const { return Read<FDelMarVehicleOversteerConfig>(uintptr_t(this) + 0x1d88); } // 0x1d88 (Size: 0x138, Type: StructProperty)
    FDelMarVehicleConfig_Reattachment Reattachment() const { return Read<FDelMarVehicleConfig_Reattachment>(uintptr_t(this) + 0x1ec0); } // 0x1ec0 (Size: 0xa0, Type: StructProperty)
    FDelMarVehicleConfig_Rubberbanding Rubberbanding() const { return Read<FDelMarVehicleConfig_Rubberbanding>(uintptr_t(this) + 0x1f60); } // 0x1f60 (Size: 0x1b8, Type: StructProperty)
    FDelMarVehicleConfig_StartlineBoost StartlineBoost() const { return Read<FDelMarVehicleConfig_StartlineBoost>(uintptr_t(this) + 0x2118); } // 0x2118 (Size: 0xa8, Type: StructProperty)
    FDelMarVehicleConfig_Strafe Strafe() const { return Read<FDelMarVehicleConfig_Strafe>(uintptr_t(this) + 0x21c0); } // 0x21c0 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleTurboConfig Turbo() const { return Read<FDelMarVehicleTurboConfig>(uintptr_t(this) + 0x21e0); } // 0x21e0 (Size: 0x70, Type: StructProperty)
    FDelMarVehicleConfig_Underthrust Underthrust() const { return Read<FDelMarVehicleConfig_Underthrust>(uintptr_t(this) + 0x2250); } // 0x2250 (Size: 0x168, Type: StructProperty)
    FDelMarVehicleConfig_SelfDemolish SelfDemolish() const { return Read<FDelMarVehicleConfig_SelfDemolish>(uintptr_t(this) + 0x23b8); } // 0x23b8 (Size: 0x8, Type: StructProperty)

    void SET_Collision(const FDelMarVehicleCollisionConfig& Value) { Write<FDelMarVehicleCollisionConfig>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x1f8, Type: StructProperty)
    void SET_DefaultBodySetup(const UDelMarVehicleBodySetup*& Value) { Write<UDelMarVehicleBodySetup*>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    void SET_BodySetupMap(const UDelMarVehicleBodySetupMap*& Value) { Write<UDelMarVehicleBodySetupMap*>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    void SET_DriveSetup(const FDelMarVehicleDriveSetup& Value) { Write<FDelMarVehicleDriveSetup>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x370, Type: StructProperty)
    void SET_PhysMatAttributeMap(const UDelMarPhysMatAttributeMap*& Value) { Write<UDelMarPhysMatAttributeMap*>(uintptr_t(this) + 0xf38, Value); } // 0xf38 (Size: 0x8, Type: ObjectProperty)
    void SET_RigidBody(const FDelMarVehicleRigidBodyConfig& Value) { Write<FDelMarVehicleRigidBodyConfig>(uintptr_t(this) + 0xf40, Value); } // 0xf40 (Size: 0x38, Type: StructProperty)
    void SET_Terrain(const FDelMarVehicleConfig_Terrain& Value) { Write<FDelMarVehicleConfig_Terrain>(uintptr_t(this) + 0xf78, Value); } // 0xf78 (Size: 0x30, Type: StructProperty)
    void SET_WorldBonusSpeed(const FDelMarVehicleConfig_WorldBonusSpeed& Value) { Write<FDelMarVehicleConfig_WorldBonusSpeed>(uintptr_t(this) + 0xfa8, Value); } // 0xfa8 (Size: 0x28, Type: StructProperty)
    void SET_AerialRotation(const FDelMarVehicleConfig_AutoAerialRotation& Value) { Write<FDelMarVehicleConfig_AutoAerialRotation>(uintptr_t(this) + 0xfd0, Value); } // 0xfd0 (Size: 0xa8, Type: StructProperty)
    void SET_AirControl(const FDelMarVehicleConfig_AirControl& Value) { Write<FDelMarVehicleConfig_AirControl>(uintptr_t(this) + 0x1078, Value); } // 0x1078 (Size: 0xd0, Type: StructProperty)
    void SET_AirFreestyle(const FDelMarVehicleConfig_AirFreestyle& Value) { Write<FDelMarVehicleConfig_AirFreestyle>(uintptr_t(this) + 0x1148, Value); } // 0x1148 (Size: 0x30, Type: StructProperty)
    void SET_AirThrottle(const FDelMarVehicleConfig_AirThrottle& Value) { Write<FDelMarVehicleConfig_AirThrottle>(uintptr_t(this) + 0x1178, Value); } // 0x1178 (Size: 0xa0, Type: StructProperty)
    void SET_AutoUpright(const FDelMarVehicleConfig_AutoUpright& Value) { Write<FDelMarVehicleConfig_AutoUpright>(uintptr_t(this) + 0x1218, Value); } // 0x1218 (Size: 0x24, Type: StructProperty)
    void SET_Drafting(const FDelMarVehicleDraftingConfig& Value) { Write<FDelMarVehicleDraftingConfig>(uintptr_t(this) + 0x1240, Value); } // 0x1240 (Size: 0xc8, Type: StructProperty)
    void SET_Drift(const FDelMarVehicleDriftConfig& Value) { Write<FDelMarVehicleDriftConfig>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x718, Type: StructProperty)
    void SET_DriftBoost(const FDelMarVehicleDriftBoostConfig& Value) { Write<FDelMarVehicleDriftBoostConfig>(uintptr_t(this) + 0x1a20, Value); } // 0x1a20 (Size: 0x1d8, Type: StructProperty)
    void SET_Gravity(const FDelMarVehicleConfig_Gravity& Value) { Write<FDelMarVehicleConfig_Gravity>(uintptr_t(this) + 0x1bf8, Value); } // 0x1bf8 (Size: 0x20, Type: StructProperty)
    void SET_Jump(const FDelMarVehicleConfig_Jump& Value) { Write<FDelMarVehicleConfig_Jump>(uintptr_t(this) + 0x1c18, Value); } // 0x1c18 (Size: 0x18, Type: StructProperty)
    void SET_Kickflip(const FDelMarVehicleConfig_Kickflip& Value) { Write<FDelMarVehicleConfig_Kickflip>(uintptr_t(this) + 0x1c30, Value); } // 0x1c30 (Size: 0x158, Type: StructProperty)
    void SET_Oversteer(const FDelMarVehicleOversteerConfig& Value) { Write<FDelMarVehicleOversteerConfig>(uintptr_t(this) + 0x1d88, Value); } // 0x1d88 (Size: 0x138, Type: StructProperty)
    void SET_Reattachment(const FDelMarVehicleConfig_Reattachment& Value) { Write<FDelMarVehicleConfig_Reattachment>(uintptr_t(this) + 0x1ec0, Value); } // 0x1ec0 (Size: 0xa0, Type: StructProperty)
    void SET_Rubberbanding(const FDelMarVehicleConfig_Rubberbanding& Value) { Write<FDelMarVehicleConfig_Rubberbanding>(uintptr_t(this) + 0x1f60, Value); } // 0x1f60 (Size: 0x1b8, Type: StructProperty)
    void SET_StartlineBoost(const FDelMarVehicleConfig_StartlineBoost& Value) { Write<FDelMarVehicleConfig_StartlineBoost>(uintptr_t(this) + 0x2118, Value); } // 0x2118 (Size: 0xa8, Type: StructProperty)
    void SET_Strafe(const FDelMarVehicleConfig_Strafe& Value) { Write<FDelMarVehicleConfig_Strafe>(uintptr_t(this) + 0x21c0, Value); } // 0x21c0 (Size: 0x1c, Type: StructProperty)
    void SET_Turbo(const FDelMarVehicleTurboConfig& Value) { Write<FDelMarVehicleTurboConfig>(uintptr_t(this) + 0x21e0, Value); } // 0x21e0 (Size: 0x70, Type: StructProperty)
    void SET_Underthrust(const FDelMarVehicleConfig_Underthrust& Value) { Write<FDelMarVehicleConfig_Underthrust>(uintptr_t(this) + 0x2250, Value); } // 0x2250 (Size: 0x168, Type: StructProperty)
    void SET_SelfDemolish(const FDelMarVehicleConfig_SelfDemolish& Value) { Write<FDelMarVehicleConfig_SelfDemolish>(uintptr_t(this) + 0x23b8, Value); } // 0x23b8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x108
class UDelMarVehicleCosmeticComponent : public UActorComponent
{
public:
    TArray<TSoftClassPtr> StaticCosmeticActorClasses() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> AllowedServerCosmeticActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TArray<ADelMarCosmeticActor*> SpawnedCosmeticActors() const { return Read<TArray<ADelMarCosmeticActor*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)

    void SET_StaticCosmeticActorClasses(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_AllowedServerCosmeticActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_SpawnedCosmeticActors(const TArray<ADelMarCosmeticActor*>& Value) { Write<TArray<ADelMarCosmeticActor*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x410
class UDelMarVehicleForceFeedbackComponent : public UControllerComponent
{
public:
    FDelMarDynamicForceFeedbackEffect DrivingForceFeedback() const { return Read<FDelMarDynamicForceFeedbackEffect>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x128, Type: StructProperty)
    UForceFeedbackEffect* JumpForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* OversteerLeftForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* OversteerRightForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: ObjectProperty)
    TArray<UForceFeedbackEffect*> LandingForceFeedbackEffects() const { return Read<TArray<UForceFeedbackEffect*>>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    FRuntimeFloatCurve LandingForceLevelLookupCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x88, Type: StructProperty)
    UForceFeedbackEffect* TurboForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: ObjectProperty)
    FDelMarDynamicForceFeedbackEffect DriftForceFeedback() const { return Read<FDelMarDynamicForceFeedbackEffect>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x128, Type: StructProperty)
    UForceFeedbackEffect* DriftUncontrolledForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* DriftBoostForceFeedbackEffect() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* DriftTractionForceFeedback() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    float MaxTractionDriftShakeAngle() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    UForceFeedbackEffect* HazardHitForceFeedback() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> Vehicle() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x10, Type: InterfaceProperty)
    TWeakObjectPtr<APlayerController*> CachedPlayerController() const { return Read<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UForceFeedbackEffect*> CurrentOversteerForceFeedbackEffect() const { return Read<TWeakObjectPtr<UForceFeedbackEffect*>>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: WeakObjectProperty)

    void SET_DrivingForceFeedback(const FDelMarDynamicForceFeedbackEffect& Value) { Write<FDelMarDynamicForceFeedbackEffect>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x128, Type: StructProperty)
    void SET_JumpForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    void SET_OversteerLeftForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    void SET_OversteerRightForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: ObjectProperty)
    void SET_LandingForceFeedbackEffects(const TArray<UForceFeedbackEffect*>& Value) { Write<TArray<UForceFeedbackEffect*>>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    void SET_LandingForceLevelLookupCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x88, Type: StructProperty)
    void SET_TurboForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: ObjectProperty)
    void SET_DriftForceFeedback(const FDelMarDynamicForceFeedbackEffect& Value) { Write<FDelMarDynamicForceFeedbackEffect>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x128, Type: StructProperty)
    void SET_DriftUncontrolledForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_DriftBoostForceFeedbackEffect(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_DriftTractionForceFeedback(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxTractionDriftShakeAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_HazardHitForceFeedback(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Vehicle(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x10, Type: InterfaceProperty)
    void SET_CachedPlayerController(const TWeakObjectPtr<APlayerController*>& Value) { Write<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentOversteerForceFeedbackEffect(const TWeakObjectPtr<UForceFeedbackEffect*>& Value) { Write<TWeakObjectPtr<UForceFeedbackEffect*>>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xa8
class UDelMarVehicleMovementSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData AccelMultiplier() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData bVehicleThrottleDisabled() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData BonusSpeed() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x28, Type: StructProperty)

    void SET_AccelMultiplier(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_bVehicleThrottleDisabled(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
    void SET_BonusSpeed(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x28, Type: StructProperty)
};

// Size: 0xd8
class UDelMarVehicleTurboManagerComponent : public UActorComponent
{
public:
    float TurboCharges() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float RechargeRateSeconds() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxCharges() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    ADelMarVehicle* OwnerVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_TurboCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_RechargeRateSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MaxCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_OwnerVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FDelMarEnvironmentVFX
{
public:
    UNiagaraSystem* OnAppliedFX() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* WhileAppliedFX() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* OnRemovedFX() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_OnAppliedFX(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_WhileAppliedFX(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnRemovedFX(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarAIDifficultySpawnInfo
{
public:
    int32_t SkillLevel() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float BotFillPercentage() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_SkillLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_BotFillPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FDelMarAIMMRSpawnDataTableRow : public FTableRowBase
{
public:
    int32_t MMRBracketLow() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MMRBracketHigh() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t FallbackSkillLevel() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    TArray<FDelMarAIDifficultySpawnInfo> BotSpawnInfo() const { return Read<TArray<FDelMarAIDifficultySpawnInfo>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_MMRBracketLow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_MMRBracketHigh(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_FallbackSkillLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_BotSpawnInfo(const TArray<FDelMarAIDifficultySpawnInfo>& Value) { Write<TArray<FDelMarAIDifficultySpawnInfo>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FDelMarAIVehicleCosmeticSlotDataTableInfo
{
public:
    TSoftObjectPtr<UCosmeticLoadoutSlotTemplate> SlotTemplate() const { return Read<TSoftObjectPtr<UCosmeticLoadoutSlotTemplate>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UDataTable> VehicleSlotCosmeticDataTable() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)

    void SET_SlotTemplate(const TSoftObjectPtr<UCosmeticLoadoutSlotTemplate>& Value) { Write<TSoftObjectPtr<UCosmeticLoadoutSlotTemplate>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_VehicleSlotCosmeticDataTable(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x40
struct FDelMarCosmeticLoadoutSlotData
{
public:
    TSoftObjectPtr<UCosmeticLoadoutSlotTemplate> SlotTemplate() const { return Read<TSoftObjectPtr<UCosmeticLoadoutSlotTemplate>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UObject> EquippedItemDefinitionObject() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)

    void SET_SlotTemplate(const TSoftObjectPtr<UCosmeticLoadoutSlotTemplate>& Value) { Write<TSoftObjectPtr<UCosmeticLoadoutSlotTemplate>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_EquippedItemDefinitionObject(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x20
struct FDelMarAIVehicleCosmeticLoadoutSetDataTableRow : public FTableRowBase
{
public:
    TArray<FDelMarCosmeticLoadoutSlotData> LoadoutSlots() const { return Read<TArray<FDelMarCosmeticLoadoutSlotData>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_LoadoutSlots(const TArray<FDelMarCosmeticLoadoutSlotData>& Value) { Write<TArray<FDelMarCosmeticLoadoutSlotData>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDelMarAIVehicleCosmeticSlotDataTableRow : public FTableRowBase
{
public:
    TSoftObjectPtr<UObject> EquippedItemDefinitionObject() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_EquippedItemDefinitionObject(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FDelMarAITrackDecision
{
public:
    TWeakObjectPtr<ADelMarTrack*> Track() const { return Read<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Track(const TWeakObjectPtr<ADelMarTrack*>& Value) { Write<TWeakObjectPtr<ADelMarTrack*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xd0
struct FDriveHazardInfo
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> HazardTrackSplineComponent() const { return Read<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_HazardTrackSplineComponent(const TWeakObjectPtr<UDelMarTrackSplineComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x90
struct FAvoidanceInfo
{
public:
};

// Size: 0x50
struct FDelMarCosmeticSlotInfo
{
public:
    FGameplayTag SlotTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FText SlotName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    bool bCanBeEmpty() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UTexture2D> UnassignedPreviewImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)

    void SET_SlotTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_SlotName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_ShortDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_bCanBeEmpty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_UnassignedPreviewImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x8
struct FDelMarEvent_DriverInteractionAdded
{
public:
};

// Size: 0x18
struct FDelMarEventRouterExt
{
public:
    bool bWorldIsTearingDown() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    UGameplayEventRouterComponent* EventRouter() const { return Read<UGameplayEventRouterComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UObject* EventRouterContextObject() const { return Read<UObject*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_bWorldIsTearingDown(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_EventRouter(const UGameplayEventRouterComponent*& Value) { Write<UGameplayEventRouterComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_EventRouterContextObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarGameplayStateChangedEvent
{
public:
    FGameplayTag PrevStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_PrevStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_NewStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x1
struct FDelMarEvent_ResetRace
{
public:
};

// Size: 0x1
struct FDelMarEvent_ResetRun
{
public:
};

// Size: 0x8
struct FDelMarEvent_RaceFinished
{
public:
};

// Size: 0x10
struct FDelMarEvent_FirstPlayerFinishedCountdown
{
public:
};

// Size: 0x8
struct FDelMarEvent_RaceActive
{
public:
};

// Size: 0x10
struct FDelMarEvent_RunActive
{
public:
};

// Size: 0x8
struct FDelMarEvent_OvertimeActive
{
public:
};

// Size: 0x28
struct FDelMarEvent_CountdownActive
{
public:
};

// Size: 0x18
struct FDelMarEvent_PlayerFinishedRace
{
public:
};

// Size: 0x10
struct FDelMarEvent_RacerStateChanged
{
public:
    FGameplayTag PrevStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)

    void SET_PrevStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_NewStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FDelMarEvent_PlayerBecomeSpectator
{
public:
};

// Size: 0x8
struct FDelMarEvent_RaceManagerInitialized
{
public:
};

// Size: 0x8
struct FDelMarEvent_VehicleAssignedToPawn
{
public:
};

// Size: 0x8
struct FDelMarEvent_ServerRaceStartCountdownTime
{
public:
    double ServerTime() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)

    void SET_ServerTime(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x8
struct FDelMarEvent_ServerPostRaceEndTime
{
public:
    double ServerTime() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)

    void SET_ServerTime(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xc
struct FDelMarEvent_VehicleDemolished
{
public:
    FGameplayTag CausedByTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_CausedByTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x1
struct FDelMarEvent_VehicleWrongwayStatus
{
public:
};

// Size: 0x8
struct FDelMarEvent_MissedCheckpointDemoCountdown
{
public:
};

// Size: 0x8
struct FDelMarEvent_ReturnToTrackDemoCountdown
{
public:
};

// Size: 0x20
struct FDelMarEvent_TrackedPlayerReadyStates
{
public:
    TArray<TWeakObjectPtr<AFortPlayerState*>> ReadyPlayers() const { return Read<TArray<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerState*>> UnreadyPlayers() const { return Read<TArray<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ReadyPlayers(const TArray<TWeakObjectPtr<AFortPlayerState*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_UnreadyPlayers(const TArray<TWeakObjectPtr<AFortPlayerState*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPlayerState*>>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FDelMarEvent_LoadedPlayerStates
{
public:
    int32_t NumLoadedPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TotalPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_NumLoadedPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_TotalPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FDelMarEvent_LoadingScreenData
{
public:
    UDelMarLevelDataAsset* LevelData() const { return Read<UDelMarLevelDataAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag RaceMode() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_LevelData(const UDelMarLevelDataAsset*& Value) { Write<UDelMarLevelDataAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_RaceMode(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FDelMarEvent_DialogRequest
{
public:
    FGameplayTag DialogTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_DialogTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FDelMarEvent_MatchmakingReadyUp
{
public:
    TWeakObjectPtr<UFortLocalPlayer*> LocalPlayer() const { return Read<TWeakObjectPtr<UFortLocalPlayer*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_LocalPlayer(const TWeakObjectPtr<UFortLocalPlayer*>& Value) { Write<TWeakObjectPtr<UFortLocalPlayer*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x48
struct FDelMarEvent_SetTutorialHint
{
public:
    FText KBMText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText TouchText() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)
    float DisplayTime() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    TArray<UInputAction*> AssociatedInputActions() const { return Read<TArray<UInputAction*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_KBMText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_GamepadText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_TouchText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
    void SET_DisplayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_AssociatedInputActions(const TArray<UInputAction*>& Value) { Write<TArray<UInputAction*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FDelMarEvent_SetTutorialAnnouncement
{
public:
    FText KBMText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText TouchText() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)
    TArray<UInputAction*> AssociatedInputActions() const { return Read<TArray<UInputAction*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_KBMText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_GamepadText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_TouchText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
    void SET_AssociatedInputActions(const TArray<UInputAction*>& Value) { Write<TArray<UInputAction*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FDelMarEvent_MidTutorialModal
{
public:
};

// Size: 0x20
struct FDelMarEvent_SetControlsText
{
public:
    FText KBMText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)

    void SET_KBMText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_GamepadText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
};

// Size: 0x18
struct FDelMarEvent_CheckpointPassed_ParallelPath
{
public:
    AFortPlayerState* PlayerState() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarCheckpoint*> CurrentCheckPoint() const { return Read<TWeakObjectPtr<ADelMarCheckpoint*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    int32_t CheckpointIndexForLap() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_PlayerState(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentCheckPoint(const TWeakObjectPtr<ADelMarCheckpoint*>& Value) { Write<TWeakObjectPtr<ADelMarCheckpoint*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CheckpointIndexForLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath
{
public:
    ADelMarCheckpoint* CurrentCheckPoint() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentCheckPoint(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarEvent_TeleportEnteredEvent
{
public:
    ADelMarCheckpoint* CheckpointEntered() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CheckpointEntered(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarEvent_TeleportExitedEvent
{
public:
    ADelMarCheckpoint* CheckpointExited() const { return Read<ADelMarCheckpoint*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_CheckpointExited(const ADelMarCheckpoint*& Value) { Write<ADelMarCheckpoint*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FDelMarEvent_SectionComplete_ParallelPath
{
public:
    int32_t ActiveLap() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SectionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarCheckpoint*> CompletedCheckpoint() const { return Read<TWeakObjectPtr<ADelMarCheckpoint*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarCheckpoint*> CurrentCheckPoint() const { return Read<TWeakObjectPtr<ADelMarCheckpoint*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    double CompletedSectionTime() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_ActiveLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SectionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_CompletedCheckpoint(const TWeakObjectPtr<ADelMarCheckpoint*>& Value) { Write<TWeakObjectPtr<ADelMarCheckpoint*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentCheckPoint(const TWeakObjectPtr<ADelMarCheckpoint*>& Value) { Write<TWeakObjectPtr<ADelMarCheckpoint*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CompletedSectionTime(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x8
struct FDelMarEvent_LapStarted
{
public:
    AFortPlayerState* PlayerState() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerState(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FDelMarEvent_LapComplete
{
public:
    AFortPlayerState* PlayerState() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t CompletedLap() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t CurrentLap() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t TotalLaps() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    double CompletedLapTime() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_PlayerState(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CompletedLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_CurrentLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_TotalLaps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_CompletedLapTime(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x30
struct FDelMarEvent_LapRecorded
{
public:
    int32_t CompletedLap() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FDelMarRunRecord CurrentRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    float BestSingleLapTime() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bIsNewLapRecord() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_CompletedLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_CurrentRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_BestSingleLapTime(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_bIsNewLapRecord(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FDelMarRunRecord
{
public:
    double RunDuration() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double RunStartTimestamp() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    TArray<FDelMarLapRecord> LapRecords() const { return Read<TArray<FDelMarLapRecord>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_RunDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_RunStartTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_LapRecords(const TArray<FDelMarLapRecord>& Value) { Write<TArray<FDelMarLapRecord>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarLapRecord
{
public:
    double LapDuration() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    TArray<double> SectionTimes() const { return Read<TArray<double>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_LapDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_SectionTimes(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FDelMarEvent_SectionRecorded
{
public:
    int32_t ActiveLap() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SectionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FDelMarRunRecord BestSectionsRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord CurrentRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    bool bIsNewSectionRecord() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_ActiveLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SectionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_BestSectionsRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_CurrentRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_bIsNewSectionRecord(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FDelMarEvent_RunRecorded
{
public:
    AFortPlayerState* PlayerState() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FDelMarRunRecord CurrentRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord BestRunRecord() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    bool bIsNewBestRun() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_PlayerState(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_BestRunRecord(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_bIsNewBestRun(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FDelMarEvent_NuxConnectedHintActionPerformed
{
public:
    FGameplayTag HintTypeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    bool bDidPerformAction() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_HintTypeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_bDidPerformAction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FDelMarEvent_RaceModeSet
{
public:
    FGameplayTag RaceModeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_RaceModeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x48
struct FDelMarEvent_GlobalLeaderboardNewPersonalBest
{
public:
    TWeakObjectPtr<AFortPlayerState*> Player() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FDelMarGlobalLeaderboardEntry PersonalBest() const { return Read<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x40, Type: StructProperty)

    void SET_Player(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PersonalBest(const FDelMarGlobalLeaderboardEntry& Value) { Write<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x40, Type: StructProperty)
};

// Size: 0x40
struct FDelMarGlobalLeaderboardEntry
{
public:
    FString PlayerAccountId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString PlayerName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    double RunDuration() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    int64_t Rank() const { return Read<int64_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: Int64Property)
    double Percentile() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    bool bIsLocalPlayer() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_PlayerAccountId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_PlayerName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_RunDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_Rank(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: Int64Property)
    void SET_Percentile(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsLocalPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FDelMarEvent_MatchmakingStateChanged
{
public:
    char NewPostMatchState() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)

    void SET_NewPostMatchState(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x1
struct FDelMarEvent_PostRaceReturnToLobbySelected
{
public:
};

// Size: 0x1
struct FDelMarEvent_PostRaceNextRaceSelected
{
public:
};

// Size: 0xc
struct FDelMarEvent_QuestScreenOpened
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag RaceState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RaceState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FDelMarEvent_QuestScreenClosed
{
public:
    float OpenedDuration() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FGameplayTag RaceState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_OpenedDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_RaceState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x14
struct FDelMarFloatModifier
{
public:
    FName Category() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EDelMarFloatOperation> Operation() const { return Read<TEnumAsByte<EDelMarFloatOperation>>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EDelMarModifierStackingPolicy> StackingPolicy() const { return Read<TEnumAsByte<EDelMarModifierStackingPolicy>>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: ByteProperty)
    int32_t Handle() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_Category(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Operation(const TEnumAsByte<EDelMarFloatOperation>& Value) { Write<TEnumAsByte<EDelMarFloatOperation>>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: ByteProperty)
    void SET_StackingPolicy(const TEnumAsByte<EDelMarModifierStackingPolicy>& Value) { Write<TEnumAsByte<EDelMarModifierStackingPolicy>>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: ByteProperty)
    void SET_Handle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FDelMarFloatAttribute
{
public:
    float BaseValue() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float FinalValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bClampMin() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float MinValue() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bClampMax() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float MaxValue() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    TArray<FDelMarFloatModifier> Modifiers() const { return Read<TArray<FDelMarFloatModifier>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    int32_t CurrentHandleIdx() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_BaseValue(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_FinalValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bClampMin(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_MinValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bClampMax(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_MaxValue(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Modifiers(const TArray<FDelMarFloatModifier>& Value) { Write<TArray<FDelMarFloatModifier>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentHandleIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

// Size: 0x50
struct FGhostReplayFrame
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    double time() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_time(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x20
struct FDelMarLeaderboardSettings
{
public:
    FString EventId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString WindowId() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_EventId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_WindowId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FDelMarInputAction
{
public:
    UInputAction* Action() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag DisabledTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_Action(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_DisabledTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FDelMarInputMappingContextData
{
public:
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    UFortInputMappingContext* MappingContext() const { return Read<UFortInputMappingContext*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_MappingContext(const UFortInputMappingContext*& Value) { Write<UFortInputMappingContext*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FDelMarActivatedInput
{
public:
    UInputAction* Action() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_Action(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FDelMarActivatedInputFrame
{
public:
    float duration() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<FDelMarActivatedInput> Inputs() const { return Read<TArray<FDelMarActivatedInput>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Inputs(const TArray<FDelMarActivatedInput>& Value) { Write<TArray<FDelMarActivatedInput>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FDelMarDisabledInputData
{
public:
    float duration() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    UClass* EffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)

    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilterBase : public FObjectiveFilter
{
public:
    FObjectiveSubjectTags LevelDescriptionId() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags GameModeId() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags VehicleTags() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x48, Type: StructProperty)
    uint8_t RequiredPlaylistTypeInfo() const { return Read<uint8_t>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: EnumProperty)
    TArray<TSoftObjectPtr<UDelMarCosmeticItemDefinition*>> RequiredCosmetics() const { return Read<TArray<TSoftObjectPtr<UDelMarCosmeticItemDefinition*>>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: ArrayProperty)

    void SET_LevelDescriptionId(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x48, Type: StructProperty)
    void SET_GameModeId(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x48, Type: StructProperty)
    void SET_VehicleTags(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x48, Type: StructProperty)
    void SET_RequiredPlaylistTypeInfo(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: EnumProperty)
    void SET_RequiredCosmetics(const TArray<TSoftObjectPtr<UDelMarCosmeticItemDefinition*>>& Value) { Write<TArray<TSoftObjectPtr<UDelMarCosmeticItemDefinition*>>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilter_BeatPlayers : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_BonusTurboActivated : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_BoostPadBonusSpeedEnded : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_BoostPadHit : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_Demolished : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_DistanceTraveled : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_DraftActivated : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_DriftBoostActivated : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredDriftBoostPercent() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredDriftBoostPercent(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_DriftBoostDeactivated : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredTotalDistance() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredTotalDistance(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_DriftComplete : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredDriftDuration() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredDriftDuration(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_HighestSpeedUpdated : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredHighestSpeed() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredHighestSpeed(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilter_InitialTurboActivated : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_JellyHit : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x198
struct FDelMarObjectiveFilter_Kickflipped : public FDelMarObjectiveFilterBase
{
public:
    uint8_t RequiredKickflipDirection() const { return Read<uint8_t>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: EnumProperty)

    void SET_RequiredKickflipDirection(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1d0
struct FDelMarObjectiveFilter_LapComplete : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredLapCompleteTime() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)
    FInt32Range RequiredLapCount() const { return Read<FInt32Range>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: StructProperty)
    FInt32Range RequiredLapPlacement() const { return Read<FInt32Range>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: StructProperty)

    void SET_RequiredLapCompleteTime(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
    void SET_RequiredLapCount(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: StructProperty)
    void SET_RequiredLapPlacement(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilter_LapStarted : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x1a8
struct FDelMarObjectiveFilter_PlacementUpdated : public FDelMarObjectiveFilterBase
{
public:
    FInt32Range RequiredCurrentPosition() const { return Read<FInt32Range>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: StructProperty)
    uint8_t RequiredPositionChangeInfo() const { return Read<uint8_t>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x1, Type: EnumProperty)

    void SET_RequiredCurrentPosition(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: StructProperty)
    void SET_RequiredPositionChangeInfo(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilter_PlayedDelMarExperience : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x1d8
struct FDelMarObjectiveFilter_RaceFinished : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredFinishTime() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)
    FInt32Range RequiredFinalPlacement() const { return Read<FInt32Range>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: StructProperty)
    FInt32Range RequiredPlayerCompetitiveRank() const { return Read<FInt32Range>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: StructProperty)

    void SET_RequiredFinishTime(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
    void SET_RequiredFinalPlacement(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: StructProperty)
    void SET_RequiredPlayerCompetitiveRank(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1a0
struct FDelMarObjectiveFilter_RankAchieved : public FDelMarObjectiveFilterBase
{
public:
    FInt32Range RequiredRank() const { return Read<FInt32Range>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: StructProperty)

    void SET_RequiredRank(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1c8
struct FDelMarObjectiveFilter_RunComplete : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredFinishTime() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)
    FInt32Range RequiredFinalPlacement() const { return Read<FInt32Range>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: StructProperty)

    void SET_RequiredFinishTime(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
    void SET_RequiredFinalPlacement(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_StartlineBoostActivated : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredStartlineBoostPercent() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredStartlineBoostPercent(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilter_StartlineBoostPercentEarned : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_UnderthrustDeactivated : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredPercentUsed() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredPercentUsed(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x190
struct FDelMarObjectiveFilter_UnderthrustPercentUsed : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x190
struct FDelMarObjectiveFilter_VehicleJumped : public FDelMarObjectiveFilterBase
{
public:
};

// Size: 0x1b0
struct FDelMarObjectiveFilter_VehicleLanded : public FDelMarObjectiveFilterBase
{
public:
    FDoubleRange RequiredTimeInAir() const { return Read<FDoubleRange>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: StructProperty)

    void SET_RequiredTimeInAir(const FDoubleRange& Value) { Write<FDoubleRange>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: StructProperty)
};

// Size: 0x40
struct FDelMarAnalyticsPlayerRaceData
{
public:
    AFortPlayerController* DriverPC() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_DriverPC(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FDelMarProxyMeshMaterialInfo
{
public:
    TArray<UMaterialInstanceDynamic*> MaterialArray() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_MaterialArray(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FDelMarRaceCVar
{
public:
    FString VariableName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_VariableName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FDelMarMusicTrack
{
public:
    USoundWave* StartLineIntro() const { return Read<USoundWave*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundWave* MainTrack() const { return Read<USoundWave*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    USoundWave* MainTrack_LowSpec() const { return Read<USoundWave*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    float BPM() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_StartLineIntro(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MainTrack(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_MainTrack_LowSpec(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_BPM(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1c
struct FDelMarEvent_MusicPlaylistUpdated
{
public:
    TWeakObjectPtr<USoundBase*> PreRaceMusic() const { return Read<TWeakObjectPtr<USoundBase*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USoundBase*> PostRaceMusic() const { return Read<TWeakObjectPtr<USoundBase*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)

    void SET_PreRaceMusic(const TWeakObjectPtr<USoundBase*>& Value) { Write<TWeakObjectPtr<USoundBase*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PostRaceMusic(const TWeakObjectPtr<USoundBase*>& Value) { Write<TWeakObjectPtr<USoundBase*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x98
struct FDelMarTutorialSection
{
public:
    float FinishTargetTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    ADelMarStartLineActor* StartLine() const { return Read<ADelMarStartLineActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    ADelMarStartLineActor* FinishLine() const { return Read<ADelMarStartLineActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> DisabledActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer InputDisabledTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleAbilityConfig VehicleAbilityConfig() const { return Read<FDelMarVehicleAbilityConfig>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x11, Type: StructProperty)
    float StartingTurboCharges() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    FText Title() const { return Read<FText>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: TextProperty)
    FDelMarEvent_SetControlsText ControlsText() const { return Read<FDelMarEvent_SetControlsText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: StructProperty)
    FGameplayTag DialogTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: StructProperty)
    bool bSkipCountdown() const { return Read<bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x1, Type: BoolProperty)

    void SET_FinishTargetTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_StartLine(const ADelMarStartLineActor*& Value) { Write<ADelMarStartLineActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_FinishLine(const ADelMarStartLineActor*& Value) { Write<ADelMarStartLineActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_DisabledActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_InputDisabledTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_VehicleAbilityConfig(const FDelMarVehicleAbilityConfig& Value) { Write<FDelMarVehicleAbilityConfig>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x11, Type: StructProperty)
    void SET_StartingTurboCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_Title(const FText& Value) { Write<FText>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: TextProperty)
    void SET_ControlsText(const FDelMarEvent_SetControlsText& Value) { Write<FDelMarEvent_SetControlsText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: StructProperty)
    void SET_DialogTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: StructProperty)
    void SET_bSkipCountdown(const bool& Value) { Write<bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x11
struct FDelMarVehicleAbilityConfig
{
public:
    bool bAirControlEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAirFreestyleEnabled() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bAirThrottleEnabled() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAutoAerialRotationEnabled() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bAutoUprightEnabled() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bDraftingEnabled() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bDriftEnabled() const { return Read<bool>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bDriftBoostEnabled() const { return Read<bool>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x1, Type: BoolProperty)
    bool bInfiniteUnderthrustEnabled() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bJumpEnabled() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bKickflipEnabled() const { return Read<bool>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x1, Type: BoolProperty)
    bool bOversteerEnabled() const { return Read<bool>(uintptr_t(this) + 0xb); } // 0xb (Size: 0x1, Type: BoolProperty)
    bool bReattachmentEnabled() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    bool bStartlineBoostEnabled() const { return Read<bool>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: BoolProperty)
    bool bStrafeEnabled() const { return Read<bool>(uintptr_t(this) + 0xe); } // 0xe (Size: 0x1, Type: BoolProperty)
    bool bTurboEnabled() const { return Read<bool>(uintptr_t(this) + 0xf); } // 0xf (Size: 0x1, Type: BoolProperty)
    bool bUnderthrustEnabled() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_bAirControlEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bAirFreestyleEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bAirThrottleEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoAerialRotationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoUprightEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bDraftingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_bDriftEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: BoolProperty)
    void SET_bDriftBoostEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x1, Type: BoolProperty)
    void SET_bInfiniteUnderthrustEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bJumpEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_bKickflipEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x1, Type: BoolProperty)
    void SET_bOversteerEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb, Value); } // 0xb (Size: 0x1, Type: BoolProperty)
    void SET_bReattachmentEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_bStartlineBoostEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: BoolProperty)
    void SET_bStrafeEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe, Value); } // 0xe (Size: 0x1, Type: BoolProperty)
    void SET_bTurboEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf, Value); } // 0xf (Size: 0x1, Type: BoolProperty)
    void SET_bUnderthrustEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
struct FDelMarEvent_TutorialSectionChanged
{
public:
    FDelMarTutorialSection CurrentSection() const { return Read<FDelMarTutorialSection>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x98, Type: StructProperty)
    int32_t CurrentSectionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: IntProperty)

    void SET_CurrentSection(const FDelMarTutorialSection& Value) { Write<FDelMarTutorialSection>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x98, Type: StructProperty)
    void SET_CurrentSectionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: IntProperty)
};

// Size: 0x90
struct FDelMarScaledCurve
{
public:
    float Scale() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve Curve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x88, Type: StructProperty)

    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Curve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x88, Type: StructProperty)
};

// Size: 0x30
struct FDelMarHintText
{
public:
    FText KBMText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText TouchText() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)

    void SET_KBMText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_GamepadText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_TouchText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
};

// Size: 0x14
struct FDelMarVehicleSuspensionConfig
{
public:
    float MaxRaise() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxDrop() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Stiffness() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float DampingCompression() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float DampingRelaxation() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_MaxRaise(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDrop(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Stiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_DampingCompression(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_DampingRelaxation(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FDelMarVehicleAxleConfig
{
public:
    float TranslateX() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float TranslateY() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float TranslateZ() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float WheelRadius() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float RestDistanceZ() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleSuspensionConfig Suspension() const { return Read<FDelMarVehicleSuspensionConfig>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x14, Type: StructProperty)

    void SET_TranslateX(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_TranslateY(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TranslateZ(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_WheelRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_RestDistanceZ(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Suspension(const FDelMarVehicleSuspensionConfig& Value) { Write<FDelMarVehicleSuspensionConfig>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x14, Type: StructProperty)
};

// Size: 0xb0
struct FDelMarCameraFloatProperty
{
public:
    bool bEvaluateInputOnCurve() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAccumulateInput() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve Curve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x88, Type: StructProperty)
    float InterpLambda() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float DecayLambda() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    FFloatRange ClampedRange() const { return Read<FFloatRange>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)

    void SET_bEvaluateInputOnCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bAccumulateInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_Curve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x88, Type: StructProperty)
    void SET_InterpLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_DecayLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_ClampedRange(const FFloatRange& Value) { Write<FFloatRange>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1d0
struct FDelMarCameraFloatBlendedProperty
{
public:
    bool bEvaluateInputOnCurve() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve InputCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x88, Type: StructProperty)
    float ActiveValue() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    bool bRemapOutputValue() const { return Read<bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve RemapCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x88, Type: StructProperty)
    float BlendInLambda() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float BlendOutLambda() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    bool bUseBlendOutCurve() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve BlendOutLambdaCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x88, Type: StructProperty)
    float Tolerance() const { return Read<float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: FloatProperty)

    void SET_bEvaluateInputOnCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_InputCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x88, Type: StructProperty)
    void SET_ActiveValue(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_bRemapOutputValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x1, Type: BoolProperty)
    void SET_RemapCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x88, Type: StructProperty)
    void SET_BlendInLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_BlendOutLambda(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_bUseBlendOutCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
    void SET_BlendOutLambdaCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x88, Type: StructProperty)
    void SET_Tolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FDelMarDefaultCameraValues
{
public:
    float FOV() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float AngleToOriginDegrees() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_FOV(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AngleToOriginDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
struct FDelMarVehicleReplay_FrameData
{
public:
    int32_t FrameCaptureIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    double SecondsSinceCountdownFinished() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    FDelMarVehicleReplay_InputState_RL Input() const { return Read<FDelMarVehicleReplay_InputState_RL>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleReplay_InputState_DM Input_DM() const { return Read<FDelMarVehicleReplay_InputState_DM>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleReplay_RigidBodyState PreSimRBState() const { return Read<FDelMarVehicleReplay_RigidBodyState>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x70, Type: StructProperty)

    void SET_FrameCaptureIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SecondsSinceCountdownFinished(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Input(const FDelMarVehicleReplay_InputState_RL& Value) { Write<FDelMarVehicleReplay_InputState_RL>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Input_DM(const FDelMarVehicleReplay_InputState_DM& Value) { Write<FDelMarVehicleReplay_InputState_DM>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: StructProperty)
    void SET_PreSimRBState(const FDelMarVehicleReplay_RigidBodyState& Value) { Write<FDelMarVehicleReplay_RigidBodyState>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x70, Type: StructProperty)
};

// Size: 0x70
struct FDelMarVehicleReplay_RigidBodyState
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FVector LinearVelocity() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_LinearVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x8
struct FDelMarVehicleReplay_InputState_DM
{
public:
    float AerialPitch() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bDrift() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bGroundedFlip() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bKickflip() const { return Read<bool>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bShunt() const { return Read<bool>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x1, Type: BoolProperty)

    void SET_AerialPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bDrift(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bGroundedFlip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_bKickflip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: BoolProperty)
    void SET_bShunt(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FDelMarVehicleReplay_InputState_RL
{
public:
    float Throttle() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Steer() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float pitch() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Yaw() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Roll() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float DodgeForward() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float DodgeRight() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bHandbrake() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    bool bJump() const { return Read<bool>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: BoolProperty)
    bool bBoost() const { return Read<bool>(uintptr_t(this) + 0x1e); } // 0x1e (Size: 0x1, Type: BoolProperty)

    void SET_Throttle(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Steer(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_pitch(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Yaw(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Roll(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_DodgeForward(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_DodgeRight(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bHandbrake(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_bJump(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: BoolProperty)
    void SET_bBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e, Value); } // 0x1e (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
struct FDelMarVehicleCachedContact
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Impulse() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector DeltaVelocity() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    bool bVehicleContact() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bDriveableContact() const { return Read<bool>(uintptr_t(this) + 0x61); } // 0x61 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UPrimitiveComponent*> Component() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Impulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_DeltaVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_bVehicleContact(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
    void SET_bDriveableContact(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61, Value); } // 0x61 (Size: 0x1, Type: BoolProperty)
    void SET_Component(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x28
struct FDelMarWorldBonusSpeedStack
{
public:
    FGameplayTag Source() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float BonusSpeed() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bApplyForce() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    int32_t GroupId() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AActor*> ActorSource() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Source(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_BonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bApplyForce(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_GroupId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_ActorSource(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x18
struct FDelMarWorldBonusSpeedGroup
{
public:
};

// Size: 0xc
struct FDelMarVehicleLandingData
{
public:
};

// Size: 0x8
struct FDelMarVehicleSkydivingData
{
public:
};

// Size: 0x14
struct FDelMarStartlineBoostData
{
public:
    bool bFailed() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float ReactionSeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float RunStartTime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float IntervalSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float EarnedPotential() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_bFailed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ReactionSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_RunStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_IntervalSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_EarnedPotential(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x130
struct FDelMarKickflipSimulationResult
{
public:
    FHitResult Hit() const { return Read<FHitResult>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xf8, Type: StructProperty)
    FQuat VehicleLandingRotation() const { return Read<FQuat>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x20, Type: StructProperty)
    bool bValidLandingRotation() const { return Read<bool>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: BoolProperty)
    bool bDriveableSurfaceHit() const { return Read<bool>(uintptr_t(this) + 0x121); } // 0x121 (Size: 0x1, Type: BoolProperty)
    float SuctionVelocityUsed() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    float ElapsedTime() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float DistanceTravelled() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)

    void SET_Hit(const FHitResult& Value) { Write<FHitResult>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xf8, Type: StructProperty)
    void SET_VehicleLandingRotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x20, Type: StructProperty)
    void SET_bValidLandingRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: BoolProperty)
    void SET_bDriveableSurfaceHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x121, Value); } // 0x121 (Size: 0x1, Type: BoolProperty)
    void SET_SuctionVelocityUsed(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_ElapsedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceTravelled(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleReplicatedState_Ability
{
public:
    bool bActive() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FDelMarVehicleReplicatedState_BonusSpeedAbility : public FDelMarVehicleReplicatedState_Ability
{
public:
    float AppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_AppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FDelMarVehicleReplicatedState_AutoUpright : public FDelMarVehicleReplicatedState_Ability
{
public:
    FVector_NetQuantizeNormal TargetVehicleUp() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_TargetVehicleUp(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FDelMarVehicleReplicatedState_Drafting : public FDelMarVehicleReplicatedState_BonusSpeedAbility
{
public:
    float AccumulatedLosingSpeedSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float AccumulatedStartDraftingSeconds() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float TotalEarnedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_AccumulatedLosingSpeedSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_AccumulatedStartDraftingSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_TotalEarnedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDelMarVehicleReplicatedState_Drift : public FDelMarVehicleReplicatedState_Ability
{
public:
    float CurrentRotationAngle() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t DriftState() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    float TargetDriftSide() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FVector_NetQuantize100 InitialImpulseTorque() const { return Read<FVector_NetQuantize100>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_CurrentRotationAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_DriftState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_TargetDriftSide(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_InitialImpulseTorque(const FVector_NetQuantize100& Value) { Write<FVector_NetQuantize100>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FDelMarVehicleReplicatedState_DriftBoost : public FDelMarVehicleReplicatedState_BonusSpeedAbility
{
public:
    float AccumulatedDriftBoostSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float AccumulatedWaitingPeriodSeconds() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float TotalEarnedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float QueuedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float QueuedBoostExtraSeconds() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_AccumulatedDriftBoostSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_AccumulatedWaitingPeriodSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_TotalEarnedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_QueuedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_QueuedBoostExtraSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDelMarVehicleReplicatedState_Drive
{
public:
    float BaseTargetSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bInvertedSteeringActive() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    int32_t bDisableDriveForces() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t bDisableWheelFriction() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    FVector_NetQuantizeNormal LastAverageWheelWorldContactNormal() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    float MinimumLandingSpeed() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_BaseTargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bInvertedSteeringActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bDisableDriveForces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_bDisableWheelFriction(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_LastAverageWheelWorldContactNormal(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MinimumLandingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FDelMarVehicleReplicatedState_Kickflip : public FDelMarVehicleReplicatedState_Ability
{
public:
    FVector_NetQuantizeNormal RelativeUpDirection() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantizeNormal KickDirection() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    bool bLeftSide() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bTakeLongestRoll() const { return Read<bool>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: BoolProperty)
    bool bRotateTowardsVelocity() const { return Read<bool>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: BoolProperty)
    bool bCanStartLongRoll() const { return Read<bool>(uintptr_t(this) + 0x3b); } // 0x3b (Size: 0x1, Type: BoolProperty)
    int32_t StartingRollSign() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    float KickflipKeybindPressTime() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    int32_t ActivationCharges() const { return Read<int32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: IntProperty)
    FVector_NetQuantizeNormal StartingPrimaryDirection() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)

    void SET_RelativeUpDirection(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_KickDirection(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_bLeftSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_bTakeLongestRoll(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: BoolProperty)
    void SET_bRotateTowardsVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: BoolProperty)
    void SET_bCanStartLongRoll(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b, Value); } // 0x3b (Size: 0x1, Type: BoolProperty)
    void SET_StartingRollSign(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_KickflipKeybindPressTime(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_ActivationCharges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: IntProperty)
    void SET_StartingPrimaryDirection(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
};

// Size: 0x4
struct FDelMarVehicleReplicatedState_Oversteer
{
public:
    float AccumulatedSteer() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_AccumulatedSteer(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FDelMarVehicleReplicatedState_Reattachment : public FDelMarVehicleReplicatedState_Ability
{
public:
    FVector_NetQuantizeNormal AttachmentDirection() const { return Read<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    bool bCanActivate() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_AttachmentDirection(const FVector_NetQuantizeNormal& Value) { Write<FVector_NetQuantizeNormal>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_bCanActivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FDelMarVehicleReplicatedState_Rubberbanding
{
public:
    float AppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_AppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x14
struct FDelMarVehicleReplicatedState_StartlineBoost : public FDelMarVehicleReplicatedState_BonusSpeedAbility
{
public:
    float PercentageMaxBonusSpeedEarned() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bFailedAttempt() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_PercentageMaxBonusSpeedEarned(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bFailedAttempt(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FDelMarVehicleReplicatedState_Turbo : public FDelMarVehicleReplicatedState_BonusSpeedAbility
{
public:
    int32_t LastBonusZoneInteractionIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    bool bSuccessfulBonusZone() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float AdditionalActiveSeconds() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_LastBonusZoneInteractionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_bSuccessfulBonusZone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_AdditionalActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FDelMarVehicleReplicatedState_Underthrust : public FDelMarVehicleReplicatedState_Ability
{
public:
    float RemainingThrustSeconds() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_RemainingThrustSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FDelMarVehicleReplicatedState_Strafe : public FDelMarVehicleReplicatedState_Ability
{
public:
    bool bLeftSide() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float StrafeKeybindPressTime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_bLeftSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_StrafeKeybindPressTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FDelMarVehicleReplicatedState_AirControl : public FDelMarVehicleReplicatedState_Ability
{
public:
    float AerialDivingBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_AerialDivingBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDelMarInputBufferData
{
public:
};

// Size: 0x40
struct FDelMarVehicleInContinuous : public FFortAthenaVehicleInputState
{
public:
};

// Size: 0x290
struct FDelMarVehicleReplicatedState
{
public:
    int32_t FrameNum() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FDelMarVehicleInContinuous Input() const { return Read<FDelMarVehicleInContinuous>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x40, Type: StructProperty)
    FRigidBodyState RBState() const { return Read<FRigidBodyState>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x80, Type: StructProperty)
    FDelMarVehicleReplicatedState_AutoUpright AutoUpright() const { return Read<FDelMarVehicleReplicatedState_AutoUpright>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleReplicatedState_Drafting Drafting() const { return Read<FDelMarVehicleReplicatedState_Drafting>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleReplicatedState_Drift Drift() const { return Read<FDelMarVehicleReplicatedState_Drift>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleReplicatedState_DriftBoost DriftBoost() const { return Read<FDelMarVehicleReplicatedState_DriftBoost>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleReplicatedState_Drive Drive() const { return Read<FDelMarVehicleReplicatedState_Drive>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleReplicatedState_Ability Jump() const { return Read<FDelMarVehicleReplicatedState_Ability>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleReplicatedState_Kickflip Kickflip() const { return Read<FDelMarVehicleReplicatedState_Kickflip>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x60, Type: StructProperty)
    FDelMarVehicleReplicatedState_Oversteer Oversteer() const { return Read<FDelMarVehicleReplicatedState_Oversteer>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleReplicatedState_Reattachment Reattachment() const { return Read<FDelMarVehicleReplicatedState_Reattachment>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleReplicatedState_Rubberbanding Rubberbanding() const { return Read<FDelMarVehicleReplicatedState_Rubberbanding>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleReplicatedState_StartlineBoost StartlineBoost() const { return Read<FDelMarVehicleReplicatedState_StartlineBoost>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0x14, Type: StructProperty)
    FDelMarVehicleReplicatedState_Strafe Strafe() const { return Read<FDelMarVehicleReplicatedState_Strafe>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x10, Type: StructProperty)
    FDelMarVehicleReplicatedState_Turbo Turbo() const { return Read<FDelMarVehicleReplicatedState_Turbo>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleReplicatedState_Underthrust Underthrust() const { return Read<FDelMarVehicleReplicatedState_Underthrust>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleReplicatedState_AirControl AirControl() const { return Read<FDelMarVehicleReplicatedState_AirControl>(uintptr_t(this) + 0x26c); } // 0x26c (Size: 0xc, Type: StructProperty)
    FDelMarInputBufferData BufferData() const { return Read<FDelMarInputBufferData>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x18, Type: StructProperty)

    void SET_FrameNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Input(const FDelMarVehicleInContinuous& Value) { Write<FDelMarVehicleInContinuous>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x40, Type: StructProperty)
    void SET_RBState(const FRigidBodyState& Value) { Write<FRigidBodyState>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x80, Type: StructProperty)
    void SET_AutoUpright(const FDelMarVehicleReplicatedState_AutoUpright& Value) { Write<FDelMarVehicleReplicatedState_AutoUpright>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_Drafting(const FDelMarVehicleReplicatedState_Drafting& Value) { Write<FDelMarVehicleReplicatedState_Drafting>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_Drift(const FDelMarVehicleReplicatedState_Drift& Value) { Write<FDelMarVehicleReplicatedState_Drift>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x30, Type: StructProperty)
    void SET_DriftBoost(const FDelMarVehicleReplicatedState_DriftBoost& Value) { Write<FDelMarVehicleReplicatedState_DriftBoost>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x20, Type: StructProperty)
    void SET_Drive(const FDelMarVehicleReplicatedState_Drive& Value) { Write<FDelMarVehicleReplicatedState_Drive>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x30, Type: StructProperty)
    void SET_Jump(const FDelMarVehicleReplicatedState_Ability& Value) { Write<FDelMarVehicleReplicatedState_Ability>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: StructProperty)
    void SET_Kickflip(const FDelMarVehicleReplicatedState_Kickflip& Value) { Write<FDelMarVehicleReplicatedState_Kickflip>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x60, Type: StructProperty)
    void SET_Oversteer(const FDelMarVehicleReplicatedState_Oversteer& Value) { Write<FDelMarVehicleReplicatedState_Oversteer>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x4, Type: StructProperty)
    void SET_Reattachment(const FDelMarVehicleReplicatedState_Reattachment& Value) { Write<FDelMarVehicleReplicatedState_Reattachment>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x28, Type: StructProperty)
    void SET_Rubberbanding(const FDelMarVehicleReplicatedState_Rubberbanding& Value) { Write<FDelMarVehicleReplicatedState_Rubberbanding>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x4, Type: StructProperty)
    void SET_StartlineBoost(const FDelMarVehicleReplicatedState_StartlineBoost& Value) { Write<FDelMarVehicleReplicatedState_StartlineBoost>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0x14, Type: StructProperty)
    void SET_Strafe(const FDelMarVehicleReplicatedState_Strafe& Value) { Write<FDelMarVehicleReplicatedState_Strafe>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x10, Type: StructProperty)
    void SET_Turbo(const FDelMarVehicleReplicatedState_Turbo& Value) { Write<FDelMarVehicleReplicatedState_Turbo>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x18, Type: StructProperty)
    void SET_Underthrust(const FDelMarVehicleReplicatedState_Underthrust& Value) { Write<FDelMarVehicleReplicatedState_Underthrust>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0xc, Type: StructProperty)
    void SET_AirControl(const FDelMarVehicleReplicatedState_AirControl& Value) { Write<FDelMarVehicleReplicatedState_AirControl>(uintptr_t(this) + 0x26c, Value); } // 0x26c (Size: 0xc, Type: StructProperty)
    void SET_BufferData(const FDelMarInputBufferData& Value) { Write<FDelMarInputBufferData>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa40
struct FDelMarVehicleInPersistent : public FFortVehicleInPersistent
{
public:
};

// Size: 0xb40
struct FDelMarVehicleInternalPersistent : public FFortVehicleInternalPersistent
{
public:
};

// Size: 0x1b0
struct FDelMarVehicleOutContinuous : public FFortVehicleOutContinuous
{
public:
};

// Size: 0xa50
struct FDelMarVehicleOutPersistent : public FFortVehicleOutPersistent
{
public:
};

// Size: 0x48
struct FDelMarVehicleNetworkInput
{
public:
    int32_t FrameNum() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FDelMarVehicleInContinuous Input() const { return Read<FDelMarVehicleInContinuous>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x40, Type: StructProperty)

    void SET_FrameNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Input(const FDelMarVehicleInContinuous& Value) { Write<FDelMarVehicleInContinuous>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x40, Type: StructProperty)
};

// Size: 0x10
struct FDelMarVehicleSpawnInfo
{
public:
    bool bFirstVehicleForPlayer() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bPreviousVehicleDemolished() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    double ServerSpawnTime() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_bFirstVehicleForPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bPreviousVehicleDemolished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_ServerSpawnTime(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x138
struct FDelMarVerbMessageBase : public FVerbMessage
{
public:
    FSubjectTagsPair LevelDescriptionId() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair GameModeId() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair VehicleTags() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x38, Type: StructProperty)
    uint8_t RankedPlaylistInfo() const { return Read<uint8_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: EnumProperty)
    TArray<FFortVerb_ObjectWrapper> Cosmetics() const { return Read<TArray<FFortVerb_ObjectWrapper>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)

    void SET_LevelDescriptionId(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x38, Type: StructProperty)
    void SET_GameModeId(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x38, Type: StructProperty)
    void SET_VehicleTags(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x38, Type: StructProperty)
    void SET_RankedPlaylistInfo(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: EnumProperty)
    void SET_Cosmetics(const TArray<FFortVerb_ObjectWrapper>& Value) { Write<TArray<FFortVerb_ObjectWrapper>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_BeatPlayers : public FDelMarVerbMessageBase
{
public:
    char AmountOfPlayersBeat() const { return Read<char>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: ByteProperty)

    void SET_AmountOfPlayersBeat(const char& Value) { Write<char>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x138
struct FDelMarVerbMessage_BonusTurboActivated : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x138
struct FDelMarVerbMessage_BoostPadBonusSpeedEnded : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x138
struct FDelMarVerbMessage_BoostPadHit : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x138
struct FDelMarVerbMessage_Demolished : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x140
struct FDelMarVerbMessage_DistanceTraveled : public FDelMarVerbMessageBase
{
public:
    float TotalDistance() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_TotalDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x138
struct FDelMarVerbMessage_DraftActivated : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x140
struct FDelMarVerbMessage_DriftBoostActivated : public FDelMarVerbMessageBase
{
public:
    float DriftBoostPercent() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_DriftBoostPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_DriftBoostDeactivated : public FDelMarVerbMessageBase
{
public:
    float TotalDistance() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_TotalDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_DriftComplete : public FDelMarVerbMessageBase
{
public:
    float DriftDuration() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_DriftDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_HighestSpeedUpdated : public FDelMarVerbMessageBase
{
public:
    float HighestSpeed() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_HighestSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x138
struct FDelMarVerbMessage_InitialTurboActivated : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x138
struct FDelMarVerbMessage_JellyHit : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x140
struct FDelMarVerbMessage_Kickflipped : public FDelMarVerbMessageBase
{
public:
    uint8_t Direction() const { return Read<uint8_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: EnumProperty)

    void SET_Direction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x148
struct FDelMarVerbMessage_LapComplete : public FDelMarVerbMessageBase
{
public:
    double LapCompleteTime() const { return Read<double>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    char LapCount() const { return Read<char>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: ByteProperty)
    char LapPlacement() const { return Read<char>(uintptr_t(this) + 0x141); } // 0x141 (Size: 0x1, Type: ByteProperty)

    void SET_LapCompleteTime(const double& Value) { Write<double>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    void SET_LapCount(const char& Value) { Write<char>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: ByteProperty)
    void SET_LapPlacement(const char& Value) { Write<char>(uintptr_t(this) + 0x141, Value); } // 0x141 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x138
struct FDelMarVerbMessage_LapStarted : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x140
struct FDelMarVerbMessage_PlacementUpdated : public FDelMarVerbMessageBase
{
public:
    char CurrentPosition() const { return Read<char>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: ByteProperty)
    uint8_t PositionChangeInfo() const { return Read<uint8_t>(uintptr_t(this) + 0x139); } // 0x139 (Size: 0x1, Type: EnumProperty)

    void SET_CurrentPosition(const char& Value) { Write<char>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: ByteProperty)
    void SET_PositionChangeInfo(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x139, Value); } // 0x139 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x138
struct FDelMarVerbMessage_PlayedDelMarExperience : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x150
struct FDelMarVerbMessage_RaceFinished : public FDelMarVerbMessageBase
{
public:
    double FinishTime() const { return Read<double>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    char FinalPlacement() const { return Read<char>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: ByteProperty)
    char PlayerRank() const { return Read<char>(uintptr_t(this) + 0x141); } // 0x141 (Size: 0x1, Type: ByteProperty)

    void SET_FinishTime(const double& Value) { Write<double>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    void SET_FinalPlacement(const char& Value) { Write<char>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: ByteProperty)
    void SET_PlayerRank(const char& Value) { Write<char>(uintptr_t(this) + 0x141, Value); } // 0x141 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_RankAchieved : public FDelMarVerbMessageBase
{
public:
    int32_t RankAchieved() const { return Read<int32_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: IntProperty)

    void SET_RankAchieved(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: IntProperty)
};

// Size: 0x150
struct FDelMarVerbMessage_RunComplete : public FDelMarVerbMessageBase
{
public:
    double FinishTime() const { return Read<double>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    char FinalPlacement() const { return Read<char>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: ByteProperty)

    void SET_FinishTime(const double& Value) { Write<double>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    void SET_FinalPlacement(const char& Value) { Write<char>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_StartlineBoostActivated : public FDelMarVerbMessageBase
{
public:
    float StartLineBoostPercent() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_StartLineBoostPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_StartlineBoostPercentEarned : public FDelMarVerbMessageBase
{
public:
    float PercentEarned() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_PercentEarned(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_UnderthrustDeactivated : public FDelMarVerbMessageBase
{
public:
    float PercentUsed() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_PercentUsed(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x140
struct FDelMarVerbMessage_UnderthrustPercentUsed : public FDelMarVerbMessageBase
{
public:
    float PercentUsed() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_PercentUsed(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x138
struct FDelMarVerbMessage_VehicleJumped : public FDelMarVerbMessageBase
{
public:
};

// Size: 0x140
struct FDelMarVerbMessage_VehicleLanded : public FDelMarVerbMessageBase
{
public:
    float TimeInAir() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)

    void SET_TimeInAir(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x98
struct FAudioMixModifier
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Target() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve Curve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x88, Type: StructProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Target(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Curve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x88, Type: StructProperty)
};

// Size: 0x18
struct FAudioMixModifierGroup
{
public:
    FName GroupName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FAudioMixModifier> Modifiers() const { return Read<TArray<FAudioMixModifier>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_GroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Modifiers(const TArray<FAudioMixModifier>& Value) { Write<TArray<FAudioMixModifier>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarRankedInfo
{
public:
    FString RankType() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t CurrentRank() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_RankType(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_CurrentRank(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FCheckpointTrackDistance
{
public:
    ADelMarTrack* Track() const { return Read<ADelMarTrack*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float LocalDistance() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Track(const ADelMarTrack*& Value) { Write<ADelMarTrack*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDelMarTerrainData
{
public:
    float MaxForwardSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float AccelerationMultiplier() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float DecelerationMultiplier() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float SteerMultiplier() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float SlipMultiplier() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float TargetSpeedPenalty() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_MaxForwardSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_AccelerationMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_DecelerationMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_SteerMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_SlipMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_TargetSpeedPenalty(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1c
struct FDelMarVehicleCameraSettings
{
public:
    float FOV() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float pitch() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Stiffness() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float SwivelSpeed() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float TransitionSpeed() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_FOV(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_pitch(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Stiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SwivelSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_TransitionSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarEliminationMMRCountPair
{
public:
    int32_t MaxMmr() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PlayersToEliminate() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_MaxMmr(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_PlayersToEliminate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FDelMarTimeDelayedState
{
public:
    FGameplayTag Name() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Name(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FDelMarReplicatedLoadout
{
public:
    TArray<UDelMarCosmeticItemDefinition*> Items() const { return Read<TArray<UDelMarCosmeticItemDefinition*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<UDelMarCosmeticItemDefinition*>& Value) { Write<TArray<UDelMarCosmeticItemDefinition*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FDelMarLoadout
{
public:
    TMap<FGameplayTag, UDelMarCosmeticItemDefinition*> Items() const { return Read<TMap<FGameplayTag, UDelMarCosmeticItemDefinition*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Items(const TMap<FGameplayTag, UDelMarCosmeticItemDefinition*>& Value) { Write<TMap<FGameplayTag, UDelMarCosmeticItemDefinition*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x20
struct FDelMarLeaderboardConfig
{
public:
    FString EventId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString WindowId() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_EventId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_WindowId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FPhysicalMaterialAttributes_X
{
public:
    TArray<UDelMarPhysMatAttribute*> Attributes() const { return Read<TArray<UDelMarPhysMatAttribute*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Attributes(const TArray<UDelMarPhysMatAttribute*>& Value) { Write<TArray<UDelMarPhysMatAttribute*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarNetworkInputPacket
{
public:
};

// Size: 0x10
struct FDelMarMapStatus
{
public:
    UDelMarLevelDataAsset* MapAsset() const { return Read<UDelMarLevelDataAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bHasBeenPlayed() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_MapAsset(const UDelMarLevelDataAsset*& Value) { Write<UDelMarLevelDataAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bHasBeenPlayed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FDelMarMapSet
{
public:
    bool bShouldConsiderValid() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bPlayLevelsRandomly() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bShouldRepeat() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    TArray<FDelMarMapStatus> Levels() const { return Read<TArray<FDelMarMapStatus>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_bShouldConsiderValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayLevelsRandomly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldRepeat(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_Levels(const TArray<FDelMarMapStatus>& Value) { Write<TArray<FDelMarMapStatus>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarDeathRaceConfig
{
public:
    TArray<int32_t> PlacementPointsMap() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ScoreThresholdToEndMatch() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_PlacementPointsMap(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ScoreThresholdToEndMatch(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FDelMarGameplayModifierList
{
public:
    TArray<UClass*> Modifiers() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Modifiers(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarPositionValue
{
public:
};

// Size: 0x10
struct FDelMarFinalRacePositionEntry
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    double RunTime() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RunTime(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xc
struct FDelMarVehicleRuntimeConfig
{
public:
    bool bCollisionDemosEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIdleDisablesVehicleCollision() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    float SecondsToSetIdle() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t VehicleCollisionsGlobalOverride() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bApplyOverlapFilter() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)

    void SET_bCollisionDemosEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bIdleDisablesVehicleCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_SecondsToSetIdle(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleCollisionsGlobalOverride(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_bApplyOverlapFilter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FDelMarRespawnConfig
{
public:
    uint8_t SpawnMode() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bUseTracesToDetermineRespawn() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bRespawnInvulnerabilityEnabled() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    float RespawnInvulnerabilitySeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bRespawnCollisionProtectionEnabled() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float RespawnCollisionProtectionSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_SpawnMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_bUseTracesToDetermineRespawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bRespawnInvulnerabilityEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_RespawnInvulnerabilitySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bRespawnCollisionProtectionEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_RespawnCollisionProtectionSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FDelMarRubberbandingConfig
{
public:
    bool bRubberbandingEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float MinPackDistance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxPackDistance() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float PackDistanceOffset() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MinDistanceFromPack() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromPack() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t NumPlayersForPackDistance() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    float MaxPackDistanceGainedPerSecond() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float MaxPackDistanceLostPerSecond() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)

    void SET_bRubberbandingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_MinPackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxPackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_PackDistanceOffset(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MinDistanceFromPack(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistanceFromPack(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_NumPlayersForPackDistance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_MaxPackDistanceGainedPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MaxPackDistanceLostPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_MaxBonusSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDelMarRubberbandingMMRConfig
{
public:
    float MinMmr() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxMmr() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarRubberbandingConfig RubberbandingConfig() const { return Read<FDelMarRubberbandingConfig>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)

    void SET_MinMmr(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxMmr(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_RubberbandingConfig(const FDelMarRubberbandingConfig& Value) { Write<FDelMarRubberbandingConfig>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x1c
struct FDelMarMatchmakingConfig
{
public:
    float MaxLoadWaitSeconds() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float LoadWaitBufferSeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float CODGracePeriodSeconds() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MatchStartDelaySeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bMatchInProgressBackFillEnabled() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float MinSecondsRemainingForBackfill() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float TimeIntervalBetweenAnalyticsSeconds() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_MaxLoadWaitSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LoadWaitBufferSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_CODGracePeriodSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MatchStartDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bMatchInProgressBackFillEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_MinSecondsRemainingForBackfill(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_TimeIntervalBetweenAnalyticsSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FDelMarCurveFloat
{
public:
    float Scale() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    UCurveFloat* Curve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Curve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FDelMarBotMMRPenaltyConfig
{
public:
    float MinMmr() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxMmr() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarCurveFloat TargetSpeedPenaltyCurve() const { return Read<FDelMarCurveFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FDelMarCurveFloat TargetTurboChancesCurve() const { return Read<FDelMarCurveFloat>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_MinMmr(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxMmr(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TargetSpeedPenaltyCurve(const FDelMarCurveFloat& Value) { Write<FDelMarCurveFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_TargetTurboChancesCurve(const FDelMarCurveFloat& Value) { Write<FDelMarCurveFloat>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FDelMarBotRuntimeConfig
{
public:
    FDelMarCurveFloat BotTargetSpeedPenaltyCurve() const { return Read<FDelMarCurveFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FDelMarBotMMRPenaltyConfig> BotTargetSpeedMMRPenalty() const { return Read<TArray<FDelMarBotMMRPenaltyConfig>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t NumPlayersAheadForNoBotPenalty() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_BotTargetSpeedPenaltyCurve(const FDelMarCurveFloat& Value) { Write<FDelMarCurveFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_BotTargetSpeedMMRPenalty(const TArray<FDelMarBotMMRPenaltyConfig>& Value) { Write<TArray<FDelMarBotMMRPenaltyConfig>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_NumPlayersAheadForNoBotPenalty(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FDelMarRandomRange
{
public:
    float MinValue() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_MinValue(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FDelMarStartlineConfig
{
public:
    bool bEnableDynamicStartline() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float InitialCountdownDelayTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float RequestCountdownDelayTime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float DefaultIntervalSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    TArray<FDelMarRandomRange> IntervalRanges() const { return Read<TArray<FDelMarRandomRange>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t CountdownIntervalNum() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_bEnableDynamicStartline(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_InitialCountdownDelayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_RequestCountdownDelayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultIntervalSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_IntervalRanges(const TArray<FDelMarRandomRange>& Value) { Write<TArray<FDelMarRandomRange>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CountdownIntervalNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FDelMarStateOverride
{
public:
    FGameplayTag StateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_StateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FDelMarStateMachineConfig
{
public:
    TArray<FDelMarStateOverride> StateOverrides() const { return Read<TArray<FDelMarStateOverride>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_StateOverrides(const TArray<FDelMarStateOverride>& Value) { Write<TArray<FDelMarStateOverride>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FDelMarDynamicCameraShakeEffect
{
public:
    UClass* CameraShakeClass() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UCameraShakeBase*> CameraShakeInstance() const { return Read<TWeakObjectPtr<UCameraShakeBase*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    FRuntimeFloatCurve ShakeIntensityCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x88, Type: StructProperty)
    float CurrentShakeIntensity() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)

    void SET_CameraShakeClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_CameraShakeInstance(const TWeakObjectPtr<UCameraShakeBase*>& Value) { Write<TWeakObjectPtr<UCameraShakeBase*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ShakeIntensityCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x88, Type: StructProperty)
    void SET_CurrentShakeIntensity(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarThrottledValue
{
public:
    float RiseRate() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float FallRate() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_RiseRate(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_FallRate(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleLandingLevel
{
public:
    float MinForce() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float SpeedChange() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_MinForce(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedChange(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarTurboBonusZone
{
public:
    float ZoneStartTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ZoneEndTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_ZoneStartTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ZoneEndTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarWorldBonusSpeedSourceCap
{
public:
    FGameplayTag Source() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t StackCap() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Source(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_StackCap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FDelMarVehicleRigidBodyConfig
{
public:
    bool bApplyGlobalBodySettings() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float LinearDamping() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float AngularDamping() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float VehicleMass() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bNotifyRigidBodyCollisions() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bSmoothEdgeCollisionsEnabled() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bUseCCD() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)
    FVector CenterOfMassOffset() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    bool bSuspensionIgnoresBodyCollision() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_bApplyGlobalBodySettings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_LinearDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_AngularDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleMass(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bNotifyRigidBodyCollisions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bSmoothEdgeCollisionsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bUseCCD(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
    void SET_CenterOfMassOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_bSuspensionIgnoresBodyCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x370
struct FDelMarVehicleDriveSetup
{
public:
    float MaxBaseForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve DriveAccel() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve TargetSpeedMaxAccelCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x90, Type: StructProperty)
    float TargetSpeedAerialFriction() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForPersistentTargetSpeedModifier() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bAllowBrakingInAir() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)
    float BrakeAccel() const { return Read<float>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: FloatProperty)
    float StopSpeed() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    float IdleBrakeFactor() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedToResetTargetSpeedDirection() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SteerAngleCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x88, Type: StructProperty)
    TArray<FRuntimeFloatCurve> SteerAngleCurveOverrides() const { return Read<TArray<FRuntimeFloatCurve>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: ArrayProperty)
    FDelMarScaledCurve LatFrictionCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x90, Type: StructProperty)
    FRuntimeFloatCurve WheelsGroundedFrictionCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x88, Type: StructProperty)
    float MaxForwardSpeedToIgnoreLandingSpeed() const { return Read<float>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float MaxKickflipLandingSeconds() const { return Read<float>(uintptr_t(this) + 0x2fc); } // 0x2fc (Size: 0x4, Type: FloatProperty)
    float SkydiveVerticalVelocitySensitivity() const { return Read<float>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: FloatProperty)
    float SkydiveVerticalPitchSensitivity() const { return Read<float>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x4, Type: FloatProperty)
    float MinInAirTimeStableLanding() const { return Read<float>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: FloatProperty)
    int32_t NumWheelsForActivelyLanding() const { return Read<int32_t>(uintptr_t(this) + 0x30c); } // 0x30c (Size: 0x4, Type: IntProperty)
    float MinAerialSpeedForPrimaryDirection() const { return Read<float>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x4, Type: FloatProperty)
    float MaxGroundNormalDiffForPrimaryDirection() const { return Read<float>(uintptr_t(this) + 0x314); } // 0x314 (Size: 0x4, Type: FloatProperty)
    float MinPrevVelocityDotProductForPrimaryDirection() const { return Read<float>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x4, Type: FloatProperty)
    float ForwardMaxSpeed() const { return Read<float>(uintptr_t(this) + 0x31c); } // 0x31c (Size: 0x4, Type: FloatProperty)
    float UpwardMaxLandingSpeed() const { return Read<float>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x4, Type: FloatProperty)
    float UpwardMaxSpeed() const { return Read<float>(uintptr_t(this) + 0x324); } // 0x324 (Size: 0x4, Type: FloatProperty)
    float MaxLandingAngularVelocity() const { return Read<float>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: FloatProperty)
    float MaxLinearSpeed() const { return Read<float>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: FloatProperty)
    float MaxAngularSpeed() const { return Read<float>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: FloatProperty)
    float MinCeilingDegrees() const { return Read<float>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: FloatProperty)
    float MaxCeilingDegrees() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    float AerialCeilingDegrees() const { return Read<float>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x4, Type: FloatProperty)
    float MaxInvertedControlSteering() const { return Read<float>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: FloatProperty)
    float MinCeilingSecondsToInvertControls() const { return Read<float>(uintptr_t(this) + 0x344); } // 0x344 (Size: 0x4, Type: FloatProperty)
    float WheelPushForce() const { return Read<float>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForVelocityDirection() const { return Read<float>(uintptr_t(this) + 0x34c); } // 0x34c (Size: 0x4, Type: FloatProperty)
    float MinZSpeedForUpwardDirection() const { return Read<float>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x4, Type: FloatProperty)
    float VerticalOrientationSensitivity() const { return Read<float>(uintptr_t(this) + 0x354); } // 0x354 (Size: 0x4, Type: FloatProperty)
    float MaxInactiveLandedFlipTime() const { return Read<float>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x4, Type: FloatProperty)
    int32_t NumWheelsForWheelsOnGround() const { return Read<int32_t>(uintptr_t(this) + 0x35c); } // 0x35c (Size: 0x4, Type: IntProperty)
    float MaxLandingSpeedSpringVarianceDegrees() const { return Read<float>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: FloatProperty)
    float MinDownDegreesForForwardDirection() const { return Read<float>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x4, Type: FloatProperty)
    float MaxNormalizedForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x4, Type: FloatProperty)
    float MaxNormalizedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x36c); } // 0x36c (Size: 0x4, Type: FloatProperty)

    void SET_MaxBaseForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_DriveAccel(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_TargetSpeedMaxAccelCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x90, Type: StructProperty)
    void SET_TargetSpeedAerialFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeedForPersistentTargetSpeedModifier(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_bAllowBrakingInAir(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
    void SET_BrakeAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: FloatProperty)
    void SET_StopSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_IdleBrakeFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpeedToResetTargetSpeedDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_SteerAngleCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x88, Type: StructProperty)
    void SET_SteerAngleCurveOverrides(const TArray<FRuntimeFloatCurve>& Value) { Write<TArray<FRuntimeFloatCurve>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: ArrayProperty)
    void SET_LatFrictionCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x90, Type: StructProperty)
    void SET_WheelsGroundedFrictionCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x88, Type: StructProperty)
    void SET_MaxForwardSpeedToIgnoreLandingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxKickflipLandingSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2fc, Value); } // 0x2fc (Size: 0x4, Type: FloatProperty)
    void SET_SkydiveVerticalVelocitySensitivity(const float& Value) { Write<float>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: FloatProperty)
    void SET_SkydiveVerticalPitchSensitivity(const float& Value) { Write<float>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x4, Type: FloatProperty)
    void SET_MinInAirTimeStableLanding(const float& Value) { Write<float>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: FloatProperty)
    void SET_NumWheelsForActivelyLanding(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30c, Value); } // 0x30c (Size: 0x4, Type: IntProperty)
    void SET_MinAerialSpeedForPrimaryDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x4, Type: FloatProperty)
    void SET_MaxGroundNormalDiffForPrimaryDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x314, Value); } // 0x314 (Size: 0x4, Type: FloatProperty)
    void SET_MinPrevVelocityDotProductForPrimaryDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x4, Type: FloatProperty)
    void SET_ForwardMaxSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x31c, Value); } // 0x31c (Size: 0x4, Type: FloatProperty)
    void SET_UpwardMaxLandingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x4, Type: FloatProperty)
    void SET_UpwardMaxSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x324, Value); } // 0x324 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLandingAngularVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLinearSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: FloatProperty)
    void SET_MaxAngularSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: FloatProperty)
    void SET_MinCeilingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: FloatProperty)
    void SET_MaxCeilingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_AerialCeilingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x4, Type: FloatProperty)
    void SET_MaxInvertedControlSteering(const float& Value) { Write<float>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: FloatProperty)
    void SET_MinCeilingSecondsToInvertControls(const float& Value) { Write<float>(uintptr_t(this) + 0x344, Value); } // 0x344 (Size: 0x4, Type: FloatProperty)
    void SET_WheelPushForce(const float& Value) { Write<float>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeedForVelocityDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x34c, Value); } // 0x34c (Size: 0x4, Type: FloatProperty)
    void SET_MinZSpeedForUpwardDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalOrientationSensitivity(const float& Value) { Write<float>(uintptr_t(this) + 0x354, Value); } // 0x354 (Size: 0x4, Type: FloatProperty)
    void SET_MaxInactiveLandedFlipTime(const float& Value) { Write<float>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x4, Type: FloatProperty)
    void SET_NumWheelsForWheelsOnGround(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x35c, Value); } // 0x35c (Size: 0x4, Type: IntProperty)
    void SET_MaxLandingSpeedSpringVarianceDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: FloatProperty)
    void SET_MinDownDegreesForForwardDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x4, Type: FloatProperty)
    void SET_MaxNormalizedForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x4, Type: FloatProperty)
    void SET_MaxNormalizedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x36c, Value); } // 0x36c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1f8
struct FDelMarVehicleCollisionConfig
{
public:
    float MinWallAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinTimeBetweenSpeedLossHits() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForTargetSpeedReduction() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve SpeedReductionPercentageCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AerialSpeedReductionPercentageCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve WallTargetRedirectAngleDegreesCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x90, Type: StructProperty)
    float WallTargetRedirectPercent() const { return Read<float>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float WallTargetRedirectDriftPercent() const { return Read<float>(uintptr_t(this) + 0x1c4); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    float WallDriftHeadOnThresholdDegrees() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    float WallHeadOnDriftRedirectAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    float WallTargetRedirectHeadOnDriftPercent() const { return Read<float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    float MinGroundedDemolitionSpeed() const { return Read<float>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x4, Type: FloatProperty)
    float MinAerialDemolitionSpeed() const { return Read<float>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: FloatProperty)
    float MaxGroundedDemolitionAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x1dc); } // 0x1dc (Size: 0x4, Type: FloatProperty)
    float MaxAerialDemolitionAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    float ParallelCollisionThresholdDegrees() const { return Read<float>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x4, Type: FloatProperty)
    float HeadOnCollisionThresholdDegrees() const { return Read<float>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x4, Type: FloatProperty)
    float BumperToBumperThresholdDegrees() const { return Read<float>(uintptr_t(this) + 0x1ec); } // 0x1ec (Size: 0x4, Type: FloatProperty)
    float ContactNormalToVehicleRightThresholdDegrees() const { return Read<float>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> TrackTraceChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0x1, Type: ByteProperty)

    void SET_MinWallAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MinTimeBetweenSpeedLossHits(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeedForTargetSpeedReduction(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedReductionPercentageCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x90, Type: StructProperty)
    void SET_AerialSpeedReductionPercentageCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x90, Type: StructProperty)
    void SET_WallTargetRedirectAngleDegreesCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x90, Type: StructProperty)
    void SET_WallTargetRedirectPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x4, Type: FloatProperty)
    void SET_WallTargetRedirectDriftPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x1c4, Value); } // 0x1c4 (Size: 0x4, Type: FloatProperty)
    void SET_WallDriftHeadOnThresholdDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    void SET_WallHeadOnDriftRedirectAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    void SET_WallTargetRedirectHeadOnDriftPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    void SET_MinGroundedDemolitionSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x4, Type: FloatProperty)
    void SET_MinAerialDemolitionSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxGroundedDemolitionAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1dc, Value); } // 0x1dc (Size: 0x4, Type: FloatProperty)
    void SET_MaxAerialDemolitionAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    void SET_ParallelCollisionThresholdDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x4, Type: FloatProperty)
    void SET_HeadOnCollisionThresholdDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x4, Type: FloatProperty)
    void SET_BumperToBumperThresholdDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1ec, Value); } // 0x1ec (Size: 0x4, Type: FloatProperty)
    void SET_ContactNormalToVehicleRightThresholdDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x4, Type: FloatProperty)
    void SET_TrackTraceChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x718
struct FDelMarVehicleDriftConfig
{
public:
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinDirectedDriftTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinInAirTime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float AerialDriftNoKeybindGracePeriod() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxForcedDriftTime() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MinKickDriftActiveSeconds() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bForceSteerWhenKicking() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    float MinForcedSteerWhenKicking() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float KickCooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bActivateDriftOnStrafeEnd() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bActivateDriftOnLanding() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bActivateDriftOnKickflipLanding() const { return Read<bool>(uintptr_t(this) + 0x26); } // 0x26 (Size: 0x1, Type: BoolProperty)
    float ActivateExitDriftTime() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinSteerInput() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float MinFullThrottleInput() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float MinFullDriftInput() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float ForcedDriftSteer() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float InitialTorqueImpulse() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float MaxAllowedGroundedSpringVarianceDegrees() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelInDriftDir() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelNoSteer() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelNotInDriftDir() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float TorqueAccelChangeDir() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelDampening() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelWithKick() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelWithKickV2() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float TorqueAccelForcedDrift() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float TorqueAgainstExit() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedWithThrottle() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedNoThrottle() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedWithKick() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedSwapDirections() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float MinDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaxDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    float ExitDriftDegrees() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float ApproachDistance() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float PeakForwardSpeedDegrees() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float KickRedirectRate() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    float KickRedirectRateV2() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float ForcedDriftRedirectRate() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float MinSteerRedirectInput() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve NonKickRedirectRateCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveControlled() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAgainstAngleCurveControlled() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveNoSteer() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveUncontrolled() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveKickback() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveKickbackV2() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x90, Type: StructProperty)
    float PeakSpeedIncreaseDegrees() const { return Read<float>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x4, Type: FloatProperty)
    float MaxAccelSpeed() const { return Read<float>(uintptr_t(this) + 0x494); } // 0x494 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve AccelerationScalarCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AdditionalSpeedLossNoThrottle() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x90, Type: StructProperty)
    float MaxControlledDriftRatio() const { return Read<float>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve ControlledSpeedCapBySlipAngle() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve ControlledSpeedCapDecelRate() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x90, Type: StructProperty)
    float UncontrolledSpeedCap() const { return Read<float>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x4, Type: FloatProperty)
    float UncontrolledSpeedLoss() const { return Read<float>(uintptr_t(this) + 0x6e4); } // 0x6e4 (Size: 0x4, Type: FloatProperty)
    float ExitVelocityMaxDegrees() const { return Read<float>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x4, Type: FloatProperty)
    float ExitKickEndMaxDegrees() const { return Read<float>(uintptr_t(this) + 0x6ec); } // 0x6ec (Size: 0x4, Type: FloatProperty)
    float ExitVelocityTorqueAccel() const { return Read<float>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x4, Type: FloatProperty)
    float ExitVelocityMaxRotationSpeed() const { return Read<float>(uintptr_t(this) + 0x6f4); } // 0x6f4 (Size: 0x4, Type: FloatProperty)
    float ExitForwardMaxDegrees() const { return Read<float>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x4, Type: FloatProperty)
    float ExitForwardTorqueSteer() const { return Read<float>(uintptr_t(this) + 0x6fc); } // 0x6fc (Size: 0x4, Type: FloatProperty)
    float ExitForwardMaxRotation() const { return Read<float>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x4, Type: FloatProperty)
    float ExitForwardTargetRedirectRate() const { return Read<float>(uintptr_t(this) + 0x704); } // 0x704 (Size: 0x4, Type: FloatProperty)
    float ExitForwardRedirectRate() const { return Read<float>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x4, Type: FloatProperty)
    float MaxExitForwardLandingSpeed() const { return Read<float>(uintptr_t(this) + 0x70c); } // 0x70c (Size: 0x4, Type: FloatProperty)
    bool bEnforceThrottleForControlledDrift() const { return Read<bool>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x1, Type: BoolProperty)

    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MinDirectedDriftTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinInAirTime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AerialDriftNoKeybindGracePeriod(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxForcedDriftTime(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MinKickDriftActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_bForceSteerWhenKicking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_MinForcedSteerWhenKicking(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_KickCooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_bActivateDriftOnStrafeEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_bActivateDriftOnLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
    void SET_bActivateDriftOnKickflipLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x26, Value); } // 0x26 (Size: 0x1, Type: BoolProperty)
    void SET_ActivateExitDriftTime(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MinSteerInput(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_MinFullThrottleInput(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_MinFullDriftInput(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_ForcedDriftSteer(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_InitialTorqueImpulse(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_MaxAllowedGroundedSpringVarianceDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelInDriftDir(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelNoSteer(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelNotInDriftDir(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelChangeDir(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelDampening(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelWithKick(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelWithKickV2(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAccelForcedDrift(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_TorqueAgainstExit(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRotationSpeedWithThrottle(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRotationSpeedNoThrottle(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_MaxRotationSpeedWithKick(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRotationSpeedSwapDirections(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_MinDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_ExitDriftDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_ApproachDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_PeakForwardSpeedDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_KickRedirectRate(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_KickRedirectRateV2(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_ForcedDriftRedirectRate(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_MinSteerRedirectInput(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_NonKickRedirectRateCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x90, Type: StructProperty)
    void SET_VelocityRedirectAngleCurveControlled(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x90, Type: StructProperty)
    void SET_VelocityRedirectAgainstAngleCurveControlled(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x90, Type: StructProperty)
    void SET_VelocityRedirectAngleCurveNoSteer(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x90, Type: StructProperty)
    void SET_VelocityRedirectAngleCurveUncontrolled(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x90, Type: StructProperty)
    void SET_VelocityRedirectAngleCurveKickback(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x90, Type: StructProperty)
    void SET_VelocityRedirectAngleCurveKickbackV2(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x90, Type: StructProperty)
    void SET_PeakSpeedIncreaseDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAccelSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x494, Value); } // 0x494 (Size: 0x4, Type: FloatProperty)
    void SET_AccelerationScalarCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x90, Type: StructProperty)
    void SET_AdditionalSpeedLossNoThrottle(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x90, Type: StructProperty)
    void SET_MaxControlledDriftRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    void SET_ControlledSpeedCapBySlipAngle(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x90, Type: StructProperty)
    void SET_ControlledSpeedCapDecelRate(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x90, Type: StructProperty)
    void SET_UncontrolledSpeedCap(const float& Value) { Write<float>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x4, Type: FloatProperty)
    void SET_UncontrolledSpeedLoss(const float& Value) { Write<float>(uintptr_t(this) + 0x6e4, Value); } // 0x6e4 (Size: 0x4, Type: FloatProperty)
    void SET_ExitVelocityMaxDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x4, Type: FloatProperty)
    void SET_ExitKickEndMaxDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x6ec, Value); } // 0x6ec (Size: 0x4, Type: FloatProperty)
    void SET_ExitVelocityTorqueAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x4, Type: FloatProperty)
    void SET_ExitVelocityMaxRotationSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x6f4, Value); } // 0x6f4 (Size: 0x4, Type: FloatProperty)
    void SET_ExitForwardMaxDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x4, Type: FloatProperty)
    void SET_ExitForwardTorqueSteer(const float& Value) { Write<float>(uintptr_t(this) + 0x6fc, Value); } // 0x6fc (Size: 0x4, Type: FloatProperty)
    void SET_ExitForwardMaxRotation(const float& Value) { Write<float>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x4, Type: FloatProperty)
    void SET_ExitForwardTargetRedirectRate(const float& Value) { Write<float>(uintptr_t(this) + 0x704, Value); } // 0x704 (Size: 0x4, Type: FloatProperty)
    void SET_ExitForwardRedirectRate(const float& Value) { Write<float>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x4, Type: FloatProperty)
    void SET_MaxExitForwardLandingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x70c, Value); } // 0x70c (Size: 0x4, Type: FloatProperty)
    void SET_bEnforceThrottleForControlledDrift(const bool& Value) { Write<bool>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1d8
struct FDelMarVehicleDriftBoostConfig
{
public:
    float MaxDriftBoostRatio() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve BonusSpeedPercentageCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    float WaitingPeriodSeconds() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float MaxDriftBoostSeconds() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve PotentialDriftBoostPercentageCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x90, Type: StructProperty)
    float MaxNumActiveBonusSpeedSeconds() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve DriftBoostDurationCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x90, Type: StructProperty)
    float BonusSpeedDecaySeconds() const { return Read<float>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    float PotentialRemovalRate() const { return Read<float>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    bool bEnforceThrottleForDriftBoost() const { return Read<bool>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    float QueuedBoostImpulseScalar() const { return Read<float>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x4, Type: FloatProperty)

    void SET_MaxDriftBoostRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_BonusSpeedPercentageCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_WaitingPeriodSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDriftBoostSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_PotentialDriftBoostPercentageCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x90, Type: StructProperty)
    void SET_MaxNumActiveBonusSpeedSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostDurationCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x90, Type: StructProperty)
    void SET_BonusSpeedDecaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x4, Type: FloatProperty)
    void SET_PotentialRemovalRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    void SET_bEnforceThrottleForDriftBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    void SET_QueuedBoostImpulseScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc8
struct FDelMarVehicleDraftingConfig
{
public:
    float TraceDistance() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinEligibleDistance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxHorizontalDegreesToDraftTarget() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxVerticalDegreesToDraftTarget() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bEnableDynamicAngle() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FDelMarScaledCurve MaxBonusSpeedPercentageCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x90, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> LineOfSightChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: ByteProperty)
    float MinSpeedToStartDrafting() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    float NumSecondsToActivateDrafting() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    float NumForgivenessSeconds() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    float NumGracePeriodSeconds() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float NumSecondsToMaxBonusSpeed() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeed() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float NumSpeedRemovalSeconds() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)

    void SET_TraceDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MinEligibleDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxHorizontalDegreesToDraftTarget(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxVerticalDegreesToDraftTarget(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bEnableDynamicAngle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_MaxBonusSpeedPercentageCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x90, Type: StructProperty)
    void SET_LineOfSightChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: ByteProperty)
    void SET_MinSpeedToStartDrafting(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_NumSecondsToActivateDrafting(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_NumForgivenessSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_NumGracePeriodSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_NumSecondsToMaxBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MaxBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_NumSpeedRemovalSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x138
struct FDelMarVehicleOversteerConfig
{
public:
    float MinInput() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxAccumulatedSteer() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve CappedAccumulatedSteerCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AccumulatedSteerRateCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x90, Type: StructProperty)
    float AccumulatedSteerDecayRate() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float DriftImpulseForce() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)
    bool bDecayAccumulatedSteer() const { return Read<bool>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x1, Type: BoolProperty)
    bool bClearAccumulatedSteerOnDrift() const { return Read<bool>(uintptr_t(this) + 0x135); } // 0x135 (Size: 0x1, Type: BoolProperty)

    void SET_MinInput(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAccumulatedSteer(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_CappedAccumulatedSteerCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_AccumulatedSteerRateCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x90, Type: StructProperty)
    void SET_AccumulatedSteerDecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_DriftImpulseForce(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
    void SET_bDecayAccumulatedSteer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x1, Type: BoolProperty)
    void SET_bClearAccumulatedSteerOnDrift(const bool& Value) { Write<bool>(uintptr_t(this) + 0x135, Value); } // 0x135 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FDelMarVehicleConfig_Terrain
{
public:
    float TargetSpeedPenaltyCooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    int32_t NumWheelsTargetSpeedPenalty() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float NoGripBrakeFactorWithThrottle() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinForwardSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bDemolishInWater() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float MaxWaterDepth() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float WaterDestructionDelay() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> NonDriveableActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_TargetSpeedPenaltyCooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_NumWheelsTargetSpeedPenalty(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_NoGripBrakeFactorWithThrottle(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinForwardSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bDemolishInWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_MaxWaterDepth(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_WaterDestructionDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_NonDriveableActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FDelMarVehicleTurboConfig
{
public:
    float MaxActiveTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float CooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float InitialImpulseForce() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinBaseTargetSpeed() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    FDelMarFloatModifier TargetSpeedModifier() const { return Read<FDelMarFloatModifier>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x14, Type: StructProperty)
    TArray<FDelMarTurboBonusZone> BonusZones() const { return Read<TArray<FDelMarTurboBonusZone>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    float BonusZoneImpulseForce() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float BonusZoneSpeedDecaySeconds() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float SuccessfulBonusZoneHitSeconds() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float ApproachingBonusZoneSeconds() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float MaxMissingZoneSeconds() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float MaxNumCharges() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float ChargeRegenRateSeconds() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float RaceStartCharges() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float LapCompleteCharges() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float TurboGainedForDriftBoostPotential() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float TurboGainedPerSecondAtMaxDriftPotential() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float MaxTurboChargesFromDrift() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    bool bTerrainInvulnerabilityDuringTurbo() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_MaxActiveTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_CooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_InitialImpulseForce(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinBaseTargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_TargetSpeedModifier(const FDelMarFloatModifier& Value) { Write<FDelMarFloatModifier>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x14, Type: StructProperty)
    void SET_BonusZones(const TArray<FDelMarTurboBonusZone>& Value) { Write<TArray<FDelMarTurboBonusZone>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_BonusZoneImpulseForce(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_BonusZoneSpeedDecaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_SuccessfulBonusZoneHitSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_ApproachingBonusZoneSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_MaxMissingZoneSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_MaxNumCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_ChargeRegenRateSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_RaceStartCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_LapCompleteCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_TurboGainedForDriftBoostPotential(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_TurboGainedPerSecondAtMaxDriftPotential(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTurboChargesFromDrift(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_bTerrainInvulnerabilityDuringTurbo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1b8
struct FDelMarVehicleConfig_Rubberbanding
{
public:
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeedLostPerSecond() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve MaxBonusSpeedGainedPerSecond() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve MaxBonusSpeed() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve MaxSpeed() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x90, Type: StructProperty)

    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxBonusSpeedLostPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxBonusSpeedGainedPerSecond(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_MaxBonusSpeed(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x90, Type: StructProperty)
    void SET_MaxSpeed(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x90, Type: StructProperty)
};

// Size: 0xa8
struct FDelMarVehicleConfig_StartlineBoost
{
public:
    float MaxBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve PercentageMaxBonusSpeedEarned() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    float BoostGainSeconds() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float BoostDurationSeconds() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    bool bEnforceForwardThrottle() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_MaxBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_PercentageMaxBonusSpeedEarned(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_BoostGainSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_BoostDurationSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_bEnforceForwardThrottle(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c
struct FDelMarVehicleConfig_Strafe
{
public:
    float InitialVelocityForce() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bVelocityRelative() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    float MinSteerInput() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float KeybindPressLandedBufferSeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxActiveSeconds() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float RaceStartCooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float CooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_InitialVelocityForce(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_bVelocityRelative(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_MinSteerInput(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_KeybindPressLandedBufferSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_RaceStartCooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x168
struct FDelMarVehicleConfig_Underthrust
{
public:
    float UpwardAccel() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ForwardAccel() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxUpwardSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxForwardSpeed() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float EndThrustForce() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float StartingTankPercentage() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxThrustSeconds() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float ForwardSpeedCap() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedReduction() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float SpeedCapSecondsBuffer() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float MinJumpActiveSecondsBeforeActivating() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve FallingUpsideDownThrustDampeningPercentage() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve PitchRatioScalarCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x90, Type: StructProperty)
    bool bVehicleRelativeWithFreestyle() const { return Read<bool>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: BoolProperty)
    float MinUpwardAccel() const { return Read<float>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: FloatProperty)
    float LateralRelativeAccel() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    bool bReplenishTankOnLanding() const { return Read<bool>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x1, Type: BoolProperty)
    bool bReplenishTankOverTime() const { return Read<bool>(uintptr_t(this) + 0x15d); } // 0x15d (Size: 0x1, Type: BoolProperty)
    float TankReplenishDelaySeconds() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)
    float TankReplenishRatePerSecond() const { return Read<float>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: FloatProperty)

    void SET_UpwardAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ForwardAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxUpwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_EndThrustForce(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_StartingTankPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_MaxThrustSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_ForwardSpeedCap(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpeedReduction(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedCapSecondsBuffer(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_MinJumpActiveSecondsBeforeActivating(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_FallingUpsideDownThrustDampeningPercentage(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x90, Type: StructProperty)
    void SET_PitchRatioScalarCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x90, Type: StructProperty)
    void SET_bVehicleRelativeWithFreestyle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: BoolProperty)
    void SET_MinUpwardAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: FloatProperty)
    void SET_LateralRelativeAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_bReplenishTankOnLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x1, Type: BoolProperty)
    void SET_bReplenishTankOverTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15d, Value); } // 0x15d (Size: 0x1, Type: BoolProperty)
    void SET_TankReplenishDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
    void SET_TankReplenishRatePerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd0
struct FDelMarVehicleConfig_AirControl
{
public:
    float MaxPitchAdjustmentForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve LateralTurnRateCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    float UnderthrustTurnRate() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bAllowRedirectDuringKickflip() const { return Read<bool>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x1, Type: BoolProperty)
    bool bAllowVerticalRedirectDuringVerticalKickflip() const { return Read<bool>(uintptr_t(this) + 0x9d); } // 0x9d (Size: 0x1, Type: BoolProperty)
    float LateralKickflipScalar() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float VerticalTurnRate() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    float VerticalTurnRateAboveHorizon() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float MinSteerInput() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    float MinPitchVerticalDegreesFromWorldDown() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    float MaxPitchVerticalDegreesFromWorldDown() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    bool bAerialDivingBonusEnabled() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    float MinPitchForAerialDivingBonus() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxAerialDivingBonusSpeed() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MinAerialDivingBonusSpeed() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float AerialDivingBonusSpeedChangeRate() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float AerialDivingBonusSpeedDecayRate() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)

    void SET_MaxPitchAdjustmentForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LateralTurnRateCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_UnderthrustTurnRate(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_bAllowRedirectDuringKickflip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x1, Type: BoolProperty)
    void SET_bAllowVerticalRedirectDuringVerticalKickflip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d, Value); } // 0x9d (Size: 0x1, Type: BoolProperty)
    void SET_LateralKickflipScalar(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalTurnRate(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalTurnRateAboveHorizon(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_MinSteerInput(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_MinPitchVerticalDegreesFromWorldDown(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxPitchVerticalDegreesFromWorldDown(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_bAerialDivingBonusEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_MinPitchForAerialDivingBonus(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MaxAerialDivingBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_MinAerialDivingBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_AerialDivingBonusSpeedChangeRate(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_AerialDivingBonusSpeedDecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FDelMarVehicleConfig_AirFreestyle
{
public:
    FVector TorqueAccel() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector TorqueDamping() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_TorqueAccel(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_TorqueDamping(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FDelMarVehicleConfig_AirThrottle
{
public:
    FDelMarScaledCurve AccelerationScalarCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x90, Type: StructProperty)
    float AerialSpeedCap() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float OverCapSpeedLossPerSecond() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float AerialSlowdownImmunitySeconds() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bApplyNoThrottleSlowdown() const { return Read<bool>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x1, Type: BoolProperty)

    void SET_AccelerationScalarCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x90, Type: StructProperty)
    void SET_AerialSpeedCap(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_OverCapSpeedLossPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_AerialSlowdownImmunitySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_bApplyNoThrottleSlowdown(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
struct FDelMarVehicleConfig_AutoAerialRotation
{
public:
    FVector StabilizationDampingFactor() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector StabilizationFactor() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    float MaxUpsideDownDegreesForForcedRoll() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float IdleRotationThreshold() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float UpsideDownRollTorque() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float UpsideDownRollDamping() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float MinRollInput() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float SteerRollOffsetDegrees() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float MinPitchInput() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float MaxUserPitchOffsetDegrees() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float LateralPitchOffsetDegrees() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float UnderthrustPitchDegrees() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float MinThrottleInput() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float MaxUserThrottleOffsetDegrees() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float YawTorque() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    FVector MaxRotationSpeed() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    float MinApproachTargetScalar() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float MinForwardSpeedForYawRotation() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinSteerInputForForwardStateTurning() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float ForwardStateTurnRate() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bLandingAssistanceEnabled() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ECollisionChannel> LandingCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: ByteProperty)
    float LandingDetectionSeconds() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float MinLandingDetectionDistance() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float LandingSurfaceNormalMaxDegrees() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float LandingRotationAmplifier() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)

    void SET_StabilizationDampingFactor(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_StabilizationFactor(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_MaxUpsideDownDegreesForForcedRoll(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_IdleRotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_UpsideDownRollTorque(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_UpsideDownRollDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_MinRollInput(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_SteerRollOffsetDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_MinPitchInput(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_MaxUserPitchOffsetDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_LateralPitchOffsetDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_UnderthrustPitchDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_MinThrottleInput(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_MaxUserThrottleOffsetDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_YawTorque(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRotationSpeed(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_MinApproachTargetScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_MinForwardSpeedForYawRotation(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MinSteerInputForForwardStateTurning(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_ForwardStateTurnRate(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_bLandingAssistanceEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_LandingCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: ByteProperty)
    void SET_LandingDetectionSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_MinLandingDetectionDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_LandingSurfaceNormalMaxDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_LandingRotationAmplifier(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x24
struct FDelMarVehicleConfig_AutoUpright
{
public:
    float RotationTorque() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float RotationDamping() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinActiveSeconds() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinActiveSecondsGrounded() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float WheelsOnGroundChangedDelaySeconds() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bClearAngularVelocity() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    float MinDegreesFromVehicleUpThreshold() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float MinThrottleForWheelRotation() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bAllowActiveStateOnGround() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_RotationTorque(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_RotationDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinActiveSecondsGrounded(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_WheelsOnGroundChangedDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_bClearAngularVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_MinDegreesFromVehicleUpThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_MinThrottleForWheelRotation(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_bAllowActiveStateOnGround(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FDelMarVehicleConfig_Jump
{
public:
    float MinJumpTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxJumpTime() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float JumpVelocity() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float ForwardVelocity() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float PitchTorque() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float EndThrustForce() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_MinJumpTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxJumpTime(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_JumpVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ForwardVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_PitchTorque(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_EndThrustForce(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x158
struct FDelMarVehicleConfig_Kickflip
{
public:
    float DirectionalSensitivity() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float SecondaryDirectionalSensitivity() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bAllowDiagonalKickDirection() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    int32_t NumWheelsForLanding() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t NumActivationCharges() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    bool bResetChargesOnLanding() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    float MinActiveSecondsToReactivate() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float MinActiveTime() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float MaxActiveLateralTime() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxActiveUpwardTime() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float MaxActiveDownwardTime() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float CooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bAllowGroundedKickflips() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    float GroundedKickflipForce() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float LateralVelocity() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve LateralVelocityScalarCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x90, Type: StructProperty)
    float MinForwardSpeedForLateralScalar() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float MaxLateralVelocityCancelled() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    float UpwardVerticalVelocity() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    float DownwardVerticalVelocity() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    float LateralVerticalForce() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    float RotationDamping() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float RotationTorque() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float RotationTorqueIncomingCollision() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float MinSpeedToRotateYaw() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float MaxVerticalYawLandingDegrees() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    float MaxLateralYawLandingDegrees() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float MaxVerticalNormalLandingDegrees() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float MaxLateralNormalLandingDegrees() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    float MinLongRollTimeCheck() const { return Read<float>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: FloatProperty)
    float MinLongRollTimeCheckDownwardKick() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float MaxLongRollDegrees() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    float MinDegreesToCompleteRoll() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    float FastTorqueDistanceCheck() const { return Read<float>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: FloatProperty)
    bool bUseStartingDirectionWhenLanding() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    int32_t PredictionTickInterval() const { return Read<int32_t>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: IntProperty)
    float MaxSimulationRedirectSeconds() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float MaxSimulationDistanceLateral() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    float MaxSimulationDistanceUpward() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float MaxSimulationDistanceDownward() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bApplySuctionToSurfaces() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)
    float SuctionVelocity() const { return Read<float>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: FloatProperty)
    float MaxSuctionPerSecond() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    float SuctionDistanceCheck() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    float MaxAdditionalVelocitySuctionDistance() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> SuctionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x1, Type: ByteProperty)
    float MaxForwardVelocityDegreeDifference() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForPrimaryForwardRotation() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    float MaxGroundedDirectionDegrees() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)

    void SET_DirectionalSensitivity(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SecondaryDirectionalSensitivity(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bAllowDiagonalKickDirection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_NumWheelsForLanding(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_NumActivationCharges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_bResetChargesOnLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_MinActiveSecondsToReactivate(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_MinActiveTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveLateralTime(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveUpwardTime(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveDownwardTime(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_CooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bAllowGroundedKickflips(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_GroundedKickflipForce(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_LateralVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_LateralVelocityScalarCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x90, Type: StructProperty)
    void SET_MinForwardSpeedForLateralScalar(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLateralVelocityCancelled(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_UpwardVerticalVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_DownwardVerticalVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_LateralVerticalForce(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_RotationDamping(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_RotationTorque(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_RotationTorqueIncomingCollision(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeedToRotateYaw(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxVerticalYawLandingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLateralYawLandingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxVerticalNormalLandingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_MaxLateralNormalLandingDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_MinLongRollTimeCheck(const float& Value) { Write<float>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: FloatProperty)
    void SET_MinLongRollTimeCheckDownwardKick(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLongRollDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_MinDegreesToCompleteRoll(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_FastTorqueDistanceCheck(const float& Value) { Write<float>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: FloatProperty)
    void SET_bUseStartingDirectionWhenLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_PredictionTickInterval(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: IntProperty)
    void SET_MaxSimulationRedirectSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSimulationDistanceLateral(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSimulationDistanceUpward(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSimulationDistanceDownward(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_bApplySuctionToSurfaces(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
    void SET_SuctionVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSuctionPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_SuctionDistanceCheck(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_MaxAdditionalVelocitySuctionDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_SuctionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x1, Type: ByteProperty)
    void SET_MaxForwardVelocityDegreeDifference(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeedForPrimaryForwardRotation(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_MaxGroundedDirectionDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FDelMarVehicleConfig_Gravity
{
public:
    float ForceScaleCeiling() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ForceScaleWall() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ForceScaleGround() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float AerialGravityForceMultiplier() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float CoyoteTimeDuration() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    int32_t MinWheelsForCounterGravityMeasures() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    float MaxCounterGravitySpringVarianceDegrees() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bCounterGravityInKickflipSuctionDirection() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_ForceScaleCeiling(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ForceScaleWall(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ForceScaleGround(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AerialGravityForceMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_CoyoteTimeDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MinWheelsForCounterGravityMeasures(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_MaxCounterGravitySpringVarianceDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bCounterGravityInKickflipSuctionDirection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
struct FDelMarVehicleConfig_Reattachment
{
public:
    float SurfaceTraceDistance() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ReattachmentForceAmount() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve ReattachmentForceScalarCurve() const { return Read<FDelMarScaledCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> ReattachmentChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: ByteProperty)

    void SET_SurfaceTraceDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ReattachmentForceAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ReattachmentForceScalarCurve(const FDelMarScaledCurve& Value) { Write<FDelMarScaledCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
    void SET_ReattachmentChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x28
struct FDelMarVehicleConfig_WorldBonusSpeed
{
public:
    TArray<FDelMarWorldBonusSpeedSourceCap> BonusSpeedSourceCaps() const { return Read<TArray<FDelMarWorldBonusSpeedSourceCap>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    float MaxBonusSpeedPerStack() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxStackDuration() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> WorldBonusSpeedActors() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_BonusSpeedSourceCaps(const TArray<FDelMarWorldBonusSpeedSourceCap>& Value) { Write<TArray<FDelMarWorldBonusSpeedSourceCap>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxBonusSpeedPerStack(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MaxStackDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_WorldBonusSpeedActors(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FDelMarVehicleConfig_SelfDemolish
{
public:
    bool bSelfDemolishEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float RequiredDemolishActionDuration() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bSelfDemolishEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_RequiredDemolishActionDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FDelMarVehicleConfigOverride_AutoUpright
{
public:
    float MaxWorldContactDegreeThreshold() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_MaxWorldContactDegreeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleConfigOverride_Collision
{
public:
    bool bCollisionDemosEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWallRicochetEnabled() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bNonTrackVelocityRedirectEnabled() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    float DemoSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bCollisionDemosEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bWallRicochetEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bNonTrackVelocityRedirectEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_DemoSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FDelMarVehicleConfigOverride_Drift
{
public:
    float SpeedCapScalar() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float AccelerationRateScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float DecelerationRateScalar() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_SpeedCapScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_AccelerationRateScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_DecelerationRateScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FDelMarVehicleConfigOverride_DriftBoost
{
public:
    float MaxBonusSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float DurationScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float PotentialRateScalar() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_MaxBonusSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_DurationScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_PotentialRateScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x14
struct FDelMarVehicleConfigOverride_Drive
{
public:
    float MaxBaseForwardSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float AccelerationScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float DecelerationScalar() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float BrakeScalar() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxAerialSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_MaxBaseForwardSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_AccelerationScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_DecelerationScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_BrakeScalar(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxAerialSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleConfigOverride_Gravity
{
public:
    float CounterGravityContactDegreeThreshold() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float AerialGravityScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_CounterGravityContactDegreeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_AerialGravityScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FDelMarVehicleConfigOverride_Jump
{
public:
    float JumpImpulseScalar() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_JumpImpulseScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FDelMarVehicleConfigOverride_Kickflip
{
public:
    bool bResetChargesOnLanding() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    int32_t NumActivationCharges() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float CooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_bResetChargesOnLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_NumActivationCharges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_CooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleConfigOverride_Oversteer
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float AccumulatedSteerThresholdScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_AccumulatedSteerThresholdScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleConfigOverride_Terrain
{
public:
    bool bDemolishInWater() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float WaterDestructionDelay() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bDemolishInWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_WaterDestructionDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDelMarVehicleConfigOverride_Turbo
{
public:
    float StartingVehicleCharges() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ChargeRegenRateScalar() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float DriftBoostTurboGenerationScalar() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float TurboSpeedScalar() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxActiveTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float SuccessfulBonusZoneHitSeconds() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_StartingVehicleCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ChargeRegenRateScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostTurboGenerationScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_TurboSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxActiveTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SuccessfulBonusZoneHitSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1c
struct FDelMarVehicleConfigOverride_Underthrust
{
public:
    float StartingTankPercentage() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ConsumptionRateMultiplier() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bReplenishTankOnLanding() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bReplenishTankOverTime() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    float TankReplenishDelaySeconds() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float TankReplenishRateMultiplier() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float AccelScalar() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxUpwardSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_StartingTankPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ConsumptionRateMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bReplenishTankOnLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bReplenishTankOverTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_TankReplenishDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_TankReplenishRateMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_AccelScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_MaxUpwardSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarVehicleConfigOverride_SelfDemolish
{
public:
    bool bSelfDemolishEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float RequiredDemolishActionDuration() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bSelfDemolishEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_RequiredDemolishActionDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xa0
struct FDelMarVehicleConfigOverrides
{
public:
    bool bValid() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FDelMarVehicleConfigOverride_AutoUpright AutoUpright() const { return Read<FDelMarVehicleConfigOverride_AutoUpright>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleConfigOverride_Collision Collision() const { return Read<FDelMarVehicleConfigOverride_Collision>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Drift Drift() const { return Read<FDelMarVehicleConfigOverride_Drift>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleConfigOverride_DriftBoost DriftBoost() const { return Read<FDelMarVehicleConfigOverride_DriftBoost>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0xc, Type: StructProperty)
    FDelMarVehicleConfigOverride_Drive Drive() const { return Read<FDelMarVehicleConfigOverride_Drive>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x14, Type: StructProperty)
    FDelMarVehicleConfigOverride_Gravity Gravity() const { return Read<FDelMarVehicleConfigOverride_Gravity>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Jump Jump() const { return Read<FDelMarVehicleConfigOverride_Jump>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleConfigOverride_Kickflip Kickflip() const { return Read<FDelMarVehicleConfigOverride_Kickflip>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleConfigOverride_Oversteer Oversteer() const { return Read<FDelMarVehicleConfigOverride_Oversteer>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Terrain Terrain() const { return Read<FDelMarVehicleConfigOverride_Terrain>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Turbo Turbo() const { return Read<FDelMarVehicleConfigOverride_Turbo>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleConfigOverride_Underthrust Underthrust() const { return Read<FDelMarVehicleConfigOverride_Underthrust>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleConfigOverride_SelfDemolish SelfDemolish() const { return Read<FDelMarVehicleConfigOverride_SelfDemolish>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)

    void SET_bValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_AutoUpright(const FDelMarVehicleConfigOverride_AutoUpright& Value) { Write<FDelMarVehicleConfigOverride_AutoUpright>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_Collision(const FDelMarVehicleConfigOverride_Collision& Value) { Write<FDelMarVehicleConfigOverride_Collision>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Drift(const FDelMarVehicleConfigOverride_Drift& Value) { Write<FDelMarVehicleConfigOverride_Drift>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_DriftBoost(const FDelMarVehicleConfigOverride_DriftBoost& Value) { Write<FDelMarVehicleConfigOverride_DriftBoost>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0xc, Type: StructProperty)
    void SET_Drive(const FDelMarVehicleConfigOverride_Drive& Value) { Write<FDelMarVehicleConfigOverride_Drive>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x14, Type: StructProperty)
    void SET_Gravity(const FDelMarVehicleConfigOverride_Gravity& Value) { Write<FDelMarVehicleConfigOverride_Gravity>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x8, Type: StructProperty)
    void SET_Jump(const FDelMarVehicleConfigOverride_Jump& Value) { Write<FDelMarVehicleConfigOverride_Jump>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: StructProperty)
    void SET_Kickflip(const FDelMarVehicleConfigOverride_Kickflip& Value) { Write<FDelMarVehicleConfigOverride_Kickflip>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0xc, Type: StructProperty)
    void SET_Oversteer(const FDelMarVehicleConfigOverride_Oversteer& Value) { Write<FDelMarVehicleConfigOverride_Oversteer>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x8, Type: StructProperty)
    void SET_Terrain(const FDelMarVehicleConfigOverride_Terrain& Value) { Write<FDelMarVehicleConfigOverride_Terrain>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x8, Type: StructProperty)
    void SET_Turbo(const FDelMarVehicleConfigOverride_Turbo& Value) { Write<FDelMarVehicleConfigOverride_Turbo>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x18, Type: StructProperty)
    void SET_Underthrust(const FDelMarVehicleConfigOverride_Underthrust& Value) { Write<FDelMarVehicleConfigOverride_Underthrust>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1c, Type: StructProperty)
    void SET_SelfDemolish(const FDelMarVehicleConfigOverride_SelfDemolish& Value) { Write<FDelMarVehicleConfigOverride_SelfDemolish>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
};

// Size: 0x128
struct FDelMarDynamicForceFeedbackEffect
{
public:
    FForceFeedbackChannelDetails Effect() const { return Read<FForceFeedbackChannelDetails>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x90, Type: StructProperty)
    FRuntimeFloatCurve IntensityAmplifierCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x88, Type: StructProperty)

    void SET_Effect(const FForceFeedbackChannelDetails& Value) { Write<FForceFeedbackChannelDetails>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x90, Type: StructProperty)
    void SET_IntensityAmplifierCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x88, Type: StructProperty)
};

