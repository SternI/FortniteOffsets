/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricEngineSequencer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "MovieScene.h"
#include "CoreUObject.h"

// Size: 0x750
class UFabricAudioSyncSection : public UMovieSceneAudioSection
{
public:
    FMovieSceneFloatChannel SyncSoundVolume() const { return Read<FMovieSceneFloatChannel>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x110, Type: StructProperty)

    void SET_SyncSoundVolume(const FMovieSceneFloatChannel& Value) { Write<FMovieSceneFloatChannel>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x110, Type: StructProperty)
};

// Size: 0xc0
class UFabricAudioSyncTrackInstance : public UMovieSceneTrackInstance
{
public:
};

// Size: 0x50
class UMusicClockMovieSceneClockSource : public UObject
{
public:
};

// Size: 0x120
class UFabricAudioSyncTrack : public UMovieSceneAudioTrack
{
public:
};

