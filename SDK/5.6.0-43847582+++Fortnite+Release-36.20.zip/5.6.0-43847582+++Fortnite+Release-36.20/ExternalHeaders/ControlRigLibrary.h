/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRigLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ControlRig.h"
#include "CoreUObject.h"

// Size: 0x140
struct FRigUnit_ProjectItemOnPlane : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FTransform Original() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    FVector PlanePoint() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FVector PlaneNormal() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    float ProjectAlongNormal() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    bool SetItem() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x60, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_CachedItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Original(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_PlanePoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_PlaneNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_ProjectAlongNormal(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_SetItem(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x60, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_JunoRuntine_SolveIKTwoBones : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey BoneA() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneB() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneC() const { return Read<FRigElementKey>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedBoneA() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneB() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneC() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FTransform Effector() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    float InitialLength() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    bool PullEffector() const { return Read<bool>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: BoolProperty)

    void SET_BoneA(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_BoneB(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_BoneC(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_CachedBoneA(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CachedBoneB(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_CachedBoneC(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_Effector(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_InitialLength(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_PullEffector(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
struct FRigUnit_JunoRuntine_RootAlignment : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    float SideRotationFactor() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float CrouchingAmount() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_CachedItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_SideRotationFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_CrouchingAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf8
struct FRigUnit_TwoBoneIKOffPlane : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey BoneA() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneB() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneC() const { return Read<FRigElementKey>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneD() const { return Read<FRigElementKey>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)
    FVector Effector() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    float Tolerance() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedBoneAIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneBIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneCIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneDIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)

    void SET_BoneA(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_BoneB(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_BoneC(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_BoneD(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
    void SET_Effector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_Tolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_CachedBoneAIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_CachedBoneBIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x18, Type: StructProperty)
    void SET_CachedBoneCIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x18, Type: StructProperty)
    void SET_CachedBoneDIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
};

