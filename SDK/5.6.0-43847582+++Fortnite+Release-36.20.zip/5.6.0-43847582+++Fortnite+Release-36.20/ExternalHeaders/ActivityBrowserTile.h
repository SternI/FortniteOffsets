/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x15b0
class UActivityBrowserTile_C : public UFortActivityBrowserTile
{
public:
};

