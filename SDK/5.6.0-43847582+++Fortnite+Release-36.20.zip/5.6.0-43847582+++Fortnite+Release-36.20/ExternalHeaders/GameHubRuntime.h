/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameHubRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"

// Size: 0x370
class AGameHubBaseMutator : public AFortAthenaMutator
{
public:
};

// Size: 0xe8
class UGameHubPlayerSpawningComponent : public UPlayspaceComponent_PlayerSpawning
{
public:
    FGameplayTagContainer PlayerStartRequirements() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x20, Type: StructProperty)

    void SET_PlayerStartRequirements(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x708
class AGameHubPlayspace : public AFortPlayspace
{
public:
    bool bSimulatePlayerDamage() const { return Read<bool>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer PlayerStartRequirements() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x20, Type: StructProperty)

    void SET_bSimulatePlayerDamage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x1, Type: BoolProperty)
    void SET_PlayerStartRequirements(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x20, Type: StructProperty)
};

