/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_ConversationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "LocalizableMessage.h"

// Size: 0x300
class AConversationEntityProxyActor : public AActor
{
public:
    TArray<AController*> ControllersInConversation() const { return Read<TArray<AController*>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    USceneComponent* RootSceneComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UFortNonPlayerConversationParticipantComponent* NonPlayerConversationComponent() const { return Read<UFortNonPlayerConversationParticipantComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    FLocalizableMessage SpeakerName() const { return Read<FLocalizableMessage>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x30, Type: StructProperty)
    UObject* CachedConversationEntityComponent() const { return Read<UObject*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)

    void SET_ControllersInConversation(const TArray<AController*>& Value) { Write<TArray<AController*>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_RootSceneComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_NonPlayerConversationComponent(const UFortNonPlayerConversationParticipantComponent*& Value) { Write<UFortNonPlayerConversationParticipantComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SpeakerName(const FLocalizableMessage& Value) { Write<FLocalizableMessage>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x30, Type: StructProperty)
    void SET_CachedConversationEntityComponent(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x638
class UFNE_NonPlayerConversationParticipantComponent : public UFortNonPlayerConversationParticipantComponent
{
public:
};

