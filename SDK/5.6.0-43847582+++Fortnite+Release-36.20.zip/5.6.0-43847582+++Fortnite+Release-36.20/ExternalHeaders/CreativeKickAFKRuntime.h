/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeKickAFKRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0x308
class UFortCreativeKickAFKComponent : public UFortInputBasedAFKComponent
{
public:
    FDataTableRowHandle AFKTableRowEntry() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: StructProperty)
    FInputBasedAFKDetectionParameters KickAFKDetectionParameters() const { return Read<FInputBasedAFKDetectionParameters>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x70, Type: StructProperty)

    void SET_AFKTableRowEntry(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: StructProperty)
    void SET_KickAFKDetectionParameters(const FInputBasedAFKDetectionParameters& Value) { Write<FInputBasedAFKDetectionParameters>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x70, Type: StructProperty)
};

