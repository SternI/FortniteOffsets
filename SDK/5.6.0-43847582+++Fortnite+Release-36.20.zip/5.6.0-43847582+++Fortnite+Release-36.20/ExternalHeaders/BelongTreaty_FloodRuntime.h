/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BelongTreaty_FloodRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0xb58
class ABelongTreatyProjectile : public AFortProjectileBase
{
public:
};

// Size: 0x630
class UBelongTreatyProjectileMovementComponent : public UFortProjectileMovementComponent_FloorSnapped
{
public:
    FScalableFloat InitialProjectileSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x28, Type: StructProperty)
    FScalableFloat StandardSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x28, Type: StructProperty)
    float ServerSpawnTime() const { return Read<float>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    FTimerHandle EaseInRecurringTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: StructProperty)
    FTimerHandle EaseInTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: StructProperty)
    UCurveFloat* EaseInCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat TransitionDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat EaseInUpdateFrequency() const { return Read<FScalableFloat>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x28, Type: StructProperty)

    void SET_InitialProjectileSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x28, Type: StructProperty)
    void SET_StandardSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x28, Type: StructProperty)
    void SET_ServerSpawnTime(const float& Value) { Write<float>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    void SET_EaseInRecurringTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: StructProperty)
    void SET_EaseInTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: StructProperty)
    void SET_EaseInCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    void SET_TransitionDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x28, Type: StructProperty)
    void SET_EaseInUpdateFrequency(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x28, Type: StructProperty)
};

