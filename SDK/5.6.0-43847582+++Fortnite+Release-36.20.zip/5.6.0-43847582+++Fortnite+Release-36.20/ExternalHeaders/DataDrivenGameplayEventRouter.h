/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataDrivenGameplayEventRouter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayEventRouter.h"

// Size: 0x28
class UGameplayEventLegacyBroadcast : public UInterface
{
public:
};

// Size: 0x28
class UGameplayEventDescriptorLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x10
struct FGameplayEventDefinition
{
public:
    UScriptStruct* EventType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bIsStateful() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t NetPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: EnumProperty)

    void SET_EventType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsStateful(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_NetPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x8
struct FGameplayEventDescriptor
{
public:
};

// Size: 0x70
struct FGameplayEventSubscription
{
public:
    TSoftObjectPtr<UObject> Object() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FMemberReference EventDescriptor() const { return Read<FMemberReference>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x30, Type: StructProperty)
    FGameplayEventListenerHandle EventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1c, Type: StructProperty)

    void SET_Object(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_EventDescriptor(const FMemberReference& Value) { Write<FMemberReference>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x30, Type: StructProperty)
    void SET_EventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1c, Type: StructProperty)
};

// Size: 0x80
struct FGameplayEventHandlerFunction
{
public:
    FMemberReference EventHandlerFunction() const { return Read<FMemberReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    TMap<FName, FString> EventHandlerFunctionDefaultValues() const { return Read<TMap<FName, FString>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_EventHandlerFunction(const FMemberReference& Value) { Write<FMemberReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_EventHandlerFunctionDefaultValues(const TMap<FName, FString>& Value) { Write<TMap<FName, FString>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x180
struct FGameplayEventHandlerFunctions
{
public:
    FGameplayEventHandlerFunction OnEventReceived() const { return Read<FGameplayEventHandlerFunction>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    FGameplayEventHandlerFunction OnStatefulEventApplied() const { return Read<FGameplayEventHandlerFunction>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x80, Type: StructProperty)
    FGameplayEventHandlerFunction OnStatefulEventCleared() const { return Read<FGameplayEventHandlerFunction>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x80, Type: StructProperty)

    void SET_OnEventReceived(const FGameplayEventHandlerFunction& Value) { Write<FGameplayEventHandlerFunction>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_OnStatefulEventApplied(const FGameplayEventHandlerFunction& Value) { Write<FGameplayEventHandlerFunction>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x80, Type: StructProperty)
    void SET_OnStatefulEventCleared(const FGameplayEventHandlerFunction& Value) { Write<FGameplayEventHandlerFunction>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x80, Type: StructProperty)
};

// Size: 0x18
struct FGameplayEventFunction
{
public:
    TArray<FGameplayEventSubscription> EventSubscriptions() const { return Read<TArray<FGameplayEventSubscription>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_EventSubscriptions(const TArray<FGameplayEventSubscription>& Value) { Write<TArray<FGameplayEventSubscription>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

