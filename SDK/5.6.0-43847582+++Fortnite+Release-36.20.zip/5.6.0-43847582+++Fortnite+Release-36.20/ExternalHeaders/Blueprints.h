/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Blueprints
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "UIKit.h"
#include "AnimationBudgetAllocator.h"
#include "CoreUObject.h"
#include "SlateCore.h"
#include "FortniteUI.h"

// Size: 0x398
class ABP_VictoryDrone_C : public APawn
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: StructProperty)
    USkeletalMeshComponentBudgeted* SkeletalMeshComponentBudgeted() const { return Read<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene() const { return Read<USceneComponent*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    double AnimPlayRate() const { return Read<double>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: DoubleProperty)
    UMaterialInstanceDynamic* StaticMeshMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool TeleportIn() const { return Read<bool>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x1, Type: BoolProperty)
    bool IsAthena() const { return Read<bool>(uintptr_t(this) + 0x361); } // 0x361 (Size: 0x1, Type: BoolProperty)
    AFortPawn* TargetPlayer() const { return Read<AFortPawn*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* CharacterAttached() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    bool InLobby() const { return Read<bool>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x1, Type: BoolProperty)
    bool IsNPC() const { return Read<bool>(uintptr_t(this) + 0x379); } // 0x379 (Size: 0x1, Type: BoolProperty)
    FName AttachPoint() const { return Read<FName>(uintptr_t(this) + 0x37c); } // 0x37c (Size: 0x4, Type: NameProperty)
    bool isDecoy() const { return Read<bool>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x1, Type: BoolProperty)
    USkeletalMeshComponent* Mesh_for_Attachment() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundOnNPCDeath() const { return Read<USoundBase*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: StructProperty)
    void SET_SkeletalMeshComponentBudgeted(const USkeletalMeshComponentBudgeted*& Value) { Write<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Scene(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: DoubleProperty)
    void SET_StaticMeshMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x1, Type: BoolProperty)
    void SET_IsAthena(const bool& Value) { Write<bool>(uintptr_t(this) + 0x361, Value); } // 0x361 (Size: 0x1, Type: BoolProperty)
    void SET_TargetPlayer(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_CharacterAttached(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_InLobby(const bool& Value) { Write<bool>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x1, Type: BoolProperty)
    void SET_IsNPC(const bool& Value) { Write<bool>(uintptr_t(this) + 0x379, Value); } // 0x379 (Size: 0x1, Type: BoolProperty)
    void SET_AttachPoint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x37c, Value); } // 0x37c (Size: 0x4, Type: NameProperty)
    void SET_isDecoy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x1, Type: BoolProperty)
    void SET_Mesh_for_Attachment(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundOnNPCDeath(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UPlatformHelpersLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x309
class UWBP_CaptureForPostBufferUpdate_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    UPostBufferUpdate* PostBufferUpdate() const { return Read<UPostBufferUpdate*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    bool Perform_Default_Post_Buffer_Update() const { return Read<bool>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: StructProperty)
    void SET_PostBufferUpdate(const UPostBufferUpdate*& Value) { Write<UPostBufferUpdate*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_Perform_Default_Post_Buffer_Update(const bool& Value) { Write<bool>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2020
class UAthena_PlayerCameraMode_Harveting_1blade_1P_C : public UAthena_PlayerCameraMode_1P_C
{
public:
};

// Size: 0x358
class ALandscapeWaterInfo_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    double Flood_Water_Level() const { return Read<double>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    UTexture2D* Game_Texture__Water_Velocity_and_Height() const { return Read<UTexture2D*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    FTransform LS_Transform() const { return Read<FTransform>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x60, Type: StructProperty)
    FIntPoint LS_RT_Res() const { return Read<FIntPoint>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: StructProperty)
    FVector2D Quad_Size() const { return Read<FVector2D>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x10, Type: StructProperty)
    bool Use_Terrain_Velocity_and_Height_Texture() const { return Read<bool>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* External_Water_MID_To_Update() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Flood_Water_Level(const double& Value) { Write<double>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    void SET_Game_Texture__Water_Velocity_and_Height(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_LS_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x60, Type: StructProperty)
    void SET_LS_RT_Res(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: StructProperty)
    void SET_Quad_Size(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x10, Type: StructProperty)
    void SET_Use_Terrain_Velocity_and_Height_Texture(const bool& Value) { Write<bool>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: BoolProperty)
    void SET_External_Water_MID_To_Update(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2020
class UAthena_PlayerCameraMode_HidingProp_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x370
class ABP_TeleportationDrone_C : public APawn
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: StructProperty)
    USkeletalMeshComponentBudgeted* SkeletalMeshComponentBudgeted() const { return Read<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene() const { return Read<USceneComponent*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    double AnimPlayRate() const { return Read<double>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    UMaterialInstanceDynamic* StaticMeshMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    bool TeleportIn() const { return Read<bool>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x1, Type: BoolProperty)
    UParticleSystemComponent* CharacterAttached() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool InLobby() const { return Read<bool>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x1, Type: BoolProperty)
    USkeletalMeshComponent* Mesh_for_Attachment() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: StructProperty)
    void SET_SkeletalMeshComponentBudgeted(const USkeletalMeshComponentBudgeted*& Value) { Write<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Scene(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimPlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    void SET_StaticMeshMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x1, Type: BoolProperty)
    void SET_CharacterAttached(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_InLobby(const bool& Value) { Write<bool>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x1, Type: BoolProperty)
    void SET_Mesh_for_Attachment(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2020
class UAthena_PlayerCameraMode_HidingProp_Teleport_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0xd8
class UGSC_MiniMapDataOverride_C : public UFortGameStateComponent_MiniMapDataOverride
{
public:
};

// Size: 0x28
class UUIKit_FunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UBlueprintDebuggingInterface_C : public UInterface
{
public:
};

// Size: 0x28
class UBuildingFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraMode_Harveting_stock_1P_C : public UAthena_PlayerCameraMode_1P_C
{
public:
};

// Size: 0x2600
class UPlayerCameraMode1P_C : public UFortCameraMode_Custom
{
public:
};

// Size: 0x28
class UInterfacePlayerPawn_C : public UInterface
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeRangedTargeting_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class USTW_PlayerCameraModeRangedTargeting_C : public UAthena_PlayerCameraModeRangedTargeting_C
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeTargetingPistol_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x1f0
class UTargeting3PCamera_MidRange_C : public UFort3PCam_Targeting
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeRanged_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeTargetingScope_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeTargetingPistol_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

// Size: 0x70
class UCinematicCamera_MatineeTransition_C : public UFortCinematicCamera
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeMelee_C : public Uv3_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class UHoverboardCameraMode_C : public UFortHoverboardCameraMode
{
public:
};

// Size: 0x2020
class USTW_PlayerCameraModeBase_C : public USTW_PlayerCameraModeMelee_C
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeTargetingVeryShortRange_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeMelee_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeTargetingVeryShortRange_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeRanged_C : public Uv2_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeMelee_C : public Uv2_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeTargetingRifle_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class UPlayerCameraMode_DBNO_C : public Uv3_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeTargetingScope_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraMode_RespawnedAir_C : public UFortCameraMode_RespawnedAir
{
public:
};

// Size: 0x1f0
class UTargeting3PCamera_LongRange_C : public UFort3PCam_Targeting
{
public:
};

// Size: 0x2020
class Uv1_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeRanged_C : public Uv3_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

// Size: 0x2020
class UAthena_PlayerCamera_DBNO_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraMode_WaterSprintBoost_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x1f0
class URanged3PCamera_C : public UFort3PCam_Default
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeTargetingVeryShortRange_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraFocalPoint_C : public UFortCameraMode_FocalPoint
{
public:
};

// Size: 0x3270
class AMainPlayerCamera_C : public AFortPlayerCameraZone
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeTargetingScope_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeTargetingTethered_C : public UAthena_PlayerCameraModeRangedTargeting_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeSkydiveParachute_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeTargetingRifle_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x1f0
class UTargeting3PCamera_Scope_C : public UFort3PCam_Targeting
{
public:
};

// Size: 0x1f0
class UDefault3PCamera_C : public UFort3PCam_Default
{
public:
};

// Size: 0x1f0
class USniper3PCamera_C : public UFort3PCam_Default
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeSkydiveGlide_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeSkydiveDive_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class Uv3_PlayerCameraModeTargetingAssault_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeTargetingRifle_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraHoisted_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x2020
class USTW_PlayerCameraModeMelee_C : public UAthena_PlayerCameraModeMelee_C
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraModeMelee_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

// Size: 0x1f0
class UTargeting3PCamera_C : public UFort3PCam_Targeting
{
public:
};

// Size: 0x1f0
class UTargeting3PCamera_VeryShortRange_C : public UFort3PCam_Targeting
{
public:
};

// Size: 0x2020
class Uv2_PlayerCameraModeTargetingPistol_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

// Size: 0x1f0
class UPlayerTakeDamage_CameraShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x2020
class UAthena_PlayerCameraMode_1P_C : public UAthena_PlayerCameraModeRangedTargeting_C
{
public:
};

// Size: 0x40
class UBP_UI_PostProcessBlur_C : public USlatePostBufferBlur
{
public:
};

