/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AIPatrolPath
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "AIModule.h"
#include "GameplayTags.h"
#include "FortniteAI.h"
#include "NavigationSystem.h"

// Size: 0x620
class UAIPatrolPathEditorComponent : public UDebugDrawComponent
{
public:
};

// Size: 0x3d0
class UAIPatrolPathComponent : public UActorComponent
{
public:
    TArray<FString> SharedOptionNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    UClass* PathRendererClass() const { return Read<UClass*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ClassProperty)
    bool bAllowPartialPaths() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer UnableToPlaceNewDeviceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x20, Type: StructProperty)
    FNavAgentProperties CachedAIAgentProperties() const { return Read<FNavAgentProperties>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x30, Type: StructProperty)
    UNavigationSystemV1* CachedNavSystem() const { return Read<UNavigationSystemV1*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    ANavigationData* CachedNavData() const { return Read<ANavigationData*>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    UClass* CachedFilterClass() const { return Read<UClass*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ClassProperty)
    TArray<AActor*> PatrolPath() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: ArrayProperty)
    FPatrolPathSegmentDetails PathSegmentDetails() const { return Read<FPatrolPathSegmentDetails>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x108, Type: StructProperty)
    UAIPatrolPathComponent* CopiedFrom() const { return Read<UAIPatrolPathComponent*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    AActor* CurrentCloningNode() const { return Read<AActor*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UAIPatrolPathComponent* CopiedFromCut() const { return Read<UAIPatrolPathComponent*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    AFortCreativePatrolPath* PatrolPathActor() const { return Read<AFortCreativePatrolPath*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    AFortAthenaPatrolPoint* PatrolPointActor() const { return Read<AFortAthenaPatrolPoint*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    TArray<UAIPatrolPathComponent*> MultiSelectActorToEnterList() const { return Read<TArray<UAIPatrolPathComponent*>>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x10, Type: ArrayProperty)
    bool bCurrentlyPropagatingSharedOptions() const { return Read<bool>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    UAIPatrolPathEditorComponent* PatrolPathEditorComponent() const { return Read<UAIPatrolPathEditorComponent*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)

    void SET_SharedOptionNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_PathRendererClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ClassProperty)
    void SET_bAllowPartialPaths(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_UnableToPlaceNewDeviceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x20, Type: StructProperty)
    void SET_CachedAIAgentProperties(const FNavAgentProperties& Value) { Write<FNavAgentProperties>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x30, Type: StructProperty)
    void SET_CachedNavSystem(const UNavigationSystemV1*& Value) { Write<UNavigationSystemV1*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedNavData(const ANavigationData*& Value) { Write<ANavigationData*>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedFilterClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ClassProperty)
    void SET_PatrolPath(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: ArrayProperty)
    void SET_PathSegmentDetails(const FPatrolPathSegmentDetails& Value) { Write<FPatrolPathSegmentDetails>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x108, Type: StructProperty)
    void SET_CopiedFrom(const UAIPatrolPathComponent*& Value) { Write<UAIPatrolPathComponent*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentCloningNode(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_CopiedFromCut(const UAIPatrolPathComponent*& Value) { Write<UAIPatrolPathComponent*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_PatrolPathActor(const AFortCreativePatrolPath*& Value) { Write<AFortCreativePatrolPath*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_PatrolPointActor(const AFortAthenaPatrolPoint*& Value) { Write<AFortAthenaPatrolPoint*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_MultiSelectActorToEnterList(const TArray<UAIPatrolPathComponent*>& Value) { Write<TArray<UAIPatrolPathComponent*>>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x10, Type: ArrayProperty)
    void SET_bCurrentlyPropagatingSharedOptions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    void SET_PatrolPathEditorComponent(const UAIPatrolPathEditorComponent*& Value) { Write<UAIPatrolPathEditorComponent*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x108
struct FPatrolPathSegmentDetails
{
public:
    UAIPatrolPathComponent* Start() const { return Read<UAIPatrolPathComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_Start(const UAIPatrolPathComponent*& Value) { Write<UAIPatrolPathComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

