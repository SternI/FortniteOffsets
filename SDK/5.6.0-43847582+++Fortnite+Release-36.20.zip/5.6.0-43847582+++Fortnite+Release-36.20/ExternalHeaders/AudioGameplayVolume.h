/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioGameplayVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0xd8
class UAttenuationVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    float ExteriorVolume() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ExteriorTime() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float InteriorVolume() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float InteriorTime() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)

    void SET_ExteriorVolume(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_ExteriorTime(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_InteriorVolume(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_InteriorTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc8
class UAudioGameplayVolumeMutator : public UAudioGameplayComponent
{
public:
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: IntProperty)

    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x310
class AAudioGameplayVolume : public AVolume
{
public:
    UAudioGameplayVolumeComponent* AGVComponent() const { return Read<UAudioGameplayVolumeComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x1, Type: BoolProperty)

    void SET_AGVComponent(const UAudioGameplayVolumeComponent*& Value) { Write<UAudioGameplayVolumeComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe8
class UAudioGameplayVolumeComponent : public UAudioGameplayComponent
{
public:
    UAudioGameplayVolumeProxy* Proxy() const { return Read<UAudioGameplayVolumeProxy*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_Proxy(const UAudioGameplayVolumeProxy*& Value) { Write<UAudioGameplayVolumeProxy*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UAudioGameplayVolumeComponentBase : public UAudioGameplayComponent
{
public:
};

// Size: 0x48
class UAudioGameplayVolumeProxy : public UObject
{
public:
};

// Size: 0x58
class UAGVPrimitiveComponentProxy : public UAudioGameplayVolumeProxy
{
public:
    TArray<UPrimitiveComponent*> Primitives() const { return Read<TArray<UPrimitiveComponent*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_Primitives(const TArray<UPrimitiveComponent*>& Value) { Write<TArray<UPrimitiveComponent*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
class UAGVConditionProxy : public UAudioGameplayVolumeProxy
{
public:
    UObject* ObjectPtr() const { return Read<UObject*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_ObjectPtr(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x168
class UAudioGameplayVolumeSubsystem : public UAudioEngineSubsystem
{
public:
    TArray<UAudioGameplayVolumeProxy*> TransientProxyList() const { return Read<TArray<UAudioGameplayVolumeProxy*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TMap<uint32_t, UAudioGameplayVolumeComponent*> AGVComponents() const { return Read<TMap<uint32_t, UAudioGameplayVolumeComponent*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: MapProperty)

    void SET_TransientProxyList(const TArray<UAudioGameplayVolumeProxy*>& Value) { Write<TArray<UAudioGameplayVolumeProxy*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_AGVComponents(const TMap<uint32_t, UAudioGameplayVolumeComponent*>& Value) { Write<TMap<uint32_t, UAudioGameplayVolumeComponent*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: MapProperty)
};

// Size: 0xd8
class UFilterVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    float ExteriorLPF() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ExteriorLPFTime() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float InteriorLPF() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float InteriorLPFTime() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)

    void SET_ExteriorLPF(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_ExteriorLPFTime(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_InteriorLPF(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_InteriorLPFTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe8
class UReverbVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    FReverbSettings ReverbSettings() const { return Read<FReverbSettings>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x20, Type: StructProperty)

    void SET_ReverbSettings(const FReverbSettings& Value) { Write<FReverbSettings>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x20, Type: StructProperty)
};

// Size: 0xd8
class USubmixOverrideVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    TArray<FAudioVolumeSubmixOverrideSettings> SubmixOverrideSettings() const { return Read<TArray<FAudioVolumeSubmixOverrideSettings>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_SubmixOverrideSettings(const TArray<FAudioVolumeSubmixOverrideSettings>& Value) { Write<TArray<FAudioVolumeSubmixOverrideSettings>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd8
class USubmixSendVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    TArray<FAudioVolumeSubmixSendSettings> SubmixSendSettings() const { return Read<TArray<FAudioVolumeSubmixSendSettings>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_SubmixSendSettings(const TArray<FAudioVolumeSubmixSendSettings>& Value) { Write<TArray<FAudioVolumeSubmixSendSettings>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

