/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricMetasoundDataTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "HarmonixDsp.h"
#include "Engine.h"

// Size: 0x50
class UFabricMetasoundDrumPlayerSampleBankAsset : public UDataAsset
{
public:
    FText SampleKitName() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    TArray<FFabricMetasoundDrumPlayerSampleData> Samples() const { return Read<TArray<FFabricMetasoundDrumPlayerSampleData>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_SampleKitName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_Samples(const TArray<FFabricMetasoundDrumPlayerSampleData>& Value) { Write<TArray<FFabricMetasoundDrumPlayerSampleData>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UFabricMetasoundDrumPlayerDataAsset : public UDataAsset
{
public:
    TArray<TSoftObjectPtr<UFabricMetasoundDrumPlayerSampleBankAsset*>> SampleBanks() const { return Read<TArray<TSoftObjectPtr<UFabricMetasoundDrumPlayerSampleBankAsset*>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_SampleBanks(const TArray<TSoftObjectPtr<UFabricMetasoundDrumPlayerSampleBankAsset*>>& Value) { Write<TArray<TSoftObjectPtr<UFabricMetasoundDrumPlayerSampleBankAsset*>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UFabricMetasoundInstrumentPlayerDataAsset : public UDataAsset
{
public:
    UFusionPatch* Patch() const { return Read<UFusionPatch*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_Patch(const UFusionPatch*& Value) { Write<UFusionPatch*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UFabricMetasoundInstrumentPlayerDataAssetList : public UDataAsset
{
public:
    TArray<TSoftObjectPtr<UFabricMetasoundInstrumentPlayerDataAsset*>> InstrumentPlayerData() const { return Read<TArray<TSoftObjectPtr<UFabricMetasoundInstrumentPlayerDataAsset*>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_InstrumentPlayerData(const TArray<TSoftObjectPtr<UFabricMetasoundInstrumentPlayerDataAsset*>>& Value) { Write<TArray<TSoftObjectPtr<UFabricMetasoundInstrumentPlayerDataAsset*>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UFabricMetaSoundUserOption : public UObject
{
public:
    FFabricUserOption FabricUserOption() const { return Read<FFabricUserOption>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x38, Type: StructProperty)

    void SET_FabricUserOption(const FFabricUserOption& Value) { Write<FFabricUserOption>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x38, Type: StructProperty)
};

// Size: 0x18
struct FFabricMetasoundDrumPlayerSampleData
{
public:
    FText SampleLabel() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    USoundWave* WaveAsset() const { return Read<USoundWave*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_SampleLabel(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_WaveAsset(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FFabricUserOption
{
public:
    uint8_t UserOptionType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ConversionType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    float Min() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Max() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float ValueCurve() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bInverted() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    TArray<float> NumericLookupTable() const { return Read<TArray<float>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> StringLookupTable() const { return Read<TArray<FString>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_UserOptionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ConversionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_Min(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Max(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ValueCurve(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_NumericLookupTable(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_StringLookupTable(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

