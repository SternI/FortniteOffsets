/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BuildPatchServices
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x120
class UBuildPatchManifest : public UObject
{
public:
    char ManifestFileVersion() const { return Read<char>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: ByteProperty)
    bool bIsFileData() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    uint32_t AppID() const { return Read<uint32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: UInt32Property)
    FString AppName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString BuildVersion() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    FString LaunchExe() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    FString LaunchCommand() const { return Read<FString>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StrProperty)
    TSet<FString> PrereqIds() const { return Read<TSet<FString>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x50, Type: SetProperty)
    FString PrereqName() const { return Read<FString>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: StrProperty)
    FString PrereqPath() const { return Read<FString>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StrProperty)
    FString PrereqArgs() const { return Read<FString>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StrProperty)
    TArray<FFileManifestData> FileManifestList() const { return Read<TArray<FFileManifestData>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<FChunkInfoData> ChunkList() const { return Read<TArray<FChunkInfoData>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomFieldData> CustomFields() const { return Read<TArray<FCustomFieldData>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)

    void SET_ManifestFileVersion(const char& Value) { Write<char>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: ByteProperty)
    void SET_bIsFileData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_AppID(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: UInt32Property)
    void SET_AppName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_BuildVersion(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_LaunchExe(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_LaunchCommand(const FString& Value) { Write<FString>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StrProperty)
    void SET_PrereqIds(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x50, Type: SetProperty)
    void SET_PrereqName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: StrProperty)
    void SET_PrereqPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StrProperty)
    void SET_PrereqArgs(const FString& Value) { Write<FString>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StrProperty)
    void SET_FileManifestList(const TArray<FFileManifestData>& Value) { Write<TArray<FFileManifestData>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_ChunkList(const TArray<FChunkInfoData>& Value) { Write<TArray<FChunkInfoData>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_CustomFields(const TArray<FCustomFieldData>& Value) { Write<TArray<FCustomFieldData>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FCustomFieldData
{
public:
    FString Key() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Key(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x14
struct FSHAHashData
{
public:
    char Hash() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: ByteProperty)

    void SET_Hash(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: ByteProperty)
};

// Size: 0x40
struct FChunkInfoData
{
public:
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    uint64_t Hash() const { return Read<uint64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: UInt64Property)
    FSHAHashData ShaHash() const { return Read<FSHAHashData>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x14, Type: StructProperty)
    int64_t FileSize() const { return Read<int64_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: Int64Property)
    char GroupNumber() const { return Read<char>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)

    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Hash(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: UInt64Property)
    void SET_ShaHash(const FSHAHashData& Value) { Write<FSHAHashData>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x14, Type: StructProperty)
    void SET_FileSize(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: Int64Property)
    void SET_GroupNumber(const char& Value) { Write<char>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x18
struct FChunkPartData
{
public:
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    uint32_t Offset() const { return Read<uint32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: UInt32Property)
    uint32_t Size() const { return Read<uint32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: UInt32Property)

    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Offset(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: UInt32Property)
    void SET_Size(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x68
struct FFileManifestData
{
public:
    FString Filename() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FSHAHashData FileHash() const { return Read<FSHAHashData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x14, Type: StructProperty)
    TArray<FChunkPartData> FileChunkParts() const { return Read<TArray<FChunkPartData>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> InstallTags() const { return Read<TArray<FString>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    bool bIsUnixExecutable() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    FString SymlinkTarget() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    bool bIsReadOnly() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bIsCompressed() const { return Read<bool>(uintptr_t(this) + 0x61); } // 0x61 (Size: 0x1, Type: BoolProperty)

    void SET_Filename(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_FileHash(const FSHAHashData& Value) { Write<FSHAHashData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x14, Type: StructProperty)
    void SET_FileChunkParts(const TArray<FChunkPartData>& Value) { Write<TArray<FChunkPartData>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_InstallTags(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsUnixExecutable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_SymlinkTarget(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_bIsReadOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCompressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61, Value); } // 0x61 (Size: 0x1, Type: BoolProperty)
};

