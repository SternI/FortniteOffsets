/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosCloth
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x180
class UChaosClothConfig : public UClothConfigCommon
{
public:
    uint8_t MassMode() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    float UniformMass() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float TotalMass() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float Density() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float MinPerParticleMass() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FChaosClothWeightedValue EdgeStiffnessWeighted() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue BendingStiffnessWeighted() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x8, Type: StructProperty)
    bool bUseBendingElements() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    float BucklingRatio() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FChaosClothWeightedValue BucklingStiffnessWeighted() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue FlatnessRatio() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue AreaStiffnessWeighted() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x8, Type: StructProperty)
    float VolumeStiffness() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    FChaosClothWeightedValue TetherStiffness() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue TetherScale() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)
    bool bUseGeodesicDistance() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)
    float ShapeTargetStiffness() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float CollisionThickness() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float FrictionCoefficient() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bUseCCD() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bUseSelfCollisions() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)
    float SelfCollisionThickness() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionFriction() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bUseSelfIntersections() const { return Read<bool>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x1, Type: BoolProperty)
    bool bUseSelfCollisionSpheres() const { return Read<bool>(uintptr_t(this) + 0x9d); } // 0x9d (Size: 0x1, Type: BoolProperty)
    float SelfCollisionSphereRadius() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionSphereStiffness() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionSphereRadiusCullMultiplier() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    bool bUseLegacyBackstop() const { return Read<bool>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x1, Type: BoolProperty)
    float DampingCoefficient() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    float LocalDampingCoefficient() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    bool bUsePointBasedWindModel() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    FChaosClothWeightedValue Drag() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x8, Type: StructProperty)
    bool bEnableOuterDrag() const { return Read<bool>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x1, Type: BoolProperty)
    FChaosClothWeightedValue OuterDrag() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue Lift() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: StructProperty)
    bool bEnableOuterLift() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    FChaosClothWeightedValue OuterLift() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x8, Type: StructProperty)
    bool bUseGravityOverride() const { return Read<bool>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x1, Type: BoolProperty)
    float GravityScale() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    FVector Gravity() const { return Read<FVector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FChaosClothWeightedValue Pressure() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue AnimDriveStiffness() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue AnimDriveDamping() const { return Read<FChaosClothWeightedValue>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: StructProperty)
    uint8_t VelocityScaleSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: EnumProperty)
    FVector LinearVelocityScale() const { return Read<FVector>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x18, Type: StructProperty)
    bool bEnableLinearVelocityClamping() const { return Read<bool>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: BoolProperty)
    FVector3f MaxLinearVelocity() const { return Read<FVector3f>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0xc, Type: StructProperty)
    bool bEnableLinearAccelerationClamping() const { return Read<bool>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: BoolProperty)
    FVector3f MaxLinearAcceleration() const { return Read<FVector3f>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0xc, Type: StructProperty)
    float AngularVelocityScale() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)
    bool bEnableAngularVelocityClamping() const { return Read<bool>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x1, Type: BoolProperty)
    float MaxAngularVelocity() const { return Read<float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: FloatProperty)
    bool bEnableAngularAccelerationClamping() const { return Read<bool>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x1, Type: BoolProperty)
    float MaxAngularAcceleration() const { return Read<float>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: FloatProperty)
    float FictitiousAngularScale() const { return Read<float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x4, Type: FloatProperty)
    bool bUseTetrahedralConstraints() const { return Read<bool>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: BoolProperty)
    bool bUseThinShellVolumeConstraints() const { return Read<bool>(uintptr_t(this) + 0x179); } // 0x179 (Size: 0x1, Type: BoolProperty)
    bool bUseContinuousCollisionDetection() const { return Read<bool>(uintptr_t(this) + 0x17a); } // 0x17a (Size: 0x1, Type: BoolProperty)

    void SET_MassMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_UniformMass(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_TotalMass(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_Density(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_MinPerParticleMass(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_EdgeStiffnessWeighted(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x8, Type: StructProperty)
    void SET_BendingStiffnessWeighted(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x8, Type: StructProperty)
    void SET_bUseBendingElements(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_BucklingRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_BucklingStiffnessWeighted(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x8, Type: StructProperty)
    void SET_FlatnessRatio(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x8, Type: StructProperty)
    void SET_AreaStiffnessWeighted(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x8, Type: StructProperty)
    void SET_VolumeStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_TetherStiffness(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: StructProperty)
    void SET_TetherScale(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
    void SET_bUseGeodesicDistance(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
    void SET_ShapeTargetStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_FrictionCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_bUseCCD(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSelfCollisions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
    void SET_SelfCollisionThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_SelfCollisionFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_bUseSelfIntersections(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x1, Type: BoolProperty)
    void SET_bUseSelfCollisionSpheres(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d, Value); } // 0x9d (Size: 0x1, Type: BoolProperty)
    void SET_SelfCollisionSphereRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_SelfCollisionSphereStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_SelfCollisionSphereRadiusCullMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_bUseLegacyBackstop(const bool& Value) { Write<bool>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x1, Type: BoolProperty)
    void SET_DampingCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_LocalDampingCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_bUsePointBasedWindModel(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_Drag(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x8, Type: StructProperty)
    void SET_bEnableOuterDrag(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x1, Type: BoolProperty)
    void SET_OuterDrag(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: StructProperty)
    void SET_Lift(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: StructProperty)
    void SET_bEnableOuterLift(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    void SET_OuterLift(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x8, Type: StructProperty)
    void SET_bUseGravityOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x1, Type: BoolProperty)
    void SET_GravityScale(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_Gravity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_Pressure(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: StructProperty)
    void SET_AnimDriveStiffness(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: StructProperty)
    void SET_AnimDriveDamping(const FChaosClothWeightedValue& Value) { Write<FChaosClothWeightedValue>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: StructProperty)
    void SET_VelocityScaleSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: EnumProperty)
    void SET_LinearVelocityScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x18, Type: StructProperty)
    void SET_bEnableLinearVelocityClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: BoolProperty)
    void SET_MaxLinearVelocity(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0xc, Type: StructProperty)
    void SET_bEnableLinearAccelerationClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: BoolProperty)
    void SET_MaxLinearAcceleration(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0xc, Type: StructProperty)
    void SET_AngularVelocityScale(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableAngularVelocityClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x1, Type: BoolProperty)
    void SET_MaxAngularVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableAngularAccelerationClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x1, Type: BoolProperty)
    void SET_MaxAngularAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: FloatProperty)
    void SET_FictitiousAngularScale(const float& Value) { Write<float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x4, Type: FloatProperty)
    void SET_bUseTetrahedralConstraints(const bool& Value) { Write<bool>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: BoolProperty)
    void SET_bUseThinShellVolumeConstraints(const bool& Value) { Write<bool>(uintptr_t(this) + 0x179, Value); } // 0x179 (Size: 0x1, Type: BoolProperty)
    void SET_bUseContinuousCollisionDetection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x17a, Value); } // 0x17a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UChaosClothSharedSimConfig : public UClothSharedConfigCommon
{
public:
    int32_t IterationCount() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MaxIterationCount() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t SubdivisionCount() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    bool bUseLocalSpaceSimulation() const { return Read<bool>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: BoolProperty)
    bool bUseXPBDConstraints() const { return Read<bool>(uintptr_t(this) + 0x35); } // 0x35 (Size: 0x1, Type: BoolProperty)

    void SET_IterationCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_MaxIterationCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_SubdivisionCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_bUseLocalSpaceSimulation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: BoolProperty)
    void SET_bUseXPBDConstraints(const bool& Value) { Write<bool>(uintptr_t(this) + 0x35, Value); } // 0x35 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UChaosClothingSimulationFactory : public UClothingSimulationFactory
{
public:
};

// Size: 0x50
class UChaosClothingInteractor : public UClothingInteractor
{
public:
};

// Size: 0xb0
class UChaosClothingSimulationInteractor : public UClothingSimulationInteractor
{
public:
};

// Size: 0x8
struct FChaosClothWeightedValue
{
public:
    float Low() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float High() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Low(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_High(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

