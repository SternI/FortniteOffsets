/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DirtbikeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "EnhancedInput.h"

// Size: 0x26d0
class AFortDirtbikeVehicle : public AFortMotorcycleVehicle
{
public:
    UInputAction* InputActionJump() const { return Read<UInputAction*>(uintptr_t(this) + 0x26c8); } // 0x26c8 (Size: 0x8, Type: ObjectProperty)

    void SET_InputActionJump(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x26c8, Value); } // 0x26c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xee8
class UFortDirtbikeVehicleConfigs : public UFortMotorcycleVehicleConfigs
{
public:
};

