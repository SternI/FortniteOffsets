/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeastGirlRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x6410
class ABeastGirlStandInPawn : public AFortStandInPlayerPawn
{
public:
    FName HolsterId() const { return Read<FName>(uintptr_t(this) + 0x6210); } // 0x6210 (Size: 0x4, Type: NameProperty)
    TArray<FGameplayTag> InventoryItemsToRemove() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x6218); } // 0x6218 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ItemsToKeepDuringReplacementTagContainer() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6228); } // 0x6228 (Size: 0x20, Type: StructProperty)
    UFortWorldItemDefinition* DefaultWeaponDefinition() const { return Read<UFortWorldItemDefinition*>(uintptr_t(this) + 0x6248); } // 0x6248 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat HF_OutOfHealthImmediateHeal() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6250); } // 0x6250 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_OutOfHealthImmediateShield() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6278); } // 0x6278 (Size: 0x28, Type: StructProperty)
    FBeastGirlTransformationData ReplicatedTransformationData() const { return Read<FBeastGirlTransformationData>(uintptr_t(this) + 0x62a0); } // 0x62a0 (Size: 0x1, Type: StructProperty)
    TArray<UCustomCharacterPart*> CharacterParts() const { return Read<TArray<UCustomCharacterPart*>>(uintptr_t(this) + 0x62a8); } // 0x62a8 (Size: 0x10, Type: ArrayProperty)
    FBeastGirlTransformationAnimations OptOutTransformationAnimations() const { return Read<FBeastGirlTransformationAnimations>(uintptr_t(this) + 0x62b8); } // 0x62b8 (Size: 0x10, Type: StructProperty)
    FBeastGirlTransformationAnimations WeakenedTransformationAnimations() const { return Read<FBeastGirlTransformationAnimations>(uintptr_t(this) + 0x62c8); } // 0x62c8 (Size: 0x10, Type: StructProperty)
    FGameplayTag SpriteTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x62d8); } // 0x62d8 (Size: 0x4, Type: StructProperty)
    bool bHadSpriteEquipped() const { return Read<bool>(uintptr_t(this) + 0x62dc); } // 0x62dc (Size: 0x1, Type: BoolProperty)
    float CachedPreviousHealth() const { return Read<float>(uintptr_t(this) + 0x62fc); } // 0x62fc (Size: 0x4, Type: FloatProperty)
    FGameplayTag PrimaryWeaponActiveTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6300); } // 0x6300 (Size: 0x4, Type: StructProperty)
    FGameplayTag SecondaryWeaponActiveTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6304); } // 0x6304 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintActiveTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6308); } // 0x6308 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<UPrimitiveComponent*> AttachedBaseForTransformation() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x630c); } // 0x630c (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortWorldItem*> DefaultWeaponInstance() const { return Read<TWeakObjectPtr<UFortWorldItem*>>(uintptr_t(this) + 0x6314); } // 0x6314 (Size: 0x8, Type: WeakObjectProperty)
    bool bIsTransformingInto() const { return (Read<uint8_t>(uintptr_t(this) + 0x631c) >> 0x2) & 1; } // 0x631c:2 (Size: 0x1, Type: BoolProperty)
    UFortAbilitySet* PawnAbilitySet() const { return Read<UFortAbilitySet*>(uintptr_t(this) + 0x6320); } // 0x6320 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag BeastGirlActiveDurationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6328); } // 0x6328 (Size: 0x4, Type: StructProperty)
    UAthenaCharacterItemDefinition* BeastGirlTempCharacter() const { return Read<UAthenaCharacterItemDefinition*>(uintptr_t(this) + 0x6330); } // 0x6330 (Size: 0x8, Type: ObjectProperty)
    UAthenaCharacterItemDefinition* CachedCharacter() const { return Read<UAthenaCharacterItemDefinition*>(uintptr_t(this) + 0x6338); } // 0x6338 (Size: 0x8, Type: ObjectProperty)
    FFortAbilitySetHandle AbilitySetHandle() const { return Read<FFortAbilitySetHandle>(uintptr_t(this) + 0x6340); } // 0x6340 (Size: 0x38, Type: StructProperty)

    void SET_HolsterId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6210, Value); } // 0x6210 (Size: 0x4, Type: NameProperty)
    void SET_InventoryItemsToRemove(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x6218, Value); } // 0x6218 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemsToKeepDuringReplacementTagContainer(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6228, Value); } // 0x6228 (Size: 0x20, Type: StructProperty)
    void SET_DefaultWeaponDefinition(const UFortWorldItemDefinition*& Value) { Write<UFortWorldItemDefinition*>(uintptr_t(this) + 0x6248, Value); } // 0x6248 (Size: 0x8, Type: ObjectProperty)
    void SET_HF_OutOfHealthImmediateHeal(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6250, Value); } // 0x6250 (Size: 0x28, Type: StructProperty)
    void SET_HF_OutOfHealthImmediateShield(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6278, Value); } // 0x6278 (Size: 0x28, Type: StructProperty)
    void SET_ReplicatedTransformationData(const FBeastGirlTransformationData& Value) { Write<FBeastGirlTransformationData>(uintptr_t(this) + 0x62a0, Value); } // 0x62a0 (Size: 0x1, Type: StructProperty)
    void SET_CharacterParts(const TArray<UCustomCharacterPart*>& Value) { Write<TArray<UCustomCharacterPart*>>(uintptr_t(this) + 0x62a8, Value); } // 0x62a8 (Size: 0x10, Type: ArrayProperty)
    void SET_OptOutTransformationAnimations(const FBeastGirlTransformationAnimations& Value) { Write<FBeastGirlTransformationAnimations>(uintptr_t(this) + 0x62b8, Value); } // 0x62b8 (Size: 0x10, Type: StructProperty)
    void SET_WeakenedTransformationAnimations(const FBeastGirlTransformationAnimations& Value) { Write<FBeastGirlTransformationAnimations>(uintptr_t(this) + 0x62c8, Value); } // 0x62c8 (Size: 0x10, Type: StructProperty)
    void SET_SpriteTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x62d8, Value); } // 0x62d8 (Size: 0x4, Type: StructProperty)
    void SET_bHadSpriteEquipped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x62dc, Value); } // 0x62dc (Size: 0x1, Type: BoolProperty)
    void SET_CachedPreviousHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x62fc, Value); } // 0x62fc (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryWeaponActiveTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6300, Value); } // 0x6300 (Size: 0x4, Type: StructProperty)
    void SET_SecondaryWeaponActiveTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6304, Value); } // 0x6304 (Size: 0x4, Type: StructProperty)
    void SET_SprintActiveTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6308, Value); } // 0x6308 (Size: 0x4, Type: StructProperty)
    void SET_AttachedBaseForTransformation(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x630c, Value); } // 0x630c (Size: 0x8, Type: WeakObjectProperty)
    void SET_DefaultWeaponInstance(const TWeakObjectPtr<UFortWorldItem*>& Value) { Write<TWeakObjectPtr<UFortWorldItem*>>(uintptr_t(this) + 0x6314, Value); } // 0x6314 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bIsTransformingInto(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x631c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x631c, B); } // 0x631c:2 (Size: 0x1, Type: BoolProperty)
    void SET_PawnAbilitySet(const UFortAbilitySet*& Value) { Write<UFortAbilitySet*>(uintptr_t(this) + 0x6320, Value); } // 0x6320 (Size: 0x8, Type: ObjectProperty)
    void SET_BeastGirlActiveDurationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6328, Value); } // 0x6328 (Size: 0x4, Type: StructProperty)
    void SET_BeastGirlTempCharacter(const UAthenaCharacterItemDefinition*& Value) { Write<UAthenaCharacterItemDefinition*>(uintptr_t(this) + 0x6330, Value); } // 0x6330 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedCharacter(const UAthenaCharacterItemDefinition*& Value) { Write<UAthenaCharacterItemDefinition*>(uintptr_t(this) + 0x6338, Value); } // 0x6338 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilitySetHandle(const FFortAbilitySetHandle& Value) { Write<FFortAbilitySetHandle>(uintptr_t(this) + 0x6340, Value); } // 0x6340 (Size: 0x38, Type: StructProperty)
};

// Size: 0x1d0
class UBeastGirlTransformationManager : public UActorComponent
{
public:
    FScalableFloat HF_RevertTransformFinishHealthToAdd() const { return Read<FScalableFloat>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_RevertTransformFinishShieldToAdd() const { return Read<FScalableFloat>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_MinimumBeastHealth() const { return Read<FScalableFloat>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x28, Type: StructProperty)
    UClass* ReverseTransformationAbility() const { return Read<UClass*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ClassProperty)
    UClass* OptOutTransformationAbility() const { return Read<UClass*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ClassProperty)
    ABeastGirlStandInPawn* SpawnedBeastGirlPawn() const { return Read<ABeastGirlStandInPawn*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UFortWorldItemDefinition* ConsumableItemDefinition() const { return Read<UFortWorldItemDefinition*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    bool bOptingOut() const { return (Read<uint8_t>(uintptr_t(this) + 0x1c8) >> 0x0) & 1; } // 0x1c8:0 (Size: 0x1, Type: BoolProperty)

    void SET_HF_RevertTransformFinishHealthToAdd(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x28, Type: StructProperty)
    void SET_HF_RevertTransformFinishShieldToAdd(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x28, Type: StructProperty)
    void SET_HF_MinimumBeastHealth(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x28, Type: StructProperty)
    void SET_ReverseTransformationAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ClassProperty)
    void SET_OptOutTransformationAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ClassProperty)
    void SET_SpawnedBeastGirlPawn(const ABeastGirlStandInPawn*& Value) { Write<ABeastGirlStandInPawn*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_ConsumableItemDefinition(const UFortWorldItemDefinition*& Value) { Write<UFortWorldItemDefinition*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    void SET_bOptingOut(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1c8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1c8, B); } // 0x1c8:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x13b0
class UBeastLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    FRotator DivePitchAdjustmentRotator() const { return Read<FRotator>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x18, Type: StructProperty)
    double IdleCorrectiveAlpha() const { return Read<double>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x8, Type: DoubleProperty)
    double HipOffsetVertical() const { return Read<double>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x8, Type: DoubleProperty)
    bool bDiveAbilityLanded() const { return Read<bool>(uintptr_t(this) + 0x1330); } // 0x1330 (Size: 0x1, Type: BoolProperty)
    bool bDiveAbilityActive() const { return Read<bool>(uintptr_t(this) + 0x1331); } // 0x1331 (Size: 0x1, Type: BoolProperty)
    bool bPlayJumpStart() const { return Read<bool>(uintptr_t(this) + 0x1332); } // 0x1332 (Size: 0x1, Type: BoolProperty)
    bool bAllowLandingAdditive() const { return Read<bool>(uintptr_t(this) + 0x1333); } // 0x1333 (Size: 0x1, Type: BoolProperty)
    bool bBlendLowerBodyCorrective() const { return Read<bool>(uintptr_t(this) + 0x1334); } // 0x1334 (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Loop() const { return Read<bool>(uintptr_t(this) + 0x1335); } // 0x1335 (Size: 0x1, Type: BoolProperty)
    bool bLandingAdditiveAllowLowerBody() const { return Read<bool>(uintptr_t(this) + 0x1336); } // 0x1336 (Size: 0x1, Type: BoolProperty)
    bool bTransformAllowLowerBody() const { return Read<bool>(uintptr_t(this) + 0x1337); } // 0x1337 (Size: 0x1, Type: BoolProperty)
    bool bSnapLowerBodyCorrective() const { return Read<bool>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Land() const { return Read<bool>(uintptr_t(this) + 0x1339); } // 0x1339 (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Transition() const { return Read<bool>(uintptr_t(this) + 0x133a); } // 0x133a (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Inactive() const { return Read<bool>(uintptr_t(this) + 0x133b); } // 0x133b (Size: 0x1, Type: BoolProperty)
    bool bEnterTransformState() const { return Read<bool>(uintptr_t(this) + 0x133c); } // 0x133c (Size: 0x1, Type: BoolProperty)
    bool bDiveState_EnterChargeState() const { return Read<bool>(uintptr_t(this) + 0x133d); } // 0x133d (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Roar_AllowLowerBody() const { return Read<bool>(uintptr_t(this) + 0x133e); } // 0x133e (Size: 0x1, Type: BoolProperty)
    bool bLowerBodyCorrective_BlendOff() const { return Read<bool>(uintptr_t(this) + 0x133f); } // 0x133f (Size: 0x1, Type: BoolProperty)
    bool bAllowAdditiveIdleLoop() const { return Read<bool>(uintptr_t(this) + 0x1340); } // 0x1340 (Size: 0x1, Type: BoolProperty)
    bool bAllowLowerbodyLandingOverride() const { return Read<bool>(uintptr_t(this) + 0x1341); } // 0x1341 (Size: 0x1, Type: BoolProperty)
    bool bTransformExitActive() const { return Read<bool>(uintptr_t(this) + 0x1342); } // 0x1342 (Size: 0x1, Type: BoolProperty)
    bool bTransformExitManual() const { return Read<bool>(uintptr_t(this) + 0x1343); } // 0x1343 (Size: 0x1, Type: BoolProperty)
    FGameplayTag DiveActiveTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1344); } // 0x1344 (Size: 0x4, Type: StructProperty)
    FGameplayTag FromAirTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1348); } // 0x1348 (Size: 0x4, Type: StructProperty)
    FGameplayTag FromGroundTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x134c); } // 0x134c (Size: 0x4, Type: StructProperty)
    UAnimSequence* BeastGirlTransformBackFastStartCLMAnimSequence() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x1350); } // 0x1350 (Size: 0x8, Type: ObjectProperty)
    UAnimSequence* BeastGirltransformBackStartCLMAnimSequence() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x1358); } // 0x1358 (Size: 0x8, Type: ObjectProperty)
    UAnimSequence* BeastGirltransformBackInWaterStartCLMAnimSequence() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x1360); } // 0x1360 (Size: 0x8, Type: ObjectProperty)
    UAnimSequence* CheerTransformPart2CMLAnimSequence() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x1368); } // 0x1368 (Size: 0x8, Type: ObjectProperty)
    UAnimSequence* CheerTransformPart2InWaterCMLAnimSequence() const { return Read<UAnimSequence*>(uintptr_t(this) + 0x1370); } // 0x1370 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayingMantis() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x0) & 1; } // 0x1378:0 (Size: 0x1, Type: BoolProperty)
    bool bWasPlayingMantis() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x1) & 1; } // 0x1378:1 (Size: 0x1, Type: BoolProperty)
    bool bIsPlayingMantisInAir() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x2) & 1; } // 0x1378:2 (Size: 0x1, Type: BoolProperty)
    bool bWasFalling() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x3) & 1; } // 0x1378:3 (Size: 0x1, Type: BoolProperty)
    bool bWantsToTurn() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x4) & 1; } // 0x1378:4 (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Launch() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x5) & 1; } // 0x1378:5 (Size: 0x1, Type: BoolProperty)
    bool bDiveState_Charge() const { return (Read<uint8_t>(uintptr_t(this) + 0x1378) >> 0x6) & 1; } // 0x1378:6 (Size: 0x1, Type: BoolProperty)
    bool bShouldCloseGate() const { return Read<bool>(uintptr_t(this) + 0x1379); } // 0x1379 (Size: 0x1, Type: BoolProperty)
    bool bPlayingEndTransformAnimation() const { return Read<bool>(uintptr_t(this) + 0x137a); } // 0x137a (Size: 0x1, Type: BoolProperty)
    float DivePitchAdjustment() const { return Read<float>(uintptr_t(this) + 0x137c); } // 0x137c (Size: 0x4, Type: FloatProperty)

    void SET_DivePitchAdjustmentRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x18, Type: StructProperty)
    void SET_IdleCorrectiveAlpha(const double& Value) { Write<double>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x8, Type: DoubleProperty)
    void SET_HipOffsetVertical(const double& Value) { Write<double>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x8, Type: DoubleProperty)
    void SET_bDiveAbilityLanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1330, Value); } // 0x1330 (Size: 0x1, Type: BoolProperty)
    void SET_bDiveAbilityActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1331, Value); } // 0x1331 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayJumpStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1332, Value); } // 0x1332 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowLandingAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1333, Value); } // 0x1333 (Size: 0x1, Type: BoolProperty)
    void SET_bBlendLowerBodyCorrective(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1334, Value); } // 0x1334 (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Loop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1335, Value); } // 0x1335 (Size: 0x1, Type: BoolProperty)
    void SET_bLandingAdditiveAllowLowerBody(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1336, Value); } // 0x1336 (Size: 0x1, Type: BoolProperty)
    void SET_bTransformAllowLowerBody(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1337, Value); } // 0x1337 (Size: 0x1, Type: BoolProperty)
    void SET_bSnapLowerBodyCorrective(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Land(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1339, Value); } // 0x1339 (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Transition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x133a, Value); } // 0x133a (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Inactive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x133b, Value); } // 0x133b (Size: 0x1, Type: BoolProperty)
    void SET_bEnterTransformState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x133c, Value); } // 0x133c (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_EnterChargeState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x133d, Value); } // 0x133d (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Roar_AllowLowerBody(const bool& Value) { Write<bool>(uintptr_t(this) + 0x133e, Value); } // 0x133e (Size: 0x1, Type: BoolProperty)
    void SET_bLowerBodyCorrective_BlendOff(const bool& Value) { Write<bool>(uintptr_t(this) + 0x133f, Value); } // 0x133f (Size: 0x1, Type: BoolProperty)
    void SET_bAllowAdditiveIdleLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1340, Value); } // 0x1340 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowLowerbodyLandingOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1341, Value); } // 0x1341 (Size: 0x1, Type: BoolProperty)
    void SET_bTransformExitActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1342, Value); } // 0x1342 (Size: 0x1, Type: BoolProperty)
    void SET_bTransformExitManual(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1343, Value); } // 0x1343 (Size: 0x1, Type: BoolProperty)
    void SET_DiveActiveTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1344, Value); } // 0x1344 (Size: 0x4, Type: StructProperty)
    void SET_FromAirTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1348, Value); } // 0x1348 (Size: 0x4, Type: StructProperty)
    void SET_FromGroundTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x134c, Value); } // 0x134c (Size: 0x4, Type: StructProperty)
    void SET_BeastGirlTransformBackFastStartCLMAnimSequence(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x1350, Value); } // 0x1350 (Size: 0x8, Type: ObjectProperty)
    void SET_BeastGirltransformBackStartCLMAnimSequence(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x1358, Value); } // 0x1358 (Size: 0x8, Type: ObjectProperty)
    void SET_BeastGirltransformBackInWaterStartCLMAnimSequence(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x1360, Value); } // 0x1360 (Size: 0x8, Type: ObjectProperty)
    void SET_CheerTransformPart2CMLAnimSequence(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x1368, Value); } // 0x1368 (Size: 0x8, Type: ObjectProperty)
    void SET_CheerTransformPart2InWaterCMLAnimSequence(const UAnimSequence*& Value) { Write<UAnimSequence*>(uintptr_t(this) + 0x1370, Value); } // 0x1370 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsPlayingMantis(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:0 (Size: 0x1, Type: BoolProperty)
    void SET_bWasPlayingMantis(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPlayingMantisInAir(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:2 (Size: 0x1, Type: BoolProperty)
    void SET_bWasFalling(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:3 (Size: 0x1, Type: BoolProperty)
    void SET_bWantsToTurn(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:4 (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Launch(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:5 (Size: 0x1, Type: BoolProperty)
    void SET_bDiveState_Charge(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1378); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x1378, B); } // 0x1378:6 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldCloseGate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1379, Value); } // 0x1379 (Size: 0x1, Type: BoolProperty)
    void SET_bPlayingEndTransformAnimation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x137a, Value); } // 0x137a (Size: 0x1, Type: BoolProperty)
    void SET_DivePitchAdjustment(const float& Value) { Write<float>(uintptr_t(this) + 0x137c, Value); } // 0x137c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UBeastPlayerAnimationInterface : public UInterface
{
public:
};

// Size: 0x4b8
class UFortMovementMode_BeastGirlGuided : public UFortMovementMode_ExtGuidedMotion
{
public:
};

// Size: 0x1
struct FBeastGirlTransformationData
{
public:
    bool bTransforming() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bIsOptOut() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    bool bIsInWater() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x2) & 1; } // 0x0:2 (Size: 0x1, Type: BoolProperty)

    void SET_bTransforming(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsOptOut(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInWater(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FBeastGirlTransformationAnimations
{
public:
    UAnimationAsset* OnGround() const { return Read<UAnimationAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAnimationAsset* InWater() const { return Read<UAnimationAsset*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_OnGround(const UAnimationAsset*& Value) { Write<UAnimationAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_InWater(const UAnimationAsset*& Value) { Write<UAnimationAsset*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
struct FCachedDamageData
{
public:
};

