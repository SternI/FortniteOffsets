/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_LinkCodeMutatorRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xc20
class ALinkCodeMutatorDevice : public AFortCreativeDeviceProp
{
public:
    TArray<FString> MutatorsToApply() const { return Read<TArray<FString>>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x10, Type: ArrayProperty)

    void SET_MutatorsToApply(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x10, Type: ArrayProperty)
};

