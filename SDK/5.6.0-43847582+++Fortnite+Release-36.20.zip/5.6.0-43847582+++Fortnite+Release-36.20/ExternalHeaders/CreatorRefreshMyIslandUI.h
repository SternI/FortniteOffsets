/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorRefreshMyIslandUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x478
class UFortCreativeMyIslandSideNavWidget : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle SearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ClearSearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x10, Type: StructProperty)

    void SET_SearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: StructProperty)
    void SET_ClearSearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x10, Type: StructProperty)
};

