/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTileDetailsDisplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "WBP_Discovery_WarningIcon.h"
#include "WBP_ActivityBrowserSocialProof.h"
#include "Engine.h"
#include "UI.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "WBP_LockedStatus.h"

// Size: 0x1978
class UActivityBrowserTileDetailsDisplay_C : public UFortActivityTileDetailsDisplay
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x17b0); } // 0x17b0 (Size: 0x8, Type: StructProperty)
    UWBP_LockedStatus_C* WBP_LockedStatus() const { return Read<UWBP_LockedStatus_C*>(uintptr_t(this) + 0x17b8); } // 0x17b8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Discovery_WarningIcon_C* WBP_Discovery_WarningIcon() const { return Read<UWBP_Discovery_WarningIcon_C*>(uintptr_t(this) + 0x17c0); } // 0x17c0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Discovery_Favorite_C* WBP_Discovery_Favorite() const { return Read<UWBP_Discovery_Favorite_C*>(uintptr_t(this) + 0x17c8); } // 0x17c8 (Size: 0x8, Type: ObjectProperty)
    UImage* TileThumbnail() const { return Read<UImage*>(uintptr_t(this) + 0x17d0); } // 0x17d0 (Size: 0x8, Type: ObjectProperty)
    UImage* TileStroke() const { return Read<UImage*>(uintptr_t(this) + 0x17d8); } // 0x17d8 (Size: 0x8, Type: ObjectProperty)
    USqueegeeInjectionSlot_C* SqueegeeSlot_Lock() const { return Read<USqueegeeInjectionSlot_C*>(uintptr_t(this) + 0x17e0); } // 0x17e0 (Size: 0x8, Type: ObjectProperty)
    USpacer* Spacer_Mobile() const { return Read<USpacer*>(uintptr_t(this) + 0x17e8); } // 0x17e8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Primary() const { return Read<USizeBox*>(uintptr_t(this) + 0x17f0); } // 0x17f0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OvrDisabledWarningMessage() const { return Read<UOverlay*>(uintptr_t(this) + 0x17f8); } // 0x17f8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Ovr_Primary() const { return Read<UOverlay*>(uintptr_t(this) + 0x1800); } // 0x1800 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_PurchaseRequired() const { return Read<UOverlay*>(uintptr_t(this) + 0x1808); } // 0x1808 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_InteractButtons() const { return Read<UOverlay*>(uintptr_t(this) + 0x1810); } // 0x1810 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Favorite() const { return Read<UOverlay*>(uintptr_t(this) + 0x1818); } // 0x1818 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OriginalContentEpicBanner() const { return Read<UOverlay*>(uintptr_t(this) + 0x1820); } // 0x1820 (Size: 0x8, Type: ObjectProperty)
    UImage* Logo_NotReady_Fort554488() const { return Read<UImage*>(uintptr_t(this) + 0x1828); } // 0x1828 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_MultiMode() const { return Read<UImage*>(uintptr_t(this) + 0x1830); } // 0x1830 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_PlayerCount() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1838); } // 0x1838 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_LocksAndHearts() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1840); } // 0x1840 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_ActivityInfo() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1848); } // 0x1848 (Size: 0x8, Type: ObjectProperty)
    UImage* EpicBannerBg() const { return Read<UImage*>(uintptr_t(this) + 0x1850); } // 0x1850 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* DisabledWarningMessage() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1858); } // 0x1858 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* BannerText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1860); } // 0x1860 (Size: 0x8, Type: ObjectProperty)
    UWBP_ActivityBrowserSocialProof_C* ActivityBrowserSocialProof() const { return Read<UWBP_ActivityBrowserSocialProof_C*>(uintptr_t(this) + 0x1868); } // 0x1868 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnHoverSelect() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1870); } // 0x1870 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnHoverSelect_GrowNonHeroRowTiles() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1878); } // 0x1878 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnIntro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1880); } // 0x1880 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_HoverPulse() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1888); } // 0x1888 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnImageLoaded() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1890); } // 0x1890 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnHoverUnhoverRehover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1898); } // 0x1898 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnDisabledClick() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x18a0); } // 0x18a0 (Size: 0x8, Type: ObjectProperty)
    bool IsKeyArtValid() const { return Read<bool>(uintptr_t(this) + 0x18a8); } // 0x18a8 (Size: 0x1, Type: BoolProperty)
    UTexture* DefaultImage() const { return Read<UTexture*>(uintptr_t(this) + 0x18b0); } // 0x18b0 (Size: 0x8, Type: ObjectProperty)
    bool IsTileActive() const { return Read<bool>(uintptr_t(this) + 0x18b8); } // 0x18b8 (Size: 0x1, Type: BoolProperty)
    FTimerHandle DisabledClickTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x18c0); } // 0x18c0 (Size: 0x8, Type: StructProperty)
    double DisabledClickDuration() const { return Read<double>(uintptr_t(this) + 0x18c8); } // 0x18c8 (Size: 0x8, Type: DoubleProperty)
    bool IsActivityValid() const { return Read<bool>(uintptr_t(this) + 0x18d0); } // 0x18d0 (Size: 0x1, Type: BoolProperty)
    FVector2D TileSize() const { return Read<FVector2D>(uintptr_t(this) + 0x18d8); } // 0x18d8 (Size: 0x10, Type: StructProperty)
    FName TextureParam() const { return Read<FName>(uintptr_t(this) + 0x18e8); } // 0x18e8 (Size: 0x4, Type: NameProperty)
    FName ThumbnailAlpha() const { return Read<FName>(uintptr_t(this) + 0x18ec); } // 0x18ec (Size: 0x4, Type: NameProperty)
    FName ThumbnailScale() const { return Read<FName>(uintptr_t(this) + 0x18f0); } // 0x18f0 (Size: 0x4, Type: NameProperty)
    FName ThumbnailDisabledOverlay() const { return Read<FName>(uintptr_t(this) + 0x18f4); } // 0x18f4 (Size: 0x4, Type: NameProperty)
    FName FrameColor() const { return Read<FName>(uintptr_t(this) + 0x18f8); } // 0x18f8 (Size: 0x4, Type: NameProperty)
    FLinearColor BaseColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18fc); } // 0x18fc (Size: 0x10, Type: StructProperty)
    FLinearColor EpicColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x190c); } // 0x190c (Size: 0x10, Type: StructProperty)
    FLinearColor StrokeColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x191c); } // 0x191c (Size: 0x10, Type: StructProperty)
    FLinearColor DisabledColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x192c); } // 0x192c (Size: 0x10, Type: StructProperty)
    double BannerColorAnimator() const { return Read<double>(uintptr_t(this) + 0x1940); } // 0x1940 (Size: 0x8, Type: DoubleProperty)
    double VerticalTilePaddingOffset() const { return Read<double>(uintptr_t(this) + 0x1948); } // 0x1948 (Size: 0x8, Type: DoubleProperty)
    bool HideDetails() const { return Read<bool>(uintptr_t(this) + 0x1950); } // 0x1950 (Size: 0x1, Type: BoolProperty)
    bool IsPurchaseRequired() const { return Read<bool>(uintptr_t(this) + 0x1951); } // 0x1951 (Size: 0x1, Type: BoolProperty)
    bool bAllowThumbnailHoverRehoverAnim() const { return Read<bool>(uintptr_t(this) + 0x1952); } // 0x1952 (Size: 0x1, Type: BoolProperty)
    double GridSingleColumnWidth() const { return Read<double>(uintptr_t(this) + 0x1958); } // 0x1958 (Size: 0x8, Type: DoubleProperty)
    double GridSingleGutterWidth() const { return Read<double>(uintptr_t(this) + 0x1960); } // 0x1960 (Size: 0x8, Type: DoubleProperty)
    double Ratio16x9ConvertWidthToHeight() const { return Read<double>(uintptr_t(this) + 0x1968); } // 0x1968 (Size: 0x8, Type: DoubleProperty)
    bool IsPromotedHeroRow() const { return Read<bool>(uintptr_t(this) + 0x1970); } // 0x1970 (Size: 0x1, Type: BoolProperty)
    int32_t DefaultGameModeTextSize() const { return Read<int32_t>(uintptr_t(this) + 0x1974); } // 0x1974 (Size: 0x4, Type: IntProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x17b0, Value); } // 0x17b0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_LockedStatus(const UWBP_LockedStatus_C*& Value) { Write<UWBP_LockedStatus_C*>(uintptr_t(this) + 0x17b8, Value); } // 0x17b8 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_Discovery_WarningIcon(const UWBP_Discovery_WarningIcon_C*& Value) { Write<UWBP_Discovery_WarningIcon_C*>(uintptr_t(this) + 0x17c0, Value); } // 0x17c0 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_Discovery_Favorite(const UWBP_Discovery_Favorite_C*& Value) { Write<UWBP_Discovery_Favorite_C*>(uintptr_t(this) + 0x17c8, Value); } // 0x17c8 (Size: 0x8, Type: ObjectProperty)
    void SET_TileThumbnail(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x17d0, Value); } // 0x17d0 (Size: 0x8, Type: ObjectProperty)
    void SET_TileStroke(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x17d8, Value); } // 0x17d8 (Size: 0x8, Type: ObjectProperty)
    void SET_SqueegeeSlot_Lock(const USqueegeeInjectionSlot_C*& Value) { Write<USqueegeeInjectionSlot_C*>(uintptr_t(this) + 0x17e0, Value); } // 0x17e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Spacer_Mobile(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x17e8, Value); } // 0x17e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_Primary(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x17f0, Value); } // 0x17f0 (Size: 0x8, Type: ObjectProperty)
    void SET_OvrDisabledWarningMessage(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x17f8, Value); } // 0x17f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Ovr_Primary(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x1800, Value); } // 0x1800 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_PurchaseRequired(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x1808, Value); } // 0x1808 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_InteractButtons(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x1810, Value); } // 0x1810 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Favorite(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x1818, Value); } // 0x1818 (Size: 0x8, Type: ObjectProperty)
    void SET_OriginalContentEpicBanner(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x1820, Value); } // 0x1820 (Size: 0x8, Type: ObjectProperty)
    void SET_Logo_NotReady_Fort554488(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1828, Value); } // 0x1828 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_MultiMode(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1830, Value); } // 0x1830 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_PlayerCount(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1838, Value); } // 0x1838 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_LocksAndHearts(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1840, Value); } // 0x1840 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_ActivityInfo(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1848, Value); } // 0x1848 (Size: 0x8, Type: ObjectProperty)
    void SET_EpicBannerBg(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1850, Value); } // 0x1850 (Size: 0x8, Type: ObjectProperty)
    void SET_DisabledWarningMessage(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1858, Value); } // 0x1858 (Size: 0x8, Type: ObjectProperty)
    void SET_BannerText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1860, Value); } // 0x1860 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityBrowserSocialProof(const UWBP_ActivityBrowserSocialProof_C*& Value) { Write<UWBP_ActivityBrowserSocialProof_C*>(uintptr_t(this) + 0x1868, Value); } // 0x1868 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnHoverSelect(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1870, Value); } // 0x1870 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnHoverSelect_GrowNonHeroRowTiles(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1878, Value); } // 0x1878 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnIntro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1880, Value); } // 0x1880 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_HoverPulse(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1888, Value); } // 0x1888 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnImageLoaded(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1890, Value); } // 0x1890 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnHoverUnhoverRehover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1898, Value); } // 0x1898 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OnDisabledClick(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x18a0, Value); } // 0x18a0 (Size: 0x8, Type: ObjectProperty)
    void SET_IsKeyArtValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18a8, Value); } // 0x18a8 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultImage(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x18b0, Value); } // 0x18b0 (Size: 0x8, Type: ObjectProperty)
    void SET_IsTileActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18b8, Value); } // 0x18b8 (Size: 0x1, Type: BoolProperty)
    void SET_DisabledClickTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x18c0, Value); } // 0x18c0 (Size: 0x8, Type: StructProperty)
    void SET_DisabledClickDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x18c8, Value); } // 0x18c8 (Size: 0x8, Type: DoubleProperty)
    void SET_IsActivityValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18d0, Value); } // 0x18d0 (Size: 0x1, Type: BoolProperty)
    void SET_TileSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18d8, Value); } // 0x18d8 (Size: 0x10, Type: StructProperty)
    void SET_TextureParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18e8, Value); } // 0x18e8 (Size: 0x4, Type: NameProperty)
    void SET_ThumbnailAlpha(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18ec, Value); } // 0x18ec (Size: 0x4, Type: NameProperty)
    void SET_ThumbnailScale(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18f0, Value); } // 0x18f0 (Size: 0x4, Type: NameProperty)
    void SET_ThumbnailDisabledOverlay(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18f4, Value); } // 0x18f4 (Size: 0x4, Type: NameProperty)
    void SET_FrameColor(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18f8, Value); } // 0x18f8 (Size: 0x4, Type: NameProperty)
    void SET_BaseColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18fc, Value); } // 0x18fc (Size: 0x10, Type: StructProperty)
    void SET_EpicColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x190c, Value); } // 0x190c (Size: 0x10, Type: StructProperty)
    void SET_StrokeColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x191c, Value); } // 0x191c (Size: 0x10, Type: StructProperty)
    void SET_DisabledColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x192c, Value); } // 0x192c (Size: 0x10, Type: StructProperty)
    void SET_BannerColorAnimator(const double& Value) { Write<double>(uintptr_t(this) + 0x1940, Value); } // 0x1940 (Size: 0x8, Type: DoubleProperty)
    void SET_VerticalTilePaddingOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x1948, Value); } // 0x1948 (Size: 0x8, Type: DoubleProperty)
    void SET_HideDetails(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1950, Value); } // 0x1950 (Size: 0x1, Type: BoolProperty)
    void SET_IsPurchaseRequired(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1951, Value); } // 0x1951 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowThumbnailHoverRehoverAnim(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1952, Value); } // 0x1952 (Size: 0x1, Type: BoolProperty)
    void SET_GridSingleColumnWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x1958, Value); } // 0x1958 (Size: 0x8, Type: DoubleProperty)
    void SET_GridSingleGutterWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x1960, Value); } // 0x1960 (Size: 0x8, Type: DoubleProperty)
    void SET_Ratio16x9ConvertWidthToHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x1968, Value); } // 0x1968 (Size: 0x8, Type: DoubleProperty)
    void SET_IsPromotedHeroRow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1970, Value); } // 0x1970 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultGameModeTextSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1974, Value); } // 0x1974 (Size: 0x4, Type: IntProperty)
};

