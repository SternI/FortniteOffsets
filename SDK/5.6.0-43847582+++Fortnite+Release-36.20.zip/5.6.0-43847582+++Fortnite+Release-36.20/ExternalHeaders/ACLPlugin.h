/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ACLPlugin
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x128
class UAnimationCompressionLibraryDatabase : public UObject
{
public:
    TArray<char> CookedCompressedBytes() const { return Read<TArray<char>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<uint64_t> CookedAnimSequenceMappings() const { return Read<TArray<uint64_t>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint32_t MaxStreamRequestSizeKB() const { return Read<uint32_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: UInt32Property)
    uint8_t DefaultVisualFidelity() const { return Read<uint8_t>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: EnumProperty)

    void SET_CookedCompressedBytes(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_CookedAnimSequenceMappings(const TArray<uint64_t>& Value) { Write<TArray<uint64_t>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxStreamRequestSizeKB(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: UInt32Property)
    void SET_DefaultVisualFidelity(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x38
class UAnimBoneCompressionCodec_ACL : public UAnimBoneCompressionCodec_ACLBase
{
public:
};

// Size: 0x38
class UAnimBoneCompressionCodec_ACLBase : public UAnimBoneCompressionCodec
{
public:
};

// Size: 0x38
class UAnimBoneCompressionCodec_ACLCustom : public UAnimBoneCompressionCodec_ACLBase
{
public:
};

// Size: 0x40
class UAnimBoneCompressionCodec_ACLDatabase : public UAnimBoneCompressionCodec_ACLBase
{
public:
    UAnimationCompressionLibraryDatabase* DatabaseAsset() const { return Read<UAnimationCompressionLibraryDatabase*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_DatabaseAsset(const UAnimationCompressionLibraryDatabase*& Value) { Write<UAnimationCompressionLibraryDatabase*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UAnimBoneCompressionCodec_ACLSafe : public UAnimBoneCompressionCodec_ACLBase
{
public:
};

// Size: 0x28
class UAnimCurveCompressionCodec_ACL : public UAnimCurveCompressionCodec
{
public:
};

