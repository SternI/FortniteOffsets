/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDataChannelTriggerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x28
class UCreativeDataChannelAnalytics : public UObject
{
public:
};

// Size: 0x370
class ACreativeDataChannelTarget : public AElectraDataChannelTarget
{
public:
    int8_t VersionByte() const { return Read<int8_t>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x1, Type: Int8Property)
    FCreativeDataChannelEvents EVENTS() const { return Read<FCreativeDataChannelEvents>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: StructProperty)
    FCreativeDataChannelEvents EventsCache() const { return Read<FCreativeDataChannelEvents>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: StructProperty)

    void SET_VersionByte(const int8_t& Value) { Write<int8_t>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x1, Type: Int8Property)
    void SET_EVENTS(const FCreativeDataChannelEvents& Value) { Write<FCreativeDataChannelEvents>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: StructProperty)
    void SET_EventsCache(const FCreativeDataChannelEvents& Value) { Write<FCreativeDataChannelEvents>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: StructProperty)
};

// Size: 0x5d8
class ACreativeDataChannelTargetFN : public AElectraDataChannelTarget
{
public:
    int32_t VersionByte() const { return Read<int32_t>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: IntProperty)
    FCDCInt VersionByteTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: StructProperty)
    FString LeaderBoard() const { return Read<FString>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x10, Type: StrProperty)
    int64_t StormCircleSize() const { return Read<int64_t>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: Int64Property)
    FCDCLargeInt StormCircleSizeTracker() const { return Read<FCDCLargeInt>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: StructProperty)
    TArray<float> StormCircleLocation() const { return Read<TArray<float>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x10, Type: ArrayProperty)
    FCDCFloatArray StormCircleLocationTracker() const { return Read<FCDCFloatArray>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: StructProperty)
    FString PlayerLocation() const { return Read<FString>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    FCDCStringFloatArrayMap PlayerLocationTracker() const { return Read<FCDCStringFloatArrayMap>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x50, Type: StructProperty)
    FString ArenaPointLeaderBoard() const { return Read<FString>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x10, Type: StrProperty)
    FCDCStringStringMap ArenaPointLeaderBoardTracker() const { return Read<FCDCStringStringMap>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0xa0, Type: StructProperty)
    FString CashCupDataAllTimeEarners() const { return Read<FString>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x10, Type: StrProperty)
    FCDCStringFloatMap CashCupDataAllTimeEanersTracker() const { return Read<FCDCStringFloatMap>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x50, Type: StructProperty)
    FString MythicBossEliminatedPlayer() const { return Read<FString>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x10, Type: StrProperty)
    FCDCString MythicBossEliminatedPlayerTracker() const { return Read<FCDCString>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x10, Type: StructProperty)
    FString MythicWeaponPlayer() const { return Read<FString>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x10, Type: StrProperty)
    FCDCString MythicWeaponPlayerTracker() const { return Read<FCDCString>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x10, Type: StructProperty)
    FString PlayerInfo() const { return Read<FString>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x10, Type: StrProperty)
    FCDCStringArray PlayerInfoTracker() const { return Read<FCDCStringArray>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x18, Type: StructProperty)

    void SET_VersionByte(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: IntProperty)
    void SET_VersionByteTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: StructProperty)
    void SET_LeaderBoard(const FString& Value) { Write<FString>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x10, Type: StrProperty)
    void SET_StormCircleSize(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: Int64Property)
    void SET_StormCircleSizeTracker(const FCDCLargeInt& Value) { Write<FCDCLargeInt>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: StructProperty)
    void SET_StormCircleLocation(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x10, Type: ArrayProperty)
    void SET_StormCircleLocationTracker(const FCDCFloatArray& Value) { Write<FCDCFloatArray>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: StructProperty)
    void SET_PlayerLocation(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    void SET_PlayerLocationTracker(const FCDCStringFloatArrayMap& Value) { Write<FCDCStringFloatArrayMap>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x50, Type: StructProperty)
    void SET_ArenaPointLeaderBoard(const FString& Value) { Write<FString>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x10, Type: StrProperty)
    void SET_ArenaPointLeaderBoardTracker(const FCDCStringStringMap& Value) { Write<FCDCStringStringMap>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0xa0, Type: StructProperty)
    void SET_CashCupDataAllTimeEarners(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x10, Type: StrProperty)
    void SET_CashCupDataAllTimeEanersTracker(const FCDCStringFloatMap& Value) { Write<FCDCStringFloatMap>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x50, Type: StructProperty)
    void SET_MythicBossEliminatedPlayer(const FString& Value) { Write<FString>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x10, Type: StrProperty)
    void SET_MythicBossEliminatedPlayerTracker(const FCDCString& Value) { Write<FCDCString>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x10, Type: StructProperty)
    void SET_MythicWeaponPlayer(const FString& Value) { Write<FString>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x10, Type: StrProperty)
    void SET_MythicWeaponPlayerTracker(const FCDCString& Value) { Write<FCDCString>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x10, Type: StructProperty)
    void SET_PlayerInfo(const FString& Value) { Write<FString>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x10, Type: StrProperty)
    void SET_PlayerInfoTracker(const FCDCStringArray& Value) { Write<FCDCStringArray>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x7e0
class ACreativeDataChannelTargetRL : public AElectraDataChannelTarget
{
public:
    int32_t VersionByte() const { return Read<int32_t>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: IntProperty)
    FCDCInt VersionByteTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: StructProperty)
    int32_t ScoreTeam() const { return Read<int32_t>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: IntProperty)
    FCDCString ScoreTeamTracker() const { return Read<FCDCString>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x10, Type: StructProperty)
    FString ScoreTotal() const { return Read<FString>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: StrProperty)
    FCDCStringIntMap ScoreTotalTracker() const { return Read<FCDCStringIntMap>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x50, Type: StructProperty)
    int64_t ScoreboardTimeLeft() const { return Read<int64_t>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: Int64Property)
    FCDCLargeInt ScoreboardTimeLeftTracker() const { return Read<FCDCLargeInt>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: StructProperty)
    FString ScoreboardBestOf() const { return Read<FString>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x10, Type: StrProperty)
    FCDCStringIntMap ScoreboardBestOfTracker() const { return Read<FCDCStringIntMap>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x50, Type: StructProperty)
    int32_t OverTime() const { return Read<int32_t>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x4, Type: IntProperty)
    FCDCInt OvertimeTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x46c); } // 0x46c (Size: 0x4, Type: StructProperty)
    FString TeamNames() const { return Read<FString>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: StrProperty)
    FCDCStringArray TeamNamesTracker() const { return Read<FCDCStringArray>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x18, Type: StructProperty)
    FString PlayerNames() const { return Read<FString>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x10, Type: StrProperty)
    FCDCStringArray PlayerNamesTracker() const { return Read<FCDCStringArray>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x18, Type: StructProperty)
    FString PlayerBoost() const { return Read<FString>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x10, Type: StrProperty)
    FCDCStringIntMap PlayerBoostTracker() const { return Read<FCDCStringIntMap>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x50, Type: StructProperty)
    FString PlayerBoostCollected() const { return Read<FString>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x10, Type: StrProperty)
    FCDCStringStringMap PlayerBoostCollectedTracker() const { return Read<FCDCStringStringMap>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0xa0, Type: StructProperty)
    FString PlayerCoords() const { return Read<FString>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x10, Type: StrProperty)
    FCDCStringFloatArrayMap PlayerCoordsTracker() const { return Read<FCDCStringFloatArrayMap>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x50, Type: StructProperty)
    FString BallCoords() const { return Read<FString>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x10, Type: StrProperty)
    FCDCFloatArray BallCoordsTracker() const { return Read<FCDCFloatArray>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x10, Type: StructProperty)
    FString MediaStart() const { return Read<FString>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x10, Type: StrProperty)
    FCDCStringStringMap MediaStartTracker() const { return Read<FCDCStringStringMap>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0xa0, Type: StructProperty)
    int32_t MediaStop() const { return Read<int32_t>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x4, Type: IntProperty)
    FCDCInt MediaStopTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x784); } // 0x784 (Size: 0x4, Type: StructProperty)
    int32_t SeriesState() const { return Read<int32_t>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x4, Type: IntProperty)
    FCDCInt SeriesStateTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x79c); } // 0x79c (Size: 0x4, Type: StructProperty)
    int32_t MatchState() const { return Read<int32_t>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x4, Type: IntProperty)
    FCDCInt MatchStateTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x7b4); } // 0x7b4 (Size: 0x4, Type: StructProperty)
    int32_t FinaleState() const { return Read<int32_t>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x4, Type: IntProperty)
    FCDCInt FinaleStateTracker() const { return Read<FCDCInt>(uintptr_t(this) + 0x7cc); } // 0x7cc (Size: 0x4, Type: StructProperty)

    void SET_VersionByte(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: IntProperty)
    void SET_VersionByteTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: StructProperty)
    void SET_ScoreTeam(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: IntProperty)
    void SET_ScoreTeamTracker(const FCDCString& Value) { Write<FCDCString>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x10, Type: StructProperty)
    void SET_ScoreTotal(const FString& Value) { Write<FString>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: StrProperty)
    void SET_ScoreTotalTracker(const FCDCStringIntMap& Value) { Write<FCDCStringIntMap>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x50, Type: StructProperty)
    void SET_ScoreboardTimeLeft(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: Int64Property)
    void SET_ScoreboardTimeLeftTracker(const FCDCLargeInt& Value) { Write<FCDCLargeInt>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: StructProperty)
    void SET_ScoreboardBestOf(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x10, Type: StrProperty)
    void SET_ScoreboardBestOfTracker(const FCDCStringIntMap& Value) { Write<FCDCStringIntMap>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x50, Type: StructProperty)
    void SET_OverTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x4, Type: IntProperty)
    void SET_OvertimeTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x46c, Value); } // 0x46c (Size: 0x4, Type: StructProperty)
    void SET_TeamNames(const FString& Value) { Write<FString>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: StrProperty)
    void SET_TeamNamesTracker(const FCDCStringArray& Value) { Write<FCDCStringArray>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x18, Type: StructProperty)
    void SET_PlayerNames(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x10, Type: StrProperty)
    void SET_PlayerNamesTracker(const FCDCStringArray& Value) { Write<FCDCStringArray>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x18, Type: StructProperty)
    void SET_PlayerBoost(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x10, Type: StrProperty)
    void SET_PlayerBoostTracker(const FCDCStringIntMap& Value) { Write<FCDCStringIntMap>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x50, Type: StructProperty)
    void SET_PlayerBoostCollected(const FString& Value) { Write<FString>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x10, Type: StrProperty)
    void SET_PlayerBoostCollectedTracker(const FCDCStringStringMap& Value) { Write<FCDCStringStringMap>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0xa0, Type: StructProperty)
    void SET_PlayerCoords(const FString& Value) { Write<FString>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x10, Type: StrProperty)
    void SET_PlayerCoordsTracker(const FCDCStringFloatArrayMap& Value) { Write<FCDCStringFloatArrayMap>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x50, Type: StructProperty)
    void SET_BallCoords(const FString& Value) { Write<FString>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x10, Type: StrProperty)
    void SET_BallCoordsTracker(const FCDCFloatArray& Value) { Write<FCDCFloatArray>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x10, Type: StructProperty)
    void SET_MediaStart(const FString& Value) { Write<FString>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x10, Type: StrProperty)
    void SET_MediaStartTracker(const FCDCStringStringMap& Value) { Write<FCDCStringStringMap>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0xa0, Type: StructProperty)
    void SET_MediaStop(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x4, Type: IntProperty)
    void SET_MediaStopTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x784, Value); } // 0x784 (Size: 0x4, Type: StructProperty)
    void SET_SeriesState(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x4, Type: IntProperty)
    void SET_SeriesStateTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x79c, Value); } // 0x79c (Size: 0x4, Type: StructProperty)
    void SET_MatchState(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x4, Type: IntProperty)
    void SET_MatchStateTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x7b4, Value); } // 0x7b4 (Size: 0x4, Type: StructProperty)
    void SET_FinaleState(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x4, Type: IntProperty)
    void SET_FinaleStateTracker(const FCDCInt& Value) { Write<FCDCInt>(uintptr_t(this) + 0x7cc, Value); } // 0x7cc (Size: 0x4, Type: StructProperty)
};

// Size: 0x50
struct FCDCStringFloatArrayMap
{
public:
    TMap<FString, FVector> Data() const { return Read<TMap<FString, FVector>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Data(const TMap<FString, FVector>& Value) { Write<TMap<FString, FVector>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FCDCFloatArray
{
public:
    TArray<float> Data() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Data(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FCDCStringFloatMap
{
public:
    TMap<FString, float> Data() const { return Read<TMap<FString, float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Data(const TMap<FString, float>& Value) { Write<TMap<FString, float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
struct FCDCStringIntMap
{
public:
    TMap<FString, int32_t> Data() const { return Read<TMap<FString, int32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Data(const TMap<FString, int32_t>& Value) { Write<TMap<FString, int32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x4
struct FCDCInt
{
public:
    int32_t Data() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Data(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FCDCLargeInt
{
public:
    int64_t Data() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)

    void SET_Data(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
};

// Size: 0xa0
struct FCDCStringStringMap
{
public:
    TMap<FString, FString> Data() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<FString, int32_t> ExtraData() const { return Read<TMap<FString, int32_t>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)

    void SET_Data(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_ExtraData(const TMap<FString, int32_t>& Value) { Write<TMap<FString, int32_t>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FCDCString
{
public:
    FString Data() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Data(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FCDCStringArray
{
public:
    TArray<FString> Data() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ExtraData() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_Data(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ExtraData(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FCreativeDataChannelEvents
{
public:
    TArray<FCreativeDataChannelEvent> EVENTS() const { return Read<TArray<FCreativeDataChannelEvent>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_EVENTS(const TArray<FCreativeDataChannelEvent>& Value) { Write<TArray<FCreativeDataChannelEvent>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FCreativeDataChannelEvent
{
public:
    FName EventName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName Parameters() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName TriggerCondition() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_EventName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Parameters(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_TriggerCondition(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

