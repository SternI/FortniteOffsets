/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_FabricJamTrackPlayerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MediaAssets.h"

// Size: 0xc0
class UFabricJamTrackPlayerPlaybackTimeVM : public UFabricPlaybackTimeViewModel
{
public:
    TWeakObjectPtr<UMediaPlayer*> CachedMediaPlayer() const { return Read<TWeakObjectPtr<UMediaPlayer*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedMediaPlayer(const TWeakObjectPtr<UMediaPlayer*>& Value) { Write<TWeakObjectPtr<UMediaPlayer*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x78
class UFabricJamTrackPlayerSongSelectVM : public UMVVMViewModelBase
{
public:
    bool bAllowOwnedSongs() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_bAllowOwnedSongs(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf0
class UFabricJamTrackPlayerTrackInfoVM : public UFabricTrackInfoViewModel
{
public:
};

// Size: 0x98
class UFabricJamTrackPlayerTrackNumberVM : public UFabricTrackNumberViewModel
{
public:
};

