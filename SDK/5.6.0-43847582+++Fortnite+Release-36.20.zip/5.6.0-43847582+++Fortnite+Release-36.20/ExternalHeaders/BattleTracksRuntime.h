/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattleTracksRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteMusic.h"
#include "SparksCoreCosmeticsRuntime.h"
#include "FortniteGame.h"
#include "GameplayTags.h"

// Size: 0xe8
class UBattleTracksPlayerComponent : public UFortControllerComponent
{
public:
    AFortPlayerController* PlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    USparksCosmeticComponent* SparksCosmeticComponent() const { return Read<USparksCosmeticComponent*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_SparksCosmeticComponent(const USparksCosmeticComponent*& Value) { Write<USparksCosmeticComponent*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
struct FFortBattleTracksPlaySongEvent
{
public:
    TScriptInterface<Class> Song() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: InterfaceProperty)
    int32_t JamTrackIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FGameplayTag MomentTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: StructProperty)
    FGameplayTag MusicEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer MusicEventBehaviorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)

    void SET_Song(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: InterfaceProperty)
    void SET_JamTrackIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_MomentTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: StructProperty)
    void SET_MusicEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_MusicEventBehaviorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
};

// Size: 0x48
struct FFortBattleTracksPrepareSongEvent : public FFortBattleTracksPlaySongEvent
{
public:
};

