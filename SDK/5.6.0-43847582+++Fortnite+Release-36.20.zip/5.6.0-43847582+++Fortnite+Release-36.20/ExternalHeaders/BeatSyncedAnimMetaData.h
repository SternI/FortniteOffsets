/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeatSyncedAnimMetaData
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x30
class UBeatSyncedAnimMetaData : public UAnimMetaData
{
public:
    bool bAllowBeatsyncing() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsForEmote() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bOverrideGroupEmoteBeatsyncingBehavior() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)
    bool bAllowGroupEmoteLeaderToBeatSync() const { return Read<bool>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: BoolProperty)
    bool bAllowGroupEmoteFollowerToBeatSync() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_bAllowBeatsyncing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bIsForEmote(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideGroupEmoteBeatsyncingBehavior(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
    void SET_bAllowGroupEmoteLeaderToBeatSync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: BoolProperty)
    void SET_bAllowGroupEmoteFollowerToBeatSync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UPreciseBeatSyncedAnimMetaData : public UBeatSyncedAnimMetaData
{
public:
    bool bShouldHalfOrDoublePlayRate() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bOverrideGlobalHalfOrDoublePlayRateLimits() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    float MaxPlayRateBeforeHalf() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float MinPlayRateBeforeDouble() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float FirstBeatAtFrame() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float BeatB() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float BPM() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    FName FirstBeatSyncingSection() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)

    void SET_bShouldHalfOrDoublePlayRate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideGlobalHalfOrDoublePlayRateLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_MaxPlayRateBeforeHalf(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_MinPlayRateBeforeDouble(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_FirstBeatAtFrame(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_BeatB(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_BPM(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_FirstBeatSyncingSection(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
};

// Size: 0x38
class UTimeSyncedBeatSyncedAnimMetaData : public UBeatSyncedAnimMetaData
{
public:
    float AnimTimeZeroOffsetSeconds() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float PlaybackScale() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_AnimTimeZeroOffsetSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_PlaybackScale(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

