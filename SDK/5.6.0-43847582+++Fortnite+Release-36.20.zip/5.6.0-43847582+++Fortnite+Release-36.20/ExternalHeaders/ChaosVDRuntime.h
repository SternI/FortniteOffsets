/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosVDRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x10
struct FChaosVDWrapperDataBase
{
public:
    bool bHasValidData() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_bHasValidData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FChaosVDAccelerationStructureBase : public FChaosVDWrapperDataBase
{
public:
    int32_t SolverId() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_SolverId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x68
struct FChaosVDBVCellElementDataWrapper : public FChaosVDWrapperDataBase
{
public:
    FBox Bounds() const { return Read<FBox>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x38, Type: StructProperty)
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)

    void SET_Bounds(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x38, Type: StructProperty)
    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
};

// Size: 0x40
struct FChaosVDBoundingVolumeDataWrapper : public FChaosVDAccelerationStructureBase
{
public:
    double MaxPayloadBounds() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)

    void SET_MaxPayloadBounds(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x90
struct FChaosVDAABBTreeNodeDataWrapper : public FChaosVDWrapperDataBase
{
public:
    FBox ChildrenBounds() const { return Read<FBox>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x70, Type: StructProperty)
    int32_t ChildrenNodes() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: IntProperty)
    int32_t ParentNode() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    bool bLeaf() const { return (Read<uint8_t>(uintptr_t(this) + 0x8c) >> 0x0) & 1; } // 0x8c:0 (Size: 0x1, Type: BoolProperty)
    bool bDirtyNode() const { return (Read<uint8_t>(uintptr_t(this) + 0x8c) >> 0x1) & 1; } // 0x8c:1 (Size: 0x1, Type: BoolProperty)

    void SET_ChildrenBounds(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x70, Type: StructProperty)
    void SET_ChildrenNodes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: IntProperty)
    void SET_ParentNode(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_bLeaf(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x8c, B); } // 0x8c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDirtyNode(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x8c, B); } // 0x8c:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
struct FChaosVDAABBTreePayloadBoundsElement : public FChaosVDWrapperDataBase
{
public:
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    FBox Bounds() const { return Read<FBox>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x38, Type: StructProperty)

    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_Bounds(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x38, Type: StructProperty)
};

// Size: 0x58
struct FChaosVDAABBTreeLeafDataWrapper : public FChaosVDWrapperDataBase
{
public:
    TArray<FChaosVDAABBTreePayloadBoundsElement> Elements() const { return Read<TArray<FChaosVDAABBTreePayloadBoundsElement>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FBox Bounds() const { return Read<FBox>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x38, Type: StructProperty)

    void SET_Elements(const TArray<FChaosVDAABBTreePayloadBoundsElement>& Value) { Write<TArray<FChaosVDAABBTreePayloadBoundsElement>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Bounds(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x38, Type: StructProperty)
};

// Size: 0x50
struct FChaosVDAccelerationStructureContainer
{
public:
};

// Size: 0x70
struct FChaosVDAABBTreeDataWrapper : public FChaosVDAccelerationStructureBase
{
public:
    int32_t RootNodeIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t TreeDepth() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t NodesNum() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t LeavesNum() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    bool bDynamicTree() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    int32_t MaxChildrenInLeaf() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t MaxTreeDepth() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    double MaxPayloadBounds() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)

    void SET_RootNodeIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_TreeDepth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_NodesNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_LeavesNum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_bDynamicTree(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_MaxChildrenInLeaf(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_MaxTreeDepth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_MaxPayloadBounds(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x58
struct FChaosVDCharacterGroundConstraintStateDataWrapper : public FChaosVDWrapperDataBase
{
public:
    bool bDisabled() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    FVector SolverAppliedForce() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector SolverAppliedTorque() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_bDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_SolverAppliedForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_SolverAppliedTorque(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x68
struct FChaosVDCharacterGroundConstraintSettingsDataWrapper : public FChaosVDWrapperDataBase
{
public:
    FVector VerticalAxis() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    double TargetHeight() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    double RadialForceLimit() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    double FrictionForceLimit() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    double TwistTorqueLimit() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double SwingTorqueLimit() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    double CosMaxWalkableSlopeAngle() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    double DampingFactor() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double AssumedOnGroundHeight() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)

    void SET_VerticalAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_TargetHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_RadialForceLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_FrictionForceLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    void SET_TwistTorqueLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_SwingTorqueLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_CosMaxWalkableSlopeAngle(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_DampingFactor(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_AssumedOnGroundHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x58
struct FChaosVDCharacterGroundConstraintDataDataWrapper : public FChaosVDWrapperDataBase
{
public:
    FVector GroundNormal() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector TargetDeltaPosition() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    double TargetDeltaFacing() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double GroundDistance() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    double CosMaxWalkableSlopeAngle() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)

    void SET_GroundNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_TargetDeltaPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_TargetDeltaFacing(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_GroundDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_CosMaxWalkableSlopeAngle(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x10
struct FChaosVDConstraintDataWrapperBase : public FChaosVDWrapperDataBase
{
public:
};

// Size: 0x138
struct FChaosVDCharacterGroundConstraint : public FChaosVDConstraintDataWrapperBase
{
public:
    int32_t ConstraintIndex() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    FChaosVDCharacterGroundConstraintStateDataWrapper State() const { return Read<FChaosVDCharacterGroundConstraintStateDataWrapper>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x58, Type: StructProperty)
    FChaosVDCharacterGroundConstraintSettingsDataWrapper Settings() const { return Read<FChaosVDCharacterGroundConstraintSettingsDataWrapper>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x68, Type: StructProperty)
    FChaosVDCharacterGroundConstraintDataDataWrapper Data() const { return Read<FChaosVDCharacterGroundConstraintDataDataWrapper>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x58, Type: StructProperty)

    void SET_ConstraintIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_State(const FChaosVDCharacterGroundConstraintStateDataWrapper& Value) { Write<FChaosVDCharacterGroundConstraintStateDataWrapper>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x58, Type: StructProperty)
    void SET_Settings(const FChaosVDCharacterGroundConstraintSettingsDataWrapper& Value) { Write<FChaosVDCharacterGroundConstraintSettingsDataWrapper>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x68, Type: StructProperty)
    void SET_Data(const FChaosVDCharacterGroundConstraintDataDataWrapper& Value) { Write<FChaosVDCharacterGroundConstraintDataDataWrapper>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x58, Type: StructProperty)
};

// Size: 0x58
struct FChaosVDContactPoint
{
public:
    FVector ShapeContactPoints() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    FVector ShapeContactNormal() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float Phi() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t FaceIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    uint8_t ContactType() const { return Read<uint8_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: EnumProperty)

    void SET_ShapeContactPoints(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_ShapeContactNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Phi(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_FaceIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET_ContactType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x130
struct FChaosVDManifoldPoint
{
public:
    bool bDisabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bWasRestored() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    bool bWasReplaced() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x2) & 1; } // 0x0:2 (Size: 0x1, Type: BoolProperty)
    bool bHasStaticFrictionAnchor() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x3) & 1; } // 0x0:3 (Size: 0x1, Type: BoolProperty)
    bool bIsValid() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x4) & 1; } // 0x0:4 (Size: 0x1, Type: BoolProperty)
    bool bInsideStaticFrictionCone() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x5) & 1; } // 0x0:5 (Size: 0x1, Type: BoolProperty)
    FVector NetPushOut() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector NetImpulse() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float TargetPhi() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float InitialPhi() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FVector ShapeAnchorPoints() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x30, Type: StructProperty)
    FVector InitialShapeContactPoints() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x30, Type: StructProperty)
    FChaosVDContactPoint ContactPoint() const { return Read<FChaosVDContactPoint>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x58, Type: StructProperty)
    FVector ShapeContactPoints() const { return Read<FVector>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x30, Type: StructProperty)

    void SET_bDisabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bWasRestored(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bWasReplaced(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bHasStaticFrictionAnchor(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsValid(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:4 (Size: 0x1, Type: BoolProperty)
    void SET_bInsideStaticFrictionCone(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:5 (Size: 0x1, Type: BoolProperty)
    void SET_NetPushOut(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_NetImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_TargetPhi(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_InitialPhi(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_ShapeAnchorPoints(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x30, Type: StructProperty)
    void SET_InitialShapeContactPoints(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x30, Type: StructProperty)
    void SET_ContactPoint(const FChaosVDContactPoint& Value) { Write<FChaosVDContactPoint>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x58, Type: StructProperty)
    void SET_ShapeContactPoints(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x30, Type: StructProperty)
};

// Size: 0x30
struct FChaosVDCollisionMaterial
{
public:
    int32_t FaceIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float MaterialDynamicFriction() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaterialStaticFriction() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaterialRestitution() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float DynamicFriction() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float StaticFriction() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Restitution() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float RestitutionThreshold() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float InvMassScale0() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float InvMassScale1() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float InvInertiaScale0() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float InvInertiaScale1() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)

    void SET_FaceIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_MaterialDynamicFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaterialStaticFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaterialRestitution(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_DynamicFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_StaticFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Restitution(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_RestitutionThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_InvMassScale0(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_InvMassScale1(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_InvInertiaScale0(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_InvInertiaScale1(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x280
struct FChaosVDConstraint
{
public:
    bool bIsCurrent() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bDisabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    bool bUseManifold() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x2) & 1; } // 0x0:2 (Size: 0x1, Type: BoolProperty)
    bool bUseIncrementalManifold() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x3) & 1; } // 0x0:3 (Size: 0x1, Type: BoolProperty)
    bool bCanRestoreManifold() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x4) & 1; } // 0x0:4 (Size: 0x1, Type: BoolProperty)
    bool bWasManifoldRestored() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x5) & 1; } // 0x0:5 (Size: 0x1, Type: BoolProperty)
    bool bIsQuadratic0() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x6) & 1; } // 0x0:6 (Size: 0x1, Type: BoolProperty)
    bool bIsQuadratic1() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x7) & 1; } // 0x0:7 (Size: 0x1, Type: BoolProperty)
    bool bIsProbe() const { return (Read<uint8_t>(uintptr_t(this) + 0x1) >> 0x0) & 1; } // 0x1:0 (Size: 0x1, Type: BoolProperty)
    bool bCCDEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x1) >> 0x1) & 1; } // 0x1:1 (Size: 0x1, Type: BoolProperty)
    bool bCCDSweepEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x1) >> 0x2) & 1; } // 0x1:2 (Size: 0x1, Type: BoolProperty)
    bool bModifierApplied() const { return (Read<uint8_t>(uintptr_t(this) + 0x1) >> 0x3) & 1; } // 0x1:3 (Size: 0x1, Type: BoolProperty)
    bool bMaterialSet() const { return (Read<uint8_t>(uintptr_t(this) + 0x1) >> 0x4) & 1; } // 0x1:4 (Size: 0x1, Type: BoolProperty)
    FChaosVDCollisionMaterial Material() const { return Read<FChaosVDCollisionMaterial>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x30, Type: StructProperty)
    FVector AccumulatedImpulse() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FTransform ShapeWorldTransforms() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0xc0, Type: StructProperty)
    FTransform ImplicitTransforms() const { return Read<FTransform>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0xc0, Type: StructProperty)
    float CullDistance() const { return Read<float>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    TArray<float> CollisionMargins() const { return Read<TArray<float>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    float CollisionTolerance() const { return Read<float>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    int32_t ClosestManifoldPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: IntProperty)
    int32_t ExpectedNumManifoldPoints() const { return Read<int32_t>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: IntProperty)
    FVector LastShapeWorldPositionDelta() const { return Read<FVector>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x18, Type: StructProperty)
    FQuat LastShapeWorldRotationDelta() const { return Read<FQuat>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x20, Type: StructProperty)
    float Stiffness() const { return Read<float>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: FloatProperty)
    float MinInitialPhi() const { return Read<float>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: FloatProperty)
    float InitialOverlapDepenetrationVelocity() const { return Read<float>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: FloatProperty)
    float CCDTimeOfImpact() const { return Read<float>(uintptr_t(this) + 0x24c); } // 0x24c (Size: 0x4, Type: FloatProperty)
    float CCDEnablePenetration() const { return Read<float>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x4, Type: FloatProperty)
    float CCDTargetPenetration() const { return Read<float>(uintptr_t(this) + 0x254); } // 0x254 (Size: 0x4, Type: FloatProperty)
    TArray<FChaosVDManifoldPoint> ManifoldPoints() const { return Read<TArray<FChaosVDManifoldPoint>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    int32_t Particle0Index() const { return Read<int32_t>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x4, Type: IntProperty)
    int32_t Particle1Index() const { return Read<int32_t>(uintptr_t(this) + 0x26c); } // 0x26c (Size: 0x4, Type: IntProperty)
    int32_t SolverId() const { return Read<int32_t>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x4, Type: IntProperty)

    void SET_bIsCurrent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDisabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseManifold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bUseIncrementalManifold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:3 (Size: 0x1, Type: BoolProperty)
    void SET_bCanRestoreManifold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:4 (Size: 0x1, Type: BoolProperty)
    void SET_bWasManifoldRestored(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsQuadratic0(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:6 (Size: 0x1, Type: BoolProperty)
    void SET_bIsQuadratic1(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:7 (Size: 0x1, Type: BoolProperty)
    void SET_bIsProbe(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1, B); } // 0x1:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCCDEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1, B); } // 0x1:1 (Size: 0x1, Type: BoolProperty)
    void SET_bCCDSweepEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1, B); } // 0x1:2 (Size: 0x1, Type: BoolProperty)
    void SET_bModifierApplied(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1, B); } // 0x1:3 (Size: 0x1, Type: BoolProperty)
    void SET_bMaterialSet(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1, B); } // 0x1:4 (Size: 0x1, Type: BoolProperty)
    void SET_Material(const FChaosVDCollisionMaterial& Value) { Write<FChaosVDCollisionMaterial>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x30, Type: StructProperty)
    void SET_AccumulatedImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_ShapeWorldTransforms(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0xc0, Type: StructProperty)
    void SET_ImplicitTransforms(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0xc0, Type: StructProperty)
    void SET_CullDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionMargins(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    void SET_CollisionTolerance(const float& Value) { Write<float>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    void SET_ClosestManifoldPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: IntProperty)
    void SET_ExpectedNumManifoldPoints(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: IntProperty)
    void SET_LastShapeWorldPositionDelta(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x18, Type: StructProperty)
    void SET_LastShapeWorldRotationDelta(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x20, Type: StructProperty)
    void SET_Stiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: FloatProperty)
    void SET_MinInitialPhi(const float& Value) { Write<float>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: FloatProperty)
    void SET_InitialOverlapDepenetrationVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: FloatProperty)
    void SET_CCDTimeOfImpact(const float& Value) { Write<float>(uintptr_t(this) + 0x24c, Value); } // 0x24c (Size: 0x4, Type: FloatProperty)
    void SET_CCDEnablePenetration(const float& Value) { Write<float>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x4, Type: FloatProperty)
    void SET_CCDTargetPenetration(const float& Value) { Write<float>(uintptr_t(this) + 0x254, Value); } // 0x254 (Size: 0x4, Type: FloatProperty)
    void SET_ManifoldPoints(const TArray<FChaosVDManifoldPoint>& Value) { Write<TArray<FChaosVDManifoldPoint>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_Particle0Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x4, Type: IntProperty)
    void SET_Particle1Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26c, Value); } // 0x26c (Size: 0x4, Type: IntProperty)
    void SET_SolverId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FChaosVDParticlePairMidPhase
{
public:
    int32_t SolverId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t MidPhaseType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    bool bIsActive() const { return (Read<uint8_t>(uintptr_t(this) + 0x5) >> 0x0) & 1; } // 0x5:0 (Size: 0x1, Type: BoolProperty)
    bool bIsCCD() const { return (Read<uint8_t>(uintptr_t(this) + 0x5) >> 0x1) & 1; } // 0x5:1 (Size: 0x1, Type: BoolProperty)
    bool bIsCCDActive() const { return (Read<uint8_t>(uintptr_t(this) + 0x5) >> 0x2) & 1; } // 0x5:2 (Size: 0x1, Type: BoolProperty)
    bool bIsSleeping() const { return (Read<uint8_t>(uintptr_t(this) + 0x5) >> 0x3) & 1; } // 0x5:3 (Size: 0x1, Type: BoolProperty)
    bool bIsModified() const { return (Read<uint8_t>(uintptr_t(this) + 0x5) >> 0x4) & 1; } // 0x5:4 (Size: 0x1, Type: BoolProperty)
    int32_t LastUsedEpoch() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Particle0Idx() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t Particle1Idx() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    TArray<FChaosVDConstraint> Constraints() const { return Read<TArray<FChaosVDConstraint>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_SolverId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_MidPhaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_bIsActive(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x5); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x5, B); } // 0x5:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCCD(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x5); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x5, B); } // 0x5:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCCDActive(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x5); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x5, B); } // 0x5:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSleeping(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x5); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x5, B); } // 0x5:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsModified(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x5); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x5, B); } // 0x5:4 (Size: 0x1, Type: BoolProperty)
    void SET_LastUsedEpoch(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Particle0Idx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_Particle1Idx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_Constraints(const TArray<FChaosVDConstraint>& Value) { Write<TArray<FChaosVDConstraint>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FChaosVDCollisionFilterData
{
public:
    uint32_t Word0() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Word1() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Word2() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t Word3() const { return Read<uint32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: UInt32Property)

    void SET_Word0(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Word1(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_Word2(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
    void SET_Word3(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: UInt32Property)
};

// Size: 0x2c
struct FChaosVDShapeCollisionData
{
public:
    bool bSimCollision() const { return (Read<uint8_t>(uintptr_t(this) + 0x4) >> 0x0) & 1; } // 0x4:0 (Size: 0x1, Type: BoolProperty)
    bool bQueryCollision() const { return (Read<uint8_t>(uintptr_t(this) + 0x4) >> 0x1) & 1; } // 0x4:1 (Size: 0x1, Type: BoolProperty)
    bool bIsProbe() const { return (Read<uint8_t>(uintptr_t(this) + 0x4) >> 0x2) & 1; } // 0x4:2 (Size: 0x1, Type: BoolProperty)
    FChaosVDCollisionFilterData QueryData() const { return Read<FChaosVDCollisionFilterData>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FChaosVDCollisionFilterData SimData() const { return Read<FChaosVDCollisionFilterData>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    bool bIsComplex() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsValid() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)

    void SET_bSimCollision(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x4, B); } // 0x4:0 (Size: 0x1, Type: BoolProperty)
    void SET_bQueryCollision(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x4); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x4, B); } // 0x4:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsProbe(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x4); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x4, B); } // 0x4:2 (Size: 0x1, Type: BoolProperty)
    void SET_QueryData(const FChaosVDCollisionFilterData& Value) { Write<FChaosVDCollisionFilterData>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_SimData(const FChaosVDCollisionFilterData& Value) { Write<FChaosVDCollisionFilterData>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_bIsComplex(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bIsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FChaosVDCollisionChannelInfo
{
public:
    FString DisplayName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t CollisionChannel() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    bool bIsTraceType() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_DisplayName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_CollisionChannel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_bIsTraceType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x300
struct FChaosVDCollisionChannelsInfoContainer
{
public:
    FChaosVDCollisionChannelInfo CustomChannelsNames() const { return Read<FChaosVDCollisionChannelInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x300, Type: StructProperty)

    void SET_CustomChannelsNames(const FChaosVDCollisionChannelInfo& Value) { Write<FChaosVDCollisionChannelInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x300, Type: StructProperty)
};

// Size: 0x40
struct FChaosVDDebugShapeDataContainer
{
public:
};

// Size: 0x50
struct FChaosVDMultiSolverDebugShapeDataContainer
{
public:
};

// Size: 0x20
struct FChaosVDDebugDrawShapeBase : public FChaosVDWrapperDataBase
{
public:
    int32_t SolverId() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FColor Color() const { return Read<FColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: StructProperty)

    void SET_SolverId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Color(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: StructProperty)
};

// Size: 0x58
struct FChaosVDDebugDrawBoxDataWrapper : public FChaosVDDebugDrawShapeBase
{
public:
    FBox Box() const { return Read<FBox>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x38, Type: StructProperty)

    void SET_Box(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x38, Type: StructProperty)
};

// Size: 0x40
struct FChaosVDDebugDrawSphereDataWrapper : public FChaosVDDebugDrawShapeBase
{
public:
    FVector origin() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_origin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
struct FChaosVDDebugDrawLineDataWrapper : public FChaosVDDebugDrawShapeBase
{
public:
    FVector StartLocation() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector EndLocation() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    bool bIsArrow() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)

    void SET_StartLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_EndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_bIsArrow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FChaosVDDebugDrawImplicitObjectDataWrapper : public FChaosVDDebugDrawShapeBase
{
public:
};

// Size: 0x60
struct FChaosVDJointStateDataWrapper : public FChaosVDWrapperDataBase
{
public:
    bool bDisabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x20) >> 0x0) & 1; } // 0x20:0 (Size: 0x1, Type: BoolProperty)
    bool bBroken() const { return (Read<uint8_t>(uintptr_t(this) + 0x20) >> 0x1) & 1; } // 0x20:1 (Size: 0x1, Type: BoolProperty)
    bool bBreaking() const { return (Read<uint8_t>(uintptr_t(this) + 0x20) >> 0x2) & 1; } // 0x20:2 (Size: 0x1, Type: BoolProperty)
    bool bDriveTargetChanged() const { return (Read<uint8_t>(uintptr_t(this) + 0x20) >> 0x3) & 1; } // 0x20:3 (Size: 0x1, Type: BoolProperty)
    bool bEnabledDuringResim() const { return (Read<uint8_t>(uintptr_t(this) + 0x20) >> 0x4) & 1; } // 0x20:4 (Size: 0x1, Type: BoolProperty)
    FVector LinearImpulse() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector AngularImpulse() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_bDisabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x20); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x20, B); } // 0x20:0 (Size: 0x1, Type: BoolProperty)
    void SET_bBroken(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x20); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x20, B); } // 0x20:1 (Size: 0x1, Type: BoolProperty)
    void SET_bBreaking(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x20); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x20, B); } // 0x20:2 (Size: 0x1, Type: BoolProperty)
    void SET_bDriveTargetChanged(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x20); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x20, B); } // 0x20:3 (Size: 0x1, Type: BoolProperty)
    void SET_bEnabledDuringResim(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x20); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x20, B); } // 0x20:4 (Size: 0x1, Type: BoolProperty)
    void SET_LinearImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_AngularImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FChaosVDGTJointStateDataWrapper : public FChaosVDWrapperDataBase
{
public:
    bool bIsBreaking() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x0) & 1; } // 0x10:0 (Size: 0x1, Type: BoolProperty)
    bool bIsBroken() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x1) & 1; } // 0x10:1 (Size: 0x1, Type: BoolProperty)
    bool bDriveTargetChanged() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x2) & 1; } // 0x10:2 (Size: 0x1, Type: BoolProperty)
    bool bIsViolating() const { return (Read<uint8_t>(uintptr_t(this) + 0x10) >> 0x3) & 1; } // 0x10:3 (Size: 0x1, Type: BoolProperty)
    FVector Force() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Torque() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float LinearViolation() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float AngularViolation() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)

    void SET_bIsBreaking(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsBroken(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:1 (Size: 0x1, Type: BoolProperty)
    void SET_bDriveTargetChanged(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsViolating(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x10); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x10, B); } // 0x10:3 (Size: 0x1, Type: BoolProperty)
    void SET_Force(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Torque(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_LinearViolation(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_AngularViolation(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd8
struct FChaosVDJointSolverSettingsDataWrapper : public FChaosVDWrapperDataBase
{
public:
    double SwingTwistAngleTolerance() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double PositionTolerance() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double AngleTolerance() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    double MinParentMassRatio() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    double MaxInertiaRatio() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    double MinSolverStiffness() const { return Read<double>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    double MaxSolverStiffness() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    int32_t NumIterationsAtMaxSolverStiffness() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    int32_t NumShockPropagationIterations() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    bool bUseLinearSolver() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x0) & 1; } // 0x50:0 (Size: 0x1, Type: BoolProperty)
    bool bSortEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x1) & 1; } // 0x50:1 (Size: 0x1, Type: BoolProperty)
    bool bSolvePositionLast() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x2) & 1; } // 0x50:2 (Size: 0x1, Type: BoolProperty)
    bool bUsePositionBasedDrives() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x3) & 1; } // 0x50:3 (Size: 0x1, Type: BoolProperty)
    bool bEnableTwistLimits() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x4) & 1; } // 0x50:4 (Size: 0x1, Type: BoolProperty)
    bool bEnableSwingLimits() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x5) & 1; } // 0x50:5 (Size: 0x1, Type: BoolProperty)
    bool bEnableDrives() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x6) & 1; } // 0x50:6 (Size: 0x1, Type: BoolProperty)
    double LinearStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double TwistStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    double SwingStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    double LinearProjectionOverride() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    double AngularProjectionOverride() const { return Read<double>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    double ShockPropagationOverride() const { return Read<double>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    double LinearDriveStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: DoubleProperty)
    double LinearDriveDampingOverride() const { return Read<double>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    double AngularDriveStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    double AngularDriveDampingOverride() const { return Read<double>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: DoubleProperty)
    double SoftLinearStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: DoubleProperty)
    double SoftLinearDampingOverride() const { return Read<double>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistDampingOverride() const { return Read<double>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingStiffnessOverride() const { return Read<double>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingDampingOverride() const { return Read<double>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: DoubleProperty)

    void SET_SwingTwistAngleTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_PositionTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_AngleTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_MinParentMassRatio(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxInertiaRatio(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
    void SET_MinSolverStiffness(const double& Value) { Write<double>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxSolverStiffness(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_NumIterationsAtMaxSolverStiffness(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_NumShockPropagationIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET_bUseLinearSolver(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:0 (Size: 0x1, Type: BoolProperty)
    void SET_bSortEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:1 (Size: 0x1, Type: BoolProperty)
    void SET_bSolvePositionLast(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:2 (Size: 0x1, Type: BoolProperty)
    void SET_bUsePositionBasedDrives(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:3 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableTwistLimits(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:4 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableSwingLimits(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:5 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDrives(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:6 (Size: 0x1, Type: BoolProperty)
    void SET_LinearStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_TwistStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_SwingStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearProjectionOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularProjectionOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    void SET_ShockPropagationOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearDriveStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearDriveDampingOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularDriveStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularDriveDampingOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftLinearStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftLinearDampingOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftTwistStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftTwistDampingOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftSwingStiffnessOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftSwingDampingOverride(const double& Value) { Write<double>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x2f0
struct FChaosVDJointSettingsDataWrapper : public FChaosVDWrapperDataBase
{
public:
    FTransform ConnectorTransforms() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc0, Type: StructProperty)
    double Stiffness() const { return Read<double>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
    double LinearProjection() const { return Read<double>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double AngularProjection() const { return Read<double>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    double ShockPropagation() const { return Read<double>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    double TeleportDistance() const { return Read<double>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    double TeleportAngle() const { return Read<double>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
    double ParentInvMassScale() const { return Read<double>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: DoubleProperty)
    bool bCollisionEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x0) & 1; } // 0x108:0 (Size: 0x1, Type: BoolProperty)
    bool bMassConditioningEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x1) & 1; } // 0x108:1 (Size: 0x1, Type: BoolProperty)
    bool bUseLinearSolver() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x2) & 1; } // 0x108:2 (Size: 0x1, Type: BoolProperty)
    bool bSoftLinearLimitsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x3) & 1; } // 0x108:3 (Size: 0x1, Type: BoolProperty)
    bool bSoftTwistLimitsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x4) & 1; } // 0x108:4 (Size: 0x1, Type: BoolProperty)
    bool bSoftSwingLimitsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x5) & 1; } // 0x108:5 (Size: 0x1, Type: BoolProperty)
    bool bAngularSLerpPositionDriveEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x6) & 1; } // 0x108:6 (Size: 0x1, Type: BoolProperty)
    bool bAngularSLerpVelocityDriveEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x108) >> 0x7) & 1; } // 0x108:7 (Size: 0x1, Type: BoolProperty)
    bool bAngularTwistPositionDriveEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x109) >> 0x0) & 1; } // 0x109:0 (Size: 0x1, Type: BoolProperty)
    bool bAngularTwistVelocityDriveEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x109) >> 0x1) & 1; } // 0x109:1 (Size: 0x1, Type: BoolProperty)
    bool bAngularSwingPositionDriveEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x109) >> 0x2) & 1; } // 0x109:2 (Size: 0x1, Type: BoolProperty)
    bool bAngularSwingVelocityDriveEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x109) >> 0x3) & 1; } // 0x109:3 (Size: 0x1, Type: BoolProperty)
    double LinearLimit() const { return Read<double>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: DoubleProperty)
    FVector AngularLimits() const { return Read<FVector>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x18, Type: StructProperty)
    double SoftLinearStiffness() const { return Read<double>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: DoubleProperty)
    double SoftLinearDamping() const { return Read<double>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistStiffness() const { return Read<double>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistDamping() const { return Read<double>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingStiffness() const { return Read<double>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingDamping() const { return Read<double>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: DoubleProperty)
    double LinearRestitution() const { return Read<double>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: DoubleProperty)
    double TwistRestitution() const { return Read<double>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    double SwingRestitution() const { return Read<double>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: DoubleProperty)
    double LinearContactDistance() const { return Read<double>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: DoubleProperty)
    double TwistContactDistance() const { return Read<double>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    double SwingContactDistance() const { return Read<double>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: DoubleProperty)
    FVector LinearDrivePositionTarget() const { return Read<FVector>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x18, Type: StructProperty)
    FVector LinearDriveVelocityTarget() const { return Read<FVector>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x18, Type: StructProperty)
    bool bLinearPositionDriveEnabled0() const { return (Read<uint8_t>(uintptr_t(this) + 0x1e0) >> 0x0) & 1; } // 0x1e0:0 (Size: 0x1, Type: BoolProperty)
    bool bLinearPositionDriveEnabled1() const { return (Read<uint8_t>(uintptr_t(this) + 0x1e0) >> 0x1) & 1; } // 0x1e0:1 (Size: 0x1, Type: BoolProperty)
    bool bLinearPositionDriveEnabled2() const { return (Read<uint8_t>(uintptr_t(this) + 0x1e0) >> 0x2) & 1; } // 0x1e0:2 (Size: 0x1, Type: BoolProperty)
    bool bLinearVelocityDriveEnabled0() const { return (Read<uint8_t>(uintptr_t(this) + 0x1e0) >> 0x3) & 1; } // 0x1e0:3 (Size: 0x1, Type: BoolProperty)
    bool bLinearVelocityDriveEnabled1() const { return (Read<uint8_t>(uintptr_t(this) + 0x1e0) >> 0x4) & 1; } // 0x1e0:4 (Size: 0x1, Type: BoolProperty)
    bool bLinearVelocityDriveEnabled2() const { return (Read<uint8_t>(uintptr_t(this) + 0x1e0) >> 0x5) & 1; } // 0x1e0:5 (Size: 0x1, Type: BoolProperty)
    FVector LinearDriveStiffness() const { return Read<FVector>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x18, Type: StructProperty)
    FVector LinearDriveDamping() const { return Read<FVector>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x18, Type: StructProperty)
    FVector LinearDriveMaxForce() const { return Read<FVector>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x18, Type: StructProperty)
    FQuat AngularDrivePositionTarget() const { return Read<FQuat>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x20, Type: StructProperty)
    FVector AngularDriveVelocityTarget() const { return Read<FVector>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x18, Type: StructProperty)
    FVector AngularDriveStiffness() const { return Read<FVector>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x18, Type: StructProperty)
    FVector AngularDriveDamping() const { return Read<FVector>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x18, Type: StructProperty)
    FVector AngularDriveMaxTorque() const { return Read<FVector>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x18, Type: StructProperty)
    double LinearBreakForce() const { return Read<double>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    double LinearPlasticityLimit() const { return Read<double>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: DoubleProperty)
    double LinearPlasticityInitialDistanceSquared() const { return Read<double>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    double AngularBreakTorque() const { return Read<double>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    double AngularPlasticityLimit() const { return Read<double>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    double ContactTransferScale() const { return Read<double>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: DoubleProperty)

    void SET_ConnectorTransforms(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc0, Type: StructProperty)
    void SET_Stiffness(const double& Value) { Write<double>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearProjection(const double& Value) { Write<double>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularProjection(const double& Value) { Write<double>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    void SET_ShockPropagation(const double& Value) { Write<double>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    void SET_TeleportDistance(const double& Value) { Write<double>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: DoubleProperty)
    void SET_TeleportAngle(const double& Value) { Write<double>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
    void SET_ParentInvMassScale(const double& Value) { Write<double>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: DoubleProperty)
    void SET_bCollisionEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:0 (Size: 0x1, Type: BoolProperty)
    void SET_bMassConditioningEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseLinearSolver(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:2 (Size: 0x1, Type: BoolProperty)
    void SET_bSoftLinearLimitsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:3 (Size: 0x1, Type: BoolProperty)
    void SET_bSoftTwistLimitsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:4 (Size: 0x1, Type: BoolProperty)
    void SET_bSoftSwingLimitsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:5 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularSLerpPositionDriveEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:6 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularSLerpVelocityDriveEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x108); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x108, B); } // 0x108:7 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularTwistPositionDriveEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x109); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x109, B); } // 0x109:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularTwistVelocityDriveEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x109); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x109, B); } // 0x109:1 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularSwingPositionDriveEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x109); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x109, B); } // 0x109:2 (Size: 0x1, Type: BoolProperty)
    void SET_bAngularSwingVelocityDriveEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x109); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x109, B); } // 0x109:3 (Size: 0x1, Type: BoolProperty)
    void SET_LinearLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularLimits(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x18, Type: StructProperty)
    void SET_SoftLinearStiffness(const double& Value) { Write<double>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftLinearDamping(const double& Value) { Write<double>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftTwistStiffness(const double& Value) { Write<double>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftTwistDamping(const double& Value) { Write<double>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftSwingStiffness(const double& Value) { Write<double>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: DoubleProperty)
    void SET_SoftSwingDamping(const double& Value) { Write<double>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearRestitution(const double& Value) { Write<double>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: DoubleProperty)
    void SET_TwistRestitution(const double& Value) { Write<double>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    void SET_SwingRestitution(const double& Value) { Write<double>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearContactDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: DoubleProperty)
    void SET_TwistContactDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    void SET_SwingContactDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearDrivePositionTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x18, Type: StructProperty)
    void SET_LinearDriveVelocityTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x18, Type: StructProperty)
    void SET_bLinearPositionDriveEnabled0(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1e0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1e0, B); } // 0x1e0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bLinearPositionDriveEnabled1(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1e0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1e0, B); } // 0x1e0:1 (Size: 0x1, Type: BoolProperty)
    void SET_bLinearPositionDriveEnabled2(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1e0); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1e0, B); } // 0x1e0:2 (Size: 0x1, Type: BoolProperty)
    void SET_bLinearVelocityDriveEnabled0(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1e0); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1e0, B); } // 0x1e0:3 (Size: 0x1, Type: BoolProperty)
    void SET_bLinearVelocityDriveEnabled1(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1e0); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1e0, B); } // 0x1e0:4 (Size: 0x1, Type: BoolProperty)
    void SET_bLinearVelocityDriveEnabled2(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1e0); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x1e0, B); } // 0x1e0:5 (Size: 0x1, Type: BoolProperty)
    void SET_LinearDriveStiffness(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x18, Type: StructProperty)
    void SET_LinearDriveDamping(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x18, Type: StructProperty)
    void SET_LinearDriveMaxForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x18, Type: StructProperty)
    void SET_AngularDrivePositionTarget(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x20, Type: StructProperty)
    void SET_AngularDriveVelocityTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x18, Type: StructProperty)
    void SET_AngularDriveStiffness(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x18, Type: StructProperty)
    void SET_AngularDriveDamping(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x18, Type: StructProperty)
    void SET_AngularDriveMaxTorque(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x18, Type: StructProperty)
    void SET_LinearBreakForce(const double& Value) { Write<double>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearPlasticityLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: DoubleProperty)
    void SET_LinearPlasticityInitialDistanceSquared(const double& Value) { Write<double>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularBreakTorque(const double& Value) { Write<double>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    void SET_AngularPlasticityLimit(const double& Value) { Write<double>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    void SET_ContactTransferScale(const double& Value) { Write<double>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x3c0
struct FChaosVDJointConstraint : public FChaosVDConstraintDataWrapperBase
{
public:
    int32_t ConstraintIndex() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    FChaosVDJointStateDataWrapper PhysicsThreadJointState() const { return Read<FChaosVDJointStateDataWrapper>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FChaosVDGTJointStateDataWrapper GameThreadJointState() const { return Read<FChaosVDGTJointStateDataWrapper>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: StructProperty)
    FChaosVDJointSettingsDataWrapper JointSettings() const { return Read<FChaosVDJointSettingsDataWrapper>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x2f0, Type: StructProperty)

    void SET_ConstraintIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_PhysicsThreadJointState(const FChaosVDJointStateDataWrapper& Value) { Write<FChaosVDJointStateDataWrapper>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_GameThreadJointState(const FChaosVDGTJointStateDataWrapper& Value) { Write<FChaosVDGTJointStateDataWrapper>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: StructProperty)
    void SET_JointSettings(const FChaosVDJointSettingsDataWrapper& Value) { Write<FChaosVDJointSettingsDataWrapper>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x2f0, Type: StructProperty)
};

// Size: 0x20
struct FChaosVDFRigidParticleControlFlags : public FChaosVDWrapperDataBase
{
public:
    bool bGravityEnabled() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bCCDEnabled() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bOneWayInteractionEnabled() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)
    bool bInertiaConditioningEnabled() const { return Read<bool>(uintptr_t(this) + 0x13); } // 0x13 (Size: 0x1, Type: BoolProperty)
    int32_t GravityGroupIndex() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    bool bMACDEnabled() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bGyroscopicTorqueEnabled() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    char PositionSolverIterationCount() const { return Read<char>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: ByteProperty)
    char VelocitySolverIterationCount() const { return Read<char>(uintptr_t(this) + 0x1b); } // 0x1b (Size: 0x1, Type: ByteProperty)
    char ProjectionSolverIterationCount() const { return Read<char>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: ByteProperty)

    void SET_bGravityEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bCCDEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bOneWayInteractionEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
    void SET_bInertiaConditioningEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13, Value); } // 0x13 (Size: 0x1, Type: BoolProperty)
    void SET_GravityGroupIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_bMACDEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bGyroscopicTorqueEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_PositionSolverIterationCount(const char& Value) { Write<char>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: ByteProperty)
    void SET_VelocitySolverIterationCount(const char& Value) { Write<char>(uintptr_t(this) + 0x1b, Value); } // 0x1b (Size: 0x1, Type: ByteProperty)
    void SET_ProjectionSolverIterationCount(const char& Value) { Write<char>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FChaosVDParticlePositionRotation : public FChaosVDWrapperDataBase
{
public:
    FVector MX() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FQuat MR() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_MX(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MR(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x40
struct FChaosVDParticleVelocities : public FChaosVDWrapperDataBase
{
public:
    FVector MV() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MW() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_MV(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MW(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FChaosVDParticleBounds : public FChaosVDWrapperDataBase
{
public:
    FVector MMin() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MMax() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_MMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FChaosVDParticleDynamics : public FChaosVDWrapperDataBase
{
public:
    FVector MAcceleration() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MAngularAcceleration() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MLinearImpulseVelocity() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector MAngularImpulseVelocity() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_MAcceleration(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MAngularAcceleration(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_MLinearImpulseVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_MAngularImpulseVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FChaosVDParticleMassProps : public FChaosVDWrapperDataBase
{
public:
    FVector MCenterOfMass() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FQuat MRotationOfMass() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FVector MI() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector MInvI() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    double MM() const { return Read<double>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    double MInvM() const { return Read<double>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: DoubleProperty)

    void SET_MCenterOfMass(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MRotationOfMass(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_MI(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_MInvI(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_MM(const double& Value) { Write<double>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    void SET_MInvM(const double& Value) { Write<double>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x70
struct FChaosVDParticleDynamicMisc : public FChaosVDWrapperDataBase
{
public:
    double MLinearEtherDrag() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double MAngularEtherDrag() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double MMaxLinearSpeedSq() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    double MMaxAngularSpeedSq() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    float MInitialOverlapDepenetrationVelocity() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float MSleepThresholdMultiplier() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    int32_t MCollisionGroup() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    uint8_t MObjectState() const { return Read<uint8_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: EnumProperty)
    uint8_t MSleepType() const { return Read<uint8_t>(uintptr_t(this) + 0x3d); } // 0x3d (Size: 0x1, Type: EnumProperty)
    uint32_t MCollisionConstraintFlag() const { return Read<uint32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: UInt32Property)
    FChaosVDFRigidParticleControlFlags MControlFlags() const { return Read<FChaosVDFRigidParticleControlFlags>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)
    bool bDisabled() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_MLinearEtherDrag(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_MAngularEtherDrag(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_MMaxLinearSpeedSq(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_MMaxAngularSpeedSq(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
    void SET_MInitialOverlapDepenetrationVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_MSleepThresholdMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_MCollisionGroup(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_MObjectState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: EnumProperty)
    void SET_MSleepType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3d, Value); } // 0x3d (Size: 0x1, Type: EnumProperty)
    void SET_MCollisionConstraintFlag(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: UInt32Property)
    void SET_MControlFlags(const FChaosVDFRigidParticleControlFlags& Value) { Write<FChaosVDFRigidParticleControlFlags>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
    void SET_bDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FChaosVDConnectivityEdge
{
public:
    int32_t SiblingParticleID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float Strain() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_SiblingParticleID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Strain(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
struct FChaosVDParticleCluster : public FChaosVDWrapperDataBase
{
public:
    int32_t ParentParticleID() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t NumChildren() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    FTransform ChildToParent() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    int32_t ClusterGroupIndex() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: IntProperty)
    bool bInternalCluster() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    float CollisionImpulse() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float ExternalStrains() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    float InternalStrains() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float Strain() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    TArray<FChaosVDConnectivityEdge> ConnectivityEdges() const { return Read<TArray<FChaosVDConnectivityEdge>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bIsAnchored() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    bool bUnbreakable() const { return Read<bool>(uintptr_t(this) + 0xa9); } // 0xa9 (Size: 0x1, Type: BoolProperty)
    bool bIsChildToParentLocked() const { return Read<bool>(uintptr_t(this) + 0xaa); } // 0xaa (Size: 0x1, Type: BoolProperty)

    void SET_ParentParticleID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_NumChildren(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_ChildToParent(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_ClusterGroupIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: IntProperty)
    void SET_bInternalCluster(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_CollisionImpulse(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_ExternalStrains(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_InternalStrains(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Strain(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_ConnectivityEdges(const TArray<FChaosVDConnectivityEdge>& Value) { Write<TArray<FChaosVDConnectivityEdge>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsAnchored(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_bUnbreakable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa9, Value); } // 0xa9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsChildToParentLocked(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaa, Value); } // 0xaa (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FChaosVDKinematicTarget : public FChaosVDWrapperDataBase
{
public:
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FChaosVDVSmooth : public FChaosVDWrapperDataBase
{
public:
    FVector MV() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MW() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_MV(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_MW(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x3f0
struct FChaosVDParticleDataWrapper : public FChaosVDWrapperDataBase
{
public:
    int32_t DirtyFlagsBits() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    uint32_t GeometryHash() const { return Read<uint32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: UInt32Property)
    FString DebugName() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    int32_t SolverId() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    FChaosVDParticlePositionRotation ParticlePositionRotation() const { return Read<FChaosVDParticlePositionRotation>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: StructProperty)
    FChaosVDParticleVelocities ParticleVelocities() const { return Read<FChaosVDParticleVelocities>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x40, Type: StructProperty)
    FChaosVDParticleBounds ParticleInflatedBounds() const { return Read<FChaosVDParticleBounds>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x40, Type: StructProperty)
    FChaosVDKinematicTarget ParticleKinematicTarget() const { return Read<FChaosVDKinematicTarget>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x50, Type: StructProperty)
    FChaosVDVSmooth ParticleVWSmooth() const { return Read<FChaosVDVSmooth>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x40, Type: StructProperty)
    FChaosVDParticleDynamics ParticleDynamics() const { return Read<FChaosVDParticleDynamics>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x70, Type: StructProperty)
    FChaosVDParticleDynamicMisc ParticleDynamicsMisc() const { return Read<FChaosVDParticleDynamicMisc>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x70, Type: StructProperty)
    FChaosVDParticleMassProps ParticleMassProps() const { return Read<FChaosVDParticleMassProps>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x90, Type: StructProperty)
    FChaosVDParticleCluster ParticleCluster() const { return Read<FChaosVDParticleCluster>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0xb0, Type: StructProperty)
    TArray<FChaosVDShapeCollisionData> CollisionDataPerShape() const { return Read<TArray<FChaosVDShapeCollisionData>>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)

    void SET_DirtyFlagsBits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_GeometryHash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: UInt32Property)
    void SET_DebugName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_SolverId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_ParticlePositionRotation(const FChaosVDParticlePositionRotation& Value) { Write<FChaosVDParticlePositionRotation>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: StructProperty)
    void SET_ParticleVelocities(const FChaosVDParticleVelocities& Value) { Write<FChaosVDParticleVelocities>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x40, Type: StructProperty)
    void SET_ParticleInflatedBounds(const FChaosVDParticleBounds& Value) { Write<FChaosVDParticleBounds>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x40, Type: StructProperty)
    void SET_ParticleKinematicTarget(const FChaosVDKinematicTarget& Value) { Write<FChaosVDKinematicTarget>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x50, Type: StructProperty)
    void SET_ParticleVWSmooth(const FChaosVDVSmooth& Value) { Write<FChaosVDVSmooth>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x40, Type: StructProperty)
    void SET_ParticleDynamics(const FChaosVDParticleDynamics& Value) { Write<FChaosVDParticleDynamics>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x70, Type: StructProperty)
    void SET_ParticleDynamicsMisc(const FChaosVDParticleDynamicMisc& Value) { Write<FChaosVDParticleDynamicMisc>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x70, Type: StructProperty)
    void SET_ParticleMassProps(const FChaosVDParticleMassProps& Value) { Write<FChaosVDParticleMassProps>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x90, Type: StructProperty)
    void SET_ParticleCluster(const FChaosVDParticleCluster& Value) { Write<FChaosVDParticleCluster>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0xb0, Type: StructProperty)
    void SET_CollisionDataPerShape(const TArray<FChaosVDShapeCollisionData>& Value) { Write<TArray<FChaosVDShapeCollisionData>>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FChaosVDCollisionResponseParams : public FChaosVDWrapperDataBase
{
public:
};

// Size: 0x18
struct FChaosVDCollisionObjectQueryParams : public FChaosVDWrapperDataBase
{
public:
    char ObjectTypesToQuery() const { return Read<char>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: ByteProperty)
    char IgnoreMask() const { return Read<char>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: ByteProperty)

    void SET_ObjectTypesToQuery(const char& Value) { Write<char>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: ByteProperty)
    void SET_IgnoreMask(const char& Value) { Write<char>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x60
struct FChaosVDCollisionQueryParams : public FChaosVDWrapperDataBase
{
public:
    FName TraceTag() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName OwnerTag() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    bool bTraceComplex() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x0) & 1; } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    bool bFindInitialOverlaps() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x1) & 1; } // 0x18:1 (Size: 0x1, Type: BoolProperty)
    bool bReturnFaceIndex() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x2) & 1; } // 0x18:2 (Size: 0x1, Type: BoolProperty)
    bool bReturnPhysicalMaterial() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x3) & 1; } // 0x18:3 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreBlocks() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x4) & 1; } // 0x18:4 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreTouches() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x5) & 1; } // 0x18:5 (Size: 0x1, Type: BoolProperty)
    bool bSkipNarrowPhase() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x6) & 1; } // 0x18:6 (Size: 0x1, Type: BoolProperty)
    bool bTraceIntoSubComponents() const { return (Read<uint8_t>(uintptr_t(this) + 0x18) >> 0x7) & 1; } // 0x18:7 (Size: 0x1, Type: BoolProperty)
    bool bReplaceHitWithSubComponents() const { return (Read<uint8_t>(uintptr_t(this) + 0x19) >> 0x0) & 1; } // 0x19:0 (Size: 0x1, Type: BoolProperty)
    char IgnoreMask() const { return Read<char>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: ByteProperty)
    TArray<FName> IgnoredActorsNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> IgnoredComponentsNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_TraceTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_OwnerTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_bTraceComplex(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:0 (Size: 0x1, Type: BoolProperty)
    void SET_bFindInitialOverlaps(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:1 (Size: 0x1, Type: BoolProperty)
    void SET_bReturnFaceIndex(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:2 (Size: 0x1, Type: BoolProperty)
    void SET_bReturnPhysicalMaterial(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreBlocks(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:4 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreTouches(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:5 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipNarrowPhase(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:6 (Size: 0x1, Type: BoolProperty)
    void SET_bTraceIntoSubComponents(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x18, B); } // 0x18:7 (Size: 0x1, Type: BoolProperty)
    void SET_bReplaceHitWithSubComponents(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x19); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x19, B); } // 0x19:0 (Size: 0x1, Type: BoolProperty)
    void SET_IgnoreMask(const char& Value) { Write<char>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: ByteProperty)
    void SET_IgnoredActorsNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_IgnoredComponentsNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
struct FChaosVDQueryFastData : public FChaosVDWrapperDataBase
{
public:
    FVector Dir() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector InvDir() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    double CurrentLength() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    double InvCurrentLength() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    bool bParallel0() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x0) & 1; } // 0x50:0 (Size: 0x1, Type: BoolProperty)
    bool bParallel1() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x1) & 1; } // 0x50:1 (Size: 0x1, Type: BoolProperty)
    bool bParallel2() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x2) & 1; } // 0x50:2 (Size: 0x1, Type: BoolProperty)

    void SET_Dir(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_InvDir(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CurrentLength(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_InvCurrentLength(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_bParallel0(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:0 (Size: 0x1, Type: BoolProperty)
    void SET_bParallel1(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:1 (Size: 0x1, Type: BoolProperty)
    void SET_bParallel2(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
struct FChaosVDQueryHitData : public FChaosVDWrapperDataBase
{
public:
    float Distance() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    int32_t FaceIdx() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    uint16_t Flags() const { return Read<uint16_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x2, Type: UInt16Property)
    FVector WorldPosition() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WorldNormal() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector FaceNormal() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)

    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_FaceIdx(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_Flags(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x2, Type: UInt16Property)
    void SET_WorldPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_WorldNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_FaceNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
};

// Size: 0x150
struct FChaosVDQueryVisitStep : public FChaosVDWrapperDataBase
{
public:
    uint32_t ShapeIndex() const { return Read<uint32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: UInt32Property)
    int32_t ParticleIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    FTransform ParticleTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FChaosVDQueryFastData QueryFastData() const { return Read<FChaosVDQueryFastData>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x58, Type: StructProperty)
    FChaosVDQueryHitData HitData() const { return Read<FChaosVDQueryHitData>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x68, Type: StructProperty)

    void SET_ShapeIndex(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: UInt32Property)
    void SET_ParticleIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_ParticleTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_QueryFastData(const FChaosVDQueryFastData& Value) { Write<FChaosVDQueryFastData>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x58, Type: StructProperty)
    void SET_HitData(const FChaosVDQueryHitData& Value) { Write<FChaosVDQueryHitData>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x68, Type: StructProperty)
};

// Size: 0x170
struct FChaosVDQueryDataWrapper
{
public:
    int32_t ID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ParentQueryID() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t WorldSolverID() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    bool bIsRetryQuery() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    FQuat GeometryOrientation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FVector StartLocation() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector EndLocation() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    int32_t CollisionChannel() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    FChaosVDCollisionQueryParams CollisionQueryParams() const { return Read<FChaosVDCollisionQueryParams>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    FChaosVDCollisionResponseParams CollisionResponseParams() const { return Read<FChaosVDCollisionResponseParams>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x40, Type: StructProperty)
    FChaosVDCollisionObjectQueryParams CollisionObjectQueryParams() const { return Read<FChaosVDCollisionObjectQueryParams>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x18, Type: StructProperty)
    TArray<FChaosVDQueryVisitStep> Hits() const { return Read<TArray<FChaosVDQueryVisitStep>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x10, Type: ArrayProperty)

    void SET_ID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_ParentQueryID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_WorldSolverID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_bIsRetryQuery(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_GeometryOrientation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_StartLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_EndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_CollisionChannel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_CollisionQueryParams(const FChaosVDCollisionQueryParams& Value) { Write<FChaosVDCollisionQueryParams>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_CollisionResponseParams(const FChaosVDCollisionResponseParams& Value) { Write<FChaosVDCollisionResponseParams>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x40, Type: StructProperty)
    void SET_CollisionObjectQueryParams(const FChaosVDCollisionObjectQueryParams& Value) { Write<FChaosVDCollisionObjectQueryParams>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x18, Type: StructProperty)
    void SET_Hits(const TArray<FChaosVDQueryVisitStep>& Value) { Write<TArray<FChaosVDQueryVisitStep>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FChaosVDSceneQueriesDataContainer
{
public:
};

// Size: 0x38
struct FChaosVDTraceDetails
{
public:
    FGuid TraceGuid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid SessionGuid() const { return Read<FGuid>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FString TraceTarget() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    bool bIsConnected() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: EnumProperty)

    void SET_TraceGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_SessionGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_TraceTarget(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_bIsConnected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: EnumProperty)
};

