/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCosmetics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "DelMarCore.h"
#include "GameplayTags.h"
#include "AudioGameplayBehavior.h"
#include "Engine.h"
#include "CosmeticsFrameworkLoadouts.h"
#include "Niagara.h"
#include "AudioGameplay.h"
#include "PhysicsCore.h"
#include "AudioMotorSim.h"

// Size: 0x2a60
class ADelMarGaragePreviewVehicle : public ADelMarPreviewVehicle
{
public:
    USceneComponent* PreviewPivotComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2888); } // 0x2888 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* ActiveCameraComponent() const { return Read<UCameraComponent*>(uintptr_t(this) + 0x2898); } // 0x2898 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* DefaultZoomInCameraComponent() const { return Read<UCameraComponent*>(uintptr_t(this) + 0x28a0); } // 0x28a0 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* DefaultZoomOutCameraComponent() const { return Read<UCameraComponent*>(uintptr_t(this) + 0x28a8); } // 0x28a8 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayTag, FRotator> SlotPreviewRotations() const { return Read<TMap<FGameplayTag, FRotator>>(uintptr_t(this) + 0x2950); } // 0x2950 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, FDelMarPreviewConfigs> SlotPreviewConfigs() const { return Read<TMap<FGameplayTag, FDelMarPreviewConfigs>>(uintptr_t(this) + 0x29a0); } // 0x29a0 (Size: 0x50, Type: MapProperty)
    float ZoomLevel() const { return Read<float>(uintptr_t(this) + 0x29f0); } // 0x29f0 (Size: 0x4, Type: FloatProperty)
    FRotator UserRotationOffset() const { return Read<FRotator>(uintptr_t(this) + 0x29f8); } // 0x29f8 (Size: 0x18, Type: StructProperty)
    FGameplayTag PreviewSlot() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2a10); } // 0x2a10 (Size: 0x4, Type: StructProperty)
    FGameplayTag PreviewVehicleTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2a14); } // 0x2a14 (Size: 0x4, Type: StructProperty)
    float RotationTransitionTime() const { return Read<float>(uintptr_t(this) + 0x2a18); } // 0x2a18 (Size: 0x4, Type: FloatProperty)

    void SET_PreviewPivotComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2888, Value); } // 0x2888 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveCameraComponent(const UCameraComponent*& Value) { Write<UCameraComponent*>(uintptr_t(this) + 0x2898, Value); } // 0x2898 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultZoomInCameraComponent(const UCameraComponent*& Value) { Write<UCameraComponent*>(uintptr_t(this) + 0x28a0, Value); } // 0x28a0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultZoomOutCameraComponent(const UCameraComponent*& Value) { Write<UCameraComponent*>(uintptr_t(this) + 0x28a8, Value); } // 0x28a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SlotPreviewRotations(const TMap<FGameplayTag, FRotator>& Value) { Write<TMap<FGameplayTag, FRotator>>(uintptr_t(this) + 0x2950, Value); } // 0x2950 (Size: 0x50, Type: MapProperty)
    void SET_SlotPreviewConfigs(const TMap<FGameplayTag, FDelMarPreviewConfigs>& Value) { Write<TMap<FGameplayTag, FDelMarPreviewConfigs>>(uintptr_t(this) + 0x29a0, Value); } // 0x29a0 (Size: 0x50, Type: MapProperty)
    void SET_ZoomLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x29f0, Value); } // 0x29f0 (Size: 0x4, Type: FloatProperty)
    void SET_UserRotationOffset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x29f8, Value); } // 0x29f8 (Size: 0x18, Type: StructProperty)
    void SET_PreviewSlot(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2a10, Value); } // 0x2a10 (Size: 0x4, Type: StructProperty)
    void SET_PreviewVehicleTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2a14, Value); } // 0x2a14 (Size: 0x4, Type: StructProperty)
    void SET_RotationTransitionTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2a18, Value); } // 0x2a18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2860
class ADelMarPreviewVehicle : public AFortAthenaVehicle
{
public:
    FCosmeticLoadout PreviewLoadout() const { return Read<FCosmeticLoadout>(uintptr_t(this) + 0x2130); } // 0x2130 (Size: 0x10, Type: StructProperty)
    TArray<FDelMarPreviewCustomization> PreviewCustomizations() const { return Read<TArray<FDelMarPreviewCustomization>>(uintptr_t(this) + 0x2140); } // 0x2140 (Size: 0x10, Type: ArrayProperty)
    int32_t NumAllowedVehicleCosmeticChanges() const { return Read<int32_t>(uintptr_t(this) + 0x2150); } // 0x2150 (Size: 0x4, Type: IntProperty)
    UDelMarVehicleCosmeticComponent* CosmeticComponent() const { return Read<UDelMarVehicleCosmeticComponent*>(uintptr_t(this) + 0x2158); } // 0x2158 (Size: 0x8, Type: ObjectProperty)
    FDelMarPreviewConfigs PreviewConfigs() const { return Read<FDelMarPreviewConfigs>(uintptr_t(this) + 0x2160); } // 0x2160 (Size: 0x108, Type: StructProperty)
    TArray<float> SpringTravelOffset() const { return Read<TArray<float>>(uintptr_t(this) + 0x22f0); } // 0x22f0 (Size: 0x10, Type: ArrayProperty)
    FDelMarBouncyChassisState BouncyChassisConfig() const { return Read<FDelMarBouncyChassisState>(uintptr_t(this) + 0x2300); } // 0x2300 (Size: 0xc, Type: StructProperty)

    void SET_PreviewLoadout(const FCosmeticLoadout& Value) { Write<FCosmeticLoadout>(uintptr_t(this) + 0x2130, Value); } // 0x2130 (Size: 0x10, Type: StructProperty)
    void SET_PreviewCustomizations(const TArray<FDelMarPreviewCustomization>& Value) { Write<TArray<FDelMarPreviewCustomization>>(uintptr_t(this) + 0x2140, Value); } // 0x2140 (Size: 0x10, Type: ArrayProperty)
    void SET_NumAllowedVehicleCosmeticChanges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2150, Value); } // 0x2150 (Size: 0x4, Type: IntProperty)
    void SET_CosmeticComponent(const UDelMarVehicleCosmeticComponent*& Value) { Write<UDelMarVehicleCosmeticComponent*>(uintptr_t(this) + 0x2158, Value); } // 0x2158 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviewConfigs(const FDelMarPreviewConfigs& Value) { Write<FDelMarPreviewConfigs>(uintptr_t(this) + 0x2160, Value); } // 0x2160 (Size: 0x108, Type: StructProperty)
    void SET_SpringTravelOffset(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x22f0, Value); } // 0x22f0 (Size: 0x10, Type: ArrayProperty)
    void SET_BouncyChassisConfig(const FDelMarBouncyChassisState& Value) { Write<FDelMarBouncyChassisState>(uintptr_t(this) + 0x2300, Value); } // 0x2300 (Size: 0xc, Type: StructProperty)
};

// Size: 0x330
class ADelMarParamOverrideCosmeticActor : public ADelMarCosmeticActor
{
public:
    TMap<UClass*, FDelMarParameterOverrides> CosmeticActorsParamterOverrides() const { return Read<TMap<UClass*, FDelMarParameterOverrides>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x50, Type: MapProperty)

    void SET_CosmeticActorsParamterOverrides(const TMap<UClass*, FDelMarParameterOverrides>& Value) { Write<TMap<UClass*, FDelMarParameterOverrides>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xa90
class UDelMarPreviewCameraComponent : public UCameraComponent
{
public:
    FGameplayTag PreviewSlot() const { return Read<FGameplayTag>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x4, Type: StructProperty)
    uint8_t PreviewType() const { return Read<uint8_t>(uintptr_t(this) + 0xa84); } // 0xa84 (Size: 0x1, Type: EnumProperty)

    void SET_PreviewSlot(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x4, Type: StructProperty)
    void SET_PreviewType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa84, Value); } // 0xa84 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x2b0
class ADelMarPreviewPivot : public AActor
{
public:
    USceneComponent* SceneComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_SceneComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x5a8
class ADelMarUnifiedVehicleCosmeticActor : public ADelMarCosmeticActor
{
public:
    TArray<UNiagaraComponent*> CachedSideBoosters() const { return Read<TArray<UNiagaraComponent*>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    FName SideBoosterParam_Scale() const { return Read<FName>(uintptr_t(this) + 0x2f4); } // 0x2f4 (Size: 0x4, Type: NameProperty)
    TArray<FDelMarVehicleBooster> Boosters() const { return Read<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    FDelMarVehicleUnderthrustVfxData UnderthrustVfxData() const { return Read<FDelMarVehicleUnderthrustVfxData>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x38, Type: StructProperty)
    USkeletalMeshComponent* BodySkeletalMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    FAudioGameplayBehaviorInstance KickflipAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: StructProperty)
    FAudioGameplayBehaviorInstance JumpAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x10, Type: StructProperty)
    UNiagaraComponent* JumpFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* SuperSonicFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* SuperSonicRadialBlurMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* SuperSonicRadialBlurMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    float SuperSonicBlurOffset() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    float SuperSonicForwardSpeedMin() const { return Read<float>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    float SuperSonicForwardSpeedMax() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    FName SuperSonicParam_Spawn() const { return Read<FName>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: NameProperty)
    FName RadialBlurParam_Offset() const { return Read<FName>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: NameProperty)
    FName RadialBlurParam_Transition() const { return Read<FName>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x4, Type: NameProperty)
    FAudioGameplayBehaviorInstance DraftingAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x10, Type: StructProperty)
    UNiagaraComponent* DraftingFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    FName DraftingParam_Spawn() const { return Read<FName>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x4, Type: NameProperty)
    FName DraftingParam_SpeedGain() const { return Read<FName>(uintptr_t(this) + 0x414); } // 0x414 (Size: 0x4, Type: NameProperty)
    FName DraftingParam_Amount() const { return Read<FName>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x4, Type: NameProperty)
    FAudioGameplayBehaviorInstance WorldBonusSpeedAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x10, Type: StructProperty)
    FName WBSGroupEvent_OnBonusSpeedActivated() const { return Read<FName>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x4, Type: NameProperty)
    FName WBSGroupEvent_OnBonusSpeedDeactivated() const { return Read<FName>(uintptr_t(this) + 0x434); } // 0x434 (Size: 0x4, Type: NameProperty)
    FName WBSGroupEvent_OnWorldBonusSpeedStackGained() const { return Read<FName>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x4, Type: NameProperty)
    FGameplayTag DemolishTag_RaceFinished() const { return Read<FGameplayTag>(uintptr_t(this) + 0x43c); } // 0x43c (Size: 0x4, Type: StructProperty)
    FAudioGameplayBehaviorInstance RespawnAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x10, Type: StructProperty)
    FAudioGameplayBehaviorInstance DespawnAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: StructProperty)
    UNiagaraComponent* TaillightTrailFX_Left() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* TaillightTrailFX_Right() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    FName TaillightTrailSocket_Left() const { return Read<FName>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x4, Type: NameProperty)
    FName TaillightTrailSocket_Right() const { return Read<FName>(uintptr_t(this) + 0x474); } // 0x474 (Size: 0x4, Type: NameProperty)
    float TaillightTrail_MinForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x4, Type: FloatProperty)
    UNiagaraComponent* TeleportFx() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* TeleportEnterSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* TeleportExitSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* EnvironmentFx() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    FAudioGameplayBehaviorInstance UnderthrustAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x10, Type: StructProperty)
    FAudioGameplayBehaviorInstance WheelsAudioBehavior() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x10, Type: StructProperty)
    FName FrontLeftWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x4, Type: NameProperty)
    FName FrontRightWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x4e4); } // 0x4e4 (Size: 0x4, Type: NameProperty)
    FName BackRightWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x4, Type: NameProperty)
    FName BackLeftWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x4ec); } // 0x4ec (Size: 0x4, Type: NameProperty)
    TArray<FDelMarVehicleCosmeticWheelInfo> WheelInfos() const { return Read<TArray<FDelMarVehicleCosmeticWheelInfo>>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    float FxSideSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x4, Type: FloatProperty)
    float FxForwardSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x5a4); } // 0x5a4 (Size: 0x4, Type: FloatProperty)

    void SET_CachedSideBoosters(const TArray<UNiagaraComponent*>& Value) { Write<TArray<UNiagaraComponent*>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_SideBoosterParam_Scale(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2f4, Value); } // 0x2f4 (Size: 0x4, Type: NameProperty)
    void SET_Boosters(const TArray<FDelMarVehicleBooster>& Value) { Write<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    void SET_UnderthrustVfxData(const FDelMarVehicleUnderthrustVfxData& Value) { Write<FDelMarVehicleUnderthrustVfxData>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x38, Type: StructProperty)
    void SET_BodySkeletalMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_KickflipAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: StructProperty)
    void SET_JumpAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x10, Type: StructProperty)
    void SET_JumpFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    void SET_SuperSonicFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SuperSonicRadialBlurMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SuperSonicRadialBlurMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_SuperSonicBlurOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_SuperSonicForwardSpeedMin(const float& Value) { Write<float>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    void SET_SuperSonicForwardSpeedMax(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    void SET_SuperSonicParam_Spawn(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: NameProperty)
    void SET_RadialBlurParam_Offset(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: NameProperty)
    void SET_RadialBlurParam_Transition(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x4, Type: NameProperty)
    void SET_DraftingAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x10, Type: StructProperty)
    void SET_DraftingFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_DraftingParam_Spawn(const FName& Value) { Write<FName>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x4, Type: NameProperty)
    void SET_DraftingParam_SpeedGain(const FName& Value) { Write<FName>(uintptr_t(this) + 0x414, Value); } // 0x414 (Size: 0x4, Type: NameProperty)
    void SET_DraftingParam_Amount(const FName& Value) { Write<FName>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x4, Type: NameProperty)
    void SET_WorldBonusSpeedAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x10, Type: StructProperty)
    void SET_WBSGroupEvent_OnBonusSpeedActivated(const FName& Value) { Write<FName>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x4, Type: NameProperty)
    void SET_WBSGroupEvent_OnBonusSpeedDeactivated(const FName& Value) { Write<FName>(uintptr_t(this) + 0x434, Value); } // 0x434 (Size: 0x4, Type: NameProperty)
    void SET_WBSGroupEvent_OnWorldBonusSpeedStackGained(const FName& Value) { Write<FName>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x4, Type: NameProperty)
    void SET_DemolishTag_RaceFinished(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x43c, Value); } // 0x43c (Size: 0x4, Type: StructProperty)
    void SET_RespawnAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x10, Type: StructProperty)
    void SET_DespawnAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: StructProperty)
    void SET_TaillightTrailFX_Left(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_TaillightTrailFX_Right(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_TaillightTrailSocket_Left(const FName& Value) { Write<FName>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x4, Type: NameProperty)
    void SET_TaillightTrailSocket_Right(const FName& Value) { Write<FName>(uintptr_t(this) + 0x474, Value); } // 0x474 (Size: 0x4, Type: NameProperty)
    void SET_TaillightTrail_MinForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x4, Type: FloatProperty)
    void SET_TeleportFx(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportEnterSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportExitSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_EnvironmentFx(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_UnderthrustAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x10, Type: StructProperty)
    void SET_WheelsAudioBehavior(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x10, Type: StructProperty)
    void SET_FrontLeftWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x4, Type: NameProperty)
    void SET_FrontRightWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4e4, Value); } // 0x4e4 (Size: 0x4, Type: NameProperty)
    void SET_BackRightWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x4, Type: NameProperty)
    void SET_BackLeftWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4ec, Value); } // 0x4ec (Size: 0x4, Type: NameProperty)
    void SET_WheelInfos(const TArray<FDelMarVehicleCosmeticWheelInfo>& Value) { Write<TArray<FDelMarVehicleCosmeticWheelInfo>>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    void SET_FxSideSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x4, Type: FloatProperty)
    void SET_FxForwardSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5a4, Value); } // 0x5a4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x710
class UDelMarVehicleAnimInstance : public UFortBaseAnimInstance
{
public:
    FDelMarBouncyChassisState BouncyChassis() const { return Read<FDelMarBouncyChassisState>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0xc, Type: StructProperty)
    FDelMarBouncyChassisSetup BouncyChassisSetup() const { return Read<FDelMarBouncyChassisSetup>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x58, Type: StructProperty)
    float BouncyChassisBlendRate() const { return Read<float>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x4, Type: FloatProperty)
    float VisualSteerAngleInterpRate() const { return Read<float>(uintptr_t(this) + 0x534); } // 0x534 (Size: 0x4, Type: FloatProperty)
    float WheelLerpSpeed() const { return Read<float>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x4, Type: FloatProperty)
    float SuspensionInterpRate() const { return Read<float>(uintptr_t(this) + 0x53c); } // 0x53c (Size: 0x4, Type: FloatProperty)
    float AirSpinAccel() const { return Read<float>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x4, Type: FloatProperty)
    float AirSpinBrake() const { return Read<float>(uintptr_t(this) + 0x544); } // 0x544 (Size: 0x4, Type: FloatProperty)
    float AirSpinDecayRate() const { return Read<float>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleAnimInfo VehicleInfo() const { return Read<FDelMarVehicleAnimInfo>(uintptr_t(this) + 0x54c); } // 0x54c (Size: 0x8, Type: StructProperty)
    bool bThrottling() const { return Read<bool>(uintptr_t(this) + 0x554); } // 0x554 (Size: 0x1, Type: BoolProperty)
    bool bReversing() const { return Read<bool>(uintptr_t(this) + 0x555); } // 0x555 (Size: 0x1, Type: BoolProperty)
    bool bAccelerating() const { return Read<bool>(uintptr_t(this) + 0x556); } // 0x556 (Size: 0x1, Type: BoolProperty)
    bool bBraking() const { return Read<bool>(uintptr_t(this) + 0x557); } // 0x557 (Size: 0x1, Type: BoolProperty)
    float Throttle() const { return Read<float>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x4, Type: FloatProperty)
    float Steering() const { return Read<float>(uintptr_t(this) + 0x55c); } // 0x55c (Size: 0x4, Type: FloatProperty)
    float SteeringAngle() const { return Read<float>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x4, Type: FloatProperty)
    bool bWheelsOnGround() const { return Read<bool>(uintptr_t(this) + 0x564); } // 0x564 (Size: 0x1, Type: BoolProperty)
    float ForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x4, Type: FloatProperty)
    bool bDriftBoostActive() const { return Read<bool>(uintptr_t(this) + 0x56c); } // 0x56c (Size: 0x1, Type: BoolProperty)
    bool bUnderthrustActive() const { return Read<bool>(uintptr_t(this) + 0x56d); } // 0x56d (Size: 0x1, Type: BoolProperty)
    bool bDriftActive() const { return Read<bool>(uintptr_t(this) + 0x56e); } // 0x56e (Size: 0x1, Type: BoolProperty)
    bool bKickflipActive() const { return Read<bool>(uintptr_t(this) + 0x56f); } // 0x56f (Size: 0x1, Type: BoolProperty)
    bool bJumpActive() const { return Read<bool>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x1, Type: BoolProperty)
    bool bTurboActive() const { return Read<bool>(uintptr_t(this) + 0x571); } // 0x571 (Size: 0x1, Type: BoolProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFR() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x574); } // 0x574 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFL() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBR() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x5ac); } // 0x5ac (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBL() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x1c, Type: StructProperty)

    void SET_BouncyChassis(const FDelMarBouncyChassisState& Value) { Write<FDelMarBouncyChassisState>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0xc, Type: StructProperty)
    void SET_BouncyChassisSetup(const FDelMarBouncyChassisSetup& Value) { Write<FDelMarBouncyChassisSetup>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x58, Type: StructProperty)
    void SET_BouncyChassisBlendRate(const float& Value) { Write<float>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x4, Type: FloatProperty)
    void SET_VisualSteerAngleInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x534, Value); } // 0x534 (Size: 0x4, Type: FloatProperty)
    void SET_WheelLerpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x4, Type: FloatProperty)
    void SET_SuspensionInterpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x53c, Value); } // 0x53c (Size: 0x4, Type: FloatProperty)
    void SET_AirSpinAccel(const float& Value) { Write<float>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x4, Type: FloatProperty)
    void SET_AirSpinBrake(const float& Value) { Write<float>(uintptr_t(this) + 0x544, Value); } // 0x544 (Size: 0x4, Type: FloatProperty)
    void SET_AirSpinDecayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleInfo(const FDelMarVehicleAnimInfo& Value) { Write<FDelMarVehicleAnimInfo>(uintptr_t(this) + 0x54c, Value); } // 0x54c (Size: 0x8, Type: StructProperty)
    void SET_bThrottling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x554, Value); } // 0x554 (Size: 0x1, Type: BoolProperty)
    void SET_bReversing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x555, Value); } // 0x555 (Size: 0x1, Type: BoolProperty)
    void SET_bAccelerating(const bool& Value) { Write<bool>(uintptr_t(this) + 0x556, Value); } // 0x556 (Size: 0x1, Type: BoolProperty)
    void SET_bBraking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x557, Value); } // 0x557 (Size: 0x1, Type: BoolProperty)
    void SET_Throttle(const float& Value) { Write<float>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x4, Type: FloatProperty)
    void SET_Steering(const float& Value) { Write<float>(uintptr_t(this) + 0x55c, Value); } // 0x55c (Size: 0x4, Type: FloatProperty)
    void SET_SteeringAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x4, Type: FloatProperty)
    void SET_bWheelsOnGround(const bool& Value) { Write<bool>(uintptr_t(this) + 0x564, Value); } // 0x564 (Size: 0x1, Type: BoolProperty)
    void SET_ForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x4, Type: FloatProperty)
    void SET_bDriftBoostActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x56c, Value); } // 0x56c (Size: 0x1, Type: BoolProperty)
    void SET_bUnderthrustActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x56d, Value); } // 0x56d (Size: 0x1, Type: BoolProperty)
    void SET_bDriftActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x56e, Value); } // 0x56e (Size: 0x1, Type: BoolProperty)
    void SET_bKickflipActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x56f, Value); } // 0x56f (Size: 0x1, Type: BoolProperty)
    void SET_bJumpActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x1, Type: BoolProperty)
    void SET_bTurboActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x571, Value); } // 0x571 (Size: 0x1, Type: BoolProperty)
    void SET_WheelInfoFR(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x574, Value); } // 0x574 (Size: 0x1c, Type: StructProperty)
    void SET_WheelInfoFL(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x1c, Type: StructProperty)
    void SET_WheelInfoBR(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x5ac, Value); } // 0x5ac (Size: 0x1c, Type: StructProperty)
    void SET_WheelInfoBL(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x1c, Type: StructProperty)
};

// Size: 0x4f0
class UDelMarWheelAnimInstance : public UFortBaseAnimInstance
{
public:
    float SpinDegrees() const { return Read<float>(uintptr_t(this) + 0x4e4); } // 0x4e4 (Size: 0x4, Type: FloatProperty)
    UDelMarVehicleAnimInstance* ParentAnimInstance() const { return Read<UDelMarVehicleAnimInstance*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_SpinDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x4e4, Value); } // 0x4e4 (Size: 0x4, Type: FloatProperty)
    void SET_ParentAnimInstance(const UDelMarVehicleAnimInstance*& Value) { Write<UDelMarVehicleAnimInstance*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x378
class ADelMarBodyCosmeticActor : public ADelMarCosmeticActor
{
public:
    TArray<FDelMarVehicleWheelSetup> FrontLeftWheelsBoneNames() const { return Read<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleWheelSetup> FrontRightWheelsBoneNames() const { return Read<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleWheelSetup> BackRightWheelsBoneNames() const { return Read<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleWheelSetup> BackLeftWheelsBoneNames() const { return Read<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleBooster> LeftBoostersInfo() const { return Read<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleBooster> RightBoostersInfo() const { return Read<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: ArrayProperty)
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UClass* AnimInstanceClass() const { return Read<UClass*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ClassProperty)
    UDelMarVehicleBodySetup* BodySetup() const { return Read<UDelMarVehicleBodySetup*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    FVector WheelContactFxOffset() const { return Read<FVector>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x18, Type: StructProperty)

    void SET_FrontLeftWheelsBoneNames(const TArray<FDelMarVehicleWheelSetup>& Value) { Write<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_FrontRightWheelsBoneNames(const TArray<FDelMarVehicleWheelSetup>& Value) { Write<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    void SET_BackRightWheelsBoneNames(const TArray<FDelMarVehicleWheelSetup>& Value) { Write<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    void SET_BackLeftWheelsBoneNames(const TArray<FDelMarVehicleWheelSetup>& Value) { Write<TArray<FDelMarVehicleWheelSetup>>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x10, Type: ArrayProperty)
    void SET_LeftBoostersInfo(const TArray<FDelMarVehicleBooster>& Value) { Write<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    void SET_RightBoostersInfo(const TArray<FDelMarVehicleBooster>& Value) { Write<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimInstanceClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ClassProperty)
    void SET_BodySetup(const UDelMarVehicleBodySetup*& Value) { Write<UDelMarVehicleBodySetup*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_WheelContactFxOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x18, Type: StructProperty)
};

// Size: 0x310
class ADelMarBoosterCosmeticActor : public ADelMarCosmeticActor
{
public:
    UNiagaraSystem* BoosterFx() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarVehicleBooster> LeftBoosters() const { return Read<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleBooster> RightBoosters() const { return Read<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    USkeletalMeshComponent* BodySkeletalMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)

    void SET_BoosterFx(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftBoosters(const TArray<FDelMarVehicleBooster>& Value) { Write<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    void SET_RightBoosters(const TArray<FDelMarVehicleBooster>& Value) { Write<TArray<FDelMarVehicleBooster>>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    void SET_BodySkeletalMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x328
class ADelMarEngineAudioCosmeticActor : public ADelMarCosmeticActor
{
public:
    FAudioGameplayBehaviorInstance EngineAudio() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: StructProperty)
    float NonLocalVelocityInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    bool bDisabled() const { return Read<bool>(uintptr_t(this) + 0x2f4); } // 0x2f4 (Size: 0x1, Type: BoolProperty)
    UAudioComponentGroup* ComponentGroup() const { return Read<UAudioComponentGroup*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UAudioMotorModelComponent* MotorModel() const { return Read<UAudioMotorModelComponent*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)

    void SET_EngineAudio(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: StructProperty)
    void SET_NonLocalVelocityInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    void SET_bDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f4, Value); } // 0x2f4 (Size: 0x1, Type: BoolProperty)
    void SET_ComponentGroup(const UAudioComponentGroup*& Value) { Write<UAudioComponentGroup*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_MotorModel(const UAudioMotorModelComponent*& Value) { Write<UAudioMotorModelComponent*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3c0
class ADelMarWheelContactFxCosmeticActor : public ADelMarCosmeticActor
{
public:
    FAudioGameplayBehaviorInstance WheelSounds() const { return Read<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: StructProperty)
    float FxSideSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    float FxForwardSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x2f4); } // 0x2f4 (Size: 0x4, Type: FloatProperty)
    UPhysicalMaterial* ContactMaterial() const { return Read<UPhysicalMaterial*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarVehicleCosmeticWheelInfo> WheelInfos() const { return Read<TArray<FDelMarVehicleCosmeticWheelInfo>>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    FName FrontLeftWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x4, Type: NameProperty)
    FName FrontRightWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x31c); } // 0x31c (Size: 0x4, Type: NameProperty)
    FName BackRightWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x4, Type: NameProperty)
    FName BackLeftWheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x324); } // 0x324 (Size: 0x4, Type: NameProperty)

    void SET_WheelSounds(const FAudioGameplayBehaviorInstance& Value) { Write<FAudioGameplayBehaviorInstance>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: StructProperty)
    void SET_FxSideSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x4, Type: FloatProperty)
    void SET_FxForwardSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x2f4, Value); } // 0x2f4 (Size: 0x4, Type: FloatProperty)
    void SET_ContactMaterial(const UPhysicalMaterial*& Value) { Write<UPhysicalMaterial*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_WheelInfos(const TArray<FDelMarVehicleCosmeticWheelInfo>& Value) { Write<TArray<FDelMarVehicleCosmeticWheelInfo>>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    void SET_FrontLeftWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x4, Type: NameProperty)
    void SET_FrontRightWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x31c, Value); } // 0x31c (Size: 0x4, Type: NameProperty)
    void SET_BackRightWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x4, Type: NameProperty)
    void SET_BackLeftWheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x324, Value); } // 0x324 (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
class UDelMarCosmeticActorSpawnLogic_Wheel : public UDelMarCosmeticActorSpawnLogic
{
public:
    bool bFrontWheel() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bBackWheel() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t AttachPoint() const { return Read<uint8_t>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: EnumProperty)
    uint8_t MirrorType() const { return Read<uint8_t>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: EnumProperty)
    bool bOnlyFxEligibleWheels() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_bFrontWheel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bBackWheel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_AttachPoint(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: EnumProperty)
    void SET_MirrorType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: EnumProperty)
    void SET_bOnlyFxEligibleWheels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2e8
class ADelMarWheelsCosmeticActor : public ADelMarCosmeticActor
{
public:
    uint8_t WheelIndex() const { return Read<uint8_t>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x1, Type: EnumProperty)

    void SET_WheelIndex(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x2f0
class ADelMarWheelSKCosmeticActor : public ADelMarWheelsCosmeticActor
{
public:
    USkeletalMeshComponent* SkeletalMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)

    void SET_SkeletalMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarVehicleAnimInfo
{
public:
    float SteerAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float VisualSteerAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_SteerAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_VisualSteerAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1c
struct FDelMarVehicleWheelAnimInfo
{
public:
    float SpringToWheelOffsetZ() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FFloatInterval SpringTravelRange() const { return Read<FFloatInterval>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: StructProperty)
    float WheelRadius() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float TravelDistance() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float SpinSpeedDegrees() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float SpinDegrees() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_SpringToWheelOffsetZ(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SpringTravelRange(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: StructProperty)
    void SET_WheelRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_TravelDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SpinSpeedDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_SpinDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDelMarVehicleBooster
{
public:
    UNiagaraSystem* BoosterSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NiagaraComponent() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName BoosterSocket() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    char BitFlags() const { return Read<char>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: ByteProperty)

    void SET_BoosterSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_NiagaraComponent(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_BoosterSocket(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_BitFlags(const char& Value) { Write<char>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x8
struct FDelMarVehicleUnderthrustSocket
{
public:
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    char SideFlags() const { return Read<char>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: ByteProperty)

    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_SideFlags(const char& Value) { Write<char>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x38
struct FDelMarVehicleUnderthrustVfxData
{
public:
    UNiagaraSystem* UnderthrustVfxSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NiagaraComponent() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName NiagaraLocationArrayParam() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName NiagaraActivationsArrayParam() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    TArray<FDelMarVehicleUnderthrustSocket> Sockets() const { return Read<TArray<FDelMarVehicleUnderthrustSocket>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_UnderthrustVfxSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_NiagaraComponent(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_NiagaraLocationArrayParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_NiagaraActivationsArrayParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Sockets(const TArray<FDelMarVehicleUnderthrustSocket>& Value) { Write<TArray<FDelMarVehicleUnderthrustSocket>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FDelMarVehicleWheelSetup
{
public:
    FName WheelSpinBone() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName WheelPivotBone() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName WheelContactBone() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    bool bEligibleForPhysMatContactFx() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_WheelSpinBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_WheelPivotBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_WheelContactBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_bEligibleForPhysMatContactFx(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FDelMarVehicleCosmeticWheelInfo
{
public:
    UNiagaraComponent* ContactParticleComponent() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* ContactParticle() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UPhysicalMaterial* ContactMaterial() const { return Read<UPhysicalMaterial*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t WheelIndex() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    FDelMarVehicleWheelSetup Setup() const { return Read<FDelMarVehicleWheelSetup>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x10, Type: StructProperty)

    void SET_ContactParticleComponent(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ContactParticle(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ContactMaterial(const UPhysicalMaterial*& Value) { Write<UPhysicalMaterial*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_WheelIndex(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_Setup(const FDelMarVehicleWheelSetup& Value) { Write<FDelMarVehicleWheelSetup>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FDelMarOverrideParameter_Bool
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FDelMarOverrideParameter_Int
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FDelMarOverrideParameter_Float
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FDelMarOverrideParameter_Vector
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x14
struct FDelMarOverrideParameter_Color
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FLinearColor Value() const { return Read<FLinearColor>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FDelMarOverrideParameter_Texture
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UTexture* Value() const { return Read<UTexture*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FDelMarOverrideParameter_StaticMesh
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UStaticMesh* Value() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FDelMarOverrideParameter_Actor
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    AActor* Value() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FDelMarOverrideParameter_Material
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UMaterialInterface* Value() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
struct FDelMarMaterialParameterCollection
{
public:
    TArray<FDelMarOverrideParameter_Float> OverrideFloatParameters() const { return Read<TArray<FDelMarOverrideParameter_Float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Vector> OverrideVectorParameters() const { return Read<TArray<FDelMarOverrideParameter_Vector>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Texture> OverrideTextureParameters() const { return Read<TArray<FDelMarOverrideParameter_Texture>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_OverrideFloatParameters(const TArray<FDelMarOverrideParameter_Float>& Value) { Write<TArray<FDelMarOverrideParameter_Float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideVectorParameters(const TArray<FDelMarOverrideParameter_Vector>& Value) { Write<TArray<FDelMarOverrideParameter_Vector>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideTextureParameters(const TArray<FDelMarOverrideParameter_Texture>& Value) { Write<TArray<FDelMarOverrideParameter_Texture>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
struct FDelMarNiagaraParameterCollection
{
public:
    UNiagaraSystem* OverrideNiagaraSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarOverrideParameter_Bool> OverrideBoolParameters() const { return Read<TArray<FDelMarOverrideParameter_Bool>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Int> OverrideIntParameters() const { return Read<TArray<FDelMarOverrideParameter_Int>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Float> OverrideFloatParameters() const { return Read<TArray<FDelMarOverrideParameter_Float>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Vector> OverrideVectorParameters() const { return Read<TArray<FDelMarOverrideParameter_Vector>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Color> OverrideColorParameters() const { return Read<TArray<FDelMarOverrideParameter_Color>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Texture> OverrideTextureParameters() const { return Read<TArray<FDelMarOverrideParameter_Texture>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Material> OverrideMaterialsParameters() const { return Read<TArray<FDelMarOverrideParameter_Material>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_StaticMesh> OverrideStaticMeshParameters() const { return Read<TArray<FDelMarOverrideParameter_StaticMesh>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Actor> OverrideActorParameters() const { return Read<TArray<FDelMarOverrideParameter_Actor>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_OverrideNiagaraSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideBoolParameters(const TArray<FDelMarOverrideParameter_Bool>& Value) { Write<TArray<FDelMarOverrideParameter_Bool>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideIntParameters(const TArray<FDelMarOverrideParameter_Int>& Value) { Write<TArray<FDelMarOverrideParameter_Int>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideFloatParameters(const TArray<FDelMarOverrideParameter_Float>& Value) { Write<TArray<FDelMarOverrideParameter_Float>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideVectorParameters(const TArray<FDelMarOverrideParameter_Vector>& Value) { Write<TArray<FDelMarOverrideParameter_Vector>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideColorParameters(const TArray<FDelMarOverrideParameter_Color>& Value) { Write<TArray<FDelMarOverrideParameter_Color>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideTextureParameters(const TArray<FDelMarOverrideParameter_Texture>& Value) { Write<TArray<FDelMarOverrideParameter_Texture>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideMaterialsParameters(const TArray<FDelMarOverrideParameter_Material>& Value) { Write<TArray<FDelMarOverrideParameter_Material>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideStaticMeshParameters(const TArray<FDelMarOverrideParameter_StaticMesh>& Value) { Write<TArray<FDelMarOverrideParameter_StaticMesh>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideActorParameters(const TArray<FDelMarOverrideParameter_Actor>& Value) { Write<TArray<FDelMarOverrideParameter_Actor>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FDelMarMaterialOverrides
{
public:
    int32_t MaterialInstanceDynamicIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    UMaterialInterface* MaterialInterface() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FDelMarMaterialParameterCollection ParameterOverrides() const { return Read<FDelMarMaterialParameterCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x30, Type: StructProperty)

    void SET_MaterialInstanceDynamicIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_MaterialInterface(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ParameterOverrides(const FDelMarMaterialParameterCollection& Value) { Write<FDelMarMaterialParameterCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x30, Type: StructProperty)
};

// Size: 0x98
struct FDelMarNiagaraOverrides
{
public:
    FDelMarNiagaraParameterCollection ParameterOverrides() const { return Read<FDelMarNiagaraParameterCollection>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x98, Type: StructProperty)

    void SET_ParameterOverrides(const FDelMarNiagaraParameterCollection& Value) { Write<FDelMarNiagaraParameterCollection>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x98, Type: StructProperty)
};

// Size: 0x20
struct FDelMarParameterOverrides
{
public:
    TArray<FDelMarMaterialOverrides> MaterialOverrides() const { return Read<TArray<FDelMarMaterialOverrides>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarNiagaraOverrides> NiagaraOverrides() const { return Read<TArray<FDelMarNiagaraOverrides>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_MaterialOverrides(const TArray<FDelMarMaterialOverrides>& Value) { Write<TArray<FDelMarMaterialOverrides>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_NiagaraOverrides(const TArray<FDelMarNiagaraOverrides>& Value) { Write<TArray<FDelMarNiagaraOverrides>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x24
struct FDelMarVehicleController_WheelData
{
public:
    FBoneReference SuspensionBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference SteeringBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    FBoneReference RollBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)

    void SET_SuspensionBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_SteeringBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_RollBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
};

// Size: 0x1e8
struct FDelMarAnimNode_VehicleController : public FAnimNode_SkeletalControlBase
{
public:
    FDelMarBouncyChassisState BouncyChassis() const { return Read<FDelMarBouncyChassisState>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleController_WheelData FrontLeftWheel() const { return Read<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x24, Type: StructProperty)
    FDelMarVehicleController_WheelData FrontRightWheel() const { return Read<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x24, Type: StructProperty)
    FDelMarVehicleController_WheelData BackLeftWheel() const { return Read<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x24, Type: StructProperty)
    FDelMarVehicleController_WheelData BackRightWheel() const { return Read<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x24, Type: StructProperty)
    FBoneReference ChassisBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleAnimInfo VehicleInfo() const { return Read<FDelMarVehicleAnimInfo>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFR() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFL() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBR() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBL() const { return Read<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x1c, Type: StructProperty)

    void SET_BouncyChassis(const FDelMarBouncyChassisState& Value) { Write<FDelMarBouncyChassisState>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_FrontLeftWheel(const FDelMarVehicleController_WheelData& Value) { Write<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x24, Type: StructProperty)
    void SET_FrontRightWheel(const FDelMarVehicleController_WheelData& Value) { Write<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x24, Type: StructProperty)
    void SET_BackLeftWheel(const FDelMarVehicleController_WheelData& Value) { Write<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x24, Type: StructProperty)
    void SET_BackRightWheel(const FDelMarVehicleController_WheelData& Value) { Write<FDelMarVehicleController_WheelData>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x24, Type: StructProperty)
    void SET_ChassisBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0xc, Type: StructProperty)
    void SET_VehicleInfo(const FDelMarVehicleAnimInfo& Value) { Write<FDelMarVehicleAnimInfo>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: StructProperty)
    void SET_WheelInfoFR(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1c, Type: StructProperty)
    void SET_WheelInfoFL(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x1c, Type: StructProperty)
    void SET_WheelInfoBR(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x1c, Type: StructProperty)
    void SET_WheelInfoBL(const FDelMarVehicleWheelAnimInfo& Value) { Write<FDelMarVehicleWheelAnimInfo>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x1c, Type: StructProperty)
};

// Size: 0xc
struct FDelMarBouncyChassisState
{
public:
    float PitchDegrees() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float RollDegrees() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float TranslationZ() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_PitchDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_RollDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TranslationZ(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FDelMarBoxSpringSetup
{
public:
    FVector Strength() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Damping() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector MaxDisplacement() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float MaxSpeed() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)

    void SET_Strength(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Damping(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_MaxDisplacement(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_MaxSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
struct FDelMarBoxSpring
{
public:
    FDelMarBoxSpringSetup Setup() const { return Read<FDelMarBoxSpringSetup>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: StructProperty)

    void SET_Setup(const FDelMarBoxSpringSetup& Value) { Write<FDelMarBoxSpringSetup>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: StructProperty)
};

// Size: 0x8
struct FDelMarSpringSettings
{
public:
    float Strength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Damping() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Damping(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
struct FDelMarBouncyChassisSetup
{
public:
    FDelMarSpringSettings PitchSpring() const { return Read<FDelMarSpringSettings>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float PitchMaxAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FDelMarSpringSettings RollSpring() const { return Read<FDelMarSpringSettings>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x8, Type: StructProperty)
    float RollMaxAngleDegrees() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FDelMarSpringSettings ZSpring() const { return Read<FDelMarSpringSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    float ZMaxDrop() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float ZMaxRaise() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    FVector MaxDisplacement() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MassOffset() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_PitchSpring(const FDelMarSpringSettings& Value) { Write<FDelMarSpringSettings>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_PitchMaxAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_RollSpring(const FDelMarSpringSettings& Value) { Write<FDelMarSpringSettings>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x8, Type: StructProperty)
    void SET_RollMaxAngleDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_ZSpring(const FDelMarSpringSettings& Value) { Write<FDelMarSpringSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_ZMaxDrop(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_ZMaxRaise(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDisplacement(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_MassOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x118
struct FDelMarBouncyChassisInstance
{
public:
    FDelMarBoxSpring Spring() const { return Read<FDelMarBoxSpring>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xb0, Type: StructProperty)

    void SET_Spring(const FDelMarBoxSpring& Value) { Write<FDelMarBoxSpring>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x108
struct FDelMarPreviewConfigs
{
public:
    bool bAnyWheelsOnGround() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWheelsOnGround() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    float ForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float SideSpeed() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Acceleration() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Throttle() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Steering() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float SteerAngle() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float TargetSpeed() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float BaseTargetSpeed() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float NormalizedForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float NormalizedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t VehicleForwardState() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)
    float BonusSpeed() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float WorldAppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleLandingData LandingData() const { return Read<FDelMarVehicleLandingData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0xc, Type: StructProperty)
    bool bLanded() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    bool bSkydiving() const { return Read<bool>(uintptr_t(this) + 0x45); } // 0x45 (Size: 0x1, Type: BoolProperty)
    uint8_t DriftState() const { return Read<uint8_t>(uintptr_t(this) + 0x46); } // 0x46 (Size: 0x1, Type: EnumProperty)
    bool bDriftControlled() const { return Read<bool>(uintptr_t(this) + 0x47); } // 0x47 (Size: 0x1, Type: BoolProperty)
    float DriftAngle() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float DriftSlipAngleRatio() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float DriftTargetSide() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float DriftDuration() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    bool bDriftBoostInRange() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    bool bDriftBoostLosingAppliedBonusSpeed() const { return Read<bool>(uintptr_t(this) + 0x59); } // 0x59 (Size: 0x1, Type: BoolProperty)
    float DriftBoostPotentialPercentage() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float DriftBoostAppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float DriftBoostQueuedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float DraftingAppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float DraftingMaxBonusSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float DraftingTargetDegrees() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float DraftingCurrentBonusSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bHasValidDraftingTarget() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t DraftingState() const { return Read<uint8_t>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: EnumProperty)
    float OversteerAccumulationPercentage() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    bool bStartlineBoostActive() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)
    bool bFailedStartlineBoost() const { return Read<bool>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: BoolProperty)
    float PercentageMaxBonusSpeedEarned() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float StartlineBoostAppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float MaxEarnedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bLeftStrafe() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bStrafeActive() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)
    bool bStrafeDisabled() const { return Read<bool>(uintptr_t(this) + 0x92); } // 0x92 (Size: 0x1, Type: BoolProperty)
    bool bCanStrafeBeActivated() const { return Read<bool>(uintptr_t(this) + 0x93); } // 0x93 (Size: 0x1, Type: BoolProperty)
    float StrafeCooldownPercentage() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    bool bTurboActive() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    float NumCurrentCharges() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float NumMaxCharges() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t BonusZoneState() const { return Read<uint8_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    float PercentageTurboActiveTimeRemaining() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float RemainingTurboActiveSeconds() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    float TurboAppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    float TurboBonusZoneBonusSpeed() const { return Read<float>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    float TurboAdditionalActiveSeconds() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    bool bKickflipActive() const { return Read<bool>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x1, Type: BoolProperty)
    bool bKickflipLeftSide() const { return Read<bool>(uintptr_t(this) + 0xbd); } // 0xbd (Size: 0x1, Type: BoolProperty)
    bool bKickflipSuctionActive() const { return Read<bool>(uintptr_t(this) + 0xbe); } // 0xbe (Size: 0x1, Type: BoolProperty)
    float DistanceToSuctionSurface() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float KickflipDuration() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    int32_t KickflipActivationCharges() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)
    bool bReattachmentActive() const { return Read<bool>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: BoolProperty)
    FVector ReattachmentDirection() const { return Read<FVector>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    bool bUnderthrustActive() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    float UnderthrustPercentageTankRemaining() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float UnderthrustActiveDuration() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    bool bJumpActive() const { return Read<bool>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x1, Type: BoolProperty)
    bool bAirFreestyleActive() const { return Read<bool>(uintptr_t(this) + 0xf5); } // 0xf5 (Size: 0x1, Type: BoolProperty)
    bool bVehicleDemolished() const { return Read<bool>(uintptr_t(this) + 0xf6); } // 0xf6 (Size: 0x1, Type: BoolProperty)
    FGameplayTag DemolishCausedByTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: StructProperty)
    bool bInvulnerabilityActive() const { return Read<bool>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x1, Type: BoolProperty)
    bool bVehicleSpawnedThisFrame() const { return Read<bool>(uintptr_t(this) + 0xfd); } // 0xfd (Size: 0x1, Type: BoolProperty)
    bool bFirstVehicleForPlayer() const { return Read<bool>(uintptr_t(this) + 0xfe); } // 0xfe (Size: 0x1, Type: BoolProperty)
    bool bPreviousVehicleDemolished() const { return Read<bool>(uintptr_t(this) + 0xff); } // 0xff (Size: 0x1, Type: BoolProperty)
    bool bHeadlightsActive() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_bAnyWheelsOnGround(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bWheelsOnGround(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_ForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_SideSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Acceleration(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Throttle(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Steering(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_SteerAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_TargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_BaseTargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_NormalizedForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_NormalizedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_VehicleForwardState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
    void SET_BonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_WorldAppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_LandingData(const FDelMarVehicleLandingData& Value) { Write<FDelMarVehicleLandingData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0xc, Type: StructProperty)
    void SET_bLanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_bSkydiving(const bool& Value) { Write<bool>(uintptr_t(this) + 0x45, Value); } // 0x45 (Size: 0x1, Type: BoolProperty)
    void SET_DriftState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x46, Value); } // 0x46 (Size: 0x1, Type: EnumProperty)
    void SET_bDriftControlled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x47, Value); } // 0x47 (Size: 0x1, Type: BoolProperty)
    void SET_DriftAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_DriftSlipAngleRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_DriftTargetSide(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_DriftDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_bDriftBoostInRange(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_bDriftBoostLosingAppliedBonusSpeed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x59, Value); } // 0x59 (Size: 0x1, Type: BoolProperty)
    void SET_DriftBoostPotentialPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostAppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostQueuedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_DraftingAppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_DraftingMaxBonusSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_DraftingTargetDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_DraftingCurrentBonusSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_bHasValidDraftingTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_DraftingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: EnumProperty)
    void SET_OversteerAccumulationPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_bStartlineBoostActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
    void SET_bFailedStartlineBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: BoolProperty)
    void SET_PercentageMaxBonusSpeedEarned(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_StartlineBoostAppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_MaxEarnedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_bLeftStrafe(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bStrafeActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
    void SET_bStrafeDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x92, Value); } // 0x92 (Size: 0x1, Type: BoolProperty)
    void SET_bCanStrafeBeActivated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x93, Value); } // 0x93 (Size: 0x1, Type: BoolProperty)
    void SET_StrafeCooldownPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_bTurboActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_NumCurrentCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_NumMaxCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_BonusZoneState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    void SET_PercentageTurboActiveTimeRemaining(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_RemainingTurboActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_TurboAppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_TurboBonusZoneBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: FloatProperty)
    void SET_TurboAdditionalActiveSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_bKickflipActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x1, Type: BoolProperty)
    void SET_bKickflipLeftSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbd, Value); } // 0xbd (Size: 0x1, Type: BoolProperty)
    void SET_bKickflipSuctionActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbe, Value); } // 0xbe (Size: 0x1, Type: BoolProperty)
    void SET_DistanceToSuctionSurface(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_KickflipDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_KickflipActivationCharges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
    void SET_bReattachmentActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: BoolProperty)
    void SET_ReattachmentDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_bUnderthrustActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_UnderthrustPercentageTankRemaining(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_UnderthrustActiveDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_bJumpActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x1, Type: BoolProperty)
    void SET_bAirFreestyleActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf5, Value); } // 0xf5 (Size: 0x1, Type: BoolProperty)
    void SET_bVehicleDemolished(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf6, Value); } // 0xf6 (Size: 0x1, Type: BoolProperty)
    void SET_DemolishCausedByTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: StructProperty)
    void SET_bInvulnerabilityActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x1, Type: BoolProperty)
    void SET_bVehicleSpawnedThisFrame(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfd, Value); } // 0xfd (Size: 0x1, Type: BoolProperty)
    void SET_bFirstVehicleForPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfe, Value); } // 0xfe (Size: 0x1, Type: BoolProperty)
    void SET_bPreviousVehicleDemolished(const bool& Value) { Write<bool>(uintptr_t(this) + 0xff, Value); } // 0xff (Size: 0x1, Type: BoolProperty)
    void SET_bHeadlightsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FDelMarPreviousPreviewConfigs
{
public:
};

// Size: 0x18
struct FDelMarPreviewCustomization
{
public:
    FGameplayTag SlotTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<FCosmeticCustomizationInfo> CustomizationInfo() const { return Read<TArray<FCosmeticCustomizationInfo>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_SlotTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_CustomizationInfo(const TArray<FCosmeticCustomizationInfo>& Value) { Write<TArray<FCosmeticCustomizationInfo>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

