/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeltaFileSystem
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x30
class UDeltaFileSaveHandlerTestContext : public UObject
{
public:
    UDeltaFileSaveHandler* SaveHandler() const { return Read<UDeltaFileSaveHandler*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_SaveHandler(const UDeltaFileSaveHandler*& Value) { Write<UDeltaFileSaveHandler*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UDeltaFile : public UInterface
{
public:
};

// Size: 0x28
class UDeltaFileApplier : public UInterface
{
public:
};

// Size: 0xc8
class UDeltaComponent : public UActorComponent
{
public:
};

// Size: 0x120
class UDeltaFileSaveHandler : public UObject
{
public:
};

// Size: 0xe8
class UDeltaFileSubsystem : public UEngineSubsystem
{
public:
    TMap<UWorld*, FDeltaTrackingHandles> WorldToTrackingHandles() const { return Read<TMap<UWorld*, FDeltaTrackingHandles>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<FName, UObject*> DeltaFiles() const { return Read<TMap<FName, UObject*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)
    FSoftClassPath DefaultDeltaFileClass() const { return Read<FSoftClassPath>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)

    void SET_WorldToTrackingHandles(const TMap<UWorld*, FDeltaTrackingHandles>& Value) { Write<TMap<UWorld*, FDeltaTrackingHandles>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_DeltaFiles(const TMap<FName, UObject*>& Value) { Write<TMap<FName, UObject*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
    void SET_DefaultDeltaFileClass(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xf0
class UMapDelta : public UObject
{
public:
    FString PackageToApplyTo() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    TMap<FGuid, FAddAction> AddActions() const { return Read<TMap<FGuid, FAddAction>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: MapProperty)
    TArray<FUpdateAction> UpdateActions() const { return Read<TArray<FUpdateAction>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TMap<FGuid, FDeleteAction> DeleteActions() const { return Read<TMap<FGuid, FDeleteAction>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)

    void SET_PackageToApplyTo(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_AddActions(const TMap<FGuid, FAddAction>& Value) { Write<TMap<FGuid, FAddAction>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: MapProperty)
    void SET_UpdateActions(const TArray<FUpdateAction>& Value) { Write<TArray<FUpdateAction>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_DeleteActions(const TMap<FGuid, FDeleteAction>& Value) { Write<TMap<FGuid, FDeleteAction>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xf0
class UMapDeltaApplier : public UObject
{
public:
};

// Size: 0x20
struct FDeltaAction
{
public:
    FGuid ActorGuid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FDateTime CommitTime() const { return Read<FDateTime>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint32_t DataHash() const { return Read<uint32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: UInt32Property)

    void SET_ActorGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_CommitTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_DataHash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: UInt32Property)
};

// Size: 0xb0
struct FAddAction : public FDeltaAction
{
public:
    FString JsonStringObjectForPropertyData() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x60, Type: StructProperty)

    void SET_JsonStringObjectForPropertyData(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x60, Type: StructProperty)
};

// Size: 0x30
struct FUpdateAction : public FDeltaAction
{
public:
    FString JsonStringObjectForPropertyData() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_JsonStringObjectForPropertyData(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x90
struct FDeleteAction : public FDeltaAction
{
public:
    FString ActorName() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)

    void SET_ActorName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
};

// Size: 0x40
struct FDeltaTrackingHandles
{
public:
};

