/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChronoWeaponGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x3f0
class UAnimInstance_ChronoPanRifle : public UAnimInstance
{
public:
    bool bIsFiring() const { return Read<bool>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    bool bIsReloading() const { return Read<bool>(uintptr_t(this) + 0x3d9); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    float MagRotationValue() const { return Read<float>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    FName ResetMagRotationCurveName() const { return Read<FName>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: NameProperty)

    void SET_bIsFiring(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsReloading(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d9, Value); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    void SET_MagRotationValue(const float& Value) { Write<float>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    void SET_ResetMagRotationCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: NameProperty)
};

