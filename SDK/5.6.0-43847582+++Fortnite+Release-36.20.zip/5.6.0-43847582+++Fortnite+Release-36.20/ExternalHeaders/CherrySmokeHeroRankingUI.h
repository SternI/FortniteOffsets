/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CherrySmokeHeroRankingUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CherrySmokeHeroRankingSystemRuntime.h"
#include "Engine.h"

// Size: 0x368
class UCherrySmokeHeroRankingPlayerInfoWidget : public UFortHUDElementWidget
{
public:
};

// Size: 0xa0
class UCherrySmokeHeroRankingVM : public UFortPerUserViewModel
{
public:
    bool bIsNewPlayerState() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    bool bIsValidPlayerState() const { return Read<bool>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: BoolProperty)
    FGameplayTag CurrentRankTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: StructProperty)
    float CurrentTotalHeroPoints() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float CurrentHeroPointsMax() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float CurrentRankPercentage() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    FCherrySmokeHeroPointsEarnedData RecentPointsEarnedData() const { return Read<FCherrySmokeHeroPointsEarnedData>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0xc, Type: StructProperty)
    FHeroRankMultiplier CurrentMultiplierData() const { return Read<FHeroRankMultiplier>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)

    void SET_bIsNewPlayerState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_bIsValidPlayerState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentRankTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: StructProperty)
    void SET_CurrentTotalHeroPoints(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentHeroPointsMax(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentRankPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_RecentPointsEarnedData(const FCherrySmokeHeroPointsEarnedData& Value) { Write<FCherrySmokeHeroPointsEarnedData>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0xc, Type: StructProperty)
    void SET_CurrentMultiplierData(const FHeroRankMultiplier& Value) { Write<FHeroRankMultiplier>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
};

// Size: 0x300
class UCherrySmokeLastKillerHeroRankingInfo : public UUserWidget
{
public:
};

// Size: 0xa0
class UCherrySmokeViewerHeroRankingVM : public UCherrySmokeHeroRankingVM
{
public:
};

// Size: 0xc
struct FCherrySmokeHeroPointsEarnedData
{
public:
    float PointsEarned() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t PointsSource() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    char PointsSourceAsInt() const { return Read<char>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: ByteProperty)
    FGameplayTag Context() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_PointsEarned(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_PointsSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_PointsSourceAsInt(const char& Value) { Write<char>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: ByteProperty)
    void SET_Context(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

