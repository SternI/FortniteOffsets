/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteQuest
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "CoreUObject.h"
#include "DataRegistry.h"
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0x228
class UFortGameFrameworkComponent_MatchStats : public UGameFrameworkComponent
{
public:
    FFortMatchStatFastArray ReplicatedMatchStats() const { return Read<FFortMatchStatFastArray>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x120, Type: StructProperty)

    void SET_ReplicatedMatchStats(const FFortMatchStatFastArray& Value) { Write<FFortMatchStatFastArray>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x120, Type: StructProperty)
};

// Size: 0xa8
class UFortCheatManager_Quests : public UChildCheatManager
{
public:
};

// Size: 0x130
class UFortGameStateComponent_MilestoneQuests : public UFortGameStateComponent
{
public:
    FDataRegistryType DataRegistryType_SeasonalMilestoneQuests() const { return Read<FDataRegistryType>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: StructProperty)

    void SET_DataRegistryType_SeasonalMilestoneQuests(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x110
class UFortPlayerStateComponent_MilestoneQuests : public UFortPlayerStateComponent
{
public:
};

// Size: 0x78
class UFortQuestDefinitionComponent_Accolade : public UFortQuestDefinitionComponent
{
public:
};

// Size: 0x78
class UFortQuestDefinitionComponent_Conditionals : public UFortQuestDefinitionComponent
{
public:
};

// Size: 0x78
class UFortQuestDefinitionComponent_InitialProgress : public UFortQuestDefinitionComponent
{
public:
};

// Size: 0x78
class UFortQuestDefinitionComponent_MilestoneQuest : public UFortQuestDefinitionComponent
{
public:
};

// Size: 0x78
class UFortQuestDefinitionComponent_ProductCompatibilityInjector_GameModeRanked : public UFortQuestDefinitionComponent_ProductCompatibilityInjector
{
public:
};

// Size: 0x78
class UFortQuestDefinitionComponent_ProductCompatibilityInjector_IslandMetadata : public UFortQuestDefinitionComponent_ProductCompatibilityInjector
{
public:
};

// Size: 0x30
class UFortQuestItemComponent_Accolade : public UFortQuestItemComponent
{
public:
};

// Size: 0x80
class UFortQuestItemComponent_Conditionals : public UFortQuestItemComponent
{
public:
};

// Size: 0x30
class UFortQuestItemComponent_InitialProgress : public UFortQuestItemComponent
{
public:
};

// Size: 0x38
class UFortQuestItemComponent_MilestoneQuest : public UFortQuestItemComponent
{
public:
};

// Size: 0x440
class AFortReactionGrantVolume : public AGameplayVolume
{
public:
    UOverlapComponent* OverlapComponent() const { return Read<UOverlapComponent*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnEnter() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnExit() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: ArrayProperty)
    bool bUseQuestRequirement() const { return Read<bool>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x1, Type: BoolProperty)
    bool bTriggerExitOnObjectiveCompletion() const { return Read<bool>(uintptr_t(this) + 0x371); } // 0x371 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UFortQuestItemDefinition> RequiredQuest() const { return Read<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x20, Type: SoftObjectProperty)
    FName RequiredObjective() const { return Read<FName>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x4, Type: NameProperty)

    void SET_OverlapComponent(const UOverlapComponent*& Value) { Write<UOverlapComponent*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_ReactionsToGrantOnEnter(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    void SET_ReactionsToGrantOnExit(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseQuestRequirement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x1, Type: BoolProperty)
    void SET_bTriggerExitOnObjectiveCompletion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x371, Value); } // 0x371 (Size: 0x1, Type: BoolProperty)
    void SET_RequiredQuest(const TSoftObjectPtr<UFortQuestItemDefinition>& Value) { Write<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x20, Type: SoftObjectProperty)
    void SET_RequiredObjective(const FName& Value) { Write<FName>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x4, Type: NameProperty)
};

// Size: 0x898
class AFortQuestManagerVolume : public AFortOverlapTrackingVolume
{
public:
    TArray<TSoftObjectPtr<UFortQuestItemDefinition*>> QuestsToGrantOnStart() const { return Read<TArray<TSoftObjectPtr<UFortQuestItemDefinition*>>>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: ArrayProperty)
    FFortGrantedQuestDataArray GrantedQuestDataArray() const { return Read<FFortGrantedQuestDataArray>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x128, Type: StructProperty)
    FUpdatedQuestObjectiveDataArray UpdatedQuestObjectivesArray() const { return Read<FUpdatedQuestObjectiveDataArray>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x148, Type: StructProperty)
    UFortQuestVolumeComponent_QueuedReactions* ReactionComponent() const { return Read<UFortQuestVolumeComponent_QueuedReactions*>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    FTrackingVolumeParticipantList VolumeParticipants() const { return Read<FTrackingVolumeParticipantList>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x178, Type: StructProperty)
    TArray<FUniqueNetIdRepl> PendingUsers() const { return Read<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x10, Type: ArrayProperty)

    void SET_QuestsToGrantOnStart(const TArray<TSoftObjectPtr<UFortQuestItemDefinition*>>& Value) { Write<TArray<TSoftObjectPtr<UFortQuestItemDefinition*>>>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: ArrayProperty)
    void SET_GrantedQuestDataArray(const FFortGrantedQuestDataArray& Value) { Write<FFortGrantedQuestDataArray>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x128, Type: StructProperty)
    void SET_UpdatedQuestObjectivesArray(const FUpdatedQuestObjectiveDataArray& Value) { Write<FUpdatedQuestObjectiveDataArray>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x148, Type: StructProperty)
    void SET_ReactionComponent(const UFortQuestVolumeComponent_QueuedReactions*& Value) { Write<UFortQuestVolumeComponent_QueuedReactions*>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    void SET_VolumeParticipants(const FTrackingVolumeParticipantList& Value) { Write<FTrackingVolumeParticipantList>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x178, Type: StructProperty)
    void SET_PendingUsers(const TArray<FUniqueNetIdRepl>& Value) { Write<TArray<FUniqueNetIdRepl>>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x270
class UFortQuestVolumeComponent_QueuedReactions : public UFortGameFrameworkComponent_QueuedReactionsManager
{
public:
};

// Size: 0x10
struct FFortEventReaction_UpdateMatchStat : public FEventReactionBase
{
public:
    FGameplayTag MatchStatTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_MatchStatTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FFortMatchStatUpdateInfo
{
public:
    FGameplayTag MatchStatTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t StatAmount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_MatchStatTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_StatAmount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FFortMatchStatUpdatedMessage
{
public:
    TArray<FFortMatchStatUpdateInfo> UpdatedStats() const { return Read<TArray<FFortMatchStatUpdateInfo>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_UpdatedStats(const TArray<FFortMatchStatUpdateInfo>& Value) { Write<TArray<FFortMatchStatUpdateInfo>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x14
struct FFortMatchStatFastEntry : public FFastArraySerializerItem
{
public:
    FFortMatchStatUpdateInfo StatInfo() const { return Read<FFortMatchStatUpdateInfo>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x8, Type: StructProperty)

    void SET_StatInfo(const FFortMatchStatUpdateInfo& Value) { Write<FFortMatchStatUpdateInfo>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x8, Type: StructProperty)
};

// Size: 0x120
struct FFortMatchStatFastArray : public FFastArraySerializer
{
public:
    TArray<FFortMatchStatFastEntry> Entries() const { return Read<TArray<FFortMatchStatFastEntry>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UFortGameFrameworkComponent_MatchStats*> ParentComp() const { return Read<TWeakObjectPtr<UFortGameFrameworkComponent_MatchStats*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Entries(const TArray<FFortMatchStatFastEntry>& Value) { Write<TArray<FFortMatchStatFastEntry>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_ParentComp(const TWeakObjectPtr<UFortGameFrameworkComponent_MatchStats*>& Value) { Write<TWeakObjectPtr<UFortGameFrameworkComponent_MatchStats*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x18
struct FMilestoneQuestTableRow : public FTableRowBase
{
public:
    TScriptInterface<Class> Quest() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: InterfaceProperty)

    void SET_Quest(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x10
struct FObjectiveExtension_Conditionals : public FObjectiveExtensionData
{
public:
    TArray<FInstancedStruct> Conditionals() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Conditionals(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FObjectiveExtension_InitialProgress : public FObjectiveExtensionData
{
public:
    FInstancedStruct InitialProgress() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_InitialProgress(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FObjectiveUpdateGate_ZoneDifficulty : public FGateType_ObjectiveUpdate_Base
{
public:
    FInt32Range RequiredDifficulty() const { return Read<FInt32Range>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_RequiredDifficulty(const FInt32Range& Value) { Write<FInt32Range>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FReactionCondition
{
public:
};

// Size: 0x20
struct FReactionConditionalGrant
{
public:
    TArray<FInstancedStruct> ReactionsToGrant() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FInstancedStruct Condition() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_ReactionsToGrant(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Condition(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FEventReaction_Conditional : public FEventReactionBase
{
public:
    uint8_t GrantType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    TArray<FReactionConditionalGrant> ConditionalReactions() const { return Read<TArray<FReactionConditionalGrant>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_GrantType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_ConditionalReactions(const TArray<FReactionConditionalGrant>& Value) { Write<TArray<FReactionConditionalGrant>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FEventReactionCumulativeRollEntry
{
public:
    int32_t RollChance() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    TArray<FInstancedStruct> Reactions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_RollChance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Reactions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FEventReaction_CumulativeRoll : public FEventReactionBase
{
public:
    TArray<FEventReactionCumulativeRollEntry> CumulativeRollEntries() const { return Read<TArray<FEventReactionCumulativeRollEntry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_CumulativeRollEntries(const TArray<FEventReactionCumulativeRollEntry>& Value) { Write<TArray<FEventReactionCumulativeRollEntry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
struct FFortEventReaction_SpawnLoot : public FFortEventReaction_SideEffect
{
public:
    FVector RewardOffset() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector RewardDirection() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FScalableFloat RewardConeAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    FScalableFloat RewardFlingMagnitude() const { return Read<FScalableFloat>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FName LootTier() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)

    void SET_RewardOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_RewardDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_RewardConeAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_RewardFlingMagnitude(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_LootTier(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
};

// Size: 0x18
struct FReactionCondition_AllConditionsPass : public FReactionCondition
{
public:
    TArray<FInstancedStruct> Conditions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Conditions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FReactionCondition_AnyConditionsPass : public FReactionCondition
{
public:
    TArray<FInstancedStruct> Conditions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Conditions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FReactionCondition_NoConditionsPass : public FReactionCondition
{
public:
    TArray<FInstancedStruct> Conditions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Conditions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FReactionCondition_GameplayTagQuery : public FReactionCondition
{
public:
    FGameplayTagQuery TargetQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)

    void SET_TargetQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x28
struct FReactionCondition_HasRequiredToken : public FReactionCondition
{
public:
    TSoftObjectPtr<UFortTokenType> RequiredTokenDefinition() const { return Read<TSoftObjectPtr<UFortTokenType>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_RequiredTokenDefinition(const TSoftObjectPtr<UFortTokenType>& Value) { Write<TSoftObjectPtr<UFortTokenType>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x78
struct FFortEventReaction_GrantEmote : public FFortEventReaction_SideEffect
{
public:
    FExternalEmoteCategory EmoteToGrant() const { return Read<FExternalEmoteCategory>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)

    void SET_EmoteToGrant(const FExternalEmoteCategory& Value) { Write<FExternalEmoteCategory>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
};

// Size: 0x10
struct FFortEventReaction_RemoveEmote : public FFortEventReaction_SideEffect
{
public:
    FName EmoteCategoryToRemove() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_EmoteCategoryToRemove(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x58
struct FTrackingVolumeParticipant : public FFastArraySerializerItem
{
public:
    FUniqueNetIdRepl UserId() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x30, Type: StructProperty)
    TWeakObjectPtr<AFortQuestManagerVolume*> TrackingVolume() const { return Read<TWeakObjectPtr<AFortQuestManagerVolume*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerState*> PlayerStateCached() const { return Read<TWeakObjectPtr<APlayerState*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AController*> ControllerCached() const { return Read<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)

    void SET_UserId(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x30, Type: StructProperty)
    void SET_TrackingVolume(const TWeakObjectPtr<AFortQuestManagerVolume*>& Value) { Write<TWeakObjectPtr<AFortQuestManagerVolume*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerStateCached(const TWeakObjectPtr<APlayerState*>& Value) { Write<TWeakObjectPtr<APlayerState*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ControllerCached(const TWeakObjectPtr<AController*>& Value) { Write<TWeakObjectPtr<AController*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x178
struct FTrackingVolumeParticipantList : public FFastArraySerializer
{
public:
    TArray<FTrackingVolumeParticipant> TrackingVolumeParticipants() const { return Read<TArray<FTrackingVolumeParticipant>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    AFortQuestManagerVolume* TrackingVolume() const { return Read<AFortQuestManagerVolume*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ObjectProperty)

    void SET_TrackingVolumeParticipants(const TArray<FTrackingVolumeParticipant>& Value) { Write<TArray<FTrackingVolumeParticipant>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_TrackingVolume(const AFortQuestManagerVolume*& Value) { Write<AFortQuestManagerVolume*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ObjectProperty)
};

