/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DistortedWeaponsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "FortniteUI.h"

// Size: 0x380
class UChromeWeaponInfoWidget : public UFortHUDElementWidget
{
public:
    UFortHUDContext* HUDContext() const { return Read<UFortHUDContext*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UFortWorldMultiItemXPComponent* CurrentXpComponent() const { return Read<UFortWorldMultiItemXPComponent*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UAthenaItemTierWidget* ItemTierWidget() const { return Read<UAthenaItemTierWidget*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UFortKeybindWidget* KeybindWidget() const { return Read<UFortKeybindWidget*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)

    void SET_HUDContext(const UFortHUDContext*& Value) { Write<UFortHUDContext*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentXpComponent(const UFortWorldMultiItemXPComponent*& Value) { Write<UFortWorldMultiItemXPComponent*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemTierWidget(const UAthenaItemTierWidget*& Value) { Write<UAthenaItemTierWidget*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_KeybindWidget(const UFortKeybindWidget*& Value) { Write<UFortKeybindWidget*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
};

