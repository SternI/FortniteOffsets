/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FancyMopGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x1380
class UFancyMop_PlayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    FRotator UpperBodyTwistRotator() const { return Read<FRotator>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x18, Type: StructProperty)
    bool bIsIceFire() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x0) & 1; } // 0x1320:0 (Size: 0x1, Type: BoolProperty)
    bool bIsUpperBody() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x1) & 1; } // 0x1320:1 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireToSprint() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x2) & 1; } // 0x1320:2 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireToIdle() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x3) & 1; } // 0x1320:3 (Size: 0x1, Type: BoolProperty)
    bool bIsGrindRail() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x4) & 1; } // 0x1320:4 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireUpperBody() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x5) & 1; } // 0x1320:5 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireFallStart() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x6) & 1; } // 0x1320:6 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireFallEnd() const { return (Read<uint8_t>(uintptr_t(this) + 0x1320) >> 0x7) & 1; } // 0x1320:7 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireFullBodyGround() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x0) & 1; } // 0x1321:0 (Size: 0x1, Type: BoolProperty)
    bool bIsFromIceFireEndState() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x1) & 1; } // 0x1321:1 (Size: 0x1, Type: BoolProperty)
    bool bIsTrFromFireEndIdle() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x2) & 1; } // 0x1321:2 (Size: 0x1, Type: BoolProperty)
    bool bIsTrFromFireEndLoco() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x3) & 1; } // 0x1321:3 (Size: 0x1, Type: BoolProperty)
    bool bIsFireExitUnexpectedly() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x4) & 1; } // 0x1321:4 (Size: 0x1, Type: BoolProperty)
    bool bIsFireEndExitUnexpectedly() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x5) & 1; } // 0x1321:5 (Size: 0x1, Type: BoolProperty)
    bool bIsIceFireFullBodyGroundSprint() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x6) & 1; } // 0x1321:6 (Size: 0x1, Type: BoolProperty)
    bool bRockThrow_01() const { return (Read<uint8_t>(uintptr_t(this) + 0x1321) >> 0x7) & 1; } // 0x1321:7 (Size: 0x1, Type: BoolProperty)
    bool bRockThrowExit() const { return (Read<uint8_t>(uintptr_t(this) + 0x1322) >> 0x0) & 1; } // 0x1322:0 (Size: 0x1, Type: BoolProperty)
    bool bRockThrow_02() const { return (Read<uint8_t>(uintptr_t(this) + 0x1322) >> 0x1) & 1; } // 0x1322:1 (Size: 0x1, Type: BoolProperty)
    bool bIsCrouchMovingLocal() const { return (Read<uint8_t>(uintptr_t(this) + 0x1322) >> 0x2) & 1; } // 0x1322:2 (Size: 0x1, Type: BoolProperty)
    float PunchAim() const { return Read<float>(uintptr_t(this) + 0x1324); } // 0x1324 (Size: 0x4, Type: FloatProperty)
    FName CurveName_MeleeTwist() const { return Read<FName>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x4, Type: NameProperty)
    FName CurveName_TurnEnd() const { return Read<FName>(uintptr_t(this) + 0x132c); } // 0x132c (Size: 0x4, Type: NameProperty)
    FName CurveName_Interruptible() const { return Read<FName>(uintptr_t(this) + 0x1330); } // 0x1330 (Size: 0x4, Type: NameProperty)
    FName CurveName_UserCurve01() const { return Read<FName>(uintptr_t(this) + 0x1334); } // 0x1334 (Size: 0x4, Type: NameProperty)
    FName CurveName_UserCurve02() const { return Read<FName>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x4, Type: NameProperty)
    FString MontageName_FancyMop_Wall_Summon_Sprint_M() const { return Read<FString>(uintptr_t(this) + 0x1340); } // 0x1340 (Size: 0x10, Type: StrProperty)
    FString MontageName_FancyMop_ThrowRock_M() const { return Read<FString>(uintptr_t(this) + 0x1350); } // 0x1350 (Size: 0x10, Type: StrProperty)
    FString MontageName_CantDoThat() const { return Read<FString>(uintptr_t(this) + 0x1360); } // 0x1360 (Size: 0x10, Type: StrProperty)
    bool bDoOnce_SetIsIceFire() const { return (Read<uint8_t>(uintptr_t(this) + 0x1370) >> 0x0) & 1; } // 0x1370:0 (Size: 0x1, Type: BoolProperty)
    bool bDoOnceFlipFlop() const { return (Read<uint8_t>(uintptr_t(this) + 0x1370) >> 0x1) & 1; } // 0x1370:1 (Size: 0x1, Type: BoolProperty)
    bool bFlipFlopAB() const { return (Read<uint8_t>(uintptr_t(this) + 0x1370) >> 0x2) & 1; } // 0x1370:2 (Size: 0x1, Type: BoolProperty)

    void SET_UpperBodyTwistRotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x18, Type: StructProperty)
    void SET_bIsIceFire(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsUpperBody(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireToSprint(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireToIdle(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsGrindRail(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireUpperBody(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireFallStart(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:6 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireFallEnd(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1320); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x1320, B); } // 0x1320:7 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireFullBodyGround(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFromIceFireEndState(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTrFromFireEndIdle(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTrFromFireEndLoco(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:3 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFireExitUnexpectedly(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFireEndExitUnexpectedly(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsIceFireFullBodyGroundSprint(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:6 (Size: 0x1, Type: BoolProperty)
    void SET_bRockThrow_01(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1321); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x1321, B); } // 0x1321:7 (Size: 0x1, Type: BoolProperty)
    void SET_bRockThrowExit(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1322); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1322, B); } // 0x1322:0 (Size: 0x1, Type: BoolProperty)
    void SET_bRockThrow_02(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1322); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1322, B); } // 0x1322:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCrouchMovingLocal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1322); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1322, B); } // 0x1322:2 (Size: 0x1, Type: BoolProperty)
    void SET_PunchAim(const float& Value) { Write<float>(uintptr_t(this) + 0x1324, Value); } // 0x1324 (Size: 0x4, Type: FloatProperty)
    void SET_CurveName_MeleeTwist(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x4, Type: NameProperty)
    void SET_CurveName_TurnEnd(const FName& Value) { Write<FName>(uintptr_t(this) + 0x132c, Value); } // 0x132c (Size: 0x4, Type: NameProperty)
    void SET_CurveName_Interruptible(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1330, Value); } // 0x1330 (Size: 0x4, Type: NameProperty)
    void SET_CurveName_UserCurve01(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1334, Value); } // 0x1334 (Size: 0x4, Type: NameProperty)
    void SET_CurveName_UserCurve02(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x4, Type: NameProperty)
    void SET_MontageName_FancyMop_Wall_Summon_Sprint_M(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1340, Value); } // 0x1340 (Size: 0x10, Type: StrProperty)
    void SET_MontageName_FancyMop_ThrowRock_M(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1350, Value); } // 0x1350 (Size: 0x10, Type: StrProperty)
    void SET_MontageName_CantDoThat(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1360, Value); } // 0x1360 (Size: 0x10, Type: StrProperty)
    void SET_bDoOnce_SetIsIceFire(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1370); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1370, B); } // 0x1370:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDoOnceFlipFlop(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1370); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1370, B); } // 0x1370:1 (Size: 0x1, Type: BoolProperty)
    void SET_bFlipFlopAB(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1370); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x1370, B); } // 0x1370:2 (Size: 0x1, Type: BoolProperty)
};

