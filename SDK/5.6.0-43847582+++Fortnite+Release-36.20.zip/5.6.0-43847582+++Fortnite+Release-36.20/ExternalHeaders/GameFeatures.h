/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameFeatures
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "DataRegistry.h"

// Size: 0x28
class UGameFeatureStateChangeObserver : public UInterface
{
public:
};

// Size: 0x80
class UGameFeatureVersePathMapperCommandlet : public UCommandlet
{
public:
};

// Size: 0x28
class UGameFeatureAction : public UObject
{
public:
};

// Size: 0x28
class UGameFeatureAction_AddActorFactory : public UGameFeatureAction
{
public:
};

// Size: 0x60
class UGameFeatureAction_AddCheats : public UGameFeatureAction
{
public:
    TArray<TSoftClassPtr> CheatManagers() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bLoadCheatManagersAsync() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    TArray<TWeakObjectPtr<UCheatManagerExtension*>> SpawnedCheatManagers() const { return Read<TArray<TWeakObjectPtr<UCheatManagerExtension*>>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_CheatManagers(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_bLoadCheatManagersAsync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnedCheatManagers(const TArray<TWeakObjectPtr<UCheatManagerExtension*>>& Value) { Write<TArray<TWeakObjectPtr<UCheatManagerExtension*>>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UGameFeatureAction_AddChunkOverride : public UGameFeatureAction
{
public:
};

// Size: 0x88
class UGameFeatureAction_AddComponents : public UGameFeatureAction
{
public:
    TArray<FGameFeatureComponentEntry> ComponentList() const { return Read<TArray<FGameFeatureComponentEntry>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ComponentList(const TArray<FGameFeatureComponentEntry>& Value) { Write<TArray<FGameFeatureComponentEntry>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
class UGameFeatureAction_AddWorldPartitionContent : public UGameFeatureAction
{
public:
    UExternalDataLayerAsset* ExternalDataLayerAsset() const { return Read<UExternalDataLayerAsset*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ExternalDataLayerAsset(const UExternalDataLayerAsset*& Value) { Write<UExternalDataLayerAsset*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UGameFeatureAction_AddWPContent : public UGameFeatureAction
{
public:
    UContentBundleDescriptor* ContentBundleDescriptor() const { return Read<UContentBundleDescriptor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_ContentBundleDescriptor(const UContentBundleDescriptor*& Value) { Write<UContentBundleDescriptor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UGameFeatureAction_AudioActionBase : public UGameFeatureAction
{
public:
};

// Size: 0x40
class UGameFeatureAction_DataRegistry : public UGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UDataRegistry*>> RegistriesToAdd() const { return Read<TArray<TSoftObjectPtr<UDataRegistry*>>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bPreloadInEditor() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bPreloadInCommandlets() const { return Read<bool>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: BoolProperty)

    void SET_RegistriesToAdd(const TArray<TSoftObjectPtr<UDataRegistry*>>& Value) { Write<TArray<TSoftObjectPtr<UDataRegistry*>>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_bPreloadInEditor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_bPreloadInCommandlets(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
class UGameFeatureAction_DataRegistrySource : public UGameFeatureAction
{
public:
    TArray<FDataRegistrySourceToAdd> SourcesToAdd() const { return Read<TArray<FDataRegistrySourceToAdd>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bPreloadInEditor() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_SourcesToAdd(const TArray<FDataRegistrySourceToAdd>& Value) { Write<TArray<FDataRegistrySourceToAdd>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_bPreloadInEditor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
class UGameFeatureData : public UPrimaryDataAsset
{
public:
    TArray<UGameFeatureAction*> Actions() const { return Read<TArray<UGameFeatureAction*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FPrimaryAssetTypeInfo> PrimaryAssetTypesToScan() const { return Read<TArray<FPrimaryAssetTypeInfo>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Actions(const TArray<UGameFeatureAction*>& Value) { Write<TArray<UGameFeatureAction*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_PrimaryAssetTypesToScan(const TArray<FPrimaryAssetTypeInfo>& Value) { Write<TArray<FPrimaryAssetTypeInfo>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x280
class UGameFeatureOptionalContentInstaller : public UObject
{
public:
};

// Size: 0x240
class UGameFeaturePluginStateMachine : public UObject
{
public:
    FGameFeaturePluginStateMachineProperties StateProperties() const { return Read<FGameFeaturePluginStateMachineProperties>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xe0, Type: StructProperty)

    void SET_StateProperties(const FGameFeaturePluginStateMachineProperties& Value) { Write<FGameFeaturePluginStateMachineProperties>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xe0, Type: StructProperty)
};

// Size: 0x28
class UGameFeaturesProjectPolicies : public UObject
{
public:
};

// Size: 0x28
class UDefaultGameFeaturesProjectPolicies : public UGameFeaturesProjectPolicies
{
public:
};

// Size: 0x1d8
class UGameFeaturesSubsystem : public UEngineSubsystem
{
public:
    TMap<FString, UGameFeaturePluginStateMachine*> GameFeaturePluginStateMachines() const { return Read<TMap<FString, UGameFeaturePluginStateMachine*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    TArray<UGameFeaturePluginStateMachine*> TerminalGameFeaturePluginStateMachines() const { return Read<TArray<UGameFeaturePluginStateMachine*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> Observers() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    UGameFeaturesProjectPolicies* GameSpecificPolicies() const { return Read<UGameFeaturesProjectPolicies*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)

    void SET_GameFeaturePluginStateMachines(const TMap<FString, UGameFeaturePluginStateMachine*>& Value) { Write<TMap<FString, UGameFeaturePluginStateMachine*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_TerminalGameFeaturePluginStateMachines(const TArray<UGameFeaturePluginStateMachine*>& Value) { Write<TArray<UGameFeaturePluginStateMachine*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_Observers(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_GameSpecificPolicies(const UGameFeaturesProjectPolicies*& Value) { Write<UGameFeaturesProjectPolicies*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UGameFeaturesSubsystemSettings : public UDeveloperSettings
{
public:
    FSoftClassPath GameFeaturesManagerClassName() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    TArray<FString> EnabledPlugins() const { return Read<TArray<FString>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> DisabledPlugins() const { return Read<TArray<FString>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> AdditionalPluginMetadataKeys() const { return Read<TArray<FString>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_GameFeaturesManagerClassName(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_EnabledPlugins(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_DisabledPlugins(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_AdditionalPluginMetadataKeys(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x48
struct FGameFeatureComponentEntry
{
public:
    bool bClientComponent() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x0) & 1; } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    bool bServerComponent() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x1) & 1; } // 0x40:1 (Size: 0x1, Type: BoolProperty)
    char AdditionFlags() const { return Read<char>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: ByteProperty)

    void SET_bClientComponent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    void SET_bServerComponent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:1 (Size: 0x1, Type: BoolProperty)
    void SET_AdditionFlags(const char& Value) { Write<char>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FDataRegistrySourceToAdd
{
public:
    FName RegistryToAddTo() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t AssetPriority() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    bool bClientSource() const { return (Read<uint8_t>(uintptr_t(this) + 0x8) >> 0x0) & 1; } // 0x8:0 (Size: 0x1, Type: BoolProperty)
    bool bServerSource() const { return (Read<uint8_t>(uintptr_t(this) + 0x8) >> 0x1) & 1; } // 0x8:1 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UDataTable> DataTableToAdd() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UCurveTable> CurveTableToAdd() const { return Read<TSoftObjectPtr<UCurveTable>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)

    void SET_RegistryToAddTo(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AssetPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_bClientSource(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x8, B); } // 0x8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bServerSource(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x8, B); } // 0x8:1 (Size: 0x1, Type: BoolProperty)
    void SET_DataTableToAdd(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CurveTableToAdd(const TSoftObjectPtr<UCurveTable>& Value) { Write<TSoftObjectPtr<UCurveTable>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0xe0
struct FGameFeaturePluginStateMachineProperties
{
public:
    UGameFeatureData* GameFeatureData() const { return Read<UGameFeatureData*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_GameFeatureData(const UGameFeatureData*& Value) { Write<UGameFeatureData*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FGameFeaturePluginIdentifier
{
public:
};

// Size: 0xc
struct FInstallBundlePluginProtocolOptions
{
public:
};

