/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortControlRigUnits
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x38
struct FFortRigUnit_SphereTrace_WorkData
{
public:
    uint32_t Hash() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    bool bHit() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bInitialOverlap() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Hash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_bHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bInitialOverlap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0xe8
struct FFortRigUnit_SphereTraceByChannel : public FRigUnit
{
public:
    FVector Start() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bTraceComplex() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    TArray<FName> IgnoreActorTags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer IgnoreGameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    uint8_t TraceType() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    bool bHit() const { return Read<bool>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: BoolProperty)
    bool bInitialOverlap() const { return Read<bool>(uintptr_t(this) + 0x7a); } // 0x7a (Size: 0x1, Type: BoolProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FFortRigUnit_SphereTrace_WorkData WorkData() const { return Read<FFortRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x38, Type: StructProperty)

    void SET_Start(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_End(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_TraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_bTraceComplex(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_IgnoreActorTags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_IgnoreGameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_TraceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_bHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: BoolProperty)
    void SET_bInitialOverlap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7a, Value); } // 0x7a (Size: 0x1, Type: BoolProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_WorkData(const FFortRigUnit_SphereTrace_WorkData& Value) { Write<FFortRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x38, Type: StructProperty)
};

