/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ModalDialogRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"

// Size: 0x470
class UModalDialogVariant : public UCommonActivatableWidget
{
public:
    UWidgetAnimation* BoundAnim_Open() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BoundAnim_Response() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)

    void SET_BoundAnim_Open(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundAnim_Response(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
};

