/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FacialAnimSystem
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x30
class UFacialLiveLinkRemapAsset : public ULiveLinkRetargetAsset
{
public:
    bool bExtractBoneTransform() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bExtractCurve() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)

    void SET_bExtractBoneTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bExtractCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
};

