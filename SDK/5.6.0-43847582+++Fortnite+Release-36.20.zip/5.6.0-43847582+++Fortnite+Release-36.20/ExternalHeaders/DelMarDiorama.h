/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarDiorama
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MovieScene.h"
#include "DelMarCore.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "LevelSequence.h"
#include "CoreUObject.h"

// Size: 0x2b8
class ADelMarCockpitActor : public AActor
{
public:
    USkeletalMeshComponent* CockpitMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* BoundVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_CockpitMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x400
class ADelMarDioramaActor : public AActor
{
public:
    USkeletalMeshComponent* VehicleInteriorMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayTag, FDelMarDriverSequenceDataList> CustomSequenceListTable() const { return Read<TMap<FGameplayTag, FDelMarDriverSequenceDataList>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x50, Type: MapProperty)
    UClass* DriverMannequinClass() const { return Read<UClass*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ClassProperty)
    UClass* LevelSequenceActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ClassProperty)
    UClass* CineCameraClass() const { return Read<UClass*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ClassProperty)
    UClass* CockpitClass() const { return Read<UClass*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ClassProperty)
    UDelMarDioramaConfigData* ConfigData() const { return Read<UDelMarDioramaConfigData*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    FVector DefaultCameraOffset() const { return Read<FVector>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x18, Type: StructProperty)
    FRotator DefaultCameraRotation() const { return Read<FRotator>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x18, Type: StructProperty)
    ALevelSequenceActor* SequenceActor() const { return Read<ALevelSequenceActor*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    ADelMarDriverCameraActor* CameraActor() const { return Read<ADelMarDriverCameraActor*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    ADelMarDriverMannequin* DriverMannequin() const { return Read<ADelMarDriverMannequin*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    ADelMarCockpitActor* CockpitActor() const { return Read<ADelMarCockpitActor*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    APlayerState* BoundPlayer() const { return Read<APlayerState*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UDelMarDriverSequenceData* LastPlayedSequenceData() const { return Read<UDelMarDriverSequenceData*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    TSet<UDelMarDriverSequenceDataTable*> BoundSequencesTables() const { return Read<TSet<UDelMarDriverSequenceDataTable*>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x50, Type: SetProperty)
    int32_t DefaultCameraSocketIndex() const { return Read<int32_t>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x4, Type: IntProperty)

    void SET_VehicleInteriorMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomSequenceListTable(const TMap<FGameplayTag, FDelMarDriverSequenceDataList>& Value) { Write<TMap<FGameplayTag, FDelMarDriverSequenceDataList>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x50, Type: MapProperty)
    void SET_DriverMannequinClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ClassProperty)
    void SET_LevelSequenceActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ClassProperty)
    void SET_CineCameraClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ClassProperty)
    void SET_CockpitClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ClassProperty)
    void SET_ConfigData(const UDelMarDioramaConfigData*& Value) { Write<UDelMarDioramaConfigData*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultCameraOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x18, Type: StructProperty)
    void SET_DefaultCameraRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x18, Type: StructProperty)
    void SET_SequenceActor(const ALevelSequenceActor*& Value) { Write<ALevelSequenceActor*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraActor(const ADelMarDriverCameraActor*& Value) { Write<ADelMarDriverCameraActor*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_DriverMannequin(const ADelMarDriverMannequin*& Value) { Write<ADelMarDriverMannequin*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_CockpitActor(const ADelMarCockpitActor*& Value) { Write<ADelMarCockpitActor*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundPlayer(const APlayerState*& Value) { Write<APlayerState*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_LastPlayedSequenceData(const UDelMarDriverSequenceData*& Value) { Write<UDelMarDriverSequenceData*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundSequencesTables(const TSet<UDelMarDriverSequenceDataTable*>& Value) { Write<TSet<UDelMarDriverSequenceDataTable*>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x50, Type: SetProperty)
    void SET_DefaultCameraSocketIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
class UDelMarDioramaConfigData : public UDataAsset
{
public:
    FName CameraActorTag() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    FName DriverMannequinTag() const { return Read<FName>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: NameProperty)
    FName CockpitActorTag() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    TArray<FName> CockpitCameraCutSockets() const { return Read<TArray<FName>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FName CockpitCameraIdleSocket() const { return Read<FName>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: NameProperty)

    void SET_CameraActorTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_DriverMannequinTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: NameProperty)
    void SET_CockpitActorTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_CockpitCameraCutSockets(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_CockpitCameraIdleSocket(const FName& Value) { Write<FName>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: NameProperty)
};

// Size: 0xab0
class ADelMarDriverCameraActor : public ACineCameraActor
{
public:
    USceneCaptureComponent2D* CaptureComponent() const { return Read<USceneCaptureComponent2D*>(uintptr_t(this) + 0xaa0); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)

    void SET_CaptureComponent(const USceneCaptureComponent2D*& Value) { Write<USceneCaptureComponent2D*>(uintptr_t(this) + 0xaa0, Value); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UDelMarDriverCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x40
class UDelMarDriverSequenceData : public UDataAsset
{
public:
    ULevelSequence* Sequence() const { return Read<ULevelSequence*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    int32_t PriorityLevel() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    bool bLoop() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    bool bTriggerReactiveWidget() const { return Read<bool>(uintptr_t(this) + 0x3d); } // 0x3d (Size: 0x1, Type: BoolProperty)
    bool bCameraCut() const { return Read<bool>(uintptr_t(this) + 0x3e); } // 0x3e (Size: 0x1, Type: BoolProperty)

    void SET_Sequence(const ULevelSequence*& Value) { Write<ULevelSequence*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_PriorityLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_bLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_bTriggerReactiveWidget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d, Value); } // 0x3d (Size: 0x1, Type: BoolProperty)
    void SET_bCameraCut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e, Value); } // 0x3e (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UDelMarDriverSequenceDataTable : public UDataAsset
{
public:
    TMap<FGameplayTag, FDelMarDriverSequenceDataList> SequenceListTable() const { return Read<TMap<FGameplayTag, FDelMarDriverSequenceDataList>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_SequenceListTable(const TMap<FGameplayTag, FDelMarDriverSequenceDataList>& Value) { Write<TMap<FGameplayTag, FDelMarDriverSequenceDataList>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x40
class UDelMarIntercomEvent : public UObject
{
public:
    AFortPlayerState* OwningPlayerState() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* OwningVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UDelMarIntercomComponent* IntercomComponent() const { return Read<UDelMarIntercomComponent*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_OwningPlayerState(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_OwningVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_IntercomComponent(const UDelMarIntercomComponent*& Value) { Write<UDelMarIntercomComponent*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UDelMarIntercomEvent_TurboPassing : public UDelMarIntercomEvent
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerAhead() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarPlayerRaceDataComponent* RaceData() const { return Read<UDelMarPlayerRaceDataComponent*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerAhead(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RaceData(const UDelMarPlayerRaceDataComponent*& Value) { Write<UDelMarPlayerRaceDataComponent*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x500
class UDelMarCockpitAnimInstance : public UDelMarDriverAnimInstance
{
public:
    float DefaultCameraShakeIntensity() const { return Read<float>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x4, Type: FloatProperty)
    float DefaultTerrainAccMultiplier() const { return Read<float>(uintptr_t(this) + 0x4ec); } // 0x4ec (Size: 0x4, Type: FloatProperty)
    float DefaultTerrainMaxForwardSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x4, Type: FloatProperty)
    float CameraShakeIntensity() const { return Read<float>(uintptr_t(this) + 0x4f4); } // 0x4f4 (Size: 0x4, Type: FloatProperty)

    void SET_DefaultCameraShakeIntensity(const float& Value) { Write<float>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultTerrainAccMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4ec, Value); } // 0x4ec (Size: 0x4, Type: FloatProperty)
    void SET_DefaultTerrainMaxForwardSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x4, Type: FloatProperty)
    void SET_CameraShakeIntensity(const float& Value) { Write<float>(uintptr_t(this) + 0x4f4, Value); } // 0x4f4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4f0
class UDelMarDriverAnimInstance : public UFortBaseAnimInstance
{
public:
    ADelMarVehicle* BoundVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    bool bDrifting() const { return Read<bool>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x1, Type: BoolProperty)
    bool bTurboing() const { return Read<bool>(uintptr_t(this) + 0x4d1); } // 0x4d1 (Size: 0x1, Type: BoolProperty)
    float SteeringAngle() const { return Read<float>(uintptr_t(this) + 0x4d4); } // 0x4d4 (Size: 0x4, Type: FloatProperty)
    float SlipAngle() const { return Read<float>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x4, Type: FloatProperty)
    float StableSpeed() const { return Read<float>(uintptr_t(this) + 0x4dc); } // 0x4dc (Size: 0x4, Type: FloatProperty)
    float DrivingSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x4, Type: FloatProperty)

    void SET_BoundVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_bDrifting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x1, Type: BoolProperty)
    void SET_bTurboing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d1, Value); } // 0x4d1 (Size: 0x1, Type: BoolProperty)
    void SET_SteeringAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x4d4, Value); } // 0x4d4 (Size: 0x4, Type: FloatProperty)
    void SET_SlipAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x4, Type: FloatProperty)
    void SET_StableSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x4dc, Value); } // 0x4dc (Size: 0x4, Type: FloatProperty)
    void SET_DrivingSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1e0
class UDelMarDioramaControllerComponent : public UControllerComponent
{
public:
    FVector DioramaOffset() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    UClass* DioramaClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    UDelMarDriverSequenceDataTable* CustomizedSequencesTable() const { return Read<UDelMarDriverSequenceDataTable*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    FTransform DioramaInitialTransform() const { return Read<FTransform>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x60, Type: StructProperty)
    UClass* MainChannelClass() const { return Read<UClass*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ClassProperty)
    UDelMarDriverChannel* MainChannel() const { return Read<UDelMarDriverChannel*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    UClass* PostRaceChannelClass() const { return Read<UClass*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ClassProperty)
    TArray<UDelMarDriverChannelBase*> PostRaceChannels() const { return Read<TArray<UDelMarDriverChannelBase*>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x10, Type: ArrayProperty)
    APlayerState* CachedOwningPlayerState() const { return Read<APlayerState*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ObjectProperty)
    APlayerState* ViewTargetPlayer() const { return Read<APlayerState*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> ViewTargetVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: WeakObjectProperty)
    TMap<APlayerState*, ADelMarDioramaActor*> PlayerDioramaTable() const { return Read<TMap<APlayerState*, ADelMarDioramaActor*>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x50, Type: MapProperty)
    int32_t NumPostRaceChannel() const { return Read<int32_t>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: IntProperty)

    void SET_DioramaOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_DioramaClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_CustomizedSequencesTable(const UDelMarDriverSequenceDataTable*& Value) { Write<UDelMarDriverSequenceDataTable*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_DioramaInitialTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x60, Type: StructProperty)
    void SET_MainChannelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ClassProperty)
    void SET_MainChannel(const UDelMarDriverChannel*& Value) { Write<UDelMarDriverChannel*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    void SET_PostRaceChannelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ClassProperty)
    void SET_PostRaceChannels(const TArray<UDelMarDriverChannelBase*>& Value) { Write<TArray<UDelMarDriverChannelBase*>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedOwningPlayerState(const APlayerState*& Value) { Write<APlayerState*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewTargetPlayer(const APlayerState*& Value) { Write<APlayerState*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewTargetVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerDioramaTable(const TMap<APlayerState*, ADelMarDioramaActor*>& Value) { Write<TMap<APlayerState*, ADelMarDioramaActor*>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x50, Type: MapProperty)
    void SET_NumPostRaceChannel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x160
class UDelMarDriverChannel : public UDelMarDriverChannelBase
{
public:
    ADelMarVehicle* ViewVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayTag> QueueReactions() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TMap<FGameplayTag, FDelMarDriverSequenceDataList> SequenceListTableInstance() const { return Read<TMap<FGameplayTag, FDelMarDriverSequenceDataList>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)
    TMap<FGameplayTag, float> ReactionCoolDownTimeStamp() const { return Read<TMap<FGameplayTag, float>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    float LandingForceThreshold() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float SlowDownImpactSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float HitWallImpactThreshold() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    float HitWallImpactHardThreshold() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    float DraftBonusPercentageThreshold() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    float StartlineBoostPercentageEarnedThreshold() const { return Read<float>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: FloatProperty)

    void SET_ViewVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_QueueReactions(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_SequenceListTableInstance(const TMap<FGameplayTag, FDelMarDriverSequenceDataList>& Value) { Write<TMap<FGameplayTag, FDelMarDriverSequenceDataList>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
    void SET_ReactionCoolDownTimeStamp(const TMap<FGameplayTag, float>& Value) { Write<TMap<FGameplayTag, float>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_LandingForceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_SlowDownImpactSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_HitWallImpactThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_HitWallImpactHardThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_DraftBonusPercentageThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_StartlineBoostPercentageEarnedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x88
class UDelMarDriverChannelBase : public UObject
{
public:
    UTextureRenderTarget2D* ViewRenderTarget() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FIntPoint RenderTargetDim() const { return Read<FIntPoint>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: StructProperty)
    UDelMarDriverSequenceDataTable* SequencesTable() const { return Read<UDelMarDriverSequenceDataTable*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    APlayerState* ViewPlayer() const { return Read<APlayerState*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    ADelMarDioramaActor* ViewDiorama() const { return Read<ADelMarDioramaActor*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    UMovieSceneSequencePlayer* SequencePlayer() const { return Read<UMovieSceneSequencePlayer*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_ViewRenderTarget(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_RenderTargetDim(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: StructProperty)
    void SET_SequencesTable(const UDelMarDriverSequenceDataTable*& Value) { Write<UDelMarDriverSequenceDataTable*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewPlayer(const APlayerState*& Value) { Write<APlayerState*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewDiorama(const ADelMarDioramaActor*& Value) { Write<ADelMarDioramaActor*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_SequencePlayer(const UMovieSceneSequencePlayer*& Value) { Write<UMovieSceneSequencePlayer*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6e8
class ADelMarDriverMannequin : public AFortPlayerMannequin
{
public:
};

// Size: 0x178
class UDelMarIntercomComponent : public UControllerComponent
{
public:
    UClass* GuestChannelClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    UDelMarDriverChannel* GuestChannel() const { return Read<UDelMarDriverChannel*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> ViewPlayerPawn() const { return Read<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarDioramaActor*> MainChannelDiorama() const { return Read<TWeakObjectPtr<ADelMarDioramaActor*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    APlayerState* ViewPlayerState() const { return Read<APlayerState*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UDelMarDioramaControllerComponent* DioramaControllerComponent() const { return Read<UDelMarDioramaControllerComponent*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> ServerEventClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarIntercomEvent*> ServerEvents() const { return Read<TArray<UDelMarIntercomEvent*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    TMap<FGameplayTag, FDelMarInteractionTagData> InteractionTagTable() const { return Read<TMap<FGameplayTag, FDelMarInteractionTagData>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x50, Type: MapProperty)
    float EmoteBroadcastMaxDistanceSq() const { return Read<float>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: FloatProperty)

    void SET_GuestChannelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_GuestChannel(const UDelMarDriverChannel*& Value) { Write<UDelMarDriverChannel*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_ViewPlayerPawn(const TWeakObjectPtr<AFortPlayerPawn*>& Value) { Write<TWeakObjectPtr<AFortPlayerPawn*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MainChannelDiorama(const TWeakObjectPtr<ADelMarDioramaActor*>& Value) { Write<TWeakObjectPtr<ADelMarDioramaActor*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ViewPlayerState(const APlayerState*& Value) { Write<APlayerState*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_DioramaControllerComponent(const UDelMarDioramaControllerComponent*& Value) { Write<UDelMarDioramaControllerComponent*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerEventClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerEvents(const TArray<UDelMarIntercomEvent*>& Value) { Write<TArray<UDelMarIntercomEvent*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    void SET_InteractionTagTable(const TMap<FGameplayTag, FDelMarInteractionTagData>& Value) { Write<TMap<FGameplayTag, FDelMarInteractionTagData>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x50, Type: MapProperty)
    void SET_EmoteBroadcastMaxDistanceSq(const float& Value) { Write<float>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FDelMarDriverSequenceDataList
{
public:
    TArray<UDelMarDriverSequenceData*> SequenceDataList() const { return Read<TArray<UDelMarDriverSequenceData*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    float Cooldown() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_SequenceDataList(const TArray<UDelMarDriverSequenceData*>& Value) { Write<TArray<UDelMarDriverSequenceData*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Cooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarEvent_DioramaControllerAdded
{
public:
};

// Size: 0x8
struct FDelMarEvent_DriverChannelOpened
{
public:
};

// Size: 0x8
struct FDelMarInteractionTagData
{
public:
    FGameplayTag InstigatorReactionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ReceiverReactionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_InstigatorReactionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ReceiverReactionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

