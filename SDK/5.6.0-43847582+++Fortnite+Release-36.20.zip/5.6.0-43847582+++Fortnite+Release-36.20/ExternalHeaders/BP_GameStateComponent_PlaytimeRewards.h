/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_GameStateComponent_PlaytimeRewards
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xe8
class UBP_GameStateComponent_PlaytimeRewards_C : public UFortGameStateComponent_PlaytimeRewards
{
public:
};

