/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Chaos.h"

// Size: 0x28
class UDataflowGraphInterface : public UInterface
{
public:
};

// Size: 0x120
class UDataflowSettings : public UDeveloperSettings
{
public:
    TMap<FName, FNodeColors> NodeColorsMap() const { return Read<TMap<FName, FNodeColors>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<FName, FPinSettings> PinSettingsMap() const { return Read<TMap<FName, FPinSettings>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)
    FTransformLevelColors TransformLevelColors() const { return Read<FTransformLevelColors>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)

    void SET_NodeColorsMap(const TMap<FName, FNodeColors>& Value) { Write<TMap<FName, FNodeColors>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_PinSettingsMap(const TMap<FName, FPinSettings>& Value) { Write<TMap<FName, FPinSettings>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
    void SET_TransformLevelColors(const FTransformLevelColors& Value) { Write<FTransformLevelColors>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1
struct FDataflowAnyType
{
public:
};

// Size: 0x1
struct FDataflowAllTypes : public FDataflowAnyType
{
public:
};

// Size: 0x1
struct FDataflowArrayTypes : public FDataflowAnyType
{
public:
};

// Size: 0x8
struct FDataflowNumericTypes : public FDataflowAnyType
{
public:
    double Value() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)

    void SET_Value(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x20
struct FDataflowVectorTypes : public FDataflowAnyType
{
public:
    FVector4 Value() const { return Read<FVector4>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FVector4& Value) { Write<FVector4>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x10
struct FDataflowStringTypes : public FDataflowAnyType
{
public:
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x1
struct FDataflowBoolTypes : public FDataflowAnyType
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
struct FDataflowTransformTypes : public FDataflowAnyType
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x10
struct FDataflowStringConvertibleTypes : public FDataflowAnyType
{
public:
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FDataflowUObjectConvertibleTypes : public FDataflowAnyType
{
public:
    UObject* Value() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FDataflowSelectionTypes : public FDataflowAnyType
{
public:
    FDataflowSelection Value() const { return Read<FDataflowSelection>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)

    void SET_Value(const FDataflowSelection& Value) { Write<FDataflowSelection>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FDataflowSelection
{
public:
};

// Size: 0x10
struct FDataflowVectorArrayTypes : public FDataflowAnyType
{
public:
    TArray<FVector4> Value() const { return Read<TArray<FVector4>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FVector4>& Value) { Write<TArray<FVector4>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FDataflowNumericArrayTypes : public FDataflowAnyType
{
public:
    TArray<double> Value() const { return Read<TArray<double>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FDataflowStringArrayTypes : public FDataflowAnyType
{
public:
    TArray<FString> Value() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FDataflowBoolArrayTypes : public FDataflowAnyType
{
public:
    TArray<bool> Value() const { return Read<TArray<bool>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FDataflowTransformArrayTypes : public FDataflowAnyType
{
public:
    TArray<FTransform> Value() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDataflowRotationTypes : public FDataflowAnyType
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x280
struct FDataflowNode
{
public:
    bool bActive() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    bool bOverrideColor() const { return Read<bool>(uintptr_t(this) + 0xd9); } // 0xd9 (Size: 0x1, Type: BoolProperty)
    FLinearColor OverrideColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x10, Type: StructProperty)
    FInstancedPropertyBag FrozenProperties() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x10, Type: StructProperty)
    bool bIsFrozen() const { return Read<bool>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x1, Type: BoolProperty)

    void SET_bActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideColor(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd9, Value); } // 0xd9 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x10, Type: StructProperty)
    void SET_FrozenProperties(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x10, Type: StructProperty)
    void SET_bIsFrozen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x290
struct FConvertNumericTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowNumericTypes In() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Out() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)

    void SET_In(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_Out(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2c0
struct FConvertVectorTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowVectorTypes In() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes Out() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)

    void SET_In(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_Out(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertStringTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowStringTypes In() const { return Read<FDataflowStringTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowStringTypes Out() const { return Read<FDataflowStringTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowStringTypes& Value) { Write<FDataflowStringTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowStringTypes& Value) { Write<FDataflowStringTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x288
struct FConvertBoolTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowBoolTypes In() const { return Read<FDataflowBoolTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: StructProperty)
    FDataflowBoolTypes Out() const { return Read<FDataflowBoolTypes>(uintptr_t(this) + 0x281); } // 0x281 (Size: 0x1, Type: StructProperty)

    void SET_In(const FDataflowBoolTypes& Value) { Write<FDataflowBoolTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: StructProperty)
    void SET_Out(const FDataflowBoolTypes& Value) { Write<FDataflowBoolTypes>(uintptr_t(this) + 0x281, Value); } // 0x281 (Size: 0x1, Type: StructProperty)
};

// Size: 0x340
struct FConvertTransformTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowTransformTypes In() const { return Read<FDataflowTransformTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x60, Type: StructProperty)
    FDataflowTransformTypes Out() const { return Read<FDataflowTransformTypes>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x60, Type: StructProperty)

    void SET_In(const FDataflowTransformTypes& Value) { Write<FDataflowTransformTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x60, Type: StructProperty)
    void SET_Out(const FDataflowTransformTypes& Value) { Write<FDataflowTransformTypes>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertStringConvertibleTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowStringConvertibleTypes In() const { return Read<FDataflowStringConvertibleTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowStringConvertibleTypes Out() const { return Read<FDataflowStringConvertibleTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowStringConvertibleTypes& Value) { Write<FDataflowStringConvertibleTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowStringConvertibleTypes& Value) { Write<FDataflowStringConvertibleTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x290
struct FConvertUObjectConvertibleTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowUObjectConvertibleTypes In() const { return Read<FDataflowUObjectConvertibleTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowUObjectConvertibleTypes Out() const { return Read<FDataflowUObjectConvertibleTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)

    void SET_In(const FDataflowUObjectConvertibleTypes& Value) { Write<FDataflowUObjectConvertibleTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_Out(const FDataflowUObjectConvertibleTypes& Value) { Write<FDataflowUObjectConvertibleTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
};

// Size: 0x388
struct FConvertSelectionTypesDataflowNode : public FDataflowNode
{
public:
    FManagedArrayCollection Collection() const { return Read<FManagedArrayCollection>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0xb0, Type: StructProperty)
    FDataflowSelectionTypes In() const { return Read<FDataflowSelectionTypes>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x28, Type: StructProperty)
    bool bAllElementsMustBeSelected() const { return Read<bool>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x1, Type: BoolProperty)
    FDataflowSelectionTypes Out() const { return Read<FDataflowSelectionTypes>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x28, Type: StructProperty)

    void SET_Collection(const FManagedArrayCollection& Value) { Write<FManagedArrayCollection>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0xb0, Type: StructProperty)
    void SET_In(const FDataflowSelectionTypes& Value) { Write<FDataflowSelectionTypes>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x28, Type: StructProperty)
    void SET_bAllElementsMustBeSelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x1, Type: BoolProperty)
    void SET_Out(const FDataflowSelectionTypes& Value) { Write<FDataflowSelectionTypes>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x28, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertVectorArrayTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowVectorArrayTypes In() const { return Read<FDataflowVectorArrayTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowVectorArrayTypes Out() const { return Read<FDataflowVectorArrayTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowVectorArrayTypes& Value) { Write<FDataflowVectorArrayTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowVectorArrayTypes& Value) { Write<FDataflowVectorArrayTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertNumericArrayTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowNumericArrayTypes In() const { return Read<FDataflowNumericArrayTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowNumericArrayTypes Out() const { return Read<FDataflowNumericArrayTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowNumericArrayTypes& Value) { Write<FDataflowNumericArrayTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowNumericArrayTypes& Value) { Write<FDataflowNumericArrayTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertStringArrayTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowStringArrayTypes In() const { return Read<FDataflowStringArrayTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowStringArrayTypes Out() const { return Read<FDataflowStringArrayTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowStringArrayTypes& Value) { Write<FDataflowStringArrayTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowStringArrayTypes& Value) { Write<FDataflowStringArrayTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertBoolArrayTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowBoolArrayTypes In() const { return Read<FDataflowBoolArrayTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowBoolArrayTypes Out() const { return Read<FDataflowBoolArrayTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowBoolArrayTypes& Value) { Write<FDataflowBoolArrayTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowBoolArrayTypes& Value) { Write<FDataflowBoolArrayTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x2a0
struct FConvertTransformArrayTypesDataflowNode : public FDataflowNode
{
public:
    FDataflowTransformArrayTypes In() const { return Read<FDataflowTransformArrayTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowTransformArrayTypes Out() const { return Read<FDataflowTransformArrayTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)

    void SET_In(const FDataflowTransformArrayTypes& Value) { Write<FDataflowTransformArrayTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Out(const FDataflowTransformArrayTypes& Value) { Write<FDataflowTransformArrayTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
};

// Size: 0x2b0
struct FConvertRotationDataflowNode : public FDataflowNode
{
public:
    FDataflowRotationTypes In() const { return Read<FDataflowRotationTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x18, Type: StructProperty)
    FDataflowRotationTypes Out() const { return Read<FDataflowRotationTypes>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x18, Type: StructProperty)

    void SET_In(const FDataflowRotationTypes& Value) { Write<FDataflowRotationTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x18, Type: StructProperty)
    void SET_Out(const FDataflowRotationTypes& Value) { Write<FDataflowRotationTypes>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x18, Type: StructProperty)
};

// Size: 0x288
struct FDataflowReRouteNode : public FDataflowNode
{
public:
    FDataflowAnyType Value() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: StructProperty)

    void SET_Value(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: StructProperty)
};

// Size: 0x288
struct FDataflowBranchNode : public FDataflowNode
{
public:
    FDataflowAnyType TrueValue() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: StructProperty)
    FDataflowAnyType FalseValue() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x281); } // 0x281 (Size: 0x1, Type: StructProperty)
    bool bCondition() const { return Read<bool>(uintptr_t(this) + 0x282); } // 0x282 (Size: 0x1, Type: BoolProperty)
    FDataflowAnyType Result() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x283); } // 0x283 (Size: 0x1, Type: StructProperty)

    void SET_TrueValue(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: StructProperty)
    void SET_FalseValue(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x281, Value); } // 0x281 (Size: 0x1, Type: StructProperty)
    void SET_bCondition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x282, Value); } // 0x282 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x283, Value); } // 0x283 (Size: 0x1, Type: StructProperty)
};

// Size: 0x298
struct FDataflowSelectNode : public FDataflowNode
{
public:
    TArray<FDataflowAnyType> Inputs() const { return Read<TArray<FDataflowAnyType>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    int32_t SelectedIndex() const { return Read<int32_t>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: IntProperty)
    FDataflowAnyType Result() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x294); } // 0x294 (Size: 0x1, Type: StructProperty)

    void SET_Inputs(const TArray<FDataflowAnyType>& Value) { Write<TArray<FDataflowAnyType>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectedIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: IntProperty)
    void SET_Result(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x294, Value); } // 0x294 (Size: 0x1, Type: StructProperty)
};

// Size: 0x290
struct FDataflowPrintNode : public FDataflowNode
{
public:
    FDataflowStringConvertibleTypes Value() const { return Read<FDataflowStringConvertibleTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FDataflowStringConvertibleTypes& Value) { Write<FDataflowStringConvertibleTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
};

// Size: 0x288
struct FDataflowForceDependencyNode : public FDataflowNode
{
public:
    FDataflowAnyType Value() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: StructProperty)
    FDataflowAnyType DependentValue() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x281); } // 0x281 (Size: 0x1, Type: StructProperty)

    void SET_Value(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: StructProperty)
    void SET_DependentValue(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x281, Value); } // 0x281 (Size: 0x1, Type: StructProperty)
};

// Size: 0x60
struct FDataflowBaseElement
{
public:
};

// Size: 0x28
struct FDataflowImage
{
public:
};

// Size: 0x2c0
struct FDataflowImageFromColorNode : public FDataflowNode
{
public:
    FLinearColor FillColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowImage Image() const { return Read<FDataflowImage>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x28, Type: StructProperty)

    void SET_FillColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StructProperty)
    void SET_Image(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x28, Type: StructProperty)
};

// Size: 0x348
struct FDataflowImageSplitChannelsNode : public FDataflowNode
{
public:
    FDataflowImage Image() const { return Read<FDataflowImage>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FDataflowImage Red() const { return Read<FDataflowImage>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    FDataflowImage Green() const { return Read<FDataflowImage>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    FDataflowImage Blue() const { return Read<FDataflowImage>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    FDataflowImage Alpha() const { return Read<FDataflowImage>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x28, Type: StructProperty)

    void SET_Image(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_Red(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_Green(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    void SET_Blue(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    void SET_Alpha(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x28, Type: StructProperty)
};

// Size: 0x350
struct FDataflowImageCombineChannelsNode : public FDataflowNode
{
public:
    FDataflowImage Red() const { return Read<FDataflowImage>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FDataflowImage Green() const { return Read<FDataflowImage>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    FDataflowImage Blue() const { return Read<FDataflowImage>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    FDataflowImage Alpha() const { return Read<FDataflowImage>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    FDataflowImage Image() const { return Read<FDataflowImage>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x28, Type: StructProperty)

    void SET_Red(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_Green(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
    void SET_Blue(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x28, Type: StructProperty)
    void SET_Alpha(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x28, Type: StructProperty)
    void SET_Image(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x28, Type: StructProperty)
};

// Size: 0x290
struct FDataflowMathOneInputOperatorNode : public FDataflowNode
{
public:
    FDataflowNumericTypes A() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Result() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)

    void SET_A(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_Result(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
};

// Size: 0x298
struct FDataflowMathTwoInputsOperatorNode : public FDataflowNode
{
public:
    FDataflowNumericTypes A() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes B() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Result() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)

    void SET_A(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_B(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
    void SET_Result(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
};

// Size: 0x298
struct FDataflowMathAddNode : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathSubtractNode : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathMultiplyNode : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x2a0
struct FDataflowMathDivideNode : public FDataflowMathTwoInputsOperatorNode
{
public:
    FDataflowNumericTypes Fallback() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: StructProperty)

    void SET_Fallback(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: StructProperty)
};

// Size: 0x298
struct FDataflowMathMinimumNode : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathMinimumNode_v2 : public FDataflowNode
{
public:
    TArray<FDataflowNumericTypes> Inputs() const { return Read<TArray<FDataflowNumericTypes>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    FDataflowNumericTypes Result() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)

    void SET_Inputs(const TArray<FDataflowNumericTypes>& Value) { Write<TArray<FDataflowNumericTypes>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    void SET_Result(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
};

// Size: 0x298
struct FDataflowMathMaximumNode : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathMaximumNode_v2 : public FDataflowNode
{
public:
    TArray<FDataflowNumericTypes> Inputs() const { return Read<TArray<FDataflowNumericTypes>>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    FDataflowNumericTypes Result() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)

    void SET_Inputs(const TArray<FDataflowNumericTypes>& Value) { Write<TArray<FDataflowNumericTypes>>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: ArrayProperty)
    void SET_Result(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
};

// Size: 0x298
struct FDataflowMathReciprocalNode : public FDataflowMathOneInputOperatorNode
{
public:
    FDataflowNumericTypes Fallback() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)

    void SET_Fallback(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
};

// Size: 0x290
struct FDataflowMathSquareNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathCubeNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathSquareRootNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathInverseSquareRootNode : public FDataflowMathOneInputOperatorNode
{
public:
    FDataflowNumericTypes Fallback() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)

    void SET_Fallback(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
};

// Size: 0x290
struct FDataflowMathNegateNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathAbsNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathFloorNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathCeilNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathRoundNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathTruncNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathFracNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathPowNode : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathLogXNode : public FDataflowMathOneInputOperatorNode
{
public:
    FDataflowNumericTypes base() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)

    void SET_base(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
};

// Size: 0x290
struct FDataflowMathLogNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathExpNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathSignNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathOneMinusNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathConstantNode : public FDataflowNode
{
public:
    uint8_t Constant() const { return Read<uint8_t>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: EnumProperty)
    FDataflowNumericTypes Result() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)

    void SET_Constant(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: EnumProperty)
    void SET_Result(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2a0
struct FDataflowMathClampNode : public FDataflowMathOneInputOperatorNode
{
public:
    FDataflowNumericTypes Min() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Max() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: StructProperty)

    void SET_Min(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
    void SET_Max(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: StructProperty)
};

// Size: 0x290
struct FDataflowMathSinNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathCosNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathTanNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathArcSinNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathArcCosNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathArcTanNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x298
struct FDataflowMathArcTan2Node : public FDataflowMathTwoInputsOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathDegToRadNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x290
struct FDataflowMathRadToDegNode : public FDataflowMathOneInputOperatorNode
{
public:
};

// Size: 0x2b0
struct FDataflowVectorMakeVec2Node : public FDataflowNode
{
public:
    FDataflowNumericTypes X() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)
    FDataflowVectorTypes Vector2D() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x20, Type: StructProperty)

    void SET_X(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_Y(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
    void SET_Vector2D(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2c0
struct FDataflowVectorMakeVec3Node : public FDataflowNode
{
public:
    FDataflowNumericTypes X() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Z() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)
    FDataflowVectorTypes Vector3d() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)

    void SET_X(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_Y(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
    void SET_Z(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
    void SET_Vector3d(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2c0
struct FDataflowVectorMakeVec4Node : public FDataflowNode
{
public:
    FDataflowNumericTypes X() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Z() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes W() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: StructProperty)
    FDataflowVectorTypes Vector4d() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)

    void SET_X(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: StructProperty)
    void SET_Y(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: StructProperty)
    void SET_Z(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x8, Type: StructProperty)
    void SET_W(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: StructProperty)
    void SET_Vector4d(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2c0
struct FDataflowVectorBreakNode : public FDataflowNode
{
public:
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes X() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Z() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes W() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: StructProperty)

    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_X(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: StructProperty)
    void SET_Y(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_Z(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    void SET_W(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2e0
struct FDataflowVectorAddNode : public FDataflowNode
{
public:
    FDataflowVectorTypes A() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x20, Type: StructProperty)

    void SET_A(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_B(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2e0
struct FDataflowVectorSubtractNode : public FDataflowNode
{
public:
    FDataflowVectorTypes A() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x20, Type: StructProperty)

    void SET_A(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_B(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2d0
struct FDataflowVectorDotProductNode : public FDataflowNode
{
public:
    FDataflowVectorTypes A() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes DotProduct() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: StructProperty)

    void SET_A(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_B(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    void SET_DotProduct(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2b0
struct FDataflowVectorLengthNode : public FDataflowNode
{
public:
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes Length() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: StructProperty)

    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_Length(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2b0
struct FDataflowVectorSquaredLengthNode : public FDataflowNode
{
public:
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes SquaredLength() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: StructProperty)

    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_SquaredLength(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2d0
struct FDataflowVectorDistanceNode : public FDataflowNode
{
public:
    FDataflowVectorTypes A() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes Distance() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: StructProperty)

    void SET_A(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_B(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    void SET_Distance(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x2e0
struct FDataflowVectorCrossProductNode : public FDataflowNode
{
public:
    FDataflowVectorTypes A() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes CrossProduct() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x20, Type: StructProperty)

    void SET_A(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_B(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
    void SET_CrossProduct(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2d0
struct FDataflowVectorScaleNode : public FDataflowNode
{
public:
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes Scale() const { return Read<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x8, Type: StructProperty)
    FDataflowVectorTypes Scaled() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x20, Type: StructProperty)

    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_Scale(const FDataflowNumericTypes& Value) { Write<FDataflowNumericTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x8, Type: StructProperty)
    void SET_Scaled(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2c0
struct FDataflowVectorNormalize : public FDataflowNode
{
public:
    FDataflowVectorTypes V() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes Normalized() const { return Read<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)

    void SET_V(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_Normalized(const FDataflowVectorTypes& Value) { Write<FDataflowVectorTypes>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
struct FDataflowConnection
{
public:
};

// Size: 0x60
struct FDataflowInput : public FDataflowConnection
{
public:
};

// Size: 0x70
struct FDataflowArrayInput : public FDataflowInput
{
public:
};

// Size: 0x80
struct FDataflowOutput : public FDataflowConnection
{
public:
};

// Size: 0x90
struct FDataflowArrayOutput : public FDataflowOutput
{
public:
};

// Size: 0x1
struct FDataflowFreezeActions
{
public:
};

// Size: 0x2a0
struct FDataflowOverrideNode : public FDataflowNode
{
public:
    FName Key() const { return Read<FName>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x4, Type: NameProperty)
    FString Default() const { return Read<FString>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x10, Type: StrProperty)
    bool IsOverriden() const { return Read<bool>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x1, Type: BoolProperty)

    void SET_Key(const FName& Value) { Write<FName>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x4, Type: NameProperty)
    void SET_Default(const FString& Value) { Write<FString>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x10, Type: StrProperty)
    void SET_IsOverriden(const bool& Value) { Write<bool>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FDataflowPath
{
public:
};

// Size: 0x28
struct FDataflowTransformSelection : public FDataflowSelection
{
public:
};

// Size: 0x28
struct FDataflowVertexSelection : public FDataflowSelection
{
public:
};

// Size: 0x28
struct FDataflowFaceSelection : public FDataflowSelection
{
public:
};

// Size: 0x28
struct FDataflowGeometrySelection : public FDataflowSelection
{
public:
};

// Size: 0x28
struct FDataflowMaterialSelection : public FDataflowSelection
{
public:
};

// Size: 0x20
struct FNodeColors
{
public:
    FLinearColor NodeTitleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor NodeBodyTintColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_NodeTitleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_NodeBodyTintColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x14
struct FPinSettings
{
public:
    FLinearColor PinColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    float WireThickness() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_PinColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_WireThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FTransformLevelColors
{
public:
    TArray<FLinearColor> LevelColors() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FLinearColor BlankColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_LevelColors(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_BlankColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x280
struct FDataflowTerminalNode : public FDataflowNode
{
public:
};

