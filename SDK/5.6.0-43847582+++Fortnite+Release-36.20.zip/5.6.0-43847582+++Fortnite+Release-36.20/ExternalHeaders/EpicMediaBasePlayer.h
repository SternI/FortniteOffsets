/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaBasePlayer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "MediaAssets.h"
#include "MediaUtils.h"
#include "EpicStreamMediaSource.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x58
class UEpicMediaPrioritySystem : public UEngineSubsystem
{
public:
};

// Size: 0x158
class UEpicBaseStreamingVideo : public UObject
{
public:
    UEpicStreamMediaSource* MediaSource() const { return Read<UEpicStreamMediaSource*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    UMediaPlayer* MediaPlayer() const { return Read<UMediaPlayer*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FIntPoint VideoSize() const { return Read<FIntPoint>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: StructProperty)
    FEpicMediaPriorityInfo PriorityInfo() const { return Read<FEpicMediaPriorityInfo>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x3, Type: StructProperty)
    USoundSubmixBase* DefaultSubmix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* LicensedSubmix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* MediaSoundComponent() const { return Read<UMediaSoundComponent*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* PendingMediaTexture() const { return Read<UMediaTexture*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    bool bAwaitingRetry() const { return Read<bool>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: BoolProperty)
    float RetryDelayElapsed() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)

    void SET_MediaSource(const UEpicStreamMediaSource*& Value) { Write<UEpicStreamMediaSource*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
    void SET_MediaPlayer(const UMediaPlayer*& Value) { Write<UMediaPlayer*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_VideoSize(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: StructProperty)
    void SET_PriorityInfo(const FEpicMediaPriorityInfo& Value) { Write<FEpicMediaPriorityInfo>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x3, Type: StructProperty)
    void SET_DefaultSubmix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_LicensedSubmix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_MediaSoundComponent(const UMediaSoundComponent*& Value) { Write<UMediaSoundComponent*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_PendingMediaTexture(const UMediaTexture*& Value) { Write<UMediaTexture*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_bAwaitingRetry(const bool& Value) { Write<bool>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: BoolProperty)
    void SET_RetryDelayElapsed(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3
struct FEpicMediaPriorityInfo
{
public:
    bool bCanBeInterrupted() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bCanInterruptOtherAndHold() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)

    void SET_bCanBeInterrupted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bCanInterruptOtherAndHold(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xf8
struct FEpicMediaPriorityPendingInfo
{
public:
    UMediaTexture* MediaTexture() const { return Read<UMediaTexture*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FMediaPlayerOptions MediaOptions() const { return Read<FMediaPlayerOptions>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xc8, Type: StructProperty)
    FEpicMediaPriorityInfo PriorityInfo() const { return Read<FEpicMediaPriorityInfo>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x3, Type: StructProperty)

    void SET_MediaTexture(const UMediaTexture*& Value) { Write<UMediaTexture*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_MediaOptions(const FMediaPlayerOptions& Value) { Write<FMediaPlayerOptions>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xc8, Type: StructProperty)
    void SET_PriorityInfo(const FEpicMediaPriorityInfo& Value) { Write<FEpicMediaPriorityInfo>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x3, Type: StructProperty)
};

