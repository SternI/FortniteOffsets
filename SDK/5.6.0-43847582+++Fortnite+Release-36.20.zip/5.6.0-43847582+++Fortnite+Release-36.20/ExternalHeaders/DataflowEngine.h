/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "DataflowCore.h"
#include "CoreUObject.h"

// Size: 0x580
class UDataflowDebugDrawComponent : public UDebugDrawComponent
{
public:
};

// Size: 0x28
class UDataflowInstanceInterface : public UInterface
{
public:
};

// Size: 0x40
class UDataflowMesh : public UObject
{
public:
    TArray<UMaterialInterface*> Materials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Materials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UDataflowSubGraph : public UEdGraph
{
public:
    FGuid SubGraphGuid() const { return Read<FGuid>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)
    bool bIsForEach() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_SubGraphGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
    void SET_bIsForEach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UDataflowBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UDataflowContentOwner : public UInterface
{
public:
};

// Size: 0xa8
class UDataflowBaseContent : public UDataflowContextObject
{
public:
    FString DataflowTerminal() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    UObject* TerminalAsset() const { return Read<UObject*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    bool bIsConstructionDirty() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    bool bIsSimulationDirty() const { return Read<bool>(uintptr_t(this) + 0x99); } // 0x99 (Size: 0x1, Type: BoolProperty)

    void SET_DataflowTerminal(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_TerminalAsset(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsConstructionDirty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSimulationDirty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x99, Value); } // 0x99 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UDataflowContextObject : public UObject
{
public:
    UDataflowEdNode* SelectedNode() const { return Read<UDataflowEdNode*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UDataflow* DataflowGraph() const { return Read<UDataflow*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)

    void SET_SelectedNode(const UDataflowEdNode*& Value) { Write<UDataflowEdNode*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_DataflowGraph(const UDataflow*& Value) { Write<UDataflow*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc0
class UDataflowSkeletalContent : public UDataflowBaseContent
{
public:
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UAnimationAsset* AnimationAsset() const { return Read<UAnimationAsset*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)

    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimationAsset(const UAnimationAsset*& Value) { Write<UAnimationAsset*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
class UDataflowEdNode : public UEdGraphNode
{
public:
    bool bRenderInAssetEditor() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool bRenderWireframeInAssetEditor() const { return Read<bool>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool bCanEnableRenderWireframe() const { return Read<bool>(uintptr_t(this) + 0xba); } // 0xba (Size: 0x1, Type: BoolProperty)

    void SET_bRenderInAssetEditor(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_bRenderWireframeInAssetEditor(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    void SET_bCanEnableRenderWireframe(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba, Value); } // 0xba (Size: 0x1, Type: BoolProperty)
};

// Size: 0x108
class UDataflow : public UEdGraph
{
public:
    bool bActive() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    TArray<UObject*> Targets() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    UMaterial* Material() const { return Read<UMaterial*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    FInstancedPropertyBag Variables() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    TArray<UDataflowSubGraph*> DataflowSubGraphs() const { return Read<TArray<UDataflowSubGraph*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)

    void SET_bActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_Targets(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_Material(const UMaterial*& Value) { Write<UMaterial*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_Variables(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_DataflowSubGraphs(const TArray<UDataflowSubGraph*>& Value) { Write<TArray<UDataflowSubGraph*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDataflowNodeDebugDrawSettings
{
public:
    uint8_t RenderType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bTranslucent() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    float LineWidthMultiplier() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_RenderType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_bTranslucent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_LineWidthMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
struct FDataflowNodeSphereCoveringDebugDrawSettings
{
public:
    bool bDisplaySphereCovering() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t RenderType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    bool bTranslucent() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    float LineWidthMultiplier() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t ColorMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)
    int32_t ColorRandomSeed() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    FLinearColor ColorA() const { return Read<FLinearColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FLinearColor ColorB() const { return Read<FLinearColor>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_bDisplaySphereCovering(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_RenderType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_bTranslucent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_LineWidthMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ColorMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
    void SET_ColorRandomSeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_ColorA(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_ColorB(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x68
struct FDataflowProxyElement : public FDataflowBaseElement
{
public:
};

// Size: 0x78
struct FDataflowDynamicConnections
{
public:
    TArray<FDataflowAllTypes> DynamicProperties() const { return Read<TArray<FDataflowAllTypes>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_DynamicProperties(const TArray<FDataflowAllTypes>& Value) { Write<TArray<FDataflowAllTypes>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FStringValuePair
{
public:
    FString Key() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Key(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
struct FDataflowVariableOverrides
{
public:
    FInstancedPropertyBag Variables() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> OverriddenVariableGuids() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Variables(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_OverriddenVariableGuids(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FDataflowInstance
{
public:
    UDataflow* DataflowAsset() const { return Read<UDataflow*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName DataflowTerminal() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FDataflowVariableOverrides VariableOverrides() const { return Read<FDataflowVariableOverrides>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)
    UObject* Owner() const { return Read<UObject*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_DataflowAsset(const UDataflow*& Value) { Write<UDataflow*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_DataflowTerminal(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_VariableOverrides(const FDataflowVariableOverrides& Value) { Write<FDataflowVariableOverrides>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
    void SET_Owner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x24
struct FDataflowPreviewCacheParams
{
public:
    int32_t FrameRate() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SubframeRate() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    bool bCanEditSubframeRate() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    FVector2f TimeRange() const { return Read<FVector2f>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x8, Type: StructProperty)
    bool bRestartSimulation() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    FVector2f RestartTimeRange() const { return Read<FVector2f>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    bool bAsyncCaching() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_FrameRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SubframeRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_bCanEditSubframeRate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_TimeRange(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x8, Type: StructProperty)
    void SET_bRestartSimulation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_RestartTimeRange(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_bAsyncCaching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x310
struct FDataflowSubGraphInputNode : public FDataflowNode
{
public:
    FDataflowDynamicConnections DynamicConnections() const { return Read<FDataflowDynamicConnections>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag PropertyBag() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: StructProperty)

    void SET_DynamicConnections(const FDataflowDynamicConnections& Value) { Write<FDataflowDynamicConnections>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x78, Type: StructProperty)
    void SET_PropertyBag(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: StructProperty)
};

// Size: 0x310
struct FDataflowSubGraphOutputNode : public FDataflowNode
{
public:
    FDataflowDynamicConnections DynamicConnections() const { return Read<FDataflowDynamicConnections>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag PropertyBag() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: StructProperty)

    void SET_DynamicConnections(const FDataflowDynamicConnections& Value) { Write<FDataflowDynamicConnections>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x78, Type: StructProperty)
    void SET_PropertyBag(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: StructProperty)
};

// Size: 0x288
struct FDataflowSubGraphGetCurrentIndexNode : public FDataflowNode
{
public:
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x4, Type: IntProperty)

    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x4, Type: IntProperty)
};

// Size: 0x3c0
struct FDataflowCallSubGraphNode : public FDataflowNode
{
public:
    FGuid SubGraphGuid() const { return Read<FGuid>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StructProperty)
    FDataflowDynamicConnections DynamicInputs() const { return Read<FDataflowDynamicConnections>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag InputsPropertyBag() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x10, Type: StructProperty)
    FDataflowDynamicConnections DynamicOutputs() const { return Read<FDataflowDynamicConnections>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag OutputsPropertyBag() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StructProperty)

    void SET_SubGraphGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StructProperty)
    void SET_DynamicInputs(const FDataflowDynamicConnections& Value) { Write<FDataflowDynamicConnections>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x78, Type: StructProperty)
    void SET_InputsPropertyBag(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x10, Type: StructProperty)
    void SET_DynamicOutputs(const FDataflowDynamicConnections& Value) { Write<FDataflowDynamicConnections>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x78, Type: StructProperty)
    void SET_OutputsPropertyBag(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x2b0
struct FDataflowTextureTerminalNode : public FDataflowTerminalNode
{
public:
    FDataflowImage Image() const { return Read<FDataflowImage>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    UTexture2D* TextureAsset() const { return Read<UTexture2D*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_Image(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_TextureAsset(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b0
struct FDataflowTextureToImageNode : public FDataflowNode
{
public:
    UTexture2D* TextureAsset() const { return Read<UTexture2D*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    FDataflowImage Image() const { return Read<FDataflowImage>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x28, Type: StructProperty)

    void SET_TextureAsset(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_Image(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x28, Type: StructProperty)
};

// Size: 0x2b8
struct FDataflowImageToTextureNode : public FDataflowNode
{
public:
    FDataflowImage Image() const { return Read<FDataflowImage>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x28, Type: StructProperty)
    FName TextureName() const { return Read<FName>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: NameProperty)
    UTexture2D* TransientTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_Image(const FDataflowImage& Value) { Write<FDataflowImage>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x28, Type: StructProperty)
    void SET_TextureName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: NameProperty)
    void SET_TransientTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b8
struct FGetDataflowVariableNode : public FDataflowNode
{
public:
    FDataflowAnyType Value() const { return Read<FDataflowAnyType>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: StructProperty)
    FInstancedPropertyBag VariablePropertyBag() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x10, Type: StructProperty)
    FName VariableName() const { return Read<FName>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x4, Type: NameProperty)

    void SET_Value(const FDataflowAnyType& Value) { Write<FDataflowAnyType>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: StructProperty)
    void SET_VariablePropertyBag(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x10, Type: StructProperty)
    void SET_VariableName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x4, Type: NameProperty)
};

