/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaMatchmakingSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x48
class UDianaMatchmakingSettingsUI : public UMatchmakingSettingsUI
{
public:
};

