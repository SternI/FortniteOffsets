/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_FabricMIDIPlayerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "FabricLevelSequencer.h"

// Size: 0x5d0 (Inherited: 0x16a0, Single: 0xffffef30)
class UFabricCreativePropertyEditWidgetMidiSourceBase : public UCreativePropertyEditWidgetUserOptionBase
{
public:
    FMidiSource MidiSourceOptionValue; // 0x5b8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFabricCreativePropertyEditWidgetMidiSourceBase) == 0x5d0, "Size mismatch for UFabricCreativePropertyEditWidgetMidiSourceBase");
static_assert(offsetof(UFabricCreativePropertyEditWidgetMidiSourceBase, MidiSourceOptionValue) == 0x5b8, "Offset mismatch for UFabricCreativePropertyEditWidgetMidiSourceBase::MidiSourceOptionValue");

