/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioLinkEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioLinkBlueprintInterface : public UInterface
{
public:

public:
    bool IsLinkPlaying() const; // 0x50c33cc (Index: 0x0, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PlayLink(float& StartTime); // 0x494acc4 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void SetLinkSound(USoundBase*& NewSound); // 0xa169a88 (Index: 0x2, Flags: Native|Public|BlueprintCallable)
    void StopLink(); // 0x4e84278 (Index: 0x3, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioLinkBlueprintInterface) == 0x28, "Size mismatch for UAudioLinkBlueprintInterface");

