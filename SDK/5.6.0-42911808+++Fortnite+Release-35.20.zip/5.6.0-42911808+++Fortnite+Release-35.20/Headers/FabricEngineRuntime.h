/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricEngineRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricAudioSyncProvider : public UInterface
{
public:
};

static_assert(sizeof(UFabricAudioSyncProvider) == 0x28, "Size mismatch for UFabricAudioSyncProvider");

