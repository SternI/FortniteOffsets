/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamInLobbyRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FMJamSystemRuntime.h"
#include "FortniteGame.h"
#include "FMJamPlayspaceRuntime.h"
#include "SparksMusicPlayspaceRuntime.h"
#include "PlayspaceSystem.h"
#include "GameplayEventRouter.h"
#include "GameplayTags.h"

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UJamInLobbyConfig : public UPrimaryDataAsset
{
public:
    TArray<FJamInLobbyEnableCondition> JamInLobbyEnabledConditions; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UJamInLobbyConfig) == 0x40, "Size mismatch for UJamInLobbyConfig");
static_assert(offsetof(UJamInLobbyConfig, JamInLobbyEnabledConditions) == 0x30, "Offset mismatch for UJamInLobbyConfig::JamInLobbyEnabledConditions");

// Size: 0x158 (Inherited: 0x388, Single: 0xfffffdd0)
class UJamInLobbyControllerComponent_LoopOptions : public UJamControllerComponent_LoopOptions
{
public:

protected:
    void HandleOnNewPlayspaceForPlayer(APlayspace*& Playspace, const FPlayspaceJurisdictionFilter Filter); // 0x1110e84c (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnAthenaProfileInventoryUpdated(const TSet<FString> UpdatedItems, int64_t& ProfileRevision); // 0x1110eaf8 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void OnAthenaProfileLoadoutChanged(); // 0x1110ed08 (Index: 0x2, Flags: Final|Native|Protected)
    void OnPlayerProfileInitialized(); // 0x6071618 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UJamInLobbyControllerComponent_LoopOptions) == 0x158, "Size mismatch for UJamInLobbyControllerComponent_LoopOptions");

// Size: 0x108 (Inherited: 0x308, Single: 0xfffffe00)
class UFortGameStateComponent_JamInLobbyPlayspaceManager : public UFortGameStateComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    TSoftClassPtr PlayspaceClassToSpawn; // 0xc0 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_e0[0x20]; // 0xe0 (Size: 0x20, Type: PaddingProperty)
    UJamInLobbyConfig* JamInLobbyConfig; // 0x100 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortGameStateComponent_JamInLobbyPlayspaceManager) == 0x108, "Size mismatch for UFortGameStateComponent_JamInLobbyPlayspaceManager");
static_assert(offsetof(UFortGameStateComponent_JamInLobbyPlayspaceManager, PlayspaceClassToSpawn) == 0xc0, "Offset mismatch for UFortGameStateComponent_JamInLobbyPlayspaceManager::PlayspaceClassToSpawn");
static_assert(offsetof(UFortGameStateComponent_JamInLobbyPlayspaceManager, JamInLobbyConfig) == 0x100, "Offset mismatch for UFortGameStateComponent_JamInLobbyPlayspaceManager::JamInLobbyConfig");

// Size: 0x8c8 (Inherited: 0x21b8, Single: 0xffffe710)
class AJamInLobbyPlayspace : public AJamPlayspace
{
public:
    uint8_t Pad_828[0x18]; // 0x828 (Size: 0x18, Type: PaddingProperty)
    UAudioComponent* JamAudioSource; // 0x840 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_848[0x20]; // 0x848 (Size: 0x20, Type: PaddingProperty)
    FGameplayEventListenerHandle OnKeyChangedEventHandle; // 0x868 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle OnModeChangedEventHandle; // 0x884 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle OnTempoChangedEventHandle; // 0x8a0 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_8bc[0xc]; // 0x8bc (Size: 0xc, Type: PaddingProperty)

public:
    FUniqueNetIdRepl GetUserNetIdFromLoopInstanceId(int32_t& const LoopInstanceId) const; // 0x1110e518 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void HandleOnKeyChangedEvent(const FSparksPlayspaceEvent_KeyChanged Payload); // 0x1110e6cc (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void HandleOnModeChangedEvent(const FSparksPlayspaceEvent_KeyModeChanged Payload); // 0x1110e78c (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    void HandleOnTempoChangedEvent(const FSparksPlayspaceEvent_TempoChanged Payload); // 0x1110ea38 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(AJamInLobbyPlayspace) == 0x8c8, "Size mismatch for AJamInLobbyPlayspace");
static_assert(offsetof(AJamInLobbyPlayspace, JamAudioSource) == 0x840, "Offset mismatch for AJamInLobbyPlayspace::JamAudioSource");
static_assert(offsetof(AJamInLobbyPlayspace, OnKeyChangedEventHandle) == 0x868, "Offset mismatch for AJamInLobbyPlayspace::OnKeyChangedEventHandle");
static_assert(offsetof(AJamInLobbyPlayspace, OnModeChangedEventHandle) == 0x884, "Offset mismatch for AJamInLobbyPlayspace::OnModeChangedEventHandle");
static_assert(offsetof(AJamInLobbyPlayspace, OnTempoChangedEventHandle) == 0x8a0, "Offset mismatch for AJamInLobbyPlayspace::OnTempoChangedEventHandle");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FJamInLobbyEnableCondition
{
    FGameplayTagQuery TagQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    FString RequiredCVar; // 0x48 (Size: 0x10, Type: StrProperty)
    bool bAlwaysDisableJamInLobby; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FJamInLobbyEnableCondition) == 0x60, "Size mismatch for FJamInLobbyEnableCondition");
static_assert(offsetof(FJamInLobbyEnableCondition, TagQuery) == 0x0, "Offset mismatch for FJamInLobbyEnableCondition::TagQuery");
static_assert(offsetof(FJamInLobbyEnableCondition, RequiredCVar) == 0x48, "Offset mismatch for FJamInLobbyEnableCondition::RequiredCVar");
static_assert(offsetof(FJamInLobbyEnableCondition, bAlwaysDisableJamInLobby) == 0x58, "Offset mismatch for FJamInLobbyEnableCondition::bAlwaysDisableJamInLobby");

