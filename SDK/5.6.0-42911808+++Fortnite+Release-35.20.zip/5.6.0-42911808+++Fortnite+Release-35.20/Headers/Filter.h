/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Filter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "UMG.h"
#include "UIKit.h"
#include "CompeteUI.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "Systems.h"

// Size: 0x470 (Inherited: 0xb38, Single: 0xfffff938)
class UWBP_TournamentsFilter_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Dialog_Base_C* WBP_UIKit_Dialog_Base; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_TournamentFilter; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TournamentType; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TournamentStatus; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TeamSize; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Region; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Experience; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Eligibility; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Bookmarks; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Cancel; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_ApplyFilters; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarFilterVM* FortPoblanoTournamentsCalendarFilterVM; // 0x468 (Size: 0x8, Type: ObjectProperty)

public:
    void SetMobileStyle(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortPoblanoTournamentsCalendarFilterVM(UFortPoblanoTournamentsCalendarFilterVM*& ViewModel); // 0x288a61c (Index: 0x1, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void GetRegionName(FText& Text, FText& FormatedText); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void Construct(); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x9, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UWBP_TournamentsFilter_C) == 0x470, "Size mismatch for UWBP_TournamentsFilter_C");
static_assert(offsetof(UWBP_TournamentsFilter_C, UberGraphFrame) == 0x408, "Offset mismatch for UWBP_TournamentsFilter_C::UberGraphFrame");
static_assert(offsetof(UWBP_TournamentsFilter_C, WBP_UIKit_Dialog_Base) == 0x410, "Offset mismatch for UWBP_TournamentsFilter_C::WBP_UIKit_Dialog_Base");
static_assert(offsetof(UWBP_TournamentsFilter_C, Text_TournamentFilter) == 0x418, "Offset mismatch for UWBP_TournamentsFilter_C::Text_TournamentFilter");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_TournamentType) == 0x420, "Offset mismatch for UWBP_TournamentsFilter_C::Section_TournamentType");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_TournamentStatus) == 0x428, "Offset mismatch for UWBP_TournamentsFilter_C::Section_TournamentStatus");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_TeamSize) == 0x430, "Offset mismatch for UWBP_TournamentsFilter_C::Section_TeamSize");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_Region) == 0x438, "Offset mismatch for UWBP_TournamentsFilter_C::Section_Region");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_Experience) == 0x440, "Offset mismatch for UWBP_TournamentsFilter_C::Section_Experience");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_Eligibility) == 0x448, "Offset mismatch for UWBP_TournamentsFilter_C::Section_Eligibility");
static_assert(offsetof(UWBP_TournamentsFilter_C, Section_Bookmarks) == 0x450, "Offset mismatch for UWBP_TournamentsFilter_C::Section_Bookmarks");
static_assert(offsetof(UWBP_TournamentsFilter_C, Button_Cancel) == 0x458, "Offset mismatch for UWBP_TournamentsFilter_C::Button_Cancel");
static_assert(offsetof(UWBP_TournamentsFilter_C, Button_ApplyFilters) == 0x460, "Offset mismatch for UWBP_TournamentsFilter_C::Button_ApplyFilters");
static_assert(offsetof(UWBP_TournamentsFilter_C, FortPoblanoTournamentsCalendarFilterVM) == 0x468, "Offset mismatch for UWBP_TournamentsFilter_C::FortPoblanoTournamentsCalendarFilterVM");

// Size: 0x3c1 (Inherited: 0x730, Single: 0xfffffc91)
class UWBP_TournamentsFilter_Section_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UUniformGridPanel* UniformGridPanel_Filters; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_SectionName; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ButtonWithToggle_C* SelectedRadioToggle; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    TArray<UWBP_TournamentFilter_SortToggleButton_C*> FilterSectionEntries; // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    bool bRadioType; // 0x308 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_309[0x3]; // 0x309 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxElementsPerRow; // 0x30c (Size: 0x4, Type: IntProperty)
    TArray<bool> ToggleValues; // 0x310 (Size: 0x10, Type: ArrayProperty)
    TMap<TSoftObjectPtr<UTexture*>, ETournamentType> TournamentTypesIcons; // 0x320 (Size: 0x50, Type: MapProperty)
    TMap<TSoftObjectPtr<UTexture*>, ETournamentTypeFilter> TournamentTypesFilterIcons; // 0x370 (Size: 0x50, Type: MapProperty)
    bool IsShowIcons; // 0x3c0 (Size: 0x1, Type: BoolProperty)

public:
    void BindToggleDelegates(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateToggleValues(TArray<bool> Values); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetToggleType(TEnumAsByte<E_UI_ToggleType>& ToggleType); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetToggleSelectionStateByIndex(bool& bSelected, int32_t& Index); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetTogglePosition(UWidget*& ToggleButton, int32_t& Index); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetToggleEnabled(bool& bEnabled, int32_t& Index); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFilterSectionName(FText& InText); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x8, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnToggleSelected(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0x9, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnToggleDeselected(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0xa, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnToggleClicked(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void IsFilterEntriesEmpty(bool& bEmpty); // 0x288a61c (Index: 0xc, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void GetFilterIconFromEnum(ETournamentTypeFilter& FilterEnum, TSoftObjectPtr<UTexture*>& Texture); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Get_Selected_Filters(TArray<UWBP_TournamentFilter_SortToggleButton_C*>& Filters); // 0x288a61c (Index: 0xe, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Create_Filters_Buttons(FTournamentsFilterSection& FilterData); // 0x288a61c (Index: 0x10, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_TournamentsFilter_Section_C) == 0x3c1, "Size mismatch for UWBP_TournamentsFilter_Section_C");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_TournamentsFilter_Section_C::UberGraphFrame");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, UniformGridPanel_Filters) == 0x2e0, "Offset mismatch for UWBP_TournamentsFilter_Section_C::UniformGridPanel_Filters");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, Text_SectionName) == 0x2e8, "Offset mismatch for UWBP_TournamentsFilter_Section_C::Text_SectionName");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, SelectedRadioToggle) == 0x2f0, "Offset mismatch for UWBP_TournamentsFilter_Section_C::SelectedRadioToggle");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, FilterSectionEntries) == 0x2f8, "Offset mismatch for UWBP_TournamentsFilter_Section_C::FilterSectionEntries");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, bRadioType) == 0x308, "Offset mismatch for UWBP_TournamentsFilter_Section_C::bRadioType");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, MaxElementsPerRow) == 0x30c, "Offset mismatch for UWBP_TournamentsFilter_Section_C::MaxElementsPerRow");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, ToggleValues) == 0x310, "Offset mismatch for UWBP_TournamentsFilter_Section_C::ToggleValues");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, TournamentTypesIcons) == 0x320, "Offset mismatch for UWBP_TournamentsFilter_Section_C::TournamentTypesIcons");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, TournamentTypesFilterIcons) == 0x370, "Offset mismatch for UWBP_TournamentsFilter_Section_C::TournamentTypesFilterIcons");
static_assert(offsetof(UWBP_TournamentsFilter_Section_C, IsShowIcons) == 0x3c0, "Offset mismatch for UWBP_TournamentsFilter_Section_C::IsShowIcons");

// Size: 0x18e8 (Inherited: 0x617d, Single: 0xffffb76b)
class UWBP_TournamentFilter_SortToggleButton_C : public UWBP_UIKit_ButtonWithToggle_C
{
public:
    uint8_t Pad_1889[0x7]; // 0x1889 (Size: 0x7, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x1890 (Size: 0x8, Type: StructProperty)
    uint8_t OnToggleClicked[0x10]; // 0x1898 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float MainPaddingLeft; // 0x18a8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_18ac[0x4]; // 0x18ac (Size: 0x4, Type: PaddingProperty)
    uint8_t OnToggleSelected[0x10]; // 0x18b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnToggleDeselected[0x10]; // 0x18c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UMaterialInstance* ToggleIconMaterial; // 0x18d0 (Size: 0x8, Type: ObjectProperty)
    FText FilterName; // 0x18d8 (Size: 0x10, Type: TextProperty)

public:
    void SetFilterIcon(UObject*& Icon); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnToggleSelected__DelegateSignature(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnToggleDeselected__DelegateSignature(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0x3, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnToggleClicked__DelegateSignature(UWBP_TournamentFilter_SortToggleButton_C*& Button); // 0x288a61c (Index: 0x4, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SetSlotValues(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetIconSlotValues(); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFilterIconFromTexture(TSoftObjectPtr<UTexture*>& Texture); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnSelected(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnPressed(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeselected(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_TournamentFilter_SortToggleButton_C) == 0x18e8, "Size mismatch for UWBP_TournamentFilter_SortToggleButton_C");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, UberGraphFrame) == 0x1890, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::UberGraphFrame");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, OnToggleClicked) == 0x1898, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::OnToggleClicked");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, MainPaddingLeft) == 0x18a8, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::MainPaddingLeft");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, OnToggleSelected) == 0x18b0, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::OnToggleSelected");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, OnToggleDeselected) == 0x18c0, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::OnToggleDeselected");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, ToggleIconMaterial) == 0x18d0, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::ToggleIconMaterial");
static_assert(offsetof(UWBP_TournamentFilter_SortToggleButton_C, FilterName) == 0x18d8, "Offset mismatch for UWBP_TournamentFilter_SortToggleButton_C::FilterName");

