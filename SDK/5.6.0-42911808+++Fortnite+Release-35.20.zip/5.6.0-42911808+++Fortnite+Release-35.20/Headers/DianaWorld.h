/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaWorld
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "JunoProceduralWorld.h"

// Size: 0xc0 (Inherited: 0x138, Single: 0xffffff88)
class UDianaWorldTileSelection : public UJunoWorldTileSelectionBase
{
public:
};

static_assert(sizeof(UDianaWorldTileSelection) == 0xc0, "Size mismatch for UDianaWorldTileSelection");

