/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeEditCameraModeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x548 (Inherited: 0xf20, Single: 0xfffff628)
class AFortCreativeEditCameraController : public AFortFirstPersonCameraController
{
public:
    FCreativeOptionVariableBase WantsToImmersiveEdit; // 0x518 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_520[0x28]; // 0x520 (Size: 0x28, Type: PaddingProperty)

private:
    void HandleWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x11a5ce90 (Index: 0x0, Flags: Final|Native|Private)
    void OnCreativeEditModeChanged(bool& bIsCreativeEditModeEnabled); // 0x11a5d098 (Index: 0x1, Flags: Final|Native|Private)
    void OnWantsToImmersiveEditChanged(UFortCreativeOption*& CreativeOption, char& IndexValue); // 0x11a5d1c4 (Index: 0x2, Flags: Final|Native|Private)
    virtual void ServerSetImmersiveEdit(bool& const bWantsToImmersiveEdit, bool& const bIsCreativeEditModeEnabled); // 0x11a5d3cc (Index: 0x3, Flags: Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate)
};

static_assert(sizeof(AFortCreativeEditCameraController) == 0x548, "Size mismatch for AFortCreativeEditCameraController");
static_assert(offsetof(AFortCreativeEditCameraController, WantsToImmersiveEdit) == 0x518, "Offset mismatch for AFortCreativeEditCameraController::WantsToImmersiveEdit");

