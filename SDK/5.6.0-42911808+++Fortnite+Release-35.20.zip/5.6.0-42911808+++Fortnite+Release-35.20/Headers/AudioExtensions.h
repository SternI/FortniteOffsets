/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioExtensions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioPropertiesSheetAssetUserInterface : public UInterface
{
public:
};

static_assert(sizeof(UAudioPropertiesSheetAssetUserInterface) == 0x28, "Size mismatch for UAudioPropertiesSheetAssetUserInterface");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAudioPropertiesSheetAssetBase : public UObject
{
public:
};

static_assert(sizeof(UAudioPropertiesSheetAssetBase) == 0x28, "Size mismatch for UAudioPropertiesSheetAssetBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class USpatializationPluginSourceSettingsBase : public UObject
{
public:
};

static_assert(sizeof(USpatializationPluginSourceSettingsBase) == 0x28, "Size mismatch for USpatializationPluginSourceSettingsBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class USourceDataOverridePluginSourceSettingsBase : public UObject
{
public:
};

static_assert(sizeof(USourceDataOverridePluginSourceSettingsBase) == 0x28, "Size mismatch for USourceDataOverridePluginSourceSettingsBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UOcclusionPluginSourceSettingsBase : public UObject
{
public:
};

static_assert(sizeof(UOcclusionPluginSourceSettingsBase) == 0x28, "Size mismatch for UOcclusionPluginSourceSettingsBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UReverbPluginSourceSettingsBase : public UObject
{
public:
};

static_assert(sizeof(UReverbPluginSourceSettingsBase) == 0x28, "Size mismatch for UReverbPluginSourceSettingsBase");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioParameterControllerInterface : public UInterface
{
public:

public:
    void ResetParameters(); // 0x4e3f4f8 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    void SetBoolArrayParameter(FName& InName, const TArray<bool> InValue); // 0x98f9c18 (Index: 0x1, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetBoolParameter(FName& InName, bool& InBool); // 0x53d95d8 (Index: 0x2, Flags: Native|Public|BlueprintCallable)
    void SetFloatArrayParameter(FName& InName, const TArray<float> InValue); // 0x98f9f88 (Index: 0x3, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetFloatParameter(FName& InName, float& InFloat); // 0x36944d4 (Index: 0x4, Flags: Native|Public|BlueprintCallable)
    void SetIntArrayParameter(FName& InName, const TArray<int32_t> InValue); // 0x98fa2f8 (Index: 0x5, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetIntParameter(FName& InName, int32_t& inInt); // 0x98fa668 (Index: 0x6, Flags: Native|Public|BlueprintCallable)
    void SetObjectArrayParameter(FName& InName, const TArray<UObject*> InValue); // 0x469bb34 (Index: 0x7, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetObjectParameter(FName& InName, UObject*& InValue); // 0x5513f10 (Index: 0x8, Flags: Native|Public|BlueprintCallable)
    void SetParameters_Blueprint(const TArray<FAudioParameter> InParameters); // 0x443a1d4 (Index: 0x9, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetStringArrayParameter(FName& InName, const TArray<FString> InValue); // 0x98fa870 (Index: 0xa, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetStringParameter(FName& InName, FString& InValue); // 0x98faa30 (Index: 0xb, Flags: Native|Public|BlueprintCallable)
    void SetTriggerParameter(FName& InName); // 0x3694ca0 (Index: 0xc, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioParameterControllerInterface) == 0x28, "Size mismatch for UAudioParameterControllerInterface");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAudioEndpointSettingsBase : public UObject
{
public:
};

static_assert(sizeof(UAudioEndpointSettingsBase) == 0x28, "Size mismatch for UAudioEndpointSettingsBase");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDummyEndpointSettings : public UAudioEndpointSettingsBase
{
public:
};

static_assert(sizeof(UDummyEndpointSettings) == 0x28, "Size mismatch for UDummyEndpointSettings");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class USoundModulatorBase : public UObject
{
public:
};

static_assert(sizeof(USoundModulatorBase) == 0x30, "Size mismatch for USoundModulatorBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class USoundfieldEndpointSettingsBase : public UObject
{
public:
};

static_assert(sizeof(USoundfieldEndpointSettingsBase) == 0x28, "Size mismatch for USoundfieldEndpointSettingsBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class USoundfieldEncodingSettingsBase : public UObject
{
public:
};

static_assert(sizeof(USoundfieldEncodingSettingsBase) == 0x28, "Size mismatch for USoundfieldEncodingSettingsBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class USoundfieldEffectSettingsBase : public UObject
{
public:
};

static_assert(sizeof(USoundfieldEffectSettingsBase) == 0x28, "Size mismatch for USoundfieldEffectSettingsBase");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class USoundfieldEffectBase : public UObject
{
public:
    USoundfieldEffectSettingsBase* Settings; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(USoundfieldEffectBase) == 0x30, "Size mismatch for USoundfieldEffectBase");
static_assert(offsetof(USoundfieldEffectBase, Settings) == 0x28, "Offset mismatch for USoundfieldEffectBase::Settings");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UWaveformTransformationBase : public UObject
{
public:
};

static_assert(sizeof(UWaveformTransformationBase) == 0x28, "Size mismatch for UWaveformTransformationBase");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UWaveformTransformationChain : public UObject
{
public:
    TArray<UWaveformTransformationBase*> Transformations; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UWaveformTransformationChain) == 0x38, "Size mismatch for UWaveformTransformationChain");
static_assert(offsetof(UWaveformTransformationChain, Transformations) == 0x28, "Offset mismatch for UWaveformTransformationChain::Transformations");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FSoundGeneratorOutput
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FSoundGeneratorOutput) == 0x4, "Size mismatch for FSoundGeneratorOutput");
static_assert(offsetof(FSoundGeneratorOutput, Name) == 0x0, "Offset mismatch for FSoundGeneratorOutput::Name");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FSoundWaveCloudStreamingPlatformProjectSettings
{
    uint8_t EnablementSetting; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FSoundWaveCloudStreamingPlatformProjectSettings) == 0x1, "Size mismatch for FSoundWaveCloudStreamingPlatformProjectSettings");
static_assert(offsetof(FSoundWaveCloudStreamingPlatformProjectSettings, EnablementSetting) == 0x0, "Offset mismatch for FSoundWaveCloudStreamingPlatformProjectSettings::EnablementSetting");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FSoundWaveCloudStreamingPlatformSettings
{
    uint8_t EnablementSetting; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FSoundWaveCloudStreamingPlatformSettings) == 0x1, "Size mismatch for FSoundWaveCloudStreamingPlatformSettings");
static_assert(offsetof(FSoundWaveCloudStreamingPlatformSettings, EnablementSetting) == 0x0, "Offset mismatch for FSoundWaveCloudStreamingPlatformSettings::EnablementSetting");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FAudioParameter
{
    FName ParamName; // 0x0 (Size: 0x4, Type: NameProperty)
    float FloatParam; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool BoolParam; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    int32_t IntParam; // 0xc (Size: 0x4, Type: IntProperty)
    UObject* ObjectParam; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FString StringParam; // 0x18 (Size: 0x10, Type: StrProperty)
    TArray<float> ArrayFloatParam; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<bool> ArrayBoolParam; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ArrayIntParam; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> ArrayObjectParam; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ArrayStringParam; // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t ParamType; // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_79[0x3]; // 0x79 (Size: 0x3, Type: PaddingProperty)
    FName TypeName; // 0x7c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_80[0x10]; // 0x80 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FAudioParameter) == 0x90, "Size mismatch for FAudioParameter");
static_assert(offsetof(FAudioParameter, ParamName) == 0x0, "Offset mismatch for FAudioParameter::ParamName");
static_assert(offsetof(FAudioParameter, FloatParam) == 0x4, "Offset mismatch for FAudioParameter::FloatParam");
static_assert(offsetof(FAudioParameter, BoolParam) == 0x8, "Offset mismatch for FAudioParameter::BoolParam");
static_assert(offsetof(FAudioParameter, IntParam) == 0xc, "Offset mismatch for FAudioParameter::IntParam");
static_assert(offsetof(FAudioParameter, ObjectParam) == 0x10, "Offset mismatch for FAudioParameter::ObjectParam");
static_assert(offsetof(FAudioParameter, StringParam) == 0x18, "Offset mismatch for FAudioParameter::StringParam");
static_assert(offsetof(FAudioParameter, ArrayFloatParam) == 0x28, "Offset mismatch for FAudioParameter::ArrayFloatParam");
static_assert(offsetof(FAudioParameter, ArrayBoolParam) == 0x38, "Offset mismatch for FAudioParameter::ArrayBoolParam");
static_assert(offsetof(FAudioParameter, ArrayIntParam) == 0x48, "Offset mismatch for FAudioParameter::ArrayIntParam");
static_assert(offsetof(FAudioParameter, ArrayObjectParam) == 0x58, "Offset mismatch for FAudioParameter::ArrayObjectParam");
static_assert(offsetof(FAudioParameter, ArrayStringParam) == 0x68, "Offset mismatch for FAudioParameter::ArrayStringParam");
static_assert(offsetof(FAudioParameter, ParamType) == 0x78, "Offset mismatch for FAudioParameter::ParamType");
static_assert(offsetof(FAudioParameter, TypeName) == 0x7c, "Offset mismatch for FAudioParameter::TypeName");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FSoundWaveCuePoint
{
    int32_t CuePointID; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString Label; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t FramePosition; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t FrameLength; // 0x1c (Size: 0x4, Type: IntProperty)
    bool bIsLoopRegion; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSoundWaveCuePoint) == 0x28, "Size mismatch for FSoundWaveCuePoint");
static_assert(offsetof(FSoundWaveCuePoint, CuePointID) == 0x0, "Offset mismatch for FSoundWaveCuePoint::CuePointID");
static_assert(offsetof(FSoundWaveCuePoint, Label) == 0x8, "Offset mismatch for FSoundWaveCuePoint::Label");
static_assert(offsetof(FSoundWaveCuePoint, FramePosition) == 0x18, "Offset mismatch for FSoundWaveCuePoint::FramePosition");
static_assert(offsetof(FSoundWaveCuePoint, FrameLength) == 0x1c, "Offset mismatch for FSoundWaveCuePoint::FrameLength");
static_assert(offsetof(FSoundWaveCuePoint, bIsLoopRegion) == 0x20, "Offset mismatch for FSoundWaveCuePoint::bIsLoopRegion");

