/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AmpleHammer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UAmpleHammerPINModalHelper : public UObject
{
public:
    FText Description; // 0x28 (Size: 0x10, Type: TextProperty)
    FText InfoTitle; // 0x38 (Size: 0x10, Type: TextProperty)
    FText InfoDescription; // 0x48 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(UAmpleHammerPINModalHelper) == 0x58, "Size mismatch for UAmpleHammerPINModalHelper");
static_assert(offsetof(UAmpleHammerPINModalHelper, Description) == 0x28, "Offset mismatch for UAmpleHammerPINModalHelper::Description");
static_assert(offsetof(UAmpleHammerPINModalHelper, InfoTitle) == 0x38, "Offset mismatch for UAmpleHammerPINModalHelper::InfoTitle");
static_assert(offsetof(UAmpleHammerPINModalHelper, InfoDescription) == 0x48, "Offset mismatch for UAmpleHammerPINModalHelper::InfoDescription");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAmpleHammerRequestConsentHelper : public UObject
{
public:
};

static_assert(sizeof(UAmpleHammerRequestConsentHelper) == 0x28, "Size mismatch for UAmpleHammerRequestConsentHelper");

