/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DirectLink
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDirectLinkMsg_EndpointLifecycle
{
    char LifecycleState; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    uint32_t EndpointStateRevision; // 0x4 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FDirectLinkMsg_EndpointLifecycle) == 0x8, "Size mismatch for FDirectLinkMsg_EndpointLifecycle");
static_assert(offsetof(FDirectLinkMsg_EndpointLifecycle, LifecycleState) == 0x0, "Offset mismatch for FDirectLinkMsg_EndpointLifecycle::LifecycleState");
static_assert(offsetof(FDirectLinkMsg_EndpointLifecycle, EndpointStateRevision) == 0x4, "Offset mismatch for FDirectLinkMsg_EndpointLifecycle::EndpointStateRevision");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FNamedId
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FGuid ID; // 0x10 (Size: 0x10, Type: StructProperty)
    bool bIsPublic; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FNamedId) == 0x28, "Size mismatch for FNamedId");
static_assert(offsetof(FNamedId, Name) == 0x0, "Offset mismatch for FNamedId::Name");
static_assert(offsetof(FNamedId, ID) == 0x10, "Offset mismatch for FNamedId::ID");
static_assert(offsetof(FNamedId, bIsPublic) == 0x20, "Offset mismatch for FNamedId::bIsPublic");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FDirectLinkMsg_EndpointState
{
    uint32_t StateRevision; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t MinProtocolVersion; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t ProtocolVersion; // 0x8 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FString UEVersion; // 0x10 (Size: 0x10, Type: StrProperty)
    FString ComputerName; // 0x20 (Size: 0x10, Type: StrProperty)
    FString UserName; // 0x30 (Size: 0x10, Type: StrProperty)
    uint32_t ProcessId; // 0x40 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FString ExecutableName; // 0x48 (Size: 0x10, Type: StrProperty)
    FString NiceName; // 0x58 (Size: 0x10, Type: StrProperty)
    TArray<FNamedId> Destinations; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FNamedId> Sources; // 0x78 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDirectLinkMsg_EndpointState) == 0x88, "Size mismatch for FDirectLinkMsg_EndpointState");
static_assert(offsetof(FDirectLinkMsg_EndpointState, StateRevision) == 0x0, "Offset mismatch for FDirectLinkMsg_EndpointState::StateRevision");
static_assert(offsetof(FDirectLinkMsg_EndpointState, MinProtocolVersion) == 0x4, "Offset mismatch for FDirectLinkMsg_EndpointState::MinProtocolVersion");
static_assert(offsetof(FDirectLinkMsg_EndpointState, ProtocolVersion) == 0x8, "Offset mismatch for FDirectLinkMsg_EndpointState::ProtocolVersion");
static_assert(offsetof(FDirectLinkMsg_EndpointState, UEVersion) == 0x10, "Offset mismatch for FDirectLinkMsg_EndpointState::UEVersion");
static_assert(offsetof(FDirectLinkMsg_EndpointState, ComputerName) == 0x20, "Offset mismatch for FDirectLinkMsg_EndpointState::ComputerName");
static_assert(offsetof(FDirectLinkMsg_EndpointState, UserName) == 0x30, "Offset mismatch for FDirectLinkMsg_EndpointState::UserName");
static_assert(offsetof(FDirectLinkMsg_EndpointState, ProcessId) == 0x40, "Offset mismatch for FDirectLinkMsg_EndpointState::ProcessId");
static_assert(offsetof(FDirectLinkMsg_EndpointState, ExecutableName) == 0x48, "Offset mismatch for FDirectLinkMsg_EndpointState::ExecutableName");
static_assert(offsetof(FDirectLinkMsg_EndpointState, NiceName) == 0x58, "Offset mismatch for FDirectLinkMsg_EndpointState::NiceName");
static_assert(offsetof(FDirectLinkMsg_EndpointState, Destinations) == 0x68, "Offset mismatch for FDirectLinkMsg_EndpointState::Destinations");
static_assert(offsetof(FDirectLinkMsg_EndpointState, Sources) == 0x78, "Offset mismatch for FDirectLinkMsg_EndpointState::Sources");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDirectLinkMsg_QueryEndpointState
{
};

static_assert(sizeof(FDirectLinkMsg_QueryEndpointState) == 0x1, "Size mismatch for FDirectLinkMsg_QueryEndpointState");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDirectLinkMsg_OpenStreamRequest
{
    bool bRequestFromSource; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t RequestFromStreamPort; // 0x4 (Size: 0x4, Type: IntProperty)
    FGuid SourceGuid; // 0x8 (Size: 0x10, Type: StructProperty)
    FGuid DestinationGuid; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDirectLinkMsg_OpenStreamRequest) == 0x28, "Size mismatch for FDirectLinkMsg_OpenStreamRequest");
static_assert(offsetof(FDirectLinkMsg_OpenStreamRequest, bRequestFromSource) == 0x0, "Offset mismatch for FDirectLinkMsg_OpenStreamRequest::bRequestFromSource");
static_assert(offsetof(FDirectLinkMsg_OpenStreamRequest, RequestFromStreamPort) == 0x4, "Offset mismatch for FDirectLinkMsg_OpenStreamRequest::RequestFromStreamPort");
static_assert(offsetof(FDirectLinkMsg_OpenStreamRequest, SourceGuid) == 0x8, "Offset mismatch for FDirectLinkMsg_OpenStreamRequest::SourceGuid");
static_assert(offsetof(FDirectLinkMsg_OpenStreamRequest, DestinationGuid) == 0x18, "Offset mismatch for FDirectLinkMsg_OpenStreamRequest::DestinationGuid");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDirectLinkMsg_OpenStreamAnswer
{
    int32_t RecipientStreamPort; // 0x0 (Size: 0x4, Type: IntProperty)
    bool bAccepted; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FString Error; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t OpenedStreamPort; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDirectLinkMsg_OpenStreamAnswer) == 0x20, "Size mismatch for FDirectLinkMsg_OpenStreamAnswer");
static_assert(offsetof(FDirectLinkMsg_OpenStreamAnswer, RecipientStreamPort) == 0x0, "Offset mismatch for FDirectLinkMsg_OpenStreamAnswer::RecipientStreamPort");
static_assert(offsetof(FDirectLinkMsg_OpenStreamAnswer, bAccepted) == 0x4, "Offset mismatch for FDirectLinkMsg_OpenStreamAnswer::bAccepted");
static_assert(offsetof(FDirectLinkMsg_OpenStreamAnswer, Error) == 0x8, "Offset mismatch for FDirectLinkMsg_OpenStreamAnswer::Error");
static_assert(offsetof(FDirectLinkMsg_OpenStreamAnswer, OpenedStreamPort) == 0x18, "Offset mismatch for FDirectLinkMsg_OpenStreamAnswer::OpenedStreamPort");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDirectLinkMsg_CloseStreamRequest
{
    int32_t RecipientStreamPort; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDirectLinkMsg_CloseStreamRequest) == 0x4, "Size mismatch for FDirectLinkMsg_CloseStreamRequest");
static_assert(offsetof(FDirectLinkMsg_CloseStreamRequest, RecipientStreamPort) == 0x0, "Offset mismatch for FDirectLinkMsg_CloseStreamRequest::RecipientStreamPort");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDirectLinkMsg_DeltaMessage
{
    int32_t DestinationStreamPort; // 0x0 (Size: 0x4, Type: IntProperty)
    int8_t BatchCode; // 0x4 (Size: 0x1, Type: Int8Property)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t MessageCode; // 0x8 (Size: 0x4, Type: IntProperty)
    char Kind; // 0xc (Size: 0x1, Type: ByteProperty)
    bool CompressedPayload; // 0xd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
    TArray<char> Payload; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDirectLinkMsg_DeltaMessage) == 0x20, "Size mismatch for FDirectLinkMsg_DeltaMessage");
static_assert(offsetof(FDirectLinkMsg_DeltaMessage, DestinationStreamPort) == 0x0, "Offset mismatch for FDirectLinkMsg_DeltaMessage::DestinationStreamPort");
static_assert(offsetof(FDirectLinkMsg_DeltaMessage, BatchCode) == 0x4, "Offset mismatch for FDirectLinkMsg_DeltaMessage::BatchCode");
static_assert(offsetof(FDirectLinkMsg_DeltaMessage, MessageCode) == 0x8, "Offset mismatch for FDirectLinkMsg_DeltaMessage::MessageCode");
static_assert(offsetof(FDirectLinkMsg_DeltaMessage, Kind) == 0xc, "Offset mismatch for FDirectLinkMsg_DeltaMessage::Kind");
static_assert(offsetof(FDirectLinkMsg_DeltaMessage, CompressedPayload) == 0xd, "Offset mismatch for FDirectLinkMsg_DeltaMessage::CompressedPayload");
static_assert(offsetof(FDirectLinkMsg_DeltaMessage, Payload) == 0x10, "Offset mismatch for FDirectLinkMsg_DeltaMessage::Payload");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDirectLinkMsg_HaveListMessage
{
    int32_t SourceStreamPort; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SyncCycle; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MessageCode; // 0x8 (Size: 0x4, Type: IntProperty)
    char Kind; // 0xc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    TArray<char> Payload; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> NodeIds; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> Hashes; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDirectLinkMsg_HaveListMessage) == 0x40, "Size mismatch for FDirectLinkMsg_HaveListMessage");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, SourceStreamPort) == 0x0, "Offset mismatch for FDirectLinkMsg_HaveListMessage::SourceStreamPort");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, SyncCycle) == 0x4, "Offset mismatch for FDirectLinkMsg_HaveListMessage::SyncCycle");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, MessageCode) == 0x8, "Offset mismatch for FDirectLinkMsg_HaveListMessage::MessageCode");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, Kind) == 0xc, "Offset mismatch for FDirectLinkMsg_HaveListMessage::Kind");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, Payload) == 0x10, "Offset mismatch for FDirectLinkMsg_HaveListMessage::Payload");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, NodeIds) == 0x20, "Offset mismatch for FDirectLinkMsg_HaveListMessage::NodeIds");
static_assert(offsetof(FDirectLinkMsg_HaveListMessage, Hashes) == 0x30, "Offset mismatch for FDirectLinkMsg_HaveListMessage::Hashes");

