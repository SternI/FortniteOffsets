/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCommunicationUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "ModularGameplay.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "CreativeCommunicationRuntime.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0xe8 (Inherited: 0x170, Single: 0xffffff78)
class UCreativeBubbleChatMessageViewModel : public UFortTextChatMessageVM
{
public:
    bool IsWhisper; // 0xe0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e1[0x7]; // 0xe1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCreativeBubbleChatMessageViewModel) == 0xe8, "Size mismatch for UCreativeBubbleChatMessageViewModel");
static_assert(offsetof(UCreativeBubbleChatMessageViewModel, IsWhisper) == 0xe0, "Offset mismatch for UCreativeBubbleChatMessageViewModel::IsWhisper");

// Size: 0xb8 (Inherited: 0x170, Single: 0xffffff48)
class UCreativeBubbleChatViewModel : public UFortTextChatPlayerBaseVM
{
public:
    uint8_t Pad_70[0x8]; // 0x70 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<AFortPlayerStateAthena*> TargetPlayerState; // 0x78 (Size: 0x8, Type: WeakObjectProperty)
    TArray<UCreativeBubbleChatMessageViewModel*> Messages; // 0x80 (Size: 0x10, Type: ArrayProperty)
    FText Message; // 0x90 (Size: 0x10, Type: TextProperty)
    uint8_t Pad_a0[0x18]; // 0xa0 (Size: 0x18, Type: PaddingProperty)

public:
    void InitializeTextChatVM(); // 0x1132d1f0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCreativeBubbleChatViewModel) == 0xb8, "Size mismatch for UCreativeBubbleChatViewModel");
static_assert(offsetof(UCreativeBubbleChatViewModel, TargetPlayerState) == 0x78, "Offset mismatch for UCreativeBubbleChatViewModel::TargetPlayerState");
static_assert(offsetof(UCreativeBubbleChatViewModel, Messages) == 0x80, "Offset mismatch for UCreativeBubbleChatViewModel::Messages");
static_assert(offsetof(UCreativeBubbleChatViewModel, Message) == 0x90, "Offset mismatch for UCreativeBubbleChatViewModel::Message");

// Size: 0x108 (Inherited: 0x250, Single: 0xfffffeb8)
class UCreativePlayerStateComponent_UIViewModels : public UPlayerStateComponent
{
public:

public:
    static UCreativePlayerStateComponent_UIViewModels* Get(APlayerController*& const InPlayerController); // 0x1132cbe8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    UObject* GetOrCreateViewModel(UClass*& const ViewModelClass, ULocalPlayer*& Player); // 0x1132cef4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCreativePlayerStateComponent_UIViewModels) == 0x108, "Size mismatch for UCreativePlayerStateComponent_UIViewModels");

// Size: 0x3e0 (Inherited: 0xa48, Single: 0xfffff998)
class UCreativeIndicatorLayerManagerWidget : public UFortHUDElementWidget
{
public:
    uint8_t Pad_318[0x10]; // 0x318 (Size: 0x10, Type: PaddingProperty)
    int32_t PlayerIndicatorPoolSize; // 0x328 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_32c[0x4]; // 0x32c (Size: 0x4, Type: PaddingProperty)
    FUserWidgetPool IndicatorPool; // 0x330 (Size: 0x88, Type: StructProperty)
    UCreativeLocalPlayerViewModel* LocalPlayerViewModel; // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UClass* PlayerIndicatorClass; // 0x3c0 (Size: 0x8, Type: ClassProperty)
    UFortActorCanvas* PlayerIndicators; // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    bool ShowIndicatorForLocalPlayer; // 0x3d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d1[0xf]; // 0x3d1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UCreativeIndicatorLayerManagerWidget) == 0x3e0, "Size mismatch for UCreativeIndicatorLayerManagerWidget");
static_assert(offsetof(UCreativeIndicatorLayerManagerWidget, PlayerIndicatorPoolSize) == 0x328, "Offset mismatch for UCreativeIndicatorLayerManagerWidget::PlayerIndicatorPoolSize");
static_assert(offsetof(UCreativeIndicatorLayerManagerWidget, IndicatorPool) == 0x330, "Offset mismatch for UCreativeIndicatorLayerManagerWidget::IndicatorPool");
static_assert(offsetof(UCreativeIndicatorLayerManagerWidget, LocalPlayerViewModel) == 0x3b8, "Offset mismatch for UCreativeIndicatorLayerManagerWidget::LocalPlayerViewModel");
static_assert(offsetof(UCreativeIndicatorLayerManagerWidget, PlayerIndicatorClass) == 0x3c0, "Offset mismatch for UCreativeIndicatorLayerManagerWidget::PlayerIndicatorClass");
static_assert(offsetof(UCreativeIndicatorLayerManagerWidget, PlayerIndicators) == 0x3c8, "Offset mismatch for UCreativeIndicatorLayerManagerWidget::PlayerIndicators");
static_assert(offsetof(UCreativeIndicatorLayerManagerWidget, ShowIndicatorForLocalPlayer) == 0x3d0, "Offset mismatch for UCreativeIndicatorLayerManagerWidget::ShowIndicatorForLocalPlayer");

// Size: 0xc0 (Inherited: 0x100, Single: 0xffffffc0)
class UCreativeLocalPlayerViewModel : public UFortPerUserViewModel
{
public:
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedTeammatePlayerStates; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedSquadMemberPlayerStates; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerStateAthena*>> CachedPartyMemberPlayerStates; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a0[0x20]; // 0xa0 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UCreativeLocalPlayerViewModel) == 0xc0, "Size mismatch for UCreativeLocalPlayerViewModel");
static_assert(offsetof(UCreativeLocalPlayerViewModel, CachedTeammatePlayerStates) == 0x70, "Offset mismatch for UCreativeLocalPlayerViewModel::CachedTeammatePlayerStates");
static_assert(offsetof(UCreativeLocalPlayerViewModel, CachedSquadMemberPlayerStates) == 0x80, "Offset mismatch for UCreativeLocalPlayerViewModel::CachedSquadMemberPlayerStates");
static_assert(offsetof(UCreativeLocalPlayerViewModel, CachedPartyMemberPlayerStates) == 0x90, "Offset mismatch for UCreativeLocalPlayerViewModel::CachedPartyMemberPlayerStates");

// Size: 0x418 (Inherited: 0xe08, Single: 0xfffff610)
class UCreativePlayerIndicatorWidget : public UFortActorIndicatorWidget
{
public:
    float MinDistanceToDisplayInfo; // 0x3c0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c4[0x14]; // 0x3c4 (Size: 0x14, Type: PaddingProperty)
    UCommonTextBlock* Text_Distance; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3e0[0x30]; // 0x3e0 (Size: 0x30, Type: PaddingProperty)
    UCreativeGameStateComponent_CommunicationOverride* CachedCreativeCommunicationOverride; // 0x410 (Size: 0x8, Type: ObjectProperty)

public:
    UCreativeBubbleChatViewModel* GetBubbleChatViewModel() const; // 0xcff196c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetupBubbleChatViewModel(UCreativeBubbleChatViewModel*& ViewModel); // 0x1132d218 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleCurrentPawnChanged(); // 0x1132d110 (Index: 0x1, Flags: Final|Native|Private)
    void HandlePlayerStatePawnDied(const FPawnDamageData PawnDamageInfo); // 0x1132d124 (Index: 0x2, Flags: Final|Native|Private|HasOutParms)
    void OnCreativeBubbleChatSettingsUpdated(); // 0x1132d204 (Index: 0x4, Flags: Final|Native|Private)

protected:
    virtual void OnBubbleChatVisibilityChanged(bool& bNewIsVisible); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCreativeBubbleChatSettingsUpdated_BP(EBubbleChatStyle& BubbleChatStyle, const TSoftClassPtr CustomBubbleWidgetClass); // 0x288a61c (Index: 0x5, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnInFocusStateChanged(bool& bNewIsInFocus); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTargetPlayerChanged(AFortPlayerStateAthena*& TargetedPlayer); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCreativePlayerIndicatorWidget) == 0x418, "Size mismatch for UCreativePlayerIndicatorWidget");
static_assert(offsetof(UCreativePlayerIndicatorWidget, MinDistanceToDisplayInfo) == 0x3c0, "Offset mismatch for UCreativePlayerIndicatorWidget::MinDistanceToDisplayInfo");
static_assert(offsetof(UCreativePlayerIndicatorWidget, Text_Distance) == 0x3d8, "Offset mismatch for UCreativePlayerIndicatorWidget::Text_Distance");
static_assert(offsetof(UCreativePlayerIndicatorWidget, CachedCreativeCommunicationOverride) == 0x410, "Offset mismatch for UCreativePlayerIndicatorWidget::CachedCreativeCommunicationOverride");

