/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Execution
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x48 (Inherited: 0xb8, Single: 0xffffff90)
class UExecutionSubsystem : public UEngineSubsystem
{
public:
};

static_assert(sizeof(UExecutionSubsystem) == 0x48, "Size mismatch for UExecutionSubsystem");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UBaseExecution : public UObject
{
public:
};

static_assert(sizeof(UBaseExecution) == 0x48, "Size mismatch for UBaseExecution");

