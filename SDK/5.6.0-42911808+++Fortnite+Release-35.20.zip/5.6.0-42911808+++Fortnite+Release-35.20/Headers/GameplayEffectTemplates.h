/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayEffectTemplates
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0xa68 (Inherited: 0x29c8, Single: 0xffffe0a0)
class UGET_DirectCreatureDamage_C : public UGET_DirectPhysicalDamage_C
{
public:
};

static_assert(sizeof(UGET_DirectCreatureDamage_C) == 0xa68, "Size mismatch for UGET_DirectCreatureDamage_C");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGET_DirectDamage_LootOnDestroy_C : public UGET_DamageParent_C
{
public:
};

static_assert(sizeof(UGET_DirectDamage_LootOnDestroy_C) == 0xa68, "Size mismatch for UGET_DirectDamage_LootOnDestroy_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGET_DirectPhysicalDamage_C : public UGet_DirectDamageParent_C
{
public:
};

static_assert(sizeof(UGET_DirectPhysicalDamage_C) == 0xa68, "Size mismatch for UGET_DirectPhysicalDamage_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGET_DamageParent_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGET_DamageParent_C) == 0xa68, "Size mismatch for UGET_DamageParent_C");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGET_AfflictedParent_C : public UGET_DamageParent_C
{
public:
};

static_assert(sizeof(UGET_AfflictedParent_C) == 0xa68, "Size mismatch for UGET_AfflictedParent_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGET_PeriodicDamageParent_C : public UGET_AfflictedParent_C
{
public:
};

static_assert(sizeof(UGET_PeriodicDamageParent_C) == 0xa68, "Size mismatch for UGET_PeriodicDamageParent_C");

// Size: 0xa68 (Inherited: 0x29c8, Single: 0xffffe0a0)
class UGET_PeriodicPhysicalDamage_C : public UGET_PeriodicDamageParent_C
{
public:
};

static_assert(sizeof(UGET_PeriodicPhysicalDamage_C) == 0xa68, "Size mismatch for UGET_PeriodicPhysicalDamage_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGET_DirectEnvironmentDamage_C : public UGet_DirectDamageParent_C
{
public:
};

static_assert(sizeof(UGET_DirectEnvironmentDamage_C) == 0xa68, "Size mismatch for UGET_DirectEnvironmentDamage_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGET_DirectVehicleDamage_C : public UGet_DirectDamageParent_C
{
public:
};

static_assert(sizeof(UGET_DirectVehicleDamage_C) == 0xa68, "Size mismatch for UGET_DirectVehicleDamage_C");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGet_DirectDamageParent_C : public UGET_DamageParent_C
{
public:
};

static_assert(sizeof(UGet_DirectDamageParent_C) == 0xa68, "Size mismatch for UGet_DirectDamageParent_C");

// Size: 0xa68 (Inherited: 0x3430, Single: 0xffffd638)
class UGET_PeriodicEnergyDamage_C : public UGET_PeriodicPhysicalDamage_C
{
public:
};

static_assert(sizeof(UGET_PeriodicEnergyDamage_C) == 0xa68, "Size mismatch for UGET_PeriodicEnergyDamage_C");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGET_Status_FullHealth_C : public UGET_TagContainer_C
{
public:
};

static_assert(sizeof(UGET_Status_FullHealth_C) == 0xa68, "Size mismatch for UGET_Status_FullHealth_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGET_TagContainer_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGET_TagContainer_C) == 0xa68, "Size mismatch for UGET_TagContainer_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGET_FatalDamage_C : public UGet_DirectDamageParent_C
{
public:
};

static_assert(sizeof(UGET_FatalDamage_C) == 0xa68, "Size mismatch for UGET_FatalDamage_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGET_FallingDamage_C : public UGet_DirectDamageParent_C
{
public:
};

static_assert(sizeof(UGET_FallingDamage_C) == 0xa68, "Size mismatch for UGET_FallingDamage_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGET_CooldownDuration_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGET_CooldownDuration_C) == 0xa68, "Size mismatch for UGET_CooldownDuration_C");

