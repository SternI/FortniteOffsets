/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowSimulation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "DataflowCore.h"
#include "DataflowEngine.h"

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDataflowCollisionObjectInterface : public UDataflowSimulationInterface
{
public:
};

static_assert(sizeof(UDataflowCollisionObjectInterface) == 0x28, "Size mismatch for UDataflowCollisionObjectInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowSimulationInterface : public UInterface
{
public:
};

static_assert(sizeof(UDataflowSimulationInterface) == 0x28, "Size mismatch for UDataflowSimulationInterface");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDataflowConstraintObjectInterface : public UDataflowSimulationInterface
{
public:
};

static_assert(sizeof(UDataflowConstraintObjectInterface) == 0x28, "Size mismatch for UDataflowConstraintObjectInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowGeometryCachable : public UInterface
{
public:
};

static_assert(sizeof(UDataflowGeometryCachable) == 0x28, "Size mismatch for UDataflowGeometryCachable");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDataflowPhysicsObjectInterface : public UDataflowSimulationInterface
{
public:
};

static_assert(sizeof(UDataflowPhysicsObjectInterface) == 0x28, "Size mismatch for UDataflowPhysicsObjectInterface");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDataflowPhysicsSolverInterface : public UDataflowSimulationInterface
{
public:
};

static_assert(sizeof(UDataflowPhysicsSolverInterface) == 0x28, "Size mismatch for UDataflowPhysicsSolverInterface");

// Size: 0xa8 (Inherited: 0xc8, Single: 0xffffffe0)
class UDataflowSimulationManager : public UTickableWorldSubsystem
{
public:
};

static_assert(sizeof(UDataflowSimulationManager) == 0xa8, "Size mismatch for UDataflowSimulationManager");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowSimulationActor : public UInterface
{
public:

public:
    virtual void PostDataflowSimulationTick(float& const SimulationTime, float& const DeltaTime); // 0x9f091e4 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void PreDataflowSimulationTick(float& const SimulationTime, float& const DeltaTime); // 0x9f093f0 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UDataflowSimulationActor) == 0x28, "Size mismatch for UDataflowSimulationActor");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FDataflowSimulationProxy
{
};

static_assert(sizeof(FDataflowSimulationProxy) == 0x78, "Size mismatch for FDataflowSimulationProxy");

// Size: 0x78 (Inherited: 0x78, Single: 0x0)
struct FDataflowCollisionObjectProxy : FDataflowSimulationProxy
{
};

static_assert(sizeof(FDataflowCollisionObjectProxy) == 0x78, "Size mismatch for FDataflowCollisionObjectProxy");

// Size: 0x78 (Inherited: 0x78, Single: 0x0)
struct FDataflowConstraintObjectProxy : FDataflowSimulationProxy
{
};

static_assert(sizeof(FDataflowConstraintObjectProxy) == 0x78, "Size mismatch for FDataflowConstraintObjectProxy");

// Size: 0x78 (Inherited: 0x78, Single: 0x0)
struct FDataflowPhysicsObjectProxy : FDataflowSimulationProxy
{
};

static_assert(sizeof(FDataflowPhysicsObjectProxy) == 0x78, "Size mismatch for FDataflowPhysicsObjectProxy");

// Size: 0x78 (Inherited: 0x78, Single: 0x0)
struct FDataflowPhysicsSolverProxy : FDataflowSimulationProxy
{
};

static_assert(sizeof(FDataflowPhysicsSolverProxy) == 0x78, "Size mismatch for FDataflowPhysicsSolverProxy");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FDataflowSimulationAsset
{
    UDataflow* DataflowAsset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TSet<FString> SimulationGroups; // 0x8 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FDataflowSimulationAsset) == 0x58, "Size mismatch for FDataflowSimulationAsset");
static_assert(offsetof(FDataflowSimulationAsset, DataflowAsset) == 0x0, "Offset mismatch for FDataflowSimulationAsset::DataflowAsset");
static_assert(offsetof(FDataflowSimulationAsset, SimulationGroups) == 0x8, "Offset mismatch for FDataflowSimulationAsset::SimulationGroups");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDataflowSimulationProperty
{
};

static_assert(sizeof(FDataflowSimulationProperty) == 0x8, "Size mismatch for FDataflowSimulationProperty");

// Size: 0x270 (Inherited: 0x270, Single: 0x0)
struct FDataflowSimulationNode : FDataflowNode
{
};

static_assert(sizeof(FDataflowSimulationNode) == 0x270, "Size mismatch for FDataflowSimulationNode");

// Size: 0x270 (Inherited: 0x4e0, Single: 0xfffffd90)
struct FDataflowInvalidNode : FDataflowSimulationNode
{
};

static_assert(sizeof(FDataflowInvalidNode) == 0x270, "Size mismatch for FDataflowInvalidNode");

// Size: 0x270 (Inherited: 0x4e0, Single: 0xfffffd90)
struct FDataflowExecutionNode : FDataflowSimulationNode
{
};

static_assert(sizeof(FDataflowExecutionNode) == 0x270, "Size mismatch for FDataflowExecutionNode");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDataflowSimulationTime
{
    float DeltaTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float CurrentTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float TimeOffset; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDataflowSimulationTime) == 0xc, "Size mismatch for FDataflowSimulationTime");
static_assert(offsetof(FDataflowSimulationTime, DeltaTime) == 0x0, "Offset mismatch for FDataflowSimulationTime::DeltaTime");
static_assert(offsetof(FDataflowSimulationTime, CurrentTime) == 0x4, "Offset mismatch for FDataflowSimulationTime::CurrentTime");
static_assert(offsetof(FDataflowSimulationTime, TimeOffset) == 0x8, "Offset mismatch for FDataflowSimulationTime::TimeOffset");

// Size: 0x280 (Inherited: 0x750, Single: 0xfffffb30)
struct FGetSimulationTimeDataflowNode : FDataflowInvalidNode
{
    FDataflowSimulationTime SimulationTime; // 0x270 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGetSimulationTimeDataflowNode) == 0x280, "Size mismatch for FGetSimulationTimeDataflowNode");
static_assert(offsetof(FGetSimulationTimeDataflowNode, SimulationTime) == 0x270, "Offset mismatch for FGetSimulationTimeDataflowNode::SimulationTime");

// Size: 0x290 (Inherited: 0x750, Single: 0xfffffb40)
struct FGetPhysicsSolversDataflowNode : FDataflowInvalidNode
{
    TArray<FDataflowSimulationProperty> PhysicsSolvers; // 0x270 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SimulationGroups; // 0x280 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGetPhysicsSolversDataflowNode) == 0x290, "Size mismatch for FGetPhysicsSolversDataflowNode");
static_assert(offsetof(FGetPhysicsSolversDataflowNode, PhysicsSolvers) == 0x270, "Offset mismatch for FGetPhysicsSolversDataflowNode::PhysicsSolvers");
static_assert(offsetof(FGetPhysicsSolversDataflowNode, SimulationGroups) == 0x280, "Offset mismatch for FGetPhysicsSolversDataflowNode::SimulationGroups");

// Size: 0x290 (Inherited: 0x4e0, Single: 0xfffffdb0)
struct FAdvancePhysicsSolversDataflowNode : FDataflowSimulationNode
{
    FDataflowSimulationTime SimulationTime; // 0x270 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
    TArray<FDataflowSimulationProperty> PhysicsSolvers; // 0x280 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAdvancePhysicsSolversDataflowNode) == 0x290, "Size mismatch for FAdvancePhysicsSolversDataflowNode");
static_assert(offsetof(FAdvancePhysicsSolversDataflowNode, SimulationTime) == 0x270, "Offset mismatch for FAdvancePhysicsSolversDataflowNode::SimulationTime");
static_assert(offsetof(FAdvancePhysicsSolversDataflowNode, PhysicsSolvers) == 0x280, "Offset mismatch for FAdvancePhysicsSolversDataflowNode::PhysicsSolvers");

// Size: 0x2a0 (Inherited: 0x4e0, Single: 0xfffffdc0)
struct FFilterSimulationProxiesDataflowNode : FDataflowSimulationNode
{
    TArray<FDataflowSimulationProperty> SimulationProxies; // 0x270 (Size: 0x10, Type: ArrayProperty)
    TArray<FDataflowSimulationProperty> FilteredProxies; // 0x280 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SimulationGroups; // 0x290 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFilterSimulationProxiesDataflowNode) == 0x2a0, "Size mismatch for FFilterSimulationProxiesDataflowNode");
static_assert(offsetof(FFilterSimulationProxiesDataflowNode, SimulationProxies) == 0x270, "Offset mismatch for FFilterSimulationProxiesDataflowNode::SimulationProxies");
static_assert(offsetof(FFilterSimulationProxiesDataflowNode, FilteredProxies) == 0x280, "Offset mismatch for FFilterSimulationProxiesDataflowNode::FilteredProxies");
static_assert(offsetof(FFilterSimulationProxiesDataflowNode, SimulationGroups) == 0x290, "Offset mismatch for FFilterSimulationProxiesDataflowNode::SimulationGroups");

// Size: 0x280 (Inherited: 0x750, Single: 0xfffffb30)
struct FSimulationProxiesTerminalDataflowNode : FDataflowExecutionNode
{
    TArray<FDataflowSimulationProperty> SimulationProxies; // 0x270 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSimulationProxiesTerminalDataflowNode) == 0x280, "Size mismatch for FSimulationProxiesTerminalDataflowNode");
static_assert(offsetof(FSimulationProxiesTerminalDataflowNode, SimulationProxies) == 0x270, "Offset mismatch for FSimulationProxiesTerminalDataflowNode::SimulationProxies");

