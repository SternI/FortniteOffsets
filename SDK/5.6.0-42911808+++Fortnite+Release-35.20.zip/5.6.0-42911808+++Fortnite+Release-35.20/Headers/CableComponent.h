/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CableComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ACableActor : public AActor
{
public:
    UCableComponent* CableComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ACableActor) == 0x2b0, "Size mismatch for ACableActor");
static_assert(offsetof(ACableActor, CableComponent) == 0x2a8, "Offset mismatch for ACableActor::CableComponent");

// Size: 0x730 (Inherited: 0xda0, Single: 0xfffff990)
class UCableComponent : public UMeshComponent
{
public:
    bool bAttachStart; // 0x560 (Size: 0x1, Type: BoolProperty)
    bool bAttachEnd; // 0x561 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_562[0x6]; // 0x562 (Size: 0x6, Type: PaddingProperty)
    FComponentReference AttachEndTo; // 0x568 (Size: 0x28, Type: StructProperty)
    FName AttachEndToSocketName; // 0x590 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_594[0x4]; // 0x594 (Size: 0x4, Type: PaddingProperty)
    FVector EndLocation; // 0x598 (Size: 0x18, Type: StructProperty)
    float CableLength; // 0x5b0 (Size: 0x4, Type: FloatProperty)
    int32_t NumSegments; // 0x5b4 (Size: 0x4, Type: IntProperty)
    float SubstepTime; // 0x5b8 (Size: 0x4, Type: FloatProperty)
    int32_t SolverIterations; // 0x5bc (Size: 0x4, Type: IntProperty)
    bool bEnableStiffness; // 0x5c0 (Size: 0x1, Type: BoolProperty)
    bool bUseSubstepping; // 0x5c1 (Size: 0x1, Type: BoolProperty)
    bool bSkipCableUpdateWhenNotVisible; // 0x5c2 (Size: 0x1, Type: BoolProperty)
    bool bSkipCableUpdateWhenNotOwnerRecentlyRendered; // 0x5c3 (Size: 0x1, Type: BoolProperty)
    bool bEnableCollision; // 0x5c4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5c5[0x3]; // 0x5c5 (Size: 0x3, Type: PaddingProperty)
    float CollisionFriction; // 0x5c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5cc[0x4]; // 0x5cc (Size: 0x4, Type: PaddingProperty)
    FVector CableForce; // 0x5d0 (Size: 0x18, Type: StructProperty)
    float CableGravityScale; // 0x5e8 (Size: 0x4, Type: FloatProperty)
    float CableWidth; // 0x5ec (Size: 0x4, Type: FloatProperty)
    int32_t NumSides; // 0x5f0 (Size: 0x4, Type: IntProperty)
    float TileMaterial; // 0x5f4 (Size: 0x4, Type: FloatProperty)
    bool bResetAfterTeleport; // 0x5f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5f9[0x3]; // 0x5f9 (Size: 0x3, Type: PaddingProperty)
    float TeleportDistanceThreshold; // 0x5fc (Size: 0x4, Type: FloatProperty)
    float TeleportRotationThreshold; // 0x600 (Size: 0x4, Type: FloatProperty)
    bool bTeleportAfterReattach; // 0x604 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_605[0x12b]; // 0x605 (Size: 0x12b, Type: PaddingProperty)

public:
    AActor* GetAttachedActor() const; // 0xca0d77c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USceneComponent* GetAttachedComponent() const; // 0xca0d7a8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetCableParticleLocations(TArray<FVector>& Locations) const; // 0xca0d808 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void SetAttachEndTo(AActor*& Actor, FName& ComponentProperty, FName& SocketName); // 0xca0da94 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetAttachEndToComponent(USceneComponent*& Component, FName& SocketName); // 0xca0df2c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCableComponent) == 0x730, "Size mismatch for UCableComponent");
static_assert(offsetof(UCableComponent, bAttachStart) == 0x560, "Offset mismatch for UCableComponent::bAttachStart");
static_assert(offsetof(UCableComponent, bAttachEnd) == 0x561, "Offset mismatch for UCableComponent::bAttachEnd");
static_assert(offsetof(UCableComponent, AttachEndTo) == 0x568, "Offset mismatch for UCableComponent::AttachEndTo");
static_assert(offsetof(UCableComponent, AttachEndToSocketName) == 0x590, "Offset mismatch for UCableComponent::AttachEndToSocketName");
static_assert(offsetof(UCableComponent, EndLocation) == 0x598, "Offset mismatch for UCableComponent::EndLocation");
static_assert(offsetof(UCableComponent, CableLength) == 0x5b0, "Offset mismatch for UCableComponent::CableLength");
static_assert(offsetof(UCableComponent, NumSegments) == 0x5b4, "Offset mismatch for UCableComponent::NumSegments");
static_assert(offsetof(UCableComponent, SubstepTime) == 0x5b8, "Offset mismatch for UCableComponent::SubstepTime");
static_assert(offsetof(UCableComponent, SolverIterations) == 0x5bc, "Offset mismatch for UCableComponent::SolverIterations");
static_assert(offsetof(UCableComponent, bEnableStiffness) == 0x5c0, "Offset mismatch for UCableComponent::bEnableStiffness");
static_assert(offsetof(UCableComponent, bUseSubstepping) == 0x5c1, "Offset mismatch for UCableComponent::bUseSubstepping");
static_assert(offsetof(UCableComponent, bSkipCableUpdateWhenNotVisible) == 0x5c2, "Offset mismatch for UCableComponent::bSkipCableUpdateWhenNotVisible");
static_assert(offsetof(UCableComponent, bSkipCableUpdateWhenNotOwnerRecentlyRendered) == 0x5c3, "Offset mismatch for UCableComponent::bSkipCableUpdateWhenNotOwnerRecentlyRendered");
static_assert(offsetof(UCableComponent, bEnableCollision) == 0x5c4, "Offset mismatch for UCableComponent::bEnableCollision");
static_assert(offsetof(UCableComponent, CollisionFriction) == 0x5c8, "Offset mismatch for UCableComponent::CollisionFriction");
static_assert(offsetof(UCableComponent, CableForce) == 0x5d0, "Offset mismatch for UCableComponent::CableForce");
static_assert(offsetof(UCableComponent, CableGravityScale) == 0x5e8, "Offset mismatch for UCableComponent::CableGravityScale");
static_assert(offsetof(UCableComponent, CableWidth) == 0x5ec, "Offset mismatch for UCableComponent::CableWidth");
static_assert(offsetof(UCableComponent, NumSides) == 0x5f0, "Offset mismatch for UCableComponent::NumSides");
static_assert(offsetof(UCableComponent, TileMaterial) == 0x5f4, "Offset mismatch for UCableComponent::TileMaterial");
static_assert(offsetof(UCableComponent, bResetAfterTeleport) == 0x5f8, "Offset mismatch for UCableComponent::bResetAfterTeleport");
static_assert(offsetof(UCableComponent, TeleportDistanceThreshold) == 0x5fc, "Offset mismatch for UCableComponent::TeleportDistanceThreshold");
static_assert(offsetof(UCableComponent, TeleportRotationThreshold) == 0x600, "Offset mismatch for UCableComponent::TeleportRotationThreshold");
static_assert(offsetof(UCableComponent, bTeleportAfterReattach) == 0x604, "Offset mismatch for UCableComponent::bTeleportAfterReattach");

