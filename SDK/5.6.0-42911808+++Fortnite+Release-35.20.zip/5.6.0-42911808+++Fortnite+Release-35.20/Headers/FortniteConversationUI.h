/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteConversationUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "CommonUILegacy.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CommonConversationRuntime.h"
#include "DynamicUI.h"

// Size: 0x448 (Inherited: 0xb38, Single: 0xfffff910)
class UFortConversation_CommActiveBase : public UCommonActivatableWidget
{
public:
    UInputComponent* ConversationInputComponent; // 0x408 (Size: 0x8, Type: ObjectProperty)
    FName FireInputActionName; // 0x410 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_414[0x4]; // 0x414 (Size: 0x4, Type: PaddingProperty)
    FDataTableRowHandle ADS_DataTableRowHandle; // 0x418 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle BackAction_DataTableRowHandle; // 0x428 (Size: 0x10, Type: StructProperty)
    FName ADSInputActionName; // 0x438 (Size: 0x4, Type: NameProperty)
    FName InventoryKBMInputActionName; // 0x43c (Size: 0x4, Type: NameProperty)
    FName InventoryGamepadInputActionName; // 0x440 (Size: 0x4, Type: NameProperty)
    FName PlaceMapMarkerInputActionName; // 0x444 (Size: 0x4, Type: NameProperty)

protected:
    virtual void BP_HandleBackAction(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortConversation_CommActiveBase) == 0x448, "Size mismatch for UFortConversation_CommActiveBase");
static_assert(offsetof(UFortConversation_CommActiveBase, ConversationInputComponent) == 0x408, "Offset mismatch for UFortConversation_CommActiveBase::ConversationInputComponent");
static_assert(offsetof(UFortConversation_CommActiveBase, FireInputActionName) == 0x410, "Offset mismatch for UFortConversation_CommActiveBase::FireInputActionName");
static_assert(offsetof(UFortConversation_CommActiveBase, ADS_DataTableRowHandle) == 0x418, "Offset mismatch for UFortConversation_CommActiveBase::ADS_DataTableRowHandle");
static_assert(offsetof(UFortConversation_CommActiveBase, BackAction_DataTableRowHandle) == 0x428, "Offset mismatch for UFortConversation_CommActiveBase::BackAction_DataTableRowHandle");
static_assert(offsetof(UFortConversation_CommActiveBase, ADSInputActionName) == 0x438, "Offset mismatch for UFortConversation_CommActiveBase::ADSInputActionName");
static_assert(offsetof(UFortConversation_CommActiveBase, InventoryKBMInputActionName) == 0x43c, "Offset mismatch for UFortConversation_CommActiveBase::InventoryKBMInputActionName");
static_assert(offsetof(UFortConversation_CommActiveBase, InventoryGamepadInputActionName) == 0x440, "Offset mismatch for UFortConversation_CommActiveBase::InventoryGamepadInputActionName");
static_assert(offsetof(UFortConversation_CommActiveBase, PlaceMapMarkerInputActionName) == 0x444, "Offset mismatch for UFortConversation_CommActiveBase::PlaceMapMarkerInputActionName");

// Size: 0x308 (Inherited: 0xcf8, Single: 0xfffff610)
class UFortApplyAbilityBrief : public UFortItemTransactionBrief
{
public:
    FText PurchaseServiceText; // 0x2f0 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Display; // 0x300 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnAbleToPurchase(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUnableToPurchase(EPreventAbilityUseReason& Reason); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortApplyAbilityBrief) == 0x308, "Size mismatch for UFortApplyAbilityBrief");
static_assert(offsetof(UFortApplyAbilityBrief, PurchaseServiceText) == 0x2f0, "Offset mismatch for UFortApplyAbilityBrief::PurchaseServiceText");
static_assert(offsetof(UFortApplyAbilityBrief, Text_Display) == 0x300, "Offset mismatch for UFortApplyAbilityBrief::Text_Display");

// Size: 0x2f0 (Inherited: 0xa08, Single: 0xfffff8e8)
class UFortItemTransactionBrief : public UFortConversationOptionBrief
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    UFortTransactionStrip* TransactionStrip_Main; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UFortItem* DisplayItem; // 0x2e8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnTransactionInfoReceived(UFortItem*& Item, const FFortServiceTransactionInfo TransactionInfo); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortItemTransactionBrief) == 0x2f0, "Size mismatch for UFortItemTransactionBrief");
static_assert(offsetof(UFortItemTransactionBrief, TransactionStrip_Main) == 0x2e0, "Offset mismatch for UFortItemTransactionBrief::TransactionStrip_Main");
static_assert(offsetof(UFortItemTransactionBrief, DisplayItem) == 0x2e8, "Offset mismatch for UFortItemTransactionBrief::DisplayItem");

// Size: 0x2d8 (Inherited: 0x730, Single: 0xfffffba8)
class UFortConversationOptionBrief : public UCommonUserWidget
{
public:

protected:
    virtual void ConfigureBP(const FConversationContext ClientContext, const FClientConversationOptionEntry OptionEntry, int32_t& const SelectedIndex); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortConversationOptionBrief) == 0x2d8, "Size mismatch for UFortConversationOptionBrief");

// Size: 0x2d8 (Inherited: 0xa08, Single: 0xfffff8d0)
class UFortBasicBrief : public UFortConversationOptionBrief
{
public:

protected:
    virtual void OnChoiceTextReceived(const FText Text); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortBasicBrief) == 0x2d8, "Size mismatch for UFortBasicBrief");

// Size: 0x348 (Inherited: 0xa08, Single: 0xfffff940)
class UFortBasicItemBrief : public UFortConversationOptionBrief
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* Text_TitleBar; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UFortTransactionStrip* TransactionStrip_Main; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UFortItem* DisplayItem; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs; // 0x2f8 (Size: 0x50, Type: MapProperty)

protected:
    virtual void OnAbleToUse(bool& const bShowWarningMessage); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnItemInfoReceived(UFortItem*& Item, int32_t& StackSize); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUnableToUse(const FText Reason); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnUpdateDescriptionText(const FText DescriptionText); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortBasicItemBrief) == 0x348, "Size mismatch for UFortBasicItemBrief");
static_assert(offsetof(UFortBasicItemBrief, Text_TitleBar) == 0x2e0, "Offset mismatch for UFortBasicItemBrief::Text_TitleBar");
static_assert(offsetof(UFortBasicItemBrief, TransactionStrip_Main) == 0x2e8, "Offset mismatch for UFortBasicItemBrief::TransactionStrip_Main");
static_assert(offsetof(UFortBasicItemBrief, DisplayItem) == 0x2f0, "Offset mismatch for UFortBasicItemBrief::DisplayItem");
static_assert(offsetof(UFortBasicItemBrief, ServiceConfigs) == 0x2f8, "Offset mismatch for UFortBasicItemBrief::ServiceConfigs");

// Size: 0x300 (Inherited: 0xcf8, Single: 0xfffff608)
class UFortBuyBrief : public UFortItemTransactionBrief
{
public:
    FString RemainingForSaleKey; // 0x2f0 (Size: 0x10, Type: StrProperty)

protected:
    virtual void OnDisplayUnavailability(ECannotBuyReason& CannotBuyReason); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPurchaseDataReceived(int32_t& StackSize, int32_t& RemainingForSale); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortBuyBrief) == 0x300, "Size mismatch for UFortBuyBrief");
static_assert(offsetof(UFortBuyBrief, RemainingForSaleKey) == 0x2f0, "Offset mismatch for UFortBuyBrief::RemainingForSaleKey");

// Size: 0x4d0 (Inherited: 0xe08, Single: 0xfffff6c8)
class UFortConversationMarker : public UFortActorIndicatorWidget
{
public:
    uint8_t Pad_3c0[0x10]; // 0x3c0 (Size: 0x10, Type: PaddingProperty)
    bool bShowConversationLimitHit; // 0x3d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d1[0x27]; // 0x3d1 (Size: 0x27, Type: PaddingProperty)
    FVector InitialOffset; // 0x3f8 (Size: 0x18, Type: StructProperty)
    FVector ManualOffset; // 0x410 (Size: 0x18, Type: StructProperty)
    float MessageBubbleDuration; // 0x428 (Size: 0x4, Type: FloatProperty)
    float LastTextBubbleDuration; // 0x42c (Size: 0x4, Type: FloatProperty)
    bool bSetCustomInteractionWidgetOnlyWhenNeeded; // 0x430 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_431[0x7]; // 0x431 (Size: 0x7, Type: PaddingProperty)
    UCommonVisibilitySwitcher* Switcher_States; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_PreviewState; // 0x440 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_448[0x8]; // 0x448 (Size: 0x8, Type: PaddingProperty)
    UFortConversationMessageWidget* ConversationMessage_Main; // 0x450 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_458[0x8]; // 0x458 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* Text_ParticipantName; // 0x460 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_468[0x8]; // 0x468 (Size: 0x8, Type: PaddingProperty)
    UFortKeybindWidget* Keybind_Nameplate; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UImage* NPCIcon; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* CustomDialogMarkerIndicatorIcon; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* DefaultDialogMarkerIndicatorIcon; // 0x488 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UTexture2D*> DefaultMaxParticipantIconTexture; // 0x490 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_4b0[0x20]; // 0x4b0 (Size: 0x20, Type: PaddingProperty)

public:
    void SetIsAtMaxConversations(UFortNonPlayerConversationParticipantComponent*& ConversationComponent, bool& bIsAtMaxConversations); // 0xff337fc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void OnCanInteract(bool& bCanInteract); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnConversationActorProximityChanged(EInteractionRange& TargetInteractionRange, UFortNonPlayerConversationParticipantComponent*& ConversationComponent); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    void OnEntityConversationComponentParticipantsChanged(UFortNonPlayerConversationParticipantComponent*& ConversationComponent, const TArray<AController*> Participants, bool& const bIsMaxParticipants); // 0xff32cd8 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    virtual void OnInteractionRangeChanged(EInteractionRange& TargetInteractionRange); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnMessageShownOverActor(AActor*& OverActor); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    void OnNonPlayerConversationSettingsChanged(UFortNonPlayerConversationParticipantComponent*& ConversationComponent); // 0xff33378 (Index: 0x5, Flags: Final|Native|Protected)
    void OnParticipantNameSanitizationComplete(bool& bSuccess, TArray<FSanitizedEntry>& SanitizedEntries, int32_t& const SanitizeID); // 0xff334a4 (Index: 0x6, Flags: Final|Native|Protected)
    virtual void OnSetIndicatedActor(AActor*& NewIndicatorActor); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortConversationMarker) == 0x4d0, "Size mismatch for UFortConversationMarker");
static_assert(offsetof(UFortConversationMarker, bShowConversationLimitHit) == 0x3d0, "Offset mismatch for UFortConversationMarker::bShowConversationLimitHit");
static_assert(offsetof(UFortConversationMarker, InitialOffset) == 0x3f8, "Offset mismatch for UFortConversationMarker::InitialOffset");
static_assert(offsetof(UFortConversationMarker, ManualOffset) == 0x410, "Offset mismatch for UFortConversationMarker::ManualOffset");
static_assert(offsetof(UFortConversationMarker, MessageBubbleDuration) == 0x428, "Offset mismatch for UFortConversationMarker::MessageBubbleDuration");
static_assert(offsetof(UFortConversationMarker, LastTextBubbleDuration) == 0x42c, "Offset mismatch for UFortConversationMarker::LastTextBubbleDuration");
static_assert(offsetof(UFortConversationMarker, bSetCustomInteractionWidgetOnlyWhenNeeded) == 0x430, "Offset mismatch for UFortConversationMarker::bSetCustomInteractionWidgetOnlyWhenNeeded");
static_assert(offsetof(UFortConversationMarker, Switcher_States) == 0x438, "Offset mismatch for UFortConversationMarker::Switcher_States");
static_assert(offsetof(UFortConversationMarker, Overlay_PreviewState) == 0x440, "Offset mismatch for UFortConversationMarker::Overlay_PreviewState");
static_assert(offsetof(UFortConversationMarker, ConversationMessage_Main) == 0x450, "Offset mismatch for UFortConversationMarker::ConversationMessage_Main");
static_assert(offsetof(UFortConversationMarker, Text_ParticipantName) == 0x460, "Offset mismatch for UFortConversationMarker::Text_ParticipantName");
static_assert(offsetof(UFortConversationMarker, Keybind_Nameplate) == 0x470, "Offset mismatch for UFortConversationMarker::Keybind_Nameplate");
static_assert(offsetof(UFortConversationMarker, NPCIcon) == 0x478, "Offset mismatch for UFortConversationMarker::NPCIcon");
static_assert(offsetof(UFortConversationMarker, CustomDialogMarkerIndicatorIcon) == 0x480, "Offset mismatch for UFortConversationMarker::CustomDialogMarkerIndicatorIcon");
static_assert(offsetof(UFortConversationMarker, DefaultDialogMarkerIndicatorIcon) == 0x488, "Offset mismatch for UFortConversationMarker::DefaultDialogMarkerIndicatorIcon");
static_assert(offsetof(UFortConversationMarker, DefaultMaxParticipantIconTexture) == 0x490, "Offset mismatch for UFortConversationMarker::DefaultMaxParticipantIconTexture");

// Size: 0x318 (Inherited: 0xa48, Single: 0xfffff8d0)
class UFortConversationMessageWidget : public UFortHUDElementWidget
{
public:

public:
    void SetPreviewMessage(const FText MessageToSet); // 0xff33a08 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void OnMainMessageSet(const FText NpcName, const FText MessageBody); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnMessageHidden(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnMessageShown(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPreviewMessageSet(const FText PreviewText); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortConversationMessageWidget) == 0x318, "Size mismatch for UFortConversationMessageWidget");

// Size: 0x1600 (Inherited: 0x5b60, Single: 0xffffbaa0)
class UFortConversationOption : public UFortRadialPickerEntry
{
public:
    USoundBase* OnOptionConfirmedSound; // 0x1560 (Size: 0x8, Type: ObjectProperty)
    USoundBase* OnOptionHoveredSound; // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_DisplayAsset; // 0x1570 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UObject*> DefaultSoftTaskIcon; // 0x1578 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<USoundBase*> DefaultConfirmChoiceSound; // 0x1598 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<USoundBase*> DefaultHoverChoiceSound; // 0x15b8 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_15d8[0x28]; // 0x15d8 (Size: 0x28, Type: PaddingProperty)

public:
    int32_t GetUnlockLevel() const; // 0xff32c00 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAvailable() const; // 0xff32c90 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLocked() const; // 0xff32cb4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnOptionConfirmed(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void OnSetupFromDisplayAsset(UObject*& DisplayAsset); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetupFromItemDef(UFortItem*& Item); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetupPivotFromRadialInformation(int32_t& NumElements, int32_t& ItemIndex); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortConversationOption) == 0x1600, "Size mismatch for UFortConversationOption");
static_assert(offsetof(UFortConversationOption, OnOptionConfirmedSound) == 0x1560, "Offset mismatch for UFortConversationOption::OnOptionConfirmedSound");
static_assert(offsetof(UFortConversationOption, OnOptionHoveredSound) == 0x1568, "Offset mismatch for UFortConversationOption::OnOptionHoveredSound");
static_assert(offsetof(UFortConversationOption, Switcher_DisplayAsset) == 0x1570, "Offset mismatch for UFortConversationOption::Switcher_DisplayAsset");
static_assert(offsetof(UFortConversationOption, DefaultSoftTaskIcon) == 0x1578, "Offset mismatch for UFortConversationOption::DefaultSoftTaskIcon");
static_assert(offsetof(UFortConversationOption, DefaultConfirmChoiceSound) == 0x1598, "Offset mismatch for UFortConversationOption::DefaultConfirmChoiceSound");
static_assert(offsetof(UFortConversationOption, DefaultHoverChoiceSound) == 0x15b8, "Offset mismatch for UFortConversationOption::DefaultHoverChoiceSound");

// Size: 0x188 (Inherited: 0x318, Single: 0xfffffe70)
class UFortConversationOptionsPanel : public UPanelWidget
{
public:
    uint8_t Pad_170[0x10]; // 0x170 (Size: 0x10, Type: PaddingProperty)
    int32_t MaxRows; // 0x180 (Size: 0x4, Type: IntProperty)
    int32_t MiddleColumnWidth; // 0x184 (Size: 0x4, Type: IntProperty)

public:
    UPanelSlot* AddChildToDynamicPanel(UWidget*& Content); // 0x5585728 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortConversationOptionsPanel) == 0x188, "Size mismatch for UFortConversationOptionsPanel");
static_assert(offsetof(UFortConversationOptionsPanel, MaxRows) == 0x180, "Offset mismatch for UFortConversationOptionsPanel::MaxRows");
static_assert(offsetof(UFortConversationOptionsPanel, MiddleColumnWidth) == 0x184, "Offset mismatch for UFortConversationOptionsPanel::MiddleColumnWidth");

// Size: 0x5e0 (Inherited: 0xb38, Single: 0xfffffaa8)
class UFortConversationScreen : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x10]; // 0x408 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnConversationOptionUpdated[0x10]; // 0x418 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_428[0x8]; // 0x428 (Size: 0x8, Type: PaddingProperty)
    UCommonVisibilitySwitcher* Switcher_Details; // 0x430 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_438[0x38]; // 0x438 (Size: 0x38, Type: PaddingProperty)
    UInputComponent* ConversationInputComp; // 0x470 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentlySelectedIndex; // 0x478 (Size: 0x4, Type: IntProperty)
    bool bBlockOptionIntroAnimation; // 0x47c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_47d[0x3]; // 0x47d (Size: 0x3, Type: PaddingProperty)
    FName RadialSelectionMaterialParameterName; // 0x480 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_484[0x4]; // 0x484 (Size: 0x4, Type: PaddingProperty)
    TArray<FGameplayTag> TagPriorities; // 0x488 (Size: 0x10, Type: ArrayProperty)
    FName InteractActionNameKBM; // 0x498 (Size: 0x4, Type: NameProperty)
    FName ADSInputAction; // 0x49c (Size: 0x4, Type: NameProperty)
    FName InteractActionNameGamepad; // 0x4a0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4a4[0x4]; // 0x4a4 (Size: 0x4, Type: PaddingProperty)
    FDataTableRowHandle ConfirmBinding; // 0x4a8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle MakeSelectionBinding; // 0x4b8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ADSMouseBinding; // 0x4c8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle CancelActionBinding; // 0x4d8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RightTriggerBinding; // 0x4e8 (Size: 0x10, Type: StructProperty)
    TMap<TSoftClassPtr, FString> DetailsNodeTypeToBrief; // 0x4f8 (Size: 0x50, Type: MapProperty)
    TSoftClassPtr ChatBrief; // 0x548 (Size: 0x20, Type: SoftClassProperty)
    FString DataDrivenBriefPrefix; // 0x568 (Size: 0x10, Type: StrProperty)
    TSoftClassPtr DataDrivenBrief; // 0x578 (Size: 0x20, Type: SoftClassProperty)
    UFortSlottedRadialMenu* RadialMenu_DialogOptions; // 0x598 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RadialHighlight; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UFortKeybindWidget* Keybind_Confirm; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    UFortBasicBrief* BasicBrief_Main; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_RadialMenu; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_Details; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_WheelContainer; // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_LoadingSpinner; // 0x5d8 (Size: 0x8, Type: ObjectProperty)

protected:
    void EndConversation(); // 0xb4a85b4 (Index: 0x0, Flags: Native|Protected)
    virtual void OnConversationOptionUnavailable(UFortRadialSlot*& SelectedEntry); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnConversationStarted(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnItemSelected(int32_t& OriginalIndex); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnOptionsPopulated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSelectedItemAvailabilityChanged(bool& bIsAvailable); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    bool ShouldBlockOptionIntroAnim() const; // 0xff33b5c (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortConversationScreen) == 0x5e0, "Size mismatch for UFortConversationScreen");
static_assert(offsetof(UFortConversationScreen, OnConversationOptionUpdated) == 0x418, "Offset mismatch for UFortConversationScreen::OnConversationOptionUpdated");
static_assert(offsetof(UFortConversationScreen, Switcher_Details) == 0x430, "Offset mismatch for UFortConversationScreen::Switcher_Details");
static_assert(offsetof(UFortConversationScreen, ConversationInputComp) == 0x470, "Offset mismatch for UFortConversationScreen::ConversationInputComp");
static_assert(offsetof(UFortConversationScreen, CurrentlySelectedIndex) == 0x478, "Offset mismatch for UFortConversationScreen::CurrentlySelectedIndex");
static_assert(offsetof(UFortConversationScreen, bBlockOptionIntroAnimation) == 0x47c, "Offset mismatch for UFortConversationScreen::bBlockOptionIntroAnimation");
static_assert(offsetof(UFortConversationScreen, RadialSelectionMaterialParameterName) == 0x480, "Offset mismatch for UFortConversationScreen::RadialSelectionMaterialParameterName");
static_assert(offsetof(UFortConversationScreen, TagPriorities) == 0x488, "Offset mismatch for UFortConversationScreen::TagPriorities");
static_assert(offsetof(UFortConversationScreen, InteractActionNameKBM) == 0x498, "Offset mismatch for UFortConversationScreen::InteractActionNameKBM");
static_assert(offsetof(UFortConversationScreen, ADSInputAction) == 0x49c, "Offset mismatch for UFortConversationScreen::ADSInputAction");
static_assert(offsetof(UFortConversationScreen, InteractActionNameGamepad) == 0x4a0, "Offset mismatch for UFortConversationScreen::InteractActionNameGamepad");
static_assert(offsetof(UFortConversationScreen, ConfirmBinding) == 0x4a8, "Offset mismatch for UFortConversationScreen::ConfirmBinding");
static_assert(offsetof(UFortConversationScreen, MakeSelectionBinding) == 0x4b8, "Offset mismatch for UFortConversationScreen::MakeSelectionBinding");
static_assert(offsetof(UFortConversationScreen, ADSMouseBinding) == 0x4c8, "Offset mismatch for UFortConversationScreen::ADSMouseBinding");
static_assert(offsetof(UFortConversationScreen, CancelActionBinding) == 0x4d8, "Offset mismatch for UFortConversationScreen::CancelActionBinding");
static_assert(offsetof(UFortConversationScreen, RightTriggerBinding) == 0x4e8, "Offset mismatch for UFortConversationScreen::RightTriggerBinding");
static_assert(offsetof(UFortConversationScreen, DetailsNodeTypeToBrief) == 0x4f8, "Offset mismatch for UFortConversationScreen::DetailsNodeTypeToBrief");
static_assert(offsetof(UFortConversationScreen, ChatBrief) == 0x548, "Offset mismatch for UFortConversationScreen::ChatBrief");
static_assert(offsetof(UFortConversationScreen, DataDrivenBriefPrefix) == 0x568, "Offset mismatch for UFortConversationScreen::DataDrivenBriefPrefix");
static_assert(offsetof(UFortConversationScreen, DataDrivenBrief) == 0x578, "Offset mismatch for UFortConversationScreen::DataDrivenBrief");
static_assert(offsetof(UFortConversationScreen, RadialMenu_DialogOptions) == 0x598, "Offset mismatch for UFortConversationScreen::RadialMenu_DialogOptions");
static_assert(offsetof(UFortConversationScreen, Image_RadialHighlight) == 0x5a0, "Offset mismatch for UFortConversationScreen::Image_RadialHighlight");
static_assert(offsetof(UFortConversationScreen, Keybind_Confirm) == 0x5a8, "Offset mismatch for UFortConversationScreen::Keybind_Confirm");
static_assert(offsetof(UFortConversationScreen, BasicBrief_Main) == 0x5b0, "Offset mismatch for UFortConversationScreen::BasicBrief_Main");
static_assert(offsetof(UFortConversationScreen, SizeBox_RadialMenu) == 0x5b8, "Offset mismatch for UFortConversationScreen::SizeBox_RadialMenu");
static_assert(offsetof(UFortConversationScreen, Overlay_Details) == 0x5c0, "Offset mismatch for UFortConversationScreen::Overlay_Details");
static_assert(offsetof(UFortConversationScreen, Overlay_WheelContainer) == 0x5c8, "Offset mismatch for UFortConversationScreen::Overlay_WheelContainer");
static_assert(offsetof(UFortConversationScreen, Image_Background) == 0x5d0, "Offset mismatch for UFortConversationScreen::Image_Background");
static_assert(offsetof(UFortConversationScreen, Image_LoadingSpinner) == 0x5d8, "Offset mismatch for UFortConversationScreen::Image_LoadingSpinner");

// Size: 0x350 (Inherited: 0xa08, Single: 0xfffff948)
class UFortDataDrivenServiceBrief : public UFortConversationOptionBrief
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* Text_TitleBar; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Description; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_StockRemaining; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UFortTransactionStrip* TransactionStrip_Main; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs; // 0x300 (Size: 0x50, Type: MapProperty)

protected:
    virtual void OnAbleToPurchase(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransactionInfoReceived(UFortItem*& Item); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUnableToPurchase(const FText Reason); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnWarningMessageUpdated(const FText WarningMessage); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortDataDrivenServiceBrief) == 0x350, "Size mismatch for UFortDataDrivenServiceBrief");
static_assert(offsetof(UFortDataDrivenServiceBrief, Text_TitleBar) == 0x2e0, "Offset mismatch for UFortDataDrivenServiceBrief::Text_TitleBar");
static_assert(offsetof(UFortDataDrivenServiceBrief, RichText_Description) == 0x2e8, "Offset mismatch for UFortDataDrivenServiceBrief::RichText_Description");
static_assert(offsetof(UFortDataDrivenServiceBrief, Text_StockRemaining) == 0x2f0, "Offset mismatch for UFortDataDrivenServiceBrief::Text_StockRemaining");
static_assert(offsetof(UFortDataDrivenServiceBrief, TransactionStrip_Main) == 0x2f8, "Offset mismatch for UFortDataDrivenServiceBrief::TransactionStrip_Main");
static_assert(offsetof(UFortDataDrivenServiceBrief, ServiceConfigs) == 0x300, "Offset mismatch for UFortDataDrivenServiceBrief::ServiceConfigs");

// Size: 0x310 (Inherited: 0xcf8, Single: 0xfffff618)
class UFortDuelBrief : public UFortItemTransactionBrief
{
public:
    FText TextTemplate; // 0x2f0 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UCommonTileView* TileView; // 0x308 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void DisplayLootItems(const TArray<UFortItem*> Items); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortDuelBrief) == 0x310, "Size mismatch for UFortDuelBrief");
static_assert(offsetof(UFortDuelBrief, TextTemplate) == 0x2f0, "Offset mismatch for UFortDuelBrief::TextTemplate");
static_assert(offsetof(UFortDuelBrief, Text_Objective) == 0x300, "Offset mismatch for UFortDuelBrief::Text_Objective");
static_assert(offsetof(UFortDuelBrief, TileView) == 0x308, "Offset mismatch for UFortDuelBrief::TileView");

// Size: 0x310 (Inherited: 0xcf8, Single: 0xfffff618)
class UFortHireBrief : public UFortItemTransactionBrief
{
public:
    FText TextTemplate; // 0x2f0 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UDataTable* SpecializationsVisualDataTable; // 0x308 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BP_SetSpecializationIcon(UObject*& ResourceObject); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleNPCDismissal(bool& bAtMaxNPCNum, bool& bWillDismissNPCAtHire); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortHireBrief) == 0x310, "Size mismatch for UFortHireBrief");
static_assert(offsetof(UFortHireBrief, TextTemplate) == 0x2f0, "Offset mismatch for UFortHireBrief::TextTemplate");
static_assert(offsetof(UFortHireBrief, Text_Objective) == 0x300, "Offset mismatch for UFortHireBrief::Text_Objective");
static_assert(offsetof(UFortHireBrief, SpecializationsVisualDataTable) == 0x308, "Offset mismatch for UFortHireBrief::SpecializationsVisualDataTable");

// Size: 0x308 (Inherited: 0xcf8, Single: 0xfffff610)
class UFortIntelBrief : public UFortItemTransactionBrief
{
public:
    FText TextTemplate; // 0x2f0 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective; // 0x300 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortIntelBrief) == 0x308, "Size mismatch for UFortIntelBrief");
static_assert(offsetof(UFortIntelBrief, TextTemplate) == 0x2f0, "Offset mismatch for UFortIntelBrief::TextTemplate");
static_assert(offsetof(UFortIntelBrief, Text_Objective) == 0x300, "Offset mismatch for UFortIntelBrief::Text_Objective");

// Size: 0x400 (Inherited: 0x730, Single: 0xfffffcd0)
class UFortItemFundBrief : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0xa8]; // 0x2d8 (Size: 0xa8, Type: PaddingProperty)
    UCommonTextBlock* Text_TitleBar; // 0x380 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ProgressPercent; // 0x388 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ProgressCount; // 0x390 (Size: 0x8, Type: ObjectProperty)
    UFortSimpleMaterialProgressBar* Progress_Funding; // 0x398 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* LazyImage_Icon; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UFortTransactionStrip* TransactionStrip_Main; // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs; // 0x3b0 (Size: 0x50, Type: MapProperty)

private:
    FText GetDataForKey(FString& const Key, bool& const bUseIndexAdjustment); // 0xff327cc (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable)

protected:
    virtual void InitializeFromContext(const FConversationContext ConversationContext); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnIntializationComplete(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnProgressUpdated(float& const CurrentFundingFraction); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortItemFundBrief) == 0x400, "Size mismatch for UFortItemFundBrief");
static_assert(offsetof(UFortItemFundBrief, Text_TitleBar) == 0x380, "Offset mismatch for UFortItemFundBrief::Text_TitleBar");
static_assert(offsetof(UFortItemFundBrief, Text_ProgressPercent) == 0x388, "Offset mismatch for UFortItemFundBrief::Text_ProgressPercent");
static_assert(offsetof(UFortItemFundBrief, Text_ProgressCount) == 0x390, "Offset mismatch for UFortItemFundBrief::Text_ProgressCount");
static_assert(offsetof(UFortItemFundBrief, Progress_Funding) == 0x398, "Offset mismatch for UFortItemFundBrief::Progress_Funding");
static_assert(offsetof(UFortItemFundBrief, LazyImage_Icon) == 0x3a0, "Offset mismatch for UFortItemFundBrief::LazyImage_Icon");
static_assert(offsetof(UFortItemFundBrief, TransactionStrip_Main) == 0x3a8, "Offset mismatch for UFortItemFundBrief::TransactionStrip_Main");
static_assert(offsetof(UFortItemFundBrief, ServiceConfigs) == 0x3b0, "Offset mismatch for UFortItemFundBrief::ServiceConfigs");

// Size: 0x350 (Inherited: 0xd48, Single: 0xfffff608)
class UFortMultiItemFundBrief : public UFortSingleItemFundBrief
{
public:
    UFortItemFundBrief* Item_EntrySecondary; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UFortItemFundBrief* Item_EntryTertiary; // 0x348 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void UpdateSelectedVisuals(int32_t& SelectedIndex); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortMultiItemFundBrief) == 0x350, "Size mismatch for UFortMultiItemFundBrief");
static_assert(offsetof(UFortMultiItemFundBrief, Item_EntrySecondary) == 0x340, "Offset mismatch for UFortMultiItemFundBrief::Item_EntrySecondary");
static_assert(offsetof(UFortMultiItemFundBrief, Item_EntryTertiary) == 0x348, "Offset mismatch for UFortMultiItemFundBrief::Item_EntryTertiary");

// Size: 0x340 (Inherited: 0xa08, Single: 0xfffff938)
class UFortSingleItemFundBrief : public UFortConversationOptionBrief
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    UFortItemFundBrief* Item_Entry; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UFortNPCTextDisplay* NPCTextDisplay; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs; // 0x2f0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UFortSingleItemFundBrief) == 0x340, "Size mismatch for UFortSingleItemFundBrief");
static_assert(offsetof(UFortSingleItemFundBrief, Item_Entry) == 0x2e0, "Offset mismatch for UFortSingleItemFundBrief::Item_Entry");
static_assert(offsetof(UFortSingleItemFundBrief, NPCTextDisplay) == 0x2e8, "Offset mismatch for UFortSingleItemFundBrief::NPCTextDisplay");
static_assert(offsetof(UFortSingleItemFundBrief, ServiceConfigs) == 0x2f0, "Offset mismatch for UFortSingleItemFundBrief::ServiceConfigs");

// Size: 0x2c0 (Inherited: 0x458, Single: 0xfffffe68)
class UFortNPCTextDisplay : public UUserWidget
{
public:
    UCommonRichTextBlock* Text_Message; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* LazyImage_NPCImage; // 0x2b8 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnItemNameUpdated(FString& ItemName); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void OnTextUpdated(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortNPCTextDisplay) == 0x2c0, "Size mismatch for UFortNPCTextDisplay");
static_assert(offsetof(UFortNPCTextDisplay, Text_Message) == 0x2b0, "Offset mismatch for UFortNPCTextDisplay::Text_Message");
static_assert(offsetof(UFortNPCTextDisplay, LazyImage_NPCImage) == 0x2b8, "Offset mismatch for UFortNPCTextDisplay::LazyImage_NPCImage");

// Size: 0x200 (Inherited: 0xe0, Single: 0x120)
class UFortPlayerConversationUIComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    bool bBlockUISpawning; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)
    TSoftClassPtr DialogWidgetSoftClass; // 0xc8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr DialogMarkerSoftClass; // 0xe8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr MobileDialogWidgetSoftClass; // 0x108 (Size: 0x20, Type: SoftClassProperty)
    TArray<UDynamicUIScene*> SpectatorConversationScenes; // 0x128 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicUIScene*> SpectatorMobileConversationScenes; // 0x138 (Size: 0x10, Type: ArrayProperty)
    UClass* DialogWidgetClass; // 0x148 (Size: 0x8, Type: ClassProperty)
    UClass* DialogMarkerClass; // 0x150 (Size: 0x8, Type: ClassProperty)
    FUserWidgetPool DialogWidgetPool; // 0x158 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_1e0[0x20]; // 0x1e0 (Size: 0x20, Type: PaddingProperty)

private:
    void OnMinigameStarted(); // 0xff33364 (Index: 0x1, Flags: Final|Native|Private)

protected:
    void OnMinigameReady(AFortMinigame*& InMinigame); // 0xff330ac (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortPlayerConversationUIComponent) == 0x200, "Size mismatch for UFortPlayerConversationUIComponent");
static_assert(offsetof(UFortPlayerConversationUIComponent, bBlockUISpawning) == 0xc0, "Offset mismatch for UFortPlayerConversationUIComponent::bBlockUISpawning");
static_assert(offsetof(UFortPlayerConversationUIComponent, DialogWidgetSoftClass) == 0xc8, "Offset mismatch for UFortPlayerConversationUIComponent::DialogWidgetSoftClass");
static_assert(offsetof(UFortPlayerConversationUIComponent, DialogMarkerSoftClass) == 0xe8, "Offset mismatch for UFortPlayerConversationUIComponent::DialogMarkerSoftClass");
static_assert(offsetof(UFortPlayerConversationUIComponent, MobileDialogWidgetSoftClass) == 0x108, "Offset mismatch for UFortPlayerConversationUIComponent::MobileDialogWidgetSoftClass");
static_assert(offsetof(UFortPlayerConversationUIComponent, SpectatorConversationScenes) == 0x128, "Offset mismatch for UFortPlayerConversationUIComponent::SpectatorConversationScenes");
static_assert(offsetof(UFortPlayerConversationUIComponent, SpectatorMobileConversationScenes) == 0x138, "Offset mismatch for UFortPlayerConversationUIComponent::SpectatorMobileConversationScenes");
static_assert(offsetof(UFortPlayerConversationUIComponent, DialogWidgetClass) == 0x148, "Offset mismatch for UFortPlayerConversationUIComponent::DialogWidgetClass");
static_assert(offsetof(UFortPlayerConversationUIComponent, DialogMarkerClass) == 0x150, "Offset mismatch for UFortPlayerConversationUIComponent::DialogMarkerClass");
static_assert(offsetof(UFortPlayerConversationUIComponent, DialogWidgetPool) == 0x158, "Offset mismatch for UFortPlayerConversationUIComponent::DialogWidgetPool");

// Size: 0x320 (Inherited: 0xa08, Single: 0xfffff918)
class UFortQuestBrief : public UFortConversationOptionBrief
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    FText ThisMatchOnlyQuestText; // 0x2e0 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_MoneyReward; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_XpReward; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ExpirationTime; // 0x308 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_QuestProviderImage; // 0x310 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_QuestProvider; // 0x318 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnQuestExpirationTimeSet(bool& const bDisplayExpirationTime); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnQuestInformationRecieved(const FText Objective, const FFortRarityItemData RarityData, const FGameplayTag CategoryTag, int32_t& XPReward, int32_t& MoneyReward, int32_t& TokenReward, const TSoftObjectPtr<UTexture2D*> TokenRewardIcon); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortQuestBrief) == 0x320, "Size mismatch for UFortQuestBrief");
static_assert(offsetof(UFortQuestBrief, ThisMatchOnlyQuestText) == 0x2e0, "Offset mismatch for UFortQuestBrief::ThisMatchOnlyQuestText");
static_assert(offsetof(UFortQuestBrief, Text_Objective) == 0x2f0, "Offset mismatch for UFortQuestBrief::Text_Objective");
static_assert(offsetof(UFortQuestBrief, Text_MoneyReward) == 0x2f8, "Offset mismatch for UFortQuestBrief::Text_MoneyReward");
static_assert(offsetof(UFortQuestBrief, Text_XpReward) == 0x300, "Offset mismatch for UFortQuestBrief::Text_XpReward");
static_assert(offsetof(UFortQuestBrief, Text_ExpirationTime) == 0x308, "Offset mismatch for UFortQuestBrief::Text_ExpirationTime");
static_assert(offsetof(UFortQuestBrief, LazyImage_QuestProviderImage) == 0x310, "Offset mismatch for UFortQuestBrief::LazyImage_QuestProviderImage");
static_assert(offsetof(UFortQuestBrief, Overlay_QuestProvider) == 0x318, "Offset mismatch for UFortQuestBrief::Overlay_QuestProvider");

// Size: 0x308 (Inherited: 0xcf8, Single: 0xfffff610)
class UFortShowFutureStormCircleBrief : public UFortItemTransactionBrief
{
public:
    FText PurchaseServiceText; // 0x2f0 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Display; // 0x300 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnAbleToPurchase(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUnableToPurchase(EPreventUseStormCircleServiceReason& Reason); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortShowFutureStormCircleBrief) == 0x308, "Size mismatch for UFortShowFutureStormCircleBrief");
static_assert(offsetof(UFortShowFutureStormCircleBrief, PurchaseServiceText) == 0x2f0, "Offset mismatch for UFortShowFutureStormCircleBrief::PurchaseServiceText");
static_assert(offsetof(UFortShowFutureStormCircleBrief, Text_Display) == 0x300, "Offset mismatch for UFortShowFutureStormCircleBrief::Text_Display");

// Size: 0x328 (Inherited: 0xa08, Single: 0xfffff920)
class UFortSingleOrMultiItemFundBrief : public UFortConversationOptionBrief
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    TSoftClassPtr SingleItemBrief; // 0x2e0 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr MultiItemsBrief; // 0x300 (Size: 0x20, Type: SoftClassProperty)
    UOverlay* Overlay_Brief; // 0x320 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortSingleOrMultiItemFundBrief) == 0x328, "Size mismatch for UFortSingleOrMultiItemFundBrief");
static_assert(offsetof(UFortSingleOrMultiItemFundBrief, SingleItemBrief) == 0x2e0, "Offset mismatch for UFortSingleOrMultiItemFundBrief::SingleItemBrief");
static_assert(offsetof(UFortSingleOrMultiItemFundBrief, MultiItemsBrief) == 0x300, "Offset mismatch for UFortSingleOrMultiItemFundBrief::MultiItemsBrief");
static_assert(offsetof(UFortSingleOrMultiItemFundBrief, Overlay_Brief) == 0x320, "Offset mismatch for UFortSingleOrMultiItemFundBrief::Overlay_Brief");

// Size: 0x338 (Inherited: 0x458, Single: 0xfffffee0)
class UFortTransactionStrip : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* Text_CostDescription; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortWorldItemDefinition*> CachedGlobalCurrency; // 0x2c0 (Size: 0x8, Type: WeakObjectProperty)
    UFortWorldItemDefinition* ResourceCurrency; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2d0[0x68]; // 0x2d0 (Size: 0x68, Type: PaddingProperty)

protected:
    virtual void OnSetTransactionCostVisibility(bool& const bVisible); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransactionInfoReceived(const FFortServiceTransactionInfo TransactionInfo); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortTransactionStrip) == 0x338, "Size mismatch for UFortTransactionStrip");
static_assert(offsetof(UFortTransactionStrip, Text_CostDescription) == 0x2b8, "Offset mismatch for UFortTransactionStrip::Text_CostDescription");
static_assert(offsetof(UFortTransactionStrip, CachedGlobalCurrency) == 0x2c0, "Offset mismatch for UFortTransactionStrip::CachedGlobalCurrency");
static_assert(offsetof(UFortTransactionStrip, ResourceCurrency) == 0x2c8, "Offset mismatch for UFortTransactionStrip::ResourceCurrency");

// Size: 0x2f0 (Inherited: 0xcf8, Single: 0xfffff5f8)
class UFortUpgradeBrief : public UFortItemTransactionBrief
{
public:

protected:
    virtual void OnUnableToUpgrade(EFortWeaponUpgradeInteractionResult& CannotUpgradeCause); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpgradeInfoReceived(UFortItem*& CurrentWeapon); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortUpgradeBrief) == 0x2f0, "Size mismatch for UFortUpgradeBrief");

// Size: 0x608 (Inherited: 0x1118, Single: 0xfffff4f0)
class UMobileConversationScreen : public UFortConversationScreen
{
public:
    UButton* MobileButtonConfirm; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    UButton* MobileButtonTouchInformation; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5f0[0x8]; // 0x5f0 (Size: 0x8, Type: PaddingProperty)
    UCommonButtonBase* MobileCloseButton; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_CenteredDetails; // 0x600 (Size: 0x8, Type: ObjectProperty)

protected:
    void OnHandleConfirmClicked(); // 0xff33098 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UMobileConversationScreen) == 0x608, "Size mismatch for UMobileConversationScreen");
static_assert(offsetof(UMobileConversationScreen, MobileButtonConfirm) == 0x5e0, "Offset mismatch for UMobileConversationScreen::MobileButtonConfirm");
static_assert(offsetof(UMobileConversationScreen, MobileButtonTouchInformation) == 0x5e8, "Offset mismatch for UMobileConversationScreen::MobileButtonTouchInformation");
static_assert(offsetof(UMobileConversationScreen, MobileCloseButton) == 0x5f8, "Offset mismatch for UMobileConversationScreen::MobileCloseButton");
static_assert(offsetof(UMobileConversationScreen, Switcher_CenteredDetails) == 0x600, "Offset mismatch for UMobileConversationScreen::Switcher_CenteredDetails");

