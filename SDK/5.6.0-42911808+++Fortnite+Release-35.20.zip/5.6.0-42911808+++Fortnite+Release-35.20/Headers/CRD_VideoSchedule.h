/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_VideoSchedule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "LevelSequence.h"

// Size: 0xd08 (Inherited: 0x39a0, Single: 0xffffd368)
class AVideoScheduleDeviceBase : public ABuildingProp
{
public:
    uint8_t Pad_c00[0x48]; // 0xc00 (Size: 0x48, Type: PaddingProperty)
    uint8_t RepeatSchedule; // 0xc48 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c49[0x7]; // 0xc49 (Size: 0x7, Type: PaddingProperty)
    TArray<FVideoScheduleDeviceEntryAbsolute> AbsoluteSchedule; // 0xc50 (Size: 0x10, Type: ArrayProperty)
    TArray<FVideoScheduleDeviceEntryDaily> DailySchedule; // 0xc60 (Size: 0x10, Type: ArrayProperty)
    TArray<FVideoScheduleDeviceEntryHourly> HourlySchedule; // 0xc70 (Size: 0x10, Type: ArrayProperty)
    bool bFillSchedule; // 0xc80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c81[0x3]; // 0xc81 (Size: 0x3, Type: PaddingProperty)
    int32_t FillScheduleGap; // 0xc84 (Size: 0x4, Type: IntProperty)
    int32_t FillScheduleAlign; // 0xc88 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c8c[0x4]; // 0xc8c (Size: 0x4, Type: PaddingProperty)
    FString SimpleSchedule; // 0xc90 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_ca0[0x68]; // 0xca0 (Size: 0x68, Type: PaddingProperty)

public:
    virtual void OnControlVideoPlayer(FString& VUID, FDateTime& StartTime, const TArray<AController*> Players, ULevelSequence*& const Sequence); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    void StartSchedule(AController*& InPlayer); // 0x11e9c754 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void StopSchedule(AController*& InPlayer); // 0x11e9c880 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void TestControlVideoPlayer(FString& VUID, FDateTime& StartTime, const TArray<AController*> Players); // 0x11e9caa8 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(AVideoScheduleDeviceBase) == 0xd08, "Size mismatch for AVideoScheduleDeviceBase");
static_assert(offsetof(AVideoScheduleDeviceBase, RepeatSchedule) == 0xc48, "Offset mismatch for AVideoScheduleDeviceBase::RepeatSchedule");
static_assert(offsetof(AVideoScheduleDeviceBase, AbsoluteSchedule) == 0xc50, "Offset mismatch for AVideoScheduleDeviceBase::AbsoluteSchedule");
static_assert(offsetof(AVideoScheduleDeviceBase, DailySchedule) == 0xc60, "Offset mismatch for AVideoScheduleDeviceBase::DailySchedule");
static_assert(offsetof(AVideoScheduleDeviceBase, HourlySchedule) == 0xc70, "Offset mismatch for AVideoScheduleDeviceBase::HourlySchedule");
static_assert(offsetof(AVideoScheduleDeviceBase, bFillSchedule) == 0xc80, "Offset mismatch for AVideoScheduleDeviceBase::bFillSchedule");
static_assert(offsetof(AVideoScheduleDeviceBase, FillScheduleGap) == 0xc84, "Offset mismatch for AVideoScheduleDeviceBase::FillScheduleGap");
static_assert(offsetof(AVideoScheduleDeviceBase, FillScheduleAlign) == 0xc88, "Offset mismatch for AVideoScheduleDeviceBase::FillScheduleAlign");
static_assert(offsetof(AVideoScheduleDeviceBase, SimpleSchedule) == 0xc90, "Offset mismatch for AVideoScheduleDeviceBase::SimpleSchedule");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FVideoScheduleDeviceEntryHourly
{
    int32_t Minutes; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Seconds; // 0x4 (Size: 0x4, Type: IntProperty)
    FString VUID; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    ULevelSequence* Sequence; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVideoScheduleDeviceEntryHourly) == 0x28, "Size mismatch for FVideoScheduleDeviceEntryHourly");
static_assert(offsetof(FVideoScheduleDeviceEntryHourly, Minutes) == 0x0, "Offset mismatch for FVideoScheduleDeviceEntryHourly::Minutes");
static_assert(offsetof(FVideoScheduleDeviceEntryHourly, Seconds) == 0x4, "Offset mismatch for FVideoScheduleDeviceEntryHourly::Seconds");
static_assert(offsetof(FVideoScheduleDeviceEntryHourly, VUID) == 0x8, "Offset mismatch for FVideoScheduleDeviceEntryHourly::VUID");
static_assert(offsetof(FVideoScheduleDeviceEntryHourly, DurationSeconds) == 0x18, "Offset mismatch for FVideoScheduleDeviceEntryHourly::DurationSeconds");
static_assert(offsetof(FVideoScheduleDeviceEntryHourly, Sequence) == 0x20, "Offset mismatch for FVideoScheduleDeviceEntryHourly::Sequence");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FVideoScheduleDeviceEntryDaily
{
    int32_t Hours; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Seconds; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FString VUID; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    ULevelSequence* Sequence; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVideoScheduleDeviceEntryDaily) == 0x30, "Size mismatch for FVideoScheduleDeviceEntryDaily");
static_assert(offsetof(FVideoScheduleDeviceEntryDaily, Hours) == 0x0, "Offset mismatch for FVideoScheduleDeviceEntryDaily::Hours");
static_assert(offsetof(FVideoScheduleDeviceEntryDaily, Minutes) == 0x4, "Offset mismatch for FVideoScheduleDeviceEntryDaily::Minutes");
static_assert(offsetof(FVideoScheduleDeviceEntryDaily, Seconds) == 0x8, "Offset mismatch for FVideoScheduleDeviceEntryDaily::Seconds");
static_assert(offsetof(FVideoScheduleDeviceEntryDaily, VUID) == 0x10, "Offset mismatch for FVideoScheduleDeviceEntryDaily::VUID");
static_assert(offsetof(FVideoScheduleDeviceEntryDaily, DurationSeconds) == 0x20, "Offset mismatch for FVideoScheduleDeviceEntryDaily::DurationSeconds");
static_assert(offsetof(FVideoScheduleDeviceEntryDaily, Sequence) == 0x28, "Offset mismatch for FVideoScheduleDeviceEntryDaily::Sequence");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FVideoScheduleDeviceEntryAbsolute
{
    FString IsoStartTime; // 0x0 (Size: 0x10, Type: StrProperty)
    FString VUID; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    ULevelSequence* Sequence; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVideoScheduleDeviceEntryAbsolute) == 0x30, "Size mismatch for FVideoScheduleDeviceEntryAbsolute");
static_assert(offsetof(FVideoScheduleDeviceEntryAbsolute, IsoStartTime) == 0x0, "Offset mismatch for FVideoScheduleDeviceEntryAbsolute::IsoStartTime");
static_assert(offsetof(FVideoScheduleDeviceEntryAbsolute, VUID) == 0x10, "Offset mismatch for FVideoScheduleDeviceEntryAbsolute::VUID");
static_assert(offsetof(FVideoScheduleDeviceEntryAbsolute, DurationSeconds) == 0x20, "Offset mismatch for FVideoScheduleDeviceEntryAbsolute::DurationSeconds");
static_assert(offsetof(FVideoScheduleDeviceEntryAbsolute, Sequence) == 0x28, "Offset mismatch for FVideoScheduleDeviceEntryAbsolute::Sequence");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FVideoScheduleDeviceScheduleInfo
{
    FDateTime StartTime; // 0x0 (Size: 0x8, Type: StructProperty)
    FTimespan RelativeStartTime; // 0x8 (Size: 0x8, Type: StructProperty)
    FString VUID; // 0x10 (Size: 0x10, Type: StrProperty)
    ULevelSequence* Sequence; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVideoScheduleDeviceScheduleInfo) == 0x28, "Size mismatch for FVideoScheduleDeviceScheduleInfo");
static_assert(offsetof(FVideoScheduleDeviceScheduleInfo, StartTime) == 0x0, "Offset mismatch for FVideoScheduleDeviceScheduleInfo::StartTime");
static_assert(offsetof(FVideoScheduleDeviceScheduleInfo, RelativeStartTime) == 0x8, "Offset mismatch for FVideoScheduleDeviceScheduleInfo::RelativeStartTime");
static_assert(offsetof(FVideoScheduleDeviceScheduleInfo, VUID) == 0x10, "Offset mismatch for FVideoScheduleDeviceScheduleInfo::VUID");
static_assert(offsetof(FVideoScheduleDeviceScheduleInfo, Sequence) == 0x20, "Offset mismatch for FVideoScheduleDeviceScheduleInfo::Sequence");

