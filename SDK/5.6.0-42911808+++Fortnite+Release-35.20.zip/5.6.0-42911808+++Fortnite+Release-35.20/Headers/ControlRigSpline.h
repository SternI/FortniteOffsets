/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRigSpline
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ControlRig.h"
#include "RigVM.h"
#include "CoreUObject.h"

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FControlRigSplineImpl
{
};

static_assert(sizeof(FControlRigSplineImpl) == 0x68, "Size mismatch for FControlRigSplineImpl");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FControlRigSpline
{
};

static_assert(sizeof(FControlRigSpline) == 0x18, "Size mismatch for FControlRigSpline");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_ControlRigSplineBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_ControlRigSplineBase) == 0x8, "Size mismatch for FRigUnit_ControlRigSplineBase");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigUnit_ControlRigSplineFromPoints : FRigUnit_ControlRigSplineBase
{
    TArray<FVector> Points; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t SplineMode; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bClosed; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
    int32_t SamplesPerSegment; // 0x1c (Size: 0x4, Type: IntProperty)
    float Compression; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Stretch; // 0x24 (Size: 0x4, Type: FloatProperty)
    FControlRigSpline Spline; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ControlRigSplineFromPoints) == 0x40, "Size mismatch for FRigUnit_ControlRigSplineFromPoints");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, Points) == 0x8, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::Points");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, SplineMode) == 0x18, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::SplineMode");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, bClosed) == 0x19, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::bClosed");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, SamplesPerSegment) == 0x1c, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::SamplesPerSegment");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, Compression) == 0x20, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::Compression");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, Stretch) == 0x24, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::Stretch");
static_assert(offsetof(FRigUnit_ControlRigSplineFromPoints, Spline) == 0x28, "Offset mismatch for FRigUnit_ControlRigSplineFromPoints::Spline");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigUnit_ControlRigSplineFromTransforms : FRigUnit_ControlRigSplineBase
{
    TArray<FTransform> Transforms; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t SplineMode; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bClosed; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
    int32_t SamplesPerSegment; // 0x1c (Size: 0x4, Type: IntProperty)
    float Compression; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Stretch; // 0x24 (Size: 0x4, Type: FloatProperty)
    FControlRigSpline Spline; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ControlRigSplineFromTransforms) == 0x40, "Size mismatch for FRigUnit_ControlRigSplineFromTransforms");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, Transforms) == 0x8, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::Transforms");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, SplineMode) == 0x18, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::SplineMode");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, bClosed) == 0x19, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::bClosed");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, SamplesPerSegment) == 0x1c, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::SamplesPerSegment");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, Compression) == 0x20, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::Compression");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, Stretch) == 0x24, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::Stretch");
static_assert(offsetof(FRigUnit_ControlRigSplineFromTransforms, Spline) == 0x28, "Offset mismatch for FRigUnit_ControlRigSplineFromTransforms::Spline");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetSplinePoints : FRigUnitMutable
{
    TArray<FVector> Points; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetSplinePoints) == 0x38, "Size mismatch for FRigUnit_SetSplinePoints");
static_assert(offsetof(FRigUnit_SetSplinePoints, Points) == 0x10, "Offset mismatch for FRigUnit_SetSplinePoints::Points");
static_assert(offsetof(FRigUnit_SetSplinePoints, Spline) == 0x20, "Offset mismatch for FRigUnit_SetSplinePoints::Spline");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetSplineTransforms : FRigUnitMutable
{
    TArray<FTransform> Transforms; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetSplineTransforms) == 0x38, "Size mismatch for FRigUnit_SetSplineTransforms");
static_assert(offsetof(FRigUnit_SetSplineTransforms, Transforms) == 0x10, "Offset mismatch for FRigUnit_SetSplineTransforms::Transforms");
static_assert(offsetof(FRigUnit_SetSplineTransforms, Spline) == 0x20, "Offset mismatch for FRigUnit_SetSplineTransforms::Spline");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigUnit_PositionFromControlRigSpline : FRigUnit_ControlRigSplineBase
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    float U; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PositionFromControlRigSpline) == 0x40, "Size mismatch for FRigUnit_PositionFromControlRigSpline");
static_assert(offsetof(FRigUnit_PositionFromControlRigSpline, Spline) == 0x8, "Offset mismatch for FRigUnit_PositionFromControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_PositionFromControlRigSpline, U) == 0x20, "Offset mismatch for FRigUnit_PositionFromControlRigSpline::U");
static_assert(offsetof(FRigUnit_PositionFromControlRigSpline, Position) == 0x28, "Offset mismatch for FRigUnit_PositionFromControlRigSpline::Position");

// Size: 0xa0 (Inherited: 0x18, Single: 0x88)
struct FRigUnit_TransformFromControlRigSpline : FRigUnit_ControlRigSplineBase
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector UpVector; // 0x20 (Size: 0x18, Type: StructProperty)
    float Roll; // 0x38 (Size: 0x4, Type: FloatProperty)
    float U; // 0x3c (Size: 0x4, Type: FloatProperty)
    FTransform Transform; // 0x40 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TransformFromControlRigSpline) == 0xa0, "Size mismatch for FRigUnit_TransformFromControlRigSpline");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline, Spline) == 0x8, "Offset mismatch for FRigUnit_TransformFromControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline, UpVector) == 0x20, "Offset mismatch for FRigUnit_TransformFromControlRigSpline::UpVector");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline, Roll) == 0x38, "Offset mismatch for FRigUnit_TransformFromControlRigSpline::Roll");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline, U) == 0x3c, "Offset mismatch for FRigUnit_TransformFromControlRigSpline::U");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline, Transform) == 0x40, "Offset mismatch for FRigUnit_TransformFromControlRigSpline::Transform");

// Size: 0xc0 (Inherited: 0x18, Single: 0xa8)
struct FRigUnit_TransformFromControlRigSpline2 : FRigUnit_ControlRigSplineBase
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    float U; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FVector PrimaryAxis; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x40 (Size: 0x18, Type: StructProperty)
    FTransform Transform; // 0x60 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TransformFromControlRigSpline2) == 0xc0, "Size mismatch for FRigUnit_TransformFromControlRigSpline2");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline2, Spline) == 0x8, "Offset mismatch for FRigUnit_TransformFromControlRigSpline2::Spline");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline2, U) == 0x20, "Offset mismatch for FRigUnit_TransformFromControlRigSpline2::U");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline2, PrimaryAxis) == 0x28, "Offset mismatch for FRigUnit_TransformFromControlRigSpline2::PrimaryAxis");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline2, SecondaryAxis) == 0x40, "Offset mismatch for FRigUnit_TransformFromControlRigSpline2::SecondaryAxis");
static_assert(offsetof(FRigUnit_TransformFromControlRigSpline2, Transform) == 0x60, "Offset mismatch for FRigUnit_TransformFromControlRigSpline2::Transform");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigUnit_TangentFromControlRigSpline : FRigUnit_ControlRigSplineBase
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    float U; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FVector Tangent; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TangentFromControlRigSpline) == 0x40, "Size mismatch for FRigUnit_TangentFromControlRigSpline");
static_assert(offsetof(FRigUnit_TangentFromControlRigSpline, Spline) == 0x8, "Offset mismatch for FRigUnit_TangentFromControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_TangentFromControlRigSpline, U) == 0x20, "Offset mismatch for FRigUnit_TangentFromControlRigSpline::U");
static_assert(offsetof(FRigUnit_TangentFromControlRigSpline, Tangent) == 0x28, "Offset mismatch for FRigUnit_TangentFromControlRigSpline::Tangent");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FRigUnit_DrawControlRigSpline : FRigUnitMutable
{
    FControlRigSpline Spline; // 0x10 (Size: 0x18, Type: StructProperty)
    FLinearColor Color; // 0x28 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x38 (Size: 0x4, Type: FloatProperty)
    int32_t Detail; // 0x3c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigUnit_DrawControlRigSpline) == 0x40, "Size mismatch for FRigUnit_DrawControlRigSpline");
static_assert(offsetof(FRigUnit_DrawControlRigSpline, Spline) == 0x10, "Offset mismatch for FRigUnit_DrawControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_DrawControlRigSpline, Color) == 0x28, "Offset mismatch for FRigUnit_DrawControlRigSpline::Color");
static_assert(offsetof(FRigUnit_DrawControlRigSpline, Thickness) == 0x38, "Offset mismatch for FRigUnit_DrawControlRigSpline::Thickness");
static_assert(offsetof(FRigUnit_DrawControlRigSpline, Detail) == 0x3c, "Offset mismatch for FRigUnit_DrawControlRigSpline::Detail");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FRigUnit_GetLengthControlRigSpline : FRigUnit
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    float Length; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetLengthControlRigSpline) == 0x28, "Size mismatch for FRigUnit_GetLengthControlRigSpline");
static_assert(offsetof(FRigUnit_GetLengthControlRigSpline, Spline) == 0x8, "Offset mismatch for FRigUnit_GetLengthControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_GetLengthControlRigSpline, Length) == 0x20, "Offset mismatch for FRigUnit_GetLengthControlRigSpline::Length");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FRigUnit_GetLengthAtParamControlRigSpline : FRigUnit
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    float U; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Length; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_GetLengthAtParamControlRigSpline) == 0x28, "Size mismatch for FRigUnit_GetLengthAtParamControlRigSpline");
static_assert(offsetof(FRigUnit_GetLengthAtParamControlRigSpline, Spline) == 0x8, "Offset mismatch for FRigUnit_GetLengthAtParamControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_GetLengthAtParamControlRigSpline, U) == 0x20, "Offset mismatch for FRigUnit_GetLengthAtParamControlRigSpline::U");
static_assert(offsetof(FRigUnit_GetLengthAtParamControlRigSpline, Length) == 0x24, "Offset mismatch for FRigUnit_GetLengthAtParamControlRigSpline::Length");

// Size: 0x1e0 (Inherited: 0x30, Single: 0x1b0)
struct FRigUnit_FitChainToSplineCurve : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Alignment; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x40 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision; // 0x44 (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x60 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition; // 0x78 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0xa0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a1[0x3]; // 0xa1 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xa4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings; // 0xb0 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData; // 0x140 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_1d8[0x8]; // 0x1d8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FitChainToSplineCurve) == 0x1e0, "Size mismatch for FRigUnit_FitChainToSplineCurve");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Items) == 0x10, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Items");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Spline) == 0x20, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Spline");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Alignment) == 0x38, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Alignment");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Minimum) == 0x3c, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Minimum");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Maximum) == 0x40, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Maximum");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, SamplingPrecision) == 0x44, "Offset mismatch for FRigUnit_FitChainToSplineCurve::SamplingPrecision");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, PrimaryAxis) == 0x48, "Offset mismatch for FRigUnit_FitChainToSplineCurve::PrimaryAxis");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, SecondaryAxis) == 0x60, "Offset mismatch for FRigUnit_FitChainToSplineCurve::SecondaryAxis");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, PoleVectorPosition) == 0x78, "Offset mismatch for FRigUnit_FitChainToSplineCurve::PoleVectorPosition");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Rotations) == 0x90, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Rotations");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, RotationEaseType) == 0xa0, "Offset mismatch for FRigUnit_FitChainToSplineCurve::RotationEaseType");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, Weight) == 0xa4, "Offset mismatch for FRigUnit_FitChainToSplineCurve::Weight");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, bPropagateToChildren) == 0xa8, "Offset mismatch for FRigUnit_FitChainToSplineCurve::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, DebugSettings) == 0xb0, "Offset mismatch for FRigUnit_FitChainToSplineCurve::DebugSettings");
static_assert(offsetof(FRigUnit_FitChainToSplineCurve, WorkData) == 0x140, "Offset mismatch for FRigUnit_FitChainToSplineCurve::WorkData");

// Size: 0x1e0 (Inherited: 0x30, Single: 0x1b0)
struct FRigUnit_FitChainToSplineCurveItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Alignment; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x40 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision; // 0x44 (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x60 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition; // 0x78 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0xa0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a1[0x3]; // 0xa1 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xa4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings; // 0xb0 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData; // 0x140 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_1d8[0x8]; // 0x1d8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FitChainToSplineCurveItemArray) == 0x1e0, "Size mismatch for FRigUnit_FitChainToSplineCurveItemArray");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Items");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Spline) == 0x20, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Spline");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Alignment) == 0x38, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Alignment");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Minimum) == 0x3c, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Minimum");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Maximum) == 0x40, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Maximum");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, SamplingPrecision) == 0x44, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::SamplingPrecision");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, PrimaryAxis) == 0x48, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::PrimaryAxis");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, SecondaryAxis) == 0x60, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::SecondaryAxis");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, PoleVectorPosition) == 0x78, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::PoleVectorPosition");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Rotations) == 0x90, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Rotations");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, RotationEaseType) == 0xa0, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::RotationEaseType");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, Weight) == 0xa4, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::Weight");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, bPropagateToChildren) == 0xa8, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, DebugSettings) == 0xb0, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::DebugSettings");
static_assert(offsetof(FRigUnit_FitChainToSplineCurveItemArray, WorkData) == 0x140, "Offset mismatch for FRigUnit_FitChainToSplineCurveItemArray::WorkData");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigUnit_SplineConstraint_WorkData
{
    float ChainLength; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FTransform> ItemTransforms; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemSegments; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SplineConstraint_WorkData) == 0x38, "Size mismatch for FRigUnit_SplineConstraint_WorkData");
static_assert(offsetof(FRigUnit_SplineConstraint_WorkData, ChainLength) == 0x0, "Offset mismatch for FRigUnit_SplineConstraint_WorkData::ChainLength");
static_assert(offsetof(FRigUnit_SplineConstraint_WorkData, ItemTransforms) == 0x8, "Offset mismatch for FRigUnit_SplineConstraint_WorkData::ItemTransforms");
static_assert(offsetof(FRigUnit_SplineConstraint_WorkData, ItemSegments) == 0x18, "Offset mismatch for FRigUnit_SplineConstraint_WorkData::ItemSegments");
static_assert(offsetof(FRigUnit_SplineConstraint_WorkData, CachedItems) == 0x28, "Offset mismatch for FRigUnit_SplineConstraint_WorkData::CachedItems");

// Size: 0xb8 (Inherited: 0x30, Single: 0x88)
struct FRigUnit_SplineConstraint : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Alignment; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FVector PrimaryAxis; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x60 (Size: 0x18, Type: StructProperty)
    bool bPropagateToChildren; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_SplineConstraint_WorkData WorkData; // 0x80 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SplineConstraint) == 0xb8, "Size mismatch for FRigUnit_SplineConstraint");
static_assert(offsetof(FRigUnit_SplineConstraint, Items) == 0x10, "Offset mismatch for FRigUnit_SplineConstraint::Items");
static_assert(offsetof(FRigUnit_SplineConstraint, Spline) == 0x20, "Offset mismatch for FRigUnit_SplineConstraint::Spline");
static_assert(offsetof(FRigUnit_SplineConstraint, Alignment) == 0x38, "Offset mismatch for FRigUnit_SplineConstraint::Alignment");
static_assert(offsetof(FRigUnit_SplineConstraint, Minimum) == 0x3c, "Offset mismatch for FRigUnit_SplineConstraint::Minimum");
static_assert(offsetof(FRigUnit_SplineConstraint, Maximum) == 0x40, "Offset mismatch for FRigUnit_SplineConstraint::Maximum");
static_assert(offsetof(FRigUnit_SplineConstraint, PrimaryAxis) == 0x48, "Offset mismatch for FRigUnit_SplineConstraint::PrimaryAxis");
static_assert(offsetof(FRigUnit_SplineConstraint, SecondaryAxis) == 0x60, "Offset mismatch for FRigUnit_SplineConstraint::SecondaryAxis");
static_assert(offsetof(FRigUnit_SplineConstraint, bPropagateToChildren) == 0x78, "Offset mismatch for FRigUnit_SplineConstraint::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SplineConstraint, WorkData) == 0x80, "Offset mismatch for FRigUnit_SplineConstraint::WorkData");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_FitSplineCurveToChain : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_FitSplineCurveToChain) == 0x38, "Size mismatch for FRigUnit_FitSplineCurveToChain");
static_assert(offsetof(FRigUnit_FitSplineCurveToChain, Items) == 0x10, "Offset mismatch for FRigUnit_FitSplineCurveToChain::Items");
static_assert(offsetof(FRigUnit_FitSplineCurveToChain, Spline) == 0x20, "Offset mismatch for FRigUnit_FitSplineCurveToChain::Spline");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_FitSplineCurveToChainItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FControlRigSpline Spline; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_FitSplineCurveToChainItemArray) == 0x38, "Size mismatch for FRigUnit_FitSplineCurveToChainItemArray");
static_assert(offsetof(FRigUnit_FitSplineCurveToChainItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_FitSplineCurveToChainItemArray::Items");
static_assert(offsetof(FRigUnit_FitSplineCurveToChainItemArray, Spline) == 0x20, "Offset mismatch for FRigUnit_FitSplineCurveToChainItemArray::Spline");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigUnit_ClosestParameterFromControlRigSpline : FRigUnit_ControlRigSplineBase
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Position; // 0x20 (Size: 0x18, Type: StructProperty)
    float U; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ClosestParameterFromControlRigSpline) == 0x40, "Size mismatch for FRigUnit_ClosestParameterFromControlRigSpline");
static_assert(offsetof(FRigUnit_ClosestParameterFromControlRigSpline, Spline) == 0x8, "Offset mismatch for FRigUnit_ClosestParameterFromControlRigSpline::Spline");
static_assert(offsetof(FRigUnit_ClosestParameterFromControlRigSpline, Position) == 0x20, "Offset mismatch for FRigUnit_ClosestParameterFromControlRigSpline::Position");
static_assert(offsetof(FRigUnit_ClosestParameterFromControlRigSpline, U) == 0x38, "Offset mismatch for FRigUnit_ClosestParameterFromControlRigSpline::U");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_ParameterAtPercentage : FRigUnit_ControlRigSplineBase
{
    FControlRigSpline Spline; // 0x8 (Size: 0x18, Type: StructProperty)
    float Percentage; // 0x20 (Size: 0x4, Type: FloatProperty)
    float U; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_ParameterAtPercentage) == 0x28, "Size mismatch for FRigUnit_ParameterAtPercentage");
static_assert(offsetof(FRigUnit_ParameterAtPercentage, Spline) == 0x8, "Offset mismatch for FRigUnit_ParameterAtPercentage::Spline");
static_assert(offsetof(FRigUnit_ParameterAtPercentage, Percentage) == 0x20, "Offset mismatch for FRigUnit_ParameterAtPercentage::Percentage");
static_assert(offsetof(FRigUnit_ParameterAtPercentage, U) == 0x24, "Offset mismatch for FRigUnit_ParameterAtPercentage::U");

