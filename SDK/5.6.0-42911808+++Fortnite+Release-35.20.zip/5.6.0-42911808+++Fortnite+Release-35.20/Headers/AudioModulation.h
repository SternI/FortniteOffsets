/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioModulation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "AudioExtensions.h"
#include "WaveTable.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioModulationStyle : public UBlueprintFunctionLibrary
{
public:

public:
    static FColor GetControlBusColor(); // 0xc3d2b5c (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FColor GetControlBusMixColor(); // 0xc3d2b7c (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FColor GetModulationGeneratorColor(); // 0xc3d2b9c (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FColor GetParameterColor(); // 0xc3d2d78 (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FColor GetPatchColor(); // 0xc3d2d98 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAudioModulationStyle) == 0x28, "Size mismatch for UAudioModulationStyle");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UAudioModulationDestination : public UObject
{
public:
    USoundModulatorBase* Modulator; // 0x28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_30[0x10]; // 0x30 (Size: 0x10, Type: PaddingProperty)

public:
    bool ClearModulator(); // 0xc3d0bec (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    USoundModulatorBase* GetModulator() const; // 0xc3d2bbc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetValue() const; // 0xc3d2db8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool SetModulator(USoundModulatorBase*& const InModulator); // 0xc3d3750 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioModulationDestination) == 0x40, "Size mismatch for UAudioModulationDestination");
static_assert(offsetof(UAudioModulationDestination, Modulator) == 0x28, "Offset mismatch for UAudioModulationDestination::Modulator");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UAudioModulationSettings : public UDeveloperSettings
{
public:
    TArray<FSoftObjectPath> Parameters; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAudioModulationSettings) == 0x40, "Size mismatch for UAudioModulationSettings");
static_assert(offsetof(UAudioModulationSettings, Parameters) == 0x30, "Offset mismatch for UAudioModulationSettings::Parameters");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioModulationStatics : public UBlueprintFunctionLibrary
{
public:

public:
    static void ActivateBus(UObject*& const WorldContextObject, USoundControlBus*& Bus); // 0xc3d02bc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ActivateBusMix(UObject*& const WorldContextObject, USoundControlBusMix*& Mix); // 0x37d3f1c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ActivateGenerator(UObject*& const WorldContextObject, USoundModulationGenerator*& Generator); // 0xc3d04d4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ClearAllGlobalBusMixValues(UObject*& const WorldContextObject, float& FadeTime); // 0xc3d0700 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ClearGlobalBusMixValue(UObject*& const WorldContextObject, USoundControlBus*& Bus, float& FadeTime); // 0xc3d08f8 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static USoundModulationGeneratorADEnvelope* CreateADEnvelopeGenerator(UObject*& WorldContextObject, FName& Name, const FSoundModulationADEnvelopeParams Params); // 0xc3d0c10 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static USoundControlBus* CreateBus(UObject*& WorldContextObject, FName& Name, USoundModulationParameter*& Parameter, bool& Activate); // 0xc3d0eb0 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static USoundControlBusMix* CreateBusMix(UObject*& WorldContextObject, FName& Name, TArray<FSoundControlBusMixStage>& Stages, bool& Activate); // 0x5985df4 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static USoundControlBusMix* CreateBusMixFromValue(UObject*& const WorldContextObject, FName& Name, const TArray<USoundControlBus*> Buses, float& Value, float& AttackTime, float& ReleaseTime, bool& bActivate); // 0xc3d1264 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSoundControlBusMixStage CreateBusMixStage(UObject*& const WorldContextObject, USoundControlBus*& Bus, float& Value, float& AttackTime, float& ReleaseTime); // 0x5436a40 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static USoundModulationGeneratorEnvelopeFollower* CreateEnvelopeFollowerGenerator(UObject*& WorldContextObject, FName& Name, FEnvelopeFollowerGeneratorParams& Params); // 0xc3d17c0 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static USoundModulationGeneratorLFO* CreateLFOGenerator(UObject*& WorldContextObject, FName& Name, FSoundModulationLFOParams& Params); // 0xc3d1a6c (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAudioModulationDestination* CreateModulationDestination(UObject*& WorldContextObject, FName& Name, USoundModulatorBase*& Modulator); // 0xc3d1d18 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static USoundModulationParameter* CreateModulationParameter(UObject*& WorldContextObject, FName& Name, UClass*& ParamClass, float& DefaultValue); // 0xc3d2038 (Index: 0xd, Flags: Final|Native|Static|Public)
    static void DeactivateAllBusMixes(UObject*& const WorldContextObject); // 0xc3d259c (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void DeactivateBus(UObject*& const WorldContextObject, USoundControlBus*& Bus); // 0xc3d26f0 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void DeactivateBusMix(UObject*& const WorldContextObject, USoundControlBusMix*& Mix); // 0x42b39dc (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void DeactivateGenerator(UObject*& const WorldContextObject, USoundModulationGenerator*& Generator); // 0xc3d2908 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable)
    static TSet<USoundModulatorBase*> GetModulatorsFromDestination(const FSoundModulationDestinationSettings Destination); // 0xc3d2bd4 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetModulatorValue(UObject*& const WorldContextObject, USoundModulatorBase*& Modulator); // 0x42b4874 (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsControlBusMixActive(UObject*& const WorldContextObject, USoundControlBusMix*& Mix); // 0x5e677e8 (Index: 0x14, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FSoundControlBusMixStage> LoadMixFromProfile(UObject*& const WorldContextObject, USoundControlBusMix*& Mix, bool& bActivate, int32_t& ProfileIndex); // 0xc3d2de0 (Index: 0x15, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SaveMixToProfile(UObject*& const WorldContextObject, USoundControlBusMix*& Mix, int32_t& ProfileIndex); // 0xc3d3460 (Index: 0x16, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetGlobalBusMixValue(UObject*& const WorldContextObject, USoundControlBus*& Bus, float& Value, float& FadeTime); // 0x3dadfd8 (Index: 0x17, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void UpdateMix(UObject*& const WorldContextObject, USoundControlBusMix*& Mix, TArray<FSoundControlBusMixStage>& Stages, float& FadeTime); // 0xc3d38c4 (Index: 0x18, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void UpdateMixByFilter(UObject*& const WorldContextObject, USoundControlBusMix*& Mix, FString& AddressFilter, UClass*& ParamClassFilter, USoundModulationParameter*& ParamFilter, float& Value, float& FadeTime); // 0xc3d3ef8 (Index: 0x19, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void UpdateMixFromObject(UObject*& const WorldContextObject, USoundControlBusMix*& Mix, float& FadeTime); // 0xc3d4788 (Index: 0x1a, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void UpdateModulator(UObject*& const WorldContextObject, USoundModulatorBase*& Modulator); // 0xc3d4a7c (Index: 0x1b, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioModulationStatics) == 0x28, "Size mismatch for UAudioModulationStatics");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class USoundModulationGeneratorADEnvelope : public USoundModulationGenerator
{
public:
    FSoundModulationADEnvelopeParams Params; // 0x30 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(USoundModulationGeneratorADEnvelope) == 0x48, "Size mismatch for USoundModulationGeneratorADEnvelope");
static_assert(offsetof(USoundModulationGeneratorADEnvelope, Params) == 0x30, "Offset mismatch for USoundModulationGeneratorADEnvelope::Params");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class USoundModulationGenerator : public USoundModulatorBase
{
public:
};

static_assert(sizeof(USoundModulationGenerator) == 0x30, "Size mismatch for USoundModulationGenerator");

// Size: 0x50 (Inherited: 0x88, Single: 0xffffffc8)
class USoundModulationGeneratorEnvelopeFollower : public USoundModulationGenerator
{
public:
    FEnvelopeFollowerGeneratorParams Params; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(USoundModulationGeneratorEnvelopeFollower) == 0x50, "Size mismatch for USoundModulationGeneratorEnvelopeFollower");
static_assert(offsetof(USoundModulationGeneratorEnvelopeFollower, Params) == 0x30, "Offset mismatch for USoundModulationGeneratorEnvelopeFollower::Params");

// Size: 0x50 (Inherited: 0x88, Single: 0xffffffc8)
class USoundModulationGeneratorLFO : public USoundModulationGenerator
{
public:
    FSoundModulationLFOParams Params; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(USoundModulationGeneratorLFO) == 0x50, "Size mismatch for USoundModulationGeneratorLFO");
static_assert(offsetof(USoundModulationGeneratorLFO, Params) == 0x30, "Offset mismatch for USoundModulationGeneratorLFO::Params");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class USoundControlBus : public USoundModulatorBase
{
public:
    bool bBypass; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FString address; // 0x38 (Size: 0x10, Type: StrProperty)
    TArray<USoundModulationGenerator*> Generators; // 0x48 (Size: 0x10, Type: ArrayProperty)
    USoundModulationParameter* Parameter; // 0x58 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(USoundControlBus) == 0x60, "Size mismatch for USoundControlBus");
static_assert(offsetof(USoundControlBus, bBypass) == 0x30, "Offset mismatch for USoundControlBus::bBypass");
static_assert(offsetof(USoundControlBus, address) == 0x38, "Offset mismatch for USoundControlBus::address");
static_assert(offsetof(USoundControlBus, Generators) == 0x48, "Offset mismatch for USoundControlBus::Generators");
static_assert(offsetof(USoundControlBus, Parameter) == 0x58, "Offset mismatch for USoundControlBus::Parameter");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class USoundControlBusMix : public UObject
{
public:
    uint32_t ProfileIndex; // 0x28 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<FSoundControlBusMixStage> MixStages; // 0x30 (Size: 0x10, Type: ArrayProperty)

protected:
    void ActivateMix(); // 0xc3d06ec (Index: 0x0, Flags: Final|Native|Protected)
    void DeactivateAllMixes(); // 0xc3d26b4 (Index: 0x1, Flags: Final|Native|Protected)
    void DeactivateMix(); // 0xc3d2b20 (Index: 0x2, Flags: Final|Native|Protected)
    void LoadMixFromProfile(); // 0xc3d342c (Index: 0x3, Flags: Final|Native|Protected)
    void SaveMixToProfile(); // 0xc3d3738 (Index: 0x4, Flags: Final|Native|Protected)
    void SoloMix(); // 0xc3d3888 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(USoundControlBusMix) == 0x40, "Size mismatch for USoundControlBusMix");
static_assert(offsetof(USoundControlBusMix, ProfileIndex) == 0x28, "Offset mismatch for USoundControlBusMix::ProfileIndex");
static_assert(offsetof(USoundControlBusMix, MixStages) == 0x30, "Offset mismatch for USoundControlBusMix::MixStages");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class USoundModulationParameter : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FSoundModulationParameterSettings Settings; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(USoundModulationParameter) == 0x38, "Size mismatch for USoundModulationParameter");
static_assert(offsetof(USoundModulationParameter, Settings) == 0x30, "Offset mismatch for USoundModulationParameter::Settings");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class USoundModulationParameterScaled : public USoundModulationParameter
{
public:
    float UnitMin; // 0x38 (Size: 0x4, Type: FloatProperty)
    float UnitMax; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(USoundModulationParameterScaled) == 0x40, "Size mismatch for USoundModulationParameterScaled");
static_assert(offsetof(USoundModulationParameterScaled, UnitMin) == 0x38, "Offset mismatch for USoundModulationParameterScaled::UnitMin");
static_assert(offsetof(USoundModulationParameterScaled, UnitMax) == 0x3c, "Offset mismatch for USoundModulationParameterScaled::UnitMax");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class USoundModulationParameterFrequencyBase : public USoundModulationParameter
{
public:
};

static_assert(sizeof(USoundModulationParameterFrequencyBase) == 0x38, "Size mismatch for USoundModulationParameterFrequencyBase");

// Size: 0x40 (Inherited: 0x98, Single: 0xffffffa8)
class USoundModulationParameterFrequency : public USoundModulationParameterFrequencyBase
{
public:
    float UnitMin; // 0x38 (Size: 0x4, Type: FloatProperty)
    float UnitMax; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(USoundModulationParameterFrequency) == 0x40, "Size mismatch for USoundModulationParameterFrequency");
static_assert(offsetof(USoundModulationParameterFrequency, UnitMin) == 0x38, "Offset mismatch for USoundModulationParameterFrequency::UnitMin");
static_assert(offsetof(USoundModulationParameterFrequency, UnitMax) == 0x3c, "Offset mismatch for USoundModulationParameterFrequency::UnitMax");

// Size: 0x38 (Inherited: 0x98, Single: 0xffffffa0)
class USoundModulationParameterFilterFrequency : public USoundModulationParameterFrequencyBase
{
public:
};

static_assert(sizeof(USoundModulationParameterFilterFrequency) == 0x38, "Size mismatch for USoundModulationParameterFilterFrequency");

// Size: 0x38 (Inherited: 0xd0, Single: 0xffffff68)
class USoundModulationParameterLPFFrequency : public USoundModulationParameterFilterFrequency
{
public:
};

static_assert(sizeof(USoundModulationParameterLPFFrequency) == 0x38, "Size mismatch for USoundModulationParameterLPFFrequency");

// Size: 0x38 (Inherited: 0xd0, Single: 0xffffff68)
class USoundModulationParameterHPFFrequency : public USoundModulationParameterFilterFrequency
{
public:
};

static_assert(sizeof(USoundModulationParameterHPFFrequency) == 0x38, "Size mismatch for USoundModulationParameterHPFFrequency");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class USoundModulationParameterBipolar : public USoundModulationParameter
{
public:
    float UnitRange; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(USoundModulationParameterBipolar) == 0x40, "Size mismatch for USoundModulationParameterBipolar");
static_assert(offsetof(USoundModulationParameterBipolar, UnitRange) == 0x38, "Offset mismatch for USoundModulationParameterBipolar::UnitRange");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class USoundModulationParameterVolume : public USoundModulationParameter
{
public:
    float MinVolume; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(USoundModulationParameterVolume) == 0x40, "Size mismatch for USoundModulationParameterVolume");
static_assert(offsetof(USoundModulationParameterVolume, MinVolume) == 0x38, "Offset mismatch for USoundModulationParameterVolume::MinVolume");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class USoundModulationParameterAdditive : public USoundModulationParameter
{
public:
    float UnitMin; // 0x38 (Size: 0x4, Type: FloatProperty)
    float UnitMax; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(USoundModulationParameterAdditive) == 0x40, "Size mismatch for USoundModulationParameterAdditive");
static_assert(offsetof(USoundModulationParameterAdditive, UnitMin) == 0x38, "Offset mismatch for USoundModulationParameterAdditive::UnitMin");
static_assert(offsetof(USoundModulationParameterAdditive, UnitMax) == 0x3c, "Offset mismatch for USoundModulationParameterAdditive::UnitMax");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class USoundModulationPatch : public USoundModulatorBase
{
public:
    FSoundControlModulationPatch PatchSettings; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(USoundModulationPatch) == 0x50, "Size mismatch for USoundModulationPatch");
static_assert(offsetof(USoundModulationPatch, PatchSettings) == 0x30, "Offset mismatch for USoundModulationPatch::PatchSettings");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FSoundModulationADEnvelopeParams
{
    float AttackTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float DecayTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float AttackCurve; // 0x8 (Size: 0x4, Type: FloatProperty)
    float DecayCurve; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bLooping; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bBypass; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x2]; // 0x12 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FSoundModulationADEnvelopeParams) == 0x14, "Size mismatch for FSoundModulationADEnvelopeParams");
static_assert(offsetof(FSoundModulationADEnvelopeParams, AttackTime) == 0x0, "Offset mismatch for FSoundModulationADEnvelopeParams::AttackTime");
static_assert(offsetof(FSoundModulationADEnvelopeParams, DecayTime) == 0x4, "Offset mismatch for FSoundModulationADEnvelopeParams::DecayTime");
static_assert(offsetof(FSoundModulationADEnvelopeParams, AttackCurve) == 0x8, "Offset mismatch for FSoundModulationADEnvelopeParams::AttackCurve");
static_assert(offsetof(FSoundModulationADEnvelopeParams, DecayCurve) == 0xc, "Offset mismatch for FSoundModulationADEnvelopeParams::DecayCurve");
static_assert(offsetof(FSoundModulationADEnvelopeParams, bLooping) == 0x10, "Offset mismatch for FSoundModulationADEnvelopeParams::bLooping");
static_assert(offsetof(FSoundModulationADEnvelopeParams, bBypass) == 0x11, "Offset mismatch for FSoundModulationADEnvelopeParams::bBypass");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FEnvelopeFollowerGeneratorParams
{
    bool bBypass; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bInvert; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    UAudioBus* AudioBus; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float Gain; // 0x10 (Size: 0x4, Type: FloatProperty)
    float AttackTime; // 0x14 (Size: 0x4, Type: FloatProperty)
    float ReleaseTime; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEnvelopeFollowerGeneratorParams) == 0x20, "Size mismatch for FEnvelopeFollowerGeneratorParams");
static_assert(offsetof(FEnvelopeFollowerGeneratorParams, bBypass) == 0x0, "Offset mismatch for FEnvelopeFollowerGeneratorParams::bBypass");
static_assert(offsetof(FEnvelopeFollowerGeneratorParams, bInvert) == 0x1, "Offset mismatch for FEnvelopeFollowerGeneratorParams::bInvert");
static_assert(offsetof(FEnvelopeFollowerGeneratorParams, AudioBus) == 0x8, "Offset mismatch for FEnvelopeFollowerGeneratorParams::AudioBus");
static_assert(offsetof(FEnvelopeFollowerGeneratorParams, Gain) == 0x10, "Offset mismatch for FEnvelopeFollowerGeneratorParams::Gain");
static_assert(offsetof(FEnvelopeFollowerGeneratorParams, AttackTime) == 0x14, "Offset mismatch for FEnvelopeFollowerGeneratorParams::AttackTime");
static_assert(offsetof(FEnvelopeFollowerGeneratorParams, ReleaseTime) == 0x18, "Offset mismatch for FEnvelopeFollowerGeneratorParams::ReleaseTime");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSoundModulationLFOParams
{
    uint8_t Shape; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ExponentialFactor; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Width; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Amplitude; // 0xc (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Offset; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Phase; // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bLooping; // 0x1c (Size: 0x1, Type: BoolProperty)
    bool bBypass; // 0x1d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e[0x2]; // 0x1e (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FSoundModulationLFOParams) == 0x20, "Size mismatch for FSoundModulationLFOParams");
static_assert(offsetof(FSoundModulationLFOParams, Shape) == 0x0, "Offset mismatch for FSoundModulationLFOParams::Shape");
static_assert(offsetof(FSoundModulationLFOParams, ExponentialFactor) == 0x4, "Offset mismatch for FSoundModulationLFOParams::ExponentialFactor");
static_assert(offsetof(FSoundModulationLFOParams, Width) == 0x8, "Offset mismatch for FSoundModulationLFOParams::Width");
static_assert(offsetof(FSoundModulationLFOParams, Amplitude) == 0xc, "Offset mismatch for FSoundModulationLFOParams::Amplitude");
static_assert(offsetof(FSoundModulationLFOParams, Frequency) == 0x10, "Offset mismatch for FSoundModulationLFOParams::Frequency");
static_assert(offsetof(FSoundModulationLFOParams, Offset) == 0x14, "Offset mismatch for FSoundModulationLFOParams::Offset");
static_assert(offsetof(FSoundModulationLFOParams, Phase) == 0x18, "Offset mismatch for FSoundModulationLFOParams::Phase");
static_assert(offsetof(FSoundModulationLFOParams, bLooping) == 0x1c, "Offset mismatch for FSoundModulationLFOParams::bLooping");
static_assert(offsetof(FSoundModulationLFOParams, bBypass) == 0x1d, "Offset mismatch for FSoundModulationLFOParams::bBypass");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FSoundControlBusMixStage
{
    USoundControlBus* Bus; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FSoundModulationMixValue Value; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FSoundControlBusMixStage) == 0x28, "Size mismatch for FSoundControlBusMixStage");
static_assert(offsetof(FSoundControlBusMixStage, Bus) == 0x0, "Offset mismatch for FSoundControlBusMixStage::Bus");
static_assert(offsetof(FSoundControlBusMixStage, Value) == 0x8, "Offset mismatch for FSoundControlBusMixStage::Value");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSoundModulationMixValue
{
    float TargetValue; // 0x0 (Size: 0x4, Type: FloatProperty)
    float AttackTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ReleaseTime; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x14]; // 0xc (Size: 0x14, Type: PaddingProperty)
};

static_assert(sizeof(FSoundModulationMixValue) == 0x20, "Size mismatch for FSoundModulationMixValue");
static_assert(offsetof(FSoundModulationMixValue, TargetValue) == 0x0, "Offset mismatch for FSoundModulationMixValue::TargetValue");
static_assert(offsetof(FSoundModulationMixValue, AttackTime) == 0x4, "Offset mismatch for FSoundModulationMixValue::AttackTime");
static_assert(offsetof(FSoundModulationMixValue, ReleaseTime) == 0x8, "Offset mismatch for FSoundModulationMixValue::ReleaseTime");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FSoundModulationParameterSettings
{
    float ValueNormalized; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSoundModulationParameterSettings) == 0x4, "Size mismatch for FSoundModulationParameterSettings");
static_assert(offsetof(FSoundModulationParameterSettings, ValueNormalized) == 0x0, "Offset mismatch for FSoundModulationParameterSettings::ValueNormalized");

// Size: 0xb8 (Inherited: 0xb8, Single: 0x0)
struct FSoundModulationTransform : FWaveTableTransform
{
};

static_assert(sizeof(FSoundModulationTransform) == 0xb8, "Size mismatch for FSoundModulationTransform");

// Size: 0xc8 (Inherited: 0x0, Single: 0xc8)
struct FSoundControlModulationInput
{
    uint8_t bSampleAndHold : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FSoundModulationTransform Transform; // 0x8 (Size: 0xb8, Type: StructProperty)
    USoundControlBus* Bus; // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FSoundControlModulationInput) == 0xc8, "Size mismatch for FSoundControlModulationInput");
static_assert(offsetof(FSoundControlModulationInput, bSampleAndHold) == 0x0, "Offset mismatch for FSoundControlModulationInput::bSampleAndHold");
static_assert(offsetof(FSoundControlModulationInput, Transform) == 0x8, "Offset mismatch for FSoundControlModulationInput::Transform");
static_assert(offsetof(FSoundControlModulationInput, Bus) == 0xc0, "Offset mismatch for FSoundControlModulationInput::Bus");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSoundControlModulationPatch
{
    bool bBypass; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    USoundModulationParameter* OutputParameter; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<FSoundControlModulationInput> Inputs; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSoundControlModulationPatch) == 0x20, "Size mismatch for FSoundControlModulationPatch");
static_assert(offsetof(FSoundControlModulationPatch, bBypass) == 0x0, "Offset mismatch for FSoundControlModulationPatch::bBypass");
static_assert(offsetof(FSoundControlModulationPatch, OutputParameter) == 0x8, "Offset mismatch for FSoundControlModulationPatch::OutputParameter");
static_assert(offsetof(FSoundControlModulationPatch, Inputs) == 0x10, "Offset mismatch for FSoundControlModulationPatch::Inputs");

