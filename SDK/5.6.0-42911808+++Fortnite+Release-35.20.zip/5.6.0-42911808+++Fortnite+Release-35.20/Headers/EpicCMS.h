/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicCMS
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDownloadCacheEntry
{
    FString FilePath; // 0x0 (Size: 0x10, Type: StrProperty)
    FString SourceUrl; // 0x10 (Size: 0x10, Type: StrProperty)
    FDateTime LastAccessTime; // 0x20 (Size: 0x8, Type: StructProperty)
    int32_t LifetimeInDays; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDownloadCacheEntry) == 0x30, "Size mismatch for FDownloadCacheEntry");
static_assert(offsetof(FDownloadCacheEntry, FilePath) == 0x0, "Offset mismatch for FDownloadCacheEntry::FilePath");
static_assert(offsetof(FDownloadCacheEntry, SourceUrl) == 0x10, "Offset mismatch for FDownloadCacheEntry::SourceUrl");
static_assert(offsetof(FDownloadCacheEntry, LastAccessTime) == 0x20, "Offset mismatch for FDownloadCacheEntry::LastAccessTime");
static_assert(offsetof(FDownloadCacheEntry, LifetimeInDays) == 0x28, "Offset mismatch for FDownloadCacheEntry::LifetimeInDays");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FDownloadCache
{
    int32_t Version; // 0x4 (Size: 0x4, Type: IntProperty)
    TMap<FDownloadCacheEntry, FString> Cache; // 0x8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FDownloadCache) == 0x58, "Size mismatch for FDownloadCache");
static_assert(offsetof(FDownloadCache, Version) == 0x4, "Offset mismatch for FDownloadCache::Version");
static_assert(offsetof(FDownloadCache, Cache) == 0x8, "Offset mismatch for FDownloadCache::Cache");

