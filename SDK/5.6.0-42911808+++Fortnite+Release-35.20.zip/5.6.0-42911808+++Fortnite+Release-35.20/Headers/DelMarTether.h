/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarTether
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DelMarCore.h"
#include "TowHookWeaponRuntime.h"
#include "FortniteGame.h"

// Size: 0xf0 (Inherited: 0x3c8, Single: 0xfffffd28)
class UDelMarPlayerTetherComponent : public UDelMarPlayerAttachmentComponent
{
public:
    TArray<UFortWeaponItemDefinition*> WeaponsToGive; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    bool bInfiniteAmmo; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x3]; // 0xd1 (Size: 0x3, Type: PaddingProperty)
    float SecondsBetweenRequests; // 0xd4 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> AttachedVehicle; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortPawnComponent_TetheredMovement*> TetheredMovementComp; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_e8[0x8]; // 0xe8 (Size: 0x8, Type: PaddingProperty)

protected:
    void HandleVehicleAppliedTeleportLocation(); // 0x1217a570 (Index: 0x0, Flags: Final|Native|Protected)
    void OnRep_AttachedVehicle(); // 0x1217a584 (Index: 0x1, Flags: Final|Native|Protected)
    void OnRep_TetheredMovementComp(); // 0x1217a584 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerTetherComponent) == 0xf0, "Size mismatch for UDelMarPlayerTetherComponent");
static_assert(offsetof(UDelMarPlayerTetherComponent, WeaponsToGive) == 0xc0, "Offset mismatch for UDelMarPlayerTetherComponent::WeaponsToGive");
static_assert(offsetof(UDelMarPlayerTetherComponent, bInfiniteAmmo) == 0xd0, "Offset mismatch for UDelMarPlayerTetherComponent::bInfiniteAmmo");
static_assert(offsetof(UDelMarPlayerTetherComponent, SecondsBetweenRequests) == 0xd4, "Offset mismatch for UDelMarPlayerTetherComponent::SecondsBetweenRequests");
static_assert(offsetof(UDelMarPlayerTetherComponent, AttachedVehicle) == 0xd8, "Offset mismatch for UDelMarPlayerTetherComponent::AttachedVehicle");
static_assert(offsetof(UDelMarPlayerTetherComponent, TetheredMovementComp) == 0xe0, "Offset mismatch for UDelMarPlayerTetherComponent::TetheredMovementComp");

