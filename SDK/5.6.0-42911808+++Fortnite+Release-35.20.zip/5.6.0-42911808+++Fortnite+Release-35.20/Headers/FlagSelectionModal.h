/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FlagSelectionModal
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "CareerUI.h"
#include "Engine.h"
#include "UIKit.h"
#include "Systems.h"

// Size: 0x488 (Inherited: 0xb38, Single: 0xfffff950)
class UWBP_FlagSelection_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Dialog_Base_C* WBP_UIKit_Dialog_Base; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* VisibilitySwitcher; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonTileView* TileView; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UImage* Throbber; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* SelectedFlag; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UWBP_Flag_C* PreviousFlag; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UFortFlagImage* Image_YourFlag; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UWBP_Flag_C* FutureFlag; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CurrentInfo; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ConfirmationText; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ChangeWarning; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UImage* Arrow; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UFortCareerChangeFlagModalVM* FortCareerChangeFlagModalVM; // 0x470 (Size: 0x8, Type: ObjectProperty)
    FName FutureSelectedFlag; // 0x478 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_47c[0x4]; // 0x47c (Size: 0x4, Type: PaddingProperty)
    UFortCareerChangeFlagModalItemVM* PickedFlag; // 0x480 (Size: 0x8, Type: ObjectProperty)

public:
    void FindItemByRegionId(FString& InRegionID, UFortCareerChangeFlagModalItemVM*& FlagData, int32_t& FlagListIndex); // 0x288a61c (Index: 0x5, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnFlagChanged(const FFortCompetitiveIdentityInfo NewFlagRegionInfo); // 0x288a61c (Index: 0x6, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void OnConfirmClicked(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnInputMethodChanged(ECommonInputType& bNewInputType); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetPermissionToChangeTheFlag(bool& Alowed); // 0x288a61c (Index: 0xa, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnPermissionChanged(bool& InNewPermission); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SelectTileListItemByRegionId(FString& InRegionID); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0xd, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnRegionIdChanged(FString& InRegionID); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFlagAsset(TSoftObjectPtr<UTexture2D*>& NewParam); // 0x288a61c (Index: 0xf, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetFortCareerChangeFlagModalVM(UFortCareerChangeFlagModalVM*& ViewModel); // 0x288a61c (Index: 0x10, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetNoteSection(); // 0x288a61c (Index: 0x11, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSelectedItem(UFortCareerChangeFlagModalItemVM*& NewParam); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_FlagSelection_C) == 0x488, "Size mismatch for UWBP_FlagSelection_C");
static_assert(offsetof(UWBP_FlagSelection_C, UberGraphFrame) == 0x408, "Offset mismatch for UWBP_FlagSelection_C::UberGraphFrame");
static_assert(offsetof(UWBP_FlagSelection_C, WBP_UIKit_Dialog_Base) == 0x410, "Offset mismatch for UWBP_FlagSelection_C::WBP_UIKit_Dialog_Base");
static_assert(offsetof(UWBP_FlagSelection_C, VisibilitySwitcher) == 0x418, "Offset mismatch for UWBP_FlagSelection_C::VisibilitySwitcher");
static_assert(offsetof(UWBP_FlagSelection_C, TileView) == 0x420, "Offset mismatch for UWBP_FlagSelection_C::TileView");
static_assert(offsetof(UWBP_FlagSelection_C, Throbber) == 0x428, "Offset mismatch for UWBP_FlagSelection_C::Throbber");
static_assert(offsetof(UWBP_FlagSelection_C, SelectedFlag) == 0x430, "Offset mismatch for UWBP_FlagSelection_C::SelectedFlag");
static_assert(offsetof(UWBP_FlagSelection_C, PreviousFlag) == 0x438, "Offset mismatch for UWBP_FlagSelection_C::PreviousFlag");
static_assert(offsetof(UWBP_FlagSelection_C, Image_YourFlag) == 0x440, "Offset mismatch for UWBP_FlagSelection_C::Image_YourFlag");
static_assert(offsetof(UWBP_FlagSelection_C, FutureFlag) == 0x448, "Offset mismatch for UWBP_FlagSelection_C::FutureFlag");
static_assert(offsetof(UWBP_FlagSelection_C, CurrentInfo) == 0x450, "Offset mismatch for UWBP_FlagSelection_C::CurrentInfo");
static_assert(offsetof(UWBP_FlagSelection_C, ConfirmationText) == 0x458, "Offset mismatch for UWBP_FlagSelection_C::ConfirmationText");
static_assert(offsetof(UWBP_FlagSelection_C, ChangeWarning) == 0x460, "Offset mismatch for UWBP_FlagSelection_C::ChangeWarning");
static_assert(offsetof(UWBP_FlagSelection_C, Arrow) == 0x468, "Offset mismatch for UWBP_FlagSelection_C::Arrow");
static_assert(offsetof(UWBP_FlagSelection_C, FortCareerChangeFlagModalVM) == 0x470, "Offset mismatch for UWBP_FlagSelection_C::FortCareerChangeFlagModalVM");
static_assert(offsetof(UWBP_FlagSelection_C, FutureSelectedFlag) == 0x478, "Offset mismatch for UWBP_FlagSelection_C::FutureSelectedFlag");
static_assert(offsetof(UWBP_FlagSelection_C, PickedFlag) == 0x480, "Offset mismatch for UWBP_FlagSelection_C::PickedFlag");

// Size: 0x1528 (Inherited: 0x3090, Single: 0xffffe498)
class UWBP_Flag_C : public UUIKitModularButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14c0 (Size: 0x8, Type: StructProperty)
    UImage* SelectionIndicator; // 0x14c8 (Size: 0x8, Type: ObjectProperty)
    UFortFlagImage* Flag; // 0x14d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Block_Outline_C* Block_Outline; // 0x14d8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnSelected; // 0x14e0 (Size: 0x8, Type: ObjectProperty)
    UFortCareerChangeFlagModalItemVM* FortCareerChangeFlagModalItemVM; // 0x14e8 (Size: 0x8, Type: ObjectProperty)
    FUIKitBlockTiming BlocksTiming; // 0x14f0 (Size: 0x2c, Type: StructProperty)
    uint8_t Pad_151c[0x4]; // 0x151c (Size: 0x4, Type: PaddingProperty)
    UMaterialInstanceDynamic* FlagMaterial; // 0x1520 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void SetFortCareerChangeFlagModalItemVM(UFortCareerChangeFlagModalItemVM*& ViewModel); // 0x288a61c (Index: 0x1, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    bool ShouldRequestTransition(); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void SetFlag(TSoftObjectPtr<UTexture2D*>& Value); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSelected(bool& Selected); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Blocks_Is_Selected(bool& Is_Selected); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeselected(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEnabled(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDisabled(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnPressed(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnReleased(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnSelected(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Flag_C) == 0x1528, "Size mismatch for UWBP_Flag_C");
static_assert(offsetof(UWBP_Flag_C, UberGraphFrame) == 0x14c0, "Offset mismatch for UWBP_Flag_C::UberGraphFrame");
static_assert(offsetof(UWBP_Flag_C, SelectionIndicator) == 0x14c8, "Offset mismatch for UWBP_Flag_C::SelectionIndicator");
static_assert(offsetof(UWBP_Flag_C, Flag) == 0x14d0, "Offset mismatch for UWBP_Flag_C::Flag");
static_assert(offsetof(UWBP_Flag_C, Block_Outline) == 0x14d8, "Offset mismatch for UWBP_Flag_C::Block_Outline");
static_assert(offsetof(UWBP_Flag_C, OnSelected) == 0x14e0, "Offset mismatch for UWBP_Flag_C::OnSelected");
static_assert(offsetof(UWBP_Flag_C, FortCareerChangeFlagModalItemVM) == 0x14e8, "Offset mismatch for UWBP_Flag_C::FortCareerChangeFlagModalItemVM");
static_assert(offsetof(UWBP_Flag_C, BlocksTiming) == 0x14f0, "Offset mismatch for UWBP_Flag_C::BlocksTiming");
static_assert(offsetof(UWBP_Flag_C, FlagMaterial) == 0x1520, "Offset mismatch for UWBP_Flag_C::FlagMaterial");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UVM_Dialog_FlagSelectionModal_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UVM_Dialog_FlagSelectionModal_C) == 0xd8, "Size mismatch for UVM_Dialog_FlagSelectionModal_C");

