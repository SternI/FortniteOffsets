/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataRegistries
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0xf8 (Inherited: 0x0, Single: 0xf8)
struct FStatCreatorRegistryRow
{
    FText DisplayName_9_F5EC2D0F4BEE61DAA7FD9CAE57322EC9; // 0x0 (Size: 0x10, Type: TextProperty)
    FStatEventFilter Value_5_0C712CA14D04EE76CE65A4B898BD94D5; // 0x10 (Size: 0x88, Type: StructProperty)
    FCreativeIconOption DisplayIcon_8_36F66E1B428226432A8D488CF9AE1027; // 0x98 (Size: 0x40, Type: StructProperty)
    FGameplayTagContainer ValueFilterTags_12_8A08AD2E4D36355DDEF81AB5CC48ECE4; // 0xd8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FStatCreatorRegistryRow) == 0xf8, "Size mismatch for FStatCreatorRegistryRow");
static_assert(offsetof(FStatCreatorRegistryRow, DisplayName_9_F5EC2D0F4BEE61DAA7FD9CAE57322EC9) == 0x0, "Offset mismatch for FStatCreatorRegistryRow::DisplayName_9_F5EC2D0F4BEE61DAA7FD9CAE57322EC9");
static_assert(offsetof(FStatCreatorRegistryRow, Value_5_0C712CA14D04EE76CE65A4B898BD94D5) == 0x10, "Offset mismatch for FStatCreatorRegistryRow::Value_5_0C712CA14D04EE76CE65A4B898BD94D5");
static_assert(offsetof(FStatCreatorRegistryRow, DisplayIcon_8_36F66E1B428226432A8D488CF9AE1027) == 0x98, "Offset mismatch for FStatCreatorRegistryRow::DisplayIcon_8_36F66E1B428226432A8D488CF9AE1027");
static_assert(offsetof(FStatCreatorRegistryRow, ValueFilterTags_12_8A08AD2E4D36355DDEF81AB5CC48ECE4) == 0xd8, "Offset mismatch for FStatCreatorRegistryRow::ValueFilterTags_12_8A08AD2E4D36355DDEF81AB5CC48ECE4");

