/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Enums.h"
#include "ModularGameplay.h"
#include "SparksCoreUI.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "SparksCMS.h"
#include "FMJamPlayspaceRuntime.h"
#include "Engine.h"

// Size: 0xe0 (Inherited: 0x250, Single: 0xfffffe90)
class UJamControllerComponent_EmotePickerOverrider : public UControllerComponent
{
public:
};

static_assert(sizeof(UJamControllerComponent_EmotePickerOverrider) == 0xe0, "Size mismatch for UJamControllerComponent_EmotePickerOverrider");

// Size: 0x2f0 (Inherited: 0x888, Single: 0xfffffa68)
class AJamDynamicUIDirector : public ASparksDynamicUIDirector
{
public:
};

static_assert(sizeof(AJamDynamicUIDirector) == 0x2f0, "Size mismatch for AJamDynamicUIDirector");

// Size: 0x408 (Inherited: 0xb38, Single: 0xfffff8d0)
class UJamEmoteWheelOverlay : public UCommonActivatableWidget
{
public:
};

static_assert(sizeof(UJamEmoteWheelOverlay) == 0x408, "Size mismatch for UJamEmoteWheelOverlay");

// Size: 0x4c0 (Inherited: 0x1438, Single: 0xfffff088)
class UJamHUDBase : public UFortNullHUD
{
public:
    TSoftClassPtr EmotePickerClass; // 0x4a0 (Size: 0x20, Type: SoftClassProperty)

private:
    void HandlePickerOpenRequest(EFortPickerMode& Mode, int32_t& InitialOption, bool& bIgnoreFirstAccept); // 0x107fe364 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UJamHUDBase) == 0x4c0, "Size mismatch for UJamHUDBase");
static_assert(offsetof(UJamHUDBase, EmotePickerClass) == 0x4a0, "Offset mismatch for UJamHUDBase::EmotePickerClass");

// Size: 0xa0 (Inherited: 0x100, Single: 0xffffffa0)
class UJamMusicSlotManagerVM : public UFortPerUserViewModel
{
public:
    TArray<UJamMusicSlotVM*> MusicSlots; // 0x70 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_80[0x20]; // 0x80 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UJamMusicSlotManagerVM) == 0xa0, "Size mismatch for UJamMusicSlotManagerVM");
static_assert(offsetof(UJamMusicSlotManagerVM, MusicSlots) == 0x70, "Offset mismatch for UJamMusicSlotManagerVM::MusicSlots");

// Size: 0xd8 (Inherited: 0x90, Single: 0x48)
class UJamMusicSlotVM : public UMVVMViewModelBase
{
public:
    FUniqueNetIdRepl OwningPlayerID; // 0x68 (Size: 0x30, Type: StructProperty)
    FText Title; // 0x98 (Size: 0x10, Type: TextProperty)
    FText Artist; // 0xa8 (Size: 0x10, Type: TextProperty)
    uint8_t UserMode; // 0xb8 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayState; // 0xb9 (Size: 0x1, Type: EnumProperty)
    uint8_t ResolveState; // 0xba (Size: 0x1, Type: EnumProperty)
    uint8_t LoopType; // 0xbb (Size: 0x1, Type: EnumProperty)
    uint8_t FocusState; // 0xbc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_bd[0x1b]; // 0xbd (Size: 0x1b, Type: PaddingProperty)

public:
    bool HasValidOwner() const; // 0x107fe648 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void MusicSlotReportedStart(const FJamPlayParams NewPlayParams, bool& bChangedLoop); // 0x107fe670 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
    void MusicSlotReportedStop(const FJamPlayParams OldPlayParams, bool& bChangedLoop); // 0x107fe7f0 (Index: 0x2, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UJamMusicSlotVM) == 0xd8, "Size mismatch for UJamMusicSlotVM");
static_assert(offsetof(UJamMusicSlotVM, OwningPlayerID) == 0x68, "Offset mismatch for UJamMusicSlotVM::OwningPlayerID");
static_assert(offsetof(UJamMusicSlotVM, Title) == 0x98, "Offset mismatch for UJamMusicSlotVM::Title");
static_assert(offsetof(UJamMusicSlotVM, Artist) == 0xa8, "Offset mismatch for UJamMusicSlotVM::Artist");
static_assert(offsetof(UJamMusicSlotVM, UserMode) == 0xb8, "Offset mismatch for UJamMusicSlotVM::UserMode");
static_assert(offsetof(UJamMusicSlotVM, PlayState) == 0xb9, "Offset mismatch for UJamMusicSlotVM::PlayState");
static_assert(offsetof(UJamMusicSlotVM, ResolveState) == 0xba, "Offset mismatch for UJamMusicSlotVM::ResolveState");
static_assert(offsetof(UJamMusicSlotVM, LoopType) == 0xbb, "Offset mismatch for UJamMusicSlotVM::LoopType");
static_assert(offsetof(UJamMusicSlotVM, FocusState) == 0xbc, "Offset mismatch for UJamMusicSlotVM::FocusState");

// Size: 0x150 (Inherited: 0x310, Single: 0xfffffe40)
class UJamUIManagerComponent_SongIndicators : public UFortControllerComponent
{
public:
    UClass* JamSongIndicatorClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    FUserWidgetPool IndicatorPool; // 0xc8 (Size: 0x88, Type: StructProperty)

public:
    void ClearJamIndicators(); // 0x107fe2e4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RebuildJamSongIndicatorsForPlayspace(AJamPlayspace*& Playspace); // 0x107fe978 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UJamUIManagerComponent_SongIndicators) == 0x150, "Size mismatch for UJamUIManagerComponent_SongIndicators");
static_assert(offsetof(UJamUIManagerComponent_SongIndicators, JamSongIndicatorClass) == 0xc0, "Offset mismatch for UJamUIManagerComponent_SongIndicators::JamSongIndicatorClass");
static_assert(offsetof(UJamUIManagerComponent_SongIndicators, IndicatorPool) == 0xc8, "Offset mismatch for UJamUIManagerComponent_SongIndicators::IndicatorPool");

// Size: 0x3e8 (Inherited: 0xe08, Single: 0xfffff5e0)
class UJamSongIndicator : public UFortActorIndicatorWidget
{
public:

public:
    AFortPlayerStateAthena* GetIndicatedPlayerStateAthena() const; // 0x107fe2f8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    virtual void OnDistanceChanged(int32_t& Distance); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInitInfo(UCatalogData*& const Song, EFMJamLoopType& Type); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnScreenClampChanged(bool& bIsClamped); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UJamSongIndicator) == 0x3e8, "Size mismatch for UJamSongIndicator");

