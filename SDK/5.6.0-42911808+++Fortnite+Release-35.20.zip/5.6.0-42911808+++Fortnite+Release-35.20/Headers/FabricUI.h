/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "UMG.h"
#include "Engine.h"
#include "PlayspaceSystem.h"
#include "SlateCore.h"

// Size: 0x70 (Inherited: 0x90, Single: 0xffffffe0)
class UFabricBeatDisplayViewModel : public UMVVMViewModelBase
{
public:
    float NumberOfBeats; // 0x68 (Size: 0x4, Type: FloatProperty)
    bool bVisible; // 0x6c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d[0x3]; // 0x6d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFabricBeatDisplayViewModel) == 0x70, "Size mismatch for UFabricBeatDisplayViewModel");
static_assert(offsetof(UFabricBeatDisplayViewModel, NumberOfBeats) == 0x68, "Offset mismatch for UFabricBeatDisplayViewModel::NumberOfBeats");
static_assert(offsetof(UFabricBeatDisplayViewModel, bVisible) == 0x6c, "Offset mismatch for UFabricBeatDisplayViewModel::bVisible");

// Size: 0x98 (Inherited: 0x120, Single: 0xffffff78)
class UFabricButtonBaseViewModel : public UFabricInteractableViewModel
{
public:
    uint8_t ToggleState; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFabricButtonBaseViewModel) == 0x98, "Size mismatch for UFabricButtonBaseViewModel");
static_assert(offsetof(UFabricButtonBaseViewModel, ToggleState) == 0x90, "Offset mismatch for UFabricButtonBaseViewModel::ToggleState");

// Size: 0x90 (Inherited: 0x90, Single: 0x0)
class UFabricInteractableViewModel : public UMVVMViewModelBase
{
public:
    FText Label; // 0x68 (Size: 0x10, Type: TextProperty)
    FText Value; // 0x78 (Size: 0x10, Type: TextProperty)
    bool bEnabled; // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bVisible; // 0x89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8a[0x6]; // 0x8a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFabricInteractableViewModel) == 0x90, "Size mismatch for UFabricInteractableViewModel");
static_assert(offsetof(UFabricInteractableViewModel, Label) == 0x68, "Offset mismatch for UFabricInteractableViewModel::Label");
static_assert(offsetof(UFabricInteractableViewModel, Value) == 0x78, "Offset mismatch for UFabricInteractableViewModel::Value");
static_assert(offsetof(UFabricInteractableViewModel, bEnabled) == 0x88, "Offset mismatch for UFabricInteractableViewModel::bEnabled");
static_assert(offsetof(UFabricInteractableViewModel, bVisible) == 0x89, "Offset mismatch for UFabricInteractableViewModel::bVisible");

// Size: 0x98 (Inherited: 0x120, Single: 0xffffff78)
class UFabricCarouselViewModel : public UFabricInteractableViewModel
{
public:
    bool bPresetEnabled; // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bShowBorder; // 0x91 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_92[0x2]; // 0x92 (Size: 0x2, Type: PaddingProperty)
    int32_t CurrentOptionIndex; // 0x94 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UFabricCarouselViewModel) == 0x98, "Size mismatch for UFabricCarouselViewModel");
static_assert(offsetof(UFabricCarouselViewModel, bPresetEnabled) == 0x90, "Offset mismatch for UFabricCarouselViewModel::bPresetEnabled");
static_assert(offsetof(UFabricCarouselViewModel, bShowBorder) == 0x91, "Offset mismatch for UFabricCarouselViewModel::bShowBorder");
static_assert(offsetof(UFabricCarouselViewModel, CurrentOptionIndex) == 0x94, "Offset mismatch for UFabricCarouselViewModel::CurrentOptionIndex");

// Size: 0x2e8 (Inherited: 0xa18, Single: 0xfffff8d0)
class UFabricGeneralTextWidget : public UFabricWidget
{
public:
};

static_assert(sizeof(UFabricGeneralTextWidget) == 0x2e8, "Size mismatch for UFabricGeneralTextWidget");

// Size: 0x2e8 (Inherited: 0x730, Single: 0xfffffbb8)
class UFabricWidget : public UCommonUserWidget
{
public:
    UClass* GridStyle; // 0x2d8 (Size: 0x8, Type: ClassProperty)
    UClass* ViewModelClass; // 0x2e0 (Size: 0x8, Type: ClassProperty)

public:
    virtual UFabricInteractableViewModel* GetFabricViewModel() const; // 0x1117ce0c (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UFabricWidget) == 0x2e8, "Size mismatch for UFabricWidget");
static_assert(offsetof(UFabricWidget, GridStyle) == 0x2d8, "Offset mismatch for UFabricWidget::GridStyle");
static_assert(offsetof(UFabricWidget, ViewModelClass) == 0x2e0, "Offset mismatch for UFabricWidget::ViewModelClass");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UFabricGridStyle : public UObject
{
public:
    FMargin Padding; // 0x28 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment; // 0x38 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment; // 0x39 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3a[0x2]; // 0x3a (Size: 0x2, Type: PaddingProperty)
    int32_t RowSpan; // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t ColumnSpan; // 0x40 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFabricGridStyle) == 0x48, "Size mismatch for UFabricGridStyle");
static_assert(offsetof(UFabricGridStyle, Padding) == 0x28, "Offset mismatch for UFabricGridStyle::Padding");
static_assert(offsetof(UFabricGridStyle, HorizontalAlignment) == 0x38, "Offset mismatch for UFabricGridStyle::HorizontalAlignment");
static_assert(offsetof(UFabricGridStyle, VerticalAlignment) == 0x39, "Offset mismatch for UFabricGridStyle::VerticalAlignment");
static_assert(offsetof(UFabricGridStyle, RowSpan) == 0x3c, "Offset mismatch for UFabricGridStyle::RowSpan");
static_assert(offsetof(UFabricGridStyle, ColumnSpan) == 0x40, "Offset mismatch for UFabricGridStyle::ColumnSpan");

// Size: 0x2e8 (Inherited: 0xa18, Single: 0xfffff8d0)
class UFabricInfoWidget : public UFabricWidget
{
public:
};

static_assert(sizeof(UFabricInfoWidget) == 0x2e8, "Size mismatch for UFabricInfoWidget");

// Size: 0x98 (Inherited: 0x120, Single: 0xffffff78)
class UFabricKnobViewModel : public UFabricInteractableViewModel
{
public:
    bool bValueVisible; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFabricKnobViewModel) == 0x98, "Size mismatch for UFabricKnobViewModel");
static_assert(offsetof(UFabricKnobViewModel, bValueVisible) == 0x90, "Offset mismatch for UFabricKnobViewModel::bValueVisible");

// Size: 0x80 (Inherited: 0x90, Single: 0xfffffff0)
class UFabricMeasureViewModel : public UMVVMViewModelBase
{
public:
    FText MeasureCount; // 0x68 (Size: 0x10, Type: TextProperty)
    bool bVisible; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFabricMeasureViewModel) == 0x80, "Size mismatch for UFabricMeasureViewModel");
static_assert(offsetof(UFabricMeasureViewModel, MeasureCount) == 0x68, "Offset mismatch for UFabricMeasureViewModel::MeasureCount");
static_assert(offsetof(UFabricMeasureViewModel, bVisible) == 0x78, "Offset mismatch for UFabricMeasureViewModel::bVisible");

// Size: 0x70 (Inherited: 0x90, Single: 0xffffffe0)
class UFabricPageInfoViewModel : public UMVVMViewModelBase
{
public:
    bool bHasContent; // 0x68 (Size: 0x1, Type: BoolProperty)
    bool bActivePage; // 0x69 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6a[0x6]; // 0x6a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFabricPageInfoViewModel) == 0x70, "Size mismatch for UFabricPageInfoViewModel");
static_assert(offsetof(UFabricPageInfoViewModel, bHasContent) == 0x68, "Offset mismatch for UFabricPageInfoViewModel::bHasContent");
static_assert(offsetof(UFabricPageInfoViewModel, bActivePage) == 0x69, "Offset mismatch for UFabricPageInfoViewModel::bActivePage");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UFabricPlaybackTimeViewModel : public UMVVMViewModelBase
{
public:
    float ElapsedSeconds; // 0x68 (Size: 0x4, Type: FloatProperty)
    float TotalSeconds; // 0x6c (Size: 0x4, Type: FloatProperty)
    bool bEnabled; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bVisible; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x6]; // 0x72 (Size: 0x6, Type: PaddingProperty)

public:
    float GetPercentProgress() const; // 0x1117d024 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFabricPlaybackTimeViewModel) == 0x78, "Size mismatch for UFabricPlaybackTimeViewModel");
static_assert(offsetof(UFabricPlaybackTimeViewModel, ElapsedSeconds) == 0x68, "Offset mismatch for UFabricPlaybackTimeViewModel::ElapsedSeconds");
static_assert(offsetof(UFabricPlaybackTimeViewModel, TotalSeconds) == 0x6c, "Offset mismatch for UFabricPlaybackTimeViewModel::TotalSeconds");
static_assert(offsetof(UFabricPlaybackTimeViewModel, bEnabled) == 0x70, "Offset mismatch for UFabricPlaybackTimeViewModel::bEnabled");
static_assert(offsetof(UFabricPlaybackTimeViewModel, bVisible) == 0x71, "Offset mismatch for UFabricPlaybackTimeViewModel::bVisible");

// Size: 0x2f8 (Inherited: 0xa18, Single: 0xfffff8e0)
class UFabricPlaybackTimeWidget : public UFabricWidget
{
public:
    UNamedSlot* NamedSlot_Left; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UNamedSlot* NamedSlot_Right; // 0x2f0 (Size: 0x8, Type: ObjectProperty)

public:
    UUserWidget* GetNamedSlotLeftWidgetChild() const; // 0x1117cf74 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UUserWidget* GetNamedSlotRightWidgetChild() const; // 0x1117cfcc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    FText GetFormattedTimeFromSeconds(float& Seconds) const; // 0x1117ce34 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFabricPlaybackTimeWidget) == 0x2f8, "Size mismatch for UFabricPlaybackTimeWidget");
static_assert(offsetof(UFabricPlaybackTimeWidget, NamedSlot_Left) == 0x2e8, "Offset mismatch for UFabricPlaybackTimeWidget::NamedSlot_Left");
static_assert(offsetof(UFabricPlaybackTimeWidget, NamedSlot_Right) == 0x2f0, "Offset mismatch for UFabricPlaybackTimeWidget::NamedSlot_Right");

// Size: 0x308 (Inherited: 0x730, Single: 0xfffffbd8)
class UFabricScreenWidget : public UCommonUserWidget
{
public:
    UInvalidationBox* InvalidationBox_RootBox; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UScaleBox* ScaleBox_ScreenScale; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GridPanel_ScreenGrid; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    USpacer* Spacer_ElementSpacer; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f8[0x10]; // 0x2f8 (Size: 0x10, Type: PaddingProperty)

public:
    UFabricWidget* AttachFabricWidget(const UClass* FabricWidgetClass, const FVector2D GridPosition); // 0x1117ba6c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    UFabricWidget* FindWidgetOfClass(UClass*& const FabricWidgetClass); // 0x1117c8a4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetScreenGridDimensions(const FVector2D InNewDimensions); // 0x1117d17c (Index: 0x2, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFabricScreenWidget) == 0x308, "Size mismatch for UFabricScreenWidget");
static_assert(offsetof(UFabricScreenWidget, InvalidationBox_RootBox) == 0x2d8, "Offset mismatch for UFabricScreenWidget::InvalidationBox_RootBox");
static_assert(offsetof(UFabricScreenWidget, ScaleBox_ScreenScale) == 0x2e0, "Offset mismatch for UFabricScreenWidget::ScaleBox_ScreenScale");
static_assert(offsetof(UFabricScreenWidget, GridPanel_ScreenGrid) == 0x2e8, "Offset mismatch for UFabricScreenWidget::GridPanel_ScreenGrid");
static_assert(offsetof(UFabricScreenWidget, Spacer_ElementSpacer) == 0x2f0, "Offset mismatch for UFabricScreenWidget::Spacer_ElementSpacer");

// Size: 0x70 (Inherited: 0x90, Single: 0xffffffe0)
class UFabricSongSyncViewModel : public UMVVMViewModelBase
{
public:
    uint8_t ControlTempoState; // 0x68 (Size: 0x1, Type: EnumProperty)
    bool bHasLinkedSongSyncDevices; // 0x69 (Size: 0x1, Type: BoolProperty)
    bool bEnabled; // 0x6a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6b[0x5]; // 0x6b (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UFabricSongSyncViewModel) == 0x70, "Size mismatch for UFabricSongSyncViewModel");
static_assert(offsetof(UFabricSongSyncViewModel, ControlTempoState) == 0x68, "Offset mismatch for UFabricSongSyncViewModel::ControlTempoState");
static_assert(offsetof(UFabricSongSyncViewModel, bHasLinkedSongSyncDevices) == 0x69, "Offset mismatch for UFabricSongSyncViewModel::bHasLinkedSongSyncDevices");
static_assert(offsetof(UFabricSongSyncViewModel, bEnabled) == 0x6a, "Offset mismatch for UFabricSongSyncViewModel::bEnabled");

// Size: 0x90 (Inherited: 0x90, Single: 0x0)
class UFabricTimeSignatureViewModel : public UMVVMViewModelBase
{
public:
    FText TopValue; // 0x68 (Size: 0x10, Type: TextProperty)
    FText BottomValue; // 0x78 (Size: 0x10, Type: TextProperty)
    bool bEnabled; // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bVisible; // 0x89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8a[0x6]; // 0x8a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFabricTimeSignatureViewModel) == 0x90, "Size mismatch for UFabricTimeSignatureViewModel");
static_assert(offsetof(UFabricTimeSignatureViewModel, TopValue) == 0x68, "Offset mismatch for UFabricTimeSignatureViewModel::TopValue");
static_assert(offsetof(UFabricTimeSignatureViewModel, BottomValue) == 0x78, "Offset mismatch for UFabricTimeSignatureViewModel::BottomValue");
static_assert(offsetof(UFabricTimeSignatureViewModel, bEnabled) == 0x88, "Offset mismatch for UFabricTimeSignatureViewModel::bEnabled");
static_assert(offsetof(UFabricTimeSignatureViewModel, bVisible) == 0x89, "Offset mismatch for UFabricTimeSignatureViewModel::bVisible");

// Size: 0x2e8 (Inherited: 0xa18, Single: 0xfffff8d0)
class UFabricTimeSignatureWidget : public UFabricWidget
{
public:
};

static_assert(sizeof(UFabricTimeSignatureWidget) == 0x2e8, "Size mismatch for UFabricTimeSignatureWidget");

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UFabricTrackInfoViewModel : public UMVVMViewModelBase
{
public:
    uint8_t TrackInfoState; // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
    FString Artist; // 0x70 (Size: 0x10, Type: StrProperty)
    FString Title; // 0x80 (Size: 0x10, Type: StrProperty)
    bool bLoading; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFabricTrackInfoViewModel) == 0x98, "Size mismatch for UFabricTrackInfoViewModel");
static_assert(offsetof(UFabricTrackInfoViewModel, TrackInfoState) == 0x68, "Offset mismatch for UFabricTrackInfoViewModel::TrackInfoState");
static_assert(offsetof(UFabricTrackInfoViewModel, Artist) == 0x70, "Offset mismatch for UFabricTrackInfoViewModel::Artist");
static_assert(offsetof(UFabricTrackInfoViewModel, Title) == 0x80, "Offset mismatch for UFabricTrackInfoViewModel::Title");
static_assert(offsetof(UFabricTrackInfoViewModel, bLoading) == 0x90, "Offset mismatch for UFabricTrackInfoViewModel::bLoading");

// Size: 0x2e8 (Inherited: 0xa18, Single: 0xfffff8d0)
class UFabricTrackInfoWidget : public UFabricWidget
{
public:
};

static_assert(sizeof(UFabricTrackInfoWidget) == 0x2e8, "Size mismatch for UFabricTrackInfoWidget");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UFabricTrackNumberViewModel : public UMVVMViewModelBase
{
public:
    int32_t CurrentTrackNumber; // 0x68 (Size: 0x4, Type: IntProperty)
    int32_t TotalNumberOfTracks; // 0x6c (Size: 0x4, Type: IntProperty)
    bool bEnabled; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bVisible; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x6]; // 0x72 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFabricTrackNumberViewModel) == 0x78, "Size mismatch for UFabricTrackNumberViewModel");
static_assert(offsetof(UFabricTrackNumberViewModel, CurrentTrackNumber) == 0x68, "Offset mismatch for UFabricTrackNumberViewModel::CurrentTrackNumber");
static_assert(offsetof(UFabricTrackNumberViewModel, TotalNumberOfTracks) == 0x6c, "Offset mismatch for UFabricTrackNumberViewModel::TotalNumberOfTracks");
static_assert(offsetof(UFabricTrackNumberViewModel, bEnabled) == 0x70, "Offset mismatch for UFabricTrackNumberViewModel::bEnabled");
static_assert(offsetof(UFabricTrackNumberViewModel, bVisible) == 0x71, "Offset mismatch for UFabricTrackNumberViewModel::bVisible");

// Size: 0x2e8 (Inherited: 0xa18, Single: 0xfffff8d0)
class UFabricTrackNumberWidget : public UFabricWidget
{
public:
};

static_assert(sizeof(UFabricTrackNumberWidget) == 0x2e8, "Size mismatch for UFabricTrackNumberWidget");

// Size: 0x6b0 (Inherited: 0x1440, Single: 0xfffff270)
class UFabricWidgetComponent : public UWidgetComponent
{
public:
    bool bShouldSuscribeToSignificanceSubsystem; // 0x6a0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6a1[0xf]; // 0x6a1 (Size: 0xf, Type: PaddingProperty)

public:
    ETickMode GetTickMode() const; // 0x110a8f04 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetShouldSuscribeToSignificanceSubsystem(bool& ShouldSuscribe); // 0x1117d7b4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricWidgetComponent) == 0x6b0, "Size mismatch for UFabricWidgetComponent");
static_assert(offsetof(UFabricWidgetComponent, bShouldSuscribeToSignificanceSubsystem) == 0x6a0, "Offset mismatch for UFabricWidgetComponent::bShouldSuscribeToSignificanceSubsystem");

// Size: 0x58 (Inherited: 0xc8, Single: 0xffffff90)
class UFabricWidgetTickControlSubsystem : public UTickableWorldSubsystem
{
public:

public:
    void RegisterFabricWidgetComponent(UFabricWidgetComponent*& WidgetComponent); // 0x1117d050 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterFabricWidgetComponent(UFabricWidgetComponent*& WidgetComponent); // 0x1117d8e0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricWidgetTickControlSubsystem) == 0x58, "Size mismatch for UFabricWidgetTickControlSubsystem");

// Size: 0x108 (Inherited: 0x250, Single: 0xfffffeb8)
class UPlayspaceComponent_FabricViewModelManager : public UPlayspaceComponent
{
public:
    TMap<UMVVMViewModelBase*, UClass*> Viewmodels; // 0xb8 (Size: 0x50, Type: MapProperty)

public:
    UMVVMViewModelBase* FindOrAddViewModelOfClass(UClass*& ViewModelClass); // 0x1117bbd8 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    UMVVMViewModelBase* SetSharedVMOnWidget(UClass*& ViewModelClass, UUserWidget*& Widget); // 0x1117d268 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UPlayspaceComponent_FabricViewModelManager) == 0x108, "Size mismatch for UPlayspaceComponent_FabricViewModelManager");
static_assert(offsetof(UPlayspaceComponent_FabricViewModelManager, Viewmodels) == 0xb8, "Offset mismatch for UPlayspaceComponent_FabricViewModelManager::Viewmodels");

