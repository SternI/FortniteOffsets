/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityRegistry
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Entity.h"

// Size: 0xc8 (Inherited: 0x28, Single: 0xa0)
class UEntityContainer : public UObject
{
public:
};

static_assert(sizeof(UEntityContainer) == 0xc8, "Size mismatch for UEntityContainer");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UEntityRegistry : public UEntityRegistryBase
{
public:
};

static_assert(sizeof(UEntityRegistry) == 0x30, "Size mismatch for UEntityRegistry");

