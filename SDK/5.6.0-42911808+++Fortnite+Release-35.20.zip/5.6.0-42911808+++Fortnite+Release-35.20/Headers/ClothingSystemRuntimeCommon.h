/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClothingSystemRuntimeCommon
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ClothingSystemRuntimeInterface.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UClothConfigCommon : public UClothConfigBase
{
public:
};

static_assert(sizeof(UClothConfigCommon) == 0x28, "Size mismatch for UClothConfigCommon");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UClothSharedConfigCommon : public UClothConfigCommon
{
public:
};

static_assert(sizeof(UClothSharedConfigCommon) == 0x28, "Size mismatch for UClothSharedConfigCommon");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UClothingAssetCustomData : public UObject
{
public:
};

static_assert(sizeof(UClothingAssetCustomData) == 0x28, "Size mismatch for UClothingAssetCustomData");

// Size: 0xd8 (Inherited: 0x60, Single: 0x78)
class UClothingAssetCommon : public UClothingAssetBase
{
public:
    UPhysicsAsset* PhysicsAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
    TMap<UClothConfigBase*, FName> ClothConfigs; // 0x40 (Size: 0x50, Type: MapProperty)
    TArray<FClothLODDataCommon> LODData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> LodMap; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> UsedBoneNames; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> UsedBoneIndices; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    int32_t ReferenceBoneIndex; // 0xd0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UClothingAssetCommon) == 0xd8, "Size mismatch for UClothingAssetCommon");
static_assert(offsetof(UClothingAssetCommon, PhysicsAsset) == 0x38, "Offset mismatch for UClothingAssetCommon::PhysicsAsset");
static_assert(offsetof(UClothingAssetCommon, ClothConfigs) == 0x40, "Offset mismatch for UClothingAssetCommon::ClothConfigs");
static_assert(offsetof(UClothingAssetCommon, LODData) == 0x90, "Offset mismatch for UClothingAssetCommon::LODData");
static_assert(offsetof(UClothingAssetCommon, LodMap) == 0xa0, "Offset mismatch for UClothingAssetCommon::LodMap");
static_assert(offsetof(UClothingAssetCommon, UsedBoneNames) == 0xb0, "Offset mismatch for UClothingAssetCommon::UsedBoneNames");
static_assert(offsetof(UClothingAssetCommon, UsedBoneIndices) == 0xc0, "Offset mismatch for UClothingAssetCommon::UsedBoneIndices");
static_assert(offsetof(UClothingAssetCommon, ReferenceBoneIndex) == 0xd0, "Offset mismatch for UClothingAssetCommon::ReferenceBoneIndex");

// Size: 0x1b8 (Inherited: 0x28, Single: 0x190)
class UClothLODDataCommon_Legacy : public UObject
{
public:
    UClothPhysicalMeshDataBase_Legacy* PhysicalMeshData; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FClothPhysicalMeshData ClothPhysicalMeshData; // 0x30 (Size: 0x128, Type: StructProperty)
    FClothCollisionData CollisionData; // 0x158 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_198[0x20]; // 0x198 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UClothLODDataCommon_Legacy) == 0x1b8, "Size mismatch for UClothLODDataCommon_Legacy");
static_assert(offsetof(UClothLODDataCommon_Legacy, PhysicalMeshData) == 0x28, "Offset mismatch for UClothLODDataCommon_Legacy::PhysicalMeshData");
static_assert(offsetof(UClothLODDataCommon_Legacy, ClothPhysicalMeshData) == 0x30, "Offset mismatch for UClothLODDataCommon_Legacy::ClothPhysicalMeshData");
static_assert(offsetof(UClothLODDataCommon_Legacy, CollisionData) == 0x158, "Offset mismatch for UClothLODDataCommon_Legacy::CollisionData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FClothConstraintSetup_Legacy
{
    float Stiffness; // 0x0 (Size: 0x4, Type: FloatProperty)
    float StiffnessMultiplier; // 0x4 (Size: 0x4, Type: FloatProperty)
    float StretchLimit; // 0x8 (Size: 0x4, Type: FloatProperty)
    float CompressionLimit; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FClothConstraintSetup_Legacy) == 0x10, "Size mismatch for FClothConstraintSetup_Legacy");
static_assert(offsetof(FClothConstraintSetup_Legacy, Stiffness) == 0x0, "Offset mismatch for FClothConstraintSetup_Legacy::Stiffness");
static_assert(offsetof(FClothConstraintSetup_Legacy, StiffnessMultiplier) == 0x4, "Offset mismatch for FClothConstraintSetup_Legacy::StiffnessMultiplier");
static_assert(offsetof(FClothConstraintSetup_Legacy, StretchLimit) == 0x8, "Offset mismatch for FClothConstraintSetup_Legacy::StretchLimit");
static_assert(offsetof(FClothConstraintSetup_Legacy, CompressionLimit) == 0xc, "Offset mismatch for FClothConstraintSetup_Legacy::CompressionLimit");

// Size: 0x130 (Inherited: 0x0, Single: 0x130)
struct FClothConfig_Legacy
{
    uint8_t WindMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FClothConstraintSetup_Legacy VerticalConstraintConfig; // 0x4 (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy HorizontalConstraintConfig; // 0x14 (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy BendConstraintConfig; // 0x24 (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy ShearConstraintConfig; // 0x34 (Size: 0x10, Type: StructProperty)
    float SelfCollisionRadius; // 0x44 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionStiffness; // 0x48 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionCullScale; // 0x4c (Size: 0x4, Type: FloatProperty)
    FVector Damping; // 0x50 (Size: 0x18, Type: StructProperty)
    float Friction; // 0x68 (Size: 0x4, Type: FloatProperty)
    float WindDragCoefficient; // 0x6c (Size: 0x4, Type: FloatProperty)
    float WindLiftCoefficient; // 0x70 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FVector LinearDrag; // 0x78 (Size: 0x18, Type: StructProperty)
    FVector AngularDrag; // 0x90 (Size: 0x18, Type: StructProperty)
    FVector LinearInertiaScale; // 0xa8 (Size: 0x18, Type: StructProperty)
    FVector AngularInertiaScale; // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector CentrifugalInertiaScale; // 0xd8 (Size: 0x18, Type: StructProperty)
    float SolverFrequency; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float StiffnessFrequency; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float GravityScale; // 0xf8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
    FVector GravityOverride; // 0x100 (Size: 0x18, Type: StructProperty)
    bool bUseGravityOverride; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x3]; // 0x119 (Size: 0x3, Type: PaddingProperty)
    float TetherStiffness; // 0x11c (Size: 0x4, Type: FloatProperty)
    float TetherLimit; // 0x120 (Size: 0x4, Type: FloatProperty)
    float CollisionThickness; // 0x124 (Size: 0x4, Type: FloatProperty)
    float AnimDriveSpringStiffness; // 0x128 (Size: 0x4, Type: FloatProperty)
    float AnimDriveDamperStiffness; // 0x12c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FClothConfig_Legacy) == 0x130, "Size mismatch for FClothConfig_Legacy");
static_assert(offsetof(FClothConfig_Legacy, WindMethod) == 0x0, "Offset mismatch for FClothConfig_Legacy::WindMethod");
static_assert(offsetof(FClothConfig_Legacy, VerticalConstraintConfig) == 0x4, "Offset mismatch for FClothConfig_Legacy::VerticalConstraintConfig");
static_assert(offsetof(FClothConfig_Legacy, HorizontalConstraintConfig) == 0x14, "Offset mismatch for FClothConfig_Legacy::HorizontalConstraintConfig");
static_assert(offsetof(FClothConfig_Legacy, BendConstraintConfig) == 0x24, "Offset mismatch for FClothConfig_Legacy::BendConstraintConfig");
static_assert(offsetof(FClothConfig_Legacy, ShearConstraintConfig) == 0x34, "Offset mismatch for FClothConfig_Legacy::ShearConstraintConfig");
static_assert(offsetof(FClothConfig_Legacy, SelfCollisionRadius) == 0x44, "Offset mismatch for FClothConfig_Legacy::SelfCollisionRadius");
static_assert(offsetof(FClothConfig_Legacy, SelfCollisionStiffness) == 0x48, "Offset mismatch for FClothConfig_Legacy::SelfCollisionStiffness");
static_assert(offsetof(FClothConfig_Legacy, SelfCollisionCullScale) == 0x4c, "Offset mismatch for FClothConfig_Legacy::SelfCollisionCullScale");
static_assert(offsetof(FClothConfig_Legacy, Damping) == 0x50, "Offset mismatch for FClothConfig_Legacy::Damping");
static_assert(offsetof(FClothConfig_Legacy, Friction) == 0x68, "Offset mismatch for FClothConfig_Legacy::Friction");
static_assert(offsetof(FClothConfig_Legacy, WindDragCoefficient) == 0x6c, "Offset mismatch for FClothConfig_Legacy::WindDragCoefficient");
static_assert(offsetof(FClothConfig_Legacy, WindLiftCoefficient) == 0x70, "Offset mismatch for FClothConfig_Legacy::WindLiftCoefficient");
static_assert(offsetof(FClothConfig_Legacy, LinearDrag) == 0x78, "Offset mismatch for FClothConfig_Legacy::LinearDrag");
static_assert(offsetof(FClothConfig_Legacy, AngularDrag) == 0x90, "Offset mismatch for FClothConfig_Legacy::AngularDrag");
static_assert(offsetof(FClothConfig_Legacy, LinearInertiaScale) == 0xa8, "Offset mismatch for FClothConfig_Legacy::LinearInertiaScale");
static_assert(offsetof(FClothConfig_Legacy, AngularInertiaScale) == 0xc0, "Offset mismatch for FClothConfig_Legacy::AngularInertiaScale");
static_assert(offsetof(FClothConfig_Legacy, CentrifugalInertiaScale) == 0xd8, "Offset mismatch for FClothConfig_Legacy::CentrifugalInertiaScale");
static_assert(offsetof(FClothConfig_Legacy, SolverFrequency) == 0xf0, "Offset mismatch for FClothConfig_Legacy::SolverFrequency");
static_assert(offsetof(FClothConfig_Legacy, StiffnessFrequency) == 0xf4, "Offset mismatch for FClothConfig_Legacy::StiffnessFrequency");
static_assert(offsetof(FClothConfig_Legacy, GravityScale) == 0xf8, "Offset mismatch for FClothConfig_Legacy::GravityScale");
static_assert(offsetof(FClothConfig_Legacy, GravityOverride) == 0x100, "Offset mismatch for FClothConfig_Legacy::GravityOverride");
static_assert(offsetof(FClothConfig_Legacy, bUseGravityOverride) == 0x118, "Offset mismatch for FClothConfig_Legacy::bUseGravityOverride");
static_assert(offsetof(FClothConfig_Legacy, TetherStiffness) == 0x11c, "Offset mismatch for FClothConfig_Legacy::TetherStiffness");
static_assert(offsetof(FClothConfig_Legacy, TetherLimit) == 0x120, "Offset mismatch for FClothConfig_Legacy::TetherLimit");
static_assert(offsetof(FClothConfig_Legacy, CollisionThickness) == 0x124, "Offset mismatch for FClothConfig_Legacy::CollisionThickness");
static_assert(offsetof(FClothConfig_Legacy, AnimDriveSpringStiffness) == 0x128, "Offset mismatch for FClothConfig_Legacy::AnimDriveSpringStiffness");
static_assert(offsetof(FClothConfig_Legacy, AnimDriveDamperStiffness) == 0x12c, "Offset mismatch for FClothConfig_Legacy::AnimDriveDamperStiffness");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPointWeightMap
{
    TArray<float> Values; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPointWeightMap) == 0x10, "Size mismatch for FPointWeightMap");
static_assert(offsetof(FPointWeightMap, Values) == 0x0, "Offset mismatch for FPointWeightMap::Values");

// Size: 0x158 (Inherited: 0x0, Single: 0x158)
struct FClothLODDataCommon
{
    FClothPhysicalMeshData PhysicalMeshData; // 0x0 (Size: 0x128, Type: StructProperty)
    bool bUseMultipleInfluences; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x3]; // 0x129 (Size: 0x3, Type: PaddingProperty)
    float SkinningKernelRadius; // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bSmoothTransition; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0x27]; // 0x131 (Size: 0x27, Type: PaddingProperty)
};

static_assert(sizeof(FClothLODDataCommon) == 0x158, "Size mismatch for FClothLODDataCommon");
static_assert(offsetof(FClothLODDataCommon, PhysicalMeshData) == 0x0, "Offset mismatch for FClothLODDataCommon::PhysicalMeshData");
static_assert(offsetof(FClothLODDataCommon, bUseMultipleInfluences) == 0x128, "Offset mismatch for FClothLODDataCommon::bUseMultipleInfluences");
static_assert(offsetof(FClothLODDataCommon, SkinningKernelRadius) == 0x12c, "Offset mismatch for FClothLODDataCommon::SkinningKernelRadius");
static_assert(offsetof(FClothLODDataCommon, bSmoothTransition) == 0x130, "Offset mismatch for FClothLODDataCommon::bSmoothTransition");

// Size: 0x128 (Inherited: 0x0, Single: 0x128)
struct FClothPhysicalMeshData
{
    TArray<FVector3f> Vertices; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3f> Normals; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Indices; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TMap<FPointWeightMap, uint32_t> WeightMaps; // 0x30 (Size: 0x50, Type: MapProperty)
    TArray<float> InverseMasses; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothVertBoneData> BoneData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TSet<int32_t> SelfCollisionVertexSet; // 0xa0 (Size: 0x50, Type: SetProperty)
    FClothTetherData EuclideanTethers; // 0xf0 (Size: 0x10, Type: StructProperty)
    FClothTetherData GeodesicTethers; // 0x100 (Size: 0x10, Type: StructProperty)
    int32_t MaxBoneWeights; // 0x110 (Size: 0x4, Type: IntProperty)
    int32_t NumFixedVerts; // 0x114 (Size: 0x4, Type: IntProperty)
    TArray<uint32_t> SelfCollisionIndices; // 0x118 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClothPhysicalMeshData) == 0x128, "Size mismatch for FClothPhysicalMeshData");
static_assert(offsetof(FClothPhysicalMeshData, Vertices) == 0x0, "Offset mismatch for FClothPhysicalMeshData::Vertices");
static_assert(offsetof(FClothPhysicalMeshData, Normals) == 0x10, "Offset mismatch for FClothPhysicalMeshData::Normals");
static_assert(offsetof(FClothPhysicalMeshData, Indices) == 0x20, "Offset mismatch for FClothPhysicalMeshData::Indices");
static_assert(offsetof(FClothPhysicalMeshData, WeightMaps) == 0x30, "Offset mismatch for FClothPhysicalMeshData::WeightMaps");
static_assert(offsetof(FClothPhysicalMeshData, InverseMasses) == 0x80, "Offset mismatch for FClothPhysicalMeshData::InverseMasses");
static_assert(offsetof(FClothPhysicalMeshData, BoneData) == 0x90, "Offset mismatch for FClothPhysicalMeshData::BoneData");
static_assert(offsetof(FClothPhysicalMeshData, SelfCollisionVertexSet) == 0xa0, "Offset mismatch for FClothPhysicalMeshData::SelfCollisionVertexSet");
static_assert(offsetof(FClothPhysicalMeshData, EuclideanTethers) == 0xf0, "Offset mismatch for FClothPhysicalMeshData::EuclideanTethers");
static_assert(offsetof(FClothPhysicalMeshData, GeodesicTethers) == 0x100, "Offset mismatch for FClothPhysicalMeshData::GeodesicTethers");
static_assert(offsetof(FClothPhysicalMeshData, MaxBoneWeights) == 0x110, "Offset mismatch for FClothPhysicalMeshData::MaxBoneWeights");
static_assert(offsetof(FClothPhysicalMeshData, NumFixedVerts) == 0x114, "Offset mismatch for FClothPhysicalMeshData::NumFixedVerts");
static_assert(offsetof(FClothPhysicalMeshData, SelfCollisionIndices) == 0x118, "Offset mismatch for FClothPhysicalMeshData::SelfCollisionIndices");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FClothTetherData
{
};

static_assert(sizeof(FClothTetherData) == 0x10, "Size mismatch for FClothTetherData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FClothParameterMask_Legacy
{
    FName MaskName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t CurrentTarget; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float MaxValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinValue; // 0xc (Size: 0x4, Type: FloatProperty)
    TArray<float> Values; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bEnabled; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FClothParameterMask_Legacy) == 0x28, "Size mismatch for FClothParameterMask_Legacy");
static_assert(offsetof(FClothParameterMask_Legacy, MaskName) == 0x0, "Offset mismatch for FClothParameterMask_Legacy::MaskName");
static_assert(offsetof(FClothParameterMask_Legacy, CurrentTarget) == 0x4, "Offset mismatch for FClothParameterMask_Legacy::CurrentTarget");
static_assert(offsetof(FClothParameterMask_Legacy, MaxValue) == 0x8, "Offset mismatch for FClothParameterMask_Legacy::MaxValue");
static_assert(offsetof(FClothParameterMask_Legacy, MinValue) == 0xc, "Offset mismatch for FClothParameterMask_Legacy::MinValue");
static_assert(offsetof(FClothParameterMask_Legacy, Values) == 0x10, "Offset mismatch for FClothParameterMask_Legacy::Values");
static_assert(offsetof(FClothParameterMask_Legacy, bEnabled) == 0x20, "Offset mismatch for FClothParameterMask_Legacy::bEnabled");

