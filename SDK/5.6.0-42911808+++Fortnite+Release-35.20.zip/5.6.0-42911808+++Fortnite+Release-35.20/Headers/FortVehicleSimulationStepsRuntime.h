/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortVehicleSimulationStepsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "DataRegistry.h"

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UFortVehicleSimulationStepsManager : public UObject
{
public:
    bool bEnabled; // 0x28 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EVehicleSimStepFlags> DefaultSimulationStepFlags; // 0x29 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FDataRegistryType DataRegistryType_VehicleSimulationStepsPermissions; // 0x2c (Size: 0x4, Type: StructProperty)
    FDataRegistryType DataRegistryType_VehicleSimulationStepsConfig; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x54]; // 0x34 (Size: 0x54, Type: PaddingProperty)
};

static_assert(sizeof(UFortVehicleSimulationStepsManager) == 0x88, "Size mismatch for UFortVehicleSimulationStepsManager");
static_assert(offsetof(UFortVehicleSimulationStepsManager, bEnabled) == 0x28, "Offset mismatch for UFortVehicleSimulationStepsManager::bEnabled");
static_assert(offsetof(UFortVehicleSimulationStepsManager, DefaultSimulationStepFlags) == 0x29, "Offset mismatch for UFortVehicleSimulationStepsManager::DefaultSimulationStepFlags");
static_assert(offsetof(UFortVehicleSimulationStepsManager, DataRegistryType_VehicleSimulationStepsPermissions) == 0x2c, "Offset mismatch for UFortVehicleSimulationStepsManager::DataRegistryType_VehicleSimulationStepsPermissions");
static_assert(offsetof(UFortVehicleSimulationStepsManager, DataRegistryType_VehicleSimulationStepsConfig) == 0x30, "Offset mismatch for UFortVehicleSimulationStepsManager::DataRegistryType_VehicleSimulationStepsConfig");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FFortVehicleSimulationStepOverrideTableRow : FTableRowBase
{
    TEnumAsByte<EVehicleSimStep> SimulationStep; // 0x8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVehicleSimStepFlags> SimulationStepFlags; // 0x9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FFortVehicleSimulationStepOverrideTableRow) == 0x10, "Size mismatch for FFortVehicleSimulationStepOverrideTableRow");
static_assert(offsetof(FFortVehicleSimulationStepOverrideTableRow, SimulationStep) == 0x8, "Offset mismatch for FFortVehicleSimulationStepOverrideTableRow::SimulationStep");
static_assert(offsetof(FFortVehicleSimulationStepOverrideTableRow, SimulationStepFlags) == 0x9, "Offset mismatch for FFortVehicleSimulationStepOverrideTableRow::SimulationStepFlags");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FFortVehicleSimulationConfigTableRow : FTableRowBase
{
    bool bIsSimulationManagerEnabled; // 0x8 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EVehicleSimStepFlags> DefaultSimulationStepFlags; // 0x9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FFortVehicleSimulationConfigTableRow) == 0x10, "Size mismatch for FFortVehicleSimulationConfigTableRow");
static_assert(offsetof(FFortVehicleSimulationConfigTableRow, bIsSimulationManagerEnabled) == 0x8, "Offset mismatch for FFortVehicleSimulationConfigTableRow::bIsSimulationManagerEnabled");
static_assert(offsetof(FFortVehicleSimulationConfigTableRow, DefaultSimulationStepFlags) == 0x9, "Offset mismatch for FFortVehicleSimulationConfigTableRow::DefaultSimulationStepFlags");

