/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMCalibrationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class UBeatmatchCalibrationHelper : public UActorComponent
{
public:
    float TightCalWindowMs; // 0xb8 (Size: 0x4, Type: FloatProperty)
    int32_t MinTightCalSamples; // 0xbc (Size: 0x4, Type: IntProperty)
    float LooseCalWindowMs; // 0xc0 (Size: 0x4, Type: FloatProperty)
    int32_t MinLooseCalSamples; // 0xc4 (Size: 0x4, Type: IntProperty)
    int32_t MaxSamplesBeforeFail; // 0xc8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)

public:
    void CalcCalibrationResult(const TArray<float> Samples, const TArray<float> SamplesDeltaTimes, float& BPS, ECalibrationState& ResultingState, float& ResultMs); // 0x121826d8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBeatmatchCalibrationHelper) == 0xd0, "Size mismatch for UBeatmatchCalibrationHelper");
static_assert(offsetof(UBeatmatchCalibrationHelper, TightCalWindowMs) == 0xb8, "Offset mismatch for UBeatmatchCalibrationHelper::TightCalWindowMs");
static_assert(offsetof(UBeatmatchCalibrationHelper, MinTightCalSamples) == 0xbc, "Offset mismatch for UBeatmatchCalibrationHelper::MinTightCalSamples");
static_assert(offsetof(UBeatmatchCalibrationHelper, LooseCalWindowMs) == 0xc0, "Offset mismatch for UBeatmatchCalibrationHelper::LooseCalWindowMs");
static_assert(offsetof(UBeatmatchCalibrationHelper, MinLooseCalSamples) == 0xc4, "Offset mismatch for UBeatmatchCalibrationHelper::MinLooseCalSamples");
static_assert(offsetof(UBeatmatchCalibrationHelper, MaxSamplesBeforeFail) == 0xc8, "Offset mismatch for UBeatmatchCalibrationHelper::MaxSamplesBeforeFail");

// Size: 0x1c8 (Inherited: 0x250, Single: 0xffffff78)
class UFMCalibrationControllerComponent : public UControllerComponent
{
public:
    uint8_t OnCalibrationDataLoaded[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCalibrationDataSaved[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAudioLatencyMsUpdated[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVideoLatencyMsUpdated[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnIsCalibratedUpdated[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnIsPreambleDisabledUpdated[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnIsAutolaunchDisabledUpdated[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnIsCalibrationDebugEnabled[0x10]; // 0x128 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCalibrometerDisplay[0x10]; // 0x138 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnHasTalkedWithRoadie[0x10]; // 0x148 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCalibrationRequestOpenModal[0x10]; // 0x158 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCalibrationRegisterPreamble[0x10]; // 0x168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FVector2D AudioLatencyMsMinMax; // 0x178 (Size: 0x10, Type: StructProperty)
    FVector2D VideoLatencyMsMinMax; // 0x188 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_198[0x28]; // 0x198 (Size: 0x28, Type: PaddingProperty)
    UFMCalibrationSaveData* CalibrationSaveData; // 0x1c0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void DisplayCalibrationWidget(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    float GetAudioLatencyMs() const; // 0x12182be4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMCalibrationSource GetAudioLatencySource() const; // 0x12182c0c (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetAudioVideoOffsetMs() const; // 0x12182c30 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMCalibrationSource GetAudioVideoOffsetSource() const; // 0x12182c58 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetCalibrationProfileIndex() const; // 0x12182c7c (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetCalibrometerDisplay() const; // 0x12182c94 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetHasBeenOfferedCalibration() const; // 0x12182cb8 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetHasTalkedWithRoadie() const; // 0x12182ce0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetInputLatencyMs() const; // 0x12182be4 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMCalibrationSource GetInputLatencySource() const; // 0x12182c0c (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsAutolaunchDisabled() const; // 0x12182d04 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsCalibrated() const; // 0x12182d28 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsCalibrationDebugEnabled() const; // 0x12182d4c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsPreambleDisabled() const; // 0x12182d7c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    APlayerController* GetOwningController() const; // 0x12182da0 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSystemAudioLatencyMs() const; // 0x12182dc4 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetVideoLatencyMs() const; // 0x12182df4 (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMCalibrationSource GetVideoLatencySource() const; // 0x12182c58 (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsOwnerPrimaryPlayer() const; // 0x12182e38 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void LoadCalibrationLocalToDevice(); // 0x12182e5c (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void OnCalibrationDataLoaded__DelegateSignature(); // 0x288a61c (Index: 0x17, Flags: MulticastDelegate|Public|Delegate)
    void OnCalibrationDataSaved__DelegateSignature(); // 0x288a61c (Index: 0x18, Flags: MulticastDelegate|Public|Delegate)
    void OnCalibrationRegisterPreamble__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, FGameplayTag& PreambleGameplayTag); // 0x288a61c (Index: 0x19, Flags: MulticastDelegate|Public|Delegate)
    void OnCalibrationRequestOpenModal__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& UsePreamble); // 0x288a61c (Index: 0x1a, Flags: MulticastDelegate|Public|Delegate)
    void OnCalibrometerDisplay__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& CalibrometerDisplay); // 0x288a61c (Index: 0x1c, Flags: MulticastDelegate|Public|Delegate)
    void OnHasTalkedWithRoadie__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& HasTalkedWithRoadie); // 0x288a61c (Index: 0x1d, Flags: MulticastDelegate|Public|Delegate)
    void OnIsAutolaunchDisabledUpdated__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& IsAutolaunchDisabled); // 0x288a61c (Index: 0x1e, Flags: MulticastDelegate|Public|Delegate)
    void OnIsCalibratedUpdated__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& IsCalibrated); // 0x288a61c (Index: 0x1f, Flags: MulticastDelegate|Public|Delegate)
    void OnIsCalibrationDebugEnabled__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& IsCalibrationDebugEnabled); // 0x288a61c (Index: 0x20, Flags: MulticastDelegate|Public|Delegate)
    void OnIsPreambleDisabledUpdated__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, bool& IsPreambleDisabled); // 0x288a61c (Index: 0x21, Flags: MulticastDelegate|Public|Delegate)
    void OnLatencyMsUpdated__DelegateSignature(UFMCalibrationControllerComponent*& CalibrationControllerComponent, float& LatencyMs); // 0x288a61c (Index: 0x22, Flags: MulticastDelegate|Public|Delegate)
    void SaveCalibrationLocalToDevice(); // 0x12182edc (Index: 0x23, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SendCalibrationAnalytics() const; // 0x12182ef0 (Index: 0x24, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|Const)
    void SendToggleModalMessage(AActor*& ContextActor, bool& UsePreamble, bool& bIsAutoLaunch); // 0x12182f04 (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)
    void SetAudioLatencyMs(float& LatencyMs, EFMCalibrationSource& Source); // 0x12183204 (Index: 0x26, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAudioLatencyMsFromSettingsSlider(float& LatencyMs); // 0x12183410 (Index: 0x27, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAudioVideoOffsetMs(float& OffsetMs, EFMCalibrationSource& Source); // 0x12183540 (Index: 0x28, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAudioVideoOffsetMsFromSettingsSlider(float& OffsetMs); // 0x1218374c (Index: 0x29, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCalibrationProfileIndex(int32_t& NewIndex); // 0x1218387c (Index: 0x2a, Flags: Final|Native|Public)
    void SetHasBeenOfferedCalibration(bool& bInHasBeenOfferedCalibration); // 0x121839a4 (Index: 0x2b, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetHasTalkedWithRoadie(bool& bHasTalkedWithRoadie); // 0x12183ad4 (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputLatencyMs(float& LatencyMs, EFMCalibrationSource& Source); // 0x12183bf0 (Index: 0x2d, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetInputLatencyMsFromSettingsSlider(float& LatencyMs); // 0x12183dfc (Index: 0x2e, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsAutolaunchDisabled(bool& bAutolaunchDisabled); // 0x12183f2c (Index: 0x2f, Flags: Final|Native|Public|BlueprintCallable)
    void SetIsCalibrated(bool& bCalibrated); // 0x12184048 (Index: 0x30, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsPreambleDisabled(bool& bPreambleDisabled); // 0x12184164 (Index: 0x31, Flags: Final|Native|Public|BlueprintCallable)
    void SetVideoLatencyMs(float& LatencyMs, EFMCalibrationSource& Source); // 0x12184280 (Index: 0x32, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetVideoLatencyMsFromSettingsSlider(float& OffsetMs); // 0x1218448c (Index: 0x33, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)

protected:
    bool IsCalibrationDataLoaded() const; // 0xf19bb04 (Index: 0x13, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsCalibrationDataOnLatestVersion() const; // 0x12182e1c (Index: 0x14, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void OnCalibrationSkipped(); // 0x12182e70 (Index: 0x1b, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFMCalibrationControllerComponent) == 0x1c8, "Size mismatch for UFMCalibrationControllerComponent");
static_assert(offsetof(UFMCalibrationControllerComponent, OnCalibrationDataLoaded) == 0xb8, "Offset mismatch for UFMCalibrationControllerComponent::OnCalibrationDataLoaded");
static_assert(offsetof(UFMCalibrationControllerComponent, OnCalibrationDataSaved) == 0xc8, "Offset mismatch for UFMCalibrationControllerComponent::OnCalibrationDataSaved");
static_assert(offsetof(UFMCalibrationControllerComponent, OnAudioLatencyMsUpdated) == 0xd8, "Offset mismatch for UFMCalibrationControllerComponent::OnAudioLatencyMsUpdated");
static_assert(offsetof(UFMCalibrationControllerComponent, OnVideoLatencyMsUpdated) == 0xe8, "Offset mismatch for UFMCalibrationControllerComponent::OnVideoLatencyMsUpdated");
static_assert(offsetof(UFMCalibrationControllerComponent, OnIsCalibratedUpdated) == 0xf8, "Offset mismatch for UFMCalibrationControllerComponent::OnIsCalibratedUpdated");
static_assert(offsetof(UFMCalibrationControllerComponent, OnIsPreambleDisabledUpdated) == 0x108, "Offset mismatch for UFMCalibrationControllerComponent::OnIsPreambleDisabledUpdated");
static_assert(offsetof(UFMCalibrationControllerComponent, OnIsAutolaunchDisabledUpdated) == 0x118, "Offset mismatch for UFMCalibrationControllerComponent::OnIsAutolaunchDisabledUpdated");
static_assert(offsetof(UFMCalibrationControllerComponent, OnIsCalibrationDebugEnabled) == 0x128, "Offset mismatch for UFMCalibrationControllerComponent::OnIsCalibrationDebugEnabled");
static_assert(offsetof(UFMCalibrationControllerComponent, OnCalibrometerDisplay) == 0x138, "Offset mismatch for UFMCalibrationControllerComponent::OnCalibrometerDisplay");
static_assert(offsetof(UFMCalibrationControllerComponent, OnHasTalkedWithRoadie) == 0x148, "Offset mismatch for UFMCalibrationControllerComponent::OnHasTalkedWithRoadie");
static_assert(offsetof(UFMCalibrationControllerComponent, OnCalibrationRequestOpenModal) == 0x158, "Offset mismatch for UFMCalibrationControllerComponent::OnCalibrationRequestOpenModal");
static_assert(offsetof(UFMCalibrationControllerComponent, OnCalibrationRegisterPreamble) == 0x168, "Offset mismatch for UFMCalibrationControllerComponent::OnCalibrationRegisterPreamble");
static_assert(offsetof(UFMCalibrationControllerComponent, AudioLatencyMsMinMax) == 0x178, "Offset mismatch for UFMCalibrationControllerComponent::AudioLatencyMsMinMax");
static_assert(offsetof(UFMCalibrationControllerComponent, VideoLatencyMsMinMax) == 0x188, "Offset mismatch for UFMCalibrationControllerComponent::VideoLatencyMsMinMax");
static_assert(offsetof(UFMCalibrationControllerComponent, CalibrationSaveData) == 0x1c0, "Offset mismatch for UFMCalibrationControllerComponent::CalibrationSaveData");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UFMCalibrationSaveData : public UObject
{
public:
    int32_t CalibrationProfileIndex; // 0x28 (Size: 0x4, Type: IntProperty)
    float AudioLatencyMs; // 0x2c (Size: 0x4, Type: FloatProperty)
    float VideoLatencyMs; // 0x30 (Size: 0x4, Type: FloatProperty)
    bool IsCalibrated; // 0x34 (Size: 0x1, Type: BoolProperty)
    bool IsPreambleDisabled; // 0x35 (Size: 0x1, Type: BoolProperty)
    bool IsAutolaunchDisabled; // 0x36 (Size: 0x1, Type: BoolProperty)
    bool HasTalkedWithRoadie; // 0x37 (Size: 0x1, Type: BoolProperty)
    int32_t SaveVersion; // 0x38 (Size: 0x4, Type: IntProperty)
    bool bHasBeenOfferedCalibration; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    TArray<FFMCalibrationProfileData> CalibrationProfiles; // 0x40 (Size: 0x10, Type: ArrayProperty)

public:
    bool GetHasBeenOfferedCalibration() const; // 0xee176d0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetHasBeenOfferedCalibration(bool& bNewHasBeenOfferedCalibration); // 0xee1a6d8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public)
};

static_assert(sizeof(UFMCalibrationSaveData) == 0x50, "Size mismatch for UFMCalibrationSaveData");
static_assert(offsetof(UFMCalibrationSaveData, CalibrationProfileIndex) == 0x28, "Offset mismatch for UFMCalibrationSaveData::CalibrationProfileIndex");
static_assert(offsetof(UFMCalibrationSaveData, AudioLatencyMs) == 0x2c, "Offset mismatch for UFMCalibrationSaveData::AudioLatencyMs");
static_assert(offsetof(UFMCalibrationSaveData, VideoLatencyMs) == 0x30, "Offset mismatch for UFMCalibrationSaveData::VideoLatencyMs");
static_assert(offsetof(UFMCalibrationSaveData, IsCalibrated) == 0x34, "Offset mismatch for UFMCalibrationSaveData::IsCalibrated");
static_assert(offsetof(UFMCalibrationSaveData, IsPreambleDisabled) == 0x35, "Offset mismatch for UFMCalibrationSaveData::IsPreambleDisabled");
static_assert(offsetof(UFMCalibrationSaveData, IsAutolaunchDisabled) == 0x36, "Offset mismatch for UFMCalibrationSaveData::IsAutolaunchDisabled");
static_assert(offsetof(UFMCalibrationSaveData, HasTalkedWithRoadie) == 0x37, "Offset mismatch for UFMCalibrationSaveData::HasTalkedWithRoadie");
static_assert(offsetof(UFMCalibrationSaveData, SaveVersion) == 0x38, "Offset mismatch for UFMCalibrationSaveData::SaveVersion");
static_assert(offsetof(UFMCalibrationSaveData, bHasBeenOfferedCalibration) == 0x3c, "Offset mismatch for UFMCalibrationSaveData::bHasBeenOfferedCalibration");
static_assert(offsetof(UFMCalibrationSaveData, CalibrationProfiles) == 0x40, "Offset mismatch for UFMCalibrationSaveData::CalibrationProfiles");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FFMEvent_Calibration_ToggleModal
{
    bool UsePreamble; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIsAutoLaunched; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FFMEvent_Calibration_ToggleModal) == 0x2, "Size mismatch for FFMEvent_Calibration_ToggleModal");
static_assert(offsetof(FFMEvent_Calibration_ToggleModal, UsePreamble) == 0x0, "Offset mismatch for FFMEvent_Calibration_ToggleModal::UsePreamble");
static_assert(offsetof(FFMEvent_Calibration_ToggleModal, bIsAutoLaunched) == 0x1, "Offset mismatch for FFMEvent_Calibration_ToggleModal::bIsAutoLaunched");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFMEvent_Calibration_ModalOpened
{
};

static_assert(sizeof(FFMEvent_Calibration_ModalOpened) == 0x1, "Size mismatch for FFMEvent_Calibration_ModalOpened");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFMEvent_Calibration_ModalClosed
{
};

static_assert(sizeof(FFMEvent_Calibration_ModalClosed) == 0x1, "Size mismatch for FFMEvent_Calibration_ModalClosed");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFMEvent_Calibration_ModalCloseToQuest
{
};

static_assert(sizeof(FFMEvent_Calibration_ModalCloseToQuest) == 0x1, "Size mismatch for FFMEvent_Calibration_ModalCloseToQuest");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFMEvent_Calibration_ModalSkipped
{
};

static_assert(sizeof(FFMEvent_Calibration_ModalSkipped) == 0x1, "Size mismatch for FFMEvent_Calibration_ModalSkipped");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFMEvent_Calibration_ForceClose
{
    bool IsClosed; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FFMEvent_Calibration_ForceClose) == 0x1, "Size mismatch for FFMEvent_Calibration_ForceClose");
static_assert(offsetof(FFMEvent_Calibration_ForceClose, IsClosed) == 0x0, "Offset mismatch for FFMEvent_Calibration_ForceClose::IsClosed");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFMCalibrationProfileData
{
    float InputLatencyMs; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t InputLatencySource; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float AudioVideoOffsetMs; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t AudioVideoOffsetSource; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFMCalibrationProfileData) == 0x10, "Size mismatch for FFMCalibrationProfileData");
static_assert(offsetof(FFMCalibrationProfileData, InputLatencyMs) == 0x0, "Offset mismatch for FFMCalibrationProfileData::InputLatencyMs");
static_assert(offsetof(FFMCalibrationProfileData, InputLatencySource) == 0x4, "Offset mismatch for FFMCalibrationProfileData::InputLatencySource");
static_assert(offsetof(FFMCalibrationProfileData, AudioVideoOffsetMs) == 0x8, "Offset mismatch for FFMCalibrationProfileData::AudioVideoOffsetMs");
static_assert(offsetof(FFMCalibrationProfileData, AudioVideoOffsetSource) == 0xc, "Offset mismatch for FFMCalibrationProfileData::AudioVideoOffsetSource");

