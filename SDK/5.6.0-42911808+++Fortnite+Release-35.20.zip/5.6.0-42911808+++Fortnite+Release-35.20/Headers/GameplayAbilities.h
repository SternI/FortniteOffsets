/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayAbilities
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTasks.h"
#include "DeveloperSettings.h"
#include "MovieScene.h"
#include "NetCore.h"
#include "IrisCore.h"
#include "GameplayTags.h"
#include "DataRegistry.h"
#include "PhysicsCore.h"
#include "Niagara.h"

// Size: 0xf0 (Inherited: 0x310, Single: 0xfffffde0)
class UB_BRAccoladesPlayerComponent_C : public UFortControllerComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xc0 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* Player_Pawn; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Gameplay_Tags; // 0xd0 (Size: 0x20, Type: StructProperty)

public:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UB_BRAccoladesPlayerComponent_C) == 0xf0, "Size mismatch for UB_BRAccoladesPlayerComponent_C");
static_assert(offsetof(UB_BRAccoladesPlayerComponent_C, UberGraphFrame) == 0xc0, "Offset mismatch for UB_BRAccoladesPlayerComponent_C::UberGraphFrame");
static_assert(offsetof(UB_BRAccoladesPlayerComponent_C, Player_Pawn) == 0xc8, "Offset mismatch for UB_BRAccoladesPlayerComponent_C::Player_Pawn");
static_assert(offsetof(UB_BRAccoladesPlayerComponent_C, Gameplay_Tags) == 0xd0, "Offset mismatch for UB_BRAccoladesPlayerComponent_C::Gameplay_Tags");

// Size: 0x398 (Inherited: 0x668, Single: 0xfffffd30)
class AAbilitySystemDebugHUD : public AHUD
{
public:
};

static_assert(sizeof(AAbilitySystemDebugHUD) == 0x398, "Size mismatch for AAbilitySystemDebugHUD");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UAbilitiesGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<FGameplayAbilitySpecConfig> GrantAbilityConfigs; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAbilitiesGameplayEffectComponent) == 0x38, "Size mismatch for UAbilitiesGameplayEffectComponent");
static_assert(offsetof(UAbilitiesGameplayEffectComponent, GrantAbilityConfigs) == 0x28, "Offset mismatch for UAbilitiesGameplayEffectComponent::GrantAbilityConfigs");

// Size: 0xa68 (Inherited: 0x28, Single: 0xa40)
class UGameplayEffect : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    uint8_t DurationPolicy; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FGameplayEffectModifierMagnitude DurationMagnitude; // 0x38 (Size: 0x1d8, Type: StructProperty)
    FScalableFloat Period; // 0x210 (Size: 0x28, Type: StructProperty)
    bool bExecutePeriodicEffectOnApplication; // 0x238 (Size: 0x1, Type: BoolProperty)
    uint8_t PeriodicInhibitionPolicy; // 0x239 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_23a[0x6]; // 0x23a (Size: 0x6, Type: PaddingProperty)
    TArray<FGameplayModifierInfo> Modifiers; // 0x240 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayEffectExecutionDefinition> Executions; // 0x250 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat ChanceToApplyToTarget; // 0x260 (Size: 0x28, Type: StructProperty)
    TArray<UClass*> ApplicationRequirements; // 0x288 (Size: 0x10, Type: ArrayProperty)
    TArray<FConditionalGameplayEffect> ConditionalGameplayEffects; // 0x298 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OverflowEffects; // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    bool bDenyOverflowApplication; // 0x2b8 (Size: 0x1, Type: BoolProperty)
    bool bClearStackOnOverflow; // 0x2b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ba[0x6]; // 0x2ba (Size: 0x6, Type: PaddingProperty)
    TArray<UClass*> PrematureExpirationEffectClasses; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> RoutineExpirationEffectClasses; // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    bool bRequireModifierSuccessToTriggerCues; // 0x2e0 (Size: 0x1, Type: BoolProperty)
    bool bSuppressStackingCues; // 0x2e1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e2[0x6]; // 0x2e2 (Size: 0x6, Type: PaddingProperty)
    TArray<FGameplayEffectCue> GameplayCues; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    UGameplayEffectUIData* UIData; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    FInheritedTagContainer InheritableGameplayEffectTags; // 0x300 (Size: 0x60, Type: StructProperty)
    FInheritedTagContainer InheritableOwnedTagsContainer; // 0x360 (Size: 0x60, Type: StructProperty)
    FInheritedTagContainer InheritableBlockedAbilityTagsContainer; // 0x3c0 (Size: 0x60, Type: StructProperty)
    FGameplayTagRequirements OngoingTagRequirements; // 0x420 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements ApplicationTagRequirements; // 0x4a8 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements RemovalTagRequirements; // 0x530 (Size: 0x88, Type: StructProperty)
    FInheritedTagContainer RemoveGameplayEffectsWithTags; // 0x5b8 (Size: 0x60, Type: StructProperty)
    FGameplayTagRequirements GrantedApplicationImmunityTags; // 0x618 (Size: 0x88, Type: StructProperty)
    FGameplayEffectQuery GrantedApplicationImmunityQuery; // 0x6a0 (Size: 0x198, Type: StructProperty)
    uint8_t Pad_838[0x8]; // 0x838 (Size: 0x8, Type: PaddingProperty)
    FGameplayEffectQuery RemoveGameplayEffectQuery; // 0x840 (Size: 0x198, Type: StructProperty)
    uint8_t Pad_9d8[0x1]; // 0x9d8 (Size: 0x1, Type: PaddingProperty)
    uint8_t StackingType; // 0x9d9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9da[0x2]; // 0x9da (Size: 0x2, Type: PaddingProperty)
    int32_t StackLimitCount; // 0x9dc (Size: 0x4, Type: IntProperty)
    uint8_t StackDurationRefreshPolicy; // 0x9e0 (Size: 0x1, Type: EnumProperty)
    uint8_t StackPeriodResetPolicy; // 0x9e1 (Size: 0x1, Type: EnumProperty)
    uint8_t StackExpirationPolicy; // 0x9e2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9e3[0x5]; // 0x9e3 (Size: 0x5, Type: PaddingProperty)
    TArray<FGameplayAbilitySpecDef> GrantedAbilities; // 0x9e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_9f8[0x60]; // 0x9f8 (Size: 0x60, Type: PaddingProperty)
    TArray<UGameplayEffectComponent*> GEComponents; // 0xa58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayEffect) == 0xa68, "Size mismatch for UGameplayEffect");
static_assert(offsetof(UGameplayEffect, DurationPolicy) == 0x30, "Offset mismatch for UGameplayEffect::DurationPolicy");
static_assert(offsetof(UGameplayEffect, DurationMagnitude) == 0x38, "Offset mismatch for UGameplayEffect::DurationMagnitude");
static_assert(offsetof(UGameplayEffect, Period) == 0x210, "Offset mismatch for UGameplayEffect::Period");
static_assert(offsetof(UGameplayEffect, bExecutePeriodicEffectOnApplication) == 0x238, "Offset mismatch for UGameplayEffect::bExecutePeriodicEffectOnApplication");
static_assert(offsetof(UGameplayEffect, PeriodicInhibitionPolicy) == 0x239, "Offset mismatch for UGameplayEffect::PeriodicInhibitionPolicy");
static_assert(offsetof(UGameplayEffect, Modifiers) == 0x240, "Offset mismatch for UGameplayEffect::Modifiers");
static_assert(offsetof(UGameplayEffect, Executions) == 0x250, "Offset mismatch for UGameplayEffect::Executions");
static_assert(offsetof(UGameplayEffect, ChanceToApplyToTarget) == 0x260, "Offset mismatch for UGameplayEffect::ChanceToApplyToTarget");
static_assert(offsetof(UGameplayEffect, ApplicationRequirements) == 0x288, "Offset mismatch for UGameplayEffect::ApplicationRequirements");
static_assert(offsetof(UGameplayEffect, ConditionalGameplayEffects) == 0x298, "Offset mismatch for UGameplayEffect::ConditionalGameplayEffects");
static_assert(offsetof(UGameplayEffect, OverflowEffects) == 0x2a8, "Offset mismatch for UGameplayEffect::OverflowEffects");
static_assert(offsetof(UGameplayEffect, bDenyOverflowApplication) == 0x2b8, "Offset mismatch for UGameplayEffect::bDenyOverflowApplication");
static_assert(offsetof(UGameplayEffect, bClearStackOnOverflow) == 0x2b9, "Offset mismatch for UGameplayEffect::bClearStackOnOverflow");
static_assert(offsetof(UGameplayEffect, PrematureExpirationEffectClasses) == 0x2c0, "Offset mismatch for UGameplayEffect::PrematureExpirationEffectClasses");
static_assert(offsetof(UGameplayEffect, RoutineExpirationEffectClasses) == 0x2d0, "Offset mismatch for UGameplayEffect::RoutineExpirationEffectClasses");
static_assert(offsetof(UGameplayEffect, bRequireModifierSuccessToTriggerCues) == 0x2e0, "Offset mismatch for UGameplayEffect::bRequireModifierSuccessToTriggerCues");
static_assert(offsetof(UGameplayEffect, bSuppressStackingCues) == 0x2e1, "Offset mismatch for UGameplayEffect::bSuppressStackingCues");
static_assert(offsetof(UGameplayEffect, GameplayCues) == 0x2e8, "Offset mismatch for UGameplayEffect::GameplayCues");
static_assert(offsetof(UGameplayEffect, UIData) == 0x2f8, "Offset mismatch for UGameplayEffect::UIData");
static_assert(offsetof(UGameplayEffect, InheritableGameplayEffectTags) == 0x300, "Offset mismatch for UGameplayEffect::InheritableGameplayEffectTags");
static_assert(offsetof(UGameplayEffect, InheritableOwnedTagsContainer) == 0x360, "Offset mismatch for UGameplayEffect::InheritableOwnedTagsContainer");
static_assert(offsetof(UGameplayEffect, InheritableBlockedAbilityTagsContainer) == 0x3c0, "Offset mismatch for UGameplayEffect::InheritableBlockedAbilityTagsContainer");
static_assert(offsetof(UGameplayEffect, OngoingTagRequirements) == 0x420, "Offset mismatch for UGameplayEffect::OngoingTagRequirements");
static_assert(offsetof(UGameplayEffect, ApplicationTagRequirements) == 0x4a8, "Offset mismatch for UGameplayEffect::ApplicationTagRequirements");
static_assert(offsetof(UGameplayEffect, RemovalTagRequirements) == 0x530, "Offset mismatch for UGameplayEffect::RemovalTagRequirements");
static_assert(offsetof(UGameplayEffect, RemoveGameplayEffectsWithTags) == 0x5b8, "Offset mismatch for UGameplayEffect::RemoveGameplayEffectsWithTags");
static_assert(offsetof(UGameplayEffect, GrantedApplicationImmunityTags) == 0x618, "Offset mismatch for UGameplayEffect::GrantedApplicationImmunityTags");
static_assert(offsetof(UGameplayEffect, GrantedApplicationImmunityQuery) == 0x6a0, "Offset mismatch for UGameplayEffect::GrantedApplicationImmunityQuery");
static_assert(offsetof(UGameplayEffect, RemoveGameplayEffectQuery) == 0x840, "Offset mismatch for UGameplayEffect::RemoveGameplayEffectQuery");
static_assert(offsetof(UGameplayEffect, StackingType) == 0x9d9, "Offset mismatch for UGameplayEffect::StackingType");
static_assert(offsetof(UGameplayEffect, StackLimitCount) == 0x9dc, "Offset mismatch for UGameplayEffect::StackLimitCount");
static_assert(offsetof(UGameplayEffect, StackDurationRefreshPolicy) == 0x9e0, "Offset mismatch for UGameplayEffect::StackDurationRefreshPolicy");
static_assert(offsetof(UGameplayEffect, StackPeriodResetPolicy) == 0x9e1, "Offset mismatch for UGameplayEffect::StackPeriodResetPolicy");
static_assert(offsetof(UGameplayEffect, StackExpirationPolicy) == 0x9e2, "Offset mismatch for UGameplayEffect::StackExpirationPolicy");
static_assert(offsetof(UGameplayEffect, GrantedAbilities) == 0x9e8, "Offset mismatch for UGameplayEffect::GrantedAbilities");
static_assert(offsetof(UGameplayEffect, GEComponents) == 0xa58, "Offset mismatch for UGameplayEffect::GEComponents");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGameplayEffectComponent : public UObject
{
public:
};

static_assert(sizeof(UGameplayEffectComponent) == 0x28, "Size mismatch for UGameplayEffectComponent");

// Size: 0x58 (Inherited: 0xc0, Single: 0xffffff98)
class UAbilityAsync_WaitGameplayTagCountChanged : public UAbilityAsync
{
public:
    uint8_t Pad_38[0x10]; // 0x38 (Size: 0x10, Type: PaddingProperty)
    uint8_t TagCountChanged[0x10]; // 0x48 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void AsyncWaitGameplayTagCountDelegate__DelegateSignature(int32_t& TagCount); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    static UAbilityAsync_WaitGameplayTagCountChanged* WaitGameplayTagCountChangedOnActor(AActor*& TargetActor, FGameplayTag& Tag); // 0x4aa3d64 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayTagCountChanged) == 0x58, "Size mismatch for UAbilityAsync_WaitGameplayTagCountChanged");
static_assert(offsetof(UAbilityAsync_WaitGameplayTagCountChanged, TagCountChanged) == 0x48, "Offset mismatch for UAbilityAsync_WaitGameplayTagCountChanged::TagCountChanged");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UAbilityAsync : public UCancellableAsyncAction
{
public:

public:
    void EndAction(); // 0x5ba16d4 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync) == 0x38, "Size mismatch for UAbilityAsync");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAbilitySystemCheatManagerExtension : public UCheatManagerExtension
{
public:

public:
    void AbilityActivate(FString& PartialName) const; // 0xb7a09e0 (Index: 0x0, Flags: Final|Exec|Native|Public|Const)
    void AbilityCancel(FString& PartialName) const; // 0xb7a0cd4 (Index: 0x1, Flags: Final|Exec|Native|Public|Const)
    void AbilityGrant(FString& AssetSearchString) const; // 0xb7a0fc8 (Index: 0x2, Flags: Final|Exec|Native|Public|Const)
    void AbilityListGranted() const; // 0xb7a12bc (Index: 0x3, Flags: Final|Exec|Native|Public|Const)
    void EffectApply(FString& PartialName, float& EffectLevel) const; // 0xb7a2f44 (Index: 0x4, Flags: Final|Exec|Native|Public|Const)
    void EffectListActive() const; // 0xb7a3314 (Index: 0x5, Flags: Final|Exec|Native|Public|Const)
    void EffectRemove(FString& NameOrHandle) const; // 0xb7a3328 (Index: 0x6, Flags: Final|Exec|Native|Public|Const)
};

static_assert(sizeof(UAbilitySystemCheatManagerExtension) == 0x28, "Size mismatch for UAbilitySystemCheatManagerExtension");

// Size: 0x128 (Inherited: 0x100, Single: 0x28)
class UAbilityTask_PlayAnimAndWait : public UAbilityTask
{
public:
    uint8_t OnCompleted[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBlendOut[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBlendIn[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInterrupted[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCancelled[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_c8[0x38]; // 0xc8 (Size: 0x38, Type: PaddingProperty)
    UAnimSequence* AnimSequenceToPlay; // 0x100 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_108[0x20]; // 0x108 (Size: 0x20, Type: PaddingProperty)

public:
    static UAbilityTask_PlayAnimAndWait* CreatePlayAnimAndWaitProxy(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, UAnimSequence*& AnimSequence, FName& SlotName, float& BlendInTime, float& BlendOutTime, float& InPlayRate, float& StartTimeSeconds, bool& bStopWhenAbilityEnds, float& AnimRootMotionTranslationScale, float& InPlayCount); // 0xb7a2788 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    void OnMontageBlendedIn(UAnimMontage*& Montage); // 0xb7a5ac8 (Index: 0x1, Flags: Final|Native|Public)
    void OnMontageBlendingOut(UAnimMontage*& Montage, bool& bInterrupted); // 0xb7a5bf4 (Index: 0x2, Flags: Final|Native|Public)
    void OnMontageEnded(UAnimMontage*& Montage, bool& bInterrupted); // 0xb7a5e00 (Index: 0x3, Flags: Final|Native|Public)
    void OnMontageInterrupted(); // 0xb7a600c (Index: 0x4, Flags: Final|Native|Public)
};

static_assert(sizeof(UAbilityTask_PlayAnimAndWait) == 0x128, "Size mismatch for UAbilityTask_PlayAnimAndWait");
static_assert(offsetof(UAbilityTask_PlayAnimAndWait, OnCompleted) == 0x78, "Offset mismatch for UAbilityTask_PlayAnimAndWait::OnCompleted");
static_assert(offsetof(UAbilityTask_PlayAnimAndWait, OnBlendOut) == 0x88, "Offset mismatch for UAbilityTask_PlayAnimAndWait::OnBlendOut");
static_assert(offsetof(UAbilityTask_PlayAnimAndWait, OnBlendIn) == 0x98, "Offset mismatch for UAbilityTask_PlayAnimAndWait::OnBlendIn");
static_assert(offsetof(UAbilityTask_PlayAnimAndWait, OnInterrupted) == 0xa8, "Offset mismatch for UAbilityTask_PlayAnimAndWait::OnInterrupted");
static_assert(offsetof(UAbilityTask_PlayAnimAndWait, OnCancelled) == 0xb8, "Offset mismatch for UAbilityTask_PlayAnimAndWait::OnCancelled");
static_assert(offsetof(UAbilityTask_PlayAnimAndWait, AnimSequenceToPlay) == 0x100, "Offset mismatch for UAbilityTask_PlayAnimAndWait::AnimSequenceToPlay");

// Size: 0x78 (Inherited: 0x88, Single: 0xfffffff0)
class UAbilityTask : public UGameplayTask
{
public:
    UGameplayAbility* ability; // 0x60 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> AbilitySystemComponent; // 0x68 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_70[0x8]; // 0x70 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UAbilityTask) == 0x78, "Size mismatch for UAbilityTask");
static_assert(offsetof(UAbilityTask, ability) == 0x60, "Offset mismatch for UAbilityTask::ability");
static_assert(offsetof(UAbilityTask, AbilitySystemComponent) == 0x68, "Offset mismatch for UAbilityTask::AbilitySystemComponent");

// Size: 0xa0 (Inherited: 0x100, Single: 0xffffffa0)
class UAbilityTask_WaitGameplayTagCountChanged : public UAbilityTask
{
public:
    uint8_t TagCountChanged[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    UAbilitySystemComponent* OptionalExternalTarget; // 0x90 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_98[0x8]; // 0x98 (Size: 0x8, Type: PaddingProperty)

protected:
    static UAbilityTask_WaitGameplayTagCountChanged* WaitGameplayTagCountChange(UGameplayAbility*& OwningAbility, FGameplayTag& Tag, AActor*& InOptionalExternalTarget); // 0xb7a6870 (Index: 0x0, Flags: Final|Native|Static|Protected|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayTagCountChanged) == 0xa0, "Size mismatch for UAbilityTask_WaitGameplayTagCountChanged");
static_assert(offsetof(UAbilityTask_WaitGameplayTagCountChanged, TagCountChanged) == 0x78, "Offset mismatch for UAbilityTask_WaitGameplayTagCountChanged::TagCountChanged");
static_assert(offsetof(UAbilityTask_WaitGameplayTagCountChanged, OptionalExternalTarget) == 0x90, "Offset mismatch for UAbilityTask_WaitGameplayTagCountChanged::OptionalExternalTarget");

// Size: 0x70 (Inherited: 0x50, Single: 0x20)
class UAdditionalEffectsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    bool bOnApplicationCopyDataFromOriginalSpec; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TArray<FConditionalGameplayEffect> OnApplicationGameplayEffects; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OnCompleteAlways; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OnCompleteNormal; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> OnCompletePrematurely; // 0x60 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAdditionalEffectsGameplayEffectComponent) == 0x70, "Size mismatch for UAdditionalEffectsGameplayEffectComponent");
static_assert(offsetof(UAdditionalEffectsGameplayEffectComponent, bOnApplicationCopyDataFromOriginalSpec) == 0x28, "Offset mismatch for UAdditionalEffectsGameplayEffectComponent::bOnApplicationCopyDataFromOriginalSpec");
static_assert(offsetof(UAdditionalEffectsGameplayEffectComponent, OnApplicationGameplayEffects) == 0x30, "Offset mismatch for UAdditionalEffectsGameplayEffectComponent::OnApplicationGameplayEffects");
static_assert(offsetof(UAdditionalEffectsGameplayEffectComponent, OnCompleteAlways) == 0x40, "Offset mismatch for UAdditionalEffectsGameplayEffectComponent::OnCompleteAlways");
static_assert(offsetof(UAdditionalEffectsGameplayEffectComponent, OnCompleteNormal) == 0x50, "Offset mismatch for UAdditionalEffectsGameplayEffectComponent::OnCompleteNormal");
static_assert(offsetof(UAdditionalEffectsGameplayEffectComponent, OnCompletePrematurely) == 0x60, "Offset mismatch for UAdditionalEffectsGameplayEffectComponent::OnCompletePrematurely");

// Size: 0x88 (Inherited: 0x50, Single: 0x38)
class UAssetTagsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FInheritedTagContainer InheritableAssetTags; // 0x28 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(UAssetTagsGameplayEffectComponent) == 0x88, "Size mismatch for UAssetTagsGameplayEffectComponent");
static_assert(offsetof(UAssetTagsGameplayEffectComponent, InheritableAssetTags) == 0x28, "Offset mismatch for UAssetTagsGameplayEffectComponent::InheritableAssetTags");

// Size: 0x88 (Inherited: 0x50, Single: 0x38)
class UBlockAbilityTagsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FInheritedTagContainer InheritableBlockedAbilityTagsContainer; // 0x28 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(UBlockAbilityTagsGameplayEffectComponent) == 0x88, "Size mismatch for UBlockAbilityTagsGameplayEffectComponent");
static_assert(offsetof(UBlockAbilityTagsGameplayEffectComponent, InheritableBlockedAbilityTagsContainer) == 0x28, "Offset mismatch for UBlockAbilityTagsGameplayEffectComponent::InheritableBlockedAbilityTagsContainer");

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
class UChanceToApplyGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FScalableFloat ChanceToApplyToTarget; // 0x28 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UChanceToApplyGameplayEffectComponent) == 0x50, "Size mismatch for UChanceToApplyGameplayEffectComponent");
static_assert(offsetof(UChanceToApplyGameplayEffectComponent, ChanceToApplyToTarget) == 0x28, "Offset mismatch for UChanceToApplyGameplayEffectComponent::ChanceToApplyToTarget");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UCustomCanApplyGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<UClass*> ApplicationRequirements; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCustomCanApplyGameplayEffectComponent) == 0x38, "Size mismatch for UCustomCanApplyGameplayEffectComponent");
static_assert(offsetof(UCustomCanApplyGameplayEffectComponent, ApplicationRequirements) == 0x28, "Offset mismatch for UCustomCanApplyGameplayEffectComponent::ApplicationRequirements");

// Size: 0x138 (Inherited: 0x58, Single: 0xe0)
class UGameplayAbilitiesDeveloperSettings : public UDeveloperSettings
{
public:
    FSoftClassPath AbilitySystemGlobalsClassName; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bUseDebugTargetFromHud; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    TArray<FSoftObjectPath> GlobalAttributeSetDefaultsTableNames; // 0x50 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GlobalAttributeMetaDataTableName; // 0x60 (Size: 0x18, Type: StructProperty)
    FSoftClassPath GlobalGameplayCueManagerClass; // 0x78 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath GlobalGameplayCueManagerName; // 0x90 (Size: 0x18, Type: StructProperty)
    TArray<FString> GameplayCueNotifyPaths; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GlobalCurveTableName; // 0xb8 (Size: 0x18, Type: StructProperty)
    bool PredictTargetGameplayEffects; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool ReplicateActivationOwnedTags; // 0xd1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d2[0x2]; // 0xd2 (Size: 0x2, Type: PaddingProperty)
    FGameplayTag ActivateFailCanActivateAbilityTag; // 0xd4 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailCooldownTag; // 0xd8 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailCostTag; // 0xdc (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailNetworkingTag; // 0xe0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailTagsBlockedTag; // 0xe4 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateFailTagsMissingTag; // 0xe8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
    FSoftObjectPath GameplayTagResponseTableName; // 0xf0 (Size: 0x18, Type: StructProperty)
    bool bAllowGameplayModEvaluationChannels; // 0x108 (Size: 0x1, Type: BoolProperty)
    uint8_t DefaultGameplayModEvaluationChannel; // 0x109 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_10a[0x2]; // 0x10a (Size: 0x2, Type: PaddingProperty)
    FName GameplayModEvaluationChannelAliases[0xa]; // 0x10c (Size: 0x28, Type: NameProperty)
    int32_t MinimalReplicationTagCountBits; // 0x134 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UGameplayAbilitiesDeveloperSettings) == 0x138, "Size mismatch for UGameplayAbilitiesDeveloperSettings");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, AbilitySystemGlobalsClassName) == 0x30, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::AbilitySystemGlobalsClassName");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, bUseDebugTargetFromHud) == 0x48, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::bUseDebugTargetFromHud");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GlobalAttributeSetDefaultsTableNames) == 0x50, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GlobalAttributeSetDefaultsTableNames");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GlobalAttributeMetaDataTableName) == 0x60, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GlobalAttributeMetaDataTableName");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GlobalGameplayCueManagerClass) == 0x78, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GlobalGameplayCueManagerClass");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GlobalGameplayCueManagerName) == 0x90, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GlobalGameplayCueManagerName");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GameplayCueNotifyPaths) == 0xa8, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GameplayCueNotifyPaths");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GlobalCurveTableName) == 0xb8, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GlobalCurveTableName");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, PredictTargetGameplayEffects) == 0xd0, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::PredictTargetGameplayEffects");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ReplicateActivationOwnedTags) == 0xd1, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ReplicateActivationOwnedTags");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ActivateFailCanActivateAbilityTag) == 0xd4, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ActivateFailCanActivateAbilityTag");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ActivateFailCooldownTag) == 0xd8, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ActivateFailCooldownTag");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ActivateFailCostTag) == 0xdc, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ActivateFailCostTag");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ActivateFailNetworkingTag) == 0xe0, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ActivateFailNetworkingTag");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ActivateFailTagsBlockedTag) == 0xe4, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ActivateFailTagsBlockedTag");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, ActivateFailTagsMissingTag) == 0xe8, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::ActivateFailTagsMissingTag");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GameplayTagResponseTableName) == 0xf0, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GameplayTagResponseTableName");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, bAllowGameplayModEvaluationChannels) == 0x108, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::bAllowGameplayModEvaluationChannels");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, DefaultGameplayModEvaluationChannel) == 0x109, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::DefaultGameplayModEvaluationChannel");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, GameplayModEvaluationChannelAliases) == 0x10c, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::GameplayModEvaluationChannelAliases");
static_assert(offsetof(UGameplayAbilitiesDeveloperSettings, MinimalReplicationTagCountBits) == 0x134, "Offset mismatch for UGameplayAbilitiesDeveloperSettings::MinimalReplicationTagCountBits");

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UGameplayAbilitiesEditorDeveloperSettings : public UDeveloperSettingsBackedByCVars
{
public:
    bool bIgnoreCooldowns; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreCosts; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float AbilitySystemGlobalScaler; // 0x34 (Size: 0x4, Type: FloatProperty)
    float DebugDrawMaxDistance; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayAbilitiesEditorDeveloperSettings) == 0x40, "Size mismatch for UGameplayAbilitiesEditorDeveloperSettings");
static_assert(offsetof(UGameplayAbilitiesEditorDeveloperSettings, bIgnoreCooldowns) == 0x30, "Offset mismatch for UGameplayAbilitiesEditorDeveloperSettings::bIgnoreCooldowns");
static_assert(offsetof(UGameplayAbilitiesEditorDeveloperSettings, bIgnoreCosts) == 0x31, "Offset mismatch for UGameplayAbilitiesEditorDeveloperSettings::bIgnoreCosts");
static_assert(offsetof(UGameplayAbilitiesEditorDeveloperSettings, AbilitySystemGlobalScaler) == 0x34, "Offset mismatch for UGameplayAbilitiesEditorDeveloperSettings::AbilitySystemGlobalScaler");
static_assert(offsetof(UGameplayAbilitiesEditorDeveloperSettings, DebugDrawMaxDistance) == 0x38, "Offset mismatch for UGameplayAbilitiesEditorDeveloperSettings::DebugDrawMaxDistance");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UGameplayCueNotify_UnitTest : public UGameplayCueNotify_Static
{
public:
};

static_assert(sizeof(UGameplayCueNotify_UnitTest) == 0x48, "Size mismatch for UGameplayCueNotify_UnitTest");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGameplayCueNotify_Static : public UObject
{
public:
    FGameplayTag GameplayCueTag; // 0x28 (Size: 0x4, Type: StructProperty)
    FName GameplayCueName; // 0x2c (Size: 0x4, Type: NameProperty)
    bool IsOverride; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)

public:
    virtual void K2_HandleGameplayCue(AActor*& MyTarget, TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    virtual bool OnActive(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0xb83c37c (Index: 0x1, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool OnExecute(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0xb83c774 (Index: 0x2, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool OnRemove(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0xb83c970 (Index: 0x3, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool WhileActive(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0xb83cb6c (Index: 0x4, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UGameplayCueNotify_Static) == 0x38, "Size mismatch for UGameplayCueNotify_Static");
static_assert(offsetof(UGameplayCueNotify_Static, GameplayCueTag) == 0x28, "Offset mismatch for UGameplayCueNotify_Static::GameplayCueTag");
static_assert(offsetof(UGameplayCueNotify_Static, GameplayCueName) == 0x2c, "Offset mismatch for UGameplayCueNotify_Static::GameplayCueName");
static_assert(offsetof(UGameplayCueNotify_Static, IsOverride) == 0x30, "Offset mismatch for UGameplayCueNotify_Static::IsOverride");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayEffectUIData : public UGameplayEffectComponent
{
public:
};

static_assert(sizeof(UGameplayEffectUIData) == 0x28, "Size mismatch for UGameplayEffectUIData");

// Size: 0x38 (Inherited: 0x78, Single: 0xffffffc0)
class UGameplayEffectUIData_TextOnly : public UGameplayEffectUIData
{
public:
    FText Description; // 0x28 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(UGameplayEffectUIData_TextOnly) == 0x38, "Size mismatch for UGameplayEffectUIData_TextOnly");
static_assert(offsetof(UGameplayEffectUIData_TextOnly, Description) == 0x28, "Offset mismatch for UGameplayEffectUIData_TextOnly::Description");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UImmunityGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<FGameplayEffectQuery> ImmunityQueries; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UImmunityGameplayEffectComponent) == 0x38, "Size mismatch for UImmunityGameplayEffectComponent");
static_assert(offsetof(UImmunityGameplayEffectComponent, ImmunityQueries) == 0x28, "Offset mismatch for UImmunityGameplayEffectComponent::ImmunityQueries");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class URemoveOtherGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    TArray<FGameplayEffectQuery> RemoveGameplayEffectQueries; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(URemoveOtherGameplayEffectComponent) == 0x38, "Size mismatch for URemoveOtherGameplayEffectComponent");
static_assert(offsetof(URemoveOtherGameplayEffectComponent, RemoveGameplayEffectQueries) == 0x28, "Offset mismatch for URemoveOtherGameplayEffectComponent::RemoveGameplayEffectQueries");

// Size: 0x1c0 (Inherited: 0x50, Single: 0x170)
class UTargetTagRequirementsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FGameplayTagRequirements ApplicationTagRequirements; // 0x28 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements OngoingTagRequirements; // 0xb0 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements RemovalTagRequirements; // 0x138 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(UTargetTagRequirementsGameplayEffectComponent) == 0x1c0, "Size mismatch for UTargetTagRequirementsGameplayEffectComponent");
static_assert(offsetof(UTargetTagRequirementsGameplayEffectComponent, ApplicationTagRequirements) == 0x28, "Offset mismatch for UTargetTagRequirementsGameplayEffectComponent::ApplicationTagRequirements");
static_assert(offsetof(UTargetTagRequirementsGameplayEffectComponent, OngoingTagRequirements) == 0xb0, "Offset mismatch for UTargetTagRequirementsGameplayEffectComponent::OngoingTagRequirements");
static_assert(offsetof(UTargetTagRequirementsGameplayEffectComponent, RemovalTagRequirements) == 0x138, "Offset mismatch for UTargetTagRequirementsGameplayEffectComponent::RemovalTagRequirements");

// Size: 0x88 (Inherited: 0x50, Single: 0x38)
class UTargetTagsGameplayEffectComponent : public UGameplayEffectComponent
{
public:
    FInheritedTagContainer InheritableGrantedTagsContainer; // 0x28 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(UTargetTagsGameplayEffectComponent) == 0x88, "Size mismatch for UTargetTagsGameplayEffectComponent");
static_assert(offsetof(UTargetTagsGameplayEffectComponent, InheritableGrantedTagsContainer) == 0x28, "Offset mismatch for UTargetTagsGameplayEffectComponent::InheritableGrantedTagsContainer");

// Size: 0x90 (Inherited: 0xc0, Single: 0xffffffd0)
class UAbilityAsync_WaitAttributeChanged : public UAbilityAsync
{
public:
    uint8_t Changed[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_48[0x48]; // 0x48 (Size: 0x48, Type: PaddingProperty)

public:
    void AsyncWaitAttributeChangedDelegate__DelegateSignature(FGameplayAttribute& Attribute, float& NewValue, float& OldValue); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    static UAbilityAsync_WaitAttributeChanged* WaitForAttributeChanged(AActor*& TargetActor, FGameplayAttribute& Attribute, bool& OnlyTriggerOnce); // 0x4aa49dc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitAttributeChanged) == 0x90, "Size mismatch for UAbilityAsync_WaitAttributeChanged");
static_assert(offsetof(UAbilityAsync_WaitAttributeChanged, Changed) == 0x38, "Offset mismatch for UAbilityAsync_WaitAttributeChanged::Changed");

// Size: 0x188 (Inherited: 0xc0, Single: 0xc8)
class UAbilityAsync_WaitGameplayEffectApplied : public UAbilityAsync
{
public:
    uint8_t OnApplied[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_48[0x140]; // 0x48 (Size: 0x140, Type: PaddingProperty)

public:
    void OnAppliedDelegate__DelegateSignature(AActor*& Source, FGameplayEffectSpecHandle& SpecHandle, FActiveGameplayEffectHandle& ActiveHandle); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    static UAbilityAsync_WaitGameplayEffectApplied* WaitGameplayEffectAppliedToActor(AActor*& TargetActor, FGameplayTargetDataFilterHandle& const SourceFilter, FGameplayTagRequirements& SourceTagRequirements, FGameplayTagRequirements& TargetTagRequirements, bool& TriggerOnce, bool& ListenForPeriodicEffect); // 0xb7a6414 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayEffectApplied) == 0x188, "Size mismatch for UAbilityAsync_WaitGameplayEffectApplied");
static_assert(offsetof(UAbilityAsync_WaitGameplayEffectApplied, OnApplied) == 0x38, "Offset mismatch for UAbilityAsync_WaitGameplayEffectApplied::OnApplied");

// Size: 0x58 (Inherited: 0xc0, Single: 0xffffff98)
class UAbilityAsync_WaitGameplayEvent : public UAbilityAsync
{
public:
    uint8_t EventReceived[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_48[0x10]; // 0x48 (Size: 0x10, Type: PaddingProperty)

public:
    void EventReceivedDelegate__DelegateSignature(FGameplayEventData& Payload); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    static UAbilityAsync_WaitGameplayEvent* WaitGameplayEventToActor(AActor*& TargetActor, FGameplayTag& EventTag, bool& OnlyTriggerOnce, bool& OnlyMatchExact); // 0x4aa4180 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayEvent) == 0x58, "Size mismatch for UAbilityAsync_WaitGameplayEvent");
static_assert(offsetof(UAbilityAsync_WaitGameplayEvent, EventReceived) == 0x38, "Offset mismatch for UAbilityAsync_WaitGameplayEvent::EventReceived");

// Size: 0x50 (Inherited: 0xc0, Single: 0xffffff90)
class UAbilityAsync_WaitGameplayTag : public UAbilityAsync
{
public:

public:
    void AsyncWaitGameplayTagDelegate__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayTag) == 0x50, "Size mismatch for UAbilityAsync_WaitGameplayTag");

// Size: 0x60 (Inherited: 0x110, Single: 0xffffff50)
class UAbilityAsync_WaitGameplayTagAdded : public UAbilityAsync_WaitGameplayTag
{
public:
    uint8_t Added[0x10]; // 0x50 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    static UAbilityAsync_WaitGameplayTagAdded* WaitGameplayTagAddToActor(AActor*& TargetActor, FGameplayTag& Tag, bool& OnlyTriggerOnce); // 0x4aa3378 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayTagAdded) == 0x60, "Size mismatch for UAbilityAsync_WaitGameplayTagAdded");
static_assert(offsetof(UAbilityAsync_WaitGameplayTagAdded, Added) == 0x50, "Offset mismatch for UAbilityAsync_WaitGameplayTagAdded::Added");

// Size: 0x60 (Inherited: 0x110, Single: 0xffffff50)
class UAbilityAsync_WaitGameplayTagRemoved : public UAbilityAsync_WaitGameplayTag
{
public:
    uint8_t Removed[0x10]; // 0x50 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    static UAbilityAsync_WaitGameplayTagRemoved* WaitGameplayTagRemoveFromActor(AActor*& TargetActor, FGameplayTag& Tag, bool& OnlyTriggerOnce); // 0x4aa3870 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayTagRemoved) == 0x60, "Size mismatch for UAbilityAsync_WaitGameplayTagRemoved");
static_assert(offsetof(UAbilityAsync_WaitGameplayTagRemoved, Removed) == 0x50, "Offset mismatch for UAbilityAsync_WaitGameplayTagRemoved::Removed");

// Size: 0x108 (Inherited: 0xc0, Single: 0x48)
class UAbilityAsync_WaitGameplayTagQuery : public UAbilityAsync
{
public:
    uint8_t Pad_38[0xc0]; // 0x38 (Size: 0xc0, Type: PaddingProperty)
    uint8_t Triggered[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

protected:
    static UAbilityAsync_WaitGameplayTagQuery* WaitGameplayTagQueryOnActor(AActor*& TargetActor, FGameplayTagQuery& const TagQuery, EWaitGameplayTagQueryTriggerCondition& const TriggerCondition, bool& const bOnlyTriggerOnce); // 0x4aa2af0 (Index: 0x0, Flags: Final|Native|Static|Protected|BlueprintCallable)
};

static_assert(sizeof(UAbilityAsync_WaitGameplayTagQuery) == 0x108, "Size mismatch for UAbilityAsync_WaitGameplayTagQuery");
static_assert(offsetof(UAbilityAsync_WaitGameplayTagQuery, Triggered) == 0xf8, "Offset mismatch for UAbilityAsync_WaitGameplayTagQuery::Triggered");

// Size: 0x3a8 (Inherited: 0x28, Single: 0x380)
class UGameplayAbility : public UObject
{
public:
    uint8_t Pad_28[0x80]; // 0x28 (Size: 0x80, Type: PaddingProperty)
    FGameplayTagContainer AbilityTags; // 0xa8 (Size: 0x20, Type: StructProperty)
    bool bReplicateInputDirectly; // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool RemoteInstanceEnded; // 0xc9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ca[0x4]; // 0xca (Size: 0x4, Type: PaddingProperty)
    TEnumAsByte<EGameplayAbilityReplicationPolicy> ReplicationPolicy; // 0xce (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EGameplayAbilityInstancingPolicy> InstancingPolicy; // 0xcf (Size: 0x1, Type: ByteProperty)
    bool bServerRespectsRemoteAbilityCancellation; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bRetriggerInstancedAbility; // 0xd1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d2[0x2]; // 0xd2 (Size: 0x2, Type: PaddingProperty)
    FGameplayAbilityActivationInfo CurrentActivationInfo; // 0xd4 (Size: 0x14, Type: StructProperty)
    FGameplayEventData CurrentEventData; // 0xe8 (Size: 0xb0, Type: StructProperty)
    TEnumAsByte<EGameplayAbilityNetExecutionPolicy> NetExecutionPolicy; // 0x198 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EGameplayAbilityNetSecurityPolicy> NetSecurityPolicy; // 0x199 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_19a[0x6]; // 0x19a (Size: 0x6, Type: PaddingProperty)
    UClass* CostGameplayEffectClass; // 0x1a0 (Size: 0x8, Type: ClassProperty)
    TArray<FAbilityTriggerData> AbilityTriggers; // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    UClass* CooldownGameplayEffectClass; // 0x1b8 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer CancelAbilitiesWithTag; // 0x1c0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockAbilitiesWithTag; // 0x1e0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActivationOwnedTags; // 0x200 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActivationRequiredTags; // 0x220 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActivationBlockedTags; // 0x240 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SourceRequiredTags; // 0x260 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SourceBlockedTags; // 0x280 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetRequiredTags; // 0x2a0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetBlockedTags; // 0x2c0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_2e0[0x20]; // 0x2e0 (Size: 0x20, Type: PaddingProperty)
    TArray<UGameplayTask*> ActiveTasks; // 0x300 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_310[0x10]; // 0x310 (Size: 0x10, Type: PaddingProperty)
    UAnimMontage* CurrentMontage; // 0x320 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_328[0x60]; // 0x328 (Size: 0x60, Type: PaddingProperty)
    bool bIsActive; // 0x388 (Size: 0x1, Type: BoolProperty)
    bool bIsAbilityEnding; // 0x389 (Size: 0x1, Type: BoolProperty)
    bool bIsCancelable; // 0x38a (Size: 0x1, Type: BoolProperty)
    bool bIsBlockingOtherAbilities; // 0x38b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_38c[0x14]; // 0x38c (Size: 0x14, Type: PaddingProperty)
    bool bMarkPendingKillOnAbilityEnd; // 0x3a0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a1[0x7]; // 0x3a1 (Size: 0x7, Type: PaddingProperty)

public:
    int32_t GetAbilityLevel() const; // 0xb7a38d4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetAbilityLevel_BP(FGameplayAbilitySpecHandle& Handle, const FGameplayAbilityActorInfo ActorInfo) const; // 0xb7a38f8 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UAbilitySystemComponent* GetAbilitySystemComponentFromActorInfo() const; // 0xb7a3a78 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayAbilityActorInfo GetActorInfo() const; // 0xb7a3a9c (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AActor* GetAvatarActorFromActorInfo() const; // 0xb7a3ad0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayEffectContextHandle GetContextFromOwner(FGameplayAbilityTargetDataHandle& OptionalTargetData) const; // 0xb7a3af4 (Index: 0xe, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCooldownTimeRemaining() const; // 0xb7a3c44 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAnimMontage* GetCurrentMontage() const; // 0xb7a3c80 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UObject* GetCurrentSourceObject() const; // 0xb7a3ca0 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayEffectContextHandle GetGrantedByEffectContext() const; // 0xb7a3cc4 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AActor* GetOwningActorFromActorInfo() const; // 0xb7a3d0c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMeshComponent* GetOwningComponentFromActorInfo() const; // 0xb7a3d30 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UObject* GetSourceObject_BP(FGameplayAbilitySpecHandle& Handle, const FGameplayAbilityActorInfo ActorInfo) const; // 0xb7a3d54 (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void InvalidateClientPredictionKey() const; // 0xb7a3ec4 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|Const)
    bool IsLocallyControlled() const; // 0xb7a3f00 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|Const)
    void K2_CancelAbility(); // 0xb7a4760 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable)
    bool K2_CheckAbilityCooldown(); // 0xb7a47ac (Index: 0x20, Flags: Native|Public|BlueprintCallable)
    bool K2_CheckAbilityCost(); // 0xa560114 (Index: 0x21, Flags: Native|Public|BlueprintCallable)
    bool K2_CommitAbility(); // 0xa1c47f0 (Index: 0x22, Flags: Native|Public|BlueprintCallable)
    bool K2_CommitAbilityCooldown(bool& BroadcastCommitEvent, bool& ForceCooldown); // 0xb7a47d4 (Index: 0x23, Flags: Native|Public|BlueprintCallable)
    bool K2_CommitAbilityCost(bool& BroadcastCommitEvent); // 0xb7a49f8 (Index: 0x24, Flags: Native|Public|BlueprintCallable)
    virtual void K2_CommitExecute(); // 0x288a61c (Index: 0x25, Flags: Event|Public|BlueprintEvent)
    bool K2_HasAuthority() const; // 0xb7a4e84 (Index: 0x2a, Flags: Final|Native|Public|BlueprintCallable|Const)
    FGameplayEffectSpecHandle MakeOutgoingGameplayEffectSpec(UClass*& GameplayEffectClass, float& Level) const; // 0xb7a4f64 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveGrantedByEffect(); // 0xa3a1944 (Index: 0x34, Flags: Native|Public|BlueprintCallable)
    void SetCanBeCanceled(bool& bCanBeCanceled); // 0xb7a61b4 (Index: 0x36, Flags: Native|Public|BlueprintCallable)
    void SetShouldBlockOtherAbilities(bool& bShouldBlockAbilities); // 0xb7a62e4 (Index: 0x37, Flags: Native|Public|BlueprintCallable)

protected:
    FActiveGameplayEffectHandle BP_ApplyGameplayEffectToOwner(UClass*& GameplayEffectClass, int32_t& GameplayEffectLevel, int32_t& Stacks); // 0xb7a12d0 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    TArray<FActiveGameplayEffectHandle> BP_ApplyGameplayEffectToTarget(FGameplayAbilityTargetDataHandle& TargetData, UClass*& GameplayEffectClass, int32_t& GameplayEffectLevel, int32_t& Stacks); // 0xb7a176c (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void BP_RemoveGameplayEffectFromOwnerWithAssetTags(FGameplayTagContainer& WithAssetTags, int32_t& StacksToRemove); // 0xb7a1bf4 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void BP_RemoveGameplayEffectFromOwnerWithGrantedTags(FGameplayTagContainer& WithGrantedTags, int32_t& StacksToRemove); // 0xb7a1f84 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    void BP_RemoveGameplayEffectFromOwnerWithHandle(FActiveGameplayEffectHandle& Handle, int32_t& StacksToRemove); // 0xb7a22f8 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
    void CancelTaskByInstanceName(FName& InstanceName); // 0xb7a2458 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable)
    void ConfirmTaskByInstanceName(FName& InstanceName, bool& bEndTask); // 0xb7a2580 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
    void EndAbilityState(FName& OptionalStateNameToEnd); // 0xb7a361c (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable)
    void EndTaskByInstanceName(FName& InstanceName); // 0xb7a37ac (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x19, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    void K2_AddGameplayCue(FGameplayTag& GameplayCueTag, FGameplayEffectContextHandle& Context, bool& bRemoveOnAbilityEnd); // 0xb7a3f24 (Index: 0x1a, Flags: Native|Protected|BlueprintCallable)
    void K2_AddGameplayCueWithParams(FGameplayTag& GameplayCueTag, const FGameplayCueParameters GameplayCueParameter, bool& bRemoveOnAbilityEnd); // 0xb7a413c (Index: 0x1b, Flags: Native|Protected|HasOutParms|BlueprintCallable)
    FActiveGameplayEffectHandle K2_ApplyGameplayEffectSpecToOwner(FGameplayEffectSpecHandle& const EffectSpecHandle); // 0xb7a4318 (Index: 0x1c, Flags: Final|Native|Protected|BlueprintCallable)
    TArray<FActiveGameplayEffectHandle> K2_ApplyGameplayEffectSpecToTarget(FGameplayEffectSpecHandle& const EffectSpecHandle, FGameplayAbilityTargetDataHandle& TargetData); // 0xb7a44a0 (Index: 0x1d, Flags: Final|Native|Protected|BlueprintCallable)
    virtual bool K2_CanActivateAbility(FGameplayAbilityActorInfo& ActorInfo, FGameplayAbilitySpecHandle& const Handle, FGameplayTagContainer& RelevantTags) const; // 0x288a61c (Index: 0x1e, Flags: Event|Protected|HasOutParms|BlueprintEvent|Const)
    void K2_EndAbility(); // 0xb7a4b38 (Index: 0x26, Flags: Native|Protected|BlueprintCallable)
    void K2_EndAbilityLocally(); // 0xb7a4b50 (Index: 0x27, Flags: Native|Protected|BlueprintCallable)
    void K2_ExecuteGameplayCue(FGameplayTag& GameplayCueTag, FGameplayEffectContextHandle& Context); // 0xb7a4b68 (Index: 0x28, Flags: Native|Protected|BlueprintCallable)
    void K2_ExecuteGameplayCueWithParams(FGameplayTag& GameplayCueTag, const FGameplayCueParameters GameplayCueParameters); // 0xb7a4d10 (Index: 0x29, Flags: Native|Protected|HasOutParms|BlueprintCallable)
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x2b, Flags: Event|Protected|BlueprintEvent)
    void K2_RemoveGameplayCue(FGameplayTag& GameplayCueTag); // 0xb7a4ea0 (Index: 0x2c, Flags: Native|Protected|BlueprintCallable)
    virtual bool K2_ShouldAbilityRespondToEvent(FGameplayAbilityActorInfo& ActorInfo, FGameplayEventData& Payload) const; // 0x288a61c (Index: 0x2d, Flags: Event|Protected|BlueprintEvent|Const)
    FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerActor(); // 0xb7a533c (Index: 0x2f, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(FName& SocketName); // 0xb7a53f0 (Index: 0x30, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    void MontageJumpToSection(FName& SectionName); // 0xb7a5620 (Index: 0x31, Flags: Final|Native|Protected|BlueprintCallable)
    void MontageSetNextSectionName(FName& FromSectionName, FName& ToSectionName); // 0xb7a576c (Index: 0x32, Flags: Final|Native|Protected|BlueprintCallable)
    void MontageStop(float& OverrideBlendOutTime); // 0xb7a599c (Index: 0x33, Flags: Final|Native|Protected|BlueprintCallable)
    void SendGameplayEvent(FGameplayTag& EventTag, FGameplayEventData& Payload); // 0xb7a6020 (Index: 0x35, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UGameplayAbility) == 0x3a8, "Size mismatch for UGameplayAbility");
static_assert(offsetof(UGameplayAbility, AbilityTags) == 0xa8, "Offset mismatch for UGameplayAbility::AbilityTags");
static_assert(offsetof(UGameplayAbility, bReplicateInputDirectly) == 0xc8, "Offset mismatch for UGameplayAbility::bReplicateInputDirectly");
static_assert(offsetof(UGameplayAbility, RemoteInstanceEnded) == 0xc9, "Offset mismatch for UGameplayAbility::RemoteInstanceEnded");
static_assert(offsetof(UGameplayAbility, ReplicationPolicy) == 0xce, "Offset mismatch for UGameplayAbility::ReplicationPolicy");
static_assert(offsetof(UGameplayAbility, InstancingPolicy) == 0xcf, "Offset mismatch for UGameplayAbility::InstancingPolicy");
static_assert(offsetof(UGameplayAbility, bServerRespectsRemoteAbilityCancellation) == 0xd0, "Offset mismatch for UGameplayAbility::bServerRespectsRemoteAbilityCancellation");
static_assert(offsetof(UGameplayAbility, bRetriggerInstancedAbility) == 0xd1, "Offset mismatch for UGameplayAbility::bRetriggerInstancedAbility");
static_assert(offsetof(UGameplayAbility, CurrentActivationInfo) == 0xd4, "Offset mismatch for UGameplayAbility::CurrentActivationInfo");
static_assert(offsetof(UGameplayAbility, CurrentEventData) == 0xe8, "Offset mismatch for UGameplayAbility::CurrentEventData");
static_assert(offsetof(UGameplayAbility, NetExecutionPolicy) == 0x198, "Offset mismatch for UGameplayAbility::NetExecutionPolicy");
static_assert(offsetof(UGameplayAbility, NetSecurityPolicy) == 0x199, "Offset mismatch for UGameplayAbility::NetSecurityPolicy");
static_assert(offsetof(UGameplayAbility, CostGameplayEffectClass) == 0x1a0, "Offset mismatch for UGameplayAbility::CostGameplayEffectClass");
static_assert(offsetof(UGameplayAbility, AbilityTriggers) == 0x1a8, "Offset mismatch for UGameplayAbility::AbilityTriggers");
static_assert(offsetof(UGameplayAbility, CooldownGameplayEffectClass) == 0x1b8, "Offset mismatch for UGameplayAbility::CooldownGameplayEffectClass");
static_assert(offsetof(UGameplayAbility, CancelAbilitiesWithTag) == 0x1c0, "Offset mismatch for UGameplayAbility::CancelAbilitiesWithTag");
static_assert(offsetof(UGameplayAbility, BlockAbilitiesWithTag) == 0x1e0, "Offset mismatch for UGameplayAbility::BlockAbilitiesWithTag");
static_assert(offsetof(UGameplayAbility, ActivationOwnedTags) == 0x200, "Offset mismatch for UGameplayAbility::ActivationOwnedTags");
static_assert(offsetof(UGameplayAbility, ActivationRequiredTags) == 0x220, "Offset mismatch for UGameplayAbility::ActivationRequiredTags");
static_assert(offsetof(UGameplayAbility, ActivationBlockedTags) == 0x240, "Offset mismatch for UGameplayAbility::ActivationBlockedTags");
static_assert(offsetof(UGameplayAbility, SourceRequiredTags) == 0x260, "Offset mismatch for UGameplayAbility::SourceRequiredTags");
static_assert(offsetof(UGameplayAbility, SourceBlockedTags) == 0x280, "Offset mismatch for UGameplayAbility::SourceBlockedTags");
static_assert(offsetof(UGameplayAbility, TargetRequiredTags) == 0x2a0, "Offset mismatch for UGameplayAbility::TargetRequiredTags");
static_assert(offsetof(UGameplayAbility, TargetBlockedTags) == 0x2c0, "Offset mismatch for UGameplayAbility::TargetBlockedTags");
static_assert(offsetof(UGameplayAbility, ActiveTasks) == 0x300, "Offset mismatch for UGameplayAbility::ActiveTasks");
static_assert(offsetof(UGameplayAbility, CurrentMontage) == 0x320, "Offset mismatch for UGameplayAbility::CurrentMontage");
static_assert(offsetof(UGameplayAbility, bIsActive) == 0x388, "Offset mismatch for UGameplayAbility::bIsActive");
static_assert(offsetof(UGameplayAbility, bIsAbilityEnding) == 0x389, "Offset mismatch for UGameplayAbility::bIsAbilityEnding");
static_assert(offsetof(UGameplayAbility, bIsCancelable) == 0x38a, "Offset mismatch for UGameplayAbility::bIsCancelable");
static_assert(offsetof(UGameplayAbility, bIsBlockingOtherAbilities) == 0x38b, "Offset mismatch for UGameplayAbility::bIsBlockingOtherAbilities");
static_assert(offsetof(UGameplayAbility, bMarkPendingKillOnAbilityEnd) == 0x3a0, "Offset mismatch for UGameplayAbility::bMarkPendingKillOnAbilityEnd");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UGameplayAbilitySet : public UDataAsset
{
public:
    TArray<FGameplayAbilityBindInfo> Abilities; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayAbilitySet) == 0x40, "Size mismatch for UGameplayAbilitySet");
static_assert(offsetof(UGameplayAbilitySet, Abilities) == 0x30, "Offset mismatch for UGameplayAbilitySet::Abilities");

// Size: 0x3e0 (Inherited: 0x2d0, Single: 0x110)
class AGameplayAbilityTargetActor : public AActor
{
public:
    bool ShouldProduceTargetDataOnServer; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
    FGameplayAbilityTargetingLocationInfo StartLocation; // 0x2b0 (Size: 0x90, Type: StructProperty)
    uint8_t Pad_340[0x30]; // 0x340 (Size: 0x30, Type: PaddingProperty)
    APlayerController* PrimaryPC; // 0x370 (Size: 0x8, Type: ObjectProperty)
    UGameplayAbility* OwningAbility; // 0x378 (Size: 0x8, Type: ObjectProperty)
    bool bDestroyOnConfirmation; // 0x380 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_381[0x7]; // 0x381 (Size: 0x7, Type: PaddingProperty)
    AActor* SourceActor; // 0x388 (Size: 0x8, Type: ObjectProperty)
    FWorldReticleParameters ReticleParams; // 0x390 (Size: 0x18, Type: StructProperty)
    UClass* ReticleClass; // 0x3a8 (Size: 0x8, Type: ClassProperty)
    FGameplayTargetDataFilterHandle Filter; // 0x3b0 (Size: 0x10, Type: StructProperty)
    bool bDebug; // 0x3c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c1[0x17]; // 0x3c1 (Size: 0x17, Type: PaddingProperty)
    UAbilitySystemComponent* GenericDelegateBoundASC; // 0x3d8 (Size: 0x8, Type: ObjectProperty)

public:
    void CancelTargeting(); // 0x328c674 (Index: 0x0, Flags: Native|Public)
    void ConfirmTargeting(); // 0x5349664 (Index: 0x1, Flags: Native|Public)
};

static_assert(sizeof(AGameplayAbilityTargetActor) == 0x3e0, "Size mismatch for AGameplayAbilityTargetActor");
static_assert(offsetof(AGameplayAbilityTargetActor, ShouldProduceTargetDataOnServer) == 0x2a8, "Offset mismatch for AGameplayAbilityTargetActor::ShouldProduceTargetDataOnServer");
static_assert(offsetof(AGameplayAbilityTargetActor, StartLocation) == 0x2b0, "Offset mismatch for AGameplayAbilityTargetActor::StartLocation");
static_assert(offsetof(AGameplayAbilityTargetActor, PrimaryPC) == 0x370, "Offset mismatch for AGameplayAbilityTargetActor::PrimaryPC");
static_assert(offsetof(AGameplayAbilityTargetActor, OwningAbility) == 0x378, "Offset mismatch for AGameplayAbilityTargetActor::OwningAbility");
static_assert(offsetof(AGameplayAbilityTargetActor, bDestroyOnConfirmation) == 0x380, "Offset mismatch for AGameplayAbilityTargetActor::bDestroyOnConfirmation");
static_assert(offsetof(AGameplayAbilityTargetActor, SourceActor) == 0x388, "Offset mismatch for AGameplayAbilityTargetActor::SourceActor");
static_assert(offsetof(AGameplayAbilityTargetActor, ReticleParams) == 0x390, "Offset mismatch for AGameplayAbilityTargetActor::ReticleParams");
static_assert(offsetof(AGameplayAbilityTargetActor, ReticleClass) == 0x3a8, "Offset mismatch for AGameplayAbilityTargetActor::ReticleClass");
static_assert(offsetof(AGameplayAbilityTargetActor, Filter) == 0x3b0, "Offset mismatch for AGameplayAbilityTargetActor::Filter");
static_assert(offsetof(AGameplayAbilityTargetActor, bDebug) == 0x3c0, "Offset mismatch for AGameplayAbilityTargetActor::bDebug");
static_assert(offsetof(AGameplayAbilityTargetActor, GenericDelegateBoundASC) == 0x3d8, "Offset mismatch for AGameplayAbilityTargetActor::GenericDelegateBoundASC");

// Size: 0x430 (Inherited: 0xed0, Single: 0xfffff560)
class AGameplayAbilityTargetActor_ActorPlacement : public AGameplayAbilityTargetActor_GroundTrace
{
public:
    UClass* PlacedActorClass; // 0x418 (Size: 0x8, Type: ClassProperty)
    UMaterialInterface* PlacedActorMaterial; // 0x420 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_428[0x8]; // 0x428 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(AGameplayAbilityTargetActor_ActorPlacement) == 0x430, "Size mismatch for AGameplayAbilityTargetActor_ActorPlacement");
static_assert(offsetof(AGameplayAbilityTargetActor_ActorPlacement, PlacedActorClass) == 0x418, "Offset mismatch for AGameplayAbilityTargetActor_ActorPlacement::PlacedActorClass");
static_assert(offsetof(AGameplayAbilityTargetActor_ActorPlacement, PlacedActorMaterial) == 0x420, "Offset mismatch for AGameplayAbilityTargetActor_ActorPlacement::PlacedActorMaterial");

// Size: 0x420 (Inherited: 0xab0, Single: 0xfffff970)
class AGameplayAbilityTargetActor_GroundTrace : public AGameplayAbilityTargetActor_Trace
{
public:
    float CollisionRadius; // 0x3f8 (Size: 0x4, Type: FloatProperty)
    float CollisionHeight; // 0x3fc (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_400[0x20]; // 0x400 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(AGameplayAbilityTargetActor_GroundTrace) == 0x420, "Size mismatch for AGameplayAbilityTargetActor_GroundTrace");
static_assert(offsetof(AGameplayAbilityTargetActor_GroundTrace, CollisionRadius) == 0x3f8, "Offset mismatch for AGameplayAbilityTargetActor_GroundTrace::CollisionRadius");
static_assert(offsetof(AGameplayAbilityTargetActor_GroundTrace, CollisionHeight) == 0x3fc, "Offset mismatch for AGameplayAbilityTargetActor_GroundTrace::CollisionHeight");

// Size: 0x400 (Inherited: 0x6b0, Single: 0xfffffd50)
class AGameplayAbilityTargetActor_Trace : public AGameplayAbilityTargetActor
{
public:
    float MaxRange; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    FCollisionProfileName TraceProfile; // 0x3e4 (Size: 0x4, Type: StructProperty)
    bool bTraceAffectsAimPitch; // 0x3e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e9[0x17]; // 0x3e9 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(AGameplayAbilityTargetActor_Trace) == 0x400, "Size mismatch for AGameplayAbilityTargetActor_Trace");
static_assert(offsetof(AGameplayAbilityTargetActor_Trace, MaxRange) == 0x3e0, "Offset mismatch for AGameplayAbilityTargetActor_Trace::MaxRange");
static_assert(offsetof(AGameplayAbilityTargetActor_Trace, TraceProfile) == 0x3e4, "Offset mismatch for AGameplayAbilityTargetActor_Trace::TraceProfile");
static_assert(offsetof(AGameplayAbilityTargetActor_Trace, bTraceAffectsAimPitch) == 0x3e8, "Offset mismatch for AGameplayAbilityTargetActor_Trace::bTraceAffectsAimPitch");

// Size: 0x3f0 (Inherited: 0x6b0, Single: 0xfffffd40)
class AGameplayAbilityTargetActor_Radius : public AGameplayAbilityTargetActor
{
public:
    float Radius; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3e4[0xc]; // 0x3e4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(AGameplayAbilityTargetActor_Radius) == 0x3f0, "Size mismatch for AGameplayAbilityTargetActor_Radius");
static_assert(offsetof(AGameplayAbilityTargetActor_Radius, Radius) == 0x3e0, "Offset mismatch for AGameplayAbilityTargetActor_Radius::Radius");

// Size: 0x400 (Inherited: 0xab0, Single: 0xfffff950)
class AGameplayAbilityTargetActor_SingleLineTrace : public AGameplayAbilityTargetActor_Trace
{
public:
};

static_assert(sizeof(AGameplayAbilityTargetActor_SingleLineTrace) == 0x400, "Size mismatch for AGameplayAbilityTargetActor_SingleLineTrace");

// Size: 0x2d8 (Inherited: 0x2d0, Single: 0x8)
class AGameplayAbilityWorldReticle : public AActor
{
public:
    FWorldReticleParameters Parameters; // 0x2a8 (Size: 0x18, Type: StructProperty)
    bool bFaceOwnerFlat; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bSnapToTargetedActor; // 0x2c1 (Size: 0x1, Type: BoolProperty)
    bool bIsTargetValid; // 0x2c2 (Size: 0x1, Type: BoolProperty)
    bool bIsTargetAnActor; // 0x2c3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c4[0x4]; // 0x2c4 (Size: 0x4, Type: PaddingProperty)
    APlayerController* PrimaryPC; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    AGameplayAbilityTargetActor* TargetingActor; // 0x2d0 (Size: 0x8, Type: ObjectProperty)

public:
    void FaceTowardSource(bool& bFaceIn2D); // 0xb7f4600 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    virtual void OnParametersInitialized(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void OnTargetingAnActor(bool& bNewValue); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void OnValidTargetChanged(bool& bNewValue); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void SetReticleMaterialParamFloat(FName& ParamName, float& Value); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void SetReticleMaterialParamVector(FName& ParamName, FVector& Value); // 0x288a61c (Index: 0x5, Flags: Event|Public|HasDefaults|BlueprintEvent)
};

static_assert(sizeof(AGameplayAbilityWorldReticle) == 0x2d8, "Size mismatch for AGameplayAbilityWorldReticle");
static_assert(offsetof(AGameplayAbilityWorldReticle, Parameters) == 0x2a8, "Offset mismatch for AGameplayAbilityWorldReticle::Parameters");
static_assert(offsetof(AGameplayAbilityWorldReticle, bFaceOwnerFlat) == 0x2c0, "Offset mismatch for AGameplayAbilityWorldReticle::bFaceOwnerFlat");
static_assert(offsetof(AGameplayAbilityWorldReticle, bSnapToTargetedActor) == 0x2c1, "Offset mismatch for AGameplayAbilityWorldReticle::bSnapToTargetedActor");
static_assert(offsetof(AGameplayAbilityWorldReticle, bIsTargetValid) == 0x2c2, "Offset mismatch for AGameplayAbilityWorldReticle::bIsTargetValid");
static_assert(offsetof(AGameplayAbilityWorldReticle, bIsTargetAnActor) == 0x2c3, "Offset mismatch for AGameplayAbilityWorldReticle::bIsTargetAnActor");
static_assert(offsetof(AGameplayAbilityWorldReticle, PrimaryPC) == 0x2c8, "Offset mismatch for AGameplayAbilityWorldReticle::PrimaryPC");
static_assert(offsetof(AGameplayAbilityWorldReticle, TargetingActor) == 0x2d0, "Offset mismatch for AGameplayAbilityWorldReticle::TargetingActor");

// Size: 0x2f0 (Inherited: 0x5a8, Single: 0xfffffd48)
class AGameplayAbilityWorldReticle_ActorVisualization : public AGameplayAbilityWorldReticle
{
public:
    UCapsuleComponent* CollisionComponent; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    TArray<UActorComponent*> VisualizationComponents; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(AGameplayAbilityWorldReticle_ActorVisualization) == 0x2f0, "Size mismatch for AGameplayAbilityWorldReticle_ActorVisualization");
static_assert(offsetof(AGameplayAbilityWorldReticle_ActorVisualization, CollisionComponent) == 0x2d8, "Offset mismatch for AGameplayAbilityWorldReticle_ActorVisualization::CollisionComponent");
static_assert(offsetof(AGameplayAbilityWorldReticle_ActorVisualization, VisualizationComponents) == 0x2e0, "Offset mismatch for AGameplayAbilityWorldReticle_ActorVisualization::VisualizationComponents");

// Size: 0x3a8 (Inherited: 0x3d0, Single: 0xffffffd8)
class UGameplayAbility_CharacterJump : public UGameplayAbility
{
public:
};

static_assert(sizeof(UGameplayAbility_CharacterJump) == 0x3a8, "Size mismatch for UGameplayAbility_CharacterJump");

// Size: 0x3d8 (Inherited: 0x3d0, Single: 0x8)
class UGameplayAbility_Montage : public UGameplayAbility
{
public:
    UAnimMontage* MontageToPlay; // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    float PlayRate; // 0x3b0 (Size: 0x4, Type: FloatProperty)
    FName SectionName; // 0x3b4 (Size: 0x4, Type: NameProperty)
    TArray<UClass*> GameplayEffectClassesWhileAnimating; // 0x3b8 (Size: 0x10, Type: ArrayProperty)
    TArray<UGameplayEffect*> GameplayEffectsWhileAnimating; // 0x3c8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayAbility_Montage) == 0x3d8, "Size mismatch for UGameplayAbility_Montage");
static_assert(offsetof(UGameplayAbility_Montage, MontageToPlay) == 0x3a8, "Offset mismatch for UGameplayAbility_Montage::MontageToPlay");
static_assert(offsetof(UGameplayAbility_Montage, PlayRate) == 0x3b0, "Offset mismatch for UGameplayAbility_Montage::PlayRate");
static_assert(offsetof(UGameplayAbility_Montage, SectionName) == 0x3b4, "Offset mismatch for UGameplayAbility_Montage::SectionName");
static_assert(offsetof(UGameplayAbility_Montage, GameplayEffectClassesWhileAnimating) == 0x3b8, "Offset mismatch for UGameplayAbility_Montage::GameplayEffectClassesWhileAnimating");
static_assert(offsetof(UGameplayAbility_Montage, GameplayEffectsWhileAnimating) == 0x3c8, "Offset mismatch for UGameplayAbility_Montage::GameplayEffectsWhileAnimating");

// Size: 0xf8 (Inherited: 0x1b0, Single: 0xffffff48)
class UAbilityTask_ApplyRootMotionConstantForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    uint8_t OnFinish[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FVector WorldDirection; // 0xc0 (Size: 0x18, Type: StructProperty)
    float Strength; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float duration; // 0xdc (Size: 0x4, Type: FloatProperty)
    bool bIsAdditive; // 0xe0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e1[0x7]; // 0xe1 (Size: 0x7, Type: PaddingProperty)
    UCurveFloat* StrengthOverTime; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    bool bEnableGravity; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x7]; // 0xf1 (Size: 0x7, Type: PaddingProperty)

public:
    static UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, FVector& WorldDirection, float& Strength, float& duration, bool& bIsAdditive, UCurveFloat*& StrengthOverTime, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish, bool& bEnableGravity); // 0xb7eac58 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_ApplyRootMotionConstantForce) == 0xf8, "Size mismatch for UAbilityTask_ApplyRootMotionConstantForce");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, OnFinish) == 0xb0, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::OnFinish");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, WorldDirection) == 0xc0, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::WorldDirection");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, Strength) == 0xd8, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::Strength");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, duration) == 0xdc, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::duration");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, bIsAdditive) == 0xe0, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::bIsAdditive");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, StrengthOverTime) == 0xe8, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::StrengthOverTime");
static_assert(offsetof(UAbilityTask_ApplyRootMotionConstantForce, bEnableGravity) == 0xf0, "Offset mismatch for UAbilityTask_ApplyRootMotionConstantForce::bEnableGravity");

// Size: 0xb0 (Inherited: 0x100, Single: 0xffffffb0)
class UAbilityTask_ApplyRootMotion_Base : public UAbilityTask
{
public:
    FName ForceName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t FinishVelocityMode; // 0x7c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_7d[0x3]; // 0x7d (Size: 0x3, Type: PaddingProperty)
    FVector FinishSetVelocity; // 0x80 (Size: 0x18, Type: StructProperty)
    float FinishClampVelocity; // 0x98 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UCharacterMovementComponent*> MovementComponent; // 0x9c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_a4[0xc]; // 0xa4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UAbilityTask_ApplyRootMotion_Base) == 0xb0, "Size mismatch for UAbilityTask_ApplyRootMotion_Base");
static_assert(offsetof(UAbilityTask_ApplyRootMotion_Base, ForceName) == 0x78, "Offset mismatch for UAbilityTask_ApplyRootMotion_Base::ForceName");
static_assert(offsetof(UAbilityTask_ApplyRootMotion_Base, FinishVelocityMode) == 0x7c, "Offset mismatch for UAbilityTask_ApplyRootMotion_Base::FinishVelocityMode");
static_assert(offsetof(UAbilityTask_ApplyRootMotion_Base, FinishSetVelocity) == 0x80, "Offset mismatch for UAbilityTask_ApplyRootMotion_Base::FinishSetVelocity");
static_assert(offsetof(UAbilityTask_ApplyRootMotion_Base, FinishClampVelocity) == 0x98, "Offset mismatch for UAbilityTask_ApplyRootMotion_Base::FinishClampVelocity");
static_assert(offsetof(UAbilityTask_ApplyRootMotion_Base, MovementComponent) == 0x9c, "Offset mismatch for UAbilityTask_ApplyRootMotion_Base::MovementComponent");

// Size: 0x118 (Inherited: 0x1b0, Single: 0xffffff68)
class UAbilityTask_ApplyRootMotionJumpForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    uint8_t OnFinish[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLanded[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FRotator Rotation; // 0xd0 (Size: 0x18, Type: StructProperty)
    float Distance; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float Height; // 0xec (Size: 0x4, Type: FloatProperty)
    float duration; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float MinimumLandedTriggerTime; // 0xf4 (Size: 0x4, Type: FloatProperty)
    bool bFinishOnLanded; // 0xf8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f9[0x7]; // 0xf9 (Size: 0x7, Type: PaddingProperty)
    UCurveVector* PathOffsetCurve; // 0x100 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TimeMappingCurve; // 0x108 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)

public:
    static UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, FRotator& Rotation, float& Distance, float& Height, float& duration, float& MinimumLandedTriggerTime, bool& bFinishOnLanded, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish, UCurveVector*& PathOffsetCurve, UCurveFloat*& TimeMappingCurve); // 0xb7eb1f4 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    void Finish(); // 0xb7f55bc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void OnLandedCallback(const FHitResult Hit); // 0xb8025ac (Index: 0x2, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UAbilityTask_ApplyRootMotionJumpForce) == 0x118, "Size mismatch for UAbilityTask_ApplyRootMotionJumpForce");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, OnFinish) == 0xb0, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::OnFinish");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, OnLanded) == 0xc0, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::OnLanded");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, Rotation) == 0xd0, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::Rotation");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, Distance) == 0xe8, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::Distance");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, Height) == 0xec, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::Height");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, duration) == 0xf0, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::duration");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, MinimumLandedTriggerTime) == 0xf4, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::MinimumLandedTriggerTime");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, bFinishOnLanded) == 0xf8, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::bFinishOnLanded");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, PathOffsetCurve) == 0x100, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::PathOffsetCurve");
static_assert(offsetof(UAbilityTask_ApplyRootMotionJumpForce, TimeMappingCurve) == 0x108, "Offset mismatch for UAbilityTask_ApplyRootMotionJumpForce::TimeMappingCurve");

// Size: 0x178 (Inherited: 0x1b0, Single: 0xffffffc8)
class UAbilityTask_ApplyRootMotionMoveToActorForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    uint8_t OnFinished[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
    FVector StartLocation; // 0xc8 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation; // 0xe0 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* TargetComponent; // 0x100 (Size: 0x8, Type: ObjectProperty)
    FVector TargetComponentRelativeLocation; // 0x108 (Size: 0x18, Type: StructProperty)
    FVector TargetLocationOffset; // 0x120 (Size: 0x18, Type: StructProperty)
    uint8_t OffsetAlignment; // 0x138 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_139[0x3]; // 0x139 (Size: 0x3, Type: PaddingProperty)
    float duration; // 0x13c (Size: 0x4, Type: FloatProperty)
    bool bDisableDestinationReachedInterrupt; // 0x140 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_141[0x3]; // 0x141 (Size: 0x3, Type: PaddingProperty)
    float ReachedDestinationDistance; // 0x144 (Size: 0x4, Type: FloatProperty)
    bool bSetNewMovementMode; // 0x148 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> NewMovementMode; // 0x149 (Size: 0x1, Type: ByteProperty)
    bool bRestrictSpeedToExpected; // 0x14a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_14b[0x5]; // 0x14b (Size: 0x5, Type: PaddingProperty)
    UCurveVector* PathOffsetCurve; // 0x150 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TimeMappingCurve; // 0x158 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TargetLerpSpeedHorizontalCurve; // 0x160 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* TargetLerpSpeedVerticalCurve; // 0x168 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_170[0x8]; // 0x170 (Size: 0x8, Type: PaddingProperty)

public:
    static UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, AActor*& TargetActor, FVector& TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType& OffsetAlignment, float& duration, UCurveFloat*& TargetLerpSpeedHorizontal, UCurveFloat*& TargetLerpSpeedVertical, bool& bSetNewMovementMode, TEnumAsByte<EMovementMode>& MovementMode, bool& bRestrictSpeedToExpected, UCurveVector*& PathOffsetCurve, UCurveFloat*& TimeMappingCurve, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish, bool& bDisableDestinationReachedInterrupt, float& ReachedDestinationDistance); // 0xb7eb888 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToComponentForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, USceneComponent*& TargetComponent, FVector& TargetComponentRelativeLocation, FVector& TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType& OffsetAlignment, float& duration, UCurveFloat*& TargetLerpSpeedHorizontal, UCurveFloat*& TargetLerpSpeedVertical, bool& bSetNewMovementMode, TEnumAsByte<EMovementMode>& MovementMode, bool& bRestrictSpeedToExpected, UCurveVector*& PathOffsetCurve, UCurveFloat*& TimeMappingCurve, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish, bool& bDisableDestinationReachedInterrupt, float& ReachedDestinationDistance); // 0xb7ec1e4 (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, FGameplayAbilityTargetDataHandle& TargetDataHandle, int32_t& TargetDataIndex, int32_t& TargetActorIndex, FVector& TargetLocationOffset, ERootMotionMoveToActorTargetOffsetType& OffsetAlignment, float& duration, UCurveFloat*& TargetLerpSpeedHorizontal, UCurveFloat*& TargetLerpSpeedVertical, bool& bSetNewMovementMode, TEnumAsByte<EMovementMode>& MovementMode, bool& bRestrictSpeedToExpected, UCurveVector*& PathOffsetCurve, UCurveFloat*& TimeMappingCurve, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish, bool& bDisableDestinationReachedInterrupt, float& ReachedDestinationDistance); // 0xb7ed1a4 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    void OnTargetActorSwapped(AActor*& OriginalTarget, AActor*& NewTarget); // 0xb8031f0 (Index: 0x4, Flags: Final|Native|Public)

protected:
    void OnRep_TargetLocation(); // 0xb802fac (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UAbilityTask_ApplyRootMotionMoveToActorForce) == 0x178, "Size mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, OnFinished) == 0xb0, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::OnFinished");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, StartLocation) == 0xc8, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::StartLocation");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetLocation) == 0xe0, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetLocation");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetActor) == 0xf8, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetActor");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetComponent) == 0x100, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetComponent");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetComponentRelativeLocation) == 0x108, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetComponentRelativeLocation");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetLocationOffset) == 0x120, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetLocationOffset");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, OffsetAlignment) == 0x138, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::OffsetAlignment");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, duration) == 0x13c, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::duration");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, bDisableDestinationReachedInterrupt) == 0x140, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::bDisableDestinationReachedInterrupt");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, ReachedDestinationDistance) == 0x144, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::ReachedDestinationDistance");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, bSetNewMovementMode) == 0x148, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::bSetNewMovementMode");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, NewMovementMode) == 0x149, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::NewMovementMode");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, bRestrictSpeedToExpected) == 0x14a, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::bRestrictSpeedToExpected");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, PathOffsetCurve) == 0x150, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::PathOffsetCurve");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TimeMappingCurve) == 0x158, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TimeMappingCurve");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetLerpSpeedHorizontalCurve) == 0x160, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetLerpSpeedHorizontalCurve");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToActorForce, TargetLerpSpeedVerticalCurve) == 0x168, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToActorForce::TargetLerpSpeedVerticalCurve");

// Size: 0x118 (Inherited: 0x1b0, Single: 0xffffff68)
class UAbilityTask_ApplyRootMotionMoveToForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    uint8_t OnTimedOut[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTimedOutAndDestinationReached[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FVector StartLocation; // 0xd0 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation; // 0xe8 (Size: 0x18, Type: StructProperty)
    float duration; // 0x100 (Size: 0x4, Type: FloatProperty)
    bool bSetNewMovementMode; // 0x104 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> NewMovementMode; // 0x105 (Size: 0x1, Type: ByteProperty)
    bool bRestrictSpeedToExpected; // 0x106 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_107[0x1]; // 0x107 (Size: 0x1, Type: PaddingProperty)
    UCurveVector* PathOffsetCurve; // 0x108 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)

public:
    static UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, FVector& TargetLocation, float& duration, bool& bSetNewMovementMode, TEnumAsByte<EMovementMode>& MovementMode, bool& bRestrictSpeedToExpected, UCurveVector*& PathOffsetCurve, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish); // 0xb7ecbc4 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_ApplyRootMotionMoveToForce) == 0x118, "Size mismatch for UAbilityTask_ApplyRootMotionMoveToForce");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, OnTimedOut) == 0xb0, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::OnTimedOut");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, OnTimedOutAndDestinationReached) == 0xc0, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::OnTimedOutAndDestinationReached");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, StartLocation) == 0xd0, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::StartLocation");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, TargetLocation) == 0xe8, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::TargetLocation");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, duration) == 0x100, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::duration");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, bSetNewMovementMode) == 0x104, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::bSetNewMovementMode");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, NewMovementMode) == 0x105, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::NewMovementMode");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, bRestrictSpeedToExpected) == 0x106, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::bRestrictSpeedToExpected");
static_assert(offsetof(UAbilityTask_ApplyRootMotionMoveToForce, PathOffsetCurve) == 0x108, "Offset mismatch for UAbilityTask_ApplyRootMotionMoveToForce::PathOffsetCurve");

// Size: 0x120 (Inherited: 0x1b0, Single: 0xffffff70)
class UAbilityTask_ApplyRootMotionRadialForce : public UAbilityTask_ApplyRootMotion_Base
{
public:
    uint8_t OnFinish[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FVector Location; // 0xc0 (Size: 0x18, Type: StructProperty)
    AActor* LocationActor; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    float Strength; // 0xe0 (Size: 0x4, Type: FloatProperty)
    float duration; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float Radius; // 0xe8 (Size: 0x4, Type: FloatProperty)
    bool bIsPush; // 0xec (Size: 0x1, Type: BoolProperty)
    bool bIsAdditive; // 0xed (Size: 0x1, Type: BoolProperty)
    bool bNoZForce; // 0xee (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ef[0x1]; // 0xef (Size: 0x1, Type: PaddingProperty)
    UCurveFloat* StrengthDistanceFalloff; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* StrengthOverTime; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bUseFixedWorldDirection; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
    FRotator FixedWorldDirection; // 0x108 (Size: 0x18, Type: StructProperty)

public:
    static UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, FVector& Location, AActor*& LocationActor, float& Strength, float& duration, float& Radius, bool& bIsPush, bool& bIsAdditive, bool& bNoZForce, UCurveFloat*& StrengthDistanceFalloff, UCurveFloat*& StrengthOverTime, bool& bUseFixedWorldDirection, FRotator& FixedWorldDirection, ERootMotionFinishVelocityMode& VelocityOnFinishMode, FVector& SetVelocityOnFinish, float& ClampVelocityOnFinish); // 0xb7edc04 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_ApplyRootMotionRadialForce) == 0x120, "Size mismatch for UAbilityTask_ApplyRootMotionRadialForce");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, OnFinish) == 0xb0, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::OnFinish");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, Location) == 0xc0, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::Location");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, LocationActor) == 0xd8, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::LocationActor");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, Strength) == 0xe0, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::Strength");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, duration) == 0xe4, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::duration");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, Radius) == 0xe8, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::Radius");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, bIsPush) == 0xec, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::bIsPush");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, bIsAdditive) == 0xed, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::bIsAdditive");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, bNoZForce) == 0xee, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::bNoZForce");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, StrengthDistanceFalloff) == 0xf0, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::StrengthDistanceFalloff");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, StrengthOverTime) == 0xf8, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::StrengthOverTime");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, bUseFixedWorldDirection) == 0x100, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::bUseFixedWorldDirection");
static_assert(offsetof(UAbilityTask_ApplyRootMotionRadialForce, FixedWorldDirection) == 0x108, "Offset mismatch for UAbilityTask_ApplyRootMotionRadialForce::FixedWorldDirection");

// Size: 0xe0 (Inherited: 0x100, Single: 0xffffffe0)
class UAbilityTask_MoveToLocation : public UAbilityTask
{
public:
    uint8_t OnTargetLocationReached[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    FVector StartLocation; // 0x90 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation; // 0xa8 (Size: 0x18, Type: StructProperty)
    float DurationOfMovement; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0xc]; // 0xc4 (Size: 0xc, Type: PaddingProperty)
    UCurveFloat* LerpCurve; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UCurveVector* LerpCurveVector; // 0xd8 (Size: 0x8, Type: ObjectProperty)

public:
    static UAbilityTask_MoveToLocation* MoveToLocation(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, FVector& Location, float& duration, UCurveFloat*& OptionalInterpolationCurve, UCurveVector*& OptionalVectorInterpolationCurve); // 0xb7ff718 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_MoveToLocation) == 0xe0, "Size mismatch for UAbilityTask_MoveToLocation");
static_assert(offsetof(UAbilityTask_MoveToLocation, OnTargetLocationReached) == 0x78, "Offset mismatch for UAbilityTask_MoveToLocation::OnTargetLocationReached");
static_assert(offsetof(UAbilityTask_MoveToLocation, StartLocation) == 0x90, "Offset mismatch for UAbilityTask_MoveToLocation::StartLocation");
static_assert(offsetof(UAbilityTask_MoveToLocation, TargetLocation) == 0xa8, "Offset mismatch for UAbilityTask_MoveToLocation::TargetLocation");
static_assert(offsetof(UAbilityTask_MoveToLocation, DurationOfMovement) == 0xc0, "Offset mismatch for UAbilityTask_MoveToLocation::DurationOfMovement");
static_assert(offsetof(UAbilityTask_MoveToLocation, LerpCurve) == 0xd0, "Offset mismatch for UAbilityTask_MoveToLocation::LerpCurve");
static_assert(offsetof(UAbilityTask_MoveToLocation, LerpCurveVector) == 0xd8, "Offset mismatch for UAbilityTask_MoveToLocation::LerpCurveVector");

// Size: 0x90 (Inherited: 0x100, Single: 0xffffff90)
class UAbilityTask_NetworkSyncPoint : public UAbilityTask
{
public:
    uint8_t OnSync[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)

public:
    void OnSignalCallback(); // 0xb802fd0 (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_NetworkSyncPoint* WaitNetSync(UGameplayAbility*& OwningAbility, EAbilityTaskNetSyncType& SyncType); // 0xb810454 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_NetworkSyncPoint) == 0x90, "Size mismatch for UAbilityTask_NetworkSyncPoint");
static_assert(offsetof(UAbilityTask_NetworkSyncPoint, OnSync) == 0x78, "Offset mismatch for UAbilityTask_NetworkSyncPoint::OnSync");

// Size: 0x120 (Inherited: 0x100, Single: 0x20)
class UAbilityTask_PlayMontageAndWait : public UAbilityTask
{
public:
    uint8_t OnCompleted[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBlendedIn[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBlendOut[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInterrupted[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCancelled[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_c8[0x38]; // 0xc8 (Size: 0x38, Type: PaddingProperty)
    UAnimMontage* MontageToPlay; // 0x100 (Size: 0x8, Type: ObjectProperty)
    float Rate; // 0x108 (Size: 0x4, Type: FloatProperty)
    FName StartSection; // 0x10c (Size: 0x4, Type: NameProperty)
    float AnimRootMotionTranslationScale; // 0x110 (Size: 0x4, Type: FloatProperty)
    float StartTimeSeconds; // 0x114 (Size: 0x4, Type: FloatProperty)
    bool bStopWhenAbilityEnds; // 0x118 (Size: 0x1, Type: BoolProperty)
    bool bAllowInterruptAfterBlendOut; // 0x119 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11a[0x6]; // 0x11a (Size: 0x6, Type: PaddingProperty)

public:
    static UAbilityTask_PlayMontageAndWait* CreatePlayMontageAndWaitProxy(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, UAnimMontage*& MontageToPlay, float& Rate, FName& StartSection, bool& bStopWhenAbilityEnds, float& AnimRootMotionTranslationScale, float& StartTimeSeconds, bool& bAllowInterruptAfterBlendOut); // 0xb7f13c4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    void OnGameplayAbilityCancelled(); // 0xb801d8c (Index: 0x1, Flags: Final|Native|Public)
    void OnMontageBlendedIn(UAnimMontage*& Montage); // 0xb8026dc (Index: 0x2, Flags: Final|Native|Public)
    void OnMontageBlendingOut(UAnimMontage*& Montage, bool& bInterrupted); // 0xb802808 (Index: 0x3, Flags: Final|Native|Public)
    void OnMontageEnded(UAnimMontage*& Montage, bool& bInterrupted); // 0xb802a14 (Index: 0x4, Flags: Final|Native|Public)
    void OnMontageInterrupted(); // 0xb801d8c (Index: 0x5, Flags: Final|Native|Public)
};

static_assert(sizeof(UAbilityTask_PlayMontageAndWait) == 0x120, "Size mismatch for UAbilityTask_PlayMontageAndWait");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, OnCompleted) == 0x78, "Offset mismatch for UAbilityTask_PlayMontageAndWait::OnCompleted");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, OnBlendedIn) == 0x88, "Offset mismatch for UAbilityTask_PlayMontageAndWait::OnBlendedIn");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, OnBlendOut) == 0x98, "Offset mismatch for UAbilityTask_PlayMontageAndWait::OnBlendOut");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, OnInterrupted) == 0xa8, "Offset mismatch for UAbilityTask_PlayMontageAndWait::OnInterrupted");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, OnCancelled) == 0xb8, "Offset mismatch for UAbilityTask_PlayMontageAndWait::OnCancelled");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, MontageToPlay) == 0x100, "Offset mismatch for UAbilityTask_PlayMontageAndWait::MontageToPlay");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, Rate) == 0x108, "Offset mismatch for UAbilityTask_PlayMontageAndWait::Rate");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, StartSection) == 0x10c, "Offset mismatch for UAbilityTask_PlayMontageAndWait::StartSection");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, AnimRootMotionTranslationScale) == 0x110, "Offset mismatch for UAbilityTask_PlayMontageAndWait::AnimRootMotionTranslationScale");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, StartTimeSeconds) == 0x114, "Offset mismatch for UAbilityTask_PlayMontageAndWait::StartTimeSeconds");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, bStopWhenAbilityEnds) == 0x118, "Offset mismatch for UAbilityTask_PlayMontageAndWait::bStopWhenAbilityEnds");
static_assert(offsetof(UAbilityTask_PlayMontageAndWait, bAllowInterruptAfterBlendOut) == 0x119, "Offset mismatch for UAbilityTask_PlayMontageAndWait::bAllowInterruptAfterBlendOut");

// Size: 0xb0 (Inherited: 0x100, Single: 0xffffffb0)
class UAbilityTask_Repeat : public UAbilityTask
{
public:
    uint8_t OnPerformAction[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFinished[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x18]; // 0x98 (Size: 0x18, Type: PaddingProperty)

public:
    static UAbilityTask_Repeat* RepeatAction(UGameplayAbility*& OwningAbility, float& TimeBetweenActions, int32_t& TotalActionCount); // 0xb804ae4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_Repeat) == 0xb0, "Size mismatch for UAbilityTask_Repeat");
static_assert(offsetof(UAbilityTask_Repeat, OnPerformAction) == 0x78, "Offset mismatch for UAbilityTask_Repeat::OnPerformAction");
static_assert(offsetof(UAbilityTask_Repeat, OnFinished) == 0x88, "Offset mismatch for UAbilityTask_Repeat::OnFinished");

// Size: 0xc0 (Inherited: 0x100, Single: 0xffffffc0)
class UAbilityTask_SpawnActor : public UAbilityTask
{
public:
    uint8_t Success[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t DidNotSpawn[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x28]; // 0x98 (Size: 0x28, Type: PaddingProperty)

public:
    bool BeginSpawningActor(UGameplayAbility*& OwningAbility, FGameplayAbilityTargetDataHandle& TargetData, UClass*& Class, AActor*& SpawnedActor); // 0xb7eec28 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void FinishSpawningActor(UGameplayAbility*& OwningAbility, FGameplayAbilityTargetDataHandle& TargetData, AActor*& SpawnedActor); // 0xb7f55d0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    static UAbilityTask_SpawnActor* SpawnActor(UGameplayAbility*& OwningAbility, FGameplayAbilityTargetDataHandle& TargetData, UClass*& Class); // 0xb8077cc (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_SpawnActor) == 0xc0, "Size mismatch for UAbilityTask_SpawnActor");
static_assert(offsetof(UAbilityTask_SpawnActor, Success) == 0x78, "Offset mismatch for UAbilityTask_SpawnActor::Success");
static_assert(offsetof(UAbilityTask_SpawnActor, DidNotSpawn) == 0x88, "Offset mismatch for UAbilityTask_SpawnActor::DidNotSpawn");

// Size: 0xb0 (Inherited: 0x100, Single: 0xffffffb0)
class UAbilityTask_StartAbilityState : public UAbilityTask
{
public:
    uint8_t OnStateEnded[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStateInterrupted[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x18]; // 0x98 (Size: 0x18, Type: PaddingProperty)

public:
    static UAbilityTask_StartAbilityState* StartAbilityState(UGameplayAbility*& OwningAbility, FName& StateName, bool& bEndCurrentState); // 0xb807bb4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_StartAbilityState) == 0xb0, "Size mismatch for UAbilityTask_StartAbilityState");
static_assert(offsetof(UAbilityTask_StartAbilityState, OnStateEnded) == 0x78, "Offset mismatch for UAbilityTask_StartAbilityState::OnStateEnded");
static_assert(offsetof(UAbilityTask_StartAbilityState, OnStateInterrupted) == 0x88, "Offset mismatch for UAbilityTask_StartAbilityState::OnStateInterrupted");

// Size: 0xa0 (Inherited: 0x100, Single: 0xffffffa0)
class UAbilityTask_VisualizeTargeting : public UAbilityTask
{
public:
    uint8_t TimeElapsed[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x18]; // 0x88 (Size: 0x18, Type: PaddingProperty)

public:
    bool BeginSpawningActor(UGameplayAbility*& OwningAbility, UClass*& Class, AGameplayAbilityTargetActor*& SpawnedActor); // 0xb7ef1dc (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void FinishSpawningActor(UGameplayAbility*& OwningAbility, AGameplayAbilityTargetActor*& SpawnedActor); // 0xb7f5a08 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    static UAbilityTask_VisualizeTargeting* VisualizeTargeting(UGameplayAbility*& OwningAbility, UClass*& Class, FName& TaskInstanceName, float& duration); // 0xb809310 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(UGameplayAbility*& OwningAbility, AGameplayAbilityTargetActor*& TargetActor, FName& TaskInstanceName, float& duration); // 0xb809878 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_VisualizeTargeting) == 0xa0, "Size mismatch for UAbilityTask_VisualizeTargeting");
static_assert(offsetof(UAbilityTask_VisualizeTargeting, TimeElapsed) == 0x78, "Offset mismatch for UAbilityTask_VisualizeTargeting::TimeElapsed");

// Size: 0x170 (Inherited: 0x100, Single: 0x70)
class UAbilityTask_WaitAbilityActivate : public UAbilityTask
{
public:
    uint8_t OnActivate[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0xe8]; // 0x88 (Size: 0xe8, Type: PaddingProperty)

public:
    void OnAbilityActivate(UGameplayAbility*& ActivatedAbility); // 0xb801760 (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(UGameplayAbility*& OwningAbility, FGameplayTag& WithTag, FGameplayTag& WithoutTag, bool& IncludeTriggeredAbilities, bool& TriggerOnce); // 0xb80a274 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate_Query(UGameplayAbility*& OwningAbility, FGameplayTagQuery& Query, bool& IncludeTriggeredAbilities, bool& TriggerOnce); // 0xb80a8ac (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(UGameplayAbility*& OwningAbility, FGameplayTagRequirements& TagRequirements, bool& IncludeTriggeredAbilities, bool& TriggerOnce); // 0xb80a570 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitAbilityActivate) == 0x170, "Size mismatch for UAbilityTask_WaitAbilityActivate");
static_assert(offsetof(UAbilityTask_WaitAbilityActivate, OnActivate) == 0x78, "Offset mismatch for UAbilityTask_WaitAbilityActivate::OnActivate");

// Size: 0xe8 (Inherited: 0x100, Single: 0xffffffe8)
class UAbilityTask_WaitAbilityCommit : public UAbilityTask
{
public:
    uint8_t OnCommit[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x60]; // 0x88 (Size: 0x60, Type: PaddingProperty)

public:
    void OnAbilityCommit(UGameplayAbility*& ActivatedAbility); // 0xb80188c (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit(UGameplayAbility*& OwningAbility, FGameplayTag& WithTag, FGameplayTag& WithoutTage, bool& TriggerOnce); // 0xb80ae48 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit_Query(UGameplayAbility*& OwningAbility, FGameplayTagQuery& Query, bool& TriggerOnce); // 0xb80b0b4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitAbilityCommit) == 0xe8, "Size mismatch for UAbilityTask_WaitAbilityCommit");
static_assert(offsetof(UAbilityTask_WaitAbilityCommit, OnCommit) == 0x78, "Offset mismatch for UAbilityTask_WaitAbilityCommit::OnCommit");

// Size: 0xe8 (Inherited: 0x100, Single: 0xffffffe8)
class UAbilityTask_WaitAttributeChange : public UAbilityTask
{
public:
    uint8_t OnChange[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x58]; // 0x88 (Size: 0x58, Type: PaddingProperty)
    UAbilitySystemComponent* ExternalOwner; // 0xe0 (Size: 0x8, Type: ObjectProperty)

public:
    static UAbilityTask_WaitAttributeChange* WaitForAttributeChange(UGameplayAbility*& OwningAbility, FGameplayAttribute& Attribute, FGameplayTag& WithSrcTag, FGameplayTag& WithoutSrcTag, bool& TriggerOnce, AActor*& OptionalExternalOwner); // 0xb80b5dc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(UGameplayAbility*& OwningAbility, FGameplayAttribute& InAttribute, FGameplayTag& InWithTag, FGameplayTag& InWithoutTag, TEnumAsByte<EWaitAttributeChangeComparison>& InComparisonType, float& InComparisonValue, bool& TriggerOnce, AActor*& OptionalExternalOwner); // 0xb80c7d0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitAttributeChange) == 0xe8, "Size mismatch for UAbilityTask_WaitAttributeChange");
static_assert(offsetof(UAbilityTask_WaitAttributeChange, OnChange) == 0x78, "Offset mismatch for UAbilityTask_WaitAttributeChange::OnChange");
static_assert(offsetof(UAbilityTask_WaitAttributeChange, ExternalOwner) == 0xe0, "Offset mismatch for UAbilityTask_WaitAttributeChange::ExternalOwner");

// Size: 0x138 (Inherited: 0x100, Single: 0x38)
class UAbilityTask_WaitAttributeChangeRatioThreshold : public UAbilityTask
{
public:
    uint8_t OnChange[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0xa8]; // 0x88 (Size: 0xa8, Type: PaddingProperty)
    UAbilitySystemComponent* ExternalOwner; // 0x130 (Size: 0x8, Type: ObjectProperty)

public:
    static UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(UGameplayAbility*& OwningAbility, FGameplayAttribute& AttributeNumerator, FGameplayAttribute& AttributeDenominator, TEnumAsByte<EWaitAttributeChangeComparison>& ComparisonType, float& ComparisonValue, bool& bTriggerOnce, AActor*& OptionalExternalOwner); // 0xb80bb44 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitAttributeChangeRatioThreshold) == 0x138, "Size mismatch for UAbilityTask_WaitAttributeChangeRatioThreshold");
static_assert(offsetof(UAbilityTask_WaitAttributeChangeRatioThreshold, OnChange) == 0x78, "Offset mismatch for UAbilityTask_WaitAttributeChangeRatioThreshold::OnChange");
static_assert(offsetof(UAbilityTask_WaitAttributeChangeRatioThreshold, ExternalOwner) == 0x130, "Offset mismatch for UAbilityTask_WaitAttributeChangeRatioThreshold::ExternalOwner");

// Size: 0xe8 (Inherited: 0x100, Single: 0xffffffe8)
class UAbilityTask_WaitAttributeChangeThreshold : public UAbilityTask
{
public:
    uint8_t OnChange[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x58]; // 0x88 (Size: 0x58, Type: PaddingProperty)
    UAbilitySystemComponent* ExternalOwner; // 0xe0 (Size: 0x8, Type: ObjectProperty)

public:
    static UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(UGameplayAbility*& OwningAbility, FGameplayAttribute& Attribute, TEnumAsByte<EWaitAttributeChangeComparison>& ComparisonType, float& ComparisonValue, bool& bTriggerOnce, AActor*& OptionalExternalOwner); // 0xb80c22c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitAttributeChangeThreshold) == 0xe8, "Size mismatch for UAbilityTask_WaitAttributeChangeThreshold");
static_assert(offsetof(UAbilityTask_WaitAttributeChangeThreshold, OnChange) == 0x78, "Offset mismatch for UAbilityTask_WaitAttributeChangeThreshold::OnChange");
static_assert(offsetof(UAbilityTask_WaitAttributeChangeThreshold, ExternalOwner) == 0xe0, "Offset mismatch for UAbilityTask_WaitAttributeChangeThreshold::ExternalOwner");

// Size: 0x90 (Inherited: 0x100, Single: 0xffffff90)
class UAbilityTask_WaitCancel : public UAbilityTask
{
public:
    uint8_t OnCancel[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)

public:
    void OnCancelCallback(); // 0xb801c24 (Index: 0x0, Flags: Final|Native|Public)
    void OnLocalCancelCallback(); // 0xb8026a0 (Index: 0x1, Flags: Final|Native|Public)
    static UAbilityTask_WaitCancel* WaitCancel(UGameplayAbility*& OwningAbility); // 0xb809c28 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitCancel) == 0x90, "Size mismatch for UAbilityTask_WaitCancel");
static_assert(offsetof(UAbilityTask_WaitCancel, OnCancel) == 0x78, "Offset mismatch for UAbilityTask_WaitCancel::OnCancel");

// Size: 0x98 (Inherited: 0x100, Single: 0xffffff98)
class UAbilityTask_WaitConfirm : public UAbilityTask
{
public:
    uint8_t OnConfirm[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)

public:
    void OnConfirmCallback(UGameplayAbility*& InAbility); // 0xb801c4c (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_WaitConfirm* WaitConfirm(UGameplayAbility*& OwningAbility); // 0xb809d8c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitConfirm) == 0x98, "Size mismatch for UAbilityTask_WaitConfirm");
static_assert(offsetof(UAbilityTask_WaitConfirm, OnConfirm) == 0x78, "Offset mismatch for UAbilityTask_WaitConfirm::OnConfirm");

// Size: 0xa0 (Inherited: 0x100, Single: 0xffffffa0)
class UAbilityTask_WaitConfirmCancel : public UAbilityTask
{
public:
    uint8_t OnConfirm[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCancel[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x8]; // 0x98 (Size: 0x8, Type: PaddingProperty)

public:
    void OnCancelCallback(); // 0xb801c38 (Index: 0x0, Flags: Final|Native|Public)
    void OnConfirmCallback(); // 0xb801d78 (Index: 0x1, Flags: Final|Native|Public)
    void OnLocalCancelCallback(); // 0xb8026b4 (Index: 0x2, Flags: Final|Native|Public)
    void OnLocalConfirmCallback(); // 0xb8026c8 (Index: 0x3, Flags: Final|Native|Public)
    static UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(UGameplayAbility*& OwningAbility); // 0xb809ef0 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitConfirmCancel) == 0xa0, "Size mismatch for UAbilityTask_WaitConfirmCancel");
static_assert(offsetof(UAbilityTask_WaitConfirmCancel, OnConfirm) == 0x78, "Offset mismatch for UAbilityTask_WaitConfirmCancel::OnConfirm");
static_assert(offsetof(UAbilityTask_WaitConfirmCancel, OnCancel) == 0x88, "Offset mismatch for UAbilityTask_WaitConfirmCancel::OnCancel");

// Size: 0x90 (Inherited: 0x100, Single: 0xffffff90)
class UAbilityTask_WaitDelay : public UAbilityTask
{
public:
    uint8_t OnFinish[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)

public:
    static UAbilityTask_WaitDelay* WaitDelay(UGameplayAbility*& OwningAbility, float& time); // 0xb80a054 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitDelay) == 0x90, "Size mismatch for UAbilityTask_WaitDelay");
static_assert(offsetof(UAbilityTask_WaitDelay, OnFinish) == 0x78, "Offset mismatch for UAbilityTask_WaitDelay::OnFinish");

// Size: 0x240 (Inherited: 0x100, Single: 0x140)
class UAbilityTask_WaitGameplayEffectApplied : public UAbilityTask
{
public:
    uint8_t Pad_78[0x1b8]; // 0x78 (Size: 0x1b8, Type: PaddingProperty)
    UAbilitySystemComponent* ExternalOwner; // 0x230 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_238[0x8]; // 0x238 (Size: 0x8, Type: PaddingProperty)

public:
    void OnApplyGameplayEffectCallback(UAbilitySystemComponent*& Target, const FGameplayEffectSpec SpecApplied, FActiveGameplayEffectHandle& ActiveHandle); // 0xb8019b8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEffectApplied) == 0x240, "Size mismatch for UAbilityTask_WaitGameplayEffectApplied");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectApplied, ExternalOwner) == 0x230, "Offset mismatch for UAbilityTask_WaitGameplayEffectApplied::ExternalOwner");

// Size: 0x260 (Inherited: 0x340, Single: 0xffffff20)
class UAbilityTask_WaitGameplayEffectApplied_Self : public UAbilityTask_WaitGameplayEffectApplied
{
public:
    uint8_t OnApplied[0x10]; // 0x240 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_250[0x10]; // 0x250 (Size: 0x10, Type: PaddingProperty)

public:
    static UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(UGameplayAbility*& OwningAbility, FGameplayTargetDataFilterHandle& const SourceFilter, FGameplayTagRequirements& SourceTagRequirements, FGameplayTagRequirements& TargetTagRequirements, bool& TriggerOnce, AActor*& OptionalExternalOwner, bool& ListenForPeriodicEffect); // 0xb80d374 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf_Query(UGameplayAbility*& OwningAbility, FGameplayTargetDataFilterHandle& const SourceFilter, FGameplayTagQuery& SourceTagQuery, FGameplayTagQuery& TargetTagQuery, bool& TriggerOnce, AActor*& OptionalExternalOwner, bool& ListenForPeriodicEffect); // 0xb80d854 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEffectApplied_Self) == 0x260, "Size mismatch for UAbilityTask_WaitGameplayEffectApplied_Self");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectApplied_Self, OnApplied) == 0x240, "Offset mismatch for UAbilityTask_WaitGameplayEffectApplied_Self::OnApplied");

// Size: 0x260 (Inherited: 0x340, Single: 0xffffff20)
class UAbilityTask_WaitGameplayEffectApplied_Target : public UAbilityTask_WaitGameplayEffectApplied
{
public:
    uint8_t OnApplied[0x10]; // 0x240 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_250[0x10]; // 0x250 (Size: 0x10, Type: PaddingProperty)

public:
    static UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(UGameplayAbility*& OwningAbility, FGameplayTargetDataFilterHandle& const TargetFilter, FGameplayTagRequirements& SourceTagRequirements, FGameplayTagRequirements& TargetTagRequirements, bool& TriggerOnce, AActor*& OptionalExternalOwner, bool& ListenForPeriodicEffects); // 0xb80dff0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget_Query(UGameplayAbility*& OwningAbility, FGameplayTargetDataFilterHandle& const SourceFilter, FGameplayTagQuery& SourceTagQuery, FGameplayTagQuery& TargetTagQuery, bool& TriggerOnce, AActor*& OptionalExternalOwner, bool& ListenForPeriodicEffect); // 0xb80e4d0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEffectApplied_Target) == 0x260, "Size mismatch for UAbilityTask_WaitGameplayEffectApplied_Target");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectApplied_Target, OnApplied) == 0x240, "Offset mismatch for UAbilityTask_WaitGameplayEffectApplied_Target::OnApplied");

// Size: 0x1b0 (Inherited: 0x100, Single: 0xb0)
class UAbilityTask_WaitGameplayEffectBlockedImmunity : public UAbilityTask
{
public:
    uint8_t bLocked[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x118]; // 0x88 (Size: 0x118, Type: PaddingProperty)
    UAbilitySystemComponent* ExternalOwner; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)

public:
    static UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(UGameplayAbility*& OwningAbility, FGameplayTagRequirements& SourceTagRequirements, FGameplayTagRequirements& TargetTagRequirements, AActor*& OptionalExternalTarget, bool& OnlyTriggerOnce); // 0xb80ec6c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEffectBlockedImmunity) == 0x1b0, "Size mismatch for UAbilityTask_WaitGameplayEffectBlockedImmunity");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectBlockedImmunity, bLocked) == 0x78, "Offset mismatch for UAbilityTask_WaitGameplayEffectBlockedImmunity::bLocked");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectBlockedImmunity, ExternalOwner) == 0x1a0, "Offset mismatch for UAbilityTask_WaitGameplayEffectBlockedImmunity::ExternalOwner");

// Size: 0xb8 (Inherited: 0x100, Single: 0xffffffb8)
class UAbilityTask_WaitGameplayEffectRemoved : public UAbilityTask
{
public:
    uint8_t OnRemoved[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t InvalidHandle[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x20]; // 0x98 (Size: 0x20, Type: PaddingProperty)

public:
    void OnGameplayEffectRemoved(const FGameplayEffectRemovalInfo InGameplayEffectRemovalInfo); // 0xb801da0 (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
    static UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(UGameplayAbility*& OwningAbility, FActiveGameplayEffectHandle& Handle); // 0xb80ce60 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEffectRemoved) == 0xb8, "Size mismatch for UAbilityTask_WaitGameplayEffectRemoved");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectRemoved, OnRemoved) == 0x78, "Offset mismatch for UAbilityTask_WaitGameplayEffectRemoved::OnRemoved");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectRemoved, InvalidHandle) == 0x88, "Offset mismatch for UAbilityTask_WaitGameplayEffectRemoved::InvalidHandle");

// Size: 0xb0 (Inherited: 0x100, Single: 0xffffffb0)
class UAbilityTask_WaitGameplayEffectStackChange : public UAbilityTask
{
public:
    uint8_t OnChange[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t InvalidHandle[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x18]; // 0x98 (Size: 0x18, Type: PaddingProperty)

public:
    void OnGameplayEffectStackChange(FActiveGameplayEffectHandle& Handle, int32_t& NewCount, int32_t& OldCount); // 0xb801e94 (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(UGameplayAbility*& OwningAbility, FActiveGameplayEffectHandle& Handle); // 0xb80d038 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEffectStackChange) == 0xb0, "Size mismatch for UAbilityTask_WaitGameplayEffectStackChange");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectStackChange, OnChange) == 0x78, "Offset mismatch for UAbilityTask_WaitGameplayEffectStackChange::OnChange");
static_assert(offsetof(UAbilityTask_WaitGameplayEffectStackChange, InvalidHandle) == 0x88, "Offset mismatch for UAbilityTask_WaitGameplayEffectStackChange::InvalidHandle");

// Size: 0xa8 (Inherited: 0x100, Single: 0xffffffa8)
class UAbilityTask_WaitGameplayEvent : public UAbilityTask
{
public:
    uint8_t EventReceived[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    UAbilitySystemComponent* OptionalExternalTarget; // 0x90 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_98[0x10]; // 0x98 (Size: 0x10, Type: PaddingProperty)

public:
    static UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(UGameplayAbility*& OwningAbility, FGameplayTag& EventTag, AActor*& OptionalExternalTarget, bool& OnlyTriggerOnce, bool& OnlyMatchExact); // 0xb80eff0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayEvent) == 0xa8, "Size mismatch for UAbilityTask_WaitGameplayEvent");
static_assert(offsetof(UAbilityTask_WaitGameplayEvent, EventReceived) == 0x78, "Offset mismatch for UAbilityTask_WaitGameplayEvent::EventReceived");
static_assert(offsetof(UAbilityTask_WaitGameplayEvent, OptionalExternalTarget) == 0x90, "Offset mismatch for UAbilityTask_WaitGameplayEvent::OptionalExternalTarget");

// Size: 0xa8 (Inherited: 0x198, Single: 0xffffff10)
class UAbilityTask_WaitGameplayTagAdded : public UAbilityTask_WaitGameplayTag
{
public:
    uint8_t Added[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    static UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(UGameplayAbility*& OwningAbility, FGameplayTag& Tag, AActor*& InOptionalExternalTarget, bool& OnlyTriggerOnce); // 0xb80f360 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayTagAdded) == 0xa8, "Size mismatch for UAbilityTask_WaitGameplayTagAdded");
static_assert(offsetof(UAbilityTask_WaitGameplayTagAdded, Added) == 0x98, "Offset mismatch for UAbilityTask_WaitGameplayTagAdded::Added");

// Size: 0x98 (Inherited: 0x100, Single: 0xffffff98)
class UAbilityTask_WaitGameplayTag : public UAbilityTask
{
public:
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
    UAbilitySystemComponent* OptionalExternalTarget; // 0x80 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)

public:
    void GameplayTagCallback(FGameplayTag& const Tag, int32_t& NewCount); // 0xb7f63c8 (Index: 0x0, Flags: Native|Public)
};

static_assert(sizeof(UAbilityTask_WaitGameplayTag) == 0x98, "Size mismatch for UAbilityTask_WaitGameplayTag");
static_assert(offsetof(UAbilityTask_WaitGameplayTag, OptionalExternalTarget) == 0x80, "Offset mismatch for UAbilityTask_WaitGameplayTag::OptionalExternalTarget");

// Size: 0xa8 (Inherited: 0x198, Single: 0xffffff10)
class UAbilityTask_WaitGameplayTagRemoved : public UAbilityTask_WaitGameplayTag
{
public:
    uint8_t Removed[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    static UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(UGameplayAbility*& OwningAbility, FGameplayTag& Tag, AActor*& InOptionalExternalTarget, bool& OnlyTriggerOnce); // 0xb80fcd0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitGameplayTagRemoved) == 0xa8, "Size mismatch for UAbilityTask_WaitGameplayTagRemoved");
static_assert(offsetof(UAbilityTask_WaitGameplayTagRemoved, Removed) == 0x98, "Offset mismatch for UAbilityTask_WaitGameplayTagRemoved::Removed");

// Size: 0x158 (Inherited: 0x100, Single: 0x58)
class UAbilityTask_WaitGameplayTagQuery : public UAbilityTask
{
public:
    uint8_t Pad_78[0xc0]; // 0x78 (Size: 0xc0, Type: PaddingProperty)
    uint8_t Triggered[0x10]; // 0x138 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UAbilitySystemComponent* OptionalExternalTarget; // 0x148 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_150[0x8]; // 0x150 (Size: 0x8, Type: PaddingProperty)

public:
    static UAbilityTask_WaitGameplayTagQuery* WaitGameplayTagQuery(UGameplayAbility*& OwningAbility, FGameplayTagQuery& const TagQuery, AActor*& const InOptionalExternalTarget, EWaitGameplayTagQueryTriggerCondition& const TriggerCondition, bool& const bOnlyTriggerOnce); // 0xb80f654 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)

protected:
    void UpdateTargetTags(FGameplayTag& const Tag, int32_t& NewCount); // 0xb8091d8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UAbilityTask_WaitGameplayTagQuery) == 0x158, "Size mismatch for UAbilityTask_WaitGameplayTagQuery");
static_assert(offsetof(UAbilityTask_WaitGameplayTagQuery, Triggered) == 0x138, "Offset mismatch for UAbilityTask_WaitGameplayTagQuery::Triggered");
static_assert(offsetof(UAbilityTask_WaitGameplayTagQuery, OptionalExternalTarget) == 0x148, "Offset mismatch for UAbilityTask_WaitGameplayTagQuery::OptionalExternalTarget");

// Size: 0x98 (Inherited: 0x100, Single: 0xffffff98)
class UAbilityTask_WaitInputPress : public UAbilityTask
{
public:
    uint8_t OnPress[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)

public:
    void OnPressCallback(); // 0xb802f3c (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_WaitInputPress* WaitInputPress(UGameplayAbility*& OwningAbility, bool& bTestAlreadyPressed); // 0xb80ffc4 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitInputPress) == 0x98, "Size mismatch for UAbilityTask_WaitInputPress");
static_assert(offsetof(UAbilityTask_WaitInputPress, OnPress) == 0x78, "Offset mismatch for UAbilityTask_WaitInputPress::OnPress");

// Size: 0x98 (Inherited: 0x100, Single: 0xffffff98)
class UAbilityTask_WaitInputRelease : public UAbilityTask
{
public:
    uint8_t OnRelease[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)

public:
    void OnReleaseCallback(); // 0xb802f50 (Index: 0x0, Flags: Final|Native|Public)
    static UAbilityTask_WaitInputRelease* WaitInputRelease(UGameplayAbility*& OwningAbility, bool& bTestAlreadyReleased); // 0xb81020c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitInputRelease) == 0x98, "Size mismatch for UAbilityTask_WaitInputRelease");
static_assert(offsetof(UAbilityTask_WaitInputRelease, OnRelease) == 0x78, "Offset mismatch for UAbilityTask_WaitInputRelease::OnRelease");

// Size: 0x98 (Inherited: 0x100, Single: 0xffffff98)
class UAbilityTask_WaitMovementModeChange : public UAbilityTask
{
public:
    uint8_t OnChange[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)

public:
    static UAbilityTask_WaitMovementModeChange* CreateWaitMovementModeChange(UGameplayAbility*& OwningAbility, TEnumAsByte<EMovementMode>& NewMode); // 0xb7f1a74 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    void OnMovementModeChange(ACharacter*& Character, TEnumAsByte<EMovementMode>& PrevMovementMode, char& PreviousCustomMode); // 0xb802c20 (Index: 0x1, Flags: Final|Native|Public)
};

static_assert(sizeof(UAbilityTask_WaitMovementModeChange) == 0x98, "Size mismatch for UAbilityTask_WaitMovementModeChange");
static_assert(offsetof(UAbilityTask_WaitMovementModeChange, OnChange) == 0x78, "Offset mismatch for UAbilityTask_WaitMovementModeChange::OnChange");

// Size: 0x88 (Inherited: 0x100, Single: 0xffffff88)
class UAbilityTask_WaitOverlap : public UAbilityTask
{
public:
    uint8_t OnOverlap[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnHitCallback(UPrimitiveComponent*& HitComp, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, FVector& NormalImpulse, const FHitResult Hit); // 0xb802044 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults)
    static UAbilityTask_WaitOverlap* WaitForOverlap(UGameplayAbility*& OwningAbility); // 0xb80d210 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitOverlap) == 0x88, "Size mismatch for UAbilityTask_WaitOverlap");
static_assert(offsetof(UAbilityTask_WaitOverlap, OnOverlap) == 0x78, "Offset mismatch for UAbilityTask_WaitOverlap::OnOverlap");

// Size: 0xb8 (Inherited: 0x100, Single: 0xffffffb8)
class UAbilityTask_WaitTargetData : public UAbilityTask
{
public:
    uint8_t ValidData[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Cancelled[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* TargetClass; // 0x98 (Size: 0x8, Type: ClassProperty)
    AGameplayAbilityTargetActor* TargetActor; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_a8[0x10]; // 0xa8 (Size: 0x10, Type: PaddingProperty)

public:
    bool BeginSpawningActor(UGameplayAbility*& OwningAbility, UClass*& Class, AGameplayAbilityTargetActor*& SpawnedActor); // 0xb7ef794 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void FinishSpawningActor(UGameplayAbility*& OwningAbility, AGameplayAbilityTargetActor*& SpawnedActor); // 0xb7f5d44 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void OnTargetDataCancelledCallback(const FGameplayAbilityTargetDataHandle Data); // 0xb8035e4 (Index: 0x2, Flags: Native|Public|HasOutParms)
    void OnTargetDataReadyCallback(const FGameplayAbilityTargetDataHandle Data); // 0xb8036ec (Index: 0x3, Flags: Native|Public|HasOutParms)
    void OnTargetDataReplicatedCallback(const FGameplayAbilityTargetDataHandle Data, FGameplayTag& ActivationTag); // 0xb8037f4 (Index: 0x4, Flags: Native|Public|HasOutParms)
    void OnTargetDataReplicatedCancelledCallback(); // 0x4b4be24 (Index: 0x5, Flags: Native|Public)
    static UAbilityTask_WaitTargetData* WaitTargetData(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, TEnumAsByte<EGameplayTargetingConfirmation>& ConfirmationType, UClass*& Class); // 0xb810698 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(UGameplayAbility*& OwningAbility, FName& TaskInstanceName, TEnumAsByte<EGameplayTargetingConfirmation>& ConfirmationType, AGameplayAbilityTargetActor*& TargetActor); // 0xb810d58 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitTargetData) == 0xb8, "Size mismatch for UAbilityTask_WaitTargetData");
static_assert(offsetof(UAbilityTask_WaitTargetData, ValidData) == 0x78, "Offset mismatch for UAbilityTask_WaitTargetData::ValidData");
static_assert(offsetof(UAbilityTask_WaitTargetData, Cancelled) == 0x88, "Offset mismatch for UAbilityTask_WaitTargetData::Cancelled");
static_assert(offsetof(UAbilityTask_WaitTargetData, TargetClass) == 0x98, "Offset mismatch for UAbilityTask_WaitTargetData::TargetClass");
static_assert(offsetof(UAbilityTask_WaitTargetData, TargetActor) == 0xa0, "Offset mismatch for UAbilityTask_WaitTargetData::TargetActor");

// Size: 0xb0 (Inherited: 0x100, Single: 0xffffffb0)
class UAbilityTask_WaitVelocityChange : public UAbilityTask
{
public:
    uint8_t OnVelocityChage[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TWeakObjectPtr<UMovementComponent*> CachedMovementComponent; // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_90[0x20]; // 0x90 (Size: 0x20, Type: PaddingProperty)

public:
    static UAbilityTask_WaitVelocityChange* CreateWaitVelocityChange(UGameplayAbility*& OwningAbility, FVector& Direction, float& MinimumMagnitude); // 0xb7f1cb4 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAbilityTask_WaitVelocityChange) == 0xb0, "Size mismatch for UAbilityTask_WaitVelocityChange");
static_assert(offsetof(UAbilityTask_WaitVelocityChange, OnVelocityChage) == 0x78, "Offset mismatch for UAbilityTask_WaitVelocityChange::OnVelocityChage");
static_assert(offsetof(UAbilityTask_WaitVelocityChange, CachedMovementComponent) == 0x88, "Offset mismatch for UAbilityTask_WaitVelocityChange::CachedMovementComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAbilitySystemBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FGameplayAbilityTargetDataHandle AbilityTargetDataFromActor(AActor*& Actor); // 0xb7e9510 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayAbilityTargetDataHandle AbilityTargetDataFromActorArray(const TArray<AActor*> ActorArray, bool& OneTargetPerHandle); // 0x48a042c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayAbilityTargetDataHandle AbilityTargetDataFromHitResult(const FHitResult HitResult); // 0xb7e9740 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayAbilityTargetDataHandle AbilityTargetDataFromLocations(const FGameplayAbilityTargetingLocationInfo SourceLocation, const FGameplayAbilityTargetingLocationInfo TargetLocation); // 0xb7e993c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayEffectSpecHandle AddAssetTag(FGameplayEffectSpecHandle& SpecHandle, FGameplayTag& NewGameplayTag); // 0xb7e9b58 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle AddAssetTags(FGameplayEffectSpecHandle& SpecHandle, FGameplayTagContainer& NewGameplayTags); // 0xb7e9d14 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle AddGrantedTag(FGameplayEffectSpecHandle& SpecHandle, FGameplayTag& NewGameplayTag); // 0xb7e9fe8 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle AddGrantedTags(FGameplayEffectSpecHandle& SpecHandle, FGameplayTagContainer& NewGameplayTags); // 0xb7ea1a4 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle AddLinkedGameplayEffect(FGameplayEffectSpecHandle& SpecHandle, UClass*& LinkedGameplayEffect); // 0xb7ea478 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle AddLinkedGameplayEffectSpec(FGameplayEffectSpecHandle& SpecHandle, FGameplayEffectSpecHandle& LinkedGameplayEffectSpec); // 0xb7ea7d0 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool AddLooseGameplayTags(AActor*& Actor, const FGameplayTagContainer GameplayTags, bool& bShouldReplicate); // 0x52c4be0 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGameplayAbilityTargetDataHandle AppendTargetDataHandle(FGameplayAbilityTargetDataHandle& TargetHandle, const FGameplayAbilityTargetDataHandle HandleToAdd); // 0xb7ea9e4 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGameplayEffectSpecHandle AssignSetByCallerMagnitude(FGameplayEffectSpecHandle& SpecHandle, FName& DataName, float& Magnitude); // 0xb7ee4dc (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle AssignTagSetByCallerMagnitude(FGameplayEffectSpecHandle& SpecHandle, FGameplayTag& DataTag, float& Magnitude); // 0xb7ee6f4 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void BreakGameplayCueParameters(const FGameplayCueParameters Parameters, float& NormalizedMagnitude, float& RawMagnitude, FGameplayEffectContextHandle& EffectContext, FGameplayTag& MatchedTagName, FGameplayTag& OriginalTag, FGameplayTagContainer& AggregatedSourceTags, FGameplayTagContainer& AggregatedTargetTags, FVector& Location, FVector& Normal, AActor*& Instigator, AActor*& EffectCauser, UObject*& SourceObject, UPhysicalMaterial*& PhysicalMaterial, int32_t& GameplayEffectLevel, int32_t& AbilityLevel, USceneComponent*& TargetAttachComponent, bool& bReplicateLocationWhenUsingMinimalRepProxy); // 0x34052ec (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FGameplayEffectSpecHandle CloneSpecHandle(AActor*& InNewInstigator, AActor*& InEffectCauser, FGameplayEffectSpecHandle& GameplayEffectSpecHandle_Clone); // 0xb7f0d9c (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static double Conv_ScalableFloatToDouble(const FScalableFloat Input, float& Level); // 0xb7f108c (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float Conv_ScalableFloatToFloat(const FScalableFloat Input, float& Level); // 0xb7f122c (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool DoesGameplayCueMeetTagRequirements(FGameplayCueParameters& Parameters, const FGameplayTagRequirements SourceTagReqs, const FGameplayTagRequirements TargetTagReqs); // 0xb7f1ecc (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool DoesTargetDataContainActor(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index, AActor*& Actor); // 0xb7f2198 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void EffectContextAddHitResult(FGameplayEffectContextHandle& EffectContext, FHitResult& HitResult, bool& bReset); // 0xb7f2384 (Index: 0x14, Flags: Final|Native|Static|Public|BlueprintCallable)
    static AActor* EffectContextGetEffectCauser(FGameplayEffectContextHandle& EffectContext); // 0xb7f25e8 (Index: 0x15, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FHitResult EffectContextGetHitResult(FGameplayEffectContextHandle& EffectContext); // 0x4d442d8 (Index: 0x16, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static AActor* EffectContextGetInstigatorActor(FGameplayEffectContextHandle& EffectContext); // 0x5ebddd0 (Index: 0x17, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector EffectContextGetOrigin(FGameplayEffectContextHandle& EffectContext); // 0x5acc970 (Index: 0x18, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static AActor* EffectContextGetOriginalInstigatorActor(FGameplayEffectContextHandle& EffectContext); // 0xb7f2750 (Index: 0x19, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UObject* EffectContextGetSourceObject(FGameplayEffectContextHandle& EffectContext); // 0xb7f28b8 (Index: 0x1a, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EffectContextHasHitResult(FGameplayEffectContextHandle& EffectContext); // 0xb7f2a20 (Index: 0x1b, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EffectContextIsInstigatorLocallyControlled(FGameplayEffectContextHandle& EffectContext); // 0xb7f2b8c (Index: 0x1c, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EffectContextIsValid(FGameplayEffectContextHandle& EffectContext); // 0xb7f2cf8 (Index: 0x1d, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void EffectContextSetOrigin(FGameplayEffectContextHandle& EffectContext, FVector& origin); // 0xb7f2e58 (Index: 0x1e, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static bool EqualEqual_ActiveGameplayEffectHandle(const FActiveGameplayEffectHandle A, const FActiveGameplayEffectHandle B); // 0xb7f3030 (Index: 0x1f, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool EqualEqual_GameplayAbilitySpecHandle(const FGameplayAbilitySpecHandle A, const FGameplayAbilitySpecHandle B); // 0xb7f31a8 (Index: 0x20, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool EqualEqual_GameplayAttributeGameplayAttribute(FGameplayAttribute& AttributeA, FGameplayAttribute& AttributeB); // 0xb7f3314 (Index: 0x21, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static float EvaluateAttributeValueWithTags(UAbilitySystemComponent*& AbilitySystem, FGameplayAttribute& Attribute, const FGameplayTagContainer SourceTags, const FGameplayTagContainer TargetTags, bool& bSuccess); // 0xb7f37bc (Index: 0x22, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float EvaluateAttributeValueWithTagsAndBase(UAbilitySystemComponent*& AbilitySystem, FGameplayAttribute& Attribute, const FGameplayTagContainer SourceTags, const FGameplayTagContainer TargetTags, float& BaseValue, bool& bSuccess); // 0xb7f3e9c (Index: 0x23, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayAbilityTargetDataHandle FilterTargetData(const FGameplayAbilityTargetDataHandle TargetDataHandle, FGameplayTargetDataFilterHandle& ActorFilterClass); // 0xb7f472c (Index: 0x24, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void ForwardGameplayCueToTarget(TScriptInterface<Class>& TargetCueInterface, TEnumAsByte<EGameplayCueEvent>& EventType, FGameplayCueParameters& Parameters); // 0xb7f5f50 (Index: 0x25, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAbilitySystemComponent* GetAbilitySystemComponent(AActor*& Actor); // 0x532b92c (Index: 0x26, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FString GetActiveGameplayEffectDebugString(FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f69f8 (Index: 0x27, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static float GetActiveGameplayEffectExpectedEndTime(FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f6ce0 (Index: 0x28, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetActiveGameplayEffectRemainingDuration(UObject*& WorldContextObject, FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f6da8 (Index: 0x29, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetActiveGameplayEffectStackCount(FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f6f58 (Index: 0x2a, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetActiveGameplayEffectStackLimitCount(FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f704c (Index: 0x2b, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetActiveGameplayEffectStartTime(FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f713c (Index: 0x2c, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetActiveGameplayEffectTotalDuration(FActiveGameplayEffectHandle& ActiveHandle); // 0xb7f7204 (Index: 0x2d, Flags: Final|Native|Static|Public|BlueprintCallable)
    static AActor* GetActorByIndex(FGameplayCueParameters& Parameters, int32_t& Index); // 0xb7f72cc (Index: 0x2e, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetActorCount(FGameplayCueParameters& Parameters); // 0xb7f7600 (Index: 0x2f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<AActor*> GetActorsFromTargetData(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb7f7774 (Index: 0x30, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<AActor*> GetAllActorsFromTargetData(const FGameplayAbilityTargetDataHandle TargetData); // 0xb7f7c00 (Index: 0x31, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<FGameplayEffectSpecHandle> GetAllLinkedGameplayEffectSpecHandles(FGameplayEffectSpecHandle& SpecHandle); // 0xb7f8034 (Index: 0x32, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetDataCountFromTargetData(const FGameplayAbilityTargetDataHandle TargetData); // 0xb7f843c (Index: 0x33, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FString GetDebugStringFromGameplayAttribute(const FGameplayAttribute Attribute); // 0xb7f853c (Index: 0x34, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayEffectContextHandle GetEffectContext(FGameplayEffectSpecHandle& SpecHandle); // 0xb7f88d8 (Index: 0x35, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetFloatAttribute(AActor*& const Actor, FGameplayAttribute& Attribute, bool& bSuccessfullyFoundAttribute); // 0xb7f8a30 (Index: 0x36, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetFloatAttributeBase(AActor*& const Actor, FGameplayAttribute& Attribute, bool& bSuccessfullyFoundAttribute); // 0xb7f8ea8 (Index: 0x37, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetFloatAttributeBaseFromAbilitySystemComponent(UAbilitySystemComponent*& const AbilitySystemComponent, FGameplayAttribute& Attribute, bool& bSuccessfullyFoundAttribute); // 0xb7f9320 (Index: 0x38, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetFloatAttributeFromAbilitySystemComponent(UAbilitySystemComponent*& const AbilitySystem, FGameplayAttribute& Attribute, bool& bSuccessfullyFoundAttribute); // 0xb7f9798 (Index: 0x39, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UGameplayAbility* GetGameplayAbilityFromSpecHandle(UAbilitySystemComponent*& AbilitySystem, const FGameplayAbilitySpecHandle AbilitySpecHandle, bool& bIsInstance); // 0xb7f9c10 (Index: 0x3a, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetGameplayCueDirection(AActor*& TargetActor, FGameplayCueParameters& Parameters, FVector& Direction); // 0xb7fa1ec (Index: 0x3b, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool GetGameplayCueEndLocationAndNormal(AActor*& TargetActor, FGameplayCueParameters& Parameters, FVector& Location, FVector& Normal); // 0xb7fa444 (Index: 0x3c, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer GetGameplayEffectAssetTags(UClass*& EffectClass); // 0xb7fa718 (Index: 0x3d, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UGameplayEffect* GetGameplayEffectFromActiveEffectHandle(const FActiveGameplayEffectHandle ActiveHandle); // 0xb7fb420 (Index: 0x3e, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer GetGameplayEffectGrantedTags(UClass*& EffectClass); // 0xb7fb4f0 (Index: 0x3f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UGameplayEffectUIData* GetGameplayEffectUIData(UClass*& EffectClass, UClass*& DataType); // 0xb7fbc10 (Index: 0x40, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FHitResult GetHitResult(FGameplayCueParameters& Parameters); // 0xb7fc260 (Index: 0x41, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FHitResult GetHitResultFromTargetData(const FGameplayAbilityTargetDataHandle HitResult, int32_t& Index); // 0xb7fc420 (Index: 0x42, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static AActor* GetInstigatorActor(FGameplayCueParameters& Parameters); // 0x597eda8 (Index: 0x43, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FTransform GetInstigatorTransform(FGameplayCueParameters& Parameters); // 0xb7fc644 (Index: 0x44, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static float GetModifiedAttributeMagnitude(FGameplayEffectSpecHandle& SpecHandle, FGameplayAttribute& Attribute); // 0xb7fc764 (Index: 0x45, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FVector GetOrigin(FGameplayCueParameters& Parameters); // 0xb7fcad8 (Index: 0x46, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetTargetDataEndPoint(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb7fcc10 (Index: 0x47, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform GetTargetDataEndPointTransform(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb7fcda0 (Index: 0x48, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform GetTargetDataOrigin(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb7fcfac (Index: 0x49, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool HasHitResult(FGameplayCueParameters& Parameters); // 0xb7fd180 (Index: 0x4a, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsGameplayAbilityActive(UGameplayAbility*& const GameplayAbility); // 0xb7fd284 (Index: 0x4b, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsInstigatorLocallyControlled(FGameplayCueParameters& Parameters); // 0xb7fd480 (Index: 0x4c, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsInstigatorLocallyControlledPlayer(FGameplayCueParameters& Parameters); // 0xb7fd578 (Index: 0x4d, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsValid(FGameplayAttribute& Attribute); // 0xb7fd670 (Index: 0x4e, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayTargetDataFilterHandle MakeFilterHandle(FGameplayTargetDataFilter& Filter, AActor*& FilterActor); // 0xb7fe810 (Index: 0x4f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayCueParameters MakeGameplayCueParameters(float& NormalizedMagnitude, float& RawMagnitude, FGameplayEffectContextHandle& EffectContext, FGameplayTag& MatchedTagName, FGameplayTag& OriginalTag, FGameplayTagContainer& AggregatedSourceTags, FGameplayTagContainer& AggregatedTargetTags, FVector& Location, FVector& Normal, AActor*& Instigator, AActor*& EffectCauser, UObject*& SourceObject, UPhysicalMaterial*& PhysicalMaterial, int32_t& GameplayEffectLevel, int32_t& AbilityLevel, USceneComponent*& TargetAttachComponent, bool& bReplicateLocationWhenUsingMinimalRepProxy); // 0x487e3ec (Index: 0x50, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FGameplayEffectSpecHandle MakeSpecHandle(UGameplayEffect*& InGameplayEffect, AActor*& InInstigator, AActor*& InEffectCauser, float& InLevel); // 0xb7fedd4 (Index: 0x51, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayEffectSpecHandle MakeSpecHandleByClass(UClass*& GameplayEffect, AActor*& Instigator, AActor*& EffectCauser, float& Level); // 0xb7ff1a0 (Index: 0x52, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool NotEqual_ActiveGameplayEffectHandle(const FActiveGameplayEffectHandle A, const FActiveGameplayEffectHandle B); // 0xb800fd4 (Index: 0x53, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool NotEqual_GameplayAbilitySpecHandle(const FGameplayAbilitySpecHandle A, const FGameplayAbilitySpecHandle B); // 0xb80114c (Index: 0x54, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool NotEqual_GameplayAttributeGameplayAttribute(FGameplayAttribute& AttributeA, FGameplayAttribute& AttributeB); // 0xb8012b8 (Index: 0x55, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool RemoveLooseGameplayTags(AActor*& Actor, const FGameplayTagContainer GameplayTags, bool& bShouldReplicate); // 0x3407e00 (Index: 0x56, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SendGameplayEventToActor(AActor*& Actor, FGameplayTag& EventTag, FGameplayEventData& Payload); // 0x35c31a8 (Index: 0x57, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle SetDuration(FGameplayEffectSpecHandle& SpecHandle, float& duration); // 0xb8071ec (Index: 0x58, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle SetStackCount(FGameplayEffectSpecHandle& SpecHandle, int32_t& StackCount); // 0xb8073a8 (Index: 0x59, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayEffectSpecHandle SetStackCountToMax(FGameplayEffectSpecHandle& SpecHandle); // 0xb807564 (Index: 0x5a, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool TargetDataHasActor(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb807ec4 (Index: 0x5b, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool TargetDataHasEndPoint(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb8080ec (Index: 0x5c, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool TargetDataHasHitResult(const FGameplayAbilityTargetDataHandle HitResult, int32_t& Index); // 0xb8082a4 (Index: 0x5d, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool TargetDataHasOrigin(const FGameplayAbilityTargetDataHandle TargetData, int32_t& Index); // 0xb808420 (Index: 0x5e, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAbilitySystemBlueprintLibrary) == 0x28, "Size mismatch for UAbilitySystemBlueprintLibrary");

// Size: 0x1250 (Inherited: 0x210, Single: 0x1040)
class UAbilitySystemComponent : public UGameplayTasksComponent
{
public:
    uint8_t Pad_130[0x10]; // 0x130 (Size: 0x10, Type: PaddingProperty)
    TArray<FAttributeDefaults> DefaultStartingData; // 0x140 (Size: 0x10, Type: ArrayProperty)
    FName AffectedAnimInstanceTag; // 0x150 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_154[0x1a4]; // 0x154 (Size: 0x1a4, Type: PaddingProperty)
    float OutgoingDuration; // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float IncomingDuration; // 0x2fc (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_300[0x20]; // 0x300 (Size: 0x20, Type: PaddingProperty)
    TArray<FString> ClientDebugStrings; // 0x320 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ServerDebugStrings; // 0x330 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_340[0x58]; // 0x340 (Size: 0x58, Type: PaddingProperty)
    bool UserAbilityActivationInhibited; // 0x398 (Size: 0x1, Type: BoolProperty)
    bool ReplicationProxyEnabled; // 0x399 (Size: 0x1, Type: BoolProperty)
    bool bSuppressGrantAbility; // 0x39a (Size: 0x1, Type: BoolProperty)
    bool bSuppressGameplayCues; // 0x39b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39c[0x4]; // 0x39c (Size: 0x4, Type: PaddingProperty)
    TArray<AGameplayAbilityTargetActor*> SpawnedTargetActors; // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_3b0[0x28]; // 0x3b0 (Size: 0x28, Type: PaddingProperty)
    AActor* OwnerActor; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    AActor* AvatarActor; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3e8[0x10]; // 0x3e8 (Size: 0x10, Type: PaddingProperty)
    FGameplayAbilitySpecContainer ActivatableAbilities; // 0x3f8 (Size: 0x120, Type: StructProperty)
    uint8_t Pad_518[0x30]; // 0x518 (Size: 0x30, Type: PaddingProperty)
    TArray<UGameplayAbility*> AllReplicatedInstancedAbilities; // 0x548 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_558[0x220]; // 0x558 (Size: 0x220, Type: PaddingProperty)
    FGameplayAbilityRepAnimMontage RepAnimMontageInfo; // 0x778 (Size: 0x38, Type: StructProperty)
    bool bCachedIsNetSimulated; // 0x7b0 (Size: 0x1, Type: BoolProperty)
    bool bPendingMontageRep; // 0x7b1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7b2[0x6]; // 0x7b2 (Size: 0x6, Type: PaddingProperty)
    FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo; // 0x7b8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_7e0[0xa0]; // 0x7e0 (Size: 0xa0, Type: PaddingProperty)
    FActiveGameplayEffectsContainer ActiveGameplayEffects; // 0x880 (Size: 0x300, Type: StructProperty)
    FActiveGameplayCueContainer ActiveGameplayCues; // 0xb80 (Size: 0x128, Type: StructProperty)
    FActiveGameplayCueContainer MinimalReplicationGameplayCues; // 0xca8 (Size: 0x128, Type: StructProperty)
    uint8_t Pad_dd0[0x128]; // 0xdd0 (Size: 0x128, Type: PaddingProperty)
    TArray<char> BlockedAbilityBindings; // 0xef8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_f08[0x128]; // 0xf08 (Size: 0x128, Type: PaddingProperty)
    FMinimalReplicationTagCountMap MinimalReplicationTags; // 0x1030 (Size: 0x68, Type: StructProperty)
    TArray<UAttributeSet*> SpawnedAttributes; // 0x1098 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10a8[0x10]; // 0x10a8 (Size: 0x10, Type: PaddingProperty)
    FMinimalReplicationTagCountMap ReplicatedLooseTags; // 0x10b8 (Size: 0x68, Type: StructProperty)
    uint8_t Pad_1120[0x8]; // 0x1120 (Size: 0x8, Type: PaddingProperty)
    FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap; // 0x1128 (Size: 0x118, Type: StructProperty)
    uint8_t Pad_1240[0x10]; // 0x1240 (Size: 0x10, Type: PaddingProperty)

public:
    void AbilityAbilityKey__DelegateSignature(int32_t& InputID); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void AbilityConfirmOrCancel__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToSelf(const FGameplayEffectSpecHandle SpecHandle); // 0xb7ee90c (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToTarget(const FGameplayEffectSpecHandle SpecHandle, UAbilitySystemComponent*& Target); // 0xb7eea5c (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FActiveGameplayEffectHandle BP_ApplyGameplayEffectToSelf(UClass*& GameplayEffectClass, float& Level, FGameplayEffectContextHandle& EffectContext); // 0x4243420 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    FActiveGameplayEffectHandle BP_ApplyGameplayEffectToTarget(UClass*& GameplayEffectClass, UAbilitySystemComponent*& Target, float& Level, FGameplayEffectContextHandle& Context); // 0x5088254 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void ClearAbility(const FGameplayAbilitySpecHandle Handle); // 0xb7efd60 (Index: 0x6, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void ClearAllAbilities(); // 0xb7efe30 (Index: 0x7, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void ClearAllAbilitiesWithInputID(int32_t& InputID); // 0xb7efe44 (Index: 0x8, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    virtual void ClientPrintDebug_Response(TArray<FString>& const Strings, int32_t& GameFlags); // 0xb7f0894 (Index: 0xe, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void ClientSetReplicatedEvent(TEnumAsByte<EAbilityGenericReplicatedEvent>& EventType, FGameplayAbilitySpecHandle& AbilityHandle, FPredictionKey& AbilityOriginalPredictionKey); // 0xb7f0abc (Index: 0xf, Flags: Net|NetReliableNative|Event|Public|NetClient)
    void FindAllAbilitiesMatchingQuery(TArray<FGameplayAbilitySpecHandle>& OutAbilityHandles, FGameplayTagQuery& Query) const; // 0xb7f498c (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
    void FindAllAbilitiesWithInputID(TArray<FGameplayAbilitySpecHandle>& OutAbilityHandles, int32_t& InputID) const; // 0xb7f4e48 (Index: 0x12, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
    void FindAllAbilitiesWithTags(TArray<FGameplayAbilitySpecHandle>& OutAbilityHandles, FGameplayTagContainer& Tags, bool& bExactMatch) const; // 0xb7f5148 (Index: 0x13, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
    TArray<FActiveGameplayEffectHandle> GetActiveEffects(const FGameplayEffectQuery Query) const; // 0xb7f6504 (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
    TArray<FActiveGameplayEffectHandle> GetActiveEffectsWithAllTags(FGameplayTagContainer& Tags) const; // 0xb7f666c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|Const)
    void GetAllAbilities(TArray<FGameplayAbilitySpecHandle>& OutAbilityHandles) const; // 0xb7f7974 (Index: 0x16, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
    void GetAllAttributes(TArray<FGameplayAttribute>& OutAttributes); // 0xb7f7d7c (Index: 0x17, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    UAttributeSet* GetAttributeSet(UClass*& AttributeSetClass) const; // 0xb7f8158 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|Const)
    float GetGameplayAttributeValue(FGameplayAttribute& Attribute, bool& bFound) const; // 0xb7f9e3c (Index: 0x19, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetGameplayEffectCount(UClass*& SourceGameplayEffect, UAbilitySystemComponent*& OptionalInstigatorFilterComponent, bool& bEnforceOnGoingCheck) const; // 0xb7faa9c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetGameplayEffectCount_IfLoaded(TSoftClassPtr& SoftSourceGameplayEffect, UAbilitySystemComponent*& OptionalInstigatorFilterComponent, bool& bEnforceOnGoingCheck) const; // 0xb7faf30 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetGameplayEffectMagnitude(FActiveGameplayEffectHandle& Handle, FGameplayAttribute& Attribute) const; // 0xb7fb874 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetGameplayTagCount(FGameplayTag& GameplayTag) const; // 0xb7fc138 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetUserAbilityActivationInhibited() const; // 0xb7fd168 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InputCancel(); // 0x4d2ed54 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable)
    void InputConfirm(); // 0x3872a38 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    bool IsGameplayCueActive(FGameplayTag& const GameplayCueTag) const; // 0xb7fd3ac (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayAbilitySpecHandle K2_GiveAbility(UClass*& AbilityClass, int32_t& Level, int32_t& InputID); // 0xb7fd9a8 (Index: 0x22, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    FGameplayAbilitySpecHandle K2_GiveAbilityAndActivateOnce(UClass*& AbilityClass, int32_t& Level, int32_t& InputID); // 0xb7fde40 (Index: 0x23, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void K2_InitStats(UClass*& Attributes, UDataTable*& const DataTable); // 0xb7fe2d8 (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable)
    FGameplayEffectContextHandle MakeEffectContext() const; // 0x58f6998 (Index: 0x25, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayEffectSpecHandle MakeOutgoingSpec(UClass*& GameplayEffectClass, float& Level, FGameplayEffectContextHandle& Context) const; // 0xb7fe99c (Index: 0x26, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void NetMulticast_InvokeGameplayCueAdded(FGameplayTag& const GameplayCueTag, FPredictionKey& PredictionKey, FGameplayEffectContextHandle& EffectContext); // 0xb7ffaec (Index: 0x27, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCueAdded_WithParams(FGameplayTag& const GameplayCueTag, FPredictionKey& PredictionKey, FGameplayCueParameters& Parameters); // 0x48a8630 (Index: 0x28, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(FGameplayEffectSpecForRPC& const Spec, FPredictionKey& PredictionKey); // 0xb7ffd28 (Index: 0x29, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(FGameplayTag& const GameplayCueTag, FPredictionKey& PredictionKey, FGameplayCueParameters& GameplayCueParameters); // 0xb7ffe9c (Index: 0x2a, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCueExecuted(FGameplayTag& const GameplayCueTag, FPredictionKey& PredictionKey, FGameplayEffectContextHandle& EffectContext); // 0xb8000a0 (Index: 0x2b, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCueExecuted_FromSpec(FGameplayEffectSpecForRPC& const Spec, FPredictionKey& PredictionKey); // 0x42439dc (Index: 0x2c, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCueExecuted_WithParams(FGameplayTag& const GameplayCueTag, FPredictionKey& PredictionKey, FGameplayCueParameters& GameplayCueParameters); // 0x4cb1080 (Index: 0x2d, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(FGameplayTagContainer& const GameplayCueTags, FPredictionKey& PredictionKey, FGameplayCueParameters& GameplayCueParameters); // 0xb8002dc (Index: 0x2e, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCuesExecuted(FGameplayTagContainer& const GameplayCueTags, FPredictionKey& PredictionKey, FGameplayEffectContextHandle& EffectContext); // 0xb800710 (Index: 0x2f, Flags: Net|Native|Event|NetMulticast|Public)
    virtual void NetMulticast_InvokeGameplayCuesExecuted_WithParams(FGameplayTagContainer& const GameplayCueTags, FPredictionKey& PredictionKey, FGameplayCueParameters& GameplayCueParameters); // 0xb800ba0 (Index: 0x30, Flags: Net|Native|Event|NetMulticast|Public)
    void OnAvatarActorDestroyed(AActor*& InActor); // 0x4e555b0 (Index: 0x31, Flags: Final|Native|Public)
    void OnOwnerActorDestroyed(AActor*& InActor); // 0x52a76cc (Index: 0x32, Flags: Final|Native|Public)
    void OnRep_ClientDebugString(); // 0xb802f64 (Index: 0x34, Flags: Native|Public)
    void OnRep_OwningActor(); // 0x5685e40 (Index: 0x35, Flags: Final|Native|Public)
    void OnRep_ServerDebugString(); // 0xb802f94 (Index: 0x37, Flags: Native|Public)
    void OnSpawnedAttributesEndPlayed(AActor*& InActor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0xb802fe4 (Index: 0x39, Flags: Final|Native|Public)
    void PressInputID(int32_t& InputID); // 0xb803974 (Index: 0x3a, Flags: Final|Native|Public|BlueprintCallable)
    void ReleaseInputID(int32_t& InputID); // 0xb803aa0 (Index: 0x3b, Flags: Final|Native|Public|BlueprintCallable)
    int32_t RemoveActiveEffectsWithAppliedTags(FGameplayTagContainer& Tags); // 0xb803bcc (Index: 0x3c, Flags: Final|Native|Public|BlueprintCallable)
    int32_t RemoveActiveEffectsWithGrantedTags(FGameplayTagContainer& Tags); // 0x5a9c628 (Index: 0x3d, Flags: Final|Native|Public|BlueprintCallable)
    int32_t RemoveActiveEffectsWithSourceTags(FGameplayTagContainer& Tags); // 0xb803edc (Index: 0x3e, Flags: Final|Native|Public|BlueprintCallable)
    int32_t RemoveActiveEffectsWithTags(FGameplayTagContainer& Tags); // 0xb8041ec (Index: 0x3f, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveActiveGameplayEffect(FActiveGameplayEffectHandle& Handle, int32_t& StacksToRemove); // 0xb8044fc (Index: 0x40, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void RemoveActiveGameplayEffectBySourceEffect(UClass*& GameplayEffect, UAbilitySystemComponent*& InstigatorAbilitySystemComponent, int32_t& StacksToRemove); // 0xb804650 (Index: 0x41, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    virtual void ServerAbilityRPCBatch(FServerAbilityRPCBatch& BatchInfo); // 0xb804db8 (Index: 0x42, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerPrintDebug_Request(); // 0xb805b2c (Index: 0x48, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerPrintDebug_RequestWithStrings(TArray<FString>& const Strings); // 0xb805b78 (Index: 0x49, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerSetInputPressed(FGameplayAbilitySpecHandle& AbilityHandle); // 0xb805cd0 (Index: 0x4a, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerSetInputReleased(FGameplayAbilitySpecHandle& AbilityHandle); // 0xb805dac (Index: 0x4b, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerSetReplicatedEvent(TEnumAsByte<EAbilityGenericReplicatedEvent>& EventType, FGameplayAbilitySpecHandle& AbilityHandle, FPredictionKey& AbilityOriginalPredictionKey, FPredictionKey& CurrentPredictionKey); // 0xb805e88 (Index: 0x4c, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerSetReplicatedEventWithPayload(TEnumAsByte<EAbilityGenericReplicatedEvent>& EventType, FGameplayAbilitySpecHandle& AbilityHandle, FPredictionKey& AbilityOriginalPredictionKey, FPredictionKey& CurrentPredictionKey, FVector_NetQuantize100& VectorPayload); // 0xb80616c (Index: 0x4d, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerSetReplicatedTargetData(FGameplayAbilitySpecHandle& AbilityHandle, FPredictionKey& AbilityOriginalPredictionKey, FGameplayAbilityTargetDataHandle& const ReplicatedTargetDataHandle, FGameplayTag& ApplicationTag, FPredictionKey& CurrentPredictionKey); // 0xb8064ec (Index: 0x4e, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    virtual void ServerSetReplicatedTargetDataCancelled(FGameplayAbilitySpecHandle& AbilityHandle, FPredictionKey& AbilityOriginalPredictionKey, FPredictionKey& CurrentPredictionKey); // 0xb806834 (Index: 0x4f, Flags: Net|NetReliableNative|Event|Public|NetServer|NetValidate)
    void SetActiveGameplayEffectLevel(FActiveGameplayEffectHandle& ActiveHandle, int32_t& NewLevel); // 0xb806f28 (Index: 0x52, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetActiveGameplayEffectLevelUsingQuery(FGameplayEffectQuery& Query, int32_t& NewLevel); // 0xb807068 (Index: 0x53, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetUserAbilityActivationInhibited(bool& NewInhibit); // 0xb80769c (Index: 0x54, Flags: Native|Public|BlueprintCallable)
    void TargetCancel(); // 0x35f8c8c (Index: 0x55, Flags: Native|Public|BlueprintCallable)
    void TargetConfirm(); // 0x3872268 (Index: 0x56, Flags: Native|Public|BlueprintCallable)
    bool TryActivateAbilitiesByTag(const FGameplayTagContainer GameplayTagContainer, bool& bAllowRemoteActivation); // 0xb8085d8 (Index: 0x57, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool TryActivateAbility(FGameplayAbilitySpecHandle& AbilityToActivate, bool& bAllowRemoteActivation); // 0xb80898c (Index: 0x58, Flags: Final|Native|Public|BlueprintCallable)
    bool TryActivateAbilityByClass(UClass*& InAbilityToActivate, bool& bAllowRemoteActivation); // 0xb808ad8 (Index: 0x59, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateActiveGameplayEffectSetByCallerMagnitude(FActiveGameplayEffectHandle& ActiveHandle, FGameplayTag& SetByCallerTag, float& NewValue); // 0xb808e90 (Index: 0x5a, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void UpdateActiveGameplayEffectSetByCallerMagnitudes(FActiveGameplayEffectHandle& ActiveHandle, const TMap<float, FGameplayTag> NewSetByCallerValues); // 0xb809038 (Index: 0x5b, Flags: BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnRep_SpawnedAttributes(const TArray<UAttributeSet*> PreviousSpawnedAttributes); // 0x5048ca0 (Index: 0x38, Flags: Final|Native|Private|HasOutParms)

protected:
    virtual void ClientActivateAbilityFailed(FGameplayAbilitySpecHandle& AbilityToActivate, int16_t& PredictionKey); // 0xb7f012c (Index: 0x9, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientActivateAbilitySucceed(FGameplayAbilitySpecHandle& AbilityToActivate, FPredictionKey& PredictionKey); // 0xb7f0268 (Index: 0xa, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientActivateAbilitySucceedWithEventData(FGameplayAbilitySpecHandle& AbilityToActivate, FPredictionKey& PredictionKey, FGameplayEventData& TriggerEventData); // 0xb7f03bc (Index: 0xb, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientCancelAbility(FGameplayAbilitySpecHandle& AbilityToCancel, FGameplayAbilityActivationInfo& ActivationInfo); // 0xb7f05d4 (Index: 0xc, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientEndAbility(FGameplayAbilitySpecHandle& AbilityToEnd, FGameplayAbilityActivationInfo& ActivationInfo); // 0xb7f0734 (Index: 0xd, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientTryActivateAbility(FGameplayAbilitySpecHandle& AbilityToActivate); // 0xb7f0cd4 (Index: 0x10, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    void OnRep_ActivateAbilities(); // 0x36ad88c (Index: 0x33, Flags: Native|Protected)
    void OnRep_ReplicatedAnimMontage(); // 0xb802f7c (Index: 0x36, Flags: Native|Protected)
    virtual void ServerCancelAbility(FGameplayAbilitySpecHandle& AbilityToCancel, FGameplayAbilityActivationInfo& ActivationInfo); // 0xb804f10 (Index: 0x43, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerCurrentMontageJumpToSectionName(UAnimSequenceBase*& ClientAnimation, FName& SectionName); // 0xb8050b0 (Index: 0x44, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerCurrentMontageSetNextSectionName(UAnimSequenceBase*& ClientAnimation, float& ClientPosition, FName& SectionName, FName& NextSectionName); // 0xb8052e8 (Index: 0x45, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerCurrentMontageSetPlayRate(UAnimSequenceBase*& ClientAnimation, float& InPlayRate); // 0xb8056c4 (Index: 0x46, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerEndAbility(FGameplayAbilitySpecHandle& AbilityToEnd, FGameplayAbilityActivationInfo& ActivationInfo, FPredictionKey& PredictionKey); // 0xb8058fc (Index: 0x47, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerTryActivateAbility(FGameplayAbilitySpecHandle& AbilityToActivate, bool& InputPressed, FPredictionKey& PredictionKey); // 0xb806a48 (Index: 0x50, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerTryActivateAbilityWithEventData(FGameplayAbilitySpecHandle& AbilityToActivate, bool& InputPressed, FPredictionKey& PredictionKey, FGameplayEventData& TriggerEventData); // 0xb806c48 (Index: 0x51, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
};

static_assert(sizeof(UAbilitySystemComponent) == 0x1250, "Size mismatch for UAbilitySystemComponent");
static_assert(offsetof(UAbilitySystemComponent, DefaultStartingData) == 0x140, "Offset mismatch for UAbilitySystemComponent::DefaultStartingData");
static_assert(offsetof(UAbilitySystemComponent, AffectedAnimInstanceTag) == 0x150, "Offset mismatch for UAbilitySystemComponent::AffectedAnimInstanceTag");
static_assert(offsetof(UAbilitySystemComponent, OutgoingDuration) == 0x2f8, "Offset mismatch for UAbilitySystemComponent::OutgoingDuration");
static_assert(offsetof(UAbilitySystemComponent, IncomingDuration) == 0x2fc, "Offset mismatch for UAbilitySystemComponent::IncomingDuration");
static_assert(offsetof(UAbilitySystemComponent, ClientDebugStrings) == 0x320, "Offset mismatch for UAbilitySystemComponent::ClientDebugStrings");
static_assert(offsetof(UAbilitySystemComponent, ServerDebugStrings) == 0x330, "Offset mismatch for UAbilitySystemComponent::ServerDebugStrings");
static_assert(offsetof(UAbilitySystemComponent, UserAbilityActivationInhibited) == 0x398, "Offset mismatch for UAbilitySystemComponent::UserAbilityActivationInhibited");
static_assert(offsetof(UAbilitySystemComponent, ReplicationProxyEnabled) == 0x399, "Offset mismatch for UAbilitySystemComponent::ReplicationProxyEnabled");
static_assert(offsetof(UAbilitySystemComponent, bSuppressGrantAbility) == 0x39a, "Offset mismatch for UAbilitySystemComponent::bSuppressGrantAbility");
static_assert(offsetof(UAbilitySystemComponent, bSuppressGameplayCues) == 0x39b, "Offset mismatch for UAbilitySystemComponent::bSuppressGameplayCues");
static_assert(offsetof(UAbilitySystemComponent, SpawnedTargetActors) == 0x3a0, "Offset mismatch for UAbilitySystemComponent::SpawnedTargetActors");
static_assert(offsetof(UAbilitySystemComponent, OwnerActor) == 0x3d8, "Offset mismatch for UAbilitySystemComponent::OwnerActor");
static_assert(offsetof(UAbilitySystemComponent, AvatarActor) == 0x3e0, "Offset mismatch for UAbilitySystemComponent::AvatarActor");
static_assert(offsetof(UAbilitySystemComponent, ActivatableAbilities) == 0x3f8, "Offset mismatch for UAbilitySystemComponent::ActivatableAbilities");
static_assert(offsetof(UAbilitySystemComponent, AllReplicatedInstancedAbilities) == 0x548, "Offset mismatch for UAbilitySystemComponent::AllReplicatedInstancedAbilities");
static_assert(offsetof(UAbilitySystemComponent, RepAnimMontageInfo) == 0x778, "Offset mismatch for UAbilitySystemComponent::RepAnimMontageInfo");
static_assert(offsetof(UAbilitySystemComponent, bCachedIsNetSimulated) == 0x7b0, "Offset mismatch for UAbilitySystemComponent::bCachedIsNetSimulated");
static_assert(offsetof(UAbilitySystemComponent, bPendingMontageRep) == 0x7b1, "Offset mismatch for UAbilitySystemComponent::bPendingMontageRep");
static_assert(offsetof(UAbilitySystemComponent, LocalAnimMontageInfo) == 0x7b8, "Offset mismatch for UAbilitySystemComponent::LocalAnimMontageInfo");
static_assert(offsetof(UAbilitySystemComponent, ActiveGameplayEffects) == 0x880, "Offset mismatch for UAbilitySystemComponent::ActiveGameplayEffects");
static_assert(offsetof(UAbilitySystemComponent, ActiveGameplayCues) == 0xb80, "Offset mismatch for UAbilitySystemComponent::ActiveGameplayCues");
static_assert(offsetof(UAbilitySystemComponent, MinimalReplicationGameplayCues) == 0xca8, "Offset mismatch for UAbilitySystemComponent::MinimalReplicationGameplayCues");
static_assert(offsetof(UAbilitySystemComponent, BlockedAbilityBindings) == 0xef8, "Offset mismatch for UAbilitySystemComponent::BlockedAbilityBindings");
static_assert(offsetof(UAbilitySystemComponent, MinimalReplicationTags) == 0x1030, "Offset mismatch for UAbilitySystemComponent::MinimalReplicationTags");
static_assert(offsetof(UAbilitySystemComponent, SpawnedAttributes) == 0x1098, "Offset mismatch for UAbilitySystemComponent::SpawnedAttributes");
static_assert(offsetof(UAbilitySystemComponent, ReplicatedLooseTags) == 0x10b8, "Offset mismatch for UAbilitySystemComponent::ReplicatedLooseTags");
static_assert(offsetof(UAbilitySystemComponent, ReplicatedPredictionKeyMap) == 0x1128, "Offset mismatch for UAbilitySystemComponent::ReplicatedPredictionKeyMap");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAbilitySystemDebugHUDExtension : public UObject
{
public:
};

static_assert(sizeof(UAbilitySystemDebugHUDExtension) == 0x28, "Size mismatch for UAbilitySystemDebugHUDExtension");

// Size: 0x80 (Inherited: 0x50, Single: 0x30)
class UAbilitySystemDebugHUDExtension_Tags : public UAbilitySystemDebugHUDExtension
{
public:
};

static_assert(sizeof(UAbilitySystemDebugHUDExtension_Tags) == 0x80, "Size mismatch for UAbilitySystemDebugHUDExtension_Tags");

// Size: 0x80 (Inherited: 0x50, Single: 0x30)
class UAbilitySystemDebugHUDExtension_Attributes : public UAbilitySystemDebugHUDExtension
{
public:
};

static_assert(sizeof(UAbilitySystemDebugHUDExtension_Attributes) == 0x80, "Size mismatch for UAbilitySystemDebugHUDExtension_Attributes");

// Size: 0x80 (Inherited: 0x50, Single: 0x30)
class UAbilitySystemDebugHUDExtension_BlockedAbilityTags : public UAbilitySystemDebugHUDExtension
{
public:
};

static_assert(sizeof(UAbilitySystemDebugHUDExtension_BlockedAbilityTags) == 0x80, "Size mismatch for UAbilitySystemDebugHUDExtension_BlockedAbilityTags");

// Size: 0x268 (Inherited: 0x28, Single: 0x240)
class UAbilitySystemGlobals : public UObject
{
public:
    FSoftClassPath AbilitySystemGlobalsClassName; // 0x28 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_40[0x2c]; // 0x40 (Size: 0x2c, Type: PaddingProperty)
    FGameplayTag ActivateFailIsDeadTag; // 0x6c (Size: 0x4, Type: StructProperty)
    FName ActivateFailIsDeadName; // 0x70 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailCooldownTag; // 0x74 (Size: 0x4, Type: StructProperty)
    FName ActivateFailCooldownName; // 0x78 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailCostTag; // 0x7c (Size: 0x4, Type: StructProperty)
    FName ActivateFailCostName; // 0x80 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailTagsBlockedTag; // 0x84 (Size: 0x4, Type: StructProperty)
    FName ActivateFailTagsBlockedName; // 0x88 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailTagsMissingTag; // 0x8c (Size: 0x4, Type: StructProperty)
    FName ActivateFailTagsMissingName; // 0x90 (Size: 0x4, Type: NameProperty)
    FGameplayTag ActivateFailNetworkingTag; // 0x94 (Size: 0x4, Type: StructProperty)
    FName ActivateFailNetworkingName; // 0x98 (Size: 0x4, Type: NameProperty)
    int32_t MinimalReplicationTagCountBits; // 0x9c (Size: 0x4, Type: IntProperty)
    FNetSerializeScriptStructCache TargetDataStructCache; // 0xa0 (Size: 0x10, Type: StructProperty)
    FNetSerializeScriptStructCache EffectContextStructCache; // 0xb0 (Size: 0x10, Type: StructProperty)
    bool bAllowGameplayModEvaluationChannels; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t DefaultGameplayModEvaluationChannel; // 0xc1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c2[0x2]; // 0xc2 (Size: 0x2, Type: PaddingProperty)
    FName GameplayModEvaluationChannelAliases[0xa]; // 0xc4 (Size: 0x28, Type: NameProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
    FSoftObjectPath GlobalCurveTableName; // 0xf0 (Size: 0x18, Type: StructProperty)
    UCurveTable* GlobalCurveTable; // 0x108 (Size: 0x8, Type: ObjectProperty)
    FSoftObjectPath GlobalAttributeMetaDataTableName; // 0x110 (Size: 0x18, Type: StructProperty)
    UDataTable* GlobalAttributeMetaDataTable; // 0x128 (Size: 0x8, Type: ObjectProperty)
    FSoftObjectPath GlobalAttributeSetDefaultsTableName; // 0x130 (Size: 0x18, Type: StructProperty)
    TArray<FSoftObjectPath> GlobalAttributeSetDefaultsTableNames; // 0x148 (Size: 0x10, Type: ArrayProperty)
    TArray<UCurveTable*> GlobalAttributeDefaultsTables; // 0x158 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GlobalGameplayCueManagerClass; // 0x168 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath GlobalGameplayCueManagerName; // 0x180 (Size: 0x18, Type: StructProperty)
    TArray<FString> GameplayCueNotifyPaths; // 0x198 (Size: 0x10, Type: ArrayProperty)
    FSoftObjectPath GameplayTagResponseTableName; // 0x1a8 (Size: 0x18, Type: StructProperty)
    UGameplayTagReponseTable* GameplayTagResponseTable; // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c8[0x1]; // 0x1c8 (Size: 0x1, Type: PaddingProperty)
    bool PredictTargetGameplayEffects; // 0x1c9 (Size: 0x1, Type: BoolProperty)
    bool ReplicateActivationOwnedTags; // 0x1ca (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1cb[0x5]; // 0x1cb (Size: 0x5, Type: PaddingProperty)
    UGameplayCueManager* GlobalGameplayCueManager; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1d8[0x90]; // 0x1d8 (Size: 0x90, Type: PaddingProperty)
};

static_assert(sizeof(UAbilitySystemGlobals) == 0x268, "Size mismatch for UAbilitySystemGlobals");
static_assert(offsetof(UAbilitySystemGlobals, AbilitySystemGlobalsClassName) == 0x28, "Offset mismatch for UAbilitySystemGlobals::AbilitySystemGlobalsClassName");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailIsDeadTag) == 0x6c, "Offset mismatch for UAbilitySystemGlobals::ActivateFailIsDeadTag");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailIsDeadName) == 0x70, "Offset mismatch for UAbilitySystemGlobals::ActivateFailIsDeadName");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailCooldownTag) == 0x74, "Offset mismatch for UAbilitySystemGlobals::ActivateFailCooldownTag");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailCooldownName) == 0x78, "Offset mismatch for UAbilitySystemGlobals::ActivateFailCooldownName");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailCostTag) == 0x7c, "Offset mismatch for UAbilitySystemGlobals::ActivateFailCostTag");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailCostName) == 0x80, "Offset mismatch for UAbilitySystemGlobals::ActivateFailCostName");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailTagsBlockedTag) == 0x84, "Offset mismatch for UAbilitySystemGlobals::ActivateFailTagsBlockedTag");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailTagsBlockedName) == 0x88, "Offset mismatch for UAbilitySystemGlobals::ActivateFailTagsBlockedName");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailTagsMissingTag) == 0x8c, "Offset mismatch for UAbilitySystemGlobals::ActivateFailTagsMissingTag");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailTagsMissingName) == 0x90, "Offset mismatch for UAbilitySystemGlobals::ActivateFailTagsMissingName");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailNetworkingTag) == 0x94, "Offset mismatch for UAbilitySystemGlobals::ActivateFailNetworkingTag");
static_assert(offsetof(UAbilitySystemGlobals, ActivateFailNetworkingName) == 0x98, "Offset mismatch for UAbilitySystemGlobals::ActivateFailNetworkingName");
static_assert(offsetof(UAbilitySystemGlobals, MinimalReplicationTagCountBits) == 0x9c, "Offset mismatch for UAbilitySystemGlobals::MinimalReplicationTagCountBits");
static_assert(offsetof(UAbilitySystemGlobals, TargetDataStructCache) == 0xa0, "Offset mismatch for UAbilitySystemGlobals::TargetDataStructCache");
static_assert(offsetof(UAbilitySystemGlobals, EffectContextStructCache) == 0xb0, "Offset mismatch for UAbilitySystemGlobals::EffectContextStructCache");
static_assert(offsetof(UAbilitySystemGlobals, bAllowGameplayModEvaluationChannels) == 0xc0, "Offset mismatch for UAbilitySystemGlobals::bAllowGameplayModEvaluationChannels");
static_assert(offsetof(UAbilitySystemGlobals, DefaultGameplayModEvaluationChannel) == 0xc1, "Offset mismatch for UAbilitySystemGlobals::DefaultGameplayModEvaluationChannel");
static_assert(offsetof(UAbilitySystemGlobals, GameplayModEvaluationChannelAliases) == 0xc4, "Offset mismatch for UAbilitySystemGlobals::GameplayModEvaluationChannelAliases");
static_assert(offsetof(UAbilitySystemGlobals, GlobalCurveTableName) == 0xf0, "Offset mismatch for UAbilitySystemGlobals::GlobalCurveTableName");
static_assert(offsetof(UAbilitySystemGlobals, GlobalCurveTable) == 0x108, "Offset mismatch for UAbilitySystemGlobals::GlobalCurveTable");
static_assert(offsetof(UAbilitySystemGlobals, GlobalAttributeMetaDataTableName) == 0x110, "Offset mismatch for UAbilitySystemGlobals::GlobalAttributeMetaDataTableName");
static_assert(offsetof(UAbilitySystemGlobals, GlobalAttributeMetaDataTable) == 0x128, "Offset mismatch for UAbilitySystemGlobals::GlobalAttributeMetaDataTable");
static_assert(offsetof(UAbilitySystemGlobals, GlobalAttributeSetDefaultsTableName) == 0x130, "Offset mismatch for UAbilitySystemGlobals::GlobalAttributeSetDefaultsTableName");
static_assert(offsetof(UAbilitySystemGlobals, GlobalAttributeSetDefaultsTableNames) == 0x148, "Offset mismatch for UAbilitySystemGlobals::GlobalAttributeSetDefaultsTableNames");
static_assert(offsetof(UAbilitySystemGlobals, GlobalAttributeDefaultsTables) == 0x158, "Offset mismatch for UAbilitySystemGlobals::GlobalAttributeDefaultsTables");
static_assert(offsetof(UAbilitySystemGlobals, GlobalGameplayCueManagerClass) == 0x168, "Offset mismatch for UAbilitySystemGlobals::GlobalGameplayCueManagerClass");
static_assert(offsetof(UAbilitySystemGlobals, GlobalGameplayCueManagerName) == 0x180, "Offset mismatch for UAbilitySystemGlobals::GlobalGameplayCueManagerName");
static_assert(offsetof(UAbilitySystemGlobals, GameplayCueNotifyPaths) == 0x198, "Offset mismatch for UAbilitySystemGlobals::GameplayCueNotifyPaths");
static_assert(offsetof(UAbilitySystemGlobals, GameplayTagResponseTableName) == 0x1a8, "Offset mismatch for UAbilitySystemGlobals::GameplayTagResponseTableName");
static_assert(offsetof(UAbilitySystemGlobals, GameplayTagResponseTable) == 0x1c0, "Offset mismatch for UAbilitySystemGlobals::GameplayTagResponseTable");
static_assert(offsetof(UAbilitySystemGlobals, PredictTargetGameplayEffects) == 0x1c9, "Offset mismatch for UAbilitySystemGlobals::PredictTargetGameplayEffects");
static_assert(offsetof(UAbilitySystemGlobals, ReplicateActivationOwnedTags) == 0x1ca, "Offset mismatch for UAbilitySystemGlobals::ReplicateActivationOwnedTags");
static_assert(offsetof(UAbilitySystemGlobals, GlobalGameplayCueManager) == 0x1d0, "Offset mismatch for UAbilitySystemGlobals::GlobalGameplayCueManager");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAbilitySystemInterface : public UInterface
{
public:
};

static_assert(sizeof(UAbilitySystemInterface) == 0x28, "Size mismatch for UAbilitySystemInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAbilitySystemReplicationProxyInterface : public UInterface
{
public:
};

static_assert(sizeof(UAbilitySystemReplicationProxyInterface) == 0x28, "Size mismatch for UAbilitySystemReplicationProxyInterface");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UAbilitySystemTestAttributeSet : public UAttributeSet
{
public:
    float MaxHealth; // 0x30 (Size: 0x4, Type: FloatProperty)
    float Health; // 0x34 (Size: 0x4, Type: FloatProperty)
    FGameplayAttributeData Mana; // 0x38 (Size: 0x10, Type: StructProperty)
    float MaxMana; // 0x48 (Size: 0x4, Type: FloatProperty)
    float Damage; // 0x4c (Size: 0x4, Type: FloatProperty)
    float SpellDamage; // 0x50 (Size: 0x4, Type: FloatProperty)
    float PhysicalDamage; // 0x54 (Size: 0x4, Type: FloatProperty)
    float CritChance; // 0x58 (Size: 0x4, Type: FloatProperty)
    float CritMultiplier; // 0x5c (Size: 0x4, Type: FloatProperty)
    float ArmorDamageReduction; // 0x60 (Size: 0x4, Type: FloatProperty)
    float DodgeChance; // 0x64 (Size: 0x4, Type: FloatProperty)
    float LifeSteal; // 0x68 (Size: 0x4, Type: FloatProperty)
    float Strength; // 0x6c (Size: 0x4, Type: FloatProperty)
    float StackingAttribute1; // 0x70 (Size: 0x4, Type: FloatProperty)
    float StackingAttribute2; // 0x74 (Size: 0x4, Type: FloatProperty)
    float NoStackAttribute; // 0x78 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAbilitySystemTestAttributeSet) == 0x80, "Size mismatch for UAbilitySystemTestAttributeSet");
static_assert(offsetof(UAbilitySystemTestAttributeSet, MaxHealth) == 0x30, "Offset mismatch for UAbilitySystemTestAttributeSet::MaxHealth");
static_assert(offsetof(UAbilitySystemTestAttributeSet, Health) == 0x34, "Offset mismatch for UAbilitySystemTestAttributeSet::Health");
static_assert(offsetof(UAbilitySystemTestAttributeSet, Mana) == 0x38, "Offset mismatch for UAbilitySystemTestAttributeSet::Mana");
static_assert(offsetof(UAbilitySystemTestAttributeSet, MaxMana) == 0x48, "Offset mismatch for UAbilitySystemTestAttributeSet::MaxMana");
static_assert(offsetof(UAbilitySystemTestAttributeSet, Damage) == 0x4c, "Offset mismatch for UAbilitySystemTestAttributeSet::Damage");
static_assert(offsetof(UAbilitySystemTestAttributeSet, SpellDamage) == 0x50, "Offset mismatch for UAbilitySystemTestAttributeSet::SpellDamage");
static_assert(offsetof(UAbilitySystemTestAttributeSet, PhysicalDamage) == 0x54, "Offset mismatch for UAbilitySystemTestAttributeSet::PhysicalDamage");
static_assert(offsetof(UAbilitySystemTestAttributeSet, CritChance) == 0x58, "Offset mismatch for UAbilitySystemTestAttributeSet::CritChance");
static_assert(offsetof(UAbilitySystemTestAttributeSet, CritMultiplier) == 0x5c, "Offset mismatch for UAbilitySystemTestAttributeSet::CritMultiplier");
static_assert(offsetof(UAbilitySystemTestAttributeSet, ArmorDamageReduction) == 0x60, "Offset mismatch for UAbilitySystemTestAttributeSet::ArmorDamageReduction");
static_assert(offsetof(UAbilitySystemTestAttributeSet, DodgeChance) == 0x64, "Offset mismatch for UAbilitySystemTestAttributeSet::DodgeChance");
static_assert(offsetof(UAbilitySystemTestAttributeSet, LifeSteal) == 0x68, "Offset mismatch for UAbilitySystemTestAttributeSet::LifeSteal");
static_assert(offsetof(UAbilitySystemTestAttributeSet, Strength) == 0x6c, "Offset mismatch for UAbilitySystemTestAttributeSet::Strength");
static_assert(offsetof(UAbilitySystemTestAttributeSet, StackingAttribute1) == 0x70, "Offset mismatch for UAbilitySystemTestAttributeSet::StackingAttribute1");
static_assert(offsetof(UAbilitySystemTestAttributeSet, StackingAttribute2) == 0x74, "Offset mismatch for UAbilitySystemTestAttributeSet::StackingAttribute2");
static_assert(offsetof(UAbilitySystemTestAttributeSet, NoStackAttribute) == 0x78, "Offset mismatch for UAbilitySystemTestAttributeSet::NoStackAttribute");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAttributeSet : public UObject
{
public:
};

static_assert(sizeof(UAttributeSet) == 0x30, "Size mismatch for UAttributeSet");

// Size: 0x370 (Inherited: 0x948, Single: 0xfffffa28)
class AAbilitySystemTestPawn : public ADefaultPawn
{
public:
    uint8_t Pad_350[0x18]; // 0x350 (Size: 0x18, Type: PaddingProperty)
    UAbilitySystemComponent* AbilitySystemComponent; // 0x368 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AAbilitySystemTestPawn) == 0x370, "Size mismatch for AAbilitySystemTestPawn");
static_assert(offsetof(AAbilitySystemTestPawn, AbilitySystemComponent) == 0x368, "Offset mismatch for AAbilitySystemTestPawn::AbilitySystemComponent");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UAnimNotify_GameplayCue : public UAnimNotify
{
public:
    FGameplayCueTag GameplayCue; // 0x38 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotify_GameplayCue) == 0x40, "Size mismatch for UAnimNotify_GameplayCue");
static_assert(offsetof(UAnimNotify_GameplayCue, GameplayCue) == 0x38, "Offset mismatch for UAnimNotify_GameplayCue::GameplayCue");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UAnimNotify_GameplayCueState : public UAnimNotifyState
{
public:
    FGameplayCueTag GameplayCue; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotify_GameplayCueState) == 0x38, "Size mismatch for UAnimNotify_GameplayCueState");
static_assert(offsetof(UAnimNotify_GameplayCueState, GameplayCue) == 0x30, "Offset mismatch for UAnimNotify_GameplayCueState::GameplayCue");

// Size: 0xa8 (Inherited: 0x120, Single: 0xffffff88)
class UGameplayAbilityBlueprint : public UBlueprint
{
public:
};

static_assert(sizeof(UGameplayAbilityBlueprint) == 0xa8, "Size mismatch for UGameplayAbilityBlueprint");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayCueFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddGameplayCueOnActor(AActor*& Target, FGameplayTag& const GameplayCueTag, const FGameplayCueParameters Parameters); // 0x52f78f0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ExecuteGameplayCueOnActor(AActor*& Target, FGameplayTag& const GameplayCueTag, const FGameplayCueParameters Parameters); // 0x50e34e0 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGameplayCueParameters MakeGameplayCueParametersFromHitResult(const FHitResult HitResult); // 0xb83c218 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void RemoveGameplayCueOnActor(AActor*& Target, FGameplayTag& const GameplayCueTag, const FGameplayCueParameters Parameters); // 0x5455730 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayCueFunctionLibrary) == 0x28, "Size mismatch for UGameplayCueFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayCueInterface : public UInterface
{
public:

public:
    virtual void BlueprintCustomHandler(TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent)
    void ForwardGameplayCueToParent(); // 0x4fe6ac8 (Index: 0x1, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayCueInterface) == 0x28, "Size mismatch for UGameplayCueInterface");

// Size: 0x2c0 (Inherited: 0x58, Single: 0x268)
class UGameplayCueManager : public UDataAsset
{
public:
    uint8_t Pad_30[0x18]; // 0x30 (Size: 0x18, Type: PaddingProperty)
    FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // 0x48 (Size: 0x50, Type: StructProperty)
    FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // 0x98 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_e8[0x178]; // 0xe8 (Size: 0x178, Type: PaddingProperty)
    TArray<UClass*> LoadedGameplayCueNotifyClasses; // 0x260 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> GameplayCueClassesForPreallocation; // 0x270 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayCuePendingExecute> PendingExecuteCues; // 0x280 (Size: 0x10, Type: ArrayProperty)
    int32_t GameplayCueSendContextCount; // 0x290 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_294[0x4]; // 0x294 (Size: 0x4, Type: PaddingProperty)
    TArray<FPreallocationInfo> PreallocationInfoList_Internal; // 0x298 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2a8[0x18]; // 0x2a8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayCueManager) == 0x2c0, "Size mismatch for UGameplayCueManager");
static_assert(offsetof(UGameplayCueManager, RuntimeGameplayCueObjectLibrary) == 0x48, "Offset mismatch for UGameplayCueManager::RuntimeGameplayCueObjectLibrary");
static_assert(offsetof(UGameplayCueManager, EditorGameplayCueObjectLibrary) == 0x98, "Offset mismatch for UGameplayCueManager::EditorGameplayCueObjectLibrary");
static_assert(offsetof(UGameplayCueManager, LoadedGameplayCueNotifyClasses) == 0x260, "Offset mismatch for UGameplayCueManager::LoadedGameplayCueNotifyClasses");
static_assert(offsetof(UGameplayCueManager, GameplayCueClassesForPreallocation) == 0x270, "Offset mismatch for UGameplayCueManager::GameplayCueClassesForPreallocation");
static_assert(offsetof(UGameplayCueManager, PendingExecuteCues) == 0x280, "Offset mismatch for UGameplayCueManager::PendingExecuteCues");
static_assert(offsetof(UGameplayCueManager, GameplayCueSendContextCount) == 0x290, "Offset mismatch for UGameplayCueManager::GameplayCueSendContextCount");
static_assert(offsetof(UGameplayCueManager, PreallocationInfoList_Internal) == 0x298, "Offset mismatch for UGameplayCueManager::PreallocationInfoList_Internal");

// Size: 0x310 (Inherited: 0x2d0, Single: 0x40)
class AGameplayCueNotify_Actor : public AActor
{
public:
    bool bAutoDestroyOnRemove; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a9[0x3]; // 0x2a9 (Size: 0x3, Type: PaddingProperty)
    float AutoDestroyDelay; // 0x2ac (Size: 0x4, Type: FloatProperty)
    bool WarnIfTimelineIsStillRunning; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    bool WarnIfLatentActionIsStillRunning; // 0x2b1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b2[0x2]; // 0x2b2 (Size: 0x2, Type: PaddingProperty)
    FGameplayTag GameplayCueTag; // 0x2b4 (Size: 0x4, Type: StructProperty)
    FName GameplayCueName; // 0x2b8 (Size: 0x4, Type: NameProperty)
    bool bAutoAttachToOwner; // 0x2bc (Size: 0x1, Type: BoolProperty)
    bool IsOverride; // 0x2bd (Size: 0x1, Type: BoolProperty)
    bool bUniqueInstancePerInstigator; // 0x2be (Size: 0x1, Type: BoolProperty)
    bool bUniqueInstancePerSourceObject; // 0x2bf (Size: 0x1, Type: BoolProperty)
    bool bAllowMultipleOnActiveEvents; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bAllowMultipleWhileActiveEvents; // 0x2c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c2[0x2]; // 0x2c2 (Size: 0x2, Type: PaddingProperty)
    int32_t NumPreallocatedInstances; // 0x2c4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c8[0x48]; // 0x2c8 (Size: 0x48, Type: PaddingProperty)

public:
    void K2_EndGameplayCue(); // 0x2649998 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    virtual void K2_HandleGameplayCue(AActor*& MyTarget, TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual bool OnActive(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x5561950 (Index: 0x2, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
    virtual bool OnExecute(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0xb83c578 (Index: 0x3, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
    void OnOwnerDestroyed(AActor*& DestroyedActor); // 0x5267264 (Index: 0x4, Flags: Native|Public)
    virtual bool OnRemove(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x52a5e20 (Index: 0x5, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
    virtual bool WhileActive(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x5b4de50 (Index: 0x6, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AGameplayCueNotify_Actor) == 0x310, "Size mismatch for AGameplayCueNotify_Actor");
static_assert(offsetof(AGameplayCueNotify_Actor, bAutoDestroyOnRemove) == 0x2a8, "Offset mismatch for AGameplayCueNotify_Actor::bAutoDestroyOnRemove");
static_assert(offsetof(AGameplayCueNotify_Actor, AutoDestroyDelay) == 0x2ac, "Offset mismatch for AGameplayCueNotify_Actor::AutoDestroyDelay");
static_assert(offsetof(AGameplayCueNotify_Actor, WarnIfTimelineIsStillRunning) == 0x2b0, "Offset mismatch for AGameplayCueNotify_Actor::WarnIfTimelineIsStillRunning");
static_assert(offsetof(AGameplayCueNotify_Actor, WarnIfLatentActionIsStillRunning) == 0x2b1, "Offset mismatch for AGameplayCueNotify_Actor::WarnIfLatentActionIsStillRunning");
static_assert(offsetof(AGameplayCueNotify_Actor, GameplayCueTag) == 0x2b4, "Offset mismatch for AGameplayCueNotify_Actor::GameplayCueTag");
static_assert(offsetof(AGameplayCueNotify_Actor, GameplayCueName) == 0x2b8, "Offset mismatch for AGameplayCueNotify_Actor::GameplayCueName");
static_assert(offsetof(AGameplayCueNotify_Actor, bAutoAttachToOwner) == 0x2bc, "Offset mismatch for AGameplayCueNotify_Actor::bAutoAttachToOwner");
static_assert(offsetof(AGameplayCueNotify_Actor, IsOverride) == 0x2bd, "Offset mismatch for AGameplayCueNotify_Actor::IsOverride");
static_assert(offsetof(AGameplayCueNotify_Actor, bUniqueInstancePerInstigator) == 0x2be, "Offset mismatch for AGameplayCueNotify_Actor::bUniqueInstancePerInstigator");
static_assert(offsetof(AGameplayCueNotify_Actor, bUniqueInstancePerSourceObject) == 0x2bf, "Offset mismatch for AGameplayCueNotify_Actor::bUniqueInstancePerSourceObject");
static_assert(offsetof(AGameplayCueNotify_Actor, bAllowMultipleOnActiveEvents) == 0x2c0, "Offset mismatch for AGameplayCueNotify_Actor::bAllowMultipleOnActiveEvents");
static_assert(offsetof(AGameplayCueNotify_Actor, bAllowMultipleWhileActiveEvents) == 0x2c1, "Offset mismatch for AGameplayCueNotify_Actor::bAllowMultipleWhileActiveEvents");
static_assert(offsetof(AGameplayCueNotify_Actor, NumPreallocatedInstances) == 0x2c4, "Offset mismatch for AGameplayCueNotify_Actor::NumPreallocatedInstances");

// Size: 0x348 (Inherited: 0x60, Single: 0x2e8)
class UGameplayCueNotify_Burst : public UGameplayCueNotify_Static
{
public:
    FGameplayCueNotify_SpawnCondition DefaultSpawnCondition; // 0x38 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo DefaultPlacementInfo; // 0x70 (Size: 0x40, Type: StructProperty)
    FGameplayCueNotify_BurstEffects BurstEffects; // 0xb0 (Size: 0x298, Type: StructProperty)

protected:
    virtual void OnBurst(AActor*& Target, const FGameplayCueParameters Parameters, const FGameplayCueNotify_SpawnResult SpawnResults) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UGameplayCueNotify_Burst) == 0x348, "Size mismatch for UGameplayCueNotify_Burst");
static_assert(offsetof(UGameplayCueNotify_Burst, DefaultSpawnCondition) == 0x38, "Offset mismatch for UGameplayCueNotify_Burst::DefaultSpawnCondition");
static_assert(offsetof(UGameplayCueNotify_Burst, DefaultPlacementInfo) == 0x70, "Offset mismatch for UGameplayCueNotify_Burst::DefaultPlacementInfo");
static_assert(offsetof(UGameplayCueNotify_Burst, BurstEffects) == 0xb0, "Offset mismatch for UGameplayCueNotify_Burst::BurstEffects");

// Size: 0x678 (Inherited: 0x5e0, Single: 0x98)
class AGameplayCueNotify_BurstLatent : public AGameplayCueNotify_Actor
{
public:
    FGameplayCueNotify_SpawnCondition DefaultSpawnCondition; // 0x310 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo DefaultPlacementInfo; // 0x348 (Size: 0x40, Type: StructProperty)
    FGameplayCueNotify_BurstEffects BurstEffects; // 0x388 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult BurstSpawnResults; // 0x620 (Size: 0x58, Type: StructProperty)

protected:
    virtual void OnBurst(AActor*& Target, const FGameplayCueParameters Parameters, const FGameplayCueNotify_SpawnResult SpawnResults); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AGameplayCueNotify_BurstLatent) == 0x678, "Size mismatch for AGameplayCueNotify_BurstLatent");
static_assert(offsetof(AGameplayCueNotify_BurstLatent, DefaultSpawnCondition) == 0x310, "Offset mismatch for AGameplayCueNotify_BurstLatent::DefaultSpawnCondition");
static_assert(offsetof(AGameplayCueNotify_BurstLatent, DefaultPlacementInfo) == 0x348, "Offset mismatch for AGameplayCueNotify_BurstLatent::DefaultPlacementInfo");
static_assert(offsetof(AGameplayCueNotify_BurstLatent, BurstEffects) == 0x388, "Offset mismatch for AGameplayCueNotify_BurstLatent::BurstEffects");
static_assert(offsetof(AGameplayCueNotify_BurstLatent, BurstSpawnResults) == 0x620, "Offset mismatch for AGameplayCueNotify_BurstLatent::BurstSpawnResults");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UGameplayCueNotify_HitImpact : public UGameplayCueNotify_Static
{
public:
    USoundBase* Sound; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* ParticleSystem; // 0x40 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UGameplayCueNotify_HitImpact) == 0x48, "Size mismatch for UGameplayCueNotify_HitImpact");
static_assert(offsetof(UGameplayCueNotify_HitImpact, Sound) == 0x38, "Offset mismatch for UGameplayCueNotify_HitImpact::Sound");
static_assert(offsetof(UGameplayCueNotify_HitImpact, ParticleSystem) == 0x40, "Offset mismatch for UGameplayCueNotify_HitImpact::ParticleSystem");

// Size: 0xea8 (Inherited: 0x5e0, Single: 0x8c8)
class AGameplayCueNotify_Looping : public AGameplayCueNotify_Actor
{
public:
    FGameplayCueNotify_SpawnCondition DefaultSpawnCondition; // 0x310 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo DefaultPlacementInfo; // 0x348 (Size: 0x40, Type: StructProperty)
    FGameplayCueNotify_BurstEffects ApplicationEffects; // 0x388 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult ApplicationSpawnResults; // 0x620 (Size: 0x58, Type: StructProperty)
    FGameplayCueNotify_LoopingEffects LoopingEffects; // 0x678 (Size: 0x1f0, Type: StructProperty)
    FGameplayCueNotify_SpawnResult LoopingSpawnResults; // 0x868 (Size: 0x58, Type: StructProperty)
    FGameplayCueNotify_BurstEffects RecurringEffects; // 0x8c0 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult RecurringSpawnResults; // 0xb58 (Size: 0x58, Type: StructProperty)
    FGameplayCueNotify_BurstEffects RemovalEffects; // 0xbb0 (Size: 0x298, Type: StructProperty)
    FGameplayCueNotify_SpawnResult RemovalSpawnResults; // 0xe48 (Size: 0x58, Type: StructProperty)
    uint8_t Pad_ea0[0x8]; // 0xea0 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void OnApplication(AActor*& Target, const FGameplayCueParameters Parameters, const FGameplayCueNotify_SpawnResult SpawnResults); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnLoopingStart(AActor*& Target, const FGameplayCueParameters Parameters, const FGameplayCueNotify_SpawnResult SpawnResults); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnRecurring(AActor*& Target, const FGameplayCueParameters Parameters, const FGameplayCueNotify_SpawnResult SpawnResults); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnRemoval(AActor*& Target, const FGameplayCueParameters Parameters, const FGameplayCueNotify_SpawnResult SpawnResults); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AGameplayCueNotify_Looping) == 0xea8, "Size mismatch for AGameplayCueNotify_Looping");
static_assert(offsetof(AGameplayCueNotify_Looping, DefaultSpawnCondition) == 0x310, "Offset mismatch for AGameplayCueNotify_Looping::DefaultSpawnCondition");
static_assert(offsetof(AGameplayCueNotify_Looping, DefaultPlacementInfo) == 0x348, "Offset mismatch for AGameplayCueNotify_Looping::DefaultPlacementInfo");
static_assert(offsetof(AGameplayCueNotify_Looping, ApplicationEffects) == 0x388, "Offset mismatch for AGameplayCueNotify_Looping::ApplicationEffects");
static_assert(offsetof(AGameplayCueNotify_Looping, ApplicationSpawnResults) == 0x620, "Offset mismatch for AGameplayCueNotify_Looping::ApplicationSpawnResults");
static_assert(offsetof(AGameplayCueNotify_Looping, LoopingEffects) == 0x678, "Offset mismatch for AGameplayCueNotify_Looping::LoopingEffects");
static_assert(offsetof(AGameplayCueNotify_Looping, LoopingSpawnResults) == 0x868, "Offset mismatch for AGameplayCueNotify_Looping::LoopingSpawnResults");
static_assert(offsetof(AGameplayCueNotify_Looping, RecurringEffects) == 0x8c0, "Offset mismatch for AGameplayCueNotify_Looping::RecurringEffects");
static_assert(offsetof(AGameplayCueNotify_Looping, RecurringSpawnResults) == 0xb58, "Offset mismatch for AGameplayCueNotify_Looping::RecurringSpawnResults");
static_assert(offsetof(AGameplayCueNotify_Looping, RemovalEffects) == 0xbb0, "Offset mismatch for AGameplayCueNotify_Looping::RemovalEffects");
static_assert(offsetof(AGameplayCueNotify_Looping, RemovalSpawnResults) == 0xe48, "Offset mismatch for AGameplayCueNotify_Looping::RemovalSpawnResults");

// Size: 0x90 (Inherited: 0x58, Single: 0x38)
class UGameplayCueSet : public UDataAsset
{
public:
    TArray<FGameplayCueNotifyData> GameplayCueData; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x50]; // 0x40 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayCueSet) == 0x90, "Size mismatch for UGameplayCueSet");
static_assert(offsetof(UGameplayCueSet, GameplayCueData) == 0x30, "Offset mismatch for UGameplayCueSet::GameplayCueData");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGameplayCueTranslator : public UObject
{
public:
};

static_assert(sizeof(UGameplayCueTranslator) == 0x28, "Size mismatch for UGameplayCueTranslator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayCueTranslator_Test : public UGameplayCueTranslator
{
public:
};

static_assert(sizeof(UGameplayCueTranslator_Test) == 0x28, "Size mismatch for UGameplayCueTranslator_Test");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGameplayEffectCalculation : public UObject
{
public:
    TArray<FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayEffectCalculation) == 0x38, "Size mismatch for UGameplayEffectCalculation");
static_assert(offsetof(UGameplayEffectCalculation, RelevantAttributesToCapture) == 0x28, "Offset mismatch for UGameplayEffectCalculation::RelevantAttributesToCapture");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGameplayEffectCustomApplicationRequirement : public UObject
{
public:

public:
    virtual bool CanApplyGameplayEffect(UGameplayEffect*& const GameplayEffect, const FGameplayEffectSpec Spec, UAbilitySystemComponent*& ASC) const; // 0xb85915c (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UGameplayEffectCustomApplicationRequirement) == 0x28, "Size mismatch for UGameplayEffectCustomApplicationRequirement");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UGameplayEffectExecutionCalculation : public UGameplayEffectCalculation
{
public:
    bool bRequiresPassedInTags; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)

public:
    virtual void Execute(const FGameplayEffectCustomExecutionParameters ExecutionParams, FGameplayEffectCustomExecutionOutput& OutExecutionOutput) const; // 0xb8593e4 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UGameplayEffectExecutionCalculation) == 0x40, "Size mismatch for UGameplayEffectExecutionCalculation");
static_assert(offsetof(UGameplayEffectExecutionCalculation, bRequiresPassedInTags) == 0x38, "Offset mismatch for UGameplayEffectExecutionCalculation::bRequiresPassedInTags");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UGameplayModMagnitudeCalculation : public UGameplayEffectCalculation
{
public:
    bool bAllowNonNetAuthorityDependencyRegistration; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)

public:
    virtual float CalculateBaseMagnitude(const FGameplayEffectSpec Spec) const; // 0xb85904c (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent|Const)

protected:
    float GetSetByCallerMagnitudeByName(const FGameplayEffectSpec EffectSpec, const FName MagnitudeName) const; // 0xb859590 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|Const)
    float GetSetByCallerMagnitudeByTag(const FGameplayEffectSpec EffectSpec, const FGameplayTag Tag) const; // 0xb859734 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|Const)
    FGameplayTagContainer GetSourceActorTags(const FGameplayEffectSpec EffectSpec) const; // 0xb8598d8 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagContainer GetSourceAggregatedTags(const FGameplayEffectSpec EffectSpec) const; // 0xb8599e4 (Index: 0x4, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|Const)
    FGameplayTagContainer GetSourceSpecTags(const FGameplayEffectSpec EffectSpec) const; // 0xb859c14 (Index: 0x5, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagContainer GetTargetActorTags(const FGameplayEffectSpec EffectSpec) const; // 0xb859d1c (Index: 0x6, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagContainer GetTargetAggregatedTags(const FGameplayEffectSpec EffectSpec) const; // 0xb859e2c (Index: 0x7, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|Const)
    FGameplayTagContainer GetTargetSpecTags(const FGameplayEffectSpec EffectSpec) const; // 0xb85a05c (Index: 0x8, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    float K2_GetCapturedAttributeMagnitude(const FGameplayEffectSpec EffectSpec, FGameplayAttribute& Attribute, const FGameplayTagContainer SourceTags, const FGameplayTagContainer TargetTags) const; // 0xb85a168 (Index: 0x9, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|Const)
};

static_assert(sizeof(UGameplayModMagnitudeCalculation) == 0x40, "Size mismatch for UGameplayModMagnitudeCalculation");
static_assert(offsetof(UGameplayModMagnitudeCalculation, bAllowNonNetAuthorityDependencyRegistration) == 0x38, "Offset mismatch for UGameplayModMagnitudeCalculation::bAllowNonNetAuthorityDependencyRegistration");

// Size: 0x230 (Inherited: 0x58, Single: 0x1d8)
class UGameplayTagReponseTable : public UDataAsset
{
public:
    TArray<FGameplayTagResponseTableEntry> Entries; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x1f0]; // 0x40 (Size: 0x1f0, Type: PaddingProperty)

protected:
    void TagResponseEvent(FGameplayTag& const Tag, int32_t& NewCount, UAbilitySystemComponent*& ASC, int32_t& idx); // 0xb85a830 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UGameplayTagReponseTable) == 0x230, "Size mismatch for UGameplayTagReponseTable");
static_assert(offsetof(UGameplayTagReponseTable, Entries) == 0x30, "Offset mismatch for UGameplayTagReponseTable::Entries");

// Size: 0x218 (Inherited: 0x310, Single: 0xffffff08)
class UMovieSceneGameplayCueTriggerSection : public UMovieSceneHookSection
{
public:
    FMovieSceneGameplayCueChannel Channel; // 0x120 (Size: 0xf8, Type: StructProperty)
};

static_assert(sizeof(UMovieSceneGameplayCueTriggerSection) == 0x218, "Size mismatch for UMovieSceneGameplayCueTriggerSection");
static_assert(offsetof(UMovieSceneGameplayCueTriggerSection, Channel) == 0x120, "Offset mismatch for UMovieSceneGameplayCueTriggerSection::Channel");

// Size: 0x1a8 (Inherited: 0x310, Single: 0xfffffe98)
class UMovieSceneGameplayCueSection : public UMovieSceneHookSection
{
public:
    FMovieSceneGameplayCueKey Cue; // 0x120 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(UMovieSceneGameplayCueSection) == 0x1a8, "Size mismatch for UMovieSceneGameplayCueSection");
static_assert(offsetof(UMovieSceneGameplayCueSection, Cue) == 0x120, "Offset mismatch for UMovieSceneGameplayCueSection::Cue");

// Size: 0x120 (Inherited: 0x308, Single: 0xfffffe18)
class UMovieSceneGameplayCueTrack : public UMovieSceneNameableTrack
{
public:
    TArray<UMovieSceneSection*> Sections; // 0x110 (Size: 0x10, Type: ArrayProperty)

public:
    static void SetSequencerTrackHandler(FDelegate& InGameplayCueTrackHandler); // 0xb85a704 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UMovieSceneGameplayCueTrack) == 0x120, "Size mismatch for UMovieSceneGameplayCueTrack");
static_assert(offsetof(UMovieSceneGameplayCueTrack, Sections) == 0x110, "Offset mismatch for UMovieSceneGameplayCueTrack::Sections");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UTickableAttributeSetInterface : public UInterface
{
public:
};

static_assert(sizeof(UTickableAttributeSetInterface) == 0x28, "Size mismatch for UTickableAttributeSetInterface");

// Size: 0x360 (Inherited: 0xc, Single: 0x354)
struct FActiveGameplayEffect : FFastArraySerializerItem
{
    uint8_t Pad_c[0xc]; // 0xc (Size: 0xc, Type: PaddingProperty)
    FGameplayEffectSpec Spec; // 0x18 (Size: 0x298, Type: StructProperty)
    FPredictionKey PredictionKey; // 0x2b0 (Size: 0x10, Type: StructProperty)
    TArray<FGameplayAbilitySpecHandle> GrantedAbilityHandles; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    float StartServerWorldTime; // 0x2d0 (Size: 0x4, Type: FloatProperty)
    float CachedStartServerWorldTime; // 0x2d4 (Size: 0x4, Type: FloatProperty)
    float StartWorldTime; // 0x2d8 (Size: 0x4, Type: FloatProperty)
    bool bIsInhibited; // 0x2dc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2dd[0x83]; // 0x2dd (Size: 0x83, Type: PaddingProperty)
};

static_assert(sizeof(FActiveGameplayEffect) == 0x360, "Size mismatch for FActiveGameplayEffect");
static_assert(offsetof(FActiveGameplayEffect, Spec) == 0x18, "Offset mismatch for FActiveGameplayEffect::Spec");
static_assert(offsetof(FActiveGameplayEffect, PredictionKey) == 0x2b0, "Offset mismatch for FActiveGameplayEffect::PredictionKey");
static_assert(offsetof(FActiveGameplayEffect, GrantedAbilityHandles) == 0x2c0, "Offset mismatch for FActiveGameplayEffect::GrantedAbilityHandles");
static_assert(offsetof(FActiveGameplayEffect, StartServerWorldTime) == 0x2d0, "Offset mismatch for FActiveGameplayEffect::StartServerWorldTime");
static_assert(offsetof(FActiveGameplayEffect, CachedStartServerWorldTime) == 0x2d4, "Offset mismatch for FActiveGameplayEffect::CachedStartServerWorldTime");
static_assert(offsetof(FActiveGameplayEffect, StartWorldTime) == 0x2d8, "Offset mismatch for FActiveGameplayEffect::StartWorldTime");
static_assert(offsetof(FActiveGameplayEffect, bIsInhibited) == 0x2dc, "Offset mismatch for FActiveGameplayEffect::bIsInhibited");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGameplayAbilitySpecHandle
{
    int32_t Handle; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGameplayAbilitySpecHandle) == 0x4, "Size mismatch for FGameplayAbilitySpecHandle");
static_assert(offsetof(FGameplayAbilitySpecHandle, Handle) == 0x0, "Offset mismatch for FGameplayAbilitySpecHandle::Handle");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPredictionKey
{
    int16_t Current; // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t base; // 0x2 (Size: 0x2, Type: Int16Property)
    bool bIsServerInitiated; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0xb]; // 0x5 (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(FPredictionKey) == 0x10, "Size mismatch for FPredictionKey");
static_assert(offsetof(FPredictionKey, Current) == 0x0, "Offset mismatch for FPredictionKey::Current");
static_assert(offsetof(FPredictionKey, base) == 0x2, "Offset mismatch for FPredictionKey::base");
static_assert(offsetof(FPredictionKey, bIsServerInitiated) == 0x4, "Offset mismatch for FPredictionKey::bIsServerInitiated");

// Size: 0x298 (Inherited: 0x0, Single: 0x298)
struct FGameplayEffectSpec
{
    UGameplayEffect* Def; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayEffectModifiedAttribute> ModifiedAttributes; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FGameplayEffectAttributeCaptureSpecContainer CapturedRelevantAttributes; // 0x18 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
    float duration; // 0x50 (Size: 0x4, Type: FloatProperty)
    float Period; // 0x54 (Size: 0x4, Type: FloatProperty)
    float ChanceToApplyToTarget; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FTagContainerAggregator CapturedSourceTags; // 0x60 (Size: 0x88, Type: StructProperty)
    FTagContainerAggregator CapturedTargetTags; // 0xe8 (Size: 0x88, Type: StructProperty)
    FGameplayTagContainer DynamicGrantedTags; // 0x170 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DynamicAssetTags; // 0x190 (Size: 0x20, Type: StructProperty)
    TArray<FModifierSpec> Modifiers; // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    int32_t StackCount; // 0x1c0 (Size: 0x4, Type: IntProperty)
    uint8_t bCompletedSourceAttributeCapture : 1; // 0x1c4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCompletedTargetAttributeCapture : 1; // 0x1c4:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bDurationLocked : 1; // 0x1c4:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c5[0x3]; // 0x1c5 (Size: 0x3, Type: PaddingProperty)
    TArray<FGameplayAbilitySpecDef> GrantedAbilitySpecs; // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1d8[0xa0]; // 0x1d8 (Size: 0xa0, Type: PaddingProperty)
    FGameplayEffectContextHandle EffectContext; // 0x278 (Size: 0x18, Type: StructProperty)
    float Level; // 0x290 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_294[0x4]; // 0x294 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectSpec) == 0x298, "Size mismatch for FGameplayEffectSpec");
static_assert(offsetof(FGameplayEffectSpec, Def) == 0x0, "Offset mismatch for FGameplayEffectSpec::Def");
static_assert(offsetof(FGameplayEffectSpec, ModifiedAttributes) == 0x8, "Offset mismatch for FGameplayEffectSpec::ModifiedAttributes");
static_assert(offsetof(FGameplayEffectSpec, CapturedRelevantAttributes) == 0x18, "Offset mismatch for FGameplayEffectSpec::CapturedRelevantAttributes");
static_assert(offsetof(FGameplayEffectSpec, duration) == 0x50, "Offset mismatch for FGameplayEffectSpec::duration");
static_assert(offsetof(FGameplayEffectSpec, Period) == 0x54, "Offset mismatch for FGameplayEffectSpec::Period");
static_assert(offsetof(FGameplayEffectSpec, ChanceToApplyToTarget) == 0x58, "Offset mismatch for FGameplayEffectSpec::ChanceToApplyToTarget");
static_assert(offsetof(FGameplayEffectSpec, CapturedSourceTags) == 0x60, "Offset mismatch for FGameplayEffectSpec::CapturedSourceTags");
static_assert(offsetof(FGameplayEffectSpec, CapturedTargetTags) == 0xe8, "Offset mismatch for FGameplayEffectSpec::CapturedTargetTags");
static_assert(offsetof(FGameplayEffectSpec, DynamicGrantedTags) == 0x170, "Offset mismatch for FGameplayEffectSpec::DynamicGrantedTags");
static_assert(offsetof(FGameplayEffectSpec, DynamicAssetTags) == 0x190, "Offset mismatch for FGameplayEffectSpec::DynamicAssetTags");
static_assert(offsetof(FGameplayEffectSpec, Modifiers) == 0x1b0, "Offset mismatch for FGameplayEffectSpec::Modifiers");
static_assert(offsetof(FGameplayEffectSpec, StackCount) == 0x1c0, "Offset mismatch for FGameplayEffectSpec::StackCount");
static_assert(offsetof(FGameplayEffectSpec, bCompletedSourceAttributeCapture) == 0x1c4, "Offset mismatch for FGameplayEffectSpec::bCompletedSourceAttributeCapture");
static_assert(offsetof(FGameplayEffectSpec, bCompletedTargetAttributeCapture) == 0x1c4, "Offset mismatch for FGameplayEffectSpec::bCompletedTargetAttributeCapture");
static_assert(offsetof(FGameplayEffectSpec, bDurationLocked) == 0x1c4, "Offset mismatch for FGameplayEffectSpec::bDurationLocked");
static_assert(offsetof(FGameplayEffectSpec, GrantedAbilitySpecs) == 0x1c8, "Offset mismatch for FGameplayEffectSpec::GrantedAbilitySpecs");
static_assert(offsetof(FGameplayEffectSpec, EffectContext) == 0x278, "Offset mismatch for FGameplayEffectSpec::EffectContext");
static_assert(offsetof(FGameplayEffectSpec, Level) == 0x290, "Offset mismatch for FGameplayEffectSpec::Level");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayEffectContextHandle
{
};

static_assert(sizeof(FGameplayEffectContextHandle) == 0x18, "Size mismatch for FGameplayEffectContextHandle");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FGameplayAbilitySpecDef
{
    UClass* ability; // 0x0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat LevelScalableFloat; // 0x8 (Size: 0x28, Type: StructProperty)
    int32_t InputID; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t RemovalPolicy; // 0x34 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UObject*> SourceObject; // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_40[0x50]; // 0x40 (Size: 0x50, Type: PaddingProperty)
    FGameplayAbilitySpecHandle AssignedHandle; // 0x90 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilitySpecDef) == 0x98, "Size mismatch for FGameplayAbilitySpecDef");
static_assert(offsetof(FGameplayAbilitySpecDef, ability) == 0x0, "Offset mismatch for FGameplayAbilitySpecDef::ability");
static_assert(offsetof(FGameplayAbilitySpecDef, LevelScalableFloat) == 0x8, "Offset mismatch for FGameplayAbilitySpecDef::LevelScalableFloat");
static_assert(offsetof(FGameplayAbilitySpecDef, InputID) == 0x30, "Offset mismatch for FGameplayAbilitySpecDef::InputID");
static_assert(offsetof(FGameplayAbilitySpecDef, RemovalPolicy) == 0x34, "Offset mismatch for FGameplayAbilitySpecDef::RemovalPolicy");
static_assert(offsetof(FGameplayAbilitySpecDef, SourceObject) == 0x38, "Offset mismatch for FGameplayAbilitySpecDef::SourceObject");
static_assert(offsetof(FGameplayAbilitySpecDef, AssignedHandle) == 0x90, "Offset mismatch for FGameplayAbilitySpecDef::AssignedHandle");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FScalableFloat
{
    float Value; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FCurveTableRowHandle Curve; // 0x8 (Size: 0x10, Type: StructProperty)
    FDataRegistryType RegistryType; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1c[0xc]; // 0x1c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FScalableFloat) == 0x28, "Size mismatch for FScalableFloat");
static_assert(offsetof(FScalableFloat, Value) == 0x0, "Offset mismatch for FScalableFloat::Value");
static_assert(offsetof(FScalableFloat, Curve) == 0x8, "Offset mismatch for FScalableFloat::Curve");
static_assert(offsetof(FScalableFloat, RegistryType) == 0x18, "Offset mismatch for FScalableFloat::RegistryType");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FModifierSpec
{
    float EvaluatedMagnitude; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FModifierSpec) == 0x4, "Size mismatch for FModifierSpec");
static_assert(offsetof(FModifierSpec, EvaluatedMagnitude) == 0x0, "Offset mismatch for FModifierSpec::EvaluatedMagnitude");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FTagContainerAggregator
{
    FGameplayTagContainer CapturedActorTags; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer CapturedSpecTags; // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ScopedTags; // 0x40 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_60[0x28]; // 0x60 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FTagContainerAggregator) == 0x88, "Size mismatch for FTagContainerAggregator");
static_assert(offsetof(FTagContainerAggregator, CapturedActorTags) == 0x0, "Offset mismatch for FTagContainerAggregator::CapturedActorTags");
static_assert(offsetof(FTagContainerAggregator, CapturedSpecTags) == 0x20, "Offset mismatch for FTagContainerAggregator::CapturedSpecTags");
static_assert(offsetof(FTagContainerAggregator, ScopedTags) == 0x40, "Offset mismatch for FTagContainerAggregator::ScopedTags");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayEffectAttributeCaptureSpecContainer
{
    TArray<FGameplayEffectAttributeCaptureSpec> SourceAttributes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayEffectAttributeCaptureSpec> TargetAttributes; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bHasNonSnapshottedAttributes; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectAttributeCaptureSpecContainer) == 0x28, "Size mismatch for FGameplayEffectAttributeCaptureSpecContainer");
static_assert(offsetof(FGameplayEffectAttributeCaptureSpecContainer, SourceAttributes) == 0x0, "Offset mismatch for FGameplayEffectAttributeCaptureSpecContainer::SourceAttributes");
static_assert(offsetof(FGameplayEffectAttributeCaptureSpecContainer, TargetAttributes) == 0x10, "Offset mismatch for FGameplayEffectAttributeCaptureSpecContainer::TargetAttributes");
static_assert(offsetof(FGameplayEffectAttributeCaptureSpecContainer, bHasNonSnapshottedAttributes) == 0x20, "Offset mismatch for FGameplayEffectAttributeCaptureSpecContainer::bHasNonSnapshottedAttributes");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGameplayEffectAttributeCaptureSpec
{
    FGameplayEffectAttributeCaptureDefinition BackingDefinition; // 0x0 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectAttributeCaptureSpec) == 0x50, "Size mismatch for FGameplayEffectAttributeCaptureSpec");
static_assert(offsetof(FGameplayEffectAttributeCaptureSpec, BackingDefinition) == 0x0, "Offset mismatch for FGameplayEffectAttributeCaptureSpec::BackingDefinition");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGameplayEffectAttributeCaptureDefinition
{
    FGameplayAttribute AttributeToCapture; // 0x0 (Size: 0x38, Type: StructProperty)
    uint8_t AttributeSource; // 0x38 (Size: 0x1, Type: EnumProperty)
    bool bSnapshot; // 0x39 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectAttributeCaptureDefinition) == 0x40, "Size mismatch for FGameplayEffectAttributeCaptureDefinition");
static_assert(offsetof(FGameplayEffectAttributeCaptureDefinition, AttributeToCapture) == 0x0, "Offset mismatch for FGameplayEffectAttributeCaptureDefinition::AttributeToCapture");
static_assert(offsetof(FGameplayEffectAttributeCaptureDefinition, AttributeSource) == 0x38, "Offset mismatch for FGameplayEffectAttributeCaptureDefinition::AttributeSource");
static_assert(offsetof(FGameplayEffectAttributeCaptureDefinition, bSnapshot) == 0x39, "Offset mismatch for FGameplayEffectAttributeCaptureDefinition::bSnapshot");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGameplayAttribute
{
    FString AttributeName; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t Attribute[0x20]; // 0x10 (Size: 0x20, Type: FieldPathProperty)
    UStruct* AttributeOwner; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayAttribute) == 0x38, "Size mismatch for FGameplayAttribute");
static_assert(offsetof(FGameplayAttribute, AttributeName) == 0x0, "Offset mismatch for FGameplayAttribute::AttributeName");
static_assert(offsetof(FGameplayAttribute, Attribute) == 0x10, "Offset mismatch for FGameplayAttribute::Attribute");
static_assert(offsetof(FGameplayAttribute, AttributeOwner) == 0x30, "Offset mismatch for FGameplayAttribute::AttributeOwner");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGameplayEffectModifiedAttribute
{
    FGameplayAttribute Attribute; // 0x0 (Size: 0x38, Type: StructProperty)
    float TotalMagnitude; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectModifiedAttribute) == 0x40, "Size mismatch for FGameplayEffectModifiedAttribute");
static_assert(offsetof(FGameplayEffectModifiedAttribute, Attribute) == 0x0, "Offset mismatch for FGameplayEffectModifiedAttribute::Attribute");
static_assert(offsetof(FGameplayEffectModifiedAttribute, TotalMagnitude) == 0x38, "Offset mismatch for FGameplayEffectModifiedAttribute::TotalMagnitude");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FActiveGameplayEffectHandle
{
    int32_t Handle; // 0x0 (Size: 0x4, Type: IntProperty)
    bool bPassedFiltersAndWasExecuted; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FActiveGameplayEffectHandle) == 0x8, "Size mismatch for FActiveGameplayEffectHandle");
static_assert(offsetof(FActiveGameplayEffectHandle, Handle) == 0x0, "Offset mismatch for FActiveGameplayEffectHandle::Handle");
static_assert(offsetof(FActiveGameplayEffectHandle, bPassedFiltersAndWasExecuted) == 0x4, "Offset mismatch for FActiveGameplayEffectHandle::bPassedFiltersAndWasExecuted");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayEffectSpecHandle
{
};

static_assert(sizeof(FGameplayEffectSpecHandle) == 0x10, "Size mismatch for FGameplayEffectSpecHandle");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FGameplayCueParameters
{
    float NormalizedMagnitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float RawMagnitude; // 0x4 (Size: 0x4, Type: FloatProperty)
    FGameplayEffectContextHandle EffectContext; // 0x8 (Size: 0x18, Type: StructProperty)
    FGameplayTag MatchedTagName; // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTag OriginalTag; // 0x24 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer AggregatedSourceTags; // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AggregatedTargetTags; // 0x48 (Size: 0x20, Type: StructProperty)
    FVector_NetQuantize10 Location; // 0x68 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantizeNormal Normal; // 0x80 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<AActor*> Instigator; // 0x98 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> EffectCauser; // 0xa0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UObject*> SourceObject; // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPhysicalMaterial*> PhysicalMaterial; // 0xb0 (Size: 0x8, Type: WeakObjectProperty)
    int32_t GameplayEffectLevel; // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t AbilityLevel; // 0xbc (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<USceneComponent*> TargetAttachComponent; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    bool bReplicateLocationWhenUsingMinimalRepProxy; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueParameters) == 0xd0, "Size mismatch for FGameplayCueParameters");
static_assert(offsetof(FGameplayCueParameters, NormalizedMagnitude) == 0x0, "Offset mismatch for FGameplayCueParameters::NormalizedMagnitude");
static_assert(offsetof(FGameplayCueParameters, RawMagnitude) == 0x4, "Offset mismatch for FGameplayCueParameters::RawMagnitude");
static_assert(offsetof(FGameplayCueParameters, EffectContext) == 0x8, "Offset mismatch for FGameplayCueParameters::EffectContext");
static_assert(offsetof(FGameplayCueParameters, MatchedTagName) == 0x20, "Offset mismatch for FGameplayCueParameters::MatchedTagName");
static_assert(offsetof(FGameplayCueParameters, OriginalTag) == 0x24, "Offset mismatch for FGameplayCueParameters::OriginalTag");
static_assert(offsetof(FGameplayCueParameters, AggregatedSourceTags) == 0x28, "Offset mismatch for FGameplayCueParameters::AggregatedSourceTags");
static_assert(offsetof(FGameplayCueParameters, AggregatedTargetTags) == 0x48, "Offset mismatch for FGameplayCueParameters::AggregatedTargetTags");
static_assert(offsetof(FGameplayCueParameters, Location) == 0x68, "Offset mismatch for FGameplayCueParameters::Location");
static_assert(offsetof(FGameplayCueParameters, Normal) == 0x80, "Offset mismatch for FGameplayCueParameters::Normal");
static_assert(offsetof(FGameplayCueParameters, Instigator) == 0x98, "Offset mismatch for FGameplayCueParameters::Instigator");
static_assert(offsetof(FGameplayCueParameters, EffectCauser) == 0xa0, "Offset mismatch for FGameplayCueParameters::EffectCauser");
static_assert(offsetof(FGameplayCueParameters, SourceObject) == 0xa8, "Offset mismatch for FGameplayCueParameters::SourceObject");
static_assert(offsetof(FGameplayCueParameters, PhysicalMaterial) == 0xb0, "Offset mismatch for FGameplayCueParameters::PhysicalMaterial");
static_assert(offsetof(FGameplayCueParameters, GameplayEffectLevel) == 0xb8, "Offset mismatch for FGameplayCueParameters::GameplayEffectLevel");
static_assert(offsetof(FGameplayCueParameters, AbilityLevel) == 0xbc, "Offset mismatch for FGameplayCueParameters::AbilityLevel");
static_assert(offsetof(FGameplayCueParameters, TargetAttachComponent) == 0xc0, "Offset mismatch for FGameplayCueParameters::TargetAttachComponent");
static_assert(offsetof(FGameplayCueParameters, bReplicateLocationWhenUsingMinimalRepProxy) == 0xc8, "Offset mismatch for FGameplayCueParameters::bReplicateLocationWhenUsingMinimalRepProxy");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayEffectRemovalInfo
{
    bool bPrematureRemoval; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t StackCount; // 0x4 (Size: 0x4, Type: IntProperty)
    FGameplayEffectContextHandle EffectContext; // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_20[0x8]; // 0x20 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectRemovalInfo) == 0x28, "Size mismatch for FGameplayEffectRemovalInfo");
static_assert(offsetof(FGameplayEffectRemovalInfo, bPrematureRemoval) == 0x0, "Offset mismatch for FGameplayEffectRemovalInfo::bPrematureRemoval");
static_assert(offsetof(FGameplayEffectRemovalInfo, StackCount) == 0x4, "Offset mismatch for FGameplayEffectRemovalInfo::StackCount");
static_assert(offsetof(FGameplayEffectRemovalInfo, EffectContext) == 0x8, "Offset mismatch for FGameplayEffectRemovalInfo::EffectContext");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FGameplayEventData
{
    FGameplayTag EventTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* Instigator; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UObject* OptionalObject; // 0x18 (Size: 0x8, Type: ObjectProperty)
    UObject* OptionalObject2; // 0x20 (Size: 0x8, Type: ObjectProperty)
    FGameplayEffectContextHandle ContextHandle; // 0x28 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer InstigatorTags; // 0x40 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetTags; // 0x60 (Size: 0x20, Type: StructProperty)
    float EventMagnitude; // 0x80 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    FGameplayAbilityTargetDataHandle TargetData; // 0x88 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FGameplayEventData) == 0xb0, "Size mismatch for FGameplayEventData");
static_assert(offsetof(FGameplayEventData, EventTag) == 0x0, "Offset mismatch for FGameplayEventData::EventTag");
static_assert(offsetof(FGameplayEventData, Instigator) == 0x8, "Offset mismatch for FGameplayEventData::Instigator");
static_assert(offsetof(FGameplayEventData, Target) == 0x10, "Offset mismatch for FGameplayEventData::Target");
static_assert(offsetof(FGameplayEventData, OptionalObject) == 0x18, "Offset mismatch for FGameplayEventData::OptionalObject");
static_assert(offsetof(FGameplayEventData, OptionalObject2) == 0x20, "Offset mismatch for FGameplayEventData::OptionalObject2");
static_assert(offsetof(FGameplayEventData, ContextHandle) == 0x28, "Offset mismatch for FGameplayEventData::ContextHandle");
static_assert(offsetof(FGameplayEventData, InstigatorTags) == 0x40, "Offset mismatch for FGameplayEventData::InstigatorTags");
static_assert(offsetof(FGameplayEventData, TargetTags) == 0x60, "Offset mismatch for FGameplayEventData::TargetTags");
static_assert(offsetof(FGameplayEventData, EventMagnitude) == 0x80, "Offset mismatch for FGameplayEventData::EventMagnitude");
static_assert(offsetof(FGameplayEventData, TargetData) == 0x88, "Offset mismatch for FGameplayEventData::TargetData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayAbilityTargetDataHandle
{
};

static_assert(sizeof(FGameplayAbilityTargetDataHandle) == 0x28, "Size mismatch for FGameplayAbilityTargetDataHandle");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FGameplayTagRequirements
{
    FGameplayTagContainer RequireTags; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer IgnoreTags; // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagQuery TagQuery; // 0x40 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FGameplayTagRequirements) == 0x88, "Size mismatch for FGameplayTagRequirements");
static_assert(offsetof(FGameplayTagRequirements, RequireTags) == 0x0, "Offset mismatch for FGameplayTagRequirements::RequireTags");
static_assert(offsetof(FGameplayTagRequirements, IgnoreTags) == 0x20, "Offset mismatch for FGameplayTagRequirements::IgnoreTags");
static_assert(offsetof(FGameplayTagRequirements, TagQuery) == 0x40, "Offset mismatch for FGameplayTagRequirements::TagQuery");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayTargetDataFilterHandle
{
};

static_assert(sizeof(FGameplayTargetDataFilterHandle) == 0x10, "Size mismatch for FGameplayTargetDataFilterHandle");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGameplayAbilityActivationInfo
{
    TEnumAsByte<EGameplayAbilityActivationMode> ActivationMode; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t bCanBeEndedByOtherInstance : 1; // 0x1:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FPredictionKey PredictionKeyWhenActivated; // 0x4 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGameplayAbilityActivationInfo) == 0x14, "Size mismatch for FGameplayAbilityActivationInfo");
static_assert(offsetof(FGameplayAbilityActivationInfo, ActivationMode) == 0x0, "Offset mismatch for FGameplayAbilityActivationInfo::ActivationMode");
static_assert(offsetof(FGameplayAbilityActivationInfo, bCanBeEndedByOtherInstance) == 0x1, "Offset mismatch for FGameplayAbilityActivationInfo::bCanBeEndedByOtherInstance");
static_assert(offsetof(FGameplayAbilityActivationInfo, PredictionKeyWhenActivated) == 0x4, "Offset mismatch for FGameplayAbilityActivationInfo::PredictionKeyWhenActivated");

// Size: 0x198 (Inherited: 0x0, Single: 0x198)
struct FGameplayEffectQuery
{
    uint8_t CustomMatchDelegate_BP[0xc]; // 0x10 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagQuery OwningTagQuery; // 0x20 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery EffectTagQuery; // 0x68 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery SourceTagQuery; // 0xb0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery SourceAggregateTagQuery; // 0xf8 (Size: 0x48, Type: StructProperty)
    FGameplayAttribute ModifyingAttribute; // 0x140 (Size: 0x38, Type: StructProperty)
    UObject* EffectSource; // 0x178 (Size: 0x8, Type: ObjectProperty)
    UClass* EffectDefinition; // 0x180 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FGameplayEffectQuery) == 0x198, "Size mismatch for FGameplayEffectQuery");
static_assert(offsetof(FGameplayEffectQuery, CustomMatchDelegate_BP) == 0x10, "Offset mismatch for FGameplayEffectQuery::CustomMatchDelegate_BP");
static_assert(offsetof(FGameplayEffectQuery, OwningTagQuery) == 0x20, "Offset mismatch for FGameplayEffectQuery::OwningTagQuery");
static_assert(offsetof(FGameplayEffectQuery, EffectTagQuery) == 0x68, "Offset mismatch for FGameplayEffectQuery::EffectTagQuery");
static_assert(offsetof(FGameplayEffectQuery, SourceTagQuery) == 0xb0, "Offset mismatch for FGameplayEffectQuery::SourceTagQuery");
static_assert(offsetof(FGameplayEffectQuery, SourceAggregateTagQuery) == 0xf8, "Offset mismatch for FGameplayEffectQuery::SourceAggregateTagQuery");
static_assert(offsetof(FGameplayEffectQuery, ModifyingAttribute) == 0x140, "Offset mismatch for FGameplayEffectQuery::ModifyingAttribute");
static_assert(offsetof(FGameplayEffectQuery, EffectSource) == 0x178, "Offset mismatch for FGameplayEffectQuery::EffectSource");
static_assert(offsetof(FGameplayEffectQuery, EffectDefinition) == 0x180, "Offset mismatch for FGameplayEffectQuery::EffectDefinition");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FGameplayEffectSpecForRPC
{
    UGameplayEffect* Def; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayEffectModifiedAttribute> ModifiedAttributes; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FGameplayEffectContextHandle EffectContext; // 0x18 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer AggregatedSourceTags; // 0x30 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AggregatedTargetTags; // 0x50 (Size: 0x20, Type: StructProperty)
    float Level; // 0x70 (Size: 0x4, Type: FloatProperty)
    float AbilityLevel; // 0x74 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGameplayEffectSpecForRPC) == 0x78, "Size mismatch for FGameplayEffectSpecForRPC");
static_assert(offsetof(FGameplayEffectSpecForRPC, Def) == 0x0, "Offset mismatch for FGameplayEffectSpecForRPC::Def");
static_assert(offsetof(FGameplayEffectSpecForRPC, ModifiedAttributes) == 0x8, "Offset mismatch for FGameplayEffectSpecForRPC::ModifiedAttributes");
static_assert(offsetof(FGameplayEffectSpecForRPC, EffectContext) == 0x18, "Offset mismatch for FGameplayEffectSpecForRPC::EffectContext");
static_assert(offsetof(FGameplayEffectSpecForRPC, AggregatedSourceTags) == 0x30, "Offset mismatch for FGameplayEffectSpecForRPC::AggregatedSourceTags");
static_assert(offsetof(FGameplayEffectSpecForRPC, AggregatedTargetTags) == 0x50, "Offset mismatch for FGameplayEffectSpecForRPC::AggregatedTargetTags");
static_assert(offsetof(FGameplayEffectSpecForRPC, Level) == 0x70, "Offset mismatch for FGameplayEffectSpecForRPC::Level");
static_assert(offsetof(FGameplayEffectSpecForRPC, AbilityLevel) == 0x74, "Offset mismatch for FGameplayEffectSpecForRPC::AbilityLevel");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FServerAbilityRPCBatch
{
    FGameplayAbilitySpecHandle AbilitySpecHandle; // 0x0 (Size: 0x4, Type: StructProperty)
    FPredictionKey PredictionKey; // 0x4 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FGameplayAbilityTargetDataHandle TargetData; // 0x18 (Size: 0x28, Type: StructProperty)
    bool InputPressed; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool Ended; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool Started; // 0x42 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_43[0x5]; // 0x43 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FServerAbilityRPCBatch) == 0x48, "Size mismatch for FServerAbilityRPCBatch");
static_assert(offsetof(FServerAbilityRPCBatch, AbilitySpecHandle) == 0x0, "Offset mismatch for FServerAbilityRPCBatch::AbilitySpecHandle");
static_assert(offsetof(FServerAbilityRPCBatch, PredictionKey) == 0x4, "Offset mismatch for FServerAbilityRPCBatch::PredictionKey");
static_assert(offsetof(FServerAbilityRPCBatch, TargetData) == 0x18, "Offset mismatch for FServerAbilityRPCBatch::TargetData");
static_assert(offsetof(FServerAbilityRPCBatch, InputPressed) == 0x40, "Offset mismatch for FServerAbilityRPCBatch::InputPressed");
static_assert(offsetof(FServerAbilityRPCBatch, Ended) == 0x41, "Offset mismatch for FServerAbilityRPCBatch::Ended");
static_assert(offsetof(FServerAbilityRPCBatch, Started) == 0x42, "Offset mismatch for FServerAbilityRPCBatch::Started");

// Size: 0x118 (Inherited: 0x108, Single: 0x10)
struct FReplicatedPredictionKeyMap : FFastArraySerializer
{
    TArray<FReplicatedPredictionKeyItem> PredictionKeys; // 0x108 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReplicatedPredictionKeyMap) == 0x118, "Size mismatch for FReplicatedPredictionKeyMap");
static_assert(offsetof(FReplicatedPredictionKeyMap, PredictionKeys) == 0x108, "Offset mismatch for FReplicatedPredictionKeyMap::PredictionKeys");

// Size: 0x1c (Inherited: 0xc, Single: 0x10)
struct FReplicatedPredictionKeyItem : FFastArraySerializerItem
{
    FPredictionKey PredictionKey; // 0xc (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FReplicatedPredictionKeyItem) == 0x1c, "Size mismatch for FReplicatedPredictionKeyItem");
static_assert(offsetof(FReplicatedPredictionKeyItem, PredictionKey) == 0xc, "Offset mismatch for FReplicatedPredictionKeyItem::PredictionKey");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FMinimalReplicationTagCountMap
{
    UAbilitySystemComponent* Owner; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_58[0x10]; // 0x58 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FMinimalReplicationTagCountMap) == 0x68, "Size mismatch for FMinimalReplicationTagCountMap");
static_assert(offsetof(FMinimalReplicationTagCountMap, Owner) == 0x50, "Offset mismatch for FMinimalReplicationTagCountMap::Owner");

// Size: 0x128 (Inherited: 0x108, Single: 0x20)
struct FActiveGameplayCueContainer : FFastArraySerializer
{
    TArray<FActiveGameplayCue> GameplayCues; // 0x108 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_118[0x8]; // 0x118 (Size: 0x8, Type: PaddingProperty)
    UAbilitySystemComponent* Owner; // 0x120 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FActiveGameplayCueContainer) == 0x128, "Size mismatch for FActiveGameplayCueContainer");
static_assert(offsetof(FActiveGameplayCueContainer, GameplayCues) == 0x108, "Offset mismatch for FActiveGameplayCueContainer::GameplayCues");
static_assert(offsetof(FActiveGameplayCueContainer, Owner) == 0x120, "Offset mismatch for FActiveGameplayCueContainer::Owner");

// Size: 0xf8 (Inherited: 0xc, Single: 0xec)
struct FActiveGameplayCue : FFastArraySerializerItem
{
    FGameplayTag GameplayCueTag; // 0xc (Size: 0x4, Type: StructProperty)
    FPredictionKey PredictionKey; // 0x10 (Size: 0x10, Type: StructProperty)
    FGameplayCueParameters Parameters; // 0x20 (Size: 0xd0, Type: StructProperty)
    bool bPredictivelyRemoved; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x7]; // 0xf1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FActiveGameplayCue) == 0xf8, "Size mismatch for FActiveGameplayCue");
static_assert(offsetof(FActiveGameplayCue, GameplayCueTag) == 0xc, "Offset mismatch for FActiveGameplayCue::GameplayCueTag");
static_assert(offsetof(FActiveGameplayCue, PredictionKey) == 0x10, "Offset mismatch for FActiveGameplayCue::PredictionKey");
static_assert(offsetof(FActiveGameplayCue, Parameters) == 0x20, "Offset mismatch for FActiveGameplayCue::Parameters");
static_assert(offsetof(FActiveGameplayCue, bPredictivelyRemoved) == 0xf0, "Offset mismatch for FActiveGameplayCue::bPredictivelyRemoved");

// Size: 0x300 (Inherited: 0x108, Single: 0x1f8)
struct FActiveGameplayEffectsContainer : FFastArraySerializer
{
    uint8_t Pad_108[0x28]; // 0x108 (Size: 0x28, Type: PaddingProperty)
    TArray<FActiveGameplayEffect> GameplayEffects_Internal; // 0x130 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_140[0x1c0]; // 0x140 (Size: 0x1c0, Type: PaddingProperty)
};

static_assert(sizeof(FActiveGameplayEffectsContainer) == 0x300, "Size mismatch for FActiveGameplayEffectsContainer");
static_assert(offsetof(FActiveGameplayEffectsContainer, GameplayEffects_Internal) == 0x130, "Offset mismatch for FActiveGameplayEffectsContainer::GameplayEffects_Internal");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayAbilityLocalAnimMontage
{
    UAnimMontage* AnimMontage; // 0x0 (Size: 0x8, Type: ObjectProperty)
    char PlayInstanceId; // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    FPredictionKey PredictionKey; // 0xc (Size: 0x10, Type: StructProperty)
    TWeakObjectPtr<UGameplayAbility*> AnimatingAbility; // 0x1c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilityLocalAnimMontage) == 0x28, "Size mismatch for FGameplayAbilityLocalAnimMontage");
static_assert(offsetof(FGameplayAbilityLocalAnimMontage, AnimMontage) == 0x0, "Offset mismatch for FGameplayAbilityLocalAnimMontage::AnimMontage");
static_assert(offsetof(FGameplayAbilityLocalAnimMontage, PlayInstanceId) == 0x8, "Offset mismatch for FGameplayAbilityLocalAnimMontage::PlayInstanceId");
static_assert(offsetof(FGameplayAbilityLocalAnimMontage, PredictionKey) == 0xc, "Offset mismatch for FGameplayAbilityLocalAnimMontage::PredictionKey");
static_assert(offsetof(FGameplayAbilityLocalAnimMontage, AnimatingAbility) == 0x1c, "Offset mismatch for FGameplayAbilityLocalAnimMontage::AnimatingAbility");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGameplayAbilityRepAnimMontage
{
    UAnimSequenceBase* Animation; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName SlotName; // 0x8 (Size: 0x4, Type: NameProperty)
    float PlayRate; // 0xc (Size: 0x4, Type: FloatProperty)
    float Position; // 0x10 (Size: 0x4, Type: FloatProperty)
    float BlendTime; // 0x14 (Size: 0x4, Type: FloatProperty)
    float BlendOutTime; // 0x18 (Size: 0x4, Type: FloatProperty)
    float PlayCount; // 0x1c (Size: 0x4, Type: FloatProperty)
    char NextSectionID; // 0x20 (Size: 0x1, Type: ByteProperty)
    char PlayInstanceId; // 0x21 (Size: 0x1, Type: ByteProperty)
    uint8_t bRepPosition : 1; // 0x22:0 (Size: 0x1, Type: BoolProperty)
    uint8_t IsStopped : 1; // 0x22:1 (Size: 0x1, Type: BoolProperty)
    uint8_t SkipPositionCorrection : 1; // 0x22:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bSkipPlayRate : 1; // 0x22:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_23[0x1]; // 0x23 (Size: 0x1, Type: PaddingProperty)
    FPredictionKey PredictionKey; // 0x24 (Size: 0x10, Type: StructProperty)
    char SectionIdToPlay; // 0x34 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilityRepAnimMontage) == 0x38, "Size mismatch for FGameplayAbilityRepAnimMontage");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, Animation) == 0x0, "Offset mismatch for FGameplayAbilityRepAnimMontage::Animation");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, SlotName) == 0x8, "Offset mismatch for FGameplayAbilityRepAnimMontage::SlotName");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, PlayRate) == 0xc, "Offset mismatch for FGameplayAbilityRepAnimMontage::PlayRate");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, Position) == 0x10, "Offset mismatch for FGameplayAbilityRepAnimMontage::Position");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, BlendTime) == 0x14, "Offset mismatch for FGameplayAbilityRepAnimMontage::BlendTime");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, BlendOutTime) == 0x18, "Offset mismatch for FGameplayAbilityRepAnimMontage::BlendOutTime");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, PlayCount) == 0x1c, "Offset mismatch for FGameplayAbilityRepAnimMontage::PlayCount");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, NextSectionID) == 0x20, "Offset mismatch for FGameplayAbilityRepAnimMontage::NextSectionID");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, PlayInstanceId) == 0x21, "Offset mismatch for FGameplayAbilityRepAnimMontage::PlayInstanceId");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, bRepPosition) == 0x22, "Offset mismatch for FGameplayAbilityRepAnimMontage::bRepPosition");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, IsStopped) == 0x22, "Offset mismatch for FGameplayAbilityRepAnimMontage::IsStopped");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, SkipPositionCorrection) == 0x22, "Offset mismatch for FGameplayAbilityRepAnimMontage::SkipPositionCorrection");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, bSkipPlayRate) == 0x22, "Offset mismatch for FGameplayAbilityRepAnimMontage::bSkipPlayRate");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, PredictionKey) == 0x24, "Offset mismatch for FGameplayAbilityRepAnimMontage::PredictionKey");
static_assert(offsetof(FGameplayAbilityRepAnimMontage, SectionIdToPlay) == 0x34, "Offset mismatch for FGameplayAbilityRepAnimMontage::SectionIdToPlay");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FGameplayAbilitySpecContainer : FFastArraySerializer
{
    TArray<FGameplayAbilitySpec> Items; // 0x108 (Size: 0x10, Type: ArrayProperty)
    UAbilitySystemComponent* Owner; // 0x118 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayAbilitySpecContainer) == 0x120, "Size mismatch for FGameplayAbilitySpecContainer");
static_assert(offsetof(FGameplayAbilitySpecContainer, Items) == 0x108, "Offset mismatch for FGameplayAbilitySpecContainer::Items");
static_assert(offsetof(FGameplayAbilitySpecContainer, Owner) == 0x118, "Offset mismatch for FGameplayAbilitySpecContainer::Owner");

// Size: 0xf0 (Inherited: 0xc, Single: 0xe4)
struct FGameplayAbilitySpec : FFastArraySerializerItem
{
    FGameplayAbilitySpecHandle Handle; // 0xc (Size: 0x4, Type: StructProperty)
    UGameplayAbility* ability; // 0x10 (Size: 0x8, Type: ObjectProperty)
    int32_t Level; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t InputID; // 0x1c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UObject*> SourceObject; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    char ActiveCount; // 0x28 (Size: 0x1, Type: ByteProperty)
    uint8_t InputPressed : 1; // 0x29:0 (Size: 0x1, Type: BoolProperty)
    uint8_t RemoveAfterActivation : 1; // 0x29:1 (Size: 0x1, Type: BoolProperty)
    uint8_t PendingRemove : 1; // 0x29:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bActivateOnce : 1; // 0x29:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x16]; // 0x2a (Size: 0x16, Type: PaddingProperty)
    FGameplayAbilityActivationInfo ActivationInfo; // 0x40 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer DynamicAbilityTags; // 0x58 (Size: 0x20, Type: StructProperty)
    TArray<UGameplayAbility*> NonReplicatedInstances; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<UGameplayAbility*> ReplicatedInstances; // 0x88 (Size: 0x10, Type: ArrayProperty)
    FActiveGameplayEffectHandle GameplayEffectHandle; // 0x98 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_a0[0x50]; // 0xa0 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilitySpec) == 0xf0, "Size mismatch for FGameplayAbilitySpec");
static_assert(offsetof(FGameplayAbilitySpec, Handle) == 0xc, "Offset mismatch for FGameplayAbilitySpec::Handle");
static_assert(offsetof(FGameplayAbilitySpec, ability) == 0x10, "Offset mismatch for FGameplayAbilitySpec::ability");
static_assert(offsetof(FGameplayAbilitySpec, Level) == 0x18, "Offset mismatch for FGameplayAbilitySpec::Level");
static_assert(offsetof(FGameplayAbilitySpec, InputID) == 0x1c, "Offset mismatch for FGameplayAbilitySpec::InputID");
static_assert(offsetof(FGameplayAbilitySpec, SourceObject) == 0x20, "Offset mismatch for FGameplayAbilitySpec::SourceObject");
static_assert(offsetof(FGameplayAbilitySpec, ActiveCount) == 0x28, "Offset mismatch for FGameplayAbilitySpec::ActiveCount");
static_assert(offsetof(FGameplayAbilitySpec, InputPressed) == 0x29, "Offset mismatch for FGameplayAbilitySpec::InputPressed");
static_assert(offsetof(FGameplayAbilitySpec, RemoveAfterActivation) == 0x29, "Offset mismatch for FGameplayAbilitySpec::RemoveAfterActivation");
static_assert(offsetof(FGameplayAbilitySpec, PendingRemove) == 0x29, "Offset mismatch for FGameplayAbilitySpec::PendingRemove");
static_assert(offsetof(FGameplayAbilitySpec, bActivateOnce) == 0x29, "Offset mismatch for FGameplayAbilitySpec::bActivateOnce");
static_assert(offsetof(FGameplayAbilitySpec, ActivationInfo) == 0x40, "Offset mismatch for FGameplayAbilitySpec::ActivationInfo");
static_assert(offsetof(FGameplayAbilitySpec, DynamicAbilityTags) == 0x58, "Offset mismatch for FGameplayAbilitySpec::DynamicAbilityTags");
static_assert(offsetof(FGameplayAbilitySpec, NonReplicatedInstances) == 0x78, "Offset mismatch for FGameplayAbilitySpec::NonReplicatedInstances");
static_assert(offsetof(FGameplayAbilitySpec, ReplicatedInstances) == 0x88, "Offset mismatch for FGameplayAbilitySpec::ReplicatedInstances");
static_assert(offsetof(FGameplayAbilitySpec, GameplayEffectHandle) == 0x98, "Offset mismatch for FGameplayAbilitySpec::GameplayEffectHandle");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAttributeDefaults
{
    UClass* Attributes; // 0x0 (Size: 0x8, Type: ClassProperty)
    UDataTable* DefaultStartingTable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAttributeDefaults) == 0x10, "Size mismatch for FAttributeDefaults");
static_assert(offsetof(FAttributeDefaults, Attributes) == 0x0, "Offset mismatch for FAttributeDefaults::Attributes");
static_assert(offsetof(FAttributeDefaults, DefaultStartingTable) == 0x8, "Offset mismatch for FAttributeDefaults::DefaultStartingTable");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGameplayCueTag
{
    FGameplayTag GameplayCueTag; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FGameplayCueTag) == 0x4, "Size mismatch for FGameplayCueTag");
static_assert(offsetof(FGameplayCueTag, GameplayCueTag) == 0x0, "Offset mismatch for FGameplayCueTag::GameplayCueTag");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameplayAbilityActorInfo
{
    TWeakObjectPtr<AActor*> OwnerActor; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> AvatarActor; // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerController*> PlayerController; // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> AbilitySystemComponent; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> SkeletalMeshComponent; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAnimInstance*> AnimInstance; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMovementComponent*> MovementComponent; // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    FName AffectedAnimInstanceTag; // 0x40 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilityActorInfo) == 0x48, "Size mismatch for FGameplayAbilityActorInfo");
static_assert(offsetof(FGameplayAbilityActorInfo, OwnerActor) == 0x8, "Offset mismatch for FGameplayAbilityActorInfo::OwnerActor");
static_assert(offsetof(FGameplayAbilityActorInfo, AvatarActor) == 0x10, "Offset mismatch for FGameplayAbilityActorInfo::AvatarActor");
static_assert(offsetof(FGameplayAbilityActorInfo, PlayerController) == 0x18, "Offset mismatch for FGameplayAbilityActorInfo::PlayerController");
static_assert(offsetof(FGameplayAbilityActorInfo, AbilitySystemComponent) == 0x20, "Offset mismatch for FGameplayAbilityActorInfo::AbilitySystemComponent");
static_assert(offsetof(FGameplayAbilityActorInfo, SkeletalMeshComponent) == 0x28, "Offset mismatch for FGameplayAbilityActorInfo::SkeletalMeshComponent");
static_assert(offsetof(FGameplayAbilityActorInfo, AnimInstance) == 0x30, "Offset mismatch for FGameplayAbilityActorInfo::AnimInstance");
static_assert(offsetof(FGameplayAbilityActorInfo, MovementComponent) == 0x38, "Offset mismatch for FGameplayAbilityActorInfo::MovementComponent");
static_assert(offsetof(FGameplayAbilityActorInfo, AffectedAnimInstanceTag) == 0x40, "Offset mismatch for FGameplayAbilityActorInfo::AffectedAnimInstanceTag");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FGameplayAbilityTargetingLocationInfo
{
    AActor* SourceActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMeshComponent* SourceComponent; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UGameplayAbility* SourceAbility; // 0x18 (Size: 0x8, Type: ObjectProperty)
    FTransform LiteralTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FName SourceSocketName; // 0x80 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EGameplayAbilityTargetingLocationType> LocationType; // 0x84 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_85[0xb]; // 0x85 (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilityTargetingLocationInfo) == 0x90, "Size mismatch for FGameplayAbilityTargetingLocationInfo");
static_assert(offsetof(FGameplayAbilityTargetingLocationInfo, SourceActor) == 0x8, "Offset mismatch for FGameplayAbilityTargetingLocationInfo::SourceActor");
static_assert(offsetof(FGameplayAbilityTargetingLocationInfo, SourceComponent) == 0x10, "Offset mismatch for FGameplayAbilityTargetingLocationInfo::SourceComponent");
static_assert(offsetof(FGameplayAbilityTargetingLocationInfo, SourceAbility) == 0x18, "Offset mismatch for FGameplayAbilityTargetingLocationInfo::SourceAbility");
static_assert(offsetof(FGameplayAbilityTargetingLocationInfo, LiteralTransform) == 0x20, "Offset mismatch for FGameplayAbilityTargetingLocationInfo::LiteralTransform");
static_assert(offsetof(FGameplayAbilityTargetingLocationInfo, SourceSocketName) == 0x80, "Offset mismatch for FGameplayAbilityTargetingLocationInfo::SourceSocketName");
static_assert(offsetof(FGameplayAbilityTargetingLocationInfo, LocationType) == 0x84, "Offset mismatch for FGameplayAbilityTargetingLocationInfo::LocationType");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAbilityTriggerData
{
    FGameplayTag TriggerTag; // 0x0 (Size: 0x4, Type: StructProperty)
    TEnumAsByte<EGameplayAbilityTriggerSource> TriggerSource; // 0x4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAbilityTriggerData) == 0x8, "Size mismatch for FAbilityTriggerData");
static_assert(offsetof(FAbilityTriggerData, TriggerTag) == 0x0, "Offset mismatch for FAbilityTriggerData::TriggerTag");
static_assert(offsetof(FAbilityTriggerData, TriggerSource) == 0x4, "Offset mismatch for FAbilityTriggerData::TriggerSource");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGameplayModifierEvaluatedData
{
    FGameplayAttribute Attribute; // 0x0 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EGameplayModOp> ModifierOp; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Magnitude; // 0x3c (Size: 0x4, Type: FloatProperty)
    FActiveGameplayEffectHandle Handle; // 0x40 (Size: 0x8, Type: StructProperty)
    bool IsValid; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayModifierEvaluatedData) == 0x50, "Size mismatch for FGameplayModifierEvaluatedData");
static_assert(offsetof(FGameplayModifierEvaluatedData, Attribute) == 0x0, "Offset mismatch for FGameplayModifierEvaluatedData::Attribute");
static_assert(offsetof(FGameplayModifierEvaluatedData, ModifierOp) == 0x38, "Offset mismatch for FGameplayModifierEvaluatedData::ModifierOp");
static_assert(offsetof(FGameplayModifierEvaluatedData, Magnitude) == 0x3c, "Offset mismatch for FGameplayModifierEvaluatedData::Magnitude");
static_assert(offsetof(FGameplayModifierEvaluatedData, Handle) == 0x40, "Offset mismatch for FGameplayModifierEvaluatedData::Handle");
static_assert(offsetof(FGameplayModifierEvaluatedData, IsValid) == 0x48, "Offset mismatch for FGameplayModifierEvaluatedData::IsValid");

// Size: 0x338 (Inherited: 0x0, Single: 0x338)
struct FGameplayEffectExecutionScopedModifierInfo
{
    FGameplayEffectAttributeCaptureDefinition CapturedAttribute; // 0x0 (Size: 0x40, Type: StructProperty)
    FGameplayTag TransientAggregatorIdentifier; // 0x40 (Size: 0x4, Type: StructProperty)
    uint8_t AggregatorType; // 0x44 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EGameplayModOp> ModifierOp; // 0x45 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_46[0x2]; // 0x46 (Size: 0x2, Type: PaddingProperty)
    FGameplayEffectModifierMagnitude ModifierMagnitude; // 0x48 (Size: 0x1d8, Type: StructProperty)
    FGameplayModEvaluationChannelSettings EvaluationChannelSettings; // 0x220 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_221[0x7]; // 0x221 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagRequirements SourceTags; // 0x228 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements TargetTags; // 0x2b0 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(FGameplayEffectExecutionScopedModifierInfo) == 0x338, "Size mismatch for FGameplayEffectExecutionScopedModifierInfo");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, CapturedAttribute) == 0x0, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::CapturedAttribute");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, TransientAggregatorIdentifier) == 0x40, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::TransientAggregatorIdentifier");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, AggregatorType) == 0x44, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::AggregatorType");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, ModifierOp) == 0x45, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::ModifierOp");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, ModifierMagnitude) == 0x48, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::ModifierMagnitude");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, EvaluationChannelSettings) == 0x220, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::EvaluationChannelSettings");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, SourceTags) == 0x228, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::SourceTags");
static_assert(offsetof(FGameplayEffectExecutionScopedModifierInfo, TargetTags) == 0x2b0, "Offset mismatch for FGameplayEffectExecutionScopedModifierInfo::TargetTags");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGameplayModEvaluationChannelSettings
{
    uint8_t Channel; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FGameplayModEvaluationChannelSettings) == 0x1, "Size mismatch for FGameplayModEvaluationChannelSettings");
static_assert(offsetof(FGameplayModEvaluationChannelSettings, Channel) == 0x0, "Offset mismatch for FGameplayModEvaluationChannelSettings::Channel");

// Size: 0x1d8 (Inherited: 0x0, Single: 0x1d8)
struct FGameplayEffectModifierMagnitude
{
    uint8_t MagnitudeCalculationType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat ScalableFloatMagnitude; // 0x8 (Size: 0x28, Type: StructProperty)
    FAttributeBasedFloat AttributeBasedMagnitude; // 0x30 (Size: 0x110, Type: StructProperty)
    FCustomCalculationBasedFloat CustomMagnitude; // 0x140 (Size: 0x90, Type: StructProperty)
    FSetByCallerFloat SetByCallerMagnitude; // 0x1d0 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FGameplayEffectModifierMagnitude) == 0x1d8, "Size mismatch for FGameplayEffectModifierMagnitude");
static_assert(offsetof(FGameplayEffectModifierMagnitude, MagnitudeCalculationType) == 0x0, "Offset mismatch for FGameplayEffectModifierMagnitude::MagnitudeCalculationType");
static_assert(offsetof(FGameplayEffectModifierMagnitude, ScalableFloatMagnitude) == 0x8, "Offset mismatch for FGameplayEffectModifierMagnitude::ScalableFloatMagnitude");
static_assert(offsetof(FGameplayEffectModifierMagnitude, AttributeBasedMagnitude) == 0x30, "Offset mismatch for FGameplayEffectModifierMagnitude::AttributeBasedMagnitude");
static_assert(offsetof(FGameplayEffectModifierMagnitude, CustomMagnitude) == 0x140, "Offset mismatch for FGameplayEffectModifierMagnitude::CustomMagnitude");
static_assert(offsetof(FGameplayEffectModifierMagnitude, SetByCallerMagnitude) == 0x1d0, "Offset mismatch for FGameplayEffectModifierMagnitude::SetByCallerMagnitude");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FSetByCallerFloat
{
    FName DataName; // 0x0 (Size: 0x4, Type: NameProperty)
    FGameplayTag DataTag; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FSetByCallerFloat) == 0x8, "Size mismatch for FSetByCallerFloat");
static_assert(offsetof(FSetByCallerFloat, DataName) == 0x0, "Offset mismatch for FSetByCallerFloat::DataName");
static_assert(offsetof(FSetByCallerFloat, DataTag) == 0x4, "Offset mismatch for FSetByCallerFloat::DataTag");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FCustomCalculationBasedFloat
{
    UClass* CalculationClassMagnitude; // 0x0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat Coefficient; // 0x8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PreMultiplyAdditiveValue; // 0x30 (Size: 0x28, Type: StructProperty)
    FScalableFloat PostMultiplyAdditiveValue; // 0x58 (Size: 0x28, Type: StructProperty)
    FCurveTableRowHandle FinalLookupCurve; // 0x80 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCustomCalculationBasedFloat) == 0x90, "Size mismatch for FCustomCalculationBasedFloat");
static_assert(offsetof(FCustomCalculationBasedFloat, CalculationClassMagnitude) == 0x0, "Offset mismatch for FCustomCalculationBasedFloat::CalculationClassMagnitude");
static_assert(offsetof(FCustomCalculationBasedFloat, Coefficient) == 0x8, "Offset mismatch for FCustomCalculationBasedFloat::Coefficient");
static_assert(offsetof(FCustomCalculationBasedFloat, PreMultiplyAdditiveValue) == 0x30, "Offset mismatch for FCustomCalculationBasedFloat::PreMultiplyAdditiveValue");
static_assert(offsetof(FCustomCalculationBasedFloat, PostMultiplyAdditiveValue) == 0x58, "Offset mismatch for FCustomCalculationBasedFloat::PostMultiplyAdditiveValue");
static_assert(offsetof(FCustomCalculationBasedFloat, FinalLookupCurve) == 0x80, "Offset mismatch for FCustomCalculationBasedFloat::FinalLookupCurve");

// Size: 0x110 (Inherited: 0x0, Single: 0x110)
struct FAttributeBasedFloat
{
    FScalableFloat Coefficient; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat PreMultiplyAdditiveValue; // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat PostMultiplyAdditiveValue; // 0x50 (Size: 0x28, Type: StructProperty)
    FGameplayEffectAttributeCaptureDefinition BackingAttribute; // 0x78 (Size: 0x40, Type: StructProperty)
    FCurveTableRowHandle AttributeCurve; // 0xb8 (Size: 0x10, Type: StructProperty)
    uint8_t AttributeCalculationType; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t FinalChannel; // 0xc9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_ca[0x6]; // 0xca (Size: 0x6, Type: PaddingProperty)
    FGameplayTagContainer SourceTagFilter; // 0xd0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TargetTagFilter; // 0xf0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FAttributeBasedFloat) == 0x110, "Size mismatch for FAttributeBasedFloat");
static_assert(offsetof(FAttributeBasedFloat, Coefficient) == 0x0, "Offset mismatch for FAttributeBasedFloat::Coefficient");
static_assert(offsetof(FAttributeBasedFloat, PreMultiplyAdditiveValue) == 0x28, "Offset mismatch for FAttributeBasedFloat::PreMultiplyAdditiveValue");
static_assert(offsetof(FAttributeBasedFloat, PostMultiplyAdditiveValue) == 0x50, "Offset mismatch for FAttributeBasedFloat::PostMultiplyAdditiveValue");
static_assert(offsetof(FAttributeBasedFloat, BackingAttribute) == 0x78, "Offset mismatch for FAttributeBasedFloat::BackingAttribute");
static_assert(offsetof(FAttributeBasedFloat, AttributeCurve) == 0xb8, "Offset mismatch for FAttributeBasedFloat::AttributeCurve");
static_assert(offsetof(FAttributeBasedFloat, AttributeCalculationType) == 0xc8, "Offset mismatch for FAttributeBasedFloat::AttributeCalculationType");
static_assert(offsetof(FAttributeBasedFloat, FinalChannel) == 0xc9, "Offset mismatch for FAttributeBasedFloat::FinalChannel");
static_assert(offsetof(FAttributeBasedFloat, SourceTagFilter) == 0xd0, "Offset mismatch for FAttributeBasedFloat::SourceTagFilter");
static_assert(offsetof(FAttributeBasedFloat, TargetTagFilter) == 0xf0, "Offset mismatch for FAttributeBasedFloat::TargetTagFilter");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGameplayAbilitySpecConfig
{
    UClass* ability; // 0x0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat LevelScalableFloat; // 0x8 (Size: 0x28, Type: StructProperty)
    int32_t InputID; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t RemovalPolicy; // 0x34 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilitySpecConfig) == 0x38, "Size mismatch for FGameplayAbilitySpecConfig");
static_assert(offsetof(FGameplayAbilitySpecConfig, ability) == 0x0, "Offset mismatch for FGameplayAbilitySpecConfig::ability");
static_assert(offsetof(FGameplayAbilitySpecConfig, LevelScalableFloat) == 0x8, "Offset mismatch for FGameplayAbilitySpecConfig::LevelScalableFloat");
static_assert(offsetof(FGameplayAbilitySpecConfig, InputID) == 0x30, "Offset mismatch for FGameplayAbilitySpecConfig::InputID");
static_assert(offsetof(FGameplayAbilitySpecConfig, RemovalPolicy) == 0x34, "Offset mismatch for FGameplayAbilitySpecConfig::RemovalPolicy");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FGameplayAbilityTargetingLocationInfoNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FGameplayAbilityTargetingLocationInfoNetSerializerConfig) == 0x10, "Size mismatch for FGameplayAbilityTargetingLocationInfoNetSerializerConfig");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FGameplayCuePendingExecute
{
    FPredictionKey PredictionKey; // 0x18 (Size: 0x10, Type: StructProperty)
    uint8_t PayloadType; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UAbilitySystemComponent* OwningComponent; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FGameplayEffectSpecForRPC FromSpec; // 0x38 (Size: 0x78, Type: StructProperty)
    FGameplayCueParameters CueParameters; // 0xb0 (Size: 0xd0, Type: StructProperty)
};

static_assert(sizeof(FGameplayCuePendingExecute) == 0x180, "Size mismatch for FGameplayCuePendingExecute");
static_assert(offsetof(FGameplayCuePendingExecute, PredictionKey) == 0x18, "Offset mismatch for FGameplayCuePendingExecute::PredictionKey");
static_assert(offsetof(FGameplayCuePendingExecute, PayloadType) == 0x28, "Offset mismatch for FGameplayCuePendingExecute::PayloadType");
static_assert(offsetof(FGameplayCuePendingExecute, OwningComponent) == 0x30, "Offset mismatch for FGameplayCuePendingExecute::OwningComponent");
static_assert(offsetof(FGameplayCuePendingExecute, FromSpec) == 0x38, "Offset mismatch for FGameplayCuePendingExecute::FromSpec");
static_assert(offsetof(FGameplayCuePendingExecute, CueParameters) == 0xb0, "Offset mismatch for FGameplayCuePendingExecute::CueParameters");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayCueNotifyActorArray
{
    TArray<AGameplayCueNotify_Actor*> Actors; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayCueNotifyActorArray) == 0x10, "Size mismatch for FGameplayCueNotifyActorArray");
static_assert(offsetof(FGameplayCueNotifyActorArray, Actors) == 0x0, "Offset mismatch for FGameplayCueNotifyActorArray::Actors");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FPreallocationInfo
{
    TMap<FGameplayCueNotifyActorArray, UClass*> PreallocatedInstances; // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<UClass*> ClassesNeedingPreallocation; // 0x50 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_60[0x8]; // 0x60 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FPreallocationInfo) == 0x68, "Size mismatch for FPreallocationInfo");
static_assert(offsetof(FPreallocationInfo, PreallocatedInstances) == 0x0, "Offset mismatch for FPreallocationInfo::PreallocatedInstances");
static_assert(offsetof(FPreallocationInfo, ClassesNeedingPreallocation) == 0x50, "Offset mismatch for FPreallocationInfo::ClassesNeedingPreallocation");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FMinimalGameplayCueReplicationProxyForNetSerializer
{
    TArray<FGameplayTag> Tags; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector_NetQuantize> Locations; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMinimalGameplayCueReplicationProxyForNetSerializer) == 0x20, "Size mismatch for FMinimalGameplayCueReplicationProxyForNetSerializer");
static_assert(offsetof(FMinimalGameplayCueReplicationProxyForNetSerializer, Tags) == 0x0, "Offset mismatch for FMinimalGameplayCueReplicationProxyForNetSerializer::Tags");
static_assert(offsetof(FMinimalGameplayCueReplicationProxyForNetSerializer, Locations) == 0x10, "Offset mismatch for FMinimalGameplayCueReplicationProxyForNetSerializer::Locations");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FMinimalReplicationTagCountMapForNetSerializer
{
    TArray<FGameplayTag> Tags; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMinimalReplicationTagCountMapForNetSerializer) == 0x10, "Size mismatch for FMinimalReplicationTagCountMapForNetSerializer");
static_assert(offsetof(FMinimalReplicationTagCountMapForNetSerializer, Tags) == 0x0, "Offset mismatch for FMinimalReplicationTagCountMapForNetSerializer::Tags");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayAbilityBindInfo
{
    TEnumAsByte<EGameplayAbilityInputBinds> Command; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UClass* GameplayAbilityClass; // 0x8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FGameplayAbilityBindInfo) == 0x10, "Size mismatch for FGameplayAbilityBindInfo");
static_assert(offsetof(FGameplayAbilityBindInfo, Command) == 0x0, "Offset mismatch for FGameplayAbilityBindInfo::Command");
static_assert(offsetof(FGameplayAbilityBindInfo, GameplayAbilityClass) == 0x8, "Offset mismatch for FGameplayAbilityBindInfo::GameplayAbilityClass");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayTargetDataFilter
{
    AActor* SelfActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* RequiredActorClass; // 0x10 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<ETargetDataFilterSelf> SelfFilter; // 0x18 (Size: 0x1, Type: ByteProperty)
    bool bReverseFilter; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayTargetDataFilter) == 0x20, "Size mismatch for FGameplayTargetDataFilter");
static_assert(offsetof(FGameplayTargetDataFilter, SelfActor) == 0x8, "Offset mismatch for FGameplayTargetDataFilter::SelfActor");
static_assert(offsetof(FGameplayTargetDataFilter, RequiredActorClass) == 0x10, "Offset mismatch for FGameplayTargetDataFilter::RequiredActorClass");
static_assert(offsetof(FGameplayTargetDataFilter, SelfFilter) == 0x18, "Offset mismatch for FGameplayTargetDataFilter::SelfFilter");
static_assert(offsetof(FGameplayTargetDataFilter, bReverseFilter) == 0x19, "Offset mismatch for FGameplayTargetDataFilter::bReverseFilter");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FWorldReticleParameters
{
    FVector AOEScale; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FWorldReticleParameters) == 0x18, "Size mismatch for FWorldReticleParameters");
static_assert(offsetof(FWorldReticleParameters, AOEScale) == 0x0, "Offset mismatch for FWorldReticleParameters::AOEScale");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FNetSerializeScriptStructCache
{
    TArray<UScriptStruct*> ScriptStructs; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FNetSerializeScriptStructCache) == 0x10, "Size mismatch for FNetSerializeScriptStructCache");
static_assert(offsetof(FNetSerializeScriptStructCache, ScriptStructs) == 0x0, "Offset mismatch for FNetSerializeScriptStructCache::ScriptStructs");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayAttributeData
{
    float BaseValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    float CurrentValue; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGameplayAttributeData) == 0x10, "Size mismatch for FGameplayAttributeData");
static_assert(offsetof(FGameplayAttributeData, BaseValue) == 0x8, "Offset mismatch for FGameplayAttributeData::BaseValue");
static_assert(offsetof(FGameplayAttributeData, CurrentValue) == 0xc, "Offset mismatch for FGameplayAttributeData::CurrentValue");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FAttributeMetaData : FTableRowBase
{
    float BaseValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinValue; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxValue; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FString DerivedAttributeInfo; // 0x18 (Size: 0x10, Type: StrProperty)
    bool bCanStack; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAttributeMetaData) == 0x30, "Size mismatch for FAttributeMetaData");
static_assert(offsetof(FAttributeMetaData, BaseValue) == 0x8, "Offset mismatch for FAttributeMetaData::BaseValue");
static_assert(offsetof(FAttributeMetaData, MinValue) == 0xc, "Offset mismatch for FAttributeMetaData::MinValue");
static_assert(offsetof(FAttributeMetaData, MaxValue) == 0x10, "Offset mismatch for FAttributeMetaData::MaxValue");
static_assert(offsetof(FAttributeMetaData, DerivedAttributeInfo) == 0x18, "Offset mismatch for FAttributeMetaData::DerivedAttributeInfo");
static_assert(offsetof(FAttributeMetaData, bCanStack) == 0x28, "Offset mismatch for FAttributeMetaData::bCanStack");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGameplayAbilityTargetData
{
};

static_assert(sizeof(FGameplayAbilityTargetData) == 0x8, "Size mismatch for FGameplayAbilityTargetData");

// Size: 0x130 (Inherited: 0x8, Single: 0x128)
struct FGameplayAbilityTargetData_LocationInfo : FGameplayAbilityTargetData
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FGameplayAbilityTargetingLocationInfo SourceLocation; // 0x10 (Size: 0x90, Type: StructProperty)
    FGameplayAbilityTargetingLocationInfo TargetLocation; // 0xa0 (Size: 0x90, Type: StructProperty)
};

static_assert(sizeof(FGameplayAbilityTargetData_LocationInfo) == 0x130, "Size mismatch for FGameplayAbilityTargetData_LocationInfo");
static_assert(offsetof(FGameplayAbilityTargetData_LocationInfo, SourceLocation) == 0x10, "Offset mismatch for FGameplayAbilityTargetData_LocationInfo::SourceLocation");
static_assert(offsetof(FGameplayAbilityTargetData_LocationInfo, TargetLocation) == 0xa0, "Offset mismatch for FGameplayAbilityTargetData_LocationInfo::TargetLocation");

// Size: 0xb0 (Inherited: 0x8, Single: 0xa8)
struct FGameplayAbilityTargetData_ActorArray : FGameplayAbilityTargetData
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FGameplayAbilityTargetingLocationInfo SourceLocation; // 0x10 (Size: 0x90, Type: StructProperty)
    TArray<TWeakObjectPtr<AActor*>> TargetActorArray; // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayAbilityTargetData_ActorArray) == 0xb0, "Size mismatch for FGameplayAbilityTargetData_ActorArray");
static_assert(offsetof(FGameplayAbilityTargetData_ActorArray, SourceLocation) == 0x10, "Offset mismatch for FGameplayAbilityTargetData_ActorArray::SourceLocation");
static_assert(offsetof(FGameplayAbilityTargetData_ActorArray, TargetActorArray) == 0xa0, "Offset mismatch for FGameplayAbilityTargetData_ActorArray::TargetActorArray");

// Size: 0x108 (Inherited: 0x8, Single: 0x100)
struct FGameplayAbilityTargetData_SingleTargetHit : FGameplayAbilityTargetData
{
    FHitResult HitResult; // 0x8 (Size: 0xf8, Type: StructProperty)
    bool bHitReplaced; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayAbilityTargetData_SingleTargetHit) == 0x108, "Size mismatch for FGameplayAbilityTargetData_SingleTargetHit");
static_assert(offsetof(FGameplayAbilityTargetData_SingleTargetHit, HitResult) == 0x8, "Offset mismatch for FGameplayAbilityTargetData_SingleTargetHit::HitResult");
static_assert(offsetof(FGameplayAbilityTargetData_SingleTargetHit, bHitReplaced) == 0x100, "Offset mismatch for FGameplayAbilityTargetData_SingleTargetHit::bHitReplaced");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAbilityEndedData
{
    UGameplayAbility* AbilityThatEnded; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayAbilitySpecHandle AbilitySpecHandle; // 0x8 (Size: 0x4, Type: StructProperty)
    bool bReplicateEndAbility; // 0xc (Size: 0x1, Type: BoolProperty)
    bool bWasCancelled; // 0xd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FAbilityEndedData) == 0x10, "Size mismatch for FAbilityEndedData");
static_assert(offsetof(FAbilityEndedData, AbilityThatEnded) == 0x0, "Offset mismatch for FAbilityEndedData::AbilityThatEnded");
static_assert(offsetof(FAbilityEndedData, AbilitySpecHandle) == 0x8, "Offset mismatch for FAbilityEndedData::AbilitySpecHandle");
static_assert(offsetof(FAbilityEndedData, bReplicateEndAbility) == 0xc, "Offset mismatch for FAbilityEndedData::bReplicateEndAbility");
static_assert(offsetof(FAbilityEndedData, bWasCancelled) == 0xd, "Offset mismatch for FAbilityEndedData::bWasCancelled");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAbilityTaskDebugMessage
{
    UGameplayTask* FromTask; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FString Message; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FAbilityTaskDebugMessage) == 0x18, "Size mismatch for FAbilityTaskDebugMessage");
static_assert(offsetof(FAbilityTaskDebugMessage, FromTask) == 0x0, "Offset mismatch for FAbilityTaskDebugMessage::FromTask");
static_assert(offsetof(FAbilityTaskDebugMessage, Message) == 0x8, "Offset mismatch for FAbilityTaskDebugMessage::Message");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGameplayAbilitySpecHandleAndPredictionKey
{
    FGameplayAbilitySpecHandle AbilityHandle; // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t PredictionKeyAtCreation; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGameplayAbilitySpecHandleAndPredictionKey) == 0x8, "Size mismatch for FGameplayAbilitySpecHandleAndPredictionKey");
static_assert(offsetof(FGameplayAbilitySpecHandleAndPredictionKey, AbilityHandle) == 0x0, "Offset mismatch for FGameplayAbilitySpecHandleAndPredictionKey::AbilityHandle");
static_assert(offsetof(FGameplayAbilitySpecHandleAndPredictionKey, PredictionKeyAtCreation) == 0x4, "Offset mismatch for FGameplayAbilitySpecHandleAndPredictionKey::PredictionKeyAtCreation");

// Size: 0x2c0 (Inherited: 0x0, Single: 0x2c0)
struct FMinimalGameplayCueReplicationProxy
{
    UAbilitySystemComponent* Owner; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FMinimalGameplayCueReplicationProxy) == 0x2c0, "Size mismatch for FMinimalGameplayCueReplicationProxy");
static_assert(offsetof(FMinimalGameplayCueReplicationProxy, Owner) == 0x2b0, "Offset mismatch for FMinimalGameplayCueReplicationProxy::Owner");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGameplayCueObjectLibrary
{
    TArray<FString> Paths; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x20]; // 0x10 (Size: 0x20, Type: PaddingProperty)
    UObjectLibrary* ActorObjectLibrary; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UObjectLibrary* StaticObjectLibrary; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UGameplayCueSet* CueSet; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_48[0x4]; // 0x48 (Size: 0x4, Type: PaddingProperty)
    bool bShouldSyncScan; // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bShouldAsyncLoad; // 0x4d (Size: 0x1, Type: BoolProperty)
    bool bShouldSyncLoad; // 0x4e (Size: 0x1, Type: BoolProperty)
    bool bHasBeenInitialized; // 0x4f (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGameplayCueObjectLibrary) == 0x50, "Size mismatch for FGameplayCueObjectLibrary");
static_assert(offsetof(FGameplayCueObjectLibrary, Paths) == 0x0, "Offset mismatch for FGameplayCueObjectLibrary::Paths");
static_assert(offsetof(FGameplayCueObjectLibrary, ActorObjectLibrary) == 0x30, "Offset mismatch for FGameplayCueObjectLibrary::ActorObjectLibrary");
static_assert(offsetof(FGameplayCueObjectLibrary, StaticObjectLibrary) == 0x38, "Offset mismatch for FGameplayCueObjectLibrary::StaticObjectLibrary");
static_assert(offsetof(FGameplayCueObjectLibrary, CueSet) == 0x40, "Offset mismatch for FGameplayCueObjectLibrary::CueSet");
static_assert(offsetof(FGameplayCueObjectLibrary, bShouldSyncScan) == 0x4c, "Offset mismatch for FGameplayCueObjectLibrary::bShouldSyncScan");
static_assert(offsetof(FGameplayCueObjectLibrary, bShouldAsyncLoad) == 0x4d, "Offset mismatch for FGameplayCueObjectLibrary::bShouldAsyncLoad");
static_assert(offsetof(FGameplayCueObjectLibrary, bShouldSyncLoad) == 0x4e, "Offset mismatch for FGameplayCueObjectLibrary::bShouldSyncLoad");
static_assert(offsetof(FGameplayCueObjectLibrary, bHasBeenInitialized) == 0x4f, "Offset mismatch for FGameplayCueObjectLibrary::bHasBeenInitialized");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGameplayCueNotify_SpawnCondition
{
    uint8_t LocallyControlledSource; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LocallyControlledPolicy; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float ChanceToPlay; // 0x4 (Size: 0x4, Type: FloatProperty)
    TArray<TEnumAsByte<EPhysicalSurface>> AllowedSurfaceTypes; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    TArray<TEnumAsByte<EPhysicalSurface>> RejectedSurfaceTypes; // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueNotify_SpawnCondition) == 0x38, "Size mismatch for FGameplayCueNotify_SpawnCondition");
static_assert(offsetof(FGameplayCueNotify_SpawnCondition, LocallyControlledSource) == 0x0, "Offset mismatch for FGameplayCueNotify_SpawnCondition::LocallyControlledSource");
static_assert(offsetof(FGameplayCueNotify_SpawnCondition, LocallyControlledPolicy) == 0x1, "Offset mismatch for FGameplayCueNotify_SpawnCondition::LocallyControlledPolicy");
static_assert(offsetof(FGameplayCueNotify_SpawnCondition, ChanceToPlay) == 0x4, "Offset mismatch for FGameplayCueNotify_SpawnCondition::ChanceToPlay");
static_assert(offsetof(FGameplayCueNotify_SpawnCondition, AllowedSurfaceTypes) == 0x8, "Offset mismatch for FGameplayCueNotify_SpawnCondition::AllowedSurfaceTypes");
static_assert(offsetof(FGameplayCueNotify_SpawnCondition, RejectedSurfaceTypes) == 0x20, "Offset mismatch for FGameplayCueNotify_SpawnCondition::RejectedSurfaceTypes");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGameplayCueNotify_PlacementInfo
{
    FName SocketName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t AttachPolicy; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t AttachmentRule; // 0x5 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    uint8_t bOverrideRotation : 1; // 0x8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideScale : 1; // 0x8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    FRotator RotationOverride; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector ScaleOverride; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FGameplayCueNotify_PlacementInfo) == 0x40, "Size mismatch for FGameplayCueNotify_PlacementInfo");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, SocketName) == 0x0, "Offset mismatch for FGameplayCueNotify_PlacementInfo::SocketName");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, AttachPolicy) == 0x4, "Offset mismatch for FGameplayCueNotify_PlacementInfo::AttachPolicy");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, AttachmentRule) == 0x5, "Offset mismatch for FGameplayCueNotify_PlacementInfo::AttachmentRule");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, bOverrideRotation) == 0x8, "Offset mismatch for FGameplayCueNotify_PlacementInfo::bOverrideRotation");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, bOverrideScale) == 0x8, "Offset mismatch for FGameplayCueNotify_PlacementInfo::bOverrideScale");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, RotationOverride) == 0x10, "Offset mismatch for FGameplayCueNotify_PlacementInfo::RotationOverride");
static_assert(offsetof(FGameplayCueNotify_PlacementInfo, ScaleOverride) == 0x28, "Offset mismatch for FGameplayCueNotify_PlacementInfo::ScaleOverride");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FGameplayCueNotify_SpawnResult
{
    TArray<UFXSystemComponent*> FxSystemComponents; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UAudioComponent*> AudioComponents; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraShakeBase*> CameraShakes; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<TScriptInterface<Class>> CameraLensEffects; // 0x30 (Size: 0x10, Type: ArrayProperty)
    UForceFeedbackComponent* ForceFeedbackComponent; // 0x40 (Size: 0x8, Type: ObjectProperty)
    APlayerController* ForceFeedbackTargetPC; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UDecalComponent* DecalComponent; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayCueNotify_SpawnResult) == 0x58, "Size mismatch for FGameplayCueNotify_SpawnResult");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, FxSystemComponents) == 0x0, "Offset mismatch for FGameplayCueNotify_SpawnResult::FxSystemComponents");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, AudioComponents) == 0x10, "Offset mismatch for FGameplayCueNotify_SpawnResult::AudioComponents");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, CameraShakes) == 0x20, "Offset mismatch for FGameplayCueNotify_SpawnResult::CameraShakes");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, CameraLensEffects) == 0x30, "Offset mismatch for FGameplayCueNotify_SpawnResult::CameraLensEffects");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, ForceFeedbackComponent) == 0x40, "Offset mismatch for FGameplayCueNotify_SpawnResult::ForceFeedbackComponent");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, ForceFeedbackTargetPC) == 0x48, "Offset mismatch for FGameplayCueNotify_SpawnResult::ForceFeedbackTargetPC");
static_assert(offsetof(FGameplayCueNotify_SpawnResult, DecalComponent) == 0x50, "Offset mismatch for FGameplayCueNotify_SpawnResult::DecalComponent");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FGameplayCueNotify_ParticleInfo
{
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride; // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride; // 0x38 (Size: 0x40, Type: StructProperty)
    UNiagaraSystem* NiagaraSystem; // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t bOverrideSpawnCondition : 1; // 0x80:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverridePlacementInfo : 1; // 0x80:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bCastShadow : 1; // 0x80:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueNotify_ParticleInfo) == 0x88, "Size mismatch for FGameplayCueNotify_ParticleInfo");
static_assert(offsetof(FGameplayCueNotify_ParticleInfo, SpawnConditionOverride) == 0x0, "Offset mismatch for FGameplayCueNotify_ParticleInfo::SpawnConditionOverride");
static_assert(offsetof(FGameplayCueNotify_ParticleInfo, PlacementInfoOverride) == 0x38, "Offset mismatch for FGameplayCueNotify_ParticleInfo::PlacementInfoOverride");
static_assert(offsetof(FGameplayCueNotify_ParticleInfo, NiagaraSystem) == 0x78, "Offset mismatch for FGameplayCueNotify_ParticleInfo::NiagaraSystem");
static_assert(offsetof(FGameplayCueNotify_ParticleInfo, bOverrideSpawnCondition) == 0x80, "Offset mismatch for FGameplayCueNotify_ParticleInfo::bOverrideSpawnCondition");
static_assert(offsetof(FGameplayCueNotify_ParticleInfo, bOverridePlacementInfo) == 0x80, "Offset mismatch for FGameplayCueNotify_ParticleInfo::bOverridePlacementInfo");
static_assert(offsetof(FGameplayCueNotify_ParticleInfo, bCastShadow) == 0x80, "Offset mismatch for FGameplayCueNotify_ParticleInfo::bCastShadow");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGameplayCueNotify_SoundParameterInterfaceInfo
{
    FName StopTriggerName; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FGameplayCueNotify_SoundParameterInterfaceInfo) == 0x4, "Size mismatch for FGameplayCueNotify_SoundParameterInterfaceInfo");
static_assert(offsetof(FGameplayCueNotify_SoundParameterInterfaceInfo, StopTriggerName) == 0x0, "Offset mismatch for FGameplayCueNotify_SoundParameterInterfaceInfo::StopTriggerName");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FGameplayCueNotify_SoundInfo
{
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride; // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride; // 0x38 (Size: 0x40, Type: StructProperty)
    USoundBase* Sound; // 0x78 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundCue; // 0x80 (Size: 0x8, Type: ObjectProperty)
    float LoopingFadeOutDuration; // 0x88 (Size: 0x4, Type: FloatProperty)
    float LoopingFadeVolumeLevel; // 0x8c (Size: 0x4, Type: FloatProperty)
    FGameplayCueNotify_SoundParameterInterfaceInfo SoundParameterInterfaceInfo; // 0x90 (Size: 0x4, Type: StructProperty)
    uint8_t bOverrideSpawnCondition : 1; // 0x94:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverridePlacementInfo : 1; // 0x94:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseSoundParameterInterface : 1; // 0x94:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_95[0x3]; // 0x95 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueNotify_SoundInfo) == 0x98, "Size mismatch for FGameplayCueNotify_SoundInfo");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, SpawnConditionOverride) == 0x0, "Offset mismatch for FGameplayCueNotify_SoundInfo::SpawnConditionOverride");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, PlacementInfoOverride) == 0x38, "Offset mismatch for FGameplayCueNotify_SoundInfo::PlacementInfoOverride");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, Sound) == 0x78, "Offset mismatch for FGameplayCueNotify_SoundInfo::Sound");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, SoundCue) == 0x80, "Offset mismatch for FGameplayCueNotify_SoundInfo::SoundCue");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, LoopingFadeOutDuration) == 0x88, "Offset mismatch for FGameplayCueNotify_SoundInfo::LoopingFadeOutDuration");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, LoopingFadeVolumeLevel) == 0x8c, "Offset mismatch for FGameplayCueNotify_SoundInfo::LoopingFadeVolumeLevel");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, SoundParameterInterfaceInfo) == 0x90, "Offset mismatch for FGameplayCueNotify_SoundInfo::SoundParameterInterfaceInfo");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, bOverrideSpawnCondition) == 0x94, "Offset mismatch for FGameplayCueNotify_SoundInfo::bOverrideSpawnCondition");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, bOverridePlacementInfo) == 0x94, "Offset mismatch for FGameplayCueNotify_SoundInfo::bOverridePlacementInfo");
static_assert(offsetof(FGameplayCueNotify_SoundInfo, bUseSoundParameterInterface) == 0x94, "Offset mismatch for FGameplayCueNotify_SoundInfo::bUseSoundParameterInterface");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FGameplayCueNotify_CameraShakeInfo
{
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride; // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride; // 0x38 (Size: 0x40, Type: StructProperty)
    UClass* CameraShake; // 0x78 (Size: 0x8, Type: ClassProperty)
    float ShakeScale; // 0x80 (Size: 0x4, Type: FloatProperty)
    uint8_t Playspace; // 0x84 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    uint8_t bOverrideSpawnCondition : 1; // 0x88:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverridePlacementInfo : 1; // 0x88:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bPlayInWorld : 1; // 0x88:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x3]; // 0x89 (Size: 0x3, Type: PaddingProperty)
    float WorldInnerRadius; // 0x8c (Size: 0x4, Type: FloatProperty)
    float WorldOuterRadius; // 0x90 (Size: 0x4, Type: FloatProperty)
    float WorldFalloffExponent; // 0x94 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGameplayCueNotify_CameraShakeInfo) == 0x98, "Size mismatch for FGameplayCueNotify_CameraShakeInfo");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, SpawnConditionOverride) == 0x0, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::SpawnConditionOverride");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, PlacementInfoOverride) == 0x38, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::PlacementInfoOverride");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, CameraShake) == 0x78, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::CameraShake");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, ShakeScale) == 0x80, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::ShakeScale");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, Playspace) == 0x84, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::Playspace");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, bOverrideSpawnCondition) == 0x88, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::bOverrideSpawnCondition");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, bOverridePlacementInfo) == 0x88, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::bOverridePlacementInfo");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, bPlayInWorld) == 0x88, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::bPlayInWorld");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, WorldInnerRadius) == 0x8c, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::WorldInnerRadius");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, WorldOuterRadius) == 0x90, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::WorldOuterRadius");
static_assert(offsetof(FGameplayCueNotify_CameraShakeInfo, WorldFalloffExponent) == 0x94, "Offset mismatch for FGameplayCueNotify_CameraShakeInfo::WorldFalloffExponent");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FGameplayCueNotify_CameraLensEffectInfo
{
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride; // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride; // 0x38 (Size: 0x40, Type: StructProperty)
    UClass* CameraLensEffect; // 0x78 (Size: 0x8, Type: ClassProperty)
    uint8_t bOverrideSpawnCondition : 1; // 0x80:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverridePlacementInfo : 1; // 0x80:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bPlayInWorld : 1; // 0x80:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    float WorldInnerRadius; // 0x84 (Size: 0x4, Type: FloatProperty)
    float WorldOuterRadius; // 0x88 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueNotify_CameraLensEffectInfo) == 0x90, "Size mismatch for FGameplayCueNotify_CameraLensEffectInfo");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, SpawnConditionOverride) == 0x0, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::SpawnConditionOverride");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, PlacementInfoOverride) == 0x38, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::PlacementInfoOverride");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, CameraLensEffect) == 0x78, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::CameraLensEffect");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, bOverrideSpawnCondition) == 0x80, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::bOverrideSpawnCondition");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, bOverridePlacementInfo) == 0x80, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::bOverridePlacementInfo");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, bPlayInWorld) == 0x80, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::bPlayInWorld");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, WorldInnerRadius) == 0x84, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::WorldInnerRadius");
static_assert(offsetof(FGameplayCueNotify_CameraLensEffectInfo, WorldOuterRadius) == 0x88, "Offset mismatch for FGameplayCueNotify_CameraLensEffectInfo::WorldOuterRadius");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FGameplayCueNotify_ForceFeedbackInfo
{
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride; // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride; // 0x38 (Size: 0x40, Type: StructProperty)
    UForceFeedbackEffect* ForceFeedbackEffect; // 0x78 (Size: 0x8, Type: ObjectProperty)
    FName ForceFeedbackTag; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t bIsLooping : 1; // 0x84:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideSpawnCondition : 1; // 0x84:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverridePlacementInfo : 1; // 0x84:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bPlayInWorld : 1; // 0x84:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    float WorldIntensity; // 0x88 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    UForceFeedbackAttenuation* WorldAttenuation; // 0x90 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayCueNotify_ForceFeedbackInfo) == 0x98, "Size mismatch for FGameplayCueNotify_ForceFeedbackInfo");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, SpawnConditionOverride) == 0x0, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::SpawnConditionOverride");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, PlacementInfoOverride) == 0x38, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::PlacementInfoOverride");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, ForceFeedbackEffect) == 0x78, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::ForceFeedbackEffect");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, ForceFeedbackTag) == 0x80, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::ForceFeedbackTag");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, bIsLooping) == 0x84, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::bIsLooping");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, bOverrideSpawnCondition) == 0x84, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::bOverrideSpawnCondition");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, bOverridePlacementInfo) == 0x84, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::bOverridePlacementInfo");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, bPlayInWorld) == 0x84, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::bPlayInWorld");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, WorldIntensity) == 0x88, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::WorldIntensity");
static_assert(offsetof(FGameplayCueNotify_ForceFeedbackInfo, WorldAttenuation) == 0x90, "Offset mismatch for FGameplayCueNotify_ForceFeedbackInfo::WorldAttenuation");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayCueNotify_InputDevicePropertyInfo
{
    TArray<UClass*> DeviceProperties; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayCueNotify_InputDevicePropertyInfo) == 0x10, "Size mismatch for FGameplayCueNotify_InputDevicePropertyInfo");
static_assert(offsetof(FGameplayCueNotify_InputDevicePropertyInfo, DeviceProperties) == 0x0, "Offset mismatch for FGameplayCueNotify_InputDevicePropertyInfo::DeviceProperties");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FGameplayCueNotify_DecalInfo
{
    FGameplayCueNotify_SpawnCondition SpawnConditionOverride; // 0x0 (Size: 0x38, Type: StructProperty)
    FGameplayCueNotify_PlacementInfo PlacementInfoOverride; // 0x38 (Size: 0x40, Type: StructProperty)
    UMaterialInterface* DecalMaterial; // 0x78 (Size: 0x8, Type: ObjectProperty)
    FVector DecalSize; // 0x80 (Size: 0x18, Type: StructProperty)
    uint8_t bOverrideSpawnCondition : 1; // 0x98:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverridePlacementInfo : 1; // 0x98:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideFadeOut : 1; // 0x98:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float FadeOutStartDelay; // 0x9c (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueNotify_DecalInfo) == 0xa8, "Size mismatch for FGameplayCueNotify_DecalInfo");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, SpawnConditionOverride) == 0x0, "Offset mismatch for FGameplayCueNotify_DecalInfo::SpawnConditionOverride");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, PlacementInfoOverride) == 0x38, "Offset mismatch for FGameplayCueNotify_DecalInfo::PlacementInfoOverride");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, DecalMaterial) == 0x78, "Offset mismatch for FGameplayCueNotify_DecalInfo::DecalMaterial");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, DecalSize) == 0x80, "Offset mismatch for FGameplayCueNotify_DecalInfo::DecalSize");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, bOverrideSpawnCondition) == 0x98, "Offset mismatch for FGameplayCueNotify_DecalInfo::bOverrideSpawnCondition");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, bOverridePlacementInfo) == 0x98, "Offset mismatch for FGameplayCueNotify_DecalInfo::bOverridePlacementInfo");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, bOverrideFadeOut) == 0x98, "Offset mismatch for FGameplayCueNotify_DecalInfo::bOverrideFadeOut");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, FadeOutStartDelay) == 0x9c, "Offset mismatch for FGameplayCueNotify_DecalInfo::FadeOutStartDelay");
static_assert(offsetof(FGameplayCueNotify_DecalInfo, FadeOutDuration) == 0xa0, "Offset mismatch for FGameplayCueNotify_DecalInfo::FadeOutDuration");

// Size: 0x298 (Inherited: 0x0, Single: 0x298)
struct FGameplayCueNotify_BurstEffects
{
    TArray<FGameplayCueNotify_ParticleInfo> BurstParticles; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayCueNotify_SoundInfo> BurstSounds; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FGameplayCueNotify_CameraShakeInfo BurstCameraShake; // 0x20 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_CameraLensEffectInfo BurstCameraLensEffect; // 0xb8 (Size: 0x90, Type: StructProperty)
    FGameplayCueNotify_ForceFeedbackInfo BurstForceFeedback; // 0x148 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_InputDevicePropertyInfo BurstDevicePropertyEffect; // 0x1e0 (Size: 0x10, Type: StructProperty)
    FGameplayCueNotify_DecalInfo BurstDecal; // 0x1f0 (Size: 0xa8, Type: StructProperty)
};

static_assert(sizeof(FGameplayCueNotify_BurstEffects) == 0x298, "Size mismatch for FGameplayCueNotify_BurstEffects");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstParticles) == 0x0, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstParticles");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstSounds) == 0x10, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstSounds");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstCameraShake) == 0x20, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstCameraShake");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstCameraLensEffect) == 0xb8, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstCameraLensEffect");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstForceFeedback) == 0x148, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstForceFeedback");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstDevicePropertyEffect) == 0x1e0, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstDevicePropertyEffect");
static_assert(offsetof(FGameplayCueNotify_BurstEffects, BurstDecal) == 0x1f0, "Offset mismatch for FGameplayCueNotify_BurstEffects::BurstDecal");

// Size: 0x1f0 (Inherited: 0x0, Single: 0x1f0)
struct FGameplayCueNotify_LoopingEffects
{
    TArray<FGameplayCueNotify_ParticleInfo> LoopingParticles; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayCueNotify_SoundInfo> LoopingSounds; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FGameplayCueNotify_CameraShakeInfo LoopingCameraShake; // 0x20 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_CameraLensEffectInfo LoopingCameraLensEffect; // 0xb8 (Size: 0x90, Type: StructProperty)
    FGameplayCueNotify_ForceFeedbackInfo LoopingForceFeedback; // 0x148 (Size: 0x98, Type: StructProperty)
    FGameplayCueNotify_InputDevicePropertyInfo LoopingInputDevicePropertyEffect; // 0x1e0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGameplayCueNotify_LoopingEffects) == 0x1f0, "Size mismatch for FGameplayCueNotify_LoopingEffects");
static_assert(offsetof(FGameplayCueNotify_LoopingEffects, LoopingParticles) == 0x0, "Offset mismatch for FGameplayCueNotify_LoopingEffects::LoopingParticles");
static_assert(offsetof(FGameplayCueNotify_LoopingEffects, LoopingSounds) == 0x10, "Offset mismatch for FGameplayCueNotify_LoopingEffects::LoopingSounds");
static_assert(offsetof(FGameplayCueNotify_LoopingEffects, LoopingCameraShake) == 0x20, "Offset mismatch for FGameplayCueNotify_LoopingEffects::LoopingCameraShake");
static_assert(offsetof(FGameplayCueNotify_LoopingEffects, LoopingCameraLensEffect) == 0xb8, "Offset mismatch for FGameplayCueNotify_LoopingEffects::LoopingCameraLensEffect");
static_assert(offsetof(FGameplayCueNotify_LoopingEffects, LoopingForceFeedback) == 0x148, "Offset mismatch for FGameplayCueNotify_LoopingEffects::LoopingForceFeedback");
static_assert(offsetof(FGameplayCueNotify_LoopingEffects, LoopingInputDevicePropertyEffect) == 0x1e0, "Offset mismatch for FGameplayCueNotify_LoopingEffects::LoopingInputDevicePropertyEffect");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGameplayCueNotifyData
{
    FGameplayTag GameplayCueTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FSoftObjectPath GameplayCueNotifyObj; // 0x8 (Size: 0x18, Type: StructProperty)
    UClass* LoadedGameplayCueClass; // 0x20 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueNotifyData) == 0x30, "Size mismatch for FGameplayCueNotifyData");
static_assert(offsetof(FGameplayCueNotifyData, GameplayCueTag) == 0x0, "Offset mismatch for FGameplayCueNotifyData::GameplayCueTag");
static_assert(offsetof(FGameplayCueNotifyData, GameplayCueNotifyObj) == 0x8, "Offset mismatch for FGameplayCueNotifyData::GameplayCueNotifyObj");
static_assert(offsetof(FGameplayCueNotifyData, LoadedGameplayCueClass) == 0x20, "Offset mismatch for FGameplayCueNotifyData::LoadedGameplayCueClass");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGameplayCueTranslatorNodeIndex
{
    int32_t Index; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGameplayCueTranslatorNodeIndex) == 0x4, "Size mismatch for FGameplayCueTranslatorNodeIndex");
static_assert(offsetof(FGameplayCueTranslatorNodeIndex, Index) == 0x0, "Offset mismatch for FGameplayCueTranslatorNodeIndex::Index");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayCueTranslationLink
{
    UGameplayCueTranslator* RulesCDO; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x10]; // 0x8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueTranslationLink) == 0x18, "Size mismatch for FGameplayCueTranslationLink");
static_assert(offsetof(FGameplayCueTranslationLink, RulesCDO) == 0x0, "Offset mismatch for FGameplayCueTranslationLink::RulesCDO");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FGameplayCueTranslatorNode
{
    TArray<FGameplayCueTranslationLink> Links; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FGameplayCueTranslatorNodeIndex CachedIndex; // 0x10 (Size: 0x4, Type: StructProperty)
    FGameplayTag CachedGameplayTag; // 0x14 (Size: 0x4, Type: StructProperty)
    FName CachedGameplayTagName; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x54]; // 0x1c (Size: 0x54, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueTranslatorNode) == 0x70, "Size mismatch for FGameplayCueTranslatorNode");
static_assert(offsetof(FGameplayCueTranslatorNode, Links) == 0x0, "Offset mismatch for FGameplayCueTranslatorNode::Links");
static_assert(offsetof(FGameplayCueTranslatorNode, CachedIndex) == 0x10, "Offset mismatch for FGameplayCueTranslatorNode::CachedIndex");
static_assert(offsetof(FGameplayCueTranslatorNode, CachedGameplayTag) == 0x14, "Offset mismatch for FGameplayCueTranslatorNode::CachedGameplayTag");
static_assert(offsetof(FGameplayCueTranslatorNode, CachedGameplayTagName) == 0x18, "Offset mismatch for FGameplayCueTranslatorNode::CachedGameplayTagName");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FGameplayCueTranslationManager
{
    TArray<FGameplayCueTranslatorNode> TranslationLUT; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<FGameplayCueTranslatorNodeIndex, FName> TranslationNameToIndexMap; // 0x10 (Size: 0x50, Type: MapProperty)
    UGameplayTagsManager* TagManager; // 0x60 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_68[0x18]; // 0x68 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCueTranslationManager) == 0x80, "Size mismatch for FGameplayCueTranslationManager");
static_assert(offsetof(FGameplayCueTranslationManager, TranslationLUT) == 0x0, "Offset mismatch for FGameplayCueTranslationManager::TranslationLUT");
static_assert(offsetof(FGameplayCueTranslationManager, TranslationNameToIndexMap) == 0x10, "Offset mismatch for FGameplayCueTranslationManager::TranslationNameToIndexMap");
static_assert(offsetof(FGameplayCueTranslationManager, TagManager) == 0x60, "Offset mismatch for FGameplayCueTranslationManager::TagManager");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FConditionalGameplayEffect
{
    UClass* EffectClass; // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer RequiredSourceTags; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FConditionalGameplayEffect) == 0x28, "Size mismatch for FConditionalGameplayEffect");
static_assert(offsetof(FConditionalGameplayEffect, EffectClass) == 0x0, "Offset mismatch for FConditionalGameplayEffect::EffectClass");
static_assert(offsetof(FConditionalGameplayEffect, RequiredSourceTags) == 0x8, "Offset mismatch for FConditionalGameplayEffect::RequiredSourceTags");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameplayEffectExecutionDefinition
{
    UClass* CalculationClass; // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer PassedInTags; // 0x8 (Size: 0x20, Type: StructProperty)
    TArray<FGameplayEffectExecutionScopedModifierInfo> CalculationModifiers; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FConditionalGameplayEffect> ConditionalGameplayEffects; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayEffectExecutionDefinition) == 0x48, "Size mismatch for FGameplayEffectExecutionDefinition");
static_assert(offsetof(FGameplayEffectExecutionDefinition, CalculationClass) == 0x0, "Offset mismatch for FGameplayEffectExecutionDefinition::CalculationClass");
static_assert(offsetof(FGameplayEffectExecutionDefinition, PassedInTags) == 0x8, "Offset mismatch for FGameplayEffectExecutionDefinition::PassedInTags");
static_assert(offsetof(FGameplayEffectExecutionDefinition, CalculationModifiers) == 0x28, "Offset mismatch for FGameplayEffectExecutionDefinition::CalculationModifiers");
static_assert(offsetof(FGameplayEffectExecutionDefinition, ConditionalGameplayEffects) == 0x38, "Offset mismatch for FGameplayEffectExecutionDefinition::ConditionalGameplayEffects");

// Size: 0x330 (Inherited: 0x0, Single: 0x330)
struct FGameplayModifierInfo
{
    FGameplayAttribute Attribute; // 0x0 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EGameplayModOp> ModifierOp; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    FGameplayEffectModifierMagnitude ModifierMagnitude; // 0x40 (Size: 0x1d8, Type: StructProperty)
    FGameplayModEvaluationChannelSettings EvaluationChannelSettings; // 0x218 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_219[0x7]; // 0x219 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagRequirements SourceTags; // 0x220 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements TargetTags; // 0x2a8 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(FGameplayModifierInfo) == 0x330, "Size mismatch for FGameplayModifierInfo");
static_assert(offsetof(FGameplayModifierInfo, Attribute) == 0x0, "Offset mismatch for FGameplayModifierInfo::Attribute");
static_assert(offsetof(FGameplayModifierInfo, ModifierOp) == 0x38, "Offset mismatch for FGameplayModifierInfo::ModifierOp");
static_assert(offsetof(FGameplayModifierInfo, ModifierMagnitude) == 0x40, "Offset mismatch for FGameplayModifierInfo::ModifierMagnitude");
static_assert(offsetof(FGameplayModifierInfo, EvaluationChannelSettings) == 0x218, "Offset mismatch for FGameplayModifierInfo::EvaluationChannelSettings");
static_assert(offsetof(FGameplayModifierInfo, SourceTags) == 0x220, "Offset mismatch for FGameplayModifierInfo::SourceTags");
static_assert(offsetof(FGameplayModifierInfo, TargetTags) == 0x2a8, "Offset mismatch for FGameplayModifierInfo::TargetTags");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FGameplayEffectCue
{
    FGameplayAttribute MagnitudeAttribute; // 0x0 (Size: 0x38, Type: StructProperty)
    float MinLevel; // 0x38 (Size: 0x4, Type: FloatProperty)
    float MaxLevel; // 0x3c (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer GameplayCueTags; // 0x40 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FGameplayEffectCue) == 0x60, "Size mismatch for FGameplayEffectCue");
static_assert(offsetof(FGameplayEffectCue, MagnitudeAttribute) == 0x0, "Offset mismatch for FGameplayEffectCue::MagnitudeAttribute");
static_assert(offsetof(FGameplayEffectCue, MinLevel) == 0x38, "Offset mismatch for FGameplayEffectCue::MinLevel");
static_assert(offsetof(FGameplayEffectCue, MaxLevel) == 0x3c, "Offset mismatch for FGameplayEffectCue::MaxLevel");
static_assert(offsetof(FGameplayEffectCue, GameplayCueTags) == 0x40, "Offset mismatch for FGameplayEffectCue::GameplayCueTags");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FInheritedTagContainer
{
    FGameplayTagContainer CombinedTags; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Added; // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Removed; // 0x40 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FInheritedTagContainer) == 0x60, "Size mismatch for FInheritedTagContainer");
static_assert(offsetof(FInheritedTagContainer, CombinedTags) == 0x0, "Offset mismatch for FInheritedTagContainer::CombinedTags");
static_assert(offsetof(FInheritedTagContainer, Added) == 0x20, "Offset mismatch for FInheritedTagContainer::Added");
static_assert(offsetof(FInheritedTagContainer, Removed) == 0x40, "Offset mismatch for FInheritedTagContainer::Removed");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FActiveGameplayEffectQuery
{
};

static_assert(sizeof(FActiveGameplayEffectQuery) == 0x88, "Size mismatch for FActiveGameplayEffectQuery");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGameplayEffectVersion
{
};

static_assert(sizeof(FGameplayEffectVersion) == 0x1, "Size mismatch for FGameplayEffectVersion");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FGameplayEffectCustomExecutionParameters
{
};

static_assert(sizeof(FGameplayEffectCustomExecutionParameters) == 0xf0, "Size mismatch for FGameplayEffectCustomExecutionParameters");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayEffectCustomExecutionOutput
{
    TArray<FGameplayModifierEvaluatedData> OutputModifiers; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t bTriggerConditionalGameplayEffects : 1; // 0x10:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bHandledStackCountManually : 1; // 0x10:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bHandledGameplayCuesManually : 1; // 0x10:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectCustomExecutionOutput) == 0x18, "Size mismatch for FGameplayEffectCustomExecutionOutput");
static_assert(offsetof(FGameplayEffectCustomExecutionOutput, OutputModifiers) == 0x0, "Offset mismatch for FGameplayEffectCustomExecutionOutput::OutputModifiers");
static_assert(offsetof(FGameplayEffectCustomExecutionOutput, bTriggerConditionalGameplayEffects) == 0x10, "Offset mismatch for FGameplayEffectCustomExecutionOutput::bTriggerConditionalGameplayEffects");
static_assert(offsetof(FGameplayEffectCustomExecutionOutput, bHandledStackCountManually) == 0x10, "Offset mismatch for FGameplayEffectCustomExecutionOutput::bHandledStackCountManually");
static_assert(offsetof(FGameplayEffectCustomExecutionOutput, bHandledGameplayCuesManually) == 0x10, "Offset mismatch for FGameplayEffectCustomExecutionOutput::bHandledGameplayCuesManually");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FGameplayEffectContext
{
    TWeakObjectPtr<AActor*> Instigator; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> EffectCauser; // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UGameplayAbility*> AbilityCDO; // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UGameplayAbility*> AbilityInstanceNotReplicated; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    int32_t AbilityLevel; // 0x28 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UObject*> SourceObject; // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> InstigatorAbilitySystemComponent; // 0x34 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    TArray<TWeakObjectPtr<AActor*>> Actors; // 0x40 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_50[0x10]; // 0x50 (Size: 0x10, Type: PaddingProperty)
    FVector WorldOrigin; // 0x60 (Size: 0x18, Type: StructProperty)
    uint8_t bHasWorldOrigin : 1; // 0x78:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bReplicateSourceObject : 1; // 0x78:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bReplicateInstigator : 1; // 0x78:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bReplicateEffectCauser : 1; // 0x78:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEffectContext) == 0x80, "Size mismatch for FGameplayEffectContext");
static_assert(offsetof(FGameplayEffectContext, Instigator) == 0x8, "Offset mismatch for FGameplayEffectContext::Instigator");
static_assert(offsetof(FGameplayEffectContext, EffectCauser) == 0x10, "Offset mismatch for FGameplayEffectContext::EffectCauser");
static_assert(offsetof(FGameplayEffectContext, AbilityCDO) == 0x18, "Offset mismatch for FGameplayEffectContext::AbilityCDO");
static_assert(offsetof(FGameplayEffectContext, AbilityInstanceNotReplicated) == 0x20, "Offset mismatch for FGameplayEffectContext::AbilityInstanceNotReplicated");
static_assert(offsetof(FGameplayEffectContext, AbilityLevel) == 0x28, "Offset mismatch for FGameplayEffectContext::AbilityLevel");
static_assert(offsetof(FGameplayEffectContext, SourceObject) == 0x2c, "Offset mismatch for FGameplayEffectContext::SourceObject");
static_assert(offsetof(FGameplayEffectContext, InstigatorAbilitySystemComponent) == 0x34, "Offset mismatch for FGameplayEffectContext::InstigatorAbilitySystemComponent");
static_assert(offsetof(FGameplayEffectContext, Actors) == 0x40, "Offset mismatch for FGameplayEffectContext::Actors");
static_assert(offsetof(FGameplayEffectContext, WorldOrigin) == 0x60, "Offset mismatch for FGameplayEffectContext::WorldOrigin");
static_assert(offsetof(FGameplayEffectContext, bHasWorldOrigin) == 0x78, "Offset mismatch for FGameplayEffectContext::bHasWorldOrigin");
static_assert(offsetof(FGameplayEffectContext, bReplicateSourceObject) == 0x78, "Offset mismatch for FGameplayEffectContext::bReplicateSourceObject");
static_assert(offsetof(FGameplayEffectContext, bReplicateInstigator) == 0x78, "Offset mismatch for FGameplayEffectContext::bReplicateInstigator");
static_assert(offsetof(FGameplayEffectContext, bReplicateEffectCauser) == 0x78, "Offset mismatch for FGameplayEffectContext::bReplicateEffectCauser");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameplayTagBlueprintPropertyMapping
{
    FGameplayTag TagToMap; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    uint8_t PropertyToEdit[0x20]; // 0x8 (Size: 0x20, Type: FieldPathProperty)
    FName PropertyName; // 0x28 (Size: 0x4, Type: NameProperty)
    FGuid PropertyGuid; // 0x2c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_3c[0xc]; // 0x3c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayTagBlueprintPropertyMapping) == 0x48, "Size mismatch for FGameplayTagBlueprintPropertyMapping");
static_assert(offsetof(FGameplayTagBlueprintPropertyMapping, TagToMap) == 0x0, "Offset mismatch for FGameplayTagBlueprintPropertyMapping::TagToMap");
static_assert(offsetof(FGameplayTagBlueprintPropertyMapping, PropertyToEdit) == 0x8, "Offset mismatch for FGameplayTagBlueprintPropertyMapping::PropertyToEdit");
static_assert(offsetof(FGameplayTagBlueprintPropertyMapping, PropertyName) == 0x28, "Offset mismatch for FGameplayTagBlueprintPropertyMapping::PropertyName");
static_assert(offsetof(FGameplayTagBlueprintPropertyMapping, PropertyGuid) == 0x2c, "Offset mismatch for FGameplayTagBlueprintPropertyMapping::PropertyGuid");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayTagBlueprintPropertyMap
{
    TArray<FGameplayTagBlueprintPropertyMapping> PropertyMappings; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayTagBlueprintPropertyMap) == 0x20, "Size mismatch for FGameplayTagBlueprintPropertyMap");
static_assert(offsetof(FGameplayTagBlueprintPropertyMap, PropertyMappings) == 0x10, "Offset mismatch for FGameplayTagBlueprintPropertyMap::PropertyMappings");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayTagReponsePair
{
    FGameplayTag Tag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UClass* ResponseGameplayEffect; // 0x8 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> ResponseGameplayEffects; // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t SoftCountCap; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayTagReponsePair) == 0x28, "Size mismatch for FGameplayTagReponsePair");
static_assert(offsetof(FGameplayTagReponsePair, Tag) == 0x0, "Offset mismatch for FGameplayTagReponsePair::Tag");
static_assert(offsetof(FGameplayTagReponsePair, ResponseGameplayEffect) == 0x8, "Offset mismatch for FGameplayTagReponsePair::ResponseGameplayEffect");
static_assert(offsetof(FGameplayTagReponsePair, ResponseGameplayEffects) == 0x10, "Offset mismatch for FGameplayTagReponsePair::ResponseGameplayEffects");
static_assert(offsetof(FGameplayTagReponsePair, SoftCountCap) == 0x20, "Offset mismatch for FGameplayTagReponsePair::SoftCountCap");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGameplayTagResponseTableEntry
{
    FGameplayTagReponsePair Positive; // 0x0 (Size: 0x28, Type: StructProperty)
    FGameplayTagReponsePair Negative; // 0x28 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FGameplayTagResponseTableEntry) == 0x50, "Size mismatch for FGameplayTagResponseTableEntry");
static_assert(offsetof(FGameplayTagResponseTableEntry, Positive) == 0x0, "Offset mismatch for FGameplayTagResponseTableEntry::Positive");
static_assert(offsetof(FGameplayTagResponseTableEntry, Negative) == 0x28, "Offset mismatch for FGameplayTagResponseTableEntry::Negative");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FMovieSceneGameplayCueKey
{
    FGameplayCueTag Cue; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x20 (Size: 0x18, Type: StructProperty)
    FName AttachSocketName; // 0x38 (Size: 0x4, Type: NameProperty)
    float NormalizedMagnitude; // 0x3c (Size: 0x4, Type: FloatProperty)
    FMovieSceneObjectBindingID Instigator; // 0x40 (Size: 0x18, Type: StructProperty)
    FMovieSceneObjectBindingID EffectCauser; // 0x58 (Size: 0x18, Type: StructProperty)
    UPhysicalMaterial* PhysicalMaterial; // 0x70 (Size: 0x8, Type: ObjectProperty)
    int32_t GameplayEffectLevel; // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t AbilityLevel; // 0x7c (Size: 0x4, Type: IntProperty)
    bool bAttachToBinding; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FMovieSceneGameplayCueKey) == 0x88, "Size mismatch for FMovieSceneGameplayCueKey");
static_assert(offsetof(FMovieSceneGameplayCueKey, Cue) == 0x0, "Offset mismatch for FMovieSceneGameplayCueKey::Cue");
static_assert(offsetof(FMovieSceneGameplayCueKey, Location) == 0x8, "Offset mismatch for FMovieSceneGameplayCueKey::Location");
static_assert(offsetof(FMovieSceneGameplayCueKey, Normal) == 0x20, "Offset mismatch for FMovieSceneGameplayCueKey::Normal");
static_assert(offsetof(FMovieSceneGameplayCueKey, AttachSocketName) == 0x38, "Offset mismatch for FMovieSceneGameplayCueKey::AttachSocketName");
static_assert(offsetof(FMovieSceneGameplayCueKey, NormalizedMagnitude) == 0x3c, "Offset mismatch for FMovieSceneGameplayCueKey::NormalizedMagnitude");
static_assert(offsetof(FMovieSceneGameplayCueKey, Instigator) == 0x40, "Offset mismatch for FMovieSceneGameplayCueKey::Instigator");
static_assert(offsetof(FMovieSceneGameplayCueKey, EffectCauser) == 0x58, "Offset mismatch for FMovieSceneGameplayCueKey::EffectCauser");
static_assert(offsetof(FMovieSceneGameplayCueKey, PhysicalMaterial) == 0x70, "Offset mismatch for FMovieSceneGameplayCueKey::PhysicalMaterial");
static_assert(offsetof(FMovieSceneGameplayCueKey, GameplayEffectLevel) == 0x78, "Offset mismatch for FMovieSceneGameplayCueKey::GameplayEffectLevel");
static_assert(offsetof(FMovieSceneGameplayCueKey, AbilityLevel) == 0x7c, "Offset mismatch for FMovieSceneGameplayCueKey::AbilityLevel");
static_assert(offsetof(FMovieSceneGameplayCueKey, bAttachToBinding) == 0x80, "Offset mismatch for FMovieSceneGameplayCueKey::bAttachToBinding");

// Size: 0xf8 (Inherited: 0x50, Single: 0xa8)
struct FMovieSceneGameplayCueChannel : FMovieSceneChannel
{
    TArray<FFrameNumber> KeyTimes; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FMovieSceneGameplayCueKey> KeyValues; // 0x60 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_70[0x88]; // 0x70 (Size: 0x88, Type: PaddingProperty)
};

static_assert(sizeof(FMovieSceneGameplayCueChannel) == 0xf8, "Size mismatch for FMovieSceneGameplayCueChannel");
static_assert(offsetof(FMovieSceneGameplayCueChannel, KeyTimes) == 0x50, "Offset mismatch for FMovieSceneGameplayCueChannel::KeyTimes");
static_assert(offsetof(FMovieSceneGameplayCueChannel, KeyValues) == 0x60, "Offset mismatch for FMovieSceneGameplayCueChannel::KeyValues");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FGameplayAbilityRepAnimMontageNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FGameplayAbilityRepAnimMontageNetSerializerConfig) == 0x10, "Size mismatch for FGameplayAbilityRepAnimMontageNetSerializerConfig");

// Size: 0x28 (Inherited: 0x38, Single: 0xfffffff0)
struct FGameplayEffectContextHandleNetSerializerConfig : FPolymorphicStructNetSerializerConfig
{
};

static_assert(sizeof(FGameplayEffectContextHandleNetSerializerConfig) == 0x28, "Size mismatch for FGameplayEffectContextHandleNetSerializerConfig");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FGameplayEffectContextNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FGameplayEffectContextNetSerializerConfig) == 0x10, "Size mismatch for FGameplayEffectContextNetSerializerConfig");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FMinimalGameplayCueReplicationProxyNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FMinimalGameplayCueReplicationProxyNetSerializerConfig) == 0x10, "Size mismatch for FMinimalGameplayCueReplicationProxyNetSerializerConfig");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FMinimalReplicationTagCountMapNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FMinimalReplicationTagCountMapNetSerializerConfig) == 0x10, "Size mismatch for FMinimalReplicationTagCountMapNetSerializerConfig");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FPredictionKeyNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FPredictionKeyNetSerializerConfig) == 0x10, "Size mismatch for FPredictionKeyNetSerializerConfig");

