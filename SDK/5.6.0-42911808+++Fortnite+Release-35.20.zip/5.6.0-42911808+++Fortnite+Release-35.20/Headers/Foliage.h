/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Foliage
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0xb70 (Inherited: 0x2890, Single: 0xffffe2e0)
class UFoliageInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
public:
    uint8_t OnInstanceTakePointDamage[0x10]; // 0xb38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInstanceTakeRadialDamage[0x10]; // 0xb48 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bEnableDiscardOnLoad; // 0xb58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b59[0x3]; // 0xb59 (Size: 0x3, Type: PaddingProperty)
    FGuid GenerationGuid; // 0xb5c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_b6c[0x4]; // 0xb6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFoliageInstancedStaticMeshComponent) == 0xb70, "Size mismatch for UFoliageInstancedStaticMeshComponent");
static_assert(offsetof(UFoliageInstancedStaticMeshComponent, OnInstanceTakePointDamage) == 0xb38, "Offset mismatch for UFoliageInstancedStaticMeshComponent::OnInstanceTakePointDamage");
static_assert(offsetof(UFoliageInstancedStaticMeshComponent, OnInstanceTakeRadialDamage) == 0xb48, "Offset mismatch for UFoliageInstancedStaticMeshComponent::OnInstanceTakeRadialDamage");
static_assert(offsetof(UFoliageInstancedStaticMeshComponent, bEnableDiscardOnLoad) == 0xb58, "Offset mismatch for UFoliageInstancedStaticMeshComponent::bEnableDiscardOnLoad");
static_assert(offsetof(UFoliageInstancedStaticMeshComponent, GenerationGuid) == 0xb5c, "Offset mismatch for UFoliageInstancedStaticMeshComponent::GenerationGuid");

// Size: 0x4a8 (Inherited: 0x28, Single: 0x480)
class UFoliageType : public UObject
{
public:
    FGuid UpdateGuid; // 0x28 (Size: 0x10, Type: StructProperty)
    float Density; // 0x38 (Size: 0x4, Type: FloatProperty)
    float DensityAdjustmentFactor; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Radius; // 0x40 (Size: 0x4, Type: FloatProperty)
    bool bSingleInstanceModeOverrideRadius; // 0x44 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x3]; // 0x45 (Size: 0x3, Type: PaddingProperty)
    float SingleInstanceModeRadius; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Scaling; // 0x4c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
    FFloatInterval ScaleX; // 0x50 (Size: 0x8, Type: StructProperty)
    FFloatInterval ScaleY; // 0x58 (Size: 0x8, Type: StructProperty)
    FFloatInterval ScaleZ; // 0x60 (Size: 0x8, Type: StructProperty)
    FFoliageVertexColorChannelMask VertexColorMaskByChannel[0x4]; // 0x68 (Size: 0x30, Type: StructProperty)
    TEnumAsByte<FoliageVertexColorMask> VertexColorMask; // 0x98 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float VertexColorMaskThreshold; // 0x9c (Size: 0x4, Type: FloatProperty)
    uint8_t VertexColorMaskInvert : 1; // 0xa0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x3]; // 0xa1 (Size: 0x3, Type: PaddingProperty)
    FFloatInterval ZOffset; // 0xa4 (Size: 0x8, Type: StructProperty)
    uint8_t AlignToNormal : 1; // 0xac:0 (Size: 0x1, Type: BoolProperty)
    uint8_t AverageNormal : 1; // 0xac:1 (Size: 0x1, Type: BoolProperty)
    uint8_t AverageNormalSingleComponent : 1; // 0xac:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ad[0x3]; // 0xad (Size: 0x3, Type: PaddingProperty)
    float AlignMaxAngle; // 0xb0 (Size: 0x4, Type: FloatProperty)
    uint8_t RandomYaw : 1; // 0xb4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b5[0x3]; // 0xb5 (Size: 0x3, Type: PaddingProperty)
    float RandomPitchAngle; // 0xb8 (Size: 0x4, Type: FloatProperty)
    FFloatInterval GroundSlopeAngle; // 0xbc (Size: 0x8, Type: StructProperty)
    FFloatInterval Height; // 0xc4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    TArray<FName> LandscapeLayers; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    float MinimumLayerWeight; // 0xe0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_e4[0x4]; // 0xe4 (Size: 0x4, Type: PaddingProperty)
    TArray<FName> ExclusionLandscapeLayers; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    float MinimumExclusionLayerWeight; // 0xf8 (Size: 0x4, Type: FloatProperty)
    FName LandscapeLayer; // 0xfc (Size: 0x4, Type: NameProperty)
    uint8_t CollisionWithWorld : 1; // 0x100:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
    FVector CollisionScale; // 0x108 (Size: 0x18, Type: StructProperty)
    int32_t AverageNormalSampleCount; // 0x120 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
    FBoxSphereBounds MeshBounds; // 0x128 (Size: 0x38, Type: StructProperty)
    FVector LowBoundOriginRadius; // 0x160 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EComponentMobility> Mobility; // 0x178 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_179[0x3]; // 0x179 (Size: 0x3, Type: PaddingProperty)
    FInt32Interval CullDistance; // 0x17c (Size: 0x8, Type: StructProperty)
    uint8_t bEnableStaticLighting : 1; // 0x184:0 (Size: 0x1, Type: BoolProperty)
    uint8_t CastShadow : 1; // 0x184:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectDynamicIndirectLighting : 1; // 0x184:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectDistanceFieldLighting : 1; // 0x184:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bCastDynamicShadow : 1; // 0x184:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bCastStaticShadow : 1; // 0x184:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_185[0x3]; // 0x185 (Size: 0x3, Type: PaddingProperty)
    uint8_t bCastContactShadow : 1; // 0x188:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_189[0x3]; // 0x189 (Size: 0x3, Type: PaddingProperty)
    uint8_t bCastShadowAsTwoSided : 1; // 0x18c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bReceivesDecals : 1; // 0x18c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideLightMapRes : 1; // 0x18c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_18d[0x3]; // 0x18d (Size: 0x3, Type: PaddingProperty)
    uint8_t ShadowCacheInvalidationBehavior; // 0x190 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_191[0x3]; // 0x191 (Size: 0x3, Type: PaddingProperty)
    int32_t OverriddenLightMapRes; // 0x194 (Size: 0x4, Type: IntProperty)
    uint8_t LightmapType; // 0x198 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_199[0x3]; // 0x199 (Size: 0x3, Type: PaddingProperty)
    uint8_t bUseAsOccluder : 1; // 0x19c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19d[0x3]; // 0x19d (Size: 0x3, Type: PaddingProperty)
    uint8_t bVisibleInRayTracing : 1; // 0x1a0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEvaluateWorldPositionOffset : 1; // 0x1a0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a1[0x3]; // 0x1a1 (Size: 0x3, Type: PaddingProperty)
    int32_t WorldPositionOffsetDisableDistance; // 0x1a4 (Size: 0x4, Type: IntProperty)
    FBodyInstance BodyInstance; // 0x1a8 (Size: 0x178, Type: StructProperty)
    TEnumAsByte<EHasCustomNavigableGeometry> CustomNavigableGeometry; // 0x320 (Size: 0x1, Type: ByteProperty)
    FLightingChannels LightingChannels; // 0x321 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_322[0x2]; // 0x322 (Size: 0x2, Type: PaddingProperty)
    uint8_t bRenderCustomDepth : 1; // 0x324:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_325[0x3]; // 0x325 (Size: 0x3, Type: PaddingProperty)
    uint8_t CustomDepthStencilWriteMask; // 0x328 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_329[0x3]; // 0x329 (Size: 0x3, Type: PaddingProperty)
    int32_t CustomDepthStencilValue; // 0x32c (Size: 0x4, Type: IntProperty)
    int32_t TranslucencySortPriority; // 0x330 (Size: 0x4, Type: IntProperty)
    float CollisionRadius; // 0x334 (Size: 0x4, Type: FloatProperty)
    float ShadeRadius; // 0x338 (Size: 0x4, Type: FloatProperty)
    int32_t NumSteps; // 0x33c (Size: 0x4, Type: IntProperty)
    float InitialSeedDensity; // 0x340 (Size: 0x4, Type: FloatProperty)
    float AverageSpreadDistance; // 0x344 (Size: 0x4, Type: FloatProperty)
    float SpreadVariance; // 0x348 (Size: 0x4, Type: FloatProperty)
    int32_t SeedsPerStep; // 0x34c (Size: 0x4, Type: IntProperty)
    int32_t DistributionSeed; // 0x350 (Size: 0x4, Type: IntProperty)
    float MaxInitialSeedOffset; // 0x354 (Size: 0x4, Type: FloatProperty)
    bool bCanGrowInShade; // 0x358 (Size: 0x1, Type: BoolProperty)
    bool bSpawnsInShade; // 0x359 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_35a[0x2]; // 0x35a (Size: 0x2, Type: PaddingProperty)
    float MaxInitialAge; // 0x35c (Size: 0x4, Type: FloatProperty)
    float MaxAge; // 0x360 (Size: 0x4, Type: FloatProperty)
    float OverlapPriority; // 0x364 (Size: 0x4, Type: FloatProperty)
    FFloatInterval ProceduralScale; // 0x368 (Size: 0x8, Type: StructProperty)
    FRuntimeFloatCurve ScaleCurve; // 0x370 (Size: 0x88, Type: StructProperty)
    FFoliageDensityFalloff DensityFalloff; // 0x3f8 (Size: 0x90, Type: StructProperty)
    int32_t ChangeCount; // 0x488 (Size: 0x4, Type: IntProperty)
    uint8_t ReapplyDensity : 1; // 0x48c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyRadius : 1; // 0x48c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyAlignToNormal : 1; // 0x48c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyRandomYaw : 1; // 0x48c:3 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyScaling : 1; // 0x48c:4 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyScaleX : 1; // 0x48c:5 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyScaleY : 1; // 0x48c:6 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyScaleZ : 1; // 0x48c:7 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyRandomPitchAngle : 1; // 0x48d:0 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyGroundSlope : 1; // 0x48d:1 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyHeight : 1; // 0x48d:2 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyLandscapeLayers : 1; // 0x48d:3 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyZOffset : 1; // 0x48d:4 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyCollisionWithWorld : 1; // 0x48d:5 (Size: 0x1, Type: BoolProperty)
    uint8_t ReapplyVertexColorMask : 1; // 0x48d:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableDensityScaling : 1; // 0x48d:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableDiscardOnLoad : 1; // 0x48e:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableCullDistanceScaling : 1; // 0x48e:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_48f[0x1]; // 0x48f (Size: 0x1, Type: PaddingProperty)
    TArray<URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x490 (Size: 0x10, Type: ArrayProperty)
    int32_t VirtualTextureCullMips; // 0x4a0 (Size: 0x4, Type: IntProperty)
    uint8_t VirtualTextureRenderPassType; // 0x4a4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_4a5[0x3]; // 0x4a5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFoliageType) == 0x4a8, "Size mismatch for UFoliageType");
static_assert(offsetof(UFoliageType, UpdateGuid) == 0x28, "Offset mismatch for UFoliageType::UpdateGuid");
static_assert(offsetof(UFoliageType, Density) == 0x38, "Offset mismatch for UFoliageType::Density");
static_assert(offsetof(UFoliageType, DensityAdjustmentFactor) == 0x3c, "Offset mismatch for UFoliageType::DensityAdjustmentFactor");
static_assert(offsetof(UFoliageType, Radius) == 0x40, "Offset mismatch for UFoliageType::Radius");
static_assert(offsetof(UFoliageType, bSingleInstanceModeOverrideRadius) == 0x44, "Offset mismatch for UFoliageType::bSingleInstanceModeOverrideRadius");
static_assert(offsetof(UFoliageType, SingleInstanceModeRadius) == 0x48, "Offset mismatch for UFoliageType::SingleInstanceModeRadius");
static_assert(offsetof(UFoliageType, Scaling) == 0x4c, "Offset mismatch for UFoliageType::Scaling");
static_assert(offsetof(UFoliageType, ScaleX) == 0x50, "Offset mismatch for UFoliageType::ScaleX");
static_assert(offsetof(UFoliageType, ScaleY) == 0x58, "Offset mismatch for UFoliageType::ScaleY");
static_assert(offsetof(UFoliageType, ScaleZ) == 0x60, "Offset mismatch for UFoliageType::ScaleZ");
static_assert(offsetof(UFoliageType, VertexColorMaskByChannel) == 0x68, "Offset mismatch for UFoliageType::VertexColorMaskByChannel");
static_assert(offsetof(UFoliageType, VertexColorMask) == 0x98, "Offset mismatch for UFoliageType::VertexColorMask");
static_assert(offsetof(UFoliageType, VertexColorMaskThreshold) == 0x9c, "Offset mismatch for UFoliageType::VertexColorMaskThreshold");
static_assert(offsetof(UFoliageType, VertexColorMaskInvert) == 0xa0, "Offset mismatch for UFoliageType::VertexColorMaskInvert");
static_assert(offsetof(UFoliageType, ZOffset) == 0xa4, "Offset mismatch for UFoliageType::ZOffset");
static_assert(offsetof(UFoliageType, AlignToNormal) == 0xac, "Offset mismatch for UFoliageType::AlignToNormal");
static_assert(offsetof(UFoliageType, AverageNormal) == 0xac, "Offset mismatch for UFoliageType::AverageNormal");
static_assert(offsetof(UFoliageType, AverageNormalSingleComponent) == 0xac, "Offset mismatch for UFoliageType::AverageNormalSingleComponent");
static_assert(offsetof(UFoliageType, AlignMaxAngle) == 0xb0, "Offset mismatch for UFoliageType::AlignMaxAngle");
static_assert(offsetof(UFoliageType, RandomYaw) == 0xb4, "Offset mismatch for UFoliageType::RandomYaw");
static_assert(offsetof(UFoliageType, RandomPitchAngle) == 0xb8, "Offset mismatch for UFoliageType::RandomPitchAngle");
static_assert(offsetof(UFoliageType, GroundSlopeAngle) == 0xbc, "Offset mismatch for UFoliageType::GroundSlopeAngle");
static_assert(offsetof(UFoliageType, Height) == 0xc4, "Offset mismatch for UFoliageType::Height");
static_assert(offsetof(UFoliageType, LandscapeLayers) == 0xd0, "Offset mismatch for UFoliageType::LandscapeLayers");
static_assert(offsetof(UFoliageType, MinimumLayerWeight) == 0xe0, "Offset mismatch for UFoliageType::MinimumLayerWeight");
static_assert(offsetof(UFoliageType, ExclusionLandscapeLayers) == 0xe8, "Offset mismatch for UFoliageType::ExclusionLandscapeLayers");
static_assert(offsetof(UFoliageType, MinimumExclusionLayerWeight) == 0xf8, "Offset mismatch for UFoliageType::MinimumExclusionLayerWeight");
static_assert(offsetof(UFoliageType, LandscapeLayer) == 0xfc, "Offset mismatch for UFoliageType::LandscapeLayer");
static_assert(offsetof(UFoliageType, CollisionWithWorld) == 0x100, "Offset mismatch for UFoliageType::CollisionWithWorld");
static_assert(offsetof(UFoliageType, CollisionScale) == 0x108, "Offset mismatch for UFoliageType::CollisionScale");
static_assert(offsetof(UFoliageType, AverageNormalSampleCount) == 0x120, "Offset mismatch for UFoliageType::AverageNormalSampleCount");
static_assert(offsetof(UFoliageType, MeshBounds) == 0x128, "Offset mismatch for UFoliageType::MeshBounds");
static_assert(offsetof(UFoliageType, LowBoundOriginRadius) == 0x160, "Offset mismatch for UFoliageType::LowBoundOriginRadius");
static_assert(offsetof(UFoliageType, Mobility) == 0x178, "Offset mismatch for UFoliageType::Mobility");
static_assert(offsetof(UFoliageType, CullDistance) == 0x17c, "Offset mismatch for UFoliageType::CullDistance");
static_assert(offsetof(UFoliageType, bEnableStaticLighting) == 0x184, "Offset mismatch for UFoliageType::bEnableStaticLighting");
static_assert(offsetof(UFoliageType, CastShadow) == 0x184, "Offset mismatch for UFoliageType::CastShadow");
static_assert(offsetof(UFoliageType, bAffectDynamicIndirectLighting) == 0x184, "Offset mismatch for UFoliageType::bAffectDynamicIndirectLighting");
static_assert(offsetof(UFoliageType, bAffectDistanceFieldLighting) == 0x184, "Offset mismatch for UFoliageType::bAffectDistanceFieldLighting");
static_assert(offsetof(UFoliageType, bCastDynamicShadow) == 0x184, "Offset mismatch for UFoliageType::bCastDynamicShadow");
static_assert(offsetof(UFoliageType, bCastStaticShadow) == 0x184, "Offset mismatch for UFoliageType::bCastStaticShadow");
static_assert(offsetof(UFoliageType, bCastContactShadow) == 0x188, "Offset mismatch for UFoliageType::bCastContactShadow");
static_assert(offsetof(UFoliageType, bCastShadowAsTwoSided) == 0x18c, "Offset mismatch for UFoliageType::bCastShadowAsTwoSided");
static_assert(offsetof(UFoliageType, bReceivesDecals) == 0x18c, "Offset mismatch for UFoliageType::bReceivesDecals");
static_assert(offsetof(UFoliageType, bOverrideLightMapRes) == 0x18c, "Offset mismatch for UFoliageType::bOverrideLightMapRes");
static_assert(offsetof(UFoliageType, ShadowCacheInvalidationBehavior) == 0x190, "Offset mismatch for UFoliageType::ShadowCacheInvalidationBehavior");
static_assert(offsetof(UFoliageType, OverriddenLightMapRes) == 0x194, "Offset mismatch for UFoliageType::OverriddenLightMapRes");
static_assert(offsetof(UFoliageType, LightmapType) == 0x198, "Offset mismatch for UFoliageType::LightmapType");
static_assert(offsetof(UFoliageType, bUseAsOccluder) == 0x19c, "Offset mismatch for UFoliageType::bUseAsOccluder");
static_assert(offsetof(UFoliageType, bVisibleInRayTracing) == 0x1a0, "Offset mismatch for UFoliageType::bVisibleInRayTracing");
static_assert(offsetof(UFoliageType, bEvaluateWorldPositionOffset) == 0x1a0, "Offset mismatch for UFoliageType::bEvaluateWorldPositionOffset");
static_assert(offsetof(UFoliageType, WorldPositionOffsetDisableDistance) == 0x1a4, "Offset mismatch for UFoliageType::WorldPositionOffsetDisableDistance");
static_assert(offsetof(UFoliageType, BodyInstance) == 0x1a8, "Offset mismatch for UFoliageType::BodyInstance");
static_assert(offsetof(UFoliageType, CustomNavigableGeometry) == 0x320, "Offset mismatch for UFoliageType::CustomNavigableGeometry");
static_assert(offsetof(UFoliageType, LightingChannels) == 0x321, "Offset mismatch for UFoliageType::LightingChannels");
static_assert(offsetof(UFoliageType, bRenderCustomDepth) == 0x324, "Offset mismatch for UFoliageType::bRenderCustomDepth");
static_assert(offsetof(UFoliageType, CustomDepthStencilWriteMask) == 0x328, "Offset mismatch for UFoliageType::CustomDepthStencilWriteMask");
static_assert(offsetof(UFoliageType, CustomDepthStencilValue) == 0x32c, "Offset mismatch for UFoliageType::CustomDepthStencilValue");
static_assert(offsetof(UFoliageType, TranslucencySortPriority) == 0x330, "Offset mismatch for UFoliageType::TranslucencySortPriority");
static_assert(offsetof(UFoliageType, CollisionRadius) == 0x334, "Offset mismatch for UFoliageType::CollisionRadius");
static_assert(offsetof(UFoliageType, ShadeRadius) == 0x338, "Offset mismatch for UFoliageType::ShadeRadius");
static_assert(offsetof(UFoliageType, NumSteps) == 0x33c, "Offset mismatch for UFoliageType::NumSteps");
static_assert(offsetof(UFoliageType, InitialSeedDensity) == 0x340, "Offset mismatch for UFoliageType::InitialSeedDensity");
static_assert(offsetof(UFoliageType, AverageSpreadDistance) == 0x344, "Offset mismatch for UFoliageType::AverageSpreadDistance");
static_assert(offsetof(UFoliageType, SpreadVariance) == 0x348, "Offset mismatch for UFoliageType::SpreadVariance");
static_assert(offsetof(UFoliageType, SeedsPerStep) == 0x34c, "Offset mismatch for UFoliageType::SeedsPerStep");
static_assert(offsetof(UFoliageType, DistributionSeed) == 0x350, "Offset mismatch for UFoliageType::DistributionSeed");
static_assert(offsetof(UFoliageType, MaxInitialSeedOffset) == 0x354, "Offset mismatch for UFoliageType::MaxInitialSeedOffset");
static_assert(offsetof(UFoliageType, bCanGrowInShade) == 0x358, "Offset mismatch for UFoliageType::bCanGrowInShade");
static_assert(offsetof(UFoliageType, bSpawnsInShade) == 0x359, "Offset mismatch for UFoliageType::bSpawnsInShade");
static_assert(offsetof(UFoliageType, MaxInitialAge) == 0x35c, "Offset mismatch for UFoliageType::MaxInitialAge");
static_assert(offsetof(UFoliageType, MaxAge) == 0x360, "Offset mismatch for UFoliageType::MaxAge");
static_assert(offsetof(UFoliageType, OverlapPriority) == 0x364, "Offset mismatch for UFoliageType::OverlapPriority");
static_assert(offsetof(UFoliageType, ProceduralScale) == 0x368, "Offset mismatch for UFoliageType::ProceduralScale");
static_assert(offsetof(UFoliageType, ScaleCurve) == 0x370, "Offset mismatch for UFoliageType::ScaleCurve");
static_assert(offsetof(UFoliageType, DensityFalloff) == 0x3f8, "Offset mismatch for UFoliageType::DensityFalloff");
static_assert(offsetof(UFoliageType, ChangeCount) == 0x488, "Offset mismatch for UFoliageType::ChangeCount");
static_assert(offsetof(UFoliageType, ReapplyDensity) == 0x48c, "Offset mismatch for UFoliageType::ReapplyDensity");
static_assert(offsetof(UFoliageType, ReapplyRadius) == 0x48c, "Offset mismatch for UFoliageType::ReapplyRadius");
static_assert(offsetof(UFoliageType, ReapplyAlignToNormal) == 0x48c, "Offset mismatch for UFoliageType::ReapplyAlignToNormal");
static_assert(offsetof(UFoliageType, ReapplyRandomYaw) == 0x48c, "Offset mismatch for UFoliageType::ReapplyRandomYaw");
static_assert(offsetof(UFoliageType, ReapplyScaling) == 0x48c, "Offset mismatch for UFoliageType::ReapplyScaling");
static_assert(offsetof(UFoliageType, ReapplyScaleX) == 0x48c, "Offset mismatch for UFoliageType::ReapplyScaleX");
static_assert(offsetof(UFoliageType, ReapplyScaleY) == 0x48c, "Offset mismatch for UFoliageType::ReapplyScaleY");
static_assert(offsetof(UFoliageType, ReapplyScaleZ) == 0x48c, "Offset mismatch for UFoliageType::ReapplyScaleZ");
static_assert(offsetof(UFoliageType, ReapplyRandomPitchAngle) == 0x48d, "Offset mismatch for UFoliageType::ReapplyRandomPitchAngle");
static_assert(offsetof(UFoliageType, ReapplyGroundSlope) == 0x48d, "Offset mismatch for UFoliageType::ReapplyGroundSlope");
static_assert(offsetof(UFoliageType, ReapplyHeight) == 0x48d, "Offset mismatch for UFoliageType::ReapplyHeight");
static_assert(offsetof(UFoliageType, ReapplyLandscapeLayers) == 0x48d, "Offset mismatch for UFoliageType::ReapplyLandscapeLayers");
static_assert(offsetof(UFoliageType, ReapplyZOffset) == 0x48d, "Offset mismatch for UFoliageType::ReapplyZOffset");
static_assert(offsetof(UFoliageType, ReapplyCollisionWithWorld) == 0x48d, "Offset mismatch for UFoliageType::ReapplyCollisionWithWorld");
static_assert(offsetof(UFoliageType, ReapplyVertexColorMask) == 0x48d, "Offset mismatch for UFoliageType::ReapplyVertexColorMask");
static_assert(offsetof(UFoliageType, bEnableDensityScaling) == 0x48d, "Offset mismatch for UFoliageType::bEnableDensityScaling");
static_assert(offsetof(UFoliageType, bEnableDiscardOnLoad) == 0x48e, "Offset mismatch for UFoliageType::bEnableDiscardOnLoad");
static_assert(offsetof(UFoliageType, bEnableCullDistanceScaling) == 0x48e, "Offset mismatch for UFoliageType::bEnableCullDistanceScaling");
static_assert(offsetof(UFoliageType, RuntimeVirtualTextures) == 0x490, "Offset mismatch for UFoliageType::RuntimeVirtualTextures");
static_assert(offsetof(UFoliageType, VirtualTextureCullMips) == 0x4a0, "Offset mismatch for UFoliageType::VirtualTextureCullMips");
static_assert(offsetof(UFoliageType, VirtualTextureRenderPassType) == 0x4a4, "Offset mismatch for UFoliageType::VirtualTextureRenderPassType");

// Size: 0x4c0 (Inherited: 0x4d0, Single: 0xfffffff0)
class UFoliageType_Actor : public UFoliageType
{
public:
    UClass* ActorClass; // 0x4a8 (Size: 0x8, Type: ClassProperty)
    bool bShouldAttachToBaseComponent; // 0x4b0 (Size: 0x1, Type: BoolProperty)
    bool bStaticMeshOnly; // 0x4b1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4b2[0x6]; // 0x4b2 (Size: 0x6, Type: PaddingProperty)
    UClass* StaticMeshOnlyComponentClass; // 0x4b8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFoliageType_Actor) == 0x4c0, "Size mismatch for UFoliageType_Actor");
static_assert(offsetof(UFoliageType_Actor, ActorClass) == 0x4a8, "Offset mismatch for UFoliageType_Actor::ActorClass");
static_assert(offsetof(UFoliageType_Actor, bShouldAttachToBaseComponent) == 0x4b0, "Offset mismatch for UFoliageType_Actor::bShouldAttachToBaseComponent");
static_assert(offsetof(UFoliageType_Actor, bStaticMeshOnly) == 0x4b1, "Offset mismatch for UFoliageType_Actor::bStaticMeshOnly");
static_assert(offsetof(UFoliageType_Actor, StaticMeshOnlyComponentClass) == 0x4b8, "Offset mismatch for UFoliageType_Actor::StaticMeshOnlyComponentClass");

// Size: 0x4d8 (Inherited: 0x4d0, Single: 0x8)
class UFoliageType_InstancedStaticMesh : public UFoliageType
{
public:
    UStaticMesh* Mesh; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> OverrideMaterials; // 0x4b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> NaniteOverrideMaterials; // 0x4c0 (Size: 0x10, Type: ArrayProperty)
    UClass* ComponentClass; // 0x4d0 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFoliageType_InstancedStaticMesh) == 0x4d8, "Size mismatch for UFoliageType_InstancedStaticMesh");
static_assert(offsetof(UFoliageType_InstancedStaticMesh, Mesh) == 0x4a8, "Offset mismatch for UFoliageType_InstancedStaticMesh::Mesh");
static_assert(offsetof(UFoliageType_InstancedStaticMesh, OverrideMaterials) == 0x4b0, "Offset mismatch for UFoliageType_InstancedStaticMesh::OverrideMaterials");
static_assert(offsetof(UFoliageType_InstancedStaticMesh, NaniteOverrideMaterials) == 0x4c0, "Offset mismatch for UFoliageType_InstancedStaticMesh::NaniteOverrideMaterials");
static_assert(offsetof(UFoliageType_InstancedStaticMesh, ComponentClass) == 0x4d0, "Offset mismatch for UFoliageType_InstancedStaticMesh::ComponentClass");

// Size: 0x308 (Inherited: 0x830, Single: 0xfffffad8)
class AInstancedFoliageActor : public AISMPartitionActor
{
public:
};

static_assert(sizeof(AInstancedFoliageActor) == 0x308, "Size mismatch for AInstancedFoliageActor");

// Size: 0x610 (Inherited: 0x13b0, Single: 0xfffff260)
class UInteractiveFoliageComponent : public UStaticMeshComponent
{
public:
};

static_assert(sizeof(UInteractiveFoliageComponent) == 0x610, "Size mismatch for UInteractiveFoliageComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFoliageStatistics : public UBlueprintFunctionLibrary
{
public:

public:
    static int32_t FoliageOverlappingBoxCount(UObject*& WorldContextObject, UStaticMesh*& const StaticMesh, FBox& Box); // 0x9e5e4c0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
    static void FoliageOverlappingBoxTransforms(UObject*& WorldContextObject, UStaticMesh*& const StaticMesh, FBox& Box, TArray<FTransform>& OutTransforms); // 0x9e5e770 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t FoliageOverlappingSphereCount(UObject*& WorldContextObject, UStaticMesh*& const StaticMesh, FVector& CenterPosition, float& Radius); // 0x9e5ec60 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFoliageStatistics) == 0x28, "Size mismatch for UFoliageStatistics");

// Size: 0xb40 (Inherited: 0x2890, Single: 0xffffe2b0)
class UGrassInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
public:
};

static_assert(sizeof(UGrassInstancedStaticMeshComponent) == 0xb40, "Size mismatch for UGrassInstancedStaticMeshComponent");

// Size: 0x348 (Inherited: 0x588, Single: 0xfffffdc0)
class AInteractiveFoliageActor : public AStaticMeshActor
{
public:
    UCapsuleComponent* CapsuleComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    FVector TouchingActorEntryPosition; // 0x2c0 (Size: 0x18, Type: StructProperty)
    FVector FoliageVelocity; // 0x2d8 (Size: 0x18, Type: StructProperty)
    FVector FoliageForce; // 0x2f0 (Size: 0x18, Type: StructProperty)
    FVector FoliagePosition; // 0x308 (Size: 0x18, Type: StructProperty)
    float FoliageDamageImpulseScale; // 0x320 (Size: 0x4, Type: FloatProperty)
    float FoliageTouchImpulseScale; // 0x324 (Size: 0x4, Type: FloatProperty)
    float FoliageStiffness; // 0x328 (Size: 0x4, Type: FloatProperty)
    float FoliageStiffnessQuadratic; // 0x32c (Size: 0x4, Type: FloatProperty)
    float FoliageDamping; // 0x330 (Size: 0x4, Type: FloatProperty)
    float MaxDamageImpulse; // 0x334 (Size: 0x4, Type: FloatProperty)
    float MaxTouchImpulse; // 0x338 (Size: 0x4, Type: FloatProperty)
    float MaxForce; // 0x33c (Size: 0x4, Type: FloatProperty)
    float Mass; // 0x340 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_344[0x4]; // 0x344 (Size: 0x4, Type: PaddingProperty)

protected:
    void CapsuleTouched(UPrimitiveComponent*& OverlappedComp, AActor*& Other, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult OverlapInfo); // 0x9e5de40 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(AInteractiveFoliageActor) == 0x348, "Size mismatch for AInteractiveFoliageActor");
static_assert(offsetof(AInteractiveFoliageActor, CapsuleComponent) == 0x2b8, "Offset mismatch for AInteractiveFoliageActor::CapsuleComponent");
static_assert(offsetof(AInteractiveFoliageActor, TouchingActorEntryPosition) == 0x2c0, "Offset mismatch for AInteractiveFoliageActor::TouchingActorEntryPosition");
static_assert(offsetof(AInteractiveFoliageActor, FoliageVelocity) == 0x2d8, "Offset mismatch for AInteractiveFoliageActor::FoliageVelocity");
static_assert(offsetof(AInteractiveFoliageActor, FoliageForce) == 0x2f0, "Offset mismatch for AInteractiveFoliageActor::FoliageForce");
static_assert(offsetof(AInteractiveFoliageActor, FoliagePosition) == 0x308, "Offset mismatch for AInteractiveFoliageActor::FoliagePosition");
static_assert(offsetof(AInteractiveFoliageActor, FoliageDamageImpulseScale) == 0x320, "Offset mismatch for AInteractiveFoliageActor::FoliageDamageImpulseScale");
static_assert(offsetof(AInteractiveFoliageActor, FoliageTouchImpulseScale) == 0x324, "Offset mismatch for AInteractiveFoliageActor::FoliageTouchImpulseScale");
static_assert(offsetof(AInteractiveFoliageActor, FoliageStiffness) == 0x328, "Offset mismatch for AInteractiveFoliageActor::FoliageStiffness");
static_assert(offsetof(AInteractiveFoliageActor, FoliageStiffnessQuadratic) == 0x32c, "Offset mismatch for AInteractiveFoliageActor::FoliageStiffnessQuadratic");
static_assert(offsetof(AInteractiveFoliageActor, FoliageDamping) == 0x330, "Offset mismatch for AInteractiveFoliageActor::FoliageDamping");
static_assert(offsetof(AInteractiveFoliageActor, MaxDamageImpulse) == 0x334, "Offset mismatch for AInteractiveFoliageActor::MaxDamageImpulse");
static_assert(offsetof(AInteractiveFoliageActor, MaxTouchImpulse) == 0x338, "Offset mismatch for AInteractiveFoliageActor::MaxTouchImpulse");
static_assert(offsetof(AInteractiveFoliageActor, MaxForce) == 0x33c, "Offset mismatch for AInteractiveFoliageActor::MaxForce");
static_assert(offsetof(AInteractiveFoliageActor, Mass) == 0x340, "Offset mismatch for AInteractiveFoliageActor::Mass");

// Size: 0x378 (Inherited: 0x890, Single: 0xfffffae8)
class AProceduralFoliageBlockingVolume : public AVolume
{
public:
    AProceduralFoliageVolume* ProceduralFoliageVolume; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    FFoliageDensityFalloff DensityFalloff; // 0x2e8 (Size: 0x90, Type: StructProperty)
};

static_assert(sizeof(AProceduralFoliageBlockingVolume) == 0x378, "Size mismatch for AProceduralFoliageBlockingVolume");
static_assert(offsetof(AProceduralFoliageBlockingVolume, ProceduralFoliageVolume) == 0x2e0, "Offset mismatch for AProceduralFoliageBlockingVolume::ProceduralFoliageVolume");
static_assert(offsetof(AProceduralFoliageBlockingVolume, DensityFalloff) == 0x2e8, "Offset mismatch for AProceduralFoliageBlockingVolume::DensityFalloff");

// Size: 0xe0 (Inherited: 0xe0, Single: 0x0)
class UProceduralFoliageComponent : public UActorComponent
{
public:
    UProceduralFoliageSpawner* FoliageSpawner; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    float TileOverlap; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
    AVolume* SpawningVolume; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGuid ProceduralGuid; // 0xd0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UProceduralFoliageComponent) == 0xe0, "Size mismatch for UProceduralFoliageComponent");
static_assert(offsetof(UProceduralFoliageComponent, FoliageSpawner) == 0xb8, "Offset mismatch for UProceduralFoliageComponent::FoliageSpawner");
static_assert(offsetof(UProceduralFoliageComponent, TileOverlap) == 0xc0, "Offset mismatch for UProceduralFoliageComponent::TileOverlap");
static_assert(offsetof(UProceduralFoliageComponent, SpawningVolume) == 0xc8, "Offset mismatch for UProceduralFoliageComponent::SpawningVolume");
static_assert(offsetof(UProceduralFoliageComponent, ProceduralGuid) == 0xd0, "Offset mismatch for UProceduralFoliageComponent::ProceduralGuid");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class UProceduralFoliageSpawner : public UObject
{
public:
    int32_t RandomSeed; // 0x28 (Size: 0x4, Type: IntProperty)
    float TileSize; // 0x2c (Size: 0x4, Type: FloatProperty)
    int32_t NumUniqueTiles; // 0x30 (Size: 0x4, Type: IntProperty)
    float MinimumQuadTreeSize; // 0x34 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    TArray<FFoliageTypeObject> FoliageTypes; // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bUseOverrideFoliageTerrainMaterials; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    TArray<TSoftObjectPtr<UMaterialInterface*>> OverrideFoliageTerrainMaterials; // 0x58 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_68[0x18]; // 0x68 (Size: 0x18, Type: PaddingProperty)

public:
    void Simulate(int32_t& NumSteps); // 0x9e5ef50 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UProceduralFoliageSpawner) == 0x80, "Size mismatch for UProceduralFoliageSpawner");
static_assert(offsetof(UProceduralFoliageSpawner, RandomSeed) == 0x28, "Offset mismatch for UProceduralFoliageSpawner::RandomSeed");
static_assert(offsetof(UProceduralFoliageSpawner, TileSize) == 0x2c, "Offset mismatch for UProceduralFoliageSpawner::TileSize");
static_assert(offsetof(UProceduralFoliageSpawner, NumUniqueTiles) == 0x30, "Offset mismatch for UProceduralFoliageSpawner::NumUniqueTiles");
static_assert(offsetof(UProceduralFoliageSpawner, MinimumQuadTreeSize) == 0x34, "Offset mismatch for UProceduralFoliageSpawner::MinimumQuadTreeSize");
static_assert(offsetof(UProceduralFoliageSpawner, FoliageTypes) == 0x40, "Offset mismatch for UProceduralFoliageSpawner::FoliageTypes");
static_assert(offsetof(UProceduralFoliageSpawner, bUseOverrideFoliageTerrainMaterials) == 0x50, "Offset mismatch for UProceduralFoliageSpawner::bUseOverrideFoliageTerrainMaterials");
static_assert(offsetof(UProceduralFoliageSpawner, OverrideFoliageTerrainMaterials) == 0x58, "Offset mismatch for UProceduralFoliageSpawner::OverrideFoliageTerrainMaterials");

// Size: 0x170 (Inherited: 0x28, Single: 0x148)
class UProceduralFoliageTile : public UObject
{
public:
    UProceduralFoliageSpawner* FoliageSpawner; // 0x28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_30[0xa0]; // 0x30 (Size: 0xa0, Type: PaddingProperty)
    TArray<FProceduralFoliageInstance> InstancesArray; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e0[0x90]; // 0xe0 (Size: 0x90, Type: PaddingProperty)
};

static_assert(sizeof(UProceduralFoliageTile) == 0x170, "Size mismatch for UProceduralFoliageTile");
static_assert(offsetof(UProceduralFoliageTile, FoliageSpawner) == 0x28, "Offset mismatch for UProceduralFoliageTile::FoliageSpawner");
static_assert(offsetof(UProceduralFoliageTile, InstancesArray) == 0xd0, "Offset mismatch for UProceduralFoliageTile::InstancesArray");

// Size: 0x2f0 (Inherited: 0x890, Single: 0xfffffa60)
class AProceduralFoliageVolume : public AVolume
{
public:
    uint8_t Pad_2e0[0x8]; // 0x2e0 (Size: 0x8, Type: PaddingProperty)
    UProceduralFoliageComponent* ProceduralComponent; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AProceduralFoliageVolume) == 0x2f0, "Size mismatch for AProceduralFoliageVolume");
static_assert(offsetof(AProceduralFoliageVolume, ProceduralComponent) == 0x2e8, "Offset mismatch for AProceduralFoliageVolume::ProceduralComponent");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFoliageVertexColorChannelMask
{
    uint8_t UseMask : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MaskThreshold; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t InvertMask : 1; // 0x8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFoliageVertexColorChannelMask) == 0xc, "Size mismatch for FFoliageVertexColorChannelMask");
static_assert(offsetof(FFoliageVertexColorChannelMask, UseMask) == 0x0, "Offset mismatch for FFoliageVertexColorChannelMask::UseMask");
static_assert(offsetof(FFoliageVertexColorChannelMask, MaskThreshold) == 0x4, "Offset mismatch for FFoliageVertexColorChannelMask::MaskThreshold");
static_assert(offsetof(FFoliageVertexColorChannelMask, InvertMask) == 0x8, "Offset mismatch for FFoliageVertexColorChannelMask::InvertMask");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FFoliageDensityFalloff
{
    bool bUseFalloffCurve; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FRuntimeFloatCurve FalloffCurve; // 0x8 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(FFoliageDensityFalloff) == 0x90, "Size mismatch for FFoliageDensityFalloff");
static_assert(offsetof(FFoliageDensityFalloff, bUseFalloffCurve) == 0x0, "Offset mismatch for FFoliageDensityFalloff::bUseFalloffCurve");
static_assert(offsetof(FFoliageDensityFalloff, FalloffCurve) == 0x8, "Offset mismatch for FFoliageDensityFalloff::FalloffCurve");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFoliageTypeObject
{
    UObject* FoliageTypeObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFoliageType* TypeInstance; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bIsAsset; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    UClass* Type; // 0x18 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FFoliageTypeObject) == 0x20, "Size mismatch for FFoliageTypeObject");
static_assert(offsetof(FFoliageTypeObject, FoliageTypeObject) == 0x0, "Offset mismatch for FFoliageTypeObject::FoliageTypeObject");
static_assert(offsetof(FFoliageTypeObject, TypeInstance) == 0x8, "Offset mismatch for FFoliageTypeObject::TypeInstance");
static_assert(offsetof(FFoliageTypeObject, bIsAsset) == 0x10, "Offset mismatch for FFoliageTypeObject::bIsAsset");
static_assert(offsetof(FFoliageTypeObject, Type) == 0x18, "Offset mismatch for FFoliageTypeObject::Type");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FProceduralFoliageInstance
{
    FQuat Rotation; // 0x0 (Size: 0x20, Type: StructProperty)
    FVector Location; // 0x20 (Size: 0x18, Type: StructProperty)
    float Age; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FVector Normal; // 0x40 (Size: 0x18, Type: StructProperty)
    float Scale; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    UFoliageType* Type; // 0x60 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_68[0x18]; // 0x68 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FProceduralFoliageInstance) == 0x80, "Size mismatch for FProceduralFoliageInstance");
static_assert(offsetof(FProceduralFoliageInstance, Rotation) == 0x0, "Offset mismatch for FProceduralFoliageInstance::Rotation");
static_assert(offsetof(FProceduralFoliageInstance, Location) == 0x20, "Offset mismatch for FProceduralFoliageInstance::Location");
static_assert(offsetof(FProceduralFoliageInstance, Age) == 0x38, "Offset mismatch for FProceduralFoliageInstance::Age");
static_assert(offsetof(FProceduralFoliageInstance, Normal) == 0x40, "Offset mismatch for FProceduralFoliageInstance::Normal");
static_assert(offsetof(FProceduralFoliageInstance, Scale) == 0x58, "Offset mismatch for FProceduralFoliageInstance::Scale");
static_assert(offsetof(FProceduralFoliageInstance, Type) == 0x60, "Offset mismatch for FProceduralFoliageInstance::Type");

