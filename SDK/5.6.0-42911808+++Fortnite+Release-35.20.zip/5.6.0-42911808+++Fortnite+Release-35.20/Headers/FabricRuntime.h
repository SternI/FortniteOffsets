/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FMCoreRuntime.h"
#include "ModularGameplay.h"
#include "PlayspaceSystem.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "GameFeatures.h"
#include "FabricFramework.h"
#include "Niagara.h"
#include "HarmonixMidi.h"
#include "MetasoundFrontend.h"
#include "FabricUI.h"
#include "GameplayTags.h"
#include "EnhancedInput.h"
#include "HarmonixMetasound.h"
#include "GameplayMessages.h"
#include "MetasoundEngine.h"
#include "FabricMetasoundDataTypes.h"
#include "HarmonixDsp.h"
#include "TargetingSystem.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricAnimatableButtonInterface : public UInterface
{
public:

public:
    virtual void PlayCloseAnimation(); // 0x538b694 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void PlayOpenAnimation(); // 0x4e3f4f8 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UFabricAnimatableButtonInterface) == 0x28, "Size mismatch for UFabricAnimatableButtonInterface");

// Size: 0x100 (Inherited: 0xe0, Single: 0x20)
class UFabricAudioBridgeComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    UClass* FabricAudioPatchWrapperClass; // 0xd0 (Size: 0x8, Type: ClassProperty)
    UFabricMetaSoundAudioPatchWrapper* FabricAudioPatchWrapperInstance; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> FabricMetasoundManager; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_e8[0x18]; // 0xe8 (Size: 0x18, Type: PaddingProperty)

public:
    void OnFabricZoneSystemSet(AFabricZoneSystem*& const FabricZoneSystem); // 0x111939b8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetAudioStartTime(const FMusicTimestamp StartTime); // 0x111943ac (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SyncAudioToMetaSound(USoundWave*& InAudio, float& AudioStartTime, float& InitialVolume, bool& bLoopAudio); // 0x11194f4c (Index: 0x3, Flags: Native|Public|BlueprintCallable)

protected:
    void OnRemoveSyncedAudioTimerElapsed(); // 0x11194120 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricAudioBridgeComponent) == 0x100, "Size mismatch for UFabricAudioBridgeComponent");
static_assert(offsetof(UFabricAudioBridgeComponent, FabricAudioPatchWrapperClass) == 0xd0, "Offset mismatch for UFabricAudioBridgeComponent::FabricAudioPatchWrapperClass");
static_assert(offsetof(UFabricAudioBridgeComponent, FabricAudioPatchWrapperInstance) == 0xd8, "Offset mismatch for UFabricAudioBridgeComponent::FabricAudioPatchWrapperInstance");
static_assert(offsetof(UFabricAudioBridgeComponent, FabricMetasoundManager) == 0xe0, "Offset mismatch for UFabricAudioBridgeComponent::FabricMetasoundManager");

// Size: 0x350 (Inherited: 0x2d0, Single: 0x80)
class AFabricButtonBase : public AActor
{
public:
    uint8_t Pad_2a8[0x18]; // 0x2a8 (Size: 0x18, Type: PaddingProperty)
    uint8_t ToggleStateChanged[0x10]; // 0x2c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double OpenTimeSeconds; // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    double CloseTimeSeconds; // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    bool bHasToggle; // 0x2e0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EButtonPressMethod> ClickMethod; // 0x2e1 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2e2[0x6]; // 0x2e2 (Size: 0x6, Type: PaddingProperty)
    APlayerController* InteractingController; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    FString ButtonId; // 0x2f0 (Size: 0x10, Type: StrProperty)
    FText ButtonLabel; // 0x300 (Size: 0x10, Type: TextProperty)
    FText ButtonDescription; // 0x310 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer GameplayTags; // 0x320 (Size: 0x20, Type: StructProperty)
    bool bEnabled; // 0x340 (Size: 0x1, Type: BoolProperty)
    bool bHovered; // 0x341 (Size: 0x1, Type: BoolProperty)
    bool bPressed; // 0x342 (Size: 0x1, Type: BoolProperty)
    uint8_t ToggleState; // 0x343 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_344[0x4]; // 0x344 (Size: 0x4, Type: PaddingProperty)
    UFabricInteractableViewModel* WidgetViewModel; // 0x348 (Size: 0x8, Type: ObjectProperty)

public:
    virtual UTimelineComponent* GetCloseTimeline(); // 0xa5f3db8 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual UTimelineComponent* GetOpenTimeline(); // 0xa5f3db8 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void HandleButtonClicked(); // 0x61ed548 (Index: 0x2, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonDoubleClicked(); // 0x35da720 (Index: 0x3, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonHovered(); // 0xce731b4 (Index: 0x4, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonPressed(); // 0x2649998 (Index: 0x5, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonReleased(); // 0xaaa7d44 (Index: 0x6, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonUnhovered(); // 0xa7464fc (Index: 0x7, Flags: Native|Event|Public|BlueprintEvent)
    bool IsEnabled(); // 0xff7d380 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsHovered(); // 0xf418b78 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsPressed(); // 0x11193920 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsToggledOn(); // 0x11193950 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    virtual void OnButtonClicked(); // 0x328c674 (Index: 0xc, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnButtonDoubleClicked(); // 0x53076e4 (Index: 0xd, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnButtonPressed(); // 0xc045150 (Index: 0xe, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnButtonReleased(); // 0xc045138 (Index: 0xf, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnDisabled(); // 0x328ca4c (Index: 0x10, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnEnabled(); // 0x4de3268 (Index: 0x11, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void OnHovered(); // 0xa280c90 (Index: 0x12, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnToggleStateChanged(bool& bIsToggled); // 0x11194134 (Index: 0x13, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnUnhovered(); // 0x5349664 (Index: 0x14, Flags: Native|Event|Public|BlueprintEvent)
    void SetEnabled(bool& bNewEnabled); // 0x11194484 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetToggleState(bool& bNewToggleState, bool& bBroadcast, bool& bForce); // 0x111946dc (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetWidgetViewModel(UFabricInteractableViewModel*& ViewModel); // 0x11194ccc (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SwapToggle(); // 0x11194f24 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void ToggleStateChanged__DelegateSignature(APlayerController*& InteractingController, bool& IsToggle); // 0x288a61c (Index: 0x19, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(AFabricButtonBase) == 0x350, "Size mismatch for AFabricButtonBase");
static_assert(offsetof(AFabricButtonBase, ToggleStateChanged) == 0x2c0, "Offset mismatch for AFabricButtonBase::ToggleStateChanged");
static_assert(offsetof(AFabricButtonBase, OpenTimeSeconds) == 0x2d0, "Offset mismatch for AFabricButtonBase::OpenTimeSeconds");
static_assert(offsetof(AFabricButtonBase, CloseTimeSeconds) == 0x2d8, "Offset mismatch for AFabricButtonBase::CloseTimeSeconds");
static_assert(offsetof(AFabricButtonBase, bHasToggle) == 0x2e0, "Offset mismatch for AFabricButtonBase::bHasToggle");
static_assert(offsetof(AFabricButtonBase, ClickMethod) == 0x2e1, "Offset mismatch for AFabricButtonBase::ClickMethod");
static_assert(offsetof(AFabricButtonBase, InteractingController) == 0x2e8, "Offset mismatch for AFabricButtonBase::InteractingController");
static_assert(offsetof(AFabricButtonBase, ButtonId) == 0x2f0, "Offset mismatch for AFabricButtonBase::ButtonId");
static_assert(offsetof(AFabricButtonBase, ButtonLabel) == 0x300, "Offset mismatch for AFabricButtonBase::ButtonLabel");
static_assert(offsetof(AFabricButtonBase, ButtonDescription) == 0x310, "Offset mismatch for AFabricButtonBase::ButtonDescription");
static_assert(offsetof(AFabricButtonBase, GameplayTags) == 0x320, "Offset mismatch for AFabricButtonBase::GameplayTags");
static_assert(offsetof(AFabricButtonBase, bEnabled) == 0x340, "Offset mismatch for AFabricButtonBase::bEnabled");
static_assert(offsetof(AFabricButtonBase, bHovered) == 0x341, "Offset mismatch for AFabricButtonBase::bHovered");
static_assert(offsetof(AFabricButtonBase, bPressed) == 0x342, "Offset mismatch for AFabricButtonBase::bPressed");
static_assert(offsetof(AFabricButtonBase, ToggleState) == 0x343, "Offset mismatch for AFabricButtonBase::ToggleState");
static_assert(offsetof(AFabricButtonBase, WidgetViewModel) == 0x348, "Offset mismatch for AFabricButtonBase::WidgetViewModel");

// Size: 0x6c0 (Inherited: 0x13b0, Single: 0xfffff310)
class UFabricButtonComponentBase : public UStaticMeshComponent
{
public:
    uint8_t Pad_610[0x8]; // 0x610 (Size: 0x8, Type: PaddingProperty)
    uint8_t ToggleStateChanged[0x10]; // 0x618 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double OpenTimeSeconds; // 0x628 (Size: 0x8, Type: DoubleProperty)
    double CloseTimeSeconds; // 0x630 (Size: 0x8, Type: DoubleProperty)
    bool bHasToggle; // 0x638 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EButtonPressMethod> ClickMethod; // 0x639 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_63a[0x6]; // 0x63a (Size: 0x6, Type: PaddingProperty)
    APlayerController* InteractingController; // 0x640 (Size: 0x8, Type: ObjectProperty)
    FString ButtonId; // 0x648 (Size: 0x10, Type: StrProperty)
    FText ButtonLabel; // 0x658 (Size: 0x10, Type: TextProperty)
    FText ButtonDescription; // 0x668 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer GameplayTags; // 0x678 (Size: 0x20, Type: StructProperty)
    bool bUseScreenGrid; // 0x698 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_699[0x7]; // 0x699 (Size: 0x7, Type: PaddingProperty)
    FVector2D ScreenGridPosition; // 0x6a0 (Size: 0x10, Type: StructProperty)
    bool bEnabled; // 0x6b0 (Size: 0x1, Type: BoolProperty)
    bool bHovered; // 0x6b1 (Size: 0x1, Type: BoolProperty)
    bool bPressed; // 0x6b2 (Size: 0x1, Type: BoolProperty)
    uint8_t ToggleState; // 0x6b3 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6b4[0x4]; // 0x6b4 (Size: 0x4, Type: PaddingProperty)
    UFabricInteractableViewModel* WidgetViewModel; // 0x6b8 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ConstructButton(); // 0x111937d0 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual UTimelineComponent* GetCloseTimeline(); // 0xa5f3db8 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual UTimelineComponent* GetOpenTimeline(); // 0xa5f3db8 (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void HandleButtonClicked(); // 0xa7f084c (Index: 0x3, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonDoubleClicked(); // 0x111938a8 (Index: 0x4, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonHovered(); // 0xd9bee10 (Index: 0x5, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonPressed(); // 0x4f6c140 (Index: 0x6, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonReleased(); // 0x111938c0 (Index: 0x7, Flags: Native|Event|Public|BlueprintEvent)
    virtual void HandleButtonUnhovered(); // 0x111938d8 (Index: 0x8, Flags: Native|Event|Public|BlueprintEvent)
    bool IsEnabled(); // 0x111938f0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsHovered(); // 0x11193908 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsPressed(); // 0x11193938 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsToggledOn(); // 0x1119396c (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    virtual void OnButtonClicked(); // 0xa7ec900 (Index: 0xd, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnButtonDoubleClicked(); // 0xec28204 (Index: 0xe, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnButtonPressed(); // 0x10871dd8 (Index: 0xf, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnButtonReleased(); // 0xa7f1a64 (Index: 0x10, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnDisabled(); // 0x11193988 (Index: 0x11, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnEnabled(); // 0x111939a0 (Index: 0x12, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void OnHovered(); // 0x11193cc8 (Index: 0x13, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnToggleStateChanged(bool& bIsToggled); // 0x11194264 (Index: 0x14, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnUnhovered(); // 0x11194394 (Index: 0x15, Flags: Native|Event|Public|BlueprintEvent)
    void SetEnabled(bool& bNewEnabled); // 0x111945b0 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetToggleState(bool& bNewToggleState, bool& bBroadcast, bool& bForce); // 0x111949d4 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetWidgetViewModel(UFabricInteractableViewModel*& ViewModel); // 0x11194df8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SwapToggle(); // 0x11194f38 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void ToggleStateChanged__DelegateSignature(APlayerController*& InteractingController, bool& IsToggle); // 0x288a61c (Index: 0x1a, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UFabricButtonComponentBase) == 0x6c0, "Size mismatch for UFabricButtonComponentBase");
static_assert(offsetof(UFabricButtonComponentBase, ToggleStateChanged) == 0x618, "Offset mismatch for UFabricButtonComponentBase::ToggleStateChanged");
static_assert(offsetof(UFabricButtonComponentBase, OpenTimeSeconds) == 0x628, "Offset mismatch for UFabricButtonComponentBase::OpenTimeSeconds");
static_assert(offsetof(UFabricButtonComponentBase, CloseTimeSeconds) == 0x630, "Offset mismatch for UFabricButtonComponentBase::CloseTimeSeconds");
static_assert(offsetof(UFabricButtonComponentBase, bHasToggle) == 0x638, "Offset mismatch for UFabricButtonComponentBase::bHasToggle");
static_assert(offsetof(UFabricButtonComponentBase, ClickMethod) == 0x639, "Offset mismatch for UFabricButtonComponentBase::ClickMethod");
static_assert(offsetof(UFabricButtonComponentBase, InteractingController) == 0x640, "Offset mismatch for UFabricButtonComponentBase::InteractingController");
static_assert(offsetof(UFabricButtonComponentBase, ButtonId) == 0x648, "Offset mismatch for UFabricButtonComponentBase::ButtonId");
static_assert(offsetof(UFabricButtonComponentBase, ButtonLabel) == 0x658, "Offset mismatch for UFabricButtonComponentBase::ButtonLabel");
static_assert(offsetof(UFabricButtonComponentBase, ButtonDescription) == 0x668, "Offset mismatch for UFabricButtonComponentBase::ButtonDescription");
static_assert(offsetof(UFabricButtonComponentBase, GameplayTags) == 0x678, "Offset mismatch for UFabricButtonComponentBase::GameplayTags");
static_assert(offsetof(UFabricButtonComponentBase, bUseScreenGrid) == 0x698, "Offset mismatch for UFabricButtonComponentBase::bUseScreenGrid");
static_assert(offsetof(UFabricButtonComponentBase, ScreenGridPosition) == 0x6a0, "Offset mismatch for UFabricButtonComponentBase::ScreenGridPosition");
static_assert(offsetof(UFabricButtonComponentBase, bEnabled) == 0x6b0, "Offset mismatch for UFabricButtonComponentBase::bEnabled");
static_assert(offsetof(UFabricButtonComponentBase, bHovered) == 0x6b1, "Offset mismatch for UFabricButtonComponentBase::bHovered");
static_assert(offsetof(UFabricButtonComponentBase, bPressed) == 0x6b2, "Offset mismatch for UFabricButtonComponentBase::bPressed");
static_assert(offsetof(UFabricButtonComponentBase, ToggleState) == 0x6b3, "Offset mismatch for UFabricButtonComponentBase::ToggleState");
static_assert(offsetof(UFabricButtonComponentBase, WidgetViewModel) == 0x6b8, "Offset mismatch for UFabricButtonComponentBase::WidgetViewModel");

// Size: 0x150 (Inherited: 0x2e0, Single: 0xfffffe70)
class UFabricDeviceCustomInteractionManager : public UFMPlayerMonitorComponent
{
public:
    UClass* CustomInteractionComponentClass; // 0x148 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFabricDeviceCustomInteractionManager) == 0x150, "Size mismatch for UFabricDeviceCustomInteractionManager");
static_assert(offsetof(UFabricDeviceCustomInteractionManager, CustomInteractionComponentClass) == 0x148, "Offset mismatch for UFabricDeviceCustomInteractionManager::CustomInteractionComponentClass");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricDevice : public UInterface
{
public:
};

static_assert(sizeof(UFabricDevice) == 0x28, "Size mismatch for UFabricDevice");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricMetaSoundPatchOwner : public UInterface
{
public:

public:
    virtual EFabricMetaSoundMaxAttenuation GetMaxAttenuation(); // 0x427a3e8 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual UFabricMetaSoundPatchWrapper* GetMetaSoundPatchWrapper(); // 0xaf412f8 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UFabricMetaSoundPatchOwner) == 0x28, "Size mismatch for UFabricMetaSoundPatchOwner");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricAudioGenerator : public UInterface
{
public:

public:
    virtual FSourceEffectChainEntry GetAudioAnalyzer(); // 0x111937e8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricAudioGenerator) == 0x28, "Size mismatch for UFabricAudioGenerator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricAudioModifier : public UInterface
{
public:

public:
    virtual TArray<FSourceEffectChainEntry> GetSourceEffectChainEntries(); // 0x11193834 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricAudioModifier) == 0x28, "Size mismatch for UFabricAudioModifier");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricAudioReceiver : public UInterface
{
public:

public:
    virtual USoundSourceBus* GetSoundSourceBus(); // 0xaf412f8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricAudioReceiver) == 0x28, "Size mismatch for UFabricAudioReceiver");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricFloatGenerator : public UInterface
{
public:

public:
    virtual UFabricFloatProviderBase* GetFloatProvider(); // 0xaf412f8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricFloatGenerator) == 0x28, "Size mismatch for UFabricFloatGenerator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricFloatReceiver : public UInterface
{
public:

public:
    virtual void SetFloatProviders(const TArray<UFabricFloatProviderBase*> FloatProvider); // 0xa345d5c (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFabricFloatReceiver) == 0x28, "Size mismatch for UFabricFloatReceiver");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricTextureGenerator : public UInterface
{
public:

public:
    virtual UFabricTextureProviderBase* GetTextureProvider(); // 0xaf412f8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricTextureGenerator) == 0x28, "Size mismatch for UFabricTextureGenerator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricTextureModifier : public UInterface
{
public:

public:
    virtual UFabricTextureModifierBase* GetTextureModifier(); // 0xaf412f8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
    virtual bool IsShowingTexturePreview() const; // 0x427a3e8 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(UFabricTextureModifier) == 0x28, "Size mismatch for UFabricTextureModifier");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricTextureReceiver : public UInterface
{
public:

public:
    virtual void OnTexturesChanged(const TArray<FFabricTextureProviderTexture> Texture); // 0xbd1e9d8 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFabricTextureReceiver) == 0x28, "Size mismatch for UFabricTextureReceiver");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricMeshGenerator : public UInterface
{
public:

public:
    virtual UFabricMeshProviderBase* GetMeshProvider(); // 0xaf412f8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricMeshGenerator) == 0x28, "Size mismatch for UFabricMeshGenerator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricMeshModifier : public UInterface
{
public:

public:
    virtual UFabricMeshModifierBase* GetMeshModifier() const; // 0x54e5764 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual bool IsShowingMeshPreview() const; // 0xcc4dc80 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual void OnMeshesChanged(const TArray<FFabricMeshInstanceReference> InstanceMeshReferences, bool& bInstancesChanged); // 0x11193fbc (Index: 0x2, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFabricMeshModifier) == 0x28, "Size mismatch for UFabricMeshModifier");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricMeshReceiver : public UInterface
{
public:

public:
    virtual void OnMeshInstanceReferencesChanged(const TArray<FFabricMeshInstanceReference> MeshInstanceReferences, bool& bMeshChanged, bool& bInstancesChanged); // 0x11193ce0 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnMeshInstancesChanged(const TArray<FTransform> Meshes); // 0xd3ef7e0 (Index: 0x1, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnMeshReferenceChanged(const FFabricMeshProviderMeshReference ReferenceMesh); // 0x11193eb8 (Index: 0x2, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFabricMeshReceiver) == 0x28, "Size mismatch for UFabricMeshReceiver");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UFabricModulationNode : public UObject
{
public:
    TArray<UFabricFloatProviderBase*> FloatProviders; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x10]; // 0x38 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFabricModulationNode) == 0x48, "Size mismatch for UFabricModulationNode");
static_assert(offsetof(UFabricModulationNode, FloatProviders) == 0x28, "Offset mismatch for UFabricModulationNode::FloatProviders");

// Size: 0x390 (Inherited: 0x350, Single: 0x40)
class UFabricFloatProviderBase : public UFabricModulatable
{
public:
    uint8_t Pad_328[0x8]; // 0x328 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnFloatChanged[0x10]; // 0x330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTransitionFloatChanged[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFloatProviderEnabledChanged[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float CurrentFloat; // 0x360 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClock; // 0x364 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_36c[0x4]; // 0x36c (Size: 0x4, Type: PaddingProperty)
    UFabricMetaSoundModulatorPatchWrapper* AssociatedPatchWrapper; // 0x370 (Size: 0x8, Type: ObjectProperty)
    FString EnabledParam; // 0x378 (Size: 0x10, Type: StrProperty)
    bool bAlwaysModulates; // 0x388 (Size: 0x1, Type: BoolProperty)
    bool bBindBlueprintOnFloatChanged; // 0x389 (Size: 0x1, Type: BoolProperty)
    bool bIsEnabled; // 0x38a (Size: 0x1, Type: BoolProperty)
    bool bModulatorValueChanged; // 0x38b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_38c[0x4]; // 0x38c (Size: 0x4, Type: PaddingProperty)

public:
    UFabricMetaSoundModulatorPatchWrapper* GetAssociatedPatchWrapper() const; // 0x11196f90 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentFloat() const; // 0xee17a38 (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFloatAtSongPos(const FMidiSongPos SongPos) const; // 0x1119733c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    EFabricFloatProviderType GetFloatProviderType() const; // 0xa39d88c (Index: 0x5, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetProviderEnabled() const; // 0x11197a94 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnFloatChanged__DelegateSignature(float& float, UFabricFloatProviderBase*& FloatProvider); // 0x288a61c (Index: 0x7, Flags: MulticastDelegate|Public|Delegate)
    void OnFloatProviderEnabledChanged__DelegateSignature(bool& bEnabled, UFabricFloatProviderBase*& FloatProvider); // 0x288a61c (Index: 0x8, Flags: MulticastDelegate|Public|Delegate)
    void OnTransitionFloatChanged__DelegateSignature(float& FinalValue, float& TransitionLerp, UFabricFloatProviderBase*& FloatProvider); // 0x288a61c (Index: 0x9, Flags: MulticastDelegate|Public|Delegate)
    void SetAssociatedPatchWrapper(UFabricMetaSoundModulatorPatchWrapper*& PatchWrapper); // 0x111989d0 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetMusicClock(UMusicClockComponent*& NewMusicClock); // 0x11198f70 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetProviderEnabled(bool& bInIsEnabled); // 0x11199248 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)

protected:
    FMidiSongPos GetCurrentSongPos() const; // 0x11196ffc (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    FMidiSongPos GetCurrentSongPosWithOffset(float& OffsetSeconds) const; // 0x1119703c (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFabricFloatProviderBase) == 0x390, "Size mismatch for UFabricFloatProviderBase");
static_assert(offsetof(UFabricFloatProviderBase, OnFloatChanged) == 0x330, "Offset mismatch for UFabricFloatProviderBase::OnFloatChanged");
static_assert(offsetof(UFabricFloatProviderBase, OnTransitionFloatChanged) == 0x340, "Offset mismatch for UFabricFloatProviderBase::OnTransitionFloatChanged");
static_assert(offsetof(UFabricFloatProviderBase, OnFloatProviderEnabledChanged) == 0x350, "Offset mismatch for UFabricFloatProviderBase::OnFloatProviderEnabledChanged");
static_assert(offsetof(UFabricFloatProviderBase, CurrentFloat) == 0x360, "Offset mismatch for UFabricFloatProviderBase::CurrentFloat");
static_assert(offsetof(UFabricFloatProviderBase, MusicClock) == 0x364, "Offset mismatch for UFabricFloatProviderBase::MusicClock");
static_assert(offsetof(UFabricFloatProviderBase, AssociatedPatchWrapper) == 0x370, "Offset mismatch for UFabricFloatProviderBase::AssociatedPatchWrapper");
static_assert(offsetof(UFabricFloatProviderBase, EnabledParam) == 0x378, "Offset mismatch for UFabricFloatProviderBase::EnabledParam");
static_assert(offsetof(UFabricFloatProviderBase, bAlwaysModulates) == 0x388, "Offset mismatch for UFabricFloatProviderBase::bAlwaysModulates");
static_assert(offsetof(UFabricFloatProviderBase, bBindBlueprintOnFloatChanged) == 0x389, "Offset mismatch for UFabricFloatProviderBase::bBindBlueprintOnFloatChanged");
static_assert(offsetof(UFabricFloatProviderBase, bIsEnabled) == 0x38a, "Offset mismatch for UFabricFloatProviderBase::bIsEnabled");
static_assert(offsetof(UFabricFloatProviderBase, bModulatorValueChanged) == 0x38b, "Offset mismatch for UFabricFloatProviderBase::bModulatorValueChanged");

// Size: 0x328 (Inherited: 0x28, Single: 0x300)
class UFabricModulatable : public UObject
{
public:
    uint8_t Pad_28[0x4]; // 0x28 (Size: 0x4, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> ModulatedActor; // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<FString> ModulatorParams; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TSet<FName> NonModulatedParamsWithCallbacks; // 0x48 (Size: 0x50, Type: SetProperty)
    TMap<TWeakObjectPtr<UObject*>, FString> Modulators; // 0x98 (Size: 0x50, Type: MapProperty)
    TMap<FName, FName> LastBroadcastedValues; // 0xe8 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<UObject*>> ModulatorSources; // 0x138 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_148[0x1e0]; // 0x148 (Size: 0x1e0, Type: PaddingProperty)

private:
    void OnModulatedPropertyChanged(FString& Value, UObject*& ModulatorObject); // 0x111a6e80 (Index: 0x8, Flags: Final|Native|Private)
    void OnModulatorFloatProviderConnectionChanged(bool& bConnected, UObject*& ModulatorObject); // 0x111a7260 (Index: 0x9, Flags: Final|Native|Private)

protected:
    AActor* GetModulatedActor() const; // 0x111a4670 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool GetModulatedBool(FString& Param, const FMidiSongPos SongPos, bool& OutBool) const; // 0x111a4698 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetModulatedEnum(FString& Param, const FMidiSongPos SongPos, char& OutEnum) const; // 0x111a4b30 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetModulatedFloat(FString& Param, const FMidiSongPos SongPos, float& OutFloat) const; // 0x111a4fc8 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetModulatedInt(FString& Param, const FMidiSongPos SongPos, int32_t& OutInt) const; // 0x111a545c (Index: 0x4, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetModulatedString(FString& Param, const FMidiSongPos SongPos, FString& OutString) const; // 0x111a58f0 (Index: 0x5, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool IsParamModulated(FString& Param) const; // 0x111a63b0 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void OnAnyOptionUpdated(); // 0x111a679c (Index: 0x7, Flags: Final|Native|Protected)
    void OnOptionsLoaded(); // 0x111a679c (Index: 0xa, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricModulatable) == 0x328, "Size mismatch for UFabricModulatable");
static_assert(offsetof(UFabricModulatable, ModulatedActor) == 0x2c, "Offset mismatch for UFabricModulatable::ModulatedActor");
static_assert(offsetof(UFabricModulatable, ModulatorParams) == 0x38, "Offset mismatch for UFabricModulatable::ModulatorParams");
static_assert(offsetof(UFabricModulatable, NonModulatedParamsWithCallbacks) == 0x48, "Offset mismatch for UFabricModulatable::NonModulatedParamsWithCallbacks");
static_assert(offsetof(UFabricModulatable, Modulators) == 0x98, "Offset mismatch for UFabricModulatable::Modulators");
static_assert(offsetof(UFabricModulatable, LastBroadcastedValues) == 0xe8, "Offset mismatch for UFabricModulatable::LastBroadcastedValues");
static_assert(offsetof(UFabricModulatable, ModulatorSources) == 0x138, "Offset mismatch for UFabricModulatable::ModulatorSources");

// Size: 0x4e8 (Inherited: 0x6e0, Single: 0xfffffe08)
class UFabricFloatProviderWave : public UFabricFloatProviderBase
{
public:
    FString WaveShapeParam; // 0x390 (Size: 0x10, Type: StrProperty)
    FString FreeHzParam; // 0x3a0 (Size: 0x10, Type: StrProperty)
    FString MinParam; // 0x3b0 (Size: 0x10, Type: StrProperty)
    FString MaxParam; // 0x3c0 (Size: 0x10, Type: StrProperty)
    FString BeatDurationParam; // 0x3d0 (Size: 0x10, Type: StrProperty)
    FString BeatOffsetParam; // 0x3e0 (Size: 0x10, Type: StrProperty)
    FString ShapeParam; // 0x3f0 (Size: 0x10, Type: StrProperty)
    FString StyleParam; // 0x400 (Size: 0x10, Type: StrProperty)
    int32_t PhaseCPDIndex; // 0x410 (Size: 0x4, Type: IntProperty)
    int32_t ValueCPDIndex; // 0x414 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_418[0x80]; // 0x418 (Size: 0x80, Type: PaddingProperty)
    TSet<TWeakObjectPtr<UStaticMeshComponent*>> PreviewDisplayMeshes; // 0x498 (Size: 0x50, Type: SetProperty)

public:
    void AddPreviewDisplayMesh(UStaticMeshComponent*& Mesh); // 0x11196414 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ClearPreviewDisplayMeshes(); // 0x11196ad4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    float GetCurrentFreePhase() const; // 0x11196fa8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentPhase() const; // 0x11196fd0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UStaticMeshComponent*> GetPreviewDisplayMeshes(); // 0x11197a54 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    int32_t GetRandomSeed() const; // 0x10d203dc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemovePreviewDisplayMesh(UStaticMeshComponent*& Mesh); // 0x11198568 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetFreePhase(float& InFreePhase); // 0x11198afc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetRandomSeedByGuid(const FGuid InRandomGuid); // 0x1119938c (Index: 0x8, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFabricFloatProviderWave) == 0x4e8, "Size mismatch for UFabricFloatProviderWave");
static_assert(offsetof(UFabricFloatProviderWave, WaveShapeParam) == 0x390, "Offset mismatch for UFabricFloatProviderWave::WaveShapeParam");
static_assert(offsetof(UFabricFloatProviderWave, FreeHzParam) == 0x3a0, "Offset mismatch for UFabricFloatProviderWave::FreeHzParam");
static_assert(offsetof(UFabricFloatProviderWave, MinParam) == 0x3b0, "Offset mismatch for UFabricFloatProviderWave::MinParam");
static_assert(offsetof(UFabricFloatProviderWave, MaxParam) == 0x3c0, "Offset mismatch for UFabricFloatProviderWave::MaxParam");
static_assert(offsetof(UFabricFloatProviderWave, BeatDurationParam) == 0x3d0, "Offset mismatch for UFabricFloatProviderWave::BeatDurationParam");
static_assert(offsetof(UFabricFloatProviderWave, BeatOffsetParam) == 0x3e0, "Offset mismatch for UFabricFloatProviderWave::BeatOffsetParam");
static_assert(offsetof(UFabricFloatProviderWave, ShapeParam) == 0x3f0, "Offset mismatch for UFabricFloatProviderWave::ShapeParam");
static_assert(offsetof(UFabricFloatProviderWave, StyleParam) == 0x400, "Offset mismatch for UFabricFloatProviderWave::StyleParam");
static_assert(offsetof(UFabricFloatProviderWave, PhaseCPDIndex) == 0x410, "Offset mismatch for UFabricFloatProviderWave::PhaseCPDIndex");
static_assert(offsetof(UFabricFloatProviderWave, ValueCPDIndex) == 0x414, "Offset mismatch for UFabricFloatProviderWave::ValueCPDIndex");
static_assert(offsetof(UFabricFloatProviderWave, PreviewDisplayMeshes) == 0x498, "Offset mismatch for UFabricFloatProviderWave::PreviewDisplayMeshes");

// Size: 0x418 (Inherited: 0x6e0, Single: 0xfffffd38)
class UFabricFloatProviderStep : public UFabricFloatProviderBase
{
public:
    FString StepRateParam; // 0x390 (Size: 0x10, Type: StrProperty)
    FString ActiveStepsParam; // 0x3a0 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_3b0[0x10]; // 0x3b0 (Size: 0x10, Type: PaddingProperty)
    FString StepParamBase; // 0x3c0 (Size: 0x10, Type: StrProperty)
    int32_t MaxSteps; // 0x3d0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3d4[0x4]; // 0x3d4 (Size: 0x4, Type: PaddingProperty)
    FFabricStepGenerator RuntimeGenerator; // 0x3d8 (Size: 0x20, Type: StructProperty)
    uint8_t OnFloatProviderStepInitialized[0x10]; // 0x3f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_408[0x10]; // 0x408 (Size: 0x10, Type: PaddingProperty)

public:
    float GetStepLengthBeats() const; // 0x11197aac (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFabricFloatProviderStep) == 0x418, "Size mismatch for UFabricFloatProviderStep");
static_assert(offsetof(UFabricFloatProviderStep, StepRateParam) == 0x390, "Offset mismatch for UFabricFloatProviderStep::StepRateParam");
static_assert(offsetof(UFabricFloatProviderStep, ActiveStepsParam) == 0x3a0, "Offset mismatch for UFabricFloatProviderStep::ActiveStepsParam");
static_assert(offsetof(UFabricFloatProviderStep, StepParamBase) == 0x3c0, "Offset mismatch for UFabricFloatProviderStep::StepParamBase");
static_assert(offsetof(UFabricFloatProviderStep, MaxSteps) == 0x3d0, "Offset mismatch for UFabricFloatProviderStep::MaxSteps");
static_assert(offsetof(UFabricFloatProviderStep, RuntimeGenerator) == 0x3d8, "Offset mismatch for UFabricFloatProviderStep::RuntimeGenerator");
static_assert(offsetof(UFabricFloatProviderStep, OnFloatProviderStepInitialized) == 0x3f8, "Offset mismatch for UFabricFloatProviderStep::OnFloatProviderStepInitialized");

// Size: 0x430 (Inherited: 0x6e0, Single: 0xfffffd50)
class UFabricFloatProviderValueSetter : public UFabricFloatProviderBase
{
public:
    FString ValueParam; // 0x390 (Size: 0x10, Type: StrProperty)
    FString TransitionTimingParam; // 0x3a0 (Size: 0x10, Type: StrProperty)
    FString BlendParam; // 0x3b0 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_3c0[0x70]; // 0x3c0 (Size: 0x70, Type: PaddingProperty)

public:
    float BroadcastCurrentValue(float& OverriddenBeat); // 0x11196888 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    float CalculateTransitionTiming() const; // 0x111969c4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool CanUsePredictiveBeatBroadcasting() const; // 0x53bb30c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    float GetUpdateBeat() const; // 0x11197ad4 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFabricFloatProviderValueSetter) == 0x430, "Size mismatch for UFabricFloatProviderValueSetter");
static_assert(offsetof(UFabricFloatProviderValueSetter, ValueParam) == 0x390, "Offset mismatch for UFabricFloatProviderValueSetter::ValueParam");
static_assert(offsetof(UFabricFloatProviderValueSetter, TransitionTimingParam) == 0x3a0, "Offset mismatch for UFabricFloatProviderValueSetter::TransitionTimingParam");
static_assert(offsetof(UFabricFloatProviderValueSetter, BlendParam) == 0x3b0, "Offset mismatch for UFabricFloatProviderValueSetter::BlendParam");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricHoldable : public UInterface
{
public:
};

static_assert(sizeof(UFabricHoldable) == 0x28, "Size mismatch for UFabricHoldable");

// Size: 0x138 (Inherited: 0x198, Single: 0xffffffa0)
class UFabricIndicatorComponent : public UGameFrameworkComponent
{
public:
    uint8_t OnEnabledStateChanged[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* FabricTooltipWidgetType; // 0xc8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag TargetsChangedTag; // 0xd0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer HUDTagsToHide; // 0xd8 (Size: 0x20, Type: StructProperty)
    UFortInputMappingContext* IndicatorShowingInputContext; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    int32_t IndicatorShowingPriority; // 0x100 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_104[0x4]; // 0x104 (Size: 0x4, Type: PaddingProperty)
    UInputAction* ShowMoreAction; // 0x108 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_110[0x28]; // 0x110 (Size: 0x28, Type: PaddingProperty)

public:
    bool IsIndicatorEnabled() const; // 0x11197c40 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnIndicatorWidgetVisibilityChanged(ESlateVisibility& const NewVisibility); // 0x11198078 (Index: 0x2, Flags: Final|Native|Public)
    void OnShowMoreActionTriggered(const FInputActionInstance Instance); // 0x11198480 (Index: 0x3, Flags: Final|Native|Public|HasOutParms)
    void SetIndicatorEnabled(bool& bEnabled, bool& bAllowWriteToSettings); // 0x11198c28 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleTooltipsEnabledChanged(); // 0x11197aec (Index: 0x0, Flags: Final|Native|Protected)
    void TryGetFortClientSettings(); // 0x11199478 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricIndicatorComponent) == 0x138, "Size mismatch for UFabricIndicatorComponent");
static_assert(offsetof(UFabricIndicatorComponent, OnEnabledStateChanged) == 0xb8, "Offset mismatch for UFabricIndicatorComponent::OnEnabledStateChanged");
static_assert(offsetof(UFabricIndicatorComponent, FabricTooltipWidgetType) == 0xc8, "Offset mismatch for UFabricIndicatorComponent::FabricTooltipWidgetType");
static_assert(offsetof(UFabricIndicatorComponent, TargetsChangedTag) == 0xd0, "Offset mismatch for UFabricIndicatorComponent::TargetsChangedTag");
static_assert(offsetof(UFabricIndicatorComponent, HUDTagsToHide) == 0xd8, "Offset mismatch for UFabricIndicatorComponent::HUDTagsToHide");
static_assert(offsetof(UFabricIndicatorComponent, IndicatorShowingInputContext) == 0xf8, "Offset mismatch for UFabricIndicatorComponent::IndicatorShowingInputContext");
static_assert(offsetof(UFabricIndicatorComponent, IndicatorShowingPriority) == 0x100, "Offset mismatch for UFabricIndicatorComponent::IndicatorShowingPriority");
static_assert(offsetof(UFabricIndicatorComponent, ShowMoreAction) == 0x108, "Offset mismatch for UFabricIndicatorComponent::ShowMoreAction");

// Size: 0x178 (Inherited: 0xe0, Single: 0x98)
class UFabricInteractableControllerComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnNoInteractablesHit[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    AFortPlayerController* PlayerController; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UFortGadgetItemDefinition*> FabricInteractionToolItemDefSoftPtr; // 0xd8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortGadgetItemDefinition*> OverriddenFabricInteractionToolItemDefSoftPtr; // 0xf8 (Size: 0x20, Type: SoftObjectProperty)
    UFortGadgetItemDefinition* FabricInteractionToolItemDef; // 0x118 (Size: 0x8, Type: ObjectProperty)
    float EnsurePlayerHasInteractionToolRetryDelay; // 0x120 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_124[0x14]; // 0x124 (Size: 0x14, Type: PaddingProperty)
    TSoftClassPtr SoftFabricDeviceBaseClass; // 0x138 (Size: 0x20, Type: SoftClassProperty)
    FGameplayTagContainer StreamingMusicGameplayTags; // 0x158 (Size: 0x20, Type: StructProperty)

public:
    void EnsurePlayerHasInteractionTool(); // 0x11196f1c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void OnCreativeModeEnabledChangedDelegate(bool& bCreativeEnabled); // 0x9e6e1b8 (Index: 0x2, Flags: Final|Native|Public)
    virtual void ServerGivePlayerFabricInteractionTool(); // 0x270d644 (Index: 0x3, Flags: Net|NetReliableNative|Event|Public|NetServer)

private:
    virtual void ClientReceiveDoesIslandContainFabricDevices(bool& const bIslandContainsFabricDevices, bool& const bIslandContainsStreamingMusicFabricDevices); // 0x11196af0 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void ServerRequestDoesIslandContainFabricDevices(); // 0x43388fc (Index: 0x4, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
};

static_assert(sizeof(UFabricInteractableControllerComponent) == 0x178, "Size mismatch for UFabricInteractableControllerComponent");
static_assert(offsetof(UFabricInteractableControllerComponent, OnNoInteractablesHit) == 0xc0, "Offset mismatch for UFabricInteractableControllerComponent::OnNoInteractablesHit");
static_assert(offsetof(UFabricInteractableControllerComponent, PlayerController) == 0xd0, "Offset mismatch for UFabricInteractableControllerComponent::PlayerController");
static_assert(offsetof(UFabricInteractableControllerComponent, FabricInteractionToolItemDefSoftPtr) == 0xd8, "Offset mismatch for UFabricInteractableControllerComponent::FabricInteractionToolItemDefSoftPtr");
static_assert(offsetof(UFabricInteractableControllerComponent, OverriddenFabricInteractionToolItemDefSoftPtr) == 0xf8, "Offset mismatch for UFabricInteractableControllerComponent::OverriddenFabricInteractionToolItemDefSoftPtr");
static_assert(offsetof(UFabricInteractableControllerComponent, FabricInteractionToolItemDef) == 0x118, "Offset mismatch for UFabricInteractableControllerComponent::FabricInteractionToolItemDef");
static_assert(offsetof(UFabricInteractableControllerComponent, EnsurePlayerHasInteractionToolRetryDelay) == 0x120, "Offset mismatch for UFabricInteractableControllerComponent::EnsurePlayerHasInteractionToolRetryDelay");
static_assert(offsetof(UFabricInteractableControllerComponent, SoftFabricDeviceBaseClass) == 0x138, "Offset mismatch for UFabricInteractableControllerComponent::SoftFabricDeviceBaseClass");
static_assert(offsetof(UFabricInteractableControllerComponent, StreamingMusicGameplayTags) == 0x158, "Offset mismatch for UFabricInteractableControllerComponent::StreamingMusicGameplayTags");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricInteractable : public UInterface
{
public:

public:
    virtual bool CanInteractWithHoldable(const TScriptInterface<Class> Holdable); // 0x111969ec (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual bool DoesInteractionRequireHoldable() const; // 0xd7b0dec (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void EndInteraction(APlayerController*& PlayerController, bool& bWasDragAndDropInteraction); // 0x11196d10 (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual EFabricContinuousInteractionDirection GetContinuousInteractableDirection(); // 0x4dd0574 (Index: 0x3, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual float GetContinuousInteractableValueNormalized(); // 0xff10674 (Index: 0x4, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual FVector GetInteractableComponentLocation(USceneComponent*& Interactable); // 0x111975c4 (Index: 0x5, Flags: Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void GetInteractableDescription(FText& OutDescription) const; // 0x11197714 (Index: 0x6, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual FVector GetInteractableForwardVector(USceneComponent*& Interactable); // 0x1119780c (Index: 0x7, Flags: Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void GetInteractableName(FText& OutName) const; // 0x1119795c (Index: 0x8, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual EFabricInteractableType GetInteractableType(); // 0xa672d10 (Index: 0x9, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual UAudioComponent* GetInteractionSFX(); // 0xe746140 (Index: 0xa, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual UObject* GetLinkedInteractable(); // 0x5798458 (Index: 0xb, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual bool IsFocusDependentOnInteractionContext(APlayerController*& Controller); // 0x11197b00 (Index: 0xc, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual bool IsValidToInteractWith(APlayerController*& Controller, FGameplayTagContainer& OutReasonTags); // 0x11197c68 (Index: 0xd, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void OnInteractionFocusTargetChanged(APlayerController*& Controller, UObject*& FocusTarget, bool& bIsFocused); // 0x111981a4 (Index: 0xe, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void SetFocused(bool& bIsFocused); // 0x5819438 (Index: 0xf, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void SetHitComponent(USceneComponent*& HitComponent); // 0xcc88e1c (Index: 0x10, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void SetInteractable(bool& bInteractable); // 0x11198e44 (Index: 0x11, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual bool ShouldPassInteractionToComponent(AFabricInteractionTool*& InteractionTool); // 0xf960bdc (Index: 0x12, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void StartInteraction(APlayerController*& Controller); // 0x57640b8 (Index: 0x13, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void StartSpecialInteraction(APlayerController*& Controller); // 0xb47bf8c (Index: 0x14, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UFabricInteractable) == 0x28, "Size mismatch for UFabricInteractable");

// Size: 0x108 (Inherited: 0x250, Single: 0xfffffeb8)
class UFabricInteractablePlayspaceComponent : public UPlayspaceComponent
{
public:

public:
    void SetFabricDeviceExistsInPlayspace(); // 0x1119b2a8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnDownloadOnDemandCompleteIndividualClient(FEventMessageTag& Channel, const FClientFinishedDownloadOnDemand Context); // 0x1119a580 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnPlayspaceUserAdded(const FPlayspaceUser PlayspaceUser); // 0x1119a708 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFabricInteractablePlayspaceComponent) == 0x108, "Size mismatch for UFabricInteractablePlayspaceComponent");

// Size: 0x2790 (Inherited: 0x4220, Single: 0xffffe570)
class AFabricInteractionTool : public AFortWeaponRanged
{
public:
    uint8_t OnInteractionStateChanged[0x10]; // 0x2590 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCablesGrabbed[0x10]; // 0x25a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCablesDropped[0x10]; // 0x25b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMetasoundGeneratorCrossfadeStarted[0x10]; // 0x25c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnZoomLevelChanged[0x10]; // 0x25d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* FITSplineMeshComponentClass; // 0x25e0 (Size: 0x8, Type: ClassProperty)
    USplineComponent* SplineComponent; // 0x25e8 (Size: 0x8, Type: ObjectProperty)
    TArray<USplineMeshComponent*> SplineMeshComponentArray; // 0x25f0 (Size: 0x10, Type: ArrayProperty)
    UMaterialInstanceDynamic* SplineMeshMaterialInstance; // 0x2600 (Size: 0x8, Type: ObjectProperty)
    float MaxRange; // 0x2608 (Size: 0x4, Type: FloatProperty)
    float MinDragAndDropTriggerTime; // 0x260c (Size: 0x4, Type: FloatProperty)
    float FiringRate; // 0x2610 (Size: 0x4, Type: FloatProperty)
    float WipeAnim; // 0x2614 (Size: 0x4, Type: FloatProperty)
    float UseWipe; // 0x2618 (Size: 0x4, Type: FloatProperty)
    int32_t SplineMeshMaterialIndex; // 0x261c (Size: 0x4, Type: IntProperty)
    int32_t CPDUVScale; // 0x2620 (Size: 0x4, Type: IntProperty)
    int32_t CPDUVPosition; // 0x2624 (Size: 0x4, Type: IntProperty)
    int32_t CPDWipeAnim; // 0x2628 (Size: 0x4, Type: IntProperty)
    int32_t CPDUseWipe; // 0x262c (Size: 0x4, Type: IntProperty)
    int32_t CPDIndex_DeviceType; // 0x2630 (Size: 0x4, Type: IntProperty)
    float SplineSectionLength; // 0x2634 (Size: 0x4, Type: FloatProperty)
    int32_t MaxSplineSpawnedInAFrame; // 0x2638 (Size: 0x4, Type: IntProperty)
    float DeviceTypeValue; // 0x263c (Size: 0x4, Type: FloatProperty)
    float FITTargetingAudioPitchMultiplier; // 0x2640 (Size: 0x4, Type: FloatProperty)
    float FITZoomAudioPitchMultiplier; // 0x2644 (Size: 0x4, Type: FloatProperty)
    float SplineEndForwardMultiplier; // 0x2648 (Size: 0x4, Type: FloatProperty)
    float SplineStartForwardMultiplier; // 0x264c (Size: 0x4, Type: FloatProperty)
    UObject* HoveredInteractable; // 0x2650 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* HoveredInteractableHitComponent; // 0x2658 (Size: 0x8, Type: ObjectProperty)
    UObject* PressedInteractable; // 0x2660 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UObject*> LastPressedInteractable; // 0x2668 (Size: 0x8, Type: WeakObjectProperty)
    USceneComponent* PressedInteractableHitComponent; // 0x2670 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortCreativeDeviceProp*> InteractableOwnerDevice; // 0x2678 (Size: 0x8, Type: WeakObjectProperty)
    float AccumulatedDragAndDropTriggerTime; // 0x2680 (Size: 0x4, Type: FloatProperty)
    FInteractionData ServerInteractionData; // 0x2684 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_2690[0x11]; // 0x2690 (Size: 0x11, Type: PaddingProperty)
    bool bServerTriggerPressed; // 0x26a1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26a2[0x1]; // 0x26a2 (Size: 0x1, Type: PaddingProperty)
    bool bServerIsHoldingCable; // 0x26a3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26a4[0x14]; // 0x26a4 (Size: 0x14, Type: PaddingProperty)
    FInteractionSplinePoints ServerSplinePoints; // 0x26b8 (Size: 0x60, Type: StructProperty)
    float ServerContinuousInteractableValue; // 0x2718 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_271c[0x74]; // 0x271c (Size: 0x74, Type: PaddingProperty)

public:
    void ClearSplineMesh(); // 0x11199e2c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void HandleMetasoundGeneratorCrossfade(float& CrossfadeSeconds); // 0x1119a194 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    bool IsHoldingCables(); // 0x1119a2d0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsRunningOnOwningClient() const; // 0x1119a2e8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual bool IsZoomed() const; // 0x4c4e47c (Index: 0xf, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void OnCableHeldStateChanged__DelegateSignature(AFortCreativeDeviceProp*& Device); // 0x288a61c (Index: 0x11, Flags: MulticastDelegate|Public|Delegate)
    void OnInteractionStateChanged__DelegateSignature(EFabricInteractionToolStates& NewState, AFortCreativeDeviceProp*& Device); // 0x288a61c (Index: 0x12, Flags: MulticastDelegate|Public|Delegate)
    void OnMetasoundGeneratorCrossfadeStarted__DelegateSignature(float& CrossfadeSeconds); // 0x288a61c (Index: 0x13, Flags: MulticastDelegate|Public|Delegate)
    void OnZoomLevelChanged__DelegateSignature(bool& IsZoomed); // 0x288a61c (Index: 0x19, Flags: MulticastDelegate|Public|Delegate)
    virtual void ServerPlayInteractionSoundOnClients(USoundBase*& Sound, FVector& const Location, USoundAttenuation*& AttenuationSettings, APawn*& const InstigatingPawn) const; // 0x1119a93c (Index: 0x1b, Flags: Net|Native|Event|Public|NetServer|HasDefaults|BlueprintCallable|Const)
    void UpdateSplineMesh(); // 0x1119b71c (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void ClientDeactiveWeaponAndState(); // 0x11199e40 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientStopInteracting(); // 0xe82f87c (Index: 0x2, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    void DeactiveWeaponAndState(); // 0xe82f93c (Index: 0x3, Flags: Native|Protected|BlueprintCallable)
    float GetContinuousInteractableValueNormalized(); // 0x11199ffc (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    EFabricContinuousInteractionDirection GetContinuousInteractionDirection(); // 0x1119a014 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable)
    float GetContinuousMovementValue(); // 0x1119a0a4 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    int32_t GetContinuousStateValue(); // 0x1119a0cc (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    EFabricInteractionToolStates GetFabricInteractionToolState(); // 0x1119a10c (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    USceneComponent* GetHoveredInteractableHitComponent(); // 0x1119a124 (Index: 0x9, Flags: Final|Native|Protected|BlueprintCallable)
    EFabricInteractableType GetHoveredInteractableType(); // 0x1119a13c (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable)
    UObject* GetPressedInteractable(); // 0x1119a17c (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void MulticastPlayInteractionSound(USoundBase*& Sound, FVector& const Location, USoundAttenuation*& AttenuationSettings, APawn*& const InstigatingPawn) const; // 0x1119a30c (Index: 0x10, Flags: Net|Native|Event|NetMulticast|Protected|HasDefaults|Const)
    void OnRep_ServerContinuousInteractableValue(); // 0x1119a80c (Index: 0x14, Flags: Final|Native|Protected)
    void OnRep_ServerInteractionData(); // 0x1119a840 (Index: 0x15, Flags: Final|Native|Protected)
    void OnRep_ServerIsHoldingCable(); // 0x1119a85c (Index: 0x16, Flags: Final|Native|Protected)
    void OnRep_ServerTriggerPressed(); // 0x1119a8c0 (Index: 0x17, Flags: Final|Native|Protected)
    virtual void OnSplineUpdated(EFabricInteractionToolStates& NewInteractionState); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual void ServerHandleFITFired(); // 0x1119a924 (Index: 0x1a, Flags: Net|Native|Event|Protected|NetServer)
    virtual void ServerSetContinuousInteractableValue(float& Value); // 0x1119abc4 (Index: 0x1c, Flags: Net|Native|Event|Protected|NetServer)
    virtual void ServerSetInteractionData(FInteractionData& NewData); // 0x1119acf4 (Index: 0x1d, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerSetIsHoldingCable(bool& bHoldingCable); // 0x1119add4 (Index: 0x1e, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerSetSplinePoints(FInteractionSplinePoints& SplinePoints); // 0x1119af04 (Index: 0x1f, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerSetTriggerPressed(bool& bPressed); // 0x1119b04c (Index: 0x20, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    void SetPitchMultipliersForTargetingSounds(bool& bIsTargetingNow); // 0x1119b31c (Index: 0x21, Flags: Final|Native|Protected)
    void UnholsterWeapon(); // 0x1119b708 (Index: 0x22, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AFabricInteractionTool) == 0x2790, "Size mismatch for AFabricInteractionTool");
static_assert(offsetof(AFabricInteractionTool, OnInteractionStateChanged) == 0x2590, "Offset mismatch for AFabricInteractionTool::OnInteractionStateChanged");
static_assert(offsetof(AFabricInteractionTool, OnCablesGrabbed) == 0x25a0, "Offset mismatch for AFabricInteractionTool::OnCablesGrabbed");
static_assert(offsetof(AFabricInteractionTool, OnCablesDropped) == 0x25b0, "Offset mismatch for AFabricInteractionTool::OnCablesDropped");
static_assert(offsetof(AFabricInteractionTool, OnMetasoundGeneratorCrossfadeStarted) == 0x25c0, "Offset mismatch for AFabricInteractionTool::OnMetasoundGeneratorCrossfadeStarted");
static_assert(offsetof(AFabricInteractionTool, OnZoomLevelChanged) == 0x25d0, "Offset mismatch for AFabricInteractionTool::OnZoomLevelChanged");
static_assert(offsetof(AFabricInteractionTool, FITSplineMeshComponentClass) == 0x25e0, "Offset mismatch for AFabricInteractionTool::FITSplineMeshComponentClass");
static_assert(offsetof(AFabricInteractionTool, SplineComponent) == 0x25e8, "Offset mismatch for AFabricInteractionTool::SplineComponent");
static_assert(offsetof(AFabricInteractionTool, SplineMeshComponentArray) == 0x25f0, "Offset mismatch for AFabricInteractionTool::SplineMeshComponentArray");
static_assert(offsetof(AFabricInteractionTool, SplineMeshMaterialInstance) == 0x2600, "Offset mismatch for AFabricInteractionTool::SplineMeshMaterialInstance");
static_assert(offsetof(AFabricInteractionTool, MaxRange) == 0x2608, "Offset mismatch for AFabricInteractionTool::MaxRange");
static_assert(offsetof(AFabricInteractionTool, MinDragAndDropTriggerTime) == 0x260c, "Offset mismatch for AFabricInteractionTool::MinDragAndDropTriggerTime");
static_assert(offsetof(AFabricInteractionTool, FiringRate) == 0x2610, "Offset mismatch for AFabricInteractionTool::FiringRate");
static_assert(offsetof(AFabricInteractionTool, WipeAnim) == 0x2614, "Offset mismatch for AFabricInteractionTool::WipeAnim");
static_assert(offsetof(AFabricInteractionTool, UseWipe) == 0x2618, "Offset mismatch for AFabricInteractionTool::UseWipe");
static_assert(offsetof(AFabricInteractionTool, SplineMeshMaterialIndex) == 0x261c, "Offset mismatch for AFabricInteractionTool::SplineMeshMaterialIndex");
static_assert(offsetof(AFabricInteractionTool, CPDUVScale) == 0x2620, "Offset mismatch for AFabricInteractionTool::CPDUVScale");
static_assert(offsetof(AFabricInteractionTool, CPDUVPosition) == 0x2624, "Offset mismatch for AFabricInteractionTool::CPDUVPosition");
static_assert(offsetof(AFabricInteractionTool, CPDWipeAnim) == 0x2628, "Offset mismatch for AFabricInteractionTool::CPDWipeAnim");
static_assert(offsetof(AFabricInteractionTool, CPDUseWipe) == 0x262c, "Offset mismatch for AFabricInteractionTool::CPDUseWipe");
static_assert(offsetof(AFabricInteractionTool, CPDIndex_DeviceType) == 0x2630, "Offset mismatch for AFabricInteractionTool::CPDIndex_DeviceType");
static_assert(offsetof(AFabricInteractionTool, SplineSectionLength) == 0x2634, "Offset mismatch for AFabricInteractionTool::SplineSectionLength");
static_assert(offsetof(AFabricInteractionTool, MaxSplineSpawnedInAFrame) == 0x2638, "Offset mismatch for AFabricInteractionTool::MaxSplineSpawnedInAFrame");
static_assert(offsetof(AFabricInteractionTool, DeviceTypeValue) == 0x263c, "Offset mismatch for AFabricInteractionTool::DeviceTypeValue");
static_assert(offsetof(AFabricInteractionTool, FITTargetingAudioPitchMultiplier) == 0x2640, "Offset mismatch for AFabricInteractionTool::FITTargetingAudioPitchMultiplier");
static_assert(offsetof(AFabricInteractionTool, FITZoomAudioPitchMultiplier) == 0x2644, "Offset mismatch for AFabricInteractionTool::FITZoomAudioPitchMultiplier");
static_assert(offsetof(AFabricInteractionTool, SplineEndForwardMultiplier) == 0x2648, "Offset mismatch for AFabricInteractionTool::SplineEndForwardMultiplier");
static_assert(offsetof(AFabricInteractionTool, SplineStartForwardMultiplier) == 0x264c, "Offset mismatch for AFabricInteractionTool::SplineStartForwardMultiplier");
static_assert(offsetof(AFabricInteractionTool, HoveredInteractable) == 0x2650, "Offset mismatch for AFabricInteractionTool::HoveredInteractable");
static_assert(offsetof(AFabricInteractionTool, HoveredInteractableHitComponent) == 0x2658, "Offset mismatch for AFabricInteractionTool::HoveredInteractableHitComponent");
static_assert(offsetof(AFabricInteractionTool, PressedInteractable) == 0x2660, "Offset mismatch for AFabricInteractionTool::PressedInteractable");
static_assert(offsetof(AFabricInteractionTool, LastPressedInteractable) == 0x2668, "Offset mismatch for AFabricInteractionTool::LastPressedInteractable");
static_assert(offsetof(AFabricInteractionTool, PressedInteractableHitComponent) == 0x2670, "Offset mismatch for AFabricInteractionTool::PressedInteractableHitComponent");
static_assert(offsetof(AFabricInteractionTool, InteractableOwnerDevice) == 0x2678, "Offset mismatch for AFabricInteractionTool::InteractableOwnerDevice");
static_assert(offsetof(AFabricInteractionTool, AccumulatedDragAndDropTriggerTime) == 0x2680, "Offset mismatch for AFabricInteractionTool::AccumulatedDragAndDropTriggerTime");
static_assert(offsetof(AFabricInteractionTool, ServerInteractionData) == 0x2684, "Offset mismatch for AFabricInteractionTool::ServerInteractionData");
static_assert(offsetof(AFabricInteractionTool, bServerTriggerPressed) == 0x26a1, "Offset mismatch for AFabricInteractionTool::bServerTriggerPressed");
static_assert(offsetof(AFabricInteractionTool, bServerIsHoldingCable) == 0x26a3, "Offset mismatch for AFabricInteractionTool::bServerIsHoldingCable");
static_assert(offsetof(AFabricInteractionTool, ServerSplinePoints) == 0x26b8, "Offset mismatch for AFabricInteractionTool::ServerSplinePoints");
static_assert(offsetof(AFabricInteractionTool, ServerContinuousInteractableValue) == 0x2718, "Offset mismatch for AFabricInteractionTool::ServerContinuousInteractableValue");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricIslandSettingsInitializedInterface : public UInterface
{
public:

public:
    virtual void OnFabricIslandSettingsInitialized(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricIslandSettingsInitializedInterface) == 0x28, "Size mismatch for UFabricIslandSettingsInitializedInterface");

// Size: 0x330 (Inherited: 0x350, Single: 0xffffffe0)
class UFabricMeshModifierBase : public UFabricModulatable
{
public:
    uint8_t CloneBehavior; // 0x328 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_329[0x7]; // 0x329 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFabricMeshModifierBase) == 0x330, "Size mismatch for UFabricMeshModifierBase");
static_assert(offsetof(UFabricMeshModifierBase, CloneBehavior) == 0x328, "Offset mismatch for UFabricMeshModifierBase::CloneBehavior");

// Size: 0x348 (Inherited: 0x680, Single: 0xfffffcc8)
class UFabricMeshModifierTranslate : public UFabricMeshModifierBase
{
public:
    FVector PositionOffset; // 0x330 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFabricMeshModifierTranslate) == 0x348, "Size mismatch for UFabricMeshModifierTranslate");
static_assert(offsetof(UFabricMeshModifierTranslate, PositionOffset) == 0x330, "Offset mismatch for UFabricMeshModifierTranslate::PositionOffset");

// Size: 0x348 (Inherited: 0x680, Single: 0xfffffcc8)
class UFabricMeshModifierRotate : public UFabricMeshModifierBase
{
public:
    FRotator RotationAmount; // 0x330 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFabricMeshModifierRotate) == 0x348, "Size mismatch for UFabricMeshModifierRotate");
static_assert(offsetof(UFabricMeshModifierRotate, RotationAmount) == 0x330, "Offset mismatch for UFabricMeshModifierRotate::RotationAmount");

// Size: 0x348 (Inherited: 0x680, Single: 0xfffffcc8)
class UFabricMeshModifierScale : public UFabricMeshModifierBase
{
public:
    FVector ScaleFactor; // 0x330 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFabricMeshModifierScale) == 0x348, "Size mismatch for UFabricMeshModifierScale");
static_assert(offsetof(UFabricMeshModifierScale, ScaleFactor) == 0x330, "Offset mismatch for UFabricMeshModifierScale::ScaleFactor");

// Size: 0x358 (Inherited: 0x680, Single: 0xfffffcd8)
class UFabricMeshModifierClone : public UFabricMeshModifierBase
{
public:
    int32_t CloneCount; // 0x330 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_334[0x4]; // 0x334 (Size: 0x4, Type: PaddingProperty)
    FVector PerCloneTranslation; // 0x338 (Size: 0x18, Type: StructProperty)
    bool bCentered; // 0x350 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_351[0x7]; // 0x351 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFabricMeshModifierClone) == 0x358, "Size mismatch for UFabricMeshModifierClone");
static_assert(offsetof(UFabricMeshModifierClone, CloneCount) == 0x330, "Offset mismatch for UFabricMeshModifierClone::CloneCount");
static_assert(offsetof(UFabricMeshModifierClone, PerCloneTranslation) == 0x338, "Offset mismatch for UFabricMeshModifierClone::PerCloneTranslation");
static_assert(offsetof(UFabricMeshModifierClone, bCentered) == 0x350, "Offset mismatch for UFabricMeshModifierClone::bCentered");

// Size: 0x398 (Inherited: 0x680, Single: 0xfffffd18)
class UFabricMeshModifierRandomize : public UFabricMeshModifierBase
{
public:
    float LocationRandLimit; // 0x330 (Size: 0x4, Type: FloatProperty)
    float RotationRandLimit; // 0x334 (Size: 0x4, Type: FloatProperty)
    float ScaleRandLimit; // 0x338 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_33c[0x4]; // 0x33c (Size: 0x4, Type: PaddingProperty)
    FVector LocationRandRange; // 0x340 (Size: 0x18, Type: StructProperty)
    FVector RotationRandRange; // 0x358 (Size: 0x18, Type: StructProperty)
    FVector ScaleRandRangeAdditive; // 0x370 (Size: 0x18, Type: StructProperty)
    float ScaleRandRangeRangeBase; // 0x388 (Size: 0x4, Type: FloatProperty)
    bool bUniformScale; // 0x38c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_38d[0x3]; // 0x38d (Size: 0x3, Type: PaddingProperty)
    FRandomStream RandomStream; // 0x390 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UFabricMeshModifierRandomize) == 0x398, "Size mismatch for UFabricMeshModifierRandomize");
static_assert(offsetof(UFabricMeshModifierRandomize, LocationRandLimit) == 0x330, "Offset mismatch for UFabricMeshModifierRandomize::LocationRandLimit");
static_assert(offsetof(UFabricMeshModifierRandomize, RotationRandLimit) == 0x334, "Offset mismatch for UFabricMeshModifierRandomize::RotationRandLimit");
static_assert(offsetof(UFabricMeshModifierRandomize, ScaleRandLimit) == 0x338, "Offset mismatch for UFabricMeshModifierRandomize::ScaleRandLimit");
static_assert(offsetof(UFabricMeshModifierRandomize, LocationRandRange) == 0x340, "Offset mismatch for UFabricMeshModifierRandomize::LocationRandRange");
static_assert(offsetof(UFabricMeshModifierRandomize, RotationRandRange) == 0x358, "Offset mismatch for UFabricMeshModifierRandomize::RotationRandRange");
static_assert(offsetof(UFabricMeshModifierRandomize, ScaleRandRangeAdditive) == 0x370, "Offset mismatch for UFabricMeshModifierRandomize::ScaleRandRangeAdditive");
static_assert(offsetof(UFabricMeshModifierRandomize, ScaleRandRangeRangeBase) == 0x388, "Offset mismatch for UFabricMeshModifierRandomize::ScaleRandRangeRangeBase");
static_assert(offsetof(UFabricMeshModifierRandomize, bUniformScale) == 0x38c, "Offset mismatch for UFabricMeshModifierRandomize::bUniformScale");
static_assert(offsetof(UFabricMeshModifierRandomize, RandomStream) == 0x390, "Offset mismatch for UFabricMeshModifierRandomize::RandomStream");

// Size: 0xa8 (Inherited: 0x28, Single: 0x80)
class UFabricMeshTreeNode : public UObject
{
public:
    UFabricMeshModifierBase* MeshModifier; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FFabricMeshProviderMeshReferenceParams Params; // 0x30 (Size: 0x28, Type: StructProperty)
    FFabricMeshProviderMeshReference MeshProviderReference; // 0x58 (Size: 0x38, Type: StructProperty)
    TArray<UFabricMeshTreeNode*> Children; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint32_t LastCalculatedChecksum; // 0xa0 (Size: 0x4, Type: UInt32Property)
    bool bAllowChecksumCalculation; // 0xa4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a5[0x3]; // 0xa5 (Size: 0x3, Type: PaddingProperty)

public:
    void CopyProperties(UFabricMeshTreeNode*& const Other); // 0x11199e58 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FFabricMeshInstanceReference> GenerateMeshInstanceReferences() const; // 0x11199f84 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Reset(); // 0x1119a910 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMeshTreeNode) == 0xa8, "Size mismatch for UFabricMeshTreeNode");
static_assert(offsetof(UFabricMeshTreeNode, MeshModifier) == 0x28, "Offset mismatch for UFabricMeshTreeNode::MeshModifier");
static_assert(offsetof(UFabricMeshTreeNode, Params) == 0x30, "Offset mismatch for UFabricMeshTreeNode::Params");
static_assert(offsetof(UFabricMeshTreeNode, MeshProviderReference) == 0x58, "Offset mismatch for UFabricMeshTreeNode::MeshProviderReference");
static_assert(offsetof(UFabricMeshTreeNode, Children) == 0x90, "Offset mismatch for UFabricMeshTreeNode::Children");
static_assert(offsetof(UFabricMeshTreeNode, LastCalculatedChecksum) == 0xa0, "Offset mismatch for UFabricMeshTreeNode::LastCalculatedChecksum");
static_assert(offsetof(UFabricMeshTreeNode, bAllowChecksumCalculation) == 0xa4, "Offset mismatch for UFabricMeshTreeNode::bAllowChecksumCalculation");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class UFabricMeshProviderBase : public UObject
{
public:
    FFabricMeshProviderMeshReference ReferenceMesh; // 0x28 (Size: 0x38, Type: StructProperty)
    TArray<FTransform> InstanceMeshes; // 0x60 (Size: 0x10, Type: ArrayProperty)
    float CurrentCableFloatValue; // 0x70 (Size: 0x4, Type: FloatProperty)
    float CurrentCableFloatDirection; // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bCurrentCableFloatDirty; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)

public:
    void SetReferenceMesh(const FFabricMeshProviderMeshReference InMesh); // 0x1119b448 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFabricMeshProviderBase) == 0x80, "Size mismatch for UFabricMeshProviderBase");
static_assert(offsetof(UFabricMeshProviderBase, ReferenceMesh) == 0x28, "Offset mismatch for UFabricMeshProviderBase::ReferenceMesh");
static_assert(offsetof(UFabricMeshProviderBase, InstanceMeshes) == 0x60, "Offset mismatch for UFabricMeshProviderBase::InstanceMeshes");
static_assert(offsetof(UFabricMeshProviderBase, CurrentCableFloatValue) == 0x70, "Offset mismatch for UFabricMeshProviderBase::CurrentCableFloatValue");
static_assert(offsetof(UFabricMeshProviderBase, CurrentCableFloatDirection) == 0x74, "Offset mismatch for UFabricMeshProviderBase::CurrentCableFloatDirection");
static_assert(offsetof(UFabricMeshProviderBase, bCurrentCableFloatDirty) == 0x78, "Offset mismatch for UFabricMeshProviderBase::bCurrentCableFloatDirty");

// Size: 0x828 (Inherited: 0xae8, Single: 0xfffffd40)
class UFabricMetaSoundAudioPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    uint8_t Pad_798[0x8]; // 0x798 (Size: 0x8, Type: PaddingProperty)
    TSoftObjectPtr<UMetaSoundPatch*> FromStartPatch; // 0x7a0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> FromCurrentPatch; // 0x7c0 (Size: 0x20, Type: SoftObjectProperty)
    UMetaSoundPatch* LoadedFromStartPatch; // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* LoadedFromCurrentPatch; // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    FName VolumeInputName; // 0x7f0 (Size: 0x4, Type: NameProperty)
    FName LoopAudioInputName; // 0x7f4 (Size: 0x4, Type: NameProperty)
    FName StartTimeInputName; // 0x7f8 (Size: 0x4, Type: NameProperty)
    FName StartTimestampInputName; // 0x7fc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_800[0x28]; // 0x800 (Size: 0x28, Type: PaddingProperty)

public:
    void SetAudio(USoundBase*& InAudio); // 0x1119b17c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMetaSoundAudioPatchWrapper) == 0x828, "Size mismatch for UFabricMetaSoundAudioPatchWrapper");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, FromStartPatch) == 0x7a0, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::FromStartPatch");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, FromCurrentPatch) == 0x7c0, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::FromCurrentPatch");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, LoadedFromStartPatch) == 0x7e0, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::LoadedFromStartPatch");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, LoadedFromCurrentPatch) == 0x7e8, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::LoadedFromCurrentPatch");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, VolumeInputName) == 0x7f0, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::VolumeInputName");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, LoopAudioInputName) == 0x7f4, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::LoopAudioInputName");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, StartTimeInputName) == 0x7f8, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::StartTimeInputName");
static_assert(offsetof(UFabricMetaSoundAudioPatchWrapper, StartTimestampInputName) == 0x7fc, "Offset mismatch for UFabricMetaSoundAudioPatchWrapper::StartTimestampInputName");

// Size: 0x798 (Inherited: 0x350, Single: 0x448)
class UFabricMetaSoundPatchWrapper : public UFabricModulatable
{
public:
    FName EnabledStateInputName; // 0x328 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_32c[0x4]; // 0x32c (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UMetaSoundPatch*> MetaSoundPatch; // 0x330 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FName, FString> UserOptionsToNodeInputs; // 0x350 (Size: 0x50, Type: MapProperty)
    TArray<FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning> PerPlatformInputBools; // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning> PerPlatformInputInts; // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning> PerPlatformInputFloats; // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMetaSoundDirectInputInfo> DirectInputs; // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    FFabricMetaSoundPatchWrapperBinding SimpleSignalOutputBinding; // 0x3e0 (Size: 0x50, Type: StructProperty)
    uint8_t OnSimpleSignalBindingUpdate[0x10]; // 0x430 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FName VisibleInputParamName; // 0x440 (Size: 0x4, Type: NameProperty)
    FName AudibleInputParamName; // 0x444 (Size: 0x4, Type: NameProperty)
    bool bCanConsumeVisibleFlag; // 0x448 (Size: 0x1, Type: BoolProperty)
    bool bCanConsumeAudibleFlag; // 0x449 (Size: 0x1, Type: BoolProperty)
    bool bIsVisible; // 0x44a (Size: 0x1, Type: BoolProperty)
    bool bIsAudible; // 0x44b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_44c[0x24]; // 0x44c (Size: 0x24, Type: PaddingProperty)
    uint8_t OnMaxAttenuationChanged[0x10]; // 0x470 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMetaSoundOutputIntChangedBatch[0x10]; // 0x480 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMetaSoundOutputFloatChangedBatch[0x10]; // 0x490 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UFabricMetaSoundManagerComponent* CurrentManager; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundTickSubsystem*> TickSubsystem; // 0x4a8 (Size: 0x8, Type: WeakObjectProperty)
    FFabricMetaSoundNodeInfo CurrentNode; // 0x4b0 (Size: 0xf0, Type: StructProperty)
    TWeakObjectPtr<AActor*> PositionalProxyActor; // 0x5a0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_5a8[0x20]; // 0x5a8 (Size: 0x20, Type: PaddingProperty)
    TWeakObjectPtr<UAudioComponent*> CurrentAudioComponent; // 0x5c8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAudioComponent*> NewAudioComponent; // 0x5d0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_5d8[0x10]; // 0x5d8 (Size: 0x10, Type: PaddingProperty)
    FName CombinerMetaSoundType; // 0x5e8 (Size: 0x4, Type: NameProperty)
    FName AnalyzerMetaSoundType; // 0x5ec (Size: 0x4, Type: NameProperty)
    TArray<FFabricMetaSoundRuntimeInputInfo> MetaSoundRuntimeInputInfos; // 0x5f0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> ConnectedInputWrappers; // 0x600 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> PendingInputWrappers; // 0x610 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> PendingOutputWrappers; // 0x620 (Size: 0x10, Type: ArrayProperty)
    FFabricMetaSoundConnectionBuilder ConnectionBuilder; // 0x630 (Size: 0xc0, Type: StructProperty)
    uint8_t Pad_6f0[0x50]; // 0x6f0 (Size: 0x50, Type: PaddingProperty)
    TArray<FMetaSoundCombinerNodeHandle> CombinersInUse; // 0x740 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> ConnectedOutputWrappers; // 0x750 (Size: 0x10, Type: ArrayProperty)
    uint8_t PatchWrapperQuality; // 0x760 (Size: 0x1, Type: EnumProperty)
    uint8_t MaxAttenuation; // 0x761 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_762[0x16]; // 0x762 (Size: 0x16, Type: PaddingProperty)
    UMetaSoundPatch* LoadedMetaSoundPatch; // 0x778 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_780[0x18]; // 0x780 (Size: 0x18, Type: PaddingProperty)

public:
    void AddToManagerGraph(UFabricMetaSoundManagerComponent*& Manager); // 0xa130e8c (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    EFabricMetaSoundMaxAttenuation GetMaxAttenuation() const; // 0x11082ca4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TSet<FName> GetMetaSoundInputNames() const; // 0x111a1238 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMusicClockComponent* GetMusicClock() const; // 0x111a1318 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetNodeCanBePooled() const; // 0x111a1338 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetNodeEnabled() const; // 0x111a1350 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricMetaSoundPatchWrapperQuality GetPatchWrapperQuality() const; // 0x111a1368 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetRunsOnServer() const; // 0x111a1380 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveFromCurrentGraph(); // 0x111a2208 (Index: 0x13, Flags: Native|Public|BlueprintCallable)
    void SetBoolInput(const FName MetaSoundInputName, bool& bValue); // 0x111a2360 (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetEnumInput(const FName MetaSoundInputName, char& Value); // 0x111a24e0 (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetFloatInput(const FName MetaSoundInputName, float& Value); // 0x111a2660 (Index: 0x16, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetIntInput(const FName MetaSoundInputName, int32_t& Value); // 0x111a27e8 (Index: 0x17, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetIsAudible(bool& bInIsAudible); // 0x111a296c (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetNodeCanBePooled(bool& bInNodeCanbePooled); // 0x111a2d98 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetNodeEnabled(bool& bEnabled); // 0x111a2ec4 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SetPositionalProxyActor(AActor*& InLocationProxyActor); // 0x111a3040 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void SetRunsOnServer(bool& bAllowRunOnServer); // 0x111a3318 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void SetStringInput(const FName MetaSoundInputName, FString& Value); // 0x111a3444 (Index: 0x1d, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnregisterForSignificance(bool& bNotifyIslandSettings); // 0x111a376c (Index: 0x1e, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)

private:
    void OnConnectedModulatorEnabledChanged(UFabricMetaSoundPatchWrapper*& EnabledPatchWrapper, bool& bEnabled); // 0x111a1584 (Index: 0xe, Flags: Final|Native|Private)
    void OnConnectedModulatorNodeCreated(UFabricMetaSoundPatchWrapper*& EnabledPatchWrapper); // 0x111a1790 (Index: 0xf, Flags: Final|Native|Private)
    void OnMetaSoundOutputChanged(FName& OutputName, const FMetaSoundOutput Output); // 0x111a1ad4 (Index: 0x11, Flags: Final|Native|Private|HasOutParms)

protected:
    virtual bool AddToGraphOnFirstConnect(); // 0xdd0f1e4 (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
    void NeedsAnalyzerParameterPackUpdate(); // 0x111a1404 (Index: 0x9, Flags: Final|Native|Protected|BlueprintCallable)
    void NeedsGeneratorHandleUpdate(); // 0x111a1418 (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable)
    void NeedsOutputWatcherUpdate(); // 0x111a142c (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
    void NeedsParameterPackUpdate(); // 0x111a1440 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnAddedToManagerGraph(UFabricMetaSoundManagerComponent*& Manager); // 0x111a1454 (Index: 0xd, Flags: Native|Event|Protected|BlueprintEvent)
    void OnMetasoundManagerEndPlay(); // 0x111a1e8c (Index: 0x10, Flags: Final|Native|Protected)
    void OnMetaSoundOutputValueChanged(FName& OutputName, const FMetaSoundOutput MetaSoundOutput); // 0x111a1cac (Index: 0x12, Flags: Native|Protected|HasOutParms)
};

static_assert(sizeof(UFabricMetaSoundPatchWrapper) == 0x798, "Size mismatch for UFabricMetaSoundPatchWrapper");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, EnabledStateInputName) == 0x328, "Offset mismatch for UFabricMetaSoundPatchWrapper::EnabledStateInputName");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, MetaSoundPatch) == 0x330, "Offset mismatch for UFabricMetaSoundPatchWrapper::MetaSoundPatch");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, UserOptionsToNodeInputs) == 0x350, "Offset mismatch for UFabricMetaSoundPatchWrapper::UserOptionsToNodeInputs");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PerPlatformInputBools) == 0x3a0, "Offset mismatch for UFabricMetaSoundPatchWrapper::PerPlatformInputBools");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PerPlatformInputInts) == 0x3b0, "Offset mismatch for UFabricMetaSoundPatchWrapper::PerPlatformInputInts");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PerPlatformInputFloats) == 0x3c0, "Offset mismatch for UFabricMetaSoundPatchWrapper::PerPlatformInputFloats");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, DirectInputs) == 0x3d0, "Offset mismatch for UFabricMetaSoundPatchWrapper::DirectInputs");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, SimpleSignalOutputBinding) == 0x3e0, "Offset mismatch for UFabricMetaSoundPatchWrapper::SimpleSignalOutputBinding");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, OnSimpleSignalBindingUpdate) == 0x430, "Offset mismatch for UFabricMetaSoundPatchWrapper::OnSimpleSignalBindingUpdate");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, VisibleInputParamName) == 0x440, "Offset mismatch for UFabricMetaSoundPatchWrapper::VisibleInputParamName");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, AudibleInputParamName) == 0x444, "Offset mismatch for UFabricMetaSoundPatchWrapper::AudibleInputParamName");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, bCanConsumeVisibleFlag) == 0x448, "Offset mismatch for UFabricMetaSoundPatchWrapper::bCanConsumeVisibleFlag");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, bCanConsumeAudibleFlag) == 0x449, "Offset mismatch for UFabricMetaSoundPatchWrapper::bCanConsumeAudibleFlag");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, bIsVisible) == 0x44a, "Offset mismatch for UFabricMetaSoundPatchWrapper::bIsVisible");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, bIsAudible) == 0x44b, "Offset mismatch for UFabricMetaSoundPatchWrapper::bIsAudible");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, OnMaxAttenuationChanged) == 0x470, "Offset mismatch for UFabricMetaSoundPatchWrapper::OnMaxAttenuationChanged");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, OnMetaSoundOutputIntChangedBatch) == 0x480, "Offset mismatch for UFabricMetaSoundPatchWrapper::OnMetaSoundOutputIntChangedBatch");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, OnMetaSoundOutputFloatChangedBatch) == 0x490, "Offset mismatch for UFabricMetaSoundPatchWrapper::OnMetaSoundOutputFloatChangedBatch");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, CurrentManager) == 0x4a0, "Offset mismatch for UFabricMetaSoundPatchWrapper::CurrentManager");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, TickSubsystem) == 0x4a8, "Offset mismatch for UFabricMetaSoundPatchWrapper::TickSubsystem");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, CurrentNode) == 0x4b0, "Offset mismatch for UFabricMetaSoundPatchWrapper::CurrentNode");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PositionalProxyActor) == 0x5a0, "Offset mismatch for UFabricMetaSoundPatchWrapper::PositionalProxyActor");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, CurrentAudioComponent) == 0x5c8, "Offset mismatch for UFabricMetaSoundPatchWrapper::CurrentAudioComponent");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, NewAudioComponent) == 0x5d0, "Offset mismatch for UFabricMetaSoundPatchWrapper::NewAudioComponent");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, CombinerMetaSoundType) == 0x5e8, "Offset mismatch for UFabricMetaSoundPatchWrapper::CombinerMetaSoundType");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, AnalyzerMetaSoundType) == 0x5ec, "Offset mismatch for UFabricMetaSoundPatchWrapper::AnalyzerMetaSoundType");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, MetaSoundRuntimeInputInfos) == 0x5f0, "Offset mismatch for UFabricMetaSoundPatchWrapper::MetaSoundRuntimeInputInfos");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, ConnectedInputWrappers) == 0x600, "Offset mismatch for UFabricMetaSoundPatchWrapper::ConnectedInputWrappers");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PendingInputWrappers) == 0x610, "Offset mismatch for UFabricMetaSoundPatchWrapper::PendingInputWrappers");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PendingOutputWrappers) == 0x620, "Offset mismatch for UFabricMetaSoundPatchWrapper::PendingOutputWrappers");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, ConnectionBuilder) == 0x630, "Offset mismatch for UFabricMetaSoundPatchWrapper::ConnectionBuilder");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, CombinersInUse) == 0x740, "Offset mismatch for UFabricMetaSoundPatchWrapper::CombinersInUse");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, ConnectedOutputWrappers) == 0x750, "Offset mismatch for UFabricMetaSoundPatchWrapper::ConnectedOutputWrappers");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, PatchWrapperQuality) == 0x760, "Offset mismatch for UFabricMetaSoundPatchWrapper::PatchWrapperQuality");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, MaxAttenuation) == 0x761, "Offset mismatch for UFabricMetaSoundPatchWrapper::MaxAttenuation");
static_assert(offsetof(UFabricMetaSoundPatchWrapper, LoadedMetaSoundPatch) == 0x778, "Offset mismatch for UFabricMetaSoundPatchWrapper::LoadedMetaSoundPatch");

// Size: 0x798 (Inherited: 0xae8, Single: 0xfffffcb0)
class UFabricMetaSoundBigKnobPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
};

static_assert(sizeof(UFabricMetaSoundBigKnobPatchWrapper) == 0x798, "Size mismatch for UFabricMetaSoundBigKnobPatchWrapper");

// Size: 0x868 (Inherited: 0xae8, Single: 0xfffffd80)
class UFabricMetaSoundDrumPlayerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    uint8_t Pad_798[0x8]; // 0x798 (Size: 0x8, Type: PaddingProperty)
    FName PitchSampleInputName; // 0x7a0 (Size: 0x4, Type: NameProperty)
    FName SlotKitInputName; // 0x7a4 (Size: 0x4, Type: NameProperty)
    TArray<FString> PitchSampleParams; // 0x7a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SlotLinkParams; // 0x7b8 (Size: 0x10, Type: ArrayProperty)
    FString CurrentKitParam; // 0x7c8 (Size: 0x10, Type: StrProperty)
    int32_t NumSamplesPerKit; // 0x7d8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7dc[0x4]; // 0x7dc (Size: 0x4, Type: PaddingProperty)
    TArray<FFabricMetaSoundPatchWrapperBinding> DrumAmplitudes; // 0x7e0 (Size: 0x10, Type: ArrayProperty)
    uint8_t OnFabricMetaSoundDrumPlayerPatchDrumAmplitudesUpdate[0x10]; // 0x7f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFabricMetaSoundDrumPlayerSampleBanksLoaded[0x10]; // 0x800 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_810[0x48]; // 0x810 (Size: 0x48, Type: PaddingProperty)
    TArray<UObject*> CurrentKitSamples; // 0x858 (Size: 0x10, Type: ArrayProperty)

public:
    void KitIndexChanged(const FName Param, int32_t& Value); // 0x1119de34 (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
    void LoadDrumPlayerSampleBanks(const TArray<TSoftObjectPtr<UFabricMetasoundDrumPlayerSampleBankAsset*>> SampleBankArray, const TSet<int32_t> KitNumbersToLoad); // 0x1119dfa4 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void PitchSampleParamChanged(int32_t& PitchSampleIndex, int32_t& Value); // 0x1119e334 (Index: 0x2, Flags: Final|Native|Public)
    void SlotLinkedParamChanged(int32_t& PitchSampleIndex, bool& Value); // 0x1119fab8 (Index: 0x3, Flags: Final|Native|Public)
    void SlotUnlinkedKitParamChanged(int32_t& PitchSampleIndex, int32_t& Value); // 0x1119fcc0 (Index: 0x4, Flags: Final|Native|Public)
};

static_assert(sizeof(UFabricMetaSoundDrumPlayerPatchWrapper) == 0x868, "Size mismatch for UFabricMetaSoundDrumPlayerPatchWrapper");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, PitchSampleInputName) == 0x7a0, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::PitchSampleInputName");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, SlotKitInputName) == 0x7a4, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::SlotKitInputName");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, PitchSampleParams) == 0x7a8, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::PitchSampleParams");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, SlotLinkParams) == 0x7b8, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::SlotLinkParams");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, CurrentKitParam) == 0x7c8, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::CurrentKitParam");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, NumSamplesPerKit) == 0x7d8, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::NumSamplesPerKit");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, DrumAmplitudes) == 0x7e0, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::DrumAmplitudes");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, OnFabricMetaSoundDrumPlayerPatchDrumAmplitudesUpdate) == 0x7f0, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::OnFabricMetaSoundDrumPlayerPatchDrumAmplitudesUpdate");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, OnFabricMetaSoundDrumPlayerSampleBanksLoaded) == 0x800, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::OnFabricMetaSoundDrumPlayerSampleBanksLoaded");
static_assert(offsetof(UFabricMetaSoundDrumPlayerPatchWrapper, CurrentKitSamples) == 0x858, "Offset mismatch for UFabricMetaSoundDrumPlayerPatchWrapper::CurrentKitSamples");

// Size: 0x860 (Inherited: 0x1330, Single: 0xfffff530)
class UFabricMetaSoundEchoPatchWrapper : public UFabricMetaSoundWetDryPatchWrapper
{
public:
    bool bAllowWetSignalWaveformTexture; // 0x848 (Size: 0x1, Type: BoolProperty)
    bool bAllowDrySignalWaveformTexture; // 0x849 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_84a[0x6]; // 0x84a (Size: 0x6, Type: PaddingProperty)
    UFabricWaveformTexture* WetSignalWaveformTexture; // 0x850 (Size: 0x8, Type: ObjectProperty)
    UFabricWaveformTexture* DrySignalWaveformTexture; // 0x858 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFabricMetaSoundEchoPatchWrapper) == 0x860, "Size mismatch for UFabricMetaSoundEchoPatchWrapper");
static_assert(offsetof(UFabricMetaSoundEchoPatchWrapper, bAllowWetSignalWaveformTexture) == 0x848, "Offset mismatch for UFabricMetaSoundEchoPatchWrapper::bAllowWetSignalWaveformTexture");
static_assert(offsetof(UFabricMetaSoundEchoPatchWrapper, bAllowDrySignalWaveformTexture) == 0x849, "Offset mismatch for UFabricMetaSoundEchoPatchWrapper::bAllowDrySignalWaveformTexture");
static_assert(offsetof(UFabricMetaSoundEchoPatchWrapper, WetSignalWaveformTexture) == 0x850, "Offset mismatch for UFabricMetaSoundEchoPatchWrapper::WetSignalWaveformTexture");
static_assert(offsetof(UFabricMetaSoundEchoPatchWrapper, DrySignalWaveformTexture) == 0x858, "Offset mismatch for UFabricMetaSoundEchoPatchWrapper::DrySignalWaveformTexture");

// Size: 0x848 (Inherited: 0xae8, Single: 0xfffffd60)
class UFabricMetaSoundWetDryPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    FFabricMetaSoundPatchWrapperWetDryOutputBinding WetDryOutputBinding; // 0x798 (Size: 0xa0, Type: StructProperty)
    uint8_t OnWetDryOutputSignalUpdate[0x10]; // 0x838 (Size: 0x10, Type: MulticastInlineDelegateProperty)
};

static_assert(sizeof(UFabricMetaSoundWetDryPatchWrapper) == 0x848, "Size mismatch for UFabricMetaSoundWetDryPatchWrapper");
static_assert(offsetof(UFabricMetaSoundWetDryPatchWrapper, WetDryOutputBinding) == 0x798, "Offset mismatch for UFabricMetaSoundWetDryPatchWrapper::WetDryOutputBinding");
static_assert(offsetof(UFabricMetaSoundWetDryPatchWrapper, OnWetDryOutputSignalUpdate) == 0x838, "Offset mismatch for UFabricMetaSoundWetDryPatchWrapper::OnWetDryOutputSignalUpdate");

// Size: 0x880 (Inherited: 0xae8, Single: 0xfffffd98)
class UFabricMetaSoundInstrumentPlayerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    uint8_t OnFFTResultsUpdated[0x10]; // 0x798 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FFabricMetaSoundPatchWrapperBinding FFTAnalysisOutputBinding; // 0x7a8 (Size: 0x50, Type: StructProperty)
    int32_t FFTCPDStartIndex; // 0x7f8 (Size: 0x4, Type: IntProperty)
    int32_t FFTLength; // 0x7fc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_800[0x78]; // 0x800 (Size: 0x78, Type: PaddingProperty)
    UFusionPatch* CurrentFusionPatch; // 0x878 (Size: 0x8, Type: ObjectProperty)

public:
    void DriveFFTDataOnPrimitive(UPrimitiveComponent*& Primitive); // 0x1119d248 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetFusionPatch(UFusionPatch*& FusionPatch); // 0x1119eea0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMetaSoundInstrumentPlayerPatchWrapper) == 0x880, "Size mismatch for UFabricMetaSoundInstrumentPlayerPatchWrapper");
static_assert(offsetof(UFabricMetaSoundInstrumentPlayerPatchWrapper, OnFFTResultsUpdated) == 0x798, "Offset mismatch for UFabricMetaSoundInstrumentPlayerPatchWrapper::OnFFTResultsUpdated");
static_assert(offsetof(UFabricMetaSoundInstrumentPlayerPatchWrapper, FFTAnalysisOutputBinding) == 0x7a8, "Offset mismatch for UFabricMetaSoundInstrumentPlayerPatchWrapper::FFTAnalysisOutputBinding");
static_assert(offsetof(UFabricMetaSoundInstrumentPlayerPatchWrapper, FFTCPDStartIndex) == 0x7f8, "Offset mismatch for UFabricMetaSoundInstrumentPlayerPatchWrapper::FFTCPDStartIndex");
static_assert(offsetof(UFabricMetaSoundInstrumentPlayerPatchWrapper, FFTLength) == 0x7fc, "Offset mismatch for UFabricMetaSoundInstrumentPlayerPatchWrapper::FFTLength");
static_assert(offsetof(UFabricMetaSoundInstrumentPlayerPatchWrapper, CurrentFusionPatch) == 0x878, "Offset mismatch for UFabricMetaSoundInstrumentPlayerPatchWrapper::CurrentFusionPatch");

// Size: 0x7d0 (Inherited: 0x12a0, Single: 0xfffff530)
class UFabricMetaSoundLFOPatchWrapper : public UFabricMetaSoundModulatorPatchWrapper
{
public:
    UFabricFloatProviderWave* LFOFloatProvider; // 0x7b8 (Size: 0x8, Type: ObjectProperty)
    FName FreePhaseStartName; // 0x7c0 (Size: 0x4, Type: NameProperty)
    FName RandomSeedInputName; // 0x7c4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c8[0x8]; // 0x7c8 (Size: 0x8, Type: PaddingProperty)

public:
    void UpdateRandomSeed(); // 0x1119ffac (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMetaSoundLFOPatchWrapper) == 0x7d0, "Size mismatch for UFabricMetaSoundLFOPatchWrapper");
static_assert(offsetof(UFabricMetaSoundLFOPatchWrapper, LFOFloatProvider) == 0x7b8, "Offset mismatch for UFabricMetaSoundLFOPatchWrapper::LFOFloatProvider");
static_assert(offsetof(UFabricMetaSoundLFOPatchWrapper, FreePhaseStartName) == 0x7c0, "Offset mismatch for UFabricMetaSoundLFOPatchWrapper::FreePhaseStartName");
static_assert(offsetof(UFabricMetaSoundLFOPatchWrapper, RandomSeedInputName) == 0x7c4, "Offset mismatch for UFabricMetaSoundLFOPatchWrapper::RandomSeedInputName");

// Size: 0x7b8 (Inherited: 0xae8, Single: 0xfffffcd0)
class UFabricMetaSoundModulatorPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    uint8_t OnPatchWrapperVisibilityChanged[0x10]; // 0x798 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UPlaylistUserOptionBase* CurrentUserOption; // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundUserOption* MetaSoundUserOption; // 0x7b0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFabricMetaSoundModulatorPatchWrapper) == 0x7b8, "Size mismatch for UFabricMetaSoundModulatorPatchWrapper");
static_assert(offsetof(UFabricMetaSoundModulatorPatchWrapper, OnPatchWrapperVisibilityChanged) == 0x798, "Offset mismatch for UFabricMetaSoundModulatorPatchWrapper::OnPatchWrapperVisibilityChanged");
static_assert(offsetof(UFabricMetaSoundModulatorPatchWrapper, CurrentUserOption) == 0x7a8, "Offset mismatch for UFabricMetaSoundModulatorPatchWrapper::CurrentUserOption");
static_assert(offsetof(UFabricMetaSoundModulatorPatchWrapper, MetaSoundUserOption) == 0x7b0, "Offset mismatch for UFabricMetaSoundModulatorPatchWrapper::MetaSoundUserOption");

// Size: 0xab0 (Inherited: 0xe0, Single: 0x9d0)
class UFabricMetaSoundManagerComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    TSoftObjectPtr<UMetaSoundPatch*> HarmonixMusicProviderPatch; // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> HarmonixMetronomeClockPatch; // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> HarmonixTempoClockPatch; // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> HarmonixTransportPatch; // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> UserOptionConverterNode; // 0x148 (Size: 0x20, Type: SoftObjectProperty)
    FFabricMetaSoundUtilityPatches MidiStreamUtilityPatches; // 0x168 (Size: 0x88, Type: StructProperty)
    FFabricMetaSoundUtilityPatches AudioUtilityPatches; // 0x1f0 (Size: 0x88, Type: StructProperty)
    FFabricMetaSoundUtilityPatches FloatUtilityPatches; // 0x278 (Size: 0x88, Type: StructProperty)
    FName MusicProviderVolumeName; // 0x300 (Size: 0x4, Type: NameProperty)
    FName MusicProviderRootNoteName; // 0x304 (Size: 0x4, Type: NameProperty)
    FName MusicProviderScaleName; // 0x308 (Size: 0x4, Type: NameProperty)
    FName TransportProviderPlayTriggerName; // 0x30c (Size: 0x4, Type: NameProperty)
    FName TransportProviderDelayedRestartTriggerName; // 0x310 (Size: 0x4, Type: NameProperty)
    FName TransportProviderRestartTriggerName; // 0x314 (Size: 0x4, Type: NameProperty)
    FName TransportProviderSeekTriggerName; // 0x318 (Size: 0x4, Type: NameProperty)
    FName TransportProviderPauseTriggerName; // 0x31c (Size: 0x4, Type: NameProperty)
    FName TransportProviderContinueTriggerName; // 0x320 (Size: 0x4, Type: NameProperty)
    FName TransportProviderStopTriggerName; // 0x324 (Size: 0x4, Type: NameProperty)
    FName TransportProviderSeekTargetName; // 0x328 (Size: 0x4, Type: NameProperty)
    FName ClockProviderTempoName; // 0x32c (Size: 0x4, Type: NameProperty)
    FName ClockProviderSpeedName; // 0x330 (Size: 0x4, Type: NameProperty)
    FName ClockProviderTimeSigNumName; // 0x334 (Size: 0x4, Type: NameProperty)
    FName ClockProviderTimeSignDenomName; // 0x338 (Size: 0x4, Type: NameProperty)
    FName ClockProviderMidiFileInName; // 0x33c (Size: 0x4, Type: NameProperty)
    FName ClockProviderLoopName; // 0x340 (Size: 0x4, Type: NameProperty)
    FName UserOptionConverterCountInName; // 0x344 (Size: 0x4, Type: NameProperty)
    float CrossfadeSeconds; // 0x348 (Size: 0x4, Type: FloatProperty)
    float RebuildTimeOutSeconds; // 0x34c (Size: 0x4, Type: FloatProperty)
    float BlockRateOverride; // 0x350 (Size: 0x4, Type: FloatProperty)
    FName QualityOverride; // 0x354 (Size: 0x4, Type: NameProperty)
    UMidiFile* DefaultMidiFile; // 0x358 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_360[0x30]; // 0x360 (Size: 0x30, Type: PaddingProperty)
    uint8_t OnMetasoundGeneratorCrossfadeStarted[0x10]; // 0x390 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3a0[0x50]; // 0x3a0 (Size: 0x50, Type: PaddingProperty)
    uint8_t OnMetasoundClockAuthorityChanged[0x10]; // 0x3f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_400[0x18]; // 0x400 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnPlayStateChanged[0x10]; // 0x418 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<FFabricSignificanceBasedUpdateBucketRuntime> SignificanceRuntimeBuckets; // 0x428 (Size: 0x10, Type: ArrayProperty)
    UFabricSignificanceAsset* SignificanceBasedUpdate; // 0x438 (Size: 0x8, Type: ObjectProperty)
    float InitialCooldownTimeInSeconds; // 0x440 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_444[0x4]; // 0x444 (Size: 0x4, Type: PaddingProperty)
    UMetaSoundSourceBuilder* SourceBuilder; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UMusicClockComponent* MusicClock; // 0x450 (Size: 0x8, Type: ObjectProperty)
    TArray<UAudioComponent*> PlaybackAudioComponents; // 0x458 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_468[0x50]; // 0x468 (Size: 0x50, Type: PaddingProperty)
    TArray<UMetasoundOfflinePlayerComponent*> ServerPlaybackComponents; // 0x4b8 (Size: 0x10, Type: ArrayProperty)
    uint8_t QueuedTransportRequestLock[0xc]; // 0x4c8 (Size: 0xc, Type: OptionalProperty)
    uint8_t Pad_4d4[0x44]; // 0x4d4 (Size: 0x44, Type: PaddingProperty)
    FFabricTransportRequestConfig CurrentTransportRequestLock; // 0x518 (Size: 0x8, Type: StructProperty)
    uint8_t ClockAuthorityName[0x4]; // 0x520 (Size: 0x4, Type: OptionalProperty)
    uint8_t Pad_524[0x4]; // 0x524 (Size: 0x4, Type: PaddingProperty)
    TArray<UFabricMetaSoundUtilityProviderPatchWrapper*> SortedRegisteredUtilityProviderAuthorities; // 0x528 (Size: 0x10, Type: ArrayProperty)
    FMusicTimestamp ClockAuthorityLoopLength; // 0x538 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<UMidiFile*> TempoMapMidiFile; // 0x540 (Size: 0x8, Type: WeakObjectProperty)
    FFabricMetaSoundNodeInfo HarmonixMusicProviderNode; // 0x548 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundNodeInfo HarmonixMetronomeClockNode; // 0x638 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundNodeInfo HarmonixMidiTempoClockNode; // 0x728 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundNodeInfo HarmonixTransportNode; // 0x818 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeOutputHandle OnPlayNodeOutput; // 0x908 (Size: 0x20, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle OnFinishedNodeInput; // 0x928 (Size: 0x20, Type: StructProperty)
    TArray<FMetaSoundBuilderNodeInputHandle> AudioOutNodeInputs; // 0x948 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_958[0x48]; // 0x958 (Size: 0x48, Type: PaddingProperty)
    TMap<FFabricMetaSoundNodePool, UMetaSoundPatch*> FreeMetaSoundNodes; // 0x9a0 (Size: 0x50, Type: MapProperty)
    TMap<FFabricLoadedUtilityPatches, FName> UtilityNodeTypesToPatches; // 0x9f0 (Size: 0x50, Type: MapProperty)
    TMap<UFabricMetaSoundUtilityProviderPatchWrapper*, UClass*> UtilityProviderNodesInGraph; // 0xa40 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_a90[0x10]; // 0xa90 (Size: 0x10, Type: PaddingProperty)
    bool bGraphDirty; // 0xaa0 (Size: 0x1, Type: BoolProperty)
    bool bIsAudioless; // 0xaa1 (Size: 0x1, Type: BoolProperty)
    bool bHasCompletedInitialCooldown; // 0xaa2 (Size: 0x1, Type: BoolProperty)
    uint8_t CurrentClockType; // 0xaa3 (Size: 0x1, Type: EnumProperty)
    uint8_t DefaultClockType; // 0xaa4 (Size: 0x1, Type: EnumProperty)
    uint8_t CurrentPlayState; // 0xaa5 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayStateAfterRebuild; // 0xaa6 (Size: 0x1, Type: EnumProperty)
    uint8_t JamSyncType; // 0xaa7 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_aa8[0x2]; // 0xaa8 (Size: 0x2, Type: PaddingProperty)
    uint8_t LastBroadcastBy; // 0xaaa (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_aab[0x5]; // 0xaab (Size: 0x5, Type: PaddingProperty)

public:
    void AddInputNodeForNodeByNameBP(FFabricMetaSoundNodeInfo InOutNode, EFabricUserOptionType& UserOptionType, const FName InputName); // 0x1119cdac (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void AddOutputNodeForOutputVertex(const FMetaSoundBuilderNodeOutputHandle OutputVertex, const FName NodeName, FName& OutOutputName, EMetaSoundBuilderResult& Result); // 0x1119cfb0 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool AreAllPatchesReady() const; // 0x1119d224 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void FreeMetaSoundNode(const FFabricMetaSoundNodeInfo Node); // 0x1119d6bc (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    UMetaSoundSourceBuilder* GetBuilder() const; // 0xd1261bc (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TScriptInterface<Class> GetCurrentAuthorityAsMidiProvider() const; // 0x1119d7c4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricMetasoundClock GetCurrentClockType() const; // 0x1119d7f8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EJamFabricSyncType GetCurrentJamSyncType() const; // 0x1119d810 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAudioComponent* GetCurrentPlaybackAudioComponent() const; // 0x1119d828 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricMetasoundPlayState GetCurrentPlaystate() const; // 0x1119d848 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FName GetMetasoundInputNodeName(FName& NodeName, FName& InputName); // 0x1119d9cc (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    FFabricMetaSoundNodeInfo GetMetaSoundNodeForWrapper(UFabricMetaSoundPatchWrapper*& PatchWrapper); // 0x1119d860 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    static FName GetMetasoundOutputNodeName(FName& NodeName, FName& OutputName); // 0x1119dbd8 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    UMusicClockComponent* GetMusicClock() const; // 0xf36b1a4 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasClockAuthority() const; // 0x1119dde8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InvalidateMetasoundGeneratorHandle(); // 0x1119de20 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void NotifyGraphChanged(); // 0x1119e1d0 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    bool PauseMetasound(); // 0x1119e310 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    bool PlayMetasound(const FFabricTransportRequestConfig PlayConfig); // 0x1119e53c (Index: 0x13, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void PlaySoundSourceBus(USoundSourceBus*& Bus); // 0x1119e620 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void RestartMetasoundPlayback(); // 0x1119e74c (Index: 0x15, Flags: Final|Native|Public)
    bool SeekToMs(float& Ms); // 0x1119e764 (Index: 0x16, Flags: Final|Native|Public)
    bool SeekToSeconds(float& Seconds); // 0x1119e8a0 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    bool SeekToTimestamp(const FMusicTimestamp Timestamp); // 0x1119e9e4 (Index: 0x18, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetAudioComponents(TArray<UAudioComponent*>& AudioComponents); // 0x1119eacc (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurrentJamSyncType(const EJamFabricSyncType InJamSyncType); // 0x1119edd4 (Index: 0x1a, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetMidiFile(UMidiFile*& MidiFile); // 0x1119f1a8 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void SetMusicClock(UMusicClockComponent*& MusicClockComponent); // 0x1119f2e0 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    bool SetMusicKey(EMusicKey& Key, EMusicKeyMode& Mode); // 0x1119f40c (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable)
    bool SetSpeed(float& Speed); // 0x1119f628 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable)
    bool SetTempo(float& Tempo); // 0x1119f764 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable)
    bool SetTimeSignature(int32_t& Numerator, int32_t& Denominator); // 0x1119f8a0 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    bool StopMetasound(const FFabricTransportRequestConfig PlayConfig); // 0x1119fec8 (Index: 0x21, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnGeneratorJustStarted(int32_t& ComponentIndex); // 0x1119e1e8 (Index: 0x11, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricMetaSoundManagerComponent) == 0xab0, "Size mismatch for UFabricMetaSoundManagerComponent");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixMusicProviderPatch) == 0xc8, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixMusicProviderPatch");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixMetronomeClockPatch) == 0xe8, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixMetronomeClockPatch");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixTempoClockPatch) == 0x108, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixTempoClockPatch");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixTransportPatch) == 0x128, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixTransportPatch");
static_assert(offsetof(UFabricMetaSoundManagerComponent, UserOptionConverterNode) == 0x148, "Offset mismatch for UFabricMetaSoundManagerComponent::UserOptionConverterNode");
static_assert(offsetof(UFabricMetaSoundManagerComponent, MidiStreamUtilityPatches) == 0x168, "Offset mismatch for UFabricMetaSoundManagerComponent::MidiStreamUtilityPatches");
static_assert(offsetof(UFabricMetaSoundManagerComponent, AudioUtilityPatches) == 0x1f0, "Offset mismatch for UFabricMetaSoundManagerComponent::AudioUtilityPatches");
static_assert(offsetof(UFabricMetaSoundManagerComponent, FloatUtilityPatches) == 0x278, "Offset mismatch for UFabricMetaSoundManagerComponent::FloatUtilityPatches");
static_assert(offsetof(UFabricMetaSoundManagerComponent, MusicProviderVolumeName) == 0x300, "Offset mismatch for UFabricMetaSoundManagerComponent::MusicProviderVolumeName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, MusicProviderRootNoteName) == 0x304, "Offset mismatch for UFabricMetaSoundManagerComponent::MusicProviderRootNoteName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, MusicProviderScaleName) == 0x308, "Offset mismatch for UFabricMetaSoundManagerComponent::MusicProviderScaleName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderPlayTriggerName) == 0x30c, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderPlayTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderDelayedRestartTriggerName) == 0x310, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderDelayedRestartTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderRestartTriggerName) == 0x314, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderRestartTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderSeekTriggerName) == 0x318, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderSeekTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderPauseTriggerName) == 0x31c, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderPauseTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderContinueTriggerName) == 0x320, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderContinueTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderStopTriggerName) == 0x324, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderStopTriggerName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TransportProviderSeekTargetName) == 0x328, "Offset mismatch for UFabricMetaSoundManagerComponent::TransportProviderSeekTargetName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockProviderTempoName) == 0x32c, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockProviderTempoName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockProviderSpeedName) == 0x330, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockProviderSpeedName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockProviderTimeSigNumName) == 0x334, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockProviderTimeSigNumName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockProviderTimeSignDenomName) == 0x338, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockProviderTimeSignDenomName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockProviderMidiFileInName) == 0x33c, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockProviderMidiFileInName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockProviderLoopName) == 0x340, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockProviderLoopName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, UserOptionConverterCountInName) == 0x344, "Offset mismatch for UFabricMetaSoundManagerComponent::UserOptionConverterCountInName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, CrossfadeSeconds) == 0x348, "Offset mismatch for UFabricMetaSoundManagerComponent::CrossfadeSeconds");
static_assert(offsetof(UFabricMetaSoundManagerComponent, RebuildTimeOutSeconds) == 0x34c, "Offset mismatch for UFabricMetaSoundManagerComponent::RebuildTimeOutSeconds");
static_assert(offsetof(UFabricMetaSoundManagerComponent, BlockRateOverride) == 0x350, "Offset mismatch for UFabricMetaSoundManagerComponent::BlockRateOverride");
static_assert(offsetof(UFabricMetaSoundManagerComponent, QualityOverride) == 0x354, "Offset mismatch for UFabricMetaSoundManagerComponent::QualityOverride");
static_assert(offsetof(UFabricMetaSoundManagerComponent, DefaultMidiFile) == 0x358, "Offset mismatch for UFabricMetaSoundManagerComponent::DefaultMidiFile");
static_assert(offsetof(UFabricMetaSoundManagerComponent, OnMetasoundGeneratorCrossfadeStarted) == 0x390, "Offset mismatch for UFabricMetaSoundManagerComponent::OnMetasoundGeneratorCrossfadeStarted");
static_assert(offsetof(UFabricMetaSoundManagerComponent, OnMetasoundClockAuthorityChanged) == 0x3f0, "Offset mismatch for UFabricMetaSoundManagerComponent::OnMetasoundClockAuthorityChanged");
static_assert(offsetof(UFabricMetaSoundManagerComponent, OnPlayStateChanged) == 0x418, "Offset mismatch for UFabricMetaSoundManagerComponent::OnPlayStateChanged");
static_assert(offsetof(UFabricMetaSoundManagerComponent, SignificanceRuntimeBuckets) == 0x428, "Offset mismatch for UFabricMetaSoundManagerComponent::SignificanceRuntimeBuckets");
static_assert(offsetof(UFabricMetaSoundManagerComponent, SignificanceBasedUpdate) == 0x438, "Offset mismatch for UFabricMetaSoundManagerComponent::SignificanceBasedUpdate");
static_assert(offsetof(UFabricMetaSoundManagerComponent, InitialCooldownTimeInSeconds) == 0x440, "Offset mismatch for UFabricMetaSoundManagerComponent::InitialCooldownTimeInSeconds");
static_assert(offsetof(UFabricMetaSoundManagerComponent, SourceBuilder) == 0x448, "Offset mismatch for UFabricMetaSoundManagerComponent::SourceBuilder");
static_assert(offsetof(UFabricMetaSoundManagerComponent, MusicClock) == 0x450, "Offset mismatch for UFabricMetaSoundManagerComponent::MusicClock");
static_assert(offsetof(UFabricMetaSoundManagerComponent, PlaybackAudioComponents) == 0x458, "Offset mismatch for UFabricMetaSoundManagerComponent::PlaybackAudioComponents");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ServerPlaybackComponents) == 0x4b8, "Offset mismatch for UFabricMetaSoundManagerComponent::ServerPlaybackComponents");
static_assert(offsetof(UFabricMetaSoundManagerComponent, QueuedTransportRequestLock) == 0x4c8, "Offset mismatch for UFabricMetaSoundManagerComponent::QueuedTransportRequestLock");
static_assert(offsetof(UFabricMetaSoundManagerComponent, CurrentTransportRequestLock) == 0x518, "Offset mismatch for UFabricMetaSoundManagerComponent::CurrentTransportRequestLock");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockAuthorityName) == 0x520, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockAuthorityName");
static_assert(offsetof(UFabricMetaSoundManagerComponent, SortedRegisteredUtilityProviderAuthorities) == 0x528, "Offset mismatch for UFabricMetaSoundManagerComponent::SortedRegisteredUtilityProviderAuthorities");
static_assert(offsetof(UFabricMetaSoundManagerComponent, ClockAuthorityLoopLength) == 0x538, "Offset mismatch for UFabricMetaSoundManagerComponent::ClockAuthorityLoopLength");
static_assert(offsetof(UFabricMetaSoundManagerComponent, TempoMapMidiFile) == 0x540, "Offset mismatch for UFabricMetaSoundManagerComponent::TempoMapMidiFile");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixMusicProviderNode) == 0x548, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixMusicProviderNode");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixMetronomeClockNode) == 0x638, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixMetronomeClockNode");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixMidiTempoClockNode) == 0x728, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixMidiTempoClockNode");
static_assert(offsetof(UFabricMetaSoundManagerComponent, HarmonixTransportNode) == 0x818, "Offset mismatch for UFabricMetaSoundManagerComponent::HarmonixTransportNode");
static_assert(offsetof(UFabricMetaSoundManagerComponent, OnPlayNodeOutput) == 0x908, "Offset mismatch for UFabricMetaSoundManagerComponent::OnPlayNodeOutput");
static_assert(offsetof(UFabricMetaSoundManagerComponent, OnFinishedNodeInput) == 0x928, "Offset mismatch for UFabricMetaSoundManagerComponent::OnFinishedNodeInput");
static_assert(offsetof(UFabricMetaSoundManagerComponent, AudioOutNodeInputs) == 0x948, "Offset mismatch for UFabricMetaSoundManagerComponent::AudioOutNodeInputs");
static_assert(offsetof(UFabricMetaSoundManagerComponent, FreeMetaSoundNodes) == 0x9a0, "Offset mismatch for UFabricMetaSoundManagerComponent::FreeMetaSoundNodes");
static_assert(offsetof(UFabricMetaSoundManagerComponent, UtilityNodeTypesToPatches) == 0x9f0, "Offset mismatch for UFabricMetaSoundManagerComponent::UtilityNodeTypesToPatches");
static_assert(offsetof(UFabricMetaSoundManagerComponent, UtilityProviderNodesInGraph) == 0xa40, "Offset mismatch for UFabricMetaSoundManagerComponent::UtilityProviderNodesInGraph");
static_assert(offsetof(UFabricMetaSoundManagerComponent, bGraphDirty) == 0xaa0, "Offset mismatch for UFabricMetaSoundManagerComponent::bGraphDirty");
static_assert(offsetof(UFabricMetaSoundManagerComponent, bIsAudioless) == 0xaa1, "Offset mismatch for UFabricMetaSoundManagerComponent::bIsAudioless");
static_assert(offsetof(UFabricMetaSoundManagerComponent, bHasCompletedInitialCooldown) == 0xaa2, "Offset mismatch for UFabricMetaSoundManagerComponent::bHasCompletedInitialCooldown");
static_assert(offsetof(UFabricMetaSoundManagerComponent, CurrentClockType) == 0xaa3, "Offset mismatch for UFabricMetaSoundManagerComponent::CurrentClockType");
static_assert(offsetof(UFabricMetaSoundManagerComponent, DefaultClockType) == 0xaa4, "Offset mismatch for UFabricMetaSoundManagerComponent::DefaultClockType");
static_assert(offsetof(UFabricMetaSoundManagerComponent, CurrentPlayState) == 0xaa5, "Offset mismatch for UFabricMetaSoundManagerComponent::CurrentPlayState");
static_assert(offsetof(UFabricMetaSoundManagerComponent, PlayStateAfterRebuild) == 0xaa6, "Offset mismatch for UFabricMetaSoundManagerComponent::PlayStateAfterRebuild");
static_assert(offsetof(UFabricMetaSoundManagerComponent, JamSyncType) == 0xaa7, "Offset mismatch for UFabricMetaSoundManagerComponent::JamSyncType");
static_assert(offsetof(UFabricMetaSoundManagerComponent, LastBroadcastBy) == 0xaaa, "Offset mismatch for UFabricMetaSoundManagerComponent::LastBroadcastBy");

// Size: 0x800 (Inherited: 0xae8, Single: 0xfffffd18)
class UFabricNoteReceivedPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    FName NoteOutputName; // 0x798 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_79c[0x4]; // 0x79c (Size: 0x4, Type: PaddingProperty)
    TArray<FString> TriggerNoteParams; // 0x7a0 (Size: 0x10, Type: ArrayProperty)
    uint8_t OnMatchingMidiEventPassed[0x10]; // 0x7b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMatchingNoteOnMidiEventPassed[0x10]; // 0x7c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMatchingNoteOffMidiEventPassed[0x10]; // 0x7d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_7e0[0x20]; // 0x7e0 (Size: 0x20, Type: PaddingProperty)

protected:
    void OnMetaSoundMidiEventPassed(FName& OutputName, const FMetaSoundOutput Output); // 0x111a18bc (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnTriggerNoteChanged(int32_t& NoteIndex, bool& bTriggerActive); // 0x111a2000 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricNoteReceivedPatchWrapper) == 0x800, "Size mismatch for UFabricNoteReceivedPatchWrapper");
static_assert(offsetof(UFabricNoteReceivedPatchWrapper, NoteOutputName) == 0x798, "Offset mismatch for UFabricNoteReceivedPatchWrapper::NoteOutputName");
static_assert(offsetof(UFabricNoteReceivedPatchWrapper, TriggerNoteParams) == 0x7a0, "Offset mismatch for UFabricNoteReceivedPatchWrapper::TriggerNoteParams");
static_assert(offsetof(UFabricNoteReceivedPatchWrapper, OnMatchingMidiEventPassed) == 0x7b0, "Offset mismatch for UFabricNoteReceivedPatchWrapper::OnMatchingMidiEventPassed");
static_assert(offsetof(UFabricNoteReceivedPatchWrapper, OnMatchingNoteOnMidiEventPassed) == 0x7c0, "Offset mismatch for UFabricNoteReceivedPatchWrapper::OnMatchingNoteOnMidiEventPassed");
static_assert(offsetof(UFabricNoteReceivedPatchWrapper, OnMatchingNoteOffMidiEventPassed) == 0x7d0, "Offset mismatch for UFabricNoteReceivedPatchWrapper::OnMatchingNoteOffMidiEventPassed");

// Size: 0x830 (Inherited: 0x12e8, Single: 0xfffff548)
class UFabricNoteTriggerPatchWrapper : public UFabricNoteReceivedPatchWrapper
{
public:
    FString OctaveParam; // 0x800 (Size: 0x10, Type: StrProperty)
    int32_t MaxOctave; // 0x810 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_814[0x4]; // 0x814 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnAnyMidiEventPassed[0x10]; // 0x818 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_828[0x8]; // 0x828 (Size: 0x8, Type: PaddingProperty)

protected:
    void OnOctaveChanged(const FName ParamName, int32_t& InOctave); // 0x111a1ea0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFabricNoteTriggerPatchWrapper) == 0x830, "Size mismatch for UFabricNoteTriggerPatchWrapper");
static_assert(offsetof(UFabricNoteTriggerPatchWrapper, OctaveParam) == 0x800, "Offset mismatch for UFabricNoteTriggerPatchWrapper::OctaveParam");
static_assert(offsetof(UFabricNoteTriggerPatchWrapper, MaxOctave) == 0x810, "Offset mismatch for UFabricNoteTriggerPatchWrapper::MaxOctave");
static_assert(offsetof(UFabricNoteTriggerPatchWrapper, OnAnyMidiEventPassed) == 0x818, "Offset mismatch for UFabricNoteTriggerPatchWrapper::OnAnyMidiEventPassed");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UFabricMetaSoundTreeNode : public UObject
{
public:
    uint8_t PinDirection; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UFabricMetaSoundPatchWrapper* AssociatedPatchWrapper; // 0x30 (Size: 0x8, Type: ObjectProperty)
    TArray<UFabricMetaSoundTreeNode*> Children; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t MaxAttenuation; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)

public:
    void ConnectToChildNodes(); // 0x111a1224 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<UFabricMetaSoundTreeNode*> GetValidChildren(); // 0x111a1398 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void Reset(); // 0x111a2220 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMetaSoundTreeNode) == 0x50, "Size mismatch for UFabricMetaSoundTreeNode");
static_assert(offsetof(UFabricMetaSoundTreeNode, PinDirection) == 0x28, "Offset mismatch for UFabricMetaSoundTreeNode::PinDirection");
static_assert(offsetof(UFabricMetaSoundTreeNode, AssociatedPatchWrapper) == 0x30, "Offset mismatch for UFabricMetaSoundTreeNode::AssociatedPatchWrapper");
static_assert(offsetof(UFabricMetaSoundTreeNode, Children) == 0x38, "Offset mismatch for UFabricMetaSoundTreeNode::Children");
static_assert(offsetof(UFabricMetaSoundTreeNode, MaxAttenuation) == 0x48, "Offset mismatch for UFabricMetaSoundTreeNode::MaxAttenuation");

// Size: 0x7a0 (Inherited: 0xae8, Single: 0xfffffcb8)
class UFabricMetaSoundSequencerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    UMidiStepSequence* CurrentStepSequence; // 0x798 (Size: 0x8, Type: ObjectProperty)

public:
    void SetMidiStepSequence(UMidiStepSequence*& StepSequence); // 0x111a2a98 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMetaSoundSequencerPatchWrapper) == 0x7a0, "Size mismatch for UFabricMetaSoundSequencerPatchWrapper");
static_assert(offsetof(UFabricMetaSoundSequencerPatchWrapper, CurrentStepSequence) == 0x798, "Offset mismatch for UFabricMetaSoundSequencerPatchWrapper::CurrentStepSequence");

// Size: 0x830 (Inherited: 0xae8, Single: 0xfffffd48)
class UFabricMetaSoundSpeakerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    TArray<FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding> EqBands; // 0x798 (Size: 0x10, Type: ArrayProperty)
    FFabricMetaSoundPatchWrapperBinding AudioPeak; // 0x7a8 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_7f8[0x10]; // 0x7f8 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnFabricMetaSoundSpeakerPatchEqBandUpdate[0x10]; // 0x808 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFabricSpeakerReceivingSignalChanged[0x10]; // 0x818 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_828[0x8]; // 0x828 (Size: 0x8, Type: PaddingProperty)

public:
    void SetAudioBusFromSourceBus(USoundSourceBus*& Bus); // 0x111a2234 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMetaSoundSpeakerPatchWrapper) == 0x830, "Size mismatch for UFabricMetaSoundSpeakerPatchWrapper");
static_assert(offsetof(UFabricMetaSoundSpeakerPatchWrapper, EqBands) == 0x798, "Offset mismatch for UFabricMetaSoundSpeakerPatchWrapper::EqBands");
static_assert(offsetof(UFabricMetaSoundSpeakerPatchWrapper, AudioPeak) == 0x7a8, "Offset mismatch for UFabricMetaSoundSpeakerPatchWrapper::AudioPeak");
static_assert(offsetof(UFabricMetaSoundSpeakerPatchWrapper, OnFabricMetaSoundSpeakerPatchEqBandUpdate) == 0x808, "Offset mismatch for UFabricMetaSoundSpeakerPatchWrapper::OnFabricMetaSoundSpeakerPatchEqBandUpdate");
static_assert(offsetof(UFabricMetaSoundSpeakerPatchWrapper, OnFabricSpeakerReceivingSignalChanged) == 0x818, "Offset mismatch for UFabricMetaSoundSpeakerPatchWrapper::OnFabricSpeakerReceivingSignalChanged");

// Size: 0x7f0 (Inherited: 0xae8, Single: 0xfffffd08)
class UFabricMetaSoundSplitterPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    uint8_t Pad_798[0x8]; // 0x798 (Size: 0x8, Type: PaddingProperty)
    TMap<FFabricMetaSoundNodeInfo, FName> SplitterNodes; // 0x7a0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UFabricMetaSoundSplitterPatchWrapper) == 0x7f0, "Size mismatch for UFabricMetaSoundSplitterPatchWrapper");
static_assert(offsetof(UFabricMetaSoundSplitterPatchWrapper, SplitterNodes) == 0x7a0, "Offset mismatch for UFabricMetaSoundSplitterPatchWrapper::SplitterNodes");

// Size: 0x2b0 (Inherited: 0x158, Single: 0x158)
class UFabricMetaSoundTickSubsystem : public UFortManagedTickSubsystem
{
public:
};

static_assert(sizeof(UFabricMetaSoundTickSubsystem) == 0x2b0, "Size mismatch for UFabricMetaSoundTickSubsystem");

// Size: 0x1a8 (Inherited: 0x28, Single: 0x180)
class UFabricMetaSoundUtilityProviderPatchWrapper : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TSoftObjectPtr<UMetaSoundPatch*> MetaSoundPatch; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    bool bUseAsMusicProvider; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bUseAsClockProvider; // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bUseAsTransportProvider; // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bManagesOwnMusicState; // 0x53 (Size: 0x1, Type: BoolProperty)
    int32_t Priority; // 0x54 (Size: 0x4, Type: IntProperty)
    bool bRunsOnServer; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    UFabricMetaSoundManagerComponent* CurrentManager; // 0x60 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundNodeInfo CurrentNode; // 0x68 (Size: 0xf0, Type: StructProperty)
    uint8_t Pad_158[0x20]; // 0x158 (Size: 0x20, Type: PaddingProperty)
    TWeakObjectPtr<UAudioComponent*> CurrentAudioComponent; // 0x178 (Size: 0x8, Type: WeakObjectProperty)
    FFabricTransportRequestConfig TransportRequestConfig; // 0x180 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_188[0x8]; // 0x188 (Size: 0x8, Type: PaddingProperty)
    UMetaSoundPatch* LoadedMetaSoundPatch; // 0x190 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_198[0x10]; // 0x198 (Size: 0x10, Type: PaddingProperty)

public:
    bool GetRunsOnServer() const; // 0x111a5d8c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FFabricTransportRequestConfig GetTransportRequestConfig() const; // 0x111a5da0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveFromCurrentGraph(); // 0xa20b3a8 (Index: 0x4, Flags: Native|Public|BlueprintCallable)
    void SetRunsOnServer(bool& bAllowRunOnServer); // 0x111a7dd0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void OnAddedToManagerGraph(UFabricMetaSoundManagerComponent*& Manager); // 0xb084dc0 (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent)
    void OnMetasoundManagerEndPlay(); // 0xa20b3a8 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricMetaSoundUtilityProviderPatchWrapper) == 0x1a8, "Size mismatch for UFabricMetaSoundUtilityProviderPatchWrapper");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, MetaSoundPatch) == 0x30, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::MetaSoundPatch");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, bUseAsMusicProvider) == 0x50, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::bUseAsMusicProvider");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, bUseAsClockProvider) == 0x51, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::bUseAsClockProvider");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, bUseAsTransportProvider) == 0x52, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::bUseAsTransportProvider");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, bManagesOwnMusicState) == 0x53, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::bManagesOwnMusicState");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, Priority) == 0x54, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::Priority");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, bRunsOnServer) == 0x58, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::bRunsOnServer");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, CurrentManager) == 0x60, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::CurrentManager");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, CurrentNode) == 0x68, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::CurrentNode");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, CurrentAudioComponent) == 0x178, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::CurrentAudioComponent");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, TransportRequestConfig) == 0x180, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::TransportRequestConfig");
static_assert(offsetof(UFabricMetaSoundUtilityProviderPatchWrapper, LoadedMetaSoundPatch) == 0x190, "Offset mismatch for UFabricMetaSoundUtilityProviderPatchWrapper::LoadedMetaSoundPatch");

// Size: 0x160 (Inherited: 0xe0, Single: 0x80)
class UFabricMidiFollowComponent : public UActorComponent
{
public:
    uint8_t OnFollowLengthFinished[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFollowSourcesSet[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_d8[0x20]; // 0xd8 (Size: 0x20, Type: PaddingProperty)
    uint8_t FollowMidiFile[0xc]; // 0xf8 (Size: 0xc, Type: OptionalProperty)
    uint8_t FollowLevelSequence[0xc]; // 0x104 (Size: 0xc, Type: OptionalProperty)
    uint8_t Pad_110[0x10]; // 0x110 (Size: 0x10, Type: PaddingProperty)
    FMusicTimestamp SelectedMidiTrackStartTimestamp; // 0x120 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp ExternalSourceStartTimestamp; // 0x128 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp SelectedMidiTrackEndTimestamp; // 0x130 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp ExternalSourceEndTimestamp; // 0x138 (Size: 0x8, Type: StructProperty)
    FMidiFollowData MidiFollowData; // 0x140 (Size: 0x8, Type: StructProperty)
    uint8_t DesiredLoopBehaviour; // 0x148 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_149[0x17]; // 0x149 (Size: 0x17, Type: PaddingProperty)

public:
    int32_t ClampSelectedMidiIndex(UMidiFile*& const InMidiFile, int32_t& InMidiTrackIndex) const; // 0x111a43bc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFollowLengthSeconds() const; // 0x111a45d0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetFollowName() const; // 0x111a45f8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFollowStartTimeSeconds() const; // 0x111a4624 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnFabricZoneSystemSet(AFabricZoneSystem*& const FabricZoneSystem); // 0x111a67b0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetControllingTimeline(bool& bInControllingTimeline); // 0x111a7570 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetMidiFollowData(const FMidiFollowData InMidiFollowData, EFabricMidiPlayerLoopType& InLoopBehaviour); // 0x111a7b3c (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void StartFollowing(FMusicTimestamp& InStartTimestamp); // 0x111a8790 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void StopFollowing(); // 0x111a8858 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMidiFollowComponent) == 0x160, "Size mismatch for UFabricMidiFollowComponent");
static_assert(offsetof(UFabricMidiFollowComponent, OnFollowLengthFinished) == 0xb8, "Offset mismatch for UFabricMidiFollowComponent::OnFollowLengthFinished");
static_assert(offsetof(UFabricMidiFollowComponent, OnFollowSourcesSet) == 0xc8, "Offset mismatch for UFabricMidiFollowComponent::OnFollowSourcesSet");
static_assert(offsetof(UFabricMidiFollowComponent, FollowMidiFile) == 0xf8, "Offset mismatch for UFabricMidiFollowComponent::FollowMidiFile");
static_assert(offsetof(UFabricMidiFollowComponent, FollowLevelSequence) == 0x104, "Offset mismatch for UFabricMidiFollowComponent::FollowLevelSequence");
static_assert(offsetof(UFabricMidiFollowComponent, SelectedMidiTrackStartTimestamp) == 0x120, "Offset mismatch for UFabricMidiFollowComponent::SelectedMidiTrackStartTimestamp");
static_assert(offsetof(UFabricMidiFollowComponent, ExternalSourceStartTimestamp) == 0x128, "Offset mismatch for UFabricMidiFollowComponent::ExternalSourceStartTimestamp");
static_assert(offsetof(UFabricMidiFollowComponent, SelectedMidiTrackEndTimestamp) == 0x130, "Offset mismatch for UFabricMidiFollowComponent::SelectedMidiTrackEndTimestamp");
static_assert(offsetof(UFabricMidiFollowComponent, ExternalSourceEndTimestamp) == 0x138, "Offset mismatch for UFabricMidiFollowComponent::ExternalSourceEndTimestamp");
static_assert(offsetof(UFabricMidiFollowComponent, MidiFollowData) == 0x140, "Offset mismatch for UFabricMidiFollowComponent::MidiFollowData");
static_assert(offsetof(UFabricMidiFollowComponent, DesiredLoopBehaviour) == 0x148, "Offset mismatch for UFabricMidiFollowComponent::DesiredLoopBehaviour");

// Size: 0x830 (Inherited: 0x12e8, Single: 0xfffff548)
class UFabricMIDIPlayerPatchWrapper : public UFabricNoteReceivedPatchWrapper
{
public:
    FName MidiTrackIndexUserOptionName; // 0x800 (Size: 0x4, Type: NameProperty)
    FName EnableMidiOutputName; // 0x804 (Size: 0x4, Type: NameProperty)
    FName TempoMapMidiOutName; // 0x808 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_80c[0x4]; // 0x80c (Size: 0x4, Type: PaddingProperty)
    UMidiFile* CurrentMidiFile; // 0x810 (Size: 0x8, Type: ObjectProperty)
    FName MidiTrackName; // 0x818 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_81c[0x14]; // 0x81c (Size: 0x14, Type: PaddingProperty)

public:
    void SetControlsTempo(bool& bInControlsTempo); // 0x111a769c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetMidiFile(UMidiFile*& InMidiFile, const FName InMidiTrackName); // 0x111a7980 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetMidiOutputEnabled(bool& bMidiOutputEnabled); // 0x111a7ca4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricMIDIPlayerPatchWrapper) == 0x830, "Size mismatch for UFabricMIDIPlayerPatchWrapper");
static_assert(offsetof(UFabricMIDIPlayerPatchWrapper, MidiTrackIndexUserOptionName) == 0x800, "Offset mismatch for UFabricMIDIPlayerPatchWrapper::MidiTrackIndexUserOptionName");
static_assert(offsetof(UFabricMIDIPlayerPatchWrapper, EnableMidiOutputName) == 0x804, "Offset mismatch for UFabricMIDIPlayerPatchWrapper::EnableMidiOutputName");
static_assert(offsetof(UFabricMIDIPlayerPatchWrapper, TempoMapMidiOutName) == 0x808, "Offset mismatch for UFabricMIDIPlayerPatchWrapper::TempoMapMidiOutName");
static_assert(offsetof(UFabricMIDIPlayerPatchWrapper, CurrentMidiFile) == 0x810, "Offset mismatch for UFabricMIDIPlayerPatchWrapper::CurrentMidiFile");
static_assert(offsetof(UFabricMIDIPlayerPatchWrapper, MidiTrackName) == 0x818, "Offset mismatch for UFabricMIDIPlayerPatchWrapper::MidiTrackName");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricMidiProvider : public UInterface
{
public:
};

static_assert(sizeof(UFabricMidiProvider) == 0x28, "Size mismatch for UFabricMidiProvider");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricModulator : public UInterface
{
public:
};

static_assert(sizeof(UFabricModulator) == 0x28, "Size mismatch for UFabricModulator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricModulatorSource : public UInterface
{
public:

public:
    virtual void GetModulators(UFabricModulatable*& Modulatable); // 0xcc47d7c (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
    virtual UPlaylistUserOptionBase* GetUserOption(FString& Property) const; // 0x111a5db8 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(UFabricModulatorSource) == 0x28, "Size mismatch for UFabricModulatorSource");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricModulatorDevice : public UInterface
{
public:

public:
    virtual void SetUserOption(EFabricUserOptionType& UserOptionType, UPlaylistUserOptionBase*& UserOption, UObject*& ModulatorObject); // 0x111a84bc (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFabricModulatorDevice) == 0x28, "Size mismatch for UFabricModulatorDevice");

// Size: 0x118 (Inherited: 0xe0, Single: 0x38)
class UFabricProgressorManager : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnGlobalProgressionChanged[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bHasActiveGlobalProgression; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bInPlayMode; // 0xd1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d2[0x2]; // 0xd2 (Size: 0x2, Type: PaddingProperty)
    int32_t GlobalPresetNumber; // 0xd4 (Size: 0x4, Type: IntProperty)
    FFabricProgressionPreset GlobalProgression; // 0xd8 (Size: 0x20, Type: StructProperty)
    FFabricProgressionPreset StoredGlobalProgression; // 0xf8 (Size: 0x20, Type: StructProperty)

public:
    int32_t GetGlobalPresetNumber() const; // 0x111a463c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FFabricProgressionPreset GetGlobalProgression() const; // 0x111a4654 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasActiveGlobalProgression() const; // 0x111a60b4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsProgressionGlobal(const FFabricProgressionPreset InProgression); // 0x111a66ac (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    void OnProgressionChanged__DelegateSignature(); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)
    void SetGlobalProgression(const FFabricProgressionPreset InProgression, int32_t& InPresetNumber); // 0x111a77c8 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& NewMinigameState); // 0x111a6c58 (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricProgressorManager) == 0x118, "Size mismatch for UFabricProgressorManager");
static_assert(offsetof(UFabricProgressorManager, OnGlobalProgressionChanged) == 0xc0, "Offset mismatch for UFabricProgressorManager::OnGlobalProgressionChanged");
static_assert(offsetof(UFabricProgressorManager, bHasActiveGlobalProgression) == 0xd0, "Offset mismatch for UFabricProgressorManager::bHasActiveGlobalProgression");
static_assert(offsetof(UFabricProgressorManager, bInPlayMode) == 0xd1, "Offset mismatch for UFabricProgressorManager::bInPlayMode");
static_assert(offsetof(UFabricProgressorManager, GlobalPresetNumber) == 0xd4, "Offset mismatch for UFabricProgressorManager::GlobalPresetNumber");
static_assert(offsetof(UFabricProgressorManager, GlobalProgression) == 0xd8, "Offset mismatch for UFabricProgressorManager::GlobalProgression");
static_assert(offsetof(UFabricProgressorManager, StoredGlobalProgression) == 0xf8, "Offset mismatch for UFabricProgressorManager::StoredGlobalProgression");

// Size: 0xa40 (Inherited: 0x2780, Single: 0xffffe2c0)
class UFabricSequencerPreviewFXComponent : public UFabricSteppedPreviewFXComponent
{
public:
    TWeakObjectPtr<UFabricStepSequencerComponent*> StepSequencer; // 0xa28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricStepSequencerGridComponent*> StepSequencerGrid; // 0xa30 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_a38[0x8]; // 0xa38 (Size: 0x8, Type: PaddingProperty)

public:
    void InitializePreviewFXComponent(UFabricStepSequencerComponent*& InStepSequencer, UFabricStepSequencerGridComponent*& InStepSequencerGrid, bool& bInTestNotesOn); // 0x111a60cc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)

private:
    void SetSingleTrackNoteOn(int32_t& InstanceIndex, int32_t& TrackPICDIndex, float& NoteOn, bool& bMarkRenderStateDirty); // 0x111a7ef8 (Index: 0x3, Flags: Final|Native|Private|BlueprintCallable)
    void SetSustainLength(int32_t& InstanceIndex, float& SustainLengthBeats); // 0x111a82b4 (Index: 0x4, Flags: Final|Native|Private|BlueprintCallable)
    void UpdateNoteOn(int32_t& Index, int32_t& NumSteps, bool& bMarkRenderStateDirty); // 0x111a886c (Index: 0x5, Flags: Final|Native|Private|BlueprintCallable)

protected:
    void OnFullTableChanged(); // 0x111a6c44 (Index: 0x1, Flags: Final|Native|Protected)
    void OnStepChanged(const FFabricSequencerStepChangedInfo StepInfo); // 0x111a7490 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFabricSequencerPreviewFXComponent) == 0xa40, "Size mismatch for UFabricSequencerPreviewFXComponent");
static_assert(offsetof(UFabricSequencerPreviewFXComponent, StepSequencer) == 0xa28, "Offset mismatch for UFabricSequencerPreviewFXComponent::StepSequencer");
static_assert(offsetof(UFabricSequencerPreviewFXComponent, StepSequencerGrid) == 0xa30, "Offset mismatch for UFabricSequencerPreviewFXComponent::StepSequencerGrid");

// Size: 0xa30 (Inherited: 0x1d50, Single: 0xffffece0)
class UFabricSteppedPreviewFXComponent : public UInstancedStaticMeshComponent
{
public:
    int32_t NumberOfSteps; // 0x9a0 (Size: 0x4, Type: IntProperty)
    bool bManuallySpaceMeshInstances; // 0x9a4 (Size: 0x1, Type: BoolProperty)
    bool bAllowMultipleRows; // 0x9a5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9a6[0x2]; // 0x9a6 (Size: 0x2, Type: PaddingProperty)
    int32_t InstanceCountPerRow; // 0x9a8 (Size: 0x4, Type: IntProperty)
    float SpaceBetweenInstanceRows; // 0x9ac (Size: 0x4, Type: FloatProperty)
    bool bAlignToTransformCenter; // 0x9b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9b1[0x3]; // 0x9b1 (Size: 0x3, Type: PaddingProperty)
    float CenterAlignmentBounds; // 0x9b4 (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenInstances; // 0x9b8 (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenTripletInstances; // 0x9bc (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenInstanceSets; // 0x9c0 (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenTripletInstanceSets; // 0x9c4 (Size: 0x4, Type: FloatProperty)
    uint8_t NoteStyle; // 0x9c8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9c9[0x3]; // 0x9c9 (Size: 0x3, Type: PaddingProperty)
    int32_t CPDDeviceEnabled; // 0x9cc (Size: 0x4, Type: IntProperty)
    int32_t CPDNumSteps; // 0x9d0 (Size: 0x4, Type: IntProperty)
    int32_t PICDNoteOn; // 0x9d4 (Size: 0x4, Type: IntProperty)
    int32_t PICDNoteLength; // 0x9d8 (Size: 0x4, Type: IntProperty)
    int32_t PICDSpanLength; // 0x9dc (Size: 0x4, Type: IntProperty)
    int32_t PICDNoteTime; // 0x9e0 (Size: 0x4, Type: IntProperty)
    int32_t PICDGenericFloatIndex; // 0x9e4 (Size: 0x4, Type: IntProperty)
    float LengthStepBeats; // 0x9e8 (Size: 0x4, Type: FloatProperty)
    float StepRate; // 0x9ec (Size: 0x4, Type: FloatProperty)
    float StepBeatScale; // 0x9f0 (Size: 0x4, Type: FloatProperty)
    float StepBeatOffset; // 0x9f4 (Size: 0x4, Type: FloatProperty)
    int32_t TimeSignatureNumerator; // 0x9f8 (Size: 0x4, Type: IntProperty)
    int32_t TimeSignatureDenominator; // 0x9fc (Size: 0x4, Type: IntProperty)
    float LengthTrackBeats; // 0xa00 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_a04[0x4]; // 0xa04 (Size: 0x4, Type: PaddingProperty)
    double InstanceSpace; // 0xa08 (Size: 0x8, Type: DoubleProperty)
    double InstanceSetSpace; // 0xa10 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_a18[0x18]; // 0xa18 (Size: 0x18, Type: PaddingProperty)

public:
    void ConstructPreviewVisuals(int32_t& NumSteps, float& StepBeatLength, bool& bForceUpdateTransform, bool& bInTestNotesOn); // 0x111aa3d0 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    void UpdateDeviceEnabledFX(bool& bEnabled); // 0x111b2830 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateExistingTransforms(int32_t& NumInstances, int32_t& NumSteps); // 0x111b2ab0 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)

protected:
    float GetNoteOn(int32_t& InstanceIndex); // 0x111ab3c8 (Index: 0x1, Flags: Native|Protected|BlueprintCallable)
    void OnBeatOffsetChanged(float& BeatOffset); // 0x111ad0b8 (Index: 0x2, Flags: Native|Protected)
    void OnBeatScaleChanged(float& BeatScale); // 0x111ad1e8 (Index: 0x3, Flags: Native|Protected)
    void OnNoteStyleChanged(EFabricNoteStyle& Style); // 0x111ad32c (Index: 0x4, Flags: Native|Protected)
    void OnNumStepsChanged(int32_t& NumSteps); // 0x111ad588 (Index: 0x5, Flags: Native|Protected)
    void OnNumTracksChanged(int32_t& NumTracks); // 0x111ad6b4 (Index: 0x6, Flags: Native|Protected)
    void OnPageChanged(int32_t& CurrentPage); // 0x111ad7e0 (Index: 0x7, Flags: Native|Protected)
    void OnStepRateChanged(float& StepRate); // 0x111ada00 (Index: 0x8, Flags: Native|Protected)
    void OnTimeSignatureChanged(int32_t& Numerator, int32_t& Denominator); // 0x111adb30 (Index: 0x9, Flags: Native|Protected)
    void SetGenericFloatValue(int32_t& InstanceIndex, float& FloatValue, bool& bMarkRenderStateDirty); // 0x111ae9a8 (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable)
    void SetNoteLength(int32_t& InstanceIndex, float& NoteLengthBeats); // 0x111af660 (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
    void SetNoteOn(int32_t& InstanceIndex, float& NoteOn, bool& bMarkRenderStateDirty); // 0x111af868 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable)
    void SetNoteTime(int32_t& InstanceIndex, float& NoteTimeOffsetBeats); // 0x111afc78 (Index: 0xd, Flags: Final|Native|Protected|BlueprintCallable)
    void SetNumSteps(int32_t& NumSteps); // 0x111afe80 (Index: 0xe, Flags: Final|Native|Protected|BlueprintCallable)
    void SetSpanLength(int32_t& InstanceIndex, float& SpanLengthBeats); // 0x111b04ac (Index: 0xf, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateAllCurrentStepData(int32_t& NumSteps, float& StepLengthBeats); // 0x111b2274 (Index: 0x10, Flags: Native|Protected|BlueprintCallable)
    void UpdateAllCurrentStepDataWithStepRate(int32_t& NumSteps, float& StepRate, int32_t& TimeSigNumerator, int32_t& TimeSigDenominator); // 0x111b2480 (Index: 0x11, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateStepData(int32_t& Index, bool& bMarkRenderStateDirty); // 0x111b2d94 (Index: 0x14, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFabricSteppedPreviewFXComponent) == 0xa30, "Size mismatch for UFabricSteppedPreviewFXComponent");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, NumberOfSteps) == 0x9a0, "Offset mismatch for UFabricSteppedPreviewFXComponent::NumberOfSteps");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, bManuallySpaceMeshInstances) == 0x9a4, "Offset mismatch for UFabricSteppedPreviewFXComponent::bManuallySpaceMeshInstances");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, bAllowMultipleRows) == 0x9a5, "Offset mismatch for UFabricSteppedPreviewFXComponent::bAllowMultipleRows");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, InstanceCountPerRow) == 0x9a8, "Offset mismatch for UFabricSteppedPreviewFXComponent::InstanceCountPerRow");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, SpaceBetweenInstanceRows) == 0x9ac, "Offset mismatch for UFabricSteppedPreviewFXComponent::SpaceBetweenInstanceRows");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, bAlignToTransformCenter) == 0x9b0, "Offset mismatch for UFabricSteppedPreviewFXComponent::bAlignToTransformCenter");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, CenterAlignmentBounds) == 0x9b4, "Offset mismatch for UFabricSteppedPreviewFXComponent::CenterAlignmentBounds");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, DistanceBetweenInstances) == 0x9b8, "Offset mismatch for UFabricSteppedPreviewFXComponent::DistanceBetweenInstances");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, DistanceBetweenTripletInstances) == 0x9bc, "Offset mismatch for UFabricSteppedPreviewFXComponent::DistanceBetweenTripletInstances");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, DistanceBetweenInstanceSets) == 0x9c0, "Offset mismatch for UFabricSteppedPreviewFXComponent::DistanceBetweenInstanceSets");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, DistanceBetweenTripletInstanceSets) == 0x9c4, "Offset mismatch for UFabricSteppedPreviewFXComponent::DistanceBetweenTripletInstanceSets");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, NoteStyle) == 0x9c8, "Offset mismatch for UFabricSteppedPreviewFXComponent::NoteStyle");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, CPDDeviceEnabled) == 0x9cc, "Offset mismatch for UFabricSteppedPreviewFXComponent::CPDDeviceEnabled");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, CPDNumSteps) == 0x9d0, "Offset mismatch for UFabricSteppedPreviewFXComponent::CPDNumSteps");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, PICDNoteOn) == 0x9d4, "Offset mismatch for UFabricSteppedPreviewFXComponent::PICDNoteOn");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, PICDNoteLength) == 0x9d8, "Offset mismatch for UFabricSteppedPreviewFXComponent::PICDNoteLength");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, PICDSpanLength) == 0x9dc, "Offset mismatch for UFabricSteppedPreviewFXComponent::PICDSpanLength");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, PICDNoteTime) == 0x9e0, "Offset mismatch for UFabricSteppedPreviewFXComponent::PICDNoteTime");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, PICDGenericFloatIndex) == 0x9e4, "Offset mismatch for UFabricSteppedPreviewFXComponent::PICDGenericFloatIndex");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, LengthStepBeats) == 0x9e8, "Offset mismatch for UFabricSteppedPreviewFXComponent::LengthStepBeats");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, StepRate) == 0x9ec, "Offset mismatch for UFabricSteppedPreviewFXComponent::StepRate");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, StepBeatScale) == 0x9f0, "Offset mismatch for UFabricSteppedPreviewFXComponent::StepBeatScale");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, StepBeatOffset) == 0x9f4, "Offset mismatch for UFabricSteppedPreviewFXComponent::StepBeatOffset");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, TimeSignatureNumerator) == 0x9f8, "Offset mismatch for UFabricSteppedPreviewFXComponent::TimeSignatureNumerator");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, TimeSignatureDenominator) == 0x9fc, "Offset mismatch for UFabricSteppedPreviewFXComponent::TimeSignatureDenominator");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, LengthTrackBeats) == 0xa00, "Offset mismatch for UFabricSteppedPreviewFXComponent::LengthTrackBeats");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, InstanceSpace) == 0xa08, "Offset mismatch for UFabricSteppedPreviewFXComponent::InstanceSpace");
static_assert(offsetof(UFabricSteppedPreviewFXComponent, InstanceSetSpace) == 0xa10, "Offset mismatch for UFabricSteppedPreviewFXComponent::InstanceSetSpace");

// Size: 0xa20 (Inherited: 0x1d50, Single: 0xffffecd0)
class UFabricSequencerSustainComponent : public UInstancedStaticMeshComponent
{
public:
    TMap<int32_t, FIntVector2> StepToInstanceMapping; // 0x9a0 (Size: 0x50, Type: MapProperty)
    int32_t PICDStartBeat; // 0x9f0 (Size: 0x4, Type: IntProperty)
    int32_t PICDEndBeat; // 0x9f4 (Size: 0x4, Type: IntProperty)
    int32_t PICDLoopBeat; // 0x9f8 (Size: 0x4, Type: IntProperty)
    int32_t CPDDeviceEnabled; // 0x9fc (Size: 0x4, Type: IntProperty)
    float GridSquareExtents; // 0xa00 (Size: 0x4, Type: FloatProperty)
    float SustainInstanceYLocation; // 0xa04 (Size: 0x4, Type: FloatProperty)
    float SustainInstanceYScale; // 0xa08 (Size: 0x4, Type: FloatProperty)
    float SustainInstanceZScale; // 0xa0c (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UFabricStepSequencerComponent*> StepSequencer; // 0xa10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricStepSequencerGridComponent*> StepSequencerGrid; // 0xa18 (Size: 0x8, Type: WeakObjectProperty)

public:
    void InitializeSustainComponent(UFabricStepSequencerComponent*& InStepSequencer, UFabricStepSequencerGridComponent*& InStepSequencerGrid); // 0x111aca1c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void AddSustainInstance(int32_t& StepIndex, int32_t& TrackIndex); // 0x111a98bc (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    float CalculateSustainLength(float& NumStepsCoveredBySustain); // 0x111aa07c (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void ConstructSustains(); // 0x111aa798 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void FindAndDeleteInstance(int32_t& StepIndex, int32_t& TrackIndex); // 0x111aa7ac (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    void FindHeadNoteAndUpdateInstance(int32_t& StepIndex, int32_t& TrackIndex); // 0x111aa9b4 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
    void OnFullTableChanged(); // 0x111ad318 (Index: 0x6, Flags: Final|Native|Protected)
    void OnNumStepsChanged(int32_t& NumSteps); // 0x111ad45c (Index: 0x7, Flags: Native|Protected)
    void OnNumTracksChanged(int32_t& NumTracks); // 0x111ad588 (Index: 0x8, Flags: Native|Protected)
    void OnPageChanged(int32_t& CurrentPage); // 0x111ad6b4 (Index: 0x9, Flags: Native|Protected)
    void OnStepChanged(const FFabricSequencerStepChangedInfo StepInfo); // 0x111ad920 (Index: 0xa, Flags: Final|Native|Protected|HasOutParms)
    void SetEndBeat(int32_t& InstanceIndex, float& EndBeatValue); // 0x111ae7a0 (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
    void SetLoopBeat(int32_t& InstanceIndex, float& LoopBeatValue); // 0x111aedb8 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable)
    void SetStartBeat(int32_t& InstanceIndex, float& StartBeatValue); // 0x111b06b4 (Index: 0xd, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateDeviceEnabledOnSustain(bool& bEnabled); // 0x111b2970 (Index: 0xe, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdatePipsOnGridChanged(); // 0x111b2d80 (Index: 0xf, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateSustainInstance(int32_t& StepIndex, int32_t& TrackIndex, int32_t& PageIndex, bool& bEnabled, bool& bContinuous, bool& bStepChanged); // 0x111b2fa0 (Index: 0x10, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateSustainMaterial(int32_t& InstanceIndex, int32_t& HeadNoteStepIndex, int32_t& TrackIndex); // 0x111b350c (Index: 0x11, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateVisibilityOfInstances(); // 0x111b37ec (Index: 0x12, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFabricSequencerSustainComponent) == 0xa20, "Size mismatch for UFabricSequencerSustainComponent");
static_assert(offsetof(UFabricSequencerSustainComponent, StepToInstanceMapping) == 0x9a0, "Offset mismatch for UFabricSequencerSustainComponent::StepToInstanceMapping");
static_assert(offsetof(UFabricSequencerSustainComponent, PICDStartBeat) == 0x9f0, "Offset mismatch for UFabricSequencerSustainComponent::PICDStartBeat");
static_assert(offsetof(UFabricSequencerSustainComponent, PICDEndBeat) == 0x9f4, "Offset mismatch for UFabricSequencerSustainComponent::PICDEndBeat");
static_assert(offsetof(UFabricSequencerSustainComponent, PICDLoopBeat) == 0x9f8, "Offset mismatch for UFabricSequencerSustainComponent::PICDLoopBeat");
static_assert(offsetof(UFabricSequencerSustainComponent, CPDDeviceEnabled) == 0x9fc, "Offset mismatch for UFabricSequencerSustainComponent::CPDDeviceEnabled");
static_assert(offsetof(UFabricSequencerSustainComponent, GridSquareExtents) == 0xa00, "Offset mismatch for UFabricSequencerSustainComponent::GridSquareExtents");
static_assert(offsetof(UFabricSequencerSustainComponent, SustainInstanceYLocation) == 0xa04, "Offset mismatch for UFabricSequencerSustainComponent::SustainInstanceYLocation");
static_assert(offsetof(UFabricSequencerSustainComponent, SustainInstanceYScale) == 0xa08, "Offset mismatch for UFabricSequencerSustainComponent::SustainInstanceYScale");
static_assert(offsetof(UFabricSequencerSustainComponent, SustainInstanceZScale) == 0xa0c, "Offset mismatch for UFabricSequencerSustainComponent::SustainInstanceZScale");
static_assert(offsetof(UFabricSequencerSustainComponent, StepSequencer) == 0xa10, "Offset mismatch for UFabricSequencerSustainComponent::StepSequencer");
static_assert(offsetof(UFabricSequencerSustainComponent, StepSequencerGrid) == 0xa18, "Offset mismatch for UFabricSequencerSustainComponent::StepSequencerGrid");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFabricSignificanceAsset : public UDataAsset
{
public:
    TArray<FFabricSignificanceBasedUpdateBucket> UpdateBuckets; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFabricSignificanceAsset) == 0x40, "Size mismatch for UFabricSignificanceAsset");
static_assert(offsetof(UFabricSignificanceAsset, UpdateBuckets) == 0x30, "Offset mismatch for UFabricSignificanceAsset::UpdateBuckets");

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UFabricSpeakerManagerComponent : public UActorComponent
{
public:
    uint8_t OnMusicEventPriorityChanged[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnClientAudibleMusicEventGroupChanged[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t MusicEventPriority; // 0xd8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d9[0x3]; // 0xd9 (Size: 0x3, Type: PaddingProperty)
    FName ClientCurrentAudibleMusicEventGroup; // 0xdc (Size: 0x4, Type: NameProperty)
    FGameplayTag AboveEmotesTag; // 0xe0 (Size: 0x4, Type: StructProperty)
    FGameplayTag BelowEmotesTag; // 0xe4 (Size: 0x4, Type: StructProperty)
    float ReplicatedReceivedSignalBufferDuration; // 0xe8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ec[0x24]; // 0xec (Size: 0x24, Type: PaddingProperty)

public:
    FName GetCurrentClientAudibleMusicEventGroup() const; // 0xfea8f70 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetCurrentMusicEventTag() const; // 0x111aade4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricMetasoundMusicEventPriority GetMusicEventPriority() const; // 0x111ab270 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetMusicEventTag(EFabricMetasoundMusicEventPriority& InMusicEventPriority) const; // 0x111ab288 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RegisterAsAudible(AActor*& Device, const FName AudibleEventGroup); // 0x111ade7c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetMusicEventPriority(EFabricMetasoundMusicEventPriority& InMusicEventPriority); // 0x111af3d8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterAsAudible(AActor*& Device); // 0x111b1c20 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricSpeakerManagerComponent) == 0x110, "Size mismatch for UFabricSpeakerManagerComponent");
static_assert(offsetof(UFabricSpeakerManagerComponent, OnMusicEventPriorityChanged) == 0xb8, "Offset mismatch for UFabricSpeakerManagerComponent::OnMusicEventPriorityChanged");
static_assert(offsetof(UFabricSpeakerManagerComponent, OnClientAudibleMusicEventGroupChanged) == 0xc8, "Offset mismatch for UFabricSpeakerManagerComponent::OnClientAudibleMusicEventGroupChanged");
static_assert(offsetof(UFabricSpeakerManagerComponent, MusicEventPriority) == 0xd8, "Offset mismatch for UFabricSpeakerManagerComponent::MusicEventPriority");
static_assert(offsetof(UFabricSpeakerManagerComponent, ClientCurrentAudibleMusicEventGroup) == 0xdc, "Offset mismatch for UFabricSpeakerManagerComponent::ClientCurrentAudibleMusicEventGroup");
static_assert(offsetof(UFabricSpeakerManagerComponent, AboveEmotesTag) == 0xe0, "Offset mismatch for UFabricSpeakerManagerComponent::AboveEmotesTag");
static_assert(offsetof(UFabricSpeakerManagerComponent, BelowEmotesTag) == 0xe4, "Offset mismatch for UFabricSpeakerManagerComponent::BelowEmotesTag");
static_assert(offsetof(UFabricSpeakerManagerComponent, ReplicatedReceivedSignalBufferDuration) == 0xe8, "Offset mismatch for UFabricSpeakerManagerComponent::ReplicatedReceivedSignalBufferDuration");

// Size: 0x3b0 (Inherited: 0x350, Single: 0x60)
class UFabricStepSequencerModulatable : public UFabricModulatable
{
public:
    uint8_t Pad_328[0x80]; // 0x328 (Size: 0x80, Type: PaddingProperty)
    bool bIsChromatic; // 0x3a8 (Size: 0x1, Type: BoolProperty)
    bool bModulationValueChanged; // 0x3a9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3aa[0x6]; // 0x3aa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFabricStepSequencerModulatable) == 0x3b0, "Size mismatch for UFabricStepSequencerModulatable");
static_assert(offsetof(UFabricStepSequencerModulatable, bIsChromatic) == 0x3a8, "Offset mismatch for UFabricStepSequencerModulatable::bIsChromatic");
static_assert(offsetof(UFabricStepSequencerModulatable, bModulationValueChanged) == 0x3a9, "Offset mismatch for UFabricStepSequencerModulatable::bModulationValueChanged");

// Size: 0x368 (Inherited: 0xe0, Single: 0x288)
class UFabricStepSequencerComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnNumTracksChanged[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNumStepsChanged[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPageChanged[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStepRateChanged[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTimeSignatureChanged[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBeatScaleChanged[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBeatOffsetChanged[0x10]; // 0x128 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStepChanged[0x10]; // 0x138 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNoteStyleChanged[0x10]; // 0x148 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFullTableChanged[0x10]; // 0x158 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPageCleared[0x10]; // 0x168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLoopEnded[0x10]; // 0x178 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString LengthParam; // 0x188 (Size: 0x10, Type: StrProperty)
    FString DurationParam; // 0x198 (Size: 0x10, Type: StrProperty)
    FString PageParam; // 0x1a8 (Size: 0x10, Type: StrProperty)
    FString AutoPageParam; // 0x1b8 (Size: 0x10, Type: StrProperty)
    FString OctaveParam; // 0x1c8 (Size: 0x10, Type: StrProperty)
    FString NoteStyleParam; // 0x1d8 (Size: 0x10, Type: StrProperty)
    FString LoopParam; // 0x1e8 (Size: 0x10, Type: StrProperty)
    FString AutoPagePlaysBlankPagesParam; // 0x1f8 (Size: 0x10, Type: StrProperty)
    bool bMonophonic; // 0x208 (Size: 0x1, Type: BoolProperty)
    bool bSupportsContinuation; // 0x209 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_20a[0x2]; // 0x20a (Size: 0x2, Type: PaddingProperty)
    float StepRate; // 0x20c (Size: 0x4, Type: FloatProperty)
    float StepBeatScale; // 0x210 (Size: 0x4, Type: FloatProperty)
    bool bSkipFourthStepInTriplet; // 0x214 (Size: 0x1, Type: BoolProperty)
    uint8_t NoteStyle; // 0x215 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_216[0x2]; // 0x216 (Size: 0x2, Type: PaddingProperty)
    int32_t MaxSteps; // 0x218 (Size: 0x4, Type: IntProperty)
    int32_t CurrentSteps; // 0x21c (Size: 0x4, Type: IntProperty)
    bool bMatchStepsToTimeSignature; // 0x220 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_221[0x3]; // 0x221 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxPages; // 0x224 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPage; // 0x228 (Size: 0x4, Type: IntProperty)
    int32_t MaxTracks; // 0x22c (Size: 0x4, Type: IntProperty)
    int32_t CurrentTracks; // 0x230 (Size: 0x4, Type: IntProperty)
    int32_t LocalInteractionStartTrackIndex; // 0x234 (Size: 0x4, Type: IntProperty)
    int32_t LocalInteractionStartStepIndex; // 0x238 (Size: 0x4, Type: IntProperty)
    bool bAutoPage; // 0x23c (Size: 0x1, Type: BoolProperty)
    bool bAutoPagePlaysBlankPages; // 0x23d (Size: 0x1, Type: BoolProperty)
    bool bLoop; // 0x23e (Size: 0x1, Type: BoolProperty)
    char RandomizationCommonSampleSize; // 0x23f (Size: 0x1, Type: ByteProperty)
    float RandomizationRestSelectionMaxPct; // 0x240 (Size: 0x4, Type: FloatProperty)
    float RandomizationCommonPitchSelectionMaxPct; // 0x244 (Size: 0x4, Type: FloatProperty)
    UClass* ContinuationControlClass; // 0x248 (Size: 0x8, Type: ClassProperty)
    FStepSequenceTable LocalStepTable; // 0x250 (Size: 0x28, Type: StructProperty)
    FFabricStepTablePacked PackedStepTable; // 0x278 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2a0[0x28]; // 0x2a0 (Size: 0x28, Type: PaddingProperty)
    UFabricStepSequencerModulatable* StepSequencerModulatable; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    AActor* CachedContinuationControl; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    int32_t ContinuationRowIndex; // 0x2d8 (Size: 0x4, Type: IntProperty)
    int32_t ContinuationStepIndex; // 0x2dc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2e0[0x8]; // 0x2e0 (Size: 0x8, Type: PaddingProperty)
    UMidiStepSequence* MetaSoundMidiStepSequence; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f0[0x78]; // 0x2f0 (Size: 0x78, Type: PaddingProperty)

public:
    void ApplyPage(int32_t& PageIndex, const FStepSequencePage PageData); // 0x111a9ac4 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ApplyTemplate(UMidiStepSequence*& const Template, int32_t& StepSequencePageIndex, bool& const bUpdateSaveRecord); // 0x111a9c84 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ClearCurrentPage(); // 0x111aa1b8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void ClearPage(int32_t& Page, bool& const bUpdateSaveRecord); // 0x111aa1d0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void GetContinuationFocusIndeces(int32_t& OutRowIndex, int32_t& OutStepIndex, int32_t& OutNumContinuationSteps); // 0x111aabbc (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    int32_t GetCurrentPage() const; // 0xe412658 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLengthStepBeats() const; // 0x111aae0c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLengthStepQuarterNotes() const; // 0x111aae38 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLengthTrackBeats() const; // 0x111aae5c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLengthTrackQuarterNotes() const; // 0x111aaea4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLongestContinuationLengthForColumn(int32_t& Column) const; // 0x111aaee4 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLongestContinuationLengthForColumnOnPage(int32_t& Page, int32_t& Column) const; // 0x111ab024 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMaxSteps() const; // 0x111ab240 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMaxTracks() const; // 0x111ab258 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMidiStepSequence* GetMidiStepSequence(); // 0xa200d50 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    int32_t GetNumberSteps() const; // 0x10b32fb0 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberTracks() const; // 0xd42c368 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumUsedSteps(int32_t& TotalSteps) const; // 0x111ab508 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetPageData(int32_t& PageIndex, FStepSequencePage& OutPageData) const; // 0x111ab640 (Index: 0x12, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    float GetStepContinuationLength(int32_t& Row, int32_t& Column) const; // 0x111ab850 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStepContinuationLengthOnPage(int32_t& Page, int32_t& Row, int32_t& Column) const; // 0x111aba74 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetStepEnabled(int32_t& Row, int32_t& Column) const; // 0x111abd5c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetStepEnabledOnPage(int32_t& Page, int32_t& Row, int32_t& Column) const; // 0x111abf7c (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetStepIsContinuation(int32_t& Row, int32_t& Column) const; // 0x111ac260 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetStepIsContinuationOnPage(int32_t& Page, int32_t& Row, int32_t& Column) const; // 0x111ac480 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStepRate() const; // 0x111ac764 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStepStartBeat(int32_t& Step) const; // 0x111ac77c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStepStartQuarterNotes(int32_t& Step) const; // 0x111ac8d0 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSupportsContinuation() const; // 0xed0cbd8 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPageBlank(int32_t& PageIndex) const; // 0x111acc24 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsStepEnabledForAnyTrack(int32_t& Column) const; // 0x111acd60 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsStepEnabledForAnyTrackOnPage(int32_t& Page, int32_t& Column) const; // 0x111acea0 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RandomizeCurrentPage(); // 0x111add3c (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable)
    void RandomizePage(int32_t& Page); // 0x111add54 (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable)
    void SetBeatScale(float& BeatScale); // 0x111ae534 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurrentPage(int32_t& NewPage); // 0x111ae678 (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable)
    void SetLoop(bool& bNewLoop); // 0x111aec8c (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)
    void SetMaxSteps(int32_t& NumSteps); // 0x111aefc0 (Index: 0x26, Flags: Final|Native|Public|BlueprintCallable)
    void SetMonophonic(bool& bNewMonophonic); // 0xb4ac66c (Index: 0x27, Flags: Final|Native|Public|BlueprintCallable)
    void SetMusicClock(UMusicClockComponent*& InMusicClock); // 0x111af100 (Index: 0x28, Flags: Final|Native|Public|BlueprintCallable)
    void SetNoteForTrack(FMidiNote& Note, int32_t& Track); // 0x111af51c (Index: 0x29, Flags: Final|Native|Public|BlueprintCallable)
    void SetNoteStyle(EFabricNoteStyle& Style); // 0x111afb4c (Index: 0x2a, Flags: Final|Native|Public|BlueprintCallable)
    void SetNumberPages(int32_t& NumPages); // 0x111affa8 (Index: 0x2b, Flags: Final|Native|Public|BlueprintCallable)
    void SetNumberSteps(int32_t& NumSteps); // 0x111b00f4 (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable)
    void SetNumberTracks(int32_t& NumTracks); // 0x111b021c (Index: 0x2d, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlaying(bool& bNewPlaying); // 0x111b0380 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepContinuation(int32_t& Row, int32_t& Column, bool& bIsContinuation); // 0x111b08bc (Index: 0x2f, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepContinuationOnPage(int32_t& Page, int32_t& Row, int32_t& Column, bool& bIsContinuation); // 0x111b0b9c (Index: 0x30, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepEnabled(int32_t& Row, int32_t& Column, bool& bState); // 0x111b0f54 (Index: 0x31, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepEnabledOnPage(int32_t& Page, int32_t& Row, int32_t& Column, bool& bState); // 0x111b1234 (Index: 0x32, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepRate(float& InStepRate); // 0x111b15ec (Index: 0x33, Flags: Final|Native|Public|BlueprintCallable)
    void ToggleStepEnabled(int32_t& Row, int32_t& Column); // 0x111b1730 (Index: 0x34, Flags: Final|Native|Public|BlueprintCallable)
    void ToggleStepEnabledOnPage(int32_t& Page, int32_t& Row, int32_t& Column); // 0x111b1940 (Index: 0x35, Flags: Final|Native|Public|BlueprintCallable)
    void UpdatePackedStepTableSaveRecordIfChanged(const FFabricStepTablePacked InPackedStepTable); // 0x111b2cb8 (Index: 0x36, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnRep_PackedStepTable(); // 0x111ad90c (Index: 0x20, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricStepSequencerComponent) == 0x368, "Size mismatch for UFabricStepSequencerComponent");
static_assert(offsetof(UFabricStepSequencerComponent, OnNumTracksChanged) == 0xc8, "Offset mismatch for UFabricStepSequencerComponent::OnNumTracksChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnNumStepsChanged) == 0xd8, "Offset mismatch for UFabricStepSequencerComponent::OnNumStepsChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnPageChanged) == 0xe8, "Offset mismatch for UFabricStepSequencerComponent::OnPageChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnStepRateChanged) == 0xf8, "Offset mismatch for UFabricStepSequencerComponent::OnStepRateChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnTimeSignatureChanged) == 0x108, "Offset mismatch for UFabricStepSequencerComponent::OnTimeSignatureChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnBeatScaleChanged) == 0x118, "Offset mismatch for UFabricStepSequencerComponent::OnBeatScaleChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnBeatOffsetChanged) == 0x128, "Offset mismatch for UFabricStepSequencerComponent::OnBeatOffsetChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnStepChanged) == 0x138, "Offset mismatch for UFabricStepSequencerComponent::OnStepChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnNoteStyleChanged) == 0x148, "Offset mismatch for UFabricStepSequencerComponent::OnNoteStyleChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnFullTableChanged) == 0x158, "Offset mismatch for UFabricStepSequencerComponent::OnFullTableChanged");
static_assert(offsetof(UFabricStepSequencerComponent, OnPageCleared) == 0x168, "Offset mismatch for UFabricStepSequencerComponent::OnPageCleared");
static_assert(offsetof(UFabricStepSequencerComponent, OnLoopEnded) == 0x178, "Offset mismatch for UFabricStepSequencerComponent::OnLoopEnded");
static_assert(offsetof(UFabricStepSequencerComponent, LengthParam) == 0x188, "Offset mismatch for UFabricStepSequencerComponent::LengthParam");
static_assert(offsetof(UFabricStepSequencerComponent, DurationParam) == 0x198, "Offset mismatch for UFabricStepSequencerComponent::DurationParam");
static_assert(offsetof(UFabricStepSequencerComponent, PageParam) == 0x1a8, "Offset mismatch for UFabricStepSequencerComponent::PageParam");
static_assert(offsetof(UFabricStepSequencerComponent, AutoPageParam) == 0x1b8, "Offset mismatch for UFabricStepSequencerComponent::AutoPageParam");
static_assert(offsetof(UFabricStepSequencerComponent, OctaveParam) == 0x1c8, "Offset mismatch for UFabricStepSequencerComponent::OctaveParam");
static_assert(offsetof(UFabricStepSequencerComponent, NoteStyleParam) == 0x1d8, "Offset mismatch for UFabricStepSequencerComponent::NoteStyleParam");
static_assert(offsetof(UFabricStepSequencerComponent, LoopParam) == 0x1e8, "Offset mismatch for UFabricStepSequencerComponent::LoopParam");
static_assert(offsetof(UFabricStepSequencerComponent, AutoPagePlaysBlankPagesParam) == 0x1f8, "Offset mismatch for UFabricStepSequencerComponent::AutoPagePlaysBlankPagesParam");
static_assert(offsetof(UFabricStepSequencerComponent, bMonophonic) == 0x208, "Offset mismatch for UFabricStepSequencerComponent::bMonophonic");
static_assert(offsetof(UFabricStepSequencerComponent, bSupportsContinuation) == 0x209, "Offset mismatch for UFabricStepSequencerComponent::bSupportsContinuation");
static_assert(offsetof(UFabricStepSequencerComponent, StepRate) == 0x20c, "Offset mismatch for UFabricStepSequencerComponent::StepRate");
static_assert(offsetof(UFabricStepSequencerComponent, StepBeatScale) == 0x210, "Offset mismatch for UFabricStepSequencerComponent::StepBeatScale");
static_assert(offsetof(UFabricStepSequencerComponent, bSkipFourthStepInTriplet) == 0x214, "Offset mismatch for UFabricStepSequencerComponent::bSkipFourthStepInTriplet");
static_assert(offsetof(UFabricStepSequencerComponent, NoteStyle) == 0x215, "Offset mismatch for UFabricStepSequencerComponent::NoteStyle");
static_assert(offsetof(UFabricStepSequencerComponent, MaxSteps) == 0x218, "Offset mismatch for UFabricStepSequencerComponent::MaxSteps");
static_assert(offsetof(UFabricStepSequencerComponent, CurrentSteps) == 0x21c, "Offset mismatch for UFabricStepSequencerComponent::CurrentSteps");
static_assert(offsetof(UFabricStepSequencerComponent, bMatchStepsToTimeSignature) == 0x220, "Offset mismatch for UFabricStepSequencerComponent::bMatchStepsToTimeSignature");
static_assert(offsetof(UFabricStepSequencerComponent, MaxPages) == 0x224, "Offset mismatch for UFabricStepSequencerComponent::MaxPages");
static_assert(offsetof(UFabricStepSequencerComponent, CurrentPage) == 0x228, "Offset mismatch for UFabricStepSequencerComponent::CurrentPage");
static_assert(offsetof(UFabricStepSequencerComponent, MaxTracks) == 0x22c, "Offset mismatch for UFabricStepSequencerComponent::MaxTracks");
static_assert(offsetof(UFabricStepSequencerComponent, CurrentTracks) == 0x230, "Offset mismatch for UFabricStepSequencerComponent::CurrentTracks");
static_assert(offsetof(UFabricStepSequencerComponent, LocalInteractionStartTrackIndex) == 0x234, "Offset mismatch for UFabricStepSequencerComponent::LocalInteractionStartTrackIndex");
static_assert(offsetof(UFabricStepSequencerComponent, LocalInteractionStartStepIndex) == 0x238, "Offset mismatch for UFabricStepSequencerComponent::LocalInteractionStartStepIndex");
static_assert(offsetof(UFabricStepSequencerComponent, bAutoPage) == 0x23c, "Offset mismatch for UFabricStepSequencerComponent::bAutoPage");
static_assert(offsetof(UFabricStepSequencerComponent, bAutoPagePlaysBlankPages) == 0x23d, "Offset mismatch for UFabricStepSequencerComponent::bAutoPagePlaysBlankPages");
static_assert(offsetof(UFabricStepSequencerComponent, bLoop) == 0x23e, "Offset mismatch for UFabricStepSequencerComponent::bLoop");
static_assert(offsetof(UFabricStepSequencerComponent, RandomizationCommonSampleSize) == 0x23f, "Offset mismatch for UFabricStepSequencerComponent::RandomizationCommonSampleSize");
static_assert(offsetof(UFabricStepSequencerComponent, RandomizationRestSelectionMaxPct) == 0x240, "Offset mismatch for UFabricStepSequencerComponent::RandomizationRestSelectionMaxPct");
static_assert(offsetof(UFabricStepSequencerComponent, RandomizationCommonPitchSelectionMaxPct) == 0x244, "Offset mismatch for UFabricStepSequencerComponent::RandomizationCommonPitchSelectionMaxPct");
static_assert(offsetof(UFabricStepSequencerComponent, ContinuationControlClass) == 0x248, "Offset mismatch for UFabricStepSequencerComponent::ContinuationControlClass");
static_assert(offsetof(UFabricStepSequencerComponent, LocalStepTable) == 0x250, "Offset mismatch for UFabricStepSequencerComponent::LocalStepTable");
static_assert(offsetof(UFabricStepSequencerComponent, PackedStepTable) == 0x278, "Offset mismatch for UFabricStepSequencerComponent::PackedStepTable");
static_assert(offsetof(UFabricStepSequencerComponent, StepSequencerModulatable) == 0x2c8, "Offset mismatch for UFabricStepSequencerComponent::StepSequencerModulatable");
static_assert(offsetof(UFabricStepSequencerComponent, CachedContinuationControl) == 0x2d0, "Offset mismatch for UFabricStepSequencerComponent::CachedContinuationControl");
static_assert(offsetof(UFabricStepSequencerComponent, ContinuationRowIndex) == 0x2d8, "Offset mismatch for UFabricStepSequencerComponent::ContinuationRowIndex");
static_assert(offsetof(UFabricStepSequencerComponent, ContinuationStepIndex) == 0x2dc, "Offset mismatch for UFabricStepSequencerComponent::ContinuationStepIndex");
static_assert(offsetof(UFabricStepSequencerComponent, MetaSoundMidiStepSequence) == 0x2e8, "Offset mismatch for UFabricStepSequencerComponent::MetaSoundMidiStepSequence");

// Size: 0x340 (Inherited: 0x320, Single: 0x20)
class UFabricStepSequencerGridComponent : public USceneComponent
{
public:
    uint8_t Pad_240[0x10]; // 0x240 (Size: 0x10, Type: PaddingProperty)
    FVector2D GridExtents; // 0x250 (Size: 0x10, Type: StructProperty)
    FVector2D GridSpacing; // 0x260 (Size: 0x10, Type: StructProperty)
    int32_t SingleTrackNumItemsPerRow; // 0x270 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_274[0x4]; // 0x274 (Size: 0x4, Type: PaddingProperty)
    FVector2D EditorPreviewGridSize; // 0x278 (Size: 0x10, Type: StructProperty)
    UClass* GridSquareClassPtr; // 0x288 (Size: 0x8, Type: ClassProperty)
    TSoftClassPtr GridSquareClass; // 0x290 (Size: 0x20, Type: SoftClassProperty)
    TEnumAsByte<ESequencerType> SequencerType; // 0x2b0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2b1[0x3]; // 0x2b1 (Size: 0x3, Type: PaddingProperty)
    int32_t ActiveTrack; // 0x2b4 (Size: 0x4, Type: IntProperty)
    UFabricStepSequencerComponent* StepSequencer; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TArray<FTrackRow> GridRows; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2d0[0x60]; // 0x2d0 (Size: 0x60, Type: PaddingProperty)
    int32_t MaxTrackIndexToLoadSquares; // 0x330 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_334[0xc]; // 0x334 (Size: 0xc, Type: PaddingProperty)

public:
    FVector GetGridSquareExtents(int32_t& const RowIndex, int32_t& const ColumnIndex) const; // 0x111b7ab8 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector2D GetGridSquareSize(int32_t& const NumSteps, int32_t& const NumRows) const; // 0x111b7cf0 (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetGridSquareXPosition(int32_t& const NumSteps, int32_t& const StepIndex); // 0x111b7f48 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    float GetGridSquareYPosition(int32_t& const NumRows, int32_t& const RowIndex); // 0x111b8164 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsBypassed(); // 0x111b8394 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void NotifyInteractionFocusTargetExternallyChanged(APlayerController*& PlayerController, int32_t& SourceRowIndex, int32_t& SourceColumnIndex, int32_t& FocusRowIndex, int32_t& FocusColumnIndex, bool& bIsFocused); // 0x111b83ac (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetActiveTrackIndex(int32_t& ActiveTrackIndex); // 0x111b98bc (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void SetBypassed(bool& bBypassed); // 0x111b99e4 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void SetGridVisible(bool& bInGridVisible, bool& bForceRefresh); // 0x111b9c3c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnBeatOffsetChanged(float& BeatOffset); // 0x111b88d8 (Index: 0x6, Flags: Final|Native|Protected)
    void OnBeatScaleChanged(float& BeatScale); // 0x111b88d8 (Index: 0x7, Flags: Final|Native|Protected)
    void OnCurrentPageChanged(int32_t& NewPage); // 0x111b8a00 (Index: 0x8, Flags: Final|Native|Protected)
    void OnFullTableChanged(); // 0x111b8b24 (Index: 0x9, Flags: Final|Native|Protected)
    void OnNoteStyleChanged(EFabricNoteStyle& Style); // 0x111b8b38 (Index: 0xa, Flags: Final|Native|Protected)
    void OnNumStepsChanged(int32_t& NumSteps); // 0x111b8c60 (Index: 0xb, Flags: Final|Native|Protected)
    void OnNumTracksChanged(int32_t& NumTracks); // 0x111b8d88 (Index: 0xc, Flags: Final|Native|Protected)
    void OnRep_MaxTrackIndexToLoadSquares(); // 0x111b8eb0 (Index: 0xd, Flags: Final|Native|Protected)
    void OnStepChanged(const FFabricSequencerStepChangedInfo StepInfo); // 0x111b8edc (Index: 0xe, Flags: Final|Native|Protected|HasOutParms)
    void OnStepRateChanged(float& StepRate); // 0x111b88d8 (Index: 0xf, Flags: Final|Native|Protected)
    void OnTimeSignatureChanged(int32_t& Numerator, int32_t& Denominator); // 0x111b8fbc (Index: 0x10, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricStepSequencerGridComponent) == 0x340, "Size mismatch for UFabricStepSequencerGridComponent");
static_assert(offsetof(UFabricStepSequencerGridComponent, GridExtents) == 0x250, "Offset mismatch for UFabricStepSequencerGridComponent::GridExtents");
static_assert(offsetof(UFabricStepSequencerGridComponent, GridSpacing) == 0x260, "Offset mismatch for UFabricStepSequencerGridComponent::GridSpacing");
static_assert(offsetof(UFabricStepSequencerGridComponent, SingleTrackNumItemsPerRow) == 0x270, "Offset mismatch for UFabricStepSequencerGridComponent::SingleTrackNumItemsPerRow");
static_assert(offsetof(UFabricStepSequencerGridComponent, EditorPreviewGridSize) == 0x278, "Offset mismatch for UFabricStepSequencerGridComponent::EditorPreviewGridSize");
static_assert(offsetof(UFabricStepSequencerGridComponent, GridSquareClassPtr) == 0x288, "Offset mismatch for UFabricStepSequencerGridComponent::GridSquareClassPtr");
static_assert(offsetof(UFabricStepSequencerGridComponent, GridSquareClass) == 0x290, "Offset mismatch for UFabricStepSequencerGridComponent::GridSquareClass");
static_assert(offsetof(UFabricStepSequencerGridComponent, SequencerType) == 0x2b0, "Offset mismatch for UFabricStepSequencerGridComponent::SequencerType");
static_assert(offsetof(UFabricStepSequencerGridComponent, ActiveTrack) == 0x2b4, "Offset mismatch for UFabricStepSequencerGridComponent::ActiveTrack");
static_assert(offsetof(UFabricStepSequencerGridComponent, StepSequencer) == 0x2b8, "Offset mismatch for UFabricStepSequencerGridComponent::StepSequencer");
static_assert(offsetof(UFabricStepSequencerGridComponent, GridRows) == 0x2c0, "Offset mismatch for UFabricStepSequencerGridComponent::GridRows");
static_assert(offsetof(UFabricStepSequencerGridComponent, MaxTrackIndexToLoadSquares) == 0x330, "Offset mismatch for UFabricStepSequencerGridComponent::MaxTrackIndexToLoadSquares");

// Size: 0x670 (Inherited: 0x13b0, Single: 0xfffff2c0)
class UFabricStepSequencerGridSquareComponent : public UStaticMeshComponent
{
public:
    uint8_t Pad_610[0x8]; // 0x610 (Size: 0x8, Type: PaddingProperty)
    float ContinuationControlInteractionDelay; // 0x618 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_61c[0x4]; // 0x61c (Size: 0x4, Type: PaddingProperty)
    UFabricStepSequencerComponent* AssignedStepSequencer; // 0x620 (Size: 0x8, Type: ObjectProperty)
    int32_t ActiveTrack; // 0x628 (Size: 0x4, Type: IntProperty)
    int32_t AssignedStep; // 0x62c (Size: 0x4, Type: IntProperty)
    int32_t PreviousFocusStepIndex; // 0x630 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_634[0x3c]; // 0x634 (Size: 0x3c, Type: PaddingProperty)

public:
    void SetActiveTrack(int32_t& Track); // 0x111b9774 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

private:
    bool CanDoInteractionLogicOnEndInteraction() const; // 0x111b771c (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    bool CanDoInteractionLogicOnStartInteraction() const; // 0x111b7740 (Index: 0x1, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)

protected:
    virtual void OnContinuationControl_EndInteraction(APlayerController*& Controller); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnContinuationControl_StartInteraction(APlayerController*& Controller); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFabricStepSequencerGridSquareComponent) == 0x670, "Size mismatch for UFabricStepSequencerGridSquareComponent");
static_assert(offsetof(UFabricStepSequencerGridSquareComponent, ContinuationControlInteractionDelay) == 0x618, "Offset mismatch for UFabricStepSequencerGridSquareComponent::ContinuationControlInteractionDelay");
static_assert(offsetof(UFabricStepSequencerGridSquareComponent, AssignedStepSequencer) == 0x620, "Offset mismatch for UFabricStepSequencerGridSquareComponent::AssignedStepSequencer");
static_assert(offsetof(UFabricStepSequencerGridSquareComponent, ActiveTrack) == 0x628, "Offset mismatch for UFabricStepSequencerGridSquareComponent::ActiveTrack");
static_assert(offsetof(UFabricStepSequencerGridSquareComponent, AssignedStep) == 0x62c, "Offset mismatch for UFabricStepSequencerGridSquareComponent::AssignedStep");
static_assert(offsetof(UFabricStepSequencerGridSquareComponent, PreviousFocusStepIndex) == 0x630, "Offset mismatch for UFabricStepSequencerGridSquareComponent::PreviousFocusStepIndex");

// Size: 0x340 (Inherited: 0x350, Single: 0xfffffff0)
class UFabricTextureModifierBase : public UFabricModulatable
{
public:
    uint8_t OnSourceTexturesChanged[0x10]; // 0x328 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UTexture* ModifiedTexture; // 0x338 (Size: 0x8, Type: ObjectProperty)

public:
    void OnSourceTextureChanged__DelegateSignature(const TArray<FFabricTextureProviderTexture> Textures); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
};

static_assert(sizeof(UFabricTextureModifierBase) == 0x340, "Size mismatch for UFabricTextureModifierBase");
static_assert(offsetof(UFabricTextureModifierBase, OnSourceTexturesChanged) == 0x328, "Offset mismatch for UFabricTextureModifierBase::OnSourceTexturesChanged");
static_assert(offsetof(UFabricTextureModifierBase, ModifiedTexture) == 0x338, "Offset mismatch for UFabricTextureModifierBase::ModifiedTexture");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UFabricTextureTreeNode : public UObject
{
public:
    TArray<UFabricTextureTreeNode*> Children; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FFabricTextureProviderTexture Texture; // 0x38 (Size: 0x18, Type: StructProperty)

public:
    void CopyProperties(UFabricTextureTreeNode*& const Other); // 0x111b7764 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void Reset(); // 0x111b9760 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricTextureTreeNode) == 0x50, "Size mismatch for UFabricTextureTreeNode");
static_assert(offsetof(UFabricTextureTreeNode, Children) == 0x28, "Offset mismatch for UFabricTextureTreeNode::Children");
static_assert(offsetof(UFabricTextureTreeNode, Texture) == 0x38, "Offset mismatch for UFabricTextureTreeNode::Texture");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UFabricTextureProviderBase : public UObject
{
public:
    uint8_t OnTextureChanged[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FFabricTextureProviderTexture SourceTexture; // 0x38 (Size: 0x18, Type: StructProperty)
    float CurrentCableFloatValue; // 0x50 (Size: 0x4, Type: FloatProperty)
    float CurrentCableFloatDirection; // 0x54 (Size: 0x4, Type: FloatProperty)
    float TimeElapsedSinceLastCableFloatDirty; // 0x58 (Size: 0x4, Type: FloatProperty)
    bool bCurrentCableFloatDirty; // 0x5c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5d[0x3]; // 0x5d (Size: 0x3, Type: PaddingProperty)

public:
    void OnTextureChanged__DelegateSignature(const FFabricTextureProviderTexture Texture); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void SetSourceTexture(const FFabricTextureProviderTexture InTexture); // 0x111b9e7c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFabricTextureProviderBase) == 0x60, "Size mismatch for UFabricTextureProviderBase");
static_assert(offsetof(UFabricTextureProviderBase, OnTextureChanged) == 0x28, "Offset mismatch for UFabricTextureProviderBase::OnTextureChanged");
static_assert(offsetof(UFabricTextureProviderBase, SourceTexture) == 0x38, "Offset mismatch for UFabricTextureProviderBase::SourceTexture");
static_assert(offsetof(UFabricTextureProviderBase, CurrentCableFloatValue) == 0x50, "Offset mismatch for UFabricTextureProviderBase::CurrentCableFloatValue");
static_assert(offsetof(UFabricTextureProviderBase, CurrentCableFloatDirection) == 0x54, "Offset mismatch for UFabricTextureProviderBase::CurrentCableFloatDirection");
static_assert(offsetof(UFabricTextureProviderBase, TimeElapsedSinceLastCableFloatDirty) == 0x58, "Offset mismatch for UFabricTextureProviderBase::TimeElapsedSinceLastCableFloatDirty");
static_assert(offsetof(UFabricTextureProviderBase, bCurrentCableFloatDirty) == 0x5c, "Offset mismatch for UFabricTextureProviderBase::bCurrentCableFloatDirty");

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class UFabricTimelinePreviewComponent : public UActorComponent
{
public:
    UTimelineComponent* CurrentTimeline; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c0[0x10]; // 0xc0 (Size: 0x10, Type: PaddingProperty)

public:
    bool GetShouldPreview() const; // 0x4c4e47c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PreviewTimeline(UTimelineComponent*& Timeline, float& SecondsToPlay, bool& bReverseAnimation); // 0x111b91b8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricTimelinePreviewComponent) == 0xd0, "Size mismatch for UFabricTimelinePreviewComponent");
static_assert(offsetof(UFabricTimelinePreviewComponent, CurrentTimeline) == 0xb8, "Offset mismatch for UFabricTimelinePreviewComponent::CurrentTimeline");

// Size: 0x178 (Inherited: 0xe0, Single: 0x98)
class UFabricTimelineSyncComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    float ThresholdForSeekMS; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ThresholdForSeekWhenSpeedSyncDisallowedMS; // 0xcc (Size: 0x4, Type: FloatProperty)
    float ThresholdForStartSpeedAdjustMS; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float ThresholdForEndOfSpeedAdjustMS; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float SpeedAdjustFactor; // 0xd8 (Size: 0x4, Type: FloatProperty)
    bool bPrintToScreen; // 0xdc (Size: 0x1, Type: BoolProperty)
    bool bLogCorrectedServerTimeDelta; // 0xdd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_de[0x2]; // 0xde (Size: 0x2, Type: PaddingProperty)
    float SpeedSyncTimeoutLength; // 0xe0 (Size: 0x4, Type: FloatProperty)
    float TempoDeltaThrottleSeconds; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float MassiveSyncErrorTimeThresholdMin; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float MassiveSyncErrorTimeThresholdMax; // 0xec (Size: 0x4, Type: FloatProperty)
    float MassiveSyncErrorTimeThresholdMultiplier; // 0xf0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_f4[0x4]; // 0xf4 (Size: 0x4, Type: PaddingProperty)
    UFabricMetaSoundManagerComponent* MetaSoundManager; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UMusicClockComponent* MusicClock; // 0x100 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    FFabricTimelineSyncServerSongPosition ServerTimelineSyncServerSongPosition; // 0x110 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_12c[0x4c]; // 0x12c (Size: 0x4c, Type: PaddingProperty)

public:
    void OnRep_ServerCurrentSongPos(); // 0x111b8ec4 (Index: 0x0, Flags: Final|Native|Public)
    void OnTimelinePlayingChanged(EMusicClockState& State); // 0xcf8da58 (Index: 0x1, Flags: Final|Native|Public)
    void RegisterTimelineSyncTarget(TScriptInterface<Class>& InTimelineSyncTarget); // 0x111b9470 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetFabricMetaSoundManager(UFabricMetaSoundManagerComponent*& InMetaSoundManager); // 0x111b9b10 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterTimelineSyncTarget(TScriptInterface<Class>& InTimelineSyncTarget); // 0x111ba314 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricTimelineSyncComponent) == 0x178, "Size mismatch for UFabricTimelineSyncComponent");
static_assert(offsetof(UFabricTimelineSyncComponent, ThresholdForSeekMS) == 0xc8, "Offset mismatch for UFabricTimelineSyncComponent::ThresholdForSeekMS");
static_assert(offsetof(UFabricTimelineSyncComponent, ThresholdForSeekWhenSpeedSyncDisallowedMS) == 0xcc, "Offset mismatch for UFabricTimelineSyncComponent::ThresholdForSeekWhenSpeedSyncDisallowedMS");
static_assert(offsetof(UFabricTimelineSyncComponent, ThresholdForStartSpeedAdjustMS) == 0xd0, "Offset mismatch for UFabricTimelineSyncComponent::ThresholdForStartSpeedAdjustMS");
static_assert(offsetof(UFabricTimelineSyncComponent, ThresholdForEndOfSpeedAdjustMS) == 0xd4, "Offset mismatch for UFabricTimelineSyncComponent::ThresholdForEndOfSpeedAdjustMS");
static_assert(offsetof(UFabricTimelineSyncComponent, SpeedAdjustFactor) == 0xd8, "Offset mismatch for UFabricTimelineSyncComponent::SpeedAdjustFactor");
static_assert(offsetof(UFabricTimelineSyncComponent, bPrintToScreen) == 0xdc, "Offset mismatch for UFabricTimelineSyncComponent::bPrintToScreen");
static_assert(offsetof(UFabricTimelineSyncComponent, bLogCorrectedServerTimeDelta) == 0xdd, "Offset mismatch for UFabricTimelineSyncComponent::bLogCorrectedServerTimeDelta");
static_assert(offsetof(UFabricTimelineSyncComponent, SpeedSyncTimeoutLength) == 0xe0, "Offset mismatch for UFabricTimelineSyncComponent::SpeedSyncTimeoutLength");
static_assert(offsetof(UFabricTimelineSyncComponent, TempoDeltaThrottleSeconds) == 0xe4, "Offset mismatch for UFabricTimelineSyncComponent::TempoDeltaThrottleSeconds");
static_assert(offsetof(UFabricTimelineSyncComponent, MassiveSyncErrorTimeThresholdMin) == 0xe8, "Offset mismatch for UFabricTimelineSyncComponent::MassiveSyncErrorTimeThresholdMin");
static_assert(offsetof(UFabricTimelineSyncComponent, MassiveSyncErrorTimeThresholdMax) == 0xec, "Offset mismatch for UFabricTimelineSyncComponent::MassiveSyncErrorTimeThresholdMax");
static_assert(offsetof(UFabricTimelineSyncComponent, MassiveSyncErrorTimeThresholdMultiplier) == 0xf0, "Offset mismatch for UFabricTimelineSyncComponent::MassiveSyncErrorTimeThresholdMultiplier");
static_assert(offsetof(UFabricTimelineSyncComponent, MetaSoundManager) == 0xf8, "Offset mismatch for UFabricTimelineSyncComponent::MetaSoundManager");
static_assert(offsetof(UFabricTimelineSyncComponent, MusicClock) == 0x100, "Offset mismatch for UFabricTimelineSyncComponent::MusicClock");
static_assert(offsetof(UFabricTimelineSyncComponent, ServerTimelineSyncServerSongPosition) == 0x110, "Offset mismatch for UFabricTimelineSyncComponent::ServerTimelineSyncServerSongPosition");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFabricTimelineSyncTargetInterface : public UInterface
{
public:
};

static_assert(sizeof(UFabricTimelineSyncTargetInterface) == 0x28, "Size mismatch for UFabricTimelineSyncTargetInterface");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFabricVFXTopperDataAsset : public UDataAsset
{
public:
    TArray<FFabricVFXTopperDataEntry> VFXTopperDataEntries; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFabricVFXTopperDataAsset) == 0x40, "Size mismatch for UFabricVFXTopperDataAsset");
static_assert(offsetof(UFabricVFXTopperDataAsset, VFXTopperDataEntries) == 0x30, "Offset mismatch for UFabricVFXTopperDataAsset::VFXTopperDataEntries");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UFabricWaveformTexture : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    int32_t WaveformNumSamplesHeld; // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t WaveformSmoothingDistance; // 0x34 (Size: 0x4, Type: IntProperty)
    float WaveformSmoothingFactor; // 0x38 (Size: 0x4, Type: FloatProperty)
    float WaveformDecayPerSecond; // 0x3c (Size: 0x4, Type: FloatProperty)
    UTexture2D* WaveformTexture; // 0x40 (Size: 0x8, Type: ObjectProperty)
    bool bEnableTextureRequests; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x2f]; // 0x49 (Size: 0x2f, Type: PaddingProperty)

public:
    void AddMultipleValuesToWaveformTexture(TArray<float>& Values); // 0x111b7364 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void AddNewValueToWaveformTexture(float& Value); // 0x111b75f0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UTexture2D* GetWaveformTexture() const; // 0x9edca80 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Initialize(); // 0x111b8380 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricWaveformTexture) == 0x78, "Size mismatch for UFabricWaveformTexture");
static_assert(offsetof(UFabricWaveformTexture, WaveformNumSamplesHeld) == 0x30, "Offset mismatch for UFabricWaveformTexture::WaveformNumSamplesHeld");
static_assert(offsetof(UFabricWaveformTexture, WaveformSmoothingDistance) == 0x34, "Offset mismatch for UFabricWaveformTexture::WaveformSmoothingDistance");
static_assert(offsetof(UFabricWaveformTexture, WaveformSmoothingFactor) == 0x38, "Offset mismatch for UFabricWaveformTexture::WaveformSmoothingFactor");
static_assert(offsetof(UFabricWaveformTexture, WaveformDecayPerSecond) == 0x3c, "Offset mismatch for UFabricWaveformTexture::WaveformDecayPerSecond");
static_assert(offsetof(UFabricWaveformTexture, WaveformTexture) == 0x40, "Offset mismatch for UFabricWaveformTexture::WaveformTexture");
static_assert(offsetof(UFabricWaveformTexture, bEnableTextureRequests) == 0x48, "Offset mismatch for UFabricWaveformTexture::bEnableTextureRequests");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UFabricInteractableTargetPayload : public UObject
{
public:
    TWeakObjectPtr<AActor*> TargetedActor; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPrimitiveComponent*> TargetedComponent; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UFabricInteractableTargetPayload) == 0x38, "Size mismatch for UFabricInteractableTargetPayload");
static_assert(offsetof(UFabricInteractableTargetPayload, TargetedActor) == 0x28, "Offset mismatch for UFabricInteractableTargetPayload::TargetedActor");
static_assert(offsetof(UFabricInteractableTargetPayload, TargetedComponent) == 0x30, "Offset mismatch for UFabricInteractableTargetPayload::TargetedComponent");

// Size: 0xb88 (Inherited: 0xf08, Single: 0xfffffc80)
class UFortGameplayAbility_FabricInteractableTargeting : public UFortGameplayAbility
{
public:
    UTargetingPreset* TargetingPreset; // 0xb38 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TargetsChangedTag; // 0xb40 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b44[0x4]; // 0xb44 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat TargetingInterval; // 0xb48 (Size: 0x28, Type: StructProperty)
    UFabricInteractableTargetPayload* PayloadCache; // 0xb70 (Size: 0x8, Type: ObjectProperty)
    FTargetingRequestHandle AsyncTargetingHandle; // 0xb78 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b7c[0x4]; // 0xb7c (Size: 0x4, Type: PaddingProperty)
    FTimerHandle TargetingTimerHandle; // 0xb80 (Size: 0x8, Type: StructProperty)

protected:
    void StartTargeting(); // 0x111ba2ec (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void StopTargeting(); // 0x111ba300 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortGameplayAbility_FabricInteractableTargeting) == 0xb88, "Size mismatch for UFortGameplayAbility_FabricInteractableTargeting");
static_assert(offsetof(UFortGameplayAbility_FabricInteractableTargeting, TargetingPreset) == 0xb38, "Offset mismatch for UFortGameplayAbility_FabricInteractableTargeting::TargetingPreset");
static_assert(offsetof(UFortGameplayAbility_FabricInteractableTargeting, TargetsChangedTag) == 0xb40, "Offset mismatch for UFortGameplayAbility_FabricInteractableTargeting::TargetsChangedTag");
static_assert(offsetof(UFortGameplayAbility_FabricInteractableTargeting, TargetingInterval) == 0xb48, "Offset mismatch for UFortGameplayAbility_FabricInteractableTargeting::TargetingInterval");
static_assert(offsetof(UFortGameplayAbility_FabricInteractableTargeting, PayloadCache) == 0xb70, "Offset mismatch for UFortGameplayAbility_FabricInteractableTargeting::PayloadCache");
static_assert(offsetof(UFortGameplayAbility_FabricInteractableTargeting, AsyncTargetingHandle) == 0xb78, "Offset mismatch for UFortGameplayAbility_FabricInteractableTargeting::AsyncTargetingHandle");
static_assert(offsetof(UFortGameplayAbility_FabricInteractableTargeting, TargetingTimerHandle) == 0xb80, "Offset mismatch for UFortGameplayAbility_FabricInteractableTargeting::TargetingTimerHandle");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UFabricGameFeatureAction_OverrideFabricInteractionTool : public UGameFeatureAction
{
public:
    TSoftObjectPtr<UFortGadgetItemDefinition*> OverriddenPatchworkInteractionTool; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UFabricGameFeatureAction_OverrideFabricInteractionTool) == 0x48, "Size mismatch for UFabricGameFeatureAction_OverrideFabricInteractionTool");
static_assert(offsetof(UFabricGameFeatureAction_OverrideFabricInteractionTool, OverriddenPatchworkInteractionTool) == 0x28, "Offset mismatch for UFabricGameFeatureAction_OverrideFabricInteractionTool::OverriddenPatchworkInteractionTool");

// Size: 0xa0 (Inherited: 0x88, Single: 0x18)
class UFabricGlobalRestrictionsWorldSubsystem : public UWorldSubsystem
{
public:
    FGameplayTagContainer FabricInteractionToolRestrictionGameplayTags; // 0x30 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_50[0x50]; // 0x50 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UFabricGlobalRestrictionsWorldSubsystem) == 0xa0, "Size mismatch for UFabricGlobalRestrictionsWorldSubsystem");
static_assert(offsetof(UFabricGlobalRestrictionsWorldSubsystem, FabricInteractionToolRestrictionGameplayTags) == 0x30, "Offset mismatch for UFabricGlobalRestrictionsWorldSubsystem::FabricInteractionToolRestrictionGameplayTags");

// Size: 0xf8 (Inherited: 0x88, Single: 0x70)
class UFabricIslandSettingsWorldSubsystem : public UWorldSubsystem
{
public:
    FScalableFloat UseMemoryMode; // 0x30 (Size: 0x28, Type: StructProperty)
    float CheckMinigameSettingsIntervalSeconds; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x9c]; // 0x5c (Size: 0x9c, Type: PaddingProperty)

public:
    bool AreMemoryQueriesAllowed(EFabricIslandSettingsMemoryModeType& MemoryModeType) const; // 0x11215208 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool CanUseFabricMemoryModeRelevantFeature(EFabricIslandSettingsMemoryModeType& MemoryModeType) const; // 0x1121533c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ClientNotifyMemoryModeEnabled(EFabricIslandSettingsMemoryModeType& MemoryModeType); // 0x11215470 (Index: 0x2, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    bool IsMemoryModeEnabledOnClient(EFabricIslandSettingsMemoryModeType& MemoryModeType) const; // 0x1121559c (Index: 0x3, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RegisterBlueprintForFabricIslandSettingsInitialized(const TScriptInterface<Class> InFabricIslandSettingsInitializedInterface, EFabricIslandSettingsMemoryModeType& MemoryModeType); // 0x112156dc (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnregisterBlueprintForFabricIslandSettingsInitialized(const TScriptInterface<Class> InFabricIslandSettingsInitializedInterface); // 0x11215830 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFabricIslandSettingsWorldSubsystem) == 0xf8, "Size mismatch for UFabricIslandSettingsWorldSubsystem");
static_assert(offsetof(UFabricIslandSettingsWorldSubsystem, UseMemoryMode) == 0x30, "Offset mismatch for UFabricIslandSettingsWorldSubsystem::UseMemoryMode");
static_assert(offsetof(UFabricIslandSettingsWorldSubsystem, CheckMinigameSettingsIntervalSeconds) == 0x58, "Offset mismatch for UFabricIslandSettingsWorldSubsystem::CheckMinigameSettingsIntervalSeconds");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FInteractionData
{
    uint8_t InteractionState; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AFortCreativeDeviceProp*> InteractableOwnerDevice; // 0x4 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FInteractionData) == 0xc, "Size mismatch for FInteractionData");
static_assert(offsetof(FInteractionData, InteractionState) == 0x0, "Offset mismatch for FInteractionData::InteractionState");
static_assert(offsetof(FInteractionData, InteractableOwnerDevice) == 0x4, "Offset mismatch for FInteractionData::InteractableOwnerDevice");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FInteractionSplinePoints
{
    FVector_NetQuantize10 SplineStartLocation; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize10 SplineStartForward; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize10 SplineEndLocation; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize10 SplineEndForward; // 0x48 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FInteractionSplinePoints) == 0x60, "Size mismatch for FInteractionSplinePoints");
static_assert(offsetof(FInteractionSplinePoints, SplineStartLocation) == 0x0, "Offset mismatch for FInteractionSplinePoints::SplineStartLocation");
static_assert(offsetof(FInteractionSplinePoints, SplineStartForward) == 0x18, "Offset mismatch for FInteractionSplinePoints::SplineStartForward");
static_assert(offsetof(FInteractionSplinePoints, SplineEndLocation) == 0x30, "Offset mismatch for FInteractionSplinePoints::SplineEndLocation");
static_assert(offsetof(FInteractionSplinePoints, SplineEndForward) == 0x48, "Offset mismatch for FInteractionSplinePoints::SplineEndForward");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFabricMetaSoundPatchWrapperBinding
{
    FName FriendlyName; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bAllowOnDedicatedServer; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FFabricMetaSoundPatchWrapperPeakTamer PeakTamer; // 0x8 (Size: 0x24, Type: StructProperty)
    FName MetaSoundNodeName; // 0x2c (Size: 0x4, Type: NameProperty)
    TArray<float> Signals; // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bBoundToWatchEvents; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0xf]; // 0x41 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapperBinding) == 0x50, "Size mismatch for FFabricMetaSoundPatchWrapperBinding");
static_assert(offsetof(FFabricMetaSoundPatchWrapperBinding, FriendlyName) == 0x0, "Offset mismatch for FFabricMetaSoundPatchWrapperBinding::FriendlyName");
static_assert(offsetof(FFabricMetaSoundPatchWrapperBinding, bAllowOnDedicatedServer) == 0x4, "Offset mismatch for FFabricMetaSoundPatchWrapperBinding::bAllowOnDedicatedServer");
static_assert(offsetof(FFabricMetaSoundPatchWrapperBinding, PeakTamer) == 0x8, "Offset mismatch for FFabricMetaSoundPatchWrapperBinding::PeakTamer");
static_assert(offsetof(FFabricMetaSoundPatchWrapperBinding, MetaSoundNodeName) == 0x2c, "Offset mismatch for FFabricMetaSoundPatchWrapperBinding::MetaSoundNodeName");
static_assert(offsetof(FFabricMetaSoundPatchWrapperBinding, Signals) == 0x30, "Offset mismatch for FFabricMetaSoundPatchWrapperBinding::Signals");
static_assert(offsetof(FFabricMetaSoundPatchWrapperBinding, bBoundToWatchEvents) == 0x40, "Offset mismatch for FFabricMetaSoundPatchWrapperBinding::bBoundToWatchEvents");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FFabricMetaSoundPatchWrapperPeakTamer
{
    bool bUseGameplaySmoothing; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSortSignals; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    int32_t MaxSignalsToTame; // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8[0x1c]; // 0x8 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapperPeakTamer) == 0x24, "Size mismatch for FFabricMetaSoundPatchWrapperPeakTamer");
static_assert(offsetof(FFabricMetaSoundPatchWrapperPeakTamer, bUseGameplaySmoothing) == 0x0, "Offset mismatch for FFabricMetaSoundPatchWrapperPeakTamer::bUseGameplaySmoothing");
static_assert(offsetof(FFabricMetaSoundPatchWrapperPeakTamer, bSortSignals) == 0x1, "Offset mismatch for FFabricMetaSoundPatchWrapperPeakTamer::bSortSignals");
static_assert(offsetof(FFabricMetaSoundPatchWrapperPeakTamer, MaxSignalsToTame) == 0x4, "Offset mismatch for FFabricMetaSoundPatchWrapperPeakTamer::MaxSignalsToTame");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FFabricMetaSoundPatchWrapperWetDryOutputBinding
{
    FFabricMetaSoundPatchWrapperBinding WetOutputSignalBinding; // 0x0 (Size: 0x50, Type: StructProperty)
    FFabricMetaSoundPatchWrapperBinding DryOutputSignalBinding; // 0x50 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapperWetDryOutputBinding) == 0xa0, "Size mismatch for FFabricMetaSoundPatchWrapperWetDryOutputBinding");
static_assert(offsetof(FFabricMetaSoundPatchWrapperWetDryOutputBinding, WetOutputSignalBinding) == 0x0, "Offset mismatch for FFabricMetaSoundPatchWrapperWetDryOutputBinding::WetOutputSignalBinding");
static_assert(offsetof(FFabricMetaSoundPatchWrapperWetDryOutputBinding, DryOutputSignalBinding) == 0x50, "Offset mismatch for FFabricMetaSoundPatchWrapperWetDryOutputBinding::DryOutputSignalBinding");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
struct FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding : FFabricMetaSoundPatchWrapperBinding
{
    int32_t PrimitiveDataIndex; // 0x50 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding) == 0x58, "Size mismatch for FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding");
static_assert(offsetof(FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding, PrimitiveDataIndex) == 0x50, "Offset mismatch for FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding::PrimitiveDataIndex");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFabricSequencerStepChangedInfo
{
    int32_t Page; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Row; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Step; // 0x8 (Size: 0x4, Type: IntProperty)
    FStepSequenceCell Cell; // 0xc (Size: 0x2, Type: StructProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FFabricSequencerStepChangedInfo) == 0x10, "Size mismatch for FFabricSequencerStepChangedInfo");
static_assert(offsetof(FFabricSequencerStepChangedInfo, Page) == 0x0, "Offset mismatch for FFabricSequencerStepChangedInfo::Page");
static_assert(offsetof(FFabricSequencerStepChangedInfo, Row) == 0x4, "Offset mismatch for FFabricSequencerStepChangedInfo::Row");
static_assert(offsetof(FFabricSequencerStepChangedInfo, Step) == 0x8, "Offset mismatch for FFabricSequencerStepChangedInfo::Step");
static_assert(offsetof(FFabricSequencerStepChangedInfo, Cell) == 0xc, "Offset mismatch for FFabricSequencerStepChangedInfo::Cell");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FFabricProgressionPreset : FTableRowBase
{
    FText ProgressionName; // 0x8 (Size: 0x10, Type: TextProperty)
    uint8_t Interval0; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Interval1; // 0x19 (Size: 0x1, Type: EnumProperty)
    uint8_t Interval2; // 0x1a (Size: 0x1, Type: EnumProperty)
    uint8_t Interval3; // 0x1b (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricProgressionPreset) == 0x20, "Size mismatch for FFabricProgressionPreset");
static_assert(offsetof(FFabricProgressionPreset, ProgressionName) == 0x8, "Offset mismatch for FFabricProgressionPreset::ProgressionName");
static_assert(offsetof(FFabricProgressionPreset, Interval0) == 0x18, "Offset mismatch for FFabricProgressionPreset::Interval0");
static_assert(offsetof(FFabricProgressionPreset, Interval1) == 0x19, "Offset mismatch for FFabricProgressionPreset::Interval1");
static_assert(offsetof(FFabricProgressionPreset, Interval2) == 0x1a, "Offset mismatch for FFabricProgressionPreset::Interval2");
static_assert(offsetof(FFabricProgressionPreset, Interval3) == 0x1b, "Offset mismatch for FFabricProgressionPreset::Interval3");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFabricTextureProviderTexture
{
    UTexture* Texture; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FLinearColor Tint; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFabricTextureProviderTexture) == 0x18, "Size mismatch for FFabricTextureProviderTexture");
static_assert(offsetof(FFabricTextureProviderTexture, Texture) == 0x0, "Offset mismatch for FFabricTextureProviderTexture::Texture");
static_assert(offsetof(FFabricTextureProviderTexture, Tint) == 0x8, "Offset mismatch for FFabricTextureProviderTexture::Tint");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FFabricLFOGenerator
{
    uint8_t WaveShape; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Shape; // 0xc (Size: 0x4, Type: FloatProperty)
    int32_t InitialSeed; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x6c]; // 0x14 (Size: 0x6c, Type: PaddingProperty)
};

static_assert(sizeof(FFabricLFOGenerator) == 0x80, "Size mismatch for FFabricLFOGenerator");
static_assert(offsetof(FFabricLFOGenerator, WaveShape) == 0x0, "Offset mismatch for FFabricLFOGenerator::WaveShape");
static_assert(offsetof(FFabricLFOGenerator, Minimum) == 0x4, "Offset mismatch for FFabricLFOGenerator::Minimum");
static_assert(offsetof(FFabricLFOGenerator, Maximum) == 0x8, "Offset mismatch for FFabricLFOGenerator::Maximum");
static_assert(offsetof(FFabricLFOGenerator, Shape) == 0xc, "Offset mismatch for FFabricLFOGenerator::Shape");
static_assert(offsetof(FFabricLFOGenerator, InitialSeed) == 0x10, "Offset mismatch for FFabricLFOGenerator::InitialSeed");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFabricStepGenerator
{
    TArray<float> Values; // 0x8 (Size: 0x10, Type: ArrayProperty)
    float Blend; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricStepGenerator) == 0x20, "Size mismatch for FFabricStepGenerator");
static_assert(offsetof(FFabricStepGenerator, Values) == 0x8, "Offset mismatch for FFabricStepGenerator::Values");
static_assert(offsetof(FFabricStepGenerator, Blend) == 0x18, "Offset mismatch for FFabricStepGenerator::Blend");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FFabricValueSetterGenerator
{
    int32_t PhraseLengthInBars; // 0xc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_10[0x58]; // 0x10 (Size: 0x58, Type: PaddingProperty)
};

static_assert(sizeof(FFabricValueSetterGenerator) == 0x68, "Size mismatch for FFabricValueSetterGenerator");
static_assert(offsetof(FFabricValueSetterGenerator, PhraseLengthInBars) == 0xc, "Offset mismatch for FFabricValueSetterGenerator::PhraseLengthInBars");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFabricMeshProviderMeshReferenceParamInfo
{
    FMaterialParameterInfo MaterialParameterInfo; // 0x0 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FFabricMeshProviderMeshReferenceParamInfo) == 0xc, "Size mismatch for FFabricMeshProviderMeshReferenceParamInfo");
static_assert(offsetof(FFabricMeshProviderMeshReferenceParamInfo, MaterialParameterInfo) == 0x0, "Offset mismatch for FFabricMeshProviderMeshReferenceParamInfo::MaterialParameterInfo");

// Size: 0x10 (Inherited: 0xc, Single: 0x4)
struct FFabricMeshProviderMeshReferenceParamInfo_Scalar : FFabricMeshProviderMeshReferenceParamInfo
{
    float Scalar; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFabricMeshProviderMeshReferenceParamInfo_Scalar) == 0x10, "Size mismatch for FFabricMeshProviderMeshReferenceParamInfo_Scalar");
static_assert(offsetof(FFabricMeshProviderMeshReferenceParamInfo_Scalar, Scalar) == 0xc, "Offset mismatch for FFabricMeshProviderMeshReferenceParamInfo_Scalar::Scalar");

// Size: 0x1c (Inherited: 0xc, Single: 0x10)
struct FFabricMeshProviderMeshReferenceParamInfo_Color : FFabricMeshProviderMeshReferenceParamInfo
{
    FLinearColor Color; // 0xc (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFabricMeshProviderMeshReferenceParamInfo_Color) == 0x1c, "Size mismatch for FFabricMeshProviderMeshReferenceParamInfo_Color");
static_assert(offsetof(FFabricMeshProviderMeshReferenceParamInfo_Color, Color) == 0xc, "Offset mismatch for FFabricMeshProviderMeshReferenceParamInfo_Color::Color");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFabricMeshProviderMeshReferenceParams
{
    double UniformScale; // 0x0 (Size: 0x8, Type: DoubleProperty)
    TArray<FFabricMeshProviderMeshReferenceParamInfo_Scalar> ScalarParams; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMeshProviderMeshReferenceParamInfo_Color> ColorParams; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricMeshProviderMeshReferenceParams) == 0x28, "Size mismatch for FFabricMeshProviderMeshReferenceParams");
static_assert(offsetof(FFabricMeshProviderMeshReferenceParams, UniformScale) == 0x0, "Offset mismatch for FFabricMeshProviderMeshReferenceParams::UniformScale");
static_assert(offsetof(FFabricMeshProviderMeshReferenceParams, ScalarParams) == 0x8, "Offset mismatch for FFabricMeshProviderMeshReferenceParams::ScalarParams");
static_assert(offsetof(FFabricMeshProviderMeshReferenceParams, ColorParams) == 0x18, "Offset mismatch for FFabricMeshProviderMeshReferenceParams::ColorParams");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FFabricMeshProviderMeshReference
{
    UStreamableRenderAsset* Mesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UTexture* Texture; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FFabricMeshProviderMeshReferenceParams Params; // 0x10 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FFabricMeshProviderMeshReference) == 0x38, "Size mismatch for FFabricMeshProviderMeshReference");
static_assert(offsetof(FFabricMeshProviderMeshReference, Mesh) == 0x0, "Offset mismatch for FFabricMeshProviderMeshReference::Mesh");
static_assert(offsetof(FFabricMeshProviderMeshReference, Texture) == 0x8, "Offset mismatch for FFabricMeshProviderMeshReference::Texture");
static_assert(offsetof(FFabricMeshProviderMeshReference, Params) == 0x10, "Offset mismatch for FFabricMeshProviderMeshReference::Params");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FFabricMeshInstanceReference
{
    FFabricMeshProviderMeshReference MeshReference; // 0x0 (Size: 0x38, Type: StructProperty)
    TArray<FTransform> InstanceTransforms; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricMeshInstanceReference) == 0x48, "Size mismatch for FFabricMeshInstanceReference");
static_assert(offsetof(FFabricMeshInstanceReference, MeshReference) == 0x0, "Offset mismatch for FFabricMeshInstanceReference::MeshReference");
static_assert(offsetof(FFabricMeshInstanceReference, InstanceTransforms) == 0x38, "Offset mismatch for FFabricMeshInstanceReference::InstanceTransforms");

// Size: 0x158 (Inherited: 0x0, Single: 0x158)
struct FFabricMetaSoundMergeNode
{
    FMetaSoundCombinerNodeHandle CombinerNode; // 0x0 (Size: 0x150, Type: StructProperty)
    uint8_t Pad_150[0x8]; // 0x150 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundMergeNode) == 0x158, "Size mismatch for FFabricMetaSoundMergeNode");
static_assert(offsetof(FFabricMetaSoundMergeNode, CombinerNode) == 0x0, "Offset mismatch for FFabricMetaSoundMergeNode::CombinerNode");

// Size: 0x150 (Inherited: 0x0, Single: 0x150)
struct FMetaSoundCombinerNodeHandle
{
    FFabricMetaSoundNodeInfo NodeInfo; // 0x0 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle CombinerInput1; // 0xf0 (Size: 0x20, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle CombinerInput2; // 0x110 (Size: 0x20, Type: StructProperty)
    FMetaSoundBuilderNodeOutputHandle CombinedOutput; // 0x130 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FMetaSoundCombinerNodeHandle) == 0x150, "Size mismatch for FMetaSoundCombinerNodeHandle");
static_assert(offsetof(FMetaSoundCombinerNodeHandle, NodeInfo) == 0x0, "Offset mismatch for FMetaSoundCombinerNodeHandle::NodeInfo");
static_assert(offsetof(FMetaSoundCombinerNodeHandle, CombinerInput1) == 0xf0, "Offset mismatch for FMetaSoundCombinerNodeHandle::CombinerInput1");
static_assert(offsetof(FMetaSoundCombinerNodeHandle, CombinerInput2) == 0x110, "Offset mismatch for FMetaSoundCombinerNodeHandle::CombinerInput2");
static_assert(offsetof(FMetaSoundCombinerNodeHandle, CombinedOutput) == 0x130, "Offset mismatch for FMetaSoundCombinerNodeHandle::CombinedOutput");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FFabricMetaSoundNodeInfo
{
    FMetaSoundNodeHandle NodeHandle; // 0x0 (Size: 0x10, Type: StructProperty)
    FMetaSoundNodeHandle OutputConnectionHandle; // 0x10 (Size: 0x10, Type: StructProperty)
    FMetaSoundNodeHandle InputConnectionHandle; // 0x20 (Size: 0x10, Type: StructProperty)
    FName Name; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TMap<FMetaSoundBuilderNodeOutputHandle, FName> InputNodeNamesToHandles; // 0x38 (Size: 0x50, Type: MapProperty)
    FMetaSoundNodeHandle AnalyzerHandle; // 0x88 (Size: 0x10, Type: StructProperty)
    UMetasoundParameterPack* AnalyzerParameterPack; // 0x98 (Size: 0x8, Type: ObjectProperty)
    FName AnalyzerName; // 0xa0 (Size: 0x4, Type: NameProperty)
    FMetaSoundNodeHandle SwitcherHandle; // 0xa4 (Size: 0x10, Type: StructProperty)
    FMetaSoundNodeHandle SelectHandle; // 0xb4 (Size: 0x10, Type: StructProperty)
    FName NodeEnabledInput; // 0xc4 (Size: 0x4, Type: NameProperty)
    FName AnalyzerNodeVisibleInput; // 0xc8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    TArray<FName> AnalyzerOutputNames; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    UMetaSoundPatch* PatchSpawnedFrom; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UMetasoundParameterPack* ParameterPack; // 0xe8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFabricMetaSoundNodeInfo) == 0xf0, "Size mismatch for FFabricMetaSoundNodeInfo");
static_assert(offsetof(FFabricMetaSoundNodeInfo, NodeHandle) == 0x0, "Offset mismatch for FFabricMetaSoundNodeInfo::NodeHandle");
static_assert(offsetof(FFabricMetaSoundNodeInfo, OutputConnectionHandle) == 0x10, "Offset mismatch for FFabricMetaSoundNodeInfo::OutputConnectionHandle");
static_assert(offsetof(FFabricMetaSoundNodeInfo, InputConnectionHandle) == 0x20, "Offset mismatch for FFabricMetaSoundNodeInfo::InputConnectionHandle");
static_assert(offsetof(FFabricMetaSoundNodeInfo, Name) == 0x30, "Offset mismatch for FFabricMetaSoundNodeInfo::Name");
static_assert(offsetof(FFabricMetaSoundNodeInfo, InputNodeNamesToHandles) == 0x38, "Offset mismatch for FFabricMetaSoundNodeInfo::InputNodeNamesToHandles");
static_assert(offsetof(FFabricMetaSoundNodeInfo, AnalyzerHandle) == 0x88, "Offset mismatch for FFabricMetaSoundNodeInfo::AnalyzerHandle");
static_assert(offsetof(FFabricMetaSoundNodeInfo, AnalyzerParameterPack) == 0x98, "Offset mismatch for FFabricMetaSoundNodeInfo::AnalyzerParameterPack");
static_assert(offsetof(FFabricMetaSoundNodeInfo, AnalyzerName) == 0xa0, "Offset mismatch for FFabricMetaSoundNodeInfo::AnalyzerName");
static_assert(offsetof(FFabricMetaSoundNodeInfo, SwitcherHandle) == 0xa4, "Offset mismatch for FFabricMetaSoundNodeInfo::SwitcherHandle");
static_assert(offsetof(FFabricMetaSoundNodeInfo, SelectHandle) == 0xb4, "Offset mismatch for FFabricMetaSoundNodeInfo::SelectHandle");
static_assert(offsetof(FFabricMetaSoundNodeInfo, NodeEnabledInput) == 0xc4, "Offset mismatch for FFabricMetaSoundNodeInfo::NodeEnabledInput");
static_assert(offsetof(FFabricMetaSoundNodeInfo, AnalyzerNodeVisibleInput) == 0xc8, "Offset mismatch for FFabricMetaSoundNodeInfo::AnalyzerNodeVisibleInput");
static_assert(offsetof(FFabricMetaSoundNodeInfo, AnalyzerOutputNames) == 0xd0, "Offset mismatch for FFabricMetaSoundNodeInfo::AnalyzerOutputNames");
static_assert(offsetof(FFabricMetaSoundNodeInfo, PatchSpawnedFrom) == 0xe0, "Offset mismatch for FFabricMetaSoundNodeInfo::PatchSpawnedFrom");
static_assert(offsetof(FFabricMetaSoundNodeInfo, ParameterPack) == 0xe8, "Offset mismatch for FFabricMetaSoundNodeInfo::ParameterPack");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FFabricMetaSoundConnectionBuilder
{
    TArray<FFabricMetaSoundMergeNode> MergeList; // 0xb0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricMetaSoundConnectionBuilder) == 0xc0, "Size mismatch for FFabricMetaSoundConnectionBuilder");
static_assert(offsetof(FFabricMetaSoundConnectionBuilder, MergeList) == 0xb0, "Offset mismatch for FFabricMetaSoundConnectionBuilder::MergeList");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFabricMetaSoundNodePool
{
    int32_t NumberAdded; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FFabricMetaSoundNodeInfo> FreeNodes; // 0x8 (Size: 0x10, Type: ArrayProperty)
    UMetaSoundPatch* PatchSpawnedFrom; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFabricMetaSoundNodePool) == 0x20, "Size mismatch for FFabricMetaSoundNodePool");
static_assert(offsetof(FFabricMetaSoundNodePool, NumberAdded) == 0x0, "Offset mismatch for FFabricMetaSoundNodePool::NumberAdded");
static_assert(offsetof(FFabricMetaSoundNodePool, FreeNodes) == 0x8, "Offset mismatch for FFabricMetaSoundNodePool::FreeNodes");
static_assert(offsetof(FFabricMetaSoundNodePool, PatchSpawnedFrom) == 0x18, "Offset mismatch for FFabricMetaSoundNodePool::PatchSpawnedFrom");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFabricMetaSoundUtilityParams
{
    FName SwitcherEnabledParam; // 0x0 (Size: 0x4, Type: NameProperty)
    FName SelectEnabledParam; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFabricMetaSoundUtilityParams) == 0x8, "Size mismatch for FFabricMetaSoundUtilityParams");
static_assert(offsetof(FFabricMetaSoundUtilityParams, SwitcherEnabledParam) == 0x0, "Offset mismatch for FFabricMetaSoundUtilityParams::SwitcherEnabledParam");
static_assert(offsetof(FFabricMetaSoundUtilityParams, SelectEnabledParam) == 0x4, "Offset mismatch for FFabricMetaSoundUtilityParams::SelectEnabledParam");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FFabricMetaSoundUtilityPatches
{
    TSoftObjectPtr<UMetaSoundPatch*> CombinerNode; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> SwitcherNode; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> SelectNode; // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch*> AnalyzerNode; // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    FFabricMetaSoundUtilityParams UtilityNodeParams; // 0x80 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFabricMetaSoundUtilityPatches) == 0x88, "Size mismatch for FFabricMetaSoundUtilityPatches");
static_assert(offsetof(FFabricMetaSoundUtilityPatches, CombinerNode) == 0x0, "Offset mismatch for FFabricMetaSoundUtilityPatches::CombinerNode");
static_assert(offsetof(FFabricMetaSoundUtilityPatches, SwitcherNode) == 0x20, "Offset mismatch for FFabricMetaSoundUtilityPatches::SwitcherNode");
static_assert(offsetof(FFabricMetaSoundUtilityPatches, SelectNode) == 0x40, "Offset mismatch for FFabricMetaSoundUtilityPatches::SelectNode");
static_assert(offsetof(FFabricMetaSoundUtilityPatches, AnalyzerNode) == 0x60, "Offset mismatch for FFabricMetaSoundUtilityPatches::AnalyzerNode");
static_assert(offsetof(FFabricMetaSoundUtilityPatches, UtilityNodeParams) == 0x80, "Offset mismatch for FFabricMetaSoundUtilityPatches::UtilityNodeParams");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFabricLoadedUtilityPatches
{
    UMetaSoundPatch* CombinerNode; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* SwitcherNode; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* SelectNode; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* AnalyzerNode; // 0x18 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundUtilityParams UtilityNodeParams; // 0x20 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFabricLoadedUtilityPatches) == 0x28, "Size mismatch for FFabricLoadedUtilityPatches");
static_assert(offsetof(FFabricLoadedUtilityPatches, CombinerNode) == 0x0, "Offset mismatch for FFabricLoadedUtilityPatches::CombinerNode");
static_assert(offsetof(FFabricLoadedUtilityPatches, SwitcherNode) == 0x8, "Offset mismatch for FFabricLoadedUtilityPatches::SwitcherNode");
static_assert(offsetof(FFabricLoadedUtilityPatches, SelectNode) == 0x10, "Offset mismatch for FFabricLoadedUtilityPatches::SelectNode");
static_assert(offsetof(FFabricLoadedUtilityPatches, AnalyzerNode) == 0x18, "Offset mismatch for FFabricLoadedUtilityPatches::AnalyzerNode");
static_assert(offsetof(FFabricLoadedUtilityPatches, UtilityNodeParams) == 0x20, "Offset mismatch for FFabricLoadedUtilityPatches::UtilityNodeParams");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFabricTransportRequestConfig
{
    uint8_t PlayStrategy; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayPriority; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FName LockingAuthorityName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFabricTransportRequestConfig) == 0x8, "Size mismatch for FFabricTransportRequestConfig");
static_assert(offsetof(FFabricTransportRequestConfig, PlayStrategy) == 0x0, "Offset mismatch for FFabricTransportRequestConfig::PlayStrategy");
static_assert(offsetof(FFabricTransportRequestConfig, PlayPriority) == 0x1, "Offset mismatch for FFabricTransportRequestConfig::PlayPriority");
static_assert(offsetof(FFabricTransportRequestConfig, LockingAuthorityName) == 0x4, "Offset mismatch for FFabricTransportRequestConfig::LockingAuthorityName");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFabricMetaSoundDirectInputInfo
{
    FName MetaSoundInputName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t InputType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundDirectInputInfo) == 0x8, "Size mismatch for FFabricMetaSoundDirectInputInfo");
static_assert(offsetof(FFabricMetaSoundDirectInputInfo, MetaSoundInputName) == 0x0, "Offset mismatch for FFabricMetaSoundDirectInputInfo::MetaSoundInputName");
static_assert(offsetof(FFabricMetaSoundDirectInputInfo, InputType) == 0x4, "Offset mismatch for FFabricMetaSoundDirectInputInfo::InputType");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFabricMetaSoundUserOptionInputInfo
{
    FString UserOption; // 0x0 (Size: 0x10, Type: StrProperty)
    FName MetaSoundInputName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundUserOptionInputInfo) == 0x18, "Size mismatch for FFabricMetaSoundUserOptionInputInfo");
static_assert(offsetof(FFabricMetaSoundUserOptionInputInfo, UserOption) == 0x0, "Offset mismatch for FFabricMetaSoundUserOptionInputInfo::UserOption");
static_assert(offsetof(FFabricMetaSoundUserOptionInputInfo, MetaSoundInputName) == 0x10, "Offset mismatch for FFabricMetaSoundUserOptionInputInfo::MetaSoundInputName");

// Size: 0x240 (Inherited: 0x0, Single: 0x240)
struct FFabricMetaSoundRuntimeInputInfo
{
    FFabricMetaSoundUserOptionInputInfo InputInfo; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t InputType; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t FabricKnobType; // 0x19 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
    FName DataType; // 0x1c (Size: 0x4, Type: NameProperty)
    FName MetaSoundInputNodeName; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x5c]; // 0x24 (Size: 0x5c, Type: PaddingProperty)
    UFabricMetaSoundUserOption* MetaSoundUserOption; // 0x80 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    FFabricMetaSoundNodeInfo UserOptionConverterNode; // 0x90 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundConnectionBuilder InputBuilder; // 0x180 (Size: 0xc0, Type: StructProperty)
};

static_assert(sizeof(FFabricMetaSoundRuntimeInputInfo) == 0x240, "Size mismatch for FFabricMetaSoundRuntimeInputInfo");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, InputInfo) == 0x0, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::InputInfo");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, InputType) == 0x18, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::InputType");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, FabricKnobType) == 0x19, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::FabricKnobType");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, DataType) == 0x1c, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::DataType");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, MetaSoundInputNodeName) == 0x20, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::MetaSoundInputNodeName");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, MetaSoundUserOption) == 0x80, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::MetaSoundUserOption");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, UserOptionConverterNode) == 0x90, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::UserOptionConverterNode");
static_assert(offsetof(FFabricMetaSoundRuntimeInputInfo, InputBuilder) == 0x180, "Offset mismatch for FFabricMetaSoundRuntimeInputInfo::InputBuilder");

// Size: 0x230 (Inherited: 0x0, Single: 0x230)
struct FFabricConnectedInputWrapperInfo
{
    bool bDirectlyConnected; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UFabricMetaSoundPatchWrapper* Wrapper; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundNodeInfo OutputNode; // 0x10 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeOutputHandle ConnectedNodeOutput; // 0x100 (Size: 0x20, Type: StructProperty)
    FFabricMetaSoundNodeInfo InputNode; // 0x120 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle CombinerNodeInput; // 0x210 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFabricConnectedInputWrapperInfo) == 0x230, "Size mismatch for FFabricConnectedInputWrapperInfo");
static_assert(offsetof(FFabricConnectedInputWrapperInfo, bDirectlyConnected) == 0x0, "Offset mismatch for FFabricConnectedInputWrapperInfo::bDirectlyConnected");
static_assert(offsetof(FFabricConnectedInputWrapperInfo, Wrapper) == 0x8, "Offset mismatch for FFabricConnectedInputWrapperInfo::Wrapper");
static_assert(offsetof(FFabricConnectedInputWrapperInfo, OutputNode) == 0x10, "Offset mismatch for FFabricConnectedInputWrapperInfo::OutputNode");
static_assert(offsetof(FFabricConnectedInputWrapperInfo, ConnectedNodeOutput) == 0x100, "Offset mismatch for FFabricConnectedInputWrapperInfo::ConnectedNodeOutput");
static_assert(offsetof(FFabricConnectedInputWrapperInfo, InputNode) == 0x120, "Offset mismatch for FFabricConnectedInputWrapperInfo::InputNode");
static_assert(offsetof(FFabricConnectedInputWrapperInfo, CombinerNodeInput) == 0x210, "Offset mismatch for FFabricConnectedInputWrapperInfo::CombinerNodeInput");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
    FName NodeInputName; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bUseDefaultValues; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapper_PerPlatformInputTuning) == 0x8, "Size mismatch for FFabricMetaSoundPatchWrapper_PerPlatformInputTuning");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformInputTuning, NodeInputName) == 0x0, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformInputTuning::NodeInputName");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformInputTuning, bUseDefaultValues) == 0x4, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformInputTuning::bUseDefaultValues");

// Size: 0x60 (Inherited: 0x8, Single: 0x58)
struct FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning : FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
    bool bDefaultValue; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TMap<bool, FName> PerPlatformTuning; // 0x10 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning) == 0x60, "Size mismatch for FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning, bDefaultValue) == 0x8, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning::bDefaultValue");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning, PerPlatformTuning) == 0x10, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning::PerPlatformTuning");

// Size: 0x60 (Inherited: 0x8, Single: 0x58)
struct FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning : FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
    int32_t DefaultValue; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TMap<int32_t, FName> PerPlatformTuning; // 0x10 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning) == 0x60, "Size mismatch for FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning, DefaultValue) == 0x8, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning::DefaultValue");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning, PerPlatformTuning) == 0x10, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning::PerPlatformTuning");

// Size: 0x60 (Inherited: 0x8, Single: 0x58)
struct FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning : FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
    float DefaultValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TMap<float, FName> PerPlatformTuning; // 0x10 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning) == 0x60, "Size mismatch for FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning, DefaultValue) == 0x8, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning::DefaultValue");
static_assert(offsetof(FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning, PerPlatformTuning) == 0x10, "Offset mismatch for FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning::PerPlatformTuning");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FMusicalPosition
{
};

static_assert(sizeof(FMusicalPosition) == 0x8, "Size mismatch for FMusicalPosition");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FMidiFollowData
{
    float BeatOffset; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MSOffset; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FMidiFollowData) == 0x8, "Size mismatch for FMidiFollowData");
static_assert(offsetof(FMidiFollowData, BeatOffset) == 0x0, "Offset mismatch for FMidiFollowData::BeatOffset");
static_assert(offsetof(FMidiFollowData, MSOffset) == 0x4, "Offset mismatch for FMidiFollowData::MSOffset");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFabricSignificanceBasedUpdateBucket
{
    float MinDistanceFromPlayer; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromPlayer; // 0x4 (Size: 0x4, Type: FloatProperty)
    float FramesPerUpdate; // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t MaxObjectsInBucket; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFabricSignificanceBasedUpdateBucket) == 0x10, "Size mismatch for FFabricSignificanceBasedUpdateBucket");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucket, MinDistanceFromPlayer) == 0x0, "Offset mismatch for FFabricSignificanceBasedUpdateBucket::MinDistanceFromPlayer");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucket, MaxDistanceFromPlayer) == 0x4, "Offset mismatch for FFabricSignificanceBasedUpdateBucket::MaxDistanceFromPlayer");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucket, FramesPerUpdate) == 0x8, "Offset mismatch for FFabricSignificanceBasedUpdateBucket::FramesPerUpdate");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucket, MaxObjectsInBucket) == 0xc, "Offset mismatch for FFabricSignificanceBasedUpdateBucket::MaxObjectsInBucket");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFabricSignificanceBasedUpdateBucketRuntimeGroup
{
    TArray<TWeakObjectPtr<UObject*>> ObjectsInGroup; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricSignificanceBasedUpdateBucketRuntimeGroup) == 0x18, "Size mismatch for FFabricSignificanceBasedUpdateBucketRuntimeGroup");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntimeGroup, ObjectsInGroup) == 0x8, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntimeGroup::ObjectsInGroup");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFabricSignificanceBasedUpdateBucketRuntime
{
    float ActualMinSignificance; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ActualMaxSignificance; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t ActualMaxObjectsInBucket; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ActualFramesPerUpdate; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t TotalObjectsInBucketCount; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FFabricSignificanceBasedUpdateBucketRuntimeGroup> UpdateGroups; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricSignificanceBasedUpdateBucketRuntime) == 0x28, "Size mismatch for FFabricSignificanceBasedUpdateBucketRuntime");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntime, ActualMinSignificance) == 0x0, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntime::ActualMinSignificance");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntime, ActualMaxSignificance) == 0x4, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntime::ActualMaxSignificance");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntime, ActualMaxObjectsInBucket) == 0x8, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntime::ActualMaxObjectsInBucket");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntime, ActualFramesPerUpdate) == 0xc, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntime::ActualFramesPerUpdate");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntime, TotalObjectsInBucketCount) == 0x10, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntime::TotalObjectsInBucketCount");
static_assert(offsetof(FFabricSignificanceBasedUpdateBucketRuntime, UpdateGroups) == 0x18, "Offset mismatch for FFabricSignificanceBasedUpdateBucketRuntime::UpdateGroups");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFabricStepTrackPacked
{
    TArray<int32_t> PackedEnabledSquares; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> PackedContinuationSquares; // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t TrackIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricStepTrackPacked) == 0x28, "Size mismatch for FFabricStepTrackPacked");
static_assert(offsetof(FFabricStepTrackPacked, PackedEnabledSquares) == 0x0, "Offset mismatch for FFabricStepTrackPacked::PackedEnabledSquares");
static_assert(offsetof(FFabricStepTrackPacked, PackedContinuationSquares) == 0x10, "Offset mismatch for FFabricStepTrackPacked::PackedContinuationSquares");
static_assert(offsetof(FFabricStepTrackPacked, TrackIndex) == 0x20, "Offset mismatch for FFabricStepTrackPacked::TrackIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFabricStepPagePacked
{
    TArray<FFabricStepTrackPacked> PackedTracks; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t PageNumber; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricStepPagePacked) == 0x18, "Size mismatch for FFabricStepPagePacked");
static_assert(offsetof(FFabricStepPagePacked, PackedTracks) == 0x0, "Offset mismatch for FFabricStepPagePacked::PackedTracks");
static_assert(offsetof(FFabricStepPagePacked, PageNumber) == 0x10, "Offset mismatch for FFabricStepPagePacked::PageNumber");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFabricStepTablePacked
{
    TArray<FFabricStepPagePacked> PackedPages; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FStepSequenceNote> Notes; // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t StepSkipIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    bool bHasRepDelayApplied; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFabricStepTablePacked) == 0x28, "Size mismatch for FFabricStepTablePacked");
static_assert(offsetof(FFabricStepTablePacked, PackedPages) == 0x0, "Offset mismatch for FFabricStepTablePacked::PackedPages");
static_assert(offsetof(FFabricStepTablePacked, Notes) == 0x10, "Offset mismatch for FFabricStepTablePacked::Notes");
static_assert(offsetof(FFabricStepTablePacked, StepSkipIndex) == 0x20, "Offset mismatch for FFabricStepTablePacked::StepSkipIndex");
static_assert(offsetof(FFabricStepTablePacked, bHasRepDelayApplied) == 0x24, "Offset mismatch for FFabricStepTablePacked::bHasRepDelayApplied");

// Size: 0x90 (Inherited: 0xc0, Single: 0xffffffd0)
struct FFabricStepSequencerComponentBaseInstanceData : FActorComponentInstanceData
{
    FFabricStepTablePacked PackedStepTable; // 0x68 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FFabricStepSequencerComponentBaseInstanceData) == 0x90, "Size mismatch for FFabricStepSequencerComponentBaseInstanceData");
static_assert(offsetof(FFabricStepSequencerComponentBaseInstanceData, PackedStepTable) == 0x68, "Offset mismatch for FFabricStepSequencerComponentBaseInstanceData::PackedStepTable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTrackRow
{
    TArray<UFabricStepSequencerGridSquareComponent*> GridSquares; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FTrackRow) == 0x10, "Size mismatch for FTrackRow");
static_assert(offsetof(FTrackRow, GridSquares) == 0x0, "Offset mismatch for FTrackRow::GridSquares");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FFabricTimelineSyncServerSongPosition
{
    FMusicTimestamp Timestamp; // 0x0 (Size: 0x8, Type: StructProperty)
    float SecondsIncludingCountIn; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Tempo; // 0xc (Size: 0x4, Type: FloatProperty)
    float BeatsIncludingCountIn; // 0x10 (Size: 0x4, Type: FloatProperty)
    float NetServerTimeWhenSent; // 0x14 (Size: 0x4, Type: FloatProperty)
    float TimeSigDenominator; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFabricTimelineSyncServerSongPosition) == 0x1c, "Size mismatch for FFabricTimelineSyncServerSongPosition");
static_assert(offsetof(FFabricTimelineSyncServerSongPosition, Timestamp) == 0x0, "Offset mismatch for FFabricTimelineSyncServerSongPosition::Timestamp");
static_assert(offsetof(FFabricTimelineSyncServerSongPosition, SecondsIncludingCountIn) == 0x8, "Offset mismatch for FFabricTimelineSyncServerSongPosition::SecondsIncludingCountIn");
static_assert(offsetof(FFabricTimelineSyncServerSongPosition, Tempo) == 0xc, "Offset mismatch for FFabricTimelineSyncServerSongPosition::Tempo");
static_assert(offsetof(FFabricTimelineSyncServerSongPosition, BeatsIncludingCountIn) == 0x10, "Offset mismatch for FFabricTimelineSyncServerSongPosition::BeatsIncludingCountIn");
static_assert(offsetof(FFabricTimelineSyncServerSongPosition, NetServerTimeWhenSent) == 0x14, "Offset mismatch for FFabricTimelineSyncServerSongPosition::NetServerTimeWhenSent");
static_assert(offsetof(FFabricTimelineSyncServerSongPosition, TimeSigDenominator) == 0x18, "Offset mismatch for FFabricTimelineSyncServerSongPosition::TimeSigDenominator");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFabricVFXTopperDataEntry
{
    UStaticMesh* StaticMesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstance*> MaterialInstance; // 0x8 (Size: 0x10, Type: ArrayProperty)
    UNiagaraSystem* NiagaraSystem; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFabricVFXTopperDataEntry) == 0x20, "Size mismatch for FFabricVFXTopperDataEntry");
static_assert(offsetof(FFabricVFXTopperDataEntry, StaticMesh) == 0x0, "Offset mismatch for FFabricVFXTopperDataEntry::StaticMesh");
static_assert(offsetof(FFabricVFXTopperDataEntry, MaterialInstance) == 0x8, "Offset mismatch for FFabricVFXTopperDataEntry::MaterialInstance");
static_assert(offsetof(FFabricVFXTopperDataEntry, NiagaraSystem) == 0x18, "Offset mismatch for FFabricVFXTopperDataEntry::NiagaraSystem");

