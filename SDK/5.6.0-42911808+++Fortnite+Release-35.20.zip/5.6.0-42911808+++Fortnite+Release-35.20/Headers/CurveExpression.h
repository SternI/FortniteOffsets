/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CurveExpression
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UCurveExpressionsDataAsset : public UDataAsset
{
public:
    TArray<FName> NamedConstants; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UCurveExpressionsDataAsset) == 0x50, "Size mismatch for UCurveExpressionsDataAsset");
static_assert(offsetof(UCurveExpressionsDataAsset, NamedConstants) == 0x30, "Offset mismatch for UCurveExpressionsDataAsset::NamedConstants");

// Size: 0x110 (Inherited: 0x10, Single: 0x100)
struct FAnimNode_RemapCurvesBase : FAnimNode_Base
{
    FPoseLink SourcePose; // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t ExpressionSource; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    FCurveExpressionList ExpressionList; // 0x28 (Size: 0x10, Type: StructProperty)
    UCurveExpressionsDataAsset* CurveExpressionsDataAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
    TMap<FString, FName> CurveExpressions; // 0x40 (Size: 0x50, Type: MapProperty)
    bool bExpressionsImmutable; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    TArray<FName> CachedConstantNames; // 0x98 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a8[0x68]; // 0xa8 (Size: 0x68, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RemapCurvesBase) == 0x110, "Size mismatch for FAnimNode_RemapCurvesBase");
static_assert(offsetof(FAnimNode_RemapCurvesBase, SourcePose) == 0x10, "Offset mismatch for FAnimNode_RemapCurvesBase::SourcePose");
static_assert(offsetof(FAnimNode_RemapCurvesBase, ExpressionSource) == 0x20, "Offset mismatch for FAnimNode_RemapCurvesBase::ExpressionSource");
static_assert(offsetof(FAnimNode_RemapCurvesBase, ExpressionList) == 0x28, "Offset mismatch for FAnimNode_RemapCurvesBase::ExpressionList");
static_assert(offsetof(FAnimNode_RemapCurvesBase, CurveExpressionsDataAsset) == 0x38, "Offset mismatch for FAnimNode_RemapCurvesBase::CurveExpressionsDataAsset");
static_assert(offsetof(FAnimNode_RemapCurvesBase, CurveExpressions) == 0x40, "Offset mismatch for FAnimNode_RemapCurvesBase::CurveExpressions");
static_assert(offsetof(FAnimNode_RemapCurvesBase, bExpressionsImmutable) == 0x90, "Offset mismatch for FAnimNode_RemapCurvesBase::bExpressionsImmutable");
static_assert(offsetof(FAnimNode_RemapCurvesBase, CachedConstantNames) == 0x98, "Offset mismatch for FAnimNode_RemapCurvesBase::CachedConstantNames");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurveExpressionList
{
    FString AssignmentExpressions; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCurveExpressionList) == 0x10, "Size mismatch for FCurveExpressionList");
static_assert(offsetof(FCurveExpressionList, AssignmentExpressions) == 0x0, "Offset mismatch for FCurveExpressionList::AssignmentExpressions");

// Size: 0x110 (Inherited: 0x120, Single: 0xfffffff0)
struct FAnimNode_RemapCurves : FAnimNode_RemapCurvesBase
{
};

static_assert(sizeof(FAnimNode_RemapCurves) == 0x110, "Size mismatch for FAnimNode_RemapCurves");

// Size: 0x188 (Inherited: 0x120, Single: 0x68)
struct FAnimNode_RemapCurvesFromMesh : FAnimNode_RemapCurvesBase
{
    TWeakObjectPtr<USkeletalMeshComponent*> SourceMeshComponent; // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    bool bUseAttachedParent; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x6f]; // 0x119 (Size: 0x6f, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RemapCurvesFromMesh) == 0x188, "Size mismatch for FAnimNode_RemapCurvesFromMesh");
static_assert(offsetof(FAnimNode_RemapCurvesFromMesh, SourceMeshComponent) == 0x110, "Offset mismatch for FAnimNode_RemapCurvesFromMesh::SourceMeshComponent");
static_assert(offsetof(FAnimNode_RemapCurvesFromMesh, bUseAttachedParent) == 0x118, "Offset mismatch for FAnimNode_RemapCurvesFromMesh::bUseAttachedParent");

