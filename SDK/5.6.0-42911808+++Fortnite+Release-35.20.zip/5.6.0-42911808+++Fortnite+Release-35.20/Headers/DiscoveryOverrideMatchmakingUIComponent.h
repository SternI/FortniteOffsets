/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoveryOverrideMatchmakingUIComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DiscoveryBrowserUI.h"

// Size: 0x100 (Inherited: 0x1e0, Single: 0xffffff20)
class UDiscoveryOverrideMatchmakingUIComponent_C : public UOverrideMatchmakingUIComponent
{
public:
};

static_assert(sizeof(UDiscoveryOverrideMatchmakingUIComponent_C) == 0x100, "Size mismatch for UDiscoveryOverrideMatchmakingUIComponent_C");

