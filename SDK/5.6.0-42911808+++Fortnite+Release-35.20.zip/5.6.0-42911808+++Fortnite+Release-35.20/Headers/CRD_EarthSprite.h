/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_EarthSprite
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "PlayspaceSystem.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x108 (Inherited: 0x250, Single: 0xfffffeb8)
class UFortCreativeEarthSpriteManagerComponent : public UPlayspaceComponent
{
public:

public:
    bool CanTrade(ABuildingProp*& const EarthSprite, int32_t& Limit, APlayerState*& const TradersState) const; // 0x11e2c7f4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void CountTrade(APlayerState*& const TradingPlayersState, bool& bGlobal, ABuildingProp*& const EarthSprite); // 0x11e2cbac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void DisableTrade(ABuildingProp*& const EarthSprite, APlayerState*& const TradersState); // 0x11e2d0d0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void RegisterEarthSprite(ABuildingProp*& const EarthSpriteToRegister); // 0x11e2d6a4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void ResetAllTradeCounts(ABuildingProp*& const EarthSprite); // 0x11e2d7e4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void ResetTradeCount(ABuildingProp*& const EarthSprite, APlayerState*& const TradersState); // 0x11e2d998 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterEarthSprite(ABuildingProp*& const EarthSpriteToUnregister); // 0x11e2dc0c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

private:
    void BindMinigameStateChangedEvent(); // 0x11e2c7e0 (Index: 0x0, Flags: Final|Native|Private)
    void HandleMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& NewMinigameState); // 0x11e2d3d0 (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortCreativeEarthSpriteManagerComponent) == 0x108, "Size mismatch for UFortCreativeEarthSpriteManagerComponent");

