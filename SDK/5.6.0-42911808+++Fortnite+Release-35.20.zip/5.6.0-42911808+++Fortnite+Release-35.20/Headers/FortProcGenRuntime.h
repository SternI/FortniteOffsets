/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortProcGenRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "PCG.h"

// Size: 0x128 (Inherited: 0x120, Single: 0x8)
class UFortProcGenManager : public UFortProcGenRandomSubsystem
{
public:
    uint8_t OnProcGenReady[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnProcGenStarted[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnProcGenFinished[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_c8[0x10]; // 0xc8 (Size: 0x10, Type: PaddingProperty)
    TSet<AFortProcGenActor*> ActiveGeneratingActors; // 0xd8 (Size: 0x50, Type: SetProperty)

public:
    bool IsProcGenFinished() const; // 0x1146c8ac (Index: 0x1, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void CheckProcGenReady(); // 0x1146c644 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortProcGenManager) == 0x128, "Size mismatch for UFortProcGenManager");
static_assert(offsetof(UFortProcGenManager, OnProcGenReady) == 0x98, "Offset mismatch for UFortProcGenManager::OnProcGenReady");
static_assert(offsetof(UFortProcGenManager, OnProcGenStarted) == 0xa8, "Offset mismatch for UFortProcGenManager::OnProcGenStarted");
static_assert(offsetof(UFortProcGenManager, OnProcGenFinished) == 0xb8, "Offset mismatch for UFortProcGenManager::OnProcGenFinished");
static_assert(offsetof(UFortProcGenManager, ActiveGeneratingActors) == 0xd8, "Offset mismatch for UFortProcGenManager::ActiveGeneratingActors");

// Size: 0x98 (Inherited: 0x88, Single: 0x10)
class UFortProcGenRandomSubsystem : public UWorldSubsystem
{
public:

public:
    int32_t GetInstanceSeed() const; // 0xa1f08f4 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSubsystemReady() const; // 0xbea6ef4 (Index: 0x1, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool RandomBool(UObject*& const RequestingObject); // 0x1146ca38 (Index: 0x2, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    float RandomFloat(UObject*& const RequestingObject, float& Min, float& Max); // 0x1146d0a4 (Index: 0x3, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    int32_t RandomInteger(UObject*& const RequestingObject, int32_t& Min, int32_t& Max); // 0x1146d390 (Index: 0x4, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    FVector RandomPointInBoundingBox(UObject*& const RequestingObject, FVector& const Center, FVector& const HalfSize); // 0x1146d678 (Index: 0x5, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable)
    FVector RandomPointInBoundingBox_Box(UObject*& const RequestingObject, FBox& const Box); // 0x1146de18 (Index: 0x6, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable)
    FRotator RandomRotator(UObject*& const RequestingObject, bool& bRoll); // 0x1146e5d4 (Index: 0x7, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable)
    FVector RandomUnitVector(UObject*& const RequestingObject); // 0x1146ed40 (Index: 0x8, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable)
    FVector RandomUnitVectorInConeInDegrees(UObject*& const RequestingObject, const FVector ConeDir, float& ConeHalfAngleInDegrees); // 0x1146f3b8 (Index: 0x9, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FVector RandomUnitVectorInConeInRadians(UObject*& const RequestingObject, const FVector ConeDir, float& ConeHalfAngleInRadians); // 0x1146f634 (Index: 0xa, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FVector RandomUnitVectorInEllipticalConeInDegrees(UObject*& const RequestingObject, const FVector ConeDir, float& MaxYawInDegrees, float& MaxPitchInDegrees); // 0x1146f8b0 (Index: 0xb, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FVector RandomUnitVectorInEllipticalConeInRadians(UObject*& const RequestingObject, const FVector ConeDir, float& MaxYawInRadians, float& MaxPitchInRadians); // 0x1146fbbc (Index: 0xc, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFortProcGenRandomSubsystem) == 0x98, "Size mismatch for UFortProcGenRandomSubsystem");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UAsyncAction_FortProcGenRandomSubsystemReady : public UBlueprintAsyncActionBase
{
public:
    uint8_t OnReady[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)

public:
    static UAsyncAction_FortProcGenRandomSubsystemReady* FortProcGenRandomSubsystemReady(UObject*& WorldContextObject); // 0x1146c658 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)

private:
    void HandleSubsytemInitialized(UFortProcGenRandomSubsystem*& Subsystem); // 0x1146c780 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UAsyncAction_FortProcGenRandomSubsystemReady) == 0x48, "Size mismatch for UAsyncAction_FortProcGenRandomSubsystemReady");
static_assert(offsetof(UAsyncAction_FortProcGenRandomSubsystemReady, OnReady) == 0x30, "Offset mismatch for UAsyncAction_FortProcGenRandomSubsystemReady::OnReady");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AFortProcGenActor : public AActor
{
public:

protected:
    virtual void OnGenerationFinished(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnGenerationStarted(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    void PCGCompGenerationFinished(FPCGDataCollection& PCGData); // 0x1146c8d4 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    virtual void PerformCustomGeneration_BP(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AFortProcGenActor) == 0x2b0, "Size mismatch for AFortProcGenActor");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FFortInstanceRandomStream
{
};

static_assert(sizeof(FFortInstanceRandomStream) == 0x58, "Size mismatch for FFortInstanceRandomStream");

