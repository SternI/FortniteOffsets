/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioGameplayBehavior
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "AudioGameplay.h"
#include "CoreUObject.h"

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UAudioGameplayBehavior : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    bool bKillOnSoundsFinished; // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool bTickWhileStopped; // 0xc1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c2[0x6]; // 0xc2 (Size: 0x6, Type: PaddingProperty)
    uint8_t OnAllSoundsFinished[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSoundFinished[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<FActiveVoice> PlayingSounds; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    UAudioComponentGroup* ComponentGroupOwner; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bReleaseActiveVoicesOnFadeOut; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0xf]; // 0x101 (Size: 0xf, Type: PaddingProperty)

public:
    virtual void BP_OnFinished(); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void BP_OnGroupSet(UAudioComponentGroup*& SoundGroup); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void BP_OnStart(); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void BP_OnStop(); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void BP_OnUnvirtualized(); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void BP_OnVirtualized(); // 0x288a61c (Index: 0x5, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void DisableVirtualization(); // 0xffcdac0 (Index: 0x6, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void EnableVirtualization(); // 0xffcdad4 (Index: 0x7, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    bool GetBoolParamValue(FName& const ParamName) const; // 0x516563c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFloatParamValue(FName& const ParamName) const; // 0xffcdae8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EAudioGameplayBehaviorPlayState GetPlayState(); // 0xca987f8 (Index: 0xa, Flags: Native|Public|BlueprintCallable|BlueprintPure)
    UAudioComponentGroup* GetSoundGroup() const; // 0xdcaedac (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EAudioGameplayBehaviorPlayState GetStopState(); // 0xaf6b4b0 (Index: 0xc, Flags: Native|Public|BlueprintCallable)
    FString GetStringParamValue(FName& const ParamName) const; // 0xffcdc24 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlayingAny() const; // 0xcc9eca0 (Index: 0xe, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsVirtualized() const; // 0xa287c60 (Index: 0xf, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Kill(); // 0xcc87b74 (Index: 0x10, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable)
    void PlayFrom(UAudioComponentGroup*& SoundGroup); // 0xd385b00 (Index: 0x11, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable)
    FActiveVoice PlaySound(USoundBase*& Sound, float& InFadeInTime, float& InTargetVolume, float& InStartTime, bool& bDisableAttenuation, EAudioFaderCurve& const InFadeCurve, FVector& const InRelativeLocation, FRotator& const InRelativeRotation); // 0x3abc0a8 (Index: 0x12, Flags: Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable)
    void SetPlayState(EAudioGameplayBehaviorPlayState& NewState); // 0xffcdf34 (Index: 0x13, Flags: Native|Public|BlueprintCallable)
    void Start(); // 0x270d644 (Index: 0x14, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable)
    void Stop(); // 0x3abd220 (Index: 0x15, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StopAllPlayingVoices(float& InFadeOutTime); // 0xffce064 (Index: 0x16, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StopById(FPlayingId& ID, float& InFadeOutTime, EAudioFaderCurve& const InFadeCurve); // 0xffce190 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void StopComponent(UAudioComponent*& Comp, float& InFadeOutTime, EAudioFaderCurve& const InFadeCurve); // 0x5268554 (Index: 0x18, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StopSound(USoundBase*& Sound, float& InFadeOutTime, EAudioFaderCurve& const InFadeCurve); // 0xffce35c (Index: 0x19, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SubscribeToBoolParam(FName& ParamName, FDelegate& Delegate); // 0xffce640 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SubscribeToEvent(FName& EventName, FDelegate& Delegate); // 0xffce864 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void SubscribeToStringParam(FName& ParamName, FDelegate& Delegate); // 0xffcea88 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioGameplayBehavior) == 0x110, "Size mismatch for UAudioGameplayBehavior");
static_assert(offsetof(UAudioGameplayBehavior, bKillOnSoundsFinished) == 0xc0, "Offset mismatch for UAudioGameplayBehavior::bKillOnSoundsFinished");
static_assert(offsetof(UAudioGameplayBehavior, bTickWhileStopped) == 0xc1, "Offset mismatch for UAudioGameplayBehavior::bTickWhileStopped");
static_assert(offsetof(UAudioGameplayBehavior, OnAllSoundsFinished) == 0xc8, "Offset mismatch for UAudioGameplayBehavior::OnAllSoundsFinished");
static_assert(offsetof(UAudioGameplayBehavior, OnSoundFinished) == 0xd8, "Offset mismatch for UAudioGameplayBehavior::OnSoundFinished");
static_assert(offsetof(UAudioGameplayBehavior, PlayingSounds) == 0xe8, "Offset mismatch for UAudioGameplayBehavior::PlayingSounds");
static_assert(offsetof(UAudioGameplayBehavior, ComponentGroupOwner) == 0xf8, "Offset mismatch for UAudioGameplayBehavior::ComponentGroupOwner");
static_assert(offsetof(UAudioGameplayBehavior, bReleaseActiveVoicesOnFadeOut) == 0x100, "Offset mismatch for UAudioGameplayBehavior::bReleaseActiveVoicesOnFadeOut");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FActiveVoice
{
    USoundBase* Sound; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* Component; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FPlayingId ID; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FActiveVoice) == 0x18, "Size mismatch for FActiveVoice");
static_assert(offsetof(FActiveVoice, Sound) == 0x0, "Offset mismatch for FActiveVoice::Sound");
static_assert(offsetof(FActiveVoice, Component) == 0x8, "Offset mismatch for FActiveVoice::Component");
static_assert(offsetof(FActiveVoice, ID) == 0x10, "Offset mismatch for FActiveVoice::ID");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPlayingId
{
};

static_assert(sizeof(FPlayingId) == 0x4, "Size mismatch for FPlayingId");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAudioGameplayBehaviorInstance
{
    UClass* Sound; // 0x0 (Size: 0x8, Type: ClassProperty)
    UAudioGameplayBehavior* Instance; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAudioGameplayBehaviorInstance) == 0x10, "Size mismatch for FAudioGameplayBehaviorInstance");
static_assert(offsetof(FAudioGameplayBehaviorInstance, Sound) == 0x0, "Offset mismatch for FAudioGameplayBehaviorInstance::Sound");
static_assert(offsetof(FAudioGameplayBehaviorInstance, Instance) == 0x8, "Offset mismatch for FAudioGameplayBehaviorInstance::Instance");

