/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaUtilities
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x2c0 (Inherited: 0x2d0, Single: 0xfffffff0)
class AEpicMediaServerTime : public AActor
{
public:

public:
    virtual void ClientReportServerTime(double& requestUtcTime, double& serverUtcTime); // 0xc58ead8 (Index: 0x0, Flags: Net|NetReliableNative|Event|Public|NetClient)
    bool GetTimeUtc(FDateTime OutDateTime) const; // 0xc58ecf8 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    virtual void ServerRequestServerTime(double& requestUtcTime); // 0xc58edec (Index: 0x2, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
};

static_assert(sizeof(AEpicMediaServerTime) == 0x2c0, "Size mismatch for AEpicMediaServerTime");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEpicMediaImageDataExt
{
    FString URL; // 0x0 (Size: 0x10, Type: StrProperty)
    FString FullUrl; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t Width; // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t Height; // 0x24 (Size: 0x4, Type: IntProperty)
    float AspectRatio; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEpicMediaImageDataExt) == 0x30, "Size mismatch for FEpicMediaImageDataExt");
static_assert(offsetof(FEpicMediaImageDataExt, URL) == 0x0, "Offset mismatch for FEpicMediaImageDataExt::URL");
static_assert(offsetof(FEpicMediaImageDataExt, FullUrl) == 0x10, "Offset mismatch for FEpicMediaImageDataExt::FullUrl");
static_assert(offsetof(FEpicMediaImageDataExt, Width) == 0x20, "Offset mismatch for FEpicMediaImageDataExt::Width");
static_assert(offsetof(FEpicMediaImageDataExt, Height) == 0x24, "Offset mismatch for FEpicMediaImageDataExt::Height");
static_assert(offsetof(FEpicMediaImageDataExt, AspectRatio) == 0x28, "Offset mismatch for FEpicMediaImageDataExt::AspectRatio");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEpicMediaAudioOnlyPeriodDataExt
{
    FLinearColor Color; // 0x0 (Size: 0x10, Type: StructProperty)
    bool bColorSet; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    double StartFrame; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double EndFrame; // 0x20 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FEpicMediaAudioOnlyPeriodDataExt) == 0x28, "Size mismatch for FEpicMediaAudioOnlyPeriodDataExt");
static_assert(offsetof(FEpicMediaAudioOnlyPeriodDataExt, Color) == 0x0, "Offset mismatch for FEpicMediaAudioOnlyPeriodDataExt::Color");
static_assert(offsetof(FEpicMediaAudioOnlyPeriodDataExt, bColorSet) == 0x10, "Offset mismatch for FEpicMediaAudioOnlyPeriodDataExt::bColorSet");
static_assert(offsetof(FEpicMediaAudioOnlyPeriodDataExt, StartFrame) == 0x18, "Offset mismatch for FEpicMediaAudioOnlyPeriodDataExt::StartFrame");
static_assert(offsetof(FEpicMediaAudioOnlyPeriodDataExt, EndFrame) == 0x20, "Offset mismatch for FEpicMediaAudioOnlyPeriodDataExt::EndFrame");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEpicMediaVolumeChangeDataExt
{
    double Frame; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Level; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Lerp; // 0x10 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_18[0x10]; // 0x18 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FEpicMediaVolumeChangeDataExt) == 0x28, "Size mismatch for FEpicMediaVolumeChangeDataExt");
static_assert(offsetof(FEpicMediaVolumeChangeDataExt, Frame) == 0x0, "Offset mismatch for FEpicMediaVolumeChangeDataExt::Frame");
static_assert(offsetof(FEpicMediaVolumeChangeDataExt, Level) == 0x8, "Offset mismatch for FEpicMediaVolumeChangeDataExt::Level");
static_assert(offsetof(FEpicMediaVolumeChangeDataExt, Lerp) == 0x10, "Offset mismatch for FEpicMediaVolumeChangeDataExt::Lerp");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FEpicMediaPlaylistExt
{
    FString Language; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Type; // 0x10 (Size: 0x10, Type: StrProperty)
    FString URL; // 0x20 (Size: 0x10, Type: StrProperty)
    FString RelUrl; // 0x30 (Size: 0x10, Type: StrProperty)
    FString Data; // 0x40 (Size: 0x10, Type: StrProperty)
    double duration; // 0x50 (Size: 0x8, Type: DoubleProperty)
    double FPS; // 0x58 (Size: 0x8, Type: DoubleProperty)
    TArray<FEpicMediaImageDataExt> Images; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaAudioOnlyPeriodDataExt> AudioOnlyPeriods; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaVolumeChangeDataExt> VolumeChanges; // 0x80 (Size: 0x10, Type: ArrayProperty)
    double SkipBoundaryTime; // 0x90 (Size: 0x8, Type: DoubleProperty)
    double PreEndEventTime; // 0x98 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FEpicMediaPlaylistExt) == 0xa0, "Size mismatch for FEpicMediaPlaylistExt");
static_assert(offsetof(FEpicMediaPlaylistExt, Language) == 0x0, "Offset mismatch for FEpicMediaPlaylistExt::Language");
static_assert(offsetof(FEpicMediaPlaylistExt, Type) == 0x10, "Offset mismatch for FEpicMediaPlaylistExt::Type");
static_assert(offsetof(FEpicMediaPlaylistExt, URL) == 0x20, "Offset mismatch for FEpicMediaPlaylistExt::URL");
static_assert(offsetof(FEpicMediaPlaylistExt, RelUrl) == 0x30, "Offset mismatch for FEpicMediaPlaylistExt::RelUrl");
static_assert(offsetof(FEpicMediaPlaylistExt, Data) == 0x40, "Offset mismatch for FEpicMediaPlaylistExt::Data");
static_assert(offsetof(FEpicMediaPlaylistExt, duration) == 0x50, "Offset mismatch for FEpicMediaPlaylistExt::duration");
static_assert(offsetof(FEpicMediaPlaylistExt, FPS) == 0x58, "Offset mismatch for FEpicMediaPlaylistExt::FPS");
static_assert(offsetof(FEpicMediaPlaylistExt, Images) == 0x60, "Offset mismatch for FEpicMediaPlaylistExt::Images");
static_assert(offsetof(FEpicMediaPlaylistExt, AudioOnlyPeriods) == 0x70, "Offset mismatch for FEpicMediaPlaylistExt::AudioOnlyPeriods");
static_assert(offsetof(FEpicMediaPlaylistExt, VolumeChanges) == 0x80, "Offset mismatch for FEpicMediaPlaylistExt::VolumeChanges");
static_assert(offsetof(FEpicMediaPlaylistExt, SkipBoundaryTime) == 0x90, "Offset mismatch for FEpicMediaPlaylistExt::SkipBoundaryTime");
static_assert(offsetof(FEpicMediaPlaylistExt, PreEndEventTime) == 0x98, "Offset mismatch for FEpicMediaPlaylistExt::PreEndEventTime");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FEpicMediaRegionLockExt
{
    bool AllowOnError; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString Type; // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FString> AllowList; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> DenyList; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> Limits; // 0x38 (Size: 0x50, Type: MapProperty)
    FString ContentId; // 0x88 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_98[0x10]; // 0x98 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FEpicMediaRegionLockExt) == 0xa8, "Size mismatch for FEpicMediaRegionLockExt");
static_assert(offsetof(FEpicMediaRegionLockExt, AllowOnError) == 0x0, "Offset mismatch for FEpicMediaRegionLockExt::AllowOnError");
static_assert(offsetof(FEpicMediaRegionLockExt, Type) == 0x8, "Offset mismatch for FEpicMediaRegionLockExt::Type");
static_assert(offsetof(FEpicMediaRegionLockExt, AllowList) == 0x18, "Offset mismatch for FEpicMediaRegionLockExt::AllowList");
static_assert(offsetof(FEpicMediaRegionLockExt, DenyList) == 0x28, "Offset mismatch for FEpicMediaRegionLockExt::DenyList");
static_assert(offsetof(FEpicMediaRegionLockExt, Limits) == 0x38, "Offset mismatch for FEpicMediaRegionLockExt::Limits");
static_assert(offsetof(FEpicMediaRegionLockExt, ContentId) == 0x88, "Offset mismatch for FEpicMediaRegionLockExt::ContentId");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEpicMediaAudioMetadataTrackIndicesExt
{
    TArray<int32_t> Indices; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEpicMediaAudioMetadataTrackIndicesExt) == 0x10, "Size mismatch for FEpicMediaAudioMetadataTrackIndicesExt");
static_assert(offsetof(FEpicMediaAudioMetadataTrackIndicesExt, Indices) == 0x0, "Offset mismatch for FEpicMediaAudioMetadataTrackIndicesExt::Indices");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEpicMediaAudioMetadataTrackExt
{
    TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString> TrackData; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FEpicMediaAudioMetadataTrackExt) == 0x50, "Size mismatch for FEpicMediaAudioMetadataTrackExt");
static_assert(offsetof(FEpicMediaAudioMetadataTrackExt, TrackData) == 0x0, "Offset mismatch for FEpicMediaAudioMetadataTrackExt::TrackData");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FEpicMediaAudioMetadataDataExt
{
    FString ShortName; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t SongID; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FString Title; // 0x18 (Size: 0x10, Type: StrProperty)
    FString Artist; // 0x28 (Size: 0x10, Type: StrProperty)
    FString Album; // 0x38 (Size: 0x10, Type: StrProperty)
    FString Genre; // 0x48 (Size: 0x10, Type: StrProperty)
    int32_t Year; // 0x58 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    TMap<int32_t, FString> Difficulty; // 0x60 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FEpicMediaAudioMetadataDataExt) == 0xb0, "Size mismatch for FEpicMediaAudioMetadataDataExt");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, ShortName) == 0x0, "Offset mismatch for FEpicMediaAudioMetadataDataExt::ShortName");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, SongID) == 0x10, "Offset mismatch for FEpicMediaAudioMetadataDataExt::SongID");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, Title) == 0x18, "Offset mismatch for FEpicMediaAudioMetadataDataExt::Title");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, Artist) == 0x28, "Offset mismatch for FEpicMediaAudioMetadataDataExt::Artist");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, Album) == 0x38, "Offset mismatch for FEpicMediaAudioMetadataDataExt::Album");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, Genre) == 0x48, "Offset mismatch for FEpicMediaAudioMetadataDataExt::Genre");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, Year) == 0x58, "Offset mismatch for FEpicMediaAudioMetadataDataExt::Year");
static_assert(offsetof(FEpicMediaAudioMetadataDataExt, Difficulty) == 0x60, "Offset mismatch for FEpicMediaAudioMetadataDataExt::Difficulty");

// Size: 0x130 (Inherited: 0x0, Single: 0x130)
struct FEpicMediaAudioMetadataExt
{
    TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString> Tracks; // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<float> Pans; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<float> Volumes; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<char> Midi; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FEpicMediaAudioMetadataDataExt MetadataData; // 0x80 (Size: 0xb0, Type: StructProperty)
};

static_assert(sizeof(FEpicMediaAudioMetadataExt) == 0x130, "Size mismatch for FEpicMediaAudioMetadataExt");
static_assert(offsetof(FEpicMediaAudioMetadataExt, Tracks) == 0x0, "Offset mismatch for FEpicMediaAudioMetadataExt::Tracks");
static_assert(offsetof(FEpicMediaAudioMetadataExt, Pans) == 0x50, "Offset mismatch for FEpicMediaAudioMetadataExt::Pans");
static_assert(offsetof(FEpicMediaAudioMetadataExt, Volumes) == 0x60, "Offset mismatch for FEpicMediaAudioMetadataExt::Volumes");
static_assert(offsetof(FEpicMediaAudioMetadataExt, Midi) == 0x70, "Offset mismatch for FEpicMediaAudioMetadataExt::Midi");
static_assert(offsetof(FEpicMediaAudioMetadataExt, MetadataData) == 0x80, "Offset mismatch for FEpicMediaAudioMetadataExt::MetadataData");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FEpicMediaExtraMetadataExt
{
    FString AssetId; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FString> BaseURLs; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString BaseUrl; // 0x20 (Size: 0x10, Type: StrProperty)
    int64_t Version; // 0x30 (Size: 0x8, Type: Int64Property)
    int64_t ExpiresAt; // 0x38 (Size: 0x8, Type: Int64Property)
    bool bSupportsCaching; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bSharelock; // 0x41 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_42[0x6]; // 0x42 (Size: 0x6, Type: PaddingProperty)
    FString UserContentProtection; // 0x48 (Size: 0x10, Type: StrProperty)
    FString Limits; // 0x58 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEpicMediaExtraMetadataExt) == 0x68, "Size mismatch for FEpicMediaExtraMetadataExt");
static_assert(offsetof(FEpicMediaExtraMetadataExt, AssetId) == 0x0, "Offset mismatch for FEpicMediaExtraMetadataExt::AssetId");
static_assert(offsetof(FEpicMediaExtraMetadataExt, BaseURLs) == 0x10, "Offset mismatch for FEpicMediaExtraMetadataExt::BaseURLs");
static_assert(offsetof(FEpicMediaExtraMetadataExt, BaseUrl) == 0x20, "Offset mismatch for FEpicMediaExtraMetadataExt::BaseUrl");
static_assert(offsetof(FEpicMediaExtraMetadataExt, Version) == 0x30, "Offset mismatch for FEpicMediaExtraMetadataExt::Version");
static_assert(offsetof(FEpicMediaExtraMetadataExt, ExpiresAt) == 0x38, "Offset mismatch for FEpicMediaExtraMetadataExt::ExpiresAt");
static_assert(offsetof(FEpicMediaExtraMetadataExt, bSupportsCaching) == 0x40, "Offset mismatch for FEpicMediaExtraMetadataExt::bSupportsCaching");
static_assert(offsetof(FEpicMediaExtraMetadataExt, bSharelock) == 0x41, "Offset mismatch for FEpicMediaExtraMetadataExt::bSharelock");
static_assert(offsetof(FEpicMediaExtraMetadataExt, UserContentProtection) == 0x48, "Offset mismatch for FEpicMediaExtraMetadataExt::UserContentProtection");
static_assert(offsetof(FEpicMediaExtraMetadataExt, Limits) == 0x58, "Offset mismatch for FEpicMediaExtraMetadataExt::Limits");

// Size: 0x308 (Inherited: 0x0, Single: 0x308)
struct FEpicMediaMetadataExt
{
    TArray<FEpicMediaPlaylistExt> Playlists; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaPlaylistExt> StateStreamPlaylists; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaPlaylistExt> SelectedPlaylists; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FString Type; // 0x30 (Size: 0x10, Type: StrProperty)
    FString Envelope; // 0x40 (Size: 0x10, Type: StrProperty)
    FString Limits; // 0x50 (Size: 0x10, Type: StrProperty)
    FString Subtitles; // 0x60 (Size: 0x10, Type: StrProperty)
    FString UserContentProtection; // 0x70 (Size: 0x10, Type: StrProperty)
    bool Sharelock; // 0x80 (Size: 0x1, Type: BoolProperty)
    bool AudioOnly; // 0x81 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_82[0x2]; // 0x82 (Size: 0x2, Type: PaddingProperty)
    float AspectRatio; // 0x84 (Size: 0x4, Type: FloatProperty)
    bool PartySync; // 0x88 (Size: 0x1, Type: BoolProperty)
    bool Live; // 0x89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8a[0x6]; // 0x8a (Size: 0x6, Type: PaddingProperty)
    FString DenyHTTPCode; // 0x90 (Size: 0x10, Type: StrProperty)
    int32_t ResponseHTTPCode; // 0xa0 (Size: 0x4, Type: IntProperty)
    bool bTreatCDNSwitchAsFatal; // 0xa4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a5[0x3]; // 0xa5 (Size: 0x3, Type: PaddingProperty)
    FEpicMediaRegionLockExt RegionLockData; // 0xa8 (Size: 0xa8, Type: StructProperty)
    FEpicMediaAudioMetadataExt AudioMetadata; // 0x150 (Size: 0x130, Type: StructProperty)
    bool bQuicksilverEP; // 0x280 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_281[0x7]; // 0x281 (Size: 0x7, Type: PaddingProperty)
    FEpicMediaExtraMetadataExt ExtraMetadata; // 0x288 (Size: 0x68, Type: StructProperty)
    uint8_t RequestType; // 0x2f0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2f1[0x17]; // 0x2f1 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(FEpicMediaMetadataExt) == 0x308, "Size mismatch for FEpicMediaMetadataExt");
static_assert(offsetof(FEpicMediaMetadataExt, Playlists) == 0x0, "Offset mismatch for FEpicMediaMetadataExt::Playlists");
static_assert(offsetof(FEpicMediaMetadataExt, StateStreamPlaylists) == 0x10, "Offset mismatch for FEpicMediaMetadataExt::StateStreamPlaylists");
static_assert(offsetof(FEpicMediaMetadataExt, SelectedPlaylists) == 0x20, "Offset mismatch for FEpicMediaMetadataExt::SelectedPlaylists");
static_assert(offsetof(FEpicMediaMetadataExt, Type) == 0x30, "Offset mismatch for FEpicMediaMetadataExt::Type");
static_assert(offsetof(FEpicMediaMetadataExt, Envelope) == 0x40, "Offset mismatch for FEpicMediaMetadataExt::Envelope");
static_assert(offsetof(FEpicMediaMetadataExt, Limits) == 0x50, "Offset mismatch for FEpicMediaMetadataExt::Limits");
static_assert(offsetof(FEpicMediaMetadataExt, Subtitles) == 0x60, "Offset mismatch for FEpicMediaMetadataExt::Subtitles");
static_assert(offsetof(FEpicMediaMetadataExt, UserContentProtection) == 0x70, "Offset mismatch for FEpicMediaMetadataExt::UserContentProtection");
static_assert(offsetof(FEpicMediaMetadataExt, Sharelock) == 0x80, "Offset mismatch for FEpicMediaMetadataExt::Sharelock");
static_assert(offsetof(FEpicMediaMetadataExt, AudioOnly) == 0x81, "Offset mismatch for FEpicMediaMetadataExt::AudioOnly");
static_assert(offsetof(FEpicMediaMetadataExt, AspectRatio) == 0x84, "Offset mismatch for FEpicMediaMetadataExt::AspectRatio");
static_assert(offsetof(FEpicMediaMetadataExt, PartySync) == 0x88, "Offset mismatch for FEpicMediaMetadataExt::PartySync");
static_assert(offsetof(FEpicMediaMetadataExt, Live) == 0x89, "Offset mismatch for FEpicMediaMetadataExt::Live");
static_assert(offsetof(FEpicMediaMetadataExt, DenyHTTPCode) == 0x90, "Offset mismatch for FEpicMediaMetadataExt::DenyHTTPCode");
static_assert(offsetof(FEpicMediaMetadataExt, ResponseHTTPCode) == 0xa0, "Offset mismatch for FEpicMediaMetadataExt::ResponseHTTPCode");
static_assert(offsetof(FEpicMediaMetadataExt, bTreatCDNSwitchAsFatal) == 0xa4, "Offset mismatch for FEpicMediaMetadataExt::bTreatCDNSwitchAsFatal");
static_assert(offsetof(FEpicMediaMetadataExt, RegionLockData) == 0xa8, "Offset mismatch for FEpicMediaMetadataExt::RegionLockData");
static_assert(offsetof(FEpicMediaMetadataExt, AudioMetadata) == 0x150, "Offset mismatch for FEpicMediaMetadataExt::AudioMetadata");
static_assert(offsetof(FEpicMediaMetadataExt, bQuicksilverEP) == 0x280, "Offset mismatch for FEpicMediaMetadataExt::bQuicksilverEP");
static_assert(offsetof(FEpicMediaMetadataExt, ExtraMetadata) == 0x288, "Offset mismatch for FEpicMediaMetadataExt::ExtraMetadata");
static_assert(offsetof(FEpicMediaMetadataExt, RequestType) == 0x2f0, "Offset mismatch for FEpicMediaMetadataExt::RequestType");

