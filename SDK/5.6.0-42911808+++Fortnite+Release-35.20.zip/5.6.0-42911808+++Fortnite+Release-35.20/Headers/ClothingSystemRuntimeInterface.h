/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClothingSystemRuntimeInterface
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UClothingAssetBase : public UObject
{
public:
    FGuid AssetGuid; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UClothingAssetBase) == 0x38, "Size mismatch for UClothingAssetBase");
static_assert(offsetof(UClothingAssetBase, AssetGuid) == 0x28, "Offset mismatch for UClothingAssetBase::AssetGuid");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UClothConfigBase : public UObject
{
public:
};

static_assert(sizeof(UClothConfigBase) == 0x28, "Size mismatch for UClothConfigBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UClothSharedSimConfigBase : public UObject
{
public:
};

static_assert(sizeof(UClothSharedSimConfigBase) == 0x28, "Size mismatch for UClothSharedSimConfigBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UClothingSimulationFactory : public UObject
{
public:
};

static_assert(sizeof(UClothingSimulationFactory) == 0x28, "Size mismatch for UClothingSimulationFactory");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UClothingInteractor : public UObject
{
public:
};

static_assert(sizeof(UClothingInteractor) == 0x30, "Size mismatch for UClothingInteractor");

// Size: 0x90 (Inherited: 0x28, Single: 0x68)
class UClothingSimulationInteractor : public UObject
{
public:
    TMap<UClothingInteractor*, FName> ClothingInteractors; // 0x28 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_78[0x18]; // 0x78 (Size: 0x18, Type: PaddingProperty)

public:
    void ClothConfigUpdated(); // 0x472ef98 (Index: 0x0, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void DisableGravityOverride(); // 0x31f3198 (Index: 0x1, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void EnableGravityOverride(const FVector InVector); // 0x99c3d80 (Index: 0x2, Flags: RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    UClothingInteractor* GetClothingInteractor(FString& ClothingAssetName) const; // 0x99c3e64 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumCloths() const; // 0x99c4160 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumDynamicParticles() const; // 0x5478fac (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumIterations() const; // 0x99c4174 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumKinematicParticles() const; // 0x99c418c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumSubsteps() const; // 0x99c41a0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSimulationTime() const; // 0x99c41b8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PhysicsAssetUpdated(); // 0x3305bfc (Index: 0xa, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetAnimDriveSpringStiffness(float& InStiffness); // 0x99c41d0 (Index: 0xb, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetMaxNumIterations(int32_t& MaxNumIterations); // 0x99c4300 (Index: 0xc, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetNumIterations(int32_t& NumIterations); // 0x99c442c (Index: 0xd, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetNumSubsteps(int32_t& NumSubSteps); // 0x99c4558 (Index: 0xe, Flags: RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UClothingSimulationInteractor) == 0x90, "Size mismatch for UClothingSimulationInteractor");
static_assert(offsetof(UClothingSimulationInteractor, ClothingInteractors) == 0x28, "Offset mismatch for UClothingSimulationInteractor::ClothingInteractors");

// Size: 0xe0 (Inherited: 0x28, Single: 0xb8)
class UClothPhysicalMeshDataBase_Legacy : public UObject
{
public:
    TArray<FVector3f> Vertices; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3f> Normals; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Indices; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<float> InverseMasses; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothVertBoneData> BoneData; // 0x68 (Size: 0x10, Type: ArrayProperty)
    int32_t NumFixedVerts; // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t MaxBoneWeights; // 0x7c (Size: 0x4, Type: IntProperty)
    TArray<uint32_t> SelfCollisionIndices; // 0x80 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_90[0x50]; // 0x90 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UClothPhysicalMeshDataBase_Legacy) == 0xe0, "Size mismatch for UClothPhysicalMeshDataBase_Legacy");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, Vertices) == 0x28, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::Vertices");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, Normals) == 0x38, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::Normals");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, Indices) == 0x48, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::Indices");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, InverseMasses) == 0x58, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::InverseMasses");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, BoneData) == 0x68, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::BoneData");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, NumFixedVerts) == 0x78, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::NumFixedVerts");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, MaxBoneWeights) == 0x7c, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::MaxBoneWeights");
static_assert(offsetof(UClothPhysicalMeshDataBase_Legacy, SelfCollisionIndices) == 0x80, "Offset mismatch for UClothPhysicalMeshDataBase_Legacy::SelfCollisionIndices");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FClothCollisionPrim_Sphere
{
    int32_t BoneIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    float Radius; // 0x4 (Size: 0x4, Type: FloatProperty)
    FVector LocalPosition; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FClothCollisionPrim_Sphere) == 0x20, "Size mismatch for FClothCollisionPrim_Sphere");
static_assert(offsetof(FClothCollisionPrim_Sphere, BoneIndex) == 0x0, "Offset mismatch for FClothCollisionPrim_Sphere::BoneIndex");
static_assert(offsetof(FClothCollisionPrim_Sphere, Radius) == 0x4, "Offset mismatch for FClothCollisionPrim_Sphere::Radius");
static_assert(offsetof(FClothCollisionPrim_Sphere, LocalPosition) == 0x8, "Offset mismatch for FClothCollisionPrim_Sphere::LocalPosition");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FClothCollisionPrim_SphereConnection
{
    int32_t SphereIndices[0x2]; // 0x0 (Size: 0x8, Type: IntProperty)
};

static_assert(sizeof(FClothCollisionPrim_SphereConnection) == 0x8, "Size mismatch for FClothCollisionPrim_SphereConnection");
static_assert(offsetof(FClothCollisionPrim_SphereConnection, SphereIndices) == 0x0, "Offset mismatch for FClothCollisionPrim_SphereConnection::SphereIndices");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FClothCollisionPrim_ConvexFace
{
    FPlane Plane; // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<int32_t> Indices; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClothCollisionPrim_ConvexFace) == 0x30, "Size mismatch for FClothCollisionPrim_ConvexFace");
static_assert(offsetof(FClothCollisionPrim_ConvexFace, Plane) == 0x0, "Offset mismatch for FClothCollisionPrim_ConvexFace::Plane");
static_assert(offsetof(FClothCollisionPrim_ConvexFace, Indices) == 0x20, "Offset mismatch for FClothCollisionPrim_ConvexFace::Indices");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FClothCollisionPrim_Convex
{
    TArray<FClothCollisionPrim_ConvexFace> Faces; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> SurfacePoints; // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t BoneIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FClothCollisionPrim_Convex) == 0x28, "Size mismatch for FClothCollisionPrim_Convex");
static_assert(offsetof(FClothCollisionPrim_Convex, Faces) == 0x0, "Offset mismatch for FClothCollisionPrim_Convex::Faces");
static_assert(offsetof(FClothCollisionPrim_Convex, SurfacePoints) == 0x10, "Offset mismatch for FClothCollisionPrim_Convex::SurfacePoints");
static_assert(offsetof(FClothCollisionPrim_Convex, BoneIndex) == 0x20, "Offset mismatch for FClothCollisionPrim_Convex::BoneIndex");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FClothCollisionPrim_Box
{
    FVector LocalPosition; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FQuat LocalRotation; // 0x20 (Size: 0x20, Type: StructProperty)
    FVector HalfExtents; // 0x40 (Size: 0x18, Type: StructProperty)
    int32_t BoneIndex; // 0x58 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FClothCollisionPrim_Box) == 0x60, "Size mismatch for FClothCollisionPrim_Box");
static_assert(offsetof(FClothCollisionPrim_Box, LocalPosition) == 0x0, "Offset mismatch for FClothCollisionPrim_Box::LocalPosition");
static_assert(offsetof(FClothCollisionPrim_Box, LocalRotation) == 0x20, "Offset mismatch for FClothCollisionPrim_Box::LocalRotation");
static_assert(offsetof(FClothCollisionPrim_Box, HalfExtents) == 0x40, "Offset mismatch for FClothCollisionPrim_Box::HalfExtents");
static_assert(offsetof(FClothCollisionPrim_Box, BoneIndex) == 0x58, "Offset mismatch for FClothCollisionPrim_Box::BoneIndex");

// Size: 0x4c (Inherited: 0x0, Single: 0x4c)
struct FClothVertBoneData
{
    int32_t NumInfluences; // 0x0 (Size: 0x4, Type: IntProperty)
    uint16_t BoneIndices[0xc]; // 0x4 (Size: 0x18, Type: UInt16Property)
    float BoneWeights[0xc]; // 0x1c (Size: 0x30, Type: FloatProperty)
};

static_assert(sizeof(FClothVertBoneData) == 0x4c, "Size mismatch for FClothVertBoneData");
static_assert(offsetof(FClothVertBoneData, NumInfluences) == 0x0, "Offset mismatch for FClothVertBoneData::NumInfluences");
static_assert(offsetof(FClothVertBoneData, BoneIndices) == 0x4, "Offset mismatch for FClothVertBoneData::BoneIndices");
static_assert(offsetof(FClothVertBoneData, BoneWeights) == 0x1c, "Offset mismatch for FClothVertBoneData::BoneWeights");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FClothCollisionData
{
    TArray<FClothCollisionPrim_Sphere> Spheres; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothCollisionPrim_SphereConnection> SphereConnections; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothCollisionPrim_Convex> Convexes; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothCollisionPrim_Box> Boxes; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClothCollisionData) == 0x40, "Size mismatch for FClothCollisionData");
static_assert(offsetof(FClothCollisionData, Spheres) == 0x0, "Offset mismatch for FClothCollisionData::Spheres");
static_assert(offsetof(FClothCollisionData, SphereConnections) == 0x10, "Offset mismatch for FClothCollisionData::SphereConnections");
static_assert(offsetof(FClothCollisionData, Convexes) == 0x20, "Offset mismatch for FClothCollisionData::Convexes");
static_assert(offsetof(FClothCollisionData, Boxes) == 0x30, "Offset mismatch for FClothCollisionData::Boxes");

