/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNOnlineFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UFNOnlineFrameworkSubsystem : public UGameInstanceSubsystem
{
public:
};

static_assert(sizeof(UFNOnlineFrameworkSubsystem) == 0x40, "Size mismatch for UFNOnlineFrameworkSubsystem");

