/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Building
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteAI.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "NavigationSystem.h"
#include "GameplayAbilities.h"
#include "Niagara.h"

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_BalconyO_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_BalconyO_C) == 0x80, "Size mismatch for UNavLink_BalconyO_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_RoofI_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_M1_RoofI_C) == 0xbd0, "Size mismatch for APBWA_M1_RoofI_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_HalfWallDoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_HalfWallDoorS_C) == 0xd80, "Size mismatch for APBWA_M1_HalfWallDoorS_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_S1_StairT_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_S1_StairT_C) == 0xbd8, "Size mismatch for APBWA_S1_StairT_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_RoofO_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_M1_RoofO_C) == 0xbd0, "Size mismatch for APBWA_M1_RoofO_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_DoorC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_DoorC_C) == 0xd80, "Size mismatch for APBWA_M1_DoorC_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_ArchwayLarge_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_ArchwayLarge_C) == 0xd80, "Size mismatch for APBWA_M1_ArchwayLarge_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_HalfWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_HalfWallHalf_C) == 0xd80, "Size mismatch for APBWA_M1_HalfWallHalf_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_Archway_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_Archway_C) == 0xd80, "Size mismatch for APBWA_M1_Archway_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_HalfWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_HalfWall_C) == 0xd80, "Size mismatch for APBWA_M1_HalfWall_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_BalconyD_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_M1_BalconyD_C) == 0xbd0, "Size mismatch for APBWA_M1_BalconyD_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_DoorSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_DoorSide_C) == 0xd80, "Size mismatch for APBWA_M1_DoorSide_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_DoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_DoorS_C) == 0xd80, "Size mismatch for APBWA_M1_DoorS_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_BalconyO_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_M1_BalconyO_C) == 0xbd0, "Size mismatch for APBWA_M1_BalconyO_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_ArchwayLargeSupport_C) == 0xd80, "Size mismatch for APBWA_M1_ArchwayLargeSupport_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_ArchwayLargeSupport_C) == 0xd80, "Size mismatch for APBWA_W1_ArchwayLargeSupport_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_DoorC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_DoorC_C) == 0xd80, "Size mismatch for APBWA_W1_DoorC_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_HalfWallDoor_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_HalfWallDoor_C) == 0xd80, "Size mismatch for APBWA_BG_HalfWallDoor_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_BalconyS_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_S1_BalconyS_C) == 0xbd0, "Size mismatch for APBWA_S1_BalconyS_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_BalconyS_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_M1_BalconyS_C) == 0xbd0, "Size mismatch for APBWA_M1_BalconyS_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_RoofD_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_M1_RoofD_C) == 0xbd0, "Size mismatch for APBWA_M1_RoofD_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_QuarterWallS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_QuarterWallS_C) == 0xd80, "Size mismatch for APBWA_M1_QuarterWallS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_WindowSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_WindowSide_C) == 0xd80, "Size mismatch for APBWA_M1_WindowSide_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_M1_StairF_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_M1_StairF_C) == 0xbd8, "Size mismatch for APBWA_M1_StairF_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_HalfWallDoor_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_HalfWallDoor_C) == 0xd80, "Size mismatch for APBWA_M1_HalfWallDoor_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_QuarterWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_QuarterWallHalf_C) == 0xd80, "Size mismatch for APBWA_M1_QuarterWallHalf_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_BalconyI_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_M1_BalconyI_C) == 0xbd0, "Size mismatch for APBWA_M1_BalconyI_C");

// Size: 0xbd0 (Inherited: 0x2d80, Single: 0xffffde50)
class APBWA_M1_Pillar_C : public ABuildingPillar
{
public:
};

static_assert(sizeof(APBWA_M1_Pillar_C) == 0xbd0, "Size mismatch for APBWA_M1_Pillar_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_Windows_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_Windows_C) == 0xd80, "Size mismatch for APBWA_M1_Windows_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_M1_StairT_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_M1_StairT_C) == 0xbd8, "Size mismatch for APBWA_M1_StairT_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_RoofWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_RoofWall_C) == 0xd80, "Size mismatch for APBWA_M1_RoofWall_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_RoofS_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_M1_RoofS_C) == 0xbd0, "Size mismatch for APBWA_M1_RoofS_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_M1_StairR_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_M1_StairR_C) == 0xbd8, "Size mismatch for APBWA_M1_StairR_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_Archway_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_Archway_C) == 0xd80, "Size mismatch for APBWA_S1_Archway_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_BalconyI_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_S1_BalconyI_C) == 0xbd0, "Size mismatch for APBWA_S1_BalconyI_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_DoorSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_DoorSide_C) == 0xd80, "Size mismatch for APBWA_W1_DoorSide_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_ArchwayLarge_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_ArchwayLarge_C) == 0xd80, "Size mismatch for APBWA_S1_ArchwayLarge_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_Windows_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_Windows_C) == 0xd80, "Size mismatch for APBWA_S1_Windows_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_RoofO_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_S1_RoofO_C) == 0xbd0, "Size mismatch for APBWA_S1_RoofO_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_BalconyD_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_S1_BalconyD_C) == 0xbd0, "Size mismatch for APBWA_S1_BalconyD_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_RoofWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_RoofWall_C) == 0xd80, "Size mismatch for APBWA_S1_RoofWall_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_RoofD_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_S1_RoofD_C) == 0xbd0, "Size mismatch for APBWA_S1_RoofD_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_HalfWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_HalfWallHalf_C) == 0xd80, "Size mismatch for APBWA_S1_HalfWallHalf_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_HalfWallDoor_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_HalfWallDoor_C) == 0xd80, "Size mismatch for APBWA_S1_HalfWallDoor_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_ArchwayLargeSupport_C) == 0xd80, "Size mismatch for APBWA_S1_ArchwayLargeSupport_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_DoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_DoorS_C) == 0xd80, "Size mismatch for APBWA_S1_DoorS_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_W1_StairT_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_W1_StairT_C) == 0xbd8, "Size mismatch for APBWA_W1_StairT_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_RoofS_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_W1_RoofS_C) == 0xbd0, "Size mismatch for APBWA_W1_RoofS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_ArchwayLargeSupport_C) == 0xd80, "Size mismatch for APBWA_BG_ArchwayLargeSupport_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_WindowSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_WindowSide_C) == 0xd80, "Size mismatch for APBWA_W1_WindowSide_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_Windows_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_Windows_C) == 0xd80, "Size mismatch for APBWA_W1_Windows_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_S1_StairF_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_S1_StairF_C) == 0xbd8, "Size mismatch for APBWA_S1_StairF_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_RoofI_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_S1_RoofI_C) == 0xbd0, "Size mismatch for APBWA_S1_RoofI_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_WindowsSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_WindowsSide_C) == 0xd80, "Size mismatch for APBWA_S1_WindowsSide_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_S1_StairR_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_S1_StairR_C) == 0xbd8, "Size mismatch for APBWA_S1_StairR_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_RoofS_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_S1_RoofS_C) == 0xbd0, "Size mismatch for APBWA_S1_RoofS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_QuarterWallS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_QuarterWallS_C) == 0xd80, "Size mismatch for APBWA_S1_QuarterWallS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_QuarterWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_QuarterWallHalf_C) == 0xd80, "Size mismatch for APBWA_S1_QuarterWallHalf_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_HalfWallS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_HalfWallS_C) == 0xd80, "Size mismatch for APBWA_S1_HalfWallS_C");

// Size: 0xbd0 (Inherited: 0x2d80, Single: 0xffffde50)
class APBWA_S1_Pillar_C : public ABuildingPillar
{
public:
};

static_assert(sizeof(APBWA_S1_Pillar_C) == 0xbd0, "Size mismatch for APBWA_S1_Pillar_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_DoorSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_DoorSide_C) == 0xd80, "Size mismatch for APBWA_S1_DoorSide_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_BalconyO_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_S1_BalconyO_C) == 0xbd0, "Size mismatch for APBWA_S1_BalconyO_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_HalfWallDoorSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_HalfWallDoorSide_C) == 0xd80, "Size mismatch for APBWA_S1_HalfWallDoorSide_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_DoorC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_DoorC_C) == 0xd80, "Size mismatch for APBWA_S1_DoorC_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_BalconyS_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_W1_BalconyS_C) == 0xbd0, "Size mismatch for APBWA_W1_BalconyS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_QuarterWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_QuarterWallHalf_C) == 0xd80, "Size mismatch for APBWA_W1_QuarterWallHalf_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_RoofWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_RoofWall_C) == 0xd80, "Size mismatch for APBWA_W1_RoofWall_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_W1_StairF_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_W1_StairF_C) == 0xbd8, "Size mismatch for APBWA_W1_StairF_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_Archway_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_Archway_C) == 0xd80, "Size mismatch for APBWA_W1_Archway_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_BalconyO_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_W1_BalconyO_C) == 0xbd0, "Size mismatch for APBWA_W1_BalconyO_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_BalconyD_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_W1_BalconyD_C) == 0xbd0, "Size mismatch for APBWA_W1_BalconyD_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_BalconyI_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_W1_BalconyI_C) == 0xbd0, "Size mismatch for APBWA_W1_BalconyI_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_ArchwayLarge_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_ArchwayLarge_C) == 0xd80, "Size mismatch for APBWA_W1_ArchwayLarge_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_HalfWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_HalfWallHalf_C) == 0xd80, "Size mismatch for APBWA_W1_HalfWallHalf_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_HalfWallS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_HalfWallS_C) == 0xd80, "Size mismatch for APBWA_W1_HalfWallS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_HalfWallDoor_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_HalfWallDoor_C) == 0xd80, "Size mismatch for APBWA_W1_HalfWallDoor_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_QuarterWallS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_QuarterWallS_C) == 0xd80, "Size mismatch for APBWA_W1_QuarterWallS_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_W1_StairR_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_W1_StairR_C) == 0xbd8, "Size mismatch for APBWA_W1_StairR_C");

// Size: 0xbd0 (Inherited: 0x2d80, Single: 0xffffde50)
class APBWA_W1_Pillar_C : public ABuildingPillar
{
public:
};

static_assert(sizeof(APBWA_W1_Pillar_C) == 0xbd0, "Size mismatch for APBWA_W1_Pillar_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_RoofI_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_W1_RoofI_C) == 0xbd0, "Size mismatch for APBWA_W1_RoofI_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_RoofD_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_W1_RoofD_C) == 0xbd0, "Size mismatch for APBWA_W1_RoofD_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_RoofO_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_W1_RoofO_C) == 0xbd0, "Size mismatch for APBWA_W1_RoofO_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_RoofO_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_BG_RoofO_C) == 0xbd0, "Size mismatch for APBWA_BG_RoofO_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_Solid_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_Solid_C) == 0xd80, "Size mismatch for APBWA_BG_Solid_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_RoofWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_RoofWall_C) == 0xd80, "Size mismatch for APBWA_BG_RoofWall_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_BG_StairF_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_BG_StairF_C) == 0xbd8, "Size mismatch for APBWA_BG_StairF_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_BG_StairW_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_BG_StairW_C) == 0xbd8, "Size mismatch for APBWA_BG_StairW_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_BG_StairT_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_BG_StairT_C) == 0xbd8, "Size mismatch for APBWA_BG_StairT_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_BG_StairR_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_BG_StairR_C) == 0xbd8, "Size mismatch for APBWA_BG_StairR_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_DoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_DoorS_C) == 0xd80, "Size mismatch for APBWA_W1_DoorS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_HalfWallDoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_HalfWallDoorS_C) == 0xd80, "Size mismatch for APBWA_W1_HalfWallDoorS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_Archway_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_Archway_C) == 0xd80, "Size mismatch for APBWA_BG_Archway_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_BalconyS_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_BG_BalconyS_C) == 0xbd0, "Size mismatch for APBWA_BG_BalconyS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_DoorC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_DoorC_C) == 0xd80, "Size mismatch for APBWA_BG_DoorC_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_BalconyD_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_BG_BalconyD_C) == 0xbd0, "Size mismatch for APBWA_BG_BalconyD_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_ArchwayLarge_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_ArchwayLarge_C) == 0xd80, "Size mismatch for APBWA_BG_ArchwayLarge_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_DoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_DoorS_C) == 0xd80, "Size mismatch for APBWA_BG_DoorS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_DoorSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_DoorSide_C) == 0xd80, "Size mismatch for APBWA_BG_DoorSide_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_HalfWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_HalfWallHalf_C) == 0xd80, "Size mismatch for APBWA_BG_HalfWallHalf_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_Floor_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_BG_Floor_C) == 0xbd0, "Size mismatch for APBWA_BG_Floor_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_QuarterWallHalf_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_QuarterWallHalf_C) == 0xd80, "Size mismatch for APBWA_BG_QuarterWallHalf_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_RoofC_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_BG_RoofC_C) == 0xbd0, "Size mismatch for APBWA_BG_RoofC_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_QuarterWallS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_QuarterWallS_C) == 0xd80, "Size mismatch for APBWA_BG_QuarterWallS_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_RoofI_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_BG_RoofI_C) == 0xbd0, "Size mismatch for APBWA_BG_RoofI_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_HalfWallDoorS_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_HalfWallDoorS_C) == 0xd80, "Size mismatch for APBWA_BG_HalfWallDoorS_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_HalfWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_HalfWall_C) == 0xd80, "Size mismatch for APBWA_BG_HalfWall_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_Brace_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_Brace_C) == 0xd80, "Size mismatch for APBWA_BG_Brace_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_BalconyO_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_BG_BalconyO_C) == 0xbd0, "Size mismatch for APBWA_BG_BalconyO_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_BalconyI_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_BG_BalconyI_C) == 0xbd0, "Size mismatch for APBWA_BG_BalconyI_C");

// Size: 0xf54 (Inherited: 0x4a78, Single: 0xffffc4dc)
class ACreative_Tiered_Chest_C : public ABuildingCustomizableSpawnContainer
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xe78 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* S_Chest_SmokeSheet; // 0xe80 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_Athena_Loot_Chest_Aura; // 0xe88 (Size: 0x8, Type: ObjectProperty)
    UCreativeIslandResourceComponent* CreativeIslandResource; // 0xe90 (Size: 0x8, Type: ObjectProperty)
    UPointLightComponent* TrasureLight; // 0xe98 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* Chest_Ambient_Sound; // 0xea0 (Size: 0x8, Type: ObjectProperty)
    float MobileSelectedTL_LerpInteactoIcon_3B3245644A941BB300D1A3B017FAF4AC; // 0xea8 (Size: 0x4, Type: FloatProperty)
    float MobileSelectedTL_LerpObject_3B3245644A941BB300D1A3B017FAF4AC; // 0xeac (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> MobileSelectedTL__Direction_3B3245644A941BB300D1A3B017FAF4AC; // 0xeb0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_eb1[0x7]; // 0xeb1 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* MobileSelectedTL; // 0xeb8 (Size: 0x8, Type: ObjectProperty)
    float MobileOnInteractTL_LERP_0EDB17994610CCA511D017A7FCB5FD6E; // 0xec0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> MobileOnInteractTL__Direction_0EDB17994610CCA511D017A7FCB5FD6E; // 0xec4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_ec5[0x3]; // 0xec5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* MobileOnInteractTL; // 0xec8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Loot_Effect; // 0xed0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SpecialChestOpenSound; // 0xed8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> MIDs; // 0xee0 (Size: 0x10, Type: ArrayProperty)
    double MobileWiggleAmount; // 0xef0 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle ChimeTimer; // 0xef8 (Size: 0x8, Type: StructProperty)
    double ChestChimeVisualUpdate; // 0xf00 (Size: 0x8, Type: DoubleProperty)
    UMaterialInterface* MobileInteractionMaterial; // 0xf08 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* MobileInteractIcon; // 0xf10 (Size: 0x8, Type: ObjectProperty)
    FVector MobileInteractIconLocation; // 0xf18 (Size: 0x18, Type: StructProperty)
    FVector MobileInteractIconScale; // 0xf30 (Size: 0x18, Type: StructProperty)
    FName ResourceLightTag; // 0xf48 (Size: 0x4, Type: NameProperty)
    FName ResourceVFXTag; // 0xf4c (Size: 0x4, Type: NameProperty)
    FName ResourceAudioTag; // 0xf50 (Size: 0x4, Type: NameProperty)

public:
    void CleanupWiggleMIDs(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetLightVisibility(bool& Visible); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetVisibleMobileInteractIcon(bool& Visible); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void OnLoot(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void OnSetSearched(); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    virtual void OnSetCustomDepthStencilValue(const TArray<UPrimitiveComponent*> PrimComponents, bool& bUseCustomDepth, int32_t& StencilValue, bool& bOutConsume); // 0x288a61c (Index: 0xa, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual bool ShouldDie(float& Damage, AController*& EventInstigator, AActor*& DamageCauser, bool& bIsTest, const FGameplayEffectContextHandle EffectContext); // 0x288a61c (Index: 0xd, Flags: BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void On_Free_Resources(UCreativeIslandResourceManagerComponent*& Resource_Manager); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void CreateMobileMIDs(); // 0x288a61c (Index: 0x12, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void DisableBacchusHighlight(); // 0x288a61c (Index: 0x13, Flags: Event|Public|BlueprintEvent)
    virtual void EnableBacchusHighlight(); // 0x288a61c (Index: 0x14, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveDestroyed(); // 0x288a61c (Index: 0x15, Flags: Event|Public|BlueprintEvent)
    void On_Request_Resources(UCreativeIslandResourceManagerComponent*& Resource_Manager); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnBeginSearch(); // 0x288a61c (Index: 0x17, Flags: Event|Public|BlueprintEvent)
    void GetMaxAudibleDistance(double& Max_Distance); // 0x288a61c (Index: 0x19, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual bool BlueprintCanInteract(AFortPawn*& const InteractingPawn, TEnumAsByte<EInteractionBeingAttempted>& const InteractionBeingAttempted, TEnumAsByte<TInteractionType>& const InteractionType) const; // 0x288a61c (Index: 0x1d, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void PreDestroy(); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ACreative_Tiered_Chest_C) == 0xf54, "Size mismatch for ACreative_Tiered_Chest_C");
static_assert(offsetof(ACreative_Tiered_Chest_C, UberGraphFrame) == 0xe78, "Offset mismatch for ACreative_Tiered_Chest_C::UberGraphFrame");
static_assert(offsetof(ACreative_Tiered_Chest_C, S_Chest_SmokeSheet) == 0xe80, "Offset mismatch for ACreative_Tiered_Chest_C::S_Chest_SmokeSheet");
static_assert(offsetof(ACreative_Tiered_Chest_C, NS_Athena_Loot_Chest_Aura) == 0xe88, "Offset mismatch for ACreative_Tiered_Chest_C::NS_Athena_Loot_Chest_Aura");
static_assert(offsetof(ACreative_Tiered_Chest_C, CreativeIslandResource) == 0xe90, "Offset mismatch for ACreative_Tiered_Chest_C::CreativeIslandResource");
static_assert(offsetof(ACreative_Tiered_Chest_C, TrasureLight) == 0xe98, "Offset mismatch for ACreative_Tiered_Chest_C::TrasureLight");
static_assert(offsetof(ACreative_Tiered_Chest_C, Chest_Ambient_Sound) == 0xea0, "Offset mismatch for ACreative_Tiered_Chest_C::Chest_Ambient_Sound");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileSelectedTL_LerpInteactoIcon_3B3245644A941BB300D1A3B017FAF4AC) == 0xea8, "Offset mismatch for ACreative_Tiered_Chest_C::MobileSelectedTL_LerpInteactoIcon_3B3245644A941BB300D1A3B017FAF4AC");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileSelectedTL_LerpObject_3B3245644A941BB300D1A3B017FAF4AC) == 0xeac, "Offset mismatch for ACreative_Tiered_Chest_C::MobileSelectedTL_LerpObject_3B3245644A941BB300D1A3B017FAF4AC");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileSelectedTL__Direction_3B3245644A941BB300D1A3B017FAF4AC) == 0xeb0, "Offset mismatch for ACreative_Tiered_Chest_C::MobileSelectedTL__Direction_3B3245644A941BB300D1A3B017FAF4AC");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileSelectedTL) == 0xeb8, "Offset mismatch for ACreative_Tiered_Chest_C::MobileSelectedTL");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileOnInteractTL_LERP_0EDB17994610CCA511D017A7FCB5FD6E) == 0xec0, "Offset mismatch for ACreative_Tiered_Chest_C::MobileOnInteractTL_LERP_0EDB17994610CCA511D017A7FCB5FD6E");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileOnInteractTL__Direction_0EDB17994610CCA511D017A7FCB5FD6E) == 0xec4, "Offset mismatch for ACreative_Tiered_Chest_C::MobileOnInteractTL__Direction_0EDB17994610CCA511D017A7FCB5FD6E");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileOnInteractTL) == 0xec8, "Offset mismatch for ACreative_Tiered_Chest_C::MobileOnInteractTL");
static_assert(offsetof(ACreative_Tiered_Chest_C, Loot_Effect) == 0xed0, "Offset mismatch for ACreative_Tiered_Chest_C::Loot_Effect");
static_assert(offsetof(ACreative_Tiered_Chest_C, SpecialChestOpenSound) == 0xed8, "Offset mismatch for ACreative_Tiered_Chest_C::SpecialChestOpenSound");
static_assert(offsetof(ACreative_Tiered_Chest_C, MIDs) == 0xee0, "Offset mismatch for ACreative_Tiered_Chest_C::MIDs");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileWiggleAmount) == 0xef0, "Offset mismatch for ACreative_Tiered_Chest_C::MobileWiggleAmount");
static_assert(offsetof(ACreative_Tiered_Chest_C, ChimeTimer) == 0xef8, "Offset mismatch for ACreative_Tiered_Chest_C::ChimeTimer");
static_assert(offsetof(ACreative_Tiered_Chest_C, ChestChimeVisualUpdate) == 0xf00, "Offset mismatch for ACreative_Tiered_Chest_C::ChestChimeVisualUpdate");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileInteractionMaterial) == 0xf08, "Offset mismatch for ACreative_Tiered_Chest_C::MobileInteractionMaterial");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileInteractIcon) == 0xf10, "Offset mismatch for ACreative_Tiered_Chest_C::MobileInteractIcon");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileInteractIconLocation) == 0xf18, "Offset mismatch for ACreative_Tiered_Chest_C::MobileInteractIconLocation");
static_assert(offsetof(ACreative_Tiered_Chest_C, MobileInteractIconScale) == 0xf30, "Offset mismatch for ACreative_Tiered_Chest_C::MobileInteractIconScale");
static_assert(offsetof(ACreative_Tiered_Chest_C, ResourceLightTag) == 0xf48, "Offset mismatch for ACreative_Tiered_Chest_C::ResourceLightTag");
static_assert(offsetof(ACreative_Tiered_Chest_C, ResourceVFXTag) == 0xf4c, "Offset mismatch for ACreative_Tiered_Chest_C::ResourceVFXTag");
static_assert(offsetof(ACreative_Tiered_Chest_C, ResourceAudioTag) == 0xf50, "Offset mismatch for ACreative_Tiered_Chest_C::ResourceAudioTag");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_StairR_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_StairR_C) == 0x80, "Size mismatch for UNavLink_StairR_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_BalconyS_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_BalconyS_C) == 0x80, "Size mismatch for UNavLink_BalconyS_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_RoofC_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_M1_RoofC_C) == 0xbd0, "Size mismatch for APBWA_M1_RoofC_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_M1_StairW_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_M1_StairW_C) == 0xbd8, "Size mismatch for APBWA_M1_StairW_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_Solid_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_Solid_C) == 0xd80, "Size mismatch for APBWA_M1_Solid_C");

// Size: 0xc8 (Inherited: 0x1b0, Single: 0xffffff18)
class UDoorMetaObstacle_C : public UNavAreaMeta_SwitchByAgent
{
public:
};

static_assert(sizeof(UDoorMetaObstacle_C) == 0xc8, "Size mismatch for UDoorMetaObstacle_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_Windows_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_Windows_C) == 0xd80, "Size mismatch for APBWA_BG_Windows_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_Brace_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_Brace_C) == 0xd80, "Size mismatch for APBWA_W1_Brace_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_W1_StairW_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_W1_StairW_C) == 0xbd8, "Size mismatch for APBWA_W1_StairW_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_WindowC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_WindowC_C) == 0xd80, "Size mismatch for APBWA_W1_WindowC_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_Floor_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_W1_Floor_C) == 0xbd0, "Size mismatch for APBWA_W1_Floor_C");

// Size: 0x218 (Inherited: 0x2f8, Single: 0xffffff20)
class UDoorSoundIndicatorComponent_C : public UFortSoundIndicatorComponent
{
public:

public:
    virtual bool ShouldShowSoundIndicator(AFortPlayerController*& PlayerController) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual TArray<TEnumAsByte<EFortTeamAffiliation>> GetAffiliationsToShowFor() const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UDoorSoundIndicatorComponent_C) == 0x218, "Size mismatch for UDoorSoundIndicatorComponent_C");

// Size: 0x58 (Inherited: 0x198, Single: 0xfffffec0)
class UFortMetaNavWallAreaDef_C : public UFortMetaNavArea_Wall
{
public:
};

static_assert(sizeof(UFortMetaNavWallAreaDef_C) == 0x58, "Size mismatch for UFortMetaNavWallAreaDef_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_BalconyI_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_BalconyI_C) == 0x80, "Size mismatch for UNavLink_BalconyI_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_Floor_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_S1_Floor_C) == 0xbd0, "Size mismatch for APBWA_S1_Floor_C");

// Size: 0xda8 (Inherited: 0x2360, Single: 0xffffea48)
class APBWA_S1_Solid_C : public ABuildingWall
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xd80 (Size: 0x8, Type: StructProperty)
    int32_t GnomeWallChance; // 0xd88 (Size: 0x4, Type: IntProperty)
    int32_t GnomeWallMax; // 0xd8c (Size: 0x4, Type: IntProperty)
    bool Gnomed; // 0xd90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d91[0x7]; // 0xd91 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceConstant* GnomeMaterial; // 0xd98 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* GnomeWall; // 0xda0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(APBWA_S1_Solid_C) == 0xda8, "Size mismatch for APBWA_S1_Solid_C");
static_assert(offsetof(APBWA_S1_Solid_C, UberGraphFrame) == 0xd80, "Offset mismatch for APBWA_S1_Solid_C::UberGraphFrame");
static_assert(offsetof(APBWA_S1_Solid_C, GnomeWallChance) == 0xd88, "Offset mismatch for APBWA_S1_Solid_C::GnomeWallChance");
static_assert(offsetof(APBWA_S1_Solid_C, GnomeWallMax) == 0xd8c, "Offset mismatch for APBWA_S1_Solid_C::GnomeWallMax");
static_assert(offsetof(APBWA_S1_Solid_C, Gnomed) == 0xd90, "Offset mismatch for APBWA_S1_Solid_C::Gnomed");
static_assert(offsetof(APBWA_S1_Solid_C, GnomeMaterial) == 0xd98, "Offset mismatch for APBWA_S1_Solid_C::GnomeMaterial");
static_assert(offsetof(APBWA_S1_Solid_C, GnomeWall) == 0xda0, "Offset mismatch for APBWA_S1_Solid_C::GnomeWall");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_StairT_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_StairT_C) == 0x80, "Size mismatch for UNavLink_StairT_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_WindowC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_WindowC_C) == 0xd80, "Size mismatch for APBWA_BG_WindowC_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_RoofD_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_BG_RoofD_C) == 0xbd0, "Size mismatch for APBWA_BG_RoofD_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_StairF_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_StairF_C) == 0x80, "Size mismatch for UNavLink_StairF_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_Floor_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_Floor_C) == 0x80, "Size mismatch for UNavLink_Floor_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_RoofC_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_RoofC_C) == 0x80, "Size mismatch for UNavLink_RoofC_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_FloorI_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_FloorI_C) == 0x80, "Size mismatch for UNavLink_FloorI_C");

// Size: 0x80 (Inherited: 0xf8, Single: 0xffffff88)
class UNavLink_FloorS_C : public UFortNavLinkDefinition
{
public:
};

static_assert(sizeof(UNavLink_FloorS_C) == 0x80, "Size mismatch for UNavLink_FloorS_C");

// Size: 0x58 (Inherited: 0x140, Single: 0xffffff18)
class UFortMetaNavAreaDef_C : public UFortMetaNavArea
{
public:
};

static_assert(sizeof(UFortMetaNavAreaDef_C) == 0x58, "Size mismatch for UFortMetaNavAreaDef_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_M1_Floor_C : public ABuildingFloor
{
public:
};

static_assert(sizeof(APBWA_M1_Floor_C) == 0xbd0, "Size mismatch for APBWA_M1_Floor_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_Brace_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_Brace_C) == 0xd80, "Size mismatch for APBWA_M1_Brace_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_WindowsC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_WindowsC_C) == 0xd80, "Size mismatch for APBWA_S1_WindowsC_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_S1_StairW_C : public ABuildingStairs
{
public:
};

static_assert(sizeof(APBWA_S1_StairW_C) == 0xbd8, "Size mismatch for APBWA_S1_StairW_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_S1_RoofC_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_S1_RoofC_C) == 0xbd0, "Size mismatch for APBWA_S1_RoofC_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_S1_Brace_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_S1_Brace_C) == 0xd80, "Size mismatch for APBWA_S1_Brace_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_W1_RoofC_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_W1_RoofC_C) == 0xbd0, "Size mismatch for APBWA_W1_RoofC_C");

// Size: 0xbd0 (Inherited: 0x21b0, Single: 0xffffea20)
class APBWA_BG_RoofS_C : public ABuildingRoof
{
public:
};

static_assert(sizeof(APBWA_BG_RoofS_C) == 0xbd0, "Size mismatch for APBWA_BG_RoofS_C");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDayPhaseFloats
{
    float Morning_2_DA7D290F4DA80AC0D79B888F8B1E63AF; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Day_6_7AC9422D4E5DA1F7855ECF8DF66BAFB1; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Evening_7_A7E95DF64346D1824EB55E8083A4525F; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Night_8_BD65E285445A3ED05CA26694CF4E873E; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDayPhaseFloats) == 0x10, "Size mismatch for FDayPhaseFloats");
static_assert(offsetof(FDayPhaseFloats, Morning_2_DA7D290F4DA80AC0D79B888F8B1E63AF) == 0x0, "Offset mismatch for FDayPhaseFloats::Morning_2_DA7D290F4DA80AC0D79B888F8B1E63AF");
static_assert(offsetof(FDayPhaseFloats, Day_6_7AC9422D4E5DA1F7855ECF8DF66BAFB1) == 0x4, "Offset mismatch for FDayPhaseFloats::Day_6_7AC9422D4E5DA1F7855ECF8DF66BAFB1");
static_assert(offsetof(FDayPhaseFloats, Evening_7_A7E95DF64346D1824EB55E8083A4525F) == 0x8, "Offset mismatch for FDayPhaseFloats::Evening_7_A7E95DF64346D1824EB55E8083A4525F");
static_assert(offsetof(FDayPhaseFloats, Night_8_BD65E285445A3ED05CA26694CF4E873E) == 0xc, "Offset mismatch for FDayPhaseFloats::Night_8_BD65E285445A3ED05CA26694CF4E873E");

// Size: 0xd98 (Inherited: 0x2360, Single: 0xffffea38)
class APBW_BP_Parent_C : public ABuildingWall
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xd80 (Size: 0x8, Type: StructProperty)
    TArray<UStaticMesh*> StaticMeshAlternateArray; // 0xd88 (Size: 0x10, Type: ArrayProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(APBW_BP_Parent_C) == 0xd98, "Size mismatch for APBW_BP_Parent_C");
static_assert(offsetof(APBW_BP_Parent_C, UberGraphFrame) == 0xd80, "Offset mismatch for APBW_BP_Parent_C::UberGraphFrame");
static_assert(offsetof(APBW_BP_Parent_C, StaticMeshAlternateArray) == 0xd88, "Offset mismatch for APBW_BP_Parent_C::StaticMeshAlternateArray");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_BG_WindowSide_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_BG_WindowSide_C) == 0xd80, "Size mismatch for APBWA_BG_WindowSide_C");

// Size: 0xbd8 (Inherited: 0x2d88, Single: 0xffffde50)
class APBWA_W1_StairSpiral_C : public ABuildingStairs
{
public:

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(APBWA_W1_StairSpiral_C) == 0xbd8, "Size mismatch for APBWA_W1_StairSpiral_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class AParent_BuildingWall_C : public ABuildingWall
{
public:
};

static_assert(sizeof(AParent_BuildingWall_C) == 0xd80, "Size mismatch for AParent_BuildingWall_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_M1_WindowC_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_M1_WindowC_C) == 0xd80, "Size mismatch for APBWA_M1_WindowC_C");

// Size: 0xd80 (Inherited: 0x2360, Single: 0xffffea20)
class APBWA_W1_Solid_C : public ABuildingWall
{
public:
};

static_assert(sizeof(APBWA_W1_Solid_C) == 0xd80, "Size mismatch for APBWA_W1_Solid_C");

