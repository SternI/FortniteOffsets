/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CompeteUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "ModelViewViewModel.h"
#include "Engine.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "EpicCMSUIFramework.h"

// Size: 0xc8 (Inherited: 0x28, Single: 0xa0)
class UFortCompeteGameUserSettings : public UObject
{
public:
    uint8_t Pad_28[0x80]; // 0x28 (Size: 0x80, Type: PaddingProperty)
    TArray<FFortEventBookmarks> SerializedEventBookmarks; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)

public:
    void AddBookmark(FString& EventId, FString& EventWindowId, FDateTime& const EndTime, bool& bSkipSave); // 0x110a6bdc (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool IsEventWindowBookmarked(FString& EventId, FString& EventWindowId) const; // 0x110a9868 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void LoadSettings(bool& bForceReload); // 0x110aa6d0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveBookmark(FString& EventId, FString& EventWindowId, bool& bSkipSave); // 0x110aa9d8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SaveSettings(bool& bForceSave); // 0x110ab01c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortCompeteGameUserSettings) == 0xc8, "Size mismatch for UFortCompeteGameUserSettings");
static_assert(offsetof(UFortCompeteGameUserSettings, SerializedEventBookmarks) == 0xa8, "Offset mismatch for UFortCompeteGameUserSettings::SerializedEventBookmarks");

// Size: 0x90 (Inherited: 0x90, Single: 0x0)
class UFortPoblanoTournamentsCarouselVM : public UMVVMViewModelBase
{
public:
    FTournamentDetailsScreenParams TournamentDetailsScreenParams; // 0x68 (Size: 0x28, Type: StructProperty)

public:
    void SetTournamentDetailsScreenParams(const FTournamentDetailsScreenParams InTournamentDetailsScreenParams); // 0x110ad480 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortPoblanoTournamentsCarouselVM) == 0x90, "Size mismatch for UFortPoblanoTournamentsCarouselVM");
static_assert(offsetof(UFortPoblanoTournamentsCarouselVM, TournamentDetailsScreenParams) == 0x68, "Offset mismatch for UFortPoblanoTournamentsCarouselVM::TournamentDetailsScreenParams");

// Size: 0x90 (Inherited: 0x90, Single: 0x0)
class UFortTournamentBackgroundVM : public UMVVMViewModelBase
{
public:
    UTexture2D* TournamentTexture; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FLinearColor BackgroundLeftColor; // 0x70 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundRightColor; // 0x80 (Size: 0x10, Type: StructProperty)

public:
    void SetupViewModel(EFortTournamentBackgroundImageType& InType); // 0x110ae298 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentBackgroundVM) == 0x90, "Size mismatch for UFortTournamentBackgroundVM");
static_assert(offsetof(UFortTournamentBackgroundVM, TournamentTexture) == 0x68, "Offset mismatch for UFortTournamentBackgroundVM::TournamentTexture");
static_assert(offsetof(UFortTournamentBackgroundVM, BackgroundLeftColor) == 0x70, "Offset mismatch for UFortTournamentBackgroundVM::BackgroundLeftColor");
static_assert(offsetof(UFortTournamentBackgroundVM, BackgroundRightColor) == 0x80, "Offset mismatch for UFortTournamentBackgroundVM::BackgroundRightColor");

// Size: 0xa0 (Inherited: 0x90, Single: 0x10)
class UFortTournamentBookmarksVM : public UMVVMViewModelBase
{
public:
    bool bIsCurrentIslandRanked; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
    TArray<FFortUpcomingTournamentData> UpcomingTournaments; // 0x70 (Size: 0x10, Type: ArrayProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0x80 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_88[0x18]; // 0x88 (Size: 0x18, Type: PaddingProperty)

public:
    FTimespan GetRemainingTimeToStart(const FFortUpcomingTournamentData UpcomingTournament) const; // 0x110a8238 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<FFortUpcomingTournamentData> GetUpcomingTournaments() const; // 0x110a8c8c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GoToLobbyWithTournament(const FFortUpcomingTournamentData UpcomingTournament); // 0x110a8ca8 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void InitializeVM(); // 0x110a8f84 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    bool IsUpcomingTournamentLive(const FFortUpcomingTournamentData UpcomingTournament) const; // 0x110aa46c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void RemoveEndedEntries(); // 0x110aafa4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentBookmarksVM) == 0xa0, "Size mismatch for UFortTournamentBookmarksVM");
static_assert(offsetof(UFortTournamentBookmarksVM, bIsCurrentIslandRanked) == 0x68, "Offset mismatch for UFortTournamentBookmarksVM::bIsCurrentIslandRanked");
static_assert(offsetof(UFortTournamentBookmarksVM, UpcomingTournaments) == 0x70, "Offset mismatch for UFortTournamentBookmarksVM::UpcomingTournaments");
static_assert(offsetof(UFortTournamentBookmarksVM, CompeteUIManager) == 0x80, "Offset mismatch for UFortTournamentBookmarksVM::CompeteUIManager");

// Size: 0xa8 (Inherited: 0x90, Single: 0x18)
class UFortTournamentHeaderVM : public UMVVMViewModelBase
{
public:
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
    FText TournamentName; // 0x70 (Size: 0x10, Type: TextProperty)
    FText WindowRoundText; // 0x80 (Size: 0x10, Type: TextProperty)
    FText WindowTimeText; // 0x90 (Size: 0x10, Type: TextProperty)
    uint8_t ExperienceType; // 0xa0 (Size: 0x1, Type: EnumProperty)
    uint8_t MatchType; // 0xa1 (Size: 0x1, Type: EnumProperty)
    uint8_t TournamentType; // 0xa2 (Size: 0x1, Type: EnumProperty)
    uint8_t GameType; // 0xa3 (Size: 0x1, Type: EnumProperty)
    bool bIsWindowLive; // 0xa4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a5[0x3]; // 0xa5 (Size: 0x3, Type: PaddingProperty)

public:
    void SetupViewModel(); // 0x110ae3c4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateTournamentWindow(); // 0x110af268 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentHeaderVM) == 0xa8, "Size mismatch for UFortTournamentHeaderVM");
static_assert(offsetof(UFortTournamentHeaderVM, TournamentName) == 0x70, "Offset mismatch for UFortTournamentHeaderVM::TournamentName");
static_assert(offsetof(UFortTournamentHeaderVM, WindowRoundText) == 0x80, "Offset mismatch for UFortTournamentHeaderVM::WindowRoundText");
static_assert(offsetof(UFortTournamentHeaderVM, WindowTimeText) == 0x90, "Offset mismatch for UFortTournamentHeaderVM::WindowTimeText");
static_assert(offsetof(UFortTournamentHeaderVM, ExperienceType) == 0xa0, "Offset mismatch for UFortTournamentHeaderVM::ExperienceType");
static_assert(offsetof(UFortTournamentHeaderVM, MatchType) == 0xa1, "Offset mismatch for UFortTournamentHeaderVM::MatchType");
static_assert(offsetof(UFortTournamentHeaderVM, TournamentType) == 0xa2, "Offset mismatch for UFortTournamentHeaderVM::TournamentType");
static_assert(offsetof(UFortTournamentHeaderVM, GameType) == 0xa3, "Offset mismatch for UFortTournamentHeaderVM::GameType");
static_assert(offsetof(UFortTournamentHeaderVM, bIsWindowLive) == 0xa4, "Offset mismatch for UFortTournamentHeaderVM::bIsWindowLive");

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UFortTournamentPlayerProfileVM : public UMVVMViewModelBase
{
public:
    FString AccountId; // 0x68 (Size: 0x10, Type: StrProperty)
    FString DisplayName; // 0x78 (Size: 0x10, Type: StrProperty)
    FString FlagName; // 0x88 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UFortTournamentPlayerProfileVM) == 0x98, "Size mismatch for UFortTournamentPlayerProfileVM");
static_assert(offsetof(UFortTournamentPlayerProfileVM, AccountId) == 0x68, "Offset mismatch for UFortTournamentPlayerProfileVM::AccountId");
static_assert(offsetof(UFortTournamentPlayerProfileVM, DisplayName) == 0x78, "Offset mismatch for UFortTournamentPlayerProfileVM::DisplayName");
static_assert(offsetof(UFortTournamentPlayerProfileVM, FlagName) == 0x88, "Offset mismatch for UFortTournamentPlayerProfileVM::FlagName");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UFortTournamentRewardItemVM : public UMVVMViewModelBase
{
public:
    UFortItemVM* ItemVM; // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bIsGreyedOut; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)

public:
    void SetbIsGreyedOut(bool& const bInIsGreyedOut); // 0x110ae158 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetItemVM(UFortItemVM*& const InItemVM); // 0x110ad074 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentRewardItemVM) == 0x78, "Size mismatch for UFortTournamentRewardItemVM");
static_assert(offsetof(UFortTournamentRewardItemVM, ItemVM) == 0x68, "Offset mismatch for UFortTournamentRewardItemVM::ItemVM");
static_assert(offsetof(UFortTournamentRewardItemVM, bIsGreyedOut) == 0x70, "Offset mismatch for UFortTournamentRewardItemVM::bIsGreyedOut");

// Size: 0x170 (Inherited: 0x90, Single: 0xe0)
class UFortTournamentViewVM : public UMVVMViewModelBase
{
public:
    UFortTournamentRequirementsModalVM* EligibilityRequirementsModalVM; // 0x68 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentWatchLiveVM* WatchLiveVM; // 0x70 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentHeaderVM* TournamentHeaderVM; // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_80[0x8]; // 0x80 (Size: 0x8, Type: PaddingProperty)
    FText TournamentDescription; // 0x88 (Size: 0x10, Type: TextProperty)
    FText RegionName; // 0x98 (Size: 0x10, Type: TextProperty)
    TArray<FFortShowdownScoringRuleInfo> ScoringRules; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortEventWindowsListInfo> EventWindowsList; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FTournamentLeaderboardPayoutTableData> Payouts; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FTournamentPayoutThresholdData HighestThresholdData; // 0xd8 (Size: 0x60, Type: StructProperty)
    bool bIsPlayerEligibleForWindow; // 0x138 (Size: 0x1, Type: BoolProperty)
    bool bPlayerMeetsRankRequirement; // 0x139 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13a[0x2]; // 0x13a (Size: 0x2, Type: PaddingProperty)
    int32_t MinRankLevelRequirement; // 0x13c (Size: 0x4, Type: IntProperty)
    bool bIsWindowLive; // 0x140 (Size: 0x1, Type: BoolProperty)
    bool bIsLeaderboardAvailable; // 0x141 (Size: 0x1, Type: BoolProperty)
    bool bIsCurrentWindowBookmarked; // 0x142 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_143[0x2d]; // 0x143 (Size: 0x2d, Type: PaddingProperty)

public:
    bool AreAllWindowsBookmarked() const; // 0x110a71f8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GoToLobbyWithTournament(bool& const bSwitchProfileRegion); // 0x110a8d88 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool IsPlayNowEnabled() const; // 0x110a9e4c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTournamentWindowEnded() const; // 0x110aa3d4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAllWindowsBookmark(bool& bValue); // 0x110ac680 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurrentWindowBookmark(bool& bValue); // 0x110acb34 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetupViewModel(); // 0x110ae3d8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateTournamentWindow(); // 0x110af27c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentViewVM) == 0x170, "Size mismatch for UFortTournamentViewVM");
static_assert(offsetof(UFortTournamentViewVM, EligibilityRequirementsModalVM) == 0x68, "Offset mismatch for UFortTournamentViewVM::EligibilityRequirementsModalVM");
static_assert(offsetof(UFortTournamentViewVM, WatchLiveVM) == 0x70, "Offset mismatch for UFortTournamentViewVM::WatchLiveVM");
static_assert(offsetof(UFortTournamentViewVM, TournamentHeaderVM) == 0x78, "Offset mismatch for UFortTournamentViewVM::TournamentHeaderVM");
static_assert(offsetof(UFortTournamentViewVM, TournamentDescription) == 0x88, "Offset mismatch for UFortTournamentViewVM::TournamentDescription");
static_assert(offsetof(UFortTournamentViewVM, RegionName) == 0x98, "Offset mismatch for UFortTournamentViewVM::RegionName");
static_assert(offsetof(UFortTournamentViewVM, ScoringRules) == 0xa8, "Offset mismatch for UFortTournamentViewVM::ScoringRules");
static_assert(offsetof(UFortTournamentViewVM, EventWindowsList) == 0xb8, "Offset mismatch for UFortTournamentViewVM::EventWindowsList");
static_assert(offsetof(UFortTournamentViewVM, Payouts) == 0xc8, "Offset mismatch for UFortTournamentViewVM::Payouts");
static_assert(offsetof(UFortTournamentViewVM, HighestThresholdData) == 0xd8, "Offset mismatch for UFortTournamentViewVM::HighestThresholdData");
static_assert(offsetof(UFortTournamentViewVM, bIsPlayerEligibleForWindow) == 0x138, "Offset mismatch for UFortTournamentViewVM::bIsPlayerEligibleForWindow");
static_assert(offsetof(UFortTournamentViewVM, bPlayerMeetsRankRequirement) == 0x139, "Offset mismatch for UFortTournamentViewVM::bPlayerMeetsRankRequirement");
static_assert(offsetof(UFortTournamentViewVM, MinRankLevelRequirement) == 0x13c, "Offset mismatch for UFortTournamentViewVM::MinRankLevelRequirement");
static_assert(offsetof(UFortTournamentViewVM, bIsWindowLive) == 0x140, "Offset mismatch for UFortTournamentViewVM::bIsWindowLive");
static_assert(offsetof(UFortTournamentViewVM, bIsLeaderboardAvailable) == 0x141, "Offset mismatch for UFortTournamentViewVM::bIsLeaderboardAvailable");
static_assert(offsetof(UFortTournamentViewVM, bIsCurrentWindowBookmarked) == 0x142, "Offset mismatch for UFortTournamentViewVM::bIsCurrentWindowBookmarked");

// Size: 0x6c0 (Inherited: 0xb8, Single: 0x608)
class UFortCompeteUIManager : public UEngineSubsystem
{
public:
    uint8_t Pad_30[0x38]; // 0x30 (Size: 0x38, Type: PaddingProperty)
    uint8_t OnSetTournamentLeaderboardScreenSelectedEntry[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TMap<FFortCompeteFrontendNotificationData, UFortUINotification*> FrontendNotificationDataMap; // 0x78 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_c8[0x48]; // 0xc8 (Size: 0x48, Type: PaddingProperty)
    UFortPoblanoTournamentsCalendarFilterVM* CalendarFilterVM; // 0x110 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentBookmarksVM* BookmarksVM; // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFortCompeteGameUserSettings* CompeteGameUserSettings; // 0x120 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_128[0x8]; // 0x128 (Size: 0x8, Type: PaddingProperty)
    UFortGameInstance* GameInstance; // 0x130 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentManager* TM; // 0x138 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_140[0x438]; // 0x140 (Size: 0x438, Type: PaddingProperty)
    TArray<UFortTournamentLeaderboardEntryData*> LeaderboardEntries; // 0x578 (Size: 0x10, Type: ArrayProperty)
    UFortTournamentLeaderboardEntryData* LeaderboardLocalPlayerEntry; // 0x588 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentLeaderboardEntryData* LeaderboardScreenSelectedEntry; // 0x590 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr LeaderboardClass; // 0x598 (Size: 0x20, Type: SoftClassProperty)
    TMap<UFortTournamentPlayerProfileVM*, FString> PlayersProfiles; // 0x5b8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_608[0x90]; // 0x608 (Size: 0x90, Type: PaddingProperty)
    TArray<UFortTournamentWatchLiveEntryVM*> LiveGames; // 0x698 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_6a8[0x10]; // 0x6a8 (Size: 0x10, Type: PaddingProperty)
    bool bShowDebugInfo; // 0x6b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6b9[0x7]; // 0x6b9 (Size: 0x7, Type: PaddingProperty)

public:
    bool CanWatchLiveGames() const; // 0x110a7378 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool CheckEventWillChangeTheProfileRegion() const; // 0x110a73e8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ClearFrontendNotificationData(UFortUINotification*& Notification); // 0x110a740c (Index: 0x2, Flags: Final|Native|Public)
    static FString ConvertRegionTypeToId(ERegionType& const InRegionType); // 0x110a754c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    UFortTournamentBookmarksVM* GetBookmarksVM() const; // 0xa064f94 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetCachedTournamentId() const; // 0xd42be7c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetCanResetCalendarFilterVM() const; // 0x110a7ba4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetCurrentProfileRegionName() const; // 0x110a7ca8 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetFrontendNotificationTournamentData(UFortUINotification*& Notification, FFortCompeteFrontendNotificationData& OutData); // 0x110a7ddc (Index: 0x8, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    int32_t GetMaxLeaderboardEntriesPerPage() const; // 0x110a8010 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortTournamentLeaderboardEntryData* GetTournamentLeaderboardScreenSelectedEntry(); // 0x110a8c30 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    FShowdownTournamentEntry GetTournamentStyle() const; // 0x110a8c48 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasAdditionalLeaderboards() const; // 0x110a8ecc (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasLeaderboardRequestedPage() const; // 0x110a8f04 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasLoadedTournamentStyle() const; // 0x110a8f1c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InitializeManager(UObject*& const WorldContextObject); // 0x475e420 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    static bool IsPayoutItemCosmetic(const FTournamentPayoutItemData ItemData); // 0x110a9cf0 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    bool IsTournamentSeriesPointLeaderboardAvailable() const; // 0x110a9ec0 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTournamentWindowBookmarked(FString& TournamentID, FString& TournamentWindowId) const; // 0x110a9f60 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnFrontendBookmarkedTournamentNotificationAction(UFortUINotification*& Notification); // 0x110aa7fc (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    bool RestoreRegion(); // 0x110aafcc (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void SaveBookmarks(); // 0x110aaff0 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetCanResetCalendarFilterVM(bool& const bInCanResetCalendarFilter); // 0x110ac7ac (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurrentTournamentWindowBookmarked(bool& bBookmark); // 0x110aca08 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetEventWindow(FString& InTournamentWindowId); // 0x110acd80 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetTournamentLeaderboardScreenSelectedEntry(UFortTournamentLeaderboardEntryData*& InEntry); // 0x110ad778 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetTournamentWindowBookmarked(FString& TournamentID, FString& TournamentWindowId, FDateTime& const EndTime, bool& bBookmark); // 0x110ada54 (Index: 0x1a, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void ShowCareerStatsScreen(FString& AccountId) const; // 0x110ae3ec (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|Const)
    void ShowFrontendBookmarkedTournamentNotification(UClass*& const NotificationClass, const FFortUpcomingTournamentData UpcomingTournament); // 0x110ae6e0 (Index: 0x1c, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool ShowNextRoundTokensByDivisionLabels() const; // 0x110aea64 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ShowTournamentDetailsScreen(const FTournamentDetailsScreenParams Params); // 0x110aeaec (Index: 0x1e, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ShowTournamentLeaderboardScreen(const FTournamentLeaderboardScreenParams Params); // 0x110aee00 (Index: 0x1f, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void WatchMatchReplay(FString& SessionId, const TArray<FString> TeamAccountIds); // 0x110af594 (Index: 0x20, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortCompeteUIManager) == 0x6c0, "Size mismatch for UFortCompeteUIManager");
static_assert(offsetof(UFortCompeteUIManager, OnSetTournamentLeaderboardScreenSelectedEntry) == 0x68, "Offset mismatch for UFortCompeteUIManager::OnSetTournamentLeaderboardScreenSelectedEntry");
static_assert(offsetof(UFortCompeteUIManager, FrontendNotificationDataMap) == 0x78, "Offset mismatch for UFortCompeteUIManager::FrontendNotificationDataMap");
static_assert(offsetof(UFortCompeteUIManager, CalendarFilterVM) == 0x110, "Offset mismatch for UFortCompeteUIManager::CalendarFilterVM");
static_assert(offsetof(UFortCompeteUIManager, BookmarksVM) == 0x118, "Offset mismatch for UFortCompeteUIManager::BookmarksVM");
static_assert(offsetof(UFortCompeteUIManager, CompeteGameUserSettings) == 0x120, "Offset mismatch for UFortCompeteUIManager::CompeteGameUserSettings");
static_assert(offsetof(UFortCompeteUIManager, GameInstance) == 0x130, "Offset mismatch for UFortCompeteUIManager::GameInstance");
static_assert(offsetof(UFortCompeteUIManager, TM) == 0x138, "Offset mismatch for UFortCompeteUIManager::TM");
static_assert(offsetof(UFortCompeteUIManager, LeaderboardEntries) == 0x578, "Offset mismatch for UFortCompeteUIManager::LeaderboardEntries");
static_assert(offsetof(UFortCompeteUIManager, LeaderboardLocalPlayerEntry) == 0x588, "Offset mismatch for UFortCompeteUIManager::LeaderboardLocalPlayerEntry");
static_assert(offsetof(UFortCompeteUIManager, LeaderboardScreenSelectedEntry) == 0x590, "Offset mismatch for UFortCompeteUIManager::LeaderboardScreenSelectedEntry");
static_assert(offsetof(UFortCompeteUIManager, LeaderboardClass) == 0x598, "Offset mismatch for UFortCompeteUIManager::LeaderboardClass");
static_assert(offsetof(UFortCompeteUIManager, PlayersProfiles) == 0x5b8, "Offset mismatch for UFortCompeteUIManager::PlayersProfiles");
static_assert(offsetof(UFortCompeteUIManager, LiveGames) == 0x698, "Offset mismatch for UFortCompeteUIManager::LiveGames");
static_assert(offsetof(UFortCompeteUIManager, bShowDebugInfo) == 0x6b8, "Offset mismatch for UFortCompeteUIManager::bShowDebugInfo");

// Size: 0x70 (Inherited: 0x78, Single: 0xfffffff8)
class UFortUIGameFeatureAction_CompeteUI : public UFortUIGameFeatureAction
{
public:
    TSoftClassPtr TournamentDetailsScreenClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr TournamentLeaderboardScreenClass; // 0x48 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortUIGameFeatureAction_CompeteUI) == 0x70, "Size mismatch for UFortUIGameFeatureAction_CompeteUI");
static_assert(offsetof(UFortUIGameFeatureAction_CompeteUI, TournamentDetailsScreenClass) == 0x28, "Offset mismatch for UFortUIGameFeatureAction_CompeteUI::TournamentDetailsScreenClass");
static_assert(offsetof(UFortUIGameFeatureAction_CompeteUI, TournamentLeaderboardScreenClass) == 0x48, "Offset mismatch for UFortUIGameFeatureAction_CompeteUI::TournamentLeaderboardScreenClass");

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UFortPoblanoTournamentsCalendarDayTileVM : public UMVVMViewModelBase
{
public:
    uint8_t CashCups; // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t ShopCups; // 0x69 (Size: 0x1, Type: EnumProperty)
    uint8_t FNCS; // 0x6a (Size: 0x1, Type: EnumProperty)
    uint8_t VictoryCups; // 0x6b (Size: 0x1, Type: EnumProperty)
    uint8_t RankedCups; // 0x6c (Size: 0x1, Type: EnumProperty)
    uint8_t OtherCups; // 0x6d (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6e[0x1a]; // 0x6e (Size: 0x1a, Type: PaddingProperty)
    TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*> BookmarkedTournaments; // 0x88 (Size: 0x10, Type: ArrayProperty)

public:
    int32_t GetCountOfBookmarkedTournaments() const; // 0x5478fc4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetDate() const; // 0x55bf408 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetFirstEventOnThisDate() const; // 0xc84634c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetHasAnyBookmarks() const; // 0x565a634 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ECupTimeZoneStyle GetTileTimeZoneStyle() const; // 0x5748cf4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTotalTournaments() const; // 0x5478fac (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortPoblanoTournamentsCalendarDayTileVM) == 0x98, "Size mismatch for UFortPoblanoTournamentsCalendarDayTileVM");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, CashCups) == 0x68, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::CashCups");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, ShopCups) == 0x69, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::ShopCups");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, FNCS) == 0x6a, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::FNCS");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, VictoryCups) == 0x6b, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::VictoryCups");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, RankedCups) == 0x6c, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::RankedCups");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, OtherCups) == 0x6d, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::OtherCups");
static_assert(offsetof(UFortPoblanoTournamentsCalendarDayTileVM, BookmarkedTournaments) == 0x88, "Offset mismatch for UFortPoblanoTournamentsCalendarDayTileVM::BookmarkedTournaments");

// Size: 0x3c0 (Inherited: 0x90, Single: 0x330)
class UFortPoblanoTournamentsCalendarFilterVM : public UMVVMViewModelBase
{
public:
    FTournamentsFilterSection SectionExperienceFilter; // 0x68 (Size: 0x28, Type: StructProperty)
    TMap<bool, EFortCompeteExperienceType> SectionExperienceValues; // 0x90 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionTeamSizeFilter; // 0xe0 (Size: 0x28, Type: StructProperty)
    TMap<bool, EFortCompeteMatchType> SectionTeamSizeValues; // 0x108 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionRegionFilter; // 0x158 (Size: 0x28, Type: StructProperty)
    TMap<bool, ERegionType> SectionRegionValues; // 0x180 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionTournamentTypeFilter; // 0x1d0 (Size: 0x28, Type: StructProperty)
    TMap<bool, ETournamentTypeFilter> SectionTournamentTypeValues; // 0x1f8 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionTournamentStatusFilter; // 0x248 (Size: 0x28, Type: StructProperty)
    TMap<bool, ETournamentStatusFilter> SectionTournamentStatusValues; // 0x270 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionElegibilityFilter; // 0x2c0 (Size: 0x28, Type: StructProperty)
    TMap<bool, EEligibilityType> SectionElegibilityValues; // 0x2e8 (Size: 0x50, Type: MapProperty)
    FTournamentsFilterSection SectionBookmarksFilter; // 0x338 (Size: 0x28, Type: StructProperty)
    TMap<bool, EBookmarkStateFilter> SectionBookmarksValues; // 0x360 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_3b0[0x8]; // 0x3b0 (Size: 0x8, Type: PaddingProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0x3b8 (Size: 0x8, Type: ObjectProperty)

public:
    TArray<bool> GetAllSectionBookmarks(); // 0x110a79e4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<bool> GetAllSectionElegibility(); // 0x110a7a24 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    TArray<bool> GetAllSectionExperience(); // 0x110a7a64 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    TArray<bool> GetAllSectionRegion(); // 0x110a7aa4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    TArray<bool> GetAllSectionTeamSize(); // 0x110a7ae4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    TArray<bool> GetAllSectionTournamentStatus(); // 0x110a7b24 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    TArray<bool> GetAllSectionTournamentType(); // 0x110a7b64 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    int32_t GetFilterCount(); // 0x53abd84 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionBookmarks(int32_t& const Index); // 0x110a8350 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionElegibility(int32_t& const Index); // 0x110a8488 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionExperience(int32_t& const Index); // 0x110a85c0 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionRegion(int32_t& const Index); // 0x110a86f8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionTeamSize(int32_t& const Index); // 0x110a8830 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionTournamentStatus(int32_t& const Index); // 0x110a8968 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    bool GetSectionTournamentType(int32_t& const Index); // 0x110a8aa0 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    bool IsAllFiltersDefault() const; // 0x110a9844 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAllSectionBookmarks(TArray<bool>& const State); // 0x110ab148 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllSectionElegibility(TArray<bool>& const State); // 0x110ab450 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllSectionExperience(TArray<bool>& const States); // 0x110ab758 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllSectionRegion(TArray<bool>& const State); // 0x110aba60 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllSectionTeamSize(TArray<bool>& const State); // 0x110abd68 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllSectionTournamentStatus(TArray<bool>& const State); // 0x110ac070 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllSectionTournamentType(TArray<bool>& const State); // 0x110ac378 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetbIsDirtyFilter(bool& const bInIsDirtyFilter); // 0x110ae02c (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)

protected:
    TMap<bool, ERegionType> GetSectionRegionValues(); // 0x60fa274 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortPoblanoTournamentsCalendarFilterVM) == 0x3c0, "Size mismatch for UFortPoblanoTournamentsCalendarFilterVM");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionExperienceFilter) == 0x68, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionExperienceFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionExperienceValues) == 0x90, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionExperienceValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionTeamSizeFilter) == 0xe0, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionTeamSizeFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionTeamSizeValues) == 0x108, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionTeamSizeValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionRegionFilter) == 0x158, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionRegionFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionRegionValues) == 0x180, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionRegionValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionTournamentTypeFilter) == 0x1d0, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionTournamentTypeFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionTournamentTypeValues) == 0x1f8, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionTournamentTypeValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionTournamentStatusFilter) == 0x248, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionTournamentStatusFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionTournamentStatusValues) == 0x270, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionTournamentStatusValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionElegibilityFilter) == 0x2c0, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionElegibilityFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionElegibilityValues) == 0x2e8, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionElegibilityValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionBookmarksFilter) == 0x338, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionBookmarksFilter");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, SectionBookmarksValues) == 0x360, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::SectionBookmarksValues");
static_assert(offsetof(UFortPoblanoTournamentsCalendarFilterVM, CompeteUIManager) == 0x3b8, "Offset mismatch for UFortPoblanoTournamentsCalendarFilterVM::CompeteUIManager");

// Size: 0x190 (Inherited: 0x90, Single: 0x100)
class UFortPoblanoTournamentsCalendarTournamentTileVM : public UMVVMViewModelBase
{
public:
    FDateTime Date; // 0x68 (Size: 0x8, Type: StructProperty)
    FText TextDate; // 0x70 (Size: 0x10, Type: TextProperty)
    uint8_t Region; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t RankRequirement; // 0x81 (Size: 0x1, Type: EnumProperty)
    uint8_t RankRequirementCheckResult; // 0x82 (Size: 0x1, Type: EnumProperty)
    uint8_t TournamentEligibility; // 0x83 (Size: 0x1, Type: EnumProperty)
    bool bMeetsTournamentSystemRequirements; // 0x84 (Size: 0x1, Type: BoolProperty)
    bool bMeetsRequiresQualifyingRound; // 0x85 (Size: 0x1, Type: BoolProperty)
    bool bMeetsEventsNumberHistoryRequirement; // 0x86 (Size: 0x1, Type: BoolProperty)
    bool bMeetsCheckTournamentLocksRequirement; // 0x87 (Size: 0x1, Type: BoolProperty)
    bool bMeetsAgeRequirement; // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bMeetsAccountLevelRequirement; // 0x89 (Size: 0x1, Type: BoolProperty)
    bool bMeetsPermanentTournamentBanRequirement; // 0x8a (Size: 0x1, Type: BoolProperty)
    uint8_t TournamentState; // 0x8b (Size: 0x1, Type: EnumProperty)
    uint8_t TournamentTag; // 0x8c (Size: 0x1, Type: EnumProperty)
    uint8_t ExperienceType; // 0x8d (Size: 0x1, Type: EnumProperty)
    uint8_t TeamSize; // 0x8e (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_8f[0x1]; // 0x8f (Size: 0x1, Type: PaddingProperty)
    FText TournamentTitle; // 0x90 (Size: 0x10, Type: TextProperty)
    bool bIsLive; // 0xa0 (Size: 0x1, Type: BoolProperty)
    bool bIsBookmarked; // 0xa1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a2[0x6]; // 0xa2 (Size: 0x6, Type: PaddingProperty)
    UTexture2D* PosterTexture; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FText RoundDateTime; // 0xb0 (Size: 0x10, Type: TextProperty)
    FText BookmarksAmount; // 0xc0 (Size: 0x10, Type: TextProperty)
    FBackgroundColors BackgroundCalendarColors; // 0xd0 (Size: 0x20, Type: StructProperty)
    FString TournamentID; // 0xf0 (Size: 0x10, Type: StrProperty)
    FString TournamentWindowId; // 0x100 (Size: 0x10, Type: StrProperty)
    uint8_t GameType; // 0x110 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
    FFortTournamentLockStatus AllTournamentLocks; // 0x118 (Size: 0x20, Type: StructProperty)
    UEpicCMSImage* Poster; // 0x138 (Size: 0x8, Type: ObjectProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0x140 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_148[0x20]; // 0x148 (Size: 0x20, Type: PaddingProperty)
    FTournamentRankRequirements RankInfo; // 0x168 (Size: 0x28, Type: StructProperty)

public:
    static FText GetDayOfWeekText(const FDateTime DateTime); // 0x110a7ce4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FText GetMonthText(const FDateTime DateTime); // 0x3c090b4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    bool HasTournamentEnded() const; // 0x110a8f34 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool UpdateBookmarkStatus(); // 0x110af0ec (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateData(); // 0x110af110 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    FTournamentRankRequirements GetRankInfo() const; // 0x110a8194 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void UpdateTextureFromCMSImage(UTexture2D*& Texture); // 0x110af124 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortPoblanoTournamentsCalendarTournamentTileVM) == 0x190, "Size mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, Date) == 0x68, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::Date");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TextDate) == 0x70, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TextDate");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, Region) == 0x80, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::Region");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, RankRequirement) == 0x81, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::RankRequirement");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, RankRequirementCheckResult) == 0x82, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::RankRequirementCheckResult");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TournamentEligibility) == 0x83, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TournamentEligibility");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsTournamentSystemRequirements) == 0x84, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsTournamentSystemRequirements");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsRequiresQualifyingRound) == 0x85, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsRequiresQualifyingRound");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsEventsNumberHistoryRequirement) == 0x86, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsEventsNumberHistoryRequirement");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsCheckTournamentLocksRequirement) == 0x87, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsCheckTournamentLocksRequirement");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsAgeRequirement) == 0x88, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsAgeRequirement");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsAccountLevelRequirement) == 0x89, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsAccountLevelRequirement");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bMeetsPermanentTournamentBanRequirement) == 0x8a, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bMeetsPermanentTournamentBanRequirement");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TournamentState) == 0x8b, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TournamentState");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TournamentTag) == 0x8c, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TournamentTag");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, ExperienceType) == 0x8d, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::ExperienceType");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TeamSize) == 0x8e, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TeamSize");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TournamentTitle) == 0x90, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TournamentTitle");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bIsLive) == 0xa0, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bIsLive");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, bIsBookmarked) == 0xa1, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::bIsBookmarked");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, PosterTexture) == 0xa8, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::PosterTexture");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, RoundDateTime) == 0xb0, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::RoundDateTime");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, BookmarksAmount) == 0xc0, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::BookmarksAmount");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, BackgroundCalendarColors) == 0xd0, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::BackgroundCalendarColors");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TournamentID) == 0xf0, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TournamentID");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, TournamentWindowId) == 0x100, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::TournamentWindowId");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, GameType) == 0x110, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::GameType");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, AllTournamentLocks) == 0x118, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::AllTournamentLocks");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, Poster) == 0x138, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::Poster");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, CompeteUIManager) == 0x140, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::CompeteUIManager");
static_assert(offsetof(UFortPoblanoTournamentsCalendarTournamentTileVM, RankInfo) == 0x168, "Offset mismatch for UFortPoblanoTournamentsCalendarTournamentTileVM::RankInfo");

// Size: 0xe8 (Inherited: 0x90, Single: 0x58)
class UFortPoblanoTournamentsCalendarVM : public UMVVMViewModelBase
{
public:
    FTournamentsTilesData TournamentsTilesData; // 0x68 (Size: 0x28, Type: StructProperty)
    FCalendarTilesData CalendarTilesData; // 0x90 (Size: 0x18, Type: StructProperty)
    FDateTime CurrentTime; // 0xa8 (Size: 0x8, Type: StructProperty)
    FDateTime DisplayMonthDate; // 0xb0 (Size: 0x8, Type: StructProperty)
    TArray<FString> MonthTournamentsIDs; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x18]; // 0xd0 (Size: 0x18, Type: PaddingProperty)

public:
    void DisplayNextMonth(); // 0x110a7854 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void DisplayPreviousMonth(); // 0x110a78dc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void InitializeVM(); // 0x65516dc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void ProcessFilter(); // 0x110aa9c4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetDisplayMonthDate(const FDateTime InDisplayMonthDate); // 0x110acc9c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ToggleTournamentTileBookmarked(UFortPoblanoTournamentsCalendarTournamentTileVM*& TournamentTile); // 0x110aef10 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortPoblanoTournamentsCalendarVM) == 0xe8, "Size mismatch for UFortPoblanoTournamentsCalendarVM");
static_assert(offsetof(UFortPoblanoTournamentsCalendarVM, TournamentsTilesData) == 0x68, "Offset mismatch for UFortPoblanoTournamentsCalendarVM::TournamentsTilesData");
static_assert(offsetof(UFortPoblanoTournamentsCalendarVM, CalendarTilesData) == 0x90, "Offset mismatch for UFortPoblanoTournamentsCalendarVM::CalendarTilesData");
static_assert(offsetof(UFortPoblanoTournamentsCalendarVM, CurrentTime) == 0xa8, "Offset mismatch for UFortPoblanoTournamentsCalendarVM::CurrentTime");
static_assert(offsetof(UFortPoblanoTournamentsCalendarVM, DisplayMonthDate) == 0xb0, "Offset mismatch for UFortPoblanoTournamentsCalendarVM::DisplayMonthDate");
static_assert(offsetof(UFortPoblanoTournamentsCalendarVM, MonthTournamentsIDs) == 0xb8, "Offset mismatch for UFortPoblanoTournamentsCalendarVM::MonthTournamentsIDs");
static_assert(offsetof(UFortPoblanoTournamentsCalendarVM, CompeteUIManager) == 0xc8, "Offset mismatch for UFortPoblanoTournamentsCalendarVM::CompeteUIManager");

// Size: 0xf0 (Inherited: 0x100, Single: 0xfffffff0)
class UFortTournamentBaseEntryVM : public UFortPerUserViewModel
{
public:
    FString LiveSessionId; // 0x70 (Size: 0x10, Type: StrProperty)
    TArray<FString> TeammatesAccountIds; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TMap<UFortTournamentPlayerProfileVM*, FString> PlayersProfiles; // 0x90 (Size: 0x50, Type: MapProperty)
    int32_t AdjustedRank; // 0xe0 (Size: 0x4, Type: IntProperty)
    int32_t MatchesPlayed; // 0xe4 (Size: 0x4, Type: IntProperty)
    int32_t TotalPoints; // 0xe8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortTournamentBaseEntryVM) == 0xf0, "Size mismatch for UFortTournamentBaseEntryVM");
static_assert(offsetof(UFortTournamentBaseEntryVM, LiveSessionId) == 0x70, "Offset mismatch for UFortTournamentBaseEntryVM::LiveSessionId");
static_assert(offsetof(UFortTournamentBaseEntryVM, TeammatesAccountIds) == 0x80, "Offset mismatch for UFortTournamentBaseEntryVM::TeammatesAccountIds");
static_assert(offsetof(UFortTournamentBaseEntryVM, PlayersProfiles) == 0x90, "Offset mismatch for UFortTournamentBaseEntryVM::PlayersProfiles");
static_assert(offsetof(UFortTournamentBaseEntryVM, AdjustedRank) == 0xe0, "Offset mismatch for UFortTournamentBaseEntryVM::AdjustedRank");
static_assert(offsetof(UFortTournamentBaseEntryVM, MatchesPlayed) == 0xe4, "Offset mismatch for UFortTournamentBaseEntryVM::MatchesPlayed");
static_assert(offsetof(UFortTournamentBaseEntryVM, TotalPoints) == 0xe8, "Offset mismatch for UFortTournamentBaseEntryVM::TotalPoints");

// Size: 0x1b8 (Inherited: 0x1f0, Single: 0xffffffc8)
class UFortTournamentLeaderboardEntryData : public UFortTournamentBaseEntryVM
{
public:
    int32_t DisplayIndex; // 0xf0 (Size: 0x4, Type: IntProperty)
    int32_t EntryIndex; // 0xf4 (Size: 0x4, Type: IntProperty)
    TMap<int32_t, FString> TrackedStatsTimesAchieved; // 0xf8 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FString> TrackedStatsPoints; // 0x148 (Size: 0x50, Type: MapProperty)
    int32_t TotalVictoryRoyales; // 0x198 (Size: 0x4, Type: IntProperty)
    int32_t TotalEliminations; // 0x19c (Size: 0x4, Type: IntProperty)
    float AveragePlacement; // 0x1a0 (Size: 0x4, Type: FloatProperty)
    bool bUseQualifiedIcons; // 0x1a4 (Size: 0x1, Type: BoolProperty)
    bool bIsTeamQualified; // 0x1a5 (Size: 0x1, Type: BoolProperty)
    bool bIsMatchPointWinner; // 0x1a6 (Size: 0x1, Type: BoolProperty)
    bool bIsSeriesPointLeaderboards; // 0x1a7 (Size: 0x1, Type: BoolProperty)
    TArray<UFortTournamentLeaderboardSessionTeamEntryVM*> SessionsTeamEntries; // 0x1a8 (Size: 0x10, Type: ArrayProperty)

public:
    static bool GetShowPointsToQualify(); // 0x110a8c04 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFortTournamentLeaderboardEntryData) == 0x1b8, "Size mismatch for UFortTournamentLeaderboardEntryData");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, DisplayIndex) == 0xf0, "Offset mismatch for UFortTournamentLeaderboardEntryData::DisplayIndex");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, EntryIndex) == 0xf4, "Offset mismatch for UFortTournamentLeaderboardEntryData::EntryIndex");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, TrackedStatsTimesAchieved) == 0xf8, "Offset mismatch for UFortTournamentLeaderboardEntryData::TrackedStatsTimesAchieved");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, TrackedStatsPoints) == 0x148, "Offset mismatch for UFortTournamentLeaderboardEntryData::TrackedStatsPoints");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, TotalVictoryRoyales) == 0x198, "Offset mismatch for UFortTournamentLeaderboardEntryData::TotalVictoryRoyales");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, TotalEliminations) == 0x19c, "Offset mismatch for UFortTournamentLeaderboardEntryData::TotalEliminations");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, AveragePlacement) == 0x1a0, "Offset mismatch for UFortTournamentLeaderboardEntryData::AveragePlacement");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, bUseQualifiedIcons) == 0x1a4, "Offset mismatch for UFortTournamentLeaderboardEntryData::bUseQualifiedIcons");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, bIsTeamQualified) == 0x1a5, "Offset mismatch for UFortTournamentLeaderboardEntryData::bIsTeamQualified");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, bIsMatchPointWinner) == 0x1a6, "Offset mismatch for UFortTournamentLeaderboardEntryData::bIsMatchPointWinner");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, bIsSeriesPointLeaderboards) == 0x1a7, "Offset mismatch for UFortTournamentLeaderboardEntryData::bIsSeriesPointLeaderboards");
static_assert(offsetof(UFortTournamentLeaderboardEntryData, SessionsTeamEntries) == 0x1a8, "Offset mismatch for UFortTournamentLeaderboardEntryData::SessionsTeamEntries");

// Size: 0xd8 (Inherited: 0x90, Single: 0x48)
class UFortTournamentLeaderboardSessionTeamEntryVM : public UMVVMViewModelBase
{
public:
    FString SessionId; // 0x68 (Size: 0x10, Type: StrProperty)
    int32_t SessionNumber; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    TMap<int32_t, FString> TrackedStatsTimesAchieved; // 0x80 (Size: 0x50, Type: MapProperty)
    int32_t CreativeScore; // 0xd0 (Size: 0x4, Type: IntProperty)
    bool bShowCreativeScore; // 0xd4 (Size: 0x1, Type: BoolProperty)
    bool bShowEliminations; // 0xd5 (Size: 0x1, Type: BoolProperty)
    bool bIsScoreContributor; // 0xd6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d7[0x1]; // 0xd7 (Size: 0x1, Type: PaddingProperty)

public:
    static bool GetShowMatchHistoryPoints(); // 0x110a8bd8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    void InitializeVM(FString& const InSessionId, int32_t& const InSessionNumber, const TMap<int32_t, FString> InTrackedStatsTimesAchieved, int32_t& const InCreativeScore, bool& const bInShowCreativeScore, bool& const bInShowEliminations, bool& const bInIsScoreContributor); // 0x110a8f98 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentLeaderboardSessionTeamEntryVM) == 0xd8, "Size mismatch for UFortTournamentLeaderboardSessionTeamEntryVM");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, SessionId) == 0x68, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::SessionId");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, SessionNumber) == 0x78, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::SessionNumber");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, TrackedStatsTimesAchieved) == 0x80, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::TrackedStatsTimesAchieved");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, CreativeScore) == 0xd0, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::CreativeScore");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, bShowCreativeScore) == 0xd4, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::bShowCreativeScore");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, bShowEliminations) == 0xd5, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::bShowEliminations");
static_assert(offsetof(UFortTournamentLeaderboardSessionTeamEntryVM, bIsScoreContributor) == 0xd6, "Offset mismatch for UFortTournamentLeaderboardSessionTeamEntryVM::bIsScoreContributor");

// Size: 0x1a8 (Inherited: 0x90, Single: 0x118)
class UFortTournamentLeaderboardVM : public UMVVMViewModelBase
{
public:
    TMap<FFortTournamentLeaderboardViewState, FString> ViewStates; // 0x68 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_b8[0x20]; // 0xb8 (Size: 0x20, Type: PaddingProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortCompeteUILeaderboardCategory> LeaderboardCategories; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    int32_t CurrentLeaderboardCategoryIndex; // 0xf0 (Size: 0x4, Type: IntProperty)
    bool bShowFriendsOnly; // 0xf4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f5[0x3]; // 0xf5 (Size: 0x3, Type: PaddingProperty)
    FText TournamentName; // 0xf8 (Size: 0x10, Type: TextProperty)
    FText RegionName; // 0x108 (Size: 0x10, Type: TextProperty)
    TArray<FString> EventWindowsList; // 0x118 (Size: 0x10, Type: ArrayProperty)
    bool bIsModelInitialized; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x3]; // 0x129 (Size: 0x3, Type: PaddingProperty)
    int32_t QualifierScore; // 0x12c (Size: 0x4, Type: IntProperty)
    FTournamentPayoutThresholdData TokenData; // 0x130 (Size: 0x60, Type: StructProperty)
    FDateTime LeaderboardUpdateTime; // 0x190 (Size: 0x8, Type: StructProperty)
    UUIKitDialogViewModel* MatchHistoryDialogVM; // 0x198 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1a0[0x8]; // 0x1a0 (Size: 0x8, Type: PaddingProperty)

public:
    bool CanRequestLeaderboardPage(int32_t& PageIndex); // 0x110a721c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void DeinitializeVM(); // 0xa39cba8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void FilterCurrentViewEntriesByText(const FText SearchText); // 0x110a78f0 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool GetCurrentLeaderboardCategory(FFortCompeteUILeaderboardCategory& OutLeaderboardCategory) const; // 0x110a7bbc (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<UFortTournamentLeaderboardEntryData*> GetLeaderboardEntries() const; // 0x110a7fc0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortTournamentLeaderboardEntryData* GetLeaderboardLocalPlayerEntry() const; // 0x110a7fec (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextLeaderboardPageToLoad() const; // 0x110a8034 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextLeaderboardPageToLoadInGapOfMissingPages(bool& bFromStartOfTheGap) const; // 0x110a8058 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InitializeVM(const TArray<FTournamentLeaderboardPayoutTableData> PayoutDisplayData); // 0x110a95c4 (Index: 0x8, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool IsAGapInLoadedPagesOrder() const; // 0x110a9820 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static bool IsLeaderboardSearchBarEnabled(); // 0x110a9cc4 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsQualilfierScoreCalcEnabled(); // 0x110a9e9c (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    void LeaderboardRequestPage(int32_t& PageIndex); // 0x110aa5a8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurrentLeaderboardCategoryIndex(int32_t& const InCurrentLeaderboardCategoryIndex); // 0x110ac8d8 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void SetShowFriendsOnly(bool& const InbShowFriendsOnly); // 0x110ad34c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTournamentLeaderboardVM) == 0x1a8, "Size mismatch for UFortTournamentLeaderboardVM");
static_assert(offsetof(UFortTournamentLeaderboardVM, ViewStates) == 0x68, "Offset mismatch for UFortTournamentLeaderboardVM::ViewStates");
static_assert(offsetof(UFortTournamentLeaderboardVM, CompeteUIManager) == 0xd8, "Offset mismatch for UFortTournamentLeaderboardVM::CompeteUIManager");
static_assert(offsetof(UFortTournamentLeaderboardVM, LeaderboardCategories) == 0xe0, "Offset mismatch for UFortTournamentLeaderboardVM::LeaderboardCategories");
static_assert(offsetof(UFortTournamentLeaderboardVM, CurrentLeaderboardCategoryIndex) == 0xf0, "Offset mismatch for UFortTournamentLeaderboardVM::CurrentLeaderboardCategoryIndex");
static_assert(offsetof(UFortTournamentLeaderboardVM, bShowFriendsOnly) == 0xf4, "Offset mismatch for UFortTournamentLeaderboardVM::bShowFriendsOnly");
static_assert(offsetof(UFortTournamentLeaderboardVM, TournamentName) == 0xf8, "Offset mismatch for UFortTournamentLeaderboardVM::TournamentName");
static_assert(offsetof(UFortTournamentLeaderboardVM, RegionName) == 0x108, "Offset mismatch for UFortTournamentLeaderboardVM::RegionName");
static_assert(offsetof(UFortTournamentLeaderboardVM, EventWindowsList) == 0x118, "Offset mismatch for UFortTournamentLeaderboardVM::EventWindowsList");
static_assert(offsetof(UFortTournamentLeaderboardVM, bIsModelInitialized) == 0x128, "Offset mismatch for UFortTournamentLeaderboardVM::bIsModelInitialized");
static_assert(offsetof(UFortTournamentLeaderboardVM, QualifierScore) == 0x12c, "Offset mismatch for UFortTournamentLeaderboardVM::QualifierScore");
static_assert(offsetof(UFortTournamentLeaderboardVM, TokenData) == 0x130, "Offset mismatch for UFortTournamentLeaderboardVM::TokenData");
static_assert(offsetof(UFortTournamentLeaderboardVM, LeaderboardUpdateTime) == 0x190, "Offset mismatch for UFortTournamentLeaderboardVM::LeaderboardUpdateTime");
static_assert(offsetof(UFortTournamentLeaderboardVM, MatchHistoryDialogVM) == 0x198, "Offset mismatch for UFortTournamentLeaderboardVM::MatchHistoryDialogVM");

// Size: 0xf8 (Inherited: 0x90, Single: 0x68)
class UFortTournamentRequirementsModalVM : public UMVVMViewModelBase
{
public:
    uint8_t Pad_68[0x18]; // 0x68 (Size: 0x18, Type: PaddingProperty)
    TArray<FTournamentRequirementItem> RequirementsList; // 0x80 (Size: 0x10, Type: ArrayProperty)
    bool bAllChecksPassed; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0x98 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_a0[0x20]; // 0xa0 (Size: 0x20, Type: PaddingProperty)
    FTournamentRankRequirements RankInfo; // 0xc0 (Size: 0x28, Type: StructProperty)
    uint8_t LastCheckRankResult; // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e9[0xf]; // 0xe9 (Size: 0xf, Type: PaddingProperty)

public:
    void ClearLockRefreshTimer(); // 0x110a7538 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    EFortCompeteHabaneroRankRequirementCheckResult GetHabaneroRankCheckResult() const; // 0x1027eb44 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    FTournamentRankRequirements GetRankInfo() const; // 0x110a81fc (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleCachedPlayerScores(); // 0x110a8eb8 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortTournamentRequirementsModalVM) == 0xf8, "Size mismatch for UFortTournamentRequirementsModalVM");
static_assert(offsetof(UFortTournamentRequirementsModalVM, RequirementsList) == 0x80, "Offset mismatch for UFortTournamentRequirementsModalVM::RequirementsList");
static_assert(offsetof(UFortTournamentRequirementsModalVM, bAllChecksPassed) == 0x90, "Offset mismatch for UFortTournamentRequirementsModalVM::bAllChecksPassed");
static_assert(offsetof(UFortTournamentRequirementsModalVM, CompeteUIManager) == 0x98, "Offset mismatch for UFortTournamentRequirementsModalVM::CompeteUIManager");
static_assert(offsetof(UFortTournamentRequirementsModalVM, RankInfo) == 0xc0, "Offset mismatch for UFortTournamentRequirementsModalVM::RankInfo");
static_assert(offsetof(UFortTournamentRequirementsModalVM, LastCheckRankResult) == 0xe8, "Offset mismatch for UFortTournamentRequirementsModalVM::LastCheckRankResult");

// Size: 0x1d8 (Inherited: 0x238, Single: 0xffffffa0)
class UFortTournamentSeriesPointLeaderboardVM : public UFortTournamentLeaderboardVM
{
public:
};

static_assert(sizeof(UFortTournamentSeriesPointLeaderboardVM) == 0x1d8, "Size mismatch for UFortTournamentSeriesPointLeaderboardVM");

// Size: 0x1a8 (Inherited: 0x238, Single: 0xffffff70)
class UFortTournamentSessionLeaderboardVM : public UFortTournamentLeaderboardVM
{
public:
};

static_assert(sizeof(UFortTournamentSessionLeaderboardVM) == 0x1a8, "Size mismatch for UFortTournamentSessionLeaderboardVM");

// Size: 0x108 (Inherited: 0x1f0, Single: 0xffffff18)
class UFortTournamentWatchLiveEntryVM : public UFortTournamentBaseEntryVM
{
public:
    FText TimeSinceGameStart; // 0xf0 (Size: 0x10, Type: TextProperty)
    uint8_t Pad_100[0x8]; // 0x100 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortTournamentWatchLiveEntryVM) == 0x108, "Size mismatch for UFortTournamentWatchLiveEntryVM");
static_assert(offsetof(UFortTournamentWatchLiveEntryVM, TimeSinceGameStart) == 0xf0, "Offset mismatch for UFortTournamentWatchLiveEntryVM::TimeSinceGameStart");

// Size: 0xd8 (Inherited: 0x90, Single: 0x48)
class UFortTournamentWatchLiveVM : public UMVVMViewModelBase
{
public:
    bool bIsModelInitialized; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0xf]; // 0x69 (Size: 0xf, Type: PaddingProperty)
    UFortCompeteUIManager* CompeteUIManager; // 0x78 (Size: 0x8, Type: ObjectProperty)
    FText TournamentName; // 0x80 (Size: 0x10, Type: TextProperty)
    TArray<UFortTournamentWatchLiveEntryVM*> LiveGames; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a0[0x38]; // 0xa0 (Size: 0x38, Type: PaddingProperty)

public:
    bool CanRequestMoreLiveGames(); // 0x110a7354 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void InitializeVM(FFortCompeteUILeaderboardCategory& const InLeaderboardCategory, bool& const bInShowFriendsOnly); // 0x110a96a4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void RequestMoreLiveGames(); // 0x110aafb8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void Watch(FString& const LiveSessionId) const; // 0x110af290 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|Const)
};

static_assert(sizeof(UFortTournamentWatchLiveVM) == 0xd8, "Size mismatch for UFortTournamentWatchLiveVM");
static_assert(offsetof(UFortTournamentWatchLiveVM, bIsModelInitialized) == 0x68, "Offset mismatch for UFortTournamentWatchLiveVM::bIsModelInitialized");
static_assert(offsetof(UFortTournamentWatchLiveVM, CompeteUIManager) == 0x78, "Offset mismatch for UFortTournamentWatchLiveVM::CompeteUIManager");
static_assert(offsetof(UFortTournamentWatchLiveVM, TournamentName) == 0x80, "Offset mismatch for UFortTournamentWatchLiveVM::TournamentName");
static_assert(offsetof(UFortTournamentWatchLiveVM, LiveGames) == 0x90, "Offset mismatch for UFortTournamentWatchLiveVM::LiveGames");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FFortCompeteTournamentBestResultsSummary
{
    int32_t TotalScore; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t MatchesPlayed; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t NumVictoryRoyales; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t PlacementPoints; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t EliminationPoints; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t EntryFeePoints; // 0x14 (Size: 0x4, Type: IntProperty)
    bool bIsValidSummary; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFortCompeteTournamentBestResultsSummary) == 0x1c, "Size mismatch for FFortCompeteTournamentBestResultsSummary");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, TotalScore) == 0x0, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::TotalScore");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, MatchesPlayed) == 0x4, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::MatchesPlayed");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, NumVictoryRoyales) == 0x8, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::NumVictoryRoyales");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, PlacementPoints) == 0xc, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::PlacementPoints");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, EliminationPoints) == 0x10, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::EliminationPoints");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, EntryFeePoints) == 0x14, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::EntryFeePoints");
static_assert(offsetof(FFortCompeteTournamentBestResultsSummary, bIsValidSummary) == 0x18, "Offset mismatch for FFortCompeteTournamentBestResultsSummary::bIsValidSummary");

// Size: 0x178 (Inherited: 0x8, Single: 0x170)
struct FFortCompeteTournamentDisplayInfo : FTableRowBase
{
    FText TitleLine1; // 0x8 (Size: 0x10, Type: TextProperty)
    FText TitleLine2; // 0x18 (Size: 0x10, Type: TextProperty)
    FText ScheduleInfo; // 0x28 (Size: 0x10, Type: TextProperty)
    FText FlavorDescription; // 0x38 (Size: 0x10, Type: TextProperty)
    FText DetailsDescription; // 0x48 (Size: 0x10, Type: TextProperty)
    FText ShortFormatTitle; // 0x58 (Size: 0x10, Type: TextProperty)
    FText LongFormatTitle; // 0x68 (Size: 0x10, Type: TextProperty)
    FText BackgroundTitle; // 0x78 (Size: 0x10, Type: TextProperty)
    int32_t PinScoreRequirement; // 0x88 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    FText PinEarnedText; // 0x90 (Size: 0x10, Type: TextProperty)
    FLinearColor BaseColor; // 0xa0 (Size: 0x10, Type: StructProperty)
    FLinearColor PrimaryColor; // 0xb0 (Size: 0x10, Type: StructProperty)
    FLinearColor SecondaryColor; // 0xc0 (Size: 0x10, Type: StructProperty)
    FLinearColor HighlightColor; // 0xd0 (Size: 0x10, Type: StructProperty)
    FLinearColor TitleColor; // 0xe0 (Size: 0x10, Type: StructProperty)
    FLinearColor ShadowColor; // 0xf0 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundLeftColor; // 0x100 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundRightColor; // 0x110 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundTextColor; // 0x120 (Size: 0x10, Type: StructProperty)
    FLinearColor PosterFadeColor; // 0x130 (Size: 0x10, Type: StructProperty)
    FText AlertText; // 0x140 (Size: 0x10, Type: TextProperty)
    FText SeriesPointLeaderboardName; // 0x150 (Size: 0x10, Type: TextProperty)
    uint8_t AlertType; // 0x160 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_161[0x7]; // 0x161 (Size: 0x7, Type: PaddingProperty)
    TArray<FText> RoundDisplayNames; // 0x168 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortCompeteTournamentDisplayInfo) == 0x178, "Size mismatch for FFortCompeteTournamentDisplayInfo");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, TitleLine1) == 0x8, "Offset mismatch for FFortCompeteTournamentDisplayInfo::TitleLine1");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, TitleLine2) == 0x18, "Offset mismatch for FFortCompeteTournamentDisplayInfo::TitleLine2");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, ScheduleInfo) == 0x28, "Offset mismatch for FFortCompeteTournamentDisplayInfo::ScheduleInfo");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, FlavorDescription) == 0x38, "Offset mismatch for FFortCompeteTournamentDisplayInfo::FlavorDescription");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, DetailsDescription) == 0x48, "Offset mismatch for FFortCompeteTournamentDisplayInfo::DetailsDescription");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, ShortFormatTitle) == 0x58, "Offset mismatch for FFortCompeteTournamentDisplayInfo::ShortFormatTitle");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, LongFormatTitle) == 0x68, "Offset mismatch for FFortCompeteTournamentDisplayInfo::LongFormatTitle");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, BackgroundTitle) == 0x78, "Offset mismatch for FFortCompeteTournamentDisplayInfo::BackgroundTitle");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, PinScoreRequirement) == 0x88, "Offset mismatch for FFortCompeteTournamentDisplayInfo::PinScoreRequirement");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, PinEarnedText) == 0x90, "Offset mismatch for FFortCompeteTournamentDisplayInfo::PinEarnedText");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, BaseColor) == 0xa0, "Offset mismatch for FFortCompeteTournamentDisplayInfo::BaseColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, PrimaryColor) == 0xb0, "Offset mismatch for FFortCompeteTournamentDisplayInfo::PrimaryColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, SecondaryColor) == 0xc0, "Offset mismatch for FFortCompeteTournamentDisplayInfo::SecondaryColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, HighlightColor) == 0xd0, "Offset mismatch for FFortCompeteTournamentDisplayInfo::HighlightColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, TitleColor) == 0xe0, "Offset mismatch for FFortCompeteTournamentDisplayInfo::TitleColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, ShadowColor) == 0xf0, "Offset mismatch for FFortCompeteTournamentDisplayInfo::ShadowColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, BackgroundLeftColor) == 0x100, "Offset mismatch for FFortCompeteTournamentDisplayInfo::BackgroundLeftColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, BackgroundRightColor) == 0x110, "Offset mismatch for FFortCompeteTournamentDisplayInfo::BackgroundRightColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, BackgroundTextColor) == 0x120, "Offset mismatch for FFortCompeteTournamentDisplayInfo::BackgroundTextColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, PosterFadeColor) == 0x130, "Offset mismatch for FFortCompeteTournamentDisplayInfo::PosterFadeColor");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, AlertText) == 0x140, "Offset mismatch for FFortCompeteTournamentDisplayInfo::AlertText");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, SeriesPointLeaderboardName) == 0x150, "Offset mismatch for FFortCompeteTournamentDisplayInfo::SeriesPointLeaderboardName");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, AlertType) == 0x160, "Offset mismatch for FFortCompeteTournamentDisplayInfo::AlertType");
static_assert(offsetof(FFortCompeteTournamentDisplayInfo, RoundDisplayNames) == 0x168, "Offset mismatch for FFortCompeteTournamentDisplayInfo::RoundDisplayNames");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFortCompeteUILeaderboardCategory
{
    FText LeaderboardName; // 0x0 (Size: 0x10, Type: TextProperty)
    FString GroupingKey; // 0x10 (Size: 0x10, Type: StrProperty)
    FString InstanceID; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FFortCompeteUILeaderboardCategory) == 0x30, "Size mismatch for FFortCompeteUILeaderboardCategory");
static_assert(offsetof(FFortCompeteUILeaderboardCategory, LeaderboardName) == 0x0, "Offset mismatch for FFortCompeteUILeaderboardCategory::LeaderboardName");
static_assert(offsetof(FFortCompeteUILeaderboardCategory, GroupingKey) == 0x10, "Offset mismatch for FFortCompeteUILeaderboardCategory::GroupingKey");
static_assert(offsetof(FFortCompeteUILeaderboardCategory, InstanceID) == 0x20, "Offset mismatch for FFortCompeteUILeaderboardCategory::InstanceID");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FFortCompeteUILeaderboardRequestParams
{
    UClass* LeaderboardClassPtr; // 0x50 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FFortCompeteUILeaderboardRequestParams) == 0x60, "Size mismatch for FFortCompeteUILeaderboardRequestParams");
static_assert(offsetof(FFortCompeteUILeaderboardRequestParams, LeaderboardClassPtr) == 0x50, "Offset mismatch for FFortCompeteUILeaderboardRequestParams::LeaderboardClassPtr");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FTournamentRankRequirements
{
    FString Type; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Mode; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t Level; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FTournamentRankRequirements) == 0x28, "Size mismatch for FTournamentRankRequirements");
static_assert(offsetof(FTournamentRankRequirements, Type) == 0x0, "Offset mismatch for FTournamentRankRequirements::Type");
static_assert(offsetof(FTournamentRankRequirements, Mode) == 0x10, "Offset mismatch for FTournamentRankRequirements::Mode");
static_assert(offsetof(FTournamentRankRequirements, Level) == 0x20, "Offset mismatch for FTournamentRankRequirements::Level");

// Size: 0xa8 (Inherited: 0x8, Single: 0xa0)
struct FFortCompeteTournamentStyleInfo : FTableRowBase
{
    FLinearColor BaseColor; // 0x8 (Size: 0x10, Type: StructProperty)
    FLinearColor PrimaryColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor SecondaryColor; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor HighlightColor; // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor TitleColor; // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor ShadowColor; // 0x58 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundLeftColor; // 0x68 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundRightColor; // 0x78 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundTextColor; // 0x88 (Size: 0x10, Type: StructProperty)
    FLinearColor PosterFadeColor; // 0x98 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFortCompeteTournamentStyleInfo) == 0xa8, "Size mismatch for FFortCompeteTournamentStyleInfo");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, BaseColor) == 0x8, "Offset mismatch for FFortCompeteTournamentStyleInfo::BaseColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, PrimaryColor) == 0x18, "Offset mismatch for FFortCompeteTournamentStyleInfo::PrimaryColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, SecondaryColor) == 0x28, "Offset mismatch for FFortCompeteTournamentStyleInfo::SecondaryColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, HighlightColor) == 0x38, "Offset mismatch for FFortCompeteTournamentStyleInfo::HighlightColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, TitleColor) == 0x48, "Offset mismatch for FFortCompeteTournamentStyleInfo::TitleColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, ShadowColor) == 0x58, "Offset mismatch for FFortCompeteTournamentStyleInfo::ShadowColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, BackgroundLeftColor) == 0x68, "Offset mismatch for FFortCompeteTournamentStyleInfo::BackgroundLeftColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, BackgroundRightColor) == 0x78, "Offset mismatch for FFortCompeteTournamentStyleInfo::BackgroundRightColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, BackgroundTextColor) == 0x88, "Offset mismatch for FFortCompeteTournamentStyleInfo::BackgroundTextColor");
static_assert(offsetof(FFortCompeteTournamentStyleInfo, PosterFadeColor) == 0x98, "Offset mismatch for FFortCompeteTournamentStyleInfo::PosterFadeColor");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FTournamentLeaderboardScreenParams
{
    APlayerController* ContextPC; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FString TournamentID; // 0x8 (Size: 0x10, Type: StrProperty)
    FString TournamentWindowId; // 0x18 (Size: 0x10, Type: StrProperty)
    bool bIsTournamentSeriesPointLeaderboard; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UFortTournamentWatchLiveVM* TournamentWatchLiveEntryVM; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentHeaderVM* TournamentHeaderVM; // 0x38 (Size: 0x8, Type: ObjectProperty)
    TArray<FTournamentLeaderboardPayoutTableData> PayoutDisplayData; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FTournamentLeaderboardScreenParams) == 0x50, "Size mismatch for FTournamentLeaderboardScreenParams");
static_assert(offsetof(FTournamentLeaderboardScreenParams, ContextPC) == 0x0, "Offset mismatch for FTournamentLeaderboardScreenParams::ContextPC");
static_assert(offsetof(FTournamentLeaderboardScreenParams, TournamentID) == 0x8, "Offset mismatch for FTournamentLeaderboardScreenParams::TournamentID");
static_assert(offsetof(FTournamentLeaderboardScreenParams, TournamentWindowId) == 0x18, "Offset mismatch for FTournamentLeaderboardScreenParams::TournamentWindowId");
static_assert(offsetof(FTournamentLeaderboardScreenParams, bIsTournamentSeriesPointLeaderboard) == 0x28, "Offset mismatch for FTournamentLeaderboardScreenParams::bIsTournamentSeriesPointLeaderboard");
static_assert(offsetof(FTournamentLeaderboardScreenParams, TournamentWatchLiveEntryVM) == 0x30, "Offset mismatch for FTournamentLeaderboardScreenParams::TournamentWatchLiveEntryVM");
static_assert(offsetof(FTournamentLeaderboardScreenParams, TournamentHeaderVM) == 0x38, "Offset mismatch for FTournamentLeaderboardScreenParams::TournamentHeaderVM");
static_assert(offsetof(FTournamentLeaderboardScreenParams, PayoutDisplayData) == 0x40, "Offset mismatch for FTournamentLeaderboardScreenParams::PayoutDisplayData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FSetTournamentLeaderboardType
{
    bool bIsTournamentSeriesPointLeaderboard; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UFortTournamentWatchLiveVM* TournamentWatchLiveVM; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFortTournamentHeaderVM* TournamentHeaderVM; // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<FTournamentLeaderboardPayoutTableData> PayoutDisplayData; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSetTournamentLeaderboardType) == 0x28, "Size mismatch for FSetTournamentLeaderboardType");
static_assert(offsetof(FSetTournamentLeaderboardType, bIsTournamentSeriesPointLeaderboard) == 0x0, "Offset mismatch for FSetTournamentLeaderboardType::bIsTournamentSeriesPointLeaderboard");
static_assert(offsetof(FSetTournamentLeaderboardType, TournamentWatchLiveVM) == 0x8, "Offset mismatch for FSetTournamentLeaderboardType::TournamentWatchLiveVM");
static_assert(offsetof(FSetTournamentLeaderboardType, TournamentHeaderVM) == 0x10, "Offset mismatch for FSetTournamentLeaderboardType::TournamentHeaderVM");
static_assert(offsetof(FSetTournamentLeaderboardType, PayoutDisplayData) == 0x18, "Offset mismatch for FSetTournamentLeaderboardType::PayoutDisplayData");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBackgroundColors
{
    FLinearColor Main; // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor Sub; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FBackgroundColors) == 0x20, "Size mismatch for FBackgroundColors");
static_assert(offsetof(FBackgroundColors, Main) == 0x0, "Offset mismatch for FBackgroundColors::Main");
static_assert(offsetof(FBackgroundColors, Sub) == 0x10, "Offset mismatch for FBackgroundColors::Sub");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTournamentTypeWithName
{
    FText Name; // 0x0 (Size: 0x10, Type: TextProperty)
    uint8_t Type; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTournamentTypeWithName) == 0x18, "Size mismatch for FTournamentTypeWithName");
static_assert(offsetof(FTournamentTypeWithName, Name) == 0x0, "Offset mismatch for FTournamentTypeWithName::Name");
static_assert(offsetof(FTournamentTypeWithName, Type) == 0x10, "Offset mismatch for FTournamentTypeWithName::Type");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FTournamentsFilterSection
{
    FText SectionName; // 0x0 (Size: 0x10, Type: TextProperty)
    TArray<FTournamentTypeWithName> FilterOptions; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bRadioType; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTournamentsFilterSection) == 0x28, "Size mismatch for FTournamentsFilterSection");
static_assert(offsetof(FTournamentsFilterSection, SectionName) == 0x0, "Offset mismatch for FTournamentsFilterSection::SectionName");
static_assert(offsetof(FTournamentsFilterSection, FilterOptions) == 0x10, "Offset mismatch for FTournamentsFilterSection::FilterOptions");
static_assert(offsetof(FTournamentsFilterSection, bRadioType) == 0x20, "Offset mismatch for FTournamentsFilterSection::bRadioType");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FTournamentRequirementItemArguments
{
    uint8_t HabaneroRankCheckResult; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString EULAKey; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t MinimumAccountLevel; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t NumberMatchesPlayed; // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t NumberOfMatchesNeedToBePlayed; // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t SeasonNumber; // 0x24 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FTournamentRequirementItemArguments) == 0x28, "Size mismatch for FTournamentRequirementItemArguments");
static_assert(offsetof(FTournamentRequirementItemArguments, HabaneroRankCheckResult) == 0x0, "Offset mismatch for FTournamentRequirementItemArguments::HabaneroRankCheckResult");
static_assert(offsetof(FTournamentRequirementItemArguments, EULAKey) == 0x8, "Offset mismatch for FTournamentRequirementItemArguments::EULAKey");
static_assert(offsetof(FTournamentRequirementItemArguments, MinimumAccountLevel) == 0x18, "Offset mismatch for FTournamentRequirementItemArguments::MinimumAccountLevel");
static_assert(offsetof(FTournamentRequirementItemArguments, NumberMatchesPlayed) == 0x1c, "Offset mismatch for FTournamentRequirementItemArguments::NumberMatchesPlayed");
static_assert(offsetof(FTournamentRequirementItemArguments, NumberOfMatchesNeedToBePlayed) == 0x20, "Offset mismatch for FTournamentRequirementItemArguments::NumberOfMatchesNeedToBePlayed");
static_assert(offsetof(FTournamentRequirementItemArguments, SeasonNumber) == 0x24, "Offset mismatch for FTournamentRequirementItemArguments::SeasonNumber");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FTournamentRequirementItem
{
    uint8_t RequirementType; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bHasPassed; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    FTournamentRequirementItemArguments Arguments; // 0x8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FTournamentRequirementItem) == 0x30, "Size mismatch for FTournamentRequirementItem");
static_assert(offsetof(FTournamentRequirementItem, RequirementType) == 0x0, "Offset mismatch for FTournamentRequirementItem::RequirementType");
static_assert(offsetof(FTournamentRequirementItem, bHasPassed) == 0x1, "Offset mismatch for FTournamentRequirementItem::bHasPassed");
static_assert(offsetof(FTournamentRequirementItem, Arguments) == 0x8, "Offset mismatch for FTournamentRequirementItem::Arguments");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFortCompeteFrontendNotificationData
{
    FString EventId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString EventWindowId; // 0x10 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FFortCompeteFrontendNotificationData) == 0x30, "Size mismatch for FFortCompeteFrontendNotificationData");
static_assert(offsetof(FFortCompeteFrontendNotificationData, EventId) == 0x0, "Offset mismatch for FFortCompeteFrontendNotificationData::EventId");
static_assert(offsetof(FFortCompeteFrontendNotificationData, EventWindowId) == 0x10, "Offset mismatch for FFortCompeteFrontendNotificationData::EventWindowId");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FTournamentsTilesData
{
    TArray<UFortPoblanoTournamentsCalendarTournamentTileVM*> TournamentTiles; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t PreviouslySelectedEvent; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t FirstUpcomingEvent; // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t FirstLiveEvent; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t FirstCurrentDateEvent; // 0x1c (Size: 0x4, Type: IntProperty)
    bool bIsLoadingTournaments; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTournamentsTilesData) == 0x28, "Size mismatch for FTournamentsTilesData");
static_assert(offsetof(FTournamentsTilesData, TournamentTiles) == 0x0, "Offset mismatch for FTournamentsTilesData::TournamentTiles");
static_assert(offsetof(FTournamentsTilesData, PreviouslySelectedEvent) == 0x10, "Offset mismatch for FTournamentsTilesData::PreviouslySelectedEvent");
static_assert(offsetof(FTournamentsTilesData, FirstUpcomingEvent) == 0x14, "Offset mismatch for FTournamentsTilesData::FirstUpcomingEvent");
static_assert(offsetof(FTournamentsTilesData, FirstLiveEvent) == 0x18, "Offset mismatch for FTournamentsTilesData::FirstLiveEvent");
static_assert(offsetof(FTournamentsTilesData, FirstCurrentDateEvent) == 0x1c, "Offset mismatch for FTournamentsTilesData::FirstCurrentDateEvent");
static_assert(offsetof(FTournamentsTilesData, bIsLoadingTournaments) == 0x20, "Offset mismatch for FTournamentsTilesData::bIsLoadingTournaments");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCalendarTilesData
{
    TArray<UFortPoblanoTournamentsCalendarDayTileVM*> DayTiles; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t FirstDayOfWeekForCurrentMonth; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCalendarTilesData) == 0x18, "Size mismatch for FCalendarTilesData");
static_assert(offsetof(FCalendarTilesData, DayTiles) == 0x0, "Offset mismatch for FCalendarTilesData::DayTiles");
static_assert(offsetof(FCalendarTilesData, FirstDayOfWeekForCurrentMonth) == 0x10, "Offset mismatch for FCalendarTilesData::FirstDayOfWeekForCurrentMonth");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FFortTournamentLeaderboardViewState
{
    TArray<UFortTournamentLeaderboardEntryData*> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortTournamentLeaderboardEntryData*> FilteredEntries; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UFortTournamentLeaderboardEntryData*> LocalPlayerEntry; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_50[0x20]; // 0x50 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FFortTournamentLeaderboardViewState) == 0x70, "Size mismatch for FFortTournamentLeaderboardViewState");
static_assert(offsetof(FFortTournamentLeaderboardViewState, Entries) == 0x10, "Offset mismatch for FFortTournamentLeaderboardViewState::Entries");
static_assert(offsetof(FFortTournamentLeaderboardViewState, FilteredEntries) == 0x20, "Offset mismatch for FFortTournamentLeaderboardViewState::FilteredEntries");
static_assert(offsetof(FFortTournamentLeaderboardViewState, LocalPlayerEntry) == 0x30, "Offset mismatch for FFortTournamentLeaderboardViewState::LocalPlayerEntry");

