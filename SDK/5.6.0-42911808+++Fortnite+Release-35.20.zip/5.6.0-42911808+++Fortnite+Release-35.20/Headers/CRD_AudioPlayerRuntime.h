/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_AudioPlayerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "HarmonixMetasound.h"

// Size: 0x280 (Inherited: 0xe0, Single: 0x1a0)
class UCreativeAudioComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    float StereoSpreadScaleFactor; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0x24]; // 0xc4 (Size: 0x24, Type: PaddingProperty)
    float FadeInDuration; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration; // 0xec (Size: 0x4, Type: FloatProperty)
    bool bSyncPlayerAudio; // 0xf0 (Size: 0x1, Type: BoolProperty)
    bool bRestartAudioOnPlay; // 0xf1 (Size: 0x1, Type: BoolProperty)
    uint8_t CanBeHeardBy; // 0xf2 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayLocation; // 0xf3 (Size: 0x1, Type: EnumProperty)
    uint8_t AutoplayOptions; // 0xf4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_f5[0x2b]; // 0xf5 (Size: 0x2b, Type: PaddingProperty)
    UFortMinigameProgressComponent* FortMinigameProgressComponent; // 0x120 (Size: 0x8, Type: ObjectProperty)
    UCreativeProxyManagerComponent* CreativeProxyManager; // 0x128 (Size: 0x8, Type: ObjectProperty)
    UCreativeRegisteredPlayersManagerComponent* CreativeRegisteredPlayersManagerComponent; // 0x130 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioComponent; // 0x138 (Size: 0x8, Type: ObjectProperty)
    UMusicClockComponent* MusicClockComponent; // 0x140 (Size: 0x8, Type: ObjectProperty)
    TMap<UAudioComponent*, FUniqueNetIdRepl> PlayerAudioComponents; // 0x148 (Size: 0x50, Type: MapProperty)
    ACreativeAudioPlayerReplicationProxy* ClientCachedProxy; // 0x198 (Size: 0x8, Type: ObjectProperty)
    USoundBase* LastSoundPlayed; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    FCreativeAudioPlayerData ServerInstigatorData; // 0x1a8 (Size: 0x40, Type: StructProperty)
    bool bEnabled; // 0x1e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e9[0x27]; // 0x1e9 (Size: 0x27, Type: PaddingProperty)
    bool bAudioLoaded; // 0x210 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_211[0x7]; // 0x211 (Size: 0x7, Type: PaddingProperty)
    FCreativeAudioPlayerData CachedInstigatorData; // 0x218 (Size: 0x40, Type: StructProperty)
    TArray<FUniqueNetIdRepl> RegisteredPlayerIds; // 0x258 (Size: 0x10, Type: ArrayProperty)
    TArray<FUniqueNetIdRepl> NonRegisteredPlayerIds; // 0x268 (Size: 0x10, Type: ArrayProperty)
    uint8_t CurrentAutoplayState; // 0x278 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_279[0x7]; // 0x279 (Size: 0x7, Type: PaddingProperty)

public:
    void OnEnabledStateChanged(bool& bIsEnabled); // 0x9e6e1b8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void PlayAudio(AController*& Player); // 0x6023a08 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void ResetDevice(); // 0x11a85ce8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void SetProperties(const TSoftObjectPtr<USoundBase*> Audio, USoundConcurrency*& ConcurrencySettings, float& const Volume, float& const PlaybackSpeed, float& const NewFadeInDuration, float& const NewFadeOutDuration, bool& const bEnableVolumeAttenuation, bool& const bEnableSpatialization, float& const StereoSpread, EAttenuationDistanceModel& const DistanceModel, float& const AttenuationMinDistance, float& const AttenuationFalloffDistance, bool& const bNewSyncPlayerAudio, bool& const bNewRestartAudioOnPlay, int32_t& const NewCanBeHeardBy, int32_t& const NewPlayLocation, int32_t& NewAutoplayOptions, const FCreativeAudioPlayerMusicClockParams MusicClockParams); // 0x11a86104 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void StopAudio(AController*& Player); // 0x6023a08 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnAllPlayersUnregistered(); // 0x270d644 (Index: 0x0, Flags: Final|Native|Private)
    void OnAudioLoadComplete(FSoftObjectPath& Audio); // 0x11a85a54 (Index: 0x1, Flags: Final|Native|Private|HasDefaults)
    void OnMinigameEnded(); // 0x11a85ce8 (Index: 0x3, Flags: Final|Native|Private)
    void OnMinigameStarted(); // 0x554e3c4 (Index: 0x4, Flags: Final|Native|Private)
    void OnMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& NewMinigameState); // 0xa29d5e0 (Index: 0x5, Flags: Final|Native|Private)
    void OnPlayerAdded(FUniqueNetIdRepl& NetId, bool& bIsLocalPlayer); // 0xd53f100 (Index: 0x6, Flags: Final|Native|Private)
    void OnPlayerRegistered(AFortPlayerState*& const PlayerState); // 0xa7467a0 (Index: 0x7, Flags: Final|Native|Private)
    void OnPlayerRemoved(FUniqueNetIdRepl& NetId, bool& bIsLocalPlayer); // 0x11a85cfc (Index: 0x8, Flags: Final|Native|Private)
    void OnPlayerUnregistered(AFortPlayerState*& const PlayerState); // 0xa95673c (Index: 0x9, Flags: Final|Native|Private)
    void OnProxyDataChanged(ACreativePlayerReplicationProxy*& ProxyData); // 0x11a85e9c (Index: 0xa, Flags: Final|Native|Private)
    void OnRep_RegisteredPlayerIds(); // 0x11a85fc8 (Index: 0xb, Flags: Final|Native|Private)
    void OnRep_ServerInstigatorData(); // 0x11a85fdc (Index: 0xc, Flags: Final|Native|Private)
    void RetryClientPlayAudio(const FCreativeAudioPlayerData InstigatorData); // 0x11a85ff0 (Index: 0xf, Flags: Final|Native|Private|HasOutParms)
    void RetryUpdateAutoplayStatusOnMinigameAdd(AFortMinigame*& Minigame); // 0x6023a08 (Index: 0x10, Flags: Final|Native|Private)
};

static_assert(sizeof(UCreativeAudioComponent) == 0x280, "Size mismatch for UCreativeAudioComponent");
static_assert(offsetof(UCreativeAudioComponent, StereoSpreadScaleFactor) == 0xc0, "Offset mismatch for UCreativeAudioComponent::StereoSpreadScaleFactor");
static_assert(offsetof(UCreativeAudioComponent, FadeInDuration) == 0xe8, "Offset mismatch for UCreativeAudioComponent::FadeInDuration");
static_assert(offsetof(UCreativeAudioComponent, FadeOutDuration) == 0xec, "Offset mismatch for UCreativeAudioComponent::FadeOutDuration");
static_assert(offsetof(UCreativeAudioComponent, bSyncPlayerAudio) == 0xf0, "Offset mismatch for UCreativeAudioComponent::bSyncPlayerAudio");
static_assert(offsetof(UCreativeAudioComponent, bRestartAudioOnPlay) == 0xf1, "Offset mismatch for UCreativeAudioComponent::bRestartAudioOnPlay");
static_assert(offsetof(UCreativeAudioComponent, CanBeHeardBy) == 0xf2, "Offset mismatch for UCreativeAudioComponent::CanBeHeardBy");
static_assert(offsetof(UCreativeAudioComponent, PlayLocation) == 0xf3, "Offset mismatch for UCreativeAudioComponent::PlayLocation");
static_assert(offsetof(UCreativeAudioComponent, AutoplayOptions) == 0xf4, "Offset mismatch for UCreativeAudioComponent::AutoplayOptions");
static_assert(offsetof(UCreativeAudioComponent, FortMinigameProgressComponent) == 0x120, "Offset mismatch for UCreativeAudioComponent::FortMinigameProgressComponent");
static_assert(offsetof(UCreativeAudioComponent, CreativeProxyManager) == 0x128, "Offset mismatch for UCreativeAudioComponent::CreativeProxyManager");
static_assert(offsetof(UCreativeAudioComponent, CreativeRegisteredPlayersManagerComponent) == 0x130, "Offset mismatch for UCreativeAudioComponent::CreativeRegisteredPlayersManagerComponent");
static_assert(offsetof(UCreativeAudioComponent, AudioComponent) == 0x138, "Offset mismatch for UCreativeAudioComponent::AudioComponent");
static_assert(offsetof(UCreativeAudioComponent, MusicClockComponent) == 0x140, "Offset mismatch for UCreativeAudioComponent::MusicClockComponent");
static_assert(offsetof(UCreativeAudioComponent, PlayerAudioComponents) == 0x148, "Offset mismatch for UCreativeAudioComponent::PlayerAudioComponents");
static_assert(offsetof(UCreativeAudioComponent, ClientCachedProxy) == 0x198, "Offset mismatch for UCreativeAudioComponent::ClientCachedProxy");
static_assert(offsetof(UCreativeAudioComponent, LastSoundPlayed) == 0x1a0, "Offset mismatch for UCreativeAudioComponent::LastSoundPlayed");
static_assert(offsetof(UCreativeAudioComponent, ServerInstigatorData) == 0x1a8, "Offset mismatch for UCreativeAudioComponent::ServerInstigatorData");
static_assert(offsetof(UCreativeAudioComponent, bEnabled) == 0x1e8, "Offset mismatch for UCreativeAudioComponent::bEnabled");
static_assert(offsetof(UCreativeAudioComponent, bAudioLoaded) == 0x210, "Offset mismatch for UCreativeAudioComponent::bAudioLoaded");
static_assert(offsetof(UCreativeAudioComponent, CachedInstigatorData) == 0x218, "Offset mismatch for UCreativeAudioComponent::CachedInstigatorData");
static_assert(offsetof(UCreativeAudioComponent, RegisteredPlayerIds) == 0x258, "Offset mismatch for UCreativeAudioComponent::RegisteredPlayerIds");
static_assert(offsetof(UCreativeAudioComponent, NonRegisteredPlayerIds) == 0x268, "Offset mismatch for UCreativeAudioComponent::NonRegisteredPlayerIds");
static_assert(offsetof(UCreativeAudioComponent, CurrentAutoplayState) == 0x278, "Offset mismatch for UCreativeAudioComponent::CurrentAutoplayState");

// Size: 0x2f8 (Inherited: 0x830, Single: 0xfffffac8)
class ACreativeAudioPlayerReplicationProxy : public ACreativePlayerReplicationProxy
{
public:
    FCreativeAudioPlayerData InstigatorData; // 0x2b8 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(ACreativeAudioPlayerReplicationProxy) == 0x2f8, "Size mismatch for ACreativeAudioPlayerReplicationProxy");
static_assert(offsetof(ACreativeAudioPlayerReplicationProxy, InstigatorData) == 0x2b8, "Offset mismatch for ACreativeAudioPlayerReplicationProxy::InstigatorData");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FCreativeAudioPlayerData
{
    FUniqueNetIdRepl NetId; // 0x0 (Size: 0x30, Type: StructProperty)
    APawn* Pawn; // 0x30 (Size: 0x8, Type: ObjectProperty)
    float ServerAudioStartTime; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCreativeAudioPlayerData) == 0x40, "Size mismatch for FCreativeAudioPlayerData");
static_assert(offsetof(FCreativeAudioPlayerData, NetId) == 0x0, "Offset mismatch for FCreativeAudioPlayerData::NetId");
static_assert(offsetof(FCreativeAudioPlayerData, Pawn) == 0x30, "Offset mismatch for FCreativeAudioPlayerData::Pawn");
static_assert(offsetof(FCreativeAudioPlayerData, ServerAudioStartTime) == 0x38, "Offset mismatch for FCreativeAudioPlayerData::ServerAudioStartTime");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCreativeAudioPlayerMusicClockParams
{
    bool bConnectToMetaSoundClock; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bRegisterWithMusicEventSubsystem; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FGameplayTag MusicEventSubsystemEventTag; // 0x4 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer MusicEventSubsystemBehaviorTags; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FCreativeAudioPlayerMusicClockParams) == 0x28, "Size mismatch for FCreativeAudioPlayerMusicClockParams");
static_assert(offsetof(FCreativeAudioPlayerMusicClockParams, bConnectToMetaSoundClock) == 0x0, "Offset mismatch for FCreativeAudioPlayerMusicClockParams::bConnectToMetaSoundClock");
static_assert(offsetof(FCreativeAudioPlayerMusicClockParams, bRegisterWithMusicEventSubsystem) == 0x1, "Offset mismatch for FCreativeAudioPlayerMusicClockParams::bRegisterWithMusicEventSubsystem");
static_assert(offsetof(FCreativeAudioPlayerMusicClockParams, MusicEventSubsystemEventTag) == 0x4, "Offset mismatch for FCreativeAudioPlayerMusicClockParams::MusicEventSubsystemEventTag");
static_assert(offsetof(FCreativeAudioPlayerMusicClockParams, MusicEventSubsystemBehaviorTags) == 0x8, "Offset mismatch for FCreativeAudioPlayerMusicClockParams::MusicEventSubsystemBehaviorTags");

