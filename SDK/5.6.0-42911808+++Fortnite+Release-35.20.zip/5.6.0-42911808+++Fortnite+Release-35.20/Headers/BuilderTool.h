/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BuilderTool
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "ItemizationCoreRuntime.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"
#include "EnhancedInput.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBuilderToolSelectedActorInterface : public UInterface
{
public:

public:
    virtual void ReceiveSpawnedByBuilderTool(ABuilderTool*& BuilderTool, UBuilderToolBehavior*& Behavior); // 0x10aaf49c (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UBuilderToolSelectedActorInterface) == 0x28, "Size mismatch for UBuilderToolSelectedActorInterface");

// Size: 0x1a40 (Inherited: 0x1c90, Single: 0xfffffdb0)
class ABuilderTool : public AFortWeapon
{
public:
    uint8_t OnInteractionStarted[0x10]; // 0x19c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInteractionStopped[0x10]; // 0x19d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UInputMappingContext* InputMappingContext; // 0x19e0 (Size: 0x8, Type: ObjectProperty)
    int32_t InputMappingPriority; // 0x19e8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_19ec[0x4]; // 0x19ec (Size: 0x4, Type: PaddingProperty)
    UInputAction* UnEquipInputAction; // 0x19f0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer ActivatedTags; // 0x19f8 (Size: 0x20, Type: StructProperty)
    TArray<UBuilderToolBehavior*> Behaviors; // 0x1a18 (Size: 0x10, Type: ArrayProperty)
    UBuilderToolBehavior* ActiveBehavior; // 0x1a28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1a30[0x10]; // 0x1a30 (Size: 0x10, Type: PaddingProperty)

public:
    void ExitInteraction(); // 0x10aae7e4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UBuilderToolBehavior* GetActiveBehavior() const; // 0x10aae920 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FBuilderToolSelectedActor> GetSelectedActors() const; // 0x10aaeb58 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGuid GetSelectionGUID() const; // 0x10aaec1c (Index: 0x5, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsRunningOnOwningClient() const; // 0x10aaeccc (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RequestInteraction(const TArray<FBuilderToolSoftSelectedActor> SelectedActors, const FGuid SelectionGUID); // 0x10aaf6a4 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void RequestInteractionWithActor(AActor*& const Actor, const FGuid SelectionGUID); // 0x10aafbe0 (Index: 0xc, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void RequestInteractionWithClass(const TSoftClassPtr ActorClass, const FGuid SelectionGUID); // 0x10aafdb0 (Index: 0xd, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)

private:
    virtual void ClientStartInteraction(UBuilderToolBehavior*& Behavior, TArray<FBuilderToolSoftSelectedActor>& const SelectedActors, FGuid& const SelectionGUID); // 0x10aae320 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|HasDefaults|NetClient)
    virtual void ClientStopInteraction(bool& const bIsExiting); // 0x10aae5b4 (Index: 0x1, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void MulticastClearInteractionOnRemoteClients(); // 0xd03d970 (Index: 0x7, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
    virtual void MulticastStartInteractionOnRemoteClients(UBuilderToolBehavior*& Behavior, TArray<FBuilderToolSoftSelectedActor>& const SelectedActors, FGuid& const SelectionGUID); // 0x10aaed14 (Index: 0x8, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private|HasDefaults)
    virtual void ServerClearInteraction(bool& const bExited); // 0x10ab0418 (Index: 0xe, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerStartInteraction(TArray<FBuilderToolSoftSelectedActor>& const SelectedActors, FGuid& const SelectionGUID); // 0x10ab0938 (Index: 0xf, Flags: Final|Net|NetReliableNative|Event|Private|NetServer|HasDefaults)

protected:
    virtual void ReceiveInteractionEnded(UBuilderToolBehavior*& Behavior); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveInteractionStarted(UBuilderToolBehavior*& Behavior); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABuilderTool) == 0x1a40, "Size mismatch for ABuilderTool");
static_assert(offsetof(ABuilderTool, OnInteractionStarted) == 0x19c0, "Offset mismatch for ABuilderTool::OnInteractionStarted");
static_assert(offsetof(ABuilderTool, OnInteractionStopped) == 0x19d0, "Offset mismatch for ABuilderTool::OnInteractionStopped");
static_assert(offsetof(ABuilderTool, InputMappingContext) == 0x19e0, "Offset mismatch for ABuilderTool::InputMappingContext");
static_assert(offsetof(ABuilderTool, InputMappingPriority) == 0x19e8, "Offset mismatch for ABuilderTool::InputMappingPriority");
static_assert(offsetof(ABuilderTool, UnEquipInputAction) == 0x19f0, "Offset mismatch for ABuilderTool::UnEquipInputAction");
static_assert(offsetof(ABuilderTool, ActivatedTags) == 0x19f8, "Offset mismatch for ABuilderTool::ActivatedTags");
static_assert(offsetof(ABuilderTool, Behaviors) == 0x1a18, "Offset mismatch for ABuilderTool::Behaviors");
static_assert(offsetof(ABuilderTool, ActiveBehavior) == 0x1a28, "Offset mismatch for ABuilderTool::ActiveBehavior");

// Size: 0x270 (Inherited: 0xe0, Single: 0x190)
class UBuilderToolBehavior : public UActorComponent
{
public:
    uint8_t OnInteractionStart[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInteractionTrigger[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInteractionEnd[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInteractionExit[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bShouldAddToParent; // 0xf8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f9[0x3]; // 0xf9 (Size: 0x3, Type: PaddingProperty)
    int32_t Priority; // 0xfc (Size: 0x4, Type: IntProperty)
    FDataTableRowHandle ConfigData; // 0x100 (Size: 0x10, Type: StructProperty)
    FGameplayTagContainer ActivatedTags; // 0x110 (Size: 0x20, Type: StructProperty)
    UInputMappingContext* InputMappingContext; // 0x130 (Size: 0x8, Type: ObjectProperty)
    int32_t InputMappingPriority; // 0x138 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
    UInputAction* TriggerInputAction; // 0x140 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ExitInputAction; // 0x148 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_150[0x10]; // 0x150 (Size: 0x10, Type: PaddingProperty)
    UClass* StartInteractionAbility; // 0x160 (Size: 0x8, Type: ClassProperty)
    UClass* EndInteractionAbility; // 0x168 (Size: 0x8, Type: ClassProperty)
    UClass* FailAbility; // 0x170 (Size: 0x8, Type: ClassProperty)
    UClass* ExitAbility; // 0x178 (Size: 0x8, Type: ClassProperty)
    FBuilderToolActorClassSet SupportedClasses; // 0x180 (Size: 0xa0, Type: StructProperty)
    TArray<FBuilderToolSelectedActor> SelectedActors; // 0x220 (Size: 0x10, Type: ArrayProperty)
    FGuid SelectionGUID; // 0x230 (Size: 0x10, Type: StructProperty)
    TArray<FBuilderToolTimedActors> ClientPredictedActors; // 0x240 (Size: 0x10, Type: ArrayProperty)
    TArray<FBuilderToolSpawnedSelection> ServerSpawnedSelections; // 0x250 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_260[0x10]; // 0x260 (Size: 0x10, Type: PaddingProperty)

public:
    ABuilderTool* GetBuilderTool() const; // 0x10aae96c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFortPlayerController* GetFortPlayerController() const; // 0x10aaeaec (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    APawn* GetInstigator() const; // 0x10aaeb10 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    APlayerController* GetPlayerController() const; // 0x10aaeb34 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FBuilderToolSelectedActor> GetSelectedActors() const; // 0x10aaec00 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGuid GetSelectionGUID() const; // 0x10aaec44 (Index: 0x6, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool HasAuthority() const; // 0x10aaec60 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsActiveBehavior() const; // 0x10aaec80 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRunningOnOwningClient() const; // 0x10aaecf0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PlayGameplayAbility(UClass*& const AbilityClass); // 0x10aaf1c8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ReceiveClearInteractionOnRemoteClient(); // 0x288a61c (Index: 0xc, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveEndInteraction(); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveExitInteraction(); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveStartInteractionOnClient(const TArray<FBuilderToolSelectedActor> Actors, const FGuid Guid); // 0x288a61c (Index: 0x11, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void ReceiveStartInteractionOnRemoteClient(const TArray<FBuilderToolSelectedActor> Actors, const FGuid Guid); // 0x288a61c (Index: 0x12, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void ReceiveStartInteractionOnServer(const TArray<FBuilderToolSelectedActor> Actors, const FGuid Guid); // 0x288a61c (Index: 0x13, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void ReceiveTickInteraction(); // 0x288a61c (Index: 0x14, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveTriggerInteraction(); // 0x288a61c (Index: 0x15, Flags: Event|Public|BlueprintEvent)

private:
    virtual void ClientOnServerSpawnSelectedActorsFailed(int32_t& const SpawnID, TArray<FName>& const FailedNames); // 0x10aadf50 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    void OnRep_ServerSpawnedSelection(); // 0x10aaf1b4 (Index: 0xa, Flags: Final|Native|Private)
    virtual void ServerOnSpawnedActorProcessedByClient(TArray<FName>& const Names); // 0x10ab0544 (Index: 0x16, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)

protected:
    virtual void ReceiveSpawnedActor(AActor*& SpawnedActor); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveSpawnedSelection(const FBuilderToolSpawnedSelection Selection); // 0x288a61c (Index: 0x10, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void ServerSpawnSelectedActors(FBuilderToolSelectionSpawnParams& const Params); // 0x10ab0838 (Index: 0x17, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(UBuilderToolBehavior) == 0x270, "Size mismatch for UBuilderToolBehavior");
static_assert(offsetof(UBuilderToolBehavior, OnInteractionStart) == 0xb8, "Offset mismatch for UBuilderToolBehavior::OnInteractionStart");
static_assert(offsetof(UBuilderToolBehavior, OnInteractionTrigger) == 0xc8, "Offset mismatch for UBuilderToolBehavior::OnInteractionTrigger");
static_assert(offsetof(UBuilderToolBehavior, OnInteractionEnd) == 0xd8, "Offset mismatch for UBuilderToolBehavior::OnInteractionEnd");
static_assert(offsetof(UBuilderToolBehavior, OnInteractionExit) == 0xe8, "Offset mismatch for UBuilderToolBehavior::OnInteractionExit");
static_assert(offsetof(UBuilderToolBehavior, bShouldAddToParent) == 0xf8, "Offset mismatch for UBuilderToolBehavior::bShouldAddToParent");
static_assert(offsetof(UBuilderToolBehavior, Priority) == 0xfc, "Offset mismatch for UBuilderToolBehavior::Priority");
static_assert(offsetof(UBuilderToolBehavior, ConfigData) == 0x100, "Offset mismatch for UBuilderToolBehavior::ConfigData");
static_assert(offsetof(UBuilderToolBehavior, ActivatedTags) == 0x110, "Offset mismatch for UBuilderToolBehavior::ActivatedTags");
static_assert(offsetof(UBuilderToolBehavior, InputMappingContext) == 0x130, "Offset mismatch for UBuilderToolBehavior::InputMappingContext");
static_assert(offsetof(UBuilderToolBehavior, InputMappingPriority) == 0x138, "Offset mismatch for UBuilderToolBehavior::InputMappingPriority");
static_assert(offsetof(UBuilderToolBehavior, TriggerInputAction) == 0x140, "Offset mismatch for UBuilderToolBehavior::TriggerInputAction");
static_assert(offsetof(UBuilderToolBehavior, ExitInputAction) == 0x148, "Offset mismatch for UBuilderToolBehavior::ExitInputAction");
static_assert(offsetof(UBuilderToolBehavior, StartInteractionAbility) == 0x160, "Offset mismatch for UBuilderToolBehavior::StartInteractionAbility");
static_assert(offsetof(UBuilderToolBehavior, EndInteractionAbility) == 0x168, "Offset mismatch for UBuilderToolBehavior::EndInteractionAbility");
static_assert(offsetof(UBuilderToolBehavior, FailAbility) == 0x170, "Offset mismatch for UBuilderToolBehavior::FailAbility");
static_assert(offsetof(UBuilderToolBehavior, ExitAbility) == 0x178, "Offset mismatch for UBuilderToolBehavior::ExitAbility");
static_assert(offsetof(UBuilderToolBehavior, SupportedClasses) == 0x180, "Offset mismatch for UBuilderToolBehavior::SupportedClasses");
static_assert(offsetof(UBuilderToolBehavior, SelectedActors) == 0x220, "Offset mismatch for UBuilderToolBehavior::SelectedActors");
static_assert(offsetof(UBuilderToolBehavior, SelectionGUID) == 0x230, "Offset mismatch for UBuilderToolBehavior::SelectionGUID");
static_assert(offsetof(UBuilderToolBehavior, ClientPredictedActors) == 0x240, "Offset mismatch for UBuilderToolBehavior::ClientPredictedActors");
static_assert(offsetof(UBuilderToolBehavior, ServerSpawnedSelections) == 0x250, "Offset mismatch for UBuilderToolBehavior::ServerSpawnedSelections");

// Size: 0xa8 (Inherited: 0x288, Single: 0xfffffe20)
class UBuilderToolItemDefinition : public UFortWorldItemDefinition
{
public:

public:
    TSoftClassPtr GetActorClass() const; // 0x10aae938 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBuilderToolItemDefinition) == 0xa8, "Size mismatch for UBuilderToolItemDefinition");

// Size: 0x100 (Inherited: 0x310, Single: 0xfffffdf0)
class UBuilderToolPlayerComponent : public UFortControllerComponent
{
public:
    UFortWeaponItemDefinition* BuilderToolWeaponItemDefinition; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0x38]; // 0xc8 (Size: 0x38, Type: PaddingProperty)

public:
    void EquipBuilderTool(const FDelegate OnEquipped); // 0x10aae6e4 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    static UBuilderToolPlayerComponent* Get(AFortPlayerController*& const PlayerController); // 0x10aae7f8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    ABuilderTool* GetBuilderTool() const; // 0x10aae990 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static ABuilderTool* GetBuilderToolFromPlayer(AFortPlayerController*& const FortPlayerController); // 0x10aae9b4 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    void RequestInteraction(const TArray<FBuilderToolSoftSelectedActor> SelectedActors, const FGuid Guid); // 0x10aaf824 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void RequestInteractionForPlayer(AFortPlayerController*& const FortPC, const TArray<FBuilderToolSoftSelectedActor> SelectedActors, const FGuid Guid); // 0x10aaf9a4 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void RequestInteractionWithItem(UFortItem*& const Item); // 0x10ab00e0 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    static void RequestInteractionWithItemForPlayer(AFortPlayerController*& const FortPC, UFortItem*& const Item); // 0x10ab020c (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool TryEquipBuilderTool(AFortPlayerController*& const AFortPlayerController, const FDelegate OnEquipped); // 0x10ab0b04 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)

protected:
    void OnBuilderToolUnEquipped(AFortWeapon*& Weapon); // 0x10112284 (Index: 0x4, Flags: RequiredAPI|Native|Protected)
    void OnEndInteraction(ABuilderTool*& const BuilderTool, UBuilderToolBehavior*& const Behavior); // 0x10aaefa8 (Index: 0x5, Flags: RequiredAPI|Native|Protected)
    void OnStartInteraction(ABuilderTool*& const BuilderTool, UBuilderToolBehavior*& const Behavior); // 0x10111d4c (Index: 0x6, Flags: RequiredAPI|Native|Protected)
    void OnWeaponEquipped(AFortWeapon*& const NewWeapon, AFortWeapon*& const PrevWeapon); // 0xfa4e1f0 (Index: 0x7, Flags: RequiredAPI|Native|Protected)
    virtual void ReceiveBuilderToolEquipped(ABuilderTool*& BuilderTool); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBuilderToolUnEquipped(ABuilderTool*& BuilderTool); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveEndInteraction(ABuilderTool*& BuilderTool, UBuilderToolBehavior*& Behavior); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveStartInteraction(ABuilderTool*& BuilderTool, UBuilderToolBehavior*& Behavior); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBuilderToolPlayerComponent) == 0x100, "Size mismatch for UBuilderToolPlayerComponent");
static_assert(offsetof(UBuilderToolPlayerComponent, BuilderToolWeaponItemDefinition) == 0xc0, "Offset mismatch for UBuilderToolPlayerComponent::BuilderToolWeaponItemDefinition");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBuilderToolItemDisplayData
{
    uint8_t ItemType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FText DisplayName; // 0x8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription; // 0x18 (Size: 0x10, Type: TextProperty)
    FText Description; // 0x28 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FBuilderToolItemDisplayData) == 0x38, "Size mismatch for FBuilderToolItemDisplayData");
static_assert(offsetof(FBuilderToolItemDisplayData, ItemType) == 0x0, "Offset mismatch for FBuilderToolItemDisplayData::ItemType");
static_assert(offsetof(FBuilderToolItemDisplayData, DisplayName) == 0x8, "Offset mismatch for FBuilderToolItemDisplayData::DisplayName");
static_assert(offsetof(FBuilderToolItemDisplayData, ShortDescription) == 0x18, "Offset mismatch for FBuilderToolItemDisplayData::ShortDescription");
static_assert(offsetof(FBuilderToolItemDisplayData, Description) == 0x28, "Offset mismatch for FBuilderToolItemDisplayData::Description");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FBuilderToolSelectedActor
{
    UClass* Class; // 0x0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<AActor*> Actor; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    FTransform ToSelection; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FBuilderToolSelectedActor) == 0x70, "Size mismatch for FBuilderToolSelectedActor");
static_assert(offsetof(FBuilderToolSelectedActor, Class) == 0x0, "Offset mismatch for FBuilderToolSelectedActor::Class");
static_assert(offsetof(FBuilderToolSelectedActor, Actor) == 0x8, "Offset mismatch for FBuilderToolSelectedActor::Actor");
static_assert(offsetof(FBuilderToolSelectedActor, ToSelection) == 0x10, "Offset mismatch for FBuilderToolSelectedActor::ToSelection");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FBuilderToolSoftSelectedActor
{
    TSoftClassPtr Class; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    TWeakObjectPtr<AActor*> Actor; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform ToSelection; // 0x30 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FBuilderToolSoftSelectedActor) == 0x90, "Size mismatch for FBuilderToolSoftSelectedActor");
static_assert(offsetof(FBuilderToolSoftSelectedActor, Class) == 0x0, "Offset mismatch for FBuilderToolSoftSelectedActor::Class");
static_assert(offsetof(FBuilderToolSoftSelectedActor, Actor) == 0x20, "Offset mismatch for FBuilderToolSoftSelectedActor::Actor");
static_assert(offsetof(FBuilderToolSoftSelectedActor, ToSelection) == 0x30, "Offset mismatch for FBuilderToolSoftSelectedActor::ToSelection");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FBuilderToolActorClassSet
{
    TSet<TSoftClassPtr> Classes; // 0x0 (Size: 0x50, Type: SetProperty)
    TSet<TSoftClassPtr> ExcludedSubclasses; // 0x50 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FBuilderToolActorClassSet) == 0xa0, "Size mismatch for FBuilderToolActorClassSet");
static_assert(offsetof(FBuilderToolActorClassSet, Classes) == 0x0, "Offset mismatch for FBuilderToolActorClassSet::Classes");
static_assert(offsetof(FBuilderToolActorClassSet, ExcludedSubclasses) == 0x50, "Offset mismatch for FBuilderToolActorClassSet::ExcludedSubclasses");

// Size: 0xa8 (Inherited: 0x8, Single: 0xa0)
struct FBuilderToolBehaviorRow : FTableRowBase
{
    FBuilderToolActorClassSet SupportedClasses; // 0x8 (Size: 0xa0, Type: StructProperty)
};

static_assert(sizeof(FBuilderToolBehaviorRow) == 0xa8, "Size mismatch for FBuilderToolBehaviorRow");
static_assert(offsetof(FBuilderToolBehaviorRow, SupportedClasses) == 0x8, "Offset mismatch for FBuilderToolBehaviorRow::SupportedClasses");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBuilderToolSupportActorComponentPair
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* Component; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBuilderToolSupportActorComponentPair) == 0x10, "Size mismatch for FBuilderToolSupportActorComponentPair");
static_assert(offsetof(FBuilderToolSupportActorComponentPair, Actor) == 0x0, "Offset mismatch for FBuilderToolSupportActorComponentPair::Actor");
static_assert(offsetof(FBuilderToolSupportActorComponentPair, Component) == 0x8, "Offset mismatch for FBuilderToolSupportActorComponentPair::Component");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBuilderToolSupportCandidate
{
    TWeakObjectPtr<AActor*> Actor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPrimitiveComponent*> Component; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FBuilderToolSupportCandidate) == 0x10, "Size mismatch for FBuilderToolSupportCandidate");
static_assert(offsetof(FBuilderToolSupportCandidate, Actor) == 0x0, "Offset mismatch for FBuilderToolSupportCandidate::Actor");
static_assert(offsetof(FBuilderToolSupportCandidate, Component) == 0x8, "Offset mismatch for FBuilderToolSupportCandidate::Component");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FBuilderToolSelectionSpawnParams
{
    int32_t SpawnID; // 0x0 (Size: 0x4, Type: IntProperty)
    FGuid SelectionGUID; // 0x4 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FBuilderToolSoftSelectedActor> SelectedActors; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform SelectionTransform; // 0x30 (Size: 0x60, Type: StructProperty)
    APawn* Instigator; // 0x90 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> StableNames; // 0x98 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FBuilderToolSelectionSpawnParams) == 0xb0, "Size mismatch for FBuilderToolSelectionSpawnParams");
static_assert(offsetof(FBuilderToolSelectionSpawnParams, SpawnID) == 0x0, "Offset mismatch for FBuilderToolSelectionSpawnParams::SpawnID");
static_assert(offsetof(FBuilderToolSelectionSpawnParams, SelectionGUID) == 0x4, "Offset mismatch for FBuilderToolSelectionSpawnParams::SelectionGUID");
static_assert(offsetof(FBuilderToolSelectionSpawnParams, SelectedActors) == 0x18, "Offset mismatch for FBuilderToolSelectionSpawnParams::SelectedActors");
static_assert(offsetof(FBuilderToolSelectionSpawnParams, SelectionTransform) == 0x30, "Offset mismatch for FBuilderToolSelectionSpawnParams::SelectionTransform");
static_assert(offsetof(FBuilderToolSelectionSpawnParams, Instigator) == 0x90, "Offset mismatch for FBuilderToolSelectionSpawnParams::Instigator");
static_assert(offsetof(FBuilderToolSelectionSpawnParams, StableNames) == 0x98, "Offset mismatch for FBuilderToolSelectionSpawnParams::StableNames");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBuilderToolTimedActors
{
    TArray<TWeakObjectPtr<AActor*>> Actors; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FBuilderToolTimedActors) == 0x18, "Size mismatch for FBuilderToolTimedActors");
static_assert(offsetof(FBuilderToolTimedActors, Actors) == 0x0, "Offset mismatch for FBuilderToolTimedActors::Actors");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FBuilderToolSpawnedActor
{
    TWeakObjectPtr<AActor*> Actor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FName StableName; // 0x8 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FBuilderToolSpawnedActor) == 0xc, "Size mismatch for FBuilderToolSpawnedActor");
static_assert(offsetof(FBuilderToolSpawnedActor, Actor) == 0x0, "Offset mismatch for FBuilderToolSpawnedActor::Actor");
static_assert(offsetof(FBuilderToolSpawnedActor, StableName) == 0x8, "Offset mismatch for FBuilderToolSpawnedActor::StableName");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBuilderToolSpawnedSelection
{
    int32_t SpawnID; // 0x0 (Size: 0x4, Type: IntProperty)
    FGuid Guid; // 0x4 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FBuilderToolSpawnedActor> Actors; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBuilderToolSpawnedSelection) == 0x28, "Size mismatch for FBuilderToolSpawnedSelection");
static_assert(offsetof(FBuilderToolSpawnedSelection, SpawnID) == 0x0, "Offset mismatch for FBuilderToolSpawnedSelection::SpawnID");
static_assert(offsetof(FBuilderToolSpawnedSelection, Guid) == 0x4, "Offset mismatch for FBuilderToolSpawnedSelection::Guid");
static_assert(offsetof(FBuilderToolSpawnedSelection, Actors) == 0x18, "Offset mismatch for FBuilderToolSpawnedSelection::Actors");

// Size: 0x20 (Inherited: 0x1, Single: 0x1f)
struct FItemComponentData_BuilderTool : FItemComponentData
{
    TSoftClassPtr ActorClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FItemComponentData_BuilderTool) == 0x20, "Size mismatch for FItemComponentData_BuilderTool");
static_assert(offsetof(FItemComponentData_BuilderTool, ActorClass) == 0x0, "Offset mismatch for FItemComponentData_BuilderTool::ActorClass");

