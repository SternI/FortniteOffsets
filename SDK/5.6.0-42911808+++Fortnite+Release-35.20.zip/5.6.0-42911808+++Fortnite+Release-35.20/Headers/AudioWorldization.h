/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioWorldization
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "AudioGameplayVolume.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "AudioGameplay.h"
#include "GameFeatures.h"
#include "GameplayTags.h"
#include "AudioExtensions.h"
#include "AudioModulation.h"

// Size: 0x300 (Inherited: 0x2d0, Single: 0x30)
class AAudioWorldizationReflectionProbe : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    USubmixSendVolumeComponent* SubmixSends; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USubmixOverrideVolumeComponent* SubmixEffects; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UAudioGameplayVolumeComponent* AGVComponent; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c8[0x38]; // 0x2c8 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(AAudioWorldizationReflectionProbe) == 0x300, "Size mismatch for AAudioWorldizationReflectionProbe");
static_assert(offsetof(AAudioWorldizationReflectionProbe, SubmixSends) == 0x2b0, "Offset mismatch for AAudioWorldizationReflectionProbe::SubmixSends");
static_assert(offsetof(AAudioWorldizationReflectionProbe, SubmixEffects) == 0x2b8, "Offset mismatch for AAudioWorldizationReflectionProbe::SubmixEffects");
static_assert(offsetof(AAudioWorldizationReflectionProbe, AGVComponent) == 0x2c0, "Offset mismatch for AAudioWorldizationReflectionProbe::AGVComponent");

// Size: 0xe0 (Inherited: 0x268, Single: 0xfffffe78)
class UAudioWorldizationSendsVolumeComponent : public UAudioGameplayVolumeComponentBase
{
public:
    FName Identifier; // 0xc8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    TArray<FAudioWorldizationSend> Sends; // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAudioWorldizationSendsVolumeComponent) == 0xe0, "Size mismatch for UAudioWorldizationSendsVolumeComponent");
static_assert(offsetof(UAudioWorldizationSendsVolumeComponent, Identifier) == 0xc8, "Offset mismatch for UAudioWorldizationSendsVolumeComponent::Identifier");
static_assert(offsetof(UAudioWorldizationSendsVolumeComponent, Sends) == 0xd0, "Offset mismatch for UAudioWorldizationSendsVolumeComponent::Sends");

// Size: 0xb0 (Inherited: 0x58, Single: 0x58)
class UAudioWorldizationData : public UDataAsset
{
public:
    FAudioWorldizationSettings Settings; // 0x30 (Size: 0x80, Type: StructProperty)
};

static_assert(sizeof(UAudioWorldizationData) == 0xb0, "Size mismatch for UAudioWorldizationData");
static_assert(offsetof(UAudioWorldizationData, Settings) == 0x30, "Offset mismatch for UAudioWorldizationData::Settings");

// Size: 0xf0 (Inherited: 0x58, Single: 0x98)
class UAudioWorldizationDefaultSettings : public UDeveloperSettings
{
public:
    FAudioWorldizationGlobalSettings GlobalSettings; // 0x30 (Size: 0x30, Type: StructProperty)
    FAudioWorldizationSettings DefaultSettings; // 0x60 (Size: 0x80, Type: StructProperty)
    TArray<FSoftObjectPath> ModulationParameters; // 0xe0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAudioWorldizationDefaultSettings) == 0xf0, "Size mismatch for UAudioWorldizationDefaultSettings");
static_assert(offsetof(UAudioWorldizationDefaultSettings, GlobalSettings) == 0x30, "Offset mismatch for UAudioWorldizationDefaultSettings::GlobalSettings");
static_assert(offsetof(UAudioWorldizationDefaultSettings, DefaultSettings) == 0x60, "Offset mismatch for UAudioWorldizationDefaultSettings::DefaultSettings");
static_assert(offsetof(UAudioWorldizationDefaultSettings, ModulationParameters) == 0xe0, "Offset mismatch for UAudioWorldizationDefaultSettings::ModulationParameters");

// Size: 0x470 (Inherited: 0xc8, Single: 0x3a8)
class UAudioWorldizationSubsystem : public UTickableWorldSubsystem
{
public:
    USoundControlBus* EnclosureBus; // 0x40 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* WallDistanceBus; // 0x48 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ListenerAzimuthBus; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    FAudioWorldizationSettings CurrentSettings; // 0x60 (Size: 0x80, Type: StructProperty)
    AAudioWorldizationReflectionProbe* VolumeActor; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UAudioWorldizationTracePolicyBase* TracePolicy; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAudioWorldizationTraceDirectionPolicyBase* TraceDirectionPolicy; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_f8[0x2e8]; // 0xf8 (Size: 0x2e8, Type: PaddingProperty)
    TArray<FAudioWorldizationSettings> SettingsStack; // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundControlBus*> QuadrantEnclosureBuses; // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundControlBus*> QuadrantWallDistanceBuses; // 0x400 (Size: 0x10, Type: ArrayProperty)
    FTransform CachedTraceOrigin; // 0x410 (Size: 0x60, Type: StructProperty)

public:
    TMap<int32_t, FGameplayTag> GetActorTagCounts(); // 0xc9acc40 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FGameplayTagContainer GetActorTags(); // 0xc9accb4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    float GetEnclosureFactor() const; // 0xc9accf8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetWallDistanceRatio() const; // 0xc9acd20 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OverrideEffectSends(FName& InIdentifier, const TArray<FAudioWorldizationSend> InSends); // 0xc9acd48 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveEffectSendOverride(FName& InIdentifier); // 0xc9acf08 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveWorldizationSettings(FName& const InIdentifier); // 0xc9ad030 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetDefaultSettings(); // 0xc9ad158 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetEnabled(bool& bNewEnabled); // 0xc9ad16c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetWorldizationSettings(const FAudioWorldizationSettings InSettings); // 0xc9ad298 (Index: 0x9, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAudioWorldizationSubsystem) == 0x470, "Size mismatch for UAudioWorldizationSubsystem");
static_assert(offsetof(UAudioWorldizationSubsystem, EnclosureBus) == 0x40, "Offset mismatch for UAudioWorldizationSubsystem::EnclosureBus");
static_assert(offsetof(UAudioWorldizationSubsystem, WallDistanceBus) == 0x48, "Offset mismatch for UAudioWorldizationSubsystem::WallDistanceBus");
static_assert(offsetof(UAudioWorldizationSubsystem, ListenerAzimuthBus) == 0x50, "Offset mismatch for UAudioWorldizationSubsystem::ListenerAzimuthBus");
static_assert(offsetof(UAudioWorldizationSubsystem, CurrentSettings) == 0x60, "Offset mismatch for UAudioWorldizationSubsystem::CurrentSettings");
static_assert(offsetof(UAudioWorldizationSubsystem, VolumeActor) == 0xe0, "Offset mismatch for UAudioWorldizationSubsystem::VolumeActor");
static_assert(offsetof(UAudioWorldizationSubsystem, TracePolicy) == 0xe8, "Offset mismatch for UAudioWorldizationSubsystem::TracePolicy");
static_assert(offsetof(UAudioWorldizationSubsystem, TraceDirectionPolicy) == 0xf0, "Offset mismatch for UAudioWorldizationSubsystem::TraceDirectionPolicy");
static_assert(offsetof(UAudioWorldizationSubsystem, SettingsStack) == 0x3e0, "Offset mismatch for UAudioWorldizationSubsystem::SettingsStack");
static_assert(offsetof(UAudioWorldizationSubsystem, QuadrantEnclosureBuses) == 0x3f0, "Offset mismatch for UAudioWorldizationSubsystem::QuadrantEnclosureBuses");
static_assert(offsetof(UAudioWorldizationSubsystem, QuadrantWallDistanceBuses) == 0x400, "Offset mismatch for UAudioWorldizationSubsystem::QuadrantWallDistanceBuses");
static_assert(offsetof(UAudioWorldizationSubsystem, CachedTraceOrigin) == 0x410, "Offset mismatch for UAudioWorldizationSubsystem::CachedTraceOrigin");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAudioWorldizationTraceDirectionPolicyBase : public UObject
{
public:
};

static_assert(sizeof(UAudioWorldizationTraceDirectionPolicyBase) == 0x30, "Size mismatch for UAudioWorldizationTraceDirectionPolicyBase");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UAudioWorldizationTraceDirectionPolicyDefault : public UAudioWorldizationTraceDirectionPolicyBase
{
public:
};

static_assert(sizeof(UAudioWorldizationTraceDirectionPolicyDefault) == 0x30, "Size mismatch for UAudioWorldizationTraceDirectionPolicyDefault");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAudioWorldizationTracePolicyBase : public UObject
{
public:
};

static_assert(sizeof(UAudioWorldizationTracePolicyBase) == 0x28, "Size mismatch for UAudioWorldizationTracePolicyBase");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioWorldizationTracePolicyDefault : public UAudioWorldizationTracePolicyBase
{
public:
};

static_assert(sizeof(UAudioWorldizationTracePolicyDefault) == 0x28, "Size mismatch for UAudioWorldizationTracePolicyDefault");

// Size: 0xd0 (Inherited: 0x268, Single: 0xfffffe68)
class UAudioWorldizationVolumeComponent : public UAudioGameplayVolumeComponentBase
{
public:
    UAudioWorldizationData* Settings; // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAudioWorldizationVolumeComponent) == 0xd0, "Size mismatch for UAudioWorldizationVolumeComponent");
static_assert(offsetof(UAudioWorldizationVolumeComponent, Settings) == 0xc8, "Offset mismatch for UAudioWorldizationVolumeComponent::Settings");

// Size: 0x90 (Inherited: 0x50, Single: 0x40)
class UGameFeatureAction_SetAudioWorldizationEffectSends : public UGameFeatureAction
{
public:
    FName Identifier; // 0x28 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<FAudioWorldizationSend> Sends; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x50]; // 0x40 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_SetAudioWorldizationEffectSends) == 0x90, "Size mismatch for UGameFeatureAction_SetAudioWorldizationEffectSends");
static_assert(offsetof(UGameFeatureAction_SetAudioWorldizationEffectSends, Identifier) == 0x28, "Offset mismatch for UGameFeatureAction_SetAudioWorldizationEffectSends::Identifier");
static_assert(offsetof(UGameFeatureAction_SetAudioWorldizationEffectSends, Sends) == 0x30, "Offset mismatch for UGameFeatureAction_SetAudioWorldizationEffectSends::Sends");

// Size: 0xf8 (Inherited: 0x50, Single: 0xa8)
class UGameFeatureAction_SetAudioWorldizationSettings : public UGameFeatureAction
{
public:
    FAudioWorldizationSettings Settings; // 0x28 (Size: 0x80, Type: StructProperty)
    uint8_t Pad_a8[0x50]; // 0xa8 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_SetAudioWorldizationSettings) == 0xf8, "Size mismatch for UGameFeatureAction_SetAudioWorldizationSettings");
static_assert(offsetof(UGameFeatureAction_SetAudioWorldizationSettings, Settings) == 0x28, "Offset mismatch for UGameFeatureAction_SetAudioWorldizationSettings::Settings");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FAudioWorldizationSend
{
    TSoftObjectPtr<USoundSubmix*> Submix; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSet<TSoftObjectPtr<USoundModulatorBase*>> VolumeModulators; // 0x20 (Size: 0x50, Type: SetProperty)
    TArray<TSoftObjectPtr<USoundEffectSubmixPreset*>> EffectChain; // 0x70 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAudioWorldizationSend) == 0x80, "Size mismatch for FAudioWorldizationSend");
static_assert(offsetof(FAudioWorldizationSend, Submix) == 0x0, "Offset mismatch for FAudioWorldizationSend::Submix");
static_assert(offsetof(FAudioWorldizationSend, VolumeModulators) == 0x20, "Offset mismatch for FAudioWorldizationSend::VolumeModulators");
static_assert(offsetof(FAudioWorldizationSend, EffectChain) == 0x70, "Offset mismatch for FAudioWorldizationSend::EffectChain");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FAudioWorldizationSettings
{
    FName Identifier; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FAudioWorldizationSend> Sends; // 0x8 (Size: 0x10, Type: ArrayProperty)
    float EnclosureSmoothSpeed; // 0x18 (Size: 0x4, Type: FloatProperty)
    float WallDistanceSmoothSpeed; // 0x1c (Size: 0x4, Type: FloatProperty)
    float TraceRadius; // 0x20 (Size: 0x4, Type: FloatProperty)
    float CrossfadeTime; // 0x24 (Size: 0x4, Type: FloatProperty)
    int32_t TracePoints; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t TracesPerFrame; // 0x2c (Size: 0x4, Type: IntProperty)
    float SideQuadrantDegrees; // 0x30 (Size: 0x4, Type: FloatProperty)
    float UpQuadrantDegrees; // 0x34 (Size: 0x4, Type: FloatProperty)
    FVector TraceOrigin; // 0x38 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> TraceChannel; // 0x50 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    TArray<TEnumAsByte<ECollisionChannel>> ResponseChannels; // 0x58 (Size: 0x10, Type: ArrayProperty)
    UClass* TracePolicy; // 0x68 (Size: 0x8, Type: ClassProperty)
    UClass* TraceDirectionPolicy; // 0x70 (Size: 0x8, Type: ClassProperty)
    bool bCollectActorAssetTags; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAudioWorldizationSettings) == 0x80, "Size mismatch for FAudioWorldizationSettings");
static_assert(offsetof(FAudioWorldizationSettings, Identifier) == 0x0, "Offset mismatch for FAudioWorldizationSettings::Identifier");
static_assert(offsetof(FAudioWorldizationSettings, Sends) == 0x8, "Offset mismatch for FAudioWorldizationSettings::Sends");
static_assert(offsetof(FAudioWorldizationSettings, EnclosureSmoothSpeed) == 0x18, "Offset mismatch for FAudioWorldizationSettings::EnclosureSmoothSpeed");
static_assert(offsetof(FAudioWorldizationSettings, WallDistanceSmoothSpeed) == 0x1c, "Offset mismatch for FAudioWorldizationSettings::WallDistanceSmoothSpeed");
static_assert(offsetof(FAudioWorldizationSettings, TraceRadius) == 0x20, "Offset mismatch for FAudioWorldizationSettings::TraceRadius");
static_assert(offsetof(FAudioWorldizationSettings, CrossfadeTime) == 0x24, "Offset mismatch for FAudioWorldizationSettings::CrossfadeTime");
static_assert(offsetof(FAudioWorldizationSettings, TracePoints) == 0x28, "Offset mismatch for FAudioWorldizationSettings::TracePoints");
static_assert(offsetof(FAudioWorldizationSettings, TracesPerFrame) == 0x2c, "Offset mismatch for FAudioWorldizationSettings::TracesPerFrame");
static_assert(offsetof(FAudioWorldizationSettings, SideQuadrantDegrees) == 0x30, "Offset mismatch for FAudioWorldizationSettings::SideQuadrantDegrees");
static_assert(offsetof(FAudioWorldizationSettings, UpQuadrantDegrees) == 0x34, "Offset mismatch for FAudioWorldizationSettings::UpQuadrantDegrees");
static_assert(offsetof(FAudioWorldizationSettings, TraceOrigin) == 0x38, "Offset mismatch for FAudioWorldizationSettings::TraceOrigin");
static_assert(offsetof(FAudioWorldizationSettings, TraceChannel) == 0x50, "Offset mismatch for FAudioWorldizationSettings::TraceChannel");
static_assert(offsetof(FAudioWorldizationSettings, ResponseChannels) == 0x58, "Offset mismatch for FAudioWorldizationSettings::ResponseChannels");
static_assert(offsetof(FAudioWorldizationSettings, TracePolicy) == 0x68, "Offset mismatch for FAudioWorldizationSettings::TracePolicy");
static_assert(offsetof(FAudioWorldizationSettings, TraceDirectionPolicy) == 0x70, "Offset mismatch for FAudioWorldizationSettings::TraceDirectionPolicy");
static_assert(offsetof(FAudioWorldizationSettings, bCollectActorAssetTags) == 0x78, "Offset mismatch for FAudioWorldizationSettings::bCollectActorAssetTags");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAudioWorldizationQuadrantSettings
{
    USoundControlBus* WallDistanceBus; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* EnclosureBus; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAudioWorldizationQuadrantSettings) == 0x10, "Size mismatch for FAudioWorldizationQuadrantSettings");
static_assert(offsetof(FAudioWorldizationQuadrantSettings, WallDistanceBus) == 0x0, "Offset mismatch for FAudioWorldizationQuadrantSettings::WallDistanceBus");
static_assert(offsetof(FAudioWorldizationQuadrantSettings, EnclosureBus) == 0x8, "Offset mismatch for FAudioWorldizationQuadrantSettings::EnclosureBus");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAudioWorldizationGlobalSettings
{
    float EffectCrossfadeTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    FName IgnoreTraceActorTag; // 0x4 (Size: 0x4, Type: NameProperty)
    USoundControlBus* EnclosureBus; // 0x8 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* WallDistanceBus; // 0x10 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ListenerAzimuthBus; // 0x18 (Size: 0x8, Type: ObjectProperty)
    TArray<FAudioWorldizationQuadrantSettings> Quadrants; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAudioWorldizationGlobalSettings) == 0x30, "Size mismatch for FAudioWorldizationGlobalSettings");
static_assert(offsetof(FAudioWorldizationGlobalSettings, EffectCrossfadeTime) == 0x0, "Offset mismatch for FAudioWorldizationGlobalSettings::EffectCrossfadeTime");
static_assert(offsetof(FAudioWorldizationGlobalSettings, IgnoreTraceActorTag) == 0x4, "Offset mismatch for FAudioWorldizationGlobalSettings::IgnoreTraceActorTag");
static_assert(offsetof(FAudioWorldizationGlobalSettings, EnclosureBus) == 0x8, "Offset mismatch for FAudioWorldizationGlobalSettings::EnclosureBus");
static_assert(offsetof(FAudioWorldizationGlobalSettings, WallDistanceBus) == 0x10, "Offset mismatch for FAudioWorldizationGlobalSettings::WallDistanceBus");
static_assert(offsetof(FAudioWorldizationGlobalSettings, ListenerAzimuthBus) == 0x18, "Offset mismatch for FAudioWorldizationGlobalSettings::ListenerAzimuthBus");
static_assert(offsetof(FAudioWorldizationGlobalSettings, Quadrants) == 0x20, "Offset mismatch for FAudioWorldizationGlobalSettings::Quadrants");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAudioSphereTraceResult
{
    bool bBlocking; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Distance; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8[0x4]; // 0x8 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAudioSphereTraceResult) == 0xc, "Size mismatch for FAudioSphereTraceResult");
static_assert(offsetof(FAudioSphereTraceResult, bBlocking) == 0x0, "Offset mismatch for FAudioSphereTraceResult::bBlocking");
static_assert(offsetof(FAudioSphereTraceResult, Distance) == 0x4, "Offset mismatch for FAudioSphereTraceResult::Distance");

