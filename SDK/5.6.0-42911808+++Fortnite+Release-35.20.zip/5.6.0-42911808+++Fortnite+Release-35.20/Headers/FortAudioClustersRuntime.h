/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortAudioClustersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DeveloperSettings.h"
#include "Engine.h"
#include "GameFeatures.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "AudioClustersRuntime.h"

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UFortAudioClustersSettings : public UDeveloperSettings
{
public:
    TMap<double, FGameplayTag> ParameterDefaults; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UFortAudioClustersSettings) == 0x80, "Size mismatch for UFortAudioClustersSettings");
static_assert(offsetof(UFortAudioClustersSettings, ParameterDefaults) == 0x30, "Offset mismatch for UFortAudioClustersSettings::ParameterDefaults");

// Size: 0x40 (Inherited: 0xc8, Single: 0xffffff78)
class UFortAudioClustersSubsystem : public UTickableWorldSubsystem
{
public:
};

static_assert(sizeof(UFortAudioClustersSubsystem) == 0x40, "Size mismatch for UFortAudioClustersSubsystem");

// Size: 0xf0 (Inherited: 0x50, Single: 0xa0)
class UGameFeatureAction_AddAudioCluster : public UGameFeatureAction
{
public:
    TArray<FGameFeatureAudioClusterEntry> Clusters; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TMap<FGameplayTag, FName> OverrideTable; // 0x38 (Size: 0x50, Type: MapProperty)
    FName DisabledActorTag; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x64]; // 0x8c (Size: 0x64, Type: PaddingProperty)

private:
    void HandleRegisteredActorDeath(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AFortPawn*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0x3b5a254 (Index: 0x0, Flags: Final|Native|Private|HasOutParms|HasDefaults)
};

static_assert(sizeof(UGameFeatureAction_AddAudioCluster) == 0xf0, "Size mismatch for UGameFeatureAction_AddAudioCluster");
static_assert(offsetof(UGameFeatureAction_AddAudioCluster, Clusters) == 0x28, "Offset mismatch for UGameFeatureAction_AddAudioCluster::Clusters");
static_assert(offsetof(UGameFeatureAction_AddAudioCluster, OverrideTable) == 0x38, "Offset mismatch for UGameFeatureAction_AddAudioCluster::OverrideTable");
static_assert(offsetof(UGameFeatureAction_AddAudioCluster, DisabledActorTag) == 0x88, "Offset mismatch for UGameFeatureAction_AddAudioCluster::DisabledActorTag");

// Size: 0x88 (Inherited: 0x50, Single: 0x38)
class UGameFeatureAction_AddAudioClusterConfigMaps : public UGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UAudioClusterConfigMap*>> ConfigMaps; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x50]; // 0x38 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_AddAudioClusterConfigMaps) == 0x88, "Size mismatch for UGameFeatureAction_AddAudioClusterConfigMaps");
static_assert(offsetof(UGameFeatureAction_AddAudioClusterConfigMaps, ConfigMaps) == 0x28, "Offset mismatch for UGameFeatureAction_AddAudioClusterConfigMaps::ConfigMaps");

// Size: 0xc8 (Inherited: 0x50, Single: 0x78)
class UGameFeatureAction_AddAudioClusterSettings : public UGameFeatureAction
{
public:
    TMap<double, FGameplayTag> SettingsMap; // 0x28 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_78[0x50]; // 0x78 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_AddAudioClusterSettings) == 0xc8, "Size mismatch for UGameFeatureAction_AddAudioClusterSettings");
static_assert(offsetof(UGameFeatureAction_AddAudioClusterSettings, SettingsMap) == 0x28, "Offset mismatch for UGameFeatureAction_AddAudioClusterSettings::SettingsMap");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameFeatureAudioClusterEntry
{
    FGameplayTag ClusterTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<TSoftClassPtr> ActorClasses; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameFeatureAudioClusterEntry) == 0x18, "Size mismatch for FGameFeatureAudioClusterEntry");
static_assert(offsetof(FGameFeatureAudioClusterEntry, ClusterTag) == 0x0, "Offset mismatch for FGameFeatureAudioClusterEntry::ClusterTag");
static_assert(offsetof(FGameFeatureAudioClusterEntry, ActorClasses) == 0x8, "Offset mismatch for FGameFeatureAudioClusterEntry::ActorClasses");

