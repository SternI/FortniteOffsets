/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CareerScreenStats
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "Blueprints.h"
#include "CareerUI.h"
#include "CommonUI.h"
#include "WBP_CareerPlaceholderTab.h"
#include "Engine.h"
#include "CoachMarks.h"
#include "WBP_LevelCountStats.h"
#include "WBP_StatsOptionsDisplay.h"
#include "OptionsModal.h"
#include "WBP_StatsRow.h"

// Size: 0x73c (Inherited: 0x1658, Single: 0xfffff0e4)
class UCareerScreenStats_C : public UAthenaCareerStatsScreen
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x5e0 (Size: 0x8, Type: StructProperty)
    UCommonActivatableWidgetSwitcher* WidgetSwitcher; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_StatsRow_C* WBP_StatsRow_29; // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_StatsRow_C* WBP_StatsRow; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_StatsOptionsDisplay_C* WBP_StatsOptionsDisplay; // 0x600 (Size: 0x8, Type: ObjectProperty)
    UWBP_LevelCountStats_C* WBP_LevelCountStats; // 0x608 (Size: 0x8, Type: ObjectProperty)
    UWBP_CareerPlaceholderTab_C* WBP_CareerPlaceholderTab; // 0x610 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate_1; // 0x618 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate; // 0x620 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VerticalBox_RankedProgressInfo; // 0x628 (Size: 0x8, Type: ObjectProperty)
    USpacer* TopBarLeftSpacer; // 0x630 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_5; // 0x638 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_3; // 0x640 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_2; // 0x648 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name_1; // 0x650 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Tier_Name; // 0x658 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_Content; // 0x660 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SB_Rank; // 0x668 (Size: 0x8, Type: ObjectProperty)
    USafeZone* SafeZone; // 0x670 (Size: 0x8, Type: ObjectProperty)
    UImage* ProgressSpinner; // 0x678 (Size: 0x8, Type: ObjectProperty)
    UOverlay* PlaceholderScreen; // 0x680 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* NoDataBox; // 0x688 (Size: 0x8, Type: ObjectProperty)
    UOverlay* MainScreen; // 0x690 (Size: 0x8, Type: ObjectProperty)
    UFortFlagImage* Image_YourFlag; // 0x698 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HB_AccountLevel; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    UCommonAnimatedSwitcher* CommonAnimatedSwitcher_ProgressInfo; // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    UFortVisualAttachment* ChangeFlag_VisualAttachment; // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    UWBP_ChangeFlag_CoachMark_C* ChangeFlag_CoachMark; // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* FinishedLoading; // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    UFortCareerStatsScreenVM* FortCareerStatsScreenVM; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle Input_ReplayCinematic; // 0x6d8 (Size: 0x10, Type: StructProperty)
    bool AutoPlayVideo; // 0x6e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6e9[0x7]; // 0x6e9 (Size: 0x7, Type: PaddingProperty)
    FDataTableRowHandle Input_Replays; // 0x6f0 (Size: 0x10, Type: StructProperty)
    UWBP_StatsOptionsModal_C* OptionsModal; // 0x700 (Size: 0x8, Type: ObjectProperty)
    bool InitializedRanksData; // 0x708 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_709[0x7]; // 0x709 (Size: 0x7, Type: PaddingProperty)
    USoundBase* WhooshTileSound; // 0x710 (Size: 0x8, Type: ObjectProperty)
    USoundBase* TabWhooshSound; // 0x718 (Size: 0x8, Type: ObjectProperty)
    bool HandledRanksLoaded; // 0x720 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_721[0x7]; // 0x721 (Size: 0x7, Type: PaddingProperty)
    FDataTableRowHandle Input_ChangeFlag; // 0x728 (Size: 0x10, Type: StructProperty)
    FGameplayTag ChangeFlagCoachMarkTag; // 0x738 (Size: 0x4, Type: StructProperty)

public:
    void CreateSeasonsButtons(FString& GameMode); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void CreateOptionsModalIfNecessary(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void CreateOptionsModal(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ApplySelectedOptionsFromModal(); // 0x288a61c (Index: 0x8, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetStatsData(const FStatPageData StatPageData); // 0x288a61c (Index: 0x9, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetRankedData(const FStatPageData StatPageData); // 0x288a61c (Index: 0xa, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetLoadingState(bool& IsLoading); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortCareerStatsScreenVM(UFortCareerStatsScreenVM*& ViewModel); // 0x288a61c (Index: 0xd, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetEmptyDataScreenState(bool& IsEmpty); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetBlockTemplateByPartySize(const FStatPageData StatPageData); // 0x288a61c (Index: 0xf, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetBackgroundFromSeason(FString& SeasonName); // 0x288a61c (Index: 0x10, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ReplayCinematic(bool& Passthrough); // 0x288a61c (Index: 0x11, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x12, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void PopulateScreen(const FStatPageData StatPageData, bool& Success); // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetRankedScreenState(const FStatPageData StatPageData); // 0x288a61c (Index: 0x14, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void PlayCinematic(); // 0x288a61c (Index: 0x15, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void InitializeVM(); // 0x288a61c (Index: 0x17, Flags: Public|BlueprintCallable|BlueprintEvent)
    void InitializeReplayButtonsInputHandlers(); // 0x288a61c (Index: 0x18, Flags: Public|BlueprintCallable|BlueprintEvent)
    void InitializeChangeFlagInputHandler(); // 0x288a61c (Index: 0x19, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void HandleReplaysButtonClicked(bool& bPassThrough); // 0x288a61c (Index: 0x1b, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void HandleCoachMarkHided(); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleCoachMarkButtonClicked(); // 0x288a61c (Index: 0x1f, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleChangeFlagButtonClicked(bool& bPassThrough); // 0x288a61c (Index: 0x20, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetSelectedAllForStatsModal(FString& GameMode, FString& Ranked, FString& SubMode, FString& SeasonName); // 0x288a61c (Index: 0x21, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleStatsLoaded(bool& const bSuccess); // 0x288a61c (Index: 0x1a, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleRanksLoaded(bool& const bSuccess); // 0x288a61c (Index: 0x1c, Flags: Event|Protected|BlueprintEvent)
    virtual void HandlePreOpenChangeFlagModal(UCommonActivatableWidget*& const Widget); // 0x288a61c (Index: 0x1d, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCareerScreenStats_C) == 0x73c, "Size mismatch for UCareerScreenStats_C");
static_assert(offsetof(UCareerScreenStats_C, UberGraphFrame) == 0x5e0, "Offset mismatch for UCareerScreenStats_C::UberGraphFrame");
static_assert(offsetof(UCareerScreenStats_C, WidgetSwitcher) == 0x5e8, "Offset mismatch for UCareerScreenStats_C::WidgetSwitcher");
static_assert(offsetof(UCareerScreenStats_C, WBP_StatsRow_29) == 0x5f0, "Offset mismatch for UCareerScreenStats_C::WBP_StatsRow_29");
static_assert(offsetof(UCareerScreenStats_C, WBP_StatsRow) == 0x5f8, "Offset mismatch for UCareerScreenStats_C::WBP_StatsRow");
static_assert(offsetof(UCareerScreenStats_C, WBP_StatsOptionsDisplay) == 0x600, "Offset mismatch for UCareerScreenStats_C::WBP_StatsOptionsDisplay");
static_assert(offsetof(UCareerScreenStats_C, WBP_LevelCountStats) == 0x608, "Offset mismatch for UCareerScreenStats_C::WBP_LevelCountStats");
static_assert(offsetof(UCareerScreenStats_C, WBP_CareerPlaceholderTab) == 0x610, "Offset mismatch for UCareerScreenStats_C::WBP_CareerPlaceholderTab");
static_assert(offsetof(UCareerScreenStats_C, WBP_CaptureForPostBufferUpdate_1) == 0x618, "Offset mismatch for UCareerScreenStats_C::WBP_CaptureForPostBufferUpdate_1");
static_assert(offsetof(UCareerScreenStats_C, WBP_CaptureForPostBufferUpdate) == 0x620, "Offset mismatch for UCareerScreenStats_C::WBP_CaptureForPostBufferUpdate");
static_assert(offsetof(UCareerScreenStats_C, VerticalBox_RankedProgressInfo) == 0x628, "Offset mismatch for UCareerScreenStats_C::VerticalBox_RankedProgressInfo");
static_assert(offsetof(UCareerScreenStats_C, TopBarLeftSpacer) == 0x630, "Offset mismatch for UCareerScreenStats_C::TopBarLeftSpacer");
static_assert(offsetof(UCareerScreenStats_C, Tier_Name_5) == 0x638, "Offset mismatch for UCareerScreenStats_C::Tier_Name_5");
static_assert(offsetof(UCareerScreenStats_C, Tier_Name_3) == 0x640, "Offset mismatch for UCareerScreenStats_C::Tier_Name_3");
static_assert(offsetof(UCareerScreenStats_C, Tier_Name_2) == 0x648, "Offset mismatch for UCareerScreenStats_C::Tier_Name_2");
static_assert(offsetof(UCareerScreenStats_C, Tier_Name_1) == 0x650, "Offset mismatch for UCareerScreenStats_C::Tier_Name_1");
static_assert(offsetof(UCareerScreenStats_C, Tier_Name) == 0x658, "Offset mismatch for UCareerScreenStats_C::Tier_Name");
static_assert(offsetof(UCareerScreenStats_C, Switcher_Content) == 0x660, "Offset mismatch for UCareerScreenStats_C::Switcher_Content");
static_assert(offsetof(UCareerScreenStats_C, SB_Rank) == 0x668, "Offset mismatch for UCareerScreenStats_C::SB_Rank");
static_assert(offsetof(UCareerScreenStats_C, SafeZone) == 0x670, "Offset mismatch for UCareerScreenStats_C::SafeZone");
static_assert(offsetof(UCareerScreenStats_C, ProgressSpinner) == 0x678, "Offset mismatch for UCareerScreenStats_C::ProgressSpinner");
static_assert(offsetof(UCareerScreenStats_C, PlaceholderScreen) == 0x680, "Offset mismatch for UCareerScreenStats_C::PlaceholderScreen");
static_assert(offsetof(UCareerScreenStats_C, NoDataBox) == 0x688, "Offset mismatch for UCareerScreenStats_C::NoDataBox");
static_assert(offsetof(UCareerScreenStats_C, MainScreen) == 0x690, "Offset mismatch for UCareerScreenStats_C::MainScreen");
static_assert(offsetof(UCareerScreenStats_C, Image_YourFlag) == 0x698, "Offset mismatch for UCareerScreenStats_C::Image_YourFlag");
static_assert(offsetof(UCareerScreenStats_C, Image_Background) == 0x6a0, "Offset mismatch for UCareerScreenStats_C::Image_Background");
static_assert(offsetof(UCareerScreenStats_C, HB_AccountLevel) == 0x6a8, "Offset mismatch for UCareerScreenStats_C::HB_AccountLevel");
static_assert(offsetof(UCareerScreenStats_C, CommonAnimatedSwitcher_ProgressInfo) == 0x6b0, "Offset mismatch for UCareerScreenStats_C::CommonAnimatedSwitcher_ProgressInfo");
static_assert(offsetof(UCareerScreenStats_C, ChangeFlag_VisualAttachment) == 0x6b8, "Offset mismatch for UCareerScreenStats_C::ChangeFlag_VisualAttachment");
static_assert(offsetof(UCareerScreenStats_C, ChangeFlag_CoachMark) == 0x6c0, "Offset mismatch for UCareerScreenStats_C::ChangeFlag_CoachMark");
static_assert(offsetof(UCareerScreenStats_C, FinishedLoading) == 0x6c8, "Offset mismatch for UCareerScreenStats_C::FinishedLoading");
static_assert(offsetof(UCareerScreenStats_C, FortCareerStatsScreenVM) == 0x6d0, "Offset mismatch for UCareerScreenStats_C::FortCareerStatsScreenVM");
static_assert(offsetof(UCareerScreenStats_C, Input_ReplayCinematic) == 0x6d8, "Offset mismatch for UCareerScreenStats_C::Input_ReplayCinematic");
static_assert(offsetof(UCareerScreenStats_C, AutoPlayVideo) == 0x6e8, "Offset mismatch for UCareerScreenStats_C::AutoPlayVideo");
static_assert(offsetof(UCareerScreenStats_C, Input_Replays) == 0x6f0, "Offset mismatch for UCareerScreenStats_C::Input_Replays");
static_assert(offsetof(UCareerScreenStats_C, OptionsModal) == 0x700, "Offset mismatch for UCareerScreenStats_C::OptionsModal");
static_assert(offsetof(UCareerScreenStats_C, InitializedRanksData) == 0x708, "Offset mismatch for UCareerScreenStats_C::InitializedRanksData");
static_assert(offsetof(UCareerScreenStats_C, WhooshTileSound) == 0x710, "Offset mismatch for UCareerScreenStats_C::WhooshTileSound");
static_assert(offsetof(UCareerScreenStats_C, TabWhooshSound) == 0x718, "Offset mismatch for UCareerScreenStats_C::TabWhooshSound");
static_assert(offsetof(UCareerScreenStats_C, HandledRanksLoaded) == 0x720, "Offset mismatch for UCareerScreenStats_C::HandledRanksLoaded");
static_assert(offsetof(UCareerScreenStats_C, Input_ChangeFlag) == 0x728, "Offset mismatch for UCareerScreenStats_C::Input_ChangeFlag");
static_assert(offsetof(UCareerScreenStats_C, ChangeFlagCoachMarkTag) == 0x738, "Offset mismatch for UCareerScreenStats_C::ChangeFlagCoachMarkTag");

