/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameInputBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "DeveloperSettings.h"
#include "CoreUObject.h"

// Size: 0x60 (Inherited: 0x68, Single: 0xfffffff8)
class UGameInputPlatformSettings : public UPlatformSettings
{
public:
    bool bProcessController; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bProcessRawInput; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bSpecialDevicesRequireExplicitDeviceConfiguration; // 0x42 (Size: 0x1, Type: BoolProperty)
    bool bProcessGamepad; // 0x43 (Size: 0x1, Type: BoolProperty)
    bool bProcessKeyboard; // 0x44 (Size: 0x1, Type: BoolProperty)
    bool bProcessMouse; // 0x45 (Size: 0x1, Type: BoolProperty)
    bool bProcessRacingWheel; // 0x46 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_47[0x1]; // 0x47 (Size: 0x1, Type: PaddingProperty)
    float RacingWheelDeadzone; // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bProcessArcadeStick; // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bProcessFlightStick; // 0x4d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e[0x2]; // 0x4e (Size: 0x2, Type: PaddingProperty)
    float FlightStickPitchDeadzone; // 0x50 (Size: 0x4, Type: FloatProperty)
    float FlightStickRollDeadzone; // 0x54 (Size: 0x4, Type: FloatProperty)
    float FlightStickThrottleDeadzone; // 0x58 (Size: 0x4, Type: FloatProperty)
    float FlightStickYawDeadzone; // 0x5c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UGameInputPlatformSettings) == 0x60, "Size mismatch for UGameInputPlatformSettings");
static_assert(offsetof(UGameInputPlatformSettings, bProcessController) == 0x40, "Offset mismatch for UGameInputPlatformSettings::bProcessController");
static_assert(offsetof(UGameInputPlatformSettings, bProcessRawInput) == 0x41, "Offset mismatch for UGameInputPlatformSettings::bProcessRawInput");
static_assert(offsetof(UGameInputPlatformSettings, bSpecialDevicesRequireExplicitDeviceConfiguration) == 0x42, "Offset mismatch for UGameInputPlatformSettings::bSpecialDevicesRequireExplicitDeviceConfiguration");
static_assert(offsetof(UGameInputPlatformSettings, bProcessGamepad) == 0x43, "Offset mismatch for UGameInputPlatformSettings::bProcessGamepad");
static_assert(offsetof(UGameInputPlatformSettings, bProcessKeyboard) == 0x44, "Offset mismatch for UGameInputPlatformSettings::bProcessKeyboard");
static_assert(offsetof(UGameInputPlatformSettings, bProcessMouse) == 0x45, "Offset mismatch for UGameInputPlatformSettings::bProcessMouse");
static_assert(offsetof(UGameInputPlatformSettings, bProcessRacingWheel) == 0x46, "Offset mismatch for UGameInputPlatformSettings::bProcessRacingWheel");
static_assert(offsetof(UGameInputPlatformSettings, RacingWheelDeadzone) == 0x48, "Offset mismatch for UGameInputPlatformSettings::RacingWheelDeadzone");
static_assert(offsetof(UGameInputPlatformSettings, bProcessArcadeStick) == 0x4c, "Offset mismatch for UGameInputPlatformSettings::bProcessArcadeStick");
static_assert(offsetof(UGameInputPlatformSettings, bProcessFlightStick) == 0x4d, "Offset mismatch for UGameInputPlatformSettings::bProcessFlightStick");
static_assert(offsetof(UGameInputPlatformSettings, FlightStickPitchDeadzone) == 0x50, "Offset mismatch for UGameInputPlatformSettings::FlightStickPitchDeadzone");
static_assert(offsetof(UGameInputPlatformSettings, FlightStickRollDeadzone) == 0x54, "Offset mismatch for UGameInputPlatformSettings::FlightStickRollDeadzone");
static_assert(offsetof(UGameInputPlatformSettings, FlightStickThrottleDeadzone) == 0x58, "Offset mismatch for UGameInputPlatformSettings::FlightStickThrottleDeadzone");
static_assert(offsetof(UGameInputPlatformSettings, FlightStickYawDeadzone) == 0x5c, "Offset mismatch for UGameInputPlatformSettings::FlightStickYawDeadzone");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UGameInputDeveloperSettings : public UObject
{
public:
    TArray<FGameInputDeviceConfiguration> DeviceConfigurations; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FPerPlatformSettings PlatformSpecificSettings; // 0x38 (Size: 0x10, Type: StructProperty)
    bool bDoNotProcessDuplicateCapabilitiesForSingleUser; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UGameInputDeveloperSettings) == 0x50, "Size mismatch for UGameInputDeveloperSettings");
static_assert(offsetof(UGameInputDeveloperSettings, DeviceConfigurations) == 0x28, "Offset mismatch for UGameInputDeveloperSettings::DeviceConfigurations");
static_assert(offsetof(UGameInputDeveloperSettings, PlatformSpecificSettings) == 0x38, "Offset mismatch for UGameInputDeveloperSettings::PlatformSpecificSettings");
static_assert(offsetof(UGameInputDeveloperSettings, bDoNotProcessDuplicateCapabilitiesForSingleUser) == 0x48, "Offset mismatch for UGameInputDeveloperSettings::bDoNotProcessDuplicateCapabilitiesForSingleUser");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGameInputDeviceIdentifier
{
    uint16_t VendorId; // 0x0 (Size: 0x2, Type: UInt16Property)
    uint16_t ProductID; // 0x2 (Size: 0x2, Type: UInt16Property)
};

static_assert(sizeof(FGameInputDeviceIdentifier) == 0x4, "Size mismatch for FGameInputDeviceIdentifier");
static_assert(offsetof(FGameInputDeviceIdentifier, VendorId) == 0x0, "Offset mismatch for FGameInputDeviceIdentifier::VendorId");
static_assert(offsetof(FGameInputDeviceIdentifier, ProductID) == 0x2, "Offset mismatch for FGameInputDeviceIdentifier::ProductID");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameInputControllerAxisData
{
    FName KeyName; // 0x0 (Size: 0x4, Type: NameProperty)
    float DeadZone; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Scalar; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bIsPackedPositveAndNegative; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGameInputControllerAxisData) == 0x10, "Size mismatch for FGameInputControllerAxisData");
static_assert(offsetof(FGameInputControllerAxisData, KeyName) == 0x0, "Offset mismatch for FGameInputControllerAxisData::KeyName");
static_assert(offsetof(FGameInputControllerAxisData, DeadZone) == 0x4, "Offset mismatch for FGameInputControllerAxisData::DeadZone");
static_assert(offsetof(FGameInputControllerAxisData, Scalar) == 0x8, "Offset mismatch for FGameInputControllerAxisData::Scalar");
static_assert(offsetof(FGameInputControllerAxisData, bIsPackedPositveAndNegative) == 0xc, "Offset mismatch for FGameInputControllerAxisData::bIsPackedPositveAndNegative");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FGameInputRawDeviceReportData
{
    FName KeyName; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bIgnoreAnalogInputDeviceScopeForThisRawReport; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t TranslationBehavior; // 0x5 (Size: 0x1, Type: EnumProperty)
    char AnalogDeadzone; // 0x6 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_7[0x1]; // 0x7 (Size: 0x1, Type: PaddingProperty)
    float Scalar; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TMap<FName, int32_t> ButtonBitMaskMappings; // 0x10 (Size: 0x50, Type: MapProperty)
    char LowerBitAxisIndex; // 0x60 (Size: 0x1, Type: ByteProperty)
    char HigherBitAxisIndex; // 0x61 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_62[0x6]; // 0x62 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameInputRawDeviceReportData) == 0x68, "Size mismatch for FGameInputRawDeviceReportData");
static_assert(offsetof(FGameInputRawDeviceReportData, KeyName) == 0x0, "Offset mismatch for FGameInputRawDeviceReportData::KeyName");
static_assert(offsetof(FGameInputRawDeviceReportData, bIgnoreAnalogInputDeviceScopeForThisRawReport) == 0x4, "Offset mismatch for FGameInputRawDeviceReportData::bIgnoreAnalogInputDeviceScopeForThisRawReport");
static_assert(offsetof(FGameInputRawDeviceReportData, TranslationBehavior) == 0x5, "Offset mismatch for FGameInputRawDeviceReportData::TranslationBehavior");
static_assert(offsetof(FGameInputRawDeviceReportData, AnalogDeadzone) == 0x6, "Offset mismatch for FGameInputRawDeviceReportData::AnalogDeadzone");
static_assert(offsetof(FGameInputRawDeviceReportData, Scalar) == 0x8, "Offset mismatch for FGameInputRawDeviceReportData::Scalar");
static_assert(offsetof(FGameInputRawDeviceReportData, ButtonBitMaskMappings) == 0x10, "Offset mismatch for FGameInputRawDeviceReportData::ButtonBitMaskMappings");
static_assert(offsetof(FGameInputRawDeviceReportData, LowerBitAxisIndex) == 0x60, "Offset mismatch for FGameInputRawDeviceReportData::LowerBitAxisIndex");
static_assert(offsetof(FGameInputRawDeviceReportData, HigherBitAxisIndex) == 0x61, "Offset mismatch for FGameInputRawDeviceReportData::HigherBitAxisIndex");

// Size: 0x118 (Inherited: 0x0, Single: 0x118)
struct FGameInputDeviceConfiguration
{
    FGameInputDeviceIdentifier DeviceIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    bool bOverrideHardwareDeviceIdString; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FString OverriddenHardwareDeviceId; // 0x8 (Size: 0x10, Type: StrProperty)
    bool bProcessControllerButtons; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bProcessControllerSwitchState; // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bProcessControllerAxis; // 0x1a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b[0x5]; // 0x1b (Size: 0x5, Type: PaddingProperty)
    TMap<FName, uint32_t> ControllerButtonMappingData; // 0x20 (Size: 0x50, Type: MapProperty)
    TMap<FGameInputControllerAxisData, uint32_t> ControllerAxisMappingData; // 0x70 (Size: 0x50, Type: MapProperty)
    bool bProcessRawReportData; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x3]; // 0xc1 (Size: 0x3, Type: PaddingProperty)
    uint32_t RawReportReadingId; // 0xc4 (Size: 0x4, Type: UInt32Property)
    TMap<FGameInputRawDeviceReportData, int32_t> RawReportMappingData; // 0xc8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FGameInputDeviceConfiguration) == 0x118, "Size mismatch for FGameInputDeviceConfiguration");
static_assert(offsetof(FGameInputDeviceConfiguration, DeviceIdentifier) == 0x0, "Offset mismatch for FGameInputDeviceConfiguration::DeviceIdentifier");
static_assert(offsetof(FGameInputDeviceConfiguration, bOverrideHardwareDeviceIdString) == 0x4, "Offset mismatch for FGameInputDeviceConfiguration::bOverrideHardwareDeviceIdString");
static_assert(offsetof(FGameInputDeviceConfiguration, OverriddenHardwareDeviceId) == 0x8, "Offset mismatch for FGameInputDeviceConfiguration::OverriddenHardwareDeviceId");
static_assert(offsetof(FGameInputDeviceConfiguration, bProcessControllerButtons) == 0x18, "Offset mismatch for FGameInputDeviceConfiguration::bProcessControllerButtons");
static_assert(offsetof(FGameInputDeviceConfiguration, bProcessControllerSwitchState) == 0x19, "Offset mismatch for FGameInputDeviceConfiguration::bProcessControllerSwitchState");
static_assert(offsetof(FGameInputDeviceConfiguration, bProcessControllerAxis) == 0x1a, "Offset mismatch for FGameInputDeviceConfiguration::bProcessControllerAxis");
static_assert(offsetof(FGameInputDeviceConfiguration, ControllerButtonMappingData) == 0x20, "Offset mismatch for FGameInputDeviceConfiguration::ControllerButtonMappingData");
static_assert(offsetof(FGameInputDeviceConfiguration, ControllerAxisMappingData) == 0x70, "Offset mismatch for FGameInputDeviceConfiguration::ControllerAxisMappingData");
static_assert(offsetof(FGameInputDeviceConfiguration, bProcessRawReportData) == 0xc0, "Offset mismatch for FGameInputDeviceConfiguration::bProcessRawReportData");
static_assert(offsetof(FGameInputDeviceConfiguration, RawReportReadingId) == 0xc4, "Offset mismatch for FGameInputDeviceConfiguration::RawReportReadingId");
static_assert(offsetof(FGameInputDeviceConfiguration, RawReportMappingData) == 0xc8, "Offset mismatch for FGameInputDeviceConfiguration::RawReportMappingData");

