/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClamberingCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ContextualTraversalRuntime.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0x130 (Inherited: 0x168, Single: 0xffffffc8)
class UFortMovementMode_ClamberingRuntimeData : public UFortMovementMode_TraversalBaseRuntimeData
{
public:

public:
    FVector GetSyncPosition() const; // 0x5335740 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortMovementMode_ClamberingRuntimeData) == 0x130, "Size mismatch for UFortMovementMode_ClamberingRuntimeData");

// Size: 0x2a8 (Inherited: 0x450, Single: 0xfffffe58)
class UFortMovementMode_ExtClambering : public UFortMovementMode_ExtLogicTraversalBase
{
public:
    UClass* LedgeLaunchCameraMode; // 0x240 (Size: 0x8, Type: ClassProperty)
    UClass* WindowClamberCameraMode; // 0x248 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer ClamberingTag; // 0x250 (Size: 0x20, Type: StructProperty)
    FGameplayTag ClamberingStartedTag; // 0x270 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_274[0x4]; // 0x274 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer ClamberingFinishedTag; // 0x278 (Size: 0x20, Type: StructProperty)
    UCameraShakeBase* CameraShake; // 0x298 (Size: 0x8, Type: ObjectProperty)
    float LedgeLaunchSyncPointInterpSpeed; // 0x2a0 (Size: 0x4, Type: FloatProperty)
    float LedgeLaunchPlayerCollideBounceSpeed; // 0x2a4 (Size: 0x4, Type: FloatProperty)

public:
    virtual void BP_GetAnimationMontageInformation(const FClamberMontageInput Context, UAnimMontage*& AnimMontage, FName& StartSectionName, FName& MontageMiddleSectionName); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortMovementMode_ExtClambering) == 0x2a8, "Size mismatch for UFortMovementMode_ExtClambering");
static_assert(offsetof(UFortMovementMode_ExtClambering, LedgeLaunchCameraMode) == 0x240, "Offset mismatch for UFortMovementMode_ExtClambering::LedgeLaunchCameraMode");
static_assert(offsetof(UFortMovementMode_ExtClambering, WindowClamberCameraMode) == 0x248, "Offset mismatch for UFortMovementMode_ExtClambering::WindowClamberCameraMode");
static_assert(offsetof(UFortMovementMode_ExtClambering, ClamberingTag) == 0x250, "Offset mismatch for UFortMovementMode_ExtClambering::ClamberingTag");
static_assert(offsetof(UFortMovementMode_ExtClambering, ClamberingStartedTag) == 0x270, "Offset mismatch for UFortMovementMode_ExtClambering::ClamberingStartedTag");
static_assert(offsetof(UFortMovementMode_ExtClambering, ClamberingFinishedTag) == 0x278, "Offset mismatch for UFortMovementMode_ExtClambering::ClamberingFinishedTag");
static_assert(offsetof(UFortMovementMode_ExtClambering, CameraShake) == 0x298, "Offset mismatch for UFortMovementMode_ExtClambering::CameraShake");
static_assert(offsetof(UFortMovementMode_ExtClambering, LedgeLaunchSyncPointInterpSpeed) == 0x2a0, "Offset mismatch for UFortMovementMode_ExtClambering::LedgeLaunchSyncPointInterpSpeed");
static_assert(offsetof(UFortMovementMode_ExtClambering, LedgeLaunchPlayerCollideBounceSpeed) == 0x2a4, "Offset mismatch for UFortMovementMode_ExtClambering::LedgeLaunchPlayerCollideBounceSpeed");

// Size: 0x308 (Inherited: 0x580, Single: 0xfffffd88)
class AInstancedLedgeActor : public AFortClientOnlyActor
{
public:
    UInstancedStaticMeshComponent* InstancedStaticMeshComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x50]; // 0x2b8 (Size: 0x50, Type: PaddingProperty)

protected:
    virtual void BP_OnAddInstance(const FTransform LedgeTransform, int32_t& InstanceIndex); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void BP_OnRemoveInstance(const FTransform LedgeTransform, int32_t& InstanceIndex); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
};

static_assert(sizeof(AInstancedLedgeActor) == 0x308, "Size mismatch for AInstancedLedgeActor");
static_assert(offsetof(AInstancedLedgeActor, InstancedStaticMeshComponent) == 0x2b0, "Offset mismatch for AInstancedLedgeActor::InstancedStaticMeshComponent");

// Size: 0x150 (Inherited: 0xb8, Single: 0x98)
class ULedgeLaunchWorldSubsystem : public UBuildingWallSubsystem
{
public:
    TSoftObjectPtr<UPBWLedgeConfigurationData*> ConfigurationData; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    TSoftClassPtr InstancedLedgeActorClass; // 0x50 (Size: 0x20, Type: SoftClassProperty)
    UPBWLedgeConfigurationData* CachedConfigurationData; // 0x70 (Size: 0x8, Type: ObjectProperty)
    AInstancedLedgeActor* InstancedLedgeActor; // 0x78 (Size: 0x8, Type: ObjectProperty)
    TMap<FLedgeLaunchConfigEntry, UClass*> CachedLedgeLaunchMap; // 0x80 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_d0[0x80]; // 0xd0 (Size: 0x80, Type: PaddingProperty)

public:
    void OnWallDied(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AFortPawn*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0xff4f6d8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults)
};

static_assert(sizeof(ULedgeLaunchWorldSubsystem) == 0x150, "Size mismatch for ULedgeLaunchWorldSubsystem");
static_assert(offsetof(ULedgeLaunchWorldSubsystem, ConfigurationData) == 0x30, "Offset mismatch for ULedgeLaunchWorldSubsystem::ConfigurationData");
static_assert(offsetof(ULedgeLaunchWorldSubsystem, InstancedLedgeActorClass) == 0x50, "Offset mismatch for ULedgeLaunchWorldSubsystem::InstancedLedgeActorClass");
static_assert(offsetof(ULedgeLaunchWorldSubsystem, CachedConfigurationData) == 0x70, "Offset mismatch for ULedgeLaunchWorldSubsystem::CachedConfigurationData");
static_assert(offsetof(ULedgeLaunchWorldSubsystem, InstancedLedgeActor) == 0x78, "Offset mismatch for ULedgeLaunchWorldSubsystem::InstancedLedgeActor");
static_assert(offsetof(ULedgeLaunchWorldSubsystem, CachedLedgeLaunchMap) == 0x80, "Offset mismatch for ULedgeLaunchWorldSubsystem::CachedLedgeLaunchMap");

// Size: 0x1c0 (Inherited: 0x58, Single: 0x168)
class UPBWLedgeConfigurationData : public UDataAsset
{
public:
    TMap<TSoftClassPtr, EPlayerBuiltWallType> MetalWalls; // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<TSoftClassPtr, EPlayerBuiltWallType> StoneWalls; // 0x80 (Size: 0x50, Type: MapProperty)
    TMap<TSoftClassPtr, EPlayerBuiltWallType> WoodWalls; // 0xd0 (Size: 0x50, Type: MapProperty)
    TMap<FLedgeLaunchConfigEntry, EPlayerBuiltWallType> Transforms; // 0x120 (Size: 0x50, Type: MapProperty)
    TMap<FLedgeLaunchTransformConfigEntry, EPlayerBuiltWallMaterialType> PerMaterialTransforms; // 0x170 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UPBWLedgeConfigurationData) == 0x1c0, "Size mismatch for UPBWLedgeConfigurationData");
static_assert(offsetof(UPBWLedgeConfigurationData, MetalWalls) == 0x30, "Offset mismatch for UPBWLedgeConfigurationData::MetalWalls");
static_assert(offsetof(UPBWLedgeConfigurationData, StoneWalls) == 0x80, "Offset mismatch for UPBWLedgeConfigurationData::StoneWalls");
static_assert(offsetof(UPBWLedgeConfigurationData, WoodWalls) == 0xd0, "Offset mismatch for UPBWLedgeConfigurationData::WoodWalls");
static_assert(offsetof(UPBWLedgeConfigurationData, Transforms) == 0x120, "Offset mismatch for UPBWLedgeConfigurationData::Transforms");
static_assert(offsetof(UPBWLedgeConfigurationData, PerMaterialTransforms) == 0x170, "Offset mismatch for UPBWLedgeConfigurationData::PerMaterialTransforms");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UClamberingAnalytics : public UObject
{
public:
};

static_assert(sizeof(UClamberingAnalytics) == 0x28, "Size mismatch for UClamberingAnalytics");

// Size: 0x10a0 (Inherited: 0x3d0, Single: 0xcd0)
class UClamberingComponent : public UFortPawnOverrideComponent
{
public:
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
    uint8_t LocalClamberingState; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t ReplicatedClamberingState; // 0xc9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_ca[0x6]; // 0xca (Size: 0x6, Type: PaddingProperty)
    FClamberingTargetingData LockedTargetingData; // 0xd0 (Size: 0x130, Type: StructProperty)
    uint8_t Pad_200[0x10]; // 0x200 (Size: 0x10, Type: PaddingProperty)
    FReplicatedClamberingTargetingData_SimClient ReplicatedTargetingData; // 0x210 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_248[0x8]; // 0x248 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat ClamberingEnabled; // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberIndicatorEnabled; // 0x278 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2a0[0x8]; // 0x2a0 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat ClamberStartMaxFallingDamageFraction; // 0x2a8 (Size: 0x28, Type: StructProperty)
    bool bPerformTargetingWhileWalking; // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bPerformTargetingWhileSwimming; // 0x2d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d2[0x6]; // 0x2d2 (Size: 0x6, Type: PaddingProperty)
    FScalableFloat ServerFailDelay; // 0x2d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ServerValidatePlayerMaxDistance; // 0x300 (Size: 0x28, Type: StructProperty)
    FClamberingInputConfig InputConfig; // 0x328 (Size: 0x350, Type: StructProperty)
    FClamberingTargetingConfig_Ledge TargetingConfig_Ledge; // 0x678 (Size: 0x578, Type: StructProperty)
    FClamberingInputConfig_CachedValues InputConfigCachedValues; // 0xbf0 (Size: 0x5c, Type: StructProperty)
    FClamberingTargetingConfig_Ledge_CachedContextualValues TargetingConfig_Ledge_CachedContextualValues; // 0xc4c (Size: 0x90, Type: StructProperty)
    uint8_t Pad_cdc[0x4]; // 0xcdc (Size: 0x4, Type: PaddingProperty)
    FClamberingMovementConfig_Ledge MoveConfig_Ledge; // 0xce0 (Size: 0x50, Type: StructProperty)
    FScalableFloat ClamberSyncTargetLedgeOffset; // 0xd30 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberingMaxAnalyticsEvents; // 0xd58 (Size: 0x28, Type: StructProperty)
    FScalableFloat SynchedActionFailDelay; // 0xd80 (Size: 0x28, Type: StructProperty)
    UClass* MovementModeExtension; // 0xda8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SynchedActionMMETag; // 0xdb0 (Size: 0x4, Type: StructProperty)
    FGameplayTag AllowTargetingTag; // 0xdb4 (Size: 0x4, Type: StructProperty)
    FName LedgeLaunchSyncPointName; // 0xdb8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_dbc[0x4]; // 0xdbc (Size: 0x4, Type: PaddingProperty)
    double LastTeleportTime; // 0xdc0 (Size: 0x8, Type: DoubleProperty)
    bool bTutorialModeEnabled; // 0xdc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_dc9[0x7]; // 0xdc9 (Size: 0x7, Type: PaddingProperty)
    FClamberingTargetingData LocalTargetingData; // 0xdd0 (Size: 0x130, Type: StructProperty)
    FClamberingTargetingData ParallelTargetingData; // 0xf00 (Size: 0x130, Type: StructProperty)
    float QueuedInputTimer; // 0x1030 (Size: 0x4, Type: FloatProperty)
    float InputEnabledTimer; // 0x1034 (Size: 0x4, Type: FloatProperty)
    bool bJumpInputPressed; // 0x1038 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1039[0x3]; // 0x1039 (Size: 0x3, Type: PaddingProperty)
    float JumpHeldInAirTime; // 0x103c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1040[0x50]; // 0x1040 (Size: 0x50, Type: PaddingProperty)
    FGameplayTag Tag_DisableClambering; // 0x1090 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1094[0xc]; // 0x1094 (Size: 0xc, Type: PaddingProperty)

public:
    bool IsAutoClamberingEnabled() const; // 0xff4f2e8 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTutorialModeEnabled() const; // 0xff4f330 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetTutorialModeEnabled(bool& bEnabled); // 0xff503e0 (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable)
    bool ShouldShowClamberIndicator() const; // 0xff5050c (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldShowUIPrompt() const; // 0xff50530 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    virtual void BP_CanStartClambering(bool& bCanStartClambering) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual void BP_CanStartTargeting(bool& bCanStartTargeting) const; // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual void BP_HandleClamberingStateChanged(EClamberingState& const OldClamberingState, EClamberingState& const NewClamberingState); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_HandleSynchedActionStarted(const FSynchedActionInfo SynchedActionInfo); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_IsValidTargetActor(AActor*& const TargetActor, bool& bIsValidTargetActor) const; // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual void BP_OnMMEStarted(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_TutorialModeDisabled() const; // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent|Const)
    virtual void BP_TutorialModeEnabled() const; // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent|Const)
    void DrawDebugHUD(AHUD*& HUD, UCanvas*& Canvas); // 0xa93bc70 (Index: 0x8, Flags: Final|Native|Protected)
    virtual void HandleClamberingTargetInActivationRange(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleClamberingTargetOutOfActivationRange(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    void HandleOwnerASCInitialized(UFortAbilitySystemComponent*& AbilitySystemComponent, AFortPlayerPawn*& AffectedPawn); // 0x5474e00 (Index: 0xb, Flags: Final|Native|Protected)
    void HandleOwnerASCInvalidated(); // 0x4fcf938 (Index: 0xc, Flags: Final|Native|Protected)
    void HandleOwnerDBNO(); // 0x4fcf8fc (Index: 0xd, Flags: Final|Native|Protected)
    void HandleOwnerDied(AFortPawn*& DeadPawn); // 0xff4ee24 (Index: 0xe, Flags: Final|Native|Protected)
    void HandleOwnerJumpInput(bool& bPressed); // 0xff4ef50 (Index: 0xf, Flags: Final|Native|Protected)
    void HandleOwnerMovementModeChanged(ACharacter*& Character, TEnumAsByte<EMovementMode>& PreviousMovementMode, char& PreviousCustomMode); // 0x31a04c4 (Index: 0x10, Flags: Final|Native|Protected)
    void HandleOwnerPersonalVehicleModeChanged(bool& bIsMounted); // 0xff4f07c (Index: 0x11, Flags: Final|Native|Protected)
    void HandleOwnerTeleported(AFortPawn*& TeleportedOwner); // 0x57d76e8 (Index: 0x12, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleTargetActorDestroyed(AActor*& Actor); // 0xff4f1a8 (Index: 0x13, Flags: Final|Native|Protected)
    void HandleTargetActorHealthChanged(); // 0xff4f2d4 (Index: 0x14, Flags: Final|Native|Protected)
    virtual void HandleTargetingDataInvalid(); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleTargetingDataValid(const FClamberingTargetingData TargetingData); // 0x288a61c (Index: 0x16, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    bool IsClamberingEnabled() const; // 0xff4f30c (Index: 0x18, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void NetMulticast_ClamberingLedgeFailed(EClamberingFailedReason& FailedReason, EClamberingState& FailedState); // 0xff4f354 (Index: 0x1a, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    void OnMutatorUpdated(); // 0x5827e68 (Index: 0x1b, Flags: Final|Native|Protected)
    void OnOwnerPawnPossessed(APawn*& PossessedPawn); // 0xff4f560 (Index: 0x1c, Flags: Final|Native|Protected)
    void OnPlayerStatePawnSet(APlayerState*& Player, APawn*& NewPawn, APawn*& OldPawn); // 0x5534888 (Index: 0x1d, Flags: Final|Native|Protected)
    void OnRep_ReplicatedTargetingData(); // 0xff4f6a4 (Index: 0x1e, Flags: Final|Native|Protected)
    void RegisterMutatorUpdatedDelegate(APawn*& AffectedPawn); // 0xff4fd8c (Index: 0x1f, Flags: Final|Native|Protected)
    virtual void ServerStartClambering(FReplicatedClamberingTargetingData& const InReplicatedTargetingData, double& const ClientLastTeleportTime); // 0xff50230 (Index: 0x20, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    void UnregisterMutatorUpdatedDelegate(); // 0xff50554 (Index: 0x24, Flags: Final|Native|Protected)
};

static_assert(sizeof(UClamberingComponent) == 0x10a0, "Size mismatch for UClamberingComponent");
static_assert(offsetof(UClamberingComponent, LocalClamberingState) == 0xc8, "Offset mismatch for UClamberingComponent::LocalClamberingState");
static_assert(offsetof(UClamberingComponent, ReplicatedClamberingState) == 0xc9, "Offset mismatch for UClamberingComponent::ReplicatedClamberingState");
static_assert(offsetof(UClamberingComponent, LockedTargetingData) == 0xd0, "Offset mismatch for UClamberingComponent::LockedTargetingData");
static_assert(offsetof(UClamberingComponent, ReplicatedTargetingData) == 0x210, "Offset mismatch for UClamberingComponent::ReplicatedTargetingData");
static_assert(offsetof(UClamberingComponent, ClamberingEnabled) == 0x250, "Offset mismatch for UClamberingComponent::ClamberingEnabled");
static_assert(offsetof(UClamberingComponent, ClamberIndicatorEnabled) == 0x278, "Offset mismatch for UClamberingComponent::ClamberIndicatorEnabled");
static_assert(offsetof(UClamberingComponent, ClamberStartMaxFallingDamageFraction) == 0x2a8, "Offset mismatch for UClamberingComponent::ClamberStartMaxFallingDamageFraction");
static_assert(offsetof(UClamberingComponent, bPerformTargetingWhileWalking) == 0x2d0, "Offset mismatch for UClamberingComponent::bPerformTargetingWhileWalking");
static_assert(offsetof(UClamberingComponent, bPerformTargetingWhileSwimming) == 0x2d1, "Offset mismatch for UClamberingComponent::bPerformTargetingWhileSwimming");
static_assert(offsetof(UClamberingComponent, ServerFailDelay) == 0x2d8, "Offset mismatch for UClamberingComponent::ServerFailDelay");
static_assert(offsetof(UClamberingComponent, ServerValidatePlayerMaxDistance) == 0x300, "Offset mismatch for UClamberingComponent::ServerValidatePlayerMaxDistance");
static_assert(offsetof(UClamberingComponent, InputConfig) == 0x328, "Offset mismatch for UClamberingComponent::InputConfig");
static_assert(offsetof(UClamberingComponent, TargetingConfig_Ledge) == 0x678, "Offset mismatch for UClamberingComponent::TargetingConfig_Ledge");
static_assert(offsetof(UClamberingComponent, InputConfigCachedValues) == 0xbf0, "Offset mismatch for UClamberingComponent::InputConfigCachedValues");
static_assert(offsetof(UClamberingComponent, TargetingConfig_Ledge_CachedContextualValues) == 0xc4c, "Offset mismatch for UClamberingComponent::TargetingConfig_Ledge_CachedContextualValues");
static_assert(offsetof(UClamberingComponent, MoveConfig_Ledge) == 0xce0, "Offset mismatch for UClamberingComponent::MoveConfig_Ledge");
static_assert(offsetof(UClamberingComponent, ClamberSyncTargetLedgeOffset) == 0xd30, "Offset mismatch for UClamberingComponent::ClamberSyncTargetLedgeOffset");
static_assert(offsetof(UClamberingComponent, ClamberingMaxAnalyticsEvents) == 0xd58, "Offset mismatch for UClamberingComponent::ClamberingMaxAnalyticsEvents");
static_assert(offsetof(UClamberingComponent, SynchedActionFailDelay) == 0xd80, "Offset mismatch for UClamberingComponent::SynchedActionFailDelay");
static_assert(offsetof(UClamberingComponent, MovementModeExtension) == 0xda8, "Offset mismatch for UClamberingComponent::MovementModeExtension");
static_assert(offsetof(UClamberingComponent, SynchedActionMMETag) == 0xdb0, "Offset mismatch for UClamberingComponent::SynchedActionMMETag");
static_assert(offsetof(UClamberingComponent, AllowTargetingTag) == 0xdb4, "Offset mismatch for UClamberingComponent::AllowTargetingTag");
static_assert(offsetof(UClamberingComponent, LedgeLaunchSyncPointName) == 0xdb8, "Offset mismatch for UClamberingComponent::LedgeLaunchSyncPointName");
static_assert(offsetof(UClamberingComponent, LastTeleportTime) == 0xdc0, "Offset mismatch for UClamberingComponent::LastTeleportTime");
static_assert(offsetof(UClamberingComponent, bTutorialModeEnabled) == 0xdc8, "Offset mismatch for UClamberingComponent::bTutorialModeEnabled");
static_assert(offsetof(UClamberingComponent, LocalTargetingData) == 0xdd0, "Offset mismatch for UClamberingComponent::LocalTargetingData");
static_assert(offsetof(UClamberingComponent, ParallelTargetingData) == 0xf00, "Offset mismatch for UClamberingComponent::ParallelTargetingData");
static_assert(offsetof(UClamberingComponent, QueuedInputTimer) == 0x1030, "Offset mismatch for UClamberingComponent::QueuedInputTimer");
static_assert(offsetof(UClamberingComponent, InputEnabledTimer) == 0x1034, "Offset mismatch for UClamberingComponent::InputEnabledTimer");
static_assert(offsetof(UClamberingComponent, bJumpInputPressed) == 0x1038, "Offset mismatch for UClamberingComponent::bJumpInputPressed");
static_assert(offsetof(UClamberingComponent, JumpHeldInAirTime) == 0x103c, "Offset mismatch for UClamberingComponent::JumpHeldInAirTime");
static_assert(offsetof(UClamberingComponent, Tag_DisableClambering) == 0x1090, "Offset mismatch for UClamberingComponent::Tag_DisableClambering");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UClamberingLibrary : public UBlueprintFunctionLibrary
{
public:
};

static_assert(sizeof(UClamberingLibrary) == 0x28, "Size mismatch for UClamberingLibrary");

// Size: 0x520 (Inherited: 0xbc0, Single: 0xfffff960)
class AFortAthenaMutator_LedgeLaunch : public AFortAthenaMutator
{
public:
    uint8_t Pad_360[0x1a0]; // 0x360 (Size: 0x1a0, Type: PaddingProperty)
    TArray<TWeakObjectPtr<ABuildingWall*>> CurrentWalls; // 0x500 (Size: 0x10, Type: ArrayProperty)
    bool bShouldSpawnLedge; // 0x510 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_511[0xf]; // 0x511 (Size: 0xf, Type: PaddingProperty)

private:
    void OnRep_bShouldSpawnLedge(); // 0xff4f6b8 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(AFortAthenaMutator_LedgeLaunch) == 0x520, "Size mismatch for AFortAthenaMutator_LedgeLaunch");
static_assert(offsetof(AFortAthenaMutator_LedgeLaunch, CurrentWalls) == 0x500, "Offset mismatch for AFortAthenaMutator_LedgeLaunch::CurrentWalls");
static_assert(offsetof(AFortAthenaMutator_LedgeLaunch, bShouldSpawnLedge) == 0x510, "Offset mismatch for AFortAthenaMutator_LedgeLaunch::bShouldSpawnLedge");

// Size: 0x140 (Inherited: 0x140, Single: 0x0)
struct FFortMovementMode_ClamberingCreationData : FFortMovementMode_TraversalBaseCreationData
{
    TArray<FSynchedActionWarpPointInfo_Replicated> LedgeLaunchWarpPointInfos; // 0x128 (Size: 0x10, Type: ArrayProperty)
    int32_t LedgeLaunchWarpPointIndex; // 0x138 (Size: 0x4, Type: IntProperty)
    bool bCanStandOnLedge; // 0x13c (Size: 0x1, Type: BoolProperty)
    bool bHasFixedLedgeLaunchWarpPoint; // 0x13d (Size: 0x1, Type: BoolProperty)
    bool bClamberFromFalling; // 0x13e (Size: 0x1, Type: BoolProperty)
    bool bIsReachBack; // 0x13f (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FFortMovementMode_ClamberingCreationData) == 0x140, "Size mismatch for FFortMovementMode_ClamberingCreationData");
static_assert(offsetof(FFortMovementMode_ClamberingCreationData, LedgeLaunchWarpPointInfos) == 0x128, "Offset mismatch for FFortMovementMode_ClamberingCreationData::LedgeLaunchWarpPointInfos");
static_assert(offsetof(FFortMovementMode_ClamberingCreationData, LedgeLaunchWarpPointIndex) == 0x138, "Offset mismatch for FFortMovementMode_ClamberingCreationData::LedgeLaunchWarpPointIndex");
static_assert(offsetof(FFortMovementMode_ClamberingCreationData, bCanStandOnLedge) == 0x13c, "Offset mismatch for FFortMovementMode_ClamberingCreationData::bCanStandOnLedge");
static_assert(offsetof(FFortMovementMode_ClamberingCreationData, bHasFixedLedgeLaunchWarpPoint) == 0x13d, "Offset mismatch for FFortMovementMode_ClamberingCreationData::bHasFixedLedgeLaunchWarpPoint");
static_assert(offsetof(FFortMovementMode_ClamberingCreationData, bClamberFromFalling) == 0x13e, "Offset mismatch for FFortMovementMode_ClamberingCreationData::bClamberFromFalling");
static_assert(offsetof(FFortMovementMode_ClamberingCreationData, bIsReachBack) == 0x13f, "Offset mismatch for FFortMovementMode_ClamberingCreationData::bIsReachBack");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FClamberMontageInput
{
    FSynchedActionInfo BaseSynchedActionInfo; // 0x0 (Size: 0x30, Type: StructProperty)
    FVector FutureLedgeWarpPoint; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bIsLedgeLaunch; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bHasFutureLedge; // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bClamberFromFalling; // 0x4a (Size: 0x1, Type: BoolProperty)
    bool bWindowClamber; // 0x4b (Size: 0x1, Type: BoolProperty)
    bool bIsReachBack; // 0x4c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FClamberMontageInput) == 0x50, "Size mismatch for FClamberMontageInput");
static_assert(offsetof(FClamberMontageInput, BaseSynchedActionInfo) == 0x0, "Offset mismatch for FClamberMontageInput::BaseSynchedActionInfo");
static_assert(offsetof(FClamberMontageInput, FutureLedgeWarpPoint) == 0x30, "Offset mismatch for FClamberMontageInput::FutureLedgeWarpPoint");
static_assert(offsetof(FClamberMontageInput, bIsLedgeLaunch) == 0x48, "Offset mismatch for FClamberMontageInput::bIsLedgeLaunch");
static_assert(offsetof(FClamberMontageInput, bHasFutureLedge) == 0x49, "Offset mismatch for FClamberMontageInput::bHasFutureLedge");
static_assert(offsetof(FClamberMontageInput, bClamberFromFalling) == 0x4a, "Offset mismatch for FClamberMontageInput::bClamberFromFalling");
static_assert(offsetof(FClamberMontageInput, bWindowClamber) == 0x4b, "Offset mismatch for FClamberMontageInput::bWindowClamber");
static_assert(offsetof(FClamberMontageInput, bIsReachBack) == 0x4c, "Offset mismatch for FClamberMontageInput::bIsReachBack");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FLedgeLaunchConfigEntry
{
    TArray<FTransform> LedgeTransforms; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> WindowLedgeTransforms; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FLedgeLaunchConfigEntry) == 0x20, "Size mismatch for FLedgeLaunchConfigEntry");
static_assert(offsetof(FLedgeLaunchConfigEntry, LedgeTransforms) == 0x0, "Offset mismatch for FLedgeLaunchConfigEntry::LedgeTransforms");
static_assert(offsetof(FLedgeLaunchConfigEntry, WindowLedgeTransforms) == 0x10, "Offset mismatch for FLedgeLaunchConfigEntry::WindowLedgeTransforms");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FLedgeLaunchTransformConfigEntry
{
    TMap<FLedgeLaunchConfigEntry, EPlayerBuiltWallType> Transforms; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FLedgeLaunchTransformConfigEntry) == 0x50, "Size mismatch for FLedgeLaunchTransformConfigEntry");
static_assert(offsetof(FLedgeLaunchTransformConfigEntry, Transforms) == 0x0, "Offset mismatch for FLedgeLaunchTransformConfigEntry::Transforms");

// Size: 0x350 (Inherited: 0x0, Single: 0x350)
struct FClamberingInputConfig
{
    FScalableFloat ClamberActivationHorizontalRange; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberActivationVerticalRange; // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberLookAtThreshold; // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat EnableInputDelay; // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat QueuedInputWindow; // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HeldInputDuration; // 0xc8 (Size: 0x28, Type: StructProperty)
    uint8_t ActivationMode; // 0xf0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_f1[0x7]; // 0xf1 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat AutoStartMovementThreshold; // 0xf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartLookAtThreshold; // 0x120 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartWallCheckCastRadius; // 0x148 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartWallCheckHorizontalRange; // 0x170 (Size: 0x28, Type: StructProperty)
    FScalableFloat AutoStartWallCheckLookAtThresholdMultiplier; // 0x198 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInvalidateDistance; // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetAimInvalidateAngle; // 0x1e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetActorMovementInvalidateDistance; // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat LedgeLaunchEnabled; // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDirectionalLedgeLaunchAngle; // 0x260 (Size: 0x28, Type: StructProperty)
    FScalableFloat PBWLedgeLaunchMaxHorizontalTranslation; // 0x288 (Size: 0x28, Type: StructProperty)
    FScalableFloat DefaultLedgeLaunchVerticalTranslation; // 0x2b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat PBWLedgeLaunchVerticalTranslation; // 0x2d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PBWNextLedgeLaunchVerticalTranslation; // 0x300 (Size: 0x28, Type: StructProperty)
    FScalableFloat LedgeLaunchWarpingWindow; // 0x328 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FClamberingInputConfig) == 0x350, "Size mismatch for FClamberingInputConfig");
static_assert(offsetof(FClamberingInputConfig, ClamberActivationHorizontalRange) == 0x0, "Offset mismatch for FClamberingInputConfig::ClamberActivationHorizontalRange");
static_assert(offsetof(FClamberingInputConfig, ClamberActivationVerticalRange) == 0x28, "Offset mismatch for FClamberingInputConfig::ClamberActivationVerticalRange");
static_assert(offsetof(FClamberingInputConfig, ClamberLookAtThreshold) == 0x50, "Offset mismatch for FClamberingInputConfig::ClamberLookAtThreshold");
static_assert(offsetof(FClamberingInputConfig, EnableInputDelay) == 0x78, "Offset mismatch for FClamberingInputConfig::EnableInputDelay");
static_assert(offsetof(FClamberingInputConfig, QueuedInputWindow) == 0xa0, "Offset mismatch for FClamberingInputConfig::QueuedInputWindow");
static_assert(offsetof(FClamberingInputConfig, HeldInputDuration) == 0xc8, "Offset mismatch for FClamberingInputConfig::HeldInputDuration");
static_assert(offsetof(FClamberingInputConfig, ActivationMode) == 0xf0, "Offset mismatch for FClamberingInputConfig::ActivationMode");
static_assert(offsetof(FClamberingInputConfig, AutoStartMovementThreshold) == 0xf8, "Offset mismatch for FClamberingInputConfig::AutoStartMovementThreshold");
static_assert(offsetof(FClamberingInputConfig, AutoStartLookAtThreshold) == 0x120, "Offset mismatch for FClamberingInputConfig::AutoStartLookAtThreshold");
static_assert(offsetof(FClamberingInputConfig, AutoStartWallCheckCastRadius) == 0x148, "Offset mismatch for FClamberingInputConfig::AutoStartWallCheckCastRadius");
static_assert(offsetof(FClamberingInputConfig, AutoStartWallCheckHorizontalRange) == 0x170, "Offset mismatch for FClamberingInputConfig::AutoStartWallCheckHorizontalRange");
static_assert(offsetof(FClamberingInputConfig, AutoStartWallCheckLookAtThresholdMultiplier) == 0x198, "Offset mismatch for FClamberingInputConfig::AutoStartWallCheckLookAtThresholdMultiplier");
static_assert(offsetof(FClamberingInputConfig, TargetInvalidateDistance) == 0x1c0, "Offset mismatch for FClamberingInputConfig::TargetInvalidateDistance");
static_assert(offsetof(FClamberingInputConfig, TargetAimInvalidateAngle) == 0x1e8, "Offset mismatch for FClamberingInputConfig::TargetAimInvalidateAngle");
static_assert(offsetof(FClamberingInputConfig, TargetActorMovementInvalidateDistance) == 0x210, "Offset mismatch for FClamberingInputConfig::TargetActorMovementInvalidateDistance");
static_assert(offsetof(FClamberingInputConfig, LedgeLaunchEnabled) == 0x238, "Offset mismatch for FClamberingInputConfig::LedgeLaunchEnabled");
static_assert(offsetof(FClamberingInputConfig, MaxDirectionalLedgeLaunchAngle) == 0x260, "Offset mismatch for FClamberingInputConfig::MaxDirectionalLedgeLaunchAngle");
static_assert(offsetof(FClamberingInputConfig, PBWLedgeLaunchMaxHorizontalTranslation) == 0x288, "Offset mismatch for FClamberingInputConfig::PBWLedgeLaunchMaxHorizontalTranslation");
static_assert(offsetof(FClamberingInputConfig, DefaultLedgeLaunchVerticalTranslation) == 0x2b0, "Offset mismatch for FClamberingInputConfig::DefaultLedgeLaunchVerticalTranslation");
static_assert(offsetof(FClamberingInputConfig, PBWLedgeLaunchVerticalTranslation) == 0x2d8, "Offset mismatch for FClamberingInputConfig::PBWLedgeLaunchVerticalTranslation");
static_assert(offsetof(FClamberingInputConfig, PBWNextLedgeLaunchVerticalTranslation) == 0x300, "Offset mismatch for FClamberingInputConfig::PBWNextLedgeLaunchVerticalTranslation");
static_assert(offsetof(FClamberingInputConfig, LedgeLaunchWarpingWindow) == 0x328, "Offset mismatch for FClamberingInputConfig::LedgeLaunchWarpingWindow");

// Size: 0x578 (Inherited: 0x0, Single: 0x578)
struct FClamberingTargetingConfig_Ledge
{
    FScalableFloat ForwardCastDistance; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ForwardCastRadius; // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat FowardCast2D; // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat VerticalSurfaceThreshold; // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat HorizontalSurfaceThreshold; // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat UpwardDistanceCapsuleHeightMultiplier; // 0xc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat UpwardStartDistanceCapsuleHeightMultiplier; // 0xf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DownwardDistanceCapsuleHeightMultiplier; // 0x118 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeHeight; // 0x140 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeHeightWater; // 0x168 (Size: 0x28, Type: StructProperty)
    FScalableFloat FallingSpeedThreshold; // 0x190 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeFallingHeight; // 0x1b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinimumLedgeFallingWaterHeight; // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ForwardSphereCastRadius; // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat DownwardSphereCastRadius; // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat AllowNonWalkableSurfaces; // 0x258 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationEnabled; // 0x280 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationCapsuleRadiusModifier; // 0x2a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationCapsuleHalfHeightModifier; // 0x2d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetValidationCapsuleBottomVerticalOffset; // 0x2f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat FutureLedgeLaunchMaxVerticalDetectionRange; // 0x320 (Size: 0x28, Type: StructProperty)
    FScalableFloat FutureLedgeLaunchMaxHorizontalDetectionRange; // 0x348 (Size: 0x28, Type: StructProperty)
    FScalableFloat LedgeExtentThresholdToUseMidpointTargeting; // 0x370 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorCheckCastWallOffset; // 0x398 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorCheckDownDistance; // 0x3c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorCheckMaxAllowedAngle; // 0x3e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingHorizontalSweepBreadth; // 0x410 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingHorizontalSweepHeight; // 0x438 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingHorizontalOpeningSweepBreadth; // 0x460 (Size: 0x28, Type: StructProperty)
    FScalableFloat WindowTargetingVerticalOffsetCheckInWindowFrame; // 0x488 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberScoringModifier; // 0x4b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClamberLedgeLaunchScoringModifier; // 0x4d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseMultiSweepCheckForSurfaces; // 0x500 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseReachBackClamber; // 0x528 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReachBackDistanceSweep; // 0x550 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FClamberingTargetingConfig_Ledge) == 0x578, "Size mismatch for FClamberingTargetingConfig_Ledge");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, ForwardCastDistance) == 0x0, "Offset mismatch for FClamberingTargetingConfig_Ledge::ForwardCastDistance");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, ForwardCastRadius) == 0x28, "Offset mismatch for FClamberingTargetingConfig_Ledge::ForwardCastRadius");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FowardCast2D) == 0x50, "Offset mismatch for FClamberingTargetingConfig_Ledge::FowardCast2D");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, VerticalSurfaceThreshold) == 0x78, "Offset mismatch for FClamberingTargetingConfig_Ledge::VerticalSurfaceThreshold");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, HorizontalSurfaceThreshold) == 0xa0, "Offset mismatch for FClamberingTargetingConfig_Ledge::HorizontalSurfaceThreshold");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, UpwardDistanceCapsuleHeightMultiplier) == 0xc8, "Offset mismatch for FClamberingTargetingConfig_Ledge::UpwardDistanceCapsuleHeightMultiplier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, UpwardStartDistanceCapsuleHeightMultiplier) == 0xf0, "Offset mismatch for FClamberingTargetingConfig_Ledge::UpwardStartDistanceCapsuleHeightMultiplier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, DownwardDistanceCapsuleHeightMultiplier) == 0x118, "Offset mismatch for FClamberingTargetingConfig_Ledge::DownwardDistanceCapsuleHeightMultiplier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, MinimumLedgeHeight) == 0x140, "Offset mismatch for FClamberingTargetingConfig_Ledge::MinimumLedgeHeight");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, MinimumLedgeHeightWater) == 0x168, "Offset mismatch for FClamberingTargetingConfig_Ledge::MinimumLedgeHeightWater");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FallingSpeedThreshold) == 0x190, "Offset mismatch for FClamberingTargetingConfig_Ledge::FallingSpeedThreshold");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, MinimumLedgeFallingHeight) == 0x1b8, "Offset mismatch for FClamberingTargetingConfig_Ledge::MinimumLedgeFallingHeight");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, MinimumLedgeFallingWaterHeight) == 0x1e0, "Offset mismatch for FClamberingTargetingConfig_Ledge::MinimumLedgeFallingWaterHeight");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, ForwardSphereCastRadius) == 0x208, "Offset mismatch for FClamberingTargetingConfig_Ledge::ForwardSphereCastRadius");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, DownwardSphereCastRadius) == 0x230, "Offset mismatch for FClamberingTargetingConfig_Ledge::DownwardSphereCastRadius");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, AllowNonWalkableSurfaces) == 0x258, "Offset mismatch for FClamberingTargetingConfig_Ledge::AllowNonWalkableSurfaces");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, TargetValidationEnabled) == 0x280, "Offset mismatch for FClamberingTargetingConfig_Ledge::TargetValidationEnabled");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, TargetValidationCapsuleRadiusModifier) == 0x2a8, "Offset mismatch for FClamberingTargetingConfig_Ledge::TargetValidationCapsuleRadiusModifier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, TargetValidationCapsuleHalfHeightModifier) == 0x2d0, "Offset mismatch for FClamberingTargetingConfig_Ledge::TargetValidationCapsuleHalfHeightModifier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, TargetValidationCapsuleBottomVerticalOffset) == 0x2f8, "Offset mismatch for FClamberingTargetingConfig_Ledge::TargetValidationCapsuleBottomVerticalOffset");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FutureLedgeLaunchMaxVerticalDetectionRange) == 0x320, "Offset mismatch for FClamberingTargetingConfig_Ledge::FutureLedgeLaunchMaxVerticalDetectionRange");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FutureLedgeLaunchMaxHorizontalDetectionRange) == 0x348, "Offset mismatch for FClamberingTargetingConfig_Ledge::FutureLedgeLaunchMaxHorizontalDetectionRange");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, LedgeExtentThresholdToUseMidpointTargeting) == 0x370, "Offset mismatch for FClamberingTargetingConfig_Ledge::LedgeExtentThresholdToUseMidpointTargeting");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FloorCheckCastWallOffset) == 0x398, "Offset mismatch for FClamberingTargetingConfig_Ledge::FloorCheckCastWallOffset");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FloorCheckDownDistance) == 0x3c0, "Offset mismatch for FClamberingTargetingConfig_Ledge::FloorCheckDownDistance");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, FloorCheckMaxAllowedAngle) == 0x3e8, "Offset mismatch for FClamberingTargetingConfig_Ledge::FloorCheckMaxAllowedAngle");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, WindowTargetingHorizontalSweepBreadth) == 0x410, "Offset mismatch for FClamberingTargetingConfig_Ledge::WindowTargetingHorizontalSweepBreadth");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, WindowTargetingHorizontalSweepHeight) == 0x438, "Offset mismatch for FClamberingTargetingConfig_Ledge::WindowTargetingHorizontalSweepHeight");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, WindowTargetingHorizontalOpeningSweepBreadth) == 0x460, "Offset mismatch for FClamberingTargetingConfig_Ledge::WindowTargetingHorizontalOpeningSweepBreadth");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, WindowTargetingVerticalOffsetCheckInWindowFrame) == 0x488, "Offset mismatch for FClamberingTargetingConfig_Ledge::WindowTargetingVerticalOffsetCheckInWindowFrame");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, ClamberScoringModifier) == 0x4b0, "Offset mismatch for FClamberingTargetingConfig_Ledge::ClamberScoringModifier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, ClamberLedgeLaunchScoringModifier) == 0x4d8, "Offset mismatch for FClamberingTargetingConfig_Ledge::ClamberLedgeLaunchScoringModifier");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, UseMultiSweepCheckForSurfaces) == 0x500, "Offset mismatch for FClamberingTargetingConfig_Ledge::UseMultiSweepCheckForSurfaces");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, UseReachBackClamber) == 0x528, "Offset mismatch for FClamberingTargetingConfig_Ledge::UseReachBackClamber");
static_assert(offsetof(FClamberingTargetingConfig_Ledge, ReachBackDistanceSweep) == 0x550, "Offset mismatch for FClamberingTargetingConfig_Ledge::ReachBackDistanceSweep");

// Size: 0x5c (Inherited: 0x0, Single: 0x5c)
struct FClamberingInputConfig_CachedValues
{
};

static_assert(sizeof(FClamberingInputConfig_CachedValues) == 0x5c, "Size mismatch for FClamberingInputConfig_CachedValues");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FClamberingTargetingConfig_Ledge_CachedContextualValues
{
};

static_assert(sizeof(FClamberingTargetingConfig_Ledge_CachedContextualValues) == 0x90, "Size mismatch for FClamberingTargetingConfig_Ledge_CachedContextualValues");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FClamberingTargetingDebugDrawData
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData) == 0x28, "Size mismatch for FClamberingTargetingDebugDrawData");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
struct FClamberingTargetingDebugDrawData_Box : FClamberingTargetingDebugDrawData
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_Box) == 0x70, "Size mismatch for FClamberingTargetingDebugDrawData_Box");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
struct FClamberingTargetingDebugDrawData_Capsule : FClamberingTargetingDebugDrawData
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_Capsule) == 0x50, "Size mismatch for FClamberingTargetingDebugDrawData_Capsule");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
struct FClamberingTargetingDebugDrawData_Line : FClamberingTargetingDebugDrawData
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_Line) == 0x40, "Size mismatch for FClamberingTargetingDebugDrawData_Line");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
struct FClamberingTargetingDebugDrawData_Sphere : FClamberingTargetingDebugDrawData
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_Sphere) == 0x30, "Size mismatch for FClamberingTargetingDebugDrawData_Sphere");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
struct FClamberingTargetingDebugDrawData_DirectionalArrow : FClamberingTargetingDebugDrawData
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_DirectionalArrow) == 0x48, "Size mismatch for FClamberingTargetingDebugDrawData_DirectionalArrow");

// Size: 0x70 (Inherited: 0x78, Single: 0xfffffff8)
struct FClamberingTargetingDebugDrawData_CapsuleCast : FClamberingTargetingDebugDrawData_Capsule
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_CapsuleCast) == 0x70, "Size mismatch for FClamberingTargetingDebugDrawData_CapsuleCast");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
struct FClamberingTargetingDebugDrawData_SphereCast : FClamberingTargetingDebugDrawData_Sphere
{
};

static_assert(sizeof(FClamberingTargetingDebugDrawData_SphereCast) == 0x48, "Size mismatch for FClamberingTargetingDebugDrawData_SphereCast");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FClamberingTargetingDebugData
{
};

static_assert(sizeof(FClamberingTargetingDebugData) == 0x1, "Size mismatch for FClamberingTargetingDebugData");

// Size: 0x1 (Inherited: 0x1, Single: 0x0)
struct FClamberingTargetingDebugData_Ledge : FClamberingTargetingDebugData
{
};

static_assert(sizeof(FClamberingTargetingDebugData_Ledge) == 0x1, "Size mismatch for FClamberingTargetingDebugData_Ledge");

// Size: 0x130 (Inherited: 0x48, Single: 0xe8)
struct FClamberingTargetingData : FContextualTraversalTargetingData
{
    uint8_t Type; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t bValid : 1; // 0x49:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanStandOnLedge : 1; // 0x49:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsWindow : 1; // 0x49:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
    AActor* SourceActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
    FVector SourceLocation; // 0x58 (Size: 0x18, Type: StructProperty)
    FVector SourceAim; // 0x70 (Size: 0x18, Type: StructProperty)
    FVector WallLocation; // 0x88 (Size: 0x18, Type: StructProperty)
    FVector WallNormal; // 0xa0 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation; // 0xb8 (Size: 0x18, Type: StructProperty)
    FVector TargetNormal; // 0xd0 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* TargetActorComponent; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    FVector TargetActorComponentLocation; // 0xf8 (Size: 0x18, Type: StructProperty)
    FName TargetActorBoneName; // 0x110 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    TArray<FVector> NextLedgeLaunchWarpPoints; // 0x118 (Size: 0x10, Type: ArrayProperty)
    bool bIsReachBack; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x7]; // 0x129 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FClamberingTargetingData) == 0x130, "Size mismatch for FClamberingTargetingData");
static_assert(offsetof(FClamberingTargetingData, Type) == 0x48, "Offset mismatch for FClamberingTargetingData::Type");
static_assert(offsetof(FClamberingTargetingData, bValid) == 0x49, "Offset mismatch for FClamberingTargetingData::bValid");
static_assert(offsetof(FClamberingTargetingData, bCanStandOnLedge) == 0x49, "Offset mismatch for FClamberingTargetingData::bCanStandOnLedge");
static_assert(offsetof(FClamberingTargetingData, bIsWindow) == 0x49, "Offset mismatch for FClamberingTargetingData::bIsWindow");
static_assert(offsetof(FClamberingTargetingData, SourceActor) == 0x50, "Offset mismatch for FClamberingTargetingData::SourceActor");
static_assert(offsetof(FClamberingTargetingData, SourceLocation) == 0x58, "Offset mismatch for FClamberingTargetingData::SourceLocation");
static_assert(offsetof(FClamberingTargetingData, SourceAim) == 0x70, "Offset mismatch for FClamberingTargetingData::SourceAim");
static_assert(offsetof(FClamberingTargetingData, WallLocation) == 0x88, "Offset mismatch for FClamberingTargetingData::WallLocation");
static_assert(offsetof(FClamberingTargetingData, WallNormal) == 0xa0, "Offset mismatch for FClamberingTargetingData::WallNormal");
static_assert(offsetof(FClamberingTargetingData, TargetLocation) == 0xb8, "Offset mismatch for FClamberingTargetingData::TargetLocation");
static_assert(offsetof(FClamberingTargetingData, TargetNormal) == 0xd0, "Offset mismatch for FClamberingTargetingData::TargetNormal");
static_assert(offsetof(FClamberingTargetingData, TargetActor) == 0xe8, "Offset mismatch for FClamberingTargetingData::TargetActor");
static_assert(offsetof(FClamberingTargetingData, TargetActorComponent) == 0xf0, "Offset mismatch for FClamberingTargetingData::TargetActorComponent");
static_assert(offsetof(FClamberingTargetingData, TargetActorComponentLocation) == 0xf8, "Offset mismatch for FClamberingTargetingData::TargetActorComponentLocation");
static_assert(offsetof(FClamberingTargetingData, TargetActorBoneName) == 0x110, "Offset mismatch for FClamberingTargetingData::TargetActorBoneName");
static_assert(offsetof(FClamberingTargetingData, NextLedgeLaunchWarpPoints) == 0x118, "Offset mismatch for FClamberingTargetingData::NextLedgeLaunchWarpPoints");
static_assert(offsetof(FClamberingTargetingData, bIsReachBack) == 0x128, "Offset mismatch for FClamberingTargetingData::bIsReachBack");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FReplicatedClamberingTargetingData
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector_NetQuantize10 SourceLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize100 WallLocation; // 0x20 (Size: 0x18, Type: StructProperty)
    uint16_t WallNormalYawQuantized; // 0x38 (Size: 0x2, Type: UInt16Property)
    uint16_t WallNormalPitchQuantized; // 0x3a (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FVector_NetQuantize100 TargetLocation; // 0x40 (Size: 0x18, Type: StructProperty)
    uint16_t TargetNormalYawQuantized; // 0x58 (Size: 0x2, Type: UInt16Property)
    uint16_t TargetNormalPitchQuantized; // 0x5a (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    AActor* TargetActor; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* TargetActorComponent; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FName TargetActorBoneName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FReplicatedClamberingTargetingData) == 0x78, "Size mismatch for FReplicatedClamberingTargetingData");
static_assert(offsetof(FReplicatedClamberingTargetingData, Type) == 0x0, "Offset mismatch for FReplicatedClamberingTargetingData::Type");
static_assert(offsetof(FReplicatedClamberingTargetingData, SourceLocation) == 0x8, "Offset mismatch for FReplicatedClamberingTargetingData::SourceLocation");
static_assert(offsetof(FReplicatedClamberingTargetingData, WallLocation) == 0x20, "Offset mismatch for FReplicatedClamberingTargetingData::WallLocation");
static_assert(offsetof(FReplicatedClamberingTargetingData, WallNormalYawQuantized) == 0x38, "Offset mismatch for FReplicatedClamberingTargetingData::WallNormalYawQuantized");
static_assert(offsetof(FReplicatedClamberingTargetingData, WallNormalPitchQuantized) == 0x3a, "Offset mismatch for FReplicatedClamberingTargetingData::WallNormalPitchQuantized");
static_assert(offsetof(FReplicatedClamberingTargetingData, TargetLocation) == 0x40, "Offset mismatch for FReplicatedClamberingTargetingData::TargetLocation");
static_assert(offsetof(FReplicatedClamberingTargetingData, TargetNormalYawQuantized) == 0x58, "Offset mismatch for FReplicatedClamberingTargetingData::TargetNormalYawQuantized");
static_assert(offsetof(FReplicatedClamberingTargetingData, TargetNormalPitchQuantized) == 0x5a, "Offset mismatch for FReplicatedClamberingTargetingData::TargetNormalPitchQuantized");
static_assert(offsetof(FReplicatedClamberingTargetingData, TargetActor) == 0x60, "Offset mismatch for FReplicatedClamberingTargetingData::TargetActor");
static_assert(offsetof(FReplicatedClamberingTargetingData, TargetActorComponent) == 0x68, "Offset mismatch for FReplicatedClamberingTargetingData::TargetActorComponent");
static_assert(offsetof(FReplicatedClamberingTargetingData, TargetActorBoneName) == 0x70, "Offset mismatch for FReplicatedClamberingTargetingData::TargetActorBoneName");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FReplicatedClamberingTargetingData_SimClient
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x1]; // 0x1 (Size: 0x1, Type: PaddingProperty)
    uint16_t WallNormalYawQuantized; // 0x2 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector_NetQuantize100 TargetLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor; // 0x20 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* TargetActorComponent; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FName TargetActorBoneName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FReplicatedClamberingTargetingData_SimClient) == 0x38, "Size mismatch for FReplicatedClamberingTargetingData_SimClient");
static_assert(offsetof(FReplicatedClamberingTargetingData_SimClient, Type) == 0x0, "Offset mismatch for FReplicatedClamberingTargetingData_SimClient::Type");
static_assert(offsetof(FReplicatedClamberingTargetingData_SimClient, WallNormalYawQuantized) == 0x2, "Offset mismatch for FReplicatedClamberingTargetingData_SimClient::WallNormalYawQuantized");
static_assert(offsetof(FReplicatedClamberingTargetingData_SimClient, TargetLocation) == 0x8, "Offset mismatch for FReplicatedClamberingTargetingData_SimClient::TargetLocation");
static_assert(offsetof(FReplicatedClamberingTargetingData_SimClient, TargetActor) == 0x20, "Offset mismatch for FReplicatedClamberingTargetingData_SimClient::TargetActor");
static_assert(offsetof(FReplicatedClamberingTargetingData_SimClient, TargetActorComponent) == 0x28, "Offset mismatch for FReplicatedClamberingTargetingData_SimClient::TargetActorComponent");
static_assert(offsetof(FReplicatedClamberingTargetingData_SimClient, TargetActorBoneName) == 0x30, "Offset mismatch for FReplicatedClamberingTargetingData_SimClient::TargetActorBoneName");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FClamberingMovementConfig_Ledge
{
    FScalableFloat duration; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BlockCheckTickRate; // 0x28 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FClamberingMovementConfig_Ledge) == 0x50, "Size mismatch for FClamberingMovementConfig_Ledge");
static_assert(offsetof(FClamberingMovementConfig_Ledge, duration) == 0x0, "Offset mismatch for FClamberingMovementConfig_Ledge::duration");
static_assert(offsetof(FClamberingMovementConfig_Ledge, BlockCheckTickRate) == 0x28, "Offset mismatch for FClamberingMovementConfig_Ledge::BlockCheckTickRate");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FClamberingAnalytics_ClamberEvent
{
    int32_t MatchTime; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t ClamberType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FVector ClamberLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t FailureReason; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FClamberingAnalytics_ClamberEvent) == 0x28, "Size mismatch for FClamberingAnalytics_ClamberEvent");
static_assert(offsetof(FClamberingAnalytics_ClamberEvent, MatchTime) == 0x0, "Offset mismatch for FClamberingAnalytics_ClamberEvent::MatchTime");
static_assert(offsetof(FClamberingAnalytics_ClamberEvent, ClamberType) == 0x4, "Offset mismatch for FClamberingAnalytics_ClamberEvent::ClamberType");
static_assert(offsetof(FClamberingAnalytics_ClamberEvent, ClamberLocation) == 0x8, "Offset mismatch for FClamberingAnalytics_ClamberEvent::ClamberLocation");
static_assert(offsetof(FClamberingAnalytics_ClamberEvent, FailureReason) == 0x20, "Offset mismatch for FClamberingAnalytics_ClamberEvent::FailureReason");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FClamberingAnimationEntry : FTableRowBase
{
    UAnimMontage* Montage; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float MinClamberHeight; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bLedgeLaunch; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FClamberingAnimationEntry) == 0x18, "Size mismatch for FClamberingAnimationEntry");
static_assert(offsetof(FClamberingAnimationEntry, Montage) == 0x8, "Offset mismatch for FClamberingAnimationEntry::Montage");
static_assert(offsetof(FClamberingAnimationEntry, MinClamberHeight) == 0x10, "Offset mismatch for FClamberingAnimationEntry::MinClamberHeight");
static_assert(offsetof(FClamberingAnimationEntry, bLedgeLaunch) == 0x14, "Offset mismatch for FClamberingAnimationEntry::bLedgeLaunch");

