/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioLinkCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UAudioLinkSettingsAbstract : public UObject
{
public:
};

static_assert(sizeof(UAudioLinkSettingsAbstract) == 0x38, "Size mismatch for UAudioLinkSettingsAbstract");

