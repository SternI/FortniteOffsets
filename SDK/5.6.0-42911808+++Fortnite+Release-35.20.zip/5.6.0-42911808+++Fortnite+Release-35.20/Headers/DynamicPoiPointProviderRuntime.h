/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicPoiPointProviderRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteAI.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "LagerRuntime.h"

// Size: 0xd0 (Inherited: 0xa0, Single: 0x30)
class UAIServiceDynamicPoiPointProvider : public UAthenaAIService
{
public:
    FGameplayTagContainer DynamicPOIPointProviderTags; // 0x78 (Size: 0x20, Type: StructProperty)
    uint8_t SpawnLimiterBehavior; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    TArray<FDynamicPOIMaxActorCondition> MaxActorConditions; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    int32_t DefaultMaxActorCount; // 0xb0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    UAthenaAIServicePlayerBots* CachedAIServicePlayerBots; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicPoiPointProvider*> DynamicPoiPointProviders; // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAIServiceDynamicPoiPointProvider) == 0xd0, "Size mismatch for UAIServiceDynamicPoiPointProvider");
static_assert(offsetof(UAIServiceDynamicPoiPointProvider, DynamicPOIPointProviderTags) == 0x78, "Offset mismatch for UAIServiceDynamicPoiPointProvider::DynamicPOIPointProviderTags");
static_assert(offsetof(UAIServiceDynamicPoiPointProvider, SpawnLimiterBehavior) == 0x98, "Offset mismatch for UAIServiceDynamicPoiPointProvider::SpawnLimiterBehavior");
static_assert(offsetof(UAIServiceDynamicPoiPointProvider, MaxActorConditions) == 0xa0, "Offset mismatch for UAIServiceDynamicPoiPointProvider::MaxActorConditions");
static_assert(offsetof(UAIServiceDynamicPoiPointProvider, DefaultMaxActorCount) == 0xb0, "Offset mismatch for UAIServiceDynamicPoiPointProvider::DefaultMaxActorCount");
static_assert(offsetof(UAIServiceDynamicPoiPointProvider, CachedAIServicePlayerBots) == 0xb8, "Offset mismatch for UAIServiceDynamicPoiPointProvider::CachedAIServicePlayerBots");
static_assert(offsetof(UAIServiceDynamicPoiPointProvider, DynamicPoiPointProviders) == 0xc0, "Offset mismatch for UAIServiceDynamicPoiPointProvider::DynamicPoiPointProviders");

// Size: 0x118 (Inherited: 0x28, Single: 0xf0)
class UDynamicPoiPointProvider : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    AFortGameStateAthena* CachedGameState; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaLivingWorldManager* CachedLivingWorldManager; // 0x38 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer PointProviderFiltersTags; // 0x40 (Size: 0x20, Type: StructProperty)
    FFortAthenaLivingWorldPointProviderSpawnLimiter SpawnLimiter; // 0x60 (Size: 0x68, Type: StructProperty)
    FBox Box; // 0xc8 (Size: 0x38, Type: StructProperty)
    TArray<FVector> Locations; // 0x100 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicPoiPointProvider) == 0x118, "Size mismatch for UDynamicPoiPointProvider");
static_assert(offsetof(UDynamicPoiPointProvider, CachedGameState) == 0x30, "Offset mismatch for UDynamicPoiPointProvider::CachedGameState");
static_assert(offsetof(UDynamicPoiPointProvider, CachedLivingWorldManager) == 0x38, "Offset mismatch for UDynamicPoiPointProvider::CachedLivingWorldManager");
static_assert(offsetof(UDynamicPoiPointProvider, PointProviderFiltersTags) == 0x40, "Offset mismatch for UDynamicPoiPointProvider::PointProviderFiltersTags");
static_assert(offsetof(UDynamicPoiPointProvider, SpawnLimiter) == 0x60, "Offset mismatch for UDynamicPoiPointProvider::SpawnLimiter");
static_assert(offsetof(UDynamicPoiPointProvider, Box) == 0xc8, "Offset mismatch for UDynamicPoiPointProvider::Box");
static_assert(offsetof(UDynamicPoiPointProvider, Locations) == 0x100, "Offset mismatch for UDynamicPoiPointProvider::Locations");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDynamicPOIMaxActorCondition
{
    float MinAreaSize; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxAreaSize; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MaxCount; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDynamicPOIMaxActorCondition) == 0xc, "Size mismatch for FDynamicPOIMaxActorCondition");
static_assert(offsetof(FDynamicPOIMaxActorCondition, MinAreaSize) == 0x0, "Offset mismatch for FDynamicPOIMaxActorCondition::MinAreaSize");
static_assert(offsetof(FDynamicPOIMaxActorCondition, MaxAreaSize) == 0x4, "Offset mismatch for FDynamicPOIMaxActorCondition::MaxAreaSize");
static_assert(offsetof(FDynamicPOIMaxActorCondition, MaxCount) == 0x8, "Offset mismatch for FDynamicPOIMaxActorCondition::MaxCount");

