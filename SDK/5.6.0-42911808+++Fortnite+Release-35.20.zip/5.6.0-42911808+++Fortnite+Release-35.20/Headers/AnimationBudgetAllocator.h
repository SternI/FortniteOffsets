/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationBudgetAllocator
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

private:
    static void EnableAnimationBudget(UObject*& WorldContextObject, bool& bEnabled); // 0xb24dcfc (Index: 0x0, Flags: Final|Native|Static|Private|BlueprintCallable)
    static void SetAnimationBudgetParameters(UObject*& WorldContextObject, const FAnimationBudgetAllocatorParameters InParameters); // 0xb24df48 (Index: 0x1, Flags: Final|Native|Static|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnimationBudgetBlueprintLibrary) == 0x28, "Size mismatch for UAnimationBudgetBlueprintLibrary");

// Size: 0xff0 (Inherited: 0x2650, Single: 0xffffe9a0)
class USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
public:
    uint8_t Pad_fd0[0x18]; // 0xfd0 (Size: 0x18, Type: PaddingProperty)
    uint8_t bAutoRegisterWithBudgetAllocator : 1; // 0xfe8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAutoCalculateSignificance : 1; // 0xfe8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldUseActorRenderedFlag : 1; // 0xfe8:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_fe9[0x7]; // 0xfe9 (Size: 0x7, Type: PaddingProperty)

public:
    void SetAutoRegisterWithBudgetAllocator(bool& bInAutoRegisterWithBudgetAllocator); // 0xb24e158 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(USkeletalMeshComponentBudgeted) == 0xff0, "Size mismatch for USkeletalMeshComponentBudgeted");
static_assert(offsetof(USkeletalMeshComponentBudgeted, bAutoRegisterWithBudgetAllocator) == 0xfe8, "Offset mismatch for USkeletalMeshComponentBudgeted::bAutoRegisterWithBudgetAllocator");
static_assert(offsetof(USkeletalMeshComponentBudgeted, bAutoCalculateSignificance) == 0xfe8, "Offset mismatch for USkeletalMeshComponentBudgeted::bAutoCalculateSignificance");
static_assert(offsetof(USkeletalMeshComponentBudgeted, bShouldUseActorRenderedFlag) == 0xfe8, "Offset mismatch for USkeletalMeshComponentBudgeted::bShouldUseActorRenderedFlag");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FAnimationBudgetAllocatorParameters
{
    float BudgetInMs; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinQuality; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MaxTickRate; // 0x8 (Size: 0x4, Type: IntProperty)
    float WorkUnitSmoothingSpeed; // 0xc (Size: 0x4, Type: FloatProperty)
    float AlwaysTickFalloffAggression; // 0x10 (Size: 0x4, Type: FloatProperty)
    float InterpolationFalloffAggression; // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t InterpolationMaxRate; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t MaxInterpolatedComponents; // 0x1c (Size: 0x4, Type: IntProperty)
    float InterpolationTickMultiplier; // 0x20 (Size: 0x4, Type: FloatProperty)
    float InitialEstimatedWorkUnitTimeMs; // 0x24 (Size: 0x4, Type: FloatProperty)
    int32_t MaxTickedOffsreenComponents; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t StateChangeThrottleInFrames; // 0x2c (Size: 0x4, Type: IntProperty)
    float BudgetFactorBeforeReducedWork; // 0x30 (Size: 0x4, Type: FloatProperty)
    float BudgetFactorBeforeReducedWorkEpsilon; // 0x34 (Size: 0x4, Type: FloatProperty)
    float BudgetPressureSmoothingSpeed; // 0x38 (Size: 0x4, Type: FloatProperty)
    int32_t ReducedWorkThrottleMinInFrames; // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t ReducedWorkThrottleMaxInFrames; // 0x40 (Size: 0x4, Type: IntProperty)
    float BudgetFactorBeforeAggressiveReducedWork; // 0x44 (Size: 0x4, Type: FloatProperty)
    int32_t ReducedWorkThrottleMaxPerFrame; // 0x48 (Size: 0x4, Type: IntProperty)
    float BudgetPressureBeforeEmergencyReducedWork; // 0x4c (Size: 0x4, Type: FloatProperty)
    float AutoCalculatedSignificanceMaxDistance; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimationBudgetAllocatorParameters) == 0x58, "Size mismatch for FAnimationBudgetAllocatorParameters");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, BudgetInMs) == 0x0, "Offset mismatch for FAnimationBudgetAllocatorParameters::BudgetInMs");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, MinQuality) == 0x4, "Offset mismatch for FAnimationBudgetAllocatorParameters::MinQuality");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, MaxTickRate) == 0x8, "Offset mismatch for FAnimationBudgetAllocatorParameters::MaxTickRate");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, WorkUnitSmoothingSpeed) == 0xc, "Offset mismatch for FAnimationBudgetAllocatorParameters::WorkUnitSmoothingSpeed");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, AlwaysTickFalloffAggression) == 0x10, "Offset mismatch for FAnimationBudgetAllocatorParameters::AlwaysTickFalloffAggression");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, InterpolationFalloffAggression) == 0x14, "Offset mismatch for FAnimationBudgetAllocatorParameters::InterpolationFalloffAggression");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, InterpolationMaxRate) == 0x18, "Offset mismatch for FAnimationBudgetAllocatorParameters::InterpolationMaxRate");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, MaxInterpolatedComponents) == 0x1c, "Offset mismatch for FAnimationBudgetAllocatorParameters::MaxInterpolatedComponents");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, InterpolationTickMultiplier) == 0x20, "Offset mismatch for FAnimationBudgetAllocatorParameters::InterpolationTickMultiplier");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, InitialEstimatedWorkUnitTimeMs) == 0x24, "Offset mismatch for FAnimationBudgetAllocatorParameters::InitialEstimatedWorkUnitTimeMs");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, MaxTickedOffsreenComponents) == 0x28, "Offset mismatch for FAnimationBudgetAllocatorParameters::MaxTickedOffsreenComponents");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, StateChangeThrottleInFrames) == 0x2c, "Offset mismatch for FAnimationBudgetAllocatorParameters::StateChangeThrottleInFrames");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, BudgetFactorBeforeReducedWork) == 0x30, "Offset mismatch for FAnimationBudgetAllocatorParameters::BudgetFactorBeforeReducedWork");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, BudgetFactorBeforeReducedWorkEpsilon) == 0x34, "Offset mismatch for FAnimationBudgetAllocatorParameters::BudgetFactorBeforeReducedWorkEpsilon");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, BudgetPressureSmoothingSpeed) == 0x38, "Offset mismatch for FAnimationBudgetAllocatorParameters::BudgetPressureSmoothingSpeed");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, ReducedWorkThrottleMinInFrames) == 0x3c, "Offset mismatch for FAnimationBudgetAllocatorParameters::ReducedWorkThrottleMinInFrames");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, ReducedWorkThrottleMaxInFrames) == 0x40, "Offset mismatch for FAnimationBudgetAllocatorParameters::ReducedWorkThrottleMaxInFrames");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, BudgetFactorBeforeAggressiveReducedWork) == 0x44, "Offset mismatch for FAnimationBudgetAllocatorParameters::BudgetFactorBeforeAggressiveReducedWork");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, ReducedWorkThrottleMaxPerFrame) == 0x48, "Offset mismatch for FAnimationBudgetAllocatorParameters::ReducedWorkThrottleMaxPerFrame");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, BudgetPressureBeforeEmergencyReducedWork) == 0x4c, "Offset mismatch for FAnimationBudgetAllocatorParameters::BudgetPressureBeforeEmergencyReducedWork");
static_assert(offsetof(FAnimationBudgetAllocatorParameters, AutoCalculatedSignificanceMaxDistance) == 0x50, "Offset mismatch for FAnimationBudgetAllocatorParameters::AutoCalculatedSignificanceMaxDistance");

