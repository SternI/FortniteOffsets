/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_GameStateComponent_PlaytimeRewards
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "PlaytimeRewardsRuntime.h"

// Size: 0xe8 (Inherited: 0x3f0, Single: 0xfffffcf8)
class UBP_GameStateComponent_PlaytimeRewards_C : public UFortGameStateComponent_PlaytimeRewards
{
public:
};

static_assert(sizeof(UBP_GameStateComponent_PlaytimeRewards_C) == 0xe8, "Size mismatch for UBP_GameStateComponent_PlaytimeRewards_C");

