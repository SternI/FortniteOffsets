/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ArmoredBattleBusRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x13c0 (Inherited: 0x20a8, Single: 0xfffff318)
class UFortArmoredBattleBusPassengerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    FRotator PreviousVehicleRotator; // 0x12f0 (Size: 0x18, Type: StructProperty)
    float SmoothedVehicleYawRate; // 0x1308 (Size: 0x4, Type: FloatProperty)
    int32_t PawnSeat; // 0x130c (Size: 0x4, Type: IntProperty)
    bool bIsFrontTurretPassenger; // 0x1310 (Size: 0x1, Type: BoolProperty)
    bool bIsRearTurretPassenger; // 0x1311 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1312[0x2]; // 0x1312 (Size: 0x2, Type: PaddingProperty)
    float Speed; // 0x1314 (Size: 0x4, Type: FloatProperty)
    float YawDelta; // 0x1318 (Size: 0x4, Type: FloatProperty)
    float TurretYaw; // 0x131c (Size: 0x4, Type: FloatProperty)
    float TurretPitch; // 0x1320 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1324[0x4]; // 0x1324 (Size: 0x4, Type: PaddingProperty)
    FRotator TurretYawRotator; // 0x1328 (Size: 0x18, Type: StructProperty)
    float SlopeRollDegreeAngle; // 0x1340 (Size: 0x4, Type: FloatProperty)
    float SlopePitchDegreeAngle; // 0x1344 (Size: 0x4, Type: FloatProperty)
    FVector HandAttachL; // 0x1348 (Size: 0x18, Type: StructProperty)
    FVector HandAttachR; // 0x1360 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ERelativeTransformSpace> TransformSpace; // 0x1378 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1379[0x3]; // 0x1379 (Size: 0x3, Type: PaddingProperty)
    float UpdateYawDeltaSmoothedLerpRate; // 0x137c (Size: 0x4, Type: FloatProperty)
    int32_t TurretPassengerFront; // 0x1380 (Size: 0x4, Type: IntProperty)
    int32_t TurretPassengerRear; // 0x1384 (Size: 0x4, Type: IntProperty)
    FName FrontFootBoneName; // 0x1388 (Size: 0x4, Type: NameProperty)
    FName RearFootBoneName; // 0x138c (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_FrontLeft; // 0x1390 (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_RearLeft; // 0x1394 (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_FrontRight; // 0x1398 (Size: 0x4, Type: NameProperty)
    FName GunHandAttachBoneName_RearRight; // 0x139c (Size: 0x4, Type: NameProperty)
    FName PassengerBoneName_Front; // 0x13a0 (Size: 0x4, Type: NameProperty)
    FName PassengerBoneName_Rear; // 0x13a4 (Size: 0x4, Type: NameProperty)
    float TurretPitchDegMin; // 0x13a8 (Size: 0x4, Type: FloatProperty)
    float TurretPitchDegMax; // 0x13ac (Size: 0x4, Type: FloatProperty)
    float LocalPlayerTurretPitchEaseRate; // 0x13b0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13b4[0xc]; // 0x13b4 (Size: 0xc, Type: PaddingProperty)

public:
    void GenerateCharacterPitchAndYawForSlopedTerrain(AFortAthenaVehicle*& const VehicleActor, float& TurretYaw, float& TurretPitch, FRotator& PawnYawRotator); // 0x100760a8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FTransform GetFootAttachTransform(USkeletalMeshComponent*& const BusMeshComponent); // 0x100763a0 (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    FVector GetHandAttachLocation(USkeletalMeshComponent*& const BusMeshComponent, FName& const FrontHandAttachBoneName, FName& const RearHandAttachBoneName); // 0x10076524 (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    FTransform GetPassengerTransform(USkeletalMeshComponent*& const BusMeshComponent); // 0x10076824 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    FVector UnrotateHandAttachLocation(const FVector HandLocation, const FVector FootLocation, const FRotator FootRotation); // 0x10076e00 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void UpdateHandPositionsSlopeValues(USkeletalMeshComponent*& const BusMeshComponent); // 0x10077030 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateSmoothedVehicleYawRate(AFortAthenaVehicle*& const VehicleActor); // 0x1007715c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateYawDeltaSmoothed(AFortAthenaVehicle*& const VehicleActor, FName& const SocketName, const FRotator NewRotation, float& SmoothedYawValue); // 0x10077a24 (Index: 0x7, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFortArmoredBattleBusPassengerAnimInstance) == 0x13c0, "Size mismatch for UFortArmoredBattleBusPassengerAnimInstance");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, PreviousVehicleRotator) == 0x12f0, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::PreviousVehicleRotator");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, SmoothedVehicleYawRate) == 0x1308, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::SmoothedVehicleYawRate");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, PawnSeat) == 0x130c, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::PawnSeat");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, bIsFrontTurretPassenger) == 0x1310, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::bIsFrontTurretPassenger");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, bIsRearTurretPassenger) == 0x1311, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::bIsRearTurretPassenger");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, Speed) == 0x1314, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::Speed");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, YawDelta) == 0x1318, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::YawDelta");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretYaw) == 0x131c, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretYaw");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretPitch) == 0x1320, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretPitch");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretYawRotator) == 0x1328, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretYawRotator");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, SlopeRollDegreeAngle) == 0x1340, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::SlopeRollDegreeAngle");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, SlopePitchDegreeAngle) == 0x1344, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::SlopePitchDegreeAngle");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, HandAttachL) == 0x1348, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::HandAttachL");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, HandAttachR) == 0x1360, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::HandAttachR");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TransformSpace) == 0x1378, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TransformSpace");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, UpdateYawDeltaSmoothedLerpRate) == 0x137c, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::UpdateYawDeltaSmoothedLerpRate");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretPassengerFront) == 0x1380, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretPassengerFront");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretPassengerRear) == 0x1384, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretPassengerRear");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, FrontFootBoneName) == 0x1388, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::FrontFootBoneName");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, RearFootBoneName) == 0x138c, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::RearFootBoneName");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, GunHandAttachBoneName_FrontLeft) == 0x1390, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::GunHandAttachBoneName_FrontLeft");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, GunHandAttachBoneName_RearLeft) == 0x1394, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::GunHandAttachBoneName_RearLeft");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, GunHandAttachBoneName_FrontRight) == 0x1398, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::GunHandAttachBoneName_FrontRight");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, GunHandAttachBoneName_RearRight) == 0x139c, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::GunHandAttachBoneName_RearRight");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, PassengerBoneName_Front) == 0x13a0, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::PassengerBoneName_Front");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, PassengerBoneName_Rear) == 0x13a4, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::PassengerBoneName_Rear");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretPitchDegMin) == 0x13a8, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretPitchDegMin");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, TurretPitchDegMax) == 0x13ac, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::TurretPitchDegMax");
static_assert(offsetof(UFortArmoredBattleBusPassengerAnimInstance, LocalPlayerTurretPitchEaseRate) == 0x13b0, "Offset mismatch for UFortArmoredBattleBusPassengerAnimInstance::LocalPlayerTurretPitchEaseRate");

// Size: 0x730 (Inherited: 0xf78, Single: 0xfffff7b8)
class UFortArmoredBattleBusVehicleAnimInstance : public UFortVehicleAnimInstance
{
public:
    float FrontTurretAimPitch; // 0x698 (Size: 0x4, Type: FloatProperty)
    float RearTurretAimPitch; // 0x69c (Size: 0x4, Type: FloatProperty)
    float FrontYawDeltaSmoothed; // 0x6a0 (Size: 0x4, Type: FloatProperty)
    float RearYawDeltaSmoothed; // 0x6a4 (Size: 0x4, Type: FloatProperty)
    float SmoothedVehicleYawRate; // 0x6a8 (Size: 0x4, Type: FloatProperty)
    float FrontYawDeltaSmoothedAlpha; // 0x6ac (Size: 0x4, Type: FloatProperty)
    float RearYawDeltaSmoothedAlpha; // 0x6b0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6b4[0x4]; // 0x6b4 (Size: 0x4, Type: PaddingProperty)
    FRotator FrontWeaponYaw; // 0x6b8 (Size: 0x18, Type: StructProperty)
    FRotator RearWeaponYaw; // 0x6d0 (Size: 0x18, Type: StructProperty)
    FRotator PreviousVehicleRotator; // 0x6e8 (Size: 0x18, Type: StructProperty)
    bool bHasFrontTurretPassenger; // 0x700 (Size: 0x1, Type: BoolProperty)
    bool bHasRearTurretPassenger; // 0x701 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_702[0x2]; // 0x702 (Size: 0x2, Type: PaddingProperty)
    float NetworkEaseRate; // 0x704 (Size: 0x4, Type: FloatProperty)
    float UpdateYawDeltaSmoothedLerpRate; // 0x708 (Size: 0x4, Type: FloatProperty)
    int32_t FrontPassengerSeatIndex; // 0x70c (Size: 0x4, Type: IntProperty)
    int32_t RearPassengerSeatIndex; // 0x710 (Size: 0x4, Type: IntProperty)
    float FrontPassengerYawOffset; // 0x714 (Size: 0x4, Type: FloatProperty)
    float RearPassengerYawOffset; // 0x718 (Size: 0x4, Type: FloatProperty)
    FName FrontPassengerBoneName; // 0x71c (Size: 0x4, Type: NameProperty)
    FName RearPassengerBoneName; // 0x720 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_724[0xc]; // 0x724 (Size: 0xc, Type: PaddingProperty)

public:
    void GetPitchAndYaw(AFortAthenaVehicle*& const VehicleActor, AFortPlayerPawn*& const GunnerActor, float& AdjustedPitch, float& AdjustedYaw, bool& bIsLocalPlayerControlled, FRotator& YawRotator); // 0x100769a8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    float UpdateSmoothedVehicleYawRate(AFortAthenaVehicle*& const VehicleActor, FRotator& const PreviousRotator); // 0x10077308 (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void UpdateTurretAimPitchWeaponYaw(AFortAthenaVehicle*& const OwnerVehicle, AFortPlayerPawn*& const GunnerActor, FName& const SocketName, float& const YawOffset, float& TurretAimPitch, float& YawDeltaSmoothed, FRotator& WeaponYaw); // 0x1007754c (Index: 0x2, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    float UpdateYawDeltaSmoothed(AFortAthenaVehicle*& const VehicleActor, FName& const SocketName, FRotator& const NewRotation, float& const SmoothedYawValue); // 0x10077d58 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFortArmoredBattleBusVehicleAnimInstance) == 0x730, "Size mismatch for UFortArmoredBattleBusVehicleAnimInstance");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontTurretAimPitch) == 0x698, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontTurretAimPitch");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearTurretAimPitch) == 0x69c, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearTurretAimPitch");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontYawDeltaSmoothed) == 0x6a0, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontYawDeltaSmoothed");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearYawDeltaSmoothed) == 0x6a4, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearYawDeltaSmoothed");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, SmoothedVehicleYawRate) == 0x6a8, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::SmoothedVehicleYawRate");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontYawDeltaSmoothedAlpha) == 0x6ac, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontYawDeltaSmoothedAlpha");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearYawDeltaSmoothedAlpha) == 0x6b0, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearYawDeltaSmoothedAlpha");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontWeaponYaw) == 0x6b8, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontWeaponYaw");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearWeaponYaw) == 0x6d0, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearWeaponYaw");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, PreviousVehicleRotator) == 0x6e8, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::PreviousVehicleRotator");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, bHasFrontTurretPassenger) == 0x700, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::bHasFrontTurretPassenger");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, bHasRearTurretPassenger) == 0x701, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::bHasRearTurretPassenger");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, NetworkEaseRate) == 0x704, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::NetworkEaseRate");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, UpdateYawDeltaSmoothedLerpRate) == 0x708, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::UpdateYawDeltaSmoothedLerpRate");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontPassengerSeatIndex) == 0x70c, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontPassengerSeatIndex");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearPassengerSeatIndex) == 0x710, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearPassengerSeatIndex");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontPassengerYawOffset) == 0x714, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontPassengerYawOffset");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearPassengerYawOffset) == 0x718, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearPassengerYawOffset");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, FrontPassengerBoneName) == 0x71c, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::FrontPassengerBoneName");
static_assert(offsetof(UFortArmoredBattleBusVehicleAnimInstance, RearPassengerBoneName) == 0x720, "Offset mismatch for UFortArmoredBattleBusVehicleAnimInstance::RearPassengerBoneName");

