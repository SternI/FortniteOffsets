/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChainsawGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0x400 (Inherited: 0x408, Single: 0xfffffff8)
class UChainsawAnimInstance : public UAnimInstance
{
public:
    double ChainPlayRate; // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    bool bIsSpinning; // 0x3e0 (Size: 0x1, Type: BoolProperty)
    bool bIsSprinting; // 0x3e1 (Size: 0x1, Type: BoolProperty)
    bool bIsEquip; // 0x3e2 (Size: 0x1, Type: BoolProperty)
    bool bIsNotEquip; // 0x3e3 (Size: 0x1, Type: BoolProperty)
    bool bIsFalling; // 0x3e4 (Size: 0x1, Type: BoolProperty)
    bool bIsSliding; // 0x3e5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e6[0x2]; // 0x3e6 (Size: 0x2, Type: PaddingProperty)
    FGameplayTag SprintTagName; // 0x3e8 (Size: 0x4, Type: StructProperty)
    FGameplayTag EquippedTagName; // 0x3ec (Size: 0x4, Type: StructProperty)
    FGameplayTag FallingTagName; // 0x3f0 (Size: 0x4, Type: StructProperty)
    FGameplayTag SlidingTagName; // 0x3f4 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_3f8[0x8]; // 0x3f8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UChainsawAnimInstance) == 0x400, "Size mismatch for UChainsawAnimInstance");
static_assert(offsetof(UChainsawAnimInstance, ChainPlayRate) == 0x3d8, "Offset mismatch for UChainsawAnimInstance::ChainPlayRate");
static_assert(offsetof(UChainsawAnimInstance, bIsSpinning) == 0x3e0, "Offset mismatch for UChainsawAnimInstance::bIsSpinning");
static_assert(offsetof(UChainsawAnimInstance, bIsSprinting) == 0x3e1, "Offset mismatch for UChainsawAnimInstance::bIsSprinting");
static_assert(offsetof(UChainsawAnimInstance, bIsEquip) == 0x3e2, "Offset mismatch for UChainsawAnimInstance::bIsEquip");
static_assert(offsetof(UChainsawAnimInstance, bIsNotEquip) == 0x3e3, "Offset mismatch for UChainsawAnimInstance::bIsNotEquip");
static_assert(offsetof(UChainsawAnimInstance, bIsFalling) == 0x3e4, "Offset mismatch for UChainsawAnimInstance::bIsFalling");
static_assert(offsetof(UChainsawAnimInstance, bIsSliding) == 0x3e5, "Offset mismatch for UChainsawAnimInstance::bIsSliding");
static_assert(offsetof(UChainsawAnimInstance, SprintTagName) == 0x3e8, "Offset mismatch for UChainsawAnimInstance::SprintTagName");
static_assert(offsetof(UChainsawAnimInstance, EquippedTagName) == 0x3ec, "Offset mismatch for UChainsawAnimInstance::EquippedTagName");
static_assert(offsetof(UChainsawAnimInstance, FallingTagName) == 0x3f0, "Offset mismatch for UChainsawAnimInstance::FallingTagName");
static_assert(offsetof(UChainsawAnimInstance, SlidingTagName) == 0x3f4, "Offset mismatch for UChainsawAnimInstance::SlidingTagName");

// Size: 0x58 (Inherited: 0x88, Single: 0xffffffd0)
class UChainsawAttributeSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData Overheat; // 0x30 (Size: 0x28, Type: StructProperty)

private:
    void OnRep_Overheat(const FFortGameplayAttributeData OldValue); // 0x1133ddc4 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UChainsawAttributeSet) == 0x58, "Size mismatch for UChainsawAttributeSet");
static_assert(offsetof(UChainsawAttributeSet, Overheat) == 0x30, "Offset mismatch for UChainsawAttributeSet::Overheat");

// Size: 0x1400 (Inherited: 0x20a8, Single: 0xfffff358)
class UChainsawLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bIsChainsawScooter; // 0x12f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12f1[0x3]; // 0x12f1 (Size: 0x3, Type: PaddingProperty)
    float LeanX; // 0x12f4 (Size: 0x4, Type: FloatProperty)
    float LeanY; // 0x12f8 (Size: 0x4, Type: FloatProperty)
    bool bIsFallingIntoScooter; // 0x12fc (Size: 0x1, Type: BoolProperty)
    bool bIsScooterFalling; // 0x12fd (Size: 0x1, Type: BoolProperty)
    bool bIsNotChainsawScooter; // 0x12fe (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12ff[0x1]; // 0x12ff (Size: 0x1, Type: PaddingProperty)
    float CustomMeleeTwist; // 0x1300 (Size: 0x4, Type: FloatProperty)
    bool bIsNotEquip; // 0x1304 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1305[0x3]; // 0x1305 (Size: 0x3, Type: PaddingProperty)
    float ChainsawScooterPelvisOffset; // 0x1308 (Size: 0x4, Type: FloatProperty)
    bool bIsUpperBodyEquip; // 0x130c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_130d[0x3]; // 0x130d (Size: 0x3, Type: PaddingProperty)
    double ForwardSpeedInterp; // 0x1310 (Size: 0x8, Type: DoubleProperty)
    double LateralSpeedInterp; // 0x1318 (Size: 0x8, Type: DoubleProperty)
    bool bIsSlidingMovementMode; // 0x1320 (Size: 0x1, Type: BoolProperty)
    bool bIsOtherMovementMode; // 0x1321 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1322[0x2]; // 0x1322 (Size: 0x2, Type: PaddingProperty)
    FGameplayTag StartedSharpTurnTagName; // 0x1324 (Size: 0x4, Type: StructProperty)
    FGameplayTag EndedSharpTurnTagName; // 0x1328 (Size: 0x4, Type: StructProperty)
    FGameplayTag FallingIntoScooterTagName; // 0x132c (Size: 0x4, Type: StructProperty)
    FGameplayTag HoldingScooterButtonTagName; // 0x1330 (Size: 0x4, Type: StructProperty)
    FGameplayTag ScooteringTagName; // 0x1334 (Size: 0x4, Type: StructProperty)
    FGameplayTag ZipliningOnSplineTagName; // 0x1338 (Size: 0x4, Type: StructProperty)
    FGameplayTag SurfaceSwimmingTagName; // 0x133c (Size: 0x4, Type: StructProperty)
    FGameplayTag ParachutingTagName; // 0x1340 (Size: 0x4, Type: StructProperty)
    FGameplayTag SkydivingTagName; // 0x1344 (Size: 0x4, Type: StructProperty)
    FGameplayTag BallooningTagName; // 0x1348 (Size: 0x4, Type: StructProperty)
    FGameplayTag GrindingTagName; // 0x134c (Size: 0x4, Type: StructProperty)
    FGameplayTag SlidingTagName; // 0x1350 (Size: 0x4, Type: StructProperty)
    FGameplayTag DrivingTagName; // 0x1354 (Size: 0x4, Type: StructProperty)
    FGameplayTag PassengerTagName; // 0x1358 (Size: 0x4, Type: StructProperty)
    FGameplayTag ChainsawTagName; // 0x135c (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1360[0xa0]; // 0x1360 (Size: 0xa0, Type: PaddingProperty)
};

static_assert(sizeof(UChainsawLayerAnimInstance) == 0x1400, "Size mismatch for UChainsawLayerAnimInstance");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsChainsawScooter) == 0x12f0, "Offset mismatch for UChainsawLayerAnimInstance::bIsChainsawScooter");
static_assert(offsetof(UChainsawLayerAnimInstance, LeanX) == 0x12f4, "Offset mismatch for UChainsawLayerAnimInstance::LeanX");
static_assert(offsetof(UChainsawLayerAnimInstance, LeanY) == 0x12f8, "Offset mismatch for UChainsawLayerAnimInstance::LeanY");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsFallingIntoScooter) == 0x12fc, "Offset mismatch for UChainsawLayerAnimInstance::bIsFallingIntoScooter");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsScooterFalling) == 0x12fd, "Offset mismatch for UChainsawLayerAnimInstance::bIsScooterFalling");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsNotChainsawScooter) == 0x12fe, "Offset mismatch for UChainsawLayerAnimInstance::bIsNotChainsawScooter");
static_assert(offsetof(UChainsawLayerAnimInstance, CustomMeleeTwist) == 0x1300, "Offset mismatch for UChainsawLayerAnimInstance::CustomMeleeTwist");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsNotEquip) == 0x1304, "Offset mismatch for UChainsawLayerAnimInstance::bIsNotEquip");
static_assert(offsetof(UChainsawLayerAnimInstance, ChainsawScooterPelvisOffset) == 0x1308, "Offset mismatch for UChainsawLayerAnimInstance::ChainsawScooterPelvisOffset");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsUpperBodyEquip) == 0x130c, "Offset mismatch for UChainsawLayerAnimInstance::bIsUpperBodyEquip");
static_assert(offsetof(UChainsawLayerAnimInstance, ForwardSpeedInterp) == 0x1310, "Offset mismatch for UChainsawLayerAnimInstance::ForwardSpeedInterp");
static_assert(offsetof(UChainsawLayerAnimInstance, LateralSpeedInterp) == 0x1318, "Offset mismatch for UChainsawLayerAnimInstance::LateralSpeedInterp");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsSlidingMovementMode) == 0x1320, "Offset mismatch for UChainsawLayerAnimInstance::bIsSlidingMovementMode");
static_assert(offsetof(UChainsawLayerAnimInstance, bIsOtherMovementMode) == 0x1321, "Offset mismatch for UChainsawLayerAnimInstance::bIsOtherMovementMode");
static_assert(offsetof(UChainsawLayerAnimInstance, StartedSharpTurnTagName) == 0x1324, "Offset mismatch for UChainsawLayerAnimInstance::StartedSharpTurnTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, EndedSharpTurnTagName) == 0x1328, "Offset mismatch for UChainsawLayerAnimInstance::EndedSharpTurnTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, FallingIntoScooterTagName) == 0x132c, "Offset mismatch for UChainsawLayerAnimInstance::FallingIntoScooterTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, HoldingScooterButtonTagName) == 0x1330, "Offset mismatch for UChainsawLayerAnimInstance::HoldingScooterButtonTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, ScooteringTagName) == 0x1334, "Offset mismatch for UChainsawLayerAnimInstance::ScooteringTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, ZipliningOnSplineTagName) == 0x1338, "Offset mismatch for UChainsawLayerAnimInstance::ZipliningOnSplineTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, SurfaceSwimmingTagName) == 0x133c, "Offset mismatch for UChainsawLayerAnimInstance::SurfaceSwimmingTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, ParachutingTagName) == 0x1340, "Offset mismatch for UChainsawLayerAnimInstance::ParachutingTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, SkydivingTagName) == 0x1344, "Offset mismatch for UChainsawLayerAnimInstance::SkydivingTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, BallooningTagName) == 0x1348, "Offset mismatch for UChainsawLayerAnimInstance::BallooningTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, GrindingTagName) == 0x134c, "Offset mismatch for UChainsawLayerAnimInstance::GrindingTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, SlidingTagName) == 0x1350, "Offset mismatch for UChainsawLayerAnimInstance::SlidingTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, DrivingTagName) == 0x1354, "Offset mismatch for UChainsawLayerAnimInstance::DrivingTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, PassengerTagName) == 0x1358, "Offset mismatch for UChainsawLayerAnimInstance::PassengerTagName");
static_assert(offsetof(UChainsawLayerAnimInstance, ChainsawTagName) == 0x135c, "Offset mismatch for UChainsawLayerAnimInstance::ChainsawTagName");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class UFortMovementMode_ChainsawRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_ChainsawRuntimeData) == 0x50, "Size mismatch for UFortMovementMode_ChainsawRuntimeData");

// Size: 0x420 (Inherited: 0x210, Single: 0x210)
class UFortMovementMode_ExtChainsaw : public UFortMovementMode_BaseExtLogic
{
public:
    FGameplayTag TAG_Scootering; // 0x1e8 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_BlockedByObstacle; // 0x1ec (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_StopSawScooter; // 0x1f0 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_StopSawScooterFromLedgeFall; // 0x1f4 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_StartedSharpTurn; // 0x1f8 (Size: 0x4, Type: StructProperty)
    FGameplayTag TAG_EndedSharpTurn; // 0x1fc (Size: 0x4, Type: StructProperty)
    FScalableFloat SpeedDefault; // 0x200 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_228[0x8]; // 0x228 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat SpeedBlocked; // 0x230 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_258[0x8]; // 0x258 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat SpeedSharpTurn; // 0x260 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_288[0x8]; // 0x288 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat InterpSpeedDefault; // 0x290 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat InterpSpeedBlocked; // 0x2c0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2e8[0x8]; // 0x2e8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat TurnSpeedDefault; // 0x2f0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_318[0x8]; // 0x318 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat TurnSpeedSharpTurn; // 0x320 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_348[0x8]; // 0x348 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat DotProductSharpTurn; // 0x350 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_378[0x8]; // 0x378 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat DotProductStraightenedOut; // 0x380 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_3a8[0x8]; // 0x3a8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat MinTimeForSharpTurn; // 0x3b0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_3d8[0x8]; // 0x3d8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat GoalDirectionThreshold; // 0x3e0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    bool bDeNativize; // 0x410 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_411[0x7]; // 0x411 (Size: 0x7, Type: PaddingProperty)
    UClass* DenativizedRuntimeDataClass; // 0x418 (Size: 0x8, Type: ClassProperty)

protected:
    virtual void BP_PhysUpdate(const FMMERuntimeContext RuntimeContext, const FVector InVelocity, const FVector InAcceleration, FVector& ResultVelocity, FVector& ResultAcceleration); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual EFortMovementModeExt_UpdateResult BP_UpdateBeforeCharacterMovement(const FMMERuntimeContext RuntimeContext); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortMovementMode_ExtChainsaw) == 0x420, "Size mismatch for UFortMovementMode_ExtChainsaw");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TAG_Scootering) == 0x1e8, "Offset mismatch for UFortMovementMode_ExtChainsaw::TAG_Scootering");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TAG_BlockedByObstacle) == 0x1ec, "Offset mismatch for UFortMovementMode_ExtChainsaw::TAG_BlockedByObstacle");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TAG_StopSawScooter) == 0x1f0, "Offset mismatch for UFortMovementMode_ExtChainsaw::TAG_StopSawScooter");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TAG_StopSawScooterFromLedgeFall) == 0x1f4, "Offset mismatch for UFortMovementMode_ExtChainsaw::TAG_StopSawScooterFromLedgeFall");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TAG_StartedSharpTurn) == 0x1f8, "Offset mismatch for UFortMovementMode_ExtChainsaw::TAG_StartedSharpTurn");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TAG_EndedSharpTurn) == 0x1fc, "Offset mismatch for UFortMovementMode_ExtChainsaw::TAG_EndedSharpTurn");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, SpeedDefault) == 0x200, "Offset mismatch for UFortMovementMode_ExtChainsaw::SpeedDefault");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, SpeedBlocked) == 0x230, "Offset mismatch for UFortMovementMode_ExtChainsaw::SpeedBlocked");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, SpeedSharpTurn) == 0x260, "Offset mismatch for UFortMovementMode_ExtChainsaw::SpeedSharpTurn");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, InterpSpeedDefault) == 0x290, "Offset mismatch for UFortMovementMode_ExtChainsaw::InterpSpeedDefault");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, InterpSpeedBlocked) == 0x2c0, "Offset mismatch for UFortMovementMode_ExtChainsaw::InterpSpeedBlocked");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TurnSpeedDefault) == 0x2f0, "Offset mismatch for UFortMovementMode_ExtChainsaw::TurnSpeedDefault");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, TurnSpeedSharpTurn) == 0x320, "Offset mismatch for UFortMovementMode_ExtChainsaw::TurnSpeedSharpTurn");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, DotProductSharpTurn) == 0x350, "Offset mismatch for UFortMovementMode_ExtChainsaw::DotProductSharpTurn");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, DotProductStraightenedOut) == 0x380, "Offset mismatch for UFortMovementMode_ExtChainsaw::DotProductStraightenedOut");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, MinTimeForSharpTurn) == 0x3b0, "Offset mismatch for UFortMovementMode_ExtChainsaw::MinTimeForSharpTurn");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, GoalDirectionThreshold) == 0x3e0, "Offset mismatch for UFortMovementMode_ExtChainsaw::GoalDirectionThreshold");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, bDeNativize) == 0x410, "Offset mismatch for UFortMovementMode_ExtChainsaw::bDeNativize");
static_assert(offsetof(UFortMovementMode_ExtChainsaw, DenativizedRuntimeDataClass) == 0x418, "Offset mismatch for UFortMovementMode_ExtChainsaw::DenativizedRuntimeDataClass");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FFortMovementMode_ChainsawCreationData : FFortMovementMode_BaseExtCreationData
{
};

static_assert(sizeof(FFortMovementMode_ChainsawCreationData) == 0x10, "Size mismatch for FFortMovementMode_ChainsawCreationData");

