/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayCueNotifies
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "EngineCameras.h"
#include "Niagara.h"
#include "Blueprints.h"
#include "Athena.h"

// Size: 0x7b8 (Inherited: 0xf18, Single: 0xfffff8a0)
class AGCN_RezOut_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_E9C2D3554642468472CCCFA609A39FBC; // 0x570 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_E9C2D3554642468472CCCFA609A39FBC; // 0x574 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_E9C2D3554642468472CCCFA609A39FBC; // 0x578 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_E9C2D3554642468472CCCFA609A39FBC; // 0x57c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_57d[0x3]; // 0x57d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh; // 0x580 (Size: 0x8, Type: ObjectProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_39A37BC9407CF090A09ABDA5A488F776; // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_39A37BC9407CF090A09ABDA5A488F776; // 0x58c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_58d[0x3]; // 0x58d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_GlowCharacterMesh; // 0x590 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_ANIMATION; // 0x598 (Size: 0x1, Type: BoolProperty)
    bool SpawnDrone; // 0x599 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59a[0x6]; // 0x59a (Size: 0x6, Type: PaddingProperty)
    UClass* Teleportation_Drone; // 0x5a0 (Size: 0x8, Type: ClassProperty)
    double Teleport_Bot_AnimPlayRate; // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    double Teleport_Bot_Lifespan; // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Teleportation_Point_Light; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset; // 0x5c0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color; // 0x5d8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs; // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn; // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve; // 0x608 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top; // 0x658 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_65c[0x4]; // 0x65c (Size: 0x4, Type: PaddingProperty)
    double Max_Light_Intensity; // 0x660 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom; // 0x668 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_66c[0x4]; // 0x66c (Size: 0x4, Type: PaddingProperty)
    TArray<USkeletalMeshComponent*> Meshes_to_Dissolve; // 0x670 (Size: 0x10, Type: ArrayProperty)
    ABP_TeleportationDrone_C* Drone; // 0x680 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_CHILDCOMPONENTS; // 0x688 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_689[0x7]; // 0x689 (Size: 0x7, Type: PaddingProperty)
    TArray<UFXSystemComponent*> Particle_Components; // 0x690 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Death_VFX; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Dissolve_Visual_Effect; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    FName Dissolve_VFX_Spawn_Point_Name; // 0x6b0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_6b4[0x4]; // 0x6b4 (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* Base_Elimination_Montage; // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DBNO_Elimination_Montage; // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Skydiving_Elimination_Montage; // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Swimming_Elimination_Montage; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DBNO_Swimming_Elimination_Montage; // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    bool Spawn_VFX_Attached; // 0x6e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6e1[0x7]; // 0x6e1 (Size: 0x7, Type: PaddingProperty)
    double Dissolve_Timeline_Playrate; // 0x6e8 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate; // 0x6f0 (Size: 0x8, Type: DoubleProperty)
    bool DEBUG_REMOVESPAWNVFX; // 0x6f8 (Size: 0x1, Type: BoolProperty)
    bool DEBUG_REMOVESPAWNEDPOINTLIGHT; // 0x6f9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6fa[0x6]; // 0x6fa (Size: 0x6, Type: PaddingProperty)
    UNiagaraSystem* Drone_Visual_Effect; // 0x700 (Size: 0x8, Type: ObjectProperty)
    FName Drone_VFX_Attach_Point; // 0x708 (Size: 0x4, Type: NameProperty)
    bool DEBUG_FXSYSTEMCOMPONENTS; // 0x70c (Size: 0x1, Type: BoolProperty)
    bool DEBUG_IMACTDATA; // 0x70d (Size: 0x1, Type: BoolProperty)
    bool ShouldDelayBetweenAnimAndVFX; // 0x70e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_70f[0x1]; // 0x70f (Size: 0x1, Type: PaddingProperty)
    double DelayBetweenAnimAndVFX; // 0x710 (Size: 0x8, Type: DoubleProperty)
    bool Send_Impact_Location_to_Dissolve_Material; // 0x718 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_719[0x3]; // 0x719 (Size: 0x3, Type: PaddingProperty)
    FName Impact_Location_Parameter_Name; // 0x71c (Size: 0x4, Type: NameProperty)
    FGuid Material_Override_ID; // 0x720 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters; // 0x730 (Size: 0x30, Type: StructProperty)
    FVector On_Death_Hit_Location; // 0x760 (Size: 0x18, Type: StructProperty)
    FVector On_Death_Hit_Momentum; // 0x778 (Size: 0x18, Type: StructProperty)
    bool bIsHeadShot; // 0x790 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_791[0x7]; // 0x791 (Size: 0x7, Type: PaddingProperty)
    FVector On_Death_Hit_Normal; // 0x798 (Size: 0x18, Type: StructProperty)
    USoundBase* RezOutSweetener; // 0x7b0 (Size: 0x8, Type: ObjectProperty)

public:
    void TriggerVFX(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Stop_Looping_Audio(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SpawnSweetenerIfLocal(); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleportation_Light(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleportation_Drone(); // 0x288a61c (Index: 0x8, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Spawn_Drone_VFX(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Dissolve_VFX(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Timeline_Playrates(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_On_Death_Hit_Parameters(const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0xc, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Play_Elmination_AnimMontage(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnBurstGeneric(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UFXSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance) const; // 0x288a61c (Index: 0x11, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    void EndVFX(); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Dissolve_Material_Setup(); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Clean_Up_Teleportation_Light(); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Check_Impact_Location_for_Errors(); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AGCN_RezOut_C) == 0x7b8, "Size mismatch for AGCN_RezOut_C");
static_assert(offsetof(AGCN_RezOut_C, UberGraphFrame) == 0x568, "Offset mismatch for AGCN_RezOut_C::UberGraphFrame");
static_assert(offsetof(AGCN_RezOut_C, TFX_ResOutCharacterMesh_LightIntensity_E9C2D3554642468472CCCFA609A39FBC) == 0x570, "Offset mismatch for AGCN_RezOut_C::TFX_ResOutCharacterMesh_LightIntensity_E9C2D3554642468472CCCFA609A39FBC");
static_assert(offsetof(AGCN_RezOut_C, TFX_ResOutCharacterMesh_ZHeightParam_E9C2D3554642468472CCCFA609A39FBC) == 0x574, "Offset mismatch for AGCN_RezOut_C::TFX_ResOutCharacterMesh_ZHeightParam_E9C2D3554642468472CCCFA609A39FBC");
static_assert(offsetof(AGCN_RezOut_C, TFX_ResOutCharacterMesh_TransitionParam_E9C2D3554642468472CCCFA609A39FBC) == 0x578, "Offset mismatch for AGCN_RezOut_C::TFX_ResOutCharacterMesh_TransitionParam_E9C2D3554642468472CCCFA609A39FBC");
static_assert(offsetof(AGCN_RezOut_C, TFX_ResOutCharacterMesh__Direction_E9C2D3554642468472CCCFA609A39FBC) == 0x57c, "Offset mismatch for AGCN_RezOut_C::TFX_ResOutCharacterMesh__Direction_E9C2D3554642468472CCCFA609A39FBC");
static_assert(offsetof(AGCN_RezOut_C, TFX_ResOutCharacterMesh) == 0x580, "Offset mismatch for AGCN_RezOut_C::TFX_ResOutCharacterMesh");
static_assert(offsetof(AGCN_RezOut_C, TFX_GlowCharacterMesh_EmissiveWarp_39A37BC9407CF090A09ABDA5A488F776) == 0x588, "Offset mismatch for AGCN_RezOut_C::TFX_GlowCharacterMesh_EmissiveWarp_39A37BC9407CF090A09ABDA5A488F776");
static_assert(offsetof(AGCN_RezOut_C, TFX_GlowCharacterMesh__Direction_39A37BC9407CF090A09ABDA5A488F776) == 0x58c, "Offset mismatch for AGCN_RezOut_C::TFX_GlowCharacterMesh__Direction_39A37BC9407CF090A09ABDA5A488F776");
static_assert(offsetof(AGCN_RezOut_C, TFX_GlowCharacterMesh) == 0x590, "Offset mismatch for AGCN_RezOut_C::TFX_GlowCharacterMesh");
static_assert(offsetof(AGCN_RezOut_C, DEBUG_ANIMATION) == 0x598, "Offset mismatch for AGCN_RezOut_C::DEBUG_ANIMATION");
static_assert(offsetof(AGCN_RezOut_C, SpawnDrone) == 0x599, "Offset mismatch for AGCN_RezOut_C::SpawnDrone");
static_assert(offsetof(AGCN_RezOut_C, Teleportation_Drone) == 0x5a0, "Offset mismatch for AGCN_RezOut_C::Teleportation_Drone");
static_assert(offsetof(AGCN_RezOut_C, Teleport_Bot_AnimPlayRate) == 0x5a8, "Offset mismatch for AGCN_RezOut_C::Teleport_Bot_AnimPlayRate");
static_assert(offsetof(AGCN_RezOut_C, Teleport_Bot_Lifespan) == 0x5b0, "Offset mismatch for AGCN_RezOut_C::Teleport_Bot_Lifespan");
static_assert(offsetof(AGCN_RezOut_C, Teleportation_Point_Light) == 0x5b8, "Offset mismatch for AGCN_RezOut_C::Teleportation_Point_Light");
static_assert(offsetof(AGCN_RezOut_C, Teleportation_Light_Offset) == 0x5c0, "Offset mismatch for AGCN_RezOut_C::Teleportation_Light_Offset");
static_assert(offsetof(AGCN_RezOut_C, Teleportation_Light_Color) == 0x5d8, "Offset mismatch for AGCN_RezOut_C::Teleportation_Light_Color");
static_assert(offsetof(AGCN_RezOut_C, DissolveMIDs) == 0x5e8, "Offset mismatch for AGCN_RezOut_C::DissolveMIDs");
static_assert(offsetof(AGCN_RezOut_C, Mat_Chracter_Dissolve) == 0x5f8, "Offset mismatch for AGCN_RezOut_C::Mat_Chracter_Dissolve");
static_assert(offsetof(AGCN_RezOut_C, Pawn) == 0x600, "Offset mismatch for AGCN_RezOut_C::Pawn");
static_assert(offsetof(AGCN_RezOut_C, Dissolve) == 0x608, "Offset mismatch for AGCN_RezOut_C::Dissolve");
static_assert(offsetof(AGCN_RezOut_C, Socket_Mesh_Top) == 0x658, "Offset mismatch for AGCN_RezOut_C::Socket_Mesh_Top");
static_assert(offsetof(AGCN_RezOut_C, Max_Light_Intensity) == 0x660, "Offset mismatch for AGCN_RezOut_C::Max_Light_Intensity");
static_assert(offsetof(AGCN_RezOut_C, Socket_Mesh_Bottom) == 0x668, "Offset mismatch for AGCN_RezOut_C::Socket_Mesh_Bottom");
static_assert(offsetof(AGCN_RezOut_C, Meshes_to_Dissolve) == 0x670, "Offset mismatch for AGCN_RezOut_C::Meshes_to_Dissolve");
static_assert(offsetof(AGCN_RezOut_C, Drone) == 0x680, "Offset mismatch for AGCN_RezOut_C::Drone");
static_assert(offsetof(AGCN_RezOut_C, DEBUG_CHILDCOMPONENTS) == 0x688, "Offset mismatch for AGCN_RezOut_C::DEBUG_CHILDCOMPONENTS");
static_assert(offsetof(AGCN_RezOut_C, Particle_Components) == 0x690, "Offset mismatch for AGCN_RezOut_C::Particle_Components");
static_assert(offsetof(AGCN_RezOut_C, Spawned_Death_VFX) == 0x6a0, "Offset mismatch for AGCN_RezOut_C::Spawned_Death_VFX");
static_assert(offsetof(AGCN_RezOut_C, Dissolve_Visual_Effect) == 0x6a8, "Offset mismatch for AGCN_RezOut_C::Dissolve_Visual_Effect");
static_assert(offsetof(AGCN_RezOut_C, Dissolve_VFX_Spawn_Point_Name) == 0x6b0, "Offset mismatch for AGCN_RezOut_C::Dissolve_VFX_Spawn_Point_Name");
static_assert(offsetof(AGCN_RezOut_C, Base_Elimination_Montage) == 0x6b8, "Offset mismatch for AGCN_RezOut_C::Base_Elimination_Montage");
static_assert(offsetof(AGCN_RezOut_C, DBNO_Elimination_Montage) == 0x6c0, "Offset mismatch for AGCN_RezOut_C::DBNO_Elimination_Montage");
static_assert(offsetof(AGCN_RezOut_C, Skydiving_Elimination_Montage) == 0x6c8, "Offset mismatch for AGCN_RezOut_C::Skydiving_Elimination_Montage");
static_assert(offsetof(AGCN_RezOut_C, Swimming_Elimination_Montage) == 0x6d0, "Offset mismatch for AGCN_RezOut_C::Swimming_Elimination_Montage");
static_assert(offsetof(AGCN_RezOut_C, DBNO_Swimming_Elimination_Montage) == 0x6d8, "Offset mismatch for AGCN_RezOut_C::DBNO_Swimming_Elimination_Montage");
static_assert(offsetof(AGCN_RezOut_C, Spawn_VFX_Attached) == 0x6e0, "Offset mismatch for AGCN_RezOut_C::Spawn_VFX_Attached");
static_assert(offsetof(AGCN_RezOut_C, Dissolve_Timeline_Playrate) == 0x6e8, "Offset mismatch for AGCN_RezOut_C::Dissolve_Timeline_Playrate");
static_assert(offsetof(AGCN_RezOut_C, Glow_Timeline_Playrate) == 0x6f0, "Offset mismatch for AGCN_RezOut_C::Glow_Timeline_Playrate");
static_assert(offsetof(AGCN_RezOut_C, DEBUG_REMOVESPAWNVFX) == 0x6f8, "Offset mismatch for AGCN_RezOut_C::DEBUG_REMOVESPAWNVFX");
static_assert(offsetof(AGCN_RezOut_C, DEBUG_REMOVESPAWNEDPOINTLIGHT) == 0x6f9, "Offset mismatch for AGCN_RezOut_C::DEBUG_REMOVESPAWNEDPOINTLIGHT");
static_assert(offsetof(AGCN_RezOut_C, Drone_Visual_Effect) == 0x700, "Offset mismatch for AGCN_RezOut_C::Drone_Visual_Effect");
static_assert(offsetof(AGCN_RezOut_C, Drone_VFX_Attach_Point) == 0x708, "Offset mismatch for AGCN_RezOut_C::Drone_VFX_Attach_Point");
static_assert(offsetof(AGCN_RezOut_C, DEBUG_FXSYSTEMCOMPONENTS) == 0x70c, "Offset mismatch for AGCN_RezOut_C::DEBUG_FXSYSTEMCOMPONENTS");
static_assert(offsetof(AGCN_RezOut_C, DEBUG_IMACTDATA) == 0x70d, "Offset mismatch for AGCN_RezOut_C::DEBUG_IMACTDATA");
static_assert(offsetof(AGCN_RezOut_C, ShouldDelayBetweenAnimAndVFX) == 0x70e, "Offset mismatch for AGCN_RezOut_C::ShouldDelayBetweenAnimAndVFX");
static_assert(offsetof(AGCN_RezOut_C, DelayBetweenAnimAndVFX) == 0x710, "Offset mismatch for AGCN_RezOut_C::DelayBetweenAnimAndVFX");
static_assert(offsetof(AGCN_RezOut_C, Send_Impact_Location_to_Dissolve_Material) == 0x718, "Offset mismatch for AGCN_RezOut_C::Send_Impact_Location_to_Dissolve_Material");
static_assert(offsetof(AGCN_RezOut_C, Impact_Location_Parameter_Name) == 0x71c, "Offset mismatch for AGCN_RezOut_C::Impact_Location_Parameter_Name");
static_assert(offsetof(AGCN_RezOut_C, Material_Override_ID) == 0x720, "Offset mismatch for AGCN_RezOut_C::Material_Override_ID");
static_assert(offsetof(AGCN_RezOut_C, Copied_Parameters) == 0x730, "Offset mismatch for AGCN_RezOut_C::Copied_Parameters");
static_assert(offsetof(AGCN_RezOut_C, On_Death_Hit_Location) == 0x760, "Offset mismatch for AGCN_RezOut_C::On_Death_Hit_Location");
static_assert(offsetof(AGCN_RezOut_C, On_Death_Hit_Momentum) == 0x778, "Offset mismatch for AGCN_RezOut_C::On_Death_Hit_Momentum");
static_assert(offsetof(AGCN_RezOut_C, bIsHeadShot) == 0x790, "Offset mismatch for AGCN_RezOut_C::bIsHeadShot");
static_assert(offsetof(AGCN_RezOut_C, On_Death_Hit_Normal) == 0x798, "Offset mismatch for AGCN_RezOut_C::On_Death_Hit_Normal");
static_assert(offsetof(AGCN_RezOut_C, RezOutSweetener) == 0x7b0, "Offset mismatch for AGCN_RezOut_C::RezOutSweetener");

// Size: 0x741 (Inherited: 0x1649, Single: 0xfffff0f8)
class AGCN_RezIn_SCMachine_C : public AGCN_RezIn_C
{
public:
    uint8_t Pad_731[0x7]; // 0x731 (Size: 0x7, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x738 (Size: 0x8, Type: StructProperty)
    bool bEnhancedResurrection; // 0x740 (Size: 0x1, Type: BoolProperty)

public:
    virtual void OnBurstGeneric(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UFXSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance) const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(AGCN_RezIn_SCMachine_C) == 0x741, "Size mismatch for AGCN_RezIn_SCMachine_C");
static_assert(offsetof(AGCN_RezIn_SCMachine_C, UberGraphFrame) == 0x738, "Offset mismatch for AGCN_RezIn_SCMachine_C::UberGraphFrame");
static_assert(offsetof(AGCN_RezIn_SCMachine_C, bEnhancedResurrection) == 0x740, "Offset mismatch for AGCN_RezIn_SCMachine_C::bEnhancedResurrection");

// Size: 0x730 (Inherited: 0xf18, Single: 0xfffff818)
class AGCN_RezIn_Frontend_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_43B69932442AE90AB9E7D9819F3D3E71; // 0x570 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_43B69932442AE90AB9E7D9819F3D3E71; // 0x574 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_43B69932442AE90AB9E7D9819F3D3E71; // 0x578 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_43B69932442AE90AB9E7D9819F3D3E71; // 0x57c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_57d[0x3]; // 0x57d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh; // 0x580 (Size: 0x8, Type: ObjectProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_580AB4094AE6911DB445A58F9580C544; // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_580AB4094AE6911DB445A58F9580C544; // 0x58c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_58d[0x3]; // 0x58d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_GlowCharacterMesh; // 0x590 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_ANIMATION; // 0x598 (Size: 0x1, Type: BoolProperty)
    bool SpawnDrone; // 0x599 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59a[0x6]; // 0x59a (Size: 0x6, Type: PaddingProperty)
    UClass* Teleportation_Drone; // 0x5a0 (Size: 0x8, Type: ClassProperty)
    double Teleport_Bot_AnimPlayRate; // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    double Teleport_Bot_Lifespan; // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Teleportation_Point_Light; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset; // 0x5c0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color; // 0x5d8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs; // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn; // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve; // 0x608 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top; // 0x658 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_65c[0x4]; // 0x65c (Size: 0x4, Type: PaddingProperty)
    double Max_Light_Intensity; // 0x660 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom; // 0x668 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_66c[0x4]; // 0x66c (Size: 0x4, Type: PaddingProperty)
    TArray<USkeletalMeshComponent*> Meshes_to_Dissolve; // 0x670 (Size: 0x10, Type: ArrayProperty)
    ABP_TeleportationDrone_C* Drone; // 0x680 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_CHILDCOMPONENTS; // 0x688 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_689[0x7]; // 0x689 (Size: 0x7, Type: PaddingProperty)
    TArray<UFXSystemComponent*> Particle_Components; // 0x690 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Teleport_VFX; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Teleport_In_Visual_Effect; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    FName Teleport_In_VFX_Attach_Point_Name; // 0x6b0 (Size: 0x4, Type: NameProperty)
    int32_t Cur_Dissolve_Setup_Attempt; // 0x6b4 (Size: 0x4, Type: IntProperty)
    int32_t AmountOfTimesToAttemptRestoreMats; // 0x6b8 (Size: 0x4, Type: IntProperty)
    bool Spawn_VFX_Attached; // 0x6bc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6bd[0x3]; // 0x6bd (Size: 0x3, Type: PaddingProperty)
    double Dissolve_Timeline_Playrate; // 0x6c0 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate; // 0x6c8 (Size: 0x8, Type: DoubleProperty)
    UNiagaraSystem* Drone_Visual_Effect; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_TESTJANUSFX; // 0x6d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d9[0x3]; // 0x6d9 (Size: 0x3, Type: PaddingProperty)
    FName Drone_VFX_Attach_Point; // 0x6dc (Size: 0x4, Type: NameProperty)
    FGuid Material_Override_ID; // 0x6e0 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters; // 0x6f0 (Size: 0x30, Type: StructProperty)
    FDelegateHandleController Delegate_Handle_Controller; // 0x720 (Size: 0x10, Type: StructProperty)

public:
    virtual void OnBurstGeneric(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UFXSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance) const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    void EndVFX(); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Clean_Up_Teleportation_Light(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TriggerVFX(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Stop_Looping_Audio(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleportation_Light(); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleport_In_VFX(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Timelines__Playrates(); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AGCN_RezIn_Frontend_C) == 0x730, "Size mismatch for AGCN_RezIn_Frontend_C");
static_assert(offsetof(AGCN_RezIn_Frontend_C, UberGraphFrame) == 0x568, "Offset mismatch for AGCN_RezIn_Frontend_C::UberGraphFrame");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_ResOutCharacterMesh_LightIntensity_43B69932442AE90AB9E7D9819F3D3E71) == 0x570, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_ResOutCharacterMesh_LightIntensity_43B69932442AE90AB9E7D9819F3D3E71");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_ResOutCharacterMesh_ZHeightParam_43B69932442AE90AB9E7D9819F3D3E71) == 0x574, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_ResOutCharacterMesh_ZHeightParam_43B69932442AE90AB9E7D9819F3D3E71");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_ResOutCharacterMesh_TransitionParam_43B69932442AE90AB9E7D9819F3D3E71) == 0x578, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_ResOutCharacterMesh_TransitionParam_43B69932442AE90AB9E7D9819F3D3E71");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_ResOutCharacterMesh__Direction_43B69932442AE90AB9E7D9819F3D3E71) == 0x57c, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_ResOutCharacterMesh__Direction_43B69932442AE90AB9E7D9819F3D3E71");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_ResOutCharacterMesh) == 0x580, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_ResOutCharacterMesh");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_GlowCharacterMesh_EmissiveWarp_580AB4094AE6911DB445A58F9580C544) == 0x588, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_GlowCharacterMesh_EmissiveWarp_580AB4094AE6911DB445A58F9580C544");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_GlowCharacterMesh__Direction_580AB4094AE6911DB445A58F9580C544) == 0x58c, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_GlowCharacterMesh__Direction_580AB4094AE6911DB445A58F9580C544");
static_assert(offsetof(AGCN_RezIn_Frontend_C, TFX_GlowCharacterMesh) == 0x590, "Offset mismatch for AGCN_RezIn_Frontend_C::TFX_GlowCharacterMesh");
static_assert(offsetof(AGCN_RezIn_Frontend_C, DEBUG_ANIMATION) == 0x598, "Offset mismatch for AGCN_RezIn_Frontend_C::DEBUG_ANIMATION");
static_assert(offsetof(AGCN_RezIn_Frontend_C, SpawnDrone) == 0x599, "Offset mismatch for AGCN_RezIn_Frontend_C::SpawnDrone");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleportation_Drone) == 0x5a0, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleportation_Drone");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleport_Bot_AnimPlayRate) == 0x5a8, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleport_Bot_AnimPlayRate");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleport_Bot_Lifespan) == 0x5b0, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleport_Bot_Lifespan");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleportation_Point_Light) == 0x5b8, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleportation_Point_Light");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleportation_Light_Offset) == 0x5c0, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleportation_Light_Offset");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleportation_Light_Color) == 0x5d8, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleportation_Light_Color");
static_assert(offsetof(AGCN_RezIn_Frontend_C, DissolveMIDs) == 0x5e8, "Offset mismatch for AGCN_RezIn_Frontend_C::DissolveMIDs");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Mat_Chracter_Dissolve) == 0x5f8, "Offset mismatch for AGCN_RezIn_Frontend_C::Mat_Chracter_Dissolve");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Pawn) == 0x600, "Offset mismatch for AGCN_RezIn_Frontend_C::Pawn");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Dissolve) == 0x608, "Offset mismatch for AGCN_RezIn_Frontend_C::Dissolve");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Socket_Mesh_Top) == 0x658, "Offset mismatch for AGCN_RezIn_Frontend_C::Socket_Mesh_Top");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Max_Light_Intensity) == 0x660, "Offset mismatch for AGCN_RezIn_Frontend_C::Max_Light_Intensity");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Socket_Mesh_Bottom) == 0x668, "Offset mismatch for AGCN_RezIn_Frontend_C::Socket_Mesh_Bottom");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Meshes_to_Dissolve) == 0x670, "Offset mismatch for AGCN_RezIn_Frontend_C::Meshes_to_Dissolve");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Drone) == 0x680, "Offset mismatch for AGCN_RezIn_Frontend_C::Drone");
static_assert(offsetof(AGCN_RezIn_Frontend_C, DEBUG_CHILDCOMPONENTS) == 0x688, "Offset mismatch for AGCN_RezIn_Frontend_C::DEBUG_CHILDCOMPONENTS");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Particle_Components) == 0x690, "Offset mismatch for AGCN_RezIn_Frontend_C::Particle_Components");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Spawned_Teleport_VFX) == 0x6a0, "Offset mismatch for AGCN_RezIn_Frontend_C::Spawned_Teleport_VFX");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleport_In_Visual_Effect) == 0x6a8, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleport_In_Visual_Effect");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Teleport_In_VFX_Attach_Point_Name) == 0x6b0, "Offset mismatch for AGCN_RezIn_Frontend_C::Teleport_In_VFX_Attach_Point_Name");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Cur_Dissolve_Setup_Attempt) == 0x6b4, "Offset mismatch for AGCN_RezIn_Frontend_C::Cur_Dissolve_Setup_Attempt");
static_assert(offsetof(AGCN_RezIn_Frontend_C, AmountOfTimesToAttemptRestoreMats) == 0x6b8, "Offset mismatch for AGCN_RezIn_Frontend_C::AmountOfTimesToAttemptRestoreMats");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Spawn_VFX_Attached) == 0x6bc, "Offset mismatch for AGCN_RezIn_Frontend_C::Spawn_VFX_Attached");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Dissolve_Timeline_Playrate) == 0x6c0, "Offset mismatch for AGCN_RezIn_Frontend_C::Dissolve_Timeline_Playrate");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Glow_Timeline_Playrate) == 0x6c8, "Offset mismatch for AGCN_RezIn_Frontend_C::Glow_Timeline_Playrate");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Drone_Visual_Effect) == 0x6d0, "Offset mismatch for AGCN_RezIn_Frontend_C::Drone_Visual_Effect");
static_assert(offsetof(AGCN_RezIn_Frontend_C, DEBUG_TESTJANUSFX) == 0x6d8, "Offset mismatch for AGCN_RezIn_Frontend_C::DEBUG_TESTJANUSFX");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Drone_VFX_Attach_Point) == 0x6dc, "Offset mismatch for AGCN_RezIn_Frontend_C::Drone_VFX_Attach_Point");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Material_Override_ID) == 0x6e0, "Offset mismatch for AGCN_RezIn_Frontend_C::Material_Override_ID");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Copied_Parameters) == 0x6f0, "Offset mismatch for AGCN_RezIn_Frontend_C::Copied_Parameters");
static_assert(offsetof(AGCN_RezIn_Frontend_C, Delegate_Handle_Controller) == 0x720, "Offset mismatch for AGCN_RezIn_Frontend_C::Delegate_Handle_Controller");

// Size: 0x7c0 (Inherited: 0x16d0, Single: 0xfffff0f0)
class AGCN_RezOut_TacElim_C : public AGCN_RezOut_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x7b8 (Size: 0x8, Type: StructProperty)

public:
    void Play_Elmination_AnimMontage(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AGCN_RezOut_TacElim_C) == 0x7c0, "Size mismatch for AGCN_RezOut_TacElim_C");
static_assert(offsetof(AGCN_RezOut_TacElim_C, UberGraphFrame) == 0x7b8, "Offset mismatch for AGCN_RezOut_TacElim_C::UberGraphFrame");

// Size: 0x7c8 (Inherited: 0x16d0, Single: 0xfffff0f8)
class AGCN_RezOut_NPC_C : public AGCN_RezOut_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x7b8 (Size: 0x8, Type: StructProperty)
    USoundBase* SoundOnNPCDeath; // 0x7c0 (Size: 0x8, Type: ObjectProperty)

};

static_assert(sizeof(AGCN_RezOut_NPC_C) == 0x7c8, "Size mismatch for AGCN_RezOut_NPC_C");
static_assert(offsetof(AGCN_RezOut_NPC_C, UberGraphFrame) == 0x7b8, "Offset mismatch for AGCN_RezOut_NPC_C::UberGraphFrame");
static_assert(offsetof(AGCN_RezOut_NPC_C, SoundOnNPCDeath) == 0x7c0, "Offset mismatch for AGCN_RezOut_NPC_C::SoundOnNPCDeath");

// Size: 0x598 (Inherited: 0xf18, Single: 0xfffff680)
class AGC_Abilities_Death_FadeCapsule_Athena_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x568 (Size: 0x8, Type: StructProperty)
    float CapsuleFadeTL_RemoveShadow_B48F4431426ECD264BA37C992B6887C3; // 0x570 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CapsuleFadeTL__Direction_B48F4431426ECD264BA37C992B6887C3; // 0x574 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_575[0x3]; // 0x575 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* CapsuleFadeTL; // 0x578 (Size: 0x8, Type: ObjectProperty)
    double Starting_Min_Capsule_Shadow_Vis; // 0x580 (Size: 0x8, Type: DoubleProperty)
    TArray<USkinnedMeshComponent*> SkinnedMesh; // 0x588 (Size: 0x10, Type: ArrayProperty)

public:
    void SkeletalMeshSetup(AFortPlayerPawnAthena*& FortPawn); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void K2_HandleGameplayCue(AActor*& MyTarget, TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AGC_Abilities_Death_FadeCapsule_Athena_C) == 0x598, "Size mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_Athena_C, UberGraphFrame) == 0x568, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C::UberGraphFrame");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_Athena_C, CapsuleFadeTL_RemoveShadow_B48F4431426ECD264BA37C992B6887C3) == 0x570, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C::CapsuleFadeTL_RemoveShadow_B48F4431426ECD264BA37C992B6887C3");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_Athena_C, CapsuleFadeTL__Direction_B48F4431426ECD264BA37C992B6887C3) == 0x574, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C::CapsuleFadeTL__Direction_B48F4431426ECD264BA37C992B6887C3");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_Athena_C, CapsuleFadeTL) == 0x578, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C::CapsuleFadeTL");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_Athena_C, Starting_Min_Capsule_Shadow_Vis) == 0x580, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C::Starting_Min_Capsule_Shadow_Vis");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_Athena_C, SkinnedMesh) == 0x588, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_Athena_C::SkinnedMesh");

// Size: 0x731 (Inherited: 0x1649, Single: 0xfffff0e8)
class AGCN_RezIn_CreativeRespawn_C : public AGCN_RezIn_C
{
public:
};

static_assert(sizeof(AGCN_RezIn_CreativeRespawn_C) == 0x731, "Size mismatch for AGCN_RezIn_CreativeRespawn_C");

// Size: 0x598 (Inherited: 0xf18, Single: 0xfffff680)
class AGC_Abilities_Death_FadeCapsule_StW_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x568 (Size: 0x8, Type: StructProperty)
    float CapsuleFadeTL_RemoveShadow_D18D776D462C2233B7D3E1B7577403C1; // 0x570 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CapsuleFadeTL__Direction_D18D776D462C2233B7D3E1B7577403C1; // 0x574 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_575[0x3]; // 0x575 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* CapsuleFadeTL; // 0x578 (Size: 0x8, Type: ObjectProperty)
    double Starting_Min_Capsule_Shadow_Vis; // 0x580 (Size: 0x8, Type: DoubleProperty)
    TArray<USkinnedMeshComponent*> SkinnedMesh; // 0x588 (Size: 0x10, Type: ArrayProperty)

public:
    void SkeletalMeshSetup(AFortPlayerPawn*& FortPawn); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void K2_HandleGameplayCue(AActor*& MyTarget, TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AGC_Abilities_Death_FadeCapsule_StW_C) == 0x598, "Size mismatch for AGC_Abilities_Death_FadeCapsule_StW_C");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_StW_C, UberGraphFrame) == 0x568, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_StW_C::UberGraphFrame");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_StW_C, CapsuleFadeTL_RemoveShadow_D18D776D462C2233B7D3E1B7577403C1) == 0x570, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_StW_C::CapsuleFadeTL_RemoveShadow_D18D776D462C2233B7D3E1B7577403C1");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_StW_C, CapsuleFadeTL__Direction_D18D776D462C2233B7D3E1B7577403C1) == 0x574, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_StW_C::CapsuleFadeTL__Direction_D18D776D462C2233B7D3E1B7577403C1");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_StW_C, CapsuleFadeTL) == 0x578, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_StW_C::CapsuleFadeTL");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_StW_C, Starting_Min_Capsule_Shadow_Vis) == 0x580, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_StW_C::Starting_Min_Capsule_Shadow_Vis");
static_assert(offsetof(AGC_Abilities_Death_FadeCapsule_StW_C, SkinnedMesh) == 0x588, "Offset mismatch for AGC_Abilities_Death_FadeCapsule_StW_C::SkinnedMesh");

// Size: 0x6e8 (Inherited: 0xf18, Single: 0xfffff7d0)
class AGCN_RezIn_StyleTransfer_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_47520A324BFF8E84CA190293605B9FEB; // 0x570 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_47520A324BFF8E84CA190293605B9FEB; // 0x574 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_575[0x3]; // 0x575 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_GlowCharacterMesh; // 0x578 (Size: 0x8, Type: ObjectProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_8D8520244DCE1E895202BA9542045934; // 0x580 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_8D8520244DCE1E895202BA9542045934; // 0x584 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_8D8520244DCE1E895202BA9542045934; // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_8D8520244DCE1E895202BA9542045934; // 0x58c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_58d[0x3]; // 0x58d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh; // 0x590 (Size: 0x8, Type: ObjectProperty)
    UPointLightComponent* Teleportation_Point_Light; // 0x598 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset; // 0x5a0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color; // 0x5b8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs; // 0x5c8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve; // 0x5e8 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top; // 0x638 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_63c[0x4]; // 0x63c (Size: 0x4, Type: PaddingProperty)
    double Max_Light_Intensity; // 0x640 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom; // 0x648 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_64c[0x4]; // 0x64c (Size: 0x4, Type: PaddingProperty)
    ABP_TeleportationDrone_C* Drone; // 0x650 (Size: 0x8, Type: ObjectProperty)
    TArray<UFXSystemComponent*> Particle_Components; // 0x658 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Teleport_VFX; // 0x668 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Teleport_In_Visual_Effect; // 0x670 (Size: 0x8, Type: ObjectProperty)
    FName Teleport_In_VFX_Attach_Point_Name; // 0x678 (Size: 0x4, Type: NameProperty)
    int32_t Cur_Dissolve_Setup_Attempt; // 0x67c (Size: 0x4, Type: IntProperty)
    int32_t AmountOfTimesToAttemptRestoreMats; // 0x680 (Size: 0x4, Type: IntProperty)
    bool Spawn_VFX_Attached; // 0x684 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_685[0x3]; // 0x685 (Size: 0x3, Type: PaddingProperty)
    double Dissolve_Timeline_Playrate; // 0x688 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate; // 0x690 (Size: 0x8, Type: DoubleProperty)
    FGuid Material_Override_ID; // 0x698 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters; // 0x6a8 (Size: 0x30, Type: StructProperty)
    FDelegateHandleController Delegate_Handle_Controller; // 0x6d8 (Size: 0x10, Type: StructProperty)

public:
    void Clean_Up_Teleportation_Light(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Stop_Looping_Audio(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TriggerVFX(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EndVFX(); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleportation_Light(); // 0x288a61c (Index: 0x8, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleport_In_VFX(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Timelines__Playrates(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnBurstGeneric(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UFXSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance) const; // 0x288a61c (Index: 0xf, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(AGCN_RezIn_StyleTransfer_C) == 0x6e8, "Size mismatch for AGCN_RezIn_StyleTransfer_C");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, UberGraphFrame) == 0x568, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::UberGraphFrame");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_GlowCharacterMesh_EmissiveWarp_47520A324BFF8E84CA190293605B9FEB) == 0x570, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_GlowCharacterMesh_EmissiveWarp_47520A324BFF8E84CA190293605B9FEB");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_GlowCharacterMesh__Direction_47520A324BFF8E84CA190293605B9FEB) == 0x574, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_GlowCharacterMesh__Direction_47520A324BFF8E84CA190293605B9FEB");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_GlowCharacterMesh) == 0x578, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_GlowCharacterMesh");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_ResOutCharacterMesh_LightIntensity_8D8520244DCE1E895202BA9542045934) == 0x580, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_ResOutCharacterMesh_LightIntensity_8D8520244DCE1E895202BA9542045934");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_ResOutCharacterMesh_ZHeightParam_8D8520244DCE1E895202BA9542045934) == 0x584, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_ResOutCharacterMesh_ZHeightParam_8D8520244DCE1E895202BA9542045934");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_ResOutCharacterMesh_TransitionParam_8D8520244DCE1E895202BA9542045934) == 0x588, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_ResOutCharacterMesh_TransitionParam_8D8520244DCE1E895202BA9542045934");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_ResOutCharacterMesh__Direction_8D8520244DCE1E895202BA9542045934) == 0x58c, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_ResOutCharacterMesh__Direction_8D8520244DCE1E895202BA9542045934");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, TFX_ResOutCharacterMesh) == 0x590, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::TFX_ResOutCharacterMesh");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Teleportation_Point_Light) == 0x598, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Teleportation_Point_Light");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Teleportation_Light_Offset) == 0x5a0, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Teleportation_Light_Offset");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Teleportation_Light_Color) == 0x5b8, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Teleportation_Light_Color");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, DissolveMIDs) == 0x5c8, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::DissolveMIDs");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Mat_Chracter_Dissolve) == 0x5d8, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Mat_Chracter_Dissolve");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Pawn) == 0x5e0, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Pawn");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Dissolve) == 0x5e8, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Dissolve");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Socket_Mesh_Top) == 0x638, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Socket_Mesh_Top");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Max_Light_Intensity) == 0x640, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Max_Light_Intensity");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Socket_Mesh_Bottom) == 0x648, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Socket_Mesh_Bottom");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Drone) == 0x650, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Drone");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Particle_Components) == 0x658, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Particle_Components");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Spawned_Teleport_VFX) == 0x668, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Spawned_Teleport_VFX");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Teleport_In_Visual_Effect) == 0x670, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Teleport_In_Visual_Effect");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Teleport_In_VFX_Attach_Point_Name) == 0x678, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Teleport_In_VFX_Attach_Point_Name");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Cur_Dissolve_Setup_Attempt) == 0x67c, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Cur_Dissolve_Setup_Attempt");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, AmountOfTimesToAttemptRestoreMats) == 0x680, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::AmountOfTimesToAttemptRestoreMats");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Spawn_VFX_Attached) == 0x684, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Spawn_VFX_Attached");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Dissolve_Timeline_Playrate) == 0x688, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Dissolve_Timeline_Playrate");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Glow_Timeline_Playrate) == 0x690, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Glow_Timeline_Playrate");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Material_Override_ID) == 0x698, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Material_Override_ID");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Copied_Parameters) == 0x6a8, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Copied_Parameters");
static_assert(offsetof(AGCN_RezIn_StyleTransfer_C, Delegate_Handle_Controller) == 0x6d8, "Offset mismatch for AGCN_RezIn_StyleTransfer_C::Delegate_Handle_Controller");

// Size: 0x731 (Inherited: 0xf18, Single: 0xfffff819)
class AGCN_RezIn_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x568 (Size: 0x8, Type: StructProperty)
    float TFX_ResOutCharacterMesh_LightIntensity_81C5527F43A6972D94623590BA582E8C; // 0x570 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_ZHeightParam_81C5527F43A6972D94623590BA582E8C; // 0x574 (Size: 0x4, Type: FloatProperty)
    float TFX_ResOutCharacterMesh_TransitionParam_81C5527F43A6972D94623590BA582E8C; // 0x578 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_ResOutCharacterMesh__Direction_81C5527F43A6972D94623590BA582E8C; // 0x57c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_57d[0x3]; // 0x57d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_ResOutCharacterMesh; // 0x580 (Size: 0x8, Type: ObjectProperty)
    float TFX_GlowCharacterMesh_EmissiveWarp_9EA15145493A8F1A5915938D5529A028; // 0x588 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TFX_GlowCharacterMesh__Direction_9EA15145493A8F1A5915938D5529A028; // 0x58c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_58d[0x3]; // 0x58d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TFX_GlowCharacterMesh; // 0x590 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_ANIMATION; // 0x598 (Size: 0x1, Type: BoolProperty)
    bool SpawnDrone; // 0x599 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59a[0x6]; // 0x59a (Size: 0x6, Type: PaddingProperty)
    UClass* Teleportation_Drone; // 0x5a0 (Size: 0x8, Type: ClassProperty)
    double Teleport_Bot_AnimPlayRate; // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    double Teleport_Bot_Lifespan; // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Teleportation_Point_Light; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    FVector Teleportation_Light_Offset; // 0x5c0 (Size: 0x18, Type: StructProperty)
    FLinearColor Teleportation_Light_Color; // 0x5d8 (Size: 0x10, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> DissolveMIDs; // 0x5e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Mat_Chracter_Dissolve; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    APlayerPawn_Athena_C* Pawn; // 0x600 (Size: 0x8, Type: ObjectProperty)
    TSet<USkeletalMeshComponent*> Dissolve; // 0x608 (Size: 0x50, Type: SetProperty)
    FName Socket_Mesh_Top; // 0x658 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_65c[0x4]; // 0x65c (Size: 0x4, Type: PaddingProperty)
    double Max_Light_Intensity; // 0x660 (Size: 0x8, Type: DoubleProperty)
    FName Socket_Mesh_Bottom; // 0x668 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_66c[0x4]; // 0x66c (Size: 0x4, Type: PaddingProperty)
    TArray<USkeletalMeshComponent*> Meshes_to_Dissolve; // 0x670 (Size: 0x10, Type: ArrayProperty)
    ABP_TeleportationDrone_C* Drone; // 0x680 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_CHILDCOMPONENTS; // 0x688 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_689[0x7]; // 0x689 (Size: 0x7, Type: PaddingProperty)
    TArray<UFXSystemComponent*> Particle_Components; // 0x690 (Size: 0x10, Type: ArrayProperty)
    UNiagaraComponent* Spawned_Teleport_VFX; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Teleport_In_Visual_Effect; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    FName Teleport_In_VFX_Attach_Point_Name; // 0x6b0 (Size: 0x4, Type: NameProperty)
    int32_t Cur_Dissolve_Setup_Attempt; // 0x6b4 (Size: 0x4, Type: IntProperty)
    int32_t AmountOfTimesToAttemptRestoreMats; // 0x6b8 (Size: 0x4, Type: IntProperty)
    bool Spawn_VFX_Attached; // 0x6bc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6bd[0x3]; // 0x6bd (Size: 0x3, Type: PaddingProperty)
    double Dissolve_Timeline_Playrate; // 0x6c0 (Size: 0x8, Type: DoubleProperty)
    double Glow_Timeline_Playrate; // 0x6c8 (Size: 0x8, Type: DoubleProperty)
    UNiagaraSystem* Drone_Visual_Effect; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    bool DEBUG_TESTJANUSFX; // 0x6d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d9[0x3]; // 0x6d9 (Size: 0x3, Type: PaddingProperty)
    FName Drone_VFX_Attach_Point; // 0x6dc (Size: 0x4, Type: NameProperty)
    FGuid Material_Override_ID; // 0x6e0 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Copied_Parameters; // 0x6f0 (Size: 0x30, Type: StructProperty)
    FDelegateHandleController Delegate_Handle_Controller; // 0x720 (Size: 0x10, Type: StructProperty)
    bool bCleanedUp; // 0x730 (Size: 0x1, Type: BoolProperty)

public:
    void TriggerVFX(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Clean_Up_Teleportation_Light(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EndVFX(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Timelines__Playrates(); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Drone_VFX(); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleport_In_VFX(); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Spawn_Teleportation_Drone(); // 0x288a61c (Index: 0x9, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void OnRecycle(); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)
    void Restore_Character_Materials(bool& Fully_Completed); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void OnBurstGeneric(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UFXSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance) const; // 0x288a61c (Index: 0xe, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    void Spawn_Teleportation_Light(); // 0x288a61c (Index: 0x13, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Stop_Looping_Audio(); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AGCN_RezIn_C) == 0x731, "Size mismatch for AGCN_RezIn_C");
static_assert(offsetof(AGCN_RezIn_C, UberGraphFrame) == 0x568, "Offset mismatch for AGCN_RezIn_C::UberGraphFrame");
static_assert(offsetof(AGCN_RezIn_C, TFX_ResOutCharacterMesh_LightIntensity_81C5527F43A6972D94623590BA582E8C) == 0x570, "Offset mismatch for AGCN_RezIn_C::TFX_ResOutCharacterMesh_LightIntensity_81C5527F43A6972D94623590BA582E8C");
static_assert(offsetof(AGCN_RezIn_C, TFX_ResOutCharacterMesh_ZHeightParam_81C5527F43A6972D94623590BA582E8C) == 0x574, "Offset mismatch for AGCN_RezIn_C::TFX_ResOutCharacterMesh_ZHeightParam_81C5527F43A6972D94623590BA582E8C");
static_assert(offsetof(AGCN_RezIn_C, TFX_ResOutCharacterMesh_TransitionParam_81C5527F43A6972D94623590BA582E8C) == 0x578, "Offset mismatch for AGCN_RezIn_C::TFX_ResOutCharacterMesh_TransitionParam_81C5527F43A6972D94623590BA582E8C");
static_assert(offsetof(AGCN_RezIn_C, TFX_ResOutCharacterMesh__Direction_81C5527F43A6972D94623590BA582E8C) == 0x57c, "Offset mismatch for AGCN_RezIn_C::TFX_ResOutCharacterMesh__Direction_81C5527F43A6972D94623590BA582E8C");
static_assert(offsetof(AGCN_RezIn_C, TFX_ResOutCharacterMesh) == 0x580, "Offset mismatch for AGCN_RezIn_C::TFX_ResOutCharacterMesh");
static_assert(offsetof(AGCN_RezIn_C, TFX_GlowCharacterMesh_EmissiveWarp_9EA15145493A8F1A5915938D5529A028) == 0x588, "Offset mismatch for AGCN_RezIn_C::TFX_GlowCharacterMesh_EmissiveWarp_9EA15145493A8F1A5915938D5529A028");
static_assert(offsetof(AGCN_RezIn_C, TFX_GlowCharacterMesh__Direction_9EA15145493A8F1A5915938D5529A028) == 0x58c, "Offset mismatch for AGCN_RezIn_C::TFX_GlowCharacterMesh__Direction_9EA15145493A8F1A5915938D5529A028");
static_assert(offsetof(AGCN_RezIn_C, TFX_GlowCharacterMesh) == 0x590, "Offset mismatch for AGCN_RezIn_C::TFX_GlowCharacterMesh");
static_assert(offsetof(AGCN_RezIn_C, DEBUG_ANIMATION) == 0x598, "Offset mismatch for AGCN_RezIn_C::DEBUG_ANIMATION");
static_assert(offsetof(AGCN_RezIn_C, SpawnDrone) == 0x599, "Offset mismatch for AGCN_RezIn_C::SpawnDrone");
static_assert(offsetof(AGCN_RezIn_C, Teleportation_Drone) == 0x5a0, "Offset mismatch for AGCN_RezIn_C::Teleportation_Drone");
static_assert(offsetof(AGCN_RezIn_C, Teleport_Bot_AnimPlayRate) == 0x5a8, "Offset mismatch for AGCN_RezIn_C::Teleport_Bot_AnimPlayRate");
static_assert(offsetof(AGCN_RezIn_C, Teleport_Bot_Lifespan) == 0x5b0, "Offset mismatch for AGCN_RezIn_C::Teleport_Bot_Lifespan");
static_assert(offsetof(AGCN_RezIn_C, Teleportation_Point_Light) == 0x5b8, "Offset mismatch for AGCN_RezIn_C::Teleportation_Point_Light");
static_assert(offsetof(AGCN_RezIn_C, Teleportation_Light_Offset) == 0x5c0, "Offset mismatch for AGCN_RezIn_C::Teleportation_Light_Offset");
static_assert(offsetof(AGCN_RezIn_C, Teleportation_Light_Color) == 0x5d8, "Offset mismatch for AGCN_RezIn_C::Teleportation_Light_Color");
static_assert(offsetof(AGCN_RezIn_C, DissolveMIDs) == 0x5e8, "Offset mismatch for AGCN_RezIn_C::DissolveMIDs");
static_assert(offsetof(AGCN_RezIn_C, Mat_Chracter_Dissolve) == 0x5f8, "Offset mismatch for AGCN_RezIn_C::Mat_Chracter_Dissolve");
static_assert(offsetof(AGCN_RezIn_C, Pawn) == 0x600, "Offset mismatch for AGCN_RezIn_C::Pawn");
static_assert(offsetof(AGCN_RezIn_C, Dissolve) == 0x608, "Offset mismatch for AGCN_RezIn_C::Dissolve");
static_assert(offsetof(AGCN_RezIn_C, Socket_Mesh_Top) == 0x658, "Offset mismatch for AGCN_RezIn_C::Socket_Mesh_Top");
static_assert(offsetof(AGCN_RezIn_C, Max_Light_Intensity) == 0x660, "Offset mismatch for AGCN_RezIn_C::Max_Light_Intensity");
static_assert(offsetof(AGCN_RezIn_C, Socket_Mesh_Bottom) == 0x668, "Offset mismatch for AGCN_RezIn_C::Socket_Mesh_Bottom");
static_assert(offsetof(AGCN_RezIn_C, Meshes_to_Dissolve) == 0x670, "Offset mismatch for AGCN_RezIn_C::Meshes_to_Dissolve");
static_assert(offsetof(AGCN_RezIn_C, Drone) == 0x680, "Offset mismatch for AGCN_RezIn_C::Drone");
static_assert(offsetof(AGCN_RezIn_C, DEBUG_CHILDCOMPONENTS) == 0x688, "Offset mismatch for AGCN_RezIn_C::DEBUG_CHILDCOMPONENTS");
static_assert(offsetof(AGCN_RezIn_C, Particle_Components) == 0x690, "Offset mismatch for AGCN_RezIn_C::Particle_Components");
static_assert(offsetof(AGCN_RezIn_C, Spawned_Teleport_VFX) == 0x6a0, "Offset mismatch for AGCN_RezIn_C::Spawned_Teleport_VFX");
static_assert(offsetof(AGCN_RezIn_C, Teleport_In_Visual_Effect) == 0x6a8, "Offset mismatch for AGCN_RezIn_C::Teleport_In_Visual_Effect");
static_assert(offsetof(AGCN_RezIn_C, Teleport_In_VFX_Attach_Point_Name) == 0x6b0, "Offset mismatch for AGCN_RezIn_C::Teleport_In_VFX_Attach_Point_Name");
static_assert(offsetof(AGCN_RezIn_C, Cur_Dissolve_Setup_Attempt) == 0x6b4, "Offset mismatch for AGCN_RezIn_C::Cur_Dissolve_Setup_Attempt");
static_assert(offsetof(AGCN_RezIn_C, AmountOfTimesToAttemptRestoreMats) == 0x6b8, "Offset mismatch for AGCN_RezIn_C::AmountOfTimesToAttemptRestoreMats");
static_assert(offsetof(AGCN_RezIn_C, Spawn_VFX_Attached) == 0x6bc, "Offset mismatch for AGCN_RezIn_C::Spawn_VFX_Attached");
static_assert(offsetof(AGCN_RezIn_C, Dissolve_Timeline_Playrate) == 0x6c0, "Offset mismatch for AGCN_RezIn_C::Dissolve_Timeline_Playrate");
static_assert(offsetof(AGCN_RezIn_C, Glow_Timeline_Playrate) == 0x6c8, "Offset mismatch for AGCN_RezIn_C::Glow_Timeline_Playrate");
static_assert(offsetof(AGCN_RezIn_C, Drone_Visual_Effect) == 0x6d0, "Offset mismatch for AGCN_RezIn_C::Drone_Visual_Effect");
static_assert(offsetof(AGCN_RezIn_C, DEBUG_TESTJANUSFX) == 0x6d8, "Offset mismatch for AGCN_RezIn_C::DEBUG_TESTJANUSFX");
static_assert(offsetof(AGCN_RezIn_C, Drone_VFX_Attach_Point) == 0x6dc, "Offset mismatch for AGCN_RezIn_C::Drone_VFX_Attach_Point");
static_assert(offsetof(AGCN_RezIn_C, Material_Override_ID) == 0x6e0, "Offset mismatch for AGCN_RezIn_C::Material_Override_ID");
static_assert(offsetof(AGCN_RezIn_C, Copied_Parameters) == 0x6f0, "Offset mismatch for AGCN_RezIn_C::Copied_Parameters");
static_assert(offsetof(AGCN_RezIn_C, Delegate_Handle_Controller) == 0x720, "Offset mismatch for AGCN_RezIn_C::Delegate_Handle_Controller");
static_assert(offsetof(AGCN_RezIn_C, bCleanedUp) == 0x730, "Offset mismatch for AGCN_RezIn_C::bCleanedUp");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEliminationBotVFXInterface_C : public UInterface
{
public:

public:
    void TriggerVFX(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EndVFX(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UEliminationBotVFXInterface_C) == 0x28, "Size mismatch for UEliminationBotVFXInterface_C");

