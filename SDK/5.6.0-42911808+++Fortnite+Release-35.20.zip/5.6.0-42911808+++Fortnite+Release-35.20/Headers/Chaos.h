/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Chaos
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ChaosVDRuntime.h"
#include "CoreUObject.h"

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FManagedArrayCollection
{
};

static_assert(sizeof(FManagedArrayCollection) == 0xb0, "Size mismatch for FManagedArrayCollection");

// Size: 0xb0 (Inherited: 0xb0, Single: 0x0)
struct FFieldCollection : FManagedArrayCollection
{
};

static_assert(sizeof(FFieldCollection) == 0xb0, "Size mismatch for FFieldCollection");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FClosestPhysicsObjectResult
{
};

static_assert(sizeof(FClosestPhysicsObjectResult) == 0x28, "Size mismatch for FClosestPhysicsObjectResult");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FSerializedSolverScene
{
    TArray<FChaosVDParticleDataWrapper> ParticleData; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FChaosVDJointConstraint> JointConstraintData; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FChaosVDCharacterGroundConstraint> CharacterGroundConstraintData; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FChaosVDParticlePairMidPhase> CollisionMidPhaseData; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FSerializedSolverScene) == 0x50, "Size mismatch for FSerializedSolverScene");
static_assert(offsetof(FSerializedSolverScene, ParticleData) == 0x0, "Offset mismatch for FSerializedSolverScene::ParticleData");
static_assert(offsetof(FSerializedSolverScene, JointConstraintData) == 0x10, "Offset mismatch for FSerializedSolverScene::JointConstraintData");
static_assert(offsetof(FSerializedSolverScene, CharacterGroundConstraintData) == 0x20, "Offset mismatch for FSerializedSolverScene::CharacterGroundConstraintData");
static_assert(offsetof(FSerializedSolverScene, CollisionMidPhaseData) == 0x30, "Offset mismatch for FSerializedSolverScene::CollisionMidPhaseData");

// Size: 0x6c (Inherited: 0x0, Single: 0x6c)
struct FChaosSolverConfiguration
{
    int32_t PositionIterations; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t VelocityIterations; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t ProjectionIterations; // 0x8 (Size: 0x4, Type: IntProperty)
    float CollisionMarginFraction; // 0xc (Size: 0x4, Type: FloatProperty)
    float CollisionMarginMax; // 0x10 (Size: 0x4, Type: FloatProperty)
    float CollisionCullDistance; // 0x14 (Size: 0x4, Type: FloatProperty)
    float CollisionMaxPushOutVelocity; // 0x18 (Size: 0x4, Type: FloatProperty)
    float CollisionInitialOverlapDepenetrationVelocity; // 0x1c (Size: 0x4, Type: FloatProperty)
    float ClusterConnectionFactor; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t ClusterUnionConnectionType; // 0x24 (Size: 0x1, Type: EnumProperty)
    bool bGenerateCollisionData; // 0x25 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26[0x2]; // 0x26 (Size: 0x2, Type: PaddingProperty)
    FSolverCollisionFilterSettings CollisionFilterSettings; // 0x28 (Size: 0x10, Type: StructProperty)
    bool bGenerateBreakData; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    FSolverBreakingFilterSettings BreakingFilterSettings; // 0x3c (Size: 0x10, Type: StructProperty)
    bool bGenerateTrailingData; // 0x4c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
    FSolverTrailingFilterSettings TrailingFilterSettings; // 0x50 (Size: 0x10, Type: StructProperty)
    int32_t Iterations; // 0x60 (Size: 0x4, Type: IntProperty)
    int32_t PushOutIterations; // 0x64 (Size: 0x4, Type: IntProperty)
    bool bGenerateContactGraph; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x3]; // 0x69 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosSolverConfiguration) == 0x6c, "Size mismatch for FChaosSolverConfiguration");
static_assert(offsetof(FChaosSolverConfiguration, PositionIterations) == 0x0, "Offset mismatch for FChaosSolverConfiguration::PositionIterations");
static_assert(offsetof(FChaosSolverConfiguration, VelocityIterations) == 0x4, "Offset mismatch for FChaosSolverConfiguration::VelocityIterations");
static_assert(offsetof(FChaosSolverConfiguration, ProjectionIterations) == 0x8, "Offset mismatch for FChaosSolverConfiguration::ProjectionIterations");
static_assert(offsetof(FChaosSolverConfiguration, CollisionMarginFraction) == 0xc, "Offset mismatch for FChaosSolverConfiguration::CollisionMarginFraction");
static_assert(offsetof(FChaosSolverConfiguration, CollisionMarginMax) == 0x10, "Offset mismatch for FChaosSolverConfiguration::CollisionMarginMax");
static_assert(offsetof(FChaosSolverConfiguration, CollisionCullDistance) == 0x14, "Offset mismatch for FChaosSolverConfiguration::CollisionCullDistance");
static_assert(offsetof(FChaosSolverConfiguration, CollisionMaxPushOutVelocity) == 0x18, "Offset mismatch for FChaosSolverConfiguration::CollisionMaxPushOutVelocity");
static_assert(offsetof(FChaosSolverConfiguration, CollisionInitialOverlapDepenetrationVelocity) == 0x1c, "Offset mismatch for FChaosSolverConfiguration::CollisionInitialOverlapDepenetrationVelocity");
static_assert(offsetof(FChaosSolverConfiguration, ClusterConnectionFactor) == 0x20, "Offset mismatch for FChaosSolverConfiguration::ClusterConnectionFactor");
static_assert(offsetof(FChaosSolverConfiguration, ClusterUnionConnectionType) == 0x24, "Offset mismatch for FChaosSolverConfiguration::ClusterUnionConnectionType");
static_assert(offsetof(FChaosSolverConfiguration, bGenerateCollisionData) == 0x25, "Offset mismatch for FChaosSolverConfiguration::bGenerateCollisionData");
static_assert(offsetof(FChaosSolverConfiguration, CollisionFilterSettings) == 0x28, "Offset mismatch for FChaosSolverConfiguration::CollisionFilterSettings");
static_assert(offsetof(FChaosSolverConfiguration, bGenerateBreakData) == 0x38, "Offset mismatch for FChaosSolverConfiguration::bGenerateBreakData");
static_assert(offsetof(FChaosSolverConfiguration, BreakingFilterSettings) == 0x3c, "Offset mismatch for FChaosSolverConfiguration::BreakingFilterSettings");
static_assert(offsetof(FChaosSolverConfiguration, bGenerateTrailingData) == 0x4c, "Offset mismatch for FChaosSolverConfiguration::bGenerateTrailingData");
static_assert(offsetof(FChaosSolverConfiguration, TrailingFilterSettings) == 0x50, "Offset mismatch for FChaosSolverConfiguration::TrailingFilterSettings");
static_assert(offsetof(FChaosSolverConfiguration, Iterations) == 0x60, "Offset mismatch for FChaosSolverConfiguration::Iterations");
static_assert(offsetof(FChaosSolverConfiguration, PushOutIterations) == 0x64, "Offset mismatch for FChaosSolverConfiguration::PushOutIterations");
static_assert(offsetof(FChaosSolverConfiguration, bGenerateContactGraph) == 0x68, "Offset mismatch for FChaosSolverConfiguration::bGenerateContactGraph");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSolverTrailingFilterSettings
{
    bool FilterEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinVolume; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSolverTrailingFilterSettings) == 0x10, "Size mismatch for FSolverTrailingFilterSettings");
static_assert(offsetof(FSolverTrailingFilterSettings, FilterEnabled) == 0x0, "Offset mismatch for FSolverTrailingFilterSettings::FilterEnabled");
static_assert(offsetof(FSolverTrailingFilterSettings, MinMass) == 0x4, "Offset mismatch for FSolverTrailingFilterSettings::MinMass");
static_assert(offsetof(FSolverTrailingFilterSettings, MinSpeed) == 0x8, "Offset mismatch for FSolverTrailingFilterSettings::MinSpeed");
static_assert(offsetof(FSolverTrailingFilterSettings, MinVolume) == 0xc, "Offset mismatch for FSolverTrailingFilterSettings::MinVolume");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSolverBreakingFilterSettings
{
    bool FilterEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinVolume; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSolverBreakingFilterSettings) == 0x10, "Size mismatch for FSolverBreakingFilterSettings");
static_assert(offsetof(FSolverBreakingFilterSettings, FilterEnabled) == 0x0, "Offset mismatch for FSolverBreakingFilterSettings::FilterEnabled");
static_assert(offsetof(FSolverBreakingFilterSettings, MinMass) == 0x4, "Offset mismatch for FSolverBreakingFilterSettings::MinMass");
static_assert(offsetof(FSolverBreakingFilterSettings, MinSpeed) == 0x8, "Offset mismatch for FSolverBreakingFilterSettings::MinSpeed");
static_assert(offsetof(FSolverBreakingFilterSettings, MinVolume) == 0xc, "Offset mismatch for FSolverBreakingFilterSettings::MinVolume");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSolverCollisionFilterSettings
{
    bool FilterEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinImpulse; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSolverCollisionFilterSettings) == 0x10, "Size mismatch for FSolverCollisionFilterSettings");
static_assert(offsetof(FSolverCollisionFilterSettings, FilterEnabled) == 0x0, "Offset mismatch for FSolverCollisionFilterSettings::FilterEnabled");
static_assert(offsetof(FSolverCollisionFilterSettings, MinMass) == 0x4, "Offset mismatch for FSolverCollisionFilterSettings::MinMass");
static_assert(offsetof(FSolverCollisionFilterSettings, MinSpeed) == 0x8, "Offset mismatch for FSolverCollisionFilterSettings::MinSpeed");
static_assert(offsetof(FSolverCollisionFilterSettings, MinImpulse) == 0xc, "Offset mismatch for FSolverCollisionFilterSettings::MinImpulse");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FSolverCollisionData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector AccumulatedImpulse; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector Velocity1; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector Velocity2; // 0x60 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity1; // 0x78 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity2; // 0x90 (Size: 0x18, Type: StructProperty)
    float Mass1; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float Mass2; // 0xac (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex; // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t LevelsetIndex; // 0xb4 (Size: 0x4, Type: IntProperty)
    int32_t ParticleIndexMesh; // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t LevelsetIndexMesh; // 0xbc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FSolverCollisionData) == 0xc0, "Size mismatch for FSolverCollisionData");
static_assert(offsetof(FSolverCollisionData, Location) == 0x0, "Offset mismatch for FSolverCollisionData::Location");
static_assert(offsetof(FSolverCollisionData, AccumulatedImpulse) == 0x18, "Offset mismatch for FSolverCollisionData::AccumulatedImpulse");
static_assert(offsetof(FSolverCollisionData, Normal) == 0x30, "Offset mismatch for FSolverCollisionData::Normal");
static_assert(offsetof(FSolverCollisionData, Velocity1) == 0x48, "Offset mismatch for FSolverCollisionData::Velocity1");
static_assert(offsetof(FSolverCollisionData, Velocity2) == 0x60, "Offset mismatch for FSolverCollisionData::Velocity2");
static_assert(offsetof(FSolverCollisionData, AngularVelocity1) == 0x78, "Offset mismatch for FSolverCollisionData::AngularVelocity1");
static_assert(offsetof(FSolverCollisionData, AngularVelocity2) == 0x90, "Offset mismatch for FSolverCollisionData::AngularVelocity2");
static_assert(offsetof(FSolverCollisionData, Mass1) == 0xa8, "Offset mismatch for FSolverCollisionData::Mass1");
static_assert(offsetof(FSolverCollisionData, Mass2) == 0xac, "Offset mismatch for FSolverCollisionData::Mass2");
static_assert(offsetof(FSolverCollisionData, ParticleIndex) == 0xb0, "Offset mismatch for FSolverCollisionData::ParticleIndex");
static_assert(offsetof(FSolverCollisionData, LevelsetIndex) == 0xb4, "Offset mismatch for FSolverCollisionData::LevelsetIndex");
static_assert(offsetof(FSolverCollisionData, ParticleIndexMesh) == 0xb8, "Offset mismatch for FSolverCollisionData::ParticleIndexMesh");
static_assert(offsetof(FSolverCollisionData, LevelsetIndexMesh) == 0xbc, "Offset mismatch for FSolverCollisionData::LevelsetIndexMesh");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FSolverBreakingData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x30 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex; // 0x4c (Size: 0x4, Type: IntProperty)
    int32_t ParticleIndexMesh; // 0x50 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSolverBreakingData) == 0x58, "Size mismatch for FSolverBreakingData");
static_assert(offsetof(FSolverBreakingData, Location) == 0x0, "Offset mismatch for FSolverBreakingData::Location");
static_assert(offsetof(FSolverBreakingData, Velocity) == 0x18, "Offset mismatch for FSolverBreakingData::Velocity");
static_assert(offsetof(FSolverBreakingData, AngularVelocity) == 0x30, "Offset mismatch for FSolverBreakingData::AngularVelocity");
static_assert(offsetof(FSolverBreakingData, Mass) == 0x48, "Offset mismatch for FSolverBreakingData::Mass");
static_assert(offsetof(FSolverBreakingData, ParticleIndex) == 0x4c, "Offset mismatch for FSolverBreakingData::ParticleIndex");
static_assert(offsetof(FSolverBreakingData, ParticleIndexMesh) == 0x50, "Offset mismatch for FSolverBreakingData::ParticleIndexMesh");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FSolverTrailingData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x30 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex; // 0x4c (Size: 0x4, Type: IntProperty)
    int32_t ParticleIndexMesh; // 0x50 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSolverTrailingData) == 0x58, "Size mismatch for FSolverTrailingData");
static_assert(offsetof(FSolverTrailingData, Location) == 0x0, "Offset mismatch for FSolverTrailingData::Location");
static_assert(offsetof(FSolverTrailingData, Velocity) == 0x18, "Offset mismatch for FSolverTrailingData::Velocity");
static_assert(offsetof(FSolverTrailingData, AngularVelocity) == 0x30, "Offset mismatch for FSolverTrailingData::AngularVelocity");
static_assert(offsetof(FSolverTrailingData, Mass) == 0x48, "Offset mismatch for FSolverTrailingData::Mass");
static_assert(offsetof(FSolverTrailingData, ParticleIndex) == 0x4c, "Offset mismatch for FSolverTrailingData::ParticleIndex");
static_assert(offsetof(FSolverTrailingData, ParticleIndexMesh) == 0x50, "Offset mismatch for FSolverTrailingData::ParticleIndexMesh");

// Size: 0xb8 (Inherited: 0x0, Single: 0xb8)
struct FRecordedFrame
{
    TArray<FTransform> Transforms; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> TransformIndices; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> PreviousTransformIndices; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<bool> DisabledFlags; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FSolverCollisionData> Collisions; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FSolverBreakingData> Breakings; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TSet<FSolverTrailingData> Trailings; // 0x60 (Size: 0x50, Type: SetProperty)
    float Timestamp; // 0xb0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRecordedFrame) == 0xb8, "Size mismatch for FRecordedFrame");
static_assert(offsetof(FRecordedFrame, Transforms) == 0x0, "Offset mismatch for FRecordedFrame::Transforms");
static_assert(offsetof(FRecordedFrame, TransformIndices) == 0x10, "Offset mismatch for FRecordedFrame::TransformIndices");
static_assert(offsetof(FRecordedFrame, PreviousTransformIndices) == 0x20, "Offset mismatch for FRecordedFrame::PreviousTransformIndices");
static_assert(offsetof(FRecordedFrame, DisabledFlags) == 0x30, "Offset mismatch for FRecordedFrame::DisabledFlags");
static_assert(offsetof(FRecordedFrame, Collisions) == 0x40, "Offset mismatch for FRecordedFrame::Collisions");
static_assert(offsetof(FRecordedFrame, Breakings) == 0x50, "Offset mismatch for FRecordedFrame::Breakings");
static_assert(offsetof(FRecordedFrame, Trailings) == 0x60, "Offset mismatch for FRecordedFrame::Trailings");
static_assert(offsetof(FRecordedFrame, Timestamp) == 0xb0, "Offset mismatch for FRecordedFrame::Timestamp");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRecordedTransformTrack
{
    TArray<FRecordedFrame> Records; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRecordedTransformTrack) == 0x10, "Size mismatch for FRecordedTransformTrack");
static_assert(offsetof(FRecordedTransformTrack, Records) == 0x0, "Offset mismatch for FRecordedTransformTrack::Records");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FSolverRemovalFilterSettings
{
    bool FilterEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinVolume; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSolverRemovalFilterSettings) == 0xc, "Size mismatch for FSolverRemovalFilterSettings");
static_assert(offsetof(FSolverRemovalFilterSettings, FilterEnabled) == 0x0, "Offset mismatch for FSolverRemovalFilterSettings::FilterEnabled");
static_assert(offsetof(FSolverRemovalFilterSettings, MinMass) == 0x4, "Offset mismatch for FSolverRemovalFilterSettings::MinMass");
static_assert(offsetof(FSolverRemovalFilterSettings, MinVolume) == 0x8, "Offset mismatch for FSolverRemovalFilterSettings::MinVolume");

