/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GeometryCacheTracks
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MovieScene.h"
#include "CoreUObject.h"
#include "GeometryCache.h"

// Size: 0x148 (Inherited: 0x1f0, Single: 0xffffff58)
class UMovieSceneGeometryCacheSection : public UMovieSceneSection
{
public:
    FMovieSceneGeometryCacheParams Params; // 0x108 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(UMovieSceneGeometryCacheSection) == 0x148, "Size mismatch for UMovieSceneGeometryCacheSection");
static_assert(offsetof(UMovieSceneGeometryCacheSection, Params) == 0x108, "Offset mismatch for UMovieSceneGeometryCacheSection::Params");

// Size: 0x128 (Inherited: 0x308, Single: 0xfffffe20)
class UMovieSceneGeometryCacheTrack : public UMovieSceneNameableTrack
{
public:
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)
    TArray<UMovieSceneSection*> AnimationSections; // 0x118 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UMovieSceneGeometryCacheTrack) == 0x128, "Size mismatch for UMovieSceneGeometryCacheTrack");
static_assert(offsetof(UMovieSceneGeometryCacheTrack, AnimationSections) == 0x118, "Offset mismatch for UMovieSceneGeometryCacheTrack::AnimationSections");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FMovieSceneGeometryCacheParams
{
    UGeometryCache* GeometryCacheAsset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FFrameNumber FirstLoopStartFrameOffset; // 0x8 (Size: 0x4, Type: StructProperty)
    FFrameNumber StartFrameOffset; // 0xc (Size: 0x4, Type: StructProperty)
    FFrameNumber EndFrameOffset; // 0x10 (Size: 0x4, Type: StructProperty)
    float PlayRate; // 0x14 (Size: 0x4, Type: FloatProperty)
    uint8_t bReverse : 1; // 0x18:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    float StartOffset; // 0x1c (Size: 0x4, Type: FloatProperty)
    float EndOffset; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FSoftObjectPath GeometryCache; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FMovieSceneGeometryCacheParams) == 0x40, "Size mismatch for FMovieSceneGeometryCacheParams");
static_assert(offsetof(FMovieSceneGeometryCacheParams, GeometryCacheAsset) == 0x0, "Offset mismatch for FMovieSceneGeometryCacheParams::GeometryCacheAsset");
static_assert(offsetof(FMovieSceneGeometryCacheParams, FirstLoopStartFrameOffset) == 0x8, "Offset mismatch for FMovieSceneGeometryCacheParams::FirstLoopStartFrameOffset");
static_assert(offsetof(FMovieSceneGeometryCacheParams, StartFrameOffset) == 0xc, "Offset mismatch for FMovieSceneGeometryCacheParams::StartFrameOffset");
static_assert(offsetof(FMovieSceneGeometryCacheParams, EndFrameOffset) == 0x10, "Offset mismatch for FMovieSceneGeometryCacheParams::EndFrameOffset");
static_assert(offsetof(FMovieSceneGeometryCacheParams, PlayRate) == 0x14, "Offset mismatch for FMovieSceneGeometryCacheParams::PlayRate");
static_assert(offsetof(FMovieSceneGeometryCacheParams, bReverse) == 0x18, "Offset mismatch for FMovieSceneGeometryCacheParams::bReverse");
static_assert(offsetof(FMovieSceneGeometryCacheParams, StartOffset) == 0x1c, "Offset mismatch for FMovieSceneGeometryCacheParams::StartOffset");
static_assert(offsetof(FMovieSceneGeometryCacheParams, EndOffset) == 0x20, "Offset mismatch for FMovieSceneGeometryCacheParams::EndOffset");
static_assert(offsetof(FMovieSceneGeometryCacheParams, GeometryCache) == 0x28, "Offset mismatch for FMovieSceneGeometryCacheParams::GeometryCache");

// Size: 0x48 (Inherited: 0x40, Single: 0x8)
struct FMovieSceneGeometryCacheSectionTemplateParameters : FMovieSceneGeometryCacheParams
{
    FFrameNumber SectionStartTime; // 0x40 (Size: 0x4, Type: StructProperty)
    FFrameNumber SectionEndTime; // 0x44 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FMovieSceneGeometryCacheSectionTemplateParameters) == 0x48, "Size mismatch for FMovieSceneGeometryCacheSectionTemplateParameters");
static_assert(offsetof(FMovieSceneGeometryCacheSectionTemplateParameters, SectionStartTime) == 0x40, "Offset mismatch for FMovieSceneGeometryCacheSectionTemplateParameters::SectionStartTime");
static_assert(offsetof(FMovieSceneGeometryCacheSectionTemplateParameters, SectionEndTime) == 0x44, "Offset mismatch for FMovieSceneGeometryCacheSectionTemplateParameters::SectionEndTime");

// Size: 0x68 (Inherited: 0x30, Single: 0x38)
struct FMovieSceneGeometryCacheSectionTemplate : FMovieSceneEvalTemplate
{
    FMovieSceneGeometryCacheSectionTemplateParameters Params; // 0x20 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FMovieSceneGeometryCacheSectionTemplate) == 0x68, "Size mismatch for FMovieSceneGeometryCacheSectionTemplate");
static_assert(offsetof(FMovieSceneGeometryCacheSectionTemplate, Params) == 0x20, "Offset mismatch for FMovieSceneGeometryCacheSectionTemplate::Params");

