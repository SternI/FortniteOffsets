/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DatasmithCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDatasmithClothAssetFactory : public UObject
{
public:
};

static_assert(sizeof(UDatasmithClothAssetFactory) == 0x28, "Size mismatch for UDatasmithClothAssetFactory");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDatasmithClothComponentFactory : public UObject
{
public:
};

static_assert(sizeof(UDatasmithClothComponentFactory) == 0x28, "Size mismatch for UDatasmithClothComponentFactory");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UDatasmithMesh : public UObject
{
public:
    FString MeshName; // 0x28 (Size: 0x10, Type: StrProperty)
    bool bIsCollisionMesh; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    TArray<FDatasmithMeshSourceModel> SourceModels; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDatasmithMesh) == 0x50, "Size mismatch for UDatasmithMesh");
static_assert(offsetof(UDatasmithMesh, MeshName) == 0x28, "Offset mismatch for UDatasmithMesh::MeshName");
static_assert(offsetof(UDatasmithMesh, bIsCollisionMesh) == 0x38, "Offset mismatch for UDatasmithMesh::bIsCollisionMesh");
static_assert(offsetof(UDatasmithMesh, SourceModels) == 0x40, "Offset mismatch for UDatasmithMesh::SourceModels");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDatasmithMeshSourceModel
{
};

static_assert(sizeof(FDatasmithMeshSourceModel) == 0x40, "Size mismatch for FDatasmithMeshSourceModel");

