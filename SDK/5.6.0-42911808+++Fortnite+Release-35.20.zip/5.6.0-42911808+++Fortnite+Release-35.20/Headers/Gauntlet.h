/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Gauntlet
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UGauntletTestController : public UObject
{
public:
};

static_assert(sizeof(UGauntletTestController) == 0x30, "Size mismatch for UGauntletTestController");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UGauntletTestControllerBootTest : public UGauntletTestController
{
public:
};

static_assert(sizeof(UGauntletTestControllerBootTest) == 0x30, "Size mismatch for UGauntletTestControllerBootTest");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UGauntletTestControllerErrorTest : public UGauntletTestController
{
public:
};

static_assert(sizeof(UGauntletTestControllerErrorTest) == 0x50, "Size mismatch for UGauntletTestControllerErrorTest");

