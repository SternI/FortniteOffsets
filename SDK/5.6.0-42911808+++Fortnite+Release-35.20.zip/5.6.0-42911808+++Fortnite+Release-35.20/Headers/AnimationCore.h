/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UAnimationDataSourceRegistry : public UObject
{
public:
    TMap<TWeakObjectPtr<UObject*>, FName> DataSources; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UAnimationDataSourceRegistry) == 0x78, "Size mismatch for UAnimationDataSourceRegistry");
static_assert(offsetof(UAnimationDataSourceRegistry, DataSources) == 0x28, "Offset mismatch for UAnimationDataSourceRegistry::DataSources");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAxis
{
    FVector Axis; // 0x0 (Size: 0x18, Type: StructProperty)
    bool bInLocalSpace; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAxis) == 0x20, "Size mismatch for FAxis");
static_assert(offsetof(FAxis, Axis) == 0x0, "Offset mismatch for FAxis::Axis");
static_assert(offsetof(FAxis, bInLocalSpace) == 0x18, "Offset mismatch for FAxis::bInLocalSpace");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FNodeChain
{
    TArray<FName> Nodes; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FNodeChain) == 0x10, "Size mismatch for FNodeChain");
static_assert(offsetof(FNodeChain, Nodes) == 0x0, "Offset mismatch for FNodeChain::Nodes");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FNodeObject
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    FName ParentName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FNodeObject) == 0x8, "Size mismatch for FNodeObject");
static_assert(offsetof(FNodeObject, Name) == 0x0, "Offset mismatch for FNodeObject::Name");
static_assert(offsetof(FNodeObject, ParentName) == 0x4, "Offset mismatch for FNodeObject::ParentName");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FNodeHierarchyData
{
    TArray<FNodeObject> Nodes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> Transforms; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, FName> NodeNameToIndexMapping; // 0x20 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FNodeHierarchyData) == 0x70, "Size mismatch for FNodeHierarchyData");
static_assert(offsetof(FNodeHierarchyData, Nodes) == 0x0, "Offset mismatch for FNodeHierarchyData::Nodes");
static_assert(offsetof(FNodeHierarchyData, Transforms) == 0x10, "Offset mismatch for FNodeHierarchyData::Transforms");
static_assert(offsetof(FNodeHierarchyData, NodeNameToIndexMapping) == 0x20, "Offset mismatch for FNodeHierarchyData::NodeNameToIndexMapping");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FNodeHierarchyWithUserData
{
    FNodeHierarchyData Hierarchy; // 0x8 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FNodeHierarchyWithUserData) == 0x78, "Size mismatch for FNodeHierarchyWithUserData");
static_assert(offsetof(FNodeHierarchyWithUserData, Hierarchy) == 0x8, "Offset mismatch for FNodeHierarchyWithUserData::Hierarchy");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FCCDIKChainLink
{
};

static_assert(sizeof(FCCDIKChainLink) == 0xe0, "Size mismatch for FCCDIKChainLink");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FFilterOptionPerAxis
{
    bool bX; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bY; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bZ; // 0x2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FFilterOptionPerAxis) == 0x3, "Size mismatch for FFilterOptionPerAxis");
static_assert(offsetof(FFilterOptionPerAxis, bX) == 0x0, "Offset mismatch for FFilterOptionPerAxis::bX");
static_assert(offsetof(FFilterOptionPerAxis, bY) == 0x1, "Offset mismatch for FFilterOptionPerAxis::bY");
static_assert(offsetof(FFilterOptionPerAxis, bZ) == 0x2, "Offset mismatch for FFilterOptionPerAxis::bZ");

// Size: 0x9 (Inherited: 0x0, Single: 0x9)
struct FTransformFilter
{
    FFilterOptionPerAxis TranslationFilter; // 0x0 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis RotationFilter; // 0x3 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis ScaleFilter; // 0x6 (Size: 0x3, Type: StructProperty)
};

static_assert(sizeof(FTransformFilter) == 0x9, "Size mismatch for FTransformFilter");
static_assert(offsetof(FTransformFilter, TranslationFilter) == 0x0, "Offset mismatch for FTransformFilter::TranslationFilter");
static_assert(offsetof(FTransformFilter, RotationFilter) == 0x3, "Offset mismatch for FTransformFilter::RotationFilter");
static_assert(offsetof(FTransformFilter, ScaleFilter) == 0x6, "Offset mismatch for FTransformFilter::ScaleFilter");

// Size: 0xd (Inherited: 0x0, Single: 0xd)
struct FConstraintDescription
{
    bool bTranslation; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bRotation; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bScale; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bParent; // 0x3 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis TranslationAxes; // 0x4 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis RotationAxes; // 0x7 (Size: 0x3, Type: StructProperty)
    FFilterOptionPerAxis ScaleAxes; // 0xa (Size: 0x3, Type: StructProperty)
};

static_assert(sizeof(FConstraintDescription) == 0xd, "Size mismatch for FConstraintDescription");
static_assert(offsetof(FConstraintDescription, bTranslation) == 0x0, "Offset mismatch for FConstraintDescription::bTranslation");
static_assert(offsetof(FConstraintDescription, bRotation) == 0x1, "Offset mismatch for FConstraintDescription::bRotation");
static_assert(offsetof(FConstraintDescription, bScale) == 0x2, "Offset mismatch for FConstraintDescription::bScale");
static_assert(offsetof(FConstraintDescription, bParent) == 0x3, "Offset mismatch for FConstraintDescription::bParent");
static_assert(offsetof(FConstraintDescription, TranslationAxes) == 0x4, "Offset mismatch for FConstraintDescription::TranslationAxes");
static_assert(offsetof(FConstraintDescription, RotationAxes) == 0x7, "Offset mismatch for FConstraintDescription::RotationAxes");
static_assert(offsetof(FConstraintDescription, ScaleAxes) == 0xa, "Offset mismatch for FConstraintDescription::ScaleAxes");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FConstraintOffset
{
    FVector Translation; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FQuat Rotation; // 0x20 (Size: 0x20, Type: StructProperty)
    FVector Scale; // 0x40 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    FTransform Parent; // 0x60 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FConstraintOffset) == 0xc0, "Size mismatch for FConstraintOffset");
static_assert(offsetof(FConstraintOffset, Translation) == 0x0, "Offset mismatch for FConstraintOffset::Translation");
static_assert(offsetof(FConstraintOffset, Rotation) == 0x20, "Offset mismatch for FConstraintOffset::Rotation");
static_assert(offsetof(FConstraintOffset, Scale) == 0x40, "Offset mismatch for FConstraintOffset::Scale");
static_assert(offsetof(FConstraintOffset, Parent) == 0x60, "Offset mismatch for FConstraintOffset::Parent");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FTransformConstraint
{
    FConstraintDescription Operator; // 0x0 (Size: 0xd, Type: StructProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FName SourceNode; // 0x10 (Size: 0x4, Type: NameProperty)
    FName TargetNode; // 0x14 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bMaintainOffset; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FTransformConstraint) == 0x20, "Size mismatch for FTransformConstraint");
static_assert(offsetof(FTransformConstraint, Operator) == 0x0, "Offset mismatch for FTransformConstraint::Operator");
static_assert(offsetof(FTransformConstraint, SourceNode) == 0x10, "Offset mismatch for FTransformConstraint::SourceNode");
static_assert(offsetof(FTransformConstraint, TargetNode) == 0x14, "Offset mismatch for FTransformConstraint::TargetNode");
static_assert(offsetof(FTransformConstraint, Weight) == 0x18, "Offset mismatch for FTransformConstraint::Weight");
static_assert(offsetof(FTransformConstraint, bMaintainOffset) == 0x1c, "Offset mismatch for FTransformConstraint::bMaintainOffset");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FConstraintDescriptionEx
{
    FFilterOptionPerAxis AxesFilterOption; // 0x8 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_b[0x5]; // 0xb (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FConstraintDescriptionEx) == 0x10, "Size mismatch for FConstraintDescriptionEx");
static_assert(offsetof(FConstraintDescriptionEx, AxesFilterOption) == 0x8, "Offset mismatch for FConstraintDescriptionEx::AxesFilterOption");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FTransformConstraintDescription : FConstraintDescriptionEx
{
    uint8_t TransformType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTransformConstraintDescription) == 0x18, "Size mismatch for FTransformConstraintDescription");
static_assert(offsetof(FTransformConstraintDescription, TransformType) == 0x10, "Offset mismatch for FTransformConstraintDescription::TransformType");

// Size: 0x70 (Inherited: 0x10, Single: 0x60)
struct FAimConstraintDescription : FConstraintDescriptionEx
{
    FAxis LookAt_Axis; // 0x10 (Size: 0x20, Type: StructProperty)
    FAxis LookUp_Axis; // 0x30 (Size: 0x20, Type: StructProperty)
    bool bUseLookUp; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    FVector LookUpTarget; // 0x58 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAimConstraintDescription) == 0x70, "Size mismatch for FAimConstraintDescription");
static_assert(offsetof(FAimConstraintDescription, LookAt_Axis) == 0x10, "Offset mismatch for FAimConstraintDescription::LookAt_Axis");
static_assert(offsetof(FAimConstraintDescription, LookUp_Axis) == 0x30, "Offset mismatch for FAimConstraintDescription::LookUp_Axis");
static_assert(offsetof(FAimConstraintDescription, bUseLookUp) == 0x50, "Offset mismatch for FAimConstraintDescription::bUseLookUp");
static_assert(offsetof(FAimConstraintDescription, LookUpTarget) == 0x58, "Offset mismatch for FAimConstraintDescription::LookUpTarget");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FConstraintDescriptor
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0xf]; // 0x1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FConstraintDescriptor) == 0x10, "Size mismatch for FConstraintDescriptor");
static_assert(offsetof(FConstraintDescriptor, Type) == 0x0, "Offset mismatch for FConstraintDescriptor::Type");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FConstraintData
{
    FConstraintDescriptor Constraint; // 0x0 (Size: 0x10, Type: StructProperty)
    float Weight; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bMaintainOffset; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0xb]; // 0x15 (Size: 0xb, Type: PaddingProperty)
    FTransform Offset; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform CurrentTransform; // 0x80 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FConstraintData) == 0xe0, "Size mismatch for FConstraintData");
static_assert(offsetof(FConstraintData, Constraint) == 0x0, "Offset mismatch for FConstraintData::Constraint");
static_assert(offsetof(FConstraintData, Weight) == 0x10, "Offset mismatch for FConstraintData::Weight");
static_assert(offsetof(FConstraintData, bMaintainOffset) == 0x14, "Offset mismatch for FConstraintData::bMaintainOffset");
static_assert(offsetof(FConstraintData, Offset) == 0x20, "Offset mismatch for FConstraintData::Offset");
static_assert(offsetof(FConstraintData, CurrentTransform) == 0x80, "Offset mismatch for FConstraintData::CurrentTransform");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FEulerTransform
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator Rotation; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Scale; // 0x30 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FEulerTransform) == 0x48, "Size mismatch for FEulerTransform");
static_assert(offsetof(FEulerTransform, Location) == 0x0, "Offset mismatch for FEulerTransform::Location");
static_assert(offsetof(FEulerTransform, Rotation) == 0x18, "Offset mismatch for FEulerTransform::Rotation");
static_assert(offsetof(FEulerTransform, Scale) == 0x30, "Offset mismatch for FEulerTransform::Scale");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFABRIKChainLink
{
};

static_assert(sizeof(FFABRIKChainLink) == 0x50, "Size mismatch for FFABRIKChainLink");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FTransformNoScale
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FQuat Rotation; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FTransformNoScale) == 0x40, "Size mismatch for FTransformNoScale");
static_assert(offsetof(FTransformNoScale, Location) == 0x0, "Offset mismatch for FTransformNoScale::Location");
static_assert(offsetof(FTransformNoScale, Rotation) == 0x20, "Offset mismatch for FTransformNoScale::Rotation");

