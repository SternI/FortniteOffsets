/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FacialAnimSystem
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "LiveLinkAnimationCore.h"

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UFacialLiveLinkRemapAsset : public ULiveLinkRetargetAsset
{
public:
    bool bExtractBoneTransform; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bExtractCurve; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFacialLiveLinkRemapAsset) == 0x30, "Size mismatch for UFacialLiveLinkRemapAsset");
static_assert(offsetof(UFacialLiveLinkRemapAsset, bExtractBoneTransform) == 0x28, "Offset mismatch for UFacialLiveLinkRemapAsset::bExtractBoneTransform");
static_assert(offsetof(UFacialLiveLinkRemapAsset, bExtractCurve) == 0x29, "Offset mismatch for UFacialLiveLinkRemapAsset::bExtractCurve");

