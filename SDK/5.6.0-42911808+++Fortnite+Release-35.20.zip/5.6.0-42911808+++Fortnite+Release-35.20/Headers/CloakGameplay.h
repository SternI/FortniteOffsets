/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CloakGameplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayAbilities.h"

// Size: 0xa40 (Inherited: 0x1378, Single: 0xfffff6c8)
class AFortGameCueNotifyLoop_Cloak : public AFortGameplayCueNotify_Loop
{
public:
    AFortPlayerPawn* TargetPlayer; // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    float VisibilityLevel; // 0x9d0 (Size: 0x4, Type: FloatProperty)
    float StationaryVisMult; // 0x9d4 (Size: 0x4, Type: FloatProperty)
    float MaxSpeedVisMult; // 0x9d8 (Size: 0x4, Type: FloatProperty)
    float SpeedForMaxVis; // 0x9dc (Size: 0x4, Type: FloatProperty)
    float VisibilityMinFriendly; // 0x9e0 (Size: 0x4, Type: FloatProperty)
    float VisibilityMinNonfriendly; // 0x9e4 (Size: 0x4, Type: FloatProperty)
    float VisibilityLevelChangeRate; // 0x9e8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9ec[0x4]; // 0x9ec (Size: 0x4, Type: PaddingProperty)
    TMap<FFortGameCueCloakModifier, FName> CloakModifiersByNameMap; // 0x9f0 (Size: 0x50, Type: MapProperty)

protected:
    bool GetCurrentModifierValues(float& OutVisibilityMultiplier, float& OutVisibilityAddition, const FName ModifierName) const; // 0x1133e780 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool SetModifierCanBeEnabled(const FName ModifierName, bool& const bNewCanBeEnabled); // 0x1133e9b0 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    bool SetModifierEnabled(const FName ModifierName, bool& const bNewEnabled); // 0x1133eb30 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    float TickVisibilityLevel(float& const DeltaSeconds); // 0x1133ecb0 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AFortGameCueNotifyLoop_Cloak) == 0xa40, "Size mismatch for AFortGameCueNotifyLoop_Cloak");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, TargetPlayer) == 0x9c8, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::TargetPlayer");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, VisibilityLevel) == 0x9d0, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::VisibilityLevel");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, StationaryVisMult) == 0x9d4, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::StationaryVisMult");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, MaxSpeedVisMult) == 0x9d8, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::MaxSpeedVisMult");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, SpeedForMaxVis) == 0x9dc, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::SpeedForMaxVis");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, VisibilityMinFriendly) == 0x9e0, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::VisibilityMinFriendly");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, VisibilityMinNonfriendly) == 0x9e4, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::VisibilityMinNonfriendly");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, VisibilityLevelChangeRate) == 0x9e8, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::VisibilityLevelChangeRate");
static_assert(offsetof(AFortGameCueNotifyLoop_Cloak, CloakModifiersByNameMap) == 0x9f0, "Offset mismatch for AFortGameCueNotifyLoop_Cloak::CloakModifiersByNameMap");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FFortGameCueCloakModifier
{
    FScalableFloat bCanBeEnabled; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat VisibilityModifierMultiplicative; // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat VisibilityModifierAdditive; // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat AlphaTimeToEnabled; // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat AlphaTimeToDisabled; // 0xa0 (Size: 0x28, Type: StructProperty)
    uint8_t bCurrentlyEnabled : 1; // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x3]; // 0xc9 (Size: 0x3, Type: PaddingProperty)
    float CurrentAlpha; // 0xcc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortGameCueCloakModifier) == 0xd0, "Size mismatch for FFortGameCueCloakModifier");
static_assert(offsetof(FFortGameCueCloakModifier, bCanBeEnabled) == 0x0, "Offset mismatch for FFortGameCueCloakModifier::bCanBeEnabled");
static_assert(offsetof(FFortGameCueCloakModifier, VisibilityModifierMultiplicative) == 0x28, "Offset mismatch for FFortGameCueCloakModifier::VisibilityModifierMultiplicative");
static_assert(offsetof(FFortGameCueCloakModifier, VisibilityModifierAdditive) == 0x50, "Offset mismatch for FFortGameCueCloakModifier::VisibilityModifierAdditive");
static_assert(offsetof(FFortGameCueCloakModifier, AlphaTimeToEnabled) == 0x78, "Offset mismatch for FFortGameCueCloakModifier::AlphaTimeToEnabled");
static_assert(offsetof(FFortGameCueCloakModifier, AlphaTimeToDisabled) == 0xa0, "Offset mismatch for FFortGameCueCloakModifier::AlphaTimeToDisabled");
static_assert(offsetof(FFortGameCueCloakModifier, bCurrentlyEnabled) == 0xc8, "Offset mismatch for FFortGameCueCloakModifier::bCurrentlyEnabled");
static_assert(offsetof(FFortGameCueCloakModifier, CurrentAlpha) == 0xcc, "Offset mismatch for FFortGameCueCloakModifier::CurrentAlpha");

