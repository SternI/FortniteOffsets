/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayInteractionsModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "SmartObjectsModule.h"
#include "AIModule.h"
#include "StateTreeModule.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "ContextualAnimation.h"
#include "GameplayTags.h"

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
class UGameplayInteractionSmartObjectBehaviorDefinition : public USmartObjectBehaviorDefinition
{
public:
    FStateTreeReference StateTreeReference; // 0x28 (Size: 0x28, Type: StructProperty)

public:
    UStateTree* GetStateTree() const; // 0xc3d2bbc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetStateTree(UStateTree*& NewStateTree); // 0xc94fecc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayInteractionSmartObjectBehaviorDefinition) == 0x50, "Size mismatch for UGameplayInteractionSmartObjectBehaviorDefinition");
static_assert(offsetof(UGameplayInteractionSmartObjectBehaviorDefinition, StateTreeReference) == 0x28, "Offset mismatch for UGameplayInteractionSmartObjectBehaviorDefinition::StateTreeReference");

// Size: 0x148 (Inherited: 0xf0, Single: 0x58)
class UAITask_UseGameplayInteraction : public UAITask
{
public:
    uint8_t OnFinished[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSucceeded[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFailed[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMoveToFailed[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FGameplayInteractionContext GameplayInteractionContext; // 0xa8 (Size: 0x70, Type: StructProperty)
    UAITask_MoveTo* MoveToTask; // 0x118 (Size: 0x8, Type: ObjectProperty)
    FSmartObjectClaimHandle ClaimedHandle; // 0x120 (Size: 0x20, Type: StructProperty)
    FGameplayInteractionAbortContext AbortContext; // 0x140 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_141[0x7]; // 0x141 (Size: 0x7, Type: PaddingProperty)

public:
    static UAITask_UseGameplayInteraction* MoveToAndUseSmartObjectWithGameplayInteraction(AAIController*& Controller, FSmartObjectClaimHandle& ClaimHandle, bool& bLockAILogic); // 0xc94f8b4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    void RequestAbort(); // 0xc94feb8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    static UAITask_UseGameplayInteraction* UseSmartObjectWithGameplayInteraction(AAIController*& Controller, FSmartObjectClaimHandle& ClaimHandle, bool& bLockAILogic); // 0xc9501ac (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAITask_UseGameplayInteraction) == 0x148, "Size mismatch for UAITask_UseGameplayInteraction");
static_assert(offsetof(UAITask_UseGameplayInteraction, OnFinished) == 0x68, "Offset mismatch for UAITask_UseGameplayInteraction::OnFinished");
static_assert(offsetof(UAITask_UseGameplayInteraction, OnSucceeded) == 0x78, "Offset mismatch for UAITask_UseGameplayInteraction::OnSucceeded");
static_assert(offsetof(UAITask_UseGameplayInteraction, OnFailed) == 0x88, "Offset mismatch for UAITask_UseGameplayInteraction::OnFailed");
static_assert(offsetof(UAITask_UseGameplayInteraction, OnMoveToFailed) == 0x98, "Offset mismatch for UAITask_UseGameplayInteraction::OnMoveToFailed");
static_assert(offsetof(UAITask_UseGameplayInteraction, GameplayInteractionContext) == 0xa8, "Offset mismatch for UAITask_UseGameplayInteraction::GameplayInteractionContext");
static_assert(offsetof(UAITask_UseGameplayInteraction, MoveToTask) == 0x118, "Offset mismatch for UAITask_UseGameplayInteraction::MoveToTask");
static_assert(offsetof(UAITask_UseGameplayInteraction, ClaimedHandle) == 0x120, "Offset mismatch for UAITask_UseGameplayInteraction::ClaimedHandle");
static_assert(offsetof(UAITask_UseGameplayInteraction, AbortContext) == 0x140, "Offset mismatch for UAITask_UseGameplayInteraction::AbortContext");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UGameplayInteractionStateTreeSchema : public UStateTreeSchema
{
public:
    UClass* ContextActorClass; // 0x28 (Size: 0x8, Type: ClassProperty)
    UClass* SmartObjectActorClass; // 0x30 (Size: 0x8, Type: ClassProperty)
    TArray<FStateTreeExternalDataDesc> ContextDataDescs; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayInteractionStateTreeSchema) == 0x48, "Size mismatch for UGameplayInteractionStateTreeSchema");
static_assert(offsetof(UGameplayInteractionStateTreeSchema, ContextActorClass) == 0x28, "Offset mismatch for UGameplayInteractionStateTreeSchema::ContextActorClass");
static_assert(offsetof(UGameplayInteractionStateTreeSchema, SmartObjectActorClass) == 0x30, "Offset mismatch for UGameplayInteractionStateTreeSchema::SmartObjectActorClass");
static_assert(offsetof(UGameplayInteractionStateTreeSchema, ContextDataDescs) == 0x38, "Offset mismatch for UGameplayInteractionStateTreeSchema::ContextDataDescs");

// Size: 0xa0 (Inherited: 0x28, Single: 0x78)
class UStateTreeTask_PlayContextualAnim_InstanceData : public UObject
{
public:
    AActor* PrimaryActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
    AActor* SecondaryActor; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName SecondaryRole; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    AActor* TertiaryActor; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName TertiaryRole; // 0x48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    UContextualAnimSceneAsset* SceneAsset; // 0x50 (Size: 0x8, Type: ObjectProperty)
    FName SectionName; // 0x58 (Size: 0x4, Type: NameProperty)
    uint8_t ExecutionMethod; // 0x5c (Size: 0x1, Type: EnumProperty)
    bool bWaitForNotifyEventToEnd; // 0x5d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5e[0x2]; // 0x5e (Size: 0x2, Type: PaddingProperty)
    FName NotifyEventNameToEnd; // 0x60 (Size: 0x4, Type: NameProperty)
    int32_t LoopsToRun; // 0x64 (Size: 0x4, Type: IntProperty)
    bool bLoopForever; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x3]; // 0x69 (Size: 0x3, Type: PaddingProperty)
    float DelayBetweenLoops; // 0x6c (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops; // 0x70 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    TArray<FContextualAnimWarpTarget> WarpTargets; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x18]; // 0x88 (Size: 0x18, Type: PaddingProperty)

public:
    void OnMontageEnded(UAnimMontage*& const EndedMontage, bool& const bInterrupted); // 0xc94fae4 (Index: 0x0, Flags: Final|Native|Public)
    void OnNotifyBeginReceived(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0xc94fcf0 (Index: 0x1, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UStateTreeTask_PlayContextualAnim_InstanceData) == 0xa0, "Size mismatch for UStateTreeTask_PlayContextualAnim_InstanceData");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, PrimaryActor) == 0x28, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::PrimaryActor");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, SecondaryActor) == 0x30, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::SecondaryActor");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, SecondaryRole) == 0x38, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::SecondaryRole");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, TertiaryActor) == 0x40, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::TertiaryActor");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, TertiaryRole) == 0x48, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::TertiaryRole");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, SceneAsset) == 0x50, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::SceneAsset");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, SectionName) == 0x58, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::SectionName");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, ExecutionMethod) == 0x5c, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::ExecutionMethod");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, bWaitForNotifyEventToEnd) == 0x5d, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::bWaitForNotifyEventToEnd");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, NotifyEventNameToEnd) == 0x60, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::NotifyEventNameToEnd");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, LoopsToRun) == 0x64, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::LoopsToRun");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, bLoopForever) == 0x68, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::bLoopForever");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, DelayBetweenLoops) == 0x6c, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::DelayBetweenLoops");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, RandomDeviationBetweenLoops) == 0x70, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::RandomDeviationBetweenLoops");
static_assert(offsetof(UStateTreeTask_PlayContextualAnim_InstanceData, WarpTargets) == 0x78, "Offset mismatch for UStateTreeTask_PlayContextualAnim_InstanceData::WarpTargets");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FGameplayInteractionContext
{
    FStateTreeInstanceData StateTreeInstanceData; // 0x0 (Size: 0x10, Type: StructProperty)
    FSmartObjectClaimHandle ClaimedHandle; // 0x10 (Size: 0x20, Type: StructProperty)
    FSmartObjectSlotEntranceHandle SlotEntranceHandle; // 0x30 (Size: 0x18, Type: StructProperty)
    FGameplayInteractionAbortContext AbortContext; // 0x48 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    AActor* ContextActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
    AActor* SmartObjectActor; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UGameplayInteractionSmartObjectBehaviorDefinition* Definition; // 0x60 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionContext) == 0x70, "Size mismatch for FGameplayInteractionContext");
static_assert(offsetof(FGameplayInteractionContext, StateTreeInstanceData) == 0x0, "Offset mismatch for FGameplayInteractionContext::StateTreeInstanceData");
static_assert(offsetof(FGameplayInteractionContext, ClaimedHandle) == 0x10, "Offset mismatch for FGameplayInteractionContext::ClaimedHandle");
static_assert(offsetof(FGameplayInteractionContext, SlotEntranceHandle) == 0x30, "Offset mismatch for FGameplayInteractionContext::SlotEntranceHandle");
static_assert(offsetof(FGameplayInteractionContext, AbortContext) == 0x48, "Offset mismatch for FGameplayInteractionContext::AbortContext");
static_assert(offsetof(FGameplayInteractionContext, ContextActor) == 0x50, "Offset mismatch for FGameplayInteractionContext::ContextActor");
static_assert(offsetof(FGameplayInteractionContext, SmartObjectActor) == 0x58, "Offset mismatch for FGameplayInteractionContext::SmartObjectActor");
static_assert(offsetof(FGameplayInteractionContext, Definition) == 0x60, "Offset mismatch for FGameplayInteractionContext::Definition");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGameplayInteractionAbortContext
{
    uint8_t Reason; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FGameplayInteractionAbortContext) == 0x1, "Size mismatch for FGameplayInteractionAbortContext");
static_assert(offsetof(FGameplayInteractionAbortContext, Reason) == 0x0, "Offset mismatch for FGameplayInteractionAbortContext::Reason");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FGameplayInteractionSlotUserData : FSmartObjectSlotStateData
{
};

static_assert(sizeof(FGameplayInteractionSlotUserData) == 0x8, "Size mismatch for FGameplayInteractionSlotUserData");

// Size: 0x20 (Inherited: 0x38, Single: 0xffffffe8)
struct FGameplayInteractionStateTreeTask : FStateTreeTaskBase
{
};

static_assert(sizeof(FGameplayInteractionStateTreeTask) == 0x20, "Size mismatch for FGameplayInteractionStateTreeTask");

// Size: 0x20 (Inherited: 0x38, Single: 0xffffffe8)
struct FGameplayInteractionStateTreeCondition : FStateTreeConditionBase
{
};

static_assert(sizeof(FGameplayInteractionStateTreeCondition) == 0x20, "Size mismatch for FGameplayInteractionStateTreeCondition");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGameplayInteractionMatchSlotTagsConditionInstanceData
{
    FSmartObjectSlotHandle Slot; // 0x0 (Size: 0x10, Type: StructProperty)
    FGameplayTagContainer TagsToMatch; // 0x10 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FGameplayInteractionMatchSlotTagsConditionInstanceData) == 0x30, "Size mismatch for FGameplayInteractionMatchSlotTagsConditionInstanceData");
static_assert(offsetof(FGameplayInteractionMatchSlotTagsConditionInstanceData, Slot) == 0x0, "Offset mismatch for FGameplayInteractionMatchSlotTagsConditionInstanceData::Slot");
static_assert(offsetof(FGameplayInteractionMatchSlotTagsConditionInstanceData, TagsToMatch) == 0x10, "Offset mismatch for FGameplayInteractionMatchSlotTagsConditionInstanceData::TagsToMatch");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FGameplayInteractionSlotTagsMatchCondition : FGameplayInteractionStateTreeCondition
{
    uint8_t Source; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t MatchType; // 0x21 (Size: 0x1, Type: EnumProperty)
    bool bExactMatch; // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bInvert; // 0x23 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_24[0xc]; // 0x24 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSlotTagsMatchCondition) == 0x30, "Size mismatch for FGameplayInteractionSlotTagsMatchCondition");
static_assert(offsetof(FGameplayInteractionSlotTagsMatchCondition, Source) == 0x20, "Offset mismatch for FGameplayInteractionSlotTagsMatchCondition::Source");
static_assert(offsetof(FGameplayInteractionSlotTagsMatchCondition, MatchType) == 0x21, "Offset mismatch for FGameplayInteractionSlotTagsMatchCondition::MatchType");
static_assert(offsetof(FGameplayInteractionSlotTagsMatchCondition, bExactMatch) == 0x22, "Offset mismatch for FGameplayInteractionSlotTagsMatchCondition::bExactMatch");
static_assert(offsetof(FGameplayInteractionSlotTagsMatchCondition, bInvert) == 0x23, "Offset mismatch for FGameplayInteractionSlotTagsMatchCondition::bInvert");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayInteractionQuerySlotTagsConditionInstanceData
{
    FSmartObjectSlotHandle Slot; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGameplayInteractionQuerySlotTagsConditionInstanceData) == 0x10, "Size mismatch for FGameplayInteractionQuerySlotTagsConditionInstanceData");
static_assert(offsetof(FGameplayInteractionQuerySlotTagsConditionInstanceData, Slot) == 0x0, "Offset mismatch for FGameplayInteractionQuerySlotTagsConditionInstanceData::Slot");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
struct FGameplayInteractionQuerySlotTagCondition : FGameplayInteractionStateTreeCondition
{
    uint8_t Source; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery TagQuery; // 0x28 (Size: 0x48, Type: StructProperty)
    bool bInvert; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionQuerySlotTagCondition) == 0x78, "Size mismatch for FGameplayInteractionQuerySlotTagCondition");
static_assert(offsetof(FGameplayInteractionQuerySlotTagCondition, Source) == 0x20, "Offset mismatch for FGameplayInteractionQuerySlotTagCondition::Source");
static_assert(offsetof(FGameplayInteractionQuerySlotTagCondition, TagQuery) == 0x28, "Offset mismatch for FGameplayInteractionQuerySlotTagCondition::TagQuery");
static_assert(offsetof(FGameplayInteractionQuerySlotTagCondition, bInvert) == 0x70, "Offset mismatch for FGameplayInteractionQuerySlotTagCondition::bInvert");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayInteractionIsSlotHandleValidConditionInstanceData
{
    FSmartObjectSlotHandle Slot; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGameplayInteractionIsSlotHandleValidConditionInstanceData) == 0x10, "Size mismatch for FGameplayInteractionIsSlotHandleValidConditionInstanceData");
static_assert(offsetof(FGameplayInteractionIsSlotHandleValidConditionInstanceData, Slot) == 0x0, "Offset mismatch for FGameplayInteractionIsSlotHandleValidConditionInstanceData::Slot");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayInteractionIsSlotHandleValidCondition : FGameplayInteractionStateTreeCondition
{
    bool bInvert; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionIsSlotHandleValidCondition) == 0x28, "Size mismatch for FGameplayInteractionIsSlotHandleValidCondition");
static_assert(offsetof(FGameplayInteractionIsSlotHandleValidCondition, bInvert) == 0x20, "Offset mismatch for FGameplayInteractionIsSlotHandleValidCondition::bInvert");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayInteractionFindSlotTaskInstanceData
{
    FSmartObjectSlotHandle ReferenceSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    FSmartObjectSlotHandle ResultSlot; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGameplayInteractionFindSlotTaskInstanceData) == 0x20, "Size mismatch for FGameplayInteractionFindSlotTaskInstanceData");
static_assert(offsetof(FGameplayInteractionFindSlotTaskInstanceData, ReferenceSlot) == 0x0, "Offset mismatch for FGameplayInteractionFindSlotTaskInstanceData::ReferenceSlot");
static_assert(offsetof(FGameplayInteractionFindSlotTaskInstanceData, ResultSlot) == 0x10, "Offset mismatch for FGameplayInteractionFindSlotTaskInstanceData::ResultSlot");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FGameplayInteractionFindSlotTask : FGameplayInteractionStateTreeTask
{
    uint8_t ReferenceType; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag FindByTag; // 0x24 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionFindSlotTask) == 0x30, "Size mismatch for FGameplayInteractionFindSlotTask");
static_assert(offsetof(FGameplayInteractionFindSlotTask, ReferenceType) == 0x20, "Offset mismatch for FGameplayInteractionFindSlotTask::ReferenceType");
static_assert(offsetof(FGameplayInteractionFindSlotTask, FindByTag) == 0x24, "Offset mismatch for FGameplayInteractionFindSlotTask::FindByTag");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayInteractionGetSlotActorTaskInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    AActor* ResultActor; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayInteractionGetSlotActorTaskInstanceData) == 0x18, "Size mismatch for FGameplayInteractionGetSlotActorTaskInstanceData");
static_assert(offsetof(FGameplayInteractionGetSlotActorTaskInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionGetSlotActorTaskInstanceData::TargetSlot");
static_assert(offsetof(FGameplayInteractionGetSlotActorTaskInstanceData, ResultActor) == 0x10, "Offset mismatch for FGameplayInteractionGetSlotActorTaskInstanceData::ResultActor");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayInteractionGetSlotActorTask : FGameplayInteractionStateTreeTask
{
    bool bFailIfNotFound; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionGetSlotActorTask) == 0x28, "Size mismatch for FGameplayInteractionGetSlotActorTask");
static_assert(offsetof(FGameplayInteractionGetSlotActorTask, bFailIfNotFound) == 0x20, "Offset mismatch for FGameplayInteractionGetSlotActorTask::bFailIfNotFound");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayInteractionListenSlotEventsTaskInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionListenSlotEventsTaskInstanceData) == 0x18, "Size mismatch for FGameplayInteractionListenSlotEventsTaskInstanceData");
static_assert(offsetof(FGameplayInteractionListenSlotEventsTaskInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionListenSlotEventsTaskInstanceData::TargetSlot");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayInteractionListenSlotEventsTask : FGameplayInteractionStateTreeTask
{
};

static_assert(sizeof(FGameplayInteractionListenSlotEventsTask) == 0x28, "Size mismatch for FGameplayInteractionListenSlotEventsTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayInteractionModifySlotTagTaskInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    bool bTagRemoved; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionModifySlotTagTaskInstanceData) == 0x18, "Size mismatch for FGameplayInteractionModifySlotTagTaskInstanceData");
static_assert(offsetof(FGameplayInteractionModifySlotTagTaskInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionModifySlotTagTaskInstanceData::TargetSlot");
static_assert(offsetof(FGameplayInteractionModifySlotTagTaskInstanceData, bTagRemoved) == 0x10, "Offset mismatch for FGameplayInteractionModifySlotTagTaskInstanceData::bTagRemoved");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FGameplayInteractionModifySlotTagTask : FGameplayInteractionStateTreeTask
{
    uint8_t Modify; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bHandleExternalStopAsFailure; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Operation; // 0x22 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_23[0x1]; // 0x23 (Size: 0x1, Type: PaddingProperty)
    FGameplayTag Tag; // 0x24 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionModifySlotTagTask) == 0x30, "Size mismatch for FGameplayInteractionModifySlotTagTask");
static_assert(offsetof(FGameplayInteractionModifySlotTagTask, Modify) == 0x20, "Offset mismatch for FGameplayInteractionModifySlotTagTask::Modify");
static_assert(offsetof(FGameplayInteractionModifySlotTagTask, bHandleExternalStopAsFailure) == 0x21, "Offset mismatch for FGameplayInteractionModifySlotTagTask::bHandleExternalStopAsFailure");
static_assert(offsetof(FGameplayInteractionModifySlotTagTask, Operation) == 0x22, "Offset mismatch for FGameplayInteractionModifySlotTagTask::Operation");
static_assert(offsetof(FGameplayInteractionModifySlotTagTask, Tag) == 0x24, "Offset mismatch for FGameplayInteractionModifySlotTagTask::Tag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayInteractionSendSlotEventTaskInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGameplayInteractionSendSlotEventTaskInstanceData) == 0x10, "Size mismatch for FGameplayInteractionSendSlotEventTaskInstanceData");
static_assert(offsetof(FGameplayInteractionSendSlotEventTaskInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionSendSlotEventTaskInstanceData::TargetSlot");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
struct FGameplayInteractionSendSlotEventTask : FGameplayInteractionStateTreeTask
{
    FGameplayTag EventTag; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FInstancedStruct Payload; // 0x28 (Size: 0x10, Type: StructProperty)
    uint8_t Trigger; // 0x38 (Size: 0x1, Type: EnumProperty)
    bool bHandleExternalStopAsFailure; // 0x39 (Size: 0x1, Type: BoolProperty)
    bool bShouldTriggerOnReselect; // 0x3a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3b[0xd]; // 0x3b (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSendSlotEventTask) == 0x48, "Size mismatch for FGameplayInteractionSendSlotEventTask");
static_assert(offsetof(FGameplayInteractionSendSlotEventTask, EventTag) == 0x20, "Offset mismatch for FGameplayInteractionSendSlotEventTask::EventTag");
static_assert(offsetof(FGameplayInteractionSendSlotEventTask, Payload) == 0x28, "Offset mismatch for FGameplayInteractionSendSlotEventTask::Payload");
static_assert(offsetof(FGameplayInteractionSendSlotEventTask, Trigger) == 0x38, "Offset mismatch for FGameplayInteractionSendSlotEventTask::Trigger");
static_assert(offsetof(FGameplayInteractionSendSlotEventTask, bHandleExternalStopAsFailure) == 0x39, "Offset mismatch for FGameplayInteractionSendSlotEventTask::bHandleExternalStopAsFailure");
static_assert(offsetof(FGameplayInteractionSendSlotEventTask, bShouldTriggerOnReselect) == 0x3a, "Offset mismatch for FGameplayInteractionSendSlotEventTask::bShouldTriggerOnReselect");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayInteractionSetSlotEnabledInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    bool bInitialState; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSetSlotEnabledInstanceData) == 0x18, "Size mismatch for FGameplayInteractionSetSlotEnabledInstanceData");
static_assert(offsetof(FGameplayInteractionSetSlotEnabledInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionSetSlotEnabledInstanceData::TargetSlot");
static_assert(offsetof(FGameplayInteractionSetSlotEnabledInstanceData, bInitialState) == 0x10, "Offset mismatch for FGameplayInteractionSetSlotEnabledInstanceData::bInitialState");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FGameplayInteractionSetSlotEnabledTask : FGameplayInteractionStateTreeTask
{
    uint8_t Modify; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bHandleExternalStopAsFailure; // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bEnableSlot; // 0x22 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_23[0xd]; // 0x23 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSetSlotEnabledTask) == 0x30, "Size mismatch for FGameplayInteractionSetSlotEnabledTask");
static_assert(offsetof(FGameplayInteractionSetSlotEnabledTask, Modify) == 0x20, "Offset mismatch for FGameplayInteractionSetSlotEnabledTask::Modify");
static_assert(offsetof(FGameplayInteractionSetSlotEnabledTask, bHandleExternalStopAsFailure) == 0x21, "Offset mismatch for FGameplayInteractionSetSlotEnabledTask::bHandleExternalStopAsFailure");
static_assert(offsetof(FGameplayInteractionSetSlotEnabledTask, bEnableSlot) == 0x22, "Offset mismatch for FGameplayInteractionSetSlotEnabledTask::bEnableSlot");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayInteractionSyncSlotTagStateInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_10[0x10]; // 0x10 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSyncSlotTagStateInstanceData) == 0x20, "Size mismatch for FGameplayInteractionSyncSlotTagStateInstanceData");
static_assert(offsetof(FGameplayInteractionSyncSlotTagStateInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionSyncSlotTagStateInstanceData::TargetSlot");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FGameplayInteractionSyncSlotTagStateTask : FGameplayInteractionStateTreeTask
{
    FGameplayTag TagToMonitor; // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTag BreakEventTag; // 0x24 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSyncSlotTagStateTask) == 0x30, "Size mismatch for FGameplayInteractionSyncSlotTagStateTask");
static_assert(offsetof(FGameplayInteractionSyncSlotTagStateTask, TagToMonitor) == 0x20, "Offset mismatch for FGameplayInteractionSyncSlotTagStateTask::TagToMonitor");
static_assert(offsetof(FGameplayInteractionSyncSlotTagStateTask, BreakEventTag) == 0x24, "Offset mismatch for FGameplayInteractionSyncSlotTagStateTask::BreakEventTag");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayInteractionSyncSlotTagTransitionInstanceData
{
    FSmartObjectSlotHandle TargetSlot; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_10[0x10]; // 0x10 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSyncSlotTagTransitionInstanceData) == 0x20, "Size mismatch for FGameplayInteractionSyncSlotTagTransitionInstanceData");
static_assert(offsetof(FGameplayInteractionSyncSlotTagTransitionInstanceData, TargetSlot) == 0x0, "Offset mismatch for FGameplayInteractionSyncSlotTagTransitionInstanceData::TargetSlot");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
struct FGameplayInteractionSyncSlotTagTransitionTask : FGameplayInteractionStateTreeTask
{
    FGameplayTag TransitionFromTag; // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTag TransitionToTag; // 0x24 (Size: 0x4, Type: StructProperty)
    FGameplayTag TransitionEventTag; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0xc]; // 0x2c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayInteractionSyncSlotTagTransitionTask) == 0x38, "Size mismatch for FGameplayInteractionSyncSlotTagTransitionTask");
static_assert(offsetof(FGameplayInteractionSyncSlotTagTransitionTask, TransitionFromTag) == 0x20, "Offset mismatch for FGameplayInteractionSyncSlotTagTransitionTask::TransitionFromTag");
static_assert(offsetof(FGameplayInteractionSyncSlotTagTransitionTask, TransitionToTag) == 0x24, "Offset mismatch for FGameplayInteractionSyncSlotTagTransitionTask::TransitionToTag");
static_assert(offsetof(FGameplayInteractionSyncSlotTagTransitionTask, TransitionEventTag) == 0x28, "Offset mismatch for FGameplayInteractionSyncSlotTagTransitionTask::TransitionEventTag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPlayMontageStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float ComputedDuration; // 0x8 (Size: 0x4, Type: FloatProperty)
    float time; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPlayMontageStateTreeTaskInstanceData) == 0x10, "Size mismatch for FPlayMontageStateTreeTaskInstanceData");
static_assert(offsetof(FPlayMontageStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FPlayMontageStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FPlayMontageStateTreeTaskInstanceData, ComputedDuration) == 0x8, "Offset mismatch for FPlayMontageStateTreeTaskInstanceData::ComputedDuration");
static_assert(offsetof(FPlayMontageStateTreeTaskInstanceData, time) == 0xc, "Offset mismatch for FPlayMontageStateTreeTaskInstanceData::time");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FPlayMontageStateTreeTask : FGameplayInteractionStateTreeTask
{
    UAnimMontage* Montage; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FPlayMontageStateTreeTask) == 0x28, "Size mismatch for FPlayMontageStateTreeTask");
static_assert(offsetof(FPlayMontageStateTreeTask, Montage) == 0x20, "Offset mismatch for FPlayMontageStateTreeTask::Montage");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FStateTreeTask_FindSlotEntranceLocation_InstanceData
{
    AActor* UserActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FSmartObjectSlotHandle ReferenceSlot; // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform EntryTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FGameplayTagContainer EntranceTags; // 0x80 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FStateTreeTask_FindSlotEntranceLocation_InstanceData) == 0xa0, "Size mismatch for FStateTreeTask_FindSlotEntranceLocation_InstanceData");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation_InstanceData, UserActor) == 0x0, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation_InstanceData::UserActor");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation_InstanceData, ReferenceSlot) == 0x8, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation_InstanceData::ReferenceSlot");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation_InstanceData, EntryTransform) == 0x20, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation_InstanceData::EntryTransform");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation_InstanceData, EntranceTags) == 0x80, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation_InstanceData::EntranceTags");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
struct FStateTreeTask_FindSlotEntranceLocation : FGameplayInteractionStateTreeTask
{
    uint8_t SelectMethod; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bProjectNavigationLocation; // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bTraceGroundLocation; // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bCheckTransitionTrajectory; // 0x23 (Size: 0x1, Type: BoolProperty)
    bool bCheckEntranceLocationOverlap; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bCheckSlotLocationOverlap; // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bUseUpAxisLockedRotation; // 0x26 (Size: 0x1, Type: BoolProperty)
    bool bUseSlotLocationAsFallbackCandidate; // 0x27 (Size: 0x1, Type: BoolProperty)
    uint8_t LocationType; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UClass* ValidationFilter; // 0x30 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FStateTreeTask_FindSlotEntranceLocation) == 0x40, "Size mismatch for FStateTreeTask_FindSlotEntranceLocation");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, SelectMethod) == 0x20, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::SelectMethod");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bProjectNavigationLocation) == 0x21, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bProjectNavigationLocation");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bTraceGroundLocation) == 0x22, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bTraceGroundLocation");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bCheckTransitionTrajectory) == 0x23, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bCheckTransitionTrajectory");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bCheckEntranceLocationOverlap) == 0x24, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bCheckEntranceLocationOverlap");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bCheckSlotLocationOverlap) == 0x25, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bCheckSlotLocationOverlap");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bUseUpAxisLockedRotation) == 0x26, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bUseUpAxisLockedRotation");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, bUseSlotLocationAsFallbackCandidate) == 0x27, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::bUseSlotLocationAsFallbackCandidate");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, LocationType) == 0x28, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::LocationType");
static_assert(offsetof(FStateTreeTask_FindSlotEntranceLocation, ValidationFilter) == 0x30, "Offset mismatch for FStateTreeTask_FindSlotEntranceLocation::ValidationFilter");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FStateTreeTask_GetSlotEntranceTags_InstanceData
{
    FSmartObjectSlotEntranceHandle SlotEntranceHandle; // 0x0 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer EntranceTags; // 0x18 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FStateTreeTask_GetSlotEntranceTags_InstanceData) == 0x38, "Size mismatch for FStateTreeTask_GetSlotEntranceTags_InstanceData");
static_assert(offsetof(FStateTreeTask_GetSlotEntranceTags_InstanceData, SlotEntranceHandle) == 0x0, "Offset mismatch for FStateTreeTask_GetSlotEntranceTags_InstanceData::SlotEntranceHandle");
static_assert(offsetof(FStateTreeTask_GetSlotEntranceTags_InstanceData, EntranceTags) == 0x18, "Offset mismatch for FStateTreeTask_GetSlotEntranceTags_InstanceData::EntranceTags");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FStateTreeTask_GetSlotEntranceTags : FGameplayInteractionStateTreeTask
{
};

static_assert(sizeof(FStateTreeTask_GetSlotEntranceTags) == 0x28, "Size mismatch for FStateTreeTask_GetSlotEntranceTags");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FStateTreeTask_PlayContextualAnim : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FStateTreeTask_PlayContextualAnim) == 0x20, "Size mismatch for FStateTreeTask_PlayContextualAnim");

