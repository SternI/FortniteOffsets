/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioSynesthesia
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "AudioAnalyzer.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UAudioSynesthesiaSettings : public UAudioAnalyzerSettings
{
public:
};

static_assert(sizeof(UAudioSynesthesiaSettings) == 0x28, "Size mismatch for UAudioSynesthesiaSettings");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UAudioSynesthesiaNRTSettings : public UAudioAnalyzerNRTSettings
{
public:
};

static_assert(sizeof(UAudioSynesthesiaNRTSettings) == 0x28, "Size mismatch for UAudioSynesthesiaNRTSettings");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UAudioSynesthesiaNRT : public UAudioAnalyzerNRT
{
public:
};

static_assert(sizeof(UAudioSynesthesiaNRT) == 0x78, "Size mismatch for UAudioSynesthesiaNRT");

// Size: 0x48 (Inherited: 0xa0, Single: 0xffffffa8)
class UConstantQSettings : public UAudioSynesthesiaSettings
{
public:
    float StartingFrequencyHz; // 0x28 (Size: 0x4, Type: FloatProperty)
    int32_t NumBands; // 0x2c (Size: 0x4, Type: IntProperty)
    float NumBandsPerOctave; // 0x30 (Size: 0x4, Type: FloatProperty)
    float AnalysisPeriodInSeconds; // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bDownmixToMono; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t FFTSize; // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t WindowType; // 0x3a (Size: 0x1, Type: EnumProperty)
    uint8_t SpectrumType; // 0x3b (Size: 0x1, Type: EnumProperty)
    float BandWidthStretch; // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t CQTNormalization; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x3]; // 0x41 (Size: 0x3, Type: PaddingProperty)
    float NoiseFloorDb; // 0x44 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UConstantQSettings) == 0x48, "Size mismatch for UConstantQSettings");
static_assert(offsetof(UConstantQSettings, StartingFrequencyHz) == 0x28, "Offset mismatch for UConstantQSettings::StartingFrequencyHz");
static_assert(offsetof(UConstantQSettings, NumBands) == 0x2c, "Offset mismatch for UConstantQSettings::NumBands");
static_assert(offsetof(UConstantQSettings, NumBandsPerOctave) == 0x30, "Offset mismatch for UConstantQSettings::NumBandsPerOctave");
static_assert(offsetof(UConstantQSettings, AnalysisPeriodInSeconds) == 0x34, "Offset mismatch for UConstantQSettings::AnalysisPeriodInSeconds");
static_assert(offsetof(UConstantQSettings, bDownmixToMono) == 0x38, "Offset mismatch for UConstantQSettings::bDownmixToMono");
static_assert(offsetof(UConstantQSettings, FFTSize) == 0x39, "Offset mismatch for UConstantQSettings::FFTSize");
static_assert(offsetof(UConstantQSettings, WindowType) == 0x3a, "Offset mismatch for UConstantQSettings::WindowType");
static_assert(offsetof(UConstantQSettings, SpectrumType) == 0x3b, "Offset mismatch for UConstantQSettings::SpectrumType");
static_assert(offsetof(UConstantQSettings, BandWidthStretch) == 0x3c, "Offset mismatch for UConstantQSettings::BandWidthStretch");
static_assert(offsetof(UConstantQSettings, CQTNormalization) == 0x40, "Offset mismatch for UConstantQSettings::CQTNormalization");
static_assert(offsetof(UConstantQSettings, NoiseFloorDb) == 0x44, "Offset mismatch for UConstantQSettings::NoiseFloorDb");

// Size: 0xf8 (Inherited: 0xc8, Single: 0x30)
class UConstantQAnalyzer : public UAudioAnalyzer
{
public:
    UConstantQSettings* Settings; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnConstantQResults[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnLatestConstantQResults[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_e0[0x18]; // 0xe0 (Size: 0x18, Type: PaddingProperty)

public:
    void GetCenterFrequencies(TArray<float>& OutCenterFrequencies); // 0xfd5d064 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    int32_t GetNumCenterFrequencies() const; // 0xfd5f2ac (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UConstantQAnalyzer) == 0xf8, "Size mismatch for UConstantQAnalyzer");
static_assert(offsetof(UConstantQAnalyzer, Settings) == 0xa0, "Offset mismatch for UConstantQAnalyzer::Settings");
static_assert(offsetof(UConstantQAnalyzer, OnConstantQResults) == 0xa8, "Offset mismatch for UConstantQAnalyzer::OnConstantQResults");
static_assert(offsetof(UConstantQAnalyzer, OnLatestConstantQResults) == 0xd0, "Offset mismatch for UConstantQAnalyzer::OnLatestConstantQResults");

// Size: 0x48 (Inherited: 0xa0, Single: 0xffffffa8)
class UConstantQNRTSettings : public UAudioSynesthesiaNRTSettings
{
public:
    float StartingFrequency; // 0x28 (Size: 0x4, Type: FloatProperty)
    int32_t NumBands; // 0x2c (Size: 0x4, Type: IntProperty)
    float NumBandsPerOctave; // 0x30 (Size: 0x4, Type: FloatProperty)
    float AnalysisPeriod; // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bDownmixToMono; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t FFTSize; // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t WindowType; // 0x3a (Size: 0x1, Type: EnumProperty)
    uint8_t SpectrumType; // 0x3b (Size: 0x1, Type: EnumProperty)
    float BandWidthStretch; // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t CQTNormalization; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x3]; // 0x41 (Size: 0x3, Type: PaddingProperty)
    float NoiseFloorDb; // 0x44 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UConstantQNRTSettings) == 0x48, "Size mismatch for UConstantQNRTSettings");
static_assert(offsetof(UConstantQNRTSettings, StartingFrequency) == 0x28, "Offset mismatch for UConstantQNRTSettings::StartingFrequency");
static_assert(offsetof(UConstantQNRTSettings, NumBands) == 0x2c, "Offset mismatch for UConstantQNRTSettings::NumBands");
static_assert(offsetof(UConstantQNRTSettings, NumBandsPerOctave) == 0x30, "Offset mismatch for UConstantQNRTSettings::NumBandsPerOctave");
static_assert(offsetof(UConstantQNRTSettings, AnalysisPeriod) == 0x34, "Offset mismatch for UConstantQNRTSettings::AnalysisPeriod");
static_assert(offsetof(UConstantQNRTSettings, bDownmixToMono) == 0x38, "Offset mismatch for UConstantQNRTSettings::bDownmixToMono");
static_assert(offsetof(UConstantQNRTSettings, FFTSize) == 0x39, "Offset mismatch for UConstantQNRTSettings::FFTSize");
static_assert(offsetof(UConstantQNRTSettings, WindowType) == 0x3a, "Offset mismatch for UConstantQNRTSettings::WindowType");
static_assert(offsetof(UConstantQNRTSettings, SpectrumType) == 0x3b, "Offset mismatch for UConstantQNRTSettings::SpectrumType");
static_assert(offsetof(UConstantQNRTSettings, BandWidthStretch) == 0x3c, "Offset mismatch for UConstantQNRTSettings::BandWidthStretch");
static_assert(offsetof(UConstantQNRTSettings, CQTNormalization) == 0x40, "Offset mismatch for UConstantQNRTSettings::CQTNormalization");
static_assert(offsetof(UConstantQNRTSettings, NoiseFloorDb) == 0x44, "Offset mismatch for UConstantQNRTSettings::NoiseFloorDb");

// Size: 0x80 (Inherited: 0x140, Single: 0xffffff40)
class UConstantQNRT : public UAudioSynesthesiaNRT
{
public:
    UConstantQNRTSettings* Settings; // 0x78 (Size: 0x8, Type: ObjectProperty)

public:
    void GetChannelConstantQAtTime(float& const InSeconds, int32_t& const InChannel, TArray<float>& OutConstantQ) const; // 0xfd5d664 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetNormalizedChannelConstantQAtTime(float& const InSeconds, int32_t& const InChannel, TArray<float>& OutConstantQ) const; // 0xfd5e488 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UConstantQNRT) == 0x80, "Size mismatch for UConstantQNRT");
static_assert(offsetof(UConstantQNRT, Settings) == 0x78, "Offset mismatch for UConstantQNRT::Settings");

// Size: 0x40 (Inherited: 0xa0, Single: 0xffffffa0)
class ULoudnessSettings : public UAudioSynesthesiaSettings
{
public:
    float AnalysisPeriod; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumFrequency; // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumFrequency; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t CurveType; // 0x34 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
    float NoiseFloorDb; // 0x38 (Size: 0x4, Type: FloatProperty)
    float ExpectedMaxLoudness; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(ULoudnessSettings) == 0x40, "Size mismatch for ULoudnessSettings");
static_assert(offsetof(ULoudnessSettings, AnalysisPeriod) == 0x28, "Offset mismatch for ULoudnessSettings::AnalysisPeriod");
static_assert(offsetof(ULoudnessSettings, MinimumFrequency) == 0x2c, "Offset mismatch for ULoudnessSettings::MinimumFrequency");
static_assert(offsetof(ULoudnessSettings, MaximumFrequency) == 0x30, "Offset mismatch for ULoudnessSettings::MaximumFrequency");
static_assert(offsetof(ULoudnessSettings, CurveType) == 0x34, "Offset mismatch for ULoudnessSettings::CurveType");
static_assert(offsetof(ULoudnessSettings, NoiseFloorDb) == 0x38, "Offset mismatch for ULoudnessSettings::NoiseFloorDb");
static_assert(offsetof(ULoudnessSettings, ExpectedMaxLoudness) == 0x3c, "Offset mismatch for ULoudnessSettings::ExpectedMaxLoudness");

// Size: 0xe8 (Inherited: 0xc8, Single: 0x20)
class ULoudnessAnalyzer : public UAudioAnalyzer
{
public:
    ULoudnessSettings* Settings; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnOverallLoudnessResults[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPerChannelLoudnessResults[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLatestOverallLoudnessResults[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLatestPerChannelLoudnessResults[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
};

static_assert(sizeof(ULoudnessAnalyzer) == 0xe8, "Size mismatch for ULoudnessAnalyzer");
static_assert(offsetof(ULoudnessAnalyzer, Settings) == 0xa0, "Offset mismatch for ULoudnessAnalyzer::Settings");
static_assert(offsetof(ULoudnessAnalyzer, OnOverallLoudnessResults) == 0xa8, "Offset mismatch for ULoudnessAnalyzer::OnOverallLoudnessResults");
static_assert(offsetof(ULoudnessAnalyzer, OnPerChannelLoudnessResults) == 0xb8, "Offset mismatch for ULoudnessAnalyzer::OnPerChannelLoudnessResults");
static_assert(offsetof(ULoudnessAnalyzer, OnLatestOverallLoudnessResults) == 0xc8, "Offset mismatch for ULoudnessAnalyzer::OnLatestOverallLoudnessResults");
static_assert(offsetof(ULoudnessAnalyzer, OnLatestPerChannelLoudnessResults) == 0xd8, "Offset mismatch for ULoudnessAnalyzer::OnLatestPerChannelLoudnessResults");

// Size: 0x40 (Inherited: 0xa0, Single: 0xffffffa0)
class ULoudnessNRTSettings : public UAudioSynesthesiaNRTSettings
{
public:
    float AnalysisPeriod; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumFrequency; // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumFrequency; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t CurveType; // 0x34 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
    float NoiseFloorDb; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(ULoudnessNRTSettings) == 0x40, "Size mismatch for ULoudnessNRTSettings");
static_assert(offsetof(ULoudnessNRTSettings, AnalysisPeriod) == 0x28, "Offset mismatch for ULoudnessNRTSettings::AnalysisPeriod");
static_assert(offsetof(ULoudnessNRTSettings, MinimumFrequency) == 0x2c, "Offset mismatch for ULoudnessNRTSettings::MinimumFrequency");
static_assert(offsetof(ULoudnessNRTSettings, MaximumFrequency) == 0x30, "Offset mismatch for ULoudnessNRTSettings::MaximumFrequency");
static_assert(offsetof(ULoudnessNRTSettings, CurveType) == 0x34, "Offset mismatch for ULoudnessNRTSettings::CurveType");
static_assert(offsetof(ULoudnessNRTSettings, NoiseFloorDb) == 0x38, "Offset mismatch for ULoudnessNRTSettings::NoiseFloorDb");

// Size: 0x80 (Inherited: 0x140, Single: 0xffffff40)
class ULoudnessNRT : public UAudioSynesthesiaNRT
{
public:
    ULoudnessNRTSettings* Settings; // 0x78 (Size: 0x8, Type: ObjectProperty)

public:
    void GetChannelLoudnessAtTime(float& const InSeconds, int32_t& const InChannel, float& OutLoudness) const; // 0xfd5dab8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetLoudnessAtTime(float& const InSeconds, float& OutLoudness) const; // 0xfd5e2c4 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetNormalizedChannelLoudnessAtTime(float& const InSeconds, int32_t& const InChannel, float& OutLoudness) const; // 0xfd5e8dc (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetNormalizedLoudnessAtTime(float& const InSeconds, float& OutLoudness) const; // 0xfd5f0e8 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ULoudnessNRT) == 0x80, "Size mismatch for ULoudnessNRT");
static_assert(offsetof(ULoudnessNRT, Settings) == 0x78, "Offset mismatch for ULoudnessNRT::Settings");

// Size: 0x40 (Inherited: 0xa0, Single: 0xffffffa0)
class UMeterSettings : public UAudioSynesthesiaSettings
{
public:
    float AnalysisPeriod; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t PeakMode; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    int32_t MeterAttackTime; // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t MeterReleaseTime; // 0x34 (Size: 0x4, Type: IntProperty)
    int32_t PeakHoldTime; // 0x38 (Size: 0x4, Type: IntProperty)
    float ClippingThreshold; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UMeterSettings) == 0x40, "Size mismatch for UMeterSettings");
static_assert(offsetof(UMeterSettings, AnalysisPeriod) == 0x28, "Offset mismatch for UMeterSettings::AnalysisPeriod");
static_assert(offsetof(UMeterSettings, PeakMode) == 0x2c, "Offset mismatch for UMeterSettings::PeakMode");
static_assert(offsetof(UMeterSettings, MeterAttackTime) == 0x30, "Offset mismatch for UMeterSettings::MeterAttackTime");
static_assert(offsetof(UMeterSettings, MeterReleaseTime) == 0x34, "Offset mismatch for UMeterSettings::MeterReleaseTime");
static_assert(offsetof(UMeterSettings, PeakHoldTime) == 0x38, "Offset mismatch for UMeterSettings::PeakHoldTime");
static_assert(offsetof(UMeterSettings, ClippingThreshold) == 0x3c, "Offset mismatch for UMeterSettings::ClippingThreshold");

// Size: 0x148 (Inherited: 0xc8, Single: 0x80)
class UMeterAnalyzer : public UAudioAnalyzer
{
public:
    UMeterSettings* Settings; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnOverallMeterResults[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnPerChannelMeterResults[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_e0[0x18]; // 0xe0 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnLatestOverallMeterResults[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_108[0x18]; // 0x108 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnLatestPerChannelMeterResults[0x10]; // 0x120 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_130[0x18]; // 0x130 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UMeterAnalyzer) == 0x148, "Size mismatch for UMeterAnalyzer");
static_assert(offsetof(UMeterAnalyzer, Settings) == 0xa0, "Offset mismatch for UMeterAnalyzer::Settings");
static_assert(offsetof(UMeterAnalyzer, OnOverallMeterResults) == 0xa8, "Offset mismatch for UMeterAnalyzer::OnOverallMeterResults");
static_assert(offsetof(UMeterAnalyzer, OnPerChannelMeterResults) == 0xd0, "Offset mismatch for UMeterAnalyzer::OnPerChannelMeterResults");
static_assert(offsetof(UMeterAnalyzer, OnLatestOverallMeterResults) == 0xf8, "Offset mismatch for UMeterAnalyzer::OnLatestOverallMeterResults");
static_assert(offsetof(UMeterAnalyzer, OnLatestPerChannelMeterResults) == 0x120, "Offset mismatch for UMeterAnalyzer::OnLatestPerChannelMeterResults");

// Size: 0x40 (Inherited: 0xa0, Single: 0xffffffa0)
class UOnsetNRTSettings : public UAudioSynesthesiaNRTSettings
{
public:
    bool bDownmixToMono; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float GranularityInSeconds; // 0x2c (Size: 0x4, Type: FloatProperty)
    float Sensitivity; // 0x30 (Size: 0x4, Type: FloatProperty)
    float MinimumFrequency; // 0x34 (Size: 0x4, Type: FloatProperty)
    float MaximumFrequency; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UOnsetNRTSettings) == 0x40, "Size mismatch for UOnsetNRTSettings");
static_assert(offsetof(UOnsetNRTSettings, bDownmixToMono) == 0x28, "Offset mismatch for UOnsetNRTSettings::bDownmixToMono");
static_assert(offsetof(UOnsetNRTSettings, GranularityInSeconds) == 0x2c, "Offset mismatch for UOnsetNRTSettings::GranularityInSeconds");
static_assert(offsetof(UOnsetNRTSettings, Sensitivity) == 0x30, "Offset mismatch for UOnsetNRTSettings::Sensitivity");
static_assert(offsetof(UOnsetNRTSettings, MinimumFrequency) == 0x34, "Offset mismatch for UOnsetNRTSettings::MinimumFrequency");
static_assert(offsetof(UOnsetNRTSettings, MaximumFrequency) == 0x38, "Offset mismatch for UOnsetNRTSettings::MaximumFrequency");

// Size: 0x80 (Inherited: 0x140, Single: 0xffffff40)
class UOnsetNRT : public UAudioSynesthesiaNRT
{
public:
    UOnsetNRTSettings* Settings; // 0x78 (Size: 0x8, Type: ObjectProperty)

public:
    void GetChannelOnsetsBetweenTimes(float& const InStartSeconds, float& const InEndSeconds, int32_t& const InChannel, TArray<float>& OutOnsetTimestamps, TArray<float>& OutOnsetStrengths) const; // 0xfd5dd58 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetNormalizedChannelOnsetsBetweenTimes(float& const InStartSeconds, float& const InEndSeconds, int32_t& const InChannel, TArray<float>& OutOnsetTimestamps, TArray<float>& OutOnsetStrengths) const; // 0xfd5eb7c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UOnsetNRT) == 0x80, "Size mismatch for UOnsetNRT");
static_assert(offsetof(UOnsetNRT, Settings) == 0x78, "Offset mismatch for UOnsetNRT::Settings");

// Size: 0x30 (Inherited: 0xa0, Single: 0xffffff90)
class USynesthesiaSpectrumAnalysisSettings : public UAudioSynesthesiaSettings
{
public:
    float AnalysisPeriod; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t FFTSize; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t SpectrumType; // 0x2d (Size: 0x1, Type: EnumProperty)
    uint8_t WindowType; // 0x2e (Size: 0x1, Type: EnumProperty)
    bool bDownmixToMono; // 0x2f (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(USynesthesiaSpectrumAnalysisSettings) == 0x30, "Size mismatch for USynesthesiaSpectrumAnalysisSettings");
static_assert(offsetof(USynesthesiaSpectrumAnalysisSettings, AnalysisPeriod) == 0x28, "Offset mismatch for USynesthesiaSpectrumAnalysisSettings::AnalysisPeriod");
static_assert(offsetof(USynesthesiaSpectrumAnalysisSettings, FFTSize) == 0x2c, "Offset mismatch for USynesthesiaSpectrumAnalysisSettings::FFTSize");
static_assert(offsetof(USynesthesiaSpectrumAnalysisSettings, SpectrumType) == 0x2d, "Offset mismatch for USynesthesiaSpectrumAnalysisSettings::SpectrumType");
static_assert(offsetof(USynesthesiaSpectrumAnalysisSettings, WindowType) == 0x2e, "Offset mismatch for USynesthesiaSpectrumAnalysisSettings::WindowType");
static_assert(offsetof(USynesthesiaSpectrumAnalysisSettings, bDownmixToMono) == 0x2f, "Offset mismatch for USynesthesiaSpectrumAnalysisSettings::bDownmixToMono");

// Size: 0xf8 (Inherited: 0xc8, Single: 0x30)
class USynesthesiaSpectrumAnalyzer : public UAudioAnalyzer
{
public:
    USynesthesiaSpectrumAnalysisSettings* Settings; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnSpectrumResults[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnLatestSpectrumResults[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_e0[0x18]; // 0xe0 (Size: 0x18, Type: PaddingProperty)

public:
    void GetCenterFrequencies(float& const InSampleRate, TArray<float>& OutCenterFrequencies); // 0xfd5d2f0 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    int32_t GetNumCenterFrequencies() const; // 0xfd5f2c8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(USynesthesiaSpectrumAnalyzer) == 0xf8, "Size mismatch for USynesthesiaSpectrumAnalyzer");
static_assert(offsetof(USynesthesiaSpectrumAnalyzer, Settings) == 0xa0, "Offset mismatch for USynesthesiaSpectrumAnalyzer::Settings");
static_assert(offsetof(USynesthesiaSpectrumAnalyzer, OnSpectrumResults) == 0xa8, "Offset mismatch for USynesthesiaSpectrumAnalyzer::OnSpectrumResults");
static_assert(offsetof(USynesthesiaSpectrumAnalyzer, OnLatestSpectrumResults) == 0xd0, "Offset mismatch for USynesthesiaSpectrumAnalyzer::OnLatestSpectrumResults");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FConstantQResults
{
    float TimeSeconds; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<float> SpectrumValues; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FConstantQResults) == 0x18, "Size mismatch for FConstantQResults");
static_assert(offsetof(FConstantQResults, TimeSeconds) == 0x0, "Offset mismatch for FConstantQResults::TimeSeconds");
static_assert(offsetof(FConstantQResults, SpectrumValues) == 0x8, "Offset mismatch for FConstantQResults::SpectrumValues");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FLoudnessResults
{
    float Loudness; // 0x0 (Size: 0x4, Type: FloatProperty)
    float NormalizedLoudness; // 0x4 (Size: 0x4, Type: FloatProperty)
    float PerceptualEnergy; // 0x8 (Size: 0x4, Type: FloatProperty)
    float TimeSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FLoudnessResults) == 0x10, "Size mismatch for FLoudnessResults");
static_assert(offsetof(FLoudnessResults, Loudness) == 0x0, "Offset mismatch for FLoudnessResults::Loudness");
static_assert(offsetof(FLoudnessResults, NormalizedLoudness) == 0x4, "Offset mismatch for FLoudnessResults::NormalizedLoudness");
static_assert(offsetof(FLoudnessResults, PerceptualEnergy) == 0x8, "Offset mismatch for FLoudnessResults::PerceptualEnergy");
static_assert(offsetof(FLoudnessResults, TimeSeconds) == 0xc, "Offset mismatch for FLoudnessResults::TimeSeconds");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FMeterResults
{
    float TimeSeconds; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MeterValue; // 0x4 (Size: 0x4, Type: FloatProperty)
    float PeakValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t NumSamplesClipping; // 0xc (Size: 0x4, Type: IntProperty)
    float ClippingValue; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FMeterResults) == 0x14, "Size mismatch for FMeterResults");
static_assert(offsetof(FMeterResults, TimeSeconds) == 0x0, "Offset mismatch for FMeterResults::TimeSeconds");
static_assert(offsetof(FMeterResults, MeterValue) == 0x4, "Offset mismatch for FMeterResults::MeterValue");
static_assert(offsetof(FMeterResults, PeakValue) == 0x8, "Offset mismatch for FMeterResults::PeakValue");
static_assert(offsetof(FMeterResults, NumSamplesClipping) == 0xc, "Offset mismatch for FMeterResults::NumSamplesClipping");
static_assert(offsetof(FMeterResults, ClippingValue) == 0x10, "Offset mismatch for FMeterResults::ClippingValue");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FSynesthesiaSpectrumResults
{
    float TimeSeconds; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<float> SpectrumValues; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSynesthesiaSpectrumResults) == 0x18, "Size mismatch for FSynesthesiaSpectrumResults");
static_assert(offsetof(FSynesthesiaSpectrumResults, TimeSeconds) == 0x0, "Offset mismatch for FSynesthesiaSpectrumResults::TimeSeconds");
static_assert(offsetof(FSynesthesiaSpectrumResults, SpectrumValues) == 0x8, "Offset mismatch for FSynesthesiaSpectrumResults::SpectrumValues");

