/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarDiorama
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "CinematicCamera.h"
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "MovieScene.h"
#include "DelMarCore.h"
#include "GameplayTags.h"
#include "LevelSequence.h"

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class ADelMarCockpitActor : public AActor
{
public:
    USkeletalMeshComponent* CockpitMeshComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* BoundVehicle; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BP_OnBoundVehicleChanged(ADelMarVehicle*& const NewVehicle); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ADelMarCockpitActor) == 0x2b8, "Size mismatch for ADelMarCockpitActor");
static_assert(offsetof(ADelMarCockpitActor, CockpitMeshComponent) == 0x2a8, "Offset mismatch for ADelMarCockpitActor::CockpitMeshComponent");
static_assert(offsetof(ADelMarCockpitActor, BoundVehicle) == 0x2b0, "Offset mismatch for ADelMarCockpitActor::BoundVehicle");

// Size: 0x400 (Inherited: 0x2d0, Single: 0x130)
class ADelMarDioramaActor : public AActor
{
public:
    USkeletalMeshComponent* VehicleInteriorMeshComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TMap<FDelMarDriverSequenceDataList, FGameplayTag> CustomSequenceListTable; // 0x2b0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_300[0x18]; // 0x300 (Size: 0x18, Type: PaddingProperty)
    UClass* DriverMannequinClass; // 0x318 (Size: 0x8, Type: ClassProperty)
    UClass* LevelSequenceActorClass; // 0x320 (Size: 0x8, Type: ClassProperty)
    UClass* CineCameraClass; // 0x328 (Size: 0x8, Type: ClassProperty)
    UClass* CockpitClass; // 0x330 (Size: 0x8, Type: ClassProperty)
    UDelMarDioramaConfigData* ConfigData; // 0x338 (Size: 0x8, Type: ObjectProperty)
    FVector DefaultCameraOffset; // 0x340 (Size: 0x18, Type: StructProperty)
    FRotator DefaultCameraRotation; // 0x358 (Size: 0x18, Type: StructProperty)
    ALevelSequenceActor* SequenceActor; // 0x370 (Size: 0x8, Type: ObjectProperty)
    ADelMarDriverCameraActor* CameraActor; // 0x378 (Size: 0x8, Type: ObjectProperty)
    ADelMarDriverMannequin* DriverMannequin; // 0x380 (Size: 0x8, Type: ObjectProperty)
    ADelMarCockpitActor* CockpitActor; // 0x388 (Size: 0x8, Type: ObjectProperty)
    APlayerState* BoundPlayer; // 0x390 (Size: 0x8, Type: ObjectProperty)
    UDelMarDriverSequenceData* LastPlayedSequenceData; // 0x398 (Size: 0x8, Type: ObjectProperty)
    TSet<UDelMarDriverSequenceDataTable*> BoundSequencesTables; // 0x3a0 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_3f0[0x4]; // 0x3f0 (Size: 0x4, Type: PaddingProperty)
    int32_t DefaultCameraSocketIndex; // 0x3f4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3f8[0x8]; // 0x3f8 (Size: 0x8, Type: PaddingProperty)

protected:
    void HandleSequenceFinished(); // 0x11d3e3c8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarDioramaActor) == 0x400, "Size mismatch for ADelMarDioramaActor");
static_assert(offsetof(ADelMarDioramaActor, VehicleInteriorMeshComponent) == 0x2a8, "Offset mismatch for ADelMarDioramaActor::VehicleInteriorMeshComponent");
static_assert(offsetof(ADelMarDioramaActor, CustomSequenceListTable) == 0x2b0, "Offset mismatch for ADelMarDioramaActor::CustomSequenceListTable");
static_assert(offsetof(ADelMarDioramaActor, DriverMannequinClass) == 0x318, "Offset mismatch for ADelMarDioramaActor::DriverMannequinClass");
static_assert(offsetof(ADelMarDioramaActor, LevelSequenceActorClass) == 0x320, "Offset mismatch for ADelMarDioramaActor::LevelSequenceActorClass");
static_assert(offsetof(ADelMarDioramaActor, CineCameraClass) == 0x328, "Offset mismatch for ADelMarDioramaActor::CineCameraClass");
static_assert(offsetof(ADelMarDioramaActor, CockpitClass) == 0x330, "Offset mismatch for ADelMarDioramaActor::CockpitClass");
static_assert(offsetof(ADelMarDioramaActor, ConfigData) == 0x338, "Offset mismatch for ADelMarDioramaActor::ConfigData");
static_assert(offsetof(ADelMarDioramaActor, DefaultCameraOffset) == 0x340, "Offset mismatch for ADelMarDioramaActor::DefaultCameraOffset");
static_assert(offsetof(ADelMarDioramaActor, DefaultCameraRotation) == 0x358, "Offset mismatch for ADelMarDioramaActor::DefaultCameraRotation");
static_assert(offsetof(ADelMarDioramaActor, SequenceActor) == 0x370, "Offset mismatch for ADelMarDioramaActor::SequenceActor");
static_assert(offsetof(ADelMarDioramaActor, CameraActor) == 0x378, "Offset mismatch for ADelMarDioramaActor::CameraActor");
static_assert(offsetof(ADelMarDioramaActor, DriverMannequin) == 0x380, "Offset mismatch for ADelMarDioramaActor::DriverMannequin");
static_assert(offsetof(ADelMarDioramaActor, CockpitActor) == 0x388, "Offset mismatch for ADelMarDioramaActor::CockpitActor");
static_assert(offsetof(ADelMarDioramaActor, BoundPlayer) == 0x390, "Offset mismatch for ADelMarDioramaActor::BoundPlayer");
static_assert(offsetof(ADelMarDioramaActor, LastPlayedSequenceData) == 0x398, "Offset mismatch for ADelMarDioramaActor::LastPlayedSequenceData");
static_assert(offsetof(ADelMarDioramaActor, BoundSequencesTables) == 0x3a0, "Offset mismatch for ADelMarDioramaActor::BoundSequencesTables");
static_assert(offsetof(ADelMarDioramaActor, DefaultCameraSocketIndex) == 0x3f4, "Offset mismatch for ADelMarDioramaActor::DefaultCameraSocketIndex");

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
class UDelMarDioramaConfigData : public UDataAsset
{
public:
    FName CameraActorTag; // 0x30 (Size: 0x4, Type: NameProperty)
    FName DriverMannequinTag; // 0x34 (Size: 0x4, Type: NameProperty)
    FName CockpitActorTag; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    TArray<FName> CockpitCameraCutSockets; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FName CockpitCameraIdleSocket; // 0x50 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarDioramaConfigData) == 0x58, "Size mismatch for UDelMarDioramaConfigData");
static_assert(offsetof(UDelMarDioramaConfigData, CameraActorTag) == 0x30, "Offset mismatch for UDelMarDioramaConfigData::CameraActorTag");
static_assert(offsetof(UDelMarDioramaConfigData, DriverMannequinTag) == 0x34, "Offset mismatch for UDelMarDioramaConfigData::DriverMannequinTag");
static_assert(offsetof(UDelMarDioramaConfigData, CockpitActorTag) == 0x38, "Offset mismatch for UDelMarDioramaConfigData::CockpitActorTag");
static_assert(offsetof(UDelMarDioramaConfigData, CockpitCameraCutSockets) == 0x40, "Offset mismatch for UDelMarDioramaConfigData::CockpitCameraCutSockets");
static_assert(offsetof(UDelMarDioramaConfigData, CockpitCameraIdleSocket) == 0x50, "Offset mismatch for UDelMarDioramaConfigData::CockpitCameraIdleSocket");

// Size: 0xab0 (Inherited: 0x17a0, Single: 0xfffff310)
class ADelMarDriverCameraActor : public ACineCameraActor
{
public:
    USceneCaptureComponent2D* CaptureComponent; // 0xaa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_aa8[0x8]; // 0xaa8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarDriverCameraActor) == 0xab0, "Size mismatch for ADelMarDriverCameraActor");
static_assert(offsetof(ADelMarDriverCameraActor, CaptureComponent) == 0xaa0, "Offset mismatch for ADelMarDriverCameraActor::CaptureComponent");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDelMarDriverCheatManager : public UChildCheatManager
{
public:

protected:
    void DelMarDioramaOpenChannel(bool& bOpened); // 0x9e6e1b8 (Index: 0x0, Flags: Final|Exec|Native|Protected)
    void DelMarDioramaSetDriverReaction(FString& ReactionTag); // 0xa63baa0 (Index: 0x1, Flags: Final|Exec|Native|Protected)
    void DelMarDioramaSetEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x2, Flags: Final|Exec|Native|Protected)
    void DelMarDioramaSetLightingChannel(bool& bMainChannel); // 0x9e6e1b8 (Index: 0x3, Flags: Final|Exec|Native|Protected)
    void DelMarDioramaSetLocation(float& X, float& Y, float& Z); // 0xd7dfbe0 (Index: 0x4, Flags: Final|Exec|Native|Protected)
    void DelMarDioramaSetVisibleInSceneCaptureOnly(bool& bOnly); // 0x9e6e1b8 (Index: 0x5, Flags: Final|Exec|Native|Protected)
    void DelMarIntercomBroadcastEmote(FString& EmoteTag); // 0xa63baa0 (Index: 0x6, Flags: Final|Exec|Native|Protected)
    void DelMarIntercomPlayInteraction(FString& InteractionTag); // 0xa63baa0 (Index: 0x7, Flags: Final|Exec|Native|Protected)
};

static_assert(sizeof(UDelMarDriverCheatManager) == 0x28, "Size mismatch for UDelMarDriverCheatManager");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UDelMarDriverSequenceData : public UDataAsset
{
public:
    ULevelSequence* Sequence; // 0x30 (Size: 0x8, Type: ObjectProperty)
    int32_t PriorityLevel; // 0x38 (Size: 0x4, Type: IntProperty)
    bool bLoop; // 0x3c (Size: 0x1, Type: BoolProperty)
    bool bTriggerReactiveWidget; // 0x3d (Size: 0x1, Type: BoolProperty)
    bool bCameraCut; // 0x3e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3f[0x1]; // 0x3f (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarDriverSequenceData) == 0x40, "Size mismatch for UDelMarDriverSequenceData");
static_assert(offsetof(UDelMarDriverSequenceData, Sequence) == 0x30, "Offset mismatch for UDelMarDriverSequenceData::Sequence");
static_assert(offsetof(UDelMarDriverSequenceData, PriorityLevel) == 0x38, "Offset mismatch for UDelMarDriverSequenceData::PriorityLevel");
static_assert(offsetof(UDelMarDriverSequenceData, bLoop) == 0x3c, "Offset mismatch for UDelMarDriverSequenceData::bLoop");
static_assert(offsetof(UDelMarDriverSequenceData, bTriggerReactiveWidget) == 0x3d, "Offset mismatch for UDelMarDriverSequenceData::bTriggerReactiveWidget");
static_assert(offsetof(UDelMarDriverSequenceData, bCameraCut) == 0x3e, "Offset mismatch for UDelMarDriverSequenceData::bCameraCut");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UDelMarDriverSequenceDataTable : public UDataAsset
{
public:
    TMap<FDelMarDriverSequenceDataList, FGameplayTag> SequenceListTable; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarDriverSequenceDataTable) == 0x80, "Size mismatch for UDelMarDriverSequenceDataTable");
static_assert(offsetof(UDelMarDriverSequenceDataTable, SequenceListTable) == 0x30, "Offset mismatch for UDelMarDriverSequenceDataTable::SequenceListTable");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UDelMarIntercomEvent : public UObject
{
public:
    AFortPlayerState* OwningPlayerState; // 0x28 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* OwningVehicle; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UDelMarIntercomComponent* IntercomComponent; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarIntercomEvent) == 0x40, "Size mismatch for UDelMarIntercomEvent");
static_assert(offsetof(UDelMarIntercomEvent, OwningPlayerState) == 0x28, "Offset mismatch for UDelMarIntercomEvent::OwningPlayerState");
static_assert(offsetof(UDelMarIntercomEvent, OwningVehicle) == 0x30, "Offset mismatch for UDelMarIntercomEvent::OwningVehicle");
static_assert(offsetof(UDelMarIntercomEvent, IntercomComponent) == 0x38, "Offset mismatch for UDelMarIntercomEvent::IntercomComponent");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class UDelMarIntercomEvent_TurboPassing : public UDelMarIntercomEvent
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerAhead; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarPlayerRaceDataComponent* RaceData; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarIntercomEvent_TurboPassing) == 0x50, "Size mismatch for UDelMarIntercomEvent_TurboPassing");
static_assert(offsetof(UDelMarIntercomEvent_TurboPassing, PlayerAhead) == 0x40, "Offset mismatch for UDelMarIntercomEvent_TurboPassing::PlayerAhead");
static_assert(offsetof(UDelMarIntercomEvent_TurboPassing, RaceData) == 0x48, "Offset mismatch for UDelMarIntercomEvent_TurboPassing::RaceData");

// Size: 0x500 (Inherited: 0xdc8, Single: 0xfffff738)
class UDelMarCockpitAnimInstance : public UDelMarDriverAnimInstance
{
public:
    float DefaultCameraShakeIntensity; // 0x4e8 (Size: 0x4, Type: FloatProperty)
    float DefaultTerrainAccMultiplier; // 0x4ec (Size: 0x4, Type: FloatProperty)
    float DefaultTerrainMaxForwardSpeedPercentage; // 0x4f0 (Size: 0x4, Type: FloatProperty)
    float CameraShakeIntensity; // 0x4f4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4f8[0x8]; // 0x4f8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarCockpitAnimInstance) == 0x500, "Size mismatch for UDelMarCockpitAnimInstance");
static_assert(offsetof(UDelMarCockpitAnimInstance, DefaultCameraShakeIntensity) == 0x4e8, "Offset mismatch for UDelMarCockpitAnimInstance::DefaultCameraShakeIntensity");
static_assert(offsetof(UDelMarCockpitAnimInstance, DefaultTerrainAccMultiplier) == 0x4ec, "Offset mismatch for UDelMarCockpitAnimInstance::DefaultTerrainAccMultiplier");
static_assert(offsetof(UDelMarCockpitAnimInstance, DefaultTerrainMaxForwardSpeedPercentage) == 0x4f0, "Offset mismatch for UDelMarCockpitAnimInstance::DefaultTerrainMaxForwardSpeedPercentage");
static_assert(offsetof(UDelMarCockpitAnimInstance, CameraShakeIntensity) == 0x4f4, "Offset mismatch for UDelMarCockpitAnimInstance::CameraShakeIntensity");

// Size: 0x4f0 (Inherited: 0x8d8, Single: 0xfffffc18)
class UDelMarDriverAnimInstance : public UFortBaseAnimInstance
{
public:
    ADelMarVehicle* BoundVehicle; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    bool bDrifting; // 0x4d0 (Size: 0x1, Type: BoolProperty)
    bool bTurboing; // 0x4d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d2[0x2]; // 0x4d2 (Size: 0x2, Type: PaddingProperty)
    float SteeringAngle; // 0x4d4 (Size: 0x4, Type: FloatProperty)
    float SlipAngle; // 0x4d8 (Size: 0x4, Type: FloatProperty)
    float StableSpeed; // 0x4dc (Size: 0x4, Type: FloatProperty)
    float DrivingSpeedThreshold; // 0x4e0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4e4[0xc]; // 0x4e4 (Size: 0xc, Type: PaddingProperty)

protected:
    bool IsDrivingSpeed() const; // 0x11d3f34c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarDriverAnimInstance) == 0x4f0, "Size mismatch for UDelMarDriverAnimInstance");
static_assert(offsetof(UDelMarDriverAnimInstance, BoundVehicle) == 0x4c8, "Offset mismatch for UDelMarDriverAnimInstance::BoundVehicle");
static_assert(offsetof(UDelMarDriverAnimInstance, bDrifting) == 0x4d0, "Offset mismatch for UDelMarDriverAnimInstance::bDrifting");
static_assert(offsetof(UDelMarDriverAnimInstance, bTurboing) == 0x4d1, "Offset mismatch for UDelMarDriverAnimInstance::bTurboing");
static_assert(offsetof(UDelMarDriverAnimInstance, SteeringAngle) == 0x4d4, "Offset mismatch for UDelMarDriverAnimInstance::SteeringAngle");
static_assert(offsetof(UDelMarDriverAnimInstance, SlipAngle) == 0x4d8, "Offset mismatch for UDelMarDriverAnimInstance::SlipAngle");
static_assert(offsetof(UDelMarDriverAnimInstance, StableSpeed) == 0x4dc, "Offset mismatch for UDelMarDriverAnimInstance::StableSpeed");
static_assert(offsetof(UDelMarDriverAnimInstance, DrivingSpeedThreshold) == 0x4e0, "Offset mismatch for UDelMarDriverAnimInstance::DrivingSpeedThreshold");

// Size: 0x1e0 (Inherited: 0x250, Single: 0xffffff90)
class UDelMarDioramaControllerComponent : public UControllerComponent
{
public:
    FVector DioramaOffset; // 0xb8 (Size: 0x18, Type: StructProperty)
    UClass* DioramaClass; // 0xd0 (Size: 0x8, Type: ClassProperty)
    UDelMarDriverSequenceDataTable* CustomizedSequencesTable; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    FTransform DioramaInitialTransform; // 0xe0 (Size: 0x60, Type: StructProperty)
    UClass* MainChannelClass; // 0x140 (Size: 0x8, Type: ClassProperty)
    UDelMarDriverChannel* MainChannel; // 0x148 (Size: 0x8, Type: ObjectProperty)
    UClass* PostRaceChannelClass; // 0x150 (Size: 0x8, Type: ClassProperty)
    TArray<UDelMarDriverChannelBase*> PostRaceChannels; // 0x158 (Size: 0x10, Type: ArrayProperty)
    APlayerState* CachedOwningPlayerState; // 0x168 (Size: 0x8, Type: ObjectProperty)
    APlayerState* ViewTargetPlayer; // 0x170 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> ViewTargetVehicle; // 0x178 (Size: 0x8, Type: WeakObjectProperty)
    TMap<ADelMarDioramaActor*, APlayerState*> PlayerDioramaTable; // 0x180 (Size: 0x50, Type: MapProperty)
    int32_t NumPostRaceChannel; // 0x1d0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1d4[0xc]; // 0x1d4 (Size: 0xc, Type: PaddingProperty)

protected:
    void HandleViewTargetChanged(AFortPlayerController*& PC, AActor*& Old, AActor*& NewViewTarget); // 0x11d3ed48 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarDioramaControllerComponent) == 0x1e0, "Size mismatch for UDelMarDioramaControllerComponent");
static_assert(offsetof(UDelMarDioramaControllerComponent, DioramaOffset) == 0xb8, "Offset mismatch for UDelMarDioramaControllerComponent::DioramaOffset");
static_assert(offsetof(UDelMarDioramaControllerComponent, DioramaClass) == 0xd0, "Offset mismatch for UDelMarDioramaControllerComponent::DioramaClass");
static_assert(offsetof(UDelMarDioramaControllerComponent, CustomizedSequencesTable) == 0xd8, "Offset mismatch for UDelMarDioramaControllerComponent::CustomizedSequencesTable");
static_assert(offsetof(UDelMarDioramaControllerComponent, DioramaInitialTransform) == 0xe0, "Offset mismatch for UDelMarDioramaControllerComponent::DioramaInitialTransform");
static_assert(offsetof(UDelMarDioramaControllerComponent, MainChannelClass) == 0x140, "Offset mismatch for UDelMarDioramaControllerComponent::MainChannelClass");
static_assert(offsetof(UDelMarDioramaControllerComponent, MainChannel) == 0x148, "Offset mismatch for UDelMarDioramaControllerComponent::MainChannel");
static_assert(offsetof(UDelMarDioramaControllerComponent, PostRaceChannelClass) == 0x150, "Offset mismatch for UDelMarDioramaControllerComponent::PostRaceChannelClass");
static_assert(offsetof(UDelMarDioramaControllerComponent, PostRaceChannels) == 0x158, "Offset mismatch for UDelMarDioramaControllerComponent::PostRaceChannels");
static_assert(offsetof(UDelMarDioramaControllerComponent, CachedOwningPlayerState) == 0x168, "Offset mismatch for UDelMarDioramaControllerComponent::CachedOwningPlayerState");
static_assert(offsetof(UDelMarDioramaControllerComponent, ViewTargetPlayer) == 0x170, "Offset mismatch for UDelMarDioramaControllerComponent::ViewTargetPlayer");
static_assert(offsetof(UDelMarDioramaControllerComponent, ViewTargetVehicle) == 0x178, "Offset mismatch for UDelMarDioramaControllerComponent::ViewTargetVehicle");
static_assert(offsetof(UDelMarDioramaControllerComponent, PlayerDioramaTable) == 0x180, "Offset mismatch for UDelMarDioramaControllerComponent::PlayerDioramaTable");
static_assert(offsetof(UDelMarDioramaControllerComponent, NumPostRaceChannel) == 0x1d0, "Offset mismatch for UDelMarDioramaControllerComponent::NumPostRaceChannel");

// Size: 0x160 (Inherited: 0xb0, Single: 0xb0)
class UDelMarDriverChannel : public UDelMarDriverChannelBase
{
public:
    ADelMarVehicle* ViewVehicle; // 0x88 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayTag> QueueReactions; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TMap<FDelMarDriverSequenceDataList, FGameplayTag> SequenceListTableInstance; // 0xa0 (Size: 0x50, Type: MapProperty)
    TMap<float, FGameplayTag> ReactionCoolDownTimeStamp; // 0xf0 (Size: 0x50, Type: MapProperty)
    float LandingForceThreshold; // 0x140 (Size: 0x4, Type: FloatProperty)
    float SlowDownImpactSpeedThreshold; // 0x144 (Size: 0x4, Type: FloatProperty)
    float HitWallImpactThreshold; // 0x148 (Size: 0x4, Type: FloatProperty)
    float HitWallImpactHardThreshold; // 0x14c (Size: 0x4, Type: FloatProperty)
    float DraftBonusPercentageThreshold; // 0x150 (Size: 0x4, Type: FloatProperty)
    float StartlineBoostPercentageEarnedThreshold; // 0x154 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)

protected:
    void HandleDraftStateChanged(EDelmarDraftingState& DraftState); // 0x11d3e15c (Index: 0x0, Flags: Final|Native|Protected)
    void HandleDriftBoostActivated(float& PercentageMaxBoostGained); // 0x11d3e288 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleHazardSpeedLost(); // 0x11d3e3b4 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleSpeedChanged(float& NewSpeed); // 0x11d3e3dc (Index: 0x3, Flags: Final|Native|Protected)
    void HandleStartlineBoostActivated(float& PercentageSpeedEarned); // 0x11d3e508 (Index: 0x4, Flags: Final|Native|Protected)
    void HandleTurboActivated(); // 0x11d3e634 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11d3e648 (Index: 0x6, Flags: Final|Native|Protected)
    void HandleVehicleHitWall(float& ImpactMagnitude, FVector& WorldLocation, float& ForwardRotationDegrees); // 0x11d3e708 (Index: 0x7, Flags: Final|Native|Protected|HasDefaults)
    void HandleVehicleLanded(float& LandingForce, bool& bLandedKickflip); // 0x11d3e920 (Index: 0x8, Flags: Final|Native|Protected)
    void HandleVehicleSpawned(bool& bFirstCar, bool& bPrevCarDemolished); // 0x11d3eb2c (Index: 0x9, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarDriverChannel) == 0x160, "Size mismatch for UDelMarDriverChannel");
static_assert(offsetof(UDelMarDriverChannel, ViewVehicle) == 0x88, "Offset mismatch for UDelMarDriverChannel::ViewVehicle");
static_assert(offsetof(UDelMarDriverChannel, QueueReactions) == 0x90, "Offset mismatch for UDelMarDriverChannel::QueueReactions");
static_assert(offsetof(UDelMarDriverChannel, SequenceListTableInstance) == 0xa0, "Offset mismatch for UDelMarDriverChannel::SequenceListTableInstance");
static_assert(offsetof(UDelMarDriverChannel, ReactionCoolDownTimeStamp) == 0xf0, "Offset mismatch for UDelMarDriverChannel::ReactionCoolDownTimeStamp");
static_assert(offsetof(UDelMarDriverChannel, LandingForceThreshold) == 0x140, "Offset mismatch for UDelMarDriverChannel::LandingForceThreshold");
static_assert(offsetof(UDelMarDriverChannel, SlowDownImpactSpeedThreshold) == 0x144, "Offset mismatch for UDelMarDriverChannel::SlowDownImpactSpeedThreshold");
static_assert(offsetof(UDelMarDriverChannel, HitWallImpactThreshold) == 0x148, "Offset mismatch for UDelMarDriverChannel::HitWallImpactThreshold");
static_assert(offsetof(UDelMarDriverChannel, HitWallImpactHardThreshold) == 0x14c, "Offset mismatch for UDelMarDriverChannel::HitWallImpactHardThreshold");
static_assert(offsetof(UDelMarDriverChannel, DraftBonusPercentageThreshold) == 0x150, "Offset mismatch for UDelMarDriverChannel::DraftBonusPercentageThreshold");
static_assert(offsetof(UDelMarDriverChannel, StartlineBoostPercentageEarnedThreshold) == 0x154, "Offset mismatch for UDelMarDriverChannel::StartlineBoostPercentageEarnedThreshold");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UDelMarDriverChannelBase : public UObject
{
public:
    UTextureRenderTarget2D* ViewRenderTarget; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FIntPoint RenderTargetDim; // 0x30 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_38[0x30]; // 0x38 (Size: 0x30, Type: PaddingProperty)
    UDelMarDriverSequenceDataTable* SequencesTable; // 0x68 (Size: 0x8, Type: ObjectProperty)
    APlayerState* ViewPlayer; // 0x70 (Size: 0x8, Type: ObjectProperty)
    ADelMarDioramaActor* ViewDiorama; // 0x78 (Size: 0x8, Type: ObjectProperty)
    UMovieSceneSequencePlayer* SequencePlayer; // 0x80 (Size: 0x8, Type: ObjectProperty)

protected:
    void HandleSequenceFinished(); // 0x31f3198 (Index: 0x0, Flags: Native|Protected)
};

static_assert(sizeof(UDelMarDriverChannelBase) == 0x88, "Size mismatch for UDelMarDriverChannelBase");
static_assert(offsetof(UDelMarDriverChannelBase, ViewRenderTarget) == 0x28, "Offset mismatch for UDelMarDriverChannelBase::ViewRenderTarget");
static_assert(offsetof(UDelMarDriverChannelBase, RenderTargetDim) == 0x30, "Offset mismatch for UDelMarDriverChannelBase::RenderTargetDim");
static_assert(offsetof(UDelMarDriverChannelBase, SequencesTable) == 0x68, "Offset mismatch for UDelMarDriverChannelBase::SequencesTable");
static_assert(offsetof(UDelMarDriverChannelBase, ViewPlayer) == 0x70, "Offset mismatch for UDelMarDriverChannelBase::ViewPlayer");
static_assert(offsetof(UDelMarDriverChannelBase, ViewDiorama) == 0x78, "Offset mismatch for UDelMarDriverChannelBase::ViewDiorama");
static_assert(offsetof(UDelMarDriverChannelBase, SequencePlayer) == 0x80, "Offset mismatch for UDelMarDriverChannelBase::SequencePlayer");

// Size: 0x6b8 (Inherited: 0xcb0, Single: 0xfffffa08)
class ADelMarDriverMannequin : public AFortPlayerMannequin
{
public:
};

static_assert(sizeof(ADelMarDriverMannequin) == 0x6b8, "Size mismatch for ADelMarDriverMannequin");

// Size: 0x178 (Inherited: 0x250, Single: 0xffffff28)
class UDelMarIntercomComponent : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    UClass* GuestChannelClass; // 0xd0 (Size: 0x8, Type: ClassProperty)
    UDelMarDriverChannel* GuestChannel; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> ViewPlayerPawn; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarDioramaActor*> MainChannelDiorama; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    APlayerState* ViewPlayerState; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UDelMarDioramaControllerComponent* DioramaControllerComponent; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> ServerEventClasses; // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarIntercomEvent*> ServerEvents; // 0x110 (Size: 0x10, Type: ArrayProperty)
    TMap<FDelMarInteractionTagData, FGameplayTag> InteractionTagTable; // 0x120 (Size: 0x50, Type: MapProperty)
    float EmoteBroadcastMaxDistanceSq; // 0x170 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_174[0x4]; // 0x174 (Size: 0x4, Type: PaddingProperty)

public:
    virtual void ServerReceiveInteraction(FGameplayTag& const EmoteTag, APlayerState*& const Receiver); // 0x11d3f438 (Index: 0x4, Flags: Net|Native|Event|Public|NetServer)

protected:
    virtual void ClientReceiveEmote(FGameplayTag& const EmoteTag, APlayerState*& Instigator); // 0x11d3de7c (Index: 0x0, Flags: Net|Native|Event|Protected|NetClient)
    virtual void ClientReceiveInteraction(FGameplayTag& const InteractionTag, APlayerState*& const Instigator, APlayerState*& const Receiver); // 0x11d3dfb8 (Index: 0x1, Flags: Net|Native|Event|Protected|NetClient)
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11d3f068 (Index: 0x2, Flags: Final|Native|Protected)
    virtual void ServerReceiveEmote(FGameplayTag& const EmoteTag); // 0x11d3f370 (Index: 0x3, Flags: Net|Native|Event|Protected|NetServer)
};

static_assert(sizeof(UDelMarIntercomComponent) == 0x178, "Size mismatch for UDelMarIntercomComponent");
static_assert(offsetof(UDelMarIntercomComponent, GuestChannelClass) == 0xd0, "Offset mismatch for UDelMarIntercomComponent::GuestChannelClass");
static_assert(offsetof(UDelMarIntercomComponent, GuestChannel) == 0xd8, "Offset mismatch for UDelMarIntercomComponent::GuestChannel");
static_assert(offsetof(UDelMarIntercomComponent, ViewPlayerPawn) == 0xe0, "Offset mismatch for UDelMarIntercomComponent::ViewPlayerPawn");
static_assert(offsetof(UDelMarIntercomComponent, MainChannelDiorama) == 0xe8, "Offset mismatch for UDelMarIntercomComponent::MainChannelDiorama");
static_assert(offsetof(UDelMarIntercomComponent, ViewPlayerState) == 0xf0, "Offset mismatch for UDelMarIntercomComponent::ViewPlayerState");
static_assert(offsetof(UDelMarIntercomComponent, DioramaControllerComponent) == 0xf8, "Offset mismatch for UDelMarIntercomComponent::DioramaControllerComponent");
static_assert(offsetof(UDelMarIntercomComponent, ServerEventClasses) == 0x100, "Offset mismatch for UDelMarIntercomComponent::ServerEventClasses");
static_assert(offsetof(UDelMarIntercomComponent, ServerEvents) == 0x110, "Offset mismatch for UDelMarIntercomComponent::ServerEvents");
static_assert(offsetof(UDelMarIntercomComponent, InteractionTagTable) == 0x120, "Offset mismatch for UDelMarIntercomComponent::InteractionTagTable");
static_assert(offsetof(UDelMarIntercomComponent, EmoteBroadcastMaxDistanceSq) == 0x170, "Offset mismatch for UDelMarIntercomComponent::EmoteBroadcastMaxDistanceSq");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarDriverSequenceDataList
{
    TArray<UDelMarDriverSequenceData*> SequenceDataList; // 0x0 (Size: 0x10, Type: ArrayProperty)
    float Cooldown; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarDriverSequenceDataList) == 0x18, "Size mismatch for FDelMarDriverSequenceDataList");
static_assert(offsetof(FDelMarDriverSequenceDataList, SequenceDataList) == 0x0, "Offset mismatch for FDelMarDriverSequenceDataList::SequenceDataList");
static_assert(offsetof(FDelMarDriverSequenceDataList, Cooldown) == 0x10, "Offset mismatch for FDelMarDriverSequenceDataList::Cooldown");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_DioramaControllerAdded
{
};

static_assert(sizeof(FDelMarEvent_DioramaControllerAdded) == 0x8, "Size mismatch for FDelMarEvent_DioramaControllerAdded");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_DriverChannelOpened
{
};

static_assert(sizeof(FDelMarEvent_DriverChannelOpened) == 0x8, "Size mismatch for FDelMarEvent_DriverChannelOpened");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarInteractionTagData
{
    FGameplayTag InstigatorReactionTag; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ReceiverReactionTag; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarInteractionTagData) == 0x8, "Size mismatch for FDelMarInteractionTagData");
static_assert(offsetof(FDelMarInteractionTagData, InstigatorReactionTag) == 0x0, "Offset mismatch for FDelMarInteractionTagData::InstigatorReactionTag");
static_assert(offsetof(FDelMarInteractionTagData, ReceiverReactionTag) == 0x4, "Offset mismatch for FDelMarInteractionTagData::ReceiverReactionTag");

