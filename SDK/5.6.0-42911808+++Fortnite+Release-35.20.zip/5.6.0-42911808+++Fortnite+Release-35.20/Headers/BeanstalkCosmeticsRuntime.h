/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkCosmeticsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0xe0 (Inherited: 0x50, Single: 0x90)
class UBeanCosmeticItemDefinitionBase : public UFortCosmeticItemAdditionalData
{
public:
    TSoftObjectPtr<UTexture2D*> Body_Pattern; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    int32_t BodyFaceplateColorIndex; // 0x48 (Size: 0x4, Type: IntProperty)
    int32_t BodyFaceplateMaterialTypeIndex; // 0x4c (Size: 0x4, Type: IntProperty)
    int32_t BodyEyesColorIndex; // 0x50 (Size: 0x4, Type: IntProperty)
    int32_t BodyEyesMaterialTypeIndex; // 0x54 (Size: 0x4, Type: IntProperty)
    bool bEyelashes; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x3]; // 0x59 (Size: 0x3, Type: PaddingProperty)
    int32_t EyelashesColorIndex; // 0x5c (Size: 0x4, Type: IntProperty)
    int32_t EyelashesMaterialTypeIndex; // 0x60 (Size: 0x4, Type: IntProperty)
    bool bGlasses; // 0x64 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_65[0x3]; // 0x65 (Size: 0x3, Type: PaddingProperty)
    int32_t GlassesFrameColorIndex; // 0x68 (Size: 0x4, Type: IntProperty)
    int32_t GlassesFrameMaterialTypeIndex; // 0x6c (Size: 0x4, Type: IntProperty)
    bool bGlassesLenses; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    int32_t GlassesLensesColorIndex; // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t GlassesLensesMaterialTypeIndex; // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeMainColorIndex; // 0x7c (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeMainMaterialTypeIndex; // 0x80 (Size: 0x4, Type: IntProperty)
    bool bHeadCostumeMainClothingPattern; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    int32_t HeadCostumeSecondaryColorIndex; // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeSecondaryMaterialTypeIndex; // 0x8c (Size: 0x4, Type: IntProperty)
    bool bHeadCostumeSecondaryClothingPattern; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x3]; // 0x91 (Size: 0x3, Type: PaddingProperty)
    int32_t HeadCostumeAccentColorIndex; // 0x94 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumeAccentMaterialTypeIndex; // 0x98 (Size: 0x4, Type: IntProperty)
    bool bHeadCostumeAccentClothingPattern; // 0x9c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9d[0x3]; // 0x9d (Size: 0x3, Type: PaddingProperty)
    int32_t BodyMainColorIndex; // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t BodyMainMaterialTypeIndex; // 0xa4 (Size: 0x4, Type: IntProperty)
    int32_t BodySecondaryColorIndex; // 0xa8 (Size: 0x4, Type: IntProperty)
    int32_t BodySecondaryMaterialTypeIndex; // 0xac (Size: 0x4, Type: IntProperty)
    int32_t CostumePatternAtlasTextureSlot; // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t HeadCostumePatternAtlasTextureSlot; // 0xb4 (Size: 0x4, Type: IntProperty)
    int32_t CostumeMainColorIndex; // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t CostumeMainMaterialTypeIndex; // 0xbc (Size: 0x4, Type: IntProperty)
    bool bCostumeMainClothingPattern; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x3]; // 0xc1 (Size: 0x3, Type: PaddingProperty)
    int32_t CostumeSecondaryColorIndex; // 0xc4 (Size: 0x4, Type: IntProperty)
    int32_t CostumeSecondaryMaterialTypeIndex; // 0xc8 (Size: 0x4, Type: IntProperty)
    bool bCostumeSecondaryClothingPattern; // 0xcc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    int32_t CostumeAccentColorIndex; // 0xd0 (Size: 0x4, Type: IntProperty)
    int32_t CostumeAccentMaterialTypeIndex; // 0xd4 (Size: 0x4, Type: IntProperty)
    bool bCostumeAccentClothingPattern; // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d9[0x7]; // 0xd9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBeanCosmeticItemDefinitionBase) == 0xe0, "Size mismatch for UBeanCosmeticItemDefinitionBase");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, Body_Pattern) == 0x28, "Offset mismatch for UBeanCosmeticItemDefinitionBase::Body_Pattern");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodyFaceplateColorIndex) == 0x48, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodyFaceplateColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodyFaceplateMaterialTypeIndex) == 0x4c, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodyFaceplateMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodyEyesColorIndex) == 0x50, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodyEyesColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodyEyesMaterialTypeIndex) == 0x54, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodyEyesMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bEyelashes) == 0x58, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bEyelashes");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, EyelashesColorIndex) == 0x5c, "Offset mismatch for UBeanCosmeticItemDefinitionBase::EyelashesColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, EyelashesMaterialTypeIndex) == 0x60, "Offset mismatch for UBeanCosmeticItemDefinitionBase::EyelashesMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bGlasses) == 0x64, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bGlasses");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, GlassesFrameColorIndex) == 0x68, "Offset mismatch for UBeanCosmeticItemDefinitionBase::GlassesFrameColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, GlassesFrameMaterialTypeIndex) == 0x6c, "Offset mismatch for UBeanCosmeticItemDefinitionBase::GlassesFrameMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bGlassesLenses) == 0x70, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bGlassesLenses");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, GlassesLensesColorIndex) == 0x74, "Offset mismatch for UBeanCosmeticItemDefinitionBase::GlassesLensesColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, GlassesLensesMaterialTypeIndex) == 0x78, "Offset mismatch for UBeanCosmeticItemDefinitionBase::GlassesLensesMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumeMainColorIndex) == 0x7c, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumeMainColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumeMainMaterialTypeIndex) == 0x80, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumeMainMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bHeadCostumeMainClothingPattern) == 0x84, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bHeadCostumeMainClothingPattern");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumeSecondaryColorIndex) == 0x88, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumeSecondaryColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumeSecondaryMaterialTypeIndex) == 0x8c, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumeSecondaryMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bHeadCostumeSecondaryClothingPattern) == 0x90, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bHeadCostumeSecondaryClothingPattern");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumeAccentColorIndex) == 0x94, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumeAccentColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumeAccentMaterialTypeIndex) == 0x98, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumeAccentMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bHeadCostumeAccentClothingPattern) == 0x9c, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bHeadCostumeAccentClothingPattern");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodyMainColorIndex) == 0xa0, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodyMainColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodyMainMaterialTypeIndex) == 0xa4, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodyMainMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodySecondaryColorIndex) == 0xa8, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodySecondaryColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, BodySecondaryMaterialTypeIndex) == 0xac, "Offset mismatch for UBeanCosmeticItemDefinitionBase::BodySecondaryMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumePatternAtlasTextureSlot) == 0xb0, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumePatternAtlasTextureSlot");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, HeadCostumePatternAtlasTextureSlot) == 0xb4, "Offset mismatch for UBeanCosmeticItemDefinitionBase::HeadCostumePatternAtlasTextureSlot");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumeMainColorIndex) == 0xb8, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumeMainColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumeMainMaterialTypeIndex) == 0xbc, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumeMainMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bCostumeMainClothingPattern) == 0xc0, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bCostumeMainClothingPattern");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumeSecondaryColorIndex) == 0xc4, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumeSecondaryColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumeSecondaryMaterialTypeIndex) == 0xc8, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumeSecondaryMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bCostumeSecondaryClothingPattern) == 0xcc, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bCostumeSecondaryClothingPattern");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumeAccentColorIndex) == 0xd0, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumeAccentColorIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, CostumeAccentMaterialTypeIndex) == 0xd4, "Offset mismatch for UBeanCosmeticItemDefinitionBase::CostumeAccentMaterialTypeIndex");
static_assert(offsetof(UBeanCosmeticItemDefinitionBase, bCostumeAccentClothingPattern) == 0xd8, "Offset mismatch for UBeanCosmeticItemDefinitionBase::bCostumeAccentClothingPattern");

// Size: 0x60 (Inherited: 0x88, Single: 0xffffffd8)
class UBeanCosmeticsData : public UPrimaryDataAsset
{
public:
    UFortHeroType* HeroType; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UDataTable* CharacterCosmeticsMap; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UDataTable* EmoteLookupMap; // 0x40 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftObjectPtr<UAthenaCharacterItemDefinition*>> DefaultCharacterCosmetics; // 0x48 (Size: 0x10, Type: ArrayProperty)
    UFortItemDefinition* EmptyHandsPickaxeDef; // 0x58 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBeanCosmeticsData) == 0x60, "Size mismatch for UBeanCosmeticsData");
static_assert(offsetof(UBeanCosmeticsData, HeroType) == 0x30, "Offset mismatch for UBeanCosmeticsData::HeroType");
static_assert(offsetof(UBeanCosmeticsData, CharacterCosmeticsMap) == 0x38, "Offset mismatch for UBeanCosmeticsData::CharacterCosmeticsMap");
static_assert(offsetof(UBeanCosmeticsData, EmoteLookupMap) == 0x40, "Offset mismatch for UBeanCosmeticsData::EmoteLookupMap");
static_assert(offsetof(UBeanCosmeticsData, DefaultCharacterCosmetics) == 0x48, "Offset mismatch for UBeanCosmeticsData::DefaultCharacterCosmetics");
static_assert(offsetof(UBeanCosmeticsData, EmptyHandsPickaxeDef) == 0x58, "Offset mismatch for UBeanCosmeticsData::EmptyHandsPickaxeDef");

// Size: 0x6b8 (Inherited: 0xcb0, Single: 0xfffffa08)
class ABeanFortPlayerMannequin : public AFortPlayerMannequin
{
public:

protected:
    virtual void BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase*& const BeanCD, UMaterialInstanceDynamic*& MaterialBody, UMaterialInstanceDynamic*& MaterialCostume, UMaterialInstanceDynamic*& MaterialHead); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABeanFortPlayerMannequin) == 0x6b8, "Size mismatch for ABeanFortPlayerMannequin");

// Size: 0x398 (Inherited: 0xf30, Single: 0xfffff468)
class AFortAthenaMutator_BeanBRCosmeticsOverride : public AFortAthenaMutator_CosmeticLoadoutOverride
{
public:
    TSoftObjectPtr<UBeanCosmeticsData*> CosmeticsData; // 0x370 (Size: 0x20, Type: SoftObjectProperty)
    UBeanCosmeticsData* CosmeticsDataCache; // 0x390 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AFortAthenaMutator_BeanBRCosmeticsOverride) == 0x398, "Size mismatch for AFortAthenaMutator_BeanBRCosmeticsOverride");
static_assert(offsetof(AFortAthenaMutator_BeanBRCosmeticsOverride, CosmeticsData) == 0x370, "Offset mismatch for AFortAthenaMutator_BeanBRCosmeticsOverride::CosmeticsData");
static_assert(offsetof(AFortAthenaMutator_BeanBRCosmeticsOverride, CosmeticsDataCache) == 0x390, "Offset mismatch for AFortAthenaMutator_BeanBRCosmeticsOverride::CosmeticsDataCache");

// Size: 0xc8 (Inherited: 0xd8, Single: 0xfffffff0)
class UFortCosmeticStep_ApplyBeanCD : public UFortCosmeticStep
{
public:
    FGameplayTagQuery BeanPartQuery; // 0x80 (Size: 0x48, Type: StructProperty)

public:
    virtual void BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase*& const BeanCD, UMaterialInstanceDynamic*& MaterialBody, UMaterialInstanceDynamic*& MaterialCostume, UMaterialInstanceDynamic*& MaterialHead) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(UFortCosmeticStep_ApplyBeanCD) == 0xc8, "Size mismatch for UFortCosmeticStep_ApplyBeanCD");
static_assert(offsetof(UFortCosmeticStep_ApplyBeanCD, BeanPartQuery) == 0x80, "Offset mismatch for UFortCosmeticStep_ApplyBeanCD::BeanPartQuery");

// Size: 0x80 (Inherited: 0xd8, Single: 0xffffffa8)
class UFortCosmeticStep_BeanRemoveBackpack : public UFortCosmeticStep
{
public:
};

static_assert(sizeof(UFortCosmeticStep_BeanRemoveBackpack) == 0x80, "Size mismatch for UFortCosmeticStep_BeanRemoveBackpack");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FBeanCosmeticDataTableRow : FTableRowBase
{
    TSoftObjectPtr<UAthenaCharacterItemDefinition*> Definition; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FBeanCosmeticDataTableRow) == 0x28, "Size mismatch for FBeanCosmeticDataTableRow");
static_assert(offsetof(FBeanCosmeticDataTableRow, Definition) == 0x8, "Offset mismatch for FBeanCosmeticDataTableRow::Definition");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FBeanEmoteConversionRow : FTableRowBase
{
    TSoftObjectPtr<UAthenaDanceItemDefinition*> EmoteDefinition; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FBeanEmoteConversionRow) == 0x28, "Size mismatch for FBeanEmoteConversionRow");
static_assert(offsetof(FBeanEmoteConversionRow, EmoteDefinition) == 0x8, "Offset mismatch for FBeanEmoteConversionRow::EmoteDefinition");

