/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserBrowseView_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "UI.h"
#include "Engine.h"
#include "ActivityCategoryTilePanelBase.h"
#include "UMG.h"
#include "FortniteUI.h"
#include "SlateCore.h"
#include "ActivityCategoryTilePanelBase_VM.h"
#include "DiscoveryBrowserUI.h"
#include "UIKit.h"

// Size: 0x4ba (Inherited: 0xb38, Single: 0xfffff982)
class UActivityBrowserBrowseView_VM_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Throbber_C* WBP_UIKit_Throbber; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* WBP_BottomBarHack_BackToTop; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VerticalBox_Panels; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UActivityCategoryTilePanelBase_VM_C* TilePanel_Featured_VMversion; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UActivityCategoryTilePanelBase_VM_C* TilePanel_All_VMversion; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_HeaderSoftEdge; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ShiftToNextPanel; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_DisplayLoading; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverBrowseViewModel* FortDiscoverBrowseViewModel; // 0x458 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnPlayIntro[0x10]; // 0x460 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRowUpdated[0x10]; // 0x470 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double CategoryIndexAnimator; // 0x480 (Size: 0x8, Type: DoubleProperty)
    int32_t DesiredPanelIndex; // 0x488 (Size: 0x4, Type: IntProperty)
    int32_t LastDesiredPanelIndex; // 0x48c (Size: 0x4, Type: IntProperty)
    int32_t CurrentPanelIndex; // 0x490 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_494[0x4]; // 0x494 (Size: 0x4, Type: PaddingProperty)
    UActivityCategoryTilePanelBase_C* LastSelectedPanel; // 0x498 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EUMGSequencePlayMode> CurrentPlayDirection; // 0x4a0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4a1[0x7]; // 0x4a1 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnBackToTopClicked[0x10]; // 0x4a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t CurrentInputType; // 0x4b8 (Size: 0x1, Type: EnumProperty)
    bool IsClickedOnBottomPanel; // 0x4b9 (Size: 0x1, Type: BoolProperty)

public:
    void GetTilePanelFromIndex(int32_t& PanelIndex, UActivityCategoryTilePanelBase_C*& TilePanel) const; // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void GetLocalPanelPosition(int32_t& Index, double& Position); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void GetIndexOfPanel(UWidget*& const Widget, int32_t& Index); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void Destruct(); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x5, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void AnimateToDesiredPanel(int32_t& NewDesiredIndex); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void AnimatePanelOpacity(int32_t& AnimateAwayFromIndex, int32_t& AnimateToIndex); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Animate_to_Previous_Panel(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Animate_to_Next_Panel(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateMouseWheelForIndex(int32_t& PanelIndex, bool& bListenForInput); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchToGamepad(); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SnapToEndOfAnimation(UWidgetAnimation*& InAnimation, TEnumAsByte<EUMGSequencePlayMode>& PlayMode); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortDiscoverBrowseViewModel(UFortDiscoverBrowseViewModel*& ViewModel); // 0x288a61c (Index: 0xf, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetCurrentPanelIndex(int32_t& CurrentPanelIndex); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_ViewModel(UFortDiscoverBrowseViewModel*& In_Discover_Browse_VM); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Panel_Data(); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Featured_Categories_Panel_Display_Name(FText& In_Panel_Name); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Featured_Categories(TArray<UFortDiscoverTileItemVM*> In_Category_List); // 0x288a61c (Index: 0x14, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Set_All_Categories_Panel_Display_Name(FText& In_Panel_Name); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_All_Categories(TArray<UFortDiscoverTileItemVM*> In_Category_List); // 0x288a61c (Index: 0x16, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void PreUpdatePanelSize(); // 0x288a61c (Index: 0x17, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x18, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void PostUpdatePanelSize(); // 0x288a61c (Index: 0x19, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetCategoryIndexAnimator(double& NewValue); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnRowUpdated__DelegateSignature(bool& IsPromoted, bool& IsFirstRow); // 0x288a61c (Index: 0x1c, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnPlayIntro__DelegateSignature(); // 0x288a61c (Index: 0x1d, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual FEventReply OnMouseWheel(FGeometry& MyGeometry, const FPointerEvent MouseEvent); // 0x288a61c (Index: 0x1e, Flags: BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnBackToTopClicked__DelegateSignature(); // 0x288a61c (Index: 0x22, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    UWidget* NavFeaturedToAll(EUINavigation& Navigation); // 0x288a61c (Index: 0x23, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UWidget* NavAllToFeatured(EUINavigation& Navigation); // 0x288a61c (Index: 0x24, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void IsWidgetFullSizedAndOnScreen(UWidget*& Widget, bool& IsFullsized); // 0x288a61c (Index: 0x25, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserBrowseView_VM_C) == 0x4ba, "Size mismatch for UActivityBrowserBrowseView_VM_C");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, UberGraphFrame) == 0x408, "Offset mismatch for UActivityBrowserBrowseView_VM_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, WBP_UIKit_Throbber) == 0x410, "Offset mismatch for UActivityBrowserBrowseView_VM_C::WBP_UIKit_Throbber");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, WBP_BottomBarHack_BackToTop) == 0x418, "Offset mismatch for UActivityBrowserBrowseView_VM_C::WBP_BottomBarHack_BackToTop");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, VerticalBox_Panels) == 0x420, "Offset mismatch for UActivityBrowserBrowseView_VM_C::VerticalBox_Panels");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, TilePanel_Featured_VMversion) == 0x428, "Offset mismatch for UActivityBrowserBrowseView_VM_C::TilePanel_Featured_VMversion");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, TilePanel_All_VMversion) == 0x430, "Offset mismatch for UActivityBrowserBrowseView_VM_C::TilePanel_All_VMversion");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, Image_HeaderSoftEdge) == 0x438, "Offset mismatch for UActivityBrowserBrowseView_VM_C::Image_HeaderSoftEdge");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, ShiftToNextPanel) == 0x440, "Offset mismatch for UActivityBrowserBrowseView_VM_C::ShiftToNextPanel");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, Intro) == 0x448, "Offset mismatch for UActivityBrowserBrowseView_VM_C::Intro");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, Anim_DisplayLoading) == 0x450, "Offset mismatch for UActivityBrowserBrowseView_VM_C::Anim_DisplayLoading");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, FortDiscoverBrowseViewModel) == 0x458, "Offset mismatch for UActivityBrowserBrowseView_VM_C::FortDiscoverBrowseViewModel");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, OnPlayIntro) == 0x460, "Offset mismatch for UActivityBrowserBrowseView_VM_C::OnPlayIntro");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, OnRowUpdated) == 0x470, "Offset mismatch for UActivityBrowserBrowseView_VM_C::OnRowUpdated");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, CategoryIndexAnimator) == 0x480, "Offset mismatch for UActivityBrowserBrowseView_VM_C::CategoryIndexAnimator");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, DesiredPanelIndex) == 0x488, "Offset mismatch for UActivityBrowserBrowseView_VM_C::DesiredPanelIndex");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, LastDesiredPanelIndex) == 0x48c, "Offset mismatch for UActivityBrowserBrowseView_VM_C::LastDesiredPanelIndex");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, CurrentPanelIndex) == 0x490, "Offset mismatch for UActivityBrowserBrowseView_VM_C::CurrentPanelIndex");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, LastSelectedPanel) == 0x498, "Offset mismatch for UActivityBrowserBrowseView_VM_C::LastSelectedPanel");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, CurrentPlayDirection) == 0x4a0, "Offset mismatch for UActivityBrowserBrowseView_VM_C::CurrentPlayDirection");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, OnBackToTopClicked) == 0x4a8, "Offset mismatch for UActivityBrowserBrowseView_VM_C::OnBackToTopClicked");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, CurrentInputType) == 0x4b8, "Offset mismatch for UActivityBrowserBrowseView_VM_C::CurrentInputType");
static_assert(offsetof(UActivityBrowserBrowseView_VM_C, IsClickedOnBottomPanel) == 0x4b9, "Offset mismatch for UActivityBrowserBrowseView_VM_C::IsClickedOnBottomPanel");

