/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaReadyUpErrorsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "CommonUI.h"
#include "CoreUObject.h"

// Size: 0x130 (Inherited: 0x138, Single: 0xfffffff8)
class UDianaGeneralWarningUI : public UReadyUpErrorUI
{
public:
    TSoftClassPtr WarningModalClass; // 0x110 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UDianaGeneralWarningUI) == 0x130, "Size mismatch for UDianaGeneralWarningUI");
static_assert(offsetof(UDianaGeneralWarningUI, WarningModalClass) == 0x110, "Offset mismatch for UDianaGeneralWarningUI::WarningModalClass");

// Size: 0x448 (Inherited: 0xb38, Single: 0xfffff910)
class UDiana_ModeWarningPopupScreen : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x20]; // 0x408 (Size: 0x20, Type: PaddingProperty)
    FString StartDate; // 0x428 (Size: 0x10, Type: StrProperty)
    FString EndDate; // 0x438 (Size: 0x10, Type: StrProperty)

public:
    FDateTime GetEndDate() const; // 0x126c24a8 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FDateTime GetStartDate() const; // 0x126c24e4 (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)

protected:
    void HandleWarningAccepted(); // 0x126c2520 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleWarningDeclined(); // 0x126c2558 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDiana_ModeWarningPopupScreen) == 0x448, "Size mismatch for UDiana_ModeWarningPopupScreen");
static_assert(offsetof(UDiana_ModeWarningPopupScreen, StartDate) == 0x428, "Offset mismatch for UDiana_ModeWarningPopupScreen::StartDate");
static_assert(offsetof(UDiana_ModeWarningPopupScreen, EndDate) == 0x438, "Offset mismatch for UDiana_ModeWarningPopupScreen::EndDate");

