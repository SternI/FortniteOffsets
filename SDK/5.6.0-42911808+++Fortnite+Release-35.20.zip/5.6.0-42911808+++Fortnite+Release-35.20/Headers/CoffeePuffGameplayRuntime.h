/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoffeePuffGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x1350 (Inherited: 0x20a8, Single: 0xfffff2a8)
class UCoffeePuffLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    TSoftObjectPtr<UAnimMontage*> HookShotMontage; // 0x12f0 (Size: 0x20, Type: SoftObjectProperty)
    float EquipBlendOut; // 0x1310 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1314[0x4]; // 0x1314 (Size: 0x4, Type: PaddingProperty)
    double IdleAdditiveAlpha; // 0x1318 (Size: 0x8, Type: DoubleProperty)
    double HipOffsetVertical; // 0x1320 (Size: 0x8, Type: DoubleProperty)
    double LowerBodyAdditiveLoopSlopeDampFactor; // 0x1328 (Size: 0x8, Type: DoubleProperty)
    double CustomPelvisTwist; // 0x1330 (Size: 0x8, Type: DoubleProperty)
    bool bHookShot_PullFail; // 0x1338 (Size: 0x1, Type: BoolProperty)
    bool bHookShot_PullSuccess; // 0x1339 (Size: 0x1, Type: BoolProperty)
    bool bApplyLowerBodyCorrective; // 0x133a (Size: 0x1, Type: BoolProperty)
    bool bIsFiring; // 0x133b (Size: 0x1, Type: BoolProperty)
    bool bHookShot_Throw; // 0x133c (Size: 0x1, Type: BoolProperty)
    bool bHookShot_HitSuccess; // 0x133d (Size: 0x1, Type: BoolProperty)
    bool bAdditiveLoopBlend; // 0x133e (Size: 0x1, Type: BoolProperty)
    bool bEquipAdditiveToPassThrough; // 0x133f (Size: 0x1, Type: BoolProperty)
    bool bEquipAdditiveToCorrectiveAdditive; // 0x1340 (Size: 0x1, Type: BoolProperty)
    bool bPassThroughToEquipCorrective; // 0x1341 (Size: 0x1, Type: BoolProperty)
    bool bEquipCorrectiveToPassThrough; // 0x1342 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1343[0xd]; // 0x1343 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(UCoffeePuffLayerAnimInstance) == 0x1350, "Size mismatch for UCoffeePuffLayerAnimInstance");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, HookShotMontage) == 0x12f0, "Offset mismatch for UCoffeePuffLayerAnimInstance::HookShotMontage");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, EquipBlendOut) == 0x1310, "Offset mismatch for UCoffeePuffLayerAnimInstance::EquipBlendOut");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, IdleAdditiveAlpha) == 0x1318, "Offset mismatch for UCoffeePuffLayerAnimInstance::IdleAdditiveAlpha");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, HipOffsetVertical) == 0x1320, "Offset mismatch for UCoffeePuffLayerAnimInstance::HipOffsetVertical");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, LowerBodyAdditiveLoopSlopeDampFactor) == 0x1328, "Offset mismatch for UCoffeePuffLayerAnimInstance::LowerBodyAdditiveLoopSlopeDampFactor");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, CustomPelvisTwist) == 0x1330, "Offset mismatch for UCoffeePuffLayerAnimInstance::CustomPelvisTwist");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bHookShot_PullFail) == 0x1338, "Offset mismatch for UCoffeePuffLayerAnimInstance::bHookShot_PullFail");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bHookShot_PullSuccess) == 0x1339, "Offset mismatch for UCoffeePuffLayerAnimInstance::bHookShot_PullSuccess");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bApplyLowerBodyCorrective) == 0x133a, "Offset mismatch for UCoffeePuffLayerAnimInstance::bApplyLowerBodyCorrective");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bIsFiring) == 0x133b, "Offset mismatch for UCoffeePuffLayerAnimInstance::bIsFiring");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bHookShot_Throw) == 0x133c, "Offset mismatch for UCoffeePuffLayerAnimInstance::bHookShot_Throw");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bHookShot_HitSuccess) == 0x133d, "Offset mismatch for UCoffeePuffLayerAnimInstance::bHookShot_HitSuccess");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bAdditiveLoopBlend) == 0x133e, "Offset mismatch for UCoffeePuffLayerAnimInstance::bAdditiveLoopBlend");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bEquipAdditiveToPassThrough) == 0x133f, "Offset mismatch for UCoffeePuffLayerAnimInstance::bEquipAdditiveToPassThrough");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bEquipAdditiveToCorrectiveAdditive) == 0x1340, "Offset mismatch for UCoffeePuffLayerAnimInstance::bEquipAdditiveToCorrectiveAdditive");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bPassThroughToEquipCorrective) == 0x1341, "Offset mismatch for UCoffeePuffLayerAnimInstance::bPassThroughToEquipCorrective");
static_assert(offsetof(UCoffeePuffLayerAnimInstance, bEquipCorrectiveToPassThrough) == 0x1342, "Offset mismatch for UCoffeePuffLayerAnimInstance::bEquipCorrectiveToPassThrough");

// Size: 0x60 (Inherited: 0x68, Single: 0xfffffff8)
class UFortMovementMode_CoffeePuffPullRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
    TWeakObjectPtr<AActor*> NetPullingActor; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    bool bNetPullStarted; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    float LocalStartElapsedTime; // 0x4c (Size: 0x4, Type: FloatProperty)
    float LocalEndElapsedTime; // 0x50 (Size: 0x4, Type: FloatProperty)
    float LocalKnockbackSpeed; // 0x54 (Size: 0x4, Type: FloatProperty)
    float LocalInvalidPullStartTime; // 0x58 (Size: 0x4, Type: FloatProperty)
    bool bLocalLineOfSight; // 0x5c (Size: 0x1, Type: BoolProperty)
    bool bLocalMovementBlocked; // 0x5d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5e[0x2]; // 0x5e (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(UFortMovementMode_CoffeePuffPullRuntimeData) == 0x60, "Size mismatch for UFortMovementMode_CoffeePuffPullRuntimeData");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, NetPullingActor) == 0x40, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::NetPullingActor");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, bNetPullStarted) == 0x48, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::bNetPullStarted");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, LocalStartElapsedTime) == 0x4c, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::LocalStartElapsedTime");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, LocalEndElapsedTime) == 0x50, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::LocalEndElapsedTime");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, LocalKnockbackSpeed) == 0x54, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::LocalKnockbackSpeed");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, LocalInvalidPullStartTime) == 0x58, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::LocalInvalidPullStartTime");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, bLocalLineOfSight) == 0x5c, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::bLocalLineOfSight");
static_assert(offsetof(UFortMovementMode_CoffeePuffPullRuntimeData, bLocalMovementBlocked) == 0x5d, "Offset mismatch for UFortMovementMode_CoffeePuffPullRuntimeData::bLocalMovementBlocked");

// Size: 0x628 (Inherited: 0x210, Single: 0x418)
class UFortMovementMode_ExtCoffeePuffPull : public UFortMovementMode_BaseExtLogic
{
public:
    FFortCachedScalableFloat IgnorePendingLaunchForInitialDuration; // 0x1e8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackDuration; // 0x218 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackDistance; // 0x248 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PostKnockbackDelay; // 0x278 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackGravityMultiplier; // 0x2a8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackKickUpStrength; // 0x2d8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat KnockbackKickUpDuration; // 0x308 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullSpeed; // 0x338 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullTargetOffset; // 0x368 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat bForceOffsetDistance; // 0x398 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullTargetOffsetMargin; // 0x3c8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullMaxDuration; // 0x3f8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat PullMinDuration; // 0x428 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat MinImpactDotProduct; // 0x458 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat SurfaceSlideUnderOverForce; // 0x488 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat MaxInvalidPullTime; // 0x4b8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat InterruptClampedSpeed; // 0x4e8 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat LineOfSightDelay; // 0x518 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat bCheckLineOfSight; // 0x548 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat LineOfSightHeightOffset; // 0x578 (Size: 0x30, Type: StructProperty)
    FFortCachedScalableFloat DisconnectProtectionUpdateRate; // 0x5a8 (Size: 0x30, Type: StructProperty)
    FGameplayTag KnockbackEndEventTag; // 0x5d8 (Size: 0x4, Type: StructProperty)
    FGameplayTag PullStartEventTag; // 0x5dc (Size: 0x4, Type: StructProperty)
    FGameplayTag PullInvalidatedEventTag; // 0x5e0 (Size: 0x4, Type: StructProperty)
    FGameplayTag HookshotActiveTag; // 0x5e4 (Size: 0x4, Type: StructProperty)
    FCollisionProfileName LineOfSightCollisionProfile; // 0x5e8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_5ec[0x4]; // 0x5ec (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer LineOfSightIgnoreTags; // 0x5f0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_610[0x18]; // 0x610 (Size: 0x18, Type: PaddingProperty)

public:
    static UFortMovementMode_CoffeePuffPullRuntimeData* TryActivateCoffeePuffPullMME(AFortPawn*& const TargetPawn, UClass*& const MMEClass, const FFortMovementMode_CoffeePuffPullCreationData CreationData); // 0x1136325c (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)

protected:
    void ApplyGravityToVelocity(FVector& InOutVelocity) const; // 0x1136264c (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    virtual void BP_PhysicsUpdate(const FMMERuntimeContext RuntimeContext, const FVector InVelocity, const FVector InAcceleration, FVector& ResultVelocity, FVector& ResultAcceleration); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void BP_PhysUpdateHitResponse(const FMMERuntimeContext RuntimeContext, int32_t& const Iterations, const FVector InVelocity, const FVector OldPosition, const FVector Adjustement, FHitResult& Hit, float& const RemainingTime); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual EFortMovementModeExt_UpdateResult BP_UpdateBeforeCharacterMovement(const FMMERuntimeContext RuntimeContext); // 0x1136272c (Index: 0x3, Flags: Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual FVector GetKnockbackVelocity(UFortMovementMode_CoffeePuffPullRuntimeData*& const CoffeePuffPullRuntimeData, float& const ElapsedTime) const; // 0x11362818 (Index: 0x4, Flags: Native|Event|Protected|HasDefaults|BlueprintEvent|Const)
    FVector GetPullDirection(UFortMovementMode_CoffeePuffPullRuntimeData*& const CoffeePuffPullRuntimeData) const; // 0x11362a4c (Index: 0x5, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    virtual FVector GetPullVelocity(UFortMovementMode_CoffeePuffPullRuntimeData*& const CoffeePuffPullRuntimeData, float& const DeltaTime) const; // 0x11362f3c (Index: 0x6, Flags: Native|Event|Protected|HasDefaults|BlueprintEvent|Const)
    virtual bool IsPullValid(const FMMERuntimeContext RuntimeContext) const; // 0x11363170 (Index: 0x7, Flags: Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UFortMovementMode_ExtCoffeePuffPull) == 0x628, "Size mismatch for UFortMovementMode_ExtCoffeePuffPull");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, IgnorePendingLaunchForInitialDuration) == 0x1e8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::IgnorePendingLaunchForInitialDuration");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, KnockbackDuration) == 0x218, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::KnockbackDuration");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, KnockbackDistance) == 0x248, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::KnockbackDistance");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PostKnockbackDelay) == 0x278, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PostKnockbackDelay");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, KnockbackGravityMultiplier) == 0x2a8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::KnockbackGravityMultiplier");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, KnockbackKickUpStrength) == 0x2d8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::KnockbackKickUpStrength");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, KnockbackKickUpDuration) == 0x308, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::KnockbackKickUpDuration");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullSpeed) == 0x338, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullSpeed");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullTargetOffset) == 0x368, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullTargetOffset");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, bForceOffsetDistance) == 0x398, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::bForceOffsetDistance");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullTargetOffsetMargin) == 0x3c8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullTargetOffsetMargin");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullMaxDuration) == 0x3f8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullMaxDuration");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullMinDuration) == 0x428, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullMinDuration");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, MinImpactDotProduct) == 0x458, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::MinImpactDotProduct");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, SurfaceSlideUnderOverForce) == 0x488, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::SurfaceSlideUnderOverForce");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, MaxInvalidPullTime) == 0x4b8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::MaxInvalidPullTime");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, InterruptClampedSpeed) == 0x4e8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::InterruptClampedSpeed");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, LineOfSightDelay) == 0x518, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::LineOfSightDelay");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, bCheckLineOfSight) == 0x548, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::bCheckLineOfSight");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, LineOfSightHeightOffset) == 0x578, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::LineOfSightHeightOffset");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, DisconnectProtectionUpdateRate) == 0x5a8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::DisconnectProtectionUpdateRate");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, KnockbackEndEventTag) == 0x5d8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::KnockbackEndEventTag");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullStartEventTag) == 0x5dc, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullStartEventTag");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, PullInvalidatedEventTag) == 0x5e0, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::PullInvalidatedEventTag");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, HookshotActiveTag) == 0x5e4, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::HookshotActiveTag");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, LineOfSightCollisionProfile) == 0x5e8, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::LineOfSightCollisionProfile");
static_assert(offsetof(UFortMovementMode_ExtCoffeePuffPull, LineOfSightIgnoreTags) == 0x5f0, "Offset mismatch for UFortMovementMode_ExtCoffeePuffPull::LineOfSightIgnoreTags");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FFortMovementMode_CoffeePuffPullCreationData : FFortMovementMode_BaseExtCreationData
{
    TWeakObjectPtr<AActor*> PullingActor; // 0x10 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FFortMovementMode_CoffeePuffPullCreationData) == 0x18, "Size mismatch for FFortMovementMode_CoffeePuffPullCreationData");
static_assert(offsetof(FFortMovementMode_CoffeePuffPullCreationData, PullingActor) == 0x10, "Offset mismatch for FFortMovementMode_CoffeePuffPullCreationData::PullingActor");

