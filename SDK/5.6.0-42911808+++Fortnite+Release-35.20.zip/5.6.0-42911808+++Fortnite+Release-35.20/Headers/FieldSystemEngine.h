/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FieldSystemEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "ChaosSolverEngine.h"

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AFieldSystemActor : public AActor
{
public:
    UFieldSystemComponent* FieldSystemComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AFieldSystemActor) == 0x2b0, "Size mismatch for AFieldSystemActor");
static_assert(offsetof(AFieldSystemActor, FieldSystemComponent) == 0x2a8, "Offset mismatch for AFieldSystemActor::FieldSystemComponent");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UFieldSystem : public UObject
{
public:
};

static_assert(sizeof(UFieldSystem) == 0x38, "Size mismatch for UFieldSystem");

// Size: 0x5f0 (Inherited: 0x840, Single: 0xfffffdb0)
class UFieldSystemComponent : public UPrimitiveComponent
{
public:
    UFieldSystem* FieldSystem; // 0x518 (Size: 0x8, Type: ObjectProperty)
    bool bIsWorldField; // 0x520 (Size: 0x1, Type: BoolProperty)
    bool bIsChaosField; // 0x521 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_522[0x6]; // 0x522 (Size: 0x6, Type: PaddingProperty)
    TArray<TSoftObjectPtr<AChaosSolverActor*>> SupportedSolvers; // 0x528 (Size: 0x10, Type: ArrayProperty)
    FFieldObjectCommands ConstructionCommands; // 0x538 (Size: 0x30, Type: StructProperty)
    FFieldObjectCommands BufferCommands; // 0x568 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_598[0x58]; // 0x598 (Size: 0x58, Type: PaddingProperty)

public:
    void AddFieldCommand(bool& Enabled, TEnumAsByte<EFieldPhysicsType>& Target, UFieldSystemMetaData*& MetaData, UFieldNodeBase*& Field); // 0x9f11dbc (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void AddPersistentField(bool& Enabled, TEnumAsByte<EFieldPhysicsType>& Target, UFieldSystemMetaData*& MetaData, UFieldNodeBase*& Field); // 0x5749fd8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ApplyLinearForce(bool& Enabled, FVector& Direction, float& Magnitude); // 0x9f12180 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void ApplyPhysicsField(bool& Enabled, TEnumAsByte<EFieldPhysicsType>& Target, UFieldSystemMetaData*& MetaData, UFieldNodeBase*& Field); // 0x9f123a4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ApplyRadialForce(bool& Enabled, FVector& Position, float& Magnitude); // 0x9f1276c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void ApplyRadialVectorFalloffForce(bool& Enabled, FVector& Position, float& Radius, float& Magnitude); // 0x9f12990 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void ApplyStayDynamicField(bool& Enabled, FVector& Position, float& Radius); // 0x9f12c24 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void ApplyStrainField(bool& Enabled, FVector& Position, float& Radius, float& Magnitude, int32_t& Iterations); // 0x9f12e48 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void ApplyUniformVectorFalloffForce(bool& Enabled, FVector& Position, FVector& Direction, float& Radius, float& Magnitude); // 0x9f13144 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void RemovePersistentFields(); // 0x596da88 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ResetFieldSystem(); // 0x9f13460 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFieldSystemComponent) == 0x5f0, "Size mismatch for UFieldSystemComponent");
static_assert(offsetof(UFieldSystemComponent, FieldSystem) == 0x518, "Offset mismatch for UFieldSystemComponent::FieldSystem");
static_assert(offsetof(UFieldSystemComponent, bIsWorldField) == 0x520, "Offset mismatch for UFieldSystemComponent::bIsWorldField");
static_assert(offsetof(UFieldSystemComponent, bIsChaosField) == 0x521, "Offset mismatch for UFieldSystemComponent::bIsChaosField");
static_assert(offsetof(UFieldSystemComponent, SupportedSolvers) == 0x528, "Offset mismatch for UFieldSystemComponent::SupportedSolvers");
static_assert(offsetof(UFieldSystemComponent, ConstructionCommands) == 0x538, "Offset mismatch for UFieldSystemComponent::ConstructionCommands");
static_assert(offsetof(UFieldSystemComponent, BufferCommands) == 0x568, "Offset mismatch for UFieldSystemComponent::BufferCommands");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UFieldSystemMetaData : public UActorComponent
{
public:
};

static_assert(sizeof(UFieldSystemMetaData) == 0xb8, "Size mismatch for UFieldSystemMetaData");

// Size: 0xc0 (Inherited: 0x198, Single: 0xffffff28)
class UFieldSystemMetaDataIteration : public UFieldSystemMetaData
{
public:
    int32_t Iterations; // 0xb8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)

public:
    UFieldSystemMetaDataIteration* SetMetaDataIteration(int32_t& Iterations); // 0x9f140d0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFieldSystemMetaDataIteration) == 0xc0, "Size mismatch for UFieldSystemMetaDataIteration");
static_assert(offsetof(UFieldSystemMetaDataIteration, Iterations) == 0xb8, "Offset mismatch for UFieldSystemMetaDataIteration::Iterations");

// Size: 0xc0 (Inherited: 0x198, Single: 0xffffff28)
class UFieldSystemMetaDataProcessingResolution : public UFieldSystemMetaData
{
public:
    TEnumAsByte<EFieldResolutionType> ResolutionType; // 0xb8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)

public:
    UFieldSystemMetaDataProcessingResolution* SetMetaDataaProcessingResolutionType(TEnumAsByte<EFieldResolutionType>& ResolutionType); // 0x9f14208 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFieldSystemMetaDataProcessingResolution) == 0xc0, "Size mismatch for UFieldSystemMetaDataProcessingResolution");
static_assert(offsetof(UFieldSystemMetaDataProcessingResolution, ResolutionType) == 0xb8, "Offset mismatch for UFieldSystemMetaDataProcessingResolution::ResolutionType");

// Size: 0xc0 (Inherited: 0x198, Single: 0xffffff28)
class UFieldSystemMetaDataFilter : public UFieldSystemMetaData
{
public:
    TEnumAsByte<EFieldFilterType> FilterType; // 0xb8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFieldObjectType> ObjectType; // 0xb9 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFieldPositionType> PositionType; // 0xba (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_bb[0x5]; // 0xbb (Size: 0x5, Type: PaddingProperty)

public:
    UFieldSystemMetaDataFilter* SetMetaDataFilterType(TEnumAsByte<EFieldFilterType>& FilterType, TEnumAsByte<EFieldObjectType>& ObjectType, TEnumAsByte<EFieldPositionType>& PositionType); // 0x9f13ddc (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFieldSystemMetaDataFilter) == 0xc0, "Size mismatch for UFieldSystemMetaDataFilter");
static_assert(offsetof(UFieldSystemMetaDataFilter, FilterType) == 0xb8, "Offset mismatch for UFieldSystemMetaDataFilter::FilterType");
static_assert(offsetof(UFieldSystemMetaDataFilter, ObjectType) == 0xb9, "Offset mismatch for UFieldSystemMetaDataFilter::ObjectType");
static_assert(offsetof(UFieldSystemMetaDataFilter, PositionType) == 0xba, "Offset mismatch for UFieldSystemMetaDataFilter::PositionType");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UFieldNodeBase : public UActorComponent
{
public:
};

static_assert(sizeof(UFieldNodeBase) == 0xb8, "Size mismatch for UFieldNodeBase");

// Size: 0xb8 (Inherited: 0x198, Single: 0xffffff20)
class UFieldNodeInt : public UFieldNodeBase
{
public:
};

static_assert(sizeof(UFieldNodeInt) == 0xb8, "Size mismatch for UFieldNodeInt");

// Size: 0xb8 (Inherited: 0x198, Single: 0xffffff20)
class UFieldNodeFloat : public UFieldNodeBase
{
public:
};

static_assert(sizeof(UFieldNodeFloat) == 0xb8, "Size mismatch for UFieldNodeFloat");

// Size: 0xb8 (Inherited: 0x198, Single: 0xffffff20)
class UFieldNodeVector : public UFieldNodeBase
{
public:
};

static_assert(sizeof(UFieldNodeVector) == 0xb8, "Size mismatch for UFieldNodeVector");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class UUniformInteger : public UFieldNodeInt
{
public:
    int32_t Magnitude; // 0xb8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)

public:
    UUniformInteger* SetUniformInteger(int32_t& Magnitude); // 0x9f140d0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UUniformInteger) == 0xc0, "Size mismatch for UUniformInteger");
static_assert(offsetof(UUniformInteger, Magnitude) == 0xb8, "Offset mismatch for UUniformInteger::Magnitude");

// Size: 0xe8 (Inherited: 0x250, Single: 0xfffffe98)
class URadialIntMask : public UFieldNodeInt
{
public:
    float Radius; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0xc0 (Size: 0x18, Type: StructProperty)
    int32_t InteriorValue; // 0xd8 (Size: 0x4, Type: IntProperty)
    int32_t ExteriorValue; // 0xdc (Size: 0x4, Type: IntProperty)
    TEnumAsByte<ESetMaskConditionType> SetMaskCondition; // 0xe0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e1[0x7]; // 0xe1 (Size: 0x7, Type: PaddingProperty)

public:
    URadialIntMask* SetRadialIntMask(float& Radius, FVector& Position, int32_t& InteriorValue, int32_t& ExteriorValue, TEnumAsByte<ESetMaskConditionType>& SetMaskConditionIn); // 0x9f14bb8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(URadialIntMask) == 0xe8, "Size mismatch for URadialIntMask");
static_assert(offsetof(URadialIntMask, Radius) == 0xb8, "Offset mismatch for URadialIntMask::Radius");
static_assert(offsetof(URadialIntMask, Position) == 0xc0, "Offset mismatch for URadialIntMask::Position");
static_assert(offsetof(URadialIntMask, InteriorValue) == 0xd8, "Offset mismatch for URadialIntMask::InteriorValue");
static_assert(offsetof(URadialIntMask, ExteriorValue) == 0xdc, "Offset mismatch for URadialIntMask::ExteriorValue");
static_assert(offsetof(URadialIntMask, SetMaskCondition) == 0xe0, "Offset mismatch for URadialIntMask::SetMaskCondition");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class UUniformScalar : public UFieldNodeFloat
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)

public:
    UUniformScalar* SetUniformScalar(float& Magnitude); // 0x9f14ec0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UUniformScalar) == 0xc0, "Size mismatch for UUniformScalar");
static_assert(offsetof(UUniformScalar, Magnitude) == 0xb8, "Offset mismatch for UUniformScalar::Magnitude");

// Size: 0xe8 (Inherited: 0x250, Single: 0xfffffe98)
class UWaveScalar : public UFieldNodeFloat
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0xc0 (Size: 0x18, Type: StructProperty)
    float WaveLength; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float Period; // 0xdc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EWaveFunctionType> Function; // 0xe0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFieldFalloffType> Falloff; // 0xe1 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e2[0x6]; // 0xe2 (Size: 0x6, Type: PaddingProperty)

public:
    UWaveScalar* SetWaveScalar(float& Magnitude, FVector& Position, float& WaveLength, float& Period, float& time, TEnumAsByte<EWaveFunctionType>& Function, TEnumAsByte<EFieldFalloffType>& Falloff); // 0x54d4cbc (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UWaveScalar) == 0xe8, "Size mismatch for UWaveScalar");
static_assert(offsetof(UWaveScalar, Magnitude) == 0xb8, "Offset mismatch for UWaveScalar::Magnitude");
static_assert(offsetof(UWaveScalar, Position) == 0xc0, "Offset mismatch for UWaveScalar::Position");
static_assert(offsetof(UWaveScalar, WaveLength) == 0xd8, "Offset mismatch for UWaveScalar::WaveLength");
static_assert(offsetof(UWaveScalar, Period) == 0xdc, "Offset mismatch for UWaveScalar::Period");
static_assert(offsetof(UWaveScalar, Function) == 0xe0, "Offset mismatch for UWaveScalar::Function");
static_assert(offsetof(UWaveScalar, Falloff) == 0xe1, "Offset mismatch for UWaveScalar::Falloff");

// Size: 0xf0 (Inherited: 0x250, Single: 0xfffffea0)
class URadialFalloff : public UFieldNodeFloat
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MinRange; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxRange; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Default; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float Radius; // 0xc8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0xd0 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EFieldFalloffType> Falloff; // 0xe8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)

public:
    URadialFalloff* SetRadialFalloff(float& Magnitude, float& MinRange, float& MaxRange, float& Default, float& Radius, FVector& Position, TEnumAsByte<EFieldFalloffType>& Falloff); // 0x5643cc4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(URadialFalloff) == 0xf0, "Size mismatch for URadialFalloff");
static_assert(offsetof(URadialFalloff, Magnitude) == 0xb8, "Offset mismatch for URadialFalloff::Magnitude");
static_assert(offsetof(URadialFalloff, MinRange) == 0xbc, "Offset mismatch for URadialFalloff::MinRange");
static_assert(offsetof(URadialFalloff, MaxRange) == 0xc0, "Offset mismatch for URadialFalloff::MaxRange");
static_assert(offsetof(URadialFalloff, Default) == 0xc4, "Offset mismatch for URadialFalloff::Default");
static_assert(offsetof(URadialFalloff, Radius) == 0xc8, "Offset mismatch for URadialFalloff::Radius");
static_assert(offsetof(URadialFalloff, Position) == 0xd0, "Offset mismatch for URadialFalloff::Position");
static_assert(offsetof(URadialFalloff, Falloff) == 0xe8, "Offset mismatch for URadialFalloff::Falloff");

// Size: 0x108 (Inherited: 0x250, Single: 0xfffffeb8)
class UPlaneFalloff : public UFieldNodeFloat
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MinRange; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxRange; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Default; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float Distance; // 0xc8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0xd0 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0xe8 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EFieldFalloffType> Falloff; // 0x100 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)

public:
    UPlaneFalloff* SetPlaneFalloff(float& Magnitude, float& MinRange, float& MaxRange, float& Default, float& Distance, FVector& Position, FVector& Normal, TEnumAsByte<EFieldFalloffType>& Falloff); // 0x9f14684 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UPlaneFalloff) == 0x108, "Size mismatch for UPlaneFalloff");
static_assert(offsetof(UPlaneFalloff, Magnitude) == 0xb8, "Offset mismatch for UPlaneFalloff::Magnitude");
static_assert(offsetof(UPlaneFalloff, MinRange) == 0xbc, "Offset mismatch for UPlaneFalloff::MinRange");
static_assert(offsetof(UPlaneFalloff, MaxRange) == 0xc0, "Offset mismatch for UPlaneFalloff::MaxRange");
static_assert(offsetof(UPlaneFalloff, Default) == 0xc4, "Offset mismatch for UPlaneFalloff::Default");
static_assert(offsetof(UPlaneFalloff, Distance) == 0xc8, "Offset mismatch for UPlaneFalloff::Distance");
static_assert(offsetof(UPlaneFalloff, Position) == 0xd0, "Offset mismatch for UPlaneFalloff::Position");
static_assert(offsetof(UPlaneFalloff, Normal) == 0xe8, "Offset mismatch for UPlaneFalloff::Normal");
static_assert(offsetof(UPlaneFalloff, Falloff) == 0x100, "Offset mismatch for UPlaneFalloff::Falloff");

// Size: 0x140 (Inherited: 0x250, Single: 0xfffffef0)
class UBoxFalloff : public UFieldNodeFloat
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MinRange; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxRange; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Default; // 0xc4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0xd0 (Size: 0x60, Type: StructProperty)
    TEnumAsByte<EFieldFalloffType> Falloff; // 0x130 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_131[0xf]; // 0x131 (Size: 0xf, Type: PaddingProperty)

public:
    UBoxFalloff* SetBoxFalloff(float& Magnitude, float& MinRange, float& MaxRange, float& Default, FTransform& Transform, TEnumAsByte<EFieldFalloffType>& Falloff); // 0x9f13474 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UBoxFalloff) == 0x140, "Size mismatch for UBoxFalloff");
static_assert(offsetof(UBoxFalloff, Magnitude) == 0xb8, "Offset mismatch for UBoxFalloff::Magnitude");
static_assert(offsetof(UBoxFalloff, MinRange) == 0xbc, "Offset mismatch for UBoxFalloff::MinRange");
static_assert(offsetof(UBoxFalloff, MaxRange) == 0xc0, "Offset mismatch for UBoxFalloff::MaxRange");
static_assert(offsetof(UBoxFalloff, Default) == 0xc4, "Offset mismatch for UBoxFalloff::Default");
static_assert(offsetof(UBoxFalloff, Transform) == 0xd0, "Offset mismatch for UBoxFalloff::Transform");
static_assert(offsetof(UBoxFalloff, Falloff) == 0x130, "Offset mismatch for UBoxFalloff::Falloff");

// Size: 0x120 (Inherited: 0x250, Single: 0xfffffed0)
class UNoiseField : public UFieldNodeFloat
{
public:
    float MinRange; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MaxRange; // 0xbc (Size: 0x4, Type: FloatProperty)
    FTransform Transform; // 0xc0 (Size: 0x60, Type: StructProperty)

public:
    UNoiseField* SetNoiseField(float& MinRange, float& MaxRange, FTransform& Transform); // 0x9f14340 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UNoiseField) == 0x120, "Size mismatch for UNoiseField");
static_assert(offsetof(UNoiseField, MinRange) == 0xb8, "Offset mismatch for UNoiseField::MinRange");
static_assert(offsetof(UNoiseField, MaxRange) == 0xbc, "Offset mismatch for UNoiseField::MaxRange");
static_assert(offsetof(UNoiseField, Transform) == 0xc0, "Offset mismatch for UNoiseField::Transform");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UUniformVector : public UFieldNodeVector
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    FVector Direction; // 0xc0 (Size: 0x18, Type: StructProperty)

public:
    UUniformVector* SetUniformVector(float& Magnitude, FVector& Direction); // 0x583f65c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UUniformVector) == 0xd8, "Size mismatch for UUniformVector");
static_assert(offsetof(UUniformVector, Magnitude) == 0xb8, "Offset mismatch for UUniformVector::Magnitude");
static_assert(offsetof(UUniformVector, Direction) == 0xc0, "Offset mismatch for UUniformVector::Direction");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class URadialVector : public UFieldNodeVector
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0xc0 (Size: 0x18, Type: StructProperty)

public:
    URadialVector* SetRadialVector(float& Magnitude, FVector& Position); // 0x583f65c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(URadialVector) == 0xd8, "Size mismatch for URadialVector");
static_assert(offsetof(URadialVector, Magnitude) == 0xb8, "Offset mismatch for URadialVector::Magnitude");
static_assert(offsetof(URadialVector, Position) == 0xc0, "Offset mismatch for URadialVector::Position");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class URandomVector : public UFieldNodeVector
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)

public:
    URandomVector* SetRandomVector(float& Magnitude); // 0x9f14ec0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(URandomVector) == 0xc0, "Size mismatch for URandomVector");
static_assert(offsetof(URandomVector, Magnitude) == 0xb8, "Offset mismatch for URandomVector::Magnitude");

// Size: 0xd8 (Inherited: 0x198, Single: 0xffffff40)
class UOperatorField : public UFieldNodeBase
{
public:
    float Magnitude; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    UFieldNodeBase* RightField; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UFieldNodeBase* LeftField; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EFieldOperationType> Operation; // 0xd0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)

public:
    UOperatorField* SetOperatorField(float& Magnitude, UFieldNodeBase*& const LeftField, UFieldNodeBase*& const RightField, TEnumAsByte<EFieldOperationType>& Operation); // 0x4fc6060 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UOperatorField) == 0xd8, "Size mismatch for UOperatorField");
static_assert(offsetof(UOperatorField, Magnitude) == 0xb8, "Offset mismatch for UOperatorField::Magnitude");
static_assert(offsetof(UOperatorField, RightField) == 0xc0, "Offset mismatch for UOperatorField::RightField");
static_assert(offsetof(UOperatorField, LeftField) == 0xc8, "Offset mismatch for UOperatorField::LeftField");
static_assert(offsetof(UOperatorField, Operation) == 0xd0, "Offset mismatch for UOperatorField::Operation");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class UToIntegerField : public UFieldNodeInt
{
public:
    UFieldNodeFloat* FloatField; // 0xb8 (Size: 0x8, Type: ObjectProperty)

public:
    UToIntegerField* SetToIntegerField(UFieldNodeFloat*& const FloatField); // 0x9f15010 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UToIntegerField) == 0xc0, "Size mismatch for UToIntegerField");
static_assert(offsetof(UToIntegerField, FloatField) == 0xb8, "Offset mismatch for UToIntegerField::FloatField");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class UToFloatField : public UFieldNodeFloat
{
public:
    UFieldNodeInt* IntField; // 0xb8 (Size: 0x8, Type: ObjectProperty)

public:
    UToFloatField* SetToFloatField(UFieldNodeInt*& const IntegerField); // 0x9f15010 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UToFloatField) == 0xc0, "Size mismatch for UToFloatField");
static_assert(offsetof(UToFloatField, IntField) == 0xb8, "Offset mismatch for UToFloatField::IntField");

// Size: 0xd0 (Inherited: 0x198, Single: 0xffffff38)
class UCullingField : public UFieldNodeBase
{
public:
    UFieldNodeBase* Culling; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFieldNodeBase* Field; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EFieldCullingOperationType> Operation; // 0xc8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)

public:
    UCullingField* SetCullingField(UFieldNodeBase*& const Culling, UFieldNodeBase*& const Field, TEnumAsByte<EFieldCullingOperationType>& Operation); // 0x9f13938 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCullingField) == 0xd0, "Size mismatch for UCullingField");
static_assert(offsetof(UCullingField, Culling) == 0xb8, "Offset mismatch for UCullingField::Culling");
static_assert(offsetof(UCullingField, Field) == 0xc0, "Offset mismatch for UCullingField::Field");
static_assert(offsetof(UCullingField, Operation) == 0xc8, "Offset mismatch for UCullingField::Operation");

// Size: 0xb8 (Inherited: 0x198, Single: 0xffffff20)
class UReturnResultsTerminal : public UFieldNodeBase
{
public:

public:
    UReturnResultsTerminal* SetReturnResultsTerminal(); // 0x9f14ffc (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UReturnResultsTerminal) == 0xb8, "Size mismatch for UReturnResultsTerminal");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFieldObjectCommands
{
    TArray<FName> TargetNames; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFieldNodeBase*> RootNodes; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UFieldSystemMetaData*> MetaDatas; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFieldObjectCommands) == 0x30, "Size mismatch for FFieldObjectCommands");
static_assert(offsetof(FFieldObjectCommands, TargetNames) == 0x0, "Offset mismatch for FFieldObjectCommands::TargetNames");
static_assert(offsetof(FFieldObjectCommands, RootNodes) == 0x10, "Offset mismatch for FFieldObjectCommands::RootNodes");
static_assert(offsetof(FFieldObjectCommands, MetaDatas) == 0x20, "Offset mismatch for FFieldObjectCommands::MetaDatas");

