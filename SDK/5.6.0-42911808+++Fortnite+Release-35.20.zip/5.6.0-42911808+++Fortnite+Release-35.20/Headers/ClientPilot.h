/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClientPilot
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UClientPilotBlackboard : public UObject
{
public:
};

static_assert(sizeof(UClientPilotBlackboard) == 0x78, "Size mismatch for UClientPilotBlackboard");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UClientPilotBlackboardManager : public UObject
{
public:
    UClientPilotBlackboard* PilotBlackboard; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UClientPilotBlackboardManager) == 0x30, "Size mismatch for UClientPilotBlackboardManager");
static_assert(offsetof(UClientPilotBlackboardManager, PilotBlackboard) == 0x28, "Offset mismatch for UClientPilotBlackboardManager::PilotBlackboard");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UClientPilotComponent : public UObject
{
public:
};

static_assert(sizeof(UClientPilotComponent) == 0x28, "Size mismatch for UClientPilotComponent");

