/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteMusic
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "MetasoundEngine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortMusicItemInterface : public UInterface
{
public:

public:
    FText GetArtist() const; // 0xb45be58 (Index: 0x0, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetTitle() const; // 0xb45be94 (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortMusicItemInterface) == 0x28, "Size mismatch for UFortMusicItemInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortMusicPlayerInterface : public UInterface
{
public:
};

static_assert(sizeof(UFortMusicPlayerInterface) == 0x28, "Size mismatch for UFortMusicPlayerInterface");

// Size: 0x110 (Inherited: 0x88, Single: 0x88)
class UFortMusicPlayerRegistry : public UGameInstanceSubsystem
{
public:
    uint8_t Pad_30[0x60]; // 0x30 (Size: 0x60, Type: PaddingProperty)
    TScriptInterface<Class> CurrentItem; // 0x90 (Size: 0x10, Type: InterfaceProperty)
    TScriptInterface<Class> CurrentPlaylist; // 0xa0 (Size: 0x10, Type: InterfaceProperty)
    uint8_t Pad_b0[0x18]; // 0xb0 (Size: 0x18, Type: PaddingProperty)
    FFortMusicPlayerParams PlaylistParams; // 0xc8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortMusicPlayerRegistry) == 0x110, "Size mismatch for UFortMusicPlayerRegistry");
static_assert(offsetof(UFortMusicPlayerRegistry, CurrentItem) == 0x90, "Offset mismatch for UFortMusicPlayerRegistry::CurrentItem");
static_assert(offsetof(UFortMusicPlayerRegistry, CurrentPlaylist) == 0xa0, "Offset mismatch for UFortMusicPlayerRegistry::CurrentPlaylist");
static_assert(offsetof(UFortMusicPlayerRegistry, PlaylistParams) == 0xc8, "Offset mismatch for UFortMusicPlayerRegistry::PlaylistParams");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortMusicPlaylist : public UInterface
{
public:
};

static_assert(sizeof(UFortMusicPlaylist) == 0x28, "Size mismatch for UFortMusicPlaylist");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UFortSimpleMusicPlaylist : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<TScriptInterface<Class>> Items; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortSimpleMusicPlaylist) == 0x40, "Size mismatch for UFortSimpleMusicPlaylist");
static_assert(offsetof(UFortSimpleMusicPlaylist, Items) == 0x30, "Offset mismatch for UFortSimpleMusicPlaylist::Items");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FFortMusicPlayerParams
{
    uint8_t PlaybackType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float StartTimeOffset; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bSkipCountIn; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bLooping; // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bAutoPlay; // 0xa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b[0x5]; // 0xb (Size: 0x5, Type: PaddingProperty)
    UAudioComponent* AudioComponent; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundSource* MetaSoundSource; // 0x18 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag MusicEventTag; // 0x20 (Size: 0x4, Type: StructProperty)
    FName MusicEventGroup; // 0x24 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer MusicEventBehaviorTags; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortMusicPlayerParams) == 0x48, "Size mismatch for FFortMusicPlayerParams");
static_assert(offsetof(FFortMusicPlayerParams, PlaybackType) == 0x0, "Offset mismatch for FFortMusicPlayerParams::PlaybackType");
static_assert(offsetof(FFortMusicPlayerParams, StartTimeOffset) == 0x4, "Offset mismatch for FFortMusicPlayerParams::StartTimeOffset");
static_assert(offsetof(FFortMusicPlayerParams, bSkipCountIn) == 0x8, "Offset mismatch for FFortMusicPlayerParams::bSkipCountIn");
static_assert(offsetof(FFortMusicPlayerParams, bLooping) == 0x9, "Offset mismatch for FFortMusicPlayerParams::bLooping");
static_assert(offsetof(FFortMusicPlayerParams, bAutoPlay) == 0xa, "Offset mismatch for FFortMusicPlayerParams::bAutoPlay");
static_assert(offsetof(FFortMusicPlayerParams, AudioComponent) == 0x10, "Offset mismatch for FFortMusicPlayerParams::AudioComponent");
static_assert(offsetof(FFortMusicPlayerParams, MetaSoundSource) == 0x18, "Offset mismatch for FFortMusicPlayerParams::MetaSoundSource");
static_assert(offsetof(FFortMusicPlayerParams, MusicEventTag) == 0x20, "Offset mismatch for FFortMusicPlayerParams::MusicEventTag");
static_assert(offsetof(FFortMusicPlayerParams, MusicEventGroup) == 0x24, "Offset mismatch for FFortMusicPlayerParams::MusicEventGroup");
static_assert(offsetof(FFortMusicPlayerParams, MusicEventBehaviorTags) == 0x28, "Offset mismatch for FFortMusicPlayerParams::MusicEventBehaviorTags");

