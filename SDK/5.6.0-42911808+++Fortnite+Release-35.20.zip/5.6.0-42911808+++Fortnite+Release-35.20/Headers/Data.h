/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Data
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FIntercomChannelListeners
{
    TArray<USoundSourceBus*> SourceBuses_13_2E5A2A644F60CA2CEBCE13800EBD31C5; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FIntercomChannelListeners) == 0x10, "Size mismatch for FIntercomChannelListeners");
static_assert(offsetof(FIntercomChannelListeners, SourceBuses_13_2E5A2A644F60CA2CEBCE13800EBD31C5) == 0x0, "Offset mismatch for FIntercomChannelListeners::SourceBuses_13_2E5A2A644F60CA2CEBCE13800EBD31C5");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayEvent_IntercomStopBroadcast
{
    FGameplayTag ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double FadeOutDuration_19_4342B4C348EAAE8774A2088805EC7A55; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FGameplayEvent_IntercomStopBroadcast) == 0x10, "Size mismatch for FGameplayEvent_IntercomStopBroadcast");
static_assert(offsetof(FGameplayEvent_IntercomStopBroadcast, ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C) == 0x0, "Offset mismatch for FGameplayEvent_IntercomStopBroadcast::ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C");
static_assert(offsetof(FGameplayEvent_IntercomStopBroadcast, FadeOutDuration_19_4342B4C348EAAE8774A2088805EC7A55) == 0x8, "Offset mismatch for FGameplayEvent_IntercomStopBroadcast::FadeOutDuration_19_4342B4C348EAAE8774A2088805EC7A55");

// Size: 0x16 (Inherited: 0x0, Single: 0x16)
struct FGameplayEvent_IntercomBroadcastRequest
{
    FGameplayTag ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    USoundBase* Sound_5_E6C156894D5A0E2986A423BDC3A9A16C; // 0x8 (Size: 0x8, Type: ObjectProperty)
    int32_t Priority_8_9D44E8734E35A1B467EFD28590B1B0B9; // 0x10 (Size: 0x4, Type: IntProperty)
    bool IsBlocking_15_691F1A6045C7C88EA3C3F7AFD0EA541F; // 0x14 (Size: 0x1, Type: BoolProperty)
    bool QueueifOccupied_17_4342B4C348EAAE8774A2088805EC7A55; // 0x15 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGameplayEvent_IntercomBroadcastRequest) == 0x16, "Size mismatch for FGameplayEvent_IntercomBroadcastRequest");
static_assert(offsetof(FGameplayEvent_IntercomBroadcastRequest, ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C) == 0x0, "Offset mismatch for FGameplayEvent_IntercomBroadcastRequest::ChannelTag_2_7CBB941D4D8B12305FB174A284D2BE0C");
static_assert(offsetof(FGameplayEvent_IntercomBroadcastRequest, Sound_5_E6C156894D5A0E2986A423BDC3A9A16C) == 0x8, "Offset mismatch for FGameplayEvent_IntercomBroadcastRequest::Sound_5_E6C156894D5A0E2986A423BDC3A9A16C");
static_assert(offsetof(FGameplayEvent_IntercomBroadcastRequest, Priority_8_9D44E8734E35A1B467EFD28590B1B0B9) == 0x10, "Offset mismatch for FGameplayEvent_IntercomBroadcastRequest::Priority_8_9D44E8734E35A1B467EFD28590B1B0B9");
static_assert(offsetof(FGameplayEvent_IntercomBroadcastRequest, IsBlocking_15_691F1A6045C7C88EA3C3F7AFD0EA541F) == 0x14, "Offset mismatch for FGameplayEvent_IntercomBroadcastRequest::IsBlocking_15_691F1A6045C7C88EA3C3F7AFD0EA541F");
static_assert(offsetof(FGameplayEvent_IntercomBroadcastRequest, QueueifOccupied_17_4342B4C348EAAE8774A2088805EC7A55) == 0x15, "Offset mismatch for FGameplayEvent_IntercomBroadcastRequest::QueueifOccupied_17_4342B4C348EAAE8774A2088805EC7A55");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FIntercomChannelQueue
{
    TArray<FGameplayEvent_IntercomBroadcastRequest> BroadcastQueue_6_2E5A2A644F60CA2CEBCE13800EBD31C5; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FIntercomChannelQueue) == 0x10, "Size mismatch for FIntercomChannelQueue");
static_assert(offsetof(FIntercomChannelQueue, BroadcastQueue_6_2E5A2A644F60CA2CEBCE13800EBD31C5) == 0x0, "Offset mismatch for FIntercomChannelQueue::BroadcastQueue_6_2E5A2A644F60CA2CEBCE13800EBD31C5");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_BuyRewards_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_BuyRewards_C) == 0xd8, "Size mismatch for UDialogVM_BuyRewards_C");

