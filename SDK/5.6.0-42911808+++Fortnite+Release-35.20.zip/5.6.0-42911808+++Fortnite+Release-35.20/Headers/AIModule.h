/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AIModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Basic.h"
#include "NavigationSystem.h"
#include "Engine.h"
#include "GameplayTasks.h"
#include "_Verse.h"
#include "GameplayTags.h"

// Size: 0x68 (Inherited: 0x28, Single: 0x40)
class UAIAsyncTaskBlueprintProxy : public UObject
{
public:
    uint8_t OnSuccess[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFail[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_48[0x20]; // 0x48 (Size: 0x20, Type: PaddingProperty)

public:
    void OnMoveCompleted(FAIRequestID& RequestID, TEnumAsByte<EPathFollowingResult>& MovementResult); // 0xaf28254 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public)
};

static_assert(sizeof(UAIAsyncTaskBlueprintProxy) == 0x68, "Size mismatch for UAIAsyncTaskBlueprintProxy");
static_assert(offsetof(UAIAsyncTaskBlueprintProxy, OnSuccess) == 0x28, "Offset mismatch for UAIAsyncTaskBlueprintProxy::OnSuccess");
static_assert(offsetof(UAIAsyncTaskBlueprintProxy, OnFail) == 0x38, "Offset mismatch for UAIAsyncTaskBlueprintProxy::OnFail");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAIResourceInterface : public UInterface
{
public:
};

static_assert(sizeof(UAIResourceInterface) == 0x28, "Size mismatch for UAIResourceInterface");

// Size: 0x108 (Inherited: 0x2d8, Single: 0xfffffe30)
class UAISenseBlueprintListener : public UUserDefinedStruct
{
public:
};

static_assert(sizeof(UAISenseBlueprintListener) == 0x108, "Size mismatch for UAISenseBlueprintListener");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UAISenseConfig : public UObject
{
public:
    FColor DebugColor; // 0x28 (Size: 0x4, Type: StructProperty)
    float MaxAge; // 0x2c (Size: 0x4, Type: FloatProperty)
    uint8_t bStartsEnabled : 1; // 0x30:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x17]; // 0x31 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(UAISenseConfig) == 0x48, "Size mismatch for UAISenseConfig");
static_assert(offsetof(UAISenseConfig, DebugColor) == 0x28, "Offset mismatch for UAISenseConfig::DebugColor");
static_assert(offsetof(UAISenseConfig, MaxAge) == 0x2c, "Offset mismatch for UAISenseConfig::MaxAge");
static_assert(offsetof(UAISenseConfig, bStartsEnabled) == 0x30, "Offset mismatch for UAISenseConfig::bStartsEnabled");

// Size: 0x50 (Inherited: 0x70, Single: 0xffffffe0)
class UAISenseConfig_Blueprint : public UAISenseConfig
{
public:
    UClass* Implementation; // 0x48 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UAISenseConfig_Blueprint) == 0x50, "Size mismatch for UAISenseConfig_Blueprint");
static_assert(offsetof(UAISenseConfig_Blueprint, Implementation) == 0x48, "Offset mismatch for UAISenseConfig_Blueprint::Implementation");

// Size: 0x60 (Inherited: 0x70, Single: 0xfffffff0)
class UAISenseConfig_Hearing : public UAISenseConfig
{
public:
    UClass* Implementation; // 0x48 (Size: 0x8, Type: ClassProperty)
    float HearingRange; // 0x50 (Size: 0x4, Type: FloatProperty)
    float LoSHearingRange; // 0x54 (Size: 0x4, Type: FloatProperty)
    uint8_t bUseLoSHearing : 1; // 0x58:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x3]; // 0x59 (Size: 0x3, Type: PaddingProperty)
    FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UAISenseConfig_Hearing) == 0x60, "Size mismatch for UAISenseConfig_Hearing");
static_assert(offsetof(UAISenseConfig_Hearing, Implementation) == 0x48, "Offset mismatch for UAISenseConfig_Hearing::Implementation");
static_assert(offsetof(UAISenseConfig_Hearing, HearingRange) == 0x50, "Offset mismatch for UAISenseConfig_Hearing::HearingRange");
static_assert(offsetof(UAISenseConfig_Hearing, LoSHearingRange) == 0x54, "Offset mismatch for UAISenseConfig_Hearing::LoSHearingRange");
static_assert(offsetof(UAISenseConfig_Hearing, bUseLoSHearing) == 0x58, "Offset mismatch for UAISenseConfig_Hearing::bUseLoSHearing");
static_assert(offsetof(UAISenseConfig_Hearing, DetectionByAffiliation) == 0x5c, "Offset mismatch for UAISenseConfig_Hearing::DetectionByAffiliation");

// Size: 0x48 (Inherited: 0x70, Single: 0xffffffd8)
class UAISenseConfig_Prediction : public UAISenseConfig
{
public:
};

static_assert(sizeof(UAISenseConfig_Prediction) == 0x48, "Size mismatch for UAISenseConfig_Prediction");

// Size: 0x70 (Inherited: 0x70, Single: 0x0)
class UAISenseConfig_Sight : public UAISenseConfig
{
public:
    UClass* Implementation; // 0x48 (Size: 0x8, Type: ClassProperty)
    float SightRadius; // 0x50 (Size: 0x4, Type: FloatProperty)
    float LoseSightRadius; // 0x54 (Size: 0x4, Type: FloatProperty)
    float PeripheralVisionAngleDegrees; // 0x58 (Size: 0x4, Type: FloatProperty)
    FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c (Size: 0x4, Type: StructProperty)
    float AutoSuccessRangeFromLastSeenLocation; // 0x60 (Size: 0x4, Type: FloatProperty)
    float PointOfViewBackwardOffset; // 0x64 (Size: 0x4, Type: FloatProperty)
    float NearClippingRadius; // 0x68 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAISenseConfig_Sight) == 0x70, "Size mismatch for UAISenseConfig_Sight");
static_assert(offsetof(UAISenseConfig_Sight, Implementation) == 0x48, "Offset mismatch for UAISenseConfig_Sight::Implementation");
static_assert(offsetof(UAISenseConfig_Sight, SightRadius) == 0x50, "Offset mismatch for UAISenseConfig_Sight::SightRadius");
static_assert(offsetof(UAISenseConfig_Sight, LoseSightRadius) == 0x54, "Offset mismatch for UAISenseConfig_Sight::LoseSightRadius");
static_assert(offsetof(UAISenseConfig_Sight, PeripheralVisionAngleDegrees) == 0x58, "Offset mismatch for UAISenseConfig_Sight::PeripheralVisionAngleDegrees");
static_assert(offsetof(UAISenseConfig_Sight, DetectionByAffiliation) == 0x5c, "Offset mismatch for UAISenseConfig_Sight::DetectionByAffiliation");
static_assert(offsetof(UAISenseConfig_Sight, AutoSuccessRangeFromLastSeenLocation) == 0x60, "Offset mismatch for UAISenseConfig_Sight::AutoSuccessRangeFromLastSeenLocation");
static_assert(offsetof(UAISenseConfig_Sight, PointOfViewBackwardOffset) == 0x64, "Offset mismatch for UAISenseConfig_Sight::PointOfViewBackwardOffset");
static_assert(offsetof(UAISenseConfig_Sight, NearClippingRadius) == 0x68, "Offset mismatch for UAISenseConfig_Sight::NearClippingRadius");

// Size: 0x48 (Inherited: 0x70, Single: 0xffffffd8)
class UAISenseConfig_Team : public UAISenseConfig
{
public:
};

static_assert(sizeof(UAISenseConfig_Team) == 0x48, "Size mismatch for UAISenseConfig_Team");

// Size: 0x50 (Inherited: 0x70, Single: 0xffffffe0)
class UAISenseConfig_Touch : public UAISenseConfig
{
public:
    FAISenseAffiliationFilter DetectionByAffiliation; // 0x48 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAISenseConfig_Touch) == 0x50, "Size mismatch for UAISenseConfig_Touch");
static_assert(offsetof(UAISenseConfig_Touch, DetectionByAffiliation) == 0x48, "Offset mismatch for UAISenseConfig_Touch::DetectionByAffiliation");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UAISenseEvent_Damage : public UAISenseEvent
{
public:
    FAIDamageEvent Event; // 0x28 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UAISenseEvent_Damage) == 0x78, "Size mismatch for UAISenseEvent_Damage");
static_assert(offsetof(UAISenseEvent_Damage, Event) == 0x28, "Offset mismatch for UAISenseEvent_Damage::Event");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAISenseEvent : public UObject
{
public:
};

static_assert(sizeof(UAISenseEvent) == 0x28, "Size mismatch for UAISenseEvent");

// Size: 0x60 (Inherited: 0x50, Single: 0x10)
class UAISenseEvent_Hearing : public UAISenseEvent
{
public:
    FAINoiseEvent Event; // 0x28 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UAISenseEvent_Hearing) == 0x60, "Size mismatch for UAISenseEvent_Hearing");
static_assert(offsetof(UAISenseEvent_Hearing, Event) == 0x28, "Offset mismatch for UAISenseEvent_Hearing::Event");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardKeyType_Struct : public UBlackboardKeyType
{
public:
    FInstancedStruct DefaultValue; // 0x30 (Size: 0x10, Type: StructProperty)
    FInstancedStruct Value; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UBlackboardKeyType_Struct) == 0x50, "Size mismatch for UBlackboardKeyType_Struct");
static_assert(offsetof(UBlackboardKeyType_Struct, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Struct::DefaultValue");
static_assert(offsetof(UBlackboardKeyType_Struct, Value) == 0x40, "Offset mismatch for UBlackboardKeyType_Struct::Value");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UBlackboardKeyType : public UObject
{
public:
};

static_assert(sizeof(UBlackboardKeyType) == 0x30, "Size mismatch for UBlackboardKeyType");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
class UBTTask_SetKeyValueBool : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Bool Value; // 0x98 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueBool) == 0xa8, "Size mismatch for UBTTask_SetKeyValueBool");
static_assert(offsetof(UBTTask_SetKeyValueBool, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueBool::Value");

// Size: 0x98 (Inherited: 0xf0, Single: 0xffffffa8)
class UBTTask_BlackboardBase : public UBTTaskNode
{
public:
    FBlackboardKeySelector BlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTTask_BlackboardBase) == 0x98, "Size mismatch for UBTTask_BlackboardBase");
static_assert(offsetof(UBTTask_BlackboardBase, BlackboardKey) == 0x70, "Offset mismatch for UBTTask_BlackboardBase::BlackboardKey");

// Size: 0x70 (Inherited: 0x80, Single: 0xfffffff0)
class UBTTaskNode : public UBTNode
{
public:
    TArray<UBTService*> Services; // 0x58 (Size: 0x10, Type: ArrayProperty)
    uint8_t bIgnoreRestartSelf : 1; // 0x68:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBTTaskNode) == 0x70, "Size mismatch for UBTTaskNode");
static_assert(offsetof(UBTTaskNode, Services) == 0x58, "Offset mismatch for UBTTaskNode::Services");
static_assert(offsetof(UBTTaskNode, bIgnoreRestartSelf) == 0x68, "Offset mismatch for UBTTaskNode::bIgnoreRestartSelf");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UBTNode : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FString NodeName; // 0x30 (Size: 0x10, Type: StrProperty)
    UBehaviorTree* TreeAsset; // 0x40 (Size: 0x8, Type: ObjectProperty)
    UBTCompositeNode* ParentNode; // 0x48 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_50[0x8]; // 0x50 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UBTNode) == 0x58, "Size mismatch for UBTNode");
static_assert(offsetof(UBTNode, NodeName) == 0x30, "Offset mismatch for UBTNode::NodeName");
static_assert(offsetof(UBTNode, TreeAsset) == 0x40, "Offset mismatch for UBTNode::TreeAsset");
static_assert(offsetof(UBTNode, ParentNode) == 0x48, "Offset mismatch for UBTNode::ParentNode");

// Size: 0xb8 (Inherited: 0x188, Single: 0xffffff30)
class UBTTask_SetKeyValueClass : public UBTTask_BlackboardBase
{
public:
    UClass* BaseClass; // 0x98 (Size: 0x8, Type: ClassProperty)
    FValueOrBBKey_Class Value; // 0xa0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueClass) == 0xb8, "Size mismatch for UBTTask_SetKeyValueClass");
static_assert(offsetof(UBTTask_SetKeyValueClass, BaseClass) == 0x98, "Offset mismatch for UBTTask_SetKeyValueClass::BaseClass");
static_assert(offsetof(UBTTask_SetKeyValueClass, Value) == 0xa0, "Offset mismatch for UBTTask_SetKeyValueClass::Value");

// Size: 0xc8 (Inherited: 0x188, Single: 0xffffff40)
class UBTTask_SetKeyValueEnum : public UBTTask_BlackboardBase
{
public:
    UEnum* EnumType; // 0x98 (Size: 0x8, Type: ObjectProperty)
    FValueOrBBKey_Enum Value; // 0xa0 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueEnum) == 0xc8, "Size mismatch for UBTTask_SetKeyValueEnum");
static_assert(offsetof(UBTTask_SetKeyValueEnum, EnumType) == 0x98, "Offset mismatch for UBTTask_SetKeyValueEnum::EnumType");
static_assert(offsetof(UBTTask_SetKeyValueEnum, Value) == 0xa0, "Offset mismatch for UBTTask_SetKeyValueEnum::Value");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
class UBTTask_SetKeyValueInt32 : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Int32 Value; // 0x98 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueInt32) == 0xa8, "Size mismatch for UBTTask_SetKeyValueInt32");
static_assert(offsetof(UBTTask_SetKeyValueInt32, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueInt32::Value");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
class UBTTask_SetKeyValueFloat : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Float Value; // 0x98 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueFloat) == 0xa8, "Size mismatch for UBTTask_SetKeyValueFloat");
static_assert(offsetof(UBTTask_SetKeyValueFloat, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueFloat::Value");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
class UBTTask_SetKeyValueName : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Name Value; // 0x98 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueName) == 0xa8, "Size mismatch for UBTTask_SetKeyValueName");
static_assert(offsetof(UBTTask_SetKeyValueName, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueName::Value");

// Size: 0xb0 (Inherited: 0x188, Single: 0xffffff28)
class UBTTask_SetKeyValueString : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_String Value; // 0x98 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueString) == 0xb0, "Size mismatch for UBTTask_SetKeyValueString");
static_assert(offsetof(UBTTask_SetKeyValueString, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueString::Value");

// Size: 0xb8 (Inherited: 0x188, Single: 0xffffff30)
class UBTTask_SetKeyValueObject : public UBTTask_BlackboardBase
{
public:
    UClass* BaseClass; // 0x98 (Size: 0x8, Type: ClassProperty)
    FValueOrBBKey_Object Value; // 0xa0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueObject) == 0xb8, "Size mismatch for UBTTask_SetKeyValueObject");
static_assert(offsetof(UBTTask_SetKeyValueObject, BaseClass) == 0x98, "Offset mismatch for UBTTask_SetKeyValueObject::BaseClass");
static_assert(offsetof(UBTTask_SetKeyValueObject, Value) == 0xa0, "Offset mismatch for UBTTask_SetKeyValueObject::Value");

// Size: 0xb8 (Inherited: 0x188, Single: 0xffffff30)
class UBTTask_SetKeyValueRotator : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Rotator Value; // 0x98 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueRotator) == 0xb8, "Size mismatch for UBTTask_SetKeyValueRotator");
static_assert(offsetof(UBTTask_SetKeyValueRotator, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueRotator::Value");

// Size: 0xb8 (Inherited: 0x188, Single: 0xffffff30)
class UBTTask_SetKeyValueStruct : public UBTTask_BlackboardBase
{
public:
    UScriptStruct* StructType; // 0x98 (Size: 0x8, Type: ObjectProperty)
    FValueOrBBKey_Struct Value; // 0xa0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueStruct) == 0xb8, "Size mismatch for UBTTask_SetKeyValueStruct");
static_assert(offsetof(UBTTask_SetKeyValueStruct, StructType) == 0x98, "Offset mismatch for UBTTask_SetKeyValueStruct::StructType");
static_assert(offsetof(UBTTask_SetKeyValueStruct, Value) == 0xa0, "Offset mismatch for UBTTask_SetKeyValueStruct::Value");

// Size: 0xb8 (Inherited: 0x188, Single: 0xffffff30)
class UBTTask_SetKeyValueVector : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Vector Value; // 0x98 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueVector) == 0xb8, "Size mismatch for UBTTask_SetKeyValueVector");
static_assert(offsetof(UBTTask_SetKeyValueVector, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueVector::Value");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCrowdAgentInterface : public UInterface
{
public:
};

static_assert(sizeof(UCrowdAgentInterface) == 0x28, "Size mismatch for UCrowdAgentInterface");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UEnvQueryTypes : public UObject
{
public:
};

static_assert(sizeof(UEnvQueryTypes) == 0x28, "Size mismatch for UEnvQueryTypes");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEQSQueryResultSourceInterface : public UInterface
{
public:
};

static_assert(sizeof(UEQSQueryResultSourceInterface) == 0x28, "Size mismatch for UEQSQueryResultSourceInterface");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class UGeneratedNavLinksProxy : public UBaseGeneratedNavLinksProxy
{
public:
    uint8_t OnSmartLinkReached[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void ReceiveSmartLinkReached(AActor*& Agent, FVector& const Destination); // 0x288a61c (Index: 0x0, Flags: RequiredAPI|Event|Public|HasDefaults|BlueprintEvent)
};

static_assert(sizeof(UGeneratedNavLinksProxy) == 0x50, "Size mismatch for UGeneratedNavLinksProxy");
static_assert(offsetof(UGeneratedNavLinksProxy, OnSmartLinkReached) == 0x40, "Offset mismatch for UGeneratedNavLinksProxy::OnSmartLinkReached");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGenericTeamAgentInterface : public UInterface
{
public:
};

static_assert(sizeof(UGenericTeamAgentInterface) == 0x28, "Size mismatch for UGenericTeamAgentInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UValueOrBBKeyBlueprintUtility : public UBlueprintFunctionLibrary
{
public:

public:
    static bool GetBool(const FValueOrBBKey_Bool Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf41320 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UClass* GetClass(const FValueOrBBKey_Class Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf414a8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static char GetEnum(const FValueOrBBKey_Enum Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf41610 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetFloat(const FValueOrBBKey_Float Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf41938 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetInt32(const FValueOrBBKey_Int32 Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf41ca8 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FName GetName(const FValueOrBBKey_Name Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf41ff8 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UObject* GetObject(const FValueOrBBKey_Object Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf42180 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FRotator GetRotator(const FValueOrBBKey_Rotator Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf424a8 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FString GetString(const FValueOrBBKey_String Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf42680 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FInstancedStruct GetStruct(const FValueOrBBKey_Struct Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf428ec (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetVector(const FValueOrBBKey_Vector Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xaf43778 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UValueOrBBKeyBlueprintUtility) == 0x28, "Size mismatch for UValueOrBBKeyBlueprintUtility");

// Size: 0x3c8 (Inherited: 0x610, Single: 0xfffffdb8)
class AAIController : public AController
{
public:
    uint8_t Pad_340[0x38]; // 0x340 (Size: 0x38, Type: PaddingProperty)
    uint8_t bStartAILogicOnPossess : 1; // 0x378:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bStopAILogicOnUnposses : 1; // 0x378:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bLOSflag : 1; // 0x378:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bSkipExtraLOSChecks : 1; // 0x378:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowStrafe : 1; // 0x378:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bWantsPlayerState : 1; // 0x378:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bSetControlRotationFromPawnOrientation : 1; // 0x378:6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_379[0x7]; // 0x379 (Size: 0x7, Type: PaddingProperty)
    UPathFollowingComponent* PathFollowingComponent; // 0x380 (Size: 0x8, Type: ObjectProperty)
    UBrainComponent* BrainComponent; // 0x388 (Size: 0x8, Type: ObjectProperty)
    UAIPerceptionComponent* PerceptionComponent; // 0x390 (Size: 0x8, Type: ObjectProperty)
    UBlackboardComponent* Blackboard; // 0x398 (Size: 0x8, Type: ObjectProperty)
    UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UClass* DefaultNavigationFilterClass; // 0x3a8 (Size: 0x8, Type: ClassProperty)
    uint8_t ReceiveMoveCompleted[0x10]; // 0x3b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3c0[0x8]; // 0x3c0 (Size: 0x8, Type: PaddingProperty)

public:
    void ClaimTaskResource(UClass*& ResourceClass); // 0xaf40f28 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    UAIPerceptionComponent* GetAIPerceptionComponent(); // 0xaf412e0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    FVector GetFocalPoint() const; // 0xaf41ac0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetFocalPointOnActor(AActor*& const Actor) const; // 0xaf41af8 (Index: 0x3, Flags: RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    AActor* GetFocusActor() const; // 0xaf41c4c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetImmediateMoveDestination() const; // 0xaf41c70 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TEnumAsByte<EPathFollowingStatus> GetMoveStatus() const; // 0xaf41fd8 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UPathFollowingComponent* GetPathFollowingComponent() const; // 0xaf422e8 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasPartialPath() const; // 0xaf43950 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void K2_ClearFocus(); // 0xaf43ab4 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void K2_SetFocalPoint(FVector& FP); // 0xaf43ad0 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void K2_SetFocus(AActor*& NewFocus); // 0xaf43bac (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    TEnumAsByte<EPathFollowingRequestResult> MoveToActor(AActor*& Goal, float& AcceptanceRadius, bool& bStopOnOverlap, bool& bUsePathfinding, bool& bCanStrafe, UClass*& FilterClass, bool& bAllowPartialPath); // 0xaf43ce0 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    TEnumAsByte<EPathFollowingRequestResult> MoveToLocation(const FVector Dest, float& AcceptanceRadius, bool& bStopOnOverlap, bool& bUsePathfinding, bool& bProjectDestinationToNavigation, bool& bCanStrafe, UClass*& FilterClass, bool& bAllowPartialPath); // 0xaf444cc (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void OnGameplayTaskResourcesClaimed(FGameplayResourceSet& NewlyClaimed, FGameplayResourceSet& FreshlyReleased); // 0xaf44b48 (Index: 0xe, Flags: RequiredAPI|Native|Public)
    bool RunBehaviorTree(UBehaviorTree*& BTAsset); // 0xaf44c88 (Index: 0x10, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetMoveBlockDetection(bool& bEnable); // 0xaf44f04 (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetPathFollowingComponent(UPathFollowingComponent*& NewPFComponent); // 0xaf4502c (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void UnclaimTaskResource(UClass*& ResourceClass); // 0xaf463f8 (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool UseBlackboard(UBlackboardData*& BlackboardAsset, UBlackboardComponent*& BlackboardComponent); // 0xaf46728 (Index: 0x14, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void OnUsingBlackBoard(UBlackboardComponent*& BlackboardComp, UBlackboardData*& BlackboardAsset); // 0x288a61c (Index: 0xf, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AAIController) == 0x3c8, "Size mismatch for AAIController");
static_assert(offsetof(AAIController, bStartAILogicOnPossess) == 0x378, "Offset mismatch for AAIController::bStartAILogicOnPossess");
static_assert(offsetof(AAIController, bStopAILogicOnUnposses) == 0x378, "Offset mismatch for AAIController::bStopAILogicOnUnposses");
static_assert(offsetof(AAIController, bLOSflag) == 0x378, "Offset mismatch for AAIController::bLOSflag");
static_assert(offsetof(AAIController, bSkipExtraLOSChecks) == 0x378, "Offset mismatch for AAIController::bSkipExtraLOSChecks");
static_assert(offsetof(AAIController, bAllowStrafe) == 0x378, "Offset mismatch for AAIController::bAllowStrafe");
static_assert(offsetof(AAIController, bWantsPlayerState) == 0x378, "Offset mismatch for AAIController::bWantsPlayerState");
static_assert(offsetof(AAIController, bSetControlRotationFromPawnOrientation) == 0x378, "Offset mismatch for AAIController::bSetControlRotationFromPawnOrientation");
static_assert(offsetof(AAIController, PathFollowingComponent) == 0x380, "Offset mismatch for AAIController::PathFollowingComponent");
static_assert(offsetof(AAIController, BrainComponent) == 0x388, "Offset mismatch for AAIController::BrainComponent");
static_assert(offsetof(AAIController, PerceptionComponent) == 0x390, "Offset mismatch for AAIController::PerceptionComponent");
static_assert(offsetof(AAIController, Blackboard) == 0x398, "Offset mismatch for AAIController::Blackboard");
static_assert(offsetof(AAIController, CachedGameplayTasksComponent) == 0x3a0, "Offset mismatch for AAIController::CachedGameplayTasksComponent");
static_assert(offsetof(AAIController, DefaultNavigationFilterClass) == 0x3a8, "Offset mismatch for AAIController::DefaultNavigationFilterClass");
static_assert(offsetof(AAIController, ReceiveMoveCompleted) == 0x3b0, "Offset mismatch for AAIController::ReceiveMoveCompleted");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UAIResource_Movement : public UGameplayTaskResource
{
public:
};

static_assert(sizeof(UAIResource_Movement) == 0x38, "Size mismatch for UAIResource_Movement");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UAIResource_Logic : public UGameplayTaskResource
{
public:
};

static_assert(sizeof(UAIResource_Logic) == 0x38, "Size mismatch for UAIResource_Logic");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UAISubsystem : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UAISystem* AISystem; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAISubsystem) == 0x38, "Size mismatch for UAISubsystem");
static_assert(offsetof(UAISubsystem, AISystem) == 0x30, "Offset mismatch for UAISubsystem::AISystem");

// Size: 0x178 (Inherited: 0x80, Single: 0xf8)
class UAISystem : public UAISystemBase
{
public:
    FSoftClassPath PerceptionSystemClassName; // 0x58 (Size: 0x18, Type: StructProperty)
    FSoftClassPath HotSpotManagerClassName; // 0x70 (Size: 0x18, Type: StructProperty)
    FSoftClassPath EnvQueryManagerClassName; // 0x88 (Size: 0x18, Type: StructProperty)
    float AcceptanceRadius; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float PathfollowingRegularPathPointAcceptanceRadius; // 0xa4 (Size: 0x4, Type: FloatProperty)
    float PathfollowingNavLinkAcceptanceRadius; // 0xa8 (Size: 0x4, Type: FloatProperty)
    bool bFinishMoveOnGoalOverlap; // 0xac (Size: 0x1, Type: BoolProperty)
    bool bAcceptPartialPaths; // 0xad (Size: 0x1, Type: BoolProperty)
    bool bAllowStrafing; // 0xae (Size: 0x1, Type: BoolProperty)
    bool bAllowControllersAsEQSQuerier; // 0xaf (Size: 0x1, Type: BoolProperty)
    bool bEnableDebuggerPlugin; // 0xb0 (Size: 0x1, Type: BoolProperty)
    bool bForgetStaleActors; // 0xb1 (Size: 0x1, Type: BoolProperty)
    bool bAddBlackboardSelfKey; // 0xb2 (Size: 0x1, Type: BoolProperty)
    bool bClearBBEntryOnBTEQSFail; // 0xb3 (Size: 0x1, Type: BoolProperty)
    bool bBlackboardKeyDecoratorAllowsNoneAsValue; // 0xb4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b5[0x3]; // 0xb5 (Size: 0x3, Type: PaddingProperty)
    TSoftObjectPtr<UBlackboardData*> DefaultBlackboard; // 0xb8 (Size: 0x20, Type: SoftObjectProperty)
    TEnumAsByte<ECollisionChannel> DefaultSightCollisionChannel; // 0xd8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d9[0x7]; // 0xd9 (Size: 0x7, Type: PaddingProperty)
    UBehaviorTreeManager* BehaviorTreeManager; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UEnvQueryManager* EnvironmentQueryManager; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAIPerceptionSystem* PerceptionSystem; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    TArray<UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    UAIHotSpotManager* HotSpotManager; // 0x108 (Size: 0x8, Type: ObjectProperty)
    UNavLocalGridManager* NavLocalGrids; // 0x110 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_118[0x60]; // 0x118 (Size: 0x60, Type: PaddingProperty)

public:
    void AIIgnorePlayers(); // 0x31f3198 (Index: 0x0, Flags: RequiredAPI|Exec|Native|Public)
    void AILoggingVerbose(); // 0x5ba16d4 (Index: 0x1, Flags: RequiredAPI|Exec|Native|Public)
};

static_assert(sizeof(UAISystem) == 0x178, "Size mismatch for UAISystem");
static_assert(offsetof(UAISystem, PerceptionSystemClassName) == 0x58, "Offset mismatch for UAISystem::PerceptionSystemClassName");
static_assert(offsetof(UAISystem, HotSpotManagerClassName) == 0x70, "Offset mismatch for UAISystem::HotSpotManagerClassName");
static_assert(offsetof(UAISystem, EnvQueryManagerClassName) == 0x88, "Offset mismatch for UAISystem::EnvQueryManagerClassName");
static_assert(offsetof(UAISystem, AcceptanceRadius) == 0xa0, "Offset mismatch for UAISystem::AcceptanceRadius");
static_assert(offsetof(UAISystem, PathfollowingRegularPathPointAcceptanceRadius) == 0xa4, "Offset mismatch for UAISystem::PathfollowingRegularPathPointAcceptanceRadius");
static_assert(offsetof(UAISystem, PathfollowingNavLinkAcceptanceRadius) == 0xa8, "Offset mismatch for UAISystem::PathfollowingNavLinkAcceptanceRadius");
static_assert(offsetof(UAISystem, bFinishMoveOnGoalOverlap) == 0xac, "Offset mismatch for UAISystem::bFinishMoveOnGoalOverlap");
static_assert(offsetof(UAISystem, bAcceptPartialPaths) == 0xad, "Offset mismatch for UAISystem::bAcceptPartialPaths");
static_assert(offsetof(UAISystem, bAllowStrafing) == 0xae, "Offset mismatch for UAISystem::bAllowStrafing");
static_assert(offsetof(UAISystem, bAllowControllersAsEQSQuerier) == 0xaf, "Offset mismatch for UAISystem::bAllowControllersAsEQSQuerier");
static_assert(offsetof(UAISystem, bEnableDebuggerPlugin) == 0xb0, "Offset mismatch for UAISystem::bEnableDebuggerPlugin");
static_assert(offsetof(UAISystem, bForgetStaleActors) == 0xb1, "Offset mismatch for UAISystem::bForgetStaleActors");
static_assert(offsetof(UAISystem, bAddBlackboardSelfKey) == 0xb2, "Offset mismatch for UAISystem::bAddBlackboardSelfKey");
static_assert(offsetof(UAISystem, bClearBBEntryOnBTEQSFail) == 0xb3, "Offset mismatch for UAISystem::bClearBBEntryOnBTEQSFail");
static_assert(offsetof(UAISystem, bBlackboardKeyDecoratorAllowsNoneAsValue) == 0xb4, "Offset mismatch for UAISystem::bBlackboardKeyDecoratorAllowsNoneAsValue");
static_assert(offsetof(UAISystem, DefaultBlackboard) == 0xb8, "Offset mismatch for UAISystem::DefaultBlackboard");
static_assert(offsetof(UAISystem, DefaultSightCollisionChannel) == 0xd8, "Offset mismatch for UAISystem::DefaultSightCollisionChannel");
static_assert(offsetof(UAISystem, BehaviorTreeManager) == 0xe0, "Offset mismatch for UAISystem::BehaviorTreeManager");
static_assert(offsetof(UAISystem, EnvironmentQueryManager) == 0xe8, "Offset mismatch for UAISystem::EnvironmentQueryManager");
static_assert(offsetof(UAISystem, PerceptionSystem) == 0xf0, "Offset mismatch for UAISystem::PerceptionSystem");
static_assert(offsetof(UAISystem, AllProxyObjects) == 0xf8, "Offset mismatch for UAISystem::AllProxyObjects");
static_assert(offsetof(UAISystem, HotSpotManager) == 0x108, "Offset mismatch for UAISystem::HotSpotManager");
static_assert(offsetof(UAISystem, NavLocalGrids) == 0x110, "Offset mismatch for UAISystem::NavLocalGrids");

// Size: 0x68 (Inherited: 0x28, Single: 0x40)
class UBehaviorTree : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UBTCompositeNode* RootNode; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UBlackboardData* BlackboardAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
    TArray<UBTDecorator*> RootDecorators; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FBTDecoratorLogic> RootDecoratorOps; // 0x50 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_60[0x8]; // 0x60 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UBehaviorTree) == 0x68, "Size mismatch for UBehaviorTree");
static_assert(offsetof(UBehaviorTree, RootNode) == 0x30, "Offset mismatch for UBehaviorTree::RootNode");
static_assert(offsetof(UBehaviorTree, BlackboardAsset) == 0x38, "Offset mismatch for UBehaviorTree::BlackboardAsset");
static_assert(offsetof(UBehaviorTree, RootDecorators) == 0x40, "Offset mismatch for UBehaviorTree::RootDecorators");
static_assert(offsetof(UBehaviorTree, RootDecoratorOps) == 0x50, "Offset mismatch for UBehaviorTree::RootDecoratorOps");

// Size: 0x2b0 (Inherited: 0x1f0, Single: 0xc0)
class UBehaviorTreeComponent : public UBrainComponent
{
public:
    uint8_t Pad_110[0x20]; // 0x110 (Size: 0x20, Type: PaddingProperty)
    TArray<UBTNode*> NodeInstances; // 0x130 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_140[0x148]; // 0x140 (Size: 0x148, Type: PaddingProperty)
    UBehaviorTree* DefaultBehaviorTreeAsset; // 0x288 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_290[0x20]; // 0x290 (Size: 0x20, Type: PaddingProperty)

public:
    void AddCooldownTagDuration(FGameplayTag& CooldownTag, float& CooldownDuration, bool& bAddToExistingDuration); // 0xaf40d78 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    double GetTagCooldownEndTime(FGameplayTag& CooldownTag) const; // 0xaf42acc (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetDynamicSubtree(FGameplayTag& InjectTag, UBehaviorTree*& BehaviorAsset); // 0xaf44dc8 (Index: 0x2, Flags: RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UBehaviorTreeComponent) == 0x2b0, "Size mismatch for UBehaviorTreeComponent");
static_assert(offsetof(UBehaviorTreeComponent, NodeInstances) == 0x130, "Offset mismatch for UBehaviorTreeComponent::NodeInstances");
static_assert(offsetof(UBehaviorTreeComponent, DefaultBehaviorTreeAsset) == 0x288, "Offset mismatch for UBehaviorTreeComponent::DefaultBehaviorTreeAsset");

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UBrainComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    UBlackboardComponent* BlackboardComp; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    AAIController* AIOwner; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x40]; // 0xd0 (Size: 0x40, Type: PaddingProperty)

public:
    bool IsPaused() const; // 0xaf6b4b0 (Index: 0x0, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRunning() const; // 0x54e573c (Index: 0x1, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RestartLogic(); // 0x270d644 (Index: 0x2, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void StartLogic(); // 0x43388fc (Index: 0x3, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void StopLogic(FString& Reason); // 0xaf6f5c0 (Index: 0x4, Flags: RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UBrainComponent) == 0x110, "Size mismatch for UBrainComponent");
static_assert(offsetof(UBrainComponent, BlackboardComp) == 0xc0, "Offset mismatch for UBrainComponent::BlackboardComp");
static_assert(offsetof(UBrainComponent, AIOwner) == 0xc8, "Offset mismatch for UBrainComponent::AIOwner");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UBehaviorTreeManager : public UObject
{
public:
    int32_t MaxDebuggerSteps; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<FBehaviorTreeTemplateInfo> LoadedTemplates; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<UBehaviorTreeComponent*> ActiveComponents; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UBehaviorTreeManager) == 0x50, "Size mismatch for UBehaviorTreeManager");
static_assert(offsetof(UBehaviorTreeManager, MaxDebuggerSteps) == 0x28, "Offset mismatch for UBehaviorTreeManager::MaxDebuggerSteps");
static_assert(offsetof(UBehaviorTreeManager, LoadedTemplates) == 0x30, "Offset mismatch for UBehaviorTreeManager::LoadedTemplates");
static_assert(offsetof(UBehaviorTreeManager, ActiveComponents) == 0x40, "Offset mismatch for UBehaviorTreeManager::ActiveComponents");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UBehaviorTreeTypes : public UObject
{
public:
};

static_assert(sizeof(UBehaviorTreeTypes) == 0x28, "Size mismatch for UBehaviorTreeTypes");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlackboardAssetProvider : public UInterface
{
public:

public:
    UBlackboardData* GetBlackboardAsset() const; // 0xaf412f8 (Index: 0x0, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBlackboardAssetProvider) == 0x28, "Size mismatch for UBlackboardAssetProvider");

// Size: 0x1c0 (Inherited: 0xe0, Single: 0xe0)
class UBlackboardComponent : public UActorComponent
{
public:
    UBrainComponent* BrainComp; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UBlackboardData* DefaultBlackboardAsset; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UBlackboardData* BlackboardAsset; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x20]; // 0xd0 (Size: 0x20, Type: PaddingProperty)
    TArray<UBlackboardKeyType*> KeyInstances; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_100[0xc0]; // 0x100 (Size: 0xc0, Type: PaddingProperty)

public:
    void ClearValue(const FName KeyName); // 0xaf411fc (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    bool GetLocationFromEntry(const FName KeyName, FVector& ResultLocation) const; // 0xaf41e30 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool GetRotationFromEntry(const FName KeyName, FRotator& ResultRotation) const; // 0xaf42300 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool GetValueAsBool(const FName KeyName) const; // 0xaf42bec (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UClass* GetValueAsClass(const FName KeyName) const; // 0xaf42ce0 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    char GetValueAsEnum(const FName KeyName) const; // 0xaf42dd8 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    float GetValueAsFloat(const FName KeyName) const; // 0xaf42ed0 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetValueAsInt(const FName KeyName) const; // 0xaf42fc8 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FName GetValueAsName(const FName KeyName) const; // 0xaf430c0 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UObject* GetValueAsObject(const FName KeyName) const; // 0xaf431c4 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FRotator GetValueAsRotator(const FName KeyName) const; // 0xaf432b8 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FString GetValueAsString(const FName KeyName) const; // 0xaf433c4 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FVector GetValueAsVector(const FName KeyName) const; // 0xaf4366c (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsVectorValueSet(const FName KeyName) const; // 0xaf4398c (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void SetValueAsBool(const FName KeyName, bool& BoolValue); // 0xaf45304 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsClass(const FName KeyName, UClass*& ClassValue); // 0xaf45474 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsEnum(const FName KeyName, char& EnumValue); // 0xaf45600 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsFloat(const FName KeyName, float& FloatValue); // 0xaf45788 (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsInt(const FName KeyName, int32_t& IntValue); // 0xaf458f8 (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsName(const FName KeyName, FName& NameValue); // 0xaf45a80 (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsObject(const FName KeyName, UObject*& ObjectValue); // 0xaf45c08 (Index: 0x14, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsRotator(const FName KeyName, FRotator& VectorValue); // 0xaf45d78 (Index: 0x15, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetValueAsString(const FName KeyName, FString& StringValue); // 0xaf45ef8 (Index: 0x16, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetValueAsVector(const FName KeyName, FVector& VectorValue); // 0xaf46278 (Index: 0x17, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UBlackboardComponent) == 0x1c0, "Size mismatch for UBlackboardComponent");
static_assert(offsetof(UBlackboardComponent, BrainComp) == 0xb8, "Offset mismatch for UBlackboardComponent::BrainComp");
static_assert(offsetof(UBlackboardComponent, DefaultBlackboardAsset) == 0xc0, "Offset mismatch for UBlackboardComponent::DefaultBlackboardAsset");
static_assert(offsetof(UBlackboardComponent, BlackboardAsset) == 0xc8, "Offset mismatch for UBlackboardComponent::BlackboardAsset");
static_assert(offsetof(UBlackboardComponent, KeyInstances) == 0xf0, "Offset mismatch for UBlackboardComponent::KeyInstances");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardData : public UDataAsset
{
public:
    UBlackboardData* Parent; // 0x30 (Size: 0x8, Type: ObjectProperty)
    TArray<FBlackboardEntry> Keys; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t bHasSynchronizedKeys : 1; // 0x48:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardData) == 0x50, "Size mismatch for UBlackboardData");
static_assert(offsetof(UBlackboardData, Parent) == 0x30, "Offset mismatch for UBlackboardData::Parent");
static_assert(offsetof(UBlackboardData, Keys) == 0x38, "Offset mismatch for UBlackboardData::Keys");
static_assert(offsetof(UBlackboardData, bHasSynchronizedKeys) == 0x48, "Offset mismatch for UBlackboardData::bHasSynchronizedKeys");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UBlackboardKeyType_Bool : public UBlackboardKeyType
{
public:
    bool bDefaultValue; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Bool) == 0x38, "Size mismatch for UBlackboardKeyType_Bool");
static_assert(offsetof(UBlackboardKeyType_Bool, bDefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Bool::bDefaultValue");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UBlackboardKeyType_Class : public UBlackboardKeyType
{
public:
    UClass* BaseClass; // 0x30 (Size: 0x8, Type: ClassProperty)
    UClass* DefaultValue; // 0x38 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UBlackboardKeyType_Class) == 0x40, "Size mismatch for UBlackboardKeyType_Class");
static_assert(offsetof(UBlackboardKeyType_Class, BaseClass) == 0x30, "Offset mismatch for UBlackboardKeyType_Class::BaseClass");
static_assert(offsetof(UBlackboardKeyType_Class, DefaultValue) == 0x38, "Offset mismatch for UBlackboardKeyType_Class::DefaultValue");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardKeyType_Enum : public UBlackboardKeyType
{
public:
    UEnum* EnumType; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FString EnumName; // 0x38 (Size: 0x10, Type: StrProperty)
    char DefaultValue; // 0x48 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    uint8_t bIsEnumNameValid : 1; // 0x4c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Enum) == 0x50, "Size mismatch for UBlackboardKeyType_Enum");
static_assert(offsetof(UBlackboardKeyType_Enum, EnumType) == 0x30, "Offset mismatch for UBlackboardKeyType_Enum::EnumType");
static_assert(offsetof(UBlackboardKeyType_Enum, EnumName) == 0x38, "Offset mismatch for UBlackboardKeyType_Enum::EnumName");
static_assert(offsetof(UBlackboardKeyType_Enum, DefaultValue) == 0x48, "Offset mismatch for UBlackboardKeyType_Enum::DefaultValue");
static_assert(offsetof(UBlackboardKeyType_Enum, bIsEnumNameValid) == 0x4c, "Offset mismatch for UBlackboardKeyType_Enum::bIsEnumNameValid");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UBlackboardKeyType_Float : public UBlackboardKeyType
{
public:
    float DefaultValue; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Float) == 0x38, "Size mismatch for UBlackboardKeyType_Float");
static_assert(offsetof(UBlackboardKeyType_Float, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Float::DefaultValue");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UBlackboardKeyType_Int : public UBlackboardKeyType
{
public:
    int32_t DefaultValue; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Int) == 0x38, "Size mismatch for UBlackboardKeyType_Int");
static_assert(offsetof(UBlackboardKeyType_Int, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Int::DefaultValue");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UBlackboardKeyType_Name : public UBlackboardKeyType
{
public:
    FName DefaultValue; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Name) == 0x38, "Size mismatch for UBlackboardKeyType_Name");
static_assert(offsetof(UBlackboardKeyType_Name, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Name::DefaultValue");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UBlackboardKeyType_NativeEnum : public UBlackboardKeyType
{
public:
    FString EnumName; // 0x30 (Size: 0x10, Type: StrProperty)
    UEnum* EnumType; // 0x40 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBlackboardKeyType_NativeEnum) == 0x48, "Size mismatch for UBlackboardKeyType_NativeEnum");
static_assert(offsetof(UBlackboardKeyType_NativeEnum, EnumName) == 0x30, "Offset mismatch for UBlackboardKeyType_NativeEnum::EnumName");
static_assert(offsetof(UBlackboardKeyType_NativeEnum, EnumType) == 0x40, "Offset mismatch for UBlackboardKeyType_NativeEnum::EnumType");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UBlackboardKeyType_Object : public UBlackboardKeyType
{
public:
    UClass* BaseClass; // 0x30 (Size: 0x8, Type: ClassProperty)
    UObject* DefaultValue; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBlackboardKeyType_Object) == 0x40, "Size mismatch for UBlackboardKeyType_Object");
static_assert(offsetof(UBlackboardKeyType_Object, BaseClass) == 0x30, "Offset mismatch for UBlackboardKeyType_Object::BaseClass");
static_assert(offsetof(UBlackboardKeyType_Object, DefaultValue) == 0x38, "Offset mismatch for UBlackboardKeyType_Object::DefaultValue");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardKeyType_Rotator : public UBlackboardKeyType
{
public:
    FRotator DefaultValue; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bUseDefaultValue; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Rotator) == 0x50, "Size mismatch for UBlackboardKeyType_Rotator");
static_assert(offsetof(UBlackboardKeyType_Rotator, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Rotator::DefaultValue");
static_assert(offsetof(UBlackboardKeyType_Rotator, bUseDefaultValue) == 0x48, "Offset mismatch for UBlackboardKeyType_Rotator::bUseDefaultValue");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardKeyType_String : public UBlackboardKeyType
{
public:
    FString StringValue; // 0x30 (Size: 0x10, Type: StrProperty)
    FString DefaultValue; // 0x40 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UBlackboardKeyType_String) == 0x50, "Size mismatch for UBlackboardKeyType_String");
static_assert(offsetof(UBlackboardKeyType_String, StringValue) == 0x30, "Offset mismatch for UBlackboardKeyType_String::StringValue");
static_assert(offsetof(UBlackboardKeyType_String, DefaultValue) == 0x40, "Offset mismatch for UBlackboardKeyType_String::DefaultValue");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardKeyType_Vector : public UBlackboardKeyType
{
public:
    FVector DefaultValue; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bUseDefaultValue; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBlackboardKeyType_Vector) == 0x50, "Size mismatch for UBlackboardKeyType_Vector");
static_assert(offsetof(UBlackboardKeyType_Vector, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_Vector::DefaultValue");
static_assert(offsetof(UBlackboardKeyType_Vector, bUseDefaultValue) == 0x48, "Offset mismatch for UBlackboardKeyType_Vector::bUseDefaultValue");

// Size: 0x60 (Inherited: 0x80, Single: 0xffffffe0)
class UBTAuxiliaryNode : public UBTNode
{
public:
};

static_assert(sizeof(UBTAuxiliaryNode) == 0x60, "Size mismatch for UBTAuxiliaryNode");

// Size: 0x80 (Inherited: 0x80, Single: 0x0)
class UBTCompositeNode : public UBTNode
{
public:
    TArray<FBTCompositeChild> Children; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<UBTService*> Services; // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t bApplyDecoratorScope : 1; // 0x78:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBTCompositeNode) == 0x80, "Size mismatch for UBTCompositeNode");
static_assert(offsetof(UBTCompositeNode, Children) == 0x58, "Offset mismatch for UBTCompositeNode::Children");
static_assert(offsetof(UBTCompositeNode, Services) == 0x68, "Offset mismatch for UBTCompositeNode::Services");
static_assert(offsetof(UBTCompositeNode, bApplyDecoratorScope) == 0x78, "Offset mismatch for UBTCompositeNode::bApplyDecoratorScope");

// Size: 0x68 (Inherited: 0xe0, Single: 0xffffff88)
class UBTDecorator : public UBTAuxiliaryNode
{
public:
    uint8_t bInverseCondition : 1; // 0x60:7 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x3]; // 0x61 (Size: 0x3, Type: PaddingProperty)
    TEnumAsByte<EBTFlowAbortMode> FlowAbortMode; // 0x64 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_65[0x3]; // 0x65 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator) == 0x68, "Size mismatch for UBTDecorator");
static_assert(offsetof(UBTDecorator, bInverseCondition) == 0x60, "Offset mismatch for UBTDecorator::bInverseCondition");
static_assert(offsetof(UBTDecorator, FlowAbortMode) == 0x64, "Offset mismatch for UBTDecorator::FlowAbortMode");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBTFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void ClearBlackboardValue(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf67808 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ClearBlackboardValueAsVector(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf67808 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static AActor* GetBlackboardValueAsActor(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf68278 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetBlackboardValueAsBool(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf6860c (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UClass* GetBlackboardValueAsClass(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf689a0 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static char GetBlackboardValueAsEnum(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf68d3c (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetBlackboardValueAsFloat(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf690d8 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetBlackboardValueAsInt(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf69478 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FName GetBlackboardValueAsName(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf69814 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UObject* GetBlackboardValueAsObject(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf69b90 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FRotator GetBlackboardValueAsRotator(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf69f10 (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FString GetBlackboardValueAsString(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf6a2b4 (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetBlackboardValueAsVector(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xaf6a6b8 (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static UBehaviorTreeComponent* GetOwnerComponent(UBTNode*& NodeOwner); // 0xaf6b174 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UBlackboardComponent* GetOwnersBlackboard(UBTNode*& NodeOwner); // 0xaf6b2a8 (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void SetBlackboardValueAsBool(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, bool& Value); // 0xaf6bfb4 (Index: 0xf, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsClass(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, UClass*& Value); // 0xaf6c39c (Index: 0x10, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsEnum(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, char& Value); // 0xaf6c798 (Index: 0x11, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsFloat(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, float& Value); // 0xaf6cb80 (Index: 0x12, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsInt(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, int32_t& Value); // 0xaf6cf58 (Index: 0x13, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsName(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, FName& Value); // 0xaf6d354 (Index: 0x14, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsObject(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, UObject*& Value); // 0xaf6d750 (Index: 0x15, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsRotator(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, FRotator& Value); // 0xaf6db38 (Index: 0x16, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetBlackboardValueAsString(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, FString& Value); // 0xaf6df64 (Index: 0x17, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsVector(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, FVector& Value); // 0xaf6e3d4 (Index: 0x18, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void StartUsingExternalEvent(UBTNode*& NodeOwner, AActor*& OwningActor); // 0xa93bc70 (Index: 0x19, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void StopUsingExternalEvent(UBTNode*& NodeOwner); // 0x6023a08 (Index: 0x1a, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UBTFunctionLibrary) == 0x28, "Size mismatch for UBTFunctionLibrary");

// Size: 0x70 (Inherited: 0xe0, Single: 0xffffff90)
class UBTService : public UBTAuxiliaryNode
{
public:
    float Interval; // 0x60 (Size: 0x4, Type: FloatProperty)
    float RandomDeviation; // 0x64 (Size: 0x4, Type: FloatProperty)
    uint8_t bCallTickOnSearchStart : 1; // 0x68:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bRestartTimerOnEachActivation : 1; // 0x68:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBTService) == 0x70, "Size mismatch for UBTService");
static_assert(offsetof(UBTService, Interval) == 0x60, "Offset mismatch for UBTService::Interval");
static_assert(offsetof(UBTService, RandomDeviation) == 0x64, "Offset mismatch for UBTService::RandomDeviation");
static_assert(offsetof(UBTService, bCallTickOnSearchStart) == 0x68, "Offset mismatch for UBTService::bCallTickOnSearchStart");
static_assert(offsetof(UBTService, bRestartTimerOnEachActivation) == 0x68, "Offset mismatch for UBTService::bRestartTimerOnEachActivation");

// Size: 0x80 (Inherited: 0x100, Single: 0xffffff80)
class UBTComposite_Selector : public UBTCompositeNode
{
public:
};

static_assert(sizeof(UBTComposite_Selector) == 0x80, "Size mismatch for UBTComposite_Selector");

// Size: 0x80 (Inherited: 0x100, Single: 0xffffff80)
class UBTComposite_Sequence : public UBTCompositeNode
{
public:
};

static_assert(sizeof(UBTComposite_Sequence) == 0x80, "Size mismatch for UBTComposite_Sequence");

// Size: 0x88 (Inherited: 0x100, Single: 0xffffff88)
class UBTComposite_SimpleParallel : public UBTCompositeNode
{
public:
    TEnumAsByte<EBTParallelMode> FinishMode; // 0x80 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBTComposite_SimpleParallel) == 0x88, "Size mismatch for UBTComposite_SimpleParallel");
static_assert(offsetof(UBTComposite_SimpleParallel, FinishMode) == 0x80, "Offset mismatch for UBTComposite_SimpleParallel::FinishMode");

// Size: 0xc0 (Inherited: 0x1d8, Single: 0xfffffee8)
class UBTDecorator_Blackboard : public UBTDecorator_BlackboardBase
{
public:
    int32_t IntValue; // 0x90 (Size: 0x4, Type: IntProperty)
    float FloatValue; // 0x94 (Size: 0x4, Type: FloatProperty)
    FString StringValue; // 0x98 (Size: 0x10, Type: StrProperty)
    FString CachedDescription; // 0xa8 (Size: 0x10, Type: StrProperty)
    char OperationType; // 0xb8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBTBlackboardRestart> NotifyObserver; // 0xb9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_ba[0x6]; // 0xba (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator_Blackboard) == 0xc0, "Size mismatch for UBTDecorator_Blackboard");
static_assert(offsetof(UBTDecorator_Blackboard, IntValue) == 0x90, "Offset mismatch for UBTDecorator_Blackboard::IntValue");
static_assert(offsetof(UBTDecorator_Blackboard, FloatValue) == 0x94, "Offset mismatch for UBTDecorator_Blackboard::FloatValue");
static_assert(offsetof(UBTDecorator_Blackboard, StringValue) == 0x98, "Offset mismatch for UBTDecorator_Blackboard::StringValue");
static_assert(offsetof(UBTDecorator_Blackboard, CachedDescription) == 0xa8, "Offset mismatch for UBTDecorator_Blackboard::CachedDescription");
static_assert(offsetof(UBTDecorator_Blackboard, OperationType) == 0xb8, "Offset mismatch for UBTDecorator_Blackboard::OperationType");
static_assert(offsetof(UBTDecorator_Blackboard, NotifyObserver) == 0xb9, "Offset mismatch for UBTDecorator_Blackboard::NotifyObserver");

// Size: 0x90 (Inherited: 0x148, Single: 0xffffff48)
class UBTDecorator_BlackboardBase : public UBTDecorator
{
public:
    FBlackboardKeySelector BlackboardKey; // 0x68 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_BlackboardBase) == 0x90, "Size mismatch for UBTDecorator_BlackboardBase");
static_assert(offsetof(UBTDecorator_BlackboardBase, BlackboardKey) == 0x68, "Offset mismatch for UBTDecorator_BlackboardBase::BlackboardKey");

// Size: 0xa0 (Inherited: 0x148, Single: 0xffffff58)
class UBTDecorator_BlueprintBase : public UBTDecorator
{
public:
    AAIController* AIOwner; // 0x68 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorOwner; // 0x70 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> ObservedKeyNames; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)
    uint8_t bShowPropertyDetails : 1; // 0x98:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCheckConditionOnlyBlackBoardChanges : 1; // 0x98:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)

protected:
    bool IsDecoratorExecutionActive() const; // 0xaf6b3d0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsDecoratorObserverActive() const; // 0xaf6b448 (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual bool PerformConditionCheck(AActor*& OwnerActor); // 0x288a61c (Index: 0x2, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual bool PerformConditionCheckAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x3, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveExecutionFinish(AActor*& OwnerActor, TEnumAsByte<EBTNodeResult>& NodeResult); // 0x288a61c (Index: 0x4, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveExecutionFinishAI(AAIController*& OwnerController, APawn*& ControlledPawn, TEnumAsByte<EBTNodeResult>& NodeResult); // 0x288a61c (Index: 0x5, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveExecutionStart(AActor*& OwnerActor); // 0x288a61c (Index: 0x6, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveExecutionStartAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x7, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveObserverActivated(AActor*& OwnerActor); // 0x288a61c (Index: 0x8, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveObserverActivatedAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x9, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveObserverDeactivated(AActor*& OwnerActor); // 0x288a61c (Index: 0xa, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveObserverDeactivatedAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0xb, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveTick(AActor*& OwnerActor, float& DeltaSeconds); // 0x288a61c (Index: 0xc, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveTickAI(AAIController*& OwnerController, APawn*& ControlledPawn, float& DeltaSeconds); // 0x288a61c (Index: 0xd, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBTDecorator_BlueprintBase) == 0xa0, "Size mismatch for UBTDecorator_BlueprintBase");
static_assert(offsetof(UBTDecorator_BlueprintBase, AIOwner) == 0x68, "Offset mismatch for UBTDecorator_BlueprintBase::AIOwner");
static_assert(offsetof(UBTDecorator_BlueprintBase, ActorOwner) == 0x70, "Offset mismatch for UBTDecorator_BlueprintBase::ActorOwner");
static_assert(offsetof(UBTDecorator_BlueprintBase, ObservedKeyNames) == 0x78, "Offset mismatch for UBTDecorator_BlueprintBase::ObservedKeyNames");
static_assert(offsetof(UBTDecorator_BlueprintBase, bShowPropertyDetails) == 0x98, "Offset mismatch for UBTDecorator_BlueprintBase::bShowPropertyDetails");
static_assert(offsetof(UBTDecorator_BlueprintBase, bCheckConditionOnlyBlackBoardChanges) == 0x98, "Offset mismatch for UBTDecorator_BlueprintBase::bCheckConditionOnlyBlackBoardChanges");

// Size: 0xc8 (Inherited: 0x148, Single: 0xffffff80)
class UBTDecorator_CheckGameplayTagsOnActor : public UBTDecorator
{
public:
    FBlackboardKeySelector ActorToCheck; // 0x68 (Size: 0x28, Type: StructProperty)
    uint8_t TagsToMatch; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer GameplayTags; // 0x98 (Size: 0x20, Type: StructProperty)
    FString CachedDescription; // 0xb8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UBTDecorator_CheckGameplayTagsOnActor) == 0xc8, "Size mismatch for UBTDecorator_CheckGameplayTagsOnActor");
static_assert(offsetof(UBTDecorator_CheckGameplayTagsOnActor, ActorToCheck) == 0x68, "Offset mismatch for UBTDecorator_CheckGameplayTagsOnActor::ActorToCheck");
static_assert(offsetof(UBTDecorator_CheckGameplayTagsOnActor, TagsToMatch) == 0x90, "Offset mismatch for UBTDecorator_CheckGameplayTagsOnActor::TagsToMatch");
static_assert(offsetof(UBTDecorator_CheckGameplayTagsOnActor, GameplayTags) == 0x98, "Offset mismatch for UBTDecorator_CheckGameplayTagsOnActor::GameplayTags");
static_assert(offsetof(UBTDecorator_CheckGameplayTagsOnActor, CachedDescription) == 0xb8, "Offset mismatch for UBTDecorator_CheckGameplayTagsOnActor::CachedDescription");

// Size: 0xc0 (Inherited: 0x148, Single: 0xffffff78)
class UBTDecorator_CompareBBEntries : public UBTDecorator
{
public:
    TEnumAsByte<EBlackBoardEntryComparison> Operator; // 0x68 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
    FBlackboardKeySelector BlackboardKeyA; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB; // 0x98 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_CompareBBEntries) == 0xc0, "Size mismatch for UBTDecorator_CompareBBEntries");
static_assert(offsetof(UBTDecorator_CompareBBEntries, Operator) == 0x68, "Offset mismatch for UBTDecorator_CompareBBEntries::Operator");
static_assert(offsetof(UBTDecorator_CompareBBEntries, BlackboardKeyA) == 0x70, "Offset mismatch for UBTDecorator_CompareBBEntries::BlackboardKeyA");
static_assert(offsetof(UBTDecorator_CompareBBEntries, BlackboardKeyB) == 0x98, "Offset mismatch for UBTDecorator_CompareBBEntries::BlackboardKeyB");

// Size: 0xc0 (Inherited: 0x298, Single: 0xfffffe28)
class UBTDecorator_ConditionalLoop : public UBTDecorator_Blackboard
{
public:
};

static_assert(sizeof(UBTDecorator_ConditionalLoop) == 0xc0, "Size mismatch for UBTDecorator_ConditionalLoop");

// Size: 0xf0 (Inherited: 0x148, Single: 0xffffffa8)
class UBTDecorator_ConeCheck : public UBTDecorator
{
public:
    FValueOrBBKey_Float ConeHalfAngle; // 0x68 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FBlackboardKeySelector ConeOrigin; // 0x78 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector ConeDirection; // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector Observed; // 0xc8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_ConeCheck) == 0xf0, "Size mismatch for UBTDecorator_ConeCheck");
static_assert(offsetof(UBTDecorator_ConeCheck, ConeHalfAngle) == 0x68, "Offset mismatch for UBTDecorator_ConeCheck::ConeHalfAngle");
static_assert(offsetof(UBTDecorator_ConeCheck, ConeOrigin) == 0x78, "Offset mismatch for UBTDecorator_ConeCheck::ConeOrigin");
static_assert(offsetof(UBTDecorator_ConeCheck, ConeDirection) == 0xa0, "Offset mismatch for UBTDecorator_ConeCheck::ConeDirection");
static_assert(offsetof(UBTDecorator_ConeCheck, Observed) == 0xc8, "Offset mismatch for UBTDecorator_ConeCheck::Observed");

// Size: 0x78 (Inherited: 0x148, Single: 0xffffff30)
class UBTDecorator_Cooldown : public UBTDecorator
{
public:
    FValueOrBBKey_Float CooldownTime; // 0x68 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator_Cooldown) == 0x78, "Size mismatch for UBTDecorator_Cooldown");
static_assert(offsetof(UBTDecorator_Cooldown, CooldownTime) == 0x68, "Offset mismatch for UBTDecorator_Cooldown::CooldownTime");

// Size: 0x100 (Inherited: 0x148, Single: 0xffffffb8)
class UBTDecorator_DoesPathExist : public UBTDecorator
{
public:
    FBlackboardKeySelector BlackboardKeyA; // 0x68 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB; // 0x90 (Size: 0x28, Type: StructProperty)
    uint8_t bUseSelf : 1; // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    FValueOrBBKey_Enum PathQueryType; // 0xc0 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Class FilterClass; // 0xe8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_DoesPathExist) == 0x100, "Size mismatch for UBTDecorator_DoesPathExist");
static_assert(offsetof(UBTDecorator_DoesPathExist, BlackboardKeyA) == 0x68, "Offset mismatch for UBTDecorator_DoesPathExist::BlackboardKeyA");
static_assert(offsetof(UBTDecorator_DoesPathExist, BlackboardKeyB) == 0x90, "Offset mismatch for UBTDecorator_DoesPathExist::BlackboardKeyB");
static_assert(offsetof(UBTDecorator_DoesPathExist, bUseSelf) == 0xb8, "Offset mismatch for UBTDecorator_DoesPathExist::bUseSelf");
static_assert(offsetof(UBTDecorator_DoesPathExist, PathQueryType) == 0xc0, "Offset mismatch for UBTDecorator_DoesPathExist::PathQueryType");
static_assert(offsetof(UBTDecorator_DoesPathExist, FilterClass) == 0xe8, "Offset mismatch for UBTDecorator_DoesPathExist::FilterClass");

// Size: 0x68 (Inherited: 0x148, Single: 0xffffff20)
class UBTDecorator_ForceSuccess : public UBTDecorator
{
public:
};

static_assert(sizeof(UBTDecorator_ForceSuccess) == 0x68, "Size mismatch for UBTDecorator_ForceSuccess");

// Size: 0xf0 (Inherited: 0x1d8, Single: 0xffffff18)
class UBTDecorator_IsAtLocation : public UBTDecorator_BlackboardBase
{
public:
    float AcceptableRadius; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FAIDataProviderFloatValue ParametrizedAcceptableRadius; // 0x98 (Size: 0x38, Type: StructProperty)
    uint8_t GeometricDistanceType; // 0xd0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d1[0x3]; // 0xd1 (Size: 0x3, Type: PaddingProperty)
    uint8_t bUseParametrizedRadius : 1; // 0xd4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d5[0x3]; // 0xd5 (Size: 0x3, Type: PaddingProperty)
    FValueOrBBKey_Bool bUseNavAgentGoalLocation; // 0xd8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bPathFindingBasedTest; // 0xe4 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_IsAtLocation) == 0xf0, "Size mismatch for UBTDecorator_IsAtLocation");
static_assert(offsetof(UBTDecorator_IsAtLocation, AcceptableRadius) == 0x90, "Offset mismatch for UBTDecorator_IsAtLocation::AcceptableRadius");
static_assert(offsetof(UBTDecorator_IsAtLocation, ParametrizedAcceptableRadius) == 0x98, "Offset mismatch for UBTDecorator_IsAtLocation::ParametrizedAcceptableRadius");
static_assert(offsetof(UBTDecorator_IsAtLocation, GeometricDistanceType) == 0xd0, "Offset mismatch for UBTDecorator_IsAtLocation::GeometricDistanceType");
static_assert(offsetof(UBTDecorator_IsAtLocation, bUseParametrizedRadius) == 0xd4, "Offset mismatch for UBTDecorator_IsAtLocation::bUseParametrizedRadius");
static_assert(offsetof(UBTDecorator_IsAtLocation, bUseNavAgentGoalLocation) == 0xd8, "Offset mismatch for UBTDecorator_IsAtLocation::bUseNavAgentGoalLocation");
static_assert(offsetof(UBTDecorator_IsAtLocation, bPathFindingBasedTest) == 0xe4, "Offset mismatch for UBTDecorator_IsAtLocation::bPathFindingBasedTest");

// Size: 0xa8 (Inherited: 0x1d8, Single: 0xfffffed0)
class UBTDecorator_IsBBEntryOfClass : public UBTDecorator_BlackboardBase
{
public:
    FValueOrBBKey_Class TestClass; // 0x90 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_IsBBEntryOfClass) == 0xa8, "Size mismatch for UBTDecorator_IsBBEntryOfClass");
static_assert(offsetof(UBTDecorator_IsBBEntryOfClass, TestClass) == 0x90, "Offset mismatch for UBTDecorator_IsBBEntryOfClass::TestClass");

// Size: 0xd0 (Inherited: 0x148, Single: 0xffffff88)
class UBTDecorator_KeepInCone : public UBTDecorator
{
public:
    FValueOrBBKey_Float ConeHalfAngle; // 0x68 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FBlackboardKeySelector ConeOrigin; // 0x78 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector Observed; // 0xa0 (Size: 0x28, Type: StructProperty)
    uint8_t bUseSelfAsOrigin : 1; // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseSelfAsObserved : 1; // 0xc8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator_KeepInCone) == 0xd0, "Size mismatch for UBTDecorator_KeepInCone");
static_assert(offsetof(UBTDecorator_KeepInCone, ConeHalfAngle) == 0x68, "Offset mismatch for UBTDecorator_KeepInCone::ConeHalfAngle");
static_assert(offsetof(UBTDecorator_KeepInCone, ConeOrigin) == 0x78, "Offset mismatch for UBTDecorator_KeepInCone::ConeOrigin");
static_assert(offsetof(UBTDecorator_KeepInCone, Observed) == 0xa0, "Offset mismatch for UBTDecorator_KeepInCone::Observed");
static_assert(offsetof(UBTDecorator_KeepInCone, bUseSelfAsOrigin) == 0xc8, "Offset mismatch for UBTDecorator_KeepInCone::bUseSelfAsOrigin");
static_assert(offsetof(UBTDecorator_KeepInCone, bUseSelfAsObserved) == 0xc8, "Offset mismatch for UBTDecorator_KeepInCone::bUseSelfAsObserved");

// Size: 0x88 (Inherited: 0x148, Single: 0xffffff40)
class UBTDecorator_Loop : public UBTDecorator
{
public:
    FValueOrBBKey_Int32 NumLoops; // 0x68 (Size: 0xc, Type: StructProperty)
    bool bInfiniteLoop; // 0x74 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_75[0x3]; // 0x75 (Size: 0x3, Type: PaddingProperty)
    FValueOrBBKey_Float InfiniteLoopTimeoutTime; // 0x78 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator_Loop) == 0x88, "Size mismatch for UBTDecorator_Loop");
static_assert(offsetof(UBTDecorator_Loop, NumLoops) == 0x68, "Offset mismatch for UBTDecorator_Loop::NumLoops");
static_assert(offsetof(UBTDecorator_Loop, bInfiniteLoop) == 0x74, "Offset mismatch for UBTDecorator_Loop::bInfiniteLoop");
static_assert(offsetof(UBTDecorator_Loop, InfiniteLoopTimeoutTime) == 0x78, "Offset mismatch for UBTDecorator_Loop::InfiniteLoopTimeoutTime");

// Size: 0x68 (Inherited: 0x148, Single: 0xffffff20)
class UBTDecorator_ReachedMoveGoal : public UBTDecorator
{
public:
};

static_assert(sizeof(UBTDecorator_ReachedMoveGoal) == 0x68, "Size mismatch for UBTDecorator_ReachedMoveGoal");

// Size: 0x88 (Inherited: 0x148, Single: 0xffffff40)
class UBTDecorator_SetTagCooldown : public UBTDecorator
{
public:
    FGameplayTag CooldownTag; // 0x68 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration; // 0x6c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAddToExistingDuration; // 0x78 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator_SetTagCooldown) == 0x88, "Size mismatch for UBTDecorator_SetTagCooldown");
static_assert(offsetof(UBTDecorator_SetTagCooldown, CooldownTag) == 0x68, "Offset mismatch for UBTDecorator_SetTagCooldown::CooldownTag");
static_assert(offsetof(UBTDecorator_SetTagCooldown, CooldownDuration) == 0x6c, "Offset mismatch for UBTDecorator_SetTagCooldown::CooldownDuration");
static_assert(offsetof(UBTDecorator_SetTagCooldown, bAddToExistingDuration) == 0x78, "Offset mismatch for UBTDecorator_SetTagCooldown::bAddToExistingDuration");

// Size: 0x90 (Inherited: 0x148, Single: 0xffffff48)
class UBTDecorator_TagCooldown : public UBTDecorator
{
public:
    FGameplayTag CooldownTag; // 0x68 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration; // 0x6c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAddToExistingDuration; // 0x78 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bActivatesCooldown; // 0x84 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UBTDecorator_TagCooldown) == 0x90, "Size mismatch for UBTDecorator_TagCooldown");
static_assert(offsetof(UBTDecorator_TagCooldown, CooldownTag) == 0x68, "Offset mismatch for UBTDecorator_TagCooldown::CooldownTag");
static_assert(offsetof(UBTDecorator_TagCooldown, CooldownDuration) == 0x6c, "Offset mismatch for UBTDecorator_TagCooldown::CooldownDuration");
static_assert(offsetof(UBTDecorator_TagCooldown, bAddToExistingDuration) == 0x78, "Offset mismatch for UBTDecorator_TagCooldown::bAddToExistingDuration");
static_assert(offsetof(UBTDecorator_TagCooldown, bActivatesCooldown) == 0x84, "Offset mismatch for UBTDecorator_TagCooldown::bActivatesCooldown");

// Size: 0x78 (Inherited: 0x148, Single: 0xffffff30)
class UBTDecorator_TimeLimit : public UBTDecorator
{
public:
    FValueOrBBKey_Float TimeLimit; // 0x68 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTDecorator_TimeLimit) == 0x78, "Size mismatch for UBTDecorator_TimeLimit");
static_assert(offsetof(UBTDecorator_TimeLimit, TimeLimit) == 0x68, "Offset mismatch for UBTDecorator_TimeLimit::TimeLimit");

// Size: 0x98 (Inherited: 0x150, Single: 0xffffff48)
class UBTService_BlackboardBase : public UBTService
{
public:
    FBlackboardKeySelector BlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTService_BlackboardBase) == 0x98, "Size mismatch for UBTService_BlackboardBase");
static_assert(offsetof(UBTService_BlackboardBase, BlackboardKey) == 0x70, "Offset mismatch for UBTService_BlackboardBase::BlackboardKey");

// Size: 0x98 (Inherited: 0x150, Single: 0xffffff48)
class UBTService_BlueprintBase : public UBTService
{
public:
    AAIController* AIOwner; // 0x70 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorOwner; // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_80[0x10]; // 0x80 (Size: 0x10, Type: PaddingProperty)
    uint8_t bShowPropertyDetails : 1; // 0x90:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bShowEventDetails : 1; // 0x90:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)

protected:
    bool IsServiceActive() const; // 0xaf6b4d8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void ReceiveActivation(AActor*& OwnerActor); // 0x288a61c (Index: 0x1, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveActivationAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x2, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveDeactivation(AActor*& OwnerActor); // 0x288a61c (Index: 0x3, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveDeactivationAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x4, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveSearchStart(AActor*& OwnerActor); // 0x288a61c (Index: 0x5, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveSearchStartAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x6, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveTick(AActor*& OwnerActor, float& DeltaSeconds); // 0x288a61c (Index: 0x7, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveTickAI(AAIController*& OwnerController, APawn*& ControlledPawn, float& DeltaSeconds); // 0x288a61c (Index: 0x8, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBTService_BlueprintBase) == 0x98, "Size mismatch for UBTService_BlueprintBase");
static_assert(offsetof(UBTService_BlueprintBase, AIOwner) == 0x70, "Offset mismatch for UBTService_BlueprintBase::AIOwner");
static_assert(offsetof(UBTService_BlueprintBase, ActorOwner) == 0x78, "Offset mismatch for UBTService_BlueprintBase::ActorOwner");
static_assert(offsetof(UBTService_BlueprintBase, bShowPropertyDetails) == 0x90, "Offset mismatch for UBTService_BlueprintBase::bShowPropertyDetails");
static_assert(offsetof(UBTService_BlueprintBase, bShowEventDetails) == 0x90, "Offset mismatch for UBTService_BlueprintBase::bShowEventDetails");

// Size: 0xa0 (Inherited: 0x1e8, Single: 0xfffffeb8)
class UBTService_DefaultFocus : public UBTService_BlackboardBase
{
public:
    char FocusPriority; // 0x98 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBTService_DefaultFocus) == 0xa0, "Size mismatch for UBTService_DefaultFocus");
static_assert(offsetof(UBTService_DefaultFocus, FocusPriority) == 0x98, "Offset mismatch for UBTService_DefaultFocus::FocusPriority");

// Size: 0xf8 (Inherited: 0x1e8, Single: 0xffffff10)
class UBTService_RunEQS : public UBTService_BlackboardBase
{
public:
    FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x98 (Size: 0x48, Type: StructProperty)
    bool bUpdateBBOnFail; // 0xe0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e1[0x17]; // 0xe1 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(UBTService_RunEQS) == 0xf8, "Size mismatch for UBTService_RunEQS");
static_assert(offsetof(UBTService_RunEQS, EQSRequest) == 0x98, "Offset mismatch for UBTService_RunEQS::EQSRequest");
static_assert(offsetof(UBTService_RunEQS, bUpdateBBOnFail) == 0xe0, "Offset mismatch for UBTService_RunEQS::bUpdateBBOnFail");

// Size: 0xa8 (Inherited: 0xf0, Single: 0xffffffb8)
class UBTTask_BlueprintBase : public UBTTaskNode
{
public:
    AAIController* AIOwner; // 0x70 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorOwner; // 0x78 (Size: 0x8, Type: ObjectProperty)
    FIntervalCountdown TickInterval; // 0x80 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_88[0x18]; // 0x88 (Size: 0x18, Type: PaddingProperty)
    uint8_t bShowPropertyDetails : 1; // 0xa0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)

protected:
    void FinishAbort(); // 0xaf67f60 (Index: 0x0, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void FinishExecute(bool& bSuccess); // 0xaf67fc8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    bool IsTaskAborting() const; // 0xaf6b530 (Index: 0x2, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsTaskExecuting() const; // 0xaf6b54c (Index: 0x3, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void ReceiveAbort(AActor*& OwnerActor); // 0x288a61c (Index: 0x4, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveAbortAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x5, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveExecute(AActor*& OwnerActor); // 0x288a61c (Index: 0x6, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveExecuteAI(AAIController*& OwnerController, APawn*& ControlledPawn); // 0x288a61c (Index: 0x7, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveTick(AActor*& OwnerActor, float& DeltaSeconds); // 0x288a61c (Index: 0x8, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void ReceiveTickAI(AAIController*& OwnerController, APawn*& ControlledPawn, float& DeltaSeconds); // 0x288a61c (Index: 0x9, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    void SetFinishOnMessage(FName& MessageName); // 0xaf6e7f0 (Index: 0xa, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void SetFinishOnMessageWithId(FName& MessageName, int32_t& RequestID); // 0xaf6e930 (Index: 0xb, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UBTTask_BlueprintBase) == 0xa8, "Size mismatch for UBTTask_BlueprintBase");
static_assert(offsetof(UBTTask_BlueprintBase, AIOwner) == 0x70, "Offset mismatch for UBTTask_BlueprintBase::AIOwner");
static_assert(offsetof(UBTTask_BlueprintBase, ActorOwner) == 0x78, "Offset mismatch for UBTTask_BlueprintBase::ActorOwner");
static_assert(offsetof(UBTTask_BlueprintBase, TickInterval) == 0x80, "Offset mismatch for UBTTask_BlueprintBase::TickInterval");
static_assert(offsetof(UBTTask_BlueprintBase, bShowPropertyDetails) == 0xa0, "Offset mismatch for UBTTask_BlueprintBase::bShowPropertyDetails");

// Size: 0x98 (Inherited: 0xf0, Single: 0xffffffa8)
class UBTTask_FinishWithResult : public UBTTaskNode
{
public:
    FValueOrBBKey_Enum Result; // 0x70 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTTask_FinishWithResult) == 0x98, "Size mismatch for UBTTask_FinishWithResult");
static_assert(offsetof(UBTTask_FinishWithResult, Result) == 0x70, "Offset mismatch for UBTTask_FinishWithResult::Result");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UBTTask_GameplayTaskBase : public UBTTaskNode
{
public:
    FValueOrBBKey_Bool bWaitForGameplayTask; // 0x70 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_GameplayTaskBase) == 0x80, "Size mismatch for UBTTask_GameplayTaskBase");
static_assert(offsetof(UBTTask_GameplayTaskBase, bWaitForGameplayTask) == 0x70, "Offset mismatch for UBTTask_GameplayTaskBase::bWaitForGameplayTask");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UBTTask_MakeNoise : public UBTTaskNode
{
public:
    FValueOrBBKey_Float Loudnes; // 0x70 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_MakeNoise) == 0x80, "Size mismatch for UBTTask_MakeNoise");
static_assert(offsetof(UBTTask_MakeNoise, Loudnes) == 0x70, "Offset mismatch for UBTTask_MakeNoise::Loudnes");

// Size: 0x130 (Inherited: 0x2b8, Single: 0xfffffe78)
class UBTTask_MoveDirectlyToward : public UBTTask_MoveTo
{
public:
};

static_assert(sizeof(UBTTask_MoveDirectlyToward) == 0x130, "Size mismatch for UBTTask_MoveDirectlyToward");

// Size: 0x130 (Inherited: 0x188, Single: 0xffffffa8)
class UBTTask_MoveTo : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Float AcceptableRadius; // 0x98 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
    FValueOrBBKey_Class FilterClass; // 0xa8 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Float ObservedBlackboardValueTolerance; // 0xc0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAllowStrafe; // 0xcc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bAllowPartialPath; // 0xd8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bTrackMovingGoal; // 0xe4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bRequireNavigableEndLocation; // 0xf0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bProjectGoalLocation; // 0xfc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bReachTestIncludesAgentRadius; // 0x108 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bReachTestIncludesGoalRadius; // 0x114 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bStartFromPreviousPath; // 0x120 (Size: 0xc, Type: StructProperty)
    uint8_t bObserveBlackboardValue : 1; // 0x12c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12d[0x3]; // 0x12d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_MoveTo) == 0x130, "Size mismatch for UBTTask_MoveTo");
static_assert(offsetof(UBTTask_MoveTo, AcceptableRadius) == 0x98, "Offset mismatch for UBTTask_MoveTo::AcceptableRadius");
static_assert(offsetof(UBTTask_MoveTo, FilterClass) == 0xa8, "Offset mismatch for UBTTask_MoveTo::FilterClass");
static_assert(offsetof(UBTTask_MoveTo, ObservedBlackboardValueTolerance) == 0xc0, "Offset mismatch for UBTTask_MoveTo::ObservedBlackboardValueTolerance");
static_assert(offsetof(UBTTask_MoveTo, bAllowStrafe) == 0xcc, "Offset mismatch for UBTTask_MoveTo::bAllowStrafe");
static_assert(offsetof(UBTTask_MoveTo, bAllowPartialPath) == 0xd8, "Offset mismatch for UBTTask_MoveTo::bAllowPartialPath");
static_assert(offsetof(UBTTask_MoveTo, bTrackMovingGoal) == 0xe4, "Offset mismatch for UBTTask_MoveTo::bTrackMovingGoal");
static_assert(offsetof(UBTTask_MoveTo, bRequireNavigableEndLocation) == 0xf0, "Offset mismatch for UBTTask_MoveTo::bRequireNavigableEndLocation");
static_assert(offsetof(UBTTask_MoveTo, bProjectGoalLocation) == 0xfc, "Offset mismatch for UBTTask_MoveTo::bProjectGoalLocation");
static_assert(offsetof(UBTTask_MoveTo, bReachTestIncludesAgentRadius) == 0x108, "Offset mismatch for UBTTask_MoveTo::bReachTestIncludesAgentRadius");
static_assert(offsetof(UBTTask_MoveTo, bReachTestIncludesGoalRadius) == 0x114, "Offset mismatch for UBTTask_MoveTo::bReachTestIncludesGoalRadius");
static_assert(offsetof(UBTTask_MoveTo, bStartFromPreviousPath) == 0x120, "Offset mismatch for UBTTask_MoveTo::bStartFromPreviousPath");
static_assert(offsetof(UBTTask_MoveTo, bObserveBlackboardValue) == 0x12c, "Offset mismatch for UBTTask_MoveTo::bObserveBlackboardValue");

// Size: 0xd0 (Inherited: 0xf0, Single: 0xffffffe0)
class UBTTask_PlayAnimation : public UBTTaskNode
{
public:
    FValueOrBBKey_Object AnimationToPlay; // 0x70 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Bool bLooping; // 0x88 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bNonBlocking; // 0x94 (Size: 0xc, Type: StructProperty)
    UBehaviorTreeComponent* MyOwnerComp; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* CachedSkelMesh; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_b0[0x20]; // 0xb0 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_PlayAnimation) == 0xd0, "Size mismatch for UBTTask_PlayAnimation");
static_assert(offsetof(UBTTask_PlayAnimation, AnimationToPlay) == 0x70, "Offset mismatch for UBTTask_PlayAnimation::AnimationToPlay");
static_assert(offsetof(UBTTask_PlayAnimation, bLooping) == 0x88, "Offset mismatch for UBTTask_PlayAnimation::bLooping");
static_assert(offsetof(UBTTask_PlayAnimation, bNonBlocking) == 0x94, "Offset mismatch for UBTTask_PlayAnimation::bNonBlocking");
static_assert(offsetof(UBTTask_PlayAnimation, MyOwnerComp) == 0xa0, "Offset mismatch for UBTTask_PlayAnimation::MyOwnerComp");
static_assert(offsetof(UBTTask_PlayAnimation, CachedSkelMesh) == 0xa8, "Offset mismatch for UBTTask_PlayAnimation::CachedSkelMesh");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UBTTask_PlaySound : public UBTTaskNode
{
public:
    FValueOrBBKey_Object SoundToPlay; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UBTTask_PlaySound) == 0x88, "Size mismatch for UBTTask_PlaySound");
static_assert(offsetof(UBTTask_PlaySound, SoundToPlay) == 0x70, "Offset mismatch for UBTTask_PlaySound::SoundToPlay");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
class UBTTask_RotateToFaceBBEntry : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Float Precision; // 0x98 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_RotateToFaceBBEntry) == 0xa8, "Size mismatch for UBTTask_RotateToFaceBBEntry");
static_assert(offsetof(UBTTask_RotateToFaceBBEntry, Precision) == 0x98, "Offset mismatch for UBTTask_RotateToFaceBBEntry::Precision");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UBTTask_RunBehavior : public UBTTaskNode
{
public:
    UBehaviorTree* BehaviorAsset; // 0x70 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBTTask_RunBehavior) == 0x78, "Size mismatch for UBTTask_RunBehavior");
static_assert(offsetof(UBTTask_RunBehavior, BehaviorAsset) == 0x70, "Offset mismatch for UBTTask_RunBehavior::BehaviorAsset");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UBTTask_RunBehaviorDynamic : public UBTTaskNode
{
public:
    FGameplayTag InjectionTag; // 0x70 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    UBehaviorTree* DefaultBehaviorAsset; // 0x78 (Size: 0x8, Type: ObjectProperty)
    UBehaviorTree* BehaviorAsset; // 0x80 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBTTask_RunBehaviorDynamic) == 0x88, "Size mismatch for UBTTask_RunBehaviorDynamic");
static_assert(offsetof(UBTTask_RunBehaviorDynamic, InjectionTag) == 0x70, "Offset mismatch for UBTTask_RunBehaviorDynamic::InjectionTag");
static_assert(offsetof(UBTTask_RunBehaviorDynamic, DefaultBehaviorAsset) == 0x78, "Offset mismatch for UBTTask_RunBehaviorDynamic::DefaultBehaviorAsset");
static_assert(offsetof(UBTTask_RunBehaviorDynamic, BehaviorAsset) == 0x80, "Offset mismatch for UBTTask_RunBehaviorDynamic::BehaviorAsset");

// Size: 0x100 (Inherited: 0x188, Single: 0xffffff78)
class UBTTask_RunEQSQuery : public UBTTask_BlackboardBase
{
public:
    bool bUseBBKey; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xa0 (Size: 0x48, Type: StructProperty)
    bool bUpdateBBOnFail; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x17]; // 0xe9 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_RunEQSQuery) == 0x100, "Size mismatch for UBTTask_RunEQSQuery");
static_assert(offsetof(UBTTask_RunEQSQuery, bUseBBKey) == 0x98, "Offset mismatch for UBTTask_RunEQSQuery::bUseBBKey");
static_assert(offsetof(UBTTask_RunEQSQuery, EQSRequest) == 0xa0, "Offset mismatch for UBTTask_RunEQSQuery::EQSRequest");
static_assert(offsetof(UBTTask_RunEQSQuery, bUpdateBBOnFail) == 0xe8, "Offset mismatch for UBTTask_RunEQSQuery::bUpdateBBOnFail");

// Size: 0x90 (Inherited: 0xf0, Single: 0xffffffa0)
class UBTTask_SetTagCooldown : public UBTTaskNode
{
public:
    FGameplayTag CooldownTag; // 0x70 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Bool bAddToExistingDuration; // 0x74 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration; // 0x80 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_SetTagCooldown) == 0x90, "Size mismatch for UBTTask_SetTagCooldown");
static_assert(offsetof(UBTTask_SetTagCooldown, CooldownTag) == 0x70, "Offset mismatch for UBTTask_SetTagCooldown::CooldownTag");
static_assert(offsetof(UBTTask_SetTagCooldown, bAddToExistingDuration) == 0x74, "Offset mismatch for UBTTask_SetTagCooldown::bAddToExistingDuration");
static_assert(offsetof(UBTTask_SetTagCooldown, CooldownDuration) == 0x80, "Offset mismatch for UBTTask_SetTagCooldown::CooldownDuration");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UBTTask_Wait : public UBTTaskNode
{
public:
    FValueOrBBKey_Float WaitTime; // 0x70 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float RandomDeviation; // 0x7c (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UBTTask_Wait) == 0x88, "Size mismatch for UBTTask_Wait");
static_assert(offsetof(UBTTask_Wait, WaitTime) == 0x70, "Offset mismatch for UBTTask_Wait::WaitTime");
static_assert(offsetof(UBTTask_Wait, RandomDeviation) == 0x7c, "Offset mismatch for UBTTask_Wait::RandomDeviation");

// Size: 0xb0 (Inherited: 0x178, Single: 0xffffff38)
class UBTTask_WaitBlackboardTime : public UBTTask_Wait
{
public:
    FBlackboardKeySelector BlackboardKey; // 0x88 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTTask_WaitBlackboardTime) == 0xb0, "Size mismatch for UBTTask_WaitBlackboardTime");
static_assert(offsetof(UBTTask_WaitBlackboardTime, BlackboardKey) == 0x88, "Offset mismatch for UBTTask_WaitBlackboardTime::BlackboardKey");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAIBlueprintHelperLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(UObject*& WorldContextObject, APawn*& Pawn, FVector& Destination, AActor*& TargetActor, float& AcceptanceRadius, bool& bStopOnOverlap); // 0xaf67b88 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
    static AAIController* GetAIController(AActor*& ControlledActor); // 0x4474208 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UBlackboardComponent* GetBlackboard(AActor*& Target); // 0xaf68130 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UNavigationPath* GetCurrentPath(AController*& Controller); // 0xaf6aa5c (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetCurrentPathIndex(AController*& const Controller); // 0xaf6ac08 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FVector> GetCurrentPathPoints(AController*& Controller); // 0xaf6ad50 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNextNavLinkIndex(AController*& const Controller); // 0xaf6b04c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsValidAIDirection(FVector& DirectionVector); // 0xaf6b5a8 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsValidAILocation(FVector& Location); // 0xaf6b6bc (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsValidAIRotation(FRotator& Rotation); // 0xaf6b7b8 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static void LockAIResourcesWithAnimation(UAnimInstance*& AnimInstance, bool& bLockMovement, bool& LockAILogic); // 0xaf6b8a4 (Index: 0xa, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable)
    static void SendAIMessage(APawn*& Target, FName& Message, UObject*& MessageSource, bool& bSuccess); // 0xaf6bbd8 (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void SimpleMoveToActor(AController*& Controller, AActor*& const Goal); // 0xaf6eb4c (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void SimpleMoveToLocation(AController*& Controller, const FVector Goal); // 0xaf6ed44 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static APawn* SpawnAIFromClass(UObject*& WorldContextObject, UClass*& PawnClass, UBehaviorTree*& BehaviorTree, FVector& Location, FRotator& Rotation, bool& bNoCollisionFail, AActor*& Owner); // 0xaf6eefc (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
    static void UnlockAIResourcesWithAnimation(UAnimInstance*& AnimInstance, bool& bUnlockMovement, bool& UnlockAILogic); // 0xaf6f8b8 (Index: 0xf, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAIBlueprintHelperLibrary) == 0x28, "Size mismatch for UAIBlueprintHelperLibrary");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAIDataProvider : public UObject
{
public:
};

static_assert(sizeof(UAIDataProvider) == 0x28, "Size mismatch for UAIDataProvider");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UAIDataProvider_QueryParams : public UAIDataProvider
{
public:
    FName ParamName; // 0x28 (Size: 0x4, Type: NameProperty)
    float FloatValue; // 0x2c (Size: 0x4, Type: FloatProperty)
    int32_t IntValue; // 0x30 (Size: 0x4, Type: IntProperty)
    bool BoolValue; // 0x34 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UAIDataProvider_QueryParams) == 0x38, "Size mismatch for UAIDataProvider_QueryParams");
static_assert(offsetof(UAIDataProvider_QueryParams, ParamName) == 0x28, "Offset mismatch for UAIDataProvider_QueryParams::ParamName");
static_assert(offsetof(UAIDataProvider_QueryParams, FloatValue) == 0x2c, "Offset mismatch for UAIDataProvider_QueryParams::FloatValue");
static_assert(offsetof(UAIDataProvider_QueryParams, IntValue) == 0x30, "Offset mismatch for UAIDataProvider_QueryParams::IntValue");
static_assert(offsetof(UAIDataProvider_QueryParams, BoolValue) == 0x34, "Offset mismatch for UAIDataProvider_QueryParams::BoolValue");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UAIDataProvider_Random : public UAIDataProvider_QueryParams
{
public:
    float Min; // 0x38 (Size: 0x4, Type: FloatProperty)
    float Max; // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t bInteger : 1; // 0x40:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UAIDataProvider_Random) == 0x48, "Size mismatch for UAIDataProvider_Random");
static_assert(offsetof(UAIDataProvider_Random, Min) == 0x38, "Offset mismatch for UAIDataProvider_Random::Min");
static_assert(offsetof(UAIDataProvider_Random, Max) == 0x3c, "Offset mismatch for UAIDataProvider_Random::Max");
static_assert(offsetof(UAIDataProvider_Random, bInteger) == 0x40, "Offset mismatch for UAIDataProvider_Random::bInteger");

// Size: 0x3c8 (Inherited: 0x9d8, Single: 0xfffff9f0)
class ADetourCrowdAIController : public AAIController
{
public:
};

static_assert(sizeof(ADetourCrowdAIController) == 0x3c8, "Size mismatch for ADetourCrowdAIController");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UEnvQueryContext_BlueprintBase : public UEnvQueryContext
{
public:

public:
    virtual void ProvideActorsSet(UObject*& QuerierObject, AActor*& QuerierActor, TArray<AActor*>& ResultingActorsSet) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    virtual void ProvideLocationsSet(UObject*& QuerierObject, AActor*& QuerierActor, TArray<FVector>& ResultingLocationSet) const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    virtual void ProvideSingleActor(UObject*& QuerierObject, AActor*& QuerierActor, AActor*& ResultingActor) const; // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    virtual void ProvideSingleLocation(UObject*& QuerierObject, AActor*& QuerierActor, FVector& ResultingLocation) const; // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const)
};

static_assert(sizeof(UEnvQueryContext_BlueprintBase) == 0x30, "Size mismatch for UEnvQueryContext_BlueprintBase");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UEnvQueryContext : public UObject
{
public:
};

static_assert(sizeof(UEnvQueryContext) == 0x28, "Size mismatch for UEnvQueryContext");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEnvQueryContext_Item : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UEnvQueryContext_Item) == 0x28, "Size mismatch for UEnvQueryContext_Item");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UEnvQueryContext_NavigationData : public UEnvQueryContext
{
public:
    FNavAgentProperties NavAgentProperties; // 0x28 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UEnvQueryContext_NavigationData) == 0x58, "Size mismatch for UEnvQueryContext_NavigationData");
static_assert(offsetof(UEnvQueryContext_NavigationData, NavAgentProperties) == 0x28, "Offset mismatch for UEnvQueryContext_NavigationData::NavAgentProperties");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEnvQueryContext_Querier : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UEnvQueryContext_Querier) == 0x28, "Size mismatch for UEnvQueryContext_Querier");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UEnvQuery : public UDataAsset
{
public:
    FName QueryName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<UEnvQueryOption*> Options; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEnvQuery) == 0x48, "Size mismatch for UEnvQuery");
static_assert(offsetof(UEnvQuery, QueryName) == 0x30, "Offset mismatch for UEnvQuery::QueryName");
static_assert(offsetof(UEnvQuery, Options) == 0x38, "Offset mismatch for UEnvQuery::Options");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UEnvQueryDebugHelpers : public UObject
{
public:
};

static_assert(sizeof(UEnvQueryDebugHelpers) == 0x28, "Size mismatch for UEnvQueryDebugHelpers");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UEnvQueryGenerator : public UEnvQueryNode
{
public:
    FString OptionName; // 0x30 (Size: 0x10, Type: StrProperty)
    UClass* ItemType; // 0x40 (Size: 0x8, Type: ClassProperty)
    uint8_t bAutoSortTests : 1; // 0x48:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanRunAsync : 1; // 0x48:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryGenerator) == 0x50, "Size mismatch for UEnvQueryGenerator");
static_assert(offsetof(UEnvQueryGenerator, OptionName) == 0x30, "Offset mismatch for UEnvQueryGenerator::OptionName");
static_assert(offsetof(UEnvQueryGenerator, ItemType) == 0x40, "Offset mismatch for UEnvQueryGenerator::ItemType");
static_assert(offsetof(UEnvQueryGenerator, bAutoSortTests) == 0x48, "Offset mismatch for UEnvQueryGenerator::bAutoSortTests");
static_assert(offsetof(UEnvQueryGenerator, bCanRunAsync) == 0x48, "Offset mismatch for UEnvQueryGenerator::bCanRunAsync");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UEnvQueryNode : public UObject
{
public:
    int32_t VerNum; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryNode) == 0x30, "Size mismatch for UEnvQueryNode");
static_assert(offsetof(UEnvQueryNode, VerNum) == 0x28, "Offset mismatch for UEnvQueryNode::VerNum");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UEnvQueryInstanceBlueprintWrapper : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    int32_t QueryID; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x24]; // 0x34 (Size: 0x24, Type: PaddingProperty)
    UClass* ItemType; // 0x58 (Size: 0x8, Type: ClassProperty)
    int32_t OptionIndex; // 0x60 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnQueryFinishedEvent[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void EQSQueryDoneSignature__DelegateSignature(UEnvQueryInstanceBlueprintWrapper*& QueryInstance, TEnumAsByte<EEnvQueryStatus>& QueryStatus); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    float GetItemScore(int32_t& ItemIndex) const; // 0xaf9ebcc (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetQueryResultsAsActors(TArray<AActor*>& ResultActors) const; // 0xaf9ed48 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|Const)
    bool GetQueryResultsAsLocations(TArray<FVector>& ResultLocations) const; // 0xaf9eff0 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|Const)
    TArray<AActor*> GetResultsAsActors() const; // 0xaf9f280 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FVector> GetResultsAsLocations() const; // 0xaf9f2c0 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetNamedParam(FName& ParamName, float& Value); // 0xaf9f930 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UEnvQueryInstanceBlueprintWrapper) == 0x78, "Size mismatch for UEnvQueryInstanceBlueprintWrapper");
static_assert(offsetof(UEnvQueryInstanceBlueprintWrapper, QueryID) == 0x30, "Offset mismatch for UEnvQueryInstanceBlueprintWrapper::QueryID");
static_assert(offsetof(UEnvQueryInstanceBlueprintWrapper, ItemType) == 0x58, "Offset mismatch for UEnvQueryInstanceBlueprintWrapper::ItemType");
static_assert(offsetof(UEnvQueryInstanceBlueprintWrapper, OptionIndex) == 0x60, "Offset mismatch for UEnvQueryInstanceBlueprintWrapper::OptionIndex");
static_assert(offsetof(UEnvQueryInstanceBlueprintWrapper, OnQueryFinishedEvent) == 0x68, "Offset mismatch for UEnvQueryInstanceBlueprintWrapper::OnQueryFinishedEvent");

// Size: 0x158 (Inherited: 0x60, Single: 0xf8)
class UEnvQueryManager : public UAISubsystem
{
public:
    uint8_t Pad_38[0x70]; // 0x38 (Size: 0x70, Type: PaddingProperty)
    TArray<FEnvQueryInstanceCache> InstanceCache; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    TArray<UEnvQueryContext*> LocalContexts; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d8[0x54]; // 0xd8 (Size: 0x54, Type: PaddingProperty)
    float MaxAllowedTestingTime; // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bTestQueriesUsingBreadth; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0x3]; // 0x131 (Size: 0x3, Type: PaddingProperty)
    int32_t QueryCountWarningThreshold; // 0x134 (Size: 0x4, Type: IntProperty)
    double QueryCountWarningInterval; // 0x138 (Size: 0x8, Type: DoubleProperty)
    double ExecutionTimeWarningSeconds; // 0x140 (Size: 0x8, Type: DoubleProperty)
    double HandlingResultTimeWarningSeconds; // 0x148 (Size: 0x8, Type: DoubleProperty)
    double GenerationTimeWarningSeconds; // 0x150 (Size: 0x8, Type: DoubleProperty)

public:
    static UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(UObject*& WorldContextObject, UEnvQuery*& QueryTemplate, UObject*& Querier, TEnumAsByte<EEnvQueryRunMode>& RunMode, UClass*& WrapperClass); // 0xaf9f300 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UEnvQueryManager) == 0x158, "Size mismatch for UEnvQueryManager");
static_assert(offsetof(UEnvQueryManager, InstanceCache) == 0xa8, "Offset mismatch for UEnvQueryManager::InstanceCache");
static_assert(offsetof(UEnvQueryManager, LocalContexts) == 0xb8, "Offset mismatch for UEnvQueryManager::LocalContexts");
static_assert(offsetof(UEnvQueryManager, GCShieldedWrappers) == 0xc8, "Offset mismatch for UEnvQueryManager::GCShieldedWrappers");
static_assert(offsetof(UEnvQueryManager, MaxAllowedTestingTime) == 0x12c, "Offset mismatch for UEnvQueryManager::MaxAllowedTestingTime");
static_assert(offsetof(UEnvQueryManager, bTestQueriesUsingBreadth) == 0x130, "Offset mismatch for UEnvQueryManager::bTestQueriesUsingBreadth");
static_assert(offsetof(UEnvQueryManager, QueryCountWarningThreshold) == 0x134, "Offset mismatch for UEnvQueryManager::QueryCountWarningThreshold");
static_assert(offsetof(UEnvQueryManager, QueryCountWarningInterval) == 0x138, "Offset mismatch for UEnvQueryManager::QueryCountWarningInterval");
static_assert(offsetof(UEnvQueryManager, ExecutionTimeWarningSeconds) == 0x140, "Offset mismatch for UEnvQueryManager::ExecutionTimeWarningSeconds");
static_assert(offsetof(UEnvQueryManager, HandlingResultTimeWarningSeconds) == 0x148, "Offset mismatch for UEnvQueryManager::HandlingResultTimeWarningSeconds");
static_assert(offsetof(UEnvQueryManager, GenerationTimeWarningSeconds) == 0x150, "Offset mismatch for UEnvQueryManager::GenerationTimeWarningSeconds");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UEnvQueryOption : public UObject
{
public:
    UEnvQueryGenerator* Generator; // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<UEnvQueryTest*> Tests; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEnvQueryOption) == 0x40, "Size mismatch for UEnvQueryOption");
static_assert(offsetof(UEnvQueryOption, Generator) == 0x28, "Offset mismatch for UEnvQueryOption::Generator");
static_assert(offsetof(UEnvQueryOption, Tests) == 0x30, "Offset mismatch for UEnvQueryOption::Tests");

// Size: 0x1f8 (Inherited: 0x58, Single: 0x1a0)
class UEnvQueryTest : public UEnvQueryNode
{
public:
    int32_t TestOrder; // 0x30 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EEnvTestPurpose> TestPurpose; // 0x34 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
    FString TestComment; // 0x38 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<EEnvTestFilterOperator> MultipleContextFilterOp; // 0x48 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvTestScoreOperator> MultipleContextScoreOp; // 0x49 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvTestFilterType> FilterType; // 0x4a (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4b[0x5]; // 0x4b (Size: 0x5, Type: PaddingProperty)
    FAIDataProviderBoolValue BoolValue; // 0x50 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue FloatValueMin; // 0x88 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue FloatValueMax; // 0xc0 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_f8[0x1]; // 0xf8 (Size: 0x1, Type: PaddingProperty)
    TEnumAsByte<EEnvTestScoreEquation> ScoringEquation; // 0xf9 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvQueryTestClamping> ClampMinType; // 0xfa (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvQueryTestClamping> ClampMaxType; // 0xfb (Size: 0x1, Type: ByteProperty)
    uint8_t NormalizationType; // 0xfc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_fd[0x3]; // 0xfd (Size: 0x3, Type: PaddingProperty)
    FAIDataProviderFloatValue ScoreClampMin; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreClampMax; // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoringFactor; // 0x170 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ReferenceValue; // 0x1a8 (Size: 0x38, Type: StructProperty)
    bool bDefineReferenceValue; // 0x1e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e1[0xf]; // 0x1e1 (Size: 0xf, Type: PaddingProperty)
    uint8_t bWorkOnFloatValues : 1; // 0x1f0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f1[0x7]; // 0x1f1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryTest) == 0x1f8, "Size mismatch for UEnvQueryTest");
static_assert(offsetof(UEnvQueryTest, TestOrder) == 0x30, "Offset mismatch for UEnvQueryTest::TestOrder");
static_assert(offsetof(UEnvQueryTest, TestPurpose) == 0x34, "Offset mismatch for UEnvQueryTest::TestPurpose");
static_assert(offsetof(UEnvQueryTest, TestComment) == 0x38, "Offset mismatch for UEnvQueryTest::TestComment");
static_assert(offsetof(UEnvQueryTest, MultipleContextFilterOp) == 0x48, "Offset mismatch for UEnvQueryTest::MultipleContextFilterOp");
static_assert(offsetof(UEnvQueryTest, MultipleContextScoreOp) == 0x49, "Offset mismatch for UEnvQueryTest::MultipleContextScoreOp");
static_assert(offsetof(UEnvQueryTest, FilterType) == 0x4a, "Offset mismatch for UEnvQueryTest::FilterType");
static_assert(offsetof(UEnvQueryTest, BoolValue) == 0x50, "Offset mismatch for UEnvQueryTest::BoolValue");
static_assert(offsetof(UEnvQueryTest, FloatValueMin) == 0x88, "Offset mismatch for UEnvQueryTest::FloatValueMin");
static_assert(offsetof(UEnvQueryTest, FloatValueMax) == 0xc0, "Offset mismatch for UEnvQueryTest::FloatValueMax");
static_assert(offsetof(UEnvQueryTest, ScoringEquation) == 0xf9, "Offset mismatch for UEnvQueryTest::ScoringEquation");
static_assert(offsetof(UEnvQueryTest, ClampMinType) == 0xfa, "Offset mismatch for UEnvQueryTest::ClampMinType");
static_assert(offsetof(UEnvQueryTest, ClampMaxType) == 0xfb, "Offset mismatch for UEnvQueryTest::ClampMaxType");
static_assert(offsetof(UEnvQueryTest, NormalizationType) == 0xfc, "Offset mismatch for UEnvQueryTest::NormalizationType");
static_assert(offsetof(UEnvQueryTest, ScoreClampMin) == 0x100, "Offset mismatch for UEnvQueryTest::ScoreClampMin");
static_assert(offsetof(UEnvQueryTest, ScoreClampMax) == 0x138, "Offset mismatch for UEnvQueryTest::ScoreClampMax");
static_assert(offsetof(UEnvQueryTest, ScoringFactor) == 0x170, "Offset mismatch for UEnvQueryTest::ScoringFactor");
static_assert(offsetof(UEnvQueryTest, ReferenceValue) == 0x1a8, "Offset mismatch for UEnvQueryTest::ReferenceValue");
static_assert(offsetof(UEnvQueryTest, bDefineReferenceValue) == 0x1e0, "Offset mismatch for UEnvQueryTest::bDefineReferenceValue");
static_assert(offsetof(UEnvQueryTest, bWorkOnFloatValues) == 0x1f0, "Offset mismatch for UEnvQueryTest::bWorkOnFloatValues");

// Size: 0x5b0 (Inherited: 0xdc0, Single: 0xfffff7f0)
class UEQSRenderingComponent : public UDebugDrawComponent
{
public:
};

static_assert(sizeof(UEQSRenderingComponent) == 0x5b0, "Size mismatch for UEQSRenderingComponent");

// Size: 0x6d0 (Inherited: 0x660, Single: 0x70)
class AEQSTestingPawn : public UCharacter
{
public:
    uint8_t Pad_328[0x318]; // 0x328 (Size: 0x318, Type: PaddingProperty)
    UEnvQuery* QueryTemplate; // 0x640 (Size: 0x8, Type: ObjectProperty)
    TArray<FEnvNamedValue> QueryParams; // 0x648 (Size: 0x10, Type: ArrayProperty)
    TArray<FAIDynamicParam> QueryConfig; // 0x658 (Size: 0x10, Type: ArrayProperty)
    float TimeLimitPerStep; // 0x668 (Size: 0x4, Type: FloatProperty)
    int32_t StepToDebugDraw; // 0x66c (Size: 0x4, Type: IntProperty)
    uint8_t HighlightMode; // 0x670 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_671[0x3]; // 0x671 (Size: 0x3, Type: PaddingProperty)
    uint8_t bDrawLabels : 1; // 0x674:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bDrawFailedItems : 1; // 0x674:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bReRunQueryOnlyOnFinishedMove : 1; // 0x674:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldBeVisibleInGame : 1; // 0x674:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bTickDuringGame : 1; // 0x674:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bRunQueryOnSelectionChanged : 1; // 0x674:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_675[0x3]; // 0x675 (Size: 0x3, Type: PaddingProperty)
    TEnumAsByte<EEnvQueryRunMode> QueryingMode; // 0x678 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_679[0x7]; // 0x679 (Size: 0x7, Type: PaddingProperty)
    FNavAgentProperties NavAgentProperties; // 0x680 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_6b0[0x20]; // 0x6b0 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(AEQSTestingPawn) == 0x6d0, "Size mismatch for AEQSTestingPawn");
static_assert(offsetof(AEQSTestingPawn, QueryTemplate) == 0x640, "Offset mismatch for AEQSTestingPawn::QueryTemplate");
static_assert(offsetof(AEQSTestingPawn, QueryParams) == 0x648, "Offset mismatch for AEQSTestingPawn::QueryParams");
static_assert(offsetof(AEQSTestingPawn, QueryConfig) == 0x658, "Offset mismatch for AEQSTestingPawn::QueryConfig");
static_assert(offsetof(AEQSTestingPawn, TimeLimitPerStep) == 0x668, "Offset mismatch for AEQSTestingPawn::TimeLimitPerStep");
static_assert(offsetof(AEQSTestingPawn, StepToDebugDraw) == 0x66c, "Offset mismatch for AEQSTestingPawn::StepToDebugDraw");
static_assert(offsetof(AEQSTestingPawn, HighlightMode) == 0x670, "Offset mismatch for AEQSTestingPawn::HighlightMode");
static_assert(offsetof(AEQSTestingPawn, bDrawLabels) == 0x674, "Offset mismatch for AEQSTestingPawn::bDrawLabels");
static_assert(offsetof(AEQSTestingPawn, bDrawFailedItems) == 0x674, "Offset mismatch for AEQSTestingPawn::bDrawFailedItems");
static_assert(offsetof(AEQSTestingPawn, bReRunQueryOnlyOnFinishedMove) == 0x674, "Offset mismatch for AEQSTestingPawn::bReRunQueryOnlyOnFinishedMove");
static_assert(offsetof(AEQSTestingPawn, bShouldBeVisibleInGame) == 0x674, "Offset mismatch for AEQSTestingPawn::bShouldBeVisibleInGame");
static_assert(offsetof(AEQSTestingPawn, bTickDuringGame) == 0x674, "Offset mismatch for AEQSTestingPawn::bTickDuringGame");
static_assert(offsetof(AEQSTestingPawn, bRunQueryOnSelectionChanged) == 0x674, "Offset mismatch for AEQSTestingPawn::bRunQueryOnSelectionChanged");
static_assert(offsetof(AEQSTestingPawn, QueryingMode) == 0x678, "Offset mismatch for AEQSTestingPawn::QueryingMode");
static_assert(offsetof(AEQSTestingPawn, NavAgentProperties) == 0x680, "Offset mismatch for AEQSTestingPawn::NavAgentProperties");

// Size: 0xd0 (Inherited: 0xa8, Single: 0x28)
class UEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator
{
public:
    UClass* SearchedActorClass; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SearchRadius; // 0x90 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter; // 0xc8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryGenerator_ActorsOfClass) == 0xd0, "Size mismatch for UEnvQueryGenerator_ActorsOfClass");
static_assert(offsetof(UEnvQueryGenerator_ActorsOfClass, SearchedActorClass) == 0x50, "Offset mismatch for UEnvQueryGenerator_ActorsOfClass::SearchedActorClass");
static_assert(offsetof(UEnvQueryGenerator_ActorsOfClass, GenerateOnlyActorsInRadius) == 0x58, "Offset mismatch for UEnvQueryGenerator_ActorsOfClass::GenerateOnlyActorsInRadius");
static_assert(offsetof(UEnvQueryGenerator_ActorsOfClass, SearchRadius) == 0x90, "Offset mismatch for UEnvQueryGenerator_ActorsOfClass::SearchRadius");
static_assert(offsetof(UEnvQueryGenerator_ActorsOfClass, SearchCenter) == 0xc8, "Offset mismatch for UEnvQueryGenerator_ActorsOfClass::SearchCenter");

// Size: 0x80 (Inherited: 0xa8, Single: 0xffffffd8)
class UEnvQueryGenerator_BlueprintBase : public UEnvQueryGenerator
{
public:
    FText GeneratorsActionDescription; // 0x50 (Size: 0x10, Type: TextProperty)
    UClass* Context; // 0x60 (Size: 0x8, Type: ClassProperty)
    UClass* GeneratedItemType; // 0x68 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_70[0x10]; // 0x70 (Size: 0x10, Type: PaddingProperty)

public:
    void AddGeneratedActor(AActor*& GeneratedActor) const; // 0xaf9e9cc (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|Const)
    void AddGeneratedVector(FVector& GeneratedVector) const; // 0xaf9eaf8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|Const)
    virtual void DoItemGeneration(const TArray<FVector> ContextLocations) const; // 0x288a61c (Index: 0x2, Flags: RequiredAPI|Event|Public|HasOutParms|BlueprintEvent|Const)
    virtual void DoItemGenerationFromActors(const TArray<AActor*> ContextActors) const; // 0x288a61c (Index: 0x3, Flags: RequiredAPI|Event|Public|HasOutParms|BlueprintEvent|Const)
    UObject* GetQuerier() const; // 0xaf9ed1c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEnvQueryGenerator_BlueprintBase) == 0x80, "Size mismatch for UEnvQueryGenerator_BlueprintBase");
static_assert(offsetof(UEnvQueryGenerator_BlueprintBase, GeneratorsActionDescription) == 0x50, "Offset mismatch for UEnvQueryGenerator_BlueprintBase::GeneratorsActionDescription");
static_assert(offsetof(UEnvQueryGenerator_BlueprintBase, Context) == 0x60, "Offset mismatch for UEnvQueryGenerator_BlueprintBase::Context");
static_assert(offsetof(UEnvQueryGenerator_BlueprintBase, GeneratedItemType) == 0x68, "Offset mismatch for UEnvQueryGenerator_BlueprintBase::GeneratedItemType");

// Size: 0x70 (Inherited: 0xa8, Single: 0xffffffc8)
class UEnvQueryGenerator_Composite : public UEnvQueryGenerator
{
public:
    TArray<UEnvQueryGenerator*> Generators; // 0x50 (Size: 0x10, Type: ArrayProperty)
    uint8_t bAllowDifferentItemTypes : 1; // 0x60:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bHasMatchingItemType : 1; // 0x60:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
    UClass* ForcedItemType; // 0x68 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryGenerator_Composite) == 0x70, "Size mismatch for UEnvQueryGenerator_Composite");
static_assert(offsetof(UEnvQueryGenerator_Composite, Generators) == 0x50, "Offset mismatch for UEnvQueryGenerator_Composite::Generators");
static_assert(offsetof(UEnvQueryGenerator_Composite, bAllowDifferentItemTypes) == 0x60, "Offset mismatch for UEnvQueryGenerator_Composite::bAllowDifferentItemTypes");
static_assert(offsetof(UEnvQueryGenerator_Composite, bHasMatchingItemType) == 0x60, "Offset mismatch for UEnvQueryGenerator_Composite::bHasMatchingItemType");
static_assert(offsetof(UEnvQueryGenerator_Composite, ForcedItemType) == 0x68, "Offset mismatch for UEnvQueryGenerator_Composite::ForcedItemType");

// Size: 0x180 (Inherited: 0x138, Single: 0x48)
class UEnvQueryGenerator_Cone : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue AlignedPointsDistance; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ConeDegrees; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue AngleStep; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue Range; // 0x138 (Size: 0x38, Type: StructProperty)
    UClass* CenterActor; // 0x170 (Size: 0x8, Type: ClassProperty)
    uint8_t bIncludeContextLocation : 1; // 0x178:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_179[0x7]; // 0x179 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryGenerator_Cone) == 0x180, "Size mismatch for UEnvQueryGenerator_Cone");
static_assert(offsetof(UEnvQueryGenerator_Cone, AlignedPointsDistance) == 0x90, "Offset mismatch for UEnvQueryGenerator_Cone::AlignedPointsDistance");
static_assert(offsetof(UEnvQueryGenerator_Cone, ConeDegrees) == 0xc8, "Offset mismatch for UEnvQueryGenerator_Cone::ConeDegrees");
static_assert(offsetof(UEnvQueryGenerator_Cone, AngleStep) == 0x100, "Offset mismatch for UEnvQueryGenerator_Cone::AngleStep");
static_assert(offsetof(UEnvQueryGenerator_Cone, Range) == 0x138, "Offset mismatch for UEnvQueryGenerator_Cone::Range");
static_assert(offsetof(UEnvQueryGenerator_Cone, CenterActor) == 0x170, "Offset mismatch for UEnvQueryGenerator_Cone::CenterActor");
static_assert(offsetof(UEnvQueryGenerator_Cone, bIncludeContextLocation) == 0x178, "Offset mismatch for UEnvQueryGenerator_Cone::bIncludeContextLocation");

// Size: 0x90 (Inherited: 0xa8, Single: 0xffffffe8)
class UEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator
{
public:
    FEnvTraceData ProjectionData; // 0x50 (Size: 0x38, Type: StructProperty)
    UClass* NavDataOverrideContext; // 0x88 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryGenerator_ProjectedPoints) == 0x90, "Size mismatch for UEnvQueryGenerator_ProjectedPoints");
static_assert(offsetof(UEnvQueryGenerator_ProjectedPoints, ProjectionData) == 0x50, "Offset mismatch for UEnvQueryGenerator_ProjectedPoints::ProjectionData");
static_assert(offsetof(UEnvQueryGenerator_ProjectedPoints, NavDataOverrideContext) == 0x88, "Offset mismatch for UEnvQueryGenerator_ProjectedPoints::NavDataOverrideContext");

// Size: 0x98 (Inherited: 0x138, Single: 0xffffff60)
class UEnvQueryGenerator_CurrentLocation : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* QueryContext; // 0x90 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryGenerator_CurrentLocation) == 0x98, "Size mismatch for UEnvQueryGenerator_CurrentLocation");
static_assert(offsetof(UEnvQueryGenerator_CurrentLocation, QueryContext) == 0x90, "Offset mismatch for UEnvQueryGenerator_CurrentLocation::QueryContext");

// Size: 0x1e0 (Inherited: 0x138, Single: 0xa8)
class UEnvQueryGenerator_Donut : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue InnerRadius; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue OuterRadius; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumberOfRings; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue PointsPerRing; // 0x138 (Size: 0x38, Type: StructProperty)
    FEnvDirection ArcDirection; // 0x170 (Size: 0x20, Type: StructProperty)
    FAIDataProviderFloatValue ArcAngle; // 0x190 (Size: 0x38, Type: StructProperty)
    bool bUseSpiralPattern; // 0x1c8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c9[0x7]; // 0x1c9 (Size: 0x7, Type: PaddingProperty)
    UClass* Center; // 0x1d0 (Size: 0x8, Type: ClassProperty)
    uint8_t bDefineArc : 1; // 0x1d8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d9[0x7]; // 0x1d9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryGenerator_Donut) == 0x1e0, "Size mismatch for UEnvQueryGenerator_Donut");
static_assert(offsetof(UEnvQueryGenerator_Donut, InnerRadius) == 0x90, "Offset mismatch for UEnvQueryGenerator_Donut::InnerRadius");
static_assert(offsetof(UEnvQueryGenerator_Donut, OuterRadius) == 0xc8, "Offset mismatch for UEnvQueryGenerator_Donut::OuterRadius");
static_assert(offsetof(UEnvQueryGenerator_Donut, NumberOfRings) == 0x100, "Offset mismatch for UEnvQueryGenerator_Donut::NumberOfRings");
static_assert(offsetof(UEnvQueryGenerator_Donut, PointsPerRing) == 0x138, "Offset mismatch for UEnvQueryGenerator_Donut::PointsPerRing");
static_assert(offsetof(UEnvQueryGenerator_Donut, ArcDirection) == 0x170, "Offset mismatch for UEnvQueryGenerator_Donut::ArcDirection");
static_assert(offsetof(UEnvQueryGenerator_Donut, ArcAngle) == 0x190, "Offset mismatch for UEnvQueryGenerator_Donut::ArcAngle");
static_assert(offsetof(UEnvQueryGenerator_Donut, bUseSpiralPattern) == 0x1c8, "Offset mismatch for UEnvQueryGenerator_Donut::bUseSpiralPattern");
static_assert(offsetof(UEnvQueryGenerator_Donut, Center) == 0x1d0, "Offset mismatch for UEnvQueryGenerator_Donut::Center");
static_assert(offsetof(UEnvQueryGenerator_Donut, bDefineArc) == 0x1d8, "Offset mismatch for UEnvQueryGenerator_Donut::bDefineArc");

// Size: 0x228 (Inherited: 0x138, Single: 0xf0)
class UEnvQueryGenerator_OnCircle : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue CircleRadius; // 0x90 (Size: 0x38, Type: StructProperty)
    uint8_t PointOnCircleSpacingMethod; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue SpaceBetween; // 0xd0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumberOfPoints; // 0x108 (Size: 0x38, Type: StructProperty)
    FEnvDirection ArcDirection; // 0x140 (Size: 0x20, Type: StructProperty)
    FAIDataProviderFloatValue ArcAngle; // 0x160 (Size: 0x38, Type: StructProperty)
    float AngleRadians; // 0x198 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_19c[0x4]; // 0x19c (Size: 0x4, Type: PaddingProperty)
    UClass* CircleCenter; // 0x1a0 (Size: 0x8, Type: ClassProperty)
    bool bIgnoreAnyContextActorsWhenGeneratingCircle; // 0x1a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a9[0x7]; // 0x1a9 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue CircleCenterZOffset; // 0x1b0 (Size: 0x38, Type: StructProperty)
    FEnvTraceData TraceData; // 0x1e8 (Size: 0x38, Type: StructProperty)
    uint8_t bDefineArc : 1; // 0x220:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_221[0x7]; // 0x221 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryGenerator_OnCircle) == 0x228, "Size mismatch for UEnvQueryGenerator_OnCircle");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, CircleRadius) == 0x90, "Offset mismatch for UEnvQueryGenerator_OnCircle::CircleRadius");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, PointOnCircleSpacingMethod) == 0xc8, "Offset mismatch for UEnvQueryGenerator_OnCircle::PointOnCircleSpacingMethod");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, SpaceBetween) == 0xd0, "Offset mismatch for UEnvQueryGenerator_OnCircle::SpaceBetween");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, NumberOfPoints) == 0x108, "Offset mismatch for UEnvQueryGenerator_OnCircle::NumberOfPoints");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, ArcDirection) == 0x140, "Offset mismatch for UEnvQueryGenerator_OnCircle::ArcDirection");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, ArcAngle) == 0x160, "Offset mismatch for UEnvQueryGenerator_OnCircle::ArcAngle");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, AngleRadians) == 0x198, "Offset mismatch for UEnvQueryGenerator_OnCircle::AngleRadians");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, CircleCenter) == 0x1a0, "Offset mismatch for UEnvQueryGenerator_OnCircle::CircleCenter");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, bIgnoreAnyContextActorsWhenGeneratingCircle) == 0x1a8, "Offset mismatch for UEnvQueryGenerator_OnCircle::bIgnoreAnyContextActorsWhenGeneratingCircle");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, CircleCenterZOffset) == 0x1b0, "Offset mismatch for UEnvQueryGenerator_OnCircle::CircleCenterZOffset");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, TraceData) == 0x1e8, "Offset mismatch for UEnvQueryGenerator_OnCircle::TraceData");
static_assert(offsetof(UEnvQueryGenerator_OnCircle, bDefineArc) == 0x220, "Offset mismatch for UEnvQueryGenerator_OnCircle::bDefineArc");

// Size: 0x180 (Inherited: 0x240, Single: 0xffffff40)
class UEnvQueryGenerator_PathingGrid : public UEnvQueryGenerator_SimpleGrid
{
public:
    FAIDataProviderBoolValue PathToItem; // 0x108 (Size: 0x38, Type: StructProperty)
    UClass* NavigationFilter; // 0x140 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue ScanRangeMultiplier; // 0x148 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UEnvQueryGenerator_PathingGrid) == 0x180, "Size mismatch for UEnvQueryGenerator_PathingGrid");
static_assert(offsetof(UEnvQueryGenerator_PathingGrid, PathToItem) == 0x108, "Offset mismatch for UEnvQueryGenerator_PathingGrid::PathToItem");
static_assert(offsetof(UEnvQueryGenerator_PathingGrid, NavigationFilter) == 0x140, "Offset mismatch for UEnvQueryGenerator_PathingGrid::NavigationFilter");
static_assert(offsetof(UEnvQueryGenerator_PathingGrid, ScanRangeMultiplier) == 0x148, "Offset mismatch for UEnvQueryGenerator_PathingGrid::ScanRangeMultiplier");

// Size: 0x108 (Inherited: 0x138, Single: 0xffffffd0)
class UEnvQueryGenerator_SimpleGrid : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue GridSize; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween; // 0xc8 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround; // 0x100 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryGenerator_SimpleGrid) == 0x108, "Size mismatch for UEnvQueryGenerator_SimpleGrid");
static_assert(offsetof(UEnvQueryGenerator_SimpleGrid, GridSize) == 0x90, "Offset mismatch for UEnvQueryGenerator_SimpleGrid::GridSize");
static_assert(offsetof(UEnvQueryGenerator_SimpleGrid, SpaceBetween) == 0xc8, "Offset mismatch for UEnvQueryGenerator_SimpleGrid::SpaceBetween");
static_assert(offsetof(UEnvQueryGenerator_SimpleGrid, GenerateAround) == 0x100, "Offset mismatch for UEnvQueryGenerator_SimpleGrid::GenerateAround");

// Size: 0xa8 (Inherited: 0xa8, Single: 0x0)
class UEnvQueryGenerator_PerceivedActors : public UEnvQueryGenerator
{
public:
    UClass* AllowedActorClass; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue SearchRadius; // 0x58 (Size: 0x38, Type: StructProperty)
    UClass* ListenerContext; // 0x90 (Size: 0x8, Type: ClassProperty)
    UClass* SenseToUse; // 0x98 (Size: 0x8, Type: ClassProperty)
    bool bIncludeKnownActors; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryGenerator_PerceivedActors) == 0xa8, "Size mismatch for UEnvQueryGenerator_PerceivedActors");
static_assert(offsetof(UEnvQueryGenerator_PerceivedActors, AllowedActorClass) == 0x50, "Offset mismatch for UEnvQueryGenerator_PerceivedActors::AllowedActorClass");
static_assert(offsetof(UEnvQueryGenerator_PerceivedActors, SearchRadius) == 0x58, "Offset mismatch for UEnvQueryGenerator_PerceivedActors::SearchRadius");
static_assert(offsetof(UEnvQueryGenerator_PerceivedActors, ListenerContext) == 0x90, "Offset mismatch for UEnvQueryGenerator_PerceivedActors::ListenerContext");
static_assert(offsetof(UEnvQueryGenerator_PerceivedActors, SenseToUse) == 0x98, "Offset mismatch for UEnvQueryGenerator_PerceivedActors::SenseToUse");
static_assert(offsetof(UEnvQueryGenerator_PerceivedActors, bIncludeKnownActors) == 0xa0, "Offset mismatch for UEnvQueryGenerator_PerceivedActors::bIncludeKnownActors");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UEnvQueryItemType : public UObject
{
public:
};

static_assert(sizeof(UEnvQueryItemType) == 0x30, "Size mismatch for UEnvQueryItemType");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UEnvQueryItemType_Actor : public UEnvQueryItemType_ActorBase
{
public:
};

static_assert(sizeof(UEnvQueryItemType_Actor) == 0x30, "Size mismatch for UEnvQueryItemType_Actor");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UEnvQueryItemType_ActorBase : public UEnvQueryItemType_VectorBase
{
public:
};

static_assert(sizeof(UEnvQueryItemType_ActorBase) == 0x30, "Size mismatch for UEnvQueryItemType_ActorBase");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UEnvQueryItemType_VectorBase : public UEnvQueryItemType
{
public:
};

static_assert(sizeof(UEnvQueryItemType_VectorBase) == 0x30, "Size mismatch for UEnvQueryItemType_VectorBase");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UEnvQueryItemType_Direction : public UEnvQueryItemType_VectorBase
{
public:
};

static_assert(sizeof(UEnvQueryItemType_Direction) == 0x30, "Size mismatch for UEnvQueryItemType_Direction");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UEnvQueryItemType_Point : public UEnvQueryItemType_VectorBase
{
public:
};

static_assert(sizeof(UEnvQueryItemType_Point) == 0x30, "Size mismatch for UEnvQueryItemType_Point");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UEnvQueryTest_Distance : public UEnvQueryTest
{
public:
    TEnumAsByte<EEnvTestDistance> TestMode; // 0x1f8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    UClass* DistanceTo; // 0x200 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryTest_Distance) == 0x208, "Size mismatch for UEnvQueryTest_Distance");
static_assert(offsetof(UEnvQueryTest_Distance, TestMode) == 0x1f8, "Offset mismatch for UEnvQueryTest_Distance::TestMode");
static_assert(offsetof(UEnvQueryTest_Distance, DistanceTo) == 0x200, "Offset mismatch for UEnvQueryTest_Distance::DistanceTo");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UEnvQueryTest_Dot : public UEnvQueryTest
{
public:
    FEnvDirection LineA; // 0x1f8 (Size: 0x20, Type: StructProperty)
    FEnvDirection LineB; // 0x218 (Size: 0x20, Type: StructProperty)
    uint8_t TestMode; // 0x238 (Size: 0x1, Type: EnumProperty)
    bool bAbsoluteValue; // 0x239 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_23a[0x6]; // 0x23a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryTest_Dot) == 0x240, "Size mismatch for UEnvQueryTest_Dot");
static_assert(offsetof(UEnvQueryTest_Dot, LineA) == 0x1f8, "Offset mismatch for UEnvQueryTest_Dot::LineA");
static_assert(offsetof(UEnvQueryTest_Dot, LineB) == 0x218, "Offset mismatch for UEnvQueryTest_Dot::LineB");
static_assert(offsetof(UEnvQueryTest_Dot, TestMode) == 0x238, "Offset mismatch for UEnvQueryTest_Dot::TestMode");
static_assert(offsetof(UEnvQueryTest_Dot, bAbsoluteValue) == 0x239, "Offset mismatch for UEnvQueryTest_Dot::bAbsoluteValue");

// Size: 0x268 (Inherited: 0x250, Single: 0x18)
class UEnvQueryTest_GameplayTags : public UEnvQueryTest
{
public:
    FGameplayTagQuery TagQueryToMatch; // 0x1f8 (Size: 0x48, Type: StructProperty)
    bool bRejectIncompatibleItems; // 0x240 (Size: 0x1, Type: BoolProperty)
    bool bUpdatedToUseQuery; // 0x241 (Size: 0x1, Type: BoolProperty)
    uint8_t TagsToMatch; // 0x242 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_243[0x5]; // 0x243 (Size: 0x5, Type: PaddingProperty)
    FGameplayTagContainer GameplayTags; // 0x248 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UEnvQueryTest_GameplayTags) == 0x268, "Size mismatch for UEnvQueryTest_GameplayTags");
static_assert(offsetof(UEnvQueryTest_GameplayTags, TagQueryToMatch) == 0x1f8, "Offset mismatch for UEnvQueryTest_GameplayTags::TagQueryToMatch");
static_assert(offsetof(UEnvQueryTest_GameplayTags, bRejectIncompatibleItems) == 0x240, "Offset mismatch for UEnvQueryTest_GameplayTags::bRejectIncompatibleItems");
static_assert(offsetof(UEnvQueryTest_GameplayTags, bUpdatedToUseQuery) == 0x241, "Offset mismatch for UEnvQueryTest_GameplayTags::bUpdatedToUseQuery");
static_assert(offsetof(UEnvQueryTest_GameplayTags, TagsToMatch) == 0x242, "Offset mismatch for UEnvQueryTest_GameplayTags::TagsToMatch");
static_assert(offsetof(UEnvQueryTest_GameplayTags, GameplayTags) == 0x248, "Offset mismatch for UEnvQueryTest_GameplayTags::GameplayTags");

// Size: 0x228 (Inherited: 0x250, Single: 0xffffffd8)
class UEnvQueryTest_Overlap : public UEnvQueryTest
{
public:
    FEnvOverlapData OverlapData; // 0x1f8 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UEnvQueryTest_Overlap) == 0x228, "Size mismatch for UEnvQueryTest_Overlap");
static_assert(offsetof(UEnvQueryTest_Overlap, OverlapData) == 0x1f8, "Offset mismatch for UEnvQueryTest_Overlap::OverlapData");

// Size: 0x280 (Inherited: 0x250, Single: 0x30)
class UEnvQueryTest_Pathfinding : public UEnvQueryTest
{
public:
    TEnumAsByte<EEnvTestPathfinding> TestMode; // 0x1f8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    UClass* Context; // 0x200 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue PathFromContext; // 0x208 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue SkipUnreachable; // 0x240 (Size: 0x38, Type: StructProperty)
    UClass* FilterClass; // 0x278 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryTest_Pathfinding) == 0x280, "Size mismatch for UEnvQueryTest_Pathfinding");
static_assert(offsetof(UEnvQueryTest_Pathfinding, TestMode) == 0x1f8, "Offset mismatch for UEnvQueryTest_Pathfinding::TestMode");
static_assert(offsetof(UEnvQueryTest_Pathfinding, Context) == 0x200, "Offset mismatch for UEnvQueryTest_Pathfinding::Context");
static_assert(offsetof(UEnvQueryTest_Pathfinding, PathFromContext) == 0x208, "Offset mismatch for UEnvQueryTest_Pathfinding::PathFromContext");
static_assert(offsetof(UEnvQueryTest_Pathfinding, SkipUnreachable) == 0x240, "Offset mismatch for UEnvQueryTest_Pathfinding::SkipUnreachable");
static_assert(offsetof(UEnvQueryTest_Pathfinding, FilterClass) == 0x278, "Offset mismatch for UEnvQueryTest_Pathfinding::FilterClass");

// Size: 0x2b8 (Inherited: 0x4d0, Single: 0xfffffde8)
class UEnvQueryTest_PathfindingBatch : public UEnvQueryTest_Pathfinding
{
public:
    FAIDataProviderFloatValue ScanRangeMultiplier; // 0x280 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UEnvQueryTest_PathfindingBatch) == 0x2b8, "Size mismatch for UEnvQueryTest_PathfindingBatch");
static_assert(offsetof(UEnvQueryTest_PathfindingBatch, ScanRangeMultiplier) == 0x280, "Offset mismatch for UEnvQueryTest_PathfindingBatch::ScanRangeMultiplier");

// Size: 0x230 (Inherited: 0x250, Single: 0xffffffe0)
class UEnvQueryTest_Project : public UEnvQueryTest
{
public:
    FEnvTraceData ProjectionData; // 0x1f8 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UEnvQueryTest_Project) == 0x230, "Size mismatch for UEnvQueryTest_Project");
static_assert(offsetof(UEnvQueryTest_Project, ProjectionData) == 0x1f8, "Offset mismatch for UEnvQueryTest_Project::ProjectionData");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UEnvQueryTest_Random : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UEnvQueryTest_Random) == 0x1f8, "Size mismatch for UEnvQueryTest_Random");

// Size: 0x2e0 (Inherited: 0x250, Single: 0x90)
class UEnvQueryTest_Trace : public UEnvQueryTest
{
public:
    FEnvTraceData TraceData; // 0x1f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue TraceFromContext; // 0x230 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ItemHeightOffset; // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ContextHeightOffset; // 0x2a0 (Size: 0x38, Type: StructProperty)
    UClass* Context; // 0x2d8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UEnvQueryTest_Trace) == 0x2e0, "Size mismatch for UEnvQueryTest_Trace");
static_assert(offsetof(UEnvQueryTest_Trace, TraceData) == 0x1f8, "Offset mismatch for UEnvQueryTest_Trace::TraceData");
static_assert(offsetof(UEnvQueryTest_Trace, TraceFromContext) == 0x230, "Offset mismatch for UEnvQueryTest_Trace::TraceFromContext");
static_assert(offsetof(UEnvQueryTest_Trace, ItemHeightOffset) == 0x268, "Offset mismatch for UEnvQueryTest_Trace::ItemHeightOffset");
static_assert(offsetof(UEnvQueryTest_Trace, ContextHeightOffset) == 0x2a0, "Offset mismatch for UEnvQueryTest_Trace::ContextHeightOffset");
static_assert(offsetof(UEnvQueryTest_Trace, Context) == 0x2d8, "Offset mismatch for UEnvQueryTest_Trace::Context");

// Size: 0x210 (Inherited: 0x250, Single: 0xffffffc0)
class UEnvQueryTest_Volume : public UEnvQueryTest
{
public:
    UClass* VolumeContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* VolumeClass; // 0x200 (Size: 0x8, Type: ClassProperty)
    uint8_t bDoComplexVolumeTest : 1; // 0x208:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bSkipTestIfNoVolumes : 1; // 0x208:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_209[0x7]; // 0x209 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnvQueryTest_Volume) == 0x210, "Size mismatch for UEnvQueryTest_Volume");
static_assert(offsetof(UEnvQueryTest_Volume, VolumeContext) == 0x1f8, "Offset mismatch for UEnvQueryTest_Volume::VolumeContext");
static_assert(offsetof(UEnvQueryTest_Volume, VolumeClass) == 0x200, "Offset mismatch for UEnvQueryTest_Volume::VolumeClass");
static_assert(offsetof(UEnvQueryTest_Volume, bDoComplexVolumeTest) == 0x208, "Offset mismatch for UEnvQueryTest_Volume::bDoComplexVolumeTest");
static_assert(offsetof(UEnvQueryTest_Volume, bSkipTestIfNoVolumes) == 0x208, "Offset mismatch for UEnvQueryTest_Volume::bSkipTestIfNoVolumes");

// Size: 0x3c8 (Inherited: 0x9d8, Single: 0xfffff9f0)
class AGridPathAIController : public AAIController
{
public:
};

static_assert(sizeof(AGridPathAIController) == 0x3c8, "Size mismatch for AGridPathAIController");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAIHotSpotManager : public UObject
{
public:
};

static_assert(sizeof(UAIHotSpotManager) == 0x28, "Size mismatch for UAIHotSpotManager");

// Size: 0x358 (Inherited: 0x3e8, Single: 0xffffff70)
class UCrowdFollowingComponent : public UPathFollowingComponent
{
public:
    uint8_t Pad_308[0x18]; // 0x308 (Size: 0x18, Type: PaddingProperty)
    FVector CrowdAgentMoveDirection; // 0x320 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_338[0x20]; // 0x338 (Size: 0x20, Type: PaddingProperty)

public:
    void SuspendCrowdSteering(bool& bSuspend); // 0xaf9fb48 (Index: 0x0, Flags: RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCrowdFollowingComponent) == 0x358, "Size mismatch for UCrowdFollowingComponent");
static_assert(offsetof(UCrowdFollowingComponent, CrowdAgentMoveDirection) == 0x320, "Offset mismatch for UCrowdFollowingComponent::CrowdAgentMoveDirection");

// Size: 0x308 (Inherited: 0xe0, Single: 0x228)
class UPathFollowingComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x38]; // 0xb8 (Size: 0x38, Type: PaddingProperty)
    UNavMovementComponent* MovementComp; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_f8[0x20]; // 0xf8 (Size: 0x20, Type: PaddingProperty)
    ANavigationData* MyNavData; // 0x118 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_120[0x1e8]; // 0x120 (Size: 0x1e8, Type: PaddingProperty)

public:
    TEnumAsByte<EPathFollowingAction> GetPathActionType() const; // 0xafc7528 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetPathDestination() const; // 0xafc75a0 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void OnActorBump(AActor*& SelfActor, AActor*& OtherActor, FVector& NormalImpulse, const FHitResult Hit); // 0xafc8638 (Index: 0x2, Flags: RequiredAPI|Native|Public|HasOutParms|HasDefaults)

protected:
    void OnNavDataRegistered(ANavigationData*& NavData); // 0xafc897c (Index: 0x3, Flags: Final|RequiredAPI|Native|Protected)
};

static_assert(sizeof(UPathFollowingComponent) == 0x308, "Size mismatch for UPathFollowingComponent");
static_assert(offsetof(UPathFollowingComponent, MovementComp) == 0xf0, "Offset mismatch for UPathFollowingComponent::MovementComp");
static_assert(offsetof(UPathFollowingComponent, MyNavData) == 0x118, "Offset mismatch for UPathFollowingComponent::MyNavData");

// Size: 0xf0 (Inherited: 0x50, Single: 0xa0)
class UCrowdManager : public UCrowdManagerBase
{
public:
    ANavigationData* MyNavData; // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FCrowdAvoidanceConfig> AvoidanceConfig; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCrowdAvoidanceSamplingPattern> SamplingPatterns; // 0x40 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxAgents; // 0x50 (Size: 0x4, Type: IntProperty)
    float MaxAgentRadius; // 0x54 (Size: 0x4, Type: FloatProperty)
    int32_t MaxAvoidedAgents; // 0x58 (Size: 0x4, Type: IntProperty)
    int32_t MaxAvoidedWalls; // 0x5c (Size: 0x4, Type: IntProperty)
    float NavmeshCheckInterval; // 0x60 (Size: 0x4, Type: FloatProperty)
    float PathOptimizationInterval; // 0x64 (Size: 0x4, Type: FloatProperty)
    float SeparationDirClamp; // 0x68 (Size: 0x4, Type: FloatProperty)
    float PathOffsetRadiusMultiplier; // 0x6c (Size: 0x4, Type: FloatProperty)
    uint8_t bResolveCollisions : 1; // 0x70:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7f]; // 0x71 (Size: 0x7f, Type: PaddingProperty)
};

static_assert(sizeof(UCrowdManager) == 0xf0, "Size mismatch for UCrowdManager");
static_assert(offsetof(UCrowdManager, MyNavData) == 0x28, "Offset mismatch for UCrowdManager::MyNavData");
static_assert(offsetof(UCrowdManager, AvoidanceConfig) == 0x30, "Offset mismatch for UCrowdManager::AvoidanceConfig");
static_assert(offsetof(UCrowdManager, SamplingPatterns) == 0x40, "Offset mismatch for UCrowdManager::SamplingPatterns");
static_assert(offsetof(UCrowdManager, MaxAgents) == 0x50, "Offset mismatch for UCrowdManager::MaxAgents");
static_assert(offsetof(UCrowdManager, MaxAgentRadius) == 0x54, "Offset mismatch for UCrowdManager::MaxAgentRadius");
static_assert(offsetof(UCrowdManager, MaxAvoidedAgents) == 0x58, "Offset mismatch for UCrowdManager::MaxAvoidedAgents");
static_assert(offsetof(UCrowdManager, MaxAvoidedWalls) == 0x5c, "Offset mismatch for UCrowdManager::MaxAvoidedWalls");
static_assert(offsetof(UCrowdManager, NavmeshCheckInterval) == 0x60, "Offset mismatch for UCrowdManager::NavmeshCheckInterval");
static_assert(offsetof(UCrowdManager, PathOptimizationInterval) == 0x64, "Offset mismatch for UCrowdManager::PathOptimizationInterval");
static_assert(offsetof(UCrowdManager, SeparationDirClamp) == 0x68, "Offset mismatch for UCrowdManager::SeparationDirClamp");
static_assert(offsetof(UCrowdManager, PathOffsetRadiusMultiplier) == 0x6c, "Offset mismatch for UCrowdManager::PathOffsetRadiusMultiplier");
static_assert(offsetof(UCrowdManager, bResolveCollisions) == 0x70, "Offset mismatch for UCrowdManager::bResolveCollisions");

// Size: 0x338 (Inherited: 0x3e8, Single: 0xffffff50)
class UGridPathFollowingComponent : public UPathFollowingComponent
{
public:
    UNavLocalGridManager* GridManager; // 0x308 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_310[0x28]; // 0x310 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UGridPathFollowingComponent) == 0x338, "Size mismatch for UGridPathFollowingComponent");
static_assert(offsetof(UGridPathFollowingComponent, GridManager) == 0x308, "Offset mismatch for UGridPathFollowingComponent::GridManager");

// Size: 0x48 (Inherited: 0x70, Single: 0xffffffd8)
class UNavFilter_AIControllerDefault : public UNavigationQueryFilter
{
public:
};

static_assert(sizeof(UNavFilter_AIControllerDefault) == 0x48, "Size mismatch for UNavFilter_AIControllerDefault");

// Size: 0x2f8 (Inherited: 0x2d0, Single: 0x28)
class ANavLinkProxy : public AActor
{
public:
    uint8_t Pad_2a8[0x10]; // 0x2a8 (Size: 0x10, Type: PaddingProperty)
    TArray<FNavigationLink> PointLinks; // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    TArray<FNavigationSegmentLink> SegmentLinks; // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    UNavLinkCustomComponent* SmartLinkComp; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    bool bSmartLinkIsRelevant; // 0x2e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e1[0x7]; // 0x2e1 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnSmartLinkReached[0x10]; // 0x2e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    bool HasMovingAgents() const; // 0xafc82b8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSmartLinkEnabled() const; // 0xafc8614 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ReceiveSmartLinkReached(AActor*& Agent, const FVector Destination); // 0x288a61c (Index: 0x2, Flags: RequiredAPI|Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    void ResumePathFollowing(AActor*& Agent); // 0xafcb4b4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSmartLinkEnabled(bool& bEnabled); // 0xafcc380 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ANavLinkProxy) == 0x2f8, "Size mismatch for ANavLinkProxy");
static_assert(offsetof(ANavLinkProxy, PointLinks) == 0x2b8, "Offset mismatch for ANavLinkProxy::PointLinks");
static_assert(offsetof(ANavLinkProxy, SegmentLinks) == 0x2c8, "Offset mismatch for ANavLinkProxy::SegmentLinks");
static_assert(offsetof(ANavLinkProxy, SmartLinkComp) == 0x2d8, "Offset mismatch for ANavLinkProxy::SmartLinkComp");
static_assert(offsetof(ANavLinkProxy, bSmartLinkIsRelevant) == 0x2e0, "Offset mismatch for ANavLinkProxy::bSmartLinkIsRelevant");
static_assert(offsetof(ANavLinkProxy, OnSmartLinkReached) == 0x2e8, "Offset mismatch for ANavLinkProxy::OnSmartLinkReached");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UNavLocalGridManager : public UObject
{
public:

public:
    static int32_t AddLocalNavigationGridForBox(UObject*& WorldContextObject, const FVector Location, FVector& Extent, FRotator& Rotation, int32_t& const Radius2D, float& const Height, bool& bRebuildGrids); // 0xafc4dd0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t AddLocalNavigationGridForCapsule(UObject*& WorldContextObject, const FVector Location, float& CapsuleRadius, float& CapsuleHalfHeight, int32_t& const Radius2D, float& const Height, bool& bRebuildGrids); // 0xafc5194 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t AddLocalNavigationGridForPoint(UObject*& WorldContextObject, const FVector Location, int32_t& const Radius2D, float& const Height, bool& bRebuildGrids); // 0xafc5594 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t AddLocalNavigationGridForPoints(UObject*& WorldContextObject, const TArray<FVector> Locations, int32_t& const Radius2D, float& const Height, bool& bRebuildGrids); // 0xafc58f4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool FindLocalNavigationGridPath(UObject*& WorldContextObject, const FVector Start, const FVector End, TArray<FVector>& PathPoints); // 0xafc5d54 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void RemoveLocalNavigationGrid(UObject*& WorldContextObject, int32_t& GridId, bool& bRebuildGrids); // 0xafc9cec (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static bool SetLocalNavigationGridDensity(UObject*& WorldContextObject, float& CellSize); // 0xafcba34 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UNavLocalGridManager) == 0x58, "Size mismatch for UNavLocalGridManager");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UPathFollowingManager : public UObject
{
public:
};

static_assert(sizeof(UPathFollowingManager) == 0x28, "Size mismatch for UPathFollowingManager");

// Size: 0x1a0 (Inherited: 0xe0, Single: 0xc0)
class UAIPerceptionComponent : public UActorComponent
{
public:
    TArray<UAISenseConfig*> SensesConfig; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    UClass* DominantSense; // 0xc8 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_d0[0x8]; // 0xd0 (Size: 0x8, Type: PaddingProperty)
    AAIController* AIOwner; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_e0[0x80]; // 0xe0 (Size: 0x80, Type: PaddingProperty)
    uint8_t OnPerceptionUpdated[0x10]; // 0x160 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTargetPerceptionForgotten[0x10]; // 0x170 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTargetPerceptionUpdated[0x10]; // 0x180 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTargetPerceptionInfoUpdated[0x10]; // 0x190 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void ForgetAll(); // 0xafc6210 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool GetActorsPerception(AActor*& Actor, FActorPerceptionBlueprintInfo& Info); // 0xafc6224 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void GetCurrentlyPerceivedActors(UClass*& SenseToUse, TArray<AActor*>& OutActors) const; // 0xafc6ae0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetKnownPerceivedActors(UClass*& SenseToUse, TArray<AActor*>& OutActors) const; // 0xafc7004 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetPerceivedHostileActors(TArray<AActor*>& OutActors) const; // 0xafc75d8 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetPerceivedHostileActorsBySense(UClass*& const SenseToUse, TArray<AActor*>& OutActors) const; // 0xafc7880 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool IsSenseEnabled(UClass*& SenseClass) const; // 0xafc8330 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnOwnerEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0xafc8d38 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public)
    void RequestStimuliListenerUpdate(); // 0xafcb4a0 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSenseEnabled(UClass*& SenseClass, bool& const bEnable); // 0xafcbd6c (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAIPerceptionComponent) == 0x1a0, "Size mismatch for UAIPerceptionComponent");
static_assert(offsetof(UAIPerceptionComponent, SensesConfig) == 0xb8, "Offset mismatch for UAIPerceptionComponent::SensesConfig");
static_assert(offsetof(UAIPerceptionComponent, DominantSense) == 0xc8, "Offset mismatch for UAIPerceptionComponent::DominantSense");
static_assert(offsetof(UAIPerceptionComponent, AIOwner) == 0xd8, "Offset mismatch for UAIPerceptionComponent::AIOwner");
static_assert(offsetof(UAIPerceptionComponent, OnPerceptionUpdated) == 0x160, "Offset mismatch for UAIPerceptionComponent::OnPerceptionUpdated");
static_assert(offsetof(UAIPerceptionComponent, OnTargetPerceptionForgotten) == 0x170, "Offset mismatch for UAIPerceptionComponent::OnTargetPerceptionForgotten");
static_assert(offsetof(UAIPerceptionComponent, OnTargetPerceptionUpdated) == 0x180, "Offset mismatch for UAIPerceptionComponent::OnTargetPerceptionUpdated");
static_assert(offsetof(UAIPerceptionComponent, OnTargetPerceptionInfoUpdated) == 0x190, "Offset mismatch for UAIPerceptionComponent::OnTargetPerceptionInfoUpdated");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAIPerceptionListenerInterface : public UInterface
{
public:
};

static_assert(sizeof(UAIPerceptionListenerInterface) == 0x28, "Size mismatch for UAIPerceptionListenerInterface");

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class UAIPerceptionStimuliSourceComponent : public UActorComponent
{
public:
    uint8_t bAutoRegisterAsSource : 1; // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    TArray<UClass*> RegisterAsSourceForSenses; // 0xc0 (Size: 0x10, Type: ArrayProperty)

public:
    void RegisterForSense(UClass*& SenseClass); // 0xafc9150 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void RegisterWithPerceptionSystem(); // 0xafc9cd8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void UnregisterFromPerceptionSystem(); // 0xafcc4b0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void UnregisterFromSense(UClass*& SenseClass); // 0xafcc4c4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAIPerceptionStimuliSourceComponent) == 0xd0, "Size mismatch for UAIPerceptionStimuliSourceComponent");
static_assert(offsetof(UAIPerceptionStimuliSourceComponent, bAutoRegisterAsSource) == 0xb8, "Offset mismatch for UAIPerceptionStimuliSourceComponent::bAutoRegisterAsSource");
static_assert(offsetof(UAIPerceptionStimuliSourceComponent, RegisterAsSourceForSenses) == 0xc0, "Offset mismatch for UAIPerceptionStimuliSourceComponent::RegisterAsSourceForSenses");

// Size: 0x130 (Inherited: 0x60, Single: 0xd0)
class UAIPerceptionSystem : public UAISubsystem
{
public:
    uint8_t Pad_38[0x50]; // 0x38 (Size: 0x50, Type: PaddingProperty)
    TArray<UAISense*> Senses; // 0x88 (Size: 0x10, Type: ArrayProperty)
    float PerceptionAgingRate; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x94]; // 0x9c (Size: 0x94, Type: PaddingProperty)

public:
    static UClass* GetSenseClassForStimulus(UObject*& WorldContextObject, const FAIStimulus Stimulus); // 0xafc7f28 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool RegisterPerceptionStimuliSource(UObject*& WorldContextObject, UClass*& Sense, AActor*& Target); // 0xafc9634 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    void ReportEvent(UAISenseEvent*& PerceptionEvent); // 0xafca4b4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    static void ReportPerceptionEvent(UObject*& WorldContextObject, UAISenseEvent*& PerceptionEvent); // 0xafca938 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)

protected:
    void OnPerceptionStimuliSourceEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0xafc8f44 (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected)
};

static_assert(sizeof(UAIPerceptionSystem) == 0x130, "Size mismatch for UAIPerceptionSystem");
static_assert(offsetof(UAIPerceptionSystem, Senses) == 0x88, "Offset mismatch for UAIPerceptionSystem::Senses");
static_assert(offsetof(UAIPerceptionSystem, PerceptionAgingRate) == 0x98, "Offset mismatch for UAIPerceptionSystem::PerceptionAgingRate");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UAISense : public UObject
{
public:
    uint8_t NotifyType; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    uint8_t bWantsNewPawnNotification : 1; // 0x2c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAutoRegisterAllPawnsAsSources : 1; // 0x2c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    UAIPerceptionSystem* PerceptionSystemInstance; // 0x30 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_38[0x40]; // 0x38 (Size: 0x40, Type: PaddingProperty)
};

static_assert(sizeof(UAISense) == 0x78, "Size mismatch for UAISense");
static_assert(offsetof(UAISense, NotifyType) == 0x28, "Offset mismatch for UAISense::NotifyType");
static_assert(offsetof(UAISense, bWantsNewPawnNotification) == 0x2c, "Offset mismatch for UAISense::bWantsNewPawnNotification");
static_assert(offsetof(UAISense, bAutoRegisterAllPawnsAsSources) == 0x2c, "Offset mismatch for UAISense::bAutoRegisterAllPawnsAsSources");
static_assert(offsetof(UAISense, PerceptionSystemInstance) == 0x30, "Offset mismatch for UAISense::PerceptionSystemInstance");

// Size: 0x50 (Inherited: 0x70, Single: 0xffffffe0)
class UAISenseConfig_Damage : public UAISenseConfig
{
public:
    UClass* Implementation; // 0x48 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UAISenseConfig_Damage) == 0x50, "Size mismatch for UAISenseConfig_Damage");
static_assert(offsetof(UAISenseConfig_Damage, Implementation) == 0x48, "Offset mismatch for UAISenseConfig_Damage::Implementation");

// Size: 0xa0 (Inherited: 0xa0, Single: 0x0)
class UAISense_Blueprint : public UAISense
{
public:
    UClass* ListenerDataType; // 0x78 (Size: 0x8, Type: ClassProperty)
    TArray<UAIPerceptionComponent*> ListenerContainer; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<UAISenseEvent*> UnprocessedEvents; // 0x90 (Size: 0x10, Type: ArrayProperty)

public:
    void GetAllListenerActors(TArray<AActor*>& ListenerActors) const; // 0xafc659c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetAllListenerComponents(TArray<UAIPerceptionComponent*>& ListenerComponents) const; // 0xafc6840 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    virtual void K2_OnNewPawn(APawn*& NewPawn); // 0x288a61c (Index: 0x2, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    virtual void OnListenerRegistered(AActor*& ActorListener, UAIPerceptionComponent*& PerceptionComponent); // 0x288a61c (Index: 0x3, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    virtual void OnListenerUnregistered(AActor*& ActorListener, UAIPerceptionComponent*& PerceptionComponent); // 0x288a61c (Index: 0x4, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    virtual void OnListenerUpdated(AActor*& ActorListener, UAIPerceptionComponent*& PerceptionComponent); // 0x288a61c (Index: 0x5, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    virtual float OnUpdate(const TArray<UAISenseEvent*> EventsToProcess); // 0x288a61c (Index: 0x6, Flags: RequiredAPI|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UAISense_Blueprint) == 0xa0, "Size mismatch for UAISense_Blueprint");
static_assert(offsetof(UAISense_Blueprint, ListenerDataType) == 0x78, "Offset mismatch for UAISense_Blueprint::ListenerDataType");
static_assert(offsetof(UAISense_Blueprint, ListenerContainer) == 0x80, "Offset mismatch for UAISense_Blueprint::ListenerContainer");
static_assert(offsetof(UAISense_Blueprint, UnprocessedEvents) == 0x90, "Offset mismatch for UAISense_Blueprint::UnprocessedEvents");

// Size: 0x88 (Inherited: 0xa0, Single: 0xffffffe8)
class UAISense_Damage : public UAISense
{
public:
    TArray<FAIDamageEvent> RegisteredEvents; // 0x78 (Size: 0x10, Type: ArrayProperty)

public:
    static void ReportDamageEvent(UObject*& WorldContextObject, AActor*& DamagedActor, AActor*& Instigator, float& DamageAmount, FVector& EventLocation, FVector& HitLocation, FName& Tag); // 0xafc9ff4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAISense_Damage) == 0x88, "Size mismatch for UAISense_Damage");
static_assert(offsetof(UAISense_Damage, RegisteredEvents) == 0x78, "Offset mismatch for UAISense_Damage::RegisteredEvents");

// Size: 0xe0 (Inherited: 0xa0, Single: 0x40)
class UAISense_Hearing : public UAISense
{
public:
    TArray<FAINoiseEvent> NoiseEvents; // 0x78 (Size: 0x10, Type: ArrayProperty)
    float SpeedOfSoundSq; // 0x88 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8c[0x54]; // 0x8c (Size: 0x54, Type: PaddingProperty)

public:
    static void ReportNoiseEvent(UObject*& WorldContextObject, FVector& NoiseLocation, float& Loudness, AActor*& Instigator, float& MaxRange, FName& Tag); // 0xafca61c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAISense_Hearing) == 0xe0, "Size mismatch for UAISense_Hearing");
static_assert(offsetof(UAISense_Hearing, NoiseEvents) == 0x78, "Offset mismatch for UAISense_Hearing::NoiseEvents");
static_assert(offsetof(UAISense_Hearing, SpeedOfSoundSq) == 0x88, "Offset mismatch for UAISense_Hearing::SpeedOfSoundSq");

// Size: 0x88 (Inherited: 0xa0, Single: 0xffffffe8)
class UAISense_Prediction : public UAISense
{
public:
    TArray<FAIPredictionEvent> RegisteredEvents; // 0x78 (Size: 0x10, Type: ArrayProperty)

public:
    static void RequestControllerPredictionEvent(AAIController*& Requestor, AActor*& PredictedActor, float& PredictionTime); // 0xafcaee8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RequestPawnPredictionEvent(APawn*& Requestor, AActor*& PredictedActor, float& PredictionTime); // 0xafcb1c4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAISense_Prediction) == 0x88, "Size mismatch for UAISense_Prediction");
static_assert(offsetof(UAISense_Prediction, RegisteredEvents) == 0x78, "Offset mismatch for UAISense_Prediction::RegisteredEvents");

// Size: 0x1a8 (Inherited: 0xa0, Single: 0x108)
class UAISense_Sight : public UAISense
{
public:
    uint8_t Pad_78[0xd8]; // 0x78 (Size: 0xd8, Type: PaddingProperty)
    int32_t MaxTracesPerTick; // 0x150 (Size: 0x4, Type: IntProperty)
    int32_t MaxAsyncTracesPerTick; // 0x154 (Size: 0x4, Type: IntProperty)
    int32_t MinQueriesPerTimeSliceCheck; // 0x158 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_15c[0x4]; // 0x15c (Size: 0x4, Type: PaddingProperty)
    double MaxTimeSlicePerTick; // 0x160 (Size: 0x8, Type: DoubleProperty)
    float HighImportanceQueryDistanceThreshold; // 0x168 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_16c[0x4]; // 0x16c (Size: 0x4, Type: PaddingProperty)
    float MaxQueryImportance; // 0x170 (Size: 0x4, Type: FloatProperty)
    float SightLimitQueryImportance; // 0x174 (Size: 0x4, Type: FloatProperty)
    float PendingQueriesBudgetReductionRatio; // 0x178 (Size: 0x4, Type: FloatProperty)
    bool bUseAsynchronousTraceForDefaultSightQueries; // 0x17c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17d[0x2b]; // 0x17d (Size: 0x2b, Type: PaddingProperty)
};

static_assert(sizeof(UAISense_Sight) == 0x1a8, "Size mismatch for UAISense_Sight");
static_assert(offsetof(UAISense_Sight, MaxTracesPerTick) == 0x150, "Offset mismatch for UAISense_Sight::MaxTracesPerTick");
static_assert(offsetof(UAISense_Sight, MaxAsyncTracesPerTick) == 0x154, "Offset mismatch for UAISense_Sight::MaxAsyncTracesPerTick");
static_assert(offsetof(UAISense_Sight, MinQueriesPerTimeSliceCheck) == 0x158, "Offset mismatch for UAISense_Sight::MinQueriesPerTimeSliceCheck");
static_assert(offsetof(UAISense_Sight, MaxTimeSlicePerTick) == 0x160, "Offset mismatch for UAISense_Sight::MaxTimeSlicePerTick");
static_assert(offsetof(UAISense_Sight, HighImportanceQueryDistanceThreshold) == 0x168, "Offset mismatch for UAISense_Sight::HighImportanceQueryDistanceThreshold");
static_assert(offsetof(UAISense_Sight, MaxQueryImportance) == 0x170, "Offset mismatch for UAISense_Sight::MaxQueryImportance");
static_assert(offsetof(UAISense_Sight, SightLimitQueryImportance) == 0x174, "Offset mismatch for UAISense_Sight::SightLimitQueryImportance");
static_assert(offsetof(UAISense_Sight, PendingQueriesBudgetReductionRatio) == 0x178, "Offset mismatch for UAISense_Sight::PendingQueriesBudgetReductionRatio");
static_assert(offsetof(UAISense_Sight, bUseAsynchronousTraceForDefaultSightQueries) == 0x17c, "Offset mismatch for UAISense_Sight::bUseAsynchronousTraceForDefaultSightQueries");

// Size: 0x88 (Inherited: 0xa0, Single: 0xffffffe8)
class UAISense_Team : public UAISense
{
public:
    TArray<FAITeamStimulusEvent> RegisteredEvents; // 0x78 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAISense_Team) == 0x88, "Size mismatch for UAISense_Team");
static_assert(offsetof(UAISense_Team, RegisteredEvents) == 0x78, "Offset mismatch for UAISense_Team::RegisteredEvents");

// Size: 0xd8 (Inherited: 0xa0, Single: 0x38)
class UAISense_Touch : public UAISense
{
public:
    TArray<FAITouchEvent> RegisteredEvents; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x50]; // 0x88 (Size: 0x50, Type: PaddingProperty)

public:
    static void ReportTouchEvent(UObject*& WorldContextObject, AActor*& TouchReceiver, AActor*& OtherActor, FVector& Location); // 0xafcab88 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAISense_Touch) == 0xd8, "Size mismatch for UAISense_Touch");
static_assert(offsetof(UAISense_Touch, RegisteredEvents) == 0x78, "Offset mismatch for UAISense_Touch::RegisteredEvents");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAISightTargetInterface : public UInterface
{
public:
};

static_assert(sizeof(UAISightTargetInterface) == 0x28, "Size mismatch for UAISightTargetInterface");

// Size: 0x100 (Inherited: 0xe0, Single: 0x20)
class UPawnSensingComponent : public UActorComponent
{
public:
    float HearingThreshold; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float LOSHearingThreshold; // 0xbc (Size: 0x4, Type: FloatProperty)
    float SightRadius; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SensingInterval; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float HearingMaxSoundAge; // 0xc8 (Size: 0x4, Type: FloatProperty)
    uint8_t bEnableSensingUpdates : 1; // 0xcc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOnlySensePlayers : 1; // 0xcc:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bSeePawns : 1; // 0xcc:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bHearNoises : 1; // 0xcc:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0xb]; // 0xcd (Size: 0xb, Type: PaddingProperty)
    uint8_t OnSeePawn[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnHearNoise[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float PeripheralVisionAngle; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float PeripheralVisionCosine; // 0xfc (Size: 0x4, Type: FloatProperty)

public:
    float GetPeripheralVisionAngle() const; // 0xa32d2c0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPeripheralVisionCosine() const; // 0xafc7f10 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void HearNoiseDelegate__DelegateSignature(APawn*& Instigator, const FVector Location, float& Volume); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults)
    void SeePawnDelegate__DelegateSignature(APawn*& Pawn); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void SetPeripheralVisionAngle(float& const NewPeripheralVisionAngle); // 0xafcbc3c (Index: 0x4, Flags: RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetSensingInterval(float& const NewSensingInterval); // 0xafcc120 (Index: 0x5, Flags: RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetSensingUpdatesEnabled(bool& const bEnabled); // 0xafcc250 (Index: 0x6, Flags: RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UPawnSensingComponent) == 0x100, "Size mismatch for UPawnSensingComponent");
static_assert(offsetof(UPawnSensingComponent, HearingThreshold) == 0xb8, "Offset mismatch for UPawnSensingComponent::HearingThreshold");
static_assert(offsetof(UPawnSensingComponent, LOSHearingThreshold) == 0xbc, "Offset mismatch for UPawnSensingComponent::LOSHearingThreshold");
static_assert(offsetof(UPawnSensingComponent, SightRadius) == 0xc0, "Offset mismatch for UPawnSensingComponent::SightRadius");
static_assert(offsetof(UPawnSensingComponent, SensingInterval) == 0xc4, "Offset mismatch for UPawnSensingComponent::SensingInterval");
static_assert(offsetof(UPawnSensingComponent, HearingMaxSoundAge) == 0xc8, "Offset mismatch for UPawnSensingComponent::HearingMaxSoundAge");
static_assert(offsetof(UPawnSensingComponent, bEnableSensingUpdates) == 0xcc, "Offset mismatch for UPawnSensingComponent::bEnableSensingUpdates");
static_assert(offsetof(UPawnSensingComponent, bOnlySensePlayers) == 0xcc, "Offset mismatch for UPawnSensingComponent::bOnlySensePlayers");
static_assert(offsetof(UPawnSensingComponent, bSeePawns) == 0xcc, "Offset mismatch for UPawnSensingComponent::bSeePawns");
static_assert(offsetof(UPawnSensingComponent, bHearNoises) == 0xcc, "Offset mismatch for UPawnSensingComponent::bHearNoises");
static_assert(offsetof(UPawnSensingComponent, OnSeePawn) == 0xd8, "Offset mismatch for UPawnSensingComponent::OnSeePawn");
static_assert(offsetof(UPawnSensingComponent, OnHearNoise) == 0xe8, "Offset mismatch for UPawnSensingComponent::OnHearNoise");
static_assert(offsetof(UPawnSensingComponent, PeripheralVisionAngle) == 0xf8, "Offset mismatch for UPawnSensingComponent::PeripheralVisionAngle");
static_assert(offsetof(UPawnSensingComponent, PeripheralVisionCosine) == 0xfc, "Offset mismatch for UPawnSensingComponent::PeripheralVisionCosine");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UAITask : public UGameplayTask
{
public:
    AAIController* OwnerController; // 0x60 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAITask) == 0x68, "Size mismatch for UAITask");
static_assert(offsetof(UAITask, OwnerController) == 0x60, "Offset mismatch for UAITask::OwnerController");

// Size: 0x68 (Inherited: 0xf0, Single: 0xffffff78)
class UAITask_LockLogic : public UAITask
{
public:
};

static_assert(sizeof(UAITask_LockLogic) == 0x68, "Size mismatch for UAITask_LockLogic");

// Size: 0x118 (Inherited: 0xf0, Single: 0x28)
class UAITask_MoveTo : public UAITask
{
public:
    uint8_t OnRequestFailed[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMoveFinished[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FAIMoveRequest MoveRequest; // 0x88 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_d8[0x40]; // 0xd8 (Size: 0x40, Type: PaddingProperty)

public:
    static UAITask_MoveTo* AIMoveTo(AAIController*& Controller, FVector& GoalLocation, AActor*& GoalActor, float& AcceptanceRadius, TEnumAsByte<EAIOptionFlag>& StopOnOverlap, TEnumAsByte<EAIOptionFlag>& AcceptPartialPath, bool& bUsePathfinding, bool& bLockAILogic, bool& bUseContinuousGoalTracking, TEnumAsByte<EAIOptionFlag>& ProjectGoalOnNavigation, TEnumAsByte<EAIOptionFlag>& RequireNavigableEndLocation); // 0xafc483c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAITask_MoveTo) == 0x118, "Size mismatch for UAITask_MoveTo");
static_assert(offsetof(UAITask_MoveTo, OnRequestFailed) == 0x68, "Offset mismatch for UAITask_MoveTo::OnRequestFailed");
static_assert(offsetof(UAITask_MoveTo, OnMoveFinished) == 0x78, "Offset mismatch for UAITask_MoveTo::OnMoveFinished");
static_assert(offsetof(UAITask_MoveTo, MoveRequest) == 0x88, "Offset mismatch for UAITask_MoveTo::MoveRequest");

// Size: 0xe0 (Inherited: 0xf0, Single: 0xfffffff0)
class UAITask_RunEQS : public UAITask
{
public:

public:
    static UAITask_RunEQS* RunEQS(AAIController*& Controller, UEnvQuery*& QueryTemplate); // 0xafcb628 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAITask_RunEQS) == 0xe0, "Size mismatch for UAITask_RunEQS");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UVisualLoggerExtension : public UObject
{
public:
};

static_assert(sizeof(UVisualLoggerExtension) == 0x28, "Size mismatch for UVisualLoggerExtension");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FActorPerceptionUpdateInfo
{
    int32_t TargetId; // 0x0 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AActor*> Target; // 0x4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FAIStimulus Stimulus; // 0x10 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FActorPerceptionUpdateInfo) == 0x60, "Size mismatch for FActorPerceptionUpdateInfo");
static_assert(offsetof(FActorPerceptionUpdateInfo, TargetId) == 0x0, "Offset mismatch for FActorPerceptionUpdateInfo::TargetId");
static_assert(offsetof(FActorPerceptionUpdateInfo, Target) == 0x4, "Offset mismatch for FActorPerceptionUpdateInfo::Target");
static_assert(offsetof(FActorPerceptionUpdateInfo, Stimulus) == 0x10, "Offset mismatch for FActorPerceptionUpdateInfo::Stimulus");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAIStimulus
{
    float Age; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ExpirationAge; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Strength; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector StimulusLocation; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector ReceiverLocation; // 0x28 (Size: 0x18, Type: StructProperty)
    FName Tag; // 0x40 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_44[0x8]; // 0x44 (Size: 0x8, Type: PaddingProperty)
    uint8_t bSuccessfullySensed : 1; // 0x4c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAIStimulus) == 0x50, "Size mismatch for FAIStimulus");
static_assert(offsetof(FAIStimulus, Age) == 0x0, "Offset mismatch for FAIStimulus::Age");
static_assert(offsetof(FAIStimulus, ExpirationAge) == 0x4, "Offset mismatch for FAIStimulus::ExpirationAge");
static_assert(offsetof(FAIStimulus, Strength) == 0x8, "Offset mismatch for FAIStimulus::Strength");
static_assert(offsetof(FAIStimulus, StimulusLocation) == 0x10, "Offset mismatch for FAIStimulus::StimulusLocation");
static_assert(offsetof(FAIStimulus, ReceiverLocation) == 0x28, "Offset mismatch for FAIStimulus::ReceiverLocation");
static_assert(offsetof(FAIStimulus, Tag) == 0x40, "Offset mismatch for FAIStimulus::Tag");
static_assert(offsetof(FAIStimulus, bSuccessfullySensed) == 0x4c, "Offset mismatch for FAIStimulus::bSuccessfullySensed");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FAIRequestID
{
    uint32_t RequestID; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FAIRequestID) == 0x4, "Size mismatch for FAIRequestID");
static_assert(offsetof(FAIRequestID, RequestID) == 0x0, "Offset mismatch for FAIRequestID::RequestID");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FEnvNamedValue
{
    FName ParamName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParamType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float Value; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FEnvNamedValue) == 0xc, "Size mismatch for FEnvNamedValue");
static_assert(offsetof(FEnvNamedValue, ParamName) == 0x0, "Offset mismatch for FEnvNamedValue::ParamName");
static_assert(offsetof(FEnvNamedValue, ParamType) == 0x4, "Offset mismatch for FEnvNamedValue::ParamType");
static_assert(offsetof(FEnvNamedValue, Value) == 0x8, "Offset mismatch for FEnvNamedValue::Value");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FAIDynamicParam
{
    FName ParamName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParamType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t bAllowBBKey : 1; // 0x5:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    float Value; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FBlackboardKeySelector BBKey; // 0x10 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FAIDynamicParam) == 0x38, "Size mismatch for FAIDynamicParam");
static_assert(offsetof(FAIDynamicParam, ParamName) == 0x0, "Offset mismatch for FAIDynamicParam::ParamName");
static_assert(offsetof(FAIDynamicParam, ParamType) == 0x4, "Offset mismatch for FAIDynamicParam::ParamType");
static_assert(offsetof(FAIDynamicParam, bAllowBBKey) == 0x5, "Offset mismatch for FAIDynamicParam::bAllowBBKey");
static_assert(offsetof(FAIDynamicParam, Value) == 0x8, "Offset mismatch for FAIDynamicParam::Value");
static_assert(offsetof(FAIDynamicParam, BBKey) == 0x10, "Offset mismatch for FAIDynamicParam::BBKey");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBlackboardKeySelector
{
    TArray<UBlackboardKeyType*> AllowedTypes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FName SelectedKeyName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    UClass* SelectedKeyType; // 0x18 (Size: 0x8, Type: ClassProperty)
    int32_t SelectedKeyID; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t bNoneIsAllowedValue : 1; // 0x24:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FBlackboardKeySelector) == 0x28, "Size mismatch for FBlackboardKeySelector");
static_assert(offsetof(FBlackboardKeySelector, AllowedTypes) == 0x0, "Offset mismatch for FBlackboardKeySelector::AllowedTypes");
static_assert(offsetof(FBlackboardKeySelector, SelectedKeyName) == 0x10, "Offset mismatch for FBlackboardKeySelector::SelectedKeyName");
static_assert(offsetof(FBlackboardKeySelector, SelectedKeyType) == 0x18, "Offset mismatch for FBlackboardKeySelector::SelectedKeyType");
static_assert(offsetof(FBlackboardKeySelector, SelectedKeyID) == 0x20, "Offset mismatch for FBlackboardKeySelector::SelectedKeyID");
static_assert(offsetof(FBlackboardKeySelector, bNoneIsAllowedValue) == 0x24, "Offset mismatch for FBlackboardKeySelector::bNoneIsAllowedValue");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAIMoveRequest
{
    TWeakObjectPtr<AActor*> GoalActor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x48]; // 0x8 (Size: 0x48, Type: PaddingProperty)
};

static_assert(sizeof(FAIMoveRequest) == 0x50, "Size mismatch for FAIMoveRequest");
static_assert(offsetof(FAIMoveRequest, GoalActor) == 0x0, "Offset mismatch for FAIMoveRequest::GoalActor");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FIntervalCountdown
{
    float Interval; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FIntervalCountdown) == 0x8, "Size mismatch for FIntervalCountdown");
static_assert(offsetof(FIntervalCountdown, Interval) == 0x0, "Offset mismatch for FIntervalCountdown::Interval");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FEnvDirection
{
    UClass* LineFrom; // 0x0 (Size: 0x8, Type: ClassProperty)
    UClass* LineTo; // 0x8 (Size: 0x8, Type: ClassProperty)
    UClass* Rotation; // 0x10 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EEnvDirection> DirMode; // 0x18 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FEnvDirection) == 0x20, "Size mismatch for FEnvDirection");
static_assert(offsetof(FEnvDirection, LineFrom) == 0x0, "Offset mismatch for FEnvDirection::LineFrom");
static_assert(offsetof(FEnvDirection, LineTo) == 0x8, "Offset mismatch for FEnvDirection::LineTo");
static_assert(offsetof(FEnvDirection, Rotation) == 0x10, "Offset mismatch for FEnvDirection::Rotation");
static_assert(offsetof(FEnvDirection, DirMode) == 0x18, "Offset mismatch for FEnvDirection::DirMode");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FEnvTraceData
{
    int32_t VersionNum; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UClass* NavigationFilter; // 0x8 (Size: 0x8, Type: ClassProperty)
    float ProjectDown; // 0x10 (Size: 0x4, Type: FloatProperty)
    float ProjectUp; // 0x14 (Size: 0x4, Type: FloatProperty)
    float ExtentX; // 0x18 (Size: 0x4, Type: FloatProperty)
    float ExtentY; // 0x1c (Size: 0x4, Type: FloatProperty)
    float ExtentZ; // 0x20 (Size: 0x4, Type: FloatProperty)
    float PostProjectionVerticalOffset; // 0x24 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel; // 0x28 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ECollisionChannel> SerializedChannel; // 0x29 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FName TraceProfileName; // 0x2c (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EEnvTraceShape> TraceShape; // 0x30 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvQueryTrace> TraceMode; // 0x31 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    uint8_t bTraceComplex : 1; // 0x34:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOnlyBlockingHits : 1; // 0x34:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanTraceOnNavMesh : 1; // 0x34:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanTraceOnGeometry : 1; // 0x34:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanDisableTrace : 1; // 0x34:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanProjectDown : 1; // 0x34:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FEnvTraceData) == 0x38, "Size mismatch for FEnvTraceData");
static_assert(offsetof(FEnvTraceData, VersionNum) == 0x0, "Offset mismatch for FEnvTraceData::VersionNum");
static_assert(offsetof(FEnvTraceData, NavigationFilter) == 0x8, "Offset mismatch for FEnvTraceData::NavigationFilter");
static_assert(offsetof(FEnvTraceData, ProjectDown) == 0x10, "Offset mismatch for FEnvTraceData::ProjectDown");
static_assert(offsetof(FEnvTraceData, ProjectUp) == 0x14, "Offset mismatch for FEnvTraceData::ProjectUp");
static_assert(offsetof(FEnvTraceData, ExtentX) == 0x18, "Offset mismatch for FEnvTraceData::ExtentX");
static_assert(offsetof(FEnvTraceData, ExtentY) == 0x1c, "Offset mismatch for FEnvTraceData::ExtentY");
static_assert(offsetof(FEnvTraceData, ExtentZ) == 0x20, "Offset mismatch for FEnvTraceData::ExtentZ");
static_assert(offsetof(FEnvTraceData, PostProjectionVerticalOffset) == 0x24, "Offset mismatch for FEnvTraceData::PostProjectionVerticalOffset");
static_assert(offsetof(FEnvTraceData, TraceChannel) == 0x28, "Offset mismatch for FEnvTraceData::TraceChannel");
static_assert(offsetof(FEnvTraceData, SerializedChannel) == 0x29, "Offset mismatch for FEnvTraceData::SerializedChannel");
static_assert(offsetof(FEnvTraceData, TraceProfileName) == 0x2c, "Offset mismatch for FEnvTraceData::TraceProfileName");
static_assert(offsetof(FEnvTraceData, TraceShape) == 0x30, "Offset mismatch for FEnvTraceData::TraceShape");
static_assert(offsetof(FEnvTraceData, TraceMode) == 0x31, "Offset mismatch for FEnvTraceData::TraceMode");
static_assert(offsetof(FEnvTraceData, bTraceComplex) == 0x34, "Offset mismatch for FEnvTraceData::bTraceComplex");
static_assert(offsetof(FEnvTraceData, bOnlyBlockingHits) == 0x34, "Offset mismatch for FEnvTraceData::bOnlyBlockingHits");
static_assert(offsetof(FEnvTraceData, bCanTraceOnNavMesh) == 0x34, "Offset mismatch for FEnvTraceData::bCanTraceOnNavMesh");
static_assert(offsetof(FEnvTraceData, bCanTraceOnGeometry) == 0x34, "Offset mismatch for FEnvTraceData::bCanTraceOnGeometry");
static_assert(offsetof(FEnvTraceData, bCanDisableTrace) == 0x34, "Offset mismatch for FEnvTraceData::bCanDisableTrace");
static_assert(offsetof(FEnvTraceData, bCanProjectDown) == 0x34, "Offset mismatch for FEnvTraceData::bCanProjectDown");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEnvOverlapData
{
    float ExtentX; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ExtentY; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ExtentZ; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector ShapeOffset; // 0x10 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> OverlapChannel; // 0x28 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvOverlapShape> OverlapShape; // 0x29 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    uint8_t bOnlyBlockingHits : 1; // 0x2c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverlapComplex : 1; // 0x2c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bSkipOverlapQuerier : 1; // 0x2c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FEnvOverlapData) == 0x30, "Size mismatch for FEnvOverlapData");
static_assert(offsetof(FEnvOverlapData, ExtentX) == 0x0, "Offset mismatch for FEnvOverlapData::ExtentX");
static_assert(offsetof(FEnvOverlapData, ExtentY) == 0x4, "Offset mismatch for FEnvOverlapData::ExtentY");
static_assert(offsetof(FEnvOverlapData, ExtentZ) == 0x8, "Offset mismatch for FEnvOverlapData::ExtentZ");
static_assert(offsetof(FEnvOverlapData, ShapeOffset) == 0x10, "Offset mismatch for FEnvOverlapData::ShapeOffset");
static_assert(offsetof(FEnvOverlapData, OverlapChannel) == 0x28, "Offset mismatch for FEnvOverlapData::OverlapChannel");
static_assert(offsetof(FEnvOverlapData, OverlapShape) == 0x29, "Offset mismatch for FEnvOverlapData::OverlapShape");
static_assert(offsetof(FEnvOverlapData, bOnlyBlockingHits) == 0x2c, "Offset mismatch for FEnvOverlapData::bOnlyBlockingHits");
static_assert(offsetof(FEnvOverlapData, bOverlapComplex) == 0x2c, "Offset mismatch for FEnvOverlapData::bOverlapComplex");
static_assert(offsetof(FEnvOverlapData, bSkipOverlapQuerier) == 0x2c, "Offset mismatch for FEnvOverlapData::bSkipOverlapQuerier");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FEnvQueryResult
{
    UClass* ItemType; // 0x10 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_18[0x14]; // 0x18 (Size: 0x14, Type: PaddingProperty)
    int32_t OptionIndex; // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t QueryID; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0xc]; // 0x34 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FEnvQueryResult) == 0x40, "Size mismatch for FEnvQueryResult");
static_assert(offsetof(FEnvQueryResult, ItemType) == 0x10, "Offset mismatch for FEnvQueryResult::ItemType");
static_assert(offsetof(FEnvQueryResult, OptionIndex) == 0x2c, "Offset mismatch for FEnvQueryResult::OptionIndex");
static_assert(offsetof(FEnvQueryResult, QueryID) == 0x30, "Offset mismatch for FEnvQueryResult::QueryID");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FEQSParametrizedQueryExecutionRequest
{
    UEnvQuery* QueryTemplate; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FAIDynamicParam> QueryConfig; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FBlackboardKeySelector EQSQueryBlackboardKey; // 0x18 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EEnvQueryRunMode> RunMode; // 0x40 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_41[0x3]; // 0x41 (Size: 0x3, Type: PaddingProperty)
    uint8_t bUseBBKeyForQueryTemplate : 1; // 0x44:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x3]; // 0x45 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FEQSParametrizedQueryExecutionRequest) == 0x48, "Size mismatch for FEQSParametrizedQueryExecutionRequest");
static_assert(offsetof(FEQSParametrizedQueryExecutionRequest, QueryTemplate) == 0x0, "Offset mismatch for FEQSParametrizedQueryExecutionRequest::QueryTemplate");
static_assert(offsetof(FEQSParametrizedQueryExecutionRequest, QueryConfig) == 0x8, "Offset mismatch for FEQSParametrizedQueryExecutionRequest::QueryConfig");
static_assert(offsetof(FEQSParametrizedQueryExecutionRequest, EQSQueryBlackboardKey) == 0x18, "Offset mismatch for FEQSParametrizedQueryExecutionRequest::EQSQueryBlackboardKey");
static_assert(offsetof(FEQSParametrizedQueryExecutionRequest, RunMode) == 0x40, "Offset mismatch for FEQSParametrizedQueryExecutionRequest::RunMode");
static_assert(offsetof(FEQSParametrizedQueryExecutionRequest, bUseBBKeyForQueryTemplate) == 0x44, "Offset mismatch for FEQSParametrizedQueryExecutionRequest::bUseBBKeyForQueryTemplate");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGenericTeamId
{
    char TeamID; // 0x0 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FGenericTeamId) == 0x1, "Size mismatch for FGenericTeamId");
static_assert(offsetof(FGenericTeamId, TeamID) == 0x0, "Offset mismatch for FGenericTeamId::TeamID");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FSimpleIndexedHandleBase
{
};

static_assert(sizeof(FSimpleIndexedHandleBase) == 0x4, "Size mismatch for FSimpleIndexedHandleBase");

// Size: 0x8 (Inherited: 0x4, Single: 0x4)
struct FIndexedHandleBase : FSimpleIndexedHandleBase
{
};

static_assert(sizeof(FIndexedHandleBase) == 0x8, "Size mismatch for FIndexedHandleBase");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCompactIndexedHandleBase
{
};

static_assert(sizeof(FCompactIndexedHandleBase) == 0x4, "Size mismatch for FCompactIndexedHandleBase");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FSequentialIDBase
{
    uint32_t Value; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FSequentialIDBase) == 0x4, "Size mismatch for FSequentialIDBase");
static_assert(offsetof(FSequentialIDBase, Value) == 0x0, "Offset mismatch for FSequentialIDBase::Value");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FValueOrBlackboardKeyBase
{
    FName Key; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FValueOrBlackboardKeyBase) == 0x8, "Size mismatch for FValueOrBlackboardKeyBase");
static_assert(offsetof(FValueOrBlackboardKeyBase, Key) == 0x0, "Offset mismatch for FValueOrBlackboardKeyBase::Key");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FValueOrBBKey_Bool : FValueOrBlackboardKeyBase
{
    bool DefaultValue; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FValueOrBBKey_Bool) == 0xc, "Size mismatch for FValueOrBBKey_Bool");
static_assert(offsetof(FValueOrBBKey_Bool, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Bool::DefaultValue");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FValueOrBBKey_Class : FValueOrBlackboardKeyBase
{
    UClass* DefaultValue; // 0x8 (Size: 0x8, Type: ClassProperty)
    UClass* BaseClass; // 0x10 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FValueOrBBKey_Class) == 0x18, "Size mismatch for FValueOrBBKey_Class");
static_assert(offsetof(FValueOrBBKey_Class, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Class::DefaultValue");
static_assert(offsetof(FValueOrBBKey_Class, BaseClass) == 0x10, "Offset mismatch for FValueOrBBKey_Class::BaseClass");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FValueOrBBKey_Enum : FValueOrBlackboardKeyBase
{
    char DefaultValue; // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    UEnum* EnumType; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FString NativeEnumTypeName; // 0x18 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FValueOrBBKey_Enum) == 0x28, "Size mismatch for FValueOrBBKey_Enum");
static_assert(offsetof(FValueOrBBKey_Enum, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Enum::DefaultValue");
static_assert(offsetof(FValueOrBBKey_Enum, EnumType) == 0x10, "Offset mismatch for FValueOrBBKey_Enum::EnumType");
static_assert(offsetof(FValueOrBBKey_Enum, NativeEnumTypeName) == 0x18, "Offset mismatch for FValueOrBBKey_Enum::NativeEnumTypeName");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FValueOrBBKey_Float : FValueOrBlackboardKeyBase
{
    float DefaultValue; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FValueOrBBKey_Float) == 0xc, "Size mismatch for FValueOrBBKey_Float");
static_assert(offsetof(FValueOrBBKey_Float, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Float::DefaultValue");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FValueOrBBKey_Int32 : FValueOrBlackboardKeyBase
{
    int32_t DefaultValue; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FValueOrBBKey_Int32) == 0xc, "Size mismatch for FValueOrBBKey_Int32");
static_assert(offsetof(FValueOrBBKey_Int32, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Int32::DefaultValue");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FValueOrBBKey_Name : FValueOrBlackboardKeyBase
{
    FName DefaultValue; // 0x8 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FValueOrBBKey_Name) == 0xc, "Size mismatch for FValueOrBBKey_Name");
static_assert(offsetof(FValueOrBBKey_Name, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Name::DefaultValue");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FValueOrBBKey_String : FValueOrBlackboardKeyBase
{
    FString DefaultValue; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FValueOrBBKey_String) == 0x18, "Size mismatch for FValueOrBBKey_String");
static_assert(offsetof(FValueOrBBKey_String, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_String::DefaultValue");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FValueOrBBKey_Object : FValueOrBlackboardKeyBase
{
    UObject* DefaultValue; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* BaseClass; // 0x10 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FValueOrBBKey_Object) == 0x18, "Size mismatch for FValueOrBBKey_Object");
static_assert(offsetof(FValueOrBBKey_Object, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Object::DefaultValue");
static_assert(offsetof(FValueOrBBKey_Object, BaseClass) == 0x10, "Offset mismatch for FValueOrBBKey_Object::BaseClass");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FValueOrBBKey_Rotator : FValueOrBlackboardKeyBase
{
    FRotator DefaultValue; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FValueOrBBKey_Rotator) == 0x20, "Size mismatch for FValueOrBBKey_Rotator");
static_assert(offsetof(FValueOrBBKey_Rotator, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Rotator::DefaultValue");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FValueOrBBKey_Vector : FValueOrBlackboardKeyBase
{
    FVector DefaultValue; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FValueOrBBKey_Vector) == 0x20, "Size mismatch for FValueOrBBKey_Vector");
static_assert(offsetof(FValueOrBBKey_Vector, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Vector::DefaultValue");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FValueOrBBKey_Struct : FValueOrBlackboardKeyBase
{
    FInstancedStruct DefaultValue; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FValueOrBBKey_Struct) == 0x18, "Size mismatch for FValueOrBBKey_Struct");
static_assert(offsetof(FValueOrBBKey_Struct, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_Struct::DefaultValue");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBehaviorTreeTemplateInfo
{
    UBehaviorTree* Asset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UBTCompositeNode* Template; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FBehaviorTreeTemplateInfo) == 0x18, "Size mismatch for FBehaviorTreeTemplateInfo");
static_assert(offsetof(FBehaviorTreeTemplateInfo, Asset) == 0x0, "Offset mismatch for FBehaviorTreeTemplateInfo::Asset");
static_assert(offsetof(FBehaviorTreeTemplateInfo, Template) == 0x8, "Offset mismatch for FBehaviorTreeTemplateInfo::Template");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBlackboardEntry
{
    FName EntryName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UBlackboardKeyType* KeyType; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t bInstanceSynced : 1; // 0x10:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBlackboardEntry) == 0x18, "Size mismatch for FBlackboardEntry");
static_assert(offsetof(FBlackboardEntry, EntryName) == 0x0, "Offset mismatch for FBlackboardEntry::EntryName");
static_assert(offsetof(FBlackboardEntry, KeyType) == 0x8, "Offset mismatch for FBlackboardEntry::KeyType");
static_assert(offsetof(FBlackboardEntry, bInstanceSynced) == 0x10, "Offset mismatch for FBlackboardEntry::bInstanceSynced");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FBTDecoratorLogic
{
    TEnumAsByte<EBTDecoratorLogic> Operation; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x1]; // 0x1 (Size: 0x1, Type: PaddingProperty)
    uint16_t Number; // 0x2 (Size: 0x2, Type: UInt16Property)
};

static_assert(sizeof(FBTDecoratorLogic) == 0x4, "Size mismatch for FBTDecoratorLogic");
static_assert(offsetof(FBTDecoratorLogic, Operation) == 0x0, "Offset mismatch for FBTDecoratorLogic::Operation");
static_assert(offsetof(FBTDecoratorLogic, Number) == 0x2, "Offset mismatch for FBTDecoratorLogic::Number");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBTCompositeChild
{
    UBTCompositeNode* ChildComposite; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UBTTaskNode* ChildTask; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<UBTDecorator*> Decorators; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FBTDecoratorLogic> DecoratorOps; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBTCompositeChild) == 0x30, "Size mismatch for FBTCompositeChild");
static_assert(offsetof(FBTCompositeChild, ChildComposite) == 0x0, "Offset mismatch for FBTCompositeChild::ChildComposite");
static_assert(offsetof(FBTCompositeChild, ChildTask) == 0x8, "Offset mismatch for FBTCompositeChild::ChildTask");
static_assert(offsetof(FBTCompositeChild, Decorators) == 0x10, "Offset mismatch for FBTCompositeChild::Decorators");
static_assert(offsetof(FBTCompositeChild, DecoratorOps) == 0x20, "Offset mismatch for FBTCompositeChild::DecoratorOps");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAIDataProviderValue
{
    UAIDataProvider* DataBinding; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FName DataField; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAIDataProviderValue) == 0x20, "Size mismatch for FAIDataProviderValue");
static_assert(offsetof(FAIDataProviderValue, DataBinding) == 0x10, "Offset mismatch for FAIDataProviderValue::DataBinding");
static_assert(offsetof(FAIDataProviderValue, DataField) == 0x18, "Offset mismatch for FAIDataProviderValue::DataField");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FAIDataProviderTypedValue : FAIDataProviderValue
{
    UClass* PropertyType; // 0x20 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAIDataProviderTypedValue) == 0x30, "Size mismatch for FAIDataProviderTypedValue");
static_assert(offsetof(FAIDataProviderTypedValue, PropertyType) == 0x20, "Offset mismatch for FAIDataProviderTypedValue::PropertyType");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FAIDataProviderStructValue : FAIDataProviderValue
{
};

static_assert(sizeof(FAIDataProviderStructValue) == 0x30, "Size mismatch for FAIDataProviderStructValue");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
struct FAIDataProviderIntValue : FAIDataProviderTypedValue
{
    int32_t DefaultValue; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAIDataProviderIntValue) == 0x38, "Size mismatch for FAIDataProviderIntValue");
static_assert(offsetof(FAIDataProviderIntValue, DefaultValue) == 0x30, "Offset mismatch for FAIDataProviderIntValue::DefaultValue");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
struct FAIDataProviderFloatValue : FAIDataProviderTypedValue
{
    float DefaultValue; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAIDataProviderFloatValue) == 0x38, "Size mismatch for FAIDataProviderFloatValue");
static_assert(offsetof(FAIDataProviderFloatValue, DefaultValue) == 0x30, "Offset mismatch for FAIDataProviderFloatValue::DefaultValue");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
struct FAIDataProviderBoolValue : FAIDataProviderTypedValue
{
    bool DefaultValue; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAIDataProviderBoolValue) == 0x38, "Size mismatch for FAIDataProviderBoolValue");
static_assert(offsetof(FAIDataProviderBoolValue, DefaultValue) == 0x30, "Offset mismatch for FAIDataProviderBoolValue::DefaultValue");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEnvQueryManagerConfig
{
    float MaxAllowedTestingTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bTestQueriesUsingBreadth; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t QueryCountWarningThreshold; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    double QueryCountWarningInterval; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double ExecutionTimeWarningSeconds; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double HandlingResultTimeWarningSeconds; // 0x20 (Size: 0x8, Type: DoubleProperty)
    double GenerationTimeWarningSeconds; // 0x28 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FEnvQueryManagerConfig) == 0x30, "Size mismatch for FEnvQueryManagerConfig");
static_assert(offsetof(FEnvQueryManagerConfig, MaxAllowedTestingTime) == 0x0, "Offset mismatch for FEnvQueryManagerConfig::MaxAllowedTestingTime");
static_assert(offsetof(FEnvQueryManagerConfig, bTestQueriesUsingBreadth) == 0x4, "Offset mismatch for FEnvQueryManagerConfig::bTestQueriesUsingBreadth");
static_assert(offsetof(FEnvQueryManagerConfig, QueryCountWarningThreshold) == 0x8, "Offset mismatch for FEnvQueryManagerConfig::QueryCountWarningThreshold");
static_assert(offsetof(FEnvQueryManagerConfig, QueryCountWarningInterval) == 0x10, "Offset mismatch for FEnvQueryManagerConfig::QueryCountWarningInterval");
static_assert(offsetof(FEnvQueryManagerConfig, ExecutionTimeWarningSeconds) == 0x18, "Offset mismatch for FEnvQueryManagerConfig::ExecutionTimeWarningSeconds");
static_assert(offsetof(FEnvQueryManagerConfig, HandlingResultTimeWarningSeconds) == 0x20, "Offset mismatch for FEnvQueryManagerConfig::HandlingResultTimeWarningSeconds");
static_assert(offsetof(FEnvQueryManagerConfig, GenerationTimeWarningSeconds) == 0x28, "Offset mismatch for FEnvQueryManagerConfig::GenerationTimeWarningSeconds");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FEnvQueryRequest
{
    UEnvQuery* QueryTemplate; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* Owner; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UWorld* World; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_18[0x50]; // 0x18 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(FEnvQueryRequest) == 0x68, "Size mismatch for FEnvQueryRequest");
static_assert(offsetof(FEnvQueryRequest, QueryTemplate) == 0x0, "Offset mismatch for FEnvQueryRequest::QueryTemplate");
static_assert(offsetof(FEnvQueryRequest, Owner) == 0x8, "Offset mismatch for FEnvQueryRequest::Owner");
static_assert(offsetof(FEnvQueryRequest, World) == 0x10, "Offset mismatch for FEnvQueryRequest::World");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FEnvQueryInstanceCache
{
    UEnvQuery* Template; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x178]; // 0x8 (Size: 0x178, Type: PaddingProperty)
};

static_assert(sizeof(FEnvQueryInstanceCache) == 0x180, "Size mismatch for FEnvQueryInstanceCache");
static_assert(offsetof(FEnvQueryInstanceCache, Template) == 0x0, "Offset mismatch for FEnvQueryInstanceCache::Template");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FCrowdAvoidanceConfig
{
    float VelocityBias; // 0x0 (Size: 0x4, Type: FloatProperty)
    float DesiredVelocityWeight; // 0x4 (Size: 0x4, Type: FloatProperty)
    float CurrentVelocityWeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    float SideBiasWeight; // 0xc (Size: 0x4, Type: FloatProperty)
    float ImpactTimeWeight; // 0x10 (Size: 0x4, Type: FloatProperty)
    float ImpactTimeRange; // 0x14 (Size: 0x4, Type: FloatProperty)
    char CustomPatternIdx; // 0x18 (Size: 0x1, Type: ByteProperty)
    char AdaptiveDivisions; // 0x19 (Size: 0x1, Type: ByteProperty)
    char AdaptiveRings; // 0x1a (Size: 0x1, Type: ByteProperty)
    char AdaptiveDepth; // 0x1b (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FCrowdAvoidanceConfig) == 0x1c, "Size mismatch for FCrowdAvoidanceConfig");
static_assert(offsetof(FCrowdAvoidanceConfig, VelocityBias) == 0x0, "Offset mismatch for FCrowdAvoidanceConfig::VelocityBias");
static_assert(offsetof(FCrowdAvoidanceConfig, DesiredVelocityWeight) == 0x4, "Offset mismatch for FCrowdAvoidanceConfig::DesiredVelocityWeight");
static_assert(offsetof(FCrowdAvoidanceConfig, CurrentVelocityWeight) == 0x8, "Offset mismatch for FCrowdAvoidanceConfig::CurrentVelocityWeight");
static_assert(offsetof(FCrowdAvoidanceConfig, SideBiasWeight) == 0xc, "Offset mismatch for FCrowdAvoidanceConfig::SideBiasWeight");
static_assert(offsetof(FCrowdAvoidanceConfig, ImpactTimeWeight) == 0x10, "Offset mismatch for FCrowdAvoidanceConfig::ImpactTimeWeight");
static_assert(offsetof(FCrowdAvoidanceConfig, ImpactTimeRange) == 0x14, "Offset mismatch for FCrowdAvoidanceConfig::ImpactTimeRange");
static_assert(offsetof(FCrowdAvoidanceConfig, CustomPatternIdx) == 0x18, "Offset mismatch for FCrowdAvoidanceConfig::CustomPatternIdx");
static_assert(offsetof(FCrowdAvoidanceConfig, AdaptiveDivisions) == 0x19, "Offset mismatch for FCrowdAvoidanceConfig::AdaptiveDivisions");
static_assert(offsetof(FCrowdAvoidanceConfig, AdaptiveRings) == 0x1a, "Offset mismatch for FCrowdAvoidanceConfig::AdaptiveRings");
static_assert(offsetof(FCrowdAvoidanceConfig, AdaptiveDepth) == 0x1b, "Offset mismatch for FCrowdAvoidanceConfig::AdaptiveDepth");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCrowdAvoidanceSamplingPattern
{
    TArray<float> Angles; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<float> Radii; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCrowdAvoidanceSamplingPattern) == 0x20, "Size mismatch for FCrowdAvoidanceSamplingPattern");
static_assert(offsetof(FCrowdAvoidanceSamplingPattern, Angles) == 0x0, "Offset mismatch for FCrowdAvoidanceSamplingPattern::Angles");
static_assert(offsetof(FCrowdAvoidanceSamplingPattern, Radii) == 0x10, "Offset mismatch for FCrowdAvoidanceSamplingPattern::Radii");

// Size: 0xb8 (Inherited: 0x0, Single: 0xb8)
struct FRecastGraphWrapper
{
    ARecastNavMesh* RecastNavMeshActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0xb0]; // 0x8 (Size: 0xb0, Type: PaddingProperty)
};

static_assert(sizeof(FRecastGraphWrapper) == 0xb8, "Size mismatch for FRecastGraphWrapper");
static_assert(offsetof(FRecastGraphWrapper, RecastNavMeshActor) == 0x0, "Offset mismatch for FRecastGraphWrapper::RecastNavMeshActor");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FActorPerceptionBlueprintInfo
{
    AActor* Target; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FAIStimulus> LastSensedStimuli; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t bIsHostile : 1; // 0x18:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsFriendly : 1; // 0x18:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FActorPerceptionBlueprintInfo) == 0x20, "Size mismatch for FActorPerceptionBlueprintInfo");
static_assert(offsetof(FActorPerceptionBlueprintInfo, Target) == 0x0, "Offset mismatch for FActorPerceptionBlueprintInfo::Target");
static_assert(offsetof(FActorPerceptionBlueprintInfo, LastSensedStimuli) == 0x8, "Offset mismatch for FActorPerceptionBlueprintInfo::LastSensedStimuli");
static_assert(offsetof(FActorPerceptionBlueprintInfo, bIsHostile) == 0x18, "Offset mismatch for FActorPerceptionBlueprintInfo::bIsHostile");
static_assert(offsetof(FActorPerceptionBlueprintInfo, bIsFriendly) == 0x18, "Offset mismatch for FActorPerceptionBlueprintInfo::bIsFriendly");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FAISenseAffiliationFilter
{
    uint8_t bDetectEnemies : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bDetectNeutrals : 1; // 0x0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bDetectFriendlies : 1; // 0x0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAISenseAffiliationFilter) == 0x4, "Size mismatch for FAISenseAffiliationFilter");
static_assert(offsetof(FAISenseAffiliationFilter, bDetectEnemies) == 0x0, "Offset mismatch for FAISenseAffiliationFilter::bDetectEnemies");
static_assert(offsetof(FAISenseAffiliationFilter, bDetectNeutrals) == 0x0, "Offset mismatch for FAISenseAffiliationFilter::bDetectNeutrals");
static_assert(offsetof(FAISenseAffiliationFilter, bDetectFriendlies) == 0x0, "Offset mismatch for FAISenseAffiliationFilter::bDetectFriendlies");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAIDamageEvent
{
    float Amount; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector HitLocation; // 0x20 (Size: 0x18, Type: StructProperty)
    AActor* DamagedActor; // 0x38 (Size: 0x8, Type: ObjectProperty)
    AActor* Instigator; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName Tag; // 0x48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAIDamageEvent) == 0x50, "Size mismatch for FAIDamageEvent");
static_assert(offsetof(FAIDamageEvent, Amount) == 0x0, "Offset mismatch for FAIDamageEvent::Amount");
static_assert(offsetof(FAIDamageEvent, Location) == 0x8, "Offset mismatch for FAIDamageEvent::Location");
static_assert(offsetof(FAIDamageEvent, HitLocation) == 0x20, "Offset mismatch for FAIDamageEvent::HitLocation");
static_assert(offsetof(FAIDamageEvent, DamagedActor) == 0x38, "Offset mismatch for FAIDamageEvent::DamagedActor");
static_assert(offsetof(FAIDamageEvent, Instigator) == 0x40, "Offset mismatch for FAIDamageEvent::Instigator");
static_assert(offsetof(FAIDamageEvent, Tag) == 0x48, "Offset mismatch for FAIDamageEvent::Tag");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FAINoiseEvent
{
    FVector NoiseLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    float Loudness; // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxRange; // 0x24 (Size: 0x4, Type: FloatProperty)
    AActor* Instigator; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FName Tag; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAINoiseEvent) == 0x38, "Size mismatch for FAINoiseEvent");
static_assert(offsetof(FAINoiseEvent, NoiseLocation) == 0x8, "Offset mismatch for FAINoiseEvent::NoiseLocation");
static_assert(offsetof(FAINoiseEvent, Loudness) == 0x20, "Offset mismatch for FAINoiseEvent::Loudness");
static_assert(offsetof(FAINoiseEvent, MaxRange) == 0x24, "Offset mismatch for FAINoiseEvent::MaxRange");
static_assert(offsetof(FAINoiseEvent, Instigator) == 0x28, "Offset mismatch for FAINoiseEvent::Instigator");
static_assert(offsetof(FAINoiseEvent, Tag) == 0x30, "Offset mismatch for FAINoiseEvent::Tag");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAIPredictionEvent
{
    AActor* Requestor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* PredictedActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAIPredictionEvent) == 0x18, "Size mismatch for FAIPredictionEvent");
static_assert(offsetof(FAIPredictionEvent, Requestor) == 0x0, "Offset mismatch for FAIPredictionEvent::Requestor");
static_assert(offsetof(FAIPredictionEvent, PredictedActor) == 0x8, "Offset mismatch for FAIPredictionEvent::PredictedActor");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAISightEvent
{
    AActor* SeenActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* Observer; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAISightEvent) == 0x18, "Size mismatch for FAISightEvent");
static_assert(offsetof(FAISightEvent, SeenActor) == 0x8, "Offset mismatch for FAISightEvent::SeenActor");
static_assert(offsetof(FAISightEvent, Observer) == 0x10, "Offset mismatch for FAISightEvent::Observer");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAITeamStimulusEvent
{
    AActor* Broadcaster; // 0x40 (Size: 0x8, Type: ObjectProperty)
    AActor* Enemy; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAITeamStimulusEvent) == 0x50, "Size mismatch for FAITeamStimulusEvent");
static_assert(offsetof(FAITeamStimulusEvent, Broadcaster) == 0x40, "Offset mismatch for FAITeamStimulusEvent::Broadcaster");
static_assert(offsetof(FAITeamStimulusEvent, Enemy) == 0x48, "Offset mismatch for FAITeamStimulusEvent::Enemy");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAITouchEvent
{
    AActor* TouchReceiver; // 0x18 (Size: 0x8, Type: ObjectProperty)
    AActor* OtherActor; // 0x20 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAITouchEvent) == 0x30, "Size mismatch for FAITouchEvent");
static_assert(offsetof(FAITouchEvent, TouchReceiver) == 0x18, "Offset mismatch for FAITouchEvent::TouchReceiver");
static_assert(offsetof(FAITouchEvent, OtherActor) == 0x20, "Offset mismatch for FAITouchEvent::OtherActor");

