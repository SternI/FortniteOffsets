/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DualWieldingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Enums.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "Engine.h"

// Size: 0xb60 (Inherited: 0x1a68, Single: 0xfffff0f8)
class UFortGameplayAbility_ReloadPrimary : public UFortGameplayAbility_Reload
{
public:
};

static_assert(sizeof(UFortGameplayAbility_ReloadPrimary) == 0xb60, "Size mismatch for UFortGameplayAbility_ReloadPrimary");

// Size: 0xb60 (Inherited: 0x1a68, Single: 0xfffff0f8)
class UFortGameplayAbility_ReloadSecondary : public UFortGameplayAbility_Reload
{
public:
};

static_assert(sizeof(UFortGameplayAbility_ReloadSecondary) == 0xb60, "Size mismatch for UFortGameplayAbility_ReloadSecondary");

// Size: 0x25d8 (Inherited: 0x4220, Single: 0xffffe3b8)
class AFortWeaponRanged_DualWieldable : public AFortWeaponRanged
{
public:
    UAnimMontage* SecondaryFireAnimation; // 0x2590 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* SecondaryReloadAnimation; // 0x2598 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* BothPairedReloadAnimation; // 0x25a0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* SecondaryWeaponFireMontage; // 0x25a8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* SecondaryWeaponReloadMontage; // 0x25b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t DualWieldRole; // 0x25b8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_25b9[0x3]; // 0x25b9 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AFortWeaponRanged_DualWieldable*> PairedWeapon; // 0x25bc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_25c4[0x14]; // 0x25c4 (Size: 0x14, Type: PaddingProperty)

public:
    virtual void ClientHandleSecondaryReload(); // 0xe82f93c (Index: 0x0, Flags: Net|NetReliableNative|Event|Public|NetClient)
    bool GetIsTryingDualReload() const; // 0x113b5698 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFortWeaponRanged_DualWieldable* GetPairedWeapon(); // 0x113b56b4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsPrimaryWeapon(); // 0x113b56e0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void OnRep_PairedWeapon(); // 0x113b5834 (Index: 0xb, Flags: Final|Native|Public)
    void OnWeaponUnHolstered(); // 0x113b5848 (Index: 0xc, Flags: Final|Native|Public)
    bool PairedWeaponHasFullAmmo() const; // 0x113b585c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool TryReloadSecondaryWeapon(); // 0x113b59b0 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnPawnEnteredVehicle(); // 0x113b56fc (Index: 0x9, Flags: Final|Native|Private)
    void OnPawnVehicleSeatChanged(int32_t& SeatIndex); // 0x113b5710 (Index: 0xa, Flags: Final|Native|Private)

protected:
    virtual void MulticastClearIsTryingDualReload(); // 0xe82f8f4 (Index: 0x4, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void MulticastMarkHasTriedToFire(); // 0xe82f8ac (Index: 0x5, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void MulticastOnRequestEnclosedPassengerFire(); // 0xe82f894 (Index: 0x6, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void MulticastResetLeanState(); // 0xe82f87c (Index: 0x7, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void MulticastSetLeanReloadRequested(bool& bNewLeanReloadRequested); // 0x1119add4 (Index: 0x8, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void ServerMarkHasTriedToFire(); // 0xe835094 (Index: 0xe, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerOnRequestEnclosedVehicleFire(); // 0x1119a924 (Index: 0xf, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerResetLeanState(); // 0x11199e40 (Index: 0x10, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerSetIsTryingDualReload(bool& bNewIsTryingDualReload); // 0x113b5880 (Index: 0x11, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerSetLeanReloadRequested(bool& bNewLeanReloadRequested); // 0xe8363f4 (Index: 0x12, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(AFortWeaponRanged_DualWieldable) == 0x25d8, "Size mismatch for AFortWeaponRanged_DualWieldable");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, SecondaryFireAnimation) == 0x2590, "Offset mismatch for AFortWeaponRanged_DualWieldable::SecondaryFireAnimation");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, SecondaryReloadAnimation) == 0x2598, "Offset mismatch for AFortWeaponRanged_DualWieldable::SecondaryReloadAnimation");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, BothPairedReloadAnimation) == 0x25a0, "Offset mismatch for AFortWeaponRanged_DualWieldable::BothPairedReloadAnimation");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, SecondaryWeaponFireMontage) == 0x25a8, "Offset mismatch for AFortWeaponRanged_DualWieldable::SecondaryWeaponFireMontage");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, SecondaryWeaponReloadMontage) == 0x25b0, "Offset mismatch for AFortWeaponRanged_DualWieldable::SecondaryWeaponReloadMontage");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, DualWieldRole) == 0x25b8, "Offset mismatch for AFortWeaponRanged_DualWieldable::DualWieldRole");
static_assert(offsetof(AFortWeaponRanged_DualWieldable, PairedWeapon) == 0x25bc, "Offset mismatch for AFortWeaponRanged_DualWieldable::PairedWeapon");

