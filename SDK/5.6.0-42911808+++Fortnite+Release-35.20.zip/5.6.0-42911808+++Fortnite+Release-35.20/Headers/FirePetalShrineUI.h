/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalShrineUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "SlateCore.h"

// Size: 0x1e0 (Inherited: 0xe0, Single: 0x100)
class UFirePetalShrine_UIHelperComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush ShrineCompassBrush; // 0xc0 (Size: 0xb0, Type: StructProperty)
    FScalableFloat CanMarkShrinesInCompass; // 0x170 (Size: 0x28, Type: StructProperty)
    FScalableFloat ShrinesMarkedCompassTime; // 0x198 (Size: 0x28, Type: StructProperty)
    bool bAnchorCompassIconOnEdges; // 0x1c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c1[0x1f]; // 0x1c1 (Size: 0x1f, Type: PaddingProperty)

public:
    FCompassMarkHandle MarkOnCompass(AFortPlayerController*& FortPC) const; // 0x11417864 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void MarkOnCompassForDuration(AFortPlayerController*& FortPC, float& duration); // 0x114179c0 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void UnMarkFromCompass(const FCompassMarkHandle Handle) const; // 0x11417bc8 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFirePetalShrine_UIHelperComponent) == 0x1e0, "Size mismatch for UFirePetalShrine_UIHelperComponent");
static_assert(offsetof(UFirePetalShrine_UIHelperComponent, ShrineCompassBrush) == 0xc0, "Offset mismatch for UFirePetalShrine_UIHelperComponent::ShrineCompassBrush");
static_assert(offsetof(UFirePetalShrine_UIHelperComponent, CanMarkShrinesInCompass) == 0x170, "Offset mismatch for UFirePetalShrine_UIHelperComponent::CanMarkShrinesInCompass");
static_assert(offsetof(UFirePetalShrine_UIHelperComponent, ShrinesMarkedCompassTime) == 0x198, "Offset mismatch for UFirePetalShrine_UIHelperComponent::ShrinesMarkedCompassTime");
static_assert(offsetof(UFirePetalShrine_UIHelperComponent, bAnchorCompassIconOnEdges) == 0x1c0, "Offset mismatch for UFirePetalShrine_UIHelperComponent::bAnchorCompassIconOnEdges");

