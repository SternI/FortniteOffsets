/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_FortSettingMarkupVolume_JunoMusicVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0xa0 (Inherited: 0x1b8, Single: 0xfffffee8)
class UBP_FortSettingMarkupVolume_JunoMusicVolume_C : public UFortSettingVolumeMarkup
{
public:
};

static_assert(sizeof(UBP_FortSettingMarkupVolume_JunoMusicVolume_C) == 0xa0, "Size mismatch for UBP_FortSettingMarkupVolume_JunoMusicVolume_C");

