/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalWeaponGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x530 (Inherited: 0xdc8, Single: 0xfffff768)
class UFlavorFirePetalSMGAnimInstance : public UFortWeaponAnimInstance
{
public:
    double CurrentRotation; // 0x4f0 (Size: 0x8, Type: DoubleProperty)
    double ScaleDupeMag; // 0x4f8 (Size: 0x8, Type: DoubleProperty)
    double ScaleMag; // 0x500 (Size: 0x8, Type: DoubleProperty)
    double RotationAmount; // 0x508 (Size: 0x8, Type: DoubleProperty)
    FRotator CurrentRotator; // 0x510 (Size: 0x18, Type: StructProperty)
    bool bIsCrouchWalking; // 0x528 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_529[0x7]; // 0x529 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFlavorFirePetalSMGAnimInstance) == 0x530, "Size mismatch for UFlavorFirePetalSMGAnimInstance");
static_assert(offsetof(UFlavorFirePetalSMGAnimInstance, CurrentRotation) == 0x4f0, "Offset mismatch for UFlavorFirePetalSMGAnimInstance::CurrentRotation");
static_assert(offsetof(UFlavorFirePetalSMGAnimInstance, ScaleDupeMag) == 0x4f8, "Offset mismatch for UFlavorFirePetalSMGAnimInstance::ScaleDupeMag");
static_assert(offsetof(UFlavorFirePetalSMGAnimInstance, ScaleMag) == 0x500, "Offset mismatch for UFlavorFirePetalSMGAnimInstance::ScaleMag");
static_assert(offsetof(UFlavorFirePetalSMGAnimInstance, RotationAmount) == 0x508, "Offset mismatch for UFlavorFirePetalSMGAnimInstance::RotationAmount");
static_assert(offsetof(UFlavorFirePetalSMGAnimInstance, CurrentRotator) == 0x510, "Offset mismatch for UFlavorFirePetalSMGAnimInstance::CurrentRotator");
static_assert(offsetof(UFlavorFirePetalSMGAnimInstance, bIsCrouchWalking) == 0x528, "Offset mismatch for UFlavorFirePetalSMGAnimInstance::bIsCrouchWalking");

