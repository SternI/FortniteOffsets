/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayStateTreeModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "AIModule.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "StateTreeModule.h"
#include "GameplayTags.h"

// Size: 0xc8 (Inherited: 0xf0, Single: 0xffffffd8)
class UBTTask_RunDynamicStateTree : public UBTTaskNode
{
public:
    FStateTreeReference StateTreeRef; // 0x70 (Size: 0x28, Type: StructProperty)
    FStateTreeInstanceData InstanceData; // 0x98 (Size: 0x10, Type: StructProperty)
    FGameplayTag InjectionTag; // 0xa8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_ac[0x1c]; // 0xac (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_RunDynamicStateTree) == 0xc8, "Size mismatch for UBTTask_RunDynamicStateTree");
static_assert(offsetof(UBTTask_RunDynamicStateTree, StateTreeRef) == 0x70, "Offset mismatch for UBTTask_RunDynamicStateTree::StateTreeRef");
static_assert(offsetof(UBTTask_RunDynamicStateTree, InstanceData) == 0x98, "Offset mismatch for UBTTask_RunDynamicStateTree::InstanceData");
static_assert(offsetof(UBTTask_RunDynamicStateTree, InjectionTag) == 0xa8, "Offset mismatch for UBTTask_RunDynamicStateTree::InjectionTag");

// Size: 0xc0 (Inherited: 0xf0, Single: 0xffffffd0)
class UBTTask_RunStateTree : public UBTTaskNode
{
public:
    uint8_t Pad_70[0x8]; // 0x70 (Size: 0x8, Type: PaddingProperty)
    FStateTreeReference StateTreeRef; // 0x78 (Size: 0x28, Type: StructProperty)
    FStateTreeInstanceData InstanceData; // 0xa0 (Size: 0x10, Type: StructProperty)
    float Interval; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float RandomDeviation; // 0xb4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_RunStateTree) == 0xc0, "Size mismatch for UBTTask_RunStateTree");
static_assert(offsetof(UBTTask_RunStateTree, StateTreeRef) == 0x78, "Offset mismatch for UBTTask_RunStateTree::StateTreeRef");
static_assert(offsetof(UBTTask_RunStateTree, InstanceData) == 0xa0, "Offset mismatch for UBTTask_RunStateTree::InstanceData");
static_assert(offsetof(UBTTask_RunStateTree, Interval) == 0xb0, "Offset mismatch for UBTTask_RunStateTree::Interval");
static_assert(offsetof(UBTTask_RunStateTree, RandomDeviation) == 0xb4, "Offset mismatch for UBTTask_RunStateTree::RandomDeviation");

// Size: 0x180 (Inherited: 0x370, Single: 0xfffffe10)
class UStateTreeAIComponent : public UStateTreeComponent
{
public:
};

static_assert(sizeof(UStateTreeAIComponent) == 0x180, "Size mismatch for UStateTreeAIComponent");

// Size: 0x180 (Inherited: 0x1f0, Single: 0xffffff90)
class UStateTreeComponent : public UBrainComponent
{
public:
    uint8_t Pad_110[0x10]; // 0x110 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnStateTreeRunStatusChanged[0x10]; // 0x120 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FStateTreeReference StateTreeRef; // 0x130 (Size: 0x28, Type: StructProperty)
    FStateTreeReferenceOverrides LinkedStateTreeOverrides; // 0x158 (Size: 0x10, Type: StructProperty)
    FStateTreeInstanceData InstanceData; // 0x168 (Size: 0x10, Type: StructProperty)
    bool bStartLogicAutomatically; // 0x178 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_179[0x7]; // 0x179 (Size: 0x7, Type: PaddingProperty)

public:
    EStateTreeRunStatus GetStateTreeRunStatus() const; // 0xc33f134 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SendStateTreeEvent(const FStateTreeEvent Event); // 0xc33f15c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetStartLogicAutomatically(bool& const bInStartLogicAutomatically); // 0xc33f268 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetStateTree(UStateTree*& StateTree); // 0xc33f394 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetStateTreeReference(FStateTreeReference& StateTreeReference); // 0xc33f4c0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UStateTreeComponent) == 0x180, "Size mismatch for UStateTreeComponent");
static_assert(offsetof(UStateTreeComponent, OnStateTreeRunStatusChanged) == 0x120, "Offset mismatch for UStateTreeComponent::OnStateTreeRunStatusChanged");
static_assert(offsetof(UStateTreeComponent, StateTreeRef) == 0x130, "Offset mismatch for UStateTreeComponent::StateTreeRef");
static_assert(offsetof(UStateTreeComponent, LinkedStateTreeOverrides) == 0x158, "Offset mismatch for UStateTreeComponent::LinkedStateTreeOverrides");
static_assert(offsetof(UStateTreeComponent, InstanceData) == 0x168, "Offset mismatch for UStateTreeComponent::InstanceData");
static_assert(offsetof(UStateTreeComponent, bStartLogicAutomatically) == 0x178, "Offset mismatch for UStateTreeComponent::bStartLogicAutomatically");

// Size: 0x50 (Inherited: 0x98, Single: 0xffffffb8)
class UStateTreeAIComponentSchema : public UStateTreeComponentSchema
{
public:
    UClass* AIControllerClass; // 0x48 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UStateTreeAIComponentSchema) == 0x50, "Size mismatch for UStateTreeAIComponentSchema");
static_assert(offsetof(UStateTreeAIComponentSchema, AIControllerClass) == 0x48, "Offset mismatch for UStateTreeAIComponentSchema::AIControllerClass");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UStateTreeComponentSchema : public UStateTreeSchema
{
public:
    UClass* ContextActorClass; // 0x28 (Size: 0x8, Type: ClassProperty)
    uint8_t ScheduledTickPolicy; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    TArray<FStateTreeExternalDataDesc> ContextDataDescs; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UStateTreeComponentSchema) == 0x48, "Size mismatch for UStateTreeComponentSchema");
static_assert(offsetof(UStateTreeComponentSchema, ContextActorClass) == 0x28, "Offset mismatch for UStateTreeComponentSchema::ContextActorClass");
static_assert(offsetof(UStateTreeComponentSchema, ScheduledTickPolicy) == 0x30, "Offset mismatch for UStateTreeComponentSchema::ScheduledTickPolicy");
static_assert(offsetof(UStateTreeComponentSchema, ContextDataDescs) == 0x38, "Offset mismatch for UStateTreeComponentSchema::ContextDataDescs");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FStateTreeGetActorLocationPropertyFunctionInstanceData
{
    AActor* Input; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector Output; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FStateTreeGetActorLocationPropertyFunctionInstanceData) == 0x20, "Size mismatch for FStateTreeGetActorLocationPropertyFunctionInstanceData");
static_assert(offsetof(FStateTreeGetActorLocationPropertyFunctionInstanceData, Input) == 0x0, "Offset mismatch for FStateTreeGetActorLocationPropertyFunctionInstanceData::Input");
static_assert(offsetof(FStateTreeGetActorLocationPropertyFunctionInstanceData, Output) == 0x8, "Offset mismatch for FStateTreeGetActorLocationPropertyFunctionInstanceData::Output");

// Size: 0x18 (Inherited: 0x48, Single: 0xffffffd0)
struct FStateTreeGetActorLocationPropertyFunction : FStateTreePropertyFunctionCommonBase
{
};

static_assert(sizeof(FStateTreeGetActorLocationPropertyFunction) == 0x18, "Size mismatch for FStateTreeGetActorLocationPropertyFunction");

// Size: 0x20 (Inherited: 0x38, Single: 0xffffffe8)
struct FStateTreeAIConditionBase : FStateTreeConditionBase
{
};

static_assert(sizeof(FStateTreeAIConditionBase) == 0x20, "Size mismatch for FStateTreeAIConditionBase");

// Size: 0x20 (Inherited: 0x38, Single: 0xffffffe8)
struct FStateTreeAITaskBase : FStateTreeTaskBase
{
};

static_assert(sizeof(FStateTreeAITaskBase) == 0x20, "Size mismatch for FStateTreeAITaskBase");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FStateTreeAIActionTaskBase : FStateTreeAITaskBase
{
};

static_assert(sizeof(FStateTreeAIActionTaskBase) == 0x20, "Size mismatch for FStateTreeAIActionTaskBase");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FStateTreeComponentExecutionExtension : FStateTreeExecutionExtension
{
    UStateTreeComponent* Component; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FStateTreeComponentExecutionExtension) == 0x10, "Size mismatch for FStateTreeComponentExecutionExtension");
static_assert(offsetof(FStateTreeComponentExecutionExtension, Component) == 0x8, "Offset mismatch for FStateTreeComponentExecutionExtension::Component");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FStateTreeRunEnvQueryInstanceData
{
    FStateTreePropertyRef Result; // 0x0 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    AActor* QueryOwner; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UEnvQuery* QueryTemplate; // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<FAIDynamicParam> QueryConfig; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<EEnvQueryRunMode> RunMode; // 0x28 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_29[0x1f]; // 0x29 (Size: 0x1f, Type: PaddingProperty)
};

static_assert(sizeof(FStateTreeRunEnvQueryInstanceData) == 0x48, "Size mismatch for FStateTreeRunEnvQueryInstanceData");
static_assert(offsetof(FStateTreeRunEnvQueryInstanceData, Result) == 0x0, "Offset mismatch for FStateTreeRunEnvQueryInstanceData::Result");
static_assert(offsetof(FStateTreeRunEnvQueryInstanceData, QueryOwner) == 0x8, "Offset mismatch for FStateTreeRunEnvQueryInstanceData::QueryOwner");
static_assert(offsetof(FStateTreeRunEnvQueryInstanceData, QueryTemplate) == 0x10, "Offset mismatch for FStateTreeRunEnvQueryInstanceData::QueryTemplate");
static_assert(offsetof(FStateTreeRunEnvQueryInstanceData, QueryConfig) == 0x18, "Offset mismatch for FStateTreeRunEnvQueryInstanceData::QueryConfig");
static_assert(offsetof(FStateTreeRunEnvQueryInstanceData, RunMode) == 0x28, "Offset mismatch for FStateTreeRunEnvQueryInstanceData::RunMode");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FStateTreeRunEnvQueryTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FStateTreeRunEnvQueryTask) == 0x20, "Size mismatch for FStateTreeRunEnvQueryTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FStateTreeMoveToTaskInstanceData
{
    AAIController* AIController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector Destination; // 0x8 (Size: 0x18, Type: StructProperty)
    AActor* TargetActor; // 0x20 (Size: 0x8, Type: ObjectProperty)
    float AcceptableRadius; // 0x28 (Size: 0x4, Type: FloatProperty)
    float DestinationMoveTolerance; // 0x2c (Size: 0x4, Type: FloatProperty)
    UClass* FilterClass; // 0x30 (Size: 0x8, Type: ClassProperty)
    bool bAllowStrafe; // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bAllowPartialPath; // 0x39 (Size: 0x1, Type: BoolProperty)
    bool bTrackMovingGoal; // 0x3a (Size: 0x1, Type: BoolProperty)
    bool bRequireNavigableEndLocation; // 0x3b (Size: 0x1, Type: BoolProperty)
    bool bProjectGoalLocation; // 0x3c (Size: 0x1, Type: BoolProperty)
    bool bReachTestIncludesAgentRadius; // 0x3d (Size: 0x1, Type: BoolProperty)
    bool bReachTestIncludesGoalRadius; // 0x3e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3f[0x1]; // 0x3f (Size: 0x1, Type: PaddingProperty)
    UAITask_MoveTo* MoveToTask; // 0x40 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> TaskOwner; // 0x48 (Size: 0x10, Type: InterfaceProperty)
};

static_assert(sizeof(FStateTreeMoveToTaskInstanceData) == 0x58, "Size mismatch for FStateTreeMoveToTaskInstanceData");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, AIController) == 0x0, "Offset mismatch for FStateTreeMoveToTaskInstanceData::AIController");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, Destination) == 0x8, "Offset mismatch for FStateTreeMoveToTaskInstanceData::Destination");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, TargetActor) == 0x20, "Offset mismatch for FStateTreeMoveToTaskInstanceData::TargetActor");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, AcceptableRadius) == 0x28, "Offset mismatch for FStateTreeMoveToTaskInstanceData::AcceptableRadius");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, DestinationMoveTolerance) == 0x2c, "Offset mismatch for FStateTreeMoveToTaskInstanceData::DestinationMoveTolerance");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, FilterClass) == 0x30, "Offset mismatch for FStateTreeMoveToTaskInstanceData::FilterClass");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bAllowStrafe) == 0x38, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bAllowStrafe");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bAllowPartialPath) == 0x39, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bAllowPartialPath");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bTrackMovingGoal) == 0x3a, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bTrackMovingGoal");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bRequireNavigableEndLocation) == 0x3b, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bRequireNavigableEndLocation");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bProjectGoalLocation) == 0x3c, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bProjectGoalLocation");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bReachTestIncludesAgentRadius) == 0x3d, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bReachTestIncludesAgentRadius");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, bReachTestIncludesGoalRadius) == 0x3e, "Offset mismatch for FStateTreeMoveToTaskInstanceData::bReachTestIncludesGoalRadius");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, MoveToTask) == 0x40, "Offset mismatch for FStateTreeMoveToTaskInstanceData::MoveToTask");
static_assert(offsetof(FStateTreeMoveToTaskInstanceData, TaskOwner) == 0x48, "Offset mismatch for FStateTreeMoveToTaskInstanceData::TaskOwner");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FStateTreeMoveToTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FStateTreeMoveToTask) == 0x20, "Size mismatch for FStateTreeMoveToTask");

