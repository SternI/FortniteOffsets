/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoreOnline
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FJoinabilitySettings
{
    FName SessionName; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bPublicSearchable; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bAllowInvites; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bJoinViaPresence; // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bJoinViaPresenceFriendsOnly; // 0x7 (Size: 0x1, Type: BoolProperty)
    int32_t MaxPlayers; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MaxPartySize; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FJoinabilitySettings) == 0x10, "Size mismatch for FJoinabilitySettings");
static_assert(offsetof(FJoinabilitySettings, SessionName) == 0x0, "Offset mismatch for FJoinabilitySettings::SessionName");
static_assert(offsetof(FJoinabilitySettings, bPublicSearchable) == 0x4, "Offset mismatch for FJoinabilitySettings::bPublicSearchable");
static_assert(offsetof(FJoinabilitySettings, bAllowInvites) == 0x5, "Offset mismatch for FJoinabilitySettings::bAllowInvites");
static_assert(offsetof(FJoinabilitySettings, bJoinViaPresence) == 0x6, "Offset mismatch for FJoinabilitySettings::bJoinViaPresence");
static_assert(offsetof(FJoinabilitySettings, bJoinViaPresenceFriendsOnly) == 0x7, "Offset mismatch for FJoinabilitySettings::bJoinViaPresenceFriendsOnly");
static_assert(offsetof(FJoinabilitySettings, MaxPlayers) == 0x8, "Offset mismatch for FJoinabilitySettings::MaxPlayers");
static_assert(offsetof(FJoinabilitySettings, MaxPartySize) == 0xc, "Offset mismatch for FJoinabilitySettings::MaxPartySize");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FUniqueNetIdWrapper
{
};

static_assert(sizeof(FUniqueNetIdWrapper) == 0x1, "Size mismatch for FUniqueNetIdWrapper");

