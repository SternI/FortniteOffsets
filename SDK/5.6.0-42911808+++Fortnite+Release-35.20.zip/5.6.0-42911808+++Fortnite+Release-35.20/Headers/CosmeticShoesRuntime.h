/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticShoesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "ItemizationCoreRuntime.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "CustomizableObject.h"

// Size: 0x3e0 (Inherited: 0x408, Single: 0xffffffd8)
class UCosmeticShoesAnimInstance : public UAnimInstance
{
public:

public:
    virtual void OnGameplayTagsSet(const FGameplayTagContainer GameplayTags); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnShoePositionsSet(FVector& LeftShoePosition, FVector& RightShoePosition); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasDefaults|BlueprintEvent)
};

static_assert(sizeof(UCosmeticShoesAnimInstance) == 0x3e0, "Size mismatch for UCosmeticShoesAnimInstance");

// Size: 0x140 (Inherited: 0x3d0, Single: 0xfffffd70)
class UCosmeticShoesItem : public UAthenaCosmeticAccountItem
{
public:
};

static_assert(sizeof(UCosmeticShoesItem) == 0x140, "Size mismatch for UCosmeticShoesItem");

// Size: 0x4e0 (Inherited: 0xcf8, Single: 0xfffff7e8)
class UCosmeticShoesItemDefinition : public UAthenaCharacterPartItemDefinition
{
public:
    uint8_t Pad_4a8[0x8]; // 0x4a8 (Size: 0x8, Type: PaddingProperty)
    FVector LeftShoesPosition; // 0x4b0 (Size: 0x18, Type: StructProperty)
    FVector RightShoesPosition; // 0x4c8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UCosmeticShoesItemDefinition) == 0x4e0, "Size mismatch for UCosmeticShoesItemDefinition");
static_assert(offsetof(UCosmeticShoesItemDefinition, LeftShoesPosition) == 0x4b0, "Offset mismatch for UCosmeticShoesItemDefinition::LeftShoesPosition");
static_assert(offsetof(UCosmeticShoesItemDefinition, RightShoesPosition) == 0x4c8, "Offset mismatch for UCosmeticShoesItemDefinition::RightShoesPosition");

// Size: 0x310 (Inherited: 0x2d0, Single: 0x40)
class ACosmeticShoesPreviewPrefabAsset : public AActor
{
public:
    uint8_t Pad_2a8[0x10]; // 0x2a8 (Size: 0x10, Type: PaddingProperty)
    USkeletalMeshComponent* Mesh; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFXSystemComponent*> IdleVFX; // 0x2c0 (Size: 0x8, Type: WeakObjectProperty)
    UCustomizableSkeletalComponent* CustomizableComponent; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UCosmeticShoesItemDefinition*> ShoesItemDefinition; // 0x2d0 (Size: 0x8, Type: WeakObjectProperty)
    float CylinderHalfHeight; // 0x2d8 (Size: 0x4, Type: FloatProperty)
    float CylinderRadius; // 0x2dc (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2e0[0x30]; // 0x2e0 (Size: 0x30, Type: PaddingProperty)

private:
    void OnMeshAnimInitialized(); // 0x1138fce4 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(ACosmeticShoesPreviewPrefabAsset) == 0x310, "Size mismatch for ACosmeticShoesPreviewPrefabAsset");
static_assert(offsetof(ACosmeticShoesPreviewPrefabAsset, Mesh) == 0x2b8, "Offset mismatch for ACosmeticShoesPreviewPrefabAsset::Mesh");
static_assert(offsetof(ACosmeticShoesPreviewPrefabAsset, IdleVFX) == 0x2c0, "Offset mismatch for ACosmeticShoesPreviewPrefabAsset::IdleVFX");
static_assert(offsetof(ACosmeticShoesPreviewPrefabAsset, CustomizableComponent) == 0x2c8, "Offset mismatch for ACosmeticShoesPreviewPrefabAsset::CustomizableComponent");
static_assert(offsetof(ACosmeticShoesPreviewPrefabAsset, ShoesItemDefinition) == 0x2d0, "Offset mismatch for ACosmeticShoesPreviewPrefabAsset::ShoesItemDefinition");
static_assert(offsetof(ACosmeticShoesPreviewPrefabAsset, CylinderHalfHeight) == 0x2d8, "Offset mismatch for ACosmeticShoesPreviewPrefabAsset::CylinderHalfHeight");
static_assert(offsetof(ACosmeticShoesPreviewPrefabAsset, CylinderRadius) == 0x2dc, "Offset mismatch for ACosmeticShoesPreviewPrefabAsset::CylinderRadius");

