/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FrontEnd
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGameFramework.h"
#include "InputCore.h"
#include "SubtitlesWidgets.h"
#include "MediaAssets.h"

// Size: 0xa98 (Inherited: 0x1790, Single: 0xfffff308)
class ASpecialEventsCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)

public:
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnDeactivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(ASpecialEventsCamera_Blueprint_C) == 0xa98, "Size mismatch for ASpecialEventsCamera_Blueprint_C");
static_assert(offsetof(ASpecialEventsCamera_Blueprint_C, UberGraphFrame) == 0xa90, "Offset mismatch for ASpecialEventsCamera_Blueprint_C::UberGraphFrame");

// Size: 0x2e0 (Inherited: 0x2d0, Single: 0x10)
class AHBOnboardingFlow_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UFortQuestItemDefinition_Campaign* PlayPeriodicEventMovieQuest; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    bool bPlayedPeriodicEventMovie; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bHasRecheckedNeedToPlayPeriodicEventMovie; // 0x2c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c2[0x6]; // 0x2c2 (Size: 0x6, Type: PaddingProperty)
    FDataTableRowHandle PlayPeriodicEventCineObjective; // 0x2c8 (Size: 0x10, Type: StructProperty)
    UClass* PeriodicEventMovieAnnouncementClass; // 0x2d8 (Size: 0x8, Type: ClassProperty)

public:
    void RecheckNeedToPlayEventMovie(bool& WaitingToCheckAgain); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetCampaignQuestManager(UFortQuestManager*& QuestManager); // 0x288a61c (Index: 0x6, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    bool NeedsToPlayEventMovie(); // 0x288a61c (Index: 0x9, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(AHBOnboardingFlow_C) == 0x2e0, "Size mismatch for AHBOnboardingFlow_C");
static_assert(offsetof(AHBOnboardingFlow_C, UberGraphFrame) == 0x2a8, "Offset mismatch for AHBOnboardingFlow_C::UberGraphFrame");
static_assert(offsetof(AHBOnboardingFlow_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for AHBOnboardingFlow_C::DefaultSceneRoot");
static_assert(offsetof(AHBOnboardingFlow_C, PlayPeriodicEventMovieQuest) == 0x2b8, "Offset mismatch for AHBOnboardingFlow_C::PlayPeriodicEventMovieQuest");
static_assert(offsetof(AHBOnboardingFlow_C, bPlayedPeriodicEventMovie) == 0x2c0, "Offset mismatch for AHBOnboardingFlow_C::bPlayedPeriodicEventMovie");
static_assert(offsetof(AHBOnboardingFlow_C, bHasRecheckedNeedToPlayPeriodicEventMovie) == 0x2c1, "Offset mismatch for AHBOnboardingFlow_C::bHasRecheckedNeedToPlayPeriodicEventMovie");
static_assert(offsetof(AHBOnboardingFlow_C, PlayPeriodicEventCineObjective) == 0x2c8, "Offset mismatch for AHBOnboardingFlow_C::PlayPeriodicEventCineObjective");
static_assert(offsetof(AHBOnboardingFlow_C, PeriodicEventMovieAnnouncementClass) == 0x2d8, "Offset mismatch for AHBOnboardingFlow_C::PeriodicEventMovieAnnouncementClass");

// Size: 0x350 (Inherited: 0xc60, Single: 0xfffff6f0)
class AAnnounce_Storm2018Cine_C : public AAnnounce_EventCine_C
{
public:
};

static_assert(sizeof(AAnnounce_Storm2018Cine_C) == 0x350, "Size mismatch for AAnnounce_Storm2018Cine_C");

// Size: 0x36f0 (Inherited: 0x8138, Single: 0xffffb5b8)
class AFrontEnd_PlayerController_C : public AFortPlayerControllerFrontEnd
{
public:
};

static_assert(sizeof(AFrontEnd_PlayerController_C) == 0x36f0, "Size mismatch for AFrontEnd_PlayerController_C");

// Size: 0x830 (Inherited: 0x23d8, Single: 0xffffe458)
class AFrontEnd_GameMode_C : public AFortGameModeFrontEnd
{
public:
    USceneComponent* DefaultSceneRoot; // 0x828 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AFrontEnd_GameMode_C) == 0x830, "Size mismatch for AFrontEnd_GameMode_C");
static_assert(offsetof(AFrontEnd_GameMode_C, DefaultSceneRoot) == 0x828, "Offset mismatch for AFrontEnd_GameMode_C::DefaultSceneRoot");

// Size: 0xa98 (Inherited: 0x1790, Single: 0xfffff308)
class AVaultCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)

public:
    virtual void BP_OnDeactivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(AVaultCamera_Blueprint_C) == 0xa98, "Size mismatch for AVaultCamera_Blueprint_C");
static_assert(offsetof(AVaultCamera_Blueprint_C, UberGraphFrame) == 0xa90, "Offset mismatch for AVaultCamera_Blueprint_C::UberGraphFrame");

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class AStorePinataMaster_Parent_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* PinataSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

};

static_assert(sizeof(AStorePinataMaster_Parent_C) == 0x2b8, "Size mismatch for AStorePinataMaster_Parent_C");
static_assert(offsetof(AStorePinataMaster_Parent_C, UberGraphFrame) == 0x2a8, "Offset mismatch for AStorePinataMaster_Parent_C::UberGraphFrame");
static_assert(offsetof(AStorePinataMaster_Parent_C, PinataSceneRoot) == 0x2b0, "Offset mismatch for AStorePinataMaster_Parent_C::PinataSceneRoot");

// Size: 0xaa8 (Inherited: 0x1790, Single: 0xfffff318)
class ALoginCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* StaticMesh; // 0xa98 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* LoginCamera_0; // 0xaa0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(ALoginCamera_Blueprint_C) == 0xaa8, "Size mismatch for ALoginCamera_Blueprint_C");
static_assert(offsetof(ALoginCamera_Blueprint_C, UberGraphFrame) == 0xa90, "Offset mismatch for ALoginCamera_Blueprint_C::UberGraphFrame");
static_assert(offsetof(ALoginCamera_Blueprint_C, StaticMesh) == 0xa98, "Offset mismatch for ALoginCamera_Blueprint_C::StaticMesh");
static_assert(offsetof(ALoginCamera_Blueprint_C, LoginCamera_0) == 0xaa0, "Offset mismatch for ALoginCamera_Blueprint_C::LoginCamera_0");

// Size: 0xb40 (Inherited: 0x1790, Single: 0xfffff3b0)
class AStoreCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* Mesh_DarkenBG; // 0xa98 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* CameraPlaceholderGround; // 0xaa0 (Size: 0x8, Type: ObjectProperty)
    float ChoicePack_NewTrack_0_ACA3841D4D5084BE3482FA8EBB7CE9C0; // 0xaa8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ChoicePack__Direction_ACA3841D4D5084BE3482FA8EBB7CE9C0; // 0xaac (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_aad[0x3]; // 0xaad (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ChoicePack; // 0xab0 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_NewTrack_0_6555812E4B246E6144D3C99FC49F7FE9; // 0xab8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_6555812E4B246E6144D3C99FC49F7FE9; // 0xabc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_abd[0x3]; // 0xabd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_0; // 0xac0 (Size: 0x8, Type: ObjectProperty)
    FVector CameraGroundLoc; // 0xac8 (Size: 0x18, Type: StructProperty)
    FRotator CameraGroundRot; // 0xae0 (Size: 0x18, Type: StructProperty)
    FVector CameraOriginalLoc; // 0xaf8 (Size: 0x18, Type: StructProperty)
    FRotator CameraOriginalRot; // 0xb10 (Size: 0x18, Type: StructProperty)
    bool CameraInStartPos; // 0xb28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b29[0x7]; // 0xb29 (Size: 0x7, Type: PaddingProperty)
    AStorePinataMaster_Parent_C* PinataInLevel; // 0xb30 (Size: 0x8, Type: ObjectProperty)
    AStoreCardReveal_Parent_C* CardRevealInLevel; // 0xb38 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void BP_OnDeactivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AStoreCamera_Blueprint_C) == 0xb40, "Size mismatch for AStoreCamera_Blueprint_C");
static_assert(offsetof(AStoreCamera_Blueprint_C, UberGraphFrame) == 0xa90, "Offset mismatch for AStoreCamera_Blueprint_C::UberGraphFrame");
static_assert(offsetof(AStoreCamera_Blueprint_C, Mesh_DarkenBG) == 0xa98, "Offset mismatch for AStoreCamera_Blueprint_C::Mesh_DarkenBG");
static_assert(offsetof(AStoreCamera_Blueprint_C, CameraPlaceholderGround) == 0xaa0, "Offset mismatch for AStoreCamera_Blueprint_C::CameraPlaceholderGround");
static_assert(offsetof(AStoreCamera_Blueprint_C, ChoicePack_NewTrack_0_ACA3841D4D5084BE3482FA8EBB7CE9C0) == 0xaa8, "Offset mismatch for AStoreCamera_Blueprint_C::ChoicePack_NewTrack_0_ACA3841D4D5084BE3482FA8EBB7CE9C0");
static_assert(offsetof(AStoreCamera_Blueprint_C, ChoicePack__Direction_ACA3841D4D5084BE3482FA8EBB7CE9C0) == 0xaac, "Offset mismatch for AStoreCamera_Blueprint_C::ChoicePack__Direction_ACA3841D4D5084BE3482FA8EBB7CE9C0");
static_assert(offsetof(AStoreCamera_Blueprint_C, ChoicePack) == 0xab0, "Offset mismatch for AStoreCamera_Blueprint_C::ChoicePack");
static_assert(offsetof(AStoreCamera_Blueprint_C, Timeline_0_NewTrack_0_6555812E4B246E6144D3C99FC49F7FE9) == 0xab8, "Offset mismatch for AStoreCamera_Blueprint_C::Timeline_0_NewTrack_0_6555812E4B246E6144D3C99FC49F7FE9");
static_assert(offsetof(AStoreCamera_Blueprint_C, Timeline_0__Direction_6555812E4B246E6144D3C99FC49F7FE9) == 0xabc, "Offset mismatch for AStoreCamera_Blueprint_C::Timeline_0__Direction_6555812E4B246E6144D3C99FC49F7FE9");
static_assert(offsetof(AStoreCamera_Blueprint_C, Timeline_0) == 0xac0, "Offset mismatch for AStoreCamera_Blueprint_C::Timeline_0");
static_assert(offsetof(AStoreCamera_Blueprint_C, CameraGroundLoc) == 0xac8, "Offset mismatch for AStoreCamera_Blueprint_C::CameraGroundLoc");
static_assert(offsetof(AStoreCamera_Blueprint_C, CameraGroundRot) == 0xae0, "Offset mismatch for AStoreCamera_Blueprint_C::CameraGroundRot");
static_assert(offsetof(AStoreCamera_Blueprint_C, CameraOriginalLoc) == 0xaf8, "Offset mismatch for AStoreCamera_Blueprint_C::CameraOriginalLoc");
static_assert(offsetof(AStoreCamera_Blueprint_C, CameraOriginalRot) == 0xb10, "Offset mismatch for AStoreCamera_Blueprint_C::CameraOriginalRot");
static_assert(offsetof(AStoreCamera_Blueprint_C, CameraInStartPos) == 0xb28, "Offset mismatch for AStoreCamera_Blueprint_C::CameraInStartPos");
static_assert(offsetof(AStoreCamera_Blueprint_C, PinataInLevel) == 0xb30, "Offset mismatch for AStoreCamera_Blueprint_C::PinataInLevel");
static_assert(offsetof(AStoreCamera_Blueprint_C, CardRevealInLevel) == 0xb38, "Offset mismatch for AStoreCamera_Blueprint_C::CardRevealInLevel");

// Size: 0xaa8 (Inherited: 0x1790, Single: 0xfffff318)
class AHeroesCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)
    bool MouseDown; // 0xa98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a99[0x7]; // 0xa99 (Size: 0x7, Type: PaddingProperty)
    AFortPlayerPawn* Cached_Pawn; // 0xaa0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void HandleMouseRelease(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleMousePress(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void BP_OnDeactivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(AHeroesCamera_Blueprint_C) == 0xaa8, "Size mismatch for AHeroesCamera_Blueprint_C");
static_assert(offsetof(AHeroesCamera_Blueprint_C, UberGraphFrame) == 0xa90, "Offset mismatch for AHeroesCamera_Blueprint_C::UberGraphFrame");
static_assert(offsetof(AHeroesCamera_Blueprint_C, MouseDown) == 0xa98, "Offset mismatch for AHeroesCamera_Blueprint_C::MouseDown");
static_assert(offsetof(AHeroesCamera_Blueprint_C, Cached_Pawn) == 0xaa0, "Offset mismatch for AHeroesCamera_Blueprint_C::Cached_Pawn");

// Size: 0x350 (Inherited: 0x910, Single: 0xfffffa40)
class AAnnounce_EventCine_C : public AFortClientAnnouncement_Cinematic
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x328 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UMediaSource* EventMediaSource; // 0x338 (Size: 0x8, Type: ObjectProperty)
    bool AllowSkipping; // 0x340 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_341[0x7]; // 0x341 (Size: 0x7, Type: PaddingProperty)
    UFortMediaSubtitlesPlayer* EventSubtitlesPlayer; // 0x348 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnPlayerSkippedCutscene(); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnEnteredCinematicState(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnClientAnnouncementStop(); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AAnnounce_EventCine_C) == 0x350, "Size mismatch for AAnnounce_EventCine_C");
static_assert(offsetof(AAnnounce_EventCine_C, UberGraphFrame) == 0x328, "Offset mismatch for AAnnounce_EventCine_C::UberGraphFrame");
static_assert(offsetof(AAnnounce_EventCine_C, DefaultSceneRoot) == 0x330, "Offset mismatch for AAnnounce_EventCine_C::DefaultSceneRoot");
static_assert(offsetof(AAnnounce_EventCine_C, EventMediaSource) == 0x338, "Offset mismatch for AAnnounce_EventCine_C::EventMediaSource");
static_assert(offsetof(AAnnounce_EventCine_C, AllowSkipping) == 0x340, "Offset mismatch for AAnnounce_EventCine_C::AllowSkipping");
static_assert(offsetof(AAnnounce_EventCine_C, EventSubtitlesPlayer) == 0x348, "Offset mismatch for AAnnounce_EventCine_C::EventSubtitlesPlayer");

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class AStoreCardReveal_Parent_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* PinataSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

};

static_assert(sizeof(AStoreCardReveal_Parent_C) == 0x2b8, "Size mismatch for AStoreCardReveal_Parent_C");
static_assert(offsetof(AStoreCardReveal_Parent_C, UberGraphFrame) == 0x2a8, "Offset mismatch for AStoreCardReveal_Parent_C::UberGraphFrame");
static_assert(offsetof(AStoreCardReveal_Parent_C, PinataSceneRoot) == 0x2b0, "Offset mismatch for AStoreCardReveal_Parent_C::PinataSceneRoot");

// Size: 0x2d0 (Inherited: 0x598, Single: 0xfffffd38)
class AFrontEndSettingsBP_C : public AFrontEndSettings
{
public:
    USceneComponent* DefaultSceneRoot; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AFrontEndSettingsBP_C) == 0x2d0, "Size mismatch for AFrontEndSettingsBP_C");
static_assert(offsetof(AFrontEndSettingsBP_C, DefaultSceneRoot) == 0x2c8, "Offset mismatch for AFrontEndSettingsBP_C::DefaultSceneRoot");

