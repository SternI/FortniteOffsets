/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AttachableWheelsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x348 (Inherited: 0x2d0, Single: 0x78)
class AAttachableWheel : public AActor
{
public:
    UStaticMeshComponent* WheelMeshComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    FRotator WheelOrientation; // 0x2b0 (Size: 0x18, Type: StructProperty)
    float WheelDistance; // 0x2c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2cc[0x4]; // 0x2cc (Size: 0x4, Type: PaddingProperty)
    UPhysicsConstraintComponent* AxleConstraint; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    FAttachableWheelAttachData AttachData; // 0x2d8 (Size: 0x58, Type: StructProperty)
    bool bAutoCreateAttachableWheelsComponent; // 0x330 (Size: 0x1, Type: BoolProperty)
    bool bEnableWheelWheelCollision; // 0x331 (Size: 0x1, Type: BoolProperty)
    bool bReplicateRuntimeData; // 0x332 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_333[0x1]; // 0x333 (Size: 0x1, Type: PaddingProperty)
    FAttachableWheelRuntimeData RuntimeData; // 0x334 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_340[0x8]; // 0x340 (Size: 0x8, Type: PaddingProperty)

public:
    bool AttachInPlace(UPrimitiveComponent*& InComponent); // 0x11a0b480 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool AttachTo(UPrimitiveComponent*& InComponent, const FVector WorldLocation, const FVector AxleDirection, FVector& SteerAxis); // 0x11a0b5b8 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void Detach(); // 0x11a0b8ac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    bool DetachFrom(UPrimitiveComponent*& InComponent); // 0x11a0b954 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void DrawDebug() const; // 0x554e3c4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|Const)
    FAttachableWheelAttachData GetAttachData() const; // 0x11a0bb3c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UPrimitiveComponent* GetAttachedComponent() const; // 0x11a0bb94 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetWorldSpaceAttachData(FAttachableWheelAttachData& OutAttachData, UPrimitiveComponent*& PrimitiveComponent, FName& const BodyName) const; // 0x11a0bee8 (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void SetRuntimeData(float& Torque, float& Velocity, float& SteerAngle); // 0x11a0c828 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void SetRuntimeData_SteerAngle(float& SteerAngle); // 0x11a0cb0c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void SetRuntimeData_Torque(float& Torque); // 0x11a0cc48 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void SetRuntimeData_Velocity(float& Velocity); // 0x11a0cd84 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void OnAttached(UPrimitiveComponent*& AttachedComponent); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnDetached(UPrimitiveComponent*& DetachedComponent); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    void OnPhysicsStateChanged(UPrimitiveComponent*& PrimitiveComponent, EComponentPhysicsStateChange& StateChange); // 0x11a0c32c (Index: 0xa, Flags: Native|Protected)
    void OnRep_AttachData(const FAttachableWheelAttachData AttachDataPrev); // 0x11a0c538 (Index: 0xb, Flags: Final|Native|Protected|HasOutParms)
    void OnRep_RuntimeData(const FAttachableWheelRuntimeData RuntimeDataPrev); // 0x11a0c634 (Index: 0xc, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(AAttachableWheel) == 0x348, "Size mismatch for AAttachableWheel");
static_assert(offsetof(AAttachableWheel, WheelMeshComponent) == 0x2a8, "Offset mismatch for AAttachableWheel::WheelMeshComponent");
static_assert(offsetof(AAttachableWheel, WheelOrientation) == 0x2b0, "Offset mismatch for AAttachableWheel::WheelOrientation");
static_assert(offsetof(AAttachableWheel, WheelDistance) == 0x2c8, "Offset mismatch for AAttachableWheel::WheelDistance");
static_assert(offsetof(AAttachableWheel, AxleConstraint) == 0x2d0, "Offset mismatch for AAttachableWheel::AxleConstraint");
static_assert(offsetof(AAttachableWheel, AttachData) == 0x2d8, "Offset mismatch for AAttachableWheel::AttachData");
static_assert(offsetof(AAttachableWheel, bAutoCreateAttachableWheelsComponent) == 0x330, "Offset mismatch for AAttachableWheel::bAutoCreateAttachableWheelsComponent");
static_assert(offsetof(AAttachableWheel, bEnableWheelWheelCollision) == 0x331, "Offset mismatch for AAttachableWheel::bEnableWheelWheelCollision");
static_assert(offsetof(AAttachableWheel, bReplicateRuntimeData) == 0x332, "Offset mismatch for AAttachableWheel::bReplicateRuntimeData");
static_assert(offsetof(AAttachableWheel, RuntimeData) == 0x334, "Offset mismatch for AAttachableWheel::RuntimeData");

// Size: 0x120 (Inherited: 0xe0, Single: 0x40)
class UAttachableWheelsComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    TSet<AAttachableWheel*> AttachedWheels; // 0xc0 (Size: 0x50, Type: SetProperty)
    float MaxChassisMassFraction; // 0x110 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_114[0xc]; // 0x114 (Size: 0xc, Type: PaddingProperty)

public:
    int32_t DetachAllWheels(); // 0x11a0b8c0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void DrawDebug() const; // 0x554e3c4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|Const)
    AAttachableWheel* GetAttachedWheelClosestOnAxis(const FVector Point, float& OutClosetDistanceToAxis, FVector& OutClosestPointOnAxis, FVector& OutClosestAxis) const; // 0x11a0bbb8 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<AAttachableWheel*> GetAttachedWheels() const; // 0x11a0be7c (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnWheelAttached(AAttachableWheel*& AttachedWheel); // 0x288a61c (Index: 0x6, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    virtual void OnWheelDetached(AAttachableWheel*& AttachedWheel); // 0x288a61c (Index: 0x7, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    void SetMaxChassisMassFraction(float& InMaxChassisMassFraction); // 0x11a0c6fc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

protected:
    bool HandleWheelAttached_Internal(AAttachableWheel*& AttachedWheel); // 0x11a0c0bc (Index: 0x4, Flags: Final|Native|Protected)
    bool HandleWheelDetached_Internal(AAttachableWheel*& AttachedWheel); // 0x11a0c1f4 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(UAttachableWheelsComponent) == 0x120, "Size mismatch for UAttachableWheelsComponent");
static_assert(offsetof(UAttachableWheelsComponent, AttachedWheels) == 0xc0, "Offset mismatch for UAttachableWheelsComponent::AttachedWheels");
static_assert(offsetof(UAttachableWheelsComponent, MaxChassisMassFraction) == 0x110, "Offset mismatch for UAttachableWheelsComponent::MaxChassisMassFraction");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FAttachableWheelAttachData
{
    TWeakObjectPtr<UPrimitiveComponent*> PrimitiveComponent; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FVector Pos; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Axis1; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Axis2; // 0x38 (Size: 0x18, Type: StructProperty)
    float Damping; // 0x50 (Size: 0x4, Type: FloatProperty)
    FName AttachmentName; // 0x54 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FAttachableWheelAttachData) == 0x58, "Size mismatch for FAttachableWheelAttachData");
static_assert(offsetof(FAttachableWheelAttachData, PrimitiveComponent) == 0x0, "Offset mismatch for FAttachableWheelAttachData::PrimitiveComponent");
static_assert(offsetof(FAttachableWheelAttachData, Pos) == 0x8, "Offset mismatch for FAttachableWheelAttachData::Pos");
static_assert(offsetof(FAttachableWheelAttachData, Axis1) == 0x20, "Offset mismatch for FAttachableWheelAttachData::Axis1");
static_assert(offsetof(FAttachableWheelAttachData, Axis2) == 0x38, "Offset mismatch for FAttachableWheelAttachData::Axis2");
static_assert(offsetof(FAttachableWheelAttachData, Damping) == 0x50, "Offset mismatch for FAttachableWheelAttachData::Damping");
static_assert(offsetof(FAttachableWheelAttachData, AttachmentName) == 0x54, "Offset mismatch for FAttachableWheelAttachData::AttachmentName");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAttachableWheelRuntimeData
{
    float Torque; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Velocity; // 0x4 (Size: 0x4, Type: FloatProperty)
    float SteerAngle; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAttachableWheelRuntimeData) == 0xc, "Size mismatch for FAttachableWheelRuntimeData");
static_assert(offsetof(FAttachableWheelRuntimeData, Torque) == 0x0, "Offset mismatch for FAttachableWheelRuntimeData::Torque");
static_assert(offsetof(FAttachableWheelRuntimeData, Velocity) == 0x4, "Offset mismatch for FAttachableWheelRuntimeData::Velocity");
static_assert(offsetof(FAttachableWheelRuntimeData, SteerAngle) == 0x8, "Offset mismatch for FAttachableWheelRuntimeData::SteerAngle");

