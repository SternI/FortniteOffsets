/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CorruptionGameplayCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "SOMRuntime.h"
#include "FortniteGame.h"
#include "MeshNetwork.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UWarEffortFundingLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static int32_t AdjustDonation(int32_t& DonationAmount, TEnumAsByte<EWarEffortFundingStationType>& StationType); // 0x101ba778 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool DoesChoiceHaveWinner(const FWarEffortFundingMetadata MetaData, int32_t& ChoiceIndex); // 0x101ba9dc (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetIndexFundedPercent(const FWarEffortFundingMetadata MetaData, int32_t& Index, TEnumAsByte<EWarEffortFundingStationType>& StationType); // 0x101bacd0 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsIndexFunded(const FWarEffortFundingMetadata MetaData, int32_t& Index, TEnumAsByte<EWarEffortFundingStationType>& StationType); // 0x101baeac (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsOption1ChoiceWinner(const FWarEffortFundingMetadata MetaData, int32_t& ChoiceIndex); // 0x101bb258 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsOption2ChoiceWinner(const FWarEffortFundingMetadata MetaData, int32_t& ChoiceIndex); // 0x101bb404 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FString WriteTextToBuffer(const FText Text); // 0x101bc774 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UWarEffortFundingLibrary) == 0x28, "Size mismatch for UWarEffortFundingLibrary");

// Size: 0x90 (Inherited: 0x28, Single: 0x68)
class UCorruptionCoverageMap : public UObject
{
public:

private:
    bool IsLocationCorrupted(const FVector Location, float& Padding) const; // 0x101bb0a4 (Index: 0x0, Flags: Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool UpdateCorruptionCoverageMap(UObject*& WorldContextObject, UTextureRenderTarget2D*& CorruptionRenderTarget, const FVector InTopLeftWorldCoordinate, const FVector InBottomRightWorldCoordinate, float& CoverageThreshold, float& DebugDrawDuration); // 0x101bbc80 (Index: 0x1, Flags: Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UCorruptionCoverageMap) == 0x90, "Size mismatch for UCorruptionCoverageMap");

// Size: 0x50 (Inherited: 0x88, Single: 0xffffffc8)
class UFortCorruptionSequenceData : public UPrimaryDataAsset
{
public:
    TArray<FCorruptionCalendarEventData> CorruptionStartEvents; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCorruptionPauseEvent> CorruptionPauseEvents; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortCorruptionSequenceData) == 0x50, "Size mismatch for UFortCorruptionSequenceData");
static_assert(offsetof(UFortCorruptionSequenceData, CorruptionStartEvents) == 0x30, "Offset mismatch for UFortCorruptionSequenceData::CorruptionStartEvents");
static_assert(offsetof(UFortCorruptionSequenceData, CorruptionPauseEvents) == 0x40, "Offset mismatch for UFortCorruptionSequenceData::CorruptionPauseEvents");

// Size: 0x530 (Inherited: 0x7d0, Single: 0xfffffd60)
class ACubeMovementStaticPath : public AScriptedObjectMovement_StaticPath
{
public:
    float GenerationZTraceHeight; // 0x4f8 (Size: 0x4, Type: FloatProperty)
    float CubeSpacingFactor; // 0x4fc (Size: 0x4, Type: FloatProperty)
    float CubeAngleLimitDegrees; // 0x500 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_504[0x4]; // 0x504 (Size: 0x4, Type: PaddingProperty)
    UFortCorruptionSequenceData* CorruptionSequence; // 0x508 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_510[0x8]; // 0x510 (Size: 0x8, Type: PaddingProperty)
    TArray<FTravelerStepCorruptionOverrideData> TravelerCorruptionStepPercentOverrides; // 0x518 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_528[0x8]; // 0x528 (Size: 0x8, Type: PaddingProperty)

public:
    void EditorGetCorruptionGenerationData(FCubeMovement_CorruptionGenerationData& OutData) const; // 0x101bab98 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)

protected:
    void ClearAllGeneratedSplinesAndLockedData(); // 0x101ba9c8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(ACubeMovementStaticPath) == 0x530, "Size mismatch for ACubeMovementStaticPath");
static_assert(offsetof(ACubeMovementStaticPath, GenerationZTraceHeight) == 0x4f8, "Offset mismatch for ACubeMovementStaticPath::GenerationZTraceHeight");
static_assert(offsetof(ACubeMovementStaticPath, CubeSpacingFactor) == 0x4fc, "Offset mismatch for ACubeMovementStaticPath::CubeSpacingFactor");
static_assert(offsetof(ACubeMovementStaticPath, CubeAngleLimitDegrees) == 0x500, "Offset mismatch for ACubeMovementStaticPath::CubeAngleLimitDegrees");
static_assert(offsetof(ACubeMovementStaticPath, CorruptionSequence) == 0x508, "Offset mismatch for ACubeMovementStaticPath::CorruptionSequence");
static_assert(offsetof(ACubeMovementStaticPath, TravelerCorruptionStepPercentOverrides) == 0x518, "Offset mismatch for ACubeMovementStaticPath::TravelerCorruptionStepPercentOverrides");

// Size: 0x518 (Inherited: 0x1070, Single: 0xfffff4a8)
class AFortAthenaMutator_WarEffort : public AFortAthenaMutator_GameModeBase
{
public:
    uint8_t Pad_4b0[0x8]; // 0x4b0 (Size: 0x8, Type: PaddingProperty)
    FWarEffortMutatorMetadata MeshNetworkMetadata; // 0x4b8 (Size: 0x20, Type: StructProperty)
    TArray<FWarEffortMutatorChoiceData> WeaponChoices; // 0x4d8 (Size: 0x10, Type: ArrayProperty)
    TArray<FPrimaryAssetId> PreloadedItemList; // 0x4e8 (Size: 0x10, Type: ArrayProperty)
    bool bCanPreloadItems; // 0x4f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f9[0x1f]; // 0x4f9 (Size: 0x1f, Type: PaddingProperty)

public:
    void SetFundingManagerReady(bool& bIsReady); // 0x101bb600 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetItemFundedAmount(FGameplayTag& ItemFundingTag, int64_t& CurrentFundingAmount, int64_t& TargetFundingAmount); // 0x101bb72c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetItemFundedPercent(FGameplayTag& ItemFundingTag, float& FundingPercent); // 0x101bb8d8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetItemFundedState(FGameplayTag& ItemFundingTag, bool& bIsActive); // 0x101bba10 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetTryBeforeYouBuyItemState(FGameplayTag& ItemFundingTag, bool& bIsActive); // 0x101bbb48 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_PreloadedItemList(); // 0x101bb5ec (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(AFortAthenaMutator_WarEffort) == 0x518, "Size mismatch for AFortAthenaMutator_WarEffort");
static_assert(offsetof(AFortAthenaMutator_WarEffort, MeshNetworkMetadata) == 0x4b8, "Offset mismatch for AFortAthenaMutator_WarEffort::MeshNetworkMetadata");
static_assert(offsetof(AFortAthenaMutator_WarEffort, WeaponChoices) == 0x4d8, "Offset mismatch for AFortAthenaMutator_WarEffort::WeaponChoices");
static_assert(offsetof(AFortAthenaMutator_WarEffort, PreloadedItemList) == 0x4e8, "Offset mismatch for AFortAthenaMutator_WarEffort::PreloadedItemList");
static_assert(offsetof(AFortAthenaMutator_WarEffort, bCanPreloadItems) == 0x4f8, "Offset mismatch for AFortAthenaMutator_WarEffort::bCanPreloadItems");

// Size: 0x330 (Inherited: 0x578, Single: 0xfffffdb8)
class AWarEffortMeshActor : public AInfo
{
public:
    UMeshNetworkComponent* MeshNetworkComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayTag> ActiveFundedItems; // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTag> ActiveTryBeforeYouBuyItems; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<FWarEffortFundingData> CurrentFundingData; // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2e0[0x50]; // 0x2e0 (Size: 0x50, Type: PaddingProperty)

protected:
    void OnRep_ActiveFundedItems(); // 0x101bb5b0 (Index: 0x0, Flags: Final|Native|Protected)
    void OnRep_ActiveTryBeforeYouBuyItems(); // 0x101bb5c4 (Index: 0x1, Flags: Final|Native|Protected)
    void OnRep_CurrentFundingData(); // 0x101bb5d8 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(AWarEffortMeshActor) == 0x330, "Size mismatch for AWarEffortMeshActor");
static_assert(offsetof(AWarEffortMeshActor, MeshNetworkComponent) == 0x2a8, "Offset mismatch for AWarEffortMeshActor::MeshNetworkComponent");
static_assert(offsetof(AWarEffortMeshActor, ActiveFundedItems) == 0x2b0, "Offset mismatch for AWarEffortMeshActor::ActiveFundedItems");
static_assert(offsetof(AWarEffortMeshActor, ActiveTryBeforeYouBuyItems) == 0x2c0, "Offset mismatch for AWarEffortMeshActor::ActiveTryBeforeYouBuyItems");
static_assert(offsetof(AWarEffortMeshActor, CurrentFundingData) == 0x2d0, "Offset mismatch for AWarEffortMeshActor::CurrentFundingData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FWarEffortFundingOptionData
{
    FGameplayTag OptionTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    int64_t CurrentFundingAmount; // 0x8 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FWarEffortFundingOptionData) == 0x10, "Size mismatch for FWarEffortFundingOptionData");
static_assert(offsetof(FWarEffortFundingOptionData, OptionTag) == 0x0, "Offset mismatch for FWarEffortFundingOptionData::OptionTag");
static_assert(offsetof(FWarEffortFundingOptionData, CurrentFundingAmount) == 0x8, "Offset mismatch for FWarEffortFundingOptionData::CurrentFundingAmount");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FWarEffortFundingChoiceData
{
    FWarEffortFundingOptionData Option1; // 0x0 (Size: 0x10, Type: StructProperty)
    FWarEffortFundingOptionData Option2; // 0x10 (Size: 0x10, Type: StructProperty)
    int64_t TargetFundingAmount; // 0x20 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FWarEffortFundingChoiceData) == 0x28, "Size mismatch for FWarEffortFundingChoiceData");
static_assert(offsetof(FWarEffortFundingChoiceData, Option1) == 0x0, "Offset mismatch for FWarEffortFundingChoiceData::Option1");
static_assert(offsetof(FWarEffortFundingChoiceData, Option2) == 0x10, "Offset mismatch for FWarEffortFundingChoiceData::Option2");
static_assert(offsetof(FWarEffortFundingChoiceData, TargetFundingAmount) == 0x20, "Offset mismatch for FWarEffortFundingChoiceData::TargetFundingAmount");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FWarEffortIndexedFundingData
{
    TArray<int64_t> CurrentFundingArray; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int64_t FinalFundingAmount; // 0x10 (Size: 0x8, Type: Int64Property)
    int64_t TowerFundingAmount; // 0x18 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FWarEffortIndexedFundingData) == 0x20, "Size mismatch for FWarEffortIndexedFundingData");
static_assert(offsetof(FWarEffortIndexedFundingData, CurrentFundingArray) == 0x0, "Offset mismatch for FWarEffortIndexedFundingData::CurrentFundingArray");
static_assert(offsetof(FWarEffortIndexedFundingData, FinalFundingAmount) == 0x10, "Offset mismatch for FWarEffortIndexedFundingData::FinalFundingAmount");
static_assert(offsetof(FWarEffortIndexedFundingData, TowerFundingAmount) == 0x18, "Offset mismatch for FWarEffortIndexedFundingData::TowerFundingAmount");

// Size: 0x30 (Inherited: 0x1, Single: 0x2f)
struct FWarEffortFundingMetadata : FMeshMetaDataStruct
{
    FWarEffortIndexedFundingData IndexedFundingData; // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<FWarEffortFundingChoiceData> FundingChoices; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FWarEffortFundingMetadata) == 0x30, "Size mismatch for FWarEffortFundingMetadata");
static_assert(offsetof(FWarEffortFundingMetadata, IndexedFundingData) == 0x0, "Offset mismatch for FWarEffortFundingMetadata::IndexedFundingData");
static_assert(offsetof(FWarEffortFundingMetadata, FundingChoices) == 0x20, "Offset mismatch for FWarEffortFundingMetadata::FundingChoices");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FCubeMovement_CorruptionGenerationSplinePointData
{
    FTransform SplinePointTransform; // 0x0 (Size: 0x60, Type: StructProperty)
    float SplinePercentComplete; // 0x60 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_64[0xc]; // 0x64 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FCubeMovement_CorruptionGenerationSplinePointData) == 0x70, "Size mismatch for FCubeMovement_CorruptionGenerationSplinePointData");
static_assert(offsetof(FCubeMovement_CorruptionGenerationSplinePointData, SplinePointTransform) == 0x0, "Offset mismatch for FCubeMovement_CorruptionGenerationSplinePointData::SplinePointTransform");
static_assert(offsetof(FCubeMovement_CorruptionGenerationSplinePointData, SplinePercentComplete) == 0x60, "Offset mismatch for FCubeMovement_CorruptionGenerationSplinePointData::SplinePercentComplete");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCubeMovement_CorruptionGenerationTravelerData
{
    TArray<FCubeMovement_CorruptionGenerationSplinePointData> SplinePointData; // 0x0 (Size: 0x10, Type: ArrayProperty)
    AFortScriptedObjectMovement_MovableObjectBase* PathTraveler; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCubeMovement_CorruptionGenerationTravelerData) == 0x18, "Size mismatch for FCubeMovement_CorruptionGenerationTravelerData");
static_assert(offsetof(FCubeMovement_CorruptionGenerationTravelerData, SplinePointData) == 0x0, "Offset mismatch for FCubeMovement_CorruptionGenerationTravelerData::SplinePointData");
static_assert(offsetof(FCubeMovement_CorruptionGenerationTravelerData, PathTraveler) == 0x10, "Offset mismatch for FCubeMovement_CorruptionGenerationTravelerData::PathTraveler");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCubeMovement_CorruptionGenerationData
{
    TArray<FCubeMovement_CorruptionGenerationTravelerData> TravelerData; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCubeMovement_CorruptionGenerationData) == 0x10, "Size mismatch for FCubeMovement_CorruptionGenerationData");
static_assert(offsetof(FCubeMovement_CorruptionGenerationData, TravelerData) == 0x0, "Offset mismatch for FCubeMovement_CorruptionGenerationData::TravelerData");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCorruptionCalendarEventData
{
    FString EventName; // 0x0 (Size: 0x10, Type: StrProperty)
    float StartPercent; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCorruptionCalendarEventData) == 0x18, "Size mismatch for FCorruptionCalendarEventData");
static_assert(offsetof(FCorruptionCalendarEventData, EventName) == 0x0, "Offset mismatch for FCorruptionCalendarEventData::EventName");
static_assert(offsetof(FCorruptionCalendarEventData, StartPercent) == 0x10, "Offset mismatch for FCorruptionCalendarEventData::StartPercent");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCorruptionPauseEvent
{
    FString EventName; // 0x0 (Size: 0x10, Type: StrProperty)
    float PercentDurationToPause; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCorruptionPauseEvent) == 0x18, "Size mismatch for FCorruptionPauseEvent");
static_assert(offsetof(FCorruptionPauseEvent, EventName) == 0x0, "Offset mismatch for FCorruptionPauseEvent::EventName");
static_assert(offsetof(FCorruptionPauseEvent, PercentDurationToPause) == 0x10, "Offset mismatch for FCorruptionPauseEvent::PercentDurationToPause");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FTravelerStepCorruptionOverrideData
{
    TMap<float, FString> PointGroupStepPercentOverrides; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FTravelerStepCorruptionOverrideData) == 0x50, "Size mismatch for FTravelerStepCorruptionOverrideData");
static_assert(offsetof(FTravelerStepCorruptionOverrideData, PointGroupStepPercentOverrides) == 0x0, "Offset mismatch for FTravelerStepCorruptionOverrideData::PointGroupStepPercentOverrides");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FWarEffortMutatorChoiceData
{
    FGameplayTag FundingTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<TSoftObjectPtr<UFortItemDefinition*>> SoftRefsToLoad; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TMap<FScalableFloat, FName> LootTableMods; // 0x18 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FWarEffortMutatorChoiceData) == 0x68, "Size mismatch for FWarEffortMutatorChoiceData");
static_assert(offsetof(FWarEffortMutatorChoiceData, FundingTag) == 0x0, "Offset mismatch for FWarEffortMutatorChoiceData::FundingTag");
static_assert(offsetof(FWarEffortMutatorChoiceData, SoftRefsToLoad) == 0x8, "Offset mismatch for FWarEffortMutatorChoiceData::SoftRefsToLoad");
static_assert(offsetof(FWarEffortMutatorChoiceData, LootTableMods) == 0x18, "Offset mismatch for FWarEffortMutatorChoiceData::LootTableMods");

// Size: 0x20 (Inherited: 0x1, Single: 0x1f)
struct FWarEffortMutatorMetadata : FMeshMetaDataStruct
{
    TArray<FGameplayTag> ActiveFundedItems; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTag> ActiveTryBeforeYouBuyItems; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FWarEffortMutatorMetadata) == 0x20, "Size mismatch for FWarEffortMutatorMetadata");
static_assert(offsetof(FWarEffortMutatorMetadata, ActiveFundedItems) == 0x0, "Offset mismatch for FWarEffortMutatorMetadata::ActiveFundedItems");
static_assert(offsetof(FWarEffortMutatorMetadata, ActiveTryBeforeYouBuyItems) == 0x10, "Offset mismatch for FWarEffortMutatorMetadata::ActiveTryBeforeYouBuyItems");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FWarEffortFundingData
{
    FGameplayTag FundingTag; // 0x0 (Size: 0x4, Type: StructProperty)
    float FundedPercent; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FWarEffortFundingData) == 0x8, "Size mismatch for FWarEffortFundingData");
static_assert(offsetof(FWarEffortFundingData, FundingTag) == 0x0, "Offset mismatch for FWarEffortFundingData::FundingTag");
static_assert(offsetof(FWarEffortFundingData, FundedPercent) == 0x4, "Offset mismatch for FWarEffortFundingData::FundedPercent");

