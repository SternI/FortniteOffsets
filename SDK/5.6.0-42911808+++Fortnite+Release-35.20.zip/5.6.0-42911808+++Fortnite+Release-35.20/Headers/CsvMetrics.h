/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CsvMetrics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "WorldMetricsCore.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x88 (Inherited: 0x50, Single: 0x38)
class UCsvActorCountMetric : public UWorldMetricInterface
{
public:
};

static_assert(sizeof(UCsvActorCountMetric) == 0x88, "Size mismatch for UCsvActorCountMetric");

// Size: 0x60 (Inherited: 0x88, Single: 0xffffffd8)
class UCsvMetricsSubsystem : public UWorldSubsystem
{
public:
    TArray<UClass*> MetricClasses; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x20]; // 0x40 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UCsvMetricsSubsystem) == 0x60, "Size mismatch for UCsvMetricsSubsystem");
static_assert(offsetof(UCsvMetricsSubsystem, MetricClasses) == 0x30, "Offset mismatch for UCsvMetricsSubsystem::MetricClasses");

