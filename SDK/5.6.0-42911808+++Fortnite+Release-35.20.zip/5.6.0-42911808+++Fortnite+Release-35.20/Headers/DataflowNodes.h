/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowNodes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DataflowCore.h"
#include "DataflowEnginePlugin.h"
#include "Chaos.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDataflowFunctionProperty
{
};

static_assert(sizeof(FDataflowFunctionProperty) == 0x10, "Size mismatch for FDataflowFunctionProperty");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FScalarVertexPropertyGroup
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FScalarVertexPropertyGroup) == 0x4, "Size mismatch for FScalarVertexPropertyGroup");
static_assert(offsetof(FScalarVertexPropertyGroup, Name) == 0x0, "Offset mismatch for FScalarVertexPropertyGroup::Name");

// Size: 0x368 (Inherited: 0x270, Single: 0xf8)
struct FDataflowCollectionAddScalarVertexPropertyNode : FDataflowNode
{
    FManagedArrayCollection Collection; // 0x270 (Size: 0xb0, Type: StructProperty)
    FString Name; // 0x320 (Size: 0x10, Type: StrProperty)
    FCollectionAttributeKey AttributeKey; // 0x330 (Size: 0x20, Type: StructProperty)
    TArray<float> VertexWeights; // 0x350 (Size: 0x10, Type: ArrayProperty)
    FScalarVertexPropertyGroup TargetGroup; // 0x360 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_364[0x4]; // 0x364 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowCollectionAddScalarVertexPropertyNode) == 0x368, "Size mismatch for FDataflowCollectionAddScalarVertexPropertyNode");
static_assert(offsetof(FDataflowCollectionAddScalarVertexPropertyNode, Collection) == 0x270, "Offset mismatch for FDataflowCollectionAddScalarVertexPropertyNode::Collection");
static_assert(offsetof(FDataflowCollectionAddScalarVertexPropertyNode, Name) == 0x320, "Offset mismatch for FDataflowCollectionAddScalarVertexPropertyNode::Name");
static_assert(offsetof(FDataflowCollectionAddScalarVertexPropertyNode, AttributeKey) == 0x330, "Offset mismatch for FDataflowCollectionAddScalarVertexPropertyNode::AttributeKey");
static_assert(offsetof(FDataflowCollectionAddScalarVertexPropertyNode, VertexWeights) == 0x350, "Offset mismatch for FDataflowCollectionAddScalarVertexPropertyNode::VertexWeights");
static_assert(offsetof(FDataflowCollectionAddScalarVertexPropertyNode, TargetGroup) == 0x360, "Offset mismatch for FDataflowCollectionAddScalarVertexPropertyNode::TargetGroup");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FMakeAttributeKeyDataflowNode : FDataflowNode
{
    FString GroupIn; // 0x270 (Size: 0x10, Type: StrProperty)
    FString AttributeIn; // 0x280 (Size: 0x10, Type: StrProperty)
    FCollectionAttributeKey AttributeKeyOut; // 0x290 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FMakeAttributeKeyDataflowNode) == 0x2b0, "Size mismatch for FMakeAttributeKeyDataflowNode");
static_assert(offsetof(FMakeAttributeKeyDataflowNode, GroupIn) == 0x270, "Offset mismatch for FMakeAttributeKeyDataflowNode::GroupIn");
static_assert(offsetof(FMakeAttributeKeyDataflowNode, AttributeIn) == 0x280, "Offset mismatch for FMakeAttributeKeyDataflowNode::AttributeIn");
static_assert(offsetof(FMakeAttributeKeyDataflowNode, AttributeKeyOut) == 0x290, "Offset mismatch for FMakeAttributeKeyDataflowNode::AttributeKeyOut");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FBreakAttributeKeyDataflowNode : FDataflowNode
{
    FCollectionAttributeKey AttributeKeyIn; // 0x270 (Size: 0x20, Type: StructProperty)
    FString AttributeOut; // 0x290 (Size: 0x10, Type: StrProperty)
    FString GroupOut; // 0x2a0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FBreakAttributeKeyDataflowNode) == 0x2b0, "Size mismatch for FBreakAttributeKeyDataflowNode");
static_assert(offsetof(FBreakAttributeKeyDataflowNode, AttributeKeyIn) == 0x270, "Offset mismatch for FBreakAttributeKeyDataflowNode::AttributeKeyIn");
static_assert(offsetof(FBreakAttributeKeyDataflowNode, AttributeOut) == 0x290, "Offset mismatch for FBreakAttributeKeyDataflowNode::AttributeOut");
static_assert(offsetof(FBreakAttributeKeyDataflowNode, GroupOut) == 0x2a0, "Offset mismatch for FBreakAttributeKeyDataflowNode::GroupOut");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FFloatOverrideDataflowNode : FDataflowNode
{
    FName PropertyName; // 0x270 (Size: 0x4, Type: NameProperty)
    FName KeyName; // 0x274 (Size: 0x4, Type: NameProperty)
    float ValueOut; // 0x278 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFloatOverrideDataflowNode) == 0x280, "Size mismatch for FFloatOverrideDataflowNode");
static_assert(offsetof(FFloatOverrideDataflowNode, PropertyName) == 0x270, "Offset mismatch for FFloatOverrideDataflowNode::PropertyName");
static_assert(offsetof(FFloatOverrideDataflowNode, KeyName) == 0x274, "Offset mismatch for FFloatOverrideDataflowNode::KeyName");
static_assert(offsetof(FFloatOverrideDataflowNode, ValueOut) == 0x278, "Offset mismatch for FFloatOverrideDataflowNode::ValueOut");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FSelectionSetDataflowNode : FDataflowNode
{
    FString Indices; // 0x270 (Size: 0x10, Type: StrProperty)
    TArray<int32_t> IndicesOut; // 0x280 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSelectionSetDataflowNode) == 0x290, "Size mismatch for FSelectionSetDataflowNode");
static_assert(offsetof(FSelectionSetDataflowNode, Indices) == 0x270, "Offset mismatch for FSelectionSetDataflowNode::Indices");
static_assert(offsetof(FSelectionSetDataflowNode, IndicesOut) == 0x280, "Offset mismatch for FSelectionSetDataflowNode::IndicesOut");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FGetSkeletalMeshDataflowNode : FDataflowNode
{
    USkeletalMesh* SkeletalMesh; // 0x270 (Size: 0x8, Type: ObjectProperty)
    FName PropertyName; // 0x278 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGetSkeletalMeshDataflowNode) == 0x280, "Size mismatch for FGetSkeletalMeshDataflowNode");
static_assert(offsetof(FGetSkeletalMeshDataflowNode, SkeletalMesh) == 0x270, "Offset mismatch for FGetSkeletalMeshDataflowNode::SkeletalMesh");
static_assert(offsetof(FGetSkeletalMeshDataflowNode, PropertyName) == 0x278, "Offset mismatch for FGetSkeletalMeshDataflowNode::PropertyName");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FGetSkeletonDataflowNode : FDataflowNode
{
    USkeleton* Skeleton; // 0x270 (Size: 0x8, Type: ObjectProperty)
    FName PropertyName; // 0x278 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGetSkeletonDataflowNode) == 0x280, "Size mismatch for FGetSkeletonDataflowNode");
static_assert(offsetof(FGetSkeletonDataflowNode, Skeleton) == 0x270, "Offset mismatch for FGetSkeletonDataflowNode::Skeleton");
static_assert(offsetof(FGetSkeletonDataflowNode, PropertyName) == 0x278, "Offset mismatch for FGetSkeletonDataflowNode::PropertyName");

// Size: 0x288 (Inherited: 0x270, Single: 0x18)
struct FSkeletalMeshBoneDataflowNode : FDataflowNode
{
    FName BoneName; // 0x270 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_274[0x4]; // 0x274 (Size: 0x4, Type: PaddingProperty)
    USkeletalMesh* SkeletalMesh; // 0x278 (Size: 0x8, Type: ObjectProperty)
    int32_t BoneIndexOut; // 0x280 (Size: 0x4, Type: IntProperty)
    FName PropertyName; // 0x284 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FSkeletalMeshBoneDataflowNode) == 0x288, "Size mismatch for FSkeletalMeshBoneDataflowNode");
static_assert(offsetof(FSkeletalMeshBoneDataflowNode, BoneName) == 0x270, "Offset mismatch for FSkeletalMeshBoneDataflowNode::BoneName");
static_assert(offsetof(FSkeletalMeshBoneDataflowNode, SkeletalMesh) == 0x278, "Offset mismatch for FSkeletalMeshBoneDataflowNode::SkeletalMesh");
static_assert(offsetof(FSkeletalMeshBoneDataflowNode, BoneIndexOut) == 0x280, "Offset mismatch for FSkeletalMeshBoneDataflowNode::BoneIndexOut");
static_assert(offsetof(FSkeletalMeshBoneDataflowNode, PropertyName) == 0x284, "Offset mismatch for FSkeletalMeshBoneDataflowNode::PropertyName");

// Size: 0x2e0 (Inherited: 0x270, Single: 0x70)
struct FSkeletalMeshReferenceTransformDataflowNode : FDataflowNode
{
    USkeletalMesh* SkeletalMeshIn; // 0x270 (Size: 0x8, Type: ObjectProperty)
    int32_t BoneIndexIn; // 0x278 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
    FTransform TransformOut; // 0x280 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FSkeletalMeshReferenceTransformDataflowNode) == 0x2e0, "Size mismatch for FSkeletalMeshReferenceTransformDataflowNode");
static_assert(offsetof(FSkeletalMeshReferenceTransformDataflowNode, SkeletalMeshIn) == 0x270, "Offset mismatch for FSkeletalMeshReferenceTransformDataflowNode::SkeletalMeshIn");
static_assert(offsetof(FSkeletalMeshReferenceTransformDataflowNode, BoneIndexIn) == 0x278, "Offset mismatch for FSkeletalMeshReferenceTransformDataflowNode::BoneIndexIn");
static_assert(offsetof(FSkeletalMeshReferenceTransformDataflowNode, TransformOut) == 0x280, "Offset mismatch for FSkeletalMeshReferenceTransformDataflowNode::TransformOut");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FGetStaticMeshDataflowNode : FDataflowNode
{
    UStaticMesh* StaticMesh; // 0x270 (Size: 0x8, Type: ObjectProperty)
    FName PropertyName; // 0x278 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGetStaticMeshDataflowNode) == 0x280, "Size mismatch for FGetStaticMeshDataflowNode");
static_assert(offsetof(FGetStaticMeshDataflowNode, StaticMesh) == 0x270, "Offset mismatch for FGetStaticMeshDataflowNode::StaticMesh");
static_assert(offsetof(FGetStaticMeshDataflowNode, PropertyName) == 0x278, "Offset mismatch for FGetStaticMeshDataflowNode::PropertyName");

