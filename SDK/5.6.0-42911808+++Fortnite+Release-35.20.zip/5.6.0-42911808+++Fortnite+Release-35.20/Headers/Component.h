/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Component
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "MassEntity.h"
#include "Niagara.h"

// Size: 0xa30 (Inherited: 0xd00, Single: 0xfffffd30)
class ACameraEntityProxyActor : public ACameraActor
{
public:
};

static_assert(sizeof(ACameraEntityProxyActor) == 0xa30, "Size mismatch for ACameraEntityProxyActor");

// Size: 0x2b0 (Inherited: 0x580, Single: 0xfffffd30)
class APointLightProxyActor : public ALightProxyActor
{
public:
};

static_assert(sizeof(APointLightProxyActor) == 0x2b0, "Size mismatch for APointLightProxyActor");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ALightProxyActor : public AActor
{
public:
    ULightComponent* LightComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ALightProxyActor) == 0x2b0, "Size mismatch for ALightProxyActor");
static_assert(offsetof(ALightProxyActor, LightComponent) == 0x2a8, "Offset mismatch for ALightProxyActor::LightComponent");

// Size: 0x2b0 (Inherited: 0x580, Single: 0xfffffd30)
class ADirectionalLightProxyActor : public ALightProxyActor
{
public:
};

static_assert(sizeof(ADirectionalLightProxyActor) == 0x2b0, "Size mismatch for ADirectionalLightProxyActor");

// Size: 0x200 (Inherited: 0x28, Single: 0x1d8)
class UStaticMeshEntityComponent_Implementation : public UObject
{
public:
};

static_assert(sizeof(UStaticMeshEntityComponent_Implementation) == 0x200, "Size mismatch for UStaticMeshEntityComponent_Implementation");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AParticleSystemProxyActor : public AActor
{
public:
    UNiagaraComponent* NiagaraComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AParticleSystemProxyActor) == 0x2b0, "Size mismatch for AParticleSystemProxyActor");
static_assert(offsetof(AParticleSystemProxyActor, NiagaraComponent) == 0x2a8, "Offset mismatch for AParticleSystemProxyActor::NiagaraComponent");

// Size: 0x1b0 (Inherited: 0x28, Single: 0x188)
class UPhysicsEntityComponent_Implementation : public UObject
{
public:
    FBodyInstance BodyInstance; // 0x28 (Size: 0x178, Type: StructProperty)
    uint8_t Pad_1a0[0x10]; // 0x1a0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UPhysicsEntityComponent_Implementation) == 0x1b0, "Size mismatch for UPhysicsEntityComponent_Implementation");
static_assert(offsetof(UPhysicsEntityComponent_Implementation, BodyInstance) == 0x28, "Offset mismatch for UPhysicsEntityComponent_Implementation::BodyInstance");

// Size: 0x2b0 (Inherited: 0x580, Single: 0xfffffd30)
class ARectLightProxyActor : public ALightProxyActor
{
public:
};

static_assert(sizeof(ARectLightProxyActor) == 0x2b0, "Size mismatch for ARectLightProxyActor");

// Size: 0x100 (Inherited: 0x28, Single: 0xd8)
class UVerseRigidBodyMeshPhysics : public UObject
{
public:
};

static_assert(sizeof(UVerseRigidBodyMeshPhysics) == 0x100, "Size mismatch for UVerseRigidBodyMeshPhysics");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ASoundProxyActor : public AActor
{
public:
    UAudioComponent* AudioComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ASoundProxyActor) == 0x2b0, "Size mismatch for ASoundProxyActor");
static_assert(offsetof(ASoundProxyActor, AudioComponent) == 0x2a8, "Offset mismatch for ASoundProxyActor::AudioComponent");

// Size: 0x2b0 (Inherited: 0x580, Single: 0xfffffd30)
class ASphereLightProxyActor : public ALightProxyActor
{
public:
};

static_assert(sizeof(ASphereLightProxyActor) == 0x2b0, "Size mismatch for ASphereLightProxyActor");

// Size: 0x2b0 (Inherited: 0x580, Single: 0xfffffd30)
class ASpotLightProxyActor : public ALightProxyActor
{
public:
};

static_assert(sizeof(ASpotLightProxyActor) == 0x2b0, "Size mismatch for ASpotLightProxyActor");

// Size: 0x320 (Inherited: 0x2d0, Single: 0x50)
class ATextDisplayProxyActor : public AActor
{
public:
    uint8_t Pad_2a8[0x10]; // 0x2a8 (Size: 0x10, Type: PaddingProperty)
    UTextRenderComponent* TextRenderComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c0[0x30]; // 0x2c0 (Size: 0x30, Type: PaddingProperty)
    UMaterialInstanceDynamic* TextMaterialInstanceDynamic; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UFont* Font; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_300[0x20]; // 0x300 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(ATextDisplayProxyActor) == 0x320, "Size mismatch for ATextDisplayProxyActor");
static_assert(offsetof(ATextDisplayProxyActor, TextRenderComponent) == 0x2b8, "Offset mismatch for ATextDisplayProxyActor::TextRenderComponent");
static_assert(offsetof(ATextDisplayProxyActor, TextMaterialInstanceDynamic) == 0x2f0, "Offset mismatch for ATextDisplayProxyActor::TextMaterialInstanceDynamic");
static_assert(offsetof(ATextDisplayProxyActor, Font) == 0x2f8, "Offset mismatch for ATextDisplayProxyActor::Font");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FEntityMeshFragment : FMassConstSharedFragment
{
    TWeakObjectPtr<UStaticMesh*> Mesh; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FEntityMeshFragment) == 0x8, "Size mismatch for FEntityMeshFragment");
static_assert(offsetof(FEntityMeshFragment, Mesh) == 0x0, "Offset mismatch for FEntityMeshFragment::Mesh");

// Size: 0x21 (Inherited: 0x1, Single: 0x20)
struct FEntityColliderFragment : FMassConstSharedFragment
{
    TEnumAsByte<ECollisionEnabled> CollisionType; // 0x0 (Size: 0x1, Type: ByteProperty)
    FCollisionResponseContainer CollisionResponse; // 0x1 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FEntityColliderFragment) == 0x21, "Size mismatch for FEntityColliderFragment");
static_assert(offsetof(FEntityColliderFragment, CollisionType) == 0x0, "Offset mismatch for FEntityColliderFragment::CollisionType");
static_assert(offsetof(FEntityColliderFragment, CollisionResponse) == 0x1, "Offset mismatch for FEntityColliderFragment::CollisionResponse");

