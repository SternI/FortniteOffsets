/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlendStack
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlendStackAnimNodeLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void BlendTo(const FAnimUpdateContext Context, const FBlendStackAnimNodeReference BlendStackNode, UAnimationAsset*& AnimationAsset, float& AnimationTime, bool& bLoop, bool& bMirrored, float& BlendTime, FVector& BlendParameters, float& WantedPlayRate, float& ActivationDelay); // 0xc05b100 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void BlendToWithSettings(const FAnimUpdateContext Context, const FBlendStackAnimNodeReference BlendStackNode, UAnimationAsset*& AnimationAsset, float& AnimationTime, bool& bLoop, bool& bMirrored, float& BlendTime, UBlendProfile*& BlendProfile, EAlphaBlendOption& BlendOption, bool& bInertialBlend, FVector& BlendParameters, float& WantedPlayRate, float& ActivationDelay); // 0xc05b90c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FBlendStackAnimNodeReference ConvertToBlendStackNode(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0xc05c3e0 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToBlendStackNodePure(const FAnimNodeReference Node, FBlendStackAnimNodeReference& BlendStackNode, bool& Result); // 0xc05c59c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void ForceBlendNextUpdate(const FBlendStackAnimNodeReference BlendStackNode); // 0xc05c7c8 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UAnimationAsset* GetCurrentAsset(const FBlendStackAnimNodeReference BlendStackNode); // 0xc05c88c (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetCurrentAssetTime(const FBlendStackAnimNodeReference BlendStackNode); // 0xc05c960 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetCurrentAssetTimeRemaining(const FBlendStackAnimNodeReference BlendStackNode); // 0xc05ca34 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UAnimationAsset* GetCurrentBlendStackAnimAsset(const FAnimNodeReference Node); // 0xc05cb08 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetCurrentBlendStackAnimAssetMirrored(const FAnimNodeReference Node); // 0xc05cd20 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UMirrorDataTable* GetCurrentBlendStackAnimAssetMirrorTable(const FAnimNodeReference Node); // 0xc05cc10 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetCurrentBlendStackAnimAssetTime(const FAnimNodeReference Node); // 0xc05ce30 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetCurrentBlendStackAnimIsActive(const FAnimNodeReference Node); // 0xc05cf18 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsCurrentAssetLooping(const FBlendStackAnimNodeReference BlendStackNode); // 0xc05d3a0 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UBlendStackAnimNodeLibrary) == 0x28, "Size mismatch for UBlendStackAnimNodeLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlendStackInputAnimNodeLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FBlendStackInputAnimNodeReference ConvertToBlendStackInputNode(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0xc05bff8 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToBlendStackInputNodePure(const FAnimNodeReference Node, FBlendStackInputAnimNodeReference& BlendStackInputNode, bool& Result); // 0xc05c1b4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void GetProperties(const FBlendStackInputAnimNodeReference BlendStackInputNode, UAnimationAsset*& AnimationAsset, float& AccumulatedTime); // 0xc05d024 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBlendStackInputAnimNodeLibrary) == 0x28, "Size mismatch for UBlendStackInputAnimNodeLibrary");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FBlendStackAnimNodeReference : FAnimNodeReference
{
};

static_assert(sizeof(FBlendStackAnimNodeReference) == 0x10, "Size mismatch for FBlendStackAnimNodeReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FBlendStackInputAnimNodeReference : FAnimNodeReference
{
};

static_assert(sizeof(FBlendStackInputAnimNodeReference) == 0x10, "Size mismatch for FBlendStackInputAnimNodeReference");

// Size: 0x388 (Inherited: 0x0, Single: 0x388)
struct FBlendStackAnimPlayer
{
    FAnimNode_SequencePlayer_Standalone SequencePlayerNode; // 0x20 (Size: 0x90, Type: StructProperty)
    FAnimNode_BlendSpacePlayer_Standalone BlendSpacePlayerNode; // 0xb0 (Size: 0x90, Type: StructProperty)
    FAnimNode_Mirror_Standalone MirrorNode; // 0x140 (Size: 0x60, Type: StructProperty)
    uint8_t Pad_1a0[0x1e8]; // 0x1a0 (Size: 0x1e8, Type: PaddingProperty)
};

static_assert(sizeof(FBlendStackAnimPlayer) == 0x388, "Size mismatch for FBlendStackAnimPlayer");
static_assert(offsetof(FBlendStackAnimPlayer, SequencePlayerNode) == 0x20, "Offset mismatch for FBlendStackAnimPlayer::SequencePlayerNode");
static_assert(offsetof(FBlendStackAnimPlayer, BlendSpacePlayerNode) == 0xb0, "Offset mismatch for FBlendStackAnimPlayer::BlendSpacePlayerNode");
static_assert(offsetof(FBlendStackAnimPlayer, MirrorNode) == 0x140, "Offset mismatch for FBlendStackAnimPlayer::MirrorNode");

// Size: 0xc0 (Inherited: 0x58, Single: 0x68)
struct FAnimNode_BlendStack_Standalone : FAnimNode_AssetPlayerBase
{
    uint8_t Pad_38[0x10]; // 0x38 (Size: 0x10, Type: PaddingProperty)
    TArray<FPoseLink> PerSampleGraphPoseLinks; // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    TArray<FBlendStackAnimPlayer> AnimPlayers; // 0x60 (Size: 0x10, Type: ArrayProperty)
    bool bShouldFilterNotifies; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    UObject* StitchDatabase; // 0x78 (Size: 0x8, Type: ObjectProperty)
    float StitchBlendTime; // 0x80 (Size: 0x4, Type: FloatProperty)
    float StitchBlendMaxCost; // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxActiveBlends; // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStoreBlendedPose; // 0x8c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d[0x23]; // 0x8d (Size: 0x23, Type: PaddingProperty)
    float NotifyRecencyTimeOut; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float MaxBlendInTimeToOverrideAnimation; // 0xb4 (Size: 0x4, Type: FloatProperty)
    float PlayerDepthBlendInTimeMultiplier; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendStack_Standalone) == 0xc0, "Size mismatch for FAnimNode_BlendStack_Standalone");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, PerSampleGraphPoseLinks) == 0x48, "Offset mismatch for FAnimNode_BlendStack_Standalone::PerSampleGraphPoseLinks");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, AnimPlayers) == 0x60, "Offset mismatch for FAnimNode_BlendStack_Standalone::AnimPlayers");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, bShouldFilterNotifies) == 0x70, "Offset mismatch for FAnimNode_BlendStack_Standalone::bShouldFilterNotifies");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, StitchDatabase) == 0x78, "Offset mismatch for FAnimNode_BlendStack_Standalone::StitchDatabase");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, StitchBlendTime) == 0x80, "Offset mismatch for FAnimNode_BlendStack_Standalone::StitchBlendTime");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, StitchBlendMaxCost) == 0x84, "Offset mismatch for FAnimNode_BlendStack_Standalone::StitchBlendMaxCost");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, MaxActiveBlends) == 0x88, "Offset mismatch for FAnimNode_BlendStack_Standalone::MaxActiveBlends");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, bStoreBlendedPose) == 0x8c, "Offset mismatch for FAnimNode_BlendStack_Standalone::bStoreBlendedPose");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, NotifyRecencyTimeOut) == 0xb0, "Offset mismatch for FAnimNode_BlendStack_Standalone::NotifyRecencyTimeOut");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, MaxBlendInTimeToOverrideAnimation) == 0xb4, "Offset mismatch for FAnimNode_BlendStack_Standalone::MaxBlendInTimeToOverrideAnimation");
static_assert(offsetof(FAnimNode_BlendStack_Standalone, PlayerDepthBlendInTimeMultiplier) == 0xb8, "Offset mismatch for FAnimNode_BlendStack_Standalone::PlayerDepthBlendInTimeMultiplier");

// Size: 0x138 (Inherited: 0x118, Single: 0x20)
struct FAnimNode_BlendStack : FAnimNode_BlendStack_Standalone
{
    UAnimationAsset* AnimationAsset; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    float AnimationTime; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ActivationDelayTime; // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bLoop; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bMirrored; // 0xd1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d2[0x2]; // 0xd2 (Size: 0x2, Type: PaddingProperty)
    float WantedPlayRate; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float BlendTime; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float MaxAnimationDeltaTime; // 0xdc (Size: 0x4, Type: FloatProperty)
    UBlendProfile* BlendProfile; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    uint8_t BlendOption; // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t BlendspaceUpdateMode; // 0xe9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_ea[0x6]; // 0xea (Size: 0x6, Type: PaddingProperty)
    FVector BlendParameters; // 0xf0 (Size: 0x18, Type: StructProperty)
    UMirrorDataTable* MirrorDataTable; // 0x108 (Size: 0x8, Type: ObjectProperty)
    float BlendParametersDeltaThreshold; // 0x110 (Size: 0x4, Type: FloatProperty)
    bool bUseInertialBlend; // 0x114 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_115[0x3]; // 0x115 (Size: 0x3, Type: PaddingProperty)
    FName InertialBlendNodeTag; // 0x118 (Size: 0x4, Type: NameProperty)
    bool bResetOnBecomingRelevant; // 0x11c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11d[0x1b]; // 0x11d (Size: 0x1b, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendStack) == 0x138, "Size mismatch for FAnimNode_BlendStack");
static_assert(offsetof(FAnimNode_BlendStack, AnimationAsset) == 0xc0, "Offset mismatch for FAnimNode_BlendStack::AnimationAsset");
static_assert(offsetof(FAnimNode_BlendStack, AnimationTime) == 0xc8, "Offset mismatch for FAnimNode_BlendStack::AnimationTime");
static_assert(offsetof(FAnimNode_BlendStack, ActivationDelayTime) == 0xcc, "Offset mismatch for FAnimNode_BlendStack::ActivationDelayTime");
static_assert(offsetof(FAnimNode_BlendStack, bLoop) == 0xd0, "Offset mismatch for FAnimNode_BlendStack::bLoop");
static_assert(offsetof(FAnimNode_BlendStack, bMirrored) == 0xd1, "Offset mismatch for FAnimNode_BlendStack::bMirrored");
static_assert(offsetof(FAnimNode_BlendStack, WantedPlayRate) == 0xd4, "Offset mismatch for FAnimNode_BlendStack::WantedPlayRate");
static_assert(offsetof(FAnimNode_BlendStack, BlendTime) == 0xd8, "Offset mismatch for FAnimNode_BlendStack::BlendTime");
static_assert(offsetof(FAnimNode_BlendStack, MaxAnimationDeltaTime) == 0xdc, "Offset mismatch for FAnimNode_BlendStack::MaxAnimationDeltaTime");
static_assert(offsetof(FAnimNode_BlendStack, BlendProfile) == 0xe0, "Offset mismatch for FAnimNode_BlendStack::BlendProfile");
static_assert(offsetof(FAnimNode_BlendStack, BlendOption) == 0xe8, "Offset mismatch for FAnimNode_BlendStack::BlendOption");
static_assert(offsetof(FAnimNode_BlendStack, BlendspaceUpdateMode) == 0xe9, "Offset mismatch for FAnimNode_BlendStack::BlendspaceUpdateMode");
static_assert(offsetof(FAnimNode_BlendStack, BlendParameters) == 0xf0, "Offset mismatch for FAnimNode_BlendStack::BlendParameters");
static_assert(offsetof(FAnimNode_BlendStack, MirrorDataTable) == 0x108, "Offset mismatch for FAnimNode_BlendStack::MirrorDataTable");
static_assert(offsetof(FAnimNode_BlendStack, BlendParametersDeltaThreshold) == 0x110, "Offset mismatch for FAnimNode_BlendStack::BlendParametersDeltaThreshold");
static_assert(offsetof(FAnimNode_BlendStack, bUseInertialBlend) == 0x114, "Offset mismatch for FAnimNode_BlendStack::bUseInertialBlend");
static_assert(offsetof(FAnimNode_BlendStack, InertialBlendNodeTag) == 0x118, "Offset mismatch for FAnimNode_BlendStack::InertialBlendNodeTag");
static_assert(offsetof(FAnimNode_BlendStack, bResetOnBecomingRelevant) == 0x11c, "Offset mismatch for FAnimNode_BlendStack::bResetOnBecomingRelevant");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FAnimNode_BlendStackInput : FAnimNode_Base
{
    int32_t SampleIndex; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t BlendStackAllocationIndex; // 0x14 (Size: 0x4, Type: IntProperty)
    bool bOverridePlayRate; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    float PlayRate; // 0x1c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_20[0x8]; // 0x20 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendStackInput) == 0x28, "Size mismatch for FAnimNode_BlendStackInput");
static_assert(offsetof(FAnimNode_BlendStackInput, SampleIndex) == 0x10, "Offset mismatch for FAnimNode_BlendStackInput::SampleIndex");
static_assert(offsetof(FAnimNode_BlendStackInput, BlendStackAllocationIndex) == 0x14, "Offset mismatch for FAnimNode_BlendStackInput::BlendStackAllocationIndex");
static_assert(offsetof(FAnimNode_BlendStackInput, bOverridePlayRate) == 0x18, "Offset mismatch for FAnimNode_BlendStackInput::bOverridePlayRate");
static_assert(offsetof(FAnimNode_BlendStackInput, PlayRate) == 0x1c, "Offset mismatch for FAnimNode_BlendStackInput::PlayRate");

