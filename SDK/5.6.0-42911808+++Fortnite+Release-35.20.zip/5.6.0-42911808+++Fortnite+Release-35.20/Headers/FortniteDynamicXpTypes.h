/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteDynamicXpTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRestedXpUsage
{
    uint8_t RestedXpUsage; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t FixedRestedXpAmount; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRestedXpUsage) == 0x8, "Size mismatch for FRestedXpUsage");
static_assert(offsetof(FRestedXpUsage, RestedXpUsage) == 0x0, "Offset mismatch for FRestedXpUsage::RestedXpUsage");
static_assert(offsetof(FRestedXpUsage, FixedRestedXpAmount) == 0x4, "Offset mismatch for FRestedXpUsage::FixedRestedXpAmount");

