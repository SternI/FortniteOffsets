/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioGameplayVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AudioGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0xd8 (Inherited: 0x268, Single: 0xfffffe70)
class UAttenuationVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    float ExteriorVolume; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ExteriorTime; // 0xcc (Size: 0x4, Type: FloatProperty)
    float InteriorVolume; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float InteriorTime; // 0xd4 (Size: 0x4, Type: FloatProperty)

public:
    void SetExteriorVolume(float& Volume, float& InterpolateTime); // 0xc9a92f0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetInteriorVolume(float& Volume, float& InterpolateTime); // 0xc9a950c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAttenuationVolumeComponent) == 0xd8, "Size mismatch for UAttenuationVolumeComponent");
static_assert(offsetof(UAttenuationVolumeComponent, ExteriorVolume) == 0xc8, "Offset mismatch for UAttenuationVolumeComponent::ExteriorVolume");
static_assert(offsetof(UAttenuationVolumeComponent, ExteriorTime) == 0xcc, "Offset mismatch for UAttenuationVolumeComponent::ExteriorTime");
static_assert(offsetof(UAttenuationVolumeComponent, InteriorVolume) == 0xd0, "Offset mismatch for UAttenuationVolumeComponent::InteriorVolume");
static_assert(offsetof(UAttenuationVolumeComponent, InteriorTime) == 0xd4, "Offset mismatch for UAttenuationVolumeComponent::InteriorTime");

// Size: 0xc8 (Inherited: 0x1a0, Single: 0xffffff28)
class UAudioGameplayVolumeMutator : public UAudioGameplayComponent
{
public:
    int32_t Priority; // 0xc0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)

public:
    void SetPriority(int32_t& InPriority); // 0xc9a9728 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioGameplayVolumeMutator) == 0xc8, "Size mismatch for UAudioGameplayVolumeMutator");
static_assert(offsetof(UAudioGameplayVolumeMutator, Priority) == 0xc0, "Offset mismatch for UAudioGameplayVolumeMutator::Priority");

// Size: 0x310 (Inherited: 0x890, Single: 0xfffffa80)
class AAudioGameplayVolume : public AVolume
{
public:
    UAudioGameplayVolumeComponent* AGVComponent; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    bool bEnabled; // 0x2e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e9[0x7]; // 0x2e9 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnListenerEnterEvent[0x10]; // 0x2f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnListenerExitEvent[0x10]; // 0x300 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void OnListenerEnter(); // 0x530770c (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnListenerExit(); // 0x53076e4 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent)
    void SetEnabled(bool& bEnable); // 0xc9a91b4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_bEnabled(); // 0xc045150 (Index: 0x2, Flags: Native|Protected)
};

static_assert(sizeof(AAudioGameplayVolume) == 0x310, "Size mismatch for AAudioGameplayVolume");
static_assert(offsetof(AAudioGameplayVolume, AGVComponent) == 0x2e0, "Offset mismatch for AAudioGameplayVolume::AGVComponent");
static_assert(offsetof(AAudioGameplayVolume, bEnabled) == 0x2e8, "Offset mismatch for AAudioGameplayVolume::bEnabled");
static_assert(offsetof(AAudioGameplayVolume, OnListenerEnterEvent) == 0x2f0, "Offset mismatch for AAudioGameplayVolume::OnListenerEnterEvent");
static_assert(offsetof(AAudioGameplayVolume, OnListenerExitEvent) == 0x300, "Offset mismatch for AAudioGameplayVolume::OnListenerExitEvent");

// Size: 0xe8 (Inherited: 0x1a0, Single: 0xffffff48)
class UAudioGameplayVolumeComponent : public UAudioGameplayComponent
{
public:
    uint8_t OnProxyEnter[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnProxyExit[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UAudioGameplayVolumeProxy* Proxy; // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAudioGameplayVolumeComponent) == 0xe8, "Size mismatch for UAudioGameplayVolumeComponent");
static_assert(offsetof(UAudioGameplayVolumeComponent, OnProxyEnter) == 0xc0, "Offset mismatch for UAudioGameplayVolumeComponent::OnProxyEnter");
static_assert(offsetof(UAudioGameplayVolumeComponent, OnProxyExit) == 0xd0, "Offset mismatch for UAudioGameplayVolumeComponent::OnProxyExit");
static_assert(offsetof(UAudioGameplayVolumeComponent, Proxy) == 0xe0, "Offset mismatch for UAudioGameplayVolumeComponent::Proxy");

// Size: 0xc8 (Inherited: 0x1a0, Single: 0xffffff28)
class UAudioGameplayVolumeComponentBase : public UAudioGameplayComponent
{
public:
};

static_assert(sizeof(UAudioGameplayVolumeComponentBase) == 0xc8, "Size mismatch for UAudioGameplayVolumeComponentBase");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UAudioGameplayVolumeProxy : public UObject
{
public:
};

static_assert(sizeof(UAudioGameplayVolumeProxy) == 0x48, "Size mismatch for UAudioGameplayVolumeProxy");

// Size: 0x58 (Inherited: 0x70, Single: 0xffffffe8)
class UAGVPrimitiveComponentProxy : public UAudioGameplayVolumeProxy
{
public:
    TArray<UPrimitiveComponent*> Primitives; // 0x48 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAGVPrimitiveComponentProxy) == 0x58, "Size mismatch for UAGVPrimitiveComponentProxy");
static_assert(offsetof(UAGVPrimitiveComponentProxy, Primitives) == 0x48, "Offset mismatch for UAGVPrimitiveComponentProxy::Primitives");

// Size: 0x50 (Inherited: 0x70, Single: 0xffffffe0)
class UAGVConditionProxy : public UAudioGameplayVolumeProxy
{
public:
    UObject* ObjectPtr; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAGVConditionProxy) == 0x50, "Size mismatch for UAGVConditionProxy");
static_assert(offsetof(UAGVConditionProxy, ObjectPtr) == 0x48, "Offset mismatch for UAGVConditionProxy::ObjectPtr");

// Size: 0x168 (Inherited: 0xb8, Single: 0xb0)
class UAudioGameplayVolumeSubsystem : public UAudioEngineSubsystem
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    TArray<UAudioGameplayVolumeProxy*> TransientProxyList; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TMap<UAudioGameplayVolumeComponent*, uint32_t> AGVComponents; // 0x48 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_98[0xd0]; // 0x98 (Size: 0xd0, Type: PaddingProperty)
};

static_assert(sizeof(UAudioGameplayVolumeSubsystem) == 0x168, "Size mismatch for UAudioGameplayVolumeSubsystem");
static_assert(offsetof(UAudioGameplayVolumeSubsystem, TransientProxyList) == 0x38, "Offset mismatch for UAudioGameplayVolumeSubsystem::TransientProxyList");
static_assert(offsetof(UAudioGameplayVolumeSubsystem, AGVComponents) == 0x48, "Offset mismatch for UAudioGameplayVolumeSubsystem::AGVComponents");

// Size: 0xd8 (Inherited: 0x268, Single: 0xfffffe70)
class UFilterVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    float ExteriorLPF; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ExteriorLPFTime; // 0xcc (Size: 0x4, Type: FloatProperty)
    float InteriorLPF; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float InteriorLPFTime; // 0xd4 (Size: 0x4, Type: FloatProperty)

public:
    void SetExteriorLPF(float& Volume, float& InterpolateTime); // 0xc9a92f0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetInteriorLPF(float& Volume, float& InterpolateTime); // 0xc9a950c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFilterVolumeComponent) == 0xd8, "Size mismatch for UFilterVolumeComponent");
static_assert(offsetof(UFilterVolumeComponent, ExteriorLPF) == 0xc8, "Offset mismatch for UFilterVolumeComponent::ExteriorLPF");
static_assert(offsetof(UFilterVolumeComponent, ExteriorLPFTime) == 0xcc, "Offset mismatch for UFilterVolumeComponent::ExteriorLPFTime");
static_assert(offsetof(UFilterVolumeComponent, InteriorLPF) == 0xd0, "Offset mismatch for UFilterVolumeComponent::InteriorLPF");
static_assert(offsetof(UFilterVolumeComponent, InteriorLPFTime) == 0xd4, "Offset mismatch for UFilterVolumeComponent::InteriorLPFTime");

// Size: 0xe8 (Inherited: 0x268, Single: 0xfffffe80)
class UReverbVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    FReverbSettings ReverbSettings; // 0xc8 (Size: 0x20, Type: StructProperty)

public:
    void SetReverbSettings(const FReverbSettings NewReverbSettings); // 0xc9a9860 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UReverbVolumeComponent) == 0xe8, "Size mismatch for UReverbVolumeComponent");
static_assert(offsetof(UReverbVolumeComponent, ReverbSettings) == 0xc8, "Offset mismatch for UReverbVolumeComponent::ReverbSettings");

// Size: 0xd8 (Inherited: 0x268, Single: 0xfffffe70)
class USubmixOverrideVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    TArray<FAudioVolumeSubmixOverrideSettings> SubmixOverrideSettings; // 0xc8 (Size: 0x10, Type: ArrayProperty)

public:
    void SetSubmixOverrideSettings(const TArray<FAudioVolumeSubmixOverrideSettings> NewSubmixOverrideSettings); // 0xc9a9950 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USubmixOverrideVolumeComponent) == 0xd8, "Size mismatch for USubmixOverrideVolumeComponent");
static_assert(offsetof(USubmixOverrideVolumeComponent, SubmixOverrideSettings) == 0xc8, "Offset mismatch for USubmixOverrideVolumeComponent::SubmixOverrideSettings");

// Size: 0xd8 (Inherited: 0x268, Single: 0xfffffe70)
class USubmixSendVolumeComponent : public UAudioGameplayVolumeMutator
{
public:
    TArray<FAudioVolumeSubmixSendSettings> SubmixSendSettings; // 0xc8 (Size: 0x10, Type: ArrayProperty)

public:
    void SetSubmixSendSettings(const TArray<FAudioVolumeSubmixSendSettings> NewSubmixSendSettings); // 0xc9a9a2c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USubmixSendVolumeComponent) == 0xd8, "Size mismatch for USubmixSendVolumeComponent");
static_assert(offsetof(USubmixSendVolumeComponent, SubmixSendSettings) == 0xc8, "Offset mismatch for USubmixSendVolumeComponent::SubmixSendSettings");

