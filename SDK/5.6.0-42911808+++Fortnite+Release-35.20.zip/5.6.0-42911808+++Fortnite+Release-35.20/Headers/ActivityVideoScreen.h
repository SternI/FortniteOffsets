/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityVideoScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"
#include "FortniteUI.h"
#include "UI.h"
#include "Engine.h"
#include "UMG.h"
#include "UIKit.h"

// Size: 0x428 (Inherited: 0xb38, Single: 0xfffff8f0)
class UActivityVideoScreen_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    USafeZone* SafeZone_SkipButton; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_Skip; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UActivityVideoCycleWidget_C* ActivityVideoCycleWidget; // 0x420 (Size: 0x8, Type: ObjectProperty)

public:
    void StopVideo(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PlayVideo(UFortActivityViewModel*& ActivityViewModel); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UActivityVideoScreen_C) == 0x428, "Size mismatch for UActivityVideoScreen_C");
static_assert(offsetof(UActivityVideoScreen_C, UberGraphFrame) == 0x408, "Offset mismatch for UActivityVideoScreen_C::UberGraphFrame");
static_assert(offsetof(UActivityVideoScreen_C, SafeZone_SkipButton) == 0x410, "Offset mismatch for UActivityVideoScreen_C::SafeZone_SkipButton");
static_assert(offsetof(UActivityVideoScreen_C, Button_Skip) == 0x418, "Offset mismatch for UActivityVideoScreen_C::Button_Skip");
static_assert(offsetof(UActivityVideoScreen_C, ActivityVideoCycleWidget) == 0x420, "Offset mismatch for UActivityVideoScreen_C::ActivityVideoCycleWidget");

