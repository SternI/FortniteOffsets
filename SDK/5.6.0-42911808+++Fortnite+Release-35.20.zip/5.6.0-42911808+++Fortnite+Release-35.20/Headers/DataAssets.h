/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataAssets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UPDA_RankConfig_C : public UPrimaryDataAsset
{
public:
    TMap<TSoftObjectPtr<UTexture2D*>, int32_t> RankIcons; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UPDA_RankConfig_C) == 0x80, "Size mismatch for UPDA_RankConfig_C");
static_assert(offsetof(UPDA_RankConfig_C, RankIcons) == 0x30, "Offset mismatch for UPDA_RankConfig_C::RankIcons");

