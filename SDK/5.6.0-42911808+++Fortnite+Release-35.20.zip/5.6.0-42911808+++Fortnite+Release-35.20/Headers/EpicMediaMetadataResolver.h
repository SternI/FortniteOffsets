/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaMetadataResolver
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "EpicMediaOptions.h"
#include "EpicMediaCDNHostnames.h"

// Size: 0x198 (Inherited: 0x28, Single: 0x170)
class UEpicMediaMetadataResolver : public UObject
{
public:
    uint8_t MetadataResultExt[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UEpicMediaCDNHostnames* CDNHostNames; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x158]; // 0x40 (Size: 0x158, Type: PaddingProperty)

public:
    bool GetBlurl(FString& InVUID, bool& const bInBlurlLive, FEpicMediaOptions& const InMediaOptions); // 0xc59ccb0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool GetData(FString& UID, bool& const bLive, FEpicMediaOptions& const InMediaOptions); // 0xc59d140 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UEpicMediaMetadataResolver) == 0x198, "Size mismatch for UEpicMediaMetadataResolver");
static_assert(offsetof(UEpicMediaMetadataResolver, MetadataResultExt) == 0x28, "Offset mismatch for UEpicMediaMetadataResolver::MetadataResultExt");
static_assert(offsetof(UEpicMediaMetadataResolver, CDNHostNames) == 0x38, "Offset mismatch for UEpicMediaMetadataResolver::CDNHostNames");

