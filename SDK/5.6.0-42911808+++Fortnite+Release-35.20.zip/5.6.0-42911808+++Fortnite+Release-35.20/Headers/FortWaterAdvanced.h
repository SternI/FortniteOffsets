/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortWaterAdvanced
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "WaterAdvanced.h"
#include "GameFeatures.h"

// Size: 0x268 (Inherited: 0x330, Single: 0xffffff38)
class UFortShallowWaterSubsystem : public UShallowWaterSubsystem
{
public:
};

static_assert(sizeof(UFortShallowWaterSubsystem) == 0x268, "Size mismatch for UFortShallowWaterSubsystem");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UFortGameFeatureAction_InitPhysicsOverrides : public UGameFeatureAction
{
public:
    TSoftObjectPtr<UShallowWaterPhysicsAssetOverridesDataAsset*> PhysicsAssetOverrides; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UFortGameFeatureAction_InitPhysicsOverrides) == 0x48, "Size mismatch for UFortGameFeatureAction_InitPhysicsOverrides");
static_assert(offsetof(UFortGameFeatureAction_InitPhysicsOverrides, PhysicsAssetOverrides) == 0x28, "Offset mismatch for UFortGameFeatureAction_InitPhysicsOverrides::PhysicsAssetOverrides");

