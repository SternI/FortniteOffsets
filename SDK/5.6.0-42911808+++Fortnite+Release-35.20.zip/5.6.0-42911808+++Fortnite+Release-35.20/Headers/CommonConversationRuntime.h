/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonConversationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "DeveloperSettings.h"
#include "GameplayTags.h"

// Size: 0x90 (Inherited: 0xd8, Single: 0xffffffb8)
class UConversationChoiceNode : public UConversationSubNode
{
public:
    FText DefaultChoiceDisplayText; // 0x58 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer ChoiceTags; // 0x68 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void FillChoice(const FConversationContext Context, FClientConversationOptionEntry& ChoiceEntry) const; // 0xc17b37c (Index: 0x0, Flags: Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UConversationChoiceNode) == 0x90, "Size mismatch for UConversationChoiceNode");
static_assert(offsetof(UConversationChoiceNode, DefaultChoiceDisplayText) == 0x58, "Offset mismatch for UConversationChoiceNode::DefaultChoiceDisplayText");
static_assert(offsetof(UConversationChoiceNode, ChoiceTags) == 0x68, "Offset mismatch for UConversationChoiceNode::ChoiceTags");

// Size: 0x58 (Inherited: 0x80, Single: 0xffffffd8)
class UConversationSubNode : public UConversationNode
{
public:
};

static_assert(sizeof(UConversationSubNode) == 0x58, "Size mismatch for UConversationSubNode");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UConversationNode : public UObject
{
public:
    UObject* EvalWorldContextObj; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FString NodeName; // 0x30 (Size: 0x10, Type: StrProperty)
    FGuid Compiled_NodeGUID; // 0x40 (Size: 0x10, Type: StructProperty)
    UConversationNode* ParentNode; // 0x50 (Size: 0x8, Type: ObjectProperty)

protected:
    FLinearColor GetDebugParticipantColor(FGameplayTag& ParticipantID) const; // 0xc17c568 (Index: 0x0, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UConversationNode) == 0x58, "Size mismatch for UConversationNode");
static_assert(offsetof(UConversationNode, EvalWorldContextObj) == 0x28, "Offset mismatch for UConversationNode::EvalWorldContextObj");
static_assert(offsetof(UConversationNode, NodeName) == 0x30, "Offset mismatch for UConversationNode::NodeName");
static_assert(offsetof(UConversationNode, Compiled_NodeGUID) == 0x40, "Offset mismatch for UConversationNode::Compiled_NodeGUID");
static_assert(offsetof(UConversationNode, ParentNode) == 0x50, "Offset mismatch for UConversationNode::ParentNode");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UConversationContextHelpers : public UBlueprintFunctionLibrary
{
public:

public:
    static FConversationTaskResult AbortConversation(const FConversationContext Context); // 0xc179958 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationTaskResult AdvanceConversation(const FConversationContext Context); // 0xc179958 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationTaskResult AdvanceConversationWithChoice(const FConversationContext Context, const FAdvanceConversationRequest Choice); // 0xc179bcc (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool CanConversationContinue(const FConversationTaskResult ConversationTasResult); // 0xc179ee0 (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UConversationParticipantComponent* FindConversationComponent(AActor*& Actor); // 0xc17b684 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UConversationInstance* GetConversationInstance(const FConversationContext Context); // 0xc17bab8 (Index: 0x5, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UConversationParticipantComponent* GetConversationParticipant(const FConversationContext Context, FGameplayTag& ParticipantTag); // 0xc17bd1c (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static AActor* GetConversationParticipantActor(const FConversationContext Context, FGameplayTag& ParticipantTag); // 0xc17c004 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationNodeHandle GetCurrentConversationNodeHandle(const FConversationContext Context); // 0xc17c2e8 (Index: 0x8, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void MakeConversationParticipant(const FConversationContext Context, AActor*& ParticipantActor, FGameplayTag& ParticipantTag); // 0xc17cda8 (Index: 0x9, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationTaskResult PauseConversationAndSendClientChoices(const FConversationContext Context, const FClientConversationMessage Message); // 0xc17d1e8 (Index: 0xa, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationTaskResult ReturnToConversationStart(const FConversationContext Context); // 0xc179958 (Index: 0xb, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationTaskResult ReturnToCurrentClientChoice(const FConversationContext Context); // 0xc179958 (Index: 0xc, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FConversationTaskResult ReturnToLastClientChoice(const FConversationContext Context); // 0xc179958 (Index: 0xd, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UConversationContextHelpers) == 0x28, "Size mismatch for UConversationContextHelpers");

// Size: 0xe8 (Inherited: 0x88, Single: 0x60)
class UConversationDatabase : public UPrimaryDataAsset
{
public:
    int32_t CompilerVersion; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TMap<UConversationNode*, FGuid> ReachableNodeMap; // 0x38 (Size: 0x50, Type: MapProperty)
    TArray<FConversationEntryList> EntryTags; // 0x88 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ExitTags; // 0x98 (Size: 0x20, Type: StructProperty)
    TArray<FGuid> InternalNodeIds; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FGuid> LinkedToNodeIds; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCommonDialogueBankParticipant> Speakers; // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UConversationDatabase) == 0xe8, "Size mismatch for UConversationDatabase");
static_assert(offsetof(UConversationDatabase, CompilerVersion) == 0x30, "Offset mismatch for UConversationDatabase::CompilerVersion");
static_assert(offsetof(UConversationDatabase, ReachableNodeMap) == 0x38, "Offset mismatch for UConversationDatabase::ReachableNodeMap");
static_assert(offsetof(UConversationDatabase, EntryTags) == 0x88, "Offset mismatch for UConversationDatabase::EntryTags");
static_assert(offsetof(UConversationDatabase, ExitTags) == 0x98, "Offset mismatch for UConversationDatabase::ExitTags");
static_assert(offsetof(UConversationDatabase, InternalNodeIds) == 0xb8, "Offset mismatch for UConversationDatabase::InternalNodeIds");
static_assert(offsetof(UConversationDatabase, LinkedToNodeIds) == 0xc8, "Offset mismatch for UConversationDatabase::LinkedToNodeIds");
static_assert(offsetof(UConversationDatabase, Speakers) == 0xd8, "Offset mismatch for UConversationDatabase::Speakers");

// Size: 0x70 (Inherited: 0xe8, Single: 0xffffff88)
class UConversationEntryPointNode : public UConversationNodeWithLinks
{
public:
    FGameplayTag EntryTag; // 0x68 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)

public:
    FString GetIdentifier() const; // 0xc17c644 (Index: 0x0, Flags: Native|Public|Const)
};

static_assert(sizeof(UConversationEntryPointNode) == 0x70, "Size mismatch for UConversationEntryPointNode");
static_assert(offsetof(UConversationEntryPointNode, EntryTag) == 0x68, "Offset mismatch for UConversationEntryPointNode::EntryTag");

// Size: 0x68 (Inherited: 0x80, Single: 0xffffffe8)
class UConversationNodeWithLinks : public UConversationNode
{
public:
    TArray<FGuid> OutputConnections; // 0x58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UConversationNodeWithLinks) == 0x68, "Size mismatch for UConversationNodeWithLinks");
static_assert(offsetof(UConversationNodeWithLinks, OutputConnections) == 0x58, "Offset mismatch for UConversationNodeWithLinks::OutputConnections");

// Size: 0x1a0 (Inherited: 0x28, Single: 0x178)
class UConversationInstance : public UObject
{
public:
    uint8_t Pad_28[0x28]; // 0x28 (Size: 0x28, Type: PaddingProperty)
    FConversationParticipants Participants; // 0x50 (Size: 0x10, Type: StructProperty)
    UConversationDatabase* ActiveConversationGraph; // 0x60 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_68[0x138]; // 0x68 (Size: 0x138, Type: PaddingProperty)
};

static_assert(sizeof(UConversationInstance) == 0x1a0, "Size mismatch for UConversationInstance");
static_assert(offsetof(UConversationInstance, Participants) == 0x50, "Offset mismatch for UConversationInstance::Participants");
static_assert(offsetof(UConversationInstance, ActiveConversationGraph) == 0x60, "Offset mismatch for UConversationInstance::ActiveConversationGraph");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UConversationLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UConversationInstance* StartConversation(const FGameplayTag ConversationEntryTag, AActor*& Instigator, const FGameplayTag InstigatorTag, AActor*& Target, const FGameplayTag TargetTag, UClass*& const ConversationInstanceClass); // 0xc17d97c (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UConversationInstance* StartConversationFromGraph(const FGameplayTag ConversationEntryTag, AActor*& Instigator, const FGameplayTag InstigatorTag, AActor*& Target, const FGameplayTag TargetTag, UConversationDatabase*& const Graph, FString& EntryPointIdentifier); // 0xc17de6c (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UConversationLibrary) == 0x28, "Size mismatch for UConversationLibrary");

// Size: 0x88 (Inherited: 0x168, Single: 0xffffff20)
class UConversationLinkNode : public UConversationTaskNode
{
public:
    FGameplayTag RemoteEntryTag; // 0x80 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UConversationLinkNode) == 0x88, "Size mismatch for UConversationLinkNode");
static_assert(offsetof(UConversationLinkNode, RemoteEntryTag) == 0x80, "Offset mismatch for UConversationLinkNode::RemoteEntryTag");

// Size: 0x80 (Inherited: 0xe8, Single: 0xffffff98)
class UConversationTaskNode : public UConversationNodeWithLinks
{
public:
    TArray<UConversationSubNode*> SubNodes; // 0x68 (Size: 0x10, Type: ArrayProperty)
    bool bIgnoreRequirementsWhileAdvancingConversations; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)

public:
    virtual bool GetNodeBodyColor(FLinearColor& BodyColor) const; // 0xc17c688 (Index: 0x3, Flags: Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const)

protected:
    virtual void ExecuteClientEffects(const FConversationContext Context) const; // 0xc17ae90 (Index: 0x0, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual FConversationTaskResult ExecuteTaskNode(const FConversationContext Context) const; // 0xc17b0f8 (Index: 0x1, Flags: BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual void GatherStaticExtraData(const FConversationContext Context, TArray<FConversationNodeParameterPair>& InOutExtraData) const; // 0xc17b7b8 (Index: 0x2, Flags: BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual EConversationRequirementResult IsRequirementSatisfied(const FConversationContext Context) const; // 0xc17cb3c (Index: 0x4, Flags: BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UConversationTaskNode) == 0x80, "Size mismatch for UConversationTaskNode");
static_assert(offsetof(UConversationTaskNode, SubNodes) == 0x68, "Offset mismatch for UConversationTaskNode::SubNodes");
static_assert(offsetof(UConversationTaskNode, bIgnoreRequirementsWhileAdvancingConversations) == 0x78, "Offset mismatch for UConversationTaskNode::bIgnoreRequirementsWhileAdvancingConversations");

// Size: 0x1a8 (Inherited: 0xe0, Single: 0xc8)
class UConversationParticipantComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x60]; // 0xb8 (Size: 0x60, Type: PaddingProperty)
    int32_t ConversationsActive; // 0x118 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_11c[0x4]; // 0x11c (Size: 0x4, Type: PaddingProperty)
    UConversationInstance* Auth_CurrentConversation; // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<UConversationInstance*> Auth_Conversations; // 0x128 (Size: 0x10, Type: ArrayProperty)
    FClientConversationMessagePayload LastMessage; // 0x138 (Size: 0x68, Type: StructProperty)
    uint8_t Pad_1a0[0x8]; // 0x1a0 (Size: 0x8, Type: PaddingProperty)

public:
    AActor* GetParticipantActor(const FGameplayTag ParticipantTag) const; // 0xc17c77c (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FText GetParticipantDisplayName(); // 0xc17c870 (Index: 0x8, Flags: Native|Public|BlueprintCallable)
    bool IsInActiveConversation() const; // 0xc17c8b0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RequestServerAdvanceConversation(const FAdvanceConversationRequest InChoicePicked); // 0xc17d4e8 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void ClientExecuteTaskAndSideEffects(FConversationNodeHandle& Handle, UConversationDatabase*& const Graph); // 0xc17a230 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientExitConversation(FConversationParticipants& const InParticipants); // 0xc17a384 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientStartConversation(FConversationParticipants& const InParticipants); // 0xc17a608 (Index: 0x2, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientUpdateConversation(FClientConversationMessagePayload& const Message); // 0xc17a88c (Index: 0x3, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientUpdateConversations(int32_t& InConversationsActive); // 0xc17aae0 (Index: 0x4, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientUpdateConversationTaskChoiceData(FConversationNodeHandle& Handle, FClientConversationOptionEntry& const OptionEntry); // 0xc17a96c (Index: 0x5, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientUpdateParticipants(FConversationParticipants& const InParticipants); // 0xc17ac0c (Index: 0x6, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    void OnRep_ConversationsActive(int32_t& OldConversationsActive); // 0xc17d0c0 (Index: 0xa, Flags: Final|Native|Protected)
    virtual void ServerAdvanceConversation(FAdvanceConversationRequest& const InChoicePicked); // 0xc17d628 (Index: 0xc, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(UConversationParticipantComponent) == 0x1a8, "Size mismatch for UConversationParticipantComponent");
static_assert(offsetof(UConversationParticipantComponent, ConversationsActive) == 0x118, "Offset mismatch for UConversationParticipantComponent::ConversationsActive");
static_assert(offsetof(UConversationParticipantComponent, Auth_CurrentConversation) == 0x120, "Offset mismatch for UConversationParticipantComponent::Auth_CurrentConversation");
static_assert(offsetof(UConversationParticipantComponent, Auth_Conversations) == 0x128, "Offset mismatch for UConversationParticipantComponent::Auth_Conversations");
static_assert(offsetof(UConversationParticipantComponent, LastMessage) == 0x138, "Offset mismatch for UConversationParticipantComponent::LastMessage");

// Size: 0x1f8 (Inherited: 0x88, Single: 0x170)
class UConversationRegistry : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FNetSerializeScriptStructCache_ConvVersion ConversationChoiceDataStructCache; // 0x38 (Size: 0x60, Type: StructProperty)
    uint8_t Pad_98[0x160]; // 0x98 (Size: 0x160, Type: PaddingProperty)
};

static_assert(sizeof(UConversationRegistry) == 0x1f8, "Size mismatch for UConversationRegistry");
static_assert(offsetof(UConversationRegistry, ConversationChoiceDataStructCache) == 0x38, "Offset mismatch for UConversationRegistry::ConversationChoiceDataStructCache");

// Size: 0x58 (Inherited: 0xd8, Single: 0xffffff80)
class UConversationRequirementNode : public UConversationSubNode
{
public:

public:
    virtual EConversationRequirementResult IsRequirementSatisfied(const FConversationContext Context) const; // 0xc17c8d0 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UConversationRequirementNode) == 0x58, "Size mismatch for UConversationRequirementNode");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UConversationSettings : public UDeveloperSettings
{
public:
    TSoftClassPtr ConversationInstanceClass; // 0x30 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UConversationSettings) == 0x50, "Size mismatch for UConversationSettings");
static_assert(offsetof(UConversationSettings, ConversationInstanceClass) == 0x30, "Offset mismatch for UConversationSettings::ConversationInstanceClass");

// Size: 0x58 (Inherited: 0xd8, Single: 0xffffff80)
class UConversationSideEffectNode : public UConversationSubNode
{
public:

protected:
    virtual void ClientCauseSideEffect(const FConversationContext Context) const; // 0xc179fc8 (Index: 0x0, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
    virtual void ServerCauseSideEffect(const FConversationContext Context) const; // 0xc17d714 (Index: 0x1, Flags: BlueprintAuthorityOnly|Native|Event|Protected|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UConversationSideEffectNode) == 0x58, "Size mismatch for UConversationSideEffectNode");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FClientConversationMessagePayload
{
    FClientConversationMessage Message; // 0x0 (Size: 0x38, Type: StructProperty)
    FConversationParticipants Participants; // 0x38 (Size: 0x10, Type: StructProperty)
    FConversationNodeHandle CurrentNode; // 0x48 (Size: 0x10, Type: StructProperty)
    TArray<FClientConversationOptionEntry> Options; // 0x58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClientConversationMessagePayload) == 0x68, "Size mismatch for FClientConversationMessagePayload");
static_assert(offsetof(FClientConversationMessagePayload, Message) == 0x0, "Offset mismatch for FClientConversationMessagePayload::Message");
static_assert(offsetof(FClientConversationMessagePayload, Participants) == 0x38, "Offset mismatch for FClientConversationMessagePayload::Participants");
static_assert(offsetof(FClientConversationMessagePayload, CurrentNode) == 0x48, "Offset mismatch for FClientConversationMessagePayload::CurrentNode");
static_assert(offsetof(FClientConversationMessagePayload, Options) == 0x58, "Offset mismatch for FClientConversationMessagePayload::Options");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FClientConversationOptionEntry
{
    FText ChoiceText; // 0x0 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer ChoiceTags; // 0x10 (Size: 0x20, Type: StructProperty)
    uint8_t ChoiceType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FConversationChoiceReference ChoiceReference; // 0x38 (Size: 0x20, Type: StructProperty)
    TArray<FConversationNodeParameterPair> ExtraData; // 0x58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClientConversationOptionEntry) == 0x68, "Size mismatch for FClientConversationOptionEntry");
static_assert(offsetof(FClientConversationOptionEntry, ChoiceText) == 0x0, "Offset mismatch for FClientConversationOptionEntry::ChoiceText");
static_assert(offsetof(FClientConversationOptionEntry, ChoiceTags) == 0x10, "Offset mismatch for FClientConversationOptionEntry::ChoiceTags");
static_assert(offsetof(FClientConversationOptionEntry, ChoiceType) == 0x30, "Offset mismatch for FClientConversationOptionEntry::ChoiceType");
static_assert(offsetof(FClientConversationOptionEntry, ChoiceReference) == 0x38, "Offset mismatch for FClientConversationOptionEntry::ChoiceReference");
static_assert(offsetof(FClientConversationOptionEntry, ExtraData) == 0x58, "Offset mismatch for FClientConversationOptionEntry::ExtraData");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FConversationNodeParameterPair
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FConversationNodeParameterPair) == 0x20, "Size mismatch for FConversationNodeParameterPair");
static_assert(offsetof(FConversationNodeParameterPair, Name) == 0x0, "Offset mismatch for FConversationNodeParameterPair::Name");
static_assert(offsetof(FConversationNodeParameterPair, Value) == 0x10, "Offset mismatch for FConversationNodeParameterPair::Value");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FConversationChoiceReference
{
    FConversationNodeHandle NodeReference; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FConversationNodeParameterPair> NodeParameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FConversationChoiceReference) == 0x20, "Size mismatch for FConversationChoiceReference");
static_assert(offsetof(FConversationChoiceReference, NodeReference) == 0x0, "Offset mismatch for FConversationChoiceReference::NodeReference");
static_assert(offsetof(FConversationChoiceReference, NodeParameters) == 0x10, "Offset mismatch for FConversationChoiceReference::NodeParameters");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FConversationNodeHandle
{
    FGuid NodeGUID; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConversationNodeHandle) == 0x10, "Size mismatch for FConversationNodeHandle");
static_assert(offsetof(FConversationNodeHandle, NodeGUID) == 0x0, "Offset mismatch for FConversationNodeHandle::NodeGUID");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FConversationParticipants
{
    TArray<FConversationParticipantEntry> List; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FConversationParticipants) == 0x10, "Size mismatch for FConversationParticipants");
static_assert(offsetof(FConversationParticipants, List) == 0x0, "Offset mismatch for FConversationParticipants::List");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FConversationParticipantEntry
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag ParticipantID; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FConversationParticipantEntry) == 0x10, "Size mismatch for FConversationParticipantEntry");
static_assert(offsetof(FConversationParticipantEntry, Actor) == 0x0, "Offset mismatch for FConversationParticipantEntry::Actor");
static_assert(offsetof(FConversationParticipantEntry, ParticipantID) == 0x8, "Offset mismatch for FConversationParticipantEntry::ParticipantID");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FClientConversationMessage
{
    FGameplayTag SpeakerID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FText ParticipantDisplayName; // 0x8 (Size: 0x10, Type: TextProperty)
    FText Text; // 0x18 (Size: 0x10, Type: TextProperty)
    TArray<FConversationNodeParameterPair> MetadataParameters; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClientConversationMessage) == 0x38, "Size mismatch for FClientConversationMessage");
static_assert(offsetof(FClientConversationMessage, SpeakerID) == 0x0, "Offset mismatch for FClientConversationMessage::SpeakerID");
static_assert(offsetof(FClientConversationMessage, ParticipantDisplayName) == 0x8, "Offset mismatch for FClientConversationMessage::ParticipantDisplayName");
static_assert(offsetof(FClientConversationMessage, Text) == 0x18, "Offset mismatch for FClientConversationMessage::Text");
static_assert(offsetof(FClientConversationMessage, MetadataParameters) == 0x28, "Offset mismatch for FClientConversationMessage::MetadataParameters");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FConversationTaskResult
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FAdvanceConversationRequest AdvanceToChoice; // 0x8 (Size: 0x30, Type: StructProperty)
    FClientConversationMessage Message; // 0x38 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FConversationTaskResult) == 0x70, "Size mismatch for FConversationTaskResult");
static_assert(offsetof(FConversationTaskResult, Type) == 0x0, "Offset mismatch for FConversationTaskResult::Type");
static_assert(offsetof(FConversationTaskResult, AdvanceToChoice) == 0x8, "Offset mismatch for FConversationTaskResult::AdvanceToChoice");
static_assert(offsetof(FConversationTaskResult, Message) == 0x38, "Offset mismatch for FConversationTaskResult::Message");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAdvanceConversationRequest
{
    FConversationChoiceReference Choice; // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<FConversationNodeParameterPair> UserParameters; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAdvanceConversationRequest) == 0x30, "Size mismatch for FAdvanceConversationRequest");
static_assert(offsetof(FAdvanceConversationRequest, Choice) == 0x0, "Offset mismatch for FAdvanceConversationRequest::Choice");
static_assert(offsetof(FAdvanceConversationRequest, UserParameters) == 0x20, "Offset mismatch for FAdvanceConversationRequest::UserParameters");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FConversationContext
{
    UConversationRegistry* ConversationRegistry; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UConversationInstance* ActiveConversation; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UConversationParticipantComponent* ClientParticipant; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UConversationTaskNode* TaskBeingConsidered; // 0x18 (Size: 0x8, Type: ObjectProperty)
    TArray<FConversationNodeHandle> ReturnScopeStack; // 0x20 (Size: 0x10, Type: ArrayProperty)
    bool bServer_PRIVATE; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bClient_PRIVATE; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FConversationContext) == 0x38, "Size mismatch for FConversationContext");
static_assert(offsetof(FConversationContext, ConversationRegistry) == 0x0, "Offset mismatch for FConversationContext::ConversationRegistry");
static_assert(offsetof(FConversationContext, ActiveConversation) == 0x8, "Offset mismatch for FConversationContext::ActiveConversation");
static_assert(offsetof(FConversationContext, ClientParticipant) == 0x10, "Offset mismatch for FConversationContext::ClientParticipant");
static_assert(offsetof(FConversationContext, TaskBeingConsidered) == 0x18, "Offset mismatch for FConversationContext::TaskBeingConsidered");
static_assert(offsetof(FConversationContext, ReturnScopeStack) == 0x20, "Offset mismatch for FConversationContext::ReturnScopeStack");
static_assert(offsetof(FConversationContext, bServer_PRIVATE) == 0x30, "Offset mismatch for FConversationContext::bServer_PRIVATE");
static_assert(offsetof(FConversationContext, bClient_PRIVATE) == 0x31, "Offset mismatch for FConversationContext::bClient_PRIVATE");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FConversationEntryList
{
    FGameplayTag EntryTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FGuid> DestinationList; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FString EntryIdentifier; // 0x18 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FConversationEntryList) == 0x28, "Size mismatch for FConversationEntryList");
static_assert(offsetof(FConversationEntryList, EntryTag) == 0x0, "Offset mismatch for FConversationEntryList::EntryTag");
static_assert(offsetof(FConversationEntryList, DestinationList) == 0x8, "Offset mismatch for FConversationEntryList::DestinationList");
static_assert(offsetof(FConversationEntryList, EntryIdentifier) == 0x18, "Offset mismatch for FConversationEntryList::EntryIdentifier");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCommonDialogueBankParticipant
{
    FText FallbackName; // 0x0 (Size: 0x10, Type: TextProperty)
    FGameplayTag ParticipantName; // 0x10 (Size: 0x4, Type: StructProperty)
    FLinearColor NodeTint; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCommonDialogueBankParticipant) == 0x28, "Size mismatch for FCommonDialogueBankParticipant");
static_assert(offsetof(FCommonDialogueBankParticipant, FallbackName) == 0x0, "Offset mismatch for FCommonDialogueBankParticipant::FallbackName");
static_assert(offsetof(FCommonDialogueBankParticipant, ParticipantName) == 0x10, "Offset mismatch for FCommonDialogueBankParticipant::ParticipantName");
static_assert(offsetof(FCommonDialogueBankParticipant, NodeTint) == 0x14, "Offset mismatch for FCommonDialogueBankParticipant::NodeTint");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FNetSerializeScriptStructCache_ConvVersion
{
    TMap<int32_t, UScriptStruct*> ScriptStructsToIndex; // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<UScriptStruct*> IndexToScriptStructs; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FNetSerializeScriptStructCache_ConvVersion) == 0x60, "Size mismatch for FNetSerializeScriptStructCache_ConvVersion");
static_assert(offsetof(FNetSerializeScriptStructCache_ConvVersion, ScriptStructsToIndex) == 0x0, "Offset mismatch for FNetSerializeScriptStructCache_ConvVersion::ScriptStructsToIndex");
static_assert(offsetof(FNetSerializeScriptStructCache_ConvVersion, IndexToScriptStructs) == 0x50, "Offset mismatch for FNetSerializeScriptStructCache_ConvVersion::IndexToScriptStructs");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FConversationChoiceData
{
};

static_assert(sizeof(FConversationChoiceData) == 0x8, "Size mismatch for FConversationChoiceData");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FConversationChoiceDataHandle
{
};

static_assert(sizeof(FConversationChoiceDataHandle) == 0x20, "Size mismatch for FConversationChoiceDataHandle");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FConversationBranchPoint
{
    TArray<FConversationNodeHandle> ReturnScopeStack; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FClientConversationOptionEntry ClientChoice; // 0x10 (Size: 0x68, Type: StructProperty)
};

static_assert(sizeof(FConversationBranchPoint) == 0x78, "Size mismatch for FConversationBranchPoint");
static_assert(offsetof(FConversationBranchPoint, ReturnScopeStack) == 0x0, "Offset mismatch for FConversationBranchPoint::ReturnScopeStack");
static_assert(offsetof(FConversationBranchPoint, ClientChoice) == 0x10, "Offset mismatch for FConversationBranchPoint::ClientChoice");

