/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommChannelsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FCommChannelNode
{
};

static_assert(sizeof(FCommChannelNode) == 0x68, "Size mismatch for FCommChannelNode");

