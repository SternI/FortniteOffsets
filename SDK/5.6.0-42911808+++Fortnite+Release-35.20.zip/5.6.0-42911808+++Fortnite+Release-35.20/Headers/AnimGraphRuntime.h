/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimGraphRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimationCore.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimNodeRigidBodyLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FRigidBodyAnimNodeReference ConvertToRigidBodyAnimNode(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f6ca6c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToRigidBodyAnimNodePure(const FAnimNodeReference Node, FRigidBodyAnimNodeReference& RigidBodyAnimNode, bool& Result); // 0x9f6cc28 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FRigidBodyAnimNodeReference SetOverridePhysicsAsset(const FRigidBodyAnimNodeReference Node, UPhysicsAsset*& PhysicsAsset); // 0x9f6dffc (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnimNodeRigidBodyLibrary) == 0x28, "Size mismatch for UAnimNodeRigidBodyLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlendSpaceLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FBlendSpaceReference ConvertToBlendSpace(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f6c150 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToBlendSpacePure(const FAnimNodeReference Node, FBlendSpaceReference& BlendSpace, bool& Result); // 0x9f6c30c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetFilteredPosition(const FBlendSpaceReference BlendSpace); // 0x9f6d53c (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetPosition(const FBlendSpaceReference BlendSpace); // 0x9f6d668 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static void SnapToPosition(const FBlendSpaceReference BlendSpace, FVector& NewPosition); // 0x9f6e5d4 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UBlendSpaceLibrary) == 0x28, "Size mismatch for UBlendSpaceLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class USequencerAnimationOverride : public UInterface
{
public:

public:
    virtual bool AllowsCinematicOverride() const; // 0x427a3e8 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual TArray<FName> GetSequencerAnimSlotNames() const; // 0x9f6d954 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(USequencerAnimationOverride) == 0x28, "Size mismatch for USequencerAnimationOverride");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimationStateMachineLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void ConvertToAnimationStateMachine(const FAnimNodeReference Node, FAnimationStateMachineReference& AnimationState, EAnimNodeReferenceConversionResult& Result); // 0x9f6bac8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToAnimationStateMachinePure(const FAnimNodeReference Node, FAnimationStateMachineReference& AnimationState, bool& Result); // 0x9f6bcfc (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void ConvertToAnimationStateResult(const FAnimNodeReference Node, FAnimationStateResultReference& AnimationState, EAnimNodeReferenceConversionResult& Result); // 0x3cdd638 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToAnimationStateResultPure(const FAnimNodeReference Node, FAnimationStateResultReference& AnimationState, bool& Result); // 0x9f6bf34 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetRelevantAnimTimeRemaining(const FAnimUpdateContext UpdateContext, const FAnimationStateResultReference Node); // 0x3cdd478 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetRelevantAnimTimeRemainingFraction(const FAnimUpdateContext UpdateContext, const FAnimationStateResultReference Node); // 0x9f6d794 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FName GetState(const FAnimUpdateContext UpdateContext, const FAnimationStateMachineReference Node); // 0x9f6d994 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsStateBlendingIn(const FAnimUpdateContext UpdateContext, const FAnimationStateResultReference Node); // 0x9f6dc60 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsStateBlendingOut(const FAnimUpdateContext UpdateContext, const FAnimationStateResultReference Node); // 0x9f6de40 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void SetState(const FAnimUpdateContext UpdateContext, const FAnimationStateMachineReference Node, FName& TargetState, float& duration, TEnumAsByte<ETransitionLogicType>& BlendType, UBlendProfile*& BlendProfile, EAlphaBlendOption& AlphaBlendOption, UCurveFloat*& CustomBlendCurve); // 0x9f6e170 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnimationStateMachineLibrary) == 0x28, "Size mismatch for UAnimationStateMachineLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimExecutionContextLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FAnimComponentSpacePoseContext ConvertToComponentSpacePoseContext(const FAnimExecutionContext Context, EAnimExecutionContextConversionResult& Result); // 0x9f6c538 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FAnimInitializationContext ConvertToInitializationContext(const FAnimExecutionContext Context, EAnimExecutionContextConversionResult& Result); // 0x9f6c6f4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FAnimPoseContext ConvertToPoseContext(const FAnimExecutionContext Context, EAnimExecutionContextConversionResult& Result); // 0x9f6c8b0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FAnimUpdateContext ConvertToUpdateContext(const FAnimExecutionContext Context, EAnimExecutionContextConversionResult& Result); // 0x9f6ce54 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UAnimInstance* GetAnimInstance(const FAnimExecutionContext Context); // 0x9f6d010 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FAnimNodeReference GetAnimNodeReference(UAnimInstance*& Instance, int32_t& Index); // 0x9f6d108 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static float GetCurrentWeight(const FAnimUpdateContext Context); // 0x9f6d31c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetDeltaTime(const FAnimUpdateContext Context); // 0x9f6d42c (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsActive(const FAnimExecutionContext Context); // 0x9f6db70 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAnimExecutionContextLibrary) == 0x28, "Size mismatch for UAnimExecutionContextLibrary");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UAnimNotify_PlayMontageNotify : public UAnimNotify
{
public:
    FName NotifyName; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotify_PlayMontageNotify) == 0x40, "Size mismatch for UAnimNotify_PlayMontageNotify");
static_assert(offsetof(UAnimNotify_PlayMontageNotify, NotifyName) == 0x38, "Offset mismatch for UAnimNotify_PlayMontageNotify::NotifyName");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UAnimNotify_PlayMontageNotifyWindow : public UAnimNotifyState
{
public:
    FName NotifyName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotify_PlayMontageNotifyWindow) == 0x38, "Size mismatch for UAnimNotify_PlayMontageNotifyWindow");
static_assert(offsetof(UAnimNotify_PlayMontageNotifyWindow, NotifyName) == 0x30, "Offset mismatch for UAnimNotify_PlayMontageNotifyWindow::NotifyName");

// Size: 0x3e0 (Inherited: 0x408, Single: 0xffffffd8)
class UAnimSequencerInstance : public UAnimInstance
{
public:
};

static_assert(sizeof(UAnimSequencerInstance) == 0x3e0, "Size mismatch for UAnimSequencerInstance");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlendListBaseLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FBlendListBaseReference ConvertToBlendListBase(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f88cdc (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ResetNode(const FBlendListBaseReference BlendListBase); // 0x9f8cd0c (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBlendListBaseLibrary) == 0x28, "Size mismatch for UBlendListBaseLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlendSpacePlayerLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FBlendSpacePlayerReference ConvertToBlendSpacePlayer(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f88e98 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToBlendSpacePlayerPure(const FAnimNodeReference Node, FBlendSpacePlayerReference& BlendSpacePlayer, bool& Result); // 0x9f89054 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UBlendSpace* GetBlendSpace(const FBlendSpacePlayerReference BlendSpacePlayer); // 0x9f8a3ec (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetLoop(const FBlendSpacePlayerReference BlendSpacePlayer); // 0x9f8a5ec (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetPlayRate(const FBlendSpacePlayerReference BlendSpacePlayer); // 0x9f8aab4 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetPosition(const FBlendSpacePlayerReference BlendSpacePlayer); // 0x9f8ab88 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static float GetStartPosition(const FBlendSpacePlayerReference BlendSpacePlayer); // 0x9f8acb4 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FBlendSpacePlayerReference SetBlendSpace(const FBlendSpacePlayerReference BlendSpacePlayer, UBlendSpace*& BlendSpace); // 0x9f8d374 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlendSpacePlayerReference SetBlendSpaceWithInertialBlending(const FAnimUpdateContext UpdateContext, const FBlendSpacePlayerReference BlendSpacePlayer, UBlendSpace*& BlendSpace, float& BlendTime); // 0x9f8d4ec (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlendSpacePlayerReference SetLoop(const FBlendSpacePlayerReference BlendSpacePlayer, bool& bLoop); // 0x9f8d94c (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlendSpacePlayerReference SetPlayRate(const FBlendSpacePlayerReference BlendSpacePlayer, float& PlayRate); // 0x9f8dda0 (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlendSpacePlayerReference SetResetPlayTimeWhenBlendSpaceChanges(const FBlendSpacePlayerReference BlendSpacePlayer, bool& bReset); // 0x9f8df04 (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool ShouldResetPlayTimeWhenBlendSpaceChanges(const FBlendSpacePlayerReference BlendSpacePlayer); // 0x9f8e07c (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void SnapToPosition(const FBlendSpacePlayerReference BlendSpacePlayer, FVector& NewPosition); // 0x9f8e178 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UBlendSpacePlayerLibrary) == 0x28, "Size mismatch for UBlendSpacePlayerLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UKismetAnimationLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static float CalculateDirection(const FVector Velocity, const FRotator BaseRotation); // 0x9f88b58 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static float K2_CalculateVelocityFromPositionHistory(float& DeltaSeconds, FVector& Position, FPositionHistory History, int32_t& NumberOfSamples, float& VelocityMin, float& VelocityMax); // 0x519ab24 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static float K2_CalculateVelocityFromSockets(float& DeltaSeconds, USkeletalMeshComponent*& Component, FName& const SocketOrBoneName, FName& const ReferenceSocketOrBone, TEnumAsByte<ERelativeTransformSpace>& SocketSpace, FVector& OffsetInBoneSpace, FPositionHistory History, int32_t& NumberOfSamples, float& VelocityMin, float& VelocityMax, EEasingFuncType& EasingType, const FRuntimeFloatCurve CustomCurve); // 0x9f8ae84 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FVector K2_DirectionBetweenSockets(USkeletalMeshComponent*& const Component, FName& const SocketOrBoneNameFrom, FName& const SocketOrBoneNameTo); // 0x4335928 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static float K2_DistanceBetweenTwoSocketsAndMapRange(USkeletalMeshComponent*& const Component, FName& const SocketOrBoneNameA, TEnumAsByte<ERelativeTransformSpace>& SocketSpaceA, FName& const SocketOrBoneNameB, TEnumAsByte<ERelativeTransformSpace>& SocketSpaceB, bool& bRemapRange, float& InRangeMin, float& InRangeMax, float& OutRangeMin, float& OutRangeMax); // 0x4e5632c (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static float K2_EndProfilingTimer(bool& bLog, FString& LogPrefix); // 0x9f8b554 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static FTransform K2_LookAt(const FTransform CurrentTransform, const FVector TargetPosition, FVector& LookAtVector, bool& bUseUpVector, FVector& UpVector, float& ClampConeInDegree); // 0x9f8b938 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static float K2_MakePerlinNoiseAndRemap(float& Value, float& RangeOutMin, float& RangeOutMax); // 0x9f8bd88 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector K2_MakePerlinNoiseVectorAndRemap(float& X, float& Y, float& Z, float& RangeOutMinX, float& RangeOutMaxX, float& RangeOutMinY, float& RangeOutMaxY, float& RangeOutMinZ, float& RangeOutMaxZ); // 0x9f8c088 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static void K2_StartProfilingTimer(); // 0x9f8c6e8 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void K2_TwoBoneIK(const FVector RootPos, const FVector JointPos, const FVector EndPos, const FVector JointTarget, const FVector Effector, FVector& OutJointPos, FVector& OutEndPos, bool& bAllowStretching, float& StartStretchRatio, float& MaxStretchScale); // 0x9f8c6fc (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UKismetAnimationLibrary) == 0x28, "Size mismatch for UKismetAnimationLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class ULayeredBoneBlendLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void ConvertToLayeredBlendPerBonePure(const FAnimNodeReference Node, FLayeredBoneBlendReference& LayeredBoneBlend, bool& Result); // 0x9f89280 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FLayeredBoneBlendReference ConvertToLayeredBoneBlend(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f894ac (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static int32_t GetNumPoses(const FLayeredBoneBlendReference LayeredBoneBlend); // 0x9f8a9b8 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FLayeredBoneBlendReference SetBlendMask(const FAnimUpdateContext UpdateContext, const FLayeredBoneBlendReference LayeredBoneBlend, int32_t& PoseIndex, FName& BlendMaskName); // 0x9f8d0c8 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(ULayeredBoneBlendLibrary) == 0x28, "Size mismatch for ULayeredBoneBlendLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class ULinkedAnimGraphLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FLinkedAnimGraphReference ConvertToLinkedAnimGraph(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f89668 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToLinkedAnimGraphPure(const FAnimNodeReference Node, FLinkedAnimGraphReference& LinkedAnimGraph, bool& Result); // 0x9f89824 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UAnimInstance* GetLinkedAnimInstance(const FLinkedAnimGraphReference Node); // 0x9f8a4ec (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool HasLinkedAnimInstance(const FLinkedAnimGraphReference Node); // 0x9f8ad88 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(ULinkedAnimGraphLibrary) == 0x28, "Size mismatch for ULinkedAnimGraphLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UMirrorAnimLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FMirrorAnimNodeReference ConvertToMirrorNode(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f89a50 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToMirrorNodePure(const FAnimNodeReference Node, FMirrorAnimNodeReference& MirrorNode, bool& Result); // 0x9f89c0c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetMirror(const FMirrorAnimNodeReference MirrorNode); // 0x9f8a6e8 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UMirrorDataTable* GetMirrorDataTable(const FMirrorAnimNodeReference MirrorNode); // 0x9f8a7e4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetMirrorTransitionBlendTime(const FMirrorAnimNodeReference MirrorNode); // 0x9f8a8e4 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FMirrorAnimNodeReference SetMirror(const FMirrorAnimNodeReference MirrorNode, bool& bInMirror); // 0x9f8dac4 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FMirrorAnimNodeReference SetMirrorTransitionBlendTime(const FMirrorAnimNodeReference MirrorNode, float& InBlendTime); // 0x9f8dc3c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UMirrorAnimLibrary) == 0x28, "Size mismatch for UMirrorAnimLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UModifyCurveAnimLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FModifyCurveAnimNodeReference ConvertToModifyCurveNode(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f89e38 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToModifyCurveNodePure(const FAnimNodeReference Node, FModifyCurveAnimNodeReference& ModifyCurveNode, bool& Result); // 0x9f89ff4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetAlpha(const FModifyCurveAnimNodeReference ModifyCurveNode); // 0x9f8a220 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static EModifyCurveApplyMode GetApplyMode(const FModifyCurveAnimNodeReference ModifyCurveNode); // 0x9f8a2f4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FModifyCurveAnimNodeReference SetAlpha(const FModifyCurveAnimNodeReference ModifyCurveNode, float& InAlpha); // 0x9f8cdec (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FModifyCurveAnimNodeReference SetApplyMode(const FModifyCurveAnimNodeReference ModifyCurveNode, EModifyCurveApplyMode& InMode); // 0x9f8cf50 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FModifyCurveAnimNodeReference SetCurveMap(const FModifyCurveAnimNodeReference ModifyCurveNode, const TMap<float, FName> InCurveMap); // 0x9f8d77c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UModifyCurveAnimLibrary) == 0x28, "Size mismatch for UModifyCurveAnimLibrary");

// Size: 0xa8 (Inherited: 0x28, Single: 0x80)
class UPlayMontageCallbackProxy : public UObject
{
public:
    uint8_t OnCompleted[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBlendOut[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInterrupted[0x10]; // 0x48 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNotifyBegin[0x10]; // 0x58 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNotifyEnd[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_78[0x30]; // 0x78 (Size: 0x30, Type: PaddingProperty)

public:
    static UPlayMontageCallbackProxy* CreateProxyObjectForPlayMontage(USkeletalMeshComponent*& InSkeletalMeshComponent, UAnimMontage*& MontageToPlay, float& PlayRate, float& StartingPosition, FName& StartingSection, bool& bShouldStopAllMontages); // 0x9f95b94 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)

protected:
    void OnMontageBlendingOut(UAnimMontage*& Montage, bool& bInterrupted); // 0x9f96b18 (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected)
    void OnMontageEnded(UAnimMontage*& Montage, bool& bInterrupted); // 0x9f96d24 (Index: 0x2, Flags: Final|RequiredAPI|Native|Protected)
    void OnNotifyBeginReceived(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0x9f96f30 (Index: 0x3, Flags: Final|RequiredAPI|Native|Protected|HasOutParms)
    void OnNotifyEndReceived(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0x9f970f8 (Index: 0x4, Flags: Final|RequiredAPI|Native|Protected|HasOutParms)
};

static_assert(sizeof(UPlayMontageCallbackProxy) == 0xa8, "Size mismatch for UPlayMontageCallbackProxy");
static_assert(offsetof(UPlayMontageCallbackProxy, OnCompleted) == 0x28, "Offset mismatch for UPlayMontageCallbackProxy::OnCompleted");
static_assert(offsetof(UPlayMontageCallbackProxy, OnBlendOut) == 0x38, "Offset mismatch for UPlayMontageCallbackProxy::OnBlendOut");
static_assert(offsetof(UPlayMontageCallbackProxy, OnInterrupted) == 0x48, "Offset mismatch for UPlayMontageCallbackProxy::OnInterrupted");
static_assert(offsetof(UPlayMontageCallbackProxy, OnNotifyBegin) == 0x58, "Offset mismatch for UPlayMontageCallbackProxy::OnNotifyBegin");
static_assert(offsetof(UPlayMontageCallbackProxy, OnNotifyEnd) == 0x68, "Offset mismatch for UPlayMontageCallbackProxy::OnNotifyEnd");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class USequenceEvaluatorLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FSequenceEvaluatorReference AdvanceTime(const FAnimUpdateContext UpdateContext, const FSequenceEvaluatorReference SequenceEvaluator, float& PlayRate); // 0x9f94c6c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequenceEvaluatorReference ConvertToSequenceEvaluator(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f94fdc (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToSequenceEvaluatorPure(const FAnimNodeReference Node, FSequenceEvaluatorReference& SequenceEvaluator, bool& Result); // 0x9f95198 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetAccumulatedTime(const FSequenceEvaluatorReference SequenceEvaluator); // 0x9f960c0 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UAnimSequenceBase* GetSequence(const FSequenceEvaluatorReference SequenceEvaluator); // 0x9f9650c (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FSequenceEvaluatorReference SetExplicitFrame(const FSequenceEvaluatorReference SequenceEvaluator, int32_t& Frame); // 0x9f97588 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequenceEvaluatorReference SetExplicitTime(const FSequenceEvaluatorReference SequenceEvaluator, float& time); // 0x9f97700 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequenceEvaluatorReference SetSequence(const FSequenceEvaluatorReference SequenceEvaluator, UAnimSequenceBase*& Sequence); // 0x9f979c8 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequenceEvaluatorReference SetSequenceWithInertialBlending(const FAnimUpdateContext UpdateContext, const FSequenceEvaluatorReference SequenceEvaluator, UAnimSequenceBase*& Sequence, float& BlendTime); // 0x9f97cb8 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USequenceEvaluatorLibrary) == 0x28, "Size mismatch for USequenceEvaluatorLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class USequencePlayerLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static float ComputePlayRateFromDuration(const FSequencePlayerReference SequencePlayer, float& duration); // 0x9f94e84 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FSequencePlayerReference ConvertToSequencePlayer(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f953c4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToSequencePlayerPure(const FAnimNodeReference Node, FSequencePlayerReference& SequencePlayer, bool& Result); // 0x9f95580 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetAccumulatedTime(const FSequencePlayerReference SequencePlayer); // 0x9f96194 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetLoopAnimation(const FSequencePlayerReference SequencePlayer); // 0x9f9633c (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetPlayRate(const FSequencePlayerReference SequencePlayer); // 0x9f96438 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FSequencePlayerReference GetSequence(const FSequencePlayerReference SequencePlayer, UAnimSequenceBase* SequenceBase); // 0x9f9660c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UAnimSequenceBase* GetSequencePure(const FSequencePlayerReference SequencePlayer); // 0x9f96944 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetStartPosition(const FSequencePlayerReference SequencePlayer); // 0x9f96a44 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FSequencePlayerReference SetAccumulatedTime(const FSequencePlayerReference SequencePlayer, float& time); // 0x9f972c0 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequencePlayerReference SetPlayRate(const FSequencePlayerReference SequencePlayer, float& PlayRate); // 0x9f97864 (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequencePlayerReference SetSequence(const FSequencePlayerReference SequencePlayer, UAnimSequenceBase*& Sequence); // 0x9f97b40 (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequencePlayerReference SetSequenceWithInertialBlending(const FAnimUpdateContext UpdateContext, const FSequencePlayerReference SequencePlayer, UAnimSequenceBase*& Sequence, float& BlendTime); // 0x9f97f48 (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequencePlayerReference SetStartPosition(const FSequencePlayerReference SequencePlayer, float& StartPosition); // 0x9f981d8 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USequencePlayerLibrary) == 0x28, "Size mismatch for USequencePlayerLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class USequencerAnimationSupport : public UInterface
{
public:
};

static_assert(sizeof(USequencerAnimationSupport) == 0x28, "Size mismatch for USequencerAnimationSupport");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class USkeletalControlLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FSkeletalControlReference ConvertToSkeletalControl(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0x9f957ac (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToSkeletalControlPure(const FAnimNodeReference Node, FSkeletalControlReference& SkeletalControl, bool& Result); // 0x9f95968 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetAlpha(const FSkeletalControlReference SkeletalControl); // 0x9f96268 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FSkeletalControlReference SetAlpha(const FSkeletalControlReference SkeletalControl, float& Alpha); // 0x9f97424 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USkeletalControlLibrary) == 0x28, "Size mismatch for USkeletalControlLibrary");

// Size: 0x60 (Inherited: 0x10, Single: 0x50)
struct FAnimNode_BlendSpaceGraphBase : FAnimNode_Base
{
    float X; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Y; // 0x14 (Size: 0x4, Type: FloatProperty)
    FName GroupName; // 0x18 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole; // 0x1c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    UBlendSpace* BlendSpace; // 0x20 (Size: 0x8, Type: ObjectProperty)
    TArray<FPoseLink> SamplePoseLinks; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x28]; // 0x38 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendSpaceGraphBase) == 0x60, "Size mismatch for FAnimNode_BlendSpaceGraphBase");
static_assert(offsetof(FAnimNode_BlendSpaceGraphBase, X) == 0x10, "Offset mismatch for FAnimNode_BlendSpaceGraphBase::X");
static_assert(offsetof(FAnimNode_BlendSpaceGraphBase, Y) == 0x14, "Offset mismatch for FAnimNode_BlendSpaceGraphBase::Y");
static_assert(offsetof(FAnimNode_BlendSpaceGraphBase, GroupName) == 0x18, "Offset mismatch for FAnimNode_BlendSpaceGraphBase::GroupName");
static_assert(offsetof(FAnimNode_BlendSpaceGraphBase, GroupRole) == 0x1c, "Offset mismatch for FAnimNode_BlendSpaceGraphBase::GroupRole");
static_assert(offsetof(FAnimNode_BlendSpaceGraphBase, BlendSpace) == 0x20, "Offset mismatch for FAnimNode_BlendSpaceGraphBase::BlendSpace");
static_assert(offsetof(FAnimNode_BlendSpaceGraphBase, SamplePoseLinks) == 0x28, "Offset mismatch for FAnimNode_BlendSpaceGraphBase::SamplePoseLinks");

// Size: 0x60 (Inherited: 0x70, Single: 0xfffffff0)
struct FAnimNode_BlendSpaceGraph : FAnimNode_BlendSpaceGraphBase
{
};

static_assert(sizeof(FAnimNode_BlendSpaceGraph) == 0x60, "Size mismatch for FAnimNode_BlendSpaceGraph");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FAnimNode_BlendSpaceSampleResult : FAnimNode_Root
{
};

static_assert(sizeof(FAnimNode_BlendSpaceSampleResult) == 0x20, "Size mismatch for FAnimNode_BlendSpaceSampleResult");

// Size: 0xc8 (Inherited: 0x10, Single: 0xb8)
struct FAnimNode_SkeletalControlBase : FAnimNode_Base
{
    FComponentSpacePoseLink ComponentPose; // 0x10 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold; // 0x20 (Size: 0x4, Type: IntProperty)
    float ActualAlpha; // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t AlphaInputType; // 0x28 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    float Alpha; // 0x2c (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias; // 0x30 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend; // 0x38 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName; // 0x80 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x84 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_b4[0x14]; // 0xb4 (Size: 0x14, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_SkeletalControlBase) == 0xc8, "Size mismatch for FAnimNode_SkeletalControlBase");
static_assert(offsetof(FAnimNode_SkeletalControlBase, ComponentPose) == 0x10, "Offset mismatch for FAnimNode_SkeletalControlBase::ComponentPose");
static_assert(offsetof(FAnimNode_SkeletalControlBase, LODThreshold) == 0x20, "Offset mismatch for FAnimNode_SkeletalControlBase::LODThreshold");
static_assert(offsetof(FAnimNode_SkeletalControlBase, ActualAlpha) == 0x24, "Offset mismatch for FAnimNode_SkeletalControlBase::ActualAlpha");
static_assert(offsetof(FAnimNode_SkeletalControlBase, AlphaInputType) == 0x28, "Offset mismatch for FAnimNode_SkeletalControlBase::AlphaInputType");
static_assert(offsetof(FAnimNode_SkeletalControlBase, bAlphaBoolEnabled) == 0x29, "Offset mismatch for FAnimNode_SkeletalControlBase::bAlphaBoolEnabled");
static_assert(offsetof(FAnimNode_SkeletalControlBase, Alpha) == 0x2c, "Offset mismatch for FAnimNode_SkeletalControlBase::Alpha");
static_assert(offsetof(FAnimNode_SkeletalControlBase, AlphaScaleBias) == 0x30, "Offset mismatch for FAnimNode_SkeletalControlBase::AlphaScaleBias");
static_assert(offsetof(FAnimNode_SkeletalControlBase, AlphaBoolBlend) == 0x38, "Offset mismatch for FAnimNode_SkeletalControlBase::AlphaBoolBlend");
static_assert(offsetof(FAnimNode_SkeletalControlBase, AlphaCurveName) == 0x80, "Offset mismatch for FAnimNode_SkeletalControlBase::AlphaCurveName");
static_assert(offsetof(FAnimNode_SkeletalControlBase, AlphaScaleBiasClamp) == 0x84, "Offset mismatch for FAnimNode_SkeletalControlBase::AlphaScaleBiasClamp");

// Size: 0x128 (Inherited: 0xd8, Single: 0x50)
struct FAnimNode_ModifyBone : FAnimNode_SkeletalControlBase
{
    FBoneReference BoneToModify; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    FVector Translation; // 0xd8 (Size: 0x18, Type: StructProperty)
    FRotator Rotation; // 0xf0 (Size: 0x18, Type: StructProperty)
    FVector Scale; // 0x108 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EBoneModificationMode> TranslationMode; // 0x120 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneModificationMode> RotationMode; // 0x121 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneModificationMode> ScaleMode; // 0x122 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> TranslationSpace; // 0x123 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> RotationSpace; // 0x124 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> ScaleSpace; // 0x125 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_126[0x2]; // 0x126 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ModifyBone) == 0x128, "Size mismatch for FAnimNode_ModifyBone");
static_assert(offsetof(FAnimNode_ModifyBone, BoneToModify) == 0xc8, "Offset mismatch for FAnimNode_ModifyBone::BoneToModify");
static_assert(offsetof(FAnimNode_ModifyBone, Translation) == 0xd8, "Offset mismatch for FAnimNode_ModifyBone::Translation");
static_assert(offsetof(FAnimNode_ModifyBone, Rotation) == 0xf0, "Offset mismatch for FAnimNode_ModifyBone::Rotation");
static_assert(offsetof(FAnimNode_ModifyBone, Scale) == 0x108, "Offset mismatch for FAnimNode_ModifyBone::Scale");
static_assert(offsetof(FAnimNode_ModifyBone, TranslationMode) == 0x120, "Offset mismatch for FAnimNode_ModifyBone::TranslationMode");
static_assert(offsetof(FAnimNode_ModifyBone, RotationMode) == 0x121, "Offset mismatch for FAnimNode_ModifyBone::RotationMode");
static_assert(offsetof(FAnimNode_ModifyBone, ScaleMode) == 0x122, "Offset mismatch for FAnimNode_ModifyBone::ScaleMode");
static_assert(offsetof(FAnimNode_ModifyBone, TranslationSpace) == 0x123, "Offset mismatch for FAnimNode_ModifyBone::TranslationSpace");
static_assert(offsetof(FAnimNode_ModifyBone, RotationSpace) == 0x124, "Offset mismatch for FAnimNode_ModifyBone::RotationSpace");
static_assert(offsetof(FAnimNode_ModifyBone, ScaleSpace) == 0x125, "Offset mismatch for FAnimNode_ModifyBone::ScaleSpace");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FAnimNode_RefPose : FAnimNode_Base
{
};

static_assert(sizeof(FAnimNode_RefPose) == 0x10, "Size mismatch for FAnimNode_RefPose");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FAnimNode_MeshSpaceRefPose : FAnimNode_Base
{
};

static_assert(sizeof(FAnimNode_MeshSpaceRefPose) == 0x10, "Size mismatch for FAnimNode_MeshSpaceRefPose");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigidBodyAnimNodeReference : FAnimNodeReference
{
};

static_assert(sizeof(FRigidBodyAnimNodeReference) == 0x10, "Size mismatch for FRigidBodyAnimNodeReference");

// Size: 0xe8 (Inherited: 0xd8, Single: 0x10)
struct FAnimNode_RotationMultiplier : FAnimNode_SkeletalControlBase
{
    FBoneReference TargetBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference SourceBone; // 0xd4 (Size: 0xc, Type: StructProperty)
    float Multiplier; // 0xe0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EBoneAxis> RotationAxisToRefer; // 0xe4 (Size: 0x1, Type: ByteProperty)
    bool bIsAdditive; // 0xe5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e6[0x2]; // 0xe6 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RotationMultiplier) == 0xe8, "Size mismatch for FAnimNode_RotationMultiplier");
static_assert(offsetof(FAnimNode_RotationMultiplier, TargetBone) == 0xc8, "Offset mismatch for FAnimNode_RotationMultiplier::TargetBone");
static_assert(offsetof(FAnimNode_RotationMultiplier, SourceBone) == 0xd4, "Offset mismatch for FAnimNode_RotationMultiplier::SourceBone");
static_assert(offsetof(FAnimNode_RotationMultiplier, Multiplier) == 0xe0, "Offset mismatch for FAnimNode_RotationMultiplier::Multiplier");
static_assert(offsetof(FAnimNode_RotationMultiplier, RotationAxisToRefer) == 0xe4, "Offset mismatch for FAnimNode_RotationMultiplier::RotationAxisToRefer");
static_assert(offsetof(FAnimNode_RotationMultiplier, bIsAdditive) == 0xe5, "Offset mismatch for FAnimNode_RotationMultiplier::bIsAdditive");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FBlendSpaceReference : FAnimNodeReference
{
};

static_assert(sizeof(FBlendSpaceReference) == 0x10, "Size mismatch for FBlendSpaceReference");

// Size: 0x1a0 (Inherited: 0x0, Single: 0x1a0)
struct FRotationRetargetingInfo
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0xf]; // 0x1 (Size: 0xf, Type: PaddingProperty)
    FTransform Source; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Target; // 0x70 (Size: 0x60, Type: StructProperty)
    uint8_t RotationComponent; // 0xd0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)
    FVector TwistAxis; // 0xd8 (Size: 0x18, Type: StructProperty)
    bool bUseAbsoluteAngle; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x3]; // 0xf1 (Size: 0x3, Type: PaddingProperty)
    float SourceMinimum; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float SourceMaximum; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float TargetMinimum; // 0xfc (Size: 0x4, Type: FloatProperty)
    float TargetMaximum; // 0x100 (Size: 0x4, Type: FloatProperty)
    uint8_t EasingType; // 0x104 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_105[0x3]; // 0x105 (Size: 0x3, Type: PaddingProperty)
    FRuntimeFloatCurve CustomCurve; // 0x108 (Size: 0x88, Type: StructProperty)
    bool bFlipEasing; // 0x190 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_191[0x3]; // 0x191 (Size: 0x3, Type: PaddingProperty)
    float EasingWeight; // 0x194 (Size: 0x4, Type: FloatProperty)
    bool bClamp; // 0x198 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_199[0x7]; // 0x199 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRotationRetargetingInfo) == 0x1a0, "Size mismatch for FRotationRetargetingInfo");
static_assert(offsetof(FRotationRetargetingInfo, bEnabled) == 0x0, "Offset mismatch for FRotationRetargetingInfo::bEnabled");
static_assert(offsetof(FRotationRetargetingInfo, Source) == 0x10, "Offset mismatch for FRotationRetargetingInfo::Source");
static_assert(offsetof(FRotationRetargetingInfo, Target) == 0x70, "Offset mismatch for FRotationRetargetingInfo::Target");
static_assert(offsetof(FRotationRetargetingInfo, RotationComponent) == 0xd0, "Offset mismatch for FRotationRetargetingInfo::RotationComponent");
static_assert(offsetof(FRotationRetargetingInfo, TwistAxis) == 0xd8, "Offset mismatch for FRotationRetargetingInfo::TwistAxis");
static_assert(offsetof(FRotationRetargetingInfo, bUseAbsoluteAngle) == 0xf0, "Offset mismatch for FRotationRetargetingInfo::bUseAbsoluteAngle");
static_assert(offsetof(FRotationRetargetingInfo, SourceMinimum) == 0xf4, "Offset mismatch for FRotationRetargetingInfo::SourceMinimum");
static_assert(offsetof(FRotationRetargetingInfo, SourceMaximum) == 0xf8, "Offset mismatch for FRotationRetargetingInfo::SourceMaximum");
static_assert(offsetof(FRotationRetargetingInfo, TargetMinimum) == 0xfc, "Offset mismatch for FRotationRetargetingInfo::TargetMinimum");
static_assert(offsetof(FRotationRetargetingInfo, TargetMaximum) == 0x100, "Offset mismatch for FRotationRetargetingInfo::TargetMaximum");
static_assert(offsetof(FRotationRetargetingInfo, EasingType) == 0x104, "Offset mismatch for FRotationRetargetingInfo::EasingType");
static_assert(offsetof(FRotationRetargetingInfo, CustomCurve) == 0x108, "Offset mismatch for FRotationRetargetingInfo::CustomCurve");
static_assert(offsetof(FRotationRetargetingInfo, bFlipEasing) == 0x190, "Offset mismatch for FRotationRetargetingInfo::bFlipEasing");
static_assert(offsetof(FRotationRetargetingInfo, EasingWeight) == 0x194, "Offset mismatch for FRotationRetargetingInfo::EasingWeight");
static_assert(offsetof(FRotationRetargetingInfo, bClamp) == 0x198, "Offset mismatch for FRotationRetargetingInfo::bClamp");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FPositionHistory
{
    TArray<FVector> Positions; // 0x0 (Size: 0x10, Type: ArrayProperty)
    float Range; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x1c]; // 0x14 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(FPositionHistory) == 0x30, "Size mismatch for FPositionHistory");
static_assert(offsetof(FPositionHistory, Positions) == 0x0, "Offset mismatch for FPositionHistory::Positions");
static_assert(offsetof(FPositionHistory, Range) == 0x10, "Offset mismatch for FPositionHistory::Range");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FAnimationStateResultReference : FAnimNodeReference
{
};

static_assert(sizeof(FAnimationStateResultReference) == 0x10, "Size mismatch for FAnimationStateResultReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FAnimationStateMachineReference : FAnimNodeReference
{
};

static_assert(sizeof(FAnimationStateMachineReference) == 0x10, "Size mismatch for FAnimationStateMachineReference");

// Size: 0x68 (Inherited: 0x58, Single: 0x10)
struct FAnimNode_BlendSpacePlayerBase : FAnimNode_AssetPlayerBase
{
    uint8_t Pad_38[0x28]; // 0x38 (Size: 0x28, Type: PaddingProperty)
    UBlendSpace* PreviousBlendSpace; // 0x60 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAnimNode_BlendSpacePlayerBase) == 0x68, "Size mismatch for FAnimNode_BlendSpacePlayerBase");
static_assert(offsetof(FAnimNode_BlendSpacePlayerBase, PreviousBlendSpace) == 0x60, "Offset mismatch for FAnimNode_BlendSpacePlayerBase::PreviousBlendSpace");

// Size: 0x70 (Inherited: 0xc0, Single: 0xffffffb0)
struct FAnimNode_BlendSpacePlayer : FAnimNode_BlendSpacePlayerBase
{
    UBlendSpace* BlendSpace; // 0x68 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAnimNode_BlendSpacePlayer) == 0x70, "Size mismatch for FAnimNode_BlendSpacePlayer");
static_assert(offsetof(FAnimNode_BlendSpacePlayer, BlendSpace) == 0x68, "Offset mismatch for FAnimNode_BlendSpacePlayer::BlendSpace");

// Size: 0x1c0 (Inherited: 0x130, Single: 0x90)
struct FAnimNode_AimOffsetLookAt : FAnimNode_BlendSpacePlayer
{
    uint8_t Pad_70[0xc0]; // 0x70 (Size: 0xc0, Type: PaddingProperty)
    FPoseLink BasePose; // 0x130 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold; // 0x140 (Size: 0x4, Type: IntProperty)
    FName SourceSocketName; // 0x144 (Size: 0x4, Type: NameProperty)
    FName PivotSocketName; // 0x148 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
    FVector LookAtLocation; // 0x150 (Size: 0x18, Type: StructProperty)
    FVector SocketAxis; // 0x168 (Size: 0x18, Type: StructProperty)
    float Alpha; // 0x180 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_184[0x3c]; // 0x184 (Size: 0x3c, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_AimOffsetLookAt) == 0x1c0, "Size mismatch for FAnimNode_AimOffsetLookAt");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, BasePose) == 0x130, "Offset mismatch for FAnimNode_AimOffsetLookAt::BasePose");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, LODThreshold) == 0x140, "Offset mismatch for FAnimNode_AimOffsetLookAt::LODThreshold");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, SourceSocketName) == 0x144, "Offset mismatch for FAnimNode_AimOffsetLookAt::SourceSocketName");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, PivotSocketName) == 0x148, "Offset mismatch for FAnimNode_AimOffsetLookAt::PivotSocketName");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, LookAtLocation) == 0x150, "Offset mismatch for FAnimNode_AimOffsetLookAt::LookAtLocation");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, SocketAxis) == 0x168, "Offset mismatch for FAnimNode_AimOffsetLookAt::SocketAxis");
static_assert(offsetof(FAnimNode_AimOffsetLookAt, Alpha) == 0x180, "Offset mismatch for FAnimNode_AimOffsetLookAt::Alpha");

// Size: 0xc8 (Inherited: 0x10, Single: 0xb8)
struct FAnimNode_ApplyAdditive : FAnimNode_Base
{
    FPoseLink base; // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink Additive; // 0x20 (Size: 0x10, Type: StructProperty)
    float Alpha; // 0x30 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias; // 0x34 (Size: 0x8, Type: StructProperty)
    int32_t LODThreshold; // 0x3c (Size: 0x4, Type: IntProperty)
    FInputAlphaBoolBlend AlphaBoolBlend; // 0x40 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName; // 0x88 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x8c (Size: 0x30, Type: StructProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    uint8_t AlphaInputType; // 0xc0 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled; // 0xc1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c2[0x6]; // 0xc2 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ApplyAdditive) == 0xc8, "Size mismatch for FAnimNode_ApplyAdditive");
static_assert(offsetof(FAnimNode_ApplyAdditive, base) == 0x10, "Offset mismatch for FAnimNode_ApplyAdditive::base");
static_assert(offsetof(FAnimNode_ApplyAdditive, Additive) == 0x20, "Offset mismatch for FAnimNode_ApplyAdditive::Additive");
static_assert(offsetof(FAnimNode_ApplyAdditive, Alpha) == 0x30, "Offset mismatch for FAnimNode_ApplyAdditive::Alpha");
static_assert(offsetof(FAnimNode_ApplyAdditive, AlphaScaleBias) == 0x34, "Offset mismatch for FAnimNode_ApplyAdditive::AlphaScaleBias");
static_assert(offsetof(FAnimNode_ApplyAdditive, LODThreshold) == 0x3c, "Offset mismatch for FAnimNode_ApplyAdditive::LODThreshold");
static_assert(offsetof(FAnimNode_ApplyAdditive, AlphaBoolBlend) == 0x40, "Offset mismatch for FAnimNode_ApplyAdditive::AlphaBoolBlend");
static_assert(offsetof(FAnimNode_ApplyAdditive, AlphaCurveName) == 0x88, "Offset mismatch for FAnimNode_ApplyAdditive::AlphaCurveName");
static_assert(offsetof(FAnimNode_ApplyAdditive, AlphaScaleBiasClamp) == 0x8c, "Offset mismatch for FAnimNode_ApplyAdditive::AlphaScaleBiasClamp");
static_assert(offsetof(FAnimNode_ApplyAdditive, AlphaInputType) == 0xc0, "Offset mismatch for FAnimNode_ApplyAdditive::AlphaInputType");
static_assert(offsetof(FAnimNode_ApplyAdditive, bAlphaBoolEnabled) == 0xc1, "Offset mismatch for FAnimNode_ApplyAdditive::bAlphaBoolEnabled");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FBlendBoneByChannelEntry
{
    FBoneReference SourceBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone; // 0xc (Size: 0xc, Type: StructProperty)
    bool bBlendTranslation; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bBlendRotation; // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bBlendScale; // 0x1a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b[0x1]; // 0x1b (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FBlendBoneByChannelEntry) == 0x1c, "Size mismatch for FBlendBoneByChannelEntry");
static_assert(offsetof(FBlendBoneByChannelEntry, SourceBone) == 0x0, "Offset mismatch for FBlendBoneByChannelEntry::SourceBone");
static_assert(offsetof(FBlendBoneByChannelEntry, TargetBone) == 0xc, "Offset mismatch for FBlendBoneByChannelEntry::TargetBone");
static_assert(offsetof(FBlendBoneByChannelEntry, bBlendTranslation) == 0x18, "Offset mismatch for FBlendBoneByChannelEntry::bBlendTranslation");
static_assert(offsetof(FBlendBoneByChannelEntry, bBlendRotation) == 0x19, "Offset mismatch for FBlendBoneByChannelEntry::bBlendRotation");
static_assert(offsetof(FBlendBoneByChannelEntry, bBlendScale) == 0x1a, "Offset mismatch for FBlendBoneByChannelEntry::bBlendScale");

// Size: 0x68 (Inherited: 0x10, Single: 0x58)
struct FAnimNode_BlendBoneByChannel : FAnimNode_Base
{
    FPoseLink A; // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink B; // 0x20 (Size: 0x10, Type: StructProperty)
    TArray<FBlendBoneByChannelEntry> BoneDefinitions; // 0x30 (Size: 0x10, Type: ArrayProperty)
    float Alpha; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FInputScaleBias AlphaScaleBias; // 0x58 (Size: 0x8, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> TransformsSpace; // 0x60 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendBoneByChannel) == 0x68, "Size mismatch for FAnimNode_BlendBoneByChannel");
static_assert(offsetof(FAnimNode_BlendBoneByChannel, A) == 0x10, "Offset mismatch for FAnimNode_BlendBoneByChannel::A");
static_assert(offsetof(FAnimNode_BlendBoneByChannel, B) == 0x20, "Offset mismatch for FAnimNode_BlendBoneByChannel::B");
static_assert(offsetof(FAnimNode_BlendBoneByChannel, BoneDefinitions) == 0x30, "Offset mismatch for FAnimNode_BlendBoneByChannel::BoneDefinitions");
static_assert(offsetof(FAnimNode_BlendBoneByChannel, Alpha) == 0x50, "Offset mismatch for FAnimNode_BlendBoneByChannel::Alpha");
static_assert(offsetof(FAnimNode_BlendBoneByChannel, AlphaScaleBias) == 0x58, "Offset mismatch for FAnimNode_BlendBoneByChannel::AlphaScaleBias");
static_assert(offsetof(FAnimNode_BlendBoneByChannel, TransformsSpace) == 0x60, "Offset mismatch for FAnimNode_BlendBoneByChannel::TransformsSpace");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FAnimNode_BlendListBase : FAnimNode_Base
{
    TArray<FPoseLink> BlendPose; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_20[0x30]; // 0x20 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendListBase) == 0x50, "Size mismatch for FAnimNode_BlendListBase");
static_assert(offsetof(FAnimNode_BlendListBase, BlendPose) == 0x10, "Offset mismatch for FAnimNode_BlendListBase::BlendPose");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FAnimNode_BlendListByBool : FAnimNode_BlendListBase
{
};

static_assert(sizeof(FAnimNode_BlendListByBool) == 0x50, "Size mismatch for FAnimNode_BlendListByBool");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FAnimNode_BlendListByEnum : FAnimNode_BlendListBase
{
};

static_assert(sizeof(FAnimNode_BlendListByEnum) == 0x50, "Size mismatch for FAnimNode_BlendListByEnum");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FAnimNode_BlendListByInt : FAnimNode_BlendListBase
{
};

static_assert(sizeof(FAnimNode_BlendListByInt) == 0x50, "Size mismatch for FAnimNode_BlendListByInt");

// Size: 0x78 (Inherited: 0x130, Single: 0xffffff48)
struct FAnimNode_BlendSpaceEvaluator : FAnimNode_BlendSpacePlayer
{
    float NormalizedTime; // 0x70 (Size: 0x4, Type: FloatProperty)
    bool bTeleportToNormalizedTime; // 0x74 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_75[0x3]; // 0x75 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BlendSpaceEvaluator) == 0x78, "Size mismatch for FAnimNode_BlendSpaceEvaluator");
static_assert(offsetof(FAnimNode_BlendSpaceEvaluator, NormalizedTime) == 0x70, "Offset mismatch for FAnimNode_BlendSpaceEvaluator::NormalizedTime");
static_assert(offsetof(FAnimNode_BlendSpaceEvaluator, bTeleportToNormalizedTime) == 0x74, "Offset mismatch for FAnimNode_BlendSpaceEvaluator::bTeleportToNormalizedTime");

// Size: 0x90 (Inherited: 0xc0, Single: 0xffffffd0)
struct FAnimNode_BlendSpacePlayer_Standalone : FAnimNode_BlendSpacePlayerBase
{
    FName GroupName; // 0x68 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole; // 0x6c (Size: 0x1, Type: ByteProperty)
    bool bOverridePositionWhenJoiningSyncGroupAsLeader; // 0x6d (Size: 0x1, Type: BoolProperty)
    uint8_t Method; // 0x6e (Size: 0x1, Type: EnumProperty)
    bool bIgnoreForRelevancyTest; // 0x6f (Size: 0x1, Type: BoolProperty)
    float X; // 0x70 (Size: 0x4, Type: FloatProperty)
    float Y; // 0x74 (Size: 0x4, Type: FloatProperty)
    float PlayRate; // 0x78 (Size: 0x4, Type: FloatProperty)
    bool bLoop; // 0x7c (Size: 0x1, Type: BoolProperty)
    bool bResetPlayTimeWhenBlendSpaceChanges; // 0x7d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7e[0x2]; // 0x7e (Size: 0x2, Type: PaddingProperty)
    float StartPosition; // 0x80 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    UBlendSpace* BlendSpace; // 0x88 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAnimNode_BlendSpacePlayer_Standalone) == 0x90, "Size mismatch for FAnimNode_BlendSpacePlayer_Standalone");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, GroupName) == 0x68, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::GroupName");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, GroupRole) == 0x6c, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::GroupRole");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, bOverridePositionWhenJoiningSyncGroupAsLeader) == 0x6d, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::bOverridePositionWhenJoiningSyncGroupAsLeader");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, Method) == 0x6e, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::Method");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, bIgnoreForRelevancyTest) == 0x6f, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::bIgnoreForRelevancyTest");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, X) == 0x70, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::X");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, Y) == 0x74, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::Y");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, PlayRate) == 0x78, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::PlayRate");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, bLoop) == 0x7c, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::bLoop");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, bResetPlayTimeWhenBlendSpaceChanges) == 0x7d, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::bResetPlayTimeWhenBlendSpaceChanges");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, StartPosition) == 0x80, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::StartPosition");
static_assert(offsetof(FAnimNode_BlendSpacePlayer_Standalone, BlendSpace) == 0x88, "Offset mismatch for FAnimNode_BlendSpacePlayer_Standalone::BlendSpace");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FAnimNode_CallFunction : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_20[0x14]; // 0x20 (Size: 0x14, Type: PaddingProperty)
    uint8_t CallSite[0x4]; // 0x34 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FAnimNode_CallFunction) == 0x38, "Size mismatch for FAnimNode_CallFunction");
static_assert(offsetof(FAnimNode_CallFunction, Source) == 0x10, "Offset mismatch for FAnimNode_CallFunction::Source");
static_assert(offsetof(FAnimNode_CallFunction, CallSite) == 0x34, "Offset mismatch for FAnimNode_CallFunction::CallSite");

// Size: 0x150 (Inherited: 0x10, Single: 0x140)
struct FAnimNode_CopyPoseFromMesh : FAnimNode_Base
{
    TWeakObjectPtr<USkeletalMeshComponent*> SourceMeshComponent; // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t bUseAttachedParent : 1; // 0x18:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCopyCurves : 1; // 0x18:1 (Size: 0x1, Type: BoolProperty)
    bool bCopyCustomAttributes; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseMeshPose : 1; // 0x1a:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b[0x1]; // 0x1b (Size: 0x1, Type: PaddingProperty)
    FName RootBoneToCopy; // 0x1c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_20[0x130]; // 0x20 (Size: 0x130, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_CopyPoseFromMesh) == 0x150, "Size mismatch for FAnimNode_CopyPoseFromMesh");
static_assert(offsetof(FAnimNode_CopyPoseFromMesh, SourceMeshComponent) == 0x10, "Offset mismatch for FAnimNode_CopyPoseFromMesh::SourceMeshComponent");
static_assert(offsetof(FAnimNode_CopyPoseFromMesh, bUseAttachedParent) == 0x18, "Offset mismatch for FAnimNode_CopyPoseFromMesh::bUseAttachedParent");
static_assert(offsetof(FAnimNode_CopyPoseFromMesh, bCopyCurves) == 0x18, "Offset mismatch for FAnimNode_CopyPoseFromMesh::bCopyCurves");
static_assert(offsetof(FAnimNode_CopyPoseFromMesh, bCopyCustomAttributes) == 0x19, "Offset mismatch for FAnimNode_CopyPoseFromMesh::bCopyCustomAttributes");
static_assert(offsetof(FAnimNode_CopyPoseFromMesh, bUseMeshPose) == 0x1a, "Offset mismatch for FAnimNode_CopyPoseFromMesh::bUseMeshPose");
static_assert(offsetof(FAnimNode_CopyPoseFromMesh, RootBoneToCopy) == 0x1c, "Offset mismatch for FAnimNode_CopyPoseFromMesh::RootBoneToCopy");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FAnimNode_CurveSource : FAnimNode_Base
{
    FPoseLink SourcePose; // 0x10 (Size: 0x10, Type: StructProperty)
    FName SourceBinding; // 0x20 (Size: 0x4, Type: NameProperty)
    float Alpha; // 0x24 (Size: 0x4, Type: FloatProperty)
    TScriptInterface<Class> CurveSource; // 0x28 (Size: 0x10, Type: InterfaceProperty)
};

static_assert(sizeof(FAnimNode_CurveSource) == 0x38, "Size mismatch for FAnimNode_CurveSource");
static_assert(offsetof(FAnimNode_CurveSource, SourcePose) == 0x10, "Offset mismatch for FAnimNode_CurveSource::SourcePose");
static_assert(offsetof(FAnimNode_CurveSource, SourceBinding) == 0x20, "Offset mismatch for FAnimNode_CurveSource::SourceBinding");
static_assert(offsetof(FAnimNode_CurveSource, Alpha) == 0x24, "Offset mismatch for FAnimNode_CurveSource::Alpha");
static_assert(offsetof(FAnimNode_CurveSource, CurveSource) == 0x28, "Offset mismatch for FAnimNode_CurveSource::CurveSource");

// Size: 0xe8 (Inherited: 0x10, Single: 0xd8)
struct FAnimNode_LayeredBoneBlend : FAnimNode_Base
{
    FPoseLink BasePose; // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FPoseLink> BlendPoses; // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t BlendMode; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    TArray<UBlendProfile*> BlendMasks; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FInputBlendPose> LayerSetup; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<float> BlendWeights; // 0x58 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_68[0x20]; // 0x68 (Size: 0x20, Type: PaddingProperty)
    TArray<FPerBoneBlendWeight> PerBoneBlendWeights; // 0x88 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_98[0x20]; // 0x98 (Size: 0x20, Type: PaddingProperty)
    FGuid SkeletonGuid; // 0xb8 (Size: 0x10, Type: StructProperty)
    FGuid VirtualBoneGuid; // 0xc8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_d8[0x4]; // 0xd8 (Size: 0x4, Type: PaddingProperty)
    int32_t LODThreshold; // 0xdc (Size: 0x4, Type: IntProperty)
    bool bMeshSpaceRotationBlend; // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bRootSpaceRotationBlend; // 0xe1 (Size: 0x1, Type: BoolProperty)
    bool bMeshSpaceScaleBlend; // 0xe2 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ECurveBlendOption> CurveBlendOption; // 0xe3 (Size: 0x1, Type: ByteProperty)
    bool bBlendRootMotionBasedOnRootBone; // 0xe4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e5[0x3]; // 0xe5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_LayeredBoneBlend) == 0xe8, "Size mismatch for FAnimNode_LayeredBoneBlend");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, BasePose) == 0x10, "Offset mismatch for FAnimNode_LayeredBoneBlend::BasePose");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, BlendPoses) == 0x20, "Offset mismatch for FAnimNode_LayeredBoneBlend::BlendPoses");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, BlendMode) == 0x30, "Offset mismatch for FAnimNode_LayeredBoneBlend::BlendMode");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, BlendMasks) == 0x38, "Offset mismatch for FAnimNode_LayeredBoneBlend::BlendMasks");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, LayerSetup) == 0x48, "Offset mismatch for FAnimNode_LayeredBoneBlend::LayerSetup");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, BlendWeights) == 0x58, "Offset mismatch for FAnimNode_LayeredBoneBlend::BlendWeights");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, PerBoneBlendWeights) == 0x88, "Offset mismatch for FAnimNode_LayeredBoneBlend::PerBoneBlendWeights");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, SkeletonGuid) == 0xb8, "Offset mismatch for FAnimNode_LayeredBoneBlend::SkeletonGuid");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, VirtualBoneGuid) == 0xc8, "Offset mismatch for FAnimNode_LayeredBoneBlend::VirtualBoneGuid");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, LODThreshold) == 0xdc, "Offset mismatch for FAnimNode_LayeredBoneBlend::LODThreshold");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, bMeshSpaceRotationBlend) == 0xe0, "Offset mismatch for FAnimNode_LayeredBoneBlend::bMeshSpaceRotationBlend");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, bRootSpaceRotationBlend) == 0xe1, "Offset mismatch for FAnimNode_LayeredBoneBlend::bRootSpaceRotationBlend");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, bMeshSpaceScaleBlend) == 0xe2, "Offset mismatch for FAnimNode_LayeredBoneBlend::bMeshSpaceScaleBlend");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, CurveBlendOption) == 0xe3, "Offset mismatch for FAnimNode_LayeredBoneBlend::CurveBlendOption");
static_assert(offsetof(FAnimNode_LayeredBoneBlend, bBlendRootMotionBasedOnRootBone) == 0xe4, "Offset mismatch for FAnimNode_LayeredBoneBlend::bBlendRootMotionBasedOnRootBone");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FAnimNode_MakeDynamicAdditive : FAnimNode_Base
{
    FPoseLink base; // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink Additive; // 0x20 (Size: 0x10, Type: StructProperty)
    bool bMeshSpaceAdditive; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_MakeDynamicAdditive) == 0x38, "Size mismatch for FAnimNode_MakeDynamicAdditive");
static_assert(offsetof(FAnimNode_MakeDynamicAdditive, base) == 0x10, "Offset mismatch for FAnimNode_MakeDynamicAdditive::base");
static_assert(offsetof(FAnimNode_MakeDynamicAdditive, Additive) == 0x20, "Offset mismatch for FAnimNode_MakeDynamicAdditive::Additive");
static_assert(offsetof(FAnimNode_MakeDynamicAdditive, bMeshSpaceAdditive) == 0x30, "Offset mismatch for FAnimNode_MakeDynamicAdditive::bMeshSpaceAdditive");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FAnimNode_MirrorBase : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_20[0x28]; // 0x20 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_MirrorBase) == 0x48, "Size mismatch for FAnimNode_MirrorBase");
static_assert(offsetof(FAnimNode_MirrorBase, Source) == 0x10, "Offset mismatch for FAnimNode_MirrorBase::Source");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
struct FAnimNode_Mirror : FAnimNode_MirrorBase
{
};

static_assert(sizeof(FAnimNode_Mirror) == 0x48, "Size mismatch for FAnimNode_Mirror");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
struct FAnimNode_Mirror_Standalone : FAnimNode_MirrorBase
{
    bool bMirror; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    UMirrorDataTable* MirrorDataTable; // 0x50 (Size: 0x8, Type: ObjectProperty)
    float BlendTime; // 0x58 (Size: 0x4, Type: FloatProperty)
    bool bResetChild; // 0x5c (Size: 0x1, Type: BoolProperty)
    bool bBoneMirroring; // 0x5d (Size: 0x1, Type: BoolProperty)
    bool bCurveMirroring; // 0x5e (Size: 0x1, Type: BoolProperty)
    bool bAttributeMirroring; // 0x5f (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FAnimNode_Mirror_Standalone) == 0x60, "Size mismatch for FAnimNode_Mirror_Standalone");
static_assert(offsetof(FAnimNode_Mirror_Standalone, bMirror) == 0x48, "Offset mismatch for FAnimNode_Mirror_Standalone::bMirror");
static_assert(offsetof(FAnimNode_Mirror_Standalone, MirrorDataTable) == 0x50, "Offset mismatch for FAnimNode_Mirror_Standalone::MirrorDataTable");
static_assert(offsetof(FAnimNode_Mirror_Standalone, BlendTime) == 0x58, "Offset mismatch for FAnimNode_Mirror_Standalone::BlendTime");
static_assert(offsetof(FAnimNode_Mirror_Standalone, bResetChild) == 0x5c, "Offset mismatch for FAnimNode_Mirror_Standalone::bResetChild");
static_assert(offsetof(FAnimNode_Mirror_Standalone, bBoneMirroring) == 0x5d, "Offset mismatch for FAnimNode_Mirror_Standalone::bBoneMirroring");
static_assert(offsetof(FAnimNode_Mirror_Standalone, bCurveMirroring) == 0x5e, "Offset mismatch for FAnimNode_Mirror_Standalone::bCurveMirroring");
static_assert(offsetof(FAnimNode_Mirror_Standalone, bAttributeMirroring) == 0x5f, "Offset mismatch for FAnimNode_Mirror_Standalone::bAttributeMirroring");

// Size: 0x120 (Inherited: 0x10, Single: 0x110)
struct FAnimNode_ModifyCurve : FAnimNode_Base
{
    FPoseLink SourcePose; // 0x10 (Size: 0x10, Type: StructProperty)
    TMap<float, FName> CurveMap; // 0x20 (Size: 0x50, Type: MapProperty)
    TArray<float> CurveValues; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> CurveNames; // 0x80 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_90[0x88]; // 0x90 (Size: 0x88, Type: PaddingProperty)
    float Alpha; // 0x118 (Size: 0x4, Type: FloatProperty)
    uint8_t ApplyMode; // 0x11c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11d[0x3]; // 0x11d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ModifyCurve) == 0x120, "Size mismatch for FAnimNode_ModifyCurve");
static_assert(offsetof(FAnimNode_ModifyCurve, SourcePose) == 0x10, "Offset mismatch for FAnimNode_ModifyCurve::SourcePose");
static_assert(offsetof(FAnimNode_ModifyCurve, CurveMap) == 0x20, "Offset mismatch for FAnimNode_ModifyCurve::CurveMap");
static_assert(offsetof(FAnimNode_ModifyCurve, CurveValues) == 0x70, "Offset mismatch for FAnimNode_ModifyCurve::CurveValues");
static_assert(offsetof(FAnimNode_ModifyCurve, CurveNames) == 0x80, "Offset mismatch for FAnimNode_ModifyCurve::CurveNames");
static_assert(offsetof(FAnimNode_ModifyCurve, Alpha) == 0x118, "Offset mismatch for FAnimNode_ModifyCurve::Alpha");
static_assert(offsetof(FAnimNode_ModifyCurve, ApplyMode) == 0x11c, "Offset mismatch for FAnimNode_ModifyCurve::ApplyMode");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FAnimNode_MultiWayBlend : FAnimNode_Base
{
    TArray<FPoseLink> Poses; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<float> DesiredAlphas; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FInputScaleBias AlphaScaleBias; // 0x40 (Size: 0x8, Type: StructProperty)
    bool bAdditiveNode; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bNormalizeAlpha; // 0x49 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_MultiWayBlend) == 0x50, "Size mismatch for FAnimNode_MultiWayBlend");
static_assert(offsetof(FAnimNode_MultiWayBlend, Poses) == 0x10, "Offset mismatch for FAnimNode_MultiWayBlend::Poses");
static_assert(offsetof(FAnimNode_MultiWayBlend, DesiredAlphas) == 0x20, "Offset mismatch for FAnimNode_MultiWayBlend::DesiredAlphas");
static_assert(offsetof(FAnimNode_MultiWayBlend, AlphaScaleBias) == 0x40, "Offset mismatch for FAnimNode_MultiWayBlend::AlphaScaleBias");
static_assert(offsetof(FAnimNode_MultiWayBlend, bAdditiveNode) == 0x48, "Offset mismatch for FAnimNode_MultiWayBlend::bAdditiveNode");
static_assert(offsetof(FAnimNode_MultiWayBlend, bNormalizeAlpha) == 0x49, "Offset mismatch for FAnimNode_MultiWayBlend::bNormalizeAlpha");

// Size: 0xa0 (Inherited: 0x58, Single: 0x48)
struct FAnimNode_PoseHandler : FAnimNode_AssetPlayerBase
{
    UPoseAsset* PoseAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x60]; // 0x40 (Size: 0x60, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_PoseHandler) == 0xa0, "Size mismatch for FAnimNode_PoseHandler");
static_assert(offsetof(FAnimNode_PoseHandler, PoseAsset) == 0x38, "Offset mismatch for FAnimNode_PoseHandler::PoseAsset");

// Size: 0xd8 (Inherited: 0xf8, Single: 0xffffffe0)
struct FAnimNode_PoseBlendNode : FAnimNode_PoseHandler
{
    FPoseLink SourcePose; // 0xa0 (Size: 0x10, Type: StructProperty)
    uint8_t BlendOption; // 0xb0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_b1[0x7]; // 0xb1 (Size: 0x7, Type: PaddingProperty)
    UCurveFloat* CustomCurve; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c0[0x18]; // 0xc0 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_PoseBlendNode) == 0xd8, "Size mismatch for FAnimNode_PoseBlendNode");
static_assert(offsetof(FAnimNode_PoseBlendNode, SourcePose) == 0xa0, "Offset mismatch for FAnimNode_PoseBlendNode::SourcePose");
static_assert(offsetof(FAnimNode_PoseBlendNode, BlendOption) == 0xb0, "Offset mismatch for FAnimNode_PoseBlendNode::BlendOption");
static_assert(offsetof(FAnimNode_PoseBlendNode, CustomCurve) == 0xb8, "Offset mismatch for FAnimNode_PoseBlendNode::CustomCurve");

// Size: 0xb0 (Inherited: 0xf8, Single: 0xffffffb8)
struct FAnimNode_PoseByName : FAnimNode_PoseHandler
{
    FName PoseName; // 0xa0 (Size: 0x4, Type: NameProperty)
    float PoseWeight; // 0xa4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_PoseByName) == 0xb0, "Size mismatch for FAnimNode_PoseByName");
static_assert(offsetof(FAnimNode_PoseByName, PoseName) == 0xa0, "Offset mismatch for FAnimNode_PoseByName::PoseName");
static_assert(offsetof(FAnimNode_PoseByName, PoseWeight) == 0xa4, "Offset mismatch for FAnimNode_PoseByName::PoseWeight");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FPoseDriverTransform
{
    FVector TargetTranslation; // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator TargetRotation; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FPoseDriverTransform) == 0x30, "Size mismatch for FPoseDriverTransform");
static_assert(offsetof(FPoseDriverTransform, TargetTranslation) == 0x0, "Offset mismatch for FPoseDriverTransform::TargetTranslation");
static_assert(offsetof(FPoseDriverTransform, TargetRotation) == 0x18, "Offset mismatch for FPoseDriverTransform::TargetRotation");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FPoseDriverTarget
{
    TArray<FPoseDriverTransform> BoneTransforms; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FRotator TargetRotation; // 0x10 (Size: 0x18, Type: StructProperty)
    float TargetScale; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t DistanceMethod; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t FunctionType; // 0x2d (Size: 0x1, Type: EnumProperty)
    bool bApplyCustomCurve; // 0x2e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f[0x1]; // 0x2f (Size: 0x1, Type: PaddingProperty)
    FRichCurve CustomCurve; // 0x30 (Size: 0x80, Type: StructProperty)
    FName DrivenName; // 0xb0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4[0x8]; // 0xb4 (Size: 0x8, Type: PaddingProperty)
    bool bIsHidden; // 0xbc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bd[0x3]; // 0xbd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FPoseDriverTarget) == 0xc0, "Size mismatch for FPoseDriverTarget");
static_assert(offsetof(FPoseDriverTarget, BoneTransforms) == 0x0, "Offset mismatch for FPoseDriverTarget::BoneTransforms");
static_assert(offsetof(FPoseDriverTarget, TargetRotation) == 0x10, "Offset mismatch for FPoseDriverTarget::TargetRotation");
static_assert(offsetof(FPoseDriverTarget, TargetScale) == 0x28, "Offset mismatch for FPoseDriverTarget::TargetScale");
static_assert(offsetof(FPoseDriverTarget, DistanceMethod) == 0x2c, "Offset mismatch for FPoseDriverTarget::DistanceMethod");
static_assert(offsetof(FPoseDriverTarget, FunctionType) == 0x2d, "Offset mismatch for FPoseDriverTarget::FunctionType");
static_assert(offsetof(FPoseDriverTarget, bApplyCustomCurve) == 0x2e, "Offset mismatch for FPoseDriverTarget::bApplyCustomCurve");
static_assert(offsetof(FPoseDriverTarget, CustomCurve) == 0x30, "Offset mismatch for FPoseDriverTarget::CustomCurve");
static_assert(offsetof(FPoseDriverTarget, DrivenName) == 0xb0, "Offset mismatch for FPoseDriverTarget::DrivenName");
static_assert(offsetof(FPoseDriverTarget, bIsHidden) == 0xbc, "Offset mismatch for FPoseDriverTarget::bIsHidden");

// Size: 0x1a0 (Inherited: 0xf8, Single: 0xa8)
struct FAnimNode_PoseDriver : FAnimNode_PoseHandler
{
    FPoseLink SourcePose; // 0xa0 (Size: 0x10, Type: StructProperty)
    TArray<FBoneReference> SourceBones; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    FBoneReference EvalSpaceBone; // 0xc0 (Size: 0xc, Type: StructProperty)
    bool bEvalFromRefPose; // 0xcc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    TArray<FBoneReference> OnlyDriveBones; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FPoseDriverTarget> PoseTargets; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    FRBFParams RBFParams; // 0xf0 (Size: 0x38, Type: StructProperty)
    uint8_t DriveSource; // 0x128 (Size: 0x1, Type: EnumProperty)
    uint8_t DriveOutput; // 0x129 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_12a[0x42]; // 0x12a (Size: 0x42, Type: PaddingProperty)
    int32_t LODThreshold; // 0x16c (Size: 0x4, Type: IntProperty)
    uint8_t Pad_170[0x30]; // 0x170 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_PoseDriver) == 0x1a0, "Size mismatch for FAnimNode_PoseDriver");
static_assert(offsetof(FAnimNode_PoseDriver, SourcePose) == 0xa0, "Offset mismatch for FAnimNode_PoseDriver::SourcePose");
static_assert(offsetof(FAnimNode_PoseDriver, SourceBones) == 0xb0, "Offset mismatch for FAnimNode_PoseDriver::SourceBones");
static_assert(offsetof(FAnimNode_PoseDriver, EvalSpaceBone) == 0xc0, "Offset mismatch for FAnimNode_PoseDriver::EvalSpaceBone");
static_assert(offsetof(FAnimNode_PoseDriver, bEvalFromRefPose) == 0xcc, "Offset mismatch for FAnimNode_PoseDriver::bEvalFromRefPose");
static_assert(offsetof(FAnimNode_PoseDriver, OnlyDriveBones) == 0xd0, "Offset mismatch for FAnimNode_PoseDriver::OnlyDriveBones");
static_assert(offsetof(FAnimNode_PoseDriver, PoseTargets) == 0xe0, "Offset mismatch for FAnimNode_PoseDriver::PoseTargets");
static_assert(offsetof(FAnimNode_PoseDriver, RBFParams) == 0xf0, "Offset mismatch for FAnimNode_PoseDriver::RBFParams");
static_assert(offsetof(FAnimNode_PoseDriver, DriveSource) == 0x128, "Offset mismatch for FAnimNode_PoseDriver::DriveSource");
static_assert(offsetof(FAnimNode_PoseDriver, DriveOutput) == 0x129, "Offset mismatch for FAnimNode_PoseDriver::DriveOutput");
static_assert(offsetof(FAnimNode_PoseDriver, LODThreshold) == 0x16c, "Offset mismatch for FAnimNode_PoseDriver::LODThreshold");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRBFParams
{
    int32_t TargetDimensions; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t SolverType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float Radius; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bAutomaticRadius; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Function; // 0xd (Size: 0x1, Type: EnumProperty)
    uint8_t DistanceMethod; // 0xe (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EBoneAxis> TwistAxis; // 0xf (Size: 0x1, Type: ByteProperty)
    float WeightThreshold; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t NormalizeMethod; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FVector MedianReference; // 0x18 (Size: 0x18, Type: StructProperty)
    float MedianMin; // 0x30 (Size: 0x4, Type: FloatProperty)
    float MedianMax; // 0x34 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRBFParams) == 0x38, "Size mismatch for FRBFParams");
static_assert(offsetof(FRBFParams, TargetDimensions) == 0x0, "Offset mismatch for FRBFParams::TargetDimensions");
static_assert(offsetof(FRBFParams, SolverType) == 0x4, "Offset mismatch for FRBFParams::SolverType");
static_assert(offsetof(FRBFParams, Radius) == 0x8, "Offset mismatch for FRBFParams::Radius");
static_assert(offsetof(FRBFParams, bAutomaticRadius) == 0xc, "Offset mismatch for FRBFParams::bAutomaticRadius");
static_assert(offsetof(FRBFParams, Function) == 0xd, "Offset mismatch for FRBFParams::Function");
static_assert(offsetof(FRBFParams, DistanceMethod) == 0xe, "Offset mismatch for FRBFParams::DistanceMethod");
static_assert(offsetof(FRBFParams, TwistAxis) == 0xf, "Offset mismatch for FRBFParams::TwistAxis");
static_assert(offsetof(FRBFParams, WeightThreshold) == 0x10, "Offset mismatch for FRBFParams::WeightThreshold");
static_assert(offsetof(FRBFParams, NormalizeMethod) == 0x14, "Offset mismatch for FRBFParams::NormalizeMethod");
static_assert(offsetof(FRBFParams, MedianReference) == 0x18, "Offset mismatch for FRBFParams::MedianReference");
static_assert(offsetof(FRBFParams, MedianMin) == 0x30, "Offset mismatch for FRBFParams::MedianMin");
static_assert(offsetof(FRBFParams, MedianMax) == 0x34, "Offset mismatch for FRBFParams::MedianMax");

// Size: 0x80 (Inherited: 0x10, Single: 0x70)
struct FAnimNode_PoseSnapshot : FAnimNode_Base
{
    FName SnapshotName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FPoseSnapshot Snapshot; // 0x18 (Size: 0x30, Type: StructProperty)
    uint8_t Mode; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_49[0x37]; // 0x49 (Size: 0x37, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_PoseSnapshot) == 0x80, "Size mismatch for FAnimNode_PoseSnapshot");
static_assert(offsetof(FAnimNode_PoseSnapshot, SnapshotName) == 0x10, "Offset mismatch for FAnimNode_PoseSnapshot::SnapshotName");
static_assert(offsetof(FAnimNode_PoseSnapshot, Snapshot) == 0x18, "Offset mismatch for FAnimNode_PoseSnapshot::Snapshot");
static_assert(offsetof(FAnimNode_PoseSnapshot, Mode) == 0x48, "Offset mismatch for FAnimNode_PoseSnapshot::Mode");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FRandomPlayerSequenceEntry
{
    UAnimSequenceBase* Sequence; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float ChanceToPlay; // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t MinLoopCount; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MaxLoopCount; // 0x10 (Size: 0x4, Type: IntProperty)
    float MinPlayRate; // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxPlayRate; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FAlphaBlend BlendIn; // 0x20 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FRandomPlayerSequenceEntry) == 0x50, "Size mismatch for FRandomPlayerSequenceEntry");
static_assert(offsetof(FRandomPlayerSequenceEntry, Sequence) == 0x0, "Offset mismatch for FRandomPlayerSequenceEntry::Sequence");
static_assert(offsetof(FRandomPlayerSequenceEntry, ChanceToPlay) == 0x8, "Offset mismatch for FRandomPlayerSequenceEntry::ChanceToPlay");
static_assert(offsetof(FRandomPlayerSequenceEntry, MinLoopCount) == 0xc, "Offset mismatch for FRandomPlayerSequenceEntry::MinLoopCount");
static_assert(offsetof(FRandomPlayerSequenceEntry, MaxLoopCount) == 0x10, "Offset mismatch for FRandomPlayerSequenceEntry::MaxLoopCount");
static_assert(offsetof(FRandomPlayerSequenceEntry, MinPlayRate) == 0x14, "Offset mismatch for FRandomPlayerSequenceEntry::MinPlayRate");
static_assert(offsetof(FRandomPlayerSequenceEntry, MaxPlayRate) == 0x18, "Offset mismatch for FRandomPlayerSequenceEntry::MaxPlayRate");
static_assert(offsetof(FRandomPlayerSequenceEntry, BlendIn) == 0x20, "Offset mismatch for FRandomPlayerSequenceEntry::BlendIn");

// Size: 0x78 (Inherited: 0x20, Single: 0x58)
struct FAnimNode_RandomPlayer : FAnimNode_AssetPlayerRelevancyBase
{
    TArray<FRandomPlayerSequenceEntry> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_20[0x50]; // 0x20 (Size: 0x50, Type: PaddingProperty)
    float BlendWeight; // 0x70 (Size: 0x4, Type: FloatProperty)
    bool bShuffleMode; // 0x74 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_75[0x3]; // 0x75 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RandomPlayer) == 0x78, "Size mismatch for FAnimNode_RandomPlayer");
static_assert(offsetof(FAnimNode_RandomPlayer, Entries) == 0x10, "Offset mismatch for FAnimNode_RandomPlayer::Entries");
static_assert(offsetof(FAnimNode_RandomPlayer, BlendWeight) == 0x70, "Offset mismatch for FAnimNode_RandomPlayer::BlendWeight");
static_assert(offsetof(FAnimNode_RandomPlayer, bShuffleMode) == 0x74, "Offset mismatch for FAnimNode_RandomPlayer::bShuffleMode");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FAnimNode_RotateRootBone : FAnimNode_Base
{
    FPoseLink BasePose; // 0x10 (Size: 0x10, Type: StructProperty)
    float pitch; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Yaw; // 0x24 (Size: 0x4, Type: FloatProperty)
    FInputScaleBiasClamp PitchScaleBiasClamp; // 0x28 (Size: 0x30, Type: StructProperty)
    FInputScaleBiasClamp YawScaleBiasClamp; // 0x58 (Size: 0x30, Type: StructProperty)
    FRotator MeshToComponent; // 0x88 (Size: 0x18, Type: StructProperty)
    bool bRotateRootMotionAttribute; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0xf]; // 0xa1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RotateRootBone) == 0xb0, "Size mismatch for FAnimNode_RotateRootBone");
static_assert(offsetof(FAnimNode_RotateRootBone, BasePose) == 0x10, "Offset mismatch for FAnimNode_RotateRootBone::BasePose");
static_assert(offsetof(FAnimNode_RotateRootBone, pitch) == 0x20, "Offset mismatch for FAnimNode_RotateRootBone::pitch");
static_assert(offsetof(FAnimNode_RotateRootBone, Yaw) == 0x24, "Offset mismatch for FAnimNode_RotateRootBone::Yaw");
static_assert(offsetof(FAnimNode_RotateRootBone, PitchScaleBiasClamp) == 0x28, "Offset mismatch for FAnimNode_RotateRootBone::PitchScaleBiasClamp");
static_assert(offsetof(FAnimNode_RotateRootBone, YawScaleBiasClamp) == 0x58, "Offset mismatch for FAnimNode_RotateRootBone::YawScaleBiasClamp");
static_assert(offsetof(FAnimNode_RotateRootBone, MeshToComponent) == 0x88, "Offset mismatch for FAnimNode_RotateRootBone::MeshToComponent");
static_assert(offsetof(FAnimNode_RotateRootBone, bRotateRootMotionAttribute) == 0xa0, "Offset mismatch for FAnimNode_RotateRootBone::bRotateRootMotionAttribute");

// Size: 0x118 (Inherited: 0x130, Single: 0xffffffe8)
struct FAnimNode_RotationOffsetBlendSpace : FAnimNode_BlendSpacePlayer
{
    FPoseLink BasePose; // 0x70 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold; // 0x80 (Size: 0x4, Type: IntProperty)
    float Alpha; // 0x84 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias; // 0x88 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend; // 0x90 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName; // 0xd8 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp; // 0xdc (Size: 0x30, Type: StructProperty)
    uint8_t Pad_10c[0x4]; // 0x10c (Size: 0x4, Type: PaddingProperty)
    uint8_t AlphaInputType; // 0x110 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled; // 0x111 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_112[0x6]; // 0x112 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RotationOffsetBlendSpace) == 0x118, "Size mismatch for FAnimNode_RotationOffsetBlendSpace");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, BasePose) == 0x70, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::BasePose");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, LODThreshold) == 0x80, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::LODThreshold");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, Alpha) == 0x84, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::Alpha");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, AlphaScaleBias) == 0x88, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::AlphaScaleBias");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, AlphaBoolBlend) == 0x90, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::AlphaBoolBlend");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, AlphaCurveName) == 0xd8, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::AlphaCurveName");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, AlphaScaleBiasClamp) == 0xdc, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::AlphaScaleBiasClamp");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, AlphaInputType) == 0x110, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::AlphaInputType");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpace, bAlphaBoolEnabled) == 0x111, "Offset mismatch for FAnimNode_RotationOffsetBlendSpace::bAlphaBoolEnabled");

// Size: 0x108 (Inherited: 0x70, Single: 0x98)
struct FAnimNode_RotationOffsetBlendSpaceGraph : FAnimNode_BlendSpaceGraphBase
{
    FPoseLink BasePose; // 0x60 (Size: 0x10, Type: StructProperty)
    int32_t LODThreshold; // 0x70 (Size: 0x4, Type: IntProperty)
    float Alpha; // 0x74 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias; // 0x78 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend; // 0x80 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName; // 0xc8 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp; // 0xcc (Size: 0x30, Type: StructProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
    uint8_t AlphaInputType; // 0x100 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled; // 0x101 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_102[0x6]; // 0x102 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RotationOffsetBlendSpaceGraph) == 0x108, "Size mismatch for FAnimNode_RotationOffsetBlendSpaceGraph");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, BasePose) == 0x60, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::BasePose");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, LODThreshold) == 0x70, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::LODThreshold");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, Alpha) == 0x74, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::Alpha");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, AlphaScaleBias) == 0x78, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::AlphaScaleBias");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, AlphaBoolBlend) == 0x80, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::AlphaBoolBlend");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, AlphaCurveName) == 0xc8, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::AlphaCurveName");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, AlphaScaleBiasClamp) == 0xcc, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::AlphaScaleBiasClamp");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, AlphaInputType) == 0x100, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::AlphaInputType");
static_assert(offsetof(FAnimNode_RotationOffsetBlendSpaceGraph, bAlphaBoolEnabled) == 0x101, "Offset mismatch for FAnimNode_RotationOffsetBlendSpaceGraph::bAlphaBoolEnabled");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
struct FAnimNode_SequenceEvaluatorBase : FAnimNode_AssetPlayerBase
{
};

static_assert(sizeof(FAnimNode_SequenceEvaluatorBase) == 0x40, "Size mismatch for FAnimNode_SequenceEvaluatorBase");

// Size: 0x40 (Inherited: 0x98, Single: 0xffffffa8)
struct FAnimNode_SequenceEvaluator : FAnimNode_SequenceEvaluatorBase
{
};

static_assert(sizeof(FAnimNode_SequenceEvaluator) == 0x40, "Size mismatch for FAnimNode_SequenceEvaluator");

// Size: 0x68 (Inherited: 0x98, Single: 0xffffffd0)
struct FAnimNode_SequenceEvaluator_Standalone : FAnimNode_SequenceEvaluatorBase
{
    FName GroupName; // 0x40 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole; // 0x44 (Size: 0x1, Type: ByteProperty)
    uint8_t Method; // 0x45 (Size: 0x1, Type: EnumProperty)
    bool bIgnoreForRelevancyTest; // 0x46 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_47[0x1]; // 0x47 (Size: 0x1, Type: PaddingProperty)
    UAnimSequenceBase* Sequence; // 0x48 (Size: 0x8, Type: ObjectProperty)
    float ExplicitTime; // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bUseExplicitFrame; // 0x54 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
    int32_t ExplicitFrame; // 0x58 (Size: 0x4, Type: IntProperty)
    bool bShouldLoop; // 0x5c (Size: 0x1, Type: BoolProperty)
    bool bTeleportToExplicitTime; // 0x5d (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ESequenceEvalReinit> ReinitializationBehavior; // 0x5e (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5f[0x1]; // 0x5f (Size: 0x1, Type: PaddingProperty)
    float StartPosition; // 0x60 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_SequenceEvaluator_Standalone) == 0x68, "Size mismatch for FAnimNode_SequenceEvaluator_Standalone");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, GroupName) == 0x40, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::GroupName");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, GroupRole) == 0x44, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::GroupRole");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, Method) == 0x45, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::Method");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, bIgnoreForRelevancyTest) == 0x46, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::bIgnoreForRelevancyTest");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, Sequence) == 0x48, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::Sequence");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, ExplicitTime) == 0x50, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::ExplicitTime");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, bUseExplicitFrame) == 0x54, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::bUseExplicitFrame");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, ExplicitFrame) == 0x58, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::ExplicitFrame");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, bShouldLoop) == 0x5c, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::bShouldLoop");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, bTeleportToExplicitTime) == 0x5d, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::bTeleportToExplicitTime");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, ReinitializationBehavior) == 0x5e, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::ReinitializationBehavior");
static_assert(offsetof(FAnimNode_SequenceEvaluator_Standalone, StartPosition) == 0x60, "Offset mismatch for FAnimNode_SequenceEvaluator_Standalone::StartPosition");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FAnimNode_Slot : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
    FName SlotName; // 0x20 (Size: 0x4, Type: NameProperty)
    bool bAlwaysUpdateSourcePose; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x23]; // 0x25 (Size: 0x23, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_Slot) == 0x48, "Size mismatch for FAnimNode_Slot");
static_assert(offsetof(FAnimNode_Slot, Source) == 0x10, "Offset mismatch for FAnimNode_Slot::Source");
static_assert(offsetof(FAnimNode_Slot, SlotName) == 0x20, "Offset mismatch for FAnimNode_Slot::SlotName");
static_assert(offsetof(FAnimNode_Slot, bAlwaysUpdateSourcePose) == 0x24, "Offset mismatch for FAnimNode_Slot::bAlwaysUpdateSourcePose");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FAnimNode_Sync : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
    FName GroupName; // 0x20 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> GroupRole; // 0x24 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_Sync) == 0x28, "Size mismatch for FAnimNode_Sync");
static_assert(offsetof(FAnimNode_Sync, Source) == 0x10, "Offset mismatch for FAnimNode_Sync::Source");
static_assert(offsetof(FAnimNode_Sync, GroupName) == 0x20, "Offset mismatch for FAnimNode_Sync::GroupName");
static_assert(offsetof(FAnimNode_Sync, GroupRole) == 0x24, "Offset mismatch for FAnimNode_Sync::GroupRole");

// Size: 0xc0 (Inherited: 0x10, Single: 0xb0)
struct FAnimNode_TwoWayBlend : FAnimNode_Base
{
    FPoseLink A; // 0x10 (Size: 0x10, Type: StructProperty)
    FPoseLink B; // 0x20 (Size: 0x10, Type: StructProperty)
    uint8_t AlphaInputType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t bAlphaBoolEnabled : 1; // 0x31:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bResetChildOnActivation : 1; // 0x31:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bAlwaysUpdateChildren : 1; // 0x31:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float Alpha; // 0x34 (Size: 0x4, Type: FloatProperty)
    FInputScaleBias AlphaScaleBias; // 0x38 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend; // 0x40 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName; // 0x88 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x8c (Size: 0x30, Type: StructProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_TwoWayBlend) == 0xc0, "Size mismatch for FAnimNode_TwoWayBlend");
static_assert(offsetof(FAnimNode_TwoWayBlend, A) == 0x10, "Offset mismatch for FAnimNode_TwoWayBlend::A");
static_assert(offsetof(FAnimNode_TwoWayBlend, B) == 0x20, "Offset mismatch for FAnimNode_TwoWayBlend::B");
static_assert(offsetof(FAnimNode_TwoWayBlend, AlphaInputType) == 0x30, "Offset mismatch for FAnimNode_TwoWayBlend::AlphaInputType");
static_assert(offsetof(FAnimNode_TwoWayBlend, bAlphaBoolEnabled) == 0x31, "Offset mismatch for FAnimNode_TwoWayBlend::bAlphaBoolEnabled");
static_assert(offsetof(FAnimNode_TwoWayBlend, bResetChildOnActivation) == 0x31, "Offset mismatch for FAnimNode_TwoWayBlend::bResetChildOnActivation");
static_assert(offsetof(FAnimNode_TwoWayBlend, bAlwaysUpdateChildren) == 0x31, "Offset mismatch for FAnimNode_TwoWayBlend::bAlwaysUpdateChildren");
static_assert(offsetof(FAnimNode_TwoWayBlend, Alpha) == 0x34, "Offset mismatch for FAnimNode_TwoWayBlend::Alpha");
static_assert(offsetof(FAnimNode_TwoWayBlend, AlphaScaleBias) == 0x38, "Offset mismatch for FAnimNode_TwoWayBlend::AlphaScaleBias");
static_assert(offsetof(FAnimNode_TwoWayBlend, AlphaBoolBlend) == 0x40, "Offset mismatch for FAnimNode_TwoWayBlend::AlphaBoolBlend");
static_assert(offsetof(FAnimNode_TwoWayBlend, AlphaCurveName) == 0x88, "Offset mismatch for FAnimNode_TwoWayBlend::AlphaCurveName");
static_assert(offsetof(FAnimNode_TwoWayBlend, AlphaScaleBiasClamp) == 0x8c, "Offset mismatch for FAnimNode_TwoWayBlend::AlphaScaleBiasClamp");

// Size: 0xbf0 (Inherited: 0x7a0, Single: 0x450)
struct FAnimSequencerInstanceProxy : FAnimInstanceProxy
{
};

static_assert(sizeof(FAnimSequencerInstanceProxy) == 0xbf0, "Size mismatch for FAnimSequencerInstanceProxy");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FBlendListBaseReference : FAnimNodeReference
{
};

static_assert(sizeof(FBlendListBaseReference) == 0x10, "Size mismatch for FBlendListBaseReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FBlendSpacePlayerReference : FAnimNodeReference
{
};

static_assert(sizeof(FBlendSpacePlayerReference) == 0x10, "Size mismatch for FBlendSpacePlayerReference");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FAnimPhysConstraintSetup
{
    uint8_t LinearXLimitType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LinearYLimitType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t LinearZLimitType; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x5]; // 0x3 (Size: 0x5, Type: PaddingProperty)
    FVector LinearAxesMin; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector LinearAxesMax; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t AngularConstraintType; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t TwistAxis; // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t AngularTargetAxis; // 0x3a (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3b[0x1]; // 0x3b (Size: 0x1, Type: PaddingProperty)
    float ConeAngle; // 0x3c (Size: 0x4, Type: FloatProperty)
    FVector AngularLimitsMin; // 0x40 (Size: 0x18, Type: StructProperty)
    FVector AngularLimitsMax; // 0x58 (Size: 0x18, Type: StructProperty)
    FVector AngularTarget; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAnimPhysConstraintSetup) == 0x88, "Size mismatch for FAnimPhysConstraintSetup");
static_assert(offsetof(FAnimPhysConstraintSetup, LinearXLimitType) == 0x0, "Offset mismatch for FAnimPhysConstraintSetup::LinearXLimitType");
static_assert(offsetof(FAnimPhysConstraintSetup, LinearYLimitType) == 0x1, "Offset mismatch for FAnimPhysConstraintSetup::LinearYLimitType");
static_assert(offsetof(FAnimPhysConstraintSetup, LinearZLimitType) == 0x2, "Offset mismatch for FAnimPhysConstraintSetup::LinearZLimitType");
static_assert(offsetof(FAnimPhysConstraintSetup, LinearAxesMin) == 0x8, "Offset mismatch for FAnimPhysConstraintSetup::LinearAxesMin");
static_assert(offsetof(FAnimPhysConstraintSetup, LinearAxesMax) == 0x20, "Offset mismatch for FAnimPhysConstraintSetup::LinearAxesMax");
static_assert(offsetof(FAnimPhysConstraintSetup, AngularConstraintType) == 0x38, "Offset mismatch for FAnimPhysConstraintSetup::AngularConstraintType");
static_assert(offsetof(FAnimPhysConstraintSetup, TwistAxis) == 0x39, "Offset mismatch for FAnimPhysConstraintSetup::TwistAxis");
static_assert(offsetof(FAnimPhysConstraintSetup, AngularTargetAxis) == 0x3a, "Offset mismatch for FAnimPhysConstraintSetup::AngularTargetAxis");
static_assert(offsetof(FAnimPhysConstraintSetup, ConeAngle) == 0x3c, "Offset mismatch for FAnimPhysConstraintSetup::ConeAngle");
static_assert(offsetof(FAnimPhysConstraintSetup, AngularLimitsMin) == 0x40, "Offset mismatch for FAnimPhysConstraintSetup::AngularLimitsMin");
static_assert(offsetof(FAnimPhysConstraintSetup, AngularLimitsMax) == 0x58, "Offset mismatch for FAnimPhysConstraintSetup::AngularLimitsMax");
static_assert(offsetof(FAnimPhysConstraintSetup, AngularTarget) == 0x70, "Offset mismatch for FAnimPhysConstraintSetup::AngularTarget");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FAnimPhysPlanarLimit
{
    FBoneReference DrivingBone; // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform PlaneTransform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FAnimPhysPlanarLimit) == 0x70, "Size mismatch for FAnimPhysPlanarLimit");
static_assert(offsetof(FAnimPhysPlanarLimit, DrivingBone) == 0x0, "Offset mismatch for FAnimPhysPlanarLimit::DrivingBone");
static_assert(offsetof(FAnimPhysPlanarLimit, PlaneTransform) == 0x10, "Offset mismatch for FAnimPhysPlanarLimit::PlaneTransform");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAnimPhysSphericalLimit
{
    FBoneReference DrivingBone; // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector SphereLocalOffset; // 0x10 (Size: 0x18, Type: StructProperty)
    float LimitRadius; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t LimitType; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimPhysSphericalLimit) == 0x30, "Size mismatch for FAnimPhysSphericalLimit");
static_assert(offsetof(FAnimPhysSphericalLimit, DrivingBone) == 0x0, "Offset mismatch for FAnimPhysSphericalLimit::DrivingBone");
static_assert(offsetof(FAnimPhysSphericalLimit, SphereLocalOffset) == 0x10, "Offset mismatch for FAnimPhysSphericalLimit::SphereLocalOffset");
static_assert(offsetof(FAnimPhysSphericalLimit, LimitRadius) == 0x28, "Offset mismatch for FAnimPhysSphericalLimit::LimitRadius");
static_assert(offsetof(FAnimPhysSphericalLimit, LimitType) == 0x2c, "Offset mismatch for FAnimPhysSphericalLimit::LimitType");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FAnimPhysBodyDefinition
{
    FBoneReference BoundBone; // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector BoxExtents; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector LocalJointOffset; // 0x28 (Size: 0x18, Type: StructProperty)
    FAnimPhysConstraintSetup ConstraintSetup; // 0x40 (Size: 0x88, Type: StructProperty)
    uint8_t CollisionType; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c9[0x3]; // 0xc9 (Size: 0x3, Type: PaddingProperty)
    float SphereCollisionRadius; // 0xcc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAnimPhysBodyDefinition) == 0xd0, "Size mismatch for FAnimPhysBodyDefinition");
static_assert(offsetof(FAnimPhysBodyDefinition, BoundBone) == 0x0, "Offset mismatch for FAnimPhysBodyDefinition::BoundBone");
static_assert(offsetof(FAnimPhysBodyDefinition, BoxExtents) == 0x10, "Offset mismatch for FAnimPhysBodyDefinition::BoxExtents");
static_assert(offsetof(FAnimPhysBodyDefinition, LocalJointOffset) == 0x28, "Offset mismatch for FAnimPhysBodyDefinition::LocalJointOffset");
static_assert(offsetof(FAnimPhysBodyDefinition, ConstraintSetup) == 0x40, "Offset mismatch for FAnimPhysBodyDefinition::ConstraintSetup");
static_assert(offsetof(FAnimPhysBodyDefinition, CollisionType) == 0xc8, "Offset mismatch for FAnimPhysBodyDefinition::CollisionType");
static_assert(offsetof(FAnimPhysBodyDefinition, SphereCollisionRadius) == 0xcc, "Offset mismatch for FAnimPhysBodyDefinition::SphereCollisionRadius");

// Size: 0x510 (Inherited: 0xd8, Single: 0x438)
struct FAnimNode_AnimDynamics : FAnimNode_SkeletalControlBase
{
    float LinearDampingOverride; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float AngularDampingOverride; // 0xcc (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_d0[0xc0]; // 0xd0 (Size: 0xc0, Type: PaddingProperty)
    FBoneReference RelativeSpaceBone; // 0x190 (Size: 0xc, Type: StructProperty)
    FBoneReference BoundBone; // 0x19c (Size: 0xc, Type: StructProperty)
    FBoneReference ChainEnd; // 0x1a8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1b4[0x4]; // 0x1b4 (Size: 0x4, Type: PaddingProperty)
    TArray<FAnimPhysBodyDefinition> PhysicsBodyDefinitions; // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    float GravityScale; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1cc[0x4]; // 0x1cc (Size: 0x4, Type: PaddingProperty)
    FVector GravityOverride; // 0x1d0 (Size: 0x18, Type: StructProperty)
    float LinearSpringConstant; // 0x1e8 (Size: 0x4, Type: FloatProperty)
    float AngularSpringConstant; // 0x1ec (Size: 0x4, Type: FloatProperty)
    float WindScale; // 0x1f0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1f4[0x4]; // 0x1f4 (Size: 0x4, Type: PaddingProperty)
    FVector ComponentLinearAccScale; // 0x1f8 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearVelScale; // 0x210 (Size: 0x18, Type: StructProperty)
    FVector ComponentAppliedLinearAccClamp; // 0x228 (Size: 0x18, Type: StructProperty)
    float AngularBiasOverride; // 0x240 (Size: 0x4, Type: FloatProperty)
    int32_t NumSolverIterationsPreUpdate; // 0x244 (Size: 0x4, Type: IntProperty)
    int32_t NumSolverIterationsPostUpdate; // 0x248 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24c[0x4]; // 0x24c (Size: 0x4, Type: PaddingProperty)
    TArray<FAnimPhysSphericalLimit> SphericalLimits; // 0x250 (Size: 0x10, Type: ArrayProperty)
    FVector ExternalForce; // 0x260 (Size: 0x18, Type: StructProperty)
    TArray<FAnimPhysPlanarLimit> PlanarLimits; // 0x278 (Size: 0x10, Type: ArrayProperty)
    uint8_t SimulationSpace; // 0x288 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_289[0x2]; // 0x289 (Size: 0x2, Type: PaddingProperty)
    uint8_t bUseSphericalLimits : 1; // 0x28b:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUsePlanarLimit : 1; // 0x28b:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bDoUpdate : 1; // 0x28b:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bDoEval : 1; // 0x28b:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideLinearDamping : 1; // 0x28b:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideAngularBias : 1; // 0x28b:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideAngularDamping : 1; // 0x28b:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableWind : 1; // 0x28b:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseGravityOverride : 1; // 0x28c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bGravityOverrideInSimSpace : 1; // 0x28c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bLinearSpring : 1; // 0x28c:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularSpring : 1; // 0x28c:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bChain : 1; // 0x28c:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_28d[0x3]; // 0x28d (Size: 0x3, Type: PaddingProperty)
    FRotationRetargetingInfo RetargetingSettings; // 0x290 (Size: 0x1a0, Type: StructProperty)
    uint8_t Pad_430[0xe0]; // 0x430 (Size: 0xe0, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_AnimDynamics) == 0x510, "Size mismatch for FAnimNode_AnimDynamics");
static_assert(offsetof(FAnimNode_AnimDynamics, LinearDampingOverride) == 0xc8, "Offset mismatch for FAnimNode_AnimDynamics::LinearDampingOverride");
static_assert(offsetof(FAnimNode_AnimDynamics, AngularDampingOverride) == 0xcc, "Offset mismatch for FAnimNode_AnimDynamics::AngularDampingOverride");
static_assert(offsetof(FAnimNode_AnimDynamics, RelativeSpaceBone) == 0x190, "Offset mismatch for FAnimNode_AnimDynamics::RelativeSpaceBone");
static_assert(offsetof(FAnimNode_AnimDynamics, BoundBone) == 0x19c, "Offset mismatch for FAnimNode_AnimDynamics::BoundBone");
static_assert(offsetof(FAnimNode_AnimDynamics, ChainEnd) == 0x1a8, "Offset mismatch for FAnimNode_AnimDynamics::ChainEnd");
static_assert(offsetof(FAnimNode_AnimDynamics, PhysicsBodyDefinitions) == 0x1b8, "Offset mismatch for FAnimNode_AnimDynamics::PhysicsBodyDefinitions");
static_assert(offsetof(FAnimNode_AnimDynamics, GravityScale) == 0x1c8, "Offset mismatch for FAnimNode_AnimDynamics::GravityScale");
static_assert(offsetof(FAnimNode_AnimDynamics, GravityOverride) == 0x1d0, "Offset mismatch for FAnimNode_AnimDynamics::GravityOverride");
static_assert(offsetof(FAnimNode_AnimDynamics, LinearSpringConstant) == 0x1e8, "Offset mismatch for FAnimNode_AnimDynamics::LinearSpringConstant");
static_assert(offsetof(FAnimNode_AnimDynamics, AngularSpringConstant) == 0x1ec, "Offset mismatch for FAnimNode_AnimDynamics::AngularSpringConstant");
static_assert(offsetof(FAnimNode_AnimDynamics, WindScale) == 0x1f0, "Offset mismatch for FAnimNode_AnimDynamics::WindScale");
static_assert(offsetof(FAnimNode_AnimDynamics, ComponentLinearAccScale) == 0x1f8, "Offset mismatch for FAnimNode_AnimDynamics::ComponentLinearAccScale");
static_assert(offsetof(FAnimNode_AnimDynamics, ComponentLinearVelScale) == 0x210, "Offset mismatch for FAnimNode_AnimDynamics::ComponentLinearVelScale");
static_assert(offsetof(FAnimNode_AnimDynamics, ComponentAppliedLinearAccClamp) == 0x228, "Offset mismatch for FAnimNode_AnimDynamics::ComponentAppliedLinearAccClamp");
static_assert(offsetof(FAnimNode_AnimDynamics, AngularBiasOverride) == 0x240, "Offset mismatch for FAnimNode_AnimDynamics::AngularBiasOverride");
static_assert(offsetof(FAnimNode_AnimDynamics, NumSolverIterationsPreUpdate) == 0x244, "Offset mismatch for FAnimNode_AnimDynamics::NumSolverIterationsPreUpdate");
static_assert(offsetof(FAnimNode_AnimDynamics, NumSolverIterationsPostUpdate) == 0x248, "Offset mismatch for FAnimNode_AnimDynamics::NumSolverIterationsPostUpdate");
static_assert(offsetof(FAnimNode_AnimDynamics, SphericalLimits) == 0x250, "Offset mismatch for FAnimNode_AnimDynamics::SphericalLimits");
static_assert(offsetof(FAnimNode_AnimDynamics, ExternalForce) == 0x260, "Offset mismatch for FAnimNode_AnimDynamics::ExternalForce");
static_assert(offsetof(FAnimNode_AnimDynamics, PlanarLimits) == 0x278, "Offset mismatch for FAnimNode_AnimDynamics::PlanarLimits");
static_assert(offsetof(FAnimNode_AnimDynamics, SimulationSpace) == 0x288, "Offset mismatch for FAnimNode_AnimDynamics::SimulationSpace");
static_assert(offsetof(FAnimNode_AnimDynamics, bUseSphericalLimits) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bUseSphericalLimits");
static_assert(offsetof(FAnimNode_AnimDynamics, bUsePlanarLimit) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bUsePlanarLimit");
static_assert(offsetof(FAnimNode_AnimDynamics, bDoUpdate) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bDoUpdate");
static_assert(offsetof(FAnimNode_AnimDynamics, bDoEval) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bDoEval");
static_assert(offsetof(FAnimNode_AnimDynamics, bOverrideLinearDamping) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bOverrideLinearDamping");
static_assert(offsetof(FAnimNode_AnimDynamics, bOverrideAngularBias) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bOverrideAngularBias");
static_assert(offsetof(FAnimNode_AnimDynamics, bOverrideAngularDamping) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bOverrideAngularDamping");
static_assert(offsetof(FAnimNode_AnimDynamics, bEnableWind) == 0x28b, "Offset mismatch for FAnimNode_AnimDynamics::bEnableWind");
static_assert(offsetof(FAnimNode_AnimDynamics, bUseGravityOverride) == 0x28c, "Offset mismatch for FAnimNode_AnimDynamics::bUseGravityOverride");
static_assert(offsetof(FAnimNode_AnimDynamics, bGravityOverrideInSimSpace) == 0x28c, "Offset mismatch for FAnimNode_AnimDynamics::bGravityOverrideInSimSpace");
static_assert(offsetof(FAnimNode_AnimDynamics, bLinearSpring) == 0x28c, "Offset mismatch for FAnimNode_AnimDynamics::bLinearSpring");
static_assert(offsetof(FAnimNode_AnimDynamics, bAngularSpring) == 0x28c, "Offset mismatch for FAnimNode_AnimDynamics::bAngularSpring");
static_assert(offsetof(FAnimNode_AnimDynamics, bChain) == 0x28c, "Offset mismatch for FAnimNode_AnimDynamics::bChain");
static_assert(offsetof(FAnimNode_AnimDynamics, RetargetingSettings) == 0x290, "Offset mismatch for FAnimNode_AnimDynamics::RetargetingSettings");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FAngularRangeLimit
{
    FVector LimitMin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector LimitMax; // 0x18 (Size: 0x18, Type: StructProperty)
    FBoneReference bone; // 0x30 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAngularRangeLimit) == 0x40, "Size mismatch for FAngularRangeLimit");
static_assert(offsetof(FAngularRangeLimit, LimitMin) == 0x0, "Offset mismatch for FAngularRangeLimit::LimitMin");
static_assert(offsetof(FAngularRangeLimit, LimitMax) == 0x18, "Offset mismatch for FAngularRangeLimit::LimitMax");
static_assert(offsetof(FAngularRangeLimit, bone) == 0x30, "Offset mismatch for FAngularRangeLimit::bone");

// Size: 0xe8 (Inherited: 0xd8, Single: 0x10)
struct FAnimNode_ApplyLimits : FAnimNode_SkeletalControlBase
{
    TArray<FAngularRangeLimit> AngularRangeLimits; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> AngularOffsets; // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAnimNode_ApplyLimits) == 0xe8, "Size mismatch for FAnimNode_ApplyLimits");
static_assert(offsetof(FAnimNode_ApplyLimits, AngularRangeLimits) == 0xc8, "Offset mismatch for FAnimNode_ApplyLimits::AngularRangeLimits");
static_assert(offsetof(FAnimNode_ApplyLimits, AngularOffsets) == 0xd8, "Offset mismatch for FAnimNode_ApplyLimits::AngularOffsets");

// Size: 0x120 (Inherited: 0xd8, Single: 0x48)
struct FAnimNode_BoneDrivenController : FAnimNode_SkeletalControlBase
{
    FBoneReference SourceBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    UCurveFloat* DrivingCurve; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    float Multiplier; // 0xe0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_e4[0x4]; // 0xe4 (Size: 0x4, Type: PaddingProperty)
    double RangeMin; // 0xe8 (Size: 0x8, Type: DoubleProperty)
    double RangeMax; // 0xf0 (Size: 0x8, Type: DoubleProperty)
    double RemappedMin; // 0xf8 (Size: 0x8, Type: DoubleProperty)
    double RemappedMax; // 0x100 (Size: 0x8, Type: DoubleProperty)
    FName ParameterName; // 0x108 (Size: 0x4, Type: NameProperty)
    FBoneReference TargetBone; // 0x10c (Size: 0xc, Type: StructProperty)
    uint8_t DestinationMode; // 0x118 (Size: 0x1, Type: EnumProperty)
    uint8_t ModificationMode; // 0x119 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EComponentType> SourceComponent; // 0x11a (Size: 0x1, Type: ByteProperty)
    uint8_t bUseRange : 1; // 0x11b:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetTranslationX : 1; // 0x11b:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetTranslationY : 1; // 0x11b:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetTranslationZ : 1; // 0x11b:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetRotationX : 1; // 0x11b:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetRotationY : 1; // 0x11b:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetRotationZ : 1; // 0x11b:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetScaleX : 1; // 0x11b:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetScaleY : 1; // 0x11c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAffectTargetScaleZ : 1; // 0x11c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11d[0x3]; // 0x11d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BoneDrivenController) == 0x120, "Size mismatch for FAnimNode_BoneDrivenController");
static_assert(offsetof(FAnimNode_BoneDrivenController, SourceBone) == 0xc8, "Offset mismatch for FAnimNode_BoneDrivenController::SourceBone");
static_assert(offsetof(FAnimNode_BoneDrivenController, DrivingCurve) == 0xd8, "Offset mismatch for FAnimNode_BoneDrivenController::DrivingCurve");
static_assert(offsetof(FAnimNode_BoneDrivenController, Multiplier) == 0xe0, "Offset mismatch for FAnimNode_BoneDrivenController::Multiplier");
static_assert(offsetof(FAnimNode_BoneDrivenController, RangeMin) == 0xe8, "Offset mismatch for FAnimNode_BoneDrivenController::RangeMin");
static_assert(offsetof(FAnimNode_BoneDrivenController, RangeMax) == 0xf0, "Offset mismatch for FAnimNode_BoneDrivenController::RangeMax");
static_assert(offsetof(FAnimNode_BoneDrivenController, RemappedMin) == 0xf8, "Offset mismatch for FAnimNode_BoneDrivenController::RemappedMin");
static_assert(offsetof(FAnimNode_BoneDrivenController, RemappedMax) == 0x100, "Offset mismatch for FAnimNode_BoneDrivenController::RemappedMax");
static_assert(offsetof(FAnimNode_BoneDrivenController, ParameterName) == 0x108, "Offset mismatch for FAnimNode_BoneDrivenController::ParameterName");
static_assert(offsetof(FAnimNode_BoneDrivenController, TargetBone) == 0x10c, "Offset mismatch for FAnimNode_BoneDrivenController::TargetBone");
static_assert(offsetof(FAnimNode_BoneDrivenController, DestinationMode) == 0x118, "Offset mismatch for FAnimNode_BoneDrivenController::DestinationMode");
static_assert(offsetof(FAnimNode_BoneDrivenController, ModificationMode) == 0x119, "Offset mismatch for FAnimNode_BoneDrivenController::ModificationMode");
static_assert(offsetof(FAnimNode_BoneDrivenController, SourceComponent) == 0x11a, "Offset mismatch for FAnimNode_BoneDrivenController::SourceComponent");
static_assert(offsetof(FAnimNode_BoneDrivenController, bUseRange) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bUseRange");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetTranslationX) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetTranslationX");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetTranslationY) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetTranslationY");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetTranslationZ) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetTranslationZ");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetRotationX) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetRotationX");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetRotationY) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetRotationY");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetRotationZ) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetRotationZ");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetScaleX) == 0x11b, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetScaleX");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetScaleY) == 0x11c, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetScaleY");
static_assert(offsetof(FAnimNode_BoneDrivenController, bAffectTargetScaleZ) == 0x11c, "Offset mismatch for FAnimNode_BoneDrivenController::bAffectTargetScaleZ");

// Size: 0x1b0 (Inherited: 0xd8, Single: 0xd8)
struct FAnimNode_CCDIK : FAnimNode_SkeletalControlBase
{
    FVector EffectorLocation; // 0xc8 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> EffectorLocationSpace; // 0xe0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e1[0xf]; // 0xe1 (Size: 0xf, Type: PaddingProperty)
    FBoneSocketTarget EffectorTarget; // 0xf0 (Size: 0x80, Type: StructProperty)
    FBoneReference TipBone; // 0x170 (Size: 0xc, Type: StructProperty)
    FBoneReference RootBone; // 0x17c (Size: 0xc, Type: StructProperty)
    float Precision; // 0x188 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0x18c (Size: 0x4, Type: IntProperty)
    bool bStartFromTail; // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bEnableRotationLimit; // 0x191 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_192[0x6]; // 0x192 (Size: 0x6, Type: PaddingProperty)
    TArray<float> RotationLimitPerJoints; // 0x198 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_CCDIK) == 0x1b0, "Size mismatch for FAnimNode_CCDIK");
static_assert(offsetof(FAnimNode_CCDIK, EffectorLocation) == 0xc8, "Offset mismatch for FAnimNode_CCDIK::EffectorLocation");
static_assert(offsetof(FAnimNode_CCDIK, EffectorLocationSpace) == 0xe0, "Offset mismatch for FAnimNode_CCDIK::EffectorLocationSpace");
static_assert(offsetof(FAnimNode_CCDIK, EffectorTarget) == 0xf0, "Offset mismatch for FAnimNode_CCDIK::EffectorTarget");
static_assert(offsetof(FAnimNode_CCDIK, TipBone) == 0x170, "Offset mismatch for FAnimNode_CCDIK::TipBone");
static_assert(offsetof(FAnimNode_CCDIK, RootBone) == 0x17c, "Offset mismatch for FAnimNode_CCDIK::RootBone");
static_assert(offsetof(FAnimNode_CCDIK, Precision) == 0x188, "Offset mismatch for FAnimNode_CCDIK::Precision");
static_assert(offsetof(FAnimNode_CCDIK, MaxIterations) == 0x18c, "Offset mismatch for FAnimNode_CCDIK::MaxIterations");
static_assert(offsetof(FAnimNode_CCDIK, bStartFromTail) == 0x190, "Offset mismatch for FAnimNode_CCDIK::bStartFromTail");
static_assert(offsetof(FAnimNode_CCDIK, bEnableRotationLimit) == 0x191, "Offset mismatch for FAnimNode_CCDIK::bEnableRotationLimit");
static_assert(offsetof(FAnimNode_CCDIK, RotationLimitPerJoints) == 0x198, "Offset mismatch for FAnimNode_CCDIK::RotationLimitPerJoints");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FConstraint
{
    FBoneReference TargetBone; // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t OffsetOption; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t TransformType; // 0xd (Size: 0x1, Type: EnumProperty)
    FFilterOptionPerAxis PerAxis; // 0xe (Size: 0x3, Type: StructProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FConstraint) == 0x18, "Size mismatch for FConstraint");
static_assert(offsetof(FConstraint, TargetBone) == 0x0, "Offset mismatch for FConstraint::TargetBone");
static_assert(offsetof(FConstraint, OffsetOption) == 0xc, "Offset mismatch for FConstraint::OffsetOption");
static_assert(offsetof(FConstraint, TransformType) == 0xd, "Offset mismatch for FConstraint::TransformType");
static_assert(offsetof(FConstraint, PerAxis) == 0xe, "Offset mismatch for FConstraint::PerAxis");

// Size: 0x108 (Inherited: 0xd8, Single: 0x30)
struct FAnimNode_Constraint : FAnimNode_SkeletalControlBase
{
    FBoneReference BoneToModify; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraint> ConstraintSetup; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ConstraintWeights; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_f8[0x10]; // 0xf8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_Constraint) == 0x108, "Size mismatch for FAnimNode_Constraint");
static_assert(offsetof(FAnimNode_Constraint, BoneToModify) == 0xc8, "Offset mismatch for FAnimNode_Constraint::BoneToModify");
static_assert(offsetof(FAnimNode_Constraint, ConstraintSetup) == 0xd8, "Offset mismatch for FAnimNode_Constraint::ConstraintSetup");
static_assert(offsetof(FAnimNode_Constraint, ConstraintWeights) == 0xe8, "Offset mismatch for FAnimNode_Constraint::ConstraintWeights");

// Size: 0xe8 (Inherited: 0xd8, Single: 0x10)
struct FAnimNode_CopyBone : FAnimNode_SkeletalControlBase
{
    FBoneReference SourceBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone; // 0xd4 (Size: 0xc, Type: StructProperty)
    bool bCopyTranslation; // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bCopyRotation; // 0xe1 (Size: 0x1, Type: BoolProperty)
    bool bCopyScale; // 0xe2 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EBoneControlSpace> ControlSpace; // 0xe3 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e4[0x4]; // 0xe4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_CopyBone) == 0xe8, "Size mismatch for FAnimNode_CopyBone");
static_assert(offsetof(FAnimNode_CopyBone, SourceBone) == 0xc8, "Offset mismatch for FAnimNode_CopyBone::SourceBone");
static_assert(offsetof(FAnimNode_CopyBone, TargetBone) == 0xd4, "Offset mismatch for FAnimNode_CopyBone::TargetBone");
static_assert(offsetof(FAnimNode_CopyBone, bCopyTranslation) == 0xe0, "Offset mismatch for FAnimNode_CopyBone::bCopyTranslation");
static_assert(offsetof(FAnimNode_CopyBone, bCopyRotation) == 0xe1, "Offset mismatch for FAnimNode_CopyBone::bCopyRotation");
static_assert(offsetof(FAnimNode_CopyBone, bCopyScale) == 0xe2, "Offset mismatch for FAnimNode_CopyBone::bCopyScale");
static_assert(offsetof(FAnimNode_CopyBone, ControlSpace) == 0xe3, "Offset mismatch for FAnimNode_CopyBone::ControlSpace");

// Size: 0xf0 (Inherited: 0xd8, Single: 0x18)
struct FAnimNode_CopyBoneDelta : FAnimNode_SkeletalControlBase
{
    FBoneReference SourceBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone; // 0xd4 (Size: 0xc, Type: StructProperty)
    bool bCopyTranslation; // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bCopyRotation; // 0xe1 (Size: 0x1, Type: BoolProperty)
    bool bCopyScale; // 0xe2 (Size: 0x1, Type: BoolProperty)
    uint8_t CopyMode; // 0xe3 (Size: 0x1, Type: EnumProperty)
    float TranslationMultiplier; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float RotationMultiplier; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float ScaleMultiplier; // 0xec (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAnimNode_CopyBoneDelta) == 0xf0, "Size mismatch for FAnimNode_CopyBoneDelta");
static_assert(offsetof(FAnimNode_CopyBoneDelta, SourceBone) == 0xc8, "Offset mismatch for FAnimNode_CopyBoneDelta::SourceBone");
static_assert(offsetof(FAnimNode_CopyBoneDelta, TargetBone) == 0xd4, "Offset mismatch for FAnimNode_CopyBoneDelta::TargetBone");
static_assert(offsetof(FAnimNode_CopyBoneDelta, bCopyTranslation) == 0xe0, "Offset mismatch for FAnimNode_CopyBoneDelta::bCopyTranslation");
static_assert(offsetof(FAnimNode_CopyBoneDelta, bCopyRotation) == 0xe1, "Offset mismatch for FAnimNode_CopyBoneDelta::bCopyRotation");
static_assert(offsetof(FAnimNode_CopyBoneDelta, bCopyScale) == 0xe2, "Offset mismatch for FAnimNode_CopyBoneDelta::bCopyScale");
static_assert(offsetof(FAnimNode_CopyBoneDelta, CopyMode) == 0xe3, "Offset mismatch for FAnimNode_CopyBoneDelta::CopyMode");
static_assert(offsetof(FAnimNode_CopyBoneDelta, TranslationMultiplier) == 0xe4, "Offset mismatch for FAnimNode_CopyBoneDelta::TranslationMultiplier");
static_assert(offsetof(FAnimNode_CopyBoneDelta, RotationMultiplier) == 0xe8, "Offset mismatch for FAnimNode_CopyBoneDelta::RotationMultiplier");
static_assert(offsetof(FAnimNode_CopyBoneDelta, ScaleMultiplier) == 0xec, "Offset mismatch for FAnimNode_CopyBoneDelta::ScaleMultiplier");

// Size: 0x1e0 (Inherited: 0xd8, Single: 0x108)
struct FAnimNode_Fabrik : FAnimNode_SkeletalControlBase
{
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    FTransform EffectorTransform; // 0xd0 (Size: 0x60, Type: StructProperty)
    FBoneSocketTarget EffectorTarget; // 0x130 (Size: 0x80, Type: StructProperty)
    FBoneReference TipBone; // 0x1b0 (Size: 0xc, Type: StructProperty)
    FBoneReference RootBone; // 0x1bc (Size: 0xc, Type: StructProperty)
    float Precision; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0x1cc (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EBoneControlSpace> EffectorTransformSpace; // 0x1d0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneRotationSource> EffectorRotationSource; // 0x1d1 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1d2[0xe]; // 0x1d2 (Size: 0xe, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_Fabrik) == 0x1e0, "Size mismatch for FAnimNode_Fabrik");
static_assert(offsetof(FAnimNode_Fabrik, EffectorTransform) == 0xd0, "Offset mismatch for FAnimNode_Fabrik::EffectorTransform");
static_assert(offsetof(FAnimNode_Fabrik, EffectorTarget) == 0x130, "Offset mismatch for FAnimNode_Fabrik::EffectorTarget");
static_assert(offsetof(FAnimNode_Fabrik, TipBone) == 0x1b0, "Offset mismatch for FAnimNode_Fabrik::TipBone");
static_assert(offsetof(FAnimNode_Fabrik, RootBone) == 0x1bc, "Offset mismatch for FAnimNode_Fabrik::RootBone");
static_assert(offsetof(FAnimNode_Fabrik, Precision) == 0x1c8, "Offset mismatch for FAnimNode_Fabrik::Precision");
static_assert(offsetof(FAnimNode_Fabrik, MaxIterations) == 0x1cc, "Offset mismatch for FAnimNode_Fabrik::MaxIterations");
static_assert(offsetof(FAnimNode_Fabrik, EffectorTransformSpace) == 0x1d0, "Offset mismatch for FAnimNode_Fabrik::EffectorTransformSpace");
static_assert(offsetof(FAnimNode_Fabrik, EffectorRotationSource) == 0x1d1, "Offset mismatch for FAnimNode_Fabrik::EffectorRotationSource");

// Size: 0x128 (Inherited: 0xd8, Single: 0x50)
struct FAnimNode_HandIKRetargeting : FAnimNode_SkeletalControlBase
{
    FBoneReference RightHandFK; // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference LeftHandFK; // 0xd4 (Size: 0xc, Type: StructProperty)
    FBoneReference RightHandIK; // 0xe0 (Size: 0xc, Type: StructProperty)
    FBoneReference LeftHandIK; // 0xec (Size: 0xc, Type: StructProperty)
    TArray<FBoneReference> IKBonesToMove; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    FVector PerAxisAlpha; // 0x108 (Size: 0x18, Type: StructProperty)
    float HandFKWeight; // 0x120 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_HandIKRetargeting) == 0x128, "Size mismatch for FAnimNode_HandIKRetargeting");
static_assert(offsetof(FAnimNode_HandIKRetargeting, RightHandFK) == 0xc8, "Offset mismatch for FAnimNode_HandIKRetargeting::RightHandFK");
static_assert(offsetof(FAnimNode_HandIKRetargeting, LeftHandFK) == 0xd4, "Offset mismatch for FAnimNode_HandIKRetargeting::LeftHandFK");
static_assert(offsetof(FAnimNode_HandIKRetargeting, RightHandIK) == 0xe0, "Offset mismatch for FAnimNode_HandIKRetargeting::RightHandIK");
static_assert(offsetof(FAnimNode_HandIKRetargeting, LeftHandIK) == 0xec, "Offset mismatch for FAnimNode_HandIKRetargeting::LeftHandIK");
static_assert(offsetof(FAnimNode_HandIKRetargeting, IKBonesToMove) == 0xf8, "Offset mismatch for FAnimNode_HandIKRetargeting::IKBonesToMove");
static_assert(offsetof(FAnimNode_HandIKRetargeting, PerAxisAlpha) == 0x108, "Offset mismatch for FAnimNode_HandIKRetargeting::PerAxisAlpha");
static_assert(offsetof(FAnimNode_HandIKRetargeting, HandFKWeight) == 0x120, "Offset mismatch for FAnimNode_HandIKRetargeting::HandFKWeight");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FIKChainLink
{
};

static_assert(sizeof(FIKChainLink) == 0x70, "Size mismatch for FIKChainLink");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FIKChain
{
};

static_assert(sizeof(FIKChain) == 0x50, "Size mismatch for FIKChain");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAnimLegIKDefinition
{
    FBoneReference IKFootBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference FKFootBone; // 0xc (Size: 0xc, Type: StructProperty)
    int32_t NumBonesInLimb; // 0x18 (Size: 0x4, Type: IntProperty)
    float MinRotationAngle; // 0x1c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAxis> FootBoneForwardAxis; // 0x20 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EAxis> HingeRotationAxis; // 0x21 (Size: 0x1, Type: ByteProperty)
    bool bEnableRotationLimit; // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bEnableKneeTwistCorrection; // 0x23 (Size: 0x1, Type: BoolProperty)
    FName TwistOffsetCurveName; // 0x24 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FAnimLegIKDefinition) == 0x28, "Size mismatch for FAnimLegIKDefinition");
static_assert(offsetof(FAnimLegIKDefinition, IKFootBone) == 0x0, "Offset mismatch for FAnimLegIKDefinition::IKFootBone");
static_assert(offsetof(FAnimLegIKDefinition, FKFootBone) == 0xc, "Offset mismatch for FAnimLegIKDefinition::FKFootBone");
static_assert(offsetof(FAnimLegIKDefinition, NumBonesInLimb) == 0x18, "Offset mismatch for FAnimLegIKDefinition::NumBonesInLimb");
static_assert(offsetof(FAnimLegIKDefinition, MinRotationAngle) == 0x1c, "Offset mismatch for FAnimLegIKDefinition::MinRotationAngle");
static_assert(offsetof(FAnimLegIKDefinition, FootBoneForwardAxis) == 0x20, "Offset mismatch for FAnimLegIKDefinition::FootBoneForwardAxis");
static_assert(offsetof(FAnimLegIKDefinition, HingeRotationAxis) == 0x21, "Offset mismatch for FAnimLegIKDefinition::HingeRotationAxis");
static_assert(offsetof(FAnimLegIKDefinition, bEnableRotationLimit) == 0x22, "Offset mismatch for FAnimLegIKDefinition::bEnableRotationLimit");
static_assert(offsetof(FAnimLegIKDefinition, bEnableKneeTwistCorrection) == 0x23, "Offset mismatch for FAnimLegIKDefinition::bEnableKneeTwistCorrection");
static_assert(offsetof(FAnimLegIKDefinition, TwistOffsetCurveName) == 0x24, "Offset mismatch for FAnimLegIKDefinition::TwistOffsetCurveName");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FAnimLegIKData
{
};

static_assert(sizeof(FAnimLegIKData) == 0xf0, "Size mismatch for FAnimLegIKData");

// Size: 0x100 (Inherited: 0xd8, Single: 0x28)
struct FAnimNode_LegIK : FAnimNode_SkeletalControlBase
{
    float ReachPrecision; // 0xc8 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0xcc (Size: 0x4, Type: IntProperty)
    float SoftPercentLength; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float SoftAlpha; // 0xd4 (Size: 0x4, Type: FloatProperty)
    TArray<FAnimLegIKDefinition> LegsDefinition; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e8[0x18]; // 0xe8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_LegIK) == 0x100, "Size mismatch for FAnimNode_LegIK");
static_assert(offsetof(FAnimNode_LegIK, ReachPrecision) == 0xc8, "Offset mismatch for FAnimNode_LegIK::ReachPrecision");
static_assert(offsetof(FAnimNode_LegIK, MaxIterations) == 0xcc, "Offset mismatch for FAnimNode_LegIK::MaxIterations");
static_assert(offsetof(FAnimNode_LegIK, SoftPercentLength) == 0xd0, "Offset mismatch for FAnimNode_LegIK::SoftPercentLength");
static_assert(offsetof(FAnimNode_LegIK, SoftAlpha) == 0xd4, "Offset mismatch for FAnimNode_LegIK::SoftAlpha");
static_assert(offsetof(FAnimNode_LegIK, LegsDefinition) == 0xd8, "Offset mismatch for FAnimNode_LegIK::LegsDefinition");

// Size: 0x240 (Inherited: 0xd8, Single: 0x168)
struct FAnimNode_LookAt : FAnimNode_SkeletalControlBase
{
    FBoneReference BoneToModify; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0xc]; // 0xd4 (Size: 0xc, Type: PaddingProperty)
    FBoneSocketTarget LookAtTarget; // 0xe0 (Size: 0x80, Type: StructProperty)
    FVector LookAtLocation; // 0x160 (Size: 0x18, Type: StructProperty)
    FAxis LookAt_Axis; // 0x178 (Size: 0x20, Type: StructProperty)
    bool bUseLookUpAxis; // 0x198 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EInterpolationBlend> InterpolationType; // 0x199 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_19a[0x6]; // 0x19a (Size: 0x6, Type: PaddingProperty)
    FAxis LookUp_Axis; // 0x1a0 (Size: 0x20, Type: StructProperty)
    float LookAtClamp; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float InterpolationTime; // 0x1c4 (Size: 0x4, Type: FloatProperty)
    float InterpolationTriggerThreashold; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1cc[0x74]; // 0x1cc (Size: 0x74, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_LookAt) == 0x240, "Size mismatch for FAnimNode_LookAt");
static_assert(offsetof(FAnimNode_LookAt, BoneToModify) == 0xc8, "Offset mismatch for FAnimNode_LookAt::BoneToModify");
static_assert(offsetof(FAnimNode_LookAt, LookAtTarget) == 0xe0, "Offset mismatch for FAnimNode_LookAt::LookAtTarget");
static_assert(offsetof(FAnimNode_LookAt, LookAtLocation) == 0x160, "Offset mismatch for FAnimNode_LookAt::LookAtLocation");
static_assert(offsetof(FAnimNode_LookAt, LookAt_Axis) == 0x178, "Offset mismatch for FAnimNode_LookAt::LookAt_Axis");
static_assert(offsetof(FAnimNode_LookAt, bUseLookUpAxis) == 0x198, "Offset mismatch for FAnimNode_LookAt::bUseLookUpAxis");
static_assert(offsetof(FAnimNode_LookAt, InterpolationType) == 0x199, "Offset mismatch for FAnimNode_LookAt::InterpolationType");
static_assert(offsetof(FAnimNode_LookAt, LookUp_Axis) == 0x1a0, "Offset mismatch for FAnimNode_LookAt::LookUp_Axis");
static_assert(offsetof(FAnimNode_LookAt, LookAtClamp) == 0x1c0, "Offset mismatch for FAnimNode_LookAt::LookAtClamp");
static_assert(offsetof(FAnimNode_LookAt, InterpolationTime) == 0x1c4, "Offset mismatch for FAnimNode_LookAt::InterpolationTime");
static_assert(offsetof(FAnimNode_LookAt, InterpolationTriggerThreashold) == 0x1c8, "Offset mismatch for FAnimNode_LookAt::InterpolationTriggerThreashold");

// Size: 0x120 (Inherited: 0xd8, Single: 0x48)
struct FAnimNode_ObserveBone : FAnimNode_SkeletalControlBase
{
    FBoneReference BoneToObserve; // 0xc8 (Size: 0xc, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> DisplaySpace; // 0xd4 (Size: 0x1, Type: ByteProperty)
    bool bRelativeToRefPose; // 0xd5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d6[0x2]; // 0xd6 (Size: 0x2, Type: PaddingProperty)
    FVector Translation; // 0xd8 (Size: 0x18, Type: StructProperty)
    FRotator Rotation; // 0xf0 (Size: 0x18, Type: StructProperty)
    FVector Scale; // 0x108 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAnimNode_ObserveBone) == 0x120, "Size mismatch for FAnimNode_ObserveBone");
static_assert(offsetof(FAnimNode_ObserveBone, BoneToObserve) == 0xc8, "Offset mismatch for FAnimNode_ObserveBone::BoneToObserve");
static_assert(offsetof(FAnimNode_ObserveBone, DisplaySpace) == 0xd4, "Offset mismatch for FAnimNode_ObserveBone::DisplaySpace");
static_assert(offsetof(FAnimNode_ObserveBone, bRelativeToRefPose) == 0xd5, "Offset mismatch for FAnimNode_ObserveBone::bRelativeToRefPose");
static_assert(offsetof(FAnimNode_ObserveBone, Translation) == 0xd8, "Offset mismatch for FAnimNode_ObserveBone::Translation");
static_assert(offsetof(FAnimNode_ObserveBone, Rotation) == 0xf0, "Offset mismatch for FAnimNode_ObserveBone::Rotation");
static_assert(offsetof(FAnimNode_ObserveBone, Scale) == 0x108, "Offset mismatch for FAnimNode_ObserveBone::Scale");

// Size: 0xd8 (Inherited: 0xd8, Single: 0x0)
struct FAnimNode_ResetRoot : FAnimNode_SkeletalControlBase
{
};

static_assert(sizeof(FAnimNode_ResetRoot) == 0xd8, "Size mismatch for FAnimNode_ResetRoot");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FSimSpaceSettings
{
    float WorldAlpha; // 0x0 (Size: 0x4, Type: FloatProperty)
    float VelocityScaleZ; // 0x4 (Size: 0x4, Type: FloatProperty)
    float DampingAlpha; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxLinearVelocity; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxAngularVelocity; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxLinearAcceleration; // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxAngularAcceleration; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FVector ExternalLinearDragV; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector ExternalLinearVelocity; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector ExternalAngularVelocity; // 0x50 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FSimSpaceSettings) == 0x68, "Size mismatch for FSimSpaceSettings");
static_assert(offsetof(FSimSpaceSettings, WorldAlpha) == 0x0, "Offset mismatch for FSimSpaceSettings::WorldAlpha");
static_assert(offsetof(FSimSpaceSettings, VelocityScaleZ) == 0x4, "Offset mismatch for FSimSpaceSettings::VelocityScaleZ");
static_assert(offsetof(FSimSpaceSettings, DampingAlpha) == 0x8, "Offset mismatch for FSimSpaceSettings::DampingAlpha");
static_assert(offsetof(FSimSpaceSettings, MaxLinearVelocity) == 0xc, "Offset mismatch for FSimSpaceSettings::MaxLinearVelocity");
static_assert(offsetof(FSimSpaceSettings, MaxAngularVelocity) == 0x10, "Offset mismatch for FSimSpaceSettings::MaxAngularVelocity");
static_assert(offsetof(FSimSpaceSettings, MaxLinearAcceleration) == 0x14, "Offset mismatch for FSimSpaceSettings::MaxLinearAcceleration");
static_assert(offsetof(FSimSpaceSettings, MaxAngularAcceleration) == 0x18, "Offset mismatch for FSimSpaceSettings::MaxAngularAcceleration");
static_assert(offsetof(FSimSpaceSettings, ExternalLinearDragV) == 0x20, "Offset mismatch for FSimSpaceSettings::ExternalLinearDragV");
static_assert(offsetof(FSimSpaceSettings, ExternalLinearVelocity) == 0x38, "Offset mismatch for FSimSpaceSettings::ExternalLinearVelocity");
static_assert(offsetof(FSimSpaceSettings, ExternalAngularVelocity) == 0x50, "Offset mismatch for FSimSpaceSettings::ExternalAngularVelocity");

// Size: 0x920 (Inherited: 0xd8, Single: 0x848)
struct FAnimNode_RigidBody : FAnimNode_SkeletalControlBase
{
    UPhysicsAsset* OverridePhysicsAsset; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    bool bDefaultToSkeletalMeshPhysicsAsset; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x137]; // 0xd1 (Size: 0x137, Type: PaddingProperty)
    bool bUseLocalLODThresholdOnly; // 0x208 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_209[0x7]; // 0x209 (Size: 0x7, Type: PaddingProperty)
    FVector OverrideWorldGravity; // 0x210 (Size: 0x18, Type: StructProperty)
    FVector ExternalForce; // 0x228 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearAccScale; // 0x240 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearVelScale; // 0x258 (Size: 0x18, Type: StructProperty)
    FVector ComponentAppliedLinearAccClamp; // 0x270 (Size: 0x18, Type: StructProperty)
    FSimSpaceSettings SimSpaceSettings; // 0x288 (Size: 0x68, Type: StructProperty)
    float CachedBoundsScale; // 0x2f0 (Size: 0x4, Type: FloatProperty)
    FBoneReference BaseBoneRef; // 0x2f4 (Size: 0xc, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> OverlapChannel; // 0x300 (Size: 0x1, Type: ByteProperty)
    uint8_t SimulationSpace; // 0x301 (Size: 0x1, Type: EnumProperty)
    bool bForceDisableCollisionBetweenConstraintBodies; // 0x302 (Size: 0x1, Type: BoolProperty)
    bool bUseExternalClothCollision; // 0x303 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_304[0x1]; // 0x304 (Size: 0x1, Type: PaddingProperty)
    uint8_t bEnableWorldGeometry : 1; // 0x305:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideWorldGravity : 1; // 0x305:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bTransferBoneVelocities : 1; // 0x305:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bFreezeIncomingPoseOnStart : 1; // 0x305:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bClampLinearTranslationLimitToRefPose : 1; // 0x305:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_306[0x2]; // 0x306 (Size: 0x2, Type: PaddingProperty)
    float WorldSpaceMinimumScale; // 0x308 (Size: 0x4, Type: FloatProperty)
    float EvaluationResetTime; // 0x30c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_310[0x1]; // 0x310 (Size: 0x1, Type: PaddingProperty)
    uint8_t SimulationTiming; // 0x311 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_312[0x60e]; // 0x312 (Size: 0x60e, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_RigidBody) == 0x920, "Size mismatch for FAnimNode_RigidBody");
static_assert(offsetof(FAnimNode_RigidBody, OverridePhysicsAsset) == 0xc8, "Offset mismatch for FAnimNode_RigidBody::OverridePhysicsAsset");
static_assert(offsetof(FAnimNode_RigidBody, bDefaultToSkeletalMeshPhysicsAsset) == 0xd0, "Offset mismatch for FAnimNode_RigidBody::bDefaultToSkeletalMeshPhysicsAsset");
static_assert(offsetof(FAnimNode_RigidBody, bUseLocalLODThresholdOnly) == 0x208, "Offset mismatch for FAnimNode_RigidBody::bUseLocalLODThresholdOnly");
static_assert(offsetof(FAnimNode_RigidBody, OverrideWorldGravity) == 0x210, "Offset mismatch for FAnimNode_RigidBody::OverrideWorldGravity");
static_assert(offsetof(FAnimNode_RigidBody, ExternalForce) == 0x228, "Offset mismatch for FAnimNode_RigidBody::ExternalForce");
static_assert(offsetof(FAnimNode_RigidBody, ComponentLinearAccScale) == 0x240, "Offset mismatch for FAnimNode_RigidBody::ComponentLinearAccScale");
static_assert(offsetof(FAnimNode_RigidBody, ComponentLinearVelScale) == 0x258, "Offset mismatch for FAnimNode_RigidBody::ComponentLinearVelScale");
static_assert(offsetof(FAnimNode_RigidBody, ComponentAppliedLinearAccClamp) == 0x270, "Offset mismatch for FAnimNode_RigidBody::ComponentAppliedLinearAccClamp");
static_assert(offsetof(FAnimNode_RigidBody, SimSpaceSettings) == 0x288, "Offset mismatch for FAnimNode_RigidBody::SimSpaceSettings");
static_assert(offsetof(FAnimNode_RigidBody, CachedBoundsScale) == 0x2f0, "Offset mismatch for FAnimNode_RigidBody::CachedBoundsScale");
static_assert(offsetof(FAnimNode_RigidBody, BaseBoneRef) == 0x2f4, "Offset mismatch for FAnimNode_RigidBody::BaseBoneRef");
static_assert(offsetof(FAnimNode_RigidBody, OverlapChannel) == 0x300, "Offset mismatch for FAnimNode_RigidBody::OverlapChannel");
static_assert(offsetof(FAnimNode_RigidBody, SimulationSpace) == 0x301, "Offset mismatch for FAnimNode_RigidBody::SimulationSpace");
static_assert(offsetof(FAnimNode_RigidBody, bForceDisableCollisionBetweenConstraintBodies) == 0x302, "Offset mismatch for FAnimNode_RigidBody::bForceDisableCollisionBetweenConstraintBodies");
static_assert(offsetof(FAnimNode_RigidBody, bUseExternalClothCollision) == 0x303, "Offset mismatch for FAnimNode_RigidBody::bUseExternalClothCollision");
static_assert(offsetof(FAnimNode_RigidBody, bEnableWorldGeometry) == 0x305, "Offset mismatch for FAnimNode_RigidBody::bEnableWorldGeometry");
static_assert(offsetof(FAnimNode_RigidBody, bOverrideWorldGravity) == 0x305, "Offset mismatch for FAnimNode_RigidBody::bOverrideWorldGravity");
static_assert(offsetof(FAnimNode_RigidBody, bTransferBoneVelocities) == 0x305, "Offset mismatch for FAnimNode_RigidBody::bTransferBoneVelocities");
static_assert(offsetof(FAnimNode_RigidBody, bFreezeIncomingPoseOnStart) == 0x305, "Offset mismatch for FAnimNode_RigidBody::bFreezeIncomingPoseOnStart");
static_assert(offsetof(FAnimNode_RigidBody, bClampLinearTranslationLimitToRefPose) == 0x305, "Offset mismatch for FAnimNode_RigidBody::bClampLinearTranslationLimitToRefPose");
static_assert(offsetof(FAnimNode_RigidBody, WorldSpaceMinimumScale) == 0x308, "Offset mismatch for FAnimNode_RigidBody::WorldSpaceMinimumScale");
static_assert(offsetof(FAnimNode_RigidBody, EvaluationResetTime) == 0x30c, "Offset mismatch for FAnimNode_RigidBody::EvaluationResetTime");
static_assert(offsetof(FAnimNode_RigidBody, SimulationTiming) == 0x311, "Offset mismatch for FAnimNode_RigidBody::SimulationTiming");

// Size: 0x80 (Inherited: 0x10, Single: 0x70)
struct FAnimNode_ScaleChainLength : FAnimNode_Base
{
    FPoseLink InputPose; // 0x10 (Size: 0x10, Type: StructProperty)
    float DefaultChainLength; // 0x20 (Size: 0x4, Type: FloatProperty)
    FBoneReference ChainStartBone; // 0x24 (Size: 0xc, Type: StructProperty)
    FBoneReference ChainEndBone; // 0x30 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FVector TargetLocation; // 0x40 (Size: 0x18, Type: StructProperty)
    float Alpha; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FInputScaleBias AlphaScaleBias; // 0x60 (Size: 0x8, Type: StructProperty)
    uint8_t ChainInitialLength; // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_69[0x17]; // 0x69 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ScaleChainLength) == 0x80, "Size mismatch for FAnimNode_ScaleChainLength");
static_assert(offsetof(FAnimNode_ScaleChainLength, InputPose) == 0x10, "Offset mismatch for FAnimNode_ScaleChainLength::InputPose");
static_assert(offsetof(FAnimNode_ScaleChainLength, DefaultChainLength) == 0x20, "Offset mismatch for FAnimNode_ScaleChainLength::DefaultChainLength");
static_assert(offsetof(FAnimNode_ScaleChainLength, ChainStartBone) == 0x24, "Offset mismatch for FAnimNode_ScaleChainLength::ChainStartBone");
static_assert(offsetof(FAnimNode_ScaleChainLength, ChainEndBone) == 0x30, "Offset mismatch for FAnimNode_ScaleChainLength::ChainEndBone");
static_assert(offsetof(FAnimNode_ScaleChainLength, TargetLocation) == 0x40, "Offset mismatch for FAnimNode_ScaleChainLength::TargetLocation");
static_assert(offsetof(FAnimNode_ScaleChainLength, Alpha) == 0x58, "Offset mismatch for FAnimNode_ScaleChainLength::Alpha");
static_assert(offsetof(FAnimNode_ScaleChainLength, AlphaScaleBias) == 0x60, "Offset mismatch for FAnimNode_ScaleChainLength::AlphaScaleBias");
static_assert(offsetof(FAnimNode_ScaleChainLength, ChainInitialLength) == 0x68, "Offset mismatch for FAnimNode_ScaleChainLength::ChainInitialLength");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSplineIKCachedBoneData
{
    FBoneReference bone; // 0x0 (Size: 0xc, Type: StructProperty)
    int32_t RefSkeletonIndex; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FSplineIKCachedBoneData) == 0x10, "Size mismatch for FSplineIKCachedBoneData");
static_assert(offsetof(FSplineIKCachedBoneData, bone) == 0x0, "Offset mismatch for FSplineIKCachedBoneData::bone");
static_assert(offsetof(FSplineIKCachedBoneData, RefSkeletonIndex) == 0xc, "Offset mismatch for FSplineIKCachedBoneData::RefSkeletonIndex");

// Size: 0x258 (Inherited: 0xd8, Single: 0x180)
struct FAnimNode_SplineIK : FAnimNode_SkeletalControlBase
{
    FBoneReference StartBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference EndBone; // 0xd4 (Size: 0xc, Type: StructProperty)
    uint8_t BoneAxis; // 0xe0 (Size: 0x1, Type: EnumProperty)
    bool bAutoCalculateSpline; // 0xe1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e2[0x2]; // 0xe2 (Size: 0x2, Type: PaddingProperty)
    int32_t PointCount; // 0xe4 (Size: 0x4, Type: IntProperty)
    TArray<FTransform> ControlPoints; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    float Roll; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float TwistStart; // 0xfc (Size: 0x4, Type: FloatProperty)
    float TwistEnd; // 0x100 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_104[0x4]; // 0x104 (Size: 0x4, Type: PaddingProperty)
    FAlphaBlend TwistBlend; // 0x108 (Size: 0x30, Type: StructProperty)
    float Stretch; // 0x138 (Size: 0x4, Type: FloatProperty)
    float Offset; // 0x13c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_140[0x118]; // 0x140 (Size: 0x118, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_SplineIK) == 0x258, "Size mismatch for FAnimNode_SplineIK");
static_assert(offsetof(FAnimNode_SplineIK, StartBone) == 0xc8, "Offset mismatch for FAnimNode_SplineIK::StartBone");
static_assert(offsetof(FAnimNode_SplineIK, EndBone) == 0xd4, "Offset mismatch for FAnimNode_SplineIK::EndBone");
static_assert(offsetof(FAnimNode_SplineIK, BoneAxis) == 0xe0, "Offset mismatch for FAnimNode_SplineIK::BoneAxis");
static_assert(offsetof(FAnimNode_SplineIK, bAutoCalculateSpline) == 0xe1, "Offset mismatch for FAnimNode_SplineIK::bAutoCalculateSpline");
static_assert(offsetof(FAnimNode_SplineIK, PointCount) == 0xe4, "Offset mismatch for FAnimNode_SplineIK::PointCount");
static_assert(offsetof(FAnimNode_SplineIK, ControlPoints) == 0xe8, "Offset mismatch for FAnimNode_SplineIK::ControlPoints");
static_assert(offsetof(FAnimNode_SplineIK, Roll) == 0xf8, "Offset mismatch for FAnimNode_SplineIK::Roll");
static_assert(offsetof(FAnimNode_SplineIK, TwistStart) == 0xfc, "Offset mismatch for FAnimNode_SplineIK::TwistStart");
static_assert(offsetof(FAnimNode_SplineIK, TwistEnd) == 0x100, "Offset mismatch for FAnimNode_SplineIK::TwistEnd");
static_assert(offsetof(FAnimNode_SplineIK, TwistBlend) == 0x108, "Offset mismatch for FAnimNode_SplineIK::TwistBlend");
static_assert(offsetof(FAnimNode_SplineIK, Stretch) == 0x138, "Offset mismatch for FAnimNode_SplineIK::Stretch");
static_assert(offsetof(FAnimNode_SplineIK, Offset) == 0x13c, "Offset mismatch for FAnimNode_SplineIK::Offset");

// Size: 0x168 (Inherited: 0xd8, Single: 0x90)
struct FAnimNode_SpringBone : FAnimNode_SkeletalControlBase
{
    FBoneReference SpringBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    double MaxDisplacement; // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double SpringStiffness; // 0xe0 (Size: 0x8, Type: DoubleProperty)
    double SpringDamping; // 0xe8 (Size: 0x8, Type: DoubleProperty)
    double ErrorResetThresh; // 0xf0 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_f8[0x6c]; // 0xf8 (Size: 0x6c, Type: PaddingProperty)
    uint8_t bLimitDisplacement : 1; // 0x164:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bTranslateX : 1; // 0x164:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bTranslateY : 1; // 0x164:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bTranslateZ : 1; // 0x164:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bRotateX : 1; // 0x164:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bRotateY : 1; // 0x164:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bRotateZ : 1; // 0x164:6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_165[0x3]; // 0x165 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_SpringBone) == 0x168, "Size mismatch for FAnimNode_SpringBone");
static_assert(offsetof(FAnimNode_SpringBone, SpringBone) == 0xc8, "Offset mismatch for FAnimNode_SpringBone::SpringBone");
static_assert(offsetof(FAnimNode_SpringBone, MaxDisplacement) == 0xd8, "Offset mismatch for FAnimNode_SpringBone::MaxDisplacement");
static_assert(offsetof(FAnimNode_SpringBone, SpringStiffness) == 0xe0, "Offset mismatch for FAnimNode_SpringBone::SpringStiffness");
static_assert(offsetof(FAnimNode_SpringBone, SpringDamping) == 0xe8, "Offset mismatch for FAnimNode_SpringBone::SpringDamping");
static_assert(offsetof(FAnimNode_SpringBone, ErrorResetThresh) == 0xf0, "Offset mismatch for FAnimNode_SpringBone::ErrorResetThresh");
static_assert(offsetof(FAnimNode_SpringBone, bLimitDisplacement) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bLimitDisplacement");
static_assert(offsetof(FAnimNode_SpringBone, bTranslateX) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bTranslateX");
static_assert(offsetof(FAnimNode_SpringBone, bTranslateY) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bTranslateY");
static_assert(offsetof(FAnimNode_SpringBone, bTranslateZ) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bTranslateZ");
static_assert(offsetof(FAnimNode_SpringBone, bRotateX) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bRotateX");
static_assert(offsetof(FAnimNode_SpringBone, bRotateY) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bRotateY");
static_assert(offsetof(FAnimNode_SpringBone, bRotateZ) == 0x164, "Offset mismatch for FAnimNode_SpringBone::bRotateZ");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRotationLimit
{
    FVector LimitMin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector LimitMax; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRotationLimit) == 0x30, "Size mismatch for FRotationLimit");
static_assert(offsetof(FRotationLimit, LimitMin) == 0x0, "Offset mismatch for FRotationLimit::LimitMin");
static_assert(offsetof(FRotationLimit, LimitMax) == 0x18, "Offset mismatch for FRotationLimit::LimitMax");

// Size: 0x2a0 (Inherited: 0xd8, Single: 0x1c8)
struct FAnimNode_Trail : FAnimNode_SkeletalControlBase
{
    uint8_t Pad_c8[0x68]; // 0xc8 (Size: 0x68, Type: PaddingProperty)
    FBoneReference TrailBone; // 0x130 (Size: 0xc, Type: StructProperty)
    int32_t ChainLength; // 0x13c (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EAxis> ChainBoneAxis; // 0x140 (Size: 0x1, Type: ByteProperty)
    uint8_t bInvertChainBoneAxis : 1; // 0x141:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bLimitStretch : 1; // 0x141:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bLimitRotation : 1; // 0x141:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bUsePlanarLimit : 1; // 0x141:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bActorSpaceFakeVel : 1; // 0x141:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bReorientParentToChild : 1; // 0x141:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_142[0x2]; // 0x142 (Size: 0x2, Type: PaddingProperty)
    float MaxDeltaTime; // 0x144 (Size: 0x4, Type: FloatProperty)
    float RelaxationSpeedScale; // 0x148 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
    FRuntimeFloatCurve TrailRelaxationSpeed; // 0x150 (Size: 0x88, Type: StructProperty)
    FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor; // 0x1d8 (Size: 0x30, Type: StructProperty)
    TArray<FRotationLimit> RotationLimits; // 0x208 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> RotationOffsets; // 0x218 (Size: 0x10, Type: ArrayProperty)
    TArray<FAnimPhysPlanarLimit> PlanarLimits; // 0x228 (Size: 0x10, Type: ArrayProperty)
    float StretchLimit; // 0x238 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_23c[0x4]; // 0x23c (Size: 0x4, Type: PaddingProperty)
    FVector FakeVelocity; // 0x240 (Size: 0x18, Type: StructProperty)
    FBoneReference BaseJoint; // 0x258 (Size: 0xc, Type: StructProperty)
    float LastBoneRotationAnimAlphaBlend; // 0x264 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_268[0x38]; // 0x268 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_Trail) == 0x2a0, "Size mismatch for FAnimNode_Trail");
static_assert(offsetof(FAnimNode_Trail, TrailBone) == 0x130, "Offset mismatch for FAnimNode_Trail::TrailBone");
static_assert(offsetof(FAnimNode_Trail, ChainLength) == 0x13c, "Offset mismatch for FAnimNode_Trail::ChainLength");
static_assert(offsetof(FAnimNode_Trail, ChainBoneAxis) == 0x140, "Offset mismatch for FAnimNode_Trail::ChainBoneAxis");
static_assert(offsetof(FAnimNode_Trail, bInvertChainBoneAxis) == 0x141, "Offset mismatch for FAnimNode_Trail::bInvertChainBoneAxis");
static_assert(offsetof(FAnimNode_Trail, bLimitStretch) == 0x141, "Offset mismatch for FAnimNode_Trail::bLimitStretch");
static_assert(offsetof(FAnimNode_Trail, bLimitRotation) == 0x141, "Offset mismatch for FAnimNode_Trail::bLimitRotation");
static_assert(offsetof(FAnimNode_Trail, bUsePlanarLimit) == 0x141, "Offset mismatch for FAnimNode_Trail::bUsePlanarLimit");
static_assert(offsetof(FAnimNode_Trail, bActorSpaceFakeVel) == 0x141, "Offset mismatch for FAnimNode_Trail::bActorSpaceFakeVel");
static_assert(offsetof(FAnimNode_Trail, bReorientParentToChild) == 0x141, "Offset mismatch for FAnimNode_Trail::bReorientParentToChild");
static_assert(offsetof(FAnimNode_Trail, MaxDeltaTime) == 0x144, "Offset mismatch for FAnimNode_Trail::MaxDeltaTime");
static_assert(offsetof(FAnimNode_Trail, RelaxationSpeedScale) == 0x148, "Offset mismatch for FAnimNode_Trail::RelaxationSpeedScale");
static_assert(offsetof(FAnimNode_Trail, TrailRelaxationSpeed) == 0x150, "Offset mismatch for FAnimNode_Trail::TrailRelaxationSpeed");
static_assert(offsetof(FAnimNode_Trail, RelaxationSpeedScaleInputProcessor) == 0x1d8, "Offset mismatch for FAnimNode_Trail::RelaxationSpeedScaleInputProcessor");
static_assert(offsetof(FAnimNode_Trail, RotationLimits) == 0x208, "Offset mismatch for FAnimNode_Trail::RotationLimits");
static_assert(offsetof(FAnimNode_Trail, RotationOffsets) == 0x218, "Offset mismatch for FAnimNode_Trail::RotationOffsets");
static_assert(offsetof(FAnimNode_Trail, PlanarLimits) == 0x228, "Offset mismatch for FAnimNode_Trail::PlanarLimits");
static_assert(offsetof(FAnimNode_Trail, StretchLimit) == 0x238, "Offset mismatch for FAnimNode_Trail::StretchLimit");
static_assert(offsetof(FAnimNode_Trail, FakeVelocity) == 0x240, "Offset mismatch for FAnimNode_Trail::FakeVelocity");
static_assert(offsetof(FAnimNode_Trail, BaseJoint) == 0x258, "Offset mismatch for FAnimNode_Trail::BaseJoint");
static_assert(offsetof(FAnimNode_Trail, LastBoneRotationAnimAlphaBlend) == 0x264, "Offset mismatch for FAnimNode_Trail::LastBoneRotationAnimAlphaBlend");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FReferenceBoneFrame
{
    FBoneReference bone; // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FAxis Axis; // 0x10 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FReferenceBoneFrame) == 0x30, "Size mismatch for FReferenceBoneFrame");
static_assert(offsetof(FReferenceBoneFrame, bone) == 0x0, "Offset mismatch for FReferenceBoneFrame::bone");
static_assert(offsetof(FReferenceBoneFrame, Axis) == 0x10, "Offset mismatch for FReferenceBoneFrame::Axis");

// Size: 0x160 (Inherited: 0xd8, Single: 0x88)
struct FAnimNode_TwistCorrectiveNode : FAnimNode_SkeletalControlBase
{
    FReferenceBoneFrame BaseFrame; // 0xc8 (Size: 0x30, Type: StructProperty)
    FReferenceBoneFrame TwistFrame; // 0xf8 (Size: 0x30, Type: StructProperty)
    FAxis TwistPlaneNormalAxis; // 0x128 (Size: 0x20, Type: StructProperty)
    float RangeMax; // 0x148 (Size: 0x4, Type: FloatProperty)
    float RemappedMin; // 0x14c (Size: 0x4, Type: FloatProperty)
    float RemappedMax; // 0x150 (Size: 0x4, Type: FloatProperty)
    FName CurveName; // 0x154 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_TwistCorrectiveNode) == 0x160, "Size mismatch for FAnimNode_TwistCorrectiveNode");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, BaseFrame) == 0xc8, "Offset mismatch for FAnimNode_TwistCorrectiveNode::BaseFrame");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, TwistFrame) == 0xf8, "Offset mismatch for FAnimNode_TwistCorrectiveNode::TwistFrame");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, TwistPlaneNormalAxis) == 0x128, "Offset mismatch for FAnimNode_TwistCorrectiveNode::TwistPlaneNormalAxis");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, RangeMax) == 0x148, "Offset mismatch for FAnimNode_TwistCorrectiveNode::RangeMax");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, RemappedMin) == 0x14c, "Offset mismatch for FAnimNode_TwistCorrectiveNode::RemappedMin");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, RemappedMax) == 0x150, "Offset mismatch for FAnimNode_TwistCorrectiveNode::RemappedMax");
static_assert(offsetof(FAnimNode_TwistCorrectiveNode, CurveName) == 0x154, "Offset mismatch for FAnimNode_TwistCorrectiveNode::CurveName");

// Size: 0x260 (Inherited: 0xd8, Single: 0x188)
struct FAnimNode_TwoBoneIK : FAnimNode_SkeletalControlBase
{
    FBoneReference IKBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    double StartStretchRatio; // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double MaxStretchScale; // 0xe0 (Size: 0x8, Type: DoubleProperty)
    FVector EffectorLocation; // 0xe8 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_100[0x10]; // 0x100 (Size: 0x10, Type: PaddingProperty)
    FBoneSocketTarget EffectorTarget; // 0x110 (Size: 0x80, Type: StructProperty)
    FVector JointTargetLocation; // 0x190 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    FBoneSocketTarget JointTarget; // 0x1b0 (Size: 0x80, Type: StructProperty)
    FAxis TwistAxis; // 0x230 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<EBoneControlSpace> EffectorLocationSpace; // 0x250 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EBoneControlSpace> JointTargetLocationSpace; // 0x251 (Size: 0x1, Type: ByteProperty)
    uint8_t bAllowStretching : 1; // 0x252:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bTakeRotationFromEffectorSpace : 1; // 0x252:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bMaintainEffectorRelRot : 1; // 0x252:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowTwist : 1; // 0x252:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_253[0xd]; // 0x253 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_TwoBoneIK) == 0x260, "Size mismatch for FAnimNode_TwoBoneIK");
static_assert(offsetof(FAnimNode_TwoBoneIK, IKBone) == 0xc8, "Offset mismatch for FAnimNode_TwoBoneIK::IKBone");
static_assert(offsetof(FAnimNode_TwoBoneIK, StartStretchRatio) == 0xd8, "Offset mismatch for FAnimNode_TwoBoneIK::StartStretchRatio");
static_assert(offsetof(FAnimNode_TwoBoneIK, MaxStretchScale) == 0xe0, "Offset mismatch for FAnimNode_TwoBoneIK::MaxStretchScale");
static_assert(offsetof(FAnimNode_TwoBoneIK, EffectorLocation) == 0xe8, "Offset mismatch for FAnimNode_TwoBoneIK::EffectorLocation");
static_assert(offsetof(FAnimNode_TwoBoneIK, EffectorTarget) == 0x110, "Offset mismatch for FAnimNode_TwoBoneIK::EffectorTarget");
static_assert(offsetof(FAnimNode_TwoBoneIK, JointTargetLocation) == 0x190, "Offset mismatch for FAnimNode_TwoBoneIK::JointTargetLocation");
static_assert(offsetof(FAnimNode_TwoBoneIK, JointTarget) == 0x1b0, "Offset mismatch for FAnimNode_TwoBoneIK::JointTarget");
static_assert(offsetof(FAnimNode_TwoBoneIK, TwistAxis) == 0x230, "Offset mismatch for FAnimNode_TwoBoneIK::TwistAxis");
static_assert(offsetof(FAnimNode_TwoBoneIK, EffectorLocationSpace) == 0x250, "Offset mismatch for FAnimNode_TwoBoneIK::EffectorLocationSpace");
static_assert(offsetof(FAnimNode_TwoBoneIK, JointTargetLocationSpace) == 0x251, "Offset mismatch for FAnimNode_TwoBoneIK::JointTargetLocationSpace");
static_assert(offsetof(FAnimNode_TwoBoneIK, bAllowStretching) == 0x252, "Offset mismatch for FAnimNode_TwoBoneIK::bAllowStretching");
static_assert(offsetof(FAnimNode_TwoBoneIK, bTakeRotationFromEffectorSpace) == 0x252, "Offset mismatch for FAnimNode_TwoBoneIK::bTakeRotationFromEffectorSpace");
static_assert(offsetof(FAnimNode_TwoBoneIK, bMaintainEffectorRelRot) == 0x252, "Offset mismatch for FAnimNode_TwoBoneIK::bMaintainEffectorRelRot");
static_assert(offsetof(FAnimNode_TwoBoneIK, bAllowTwist) == 0x252, "Offset mismatch for FAnimNode_TwoBoneIK::bAllowTwist");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FIKFootPelvisPullDownSolver
{
    FVectorRK4SpringInterpolator PelvisAdjustmentInterp; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_8[0x58]; // 0x8 (Size: 0x58, Type: PaddingProperty)
    double PelvisAdjustmentInterpAlpha; // 0x60 (Size: 0x8, Type: DoubleProperty)
    double PelvisAdjustmentMaxDistance; // 0x68 (Size: 0x8, Type: DoubleProperty)
    double PelvisAdjustmentErrorTolerance; // 0x70 (Size: 0x8, Type: DoubleProperty)
    int32_t PelvisAdjustmentMaxIter; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FIKFootPelvisPullDownSolver) == 0x80, "Size mismatch for FIKFootPelvisPullDownSolver");
static_assert(offsetof(FIKFootPelvisPullDownSolver, PelvisAdjustmentInterp) == 0x0, "Offset mismatch for FIKFootPelvisPullDownSolver::PelvisAdjustmentInterp");
static_assert(offsetof(FIKFootPelvisPullDownSolver, PelvisAdjustmentInterpAlpha) == 0x60, "Offset mismatch for FIKFootPelvisPullDownSolver::PelvisAdjustmentInterpAlpha");
static_assert(offsetof(FIKFootPelvisPullDownSolver, PelvisAdjustmentMaxDistance) == 0x68, "Offset mismatch for FIKFootPelvisPullDownSolver::PelvisAdjustmentMaxDistance");
static_assert(offsetof(FIKFootPelvisPullDownSolver, PelvisAdjustmentErrorTolerance) == 0x70, "Offset mismatch for FIKFootPelvisPullDownSolver::PelvisAdjustmentErrorTolerance");
static_assert(offsetof(FIKFootPelvisPullDownSolver, PelvisAdjustmentMaxIter) == 0x78, "Offset mismatch for FIKFootPelvisPullDownSolver::PelvisAdjustmentMaxIter");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FWarpingVectorValue
{
    uint8_t Mode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector Value; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FWarpingVectorValue) == 0x20, "Size mismatch for FWarpingVectorValue");
static_assert(offsetof(FWarpingVectorValue, Mode) == 0x0, "Offset mismatch for FWarpingVectorValue::Mode");
static_assert(offsetof(FWarpingVectorValue, Value) == 0x8, "Offset mismatch for FWarpingVectorValue::Value");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FLayeredBoneBlendReference : FAnimNodeReference
{
};

static_assert(sizeof(FLayeredBoneBlendReference) == 0x10, "Size mismatch for FLayeredBoneBlendReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FLinkedAnimGraphReference : FAnimNodeReference
{
};

static_assert(sizeof(FLinkedAnimGraphReference) == 0x10, "Size mismatch for FLinkedAnimGraphReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FMirrorAnimNodeReference : FAnimNodeReference
{
};

static_assert(sizeof(FMirrorAnimNodeReference) == 0x10, "Size mismatch for FMirrorAnimNodeReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FModifyCurveAnimNodeReference : FAnimNodeReference
{
};

static_assert(sizeof(FModifyCurveAnimNodeReference) == 0x10, "Size mismatch for FModifyCurveAnimNodeReference");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRBFEntry
{
    TArray<float> Values; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRBFEntry) == 0x10, "Size mismatch for FRBFEntry");
static_assert(offsetof(FRBFEntry, Values) == 0x0, "Offset mismatch for FRBFEntry::Values");

// Size: 0xa0 (Inherited: 0x10, Single: 0x90)
struct FRBFTarget : FRBFEntry
{
    float ScaleFactor; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bApplyCustomCurve; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FRichCurve CustomCurve; // 0x18 (Size: 0x80, Type: StructProperty)
    uint8_t DistanceMethod; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t FunctionType; // 0x99 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9a[0x6]; // 0x9a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FRBFTarget) == 0xa0, "Size mismatch for FRBFTarget");
static_assert(offsetof(FRBFTarget, ScaleFactor) == 0x10, "Offset mismatch for FRBFTarget::ScaleFactor");
static_assert(offsetof(FRBFTarget, bApplyCustomCurve) == 0x14, "Offset mismatch for FRBFTarget::bApplyCustomCurve");
static_assert(offsetof(FRBFTarget, CustomCurve) == 0x18, "Offset mismatch for FRBFTarget::CustomCurve");
static_assert(offsetof(FRBFTarget, DistanceMethod) == 0x98, "Offset mismatch for FRBFTarget::DistanceMethod");
static_assert(offsetof(FRBFTarget, FunctionType) == 0x99, "Offset mismatch for FRBFTarget::FunctionType");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FSequenceEvaluatorReference : FAnimNodeReference
{
};

static_assert(sizeof(FSequenceEvaluatorReference) == 0x10, "Size mismatch for FSequenceEvaluatorReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FSequencePlayerReference : FAnimNodeReference
{
};

static_assert(sizeof(FSequencePlayerReference) == 0x10, "Size mismatch for FSequencePlayerReference");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FSkeletalControlReference : FAnimNodeReference
{
};

static_assert(sizeof(FSkeletalControlReference) == 0x10, "Size mismatch for FSkeletalControlReference");

