/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationSharing
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UAnimationSharingStateProcessor : public UObject
{
public:
    TSoftObjectPtr<UEnum*> AnimationStateEnum; // 0x28 (Size: 0x20, Type: SoftObjectProperty)

public:
    virtual UEnum* GetAnimationStateEnum(); // 0xc99043c (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
    virtual void ProcessActorState(int32_t& OutState, AActor*& InActor, char& CurrentState, char& OnDemandState, bool& bShouldProcess); // 0xc990708 (Index: 0x1, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UAnimationSharingStateProcessor) == 0x48, "Size mismatch for UAnimationSharingStateProcessor");
static_assert(offsetof(UAnimationSharingStateProcessor, AnimationStateEnum) == 0x28, "Offset mismatch for UAnimationSharingStateProcessor::AnimationStateEnum");

// Size: 0x400 (Inherited: 0x408, Single: 0xfffffff8)
class UAnimSharingStateInstance : public UAnimInstance
{
public:
    UAnimSequence* AnimationToPlay; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    float PermutationTimeOffset; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    float PlayRate; // 0x3e4 (Size: 0x4, Type: FloatProperty)
    bool bStateBool; // 0x3e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e9[0x7]; // 0x3e9 (Size: 0x7, Type: PaddingProperty)
    UAnimSharingInstance* Instance; // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3f8[0x8]; // 0x3f8 (Size: 0x8, Type: PaddingProperty)

protected:
    void GetInstancedActors(TArray<AActor*>& Actors); // 0xc990464 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnimSharingStateInstance) == 0x400, "Size mismatch for UAnimSharingStateInstance");
static_assert(offsetof(UAnimSharingStateInstance, AnimationToPlay) == 0x3d8, "Offset mismatch for UAnimSharingStateInstance::AnimationToPlay");
static_assert(offsetof(UAnimSharingStateInstance, PermutationTimeOffset) == 0x3e0, "Offset mismatch for UAnimSharingStateInstance::PermutationTimeOffset");
static_assert(offsetof(UAnimSharingStateInstance, PlayRate) == 0x3e4, "Offset mismatch for UAnimSharingStateInstance::PlayRate");
static_assert(offsetof(UAnimSharingStateInstance, bStateBool) == 0x3e8, "Offset mismatch for UAnimSharingStateInstance::bStateBool");
static_assert(offsetof(UAnimSharingStateInstance, Instance) == 0x3f0, "Offset mismatch for UAnimSharingStateInstance::Instance");

// Size: 0x3f0 (Inherited: 0x408, Single: 0xffffffe8)
class UAnimSharingTransitionInstance : public UAnimInstance
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> FromComponent; // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> ToComponent; // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    float BlendTime; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    bool bBlendBool; // 0x3ec (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ed[0x3]; // 0x3ed (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UAnimSharingTransitionInstance) == 0x3f0, "Size mismatch for UAnimSharingTransitionInstance");
static_assert(offsetof(UAnimSharingTransitionInstance, FromComponent) == 0x3d8, "Offset mismatch for UAnimSharingTransitionInstance::FromComponent");
static_assert(offsetof(UAnimSharingTransitionInstance, ToComponent) == 0x3e0, "Offset mismatch for UAnimSharingTransitionInstance::ToComponent");
static_assert(offsetof(UAnimSharingTransitionInstance, BlendTime) == 0x3e8, "Offset mismatch for UAnimSharingTransitionInstance::BlendTime");
static_assert(offsetof(UAnimSharingTransitionInstance, bBlendBool) == 0x3ec, "Offset mismatch for UAnimSharingTransitionInstance::bBlendBool");

// Size: 0x3f0 (Inherited: 0x408, Single: 0xffffffe8)
class UAnimSharingAdditiveInstance : public UAnimInstance
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> BaseComponent; // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAnimSequence*> AdditiveAnimation; // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    float Alpha; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    bool bStateBool; // 0x3ec (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ed[0x3]; // 0x3ed (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UAnimSharingAdditiveInstance) == 0x3f0, "Size mismatch for UAnimSharingAdditiveInstance");
static_assert(offsetof(UAnimSharingAdditiveInstance, BaseComponent) == 0x3d8, "Offset mismatch for UAnimSharingAdditiveInstance::BaseComponent");
static_assert(offsetof(UAnimSharingAdditiveInstance, AdditiveAnimation) == 0x3e0, "Offset mismatch for UAnimSharingAdditiveInstance::AdditiveAnimation");
static_assert(offsetof(UAnimSharingAdditiveInstance, Alpha) == 0x3e8, "Offset mismatch for UAnimSharingAdditiveInstance::Alpha");
static_assert(offsetof(UAnimSharingAdditiveInstance, bStateBool) == 0x3ec, "Offset mismatch for UAnimSharingAdditiveInstance::bStateBool");

// Size: 0x120 (Inherited: 0x28, Single: 0xf8)
class UAnimSharingInstance : public UObject
{
public:
    TArray<AActor*> RegisteredActors; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x50]; // 0x38 (Size: 0x50, Type: PaddingProperty)
    UAnimationSharingStateProcessor* StateProcessor; // 0x88 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_90[0x38]; // 0x90 (Size: 0x38, Type: PaddingProperty)
    TArray<UAnimSequence*> UsedAnimationSequences; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d8[0x10]; // 0xd8 (Size: 0x10, Type: PaddingProperty)
    UEnum* StateEnum; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    AActor* SharingActor; // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAnimSharingInstance) == 0x120, "Size mismatch for UAnimSharingInstance");
static_assert(offsetof(UAnimSharingInstance, RegisteredActors) == 0x28, "Offset mismatch for UAnimSharingInstance::RegisteredActors");
static_assert(offsetof(UAnimSharingInstance, StateProcessor) == 0x88, "Offset mismatch for UAnimSharingInstance::StateProcessor");
static_assert(offsetof(UAnimSharingInstance, UsedAnimationSequences) == 0xc8, "Offset mismatch for UAnimSharingInstance::UsedAnimationSequences");
static_assert(offsetof(UAnimSharingInstance, StateEnum) == 0xe8, "Offset mismatch for UAnimSharingInstance::StateEnum");
static_assert(offsetof(UAnimSharingInstance, SharingActor) == 0xf0, "Offset mismatch for UAnimSharingInstance::SharingActor");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UAnimationSharingManager : public UObject
{
public:
    TArray<USkeleton*> Skeletons; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UAnimSharingInstance*> PerSkeletonData; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_48[0x40]; // 0x48 (Size: 0x40, Type: PaddingProperty)

public:
    static bool AnimationSharingEnabled(); // 0xc9900f0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool CreateAnimationSharingManager(UObject*& WorldContextObject, UAnimationSharingSetup*& const Setup); // 0xc99010c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAnimationSharingManager* GetAnimationSharingManager(UObject*& WorldContextObject); // 0xc990314 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    void RegisterActorWithSkeletonBP(AActor*& InActor, USkeleton*& const SharingSkeleton); // 0xc990a18 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAnimationSharingManager) == 0x88, "Size mismatch for UAnimationSharingManager");
static_assert(offsetof(UAnimationSharingManager, Skeletons) == 0x28, "Offset mismatch for UAnimationSharingManager::Skeletons");
static_assert(offsetof(UAnimationSharingManager, PerSkeletonData) == 0x38, "Offset mismatch for UAnimationSharingManager::PerSkeletonData");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UAnimationSharingSetup : public UObject
{
public:
    TArray<FPerSkeletonAnimationSharingSetup> SkeletonSetups; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FAnimationSharingScalability ScalabilitySettings; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAnimationSharingSetup) == 0x48, "Size mismatch for UAnimationSharingSetup");
static_assert(offsetof(UAnimationSharingSetup, SkeletonSetups) == 0x28, "Offset mismatch for UAnimationSharingSetup::SkeletonSetups");
static_assert(offsetof(UAnimationSharingSetup, ScalabilitySettings) == 0x38, "Offset mismatch for UAnimationSharingSetup::ScalabilitySettings");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAnimationSetup
{
    UAnimSequence* AnimSequence; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UClass* AnimBlueprint; // 0x8 (Size: 0x8, Type: ClassProperty)
    FPerPlatformInt NumRandomizedInstances; // 0x10 (Size: 0x4, Type: StructProperty)
    FPerPlatformBool Enabled; // 0x14 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimationSetup) == 0x18, "Size mismatch for FAnimationSetup");
static_assert(offsetof(FAnimationSetup, AnimSequence) == 0x0, "Offset mismatch for FAnimationSetup::AnimSequence");
static_assert(offsetof(FAnimationSetup, AnimBlueprint) == 0x8, "Offset mismatch for FAnimationSetup::AnimBlueprint");
static_assert(offsetof(FAnimationSetup, NumRandomizedInstances) == 0x10, "Offset mismatch for FAnimationSetup::NumRandomizedInstances");
static_assert(offsetof(FAnimationSetup, Enabled) == 0x14, "Offset mismatch for FAnimationSetup::Enabled");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAnimationStateEntry
{
    char State; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FAnimationSetup> AnimationSetups; // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bOnDemand; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bAdditive; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
    float BlendTime; // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bReturnToPreviousState; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bSetNextState; // 0x21 (Size: 0x1, Type: BoolProperty)
    char NextState; // 0x22 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_23[0x1]; // 0x23 (Size: 0x1, Type: PaddingProperty)
    FPerPlatformInt MaximumNumberOfConcurrentInstances; // 0x24 (Size: 0x4, Type: StructProperty)
    float WiggleTimePercentage; // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bRequiresCurves; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAnimationStateEntry) == 0x30, "Size mismatch for FAnimationStateEntry");
static_assert(offsetof(FAnimationStateEntry, State) == 0x0, "Offset mismatch for FAnimationStateEntry::State");
static_assert(offsetof(FAnimationStateEntry, AnimationSetups) == 0x8, "Offset mismatch for FAnimationStateEntry::AnimationSetups");
static_assert(offsetof(FAnimationStateEntry, bOnDemand) == 0x18, "Offset mismatch for FAnimationStateEntry::bOnDemand");
static_assert(offsetof(FAnimationStateEntry, bAdditive) == 0x19, "Offset mismatch for FAnimationStateEntry::bAdditive");
static_assert(offsetof(FAnimationStateEntry, BlendTime) == 0x1c, "Offset mismatch for FAnimationStateEntry::BlendTime");
static_assert(offsetof(FAnimationStateEntry, bReturnToPreviousState) == 0x20, "Offset mismatch for FAnimationStateEntry::bReturnToPreviousState");
static_assert(offsetof(FAnimationStateEntry, bSetNextState) == 0x21, "Offset mismatch for FAnimationStateEntry::bSetNextState");
static_assert(offsetof(FAnimationStateEntry, NextState) == 0x22, "Offset mismatch for FAnimationStateEntry::NextState");
static_assert(offsetof(FAnimationStateEntry, MaximumNumberOfConcurrentInstances) == 0x24, "Offset mismatch for FAnimationStateEntry::MaximumNumberOfConcurrentInstances");
static_assert(offsetof(FAnimationStateEntry, WiggleTimePercentage) == 0x28, "Offset mismatch for FAnimationStateEntry::WiggleTimePercentage");
static_assert(offsetof(FAnimationStateEntry, bRequiresCurves) == 0x2c, "Offset mismatch for FAnimationStateEntry::bRequiresCurves");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FPerSkeletonAnimationSharingSetup
{
    USkeleton* Skeleton; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMesh* SkeletalMesh; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* BlendAnimBlueprint; // 0x10 (Size: 0x8, Type: ClassProperty)
    UClass* AdditiveAnimBlueprint; // 0x18 (Size: 0x8, Type: ClassProperty)
    UClass* StateProcessorClass; // 0x20 (Size: 0x8, Type: ClassProperty)
    bool bEnableMaterialParameterCaching; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TArray<FAnimationStateEntry> AnimationStates; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPerSkeletonAnimationSharingSetup) == 0x40, "Size mismatch for FPerSkeletonAnimationSharingSetup");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, Skeleton) == 0x0, "Offset mismatch for FPerSkeletonAnimationSharingSetup::Skeleton");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, SkeletalMesh) == 0x8, "Offset mismatch for FPerSkeletonAnimationSharingSetup::SkeletalMesh");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, BlendAnimBlueprint) == 0x10, "Offset mismatch for FPerSkeletonAnimationSharingSetup::BlendAnimBlueprint");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, AdditiveAnimBlueprint) == 0x18, "Offset mismatch for FPerSkeletonAnimationSharingSetup::AdditiveAnimBlueprint");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, StateProcessorClass) == 0x20, "Offset mismatch for FPerSkeletonAnimationSharingSetup::StateProcessorClass");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, bEnableMaterialParameterCaching) == 0x28, "Offset mismatch for FPerSkeletonAnimationSharingSetup::bEnableMaterialParameterCaching");
static_assert(offsetof(FPerSkeletonAnimationSharingSetup, AnimationStates) == 0x30, "Offset mismatch for FPerSkeletonAnimationSharingSetup::AnimationStates");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAnimationSharingScalability
{
    FPerPlatformBool UseBlendTransitions; // 0x0 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FPerPlatformFloat BlendSignificanceValue; // 0x4 (Size: 0x4, Type: StructProperty)
    FPerPlatformInt MaximumNumberConcurrentBlends; // 0x8 (Size: 0x4, Type: StructProperty)
    FPerPlatformFloat TickSignificanceValue; // 0xc (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FAnimationSharingScalability) == 0x10, "Size mismatch for FAnimationSharingScalability");
static_assert(offsetof(FAnimationSharingScalability, UseBlendTransitions) == 0x0, "Offset mismatch for FAnimationSharingScalability::UseBlendTransitions");
static_assert(offsetof(FAnimationSharingScalability, BlendSignificanceValue) == 0x4, "Offset mismatch for FAnimationSharingScalability::BlendSignificanceValue");
static_assert(offsetof(FAnimationSharingScalability, MaximumNumberConcurrentBlends) == 0x8, "Offset mismatch for FAnimationSharingScalability::MaximumNumberConcurrentBlends");
static_assert(offsetof(FAnimationSharingScalability, TickSignificanceValue) == 0xc, "Offset mismatch for FAnimationSharingScalability::TickSignificanceValue");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
struct FTickAnimationSharingFunction : FTickFunction
{
};

static_assert(sizeof(FTickAnimationSharingFunction) == 0x30, "Size mismatch for FTickAnimationSharingFunction");

