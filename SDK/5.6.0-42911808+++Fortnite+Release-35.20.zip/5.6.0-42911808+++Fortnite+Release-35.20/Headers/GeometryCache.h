/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GeometryCache
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "Niagara.h"

// Size: 0x98 (Inherited: 0x28, Single: 0x70)
class UGeometryCache : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<UMaterialInterface*> Materials; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> MaterialSlotNames; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<UGeometryCacheTrack*> Tracks; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UAssetUserData*> AssetUserData; // 0x60 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_70[0x18]; // 0x70 (Size: 0x18, Type: PaddingProperty)
    int32_t StartFrame; // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t EndFrame; // 0x8c (Size: 0x4, Type: IntProperty)
    uint64_t Hash; // 0x90 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(UGeometryCache) == 0x98, "Size mismatch for UGeometryCache");
static_assert(offsetof(UGeometryCache, Materials) == 0x30, "Offset mismatch for UGeometryCache::Materials");
static_assert(offsetof(UGeometryCache, MaterialSlotNames) == 0x40, "Offset mismatch for UGeometryCache::MaterialSlotNames");
static_assert(offsetof(UGeometryCache, Tracks) == 0x50, "Offset mismatch for UGeometryCache::Tracks");
static_assert(offsetof(UGeometryCache, AssetUserData) == 0x60, "Offset mismatch for UGeometryCache::AssetUserData");
static_assert(offsetof(UGeometryCache, StartFrame) == 0x88, "Offset mismatch for UGeometryCache::StartFrame");
static_assert(offsetof(UGeometryCache, EndFrame) == 0x8c, "Offset mismatch for UGeometryCache::EndFrame");
static_assert(offsetof(UGeometryCache, Hash) == 0x90, "Offset mismatch for UGeometryCache::Hash");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AGeometryCacheActor : public AActor
{
public:
    UGeometryCacheComponent* GeometryCacheComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)

public:
    UGeometryCacheComponent* GetGeometryCacheComponent() const; // 0xa598a54 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AGeometryCacheActor) == 0x2b0, "Size mismatch for AGeometryCacheActor");
static_assert(offsetof(AGeometryCacheActor, GeometryCacheComponent) == 0x2a8, "Offset mismatch for AGeometryCacheActor::GeometryCacheComponent");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGeometryCacheCodecBase : public UObject
{
public:
    TArray<int32_t> TopologyRanges; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGeometryCacheCodecBase) == 0x38, "Size mismatch for UGeometryCacheCodecBase");
static_assert(offsetof(UGeometryCacheCodecBase, TopologyRanges) == 0x28, "Offset mismatch for UGeometryCacheCodecBase::TopologyRanges");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UGeometryCacheCodecRaw : public UGeometryCacheCodecBase
{
public:
    int32_t DummyProperty; // 0x38 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCacheCodecRaw) == 0x40, "Size mismatch for UGeometryCacheCodecRaw");
static_assert(offsetof(UGeometryCacheCodecRaw, DummyProperty) == 0x38, "Offset mismatch for UGeometryCacheCodecRaw::DummyProperty");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UGeometryCacheCodecV1 : public UGeometryCacheCodecBase
{
public:
};

static_assert(sizeof(UGeometryCacheCodecV1) == 0x40, "Size mismatch for UGeometryCacheCodecV1");

// Size: 0x5f0 (Inherited: 0xda0, Single: 0xfffff850)
class UGeometryCacheComponent : public UMeshComponent
{
public:
    UGeometryCache* GeometryCache; // 0x560 (Size: 0x8, Type: ObjectProperty)
    bool bRunning; // 0x568 (Size: 0x1, Type: BoolProperty)
    bool bLooping; // 0x569 (Size: 0x1, Type: BoolProperty)
    bool bExtrapolateFrames; // 0x56a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_56b[0x1]; // 0x56b (Size: 0x1, Type: PaddingProperty)
    float StartTimeOffset; // 0x56c (Size: 0x4, Type: FloatProperty)
    float PlaybackSpeed; // 0x570 (Size: 0x4, Type: FloatProperty)
    float MotionVectorScale; // 0x574 (Size: 0x4, Type: FloatProperty)
    int32_t NumTracks; // 0x578 (Size: 0x4, Type: IntProperty)
    float ElapsedTime; // 0x57c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_580[0x4c]; // 0x580 (Size: 0x4c, Type: PaddingProperty)
    float duration; // 0x5cc (Size: 0x4, Type: FloatProperty)
    bool bManualTick; // 0x5d0 (Size: 0x1, Type: BoolProperty)
    bool bOverrideWireframeColor; // 0x5d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5d2[0x2]; // 0x5d2 (Size: 0x2, Type: PaddingProperty)
    FLinearColor WireframeOverrideColor; // 0x5d4 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_5e4[0xc]; // 0x5e4 (Size: 0xc, Type: PaddingProperty)

public:
    float GetAnimationTime() const; // 0x10919614 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDuration() const; // 0x10919648 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetElapsedTime() const; // 0xa1551e8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetMotionVectorScale() const; // 0x10919660 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOfFrames() const; // 0x1091968c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOfTracks() const; // 0x109196c0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetOverrideWireframeColor() const; // 0x109196e8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPlaybackDirection() const; // 0xf22ee44 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPlaybackSpeed() const; // 0x10919700 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStartTimeOffset() const; // 0x1091972c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FLinearColor GetWireframeOverrideColor() const; // 0x10919744 (Index: 0xa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsExtrapolatingFrames() const; // 0x10919760 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLooping() const; // 0x10919778 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlaying() const; // 0x10919790 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlayingReversed() const; // 0x109197a8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Pause(); // 0x109197dc (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void Play(); // 0x109197fc (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void PlayFromStart(); // 0x10919840 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void PlayReversed(); // 0x10919888 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void PlayReversedFromEnd(); // 0x109198cc (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void SetExtrapolateFrames(bool& const bNewExtrapolating); // 0x1091991c (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    bool SetGeometryCache(UGeometryCache*& NewGeomCache); // 0x10919a48 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetLooping(bool& const bNewLooping); // 0x10919b80 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetMotionVectorScale(float& const NewMotionVectorScale); // 0x10919da8 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetOverrideWireframeColor(bool& bOverride); // 0x10919ee4 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlaybackSpeed(float& const NewPlaybackSpeed); // 0x1091a010 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetStartTimeOffset(float& const NewStartTimeOffset); // 0x1091a14c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SetWireframeOverrideColor(FLinearColor& const Color); // 0x1091a29c (Index: 0x1b, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void Stop(); // 0x1091a35c (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void TickAtThisTime(float& const time, bool& bInIsRunning, bool& bInBackwards, bool& bInIsLooping); // 0x1091a374 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryCacheComponent) == 0x5f0, "Size mismatch for UGeometryCacheComponent");
static_assert(offsetof(UGeometryCacheComponent, GeometryCache) == 0x560, "Offset mismatch for UGeometryCacheComponent::GeometryCache");
static_assert(offsetof(UGeometryCacheComponent, bRunning) == 0x568, "Offset mismatch for UGeometryCacheComponent::bRunning");
static_assert(offsetof(UGeometryCacheComponent, bLooping) == 0x569, "Offset mismatch for UGeometryCacheComponent::bLooping");
static_assert(offsetof(UGeometryCacheComponent, bExtrapolateFrames) == 0x56a, "Offset mismatch for UGeometryCacheComponent::bExtrapolateFrames");
static_assert(offsetof(UGeometryCacheComponent, StartTimeOffset) == 0x56c, "Offset mismatch for UGeometryCacheComponent::StartTimeOffset");
static_assert(offsetof(UGeometryCacheComponent, PlaybackSpeed) == 0x570, "Offset mismatch for UGeometryCacheComponent::PlaybackSpeed");
static_assert(offsetof(UGeometryCacheComponent, MotionVectorScale) == 0x574, "Offset mismatch for UGeometryCacheComponent::MotionVectorScale");
static_assert(offsetof(UGeometryCacheComponent, NumTracks) == 0x578, "Offset mismatch for UGeometryCacheComponent::NumTracks");
static_assert(offsetof(UGeometryCacheComponent, ElapsedTime) == 0x57c, "Offset mismatch for UGeometryCacheComponent::ElapsedTime");
static_assert(offsetof(UGeometryCacheComponent, duration) == 0x5cc, "Offset mismatch for UGeometryCacheComponent::duration");
static_assert(offsetof(UGeometryCacheComponent, bManualTick) == 0x5d0, "Offset mismatch for UGeometryCacheComponent::bManualTick");
static_assert(offsetof(UGeometryCacheComponent, bOverrideWireframeColor) == 0x5d1, "Offset mismatch for UGeometryCacheComponent::bOverrideWireframeColor");
static_assert(offsetof(UGeometryCacheComponent, WireframeOverrideColor) == 0x5d4, "Offset mismatch for UGeometryCacheComponent::WireframeOverrideColor");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UGeometryCacheTrack : public UObject
{
public:
    float duration; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x2c]; // 0x2c (Size: 0x2c, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCacheTrack) == 0x58, "Size mismatch for UGeometryCacheTrack");
static_assert(offsetof(UGeometryCacheTrack, duration) == 0x28, "Offset mismatch for UGeometryCacheTrack::duration");

// Size: 0x80 (Inherited: 0x80, Single: 0x0)
class UGeometryCacheTrack_FlipbookAnimation : public UGeometryCacheTrack
{
public:
    uint32_t NumMeshSamples; // 0x58 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_5c[0x24]; // 0x5c (Size: 0x24, Type: PaddingProperty)

public:
    void AddMeshSample(const FGeometryCacheMeshData MeshData, float& const SampleTime); // 0x1091949c (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UGeometryCacheTrack_FlipbookAnimation) == 0x80, "Size mismatch for UGeometryCacheTrack_FlipbookAnimation");
static_assert(offsetof(UGeometryCacheTrack_FlipbookAnimation, NumMeshSamples) == 0x58, "Offset mismatch for UGeometryCacheTrack_FlipbookAnimation::NumMeshSamples");

// Size: 0xd0 (Inherited: 0x80, Single: 0x50)
class UGeometryCacheTrackStreamable : public UGeometryCacheTrack
{
public:
    UGeometryCacheCodecBase* Codec; // 0x58 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_60[0x60]; // 0x60 (Size: 0x60, Type: PaddingProperty)
    float StartSampleTime; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0xc]; // 0xc4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCacheTrackStreamable) == 0xd0, "Size mismatch for UGeometryCacheTrackStreamable");
static_assert(offsetof(UGeometryCacheTrackStreamable, Codec) == 0x58, "Offset mismatch for UGeometryCacheTrackStreamable::Codec");
static_assert(offsetof(UGeometryCacheTrackStreamable, StartSampleTime) == 0xc0, "Offset mismatch for UGeometryCacheTrackStreamable::StartSampleTime");

// Size: 0x120 (Inherited: 0x80, Single: 0xa0)
class UGeometryCacheTrack_TransformAnimation : public UGeometryCacheTrack
{
public:

public:
    void SetMesh(const FGeometryCacheMeshData NewMeshData); // 0x10919cac (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UGeometryCacheTrack_TransformAnimation) == 0x120, "Size mismatch for UGeometryCacheTrack_TransformAnimation");

// Size: 0x120 (Inherited: 0x80, Single: 0xa0)
class UGeometryCacheTrack_TransformGroupAnimation : public UGeometryCacheTrack
{
public:

public:
    void SetMesh(const FGeometryCacheMeshData NewMeshData); // 0x10919cac (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UGeometryCacheTrack_TransformGroupAnimation) == 0x120, "Size mismatch for UGeometryCacheTrack_TransformGroupAnimation");

// Size: 0x260 (Inherited: 0xf8, Single: 0x168)
class UNiagaraGeometryCacheRendererProperties : public UNiagaraRendererProperties
{
public:
    TArray<FNiagaraGeometryCacheReference> GeometryCaches; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    uint8_t SourceMode; // 0xb8 (Size: 0x1, Type: EnumProperty)
    bool bIsLooping; // 0xb9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ba[0x2]; // 0xba (Size: 0x2, Type: PaddingProperty)
    uint32_t ComponentCountLimit; // 0xbc (Size: 0x4, Type: UInt32Property)
    FNiagaraVariableAttributeBinding PositionBinding; // 0xc0 (Size: 0x28, Type: StructProperty)
    FNiagaraVariableAttributeBinding RotationBinding; // 0xe8 (Size: 0x28, Type: StructProperty)
    FNiagaraVariableAttributeBinding ScaleBinding; // 0x110 (Size: 0x28, Type: StructProperty)
    FNiagaraVariableAttributeBinding ElapsedTimeBinding; // 0x138 (Size: 0x28, Type: StructProperty)
    FNiagaraVariableAttributeBinding EnabledBinding; // 0x160 (Size: 0x28, Type: StructProperty)
    FNiagaraVariableAttributeBinding ArrayIndexBinding; // 0x188 (Size: 0x28, Type: StructProperty)
    FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x1b0 (Size: 0x28, Type: StructProperty)
    int32_t RendererVisibility; // 0x1d8 (Size: 0x4, Type: IntProperty)
    bool bAssignComponentsOnParticleID; // 0x1dc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1dd[0x3]; // 0x1dd (Size: 0x3, Type: PaddingProperty)
    FNiagaraRendererMaterialParameters MaterialParameters; // 0x1e0 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_230[0x30]; // 0x230 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(UNiagaraGeometryCacheRendererProperties) == 0x260, "Size mismatch for UNiagaraGeometryCacheRendererProperties");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, GeometryCaches) == 0xa8, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::GeometryCaches");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, SourceMode) == 0xb8, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::SourceMode");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, bIsLooping) == 0xb9, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::bIsLooping");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, ComponentCountLimit) == 0xbc, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::ComponentCountLimit");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, PositionBinding) == 0xc0, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::PositionBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, RotationBinding) == 0xe8, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::RotationBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, ScaleBinding) == 0x110, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::ScaleBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, ElapsedTimeBinding) == 0x138, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::ElapsedTimeBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, EnabledBinding) == 0x160, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::EnabledBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, ArrayIndexBinding) == 0x188, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::ArrayIndexBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, RendererVisibilityTagBinding) == 0x1b0, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::RendererVisibilityTagBinding");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, RendererVisibility) == 0x1d8, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::RendererVisibility");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, bAssignComponentsOnParticleID) == 0x1dc, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::bAssignComponentsOnParticleID");
static_assert(offsetof(UNiagaraGeometryCacheRendererProperties, MaterialParameters) == 0x1e0, "Offset mismatch for UNiagaraGeometryCacheRendererProperties::MaterialParameters");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FTrackRenderData
{
};

static_assert(sizeof(FTrackRenderData) == 0xc0, "Size mismatch for FTrackRenderData");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryCacheMeshBatchInfo
{
};

static_assert(sizeof(FGeometryCacheMeshBatchInfo) == 0xc, "Size mismatch for FGeometryCacheMeshBatchInfo");

// Size: 0x9 (Inherited: 0x0, Single: 0x9)
struct FGeometryCacheVertexInfo
{
};

static_assert(sizeof(FGeometryCacheVertexInfo) == 0x9, "Size mismatch for FGeometryCacheVertexInfo");

// Size: 0xc8 (Inherited: 0x0, Single: 0xc8)
struct FGeometryCacheMeshData
{
};

static_assert(sizeof(FGeometryCacheMeshData) == 0xc8, "Size mismatch for FGeometryCacheMeshData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FNiagaraGeometryCacheMICOverride
{
    UMaterialInterface* OriginalMaterial; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceConstant* ReplacementMaterial; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FNiagaraGeometryCacheMICOverride) == 0x10, "Size mismatch for FNiagaraGeometryCacheMICOverride");
static_assert(offsetof(FNiagaraGeometryCacheMICOverride, OriginalMaterial) == 0x0, "Offset mismatch for FNiagaraGeometryCacheMICOverride::OriginalMaterial");
static_assert(offsetof(FNiagaraGeometryCacheMICOverride, ReplacementMaterial) == 0x8, "Offset mismatch for FNiagaraGeometryCacheMICOverride::ReplacementMaterial");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FNiagaraGeometryCacheReference
{
    UGeometryCache* GeometryCache; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FNiagaraUserParameterBinding GeometryCacheUserParamBinding; // 0x8 (Size: 0x18, Type: StructProperty)
    TArray<UMaterialInterface*> OverrideMaterials; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FNiagaraGeometryCacheMICOverride> MICOverrideMaterials; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FNiagaraGeometryCacheReference) == 0x40, "Size mismatch for FNiagaraGeometryCacheReference");
static_assert(offsetof(FNiagaraGeometryCacheReference, GeometryCache) == 0x0, "Offset mismatch for FNiagaraGeometryCacheReference::GeometryCache");
static_assert(offsetof(FNiagaraGeometryCacheReference, GeometryCacheUserParamBinding) == 0x8, "Offset mismatch for FNiagaraGeometryCacheReference::GeometryCacheUserParamBinding");
static_assert(offsetof(FNiagaraGeometryCacheReference, OverrideMaterials) == 0x20, "Offset mismatch for FNiagaraGeometryCacheReference::OverrideMaterials");
static_assert(offsetof(FNiagaraGeometryCacheReference, MICOverrideMaterials) == 0x30, "Offset mismatch for FNiagaraGeometryCacheReference::MICOverrideMaterials");

