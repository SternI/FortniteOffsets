/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BuildPatchServices
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x120 (Inherited: 0x28, Single: 0xf8)
class UBuildPatchManifest : public UObject
{
public:
    char ManifestFileVersion; // 0x28 (Size: 0x1, Type: ByteProperty)
    bool bIsFileData; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    uint32_t AppID; // 0x2c (Size: 0x4, Type: UInt32Property)
    FString AppName; // 0x30 (Size: 0x10, Type: StrProperty)
    FString BuildVersion; // 0x40 (Size: 0x10, Type: StrProperty)
    FString LaunchExe; // 0x50 (Size: 0x10, Type: StrProperty)
    FString LaunchCommand; // 0x60 (Size: 0x10, Type: StrProperty)
    TSet<FString> PrereqIds; // 0x70 (Size: 0x50, Type: SetProperty)
    FString PrereqName; // 0xc0 (Size: 0x10, Type: StrProperty)
    FString PrereqPath; // 0xd0 (Size: 0x10, Type: StrProperty)
    FString PrereqArgs; // 0xe0 (Size: 0x10, Type: StrProperty)
    TArray<FFileManifestData> FileManifestList; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<FChunkInfoData> ChunkList; // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomFieldData> CustomFields; // 0x110 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UBuildPatchManifest) == 0x120, "Size mismatch for UBuildPatchManifest");
static_assert(offsetof(UBuildPatchManifest, ManifestFileVersion) == 0x28, "Offset mismatch for UBuildPatchManifest::ManifestFileVersion");
static_assert(offsetof(UBuildPatchManifest, bIsFileData) == 0x29, "Offset mismatch for UBuildPatchManifest::bIsFileData");
static_assert(offsetof(UBuildPatchManifest, AppID) == 0x2c, "Offset mismatch for UBuildPatchManifest::AppID");
static_assert(offsetof(UBuildPatchManifest, AppName) == 0x30, "Offset mismatch for UBuildPatchManifest::AppName");
static_assert(offsetof(UBuildPatchManifest, BuildVersion) == 0x40, "Offset mismatch for UBuildPatchManifest::BuildVersion");
static_assert(offsetof(UBuildPatchManifest, LaunchExe) == 0x50, "Offset mismatch for UBuildPatchManifest::LaunchExe");
static_assert(offsetof(UBuildPatchManifest, LaunchCommand) == 0x60, "Offset mismatch for UBuildPatchManifest::LaunchCommand");
static_assert(offsetof(UBuildPatchManifest, PrereqIds) == 0x70, "Offset mismatch for UBuildPatchManifest::PrereqIds");
static_assert(offsetof(UBuildPatchManifest, PrereqName) == 0xc0, "Offset mismatch for UBuildPatchManifest::PrereqName");
static_assert(offsetof(UBuildPatchManifest, PrereqPath) == 0xd0, "Offset mismatch for UBuildPatchManifest::PrereqPath");
static_assert(offsetof(UBuildPatchManifest, PrereqArgs) == 0xe0, "Offset mismatch for UBuildPatchManifest::PrereqArgs");
static_assert(offsetof(UBuildPatchManifest, FileManifestList) == 0xf0, "Offset mismatch for UBuildPatchManifest::FileManifestList");
static_assert(offsetof(UBuildPatchManifest, ChunkList) == 0x100, "Offset mismatch for UBuildPatchManifest::ChunkList");
static_assert(offsetof(UBuildPatchManifest, CustomFields) == 0x110, "Offset mismatch for UBuildPatchManifest::CustomFields");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCustomFieldData
{
    FString Key; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCustomFieldData) == 0x20, "Size mismatch for FCustomFieldData");
static_assert(offsetof(FCustomFieldData, Key) == 0x0, "Offset mismatch for FCustomFieldData::Key");
static_assert(offsetof(FCustomFieldData, Value) == 0x10, "Offset mismatch for FCustomFieldData::Value");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FSHAHashData
{
    char Hash[0x14]; // 0x0 (Size: 0x14, Type: ByteProperty)
};

static_assert(sizeof(FSHAHashData) == 0x14, "Size mismatch for FSHAHashData");
static_assert(offsetof(FSHAHashData, Hash) == 0x0, "Offset mismatch for FSHAHashData::Hash");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FChunkInfoData
{
    FGuid Guid; // 0x0 (Size: 0x10, Type: StructProperty)
    uint64_t Hash; // 0x10 (Size: 0x8, Type: UInt64Property)
    FSHAHashData ShaHash; // 0x18 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    int64_t FileSize; // 0x30 (Size: 0x8, Type: Int64Property)
    char GroupNumber; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChunkInfoData) == 0x40, "Size mismatch for FChunkInfoData");
static_assert(offsetof(FChunkInfoData, Guid) == 0x0, "Offset mismatch for FChunkInfoData::Guid");
static_assert(offsetof(FChunkInfoData, Hash) == 0x10, "Offset mismatch for FChunkInfoData::Hash");
static_assert(offsetof(FChunkInfoData, ShaHash) == 0x18, "Offset mismatch for FChunkInfoData::ShaHash");
static_assert(offsetof(FChunkInfoData, FileSize) == 0x30, "Offset mismatch for FChunkInfoData::FileSize");
static_assert(offsetof(FChunkInfoData, GroupNumber) == 0x38, "Offset mismatch for FChunkInfoData::GroupNumber");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChunkPartData
{
    FGuid Guid; // 0x0 (Size: 0x10, Type: StructProperty)
    uint32_t Offset; // 0x10 (Size: 0x4, Type: UInt32Property)
    uint32_t Size; // 0x14 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FChunkPartData) == 0x18, "Size mismatch for FChunkPartData");
static_assert(offsetof(FChunkPartData, Guid) == 0x0, "Offset mismatch for FChunkPartData::Guid");
static_assert(offsetof(FChunkPartData, Offset) == 0x10, "Offset mismatch for FChunkPartData::Offset");
static_assert(offsetof(FChunkPartData, Size) == 0x14, "Offset mismatch for FChunkPartData::Size");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FFileManifestData
{
    FString Filename; // 0x0 (Size: 0x10, Type: StrProperty)
    FSHAHashData FileHash; // 0x10 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FChunkPartData> FileChunkParts; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> InstallTags; // 0x38 (Size: 0x10, Type: ArrayProperty)
    bool bIsUnixExecutable; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    FString SymlinkTarget; // 0x50 (Size: 0x10, Type: StrProperty)
    bool bIsReadOnly; // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bIsCompressed; // 0x61 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_62[0x6]; // 0x62 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FFileManifestData) == 0x68, "Size mismatch for FFileManifestData");
static_assert(offsetof(FFileManifestData, Filename) == 0x0, "Offset mismatch for FFileManifestData::Filename");
static_assert(offsetof(FFileManifestData, FileHash) == 0x10, "Offset mismatch for FFileManifestData::FileHash");
static_assert(offsetof(FFileManifestData, FileChunkParts) == 0x28, "Offset mismatch for FFileManifestData::FileChunkParts");
static_assert(offsetof(FFileManifestData, InstallTags) == 0x38, "Offset mismatch for FFileManifestData::InstallTags");
static_assert(offsetof(FFileManifestData, bIsUnixExecutable) == 0x48, "Offset mismatch for FFileManifestData::bIsUnixExecutable");
static_assert(offsetof(FFileManifestData, SymlinkTarget) == 0x50, "Offset mismatch for FFileManifestData::SymlinkTarget");
static_assert(offsetof(FFileManifestData, bIsReadOnly) == 0x60, "Offset mismatch for FFileManifestData::bIsReadOnly");
static_assert(offsetof(FFileManifestData, bIsCompressed) == 0x61, "Offset mismatch for FFileManifestData::bIsCompressed");

