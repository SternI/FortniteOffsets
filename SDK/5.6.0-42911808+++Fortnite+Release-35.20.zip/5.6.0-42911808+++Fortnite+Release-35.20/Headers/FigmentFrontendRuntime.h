/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FigmentFrontendRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x110 (Inherited: 0x28, Single: 0xe8)
class UFigmentFrontendExperienceFlow : public UObject
{
public:
    uint8_t Pad_28[0x38]; // 0x28 (Size: 0x38, Type: PaddingProperty)
    TSoftClassPtr VideoPlayerClass; // 0x60 (Size: 0x20, Type: SoftClassProperty)
    TArray<FString> FlowStepArray; // 0x80 (Size: 0x10, Type: ArrayProperty)
    bool bEnableTrailer; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    FString CinematicTrailerVUID; // 0x98 (Size: 0x10, Type: StrProperty)
    FName CinematicTrailerString; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    TMap<FString, FString> CinematicTrailerRating; // 0xb0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_100[0x8]; // 0x100 (Size: 0x8, Type: PaddingProperty)
    UClass* SimpleBuildAndEditModalHelper; // 0x108 (Size: 0x8, Type: ClassProperty)

private:
    void HandleFinishTrailerStep(); // 0x110f9e58 (Index: 0x0, Flags: Final|Native|Private)
    void HandleTrailerTerminalError(EBaseMediaTerminalErrorReason& Reason); // 0x110f9e6c (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFigmentFrontendExperienceFlow) == 0x110, "Size mismatch for UFigmentFrontendExperienceFlow");
static_assert(offsetof(UFigmentFrontendExperienceFlow, VideoPlayerClass) == 0x60, "Offset mismatch for UFigmentFrontendExperienceFlow::VideoPlayerClass");
static_assert(offsetof(UFigmentFrontendExperienceFlow, FlowStepArray) == 0x80, "Offset mismatch for UFigmentFrontendExperienceFlow::FlowStepArray");
static_assert(offsetof(UFigmentFrontendExperienceFlow, bEnableTrailer) == 0x90, "Offset mismatch for UFigmentFrontendExperienceFlow::bEnableTrailer");
static_assert(offsetof(UFigmentFrontendExperienceFlow, CinematicTrailerVUID) == 0x98, "Offset mismatch for UFigmentFrontendExperienceFlow::CinematicTrailerVUID");
static_assert(offsetof(UFigmentFrontendExperienceFlow, CinematicTrailerString) == 0xa8, "Offset mismatch for UFigmentFrontendExperienceFlow::CinematicTrailerString");
static_assert(offsetof(UFigmentFrontendExperienceFlow, CinematicTrailerRating) == 0xb0, "Offset mismatch for UFigmentFrontendExperienceFlow::CinematicTrailerRating");
static_assert(offsetof(UFigmentFrontendExperienceFlow, SimpleBuildAndEditModalHelper) == 0x108, "Offset mismatch for UFigmentFrontendExperienceFlow::SimpleBuildAndEditModalHelper");

