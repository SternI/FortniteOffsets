/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamMapRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "Engine.h"

// Size: 0x210 (Inherited: 0x570, Single: 0xfffffca0)
class UJamIslandPlayspaceComponent_ServerExpiration : public UPlayspaceComponent_ServerExpiration
{
public:
};

static_assert(sizeof(UJamIslandPlayspaceComponent_ServerExpiration) == 0x210, "Size mismatch for UJamIslandPlayspaceComponent_ServerExpiration");

// Size: 0x250 (Inherited: 0x560, Single: 0xfffffcf0)
class UFMJamMapInputBasedAFKComponent : public UFortInputBasedAFKComponent
{
public:
    FDataTableRowHandle AFKTableRowEntry; // 0x1d0 (Size: 0x10, Type: StructProperty)
    FInputBasedAFKDetectionParameters CachedAFKDetectionParameters; // 0x1e0 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(UFMJamMapInputBasedAFKComponent) == 0x250, "Size mismatch for UFMJamMapInputBasedAFKComponent");
static_assert(offsetof(UFMJamMapInputBasedAFKComponent, AFKTableRowEntry) == 0x1d0, "Offset mismatch for UFMJamMapInputBasedAFKComponent::AFKTableRowEntry");
static_assert(offsetof(UFMJamMapInputBasedAFKComponent, CachedAFKDetectionParameters) == 0x1e0, "Offset mismatch for UFMJamMapInputBasedAFKComponent::CachedAFKDetectionParameters");

