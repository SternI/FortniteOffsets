/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimPresetsCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"
#include "IKRig.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAnimPreset : public UObject
{
public:

public:
    virtual TSoftClassPtr GetPresetClass() const; // 0xbff56b4 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void HandleAnimInstance(UAnimInstance*& Instance) const; // 0xbff5700 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UAnimPreset) == 0x28, "Size mismatch for UAnimPreset");

// Size: 0x7b0 (Inherited: 0x408, Single: 0x3a8)
class UNPCRetargetAnimInstance : public UAnimInstance
{
public:
    FAnimNode_RetargetPoseFromMesh RetargetNode; // 0x3d8 (Size: 0x3d0, Type: StructProperty)
    uint8_t Pad_7a8[0x8]; // 0x7a8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UNPCRetargetAnimInstance) == 0x7b0, "Size mismatch for UNPCRetargetAnimInstance");
static_assert(offsetof(UNPCRetargetAnimInstance, RetargetNode) == 0x3d8, "Offset mismatch for UNPCRetargetAnimInstance::RetargetNode");

// Size: 0x7a0 (Inherited: 0x7a0, Single: 0x0)
struct FNPCRetargetAnimInstanceProxy : FAnimInstanceProxy
{
};

static_assert(sizeof(FNPCRetargetAnimInstanceProxy) == 0x7a0, "Size mismatch for FNPCRetargetAnimInstanceProxy");

