/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_VehicleCosmeticsTrailTest
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class ABP_VehicleCosmeticsTrailTest_C : public AActor
{
public:
    UStaticMeshComponent* StaticMesh; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ABP_VehicleCosmeticsTrailTest_C) == 0x2b8, "Size mismatch for ABP_VehicleCosmeticsTrailTest_C");
static_assert(offsetof(ABP_VehicleCosmeticsTrailTest_C, StaticMesh) == 0x2a8, "Offset mismatch for ABP_VehicleCosmeticsTrailTest_C::StaticMesh");
static_assert(offsetof(ABP_VehicleCosmeticsTrailTest_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ABP_VehicleCosmeticsTrailTest_C::DefaultSceneRoot");

