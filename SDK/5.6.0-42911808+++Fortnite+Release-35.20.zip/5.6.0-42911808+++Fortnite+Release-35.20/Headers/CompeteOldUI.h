/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CompeteOldUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x48 (Inherited: 0x78, Single: 0xffffffd0)
class UFortUIGameFeatureAction_CompeteOldUI : public UFortUIGameFeatureAction
{
public:
    TSoftClassPtr TournamentModalClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UFortUIGameFeatureAction_CompeteOldUI) == 0x48, "Size mismatch for UFortUIGameFeatureAction_CompeteOldUI");
static_assert(offsetof(UFortUIGameFeatureAction_CompeteOldUI, TournamentModalClass) == 0x28, "Offset mismatch for UFortUIGameFeatureAction_CompeteOldUI::TournamentModalClass");

