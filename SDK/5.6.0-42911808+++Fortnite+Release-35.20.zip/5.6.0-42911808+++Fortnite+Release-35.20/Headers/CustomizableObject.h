/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomizableObject
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "ClothingSystemRuntimeCommon.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCustomizableObjectExtension : public UObject
{
public:
};

static_assert(sizeof(UCustomizableObjectExtension) == 0x28, "Size mismatch for UCustomizableObjectExtension");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UCustomizableObjectInstanceUserData : public UAssetUserData
{
public:
    FGameplayTagContainer AnimationGameplayTag; // 0x28 (Size: 0x20, Type: StructProperty)
    TArray<FCustomizableObjectAnimationSlot> AnimationSlots; // 0x48 (Size: 0x10, Type: ArrayProperty)

public:
    FGameplayTagContainer GetAnimationGameplayTags() const; // 0xb21250c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAnimationGameplayTags(const FGameplayTagContainer InstanceTags); // 0xb2125e4 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCustomizableObjectInstanceUserData) == 0x58, "Size mismatch for UCustomizableObjectInstanceUserData");
static_assert(offsetof(UCustomizableObjectInstanceUserData, AnimationGameplayTag) == 0x28, "Offset mismatch for UCustomizableObjectInstanceUserData::AnimationGameplayTag");
static_assert(offsetof(UCustomizableObjectInstanceUserData, AnimationSlots) == 0x48, "Offset mismatch for UCustomizableObjectInstanceUserData::AnimationSlots");

// Size: 0x558 (Inherited: 0x28, Single: 0x530)
class UCustomizableInstancePrivate : public UObject
{
public:
    TMap<USkeletalMesh*, FName> SkeletalMeshes; // 0x28 (Size: 0x50, Type: MapProperty)
    TArray<FGeneratedMaterial> GeneratedMaterials; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FGeneratedTexture> GeneratedTextures; // 0x88 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_98[0x10]; // 0x98 (Size: 0x10, Type: PaddingProperty)
    TMap<TWeakObjectPtr<UTexture2D*>, FString> TextureReuseCache; // 0xa8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_f8[0x10]; // 0xf8 (Size: 0x10, Type: PaddingProperty)
    TArray<FCustomizableInstanceComponentData> ComponentsData; // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> ReferencedMaterials; // 0x118 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_128[0x60]; // 0x128 (Size: 0x60, Type: PaddingProperty)
    TArray<UPhysicsAsset*> ClothingPhysicsAssets; // 0x188 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> GatheredAnimBPs; // 0x198 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer AnimBPGameplayTags; // 0x1a8 (Size: 0x20, Type: StructProperty)
    TMap<FAnimBpGeneratedPhysicsAssets, UClass*> AnimBpPhysicsAssets; // 0x1c8 (Size: 0x50, Type: MapProperty)
    TArray<FExtensionInstanceData> ExtensionInstanceData; // 0x218 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_228[0x20]; // 0x228 (Size: 0x20, Type: PaddingProperty)
    TArray<UTexture*> LoadedPassThroughTexturesPendingSetMaterial; // 0x248 (Size: 0x10, Type: ArrayProperty)
    TArray<UStreamableRenderAsset*> LoadedPassThroughMeshesPendingSetMaterial; // 0x258 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_268[0x8]; // 0x268 (Size: 0x8, Type: PaddingProperty)
    FCustomizableObjectInstanceDescriptor CommittedDescriptor; // 0x270 (Size: 0x180, Type: StructProperty)
    uint8_t Pad_3f0[0x168]; // 0x3f0 (Size: 0x168, Type: PaddingProperty)
};

static_assert(sizeof(UCustomizableInstancePrivate) == 0x558, "Size mismatch for UCustomizableInstancePrivate");
static_assert(offsetof(UCustomizableInstancePrivate, SkeletalMeshes) == 0x28, "Offset mismatch for UCustomizableInstancePrivate::SkeletalMeshes");
static_assert(offsetof(UCustomizableInstancePrivate, GeneratedMaterials) == 0x78, "Offset mismatch for UCustomizableInstancePrivate::GeneratedMaterials");
static_assert(offsetof(UCustomizableInstancePrivate, GeneratedTextures) == 0x88, "Offset mismatch for UCustomizableInstancePrivate::GeneratedTextures");
static_assert(offsetof(UCustomizableInstancePrivate, TextureReuseCache) == 0xa8, "Offset mismatch for UCustomizableInstancePrivate::TextureReuseCache");
static_assert(offsetof(UCustomizableInstancePrivate, ComponentsData) == 0x108, "Offset mismatch for UCustomizableInstancePrivate::ComponentsData");
static_assert(offsetof(UCustomizableInstancePrivate, ReferencedMaterials) == 0x118, "Offset mismatch for UCustomizableInstancePrivate::ReferencedMaterials");
static_assert(offsetof(UCustomizableInstancePrivate, ClothingPhysicsAssets) == 0x188, "Offset mismatch for UCustomizableInstancePrivate::ClothingPhysicsAssets");
static_assert(offsetof(UCustomizableInstancePrivate, GatheredAnimBPs) == 0x198, "Offset mismatch for UCustomizableInstancePrivate::GatheredAnimBPs");
static_assert(offsetof(UCustomizableInstancePrivate, AnimBPGameplayTags) == 0x1a8, "Offset mismatch for UCustomizableInstancePrivate::AnimBPGameplayTags");
static_assert(offsetof(UCustomizableInstancePrivate, AnimBpPhysicsAssets) == 0x1c8, "Offset mismatch for UCustomizableInstancePrivate::AnimBpPhysicsAssets");
static_assert(offsetof(UCustomizableInstancePrivate, ExtensionInstanceData) == 0x218, "Offset mismatch for UCustomizableInstancePrivate::ExtensionInstanceData");
static_assert(offsetof(UCustomizableInstancePrivate, LoadedPassThroughTexturesPendingSetMaterial) == 0x248, "Offset mismatch for UCustomizableInstancePrivate::LoadedPassThroughTexturesPendingSetMaterial");
static_assert(offsetof(UCustomizableInstancePrivate, LoadedPassThroughMeshesPendingSetMaterial) == 0x258, "Offset mismatch for UCustomizableInstancePrivate::LoadedPassThroughMeshesPendingSetMaterial");
static_assert(offsetof(UCustomizableInstancePrivate, CommittedDescriptor) == 0x270, "Offset mismatch for UCustomizableInstancePrivate::CommittedDescriptor");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UCustomizableObjectInstanceUsage : public UObject
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> UsedSkeletalMeshComponent; // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    UCustomizableObjectInstance* UsedCustomizableObjectInstance; // 0x40 (Size: 0x8, Type: ObjectProperty)
    int32_t UsedComponentIndex; // 0x48 (Size: 0x4, Type: IntProperty)
    FName UsedComponentName; // 0x4c (Size: 0x4, Type: NameProperty)
    bool bUsedSkipSetReferenceSkeletalMesh; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bUsedSkipSetSkeletalMeshOnAttach; // 0x51 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_52[0x6]; // 0x52 (Size: 0x6, Type: PaddingProperty)
    UCustomizableObjectInstanceUsagePrivate* Private; // 0x58 (Size: 0x8, Type: ObjectProperty)

public:
    void AttachTo(USkeletalMeshComponent*& SkeletalMeshComponent); // 0xb2123e0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    USkeletalMeshComponent* GetAttachParent() const; // 0xb212528 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetComponentName() const; // 0xb21254c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomizableObjectInstance* GetCustomizableObjectInstance() const; // 0xb212578 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSkipSetReferenceSkeletalMesh() const; // 0xb21259c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSkipSetSkeletalMeshOnAttach() const; // 0xb2125c0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetComponentName(const FName Name); // 0xb212900 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetCustomizableObjectInstance(UCustomizableObjectInstance*& CustomizableObjectInstance); // 0xb2129e4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetSkipSetReferenceSkeletalMesh(bool& bSkip); // 0xb212b10 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetSkipSetSkeletalMeshOnAttach(bool& bSkip); // 0xb212c4c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateSkeletalMeshAsync(bool& bNeverSkipUpdate); // 0xb212d88 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateSkeletalMeshAsyncResult(FDelegate& Callback, bool& bIgnoreCloseDist, bool& bForceHighPriority); // 0xb212eac (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCustomizableObjectInstanceUsage) == 0x60, "Size mismatch for UCustomizableObjectInstanceUsage");
static_assert(offsetof(UCustomizableObjectInstanceUsage, UsedSkeletalMeshComponent) == 0x38, "Offset mismatch for UCustomizableObjectInstanceUsage::UsedSkeletalMeshComponent");
static_assert(offsetof(UCustomizableObjectInstanceUsage, UsedCustomizableObjectInstance) == 0x40, "Offset mismatch for UCustomizableObjectInstanceUsage::UsedCustomizableObjectInstance");
static_assert(offsetof(UCustomizableObjectInstanceUsage, UsedComponentIndex) == 0x48, "Offset mismatch for UCustomizableObjectInstanceUsage::UsedComponentIndex");
static_assert(offsetof(UCustomizableObjectInstanceUsage, UsedComponentName) == 0x4c, "Offset mismatch for UCustomizableObjectInstanceUsage::UsedComponentName");
static_assert(offsetof(UCustomizableObjectInstanceUsage, bUsedSkipSetReferenceSkeletalMesh) == 0x50, "Offset mismatch for UCustomizableObjectInstanceUsage::bUsedSkipSetReferenceSkeletalMesh");
static_assert(offsetof(UCustomizableObjectInstanceUsage, bUsedSkipSetSkeletalMeshOnAttach) == 0x51, "Offset mismatch for UCustomizableObjectInstanceUsage::bUsedSkipSetSkeletalMeshOnAttach");
static_assert(offsetof(UCustomizableObjectInstanceUsage, Private) == 0x58, "Offset mismatch for UCustomizableObjectInstanceUsage::Private");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCustomizableObjectInstanceUsagePrivate : public UObject
{
public:
};

static_assert(sizeof(UCustomizableObjectInstanceUsagePrivate) == 0x30, "Size mismatch for UCustomizableObjectInstanceUsagePrivate");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UModelStreamableData : public UObject
{
public:
};

static_assert(sizeof(UModelStreamableData) == 0x38, "Size mismatch for UModelStreamableData");

// Size: 0x488 (Inherited: 0x28, Single: 0x460)
class UModelResources : public UObject
{
public:
    TArray<FMutableRefSkeletalMeshData> ReferenceSkeletalMeshesData; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<USkeleton*>> Skeletons; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UMaterialInterface*>> Materials; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UTexture*>> PassThroughTextures; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UStreamableRenderAsset*>> PassThroughMeshes; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UPhysicsAsset*>> PhysicsAssets; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftClassPtr> AnimBPs; // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<FAnimBpOverridePhysicsAssetsInfo> AnimBpOverridePhysiscAssetsInfo; // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> MaterialSlotNames; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    TMap<uint32_t, FString> BoneNamesMap; // 0xb8 (Size: 0x50, Type: MapProperty)
    TArray<FMutableRefSocket> SocketArray; // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<FMutableSkinWeightProfileInfo> SkinWeightProfilesInfo; // 0x118 (Size: 0x10, Type: ArrayProperty)
    TArray<FMutableModelImageProperties> ImageProperties; // 0x128 (Size: 0x10, Type: ArrayProperty)
    TMap<FMutableMeshMetadata, uint32_t> MeshMetadata; // 0x138 (Size: 0x50, Type: MapProperty)
    TMap<FMutableSurfaceMetadata, uint32_t> SurfaceMetadata; // 0x188 (Size: 0x50, Type: MapProperty)
    TMap<FMutableParameterData, FString> ParameterUIDataMap; // 0x1d8 (Size: 0x50, Type: MapProperty)
    TMap<FMutableStateData, FString> StateUIDataMap; // 0x228 (Size: 0x50, Type: MapProperty)
    TArray<FCustomizableObjectClothConfigData> ClothSharedConfigsData; // 0x278 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectClothingAssetData> ClothingAssetsData; // 0x288 (Size: 0x10, Type: ArrayProperty)
    bool bAllowClothingPhysicsEditsPropagation; // 0x298 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_299[0x7]; // 0x299 (Size: 0x7, Type: PaddingProperty)
    TArray<FCustomizableObjectStreamedResourceData> StreamedResourceData; // 0x2a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectResourceData> AlwaysLoadedExtensionData; // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectStreamedResourceData> StreamedExtensionData; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TMap<char, FName> NumLODsAvailable; // 0x2d0 (Size: 0x50, Type: MapProperty)
    TMap<char, FName> NumLODsToStream; // 0x320 (Size: 0x50, Type: MapProperty)
    TMap<char, FName> FirstLODAvailable; // 0x370 (Size: 0x50, Type: MapProperty)
    TArray<FName> ComponentNamesPerObjectComponent; // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    TMap<FPerPlatformInt, FName> MinLODPerComponent; // 0x3d0 (Size: 0x50, Type: MapProperty)
    TMap<FPerQualityLevelInt, FName> MinQualityLevelLODPerComponent; // 0x420 (Size: 0x50, Type: MapProperty)
    FString ReleaseVersion; // 0x470 (Size: 0x10, Type: StrProperty)
    int32_t CodeVersion; // 0x480 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_484[0x4]; // 0x484 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UModelResources) == 0x488, "Size mismatch for UModelResources");
static_assert(offsetof(UModelResources, ReferenceSkeletalMeshesData) == 0x28, "Offset mismatch for UModelResources::ReferenceSkeletalMeshesData");
static_assert(offsetof(UModelResources, Skeletons) == 0x38, "Offset mismatch for UModelResources::Skeletons");
static_assert(offsetof(UModelResources, Materials) == 0x48, "Offset mismatch for UModelResources::Materials");
static_assert(offsetof(UModelResources, PassThroughTextures) == 0x58, "Offset mismatch for UModelResources::PassThroughTextures");
static_assert(offsetof(UModelResources, PassThroughMeshes) == 0x68, "Offset mismatch for UModelResources::PassThroughMeshes");
static_assert(offsetof(UModelResources, PhysicsAssets) == 0x78, "Offset mismatch for UModelResources::PhysicsAssets");
static_assert(offsetof(UModelResources, AnimBPs) == 0x88, "Offset mismatch for UModelResources::AnimBPs");
static_assert(offsetof(UModelResources, AnimBpOverridePhysiscAssetsInfo) == 0x98, "Offset mismatch for UModelResources::AnimBpOverridePhysiscAssetsInfo");
static_assert(offsetof(UModelResources, MaterialSlotNames) == 0xa8, "Offset mismatch for UModelResources::MaterialSlotNames");
static_assert(offsetof(UModelResources, BoneNamesMap) == 0xb8, "Offset mismatch for UModelResources::BoneNamesMap");
static_assert(offsetof(UModelResources, SocketArray) == 0x108, "Offset mismatch for UModelResources::SocketArray");
static_assert(offsetof(UModelResources, SkinWeightProfilesInfo) == 0x118, "Offset mismatch for UModelResources::SkinWeightProfilesInfo");
static_assert(offsetof(UModelResources, ImageProperties) == 0x128, "Offset mismatch for UModelResources::ImageProperties");
static_assert(offsetof(UModelResources, MeshMetadata) == 0x138, "Offset mismatch for UModelResources::MeshMetadata");
static_assert(offsetof(UModelResources, SurfaceMetadata) == 0x188, "Offset mismatch for UModelResources::SurfaceMetadata");
static_assert(offsetof(UModelResources, ParameterUIDataMap) == 0x1d8, "Offset mismatch for UModelResources::ParameterUIDataMap");
static_assert(offsetof(UModelResources, StateUIDataMap) == 0x228, "Offset mismatch for UModelResources::StateUIDataMap");
static_assert(offsetof(UModelResources, ClothSharedConfigsData) == 0x278, "Offset mismatch for UModelResources::ClothSharedConfigsData");
static_assert(offsetof(UModelResources, ClothingAssetsData) == 0x288, "Offset mismatch for UModelResources::ClothingAssetsData");
static_assert(offsetof(UModelResources, bAllowClothingPhysicsEditsPropagation) == 0x298, "Offset mismatch for UModelResources::bAllowClothingPhysicsEditsPropagation");
static_assert(offsetof(UModelResources, StreamedResourceData) == 0x2a0, "Offset mismatch for UModelResources::StreamedResourceData");
static_assert(offsetof(UModelResources, AlwaysLoadedExtensionData) == 0x2b0, "Offset mismatch for UModelResources::AlwaysLoadedExtensionData");
static_assert(offsetof(UModelResources, StreamedExtensionData) == 0x2c0, "Offset mismatch for UModelResources::StreamedExtensionData");
static_assert(offsetof(UModelResources, NumLODsAvailable) == 0x2d0, "Offset mismatch for UModelResources::NumLODsAvailable");
static_assert(offsetof(UModelResources, NumLODsToStream) == 0x320, "Offset mismatch for UModelResources::NumLODsToStream");
static_assert(offsetof(UModelResources, FirstLODAvailable) == 0x370, "Offset mismatch for UModelResources::FirstLODAvailable");
static_assert(offsetof(UModelResources, ComponentNamesPerObjectComponent) == 0x3c0, "Offset mismatch for UModelResources::ComponentNamesPerObjectComponent");
static_assert(offsetof(UModelResources, MinLODPerComponent) == 0x3d0, "Offset mismatch for UModelResources::MinLODPerComponent");
static_assert(offsetof(UModelResources, MinQualityLevelLODPerComponent) == 0x420, "Offset mismatch for UModelResources::MinQualityLevelLODPerComponent");
static_assert(offsetof(UModelResources, ReleaseVersion) == 0x470, "Offset mismatch for UModelResources::ReleaseVersion");
static_assert(offsetof(UModelResources, CodeVersion) == 0x480, "Offset mismatch for UModelResources::CodeVersion");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UCustomizableObjectBulk : public UObject
{
public:
};

static_assert(sizeof(UCustomizableObjectBulk) == 0x38, "Size mismatch for UCustomizableObjectBulk");

// Size: 0x178 (Inherited: 0x28, Single: 0x150)
class UCustomizableObjectPrivate : public UObject
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    UModelStreamableData* ModelStreamableData; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UModelResources* ModelResources; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_48[0xc8]; // 0x48 (Size: 0xc8, Type: PaddingProperty)
    TArray<FMutableModelParameterProperties> ParameterProperties; // 0x110 (Size: 0x10, Type: ArrayProperty)
    UModelResources* ReferencedObjects; // 0x120 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_128[0x50]; // 0x128 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UCustomizableObjectPrivate) == 0x178, "Size mismatch for UCustomizableObjectPrivate");
static_assert(offsetof(UCustomizableObjectPrivate, ModelStreamableData) == 0x38, "Offset mismatch for UCustomizableObjectPrivate::ModelStreamableData");
static_assert(offsetof(UCustomizableObjectPrivate, ModelResources) == 0x40, "Offset mismatch for UCustomizableObjectPrivate::ModelResources");
static_assert(offsetof(UCustomizableObjectPrivate, ParameterProperties) == 0x110, "Offset mismatch for UCustomizableObjectPrivate::ParameterProperties");
static_assert(offsetof(UCustomizableObjectPrivate, ReferencedObjects) == 0x120, "Offset mismatch for UCustomizableObjectPrivate::ReferencedObjects");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UCustomizableObjectResourceDataContainer : public UObject
{
public:
    FCustomizableObjectResourceData Data; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UCustomizableObjectResourceDataContainer) == 0x40, "Size mismatch for UCustomizableObjectResourceDataContainer");
static_assert(offsetof(UCustomizableObjectResourceDataContainer, Data) == 0x28, "Offset mismatch for UCustomizableObjectResourceDataContainer::Data");

// Size: 0x5c8 (Inherited: 0x720, Single: 0xfffffea8)
class UCustomizableObjectSkeletalMesh : public USkeletalMesh
{
public:
};

static_assert(sizeof(UCustomizableObjectSkeletalMesh) == 0x5c8, "Size mismatch for UCustomizableObjectSkeletalMesh");

// Size: 0x4a0 (Inherited: 0x28, Single: 0x478)
class UCustomizableObjectSystemPrivate : public UObject
{
public:
    uint8_t Pad_28[0x1b8]; // 0x28 (Size: 0x1b8, Type: PaddingProperty)
    UCustomizableObjectInstance* CurrentInstanceBeingUpdated; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e8[0x260]; // 0x1e8 (Size: 0x260, Type: PaddingProperty)
    TArray<FPendingReleaseSkeletalMeshInfo> PendingReleaseSkeletalMesh; // 0x448 (Size: 0x10, Type: ArrayProperty)
    UCustomizableInstanceLODManagementBase* DefaultInstanceLODManagement; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCustomizableInstanceLODManagementBase* CurrentInstanceLODManagement; // 0x460 (Size: 0x8, Type: ObjectProperty)
    TArray<UTexture2D*> ProtectedCachedTextures; // 0x468 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_478[0x28]; // 0x478 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UCustomizableObjectSystemPrivate) == 0x4a0, "Size mismatch for UCustomizableObjectSystemPrivate");
static_assert(offsetof(UCustomizableObjectSystemPrivate, CurrentInstanceBeingUpdated) == 0x1e0, "Offset mismatch for UCustomizableObjectSystemPrivate::CurrentInstanceBeingUpdated");
static_assert(offsetof(UCustomizableObjectSystemPrivate, PendingReleaseSkeletalMesh) == 0x448, "Offset mismatch for UCustomizableObjectSystemPrivate::PendingReleaseSkeletalMesh");
static_assert(offsetof(UCustomizableObjectSystemPrivate, DefaultInstanceLODManagement) == 0x458, "Offset mismatch for UCustomizableObjectSystemPrivate::DefaultInstanceLODManagement");
static_assert(offsetof(UCustomizableObjectSystemPrivate, CurrentInstanceLODManagement) == 0x460, "Offset mismatch for UCustomizableObjectSystemPrivate::CurrentInstanceLODManagement");
static_assert(offsetof(UCustomizableObjectSystemPrivate, ProtectedCachedTextures) == 0x468, "Offset mismatch for UCustomizableObjectSystemPrivate::ProtectedCachedTextures");

// Size: 0x280 (Inherited: 0x320, Single: 0xffffff60)
class UCustomizableSkeletalComponent : public USceneComponent
{
public:
    UCustomizableObjectInstance* CustomizableObjectInstance; // 0x240 (Size: 0x8, Type: ObjectProperty)
    int32_t ComponentIndex; // 0x248 (Size: 0x4, Type: IntProperty)
    FName ComponentName; // 0x24c (Size: 0x4, Type: NameProperty)
    bool bSkipSetReferenceSkeletalMesh; // 0x250 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_251[0x17]; // 0x251 (Size: 0x17, Type: PaddingProperty)
    bool bSkipSkipSetSkeletalMeshOnAttach; // 0x268 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
    UCustomizableSkeletalComponentPrivate* Private; // 0x270 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_278[0x8]; // 0x278 (Size: 0x8, Type: PaddingProperty)

public:
    FName GetComponentName() const; // 0xb22aacc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomizableObjectInstance* GetCustomizableObjectInstance() const; // 0xa43d97c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSkipSetReferenceSkeletalMesh() const; // 0xb2303b4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSkipSetSkeletalMeshOnAttach() const; // 0xb2303cc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetComponentName(const FName Name); // 0xb234a18 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetCustomizableObjectInstance(UCustomizableObjectInstance*& Instance); // 0xb234df4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetSkipSetReferenceSkeletalMesh(bool& bSkip); // 0xa3a0d24 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetSkipSetSkeletalMeshOnAttach(bool& bSkip); // 0xb237c70 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateSkeletalMeshAsync(bool& bNeverSkipUpdate); // 0xb238c4c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateSkeletalMeshAsyncResult(FDelegate& Callback, bool& bIgnoreCloseDist, bool& bForceHighPriority); // 0xb239070 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCustomizableSkeletalComponent) == 0x280, "Size mismatch for UCustomizableSkeletalComponent");
static_assert(offsetof(UCustomizableSkeletalComponent, CustomizableObjectInstance) == 0x240, "Offset mismatch for UCustomizableSkeletalComponent::CustomizableObjectInstance");
static_assert(offsetof(UCustomizableSkeletalComponent, ComponentIndex) == 0x248, "Offset mismatch for UCustomizableSkeletalComponent::ComponentIndex");
static_assert(offsetof(UCustomizableSkeletalComponent, ComponentName) == 0x24c, "Offset mismatch for UCustomizableSkeletalComponent::ComponentName");
static_assert(offsetof(UCustomizableSkeletalComponent, bSkipSetReferenceSkeletalMesh) == 0x250, "Offset mismatch for UCustomizableSkeletalComponent::bSkipSetReferenceSkeletalMesh");
static_assert(offsetof(UCustomizableSkeletalComponent, bSkipSkipSetSkeletalMeshOnAttach) == 0x268, "Offset mismatch for UCustomizableSkeletalComponent::bSkipSkipSetSkeletalMeshOnAttach");
static_assert(offsetof(UCustomizableSkeletalComponent, Private) == 0x270, "Offset mismatch for UCustomizableSkeletalComponent::Private");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCustomizableSkeletalComponentPrivate : public UObject
{
public:
    UCustomizableObjectInstanceUsage* InstanceUsage; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCustomizableSkeletalComponentPrivate) == 0x30, "Size mismatch for UCustomizableSkeletalComponentPrivate");
static_assert(offsetof(UCustomizableSkeletalComponentPrivate, InstanceUsage) == 0x28, "Offset mismatch for UCustomizableSkeletalComponentPrivate::InstanceUsage");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCustomizableSkeletalMeshActorPrivate : public UObject
{
public:
};

static_assert(sizeof(UCustomizableSkeletalMeshActorPrivate) == 0x28, "Size mismatch for UCustomizableSkeletalMeshActorPrivate");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEditorImageProvider : public UCustomizableSystemImageProvider
{
public:
};

static_assert(sizeof(UEditorImageProvider) == 0x28, "Size mismatch for UEditorImageProvider");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCustomizableSystemImageProvider : public UObject
{
public:
};

static_assert(sizeof(UCustomizableSystemImageProvider) == 0x28, "Size mismatch for UCustomizableSystemImageProvider");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCustomizableInstanceLODManagementBase : public UObject
{
public:
};

static_assert(sizeof(UCustomizableInstanceLODManagementBase) == 0x28, "Size mismatch for UCustomizableInstanceLODManagementBase");

// Size: 0x80 (Inherited: 0x50, Single: 0x30)
class UCustomizableInstanceLODManagement : public UCustomizableInstanceLODManagementBase
{
public:
};

static_assert(sizeof(UCustomizableInstanceLODManagement) == 0x80, "Size mismatch for UCustomizableInstanceLODManagement");

// Size: 0x130 (Inherited: 0x28, Single: 0x108)
class UCustomizableObject : public UObject
{
public:
    FMutableLODSettings LODSettings; // 0x28 (Size: 0x70, Type: StructProperty)
    bool bEnableUseRefSkeletalMeshAsPlaceholder; // 0x98 (Size: 0x1, Type: BoolProperty)
    bool bPreserveUserLODsOnFirstGeneration; // 0x99 (Size: 0x1, Type: BoolProperty)
    bool bEnableMeshCache; // 0x9a (Size: 0x1, Type: BoolProperty)
    bool bEnableMeshStreaming; // 0x9b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    TArray<FName> LowPriorityTextures; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> CustomizableObjectClassTags; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> PopulationClassTags; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TMap<FParameterTags, FString> CustomizableObjectParametersTags; // 0xd0 (Size: 0x50, Type: MapProperty)
    UCustomizableObjectBulk* BulkData; // 0x120 (Size: 0x8, Type: ObjectProperty)
    UCustomizableObjectPrivate* Private; // 0x128 (Size: 0x8, Type: ObjectProperty)

public:
    void Compile(const FCompileParams Params); // 0xb2266cc (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool ContainsEnumParameterValue(FString& ParameterName, FString& const Value) const; // 0xb226ab0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ContainsParameter(FString& ParameterName) const; // 0xb227524 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomizableObjectInstance* CreateInstance(); // 0xb228134 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    int32_t FindParameter(FString& Name) const; // 0xb228a58 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetBoolParameterDefaultValue(FString& ParameterName) const; // 0xb229b54 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FLinearColor GetColorParameterDefaultValue(FString& ParameterName) const; // 0xb22a188 (Index: 0x6, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetComponentCount() const; // 0xb22a794 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMesh* GetComponentMeshReferenceSkeletalMesh(const FName Name) const; // 0xb22a7b4 (Index: 0x8, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FName GetComponentName(int32_t& ComponentIndex) const; // 0xb22a99c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetEnumParameterDefaultValue(FString& ParameterName) const; // 0xb22ab78 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ECustomizableObjectGroupType GetEnumParameterGroupType(FString& ParamName) const; // 0xb22ae74 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetEnumParameterNumValues(FString& ParameterName) const; // 0xb22b170 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetEnumParameterValue(FString& ParameterName, int32_t& ValueIndex) const; // 0xb22b46c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FMutableParamUIMetadata GetEnumParameterValueUIMetadata(FString& ParamName, FString& OptionName) const; // 0xb22b858 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFloatParameterDefaultValue(FString& ParameterName) const; // 0xb22be34 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetIntParameterAvailableOption(int32_t& ParamIndex, int32_t& K) const; // 0xb22c82c (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetIntParameterNumOptions(int32_t& ParamIndex) const; // 0xb22ca5c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetParameterCount() const; // 0xb22d54c (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetParameterName(int32_t& ParamIndex) const; // 0xb22d56c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMutableParameterType GetParameterType(int32_t& ParamIndex) const; // 0xb22d6b8 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMutableParameterType GetParameterTypeByName(FString& Name) const; // 0xb22d7f4 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FMutableParamUIMetadata GetParameterUIMetadata(FString& ParamName) const; // 0xb22daf0 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FCustomizableObjectProjector GetProjectorParameterDefaultValue(FString& ParameterName) const; // 0xb22e5e8 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetStateCount() const; // 0xb2303e4 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetStateName(int32_t& StateIndex) const; // 0xb230404 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetStateParameterCount(FString& StateName) const; // 0xb23070c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetStateParameterName(FString& StateName, int32_t& ParameterIndex) const; // 0xb230a00 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FMutableStateUIMetadata GetStateUIMetadata(FString& StateName) const; // 0xb230e48 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetTransformParameterDefaultValue(FString& ParameterName) const; // 0xb231854 (Index: 0x1d, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsCompiled() const; // 0xb231f24 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLoading() const; // 0xb231f48 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsParameterMultidimensional(FString& InParameterName) const; // 0xb232350 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCustomizableObject) == 0x130, "Size mismatch for UCustomizableObject");
static_assert(offsetof(UCustomizableObject, LODSettings) == 0x28, "Offset mismatch for UCustomizableObject::LODSettings");
static_assert(offsetof(UCustomizableObject, bEnableUseRefSkeletalMeshAsPlaceholder) == 0x98, "Offset mismatch for UCustomizableObject::bEnableUseRefSkeletalMeshAsPlaceholder");
static_assert(offsetof(UCustomizableObject, bPreserveUserLODsOnFirstGeneration) == 0x99, "Offset mismatch for UCustomizableObject::bPreserveUserLODsOnFirstGeneration");
static_assert(offsetof(UCustomizableObject, bEnableMeshCache) == 0x9a, "Offset mismatch for UCustomizableObject::bEnableMeshCache");
static_assert(offsetof(UCustomizableObject, bEnableMeshStreaming) == 0x9b, "Offset mismatch for UCustomizableObject::bEnableMeshStreaming");
static_assert(offsetof(UCustomizableObject, LowPriorityTextures) == 0xa0, "Offset mismatch for UCustomizableObject::LowPriorityTextures");
static_assert(offsetof(UCustomizableObject, CustomizableObjectClassTags) == 0xb0, "Offset mismatch for UCustomizableObject::CustomizableObjectClassTags");
static_assert(offsetof(UCustomizableObject, PopulationClassTags) == 0xc0, "Offset mismatch for UCustomizableObject::PopulationClassTags");
static_assert(offsetof(UCustomizableObject, CustomizableObjectParametersTags) == 0xd0, "Offset mismatch for UCustomizableObject::CustomizableObjectParametersTags");
static_assert(offsetof(UCustomizableObject, BulkData) == 0x120, "Offset mismatch for UCustomizableObject::BulkData");
static_assert(offsetof(UCustomizableObject, Private) == 0x128, "Offset mismatch for UCustomizableObject::Private");

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class UDGGUI : public UUserWidget
{
public:

public:
    virtual UCustomizableObjectInstanceUsage* GetCustomizableObjectInstanceUsage(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void SetCustomizableObjectInstanceUsage(UCustomizableObjectInstanceUsage*& CustomizableObjectInstanceUsage); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDGGUI) == 0x2b0, "Size mismatch for UDGGUI");

// Size: 0x270 (Inherited: 0x28, Single: 0x248)
class UCustomizableObjectInstance : public UObject
{
public:
    uint8_t UpdatedDelegate[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_38[0x40]; // 0x38 (Size: 0x40, Type: PaddingProperty)
    FCustomizableObjectInstanceDescriptor Descriptor; // 0x78 (Size: 0x180, Type: StructProperty)
    UCustomizableInstancePrivate* PrivateData; // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    UCustomizableObject* CustomizableObject; // 0x200 (Size: 0x8, Type: ObjectProperty)
    TArray<FCustomizableObjectBoolParameterValue> BoolParameters; // 0x208 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectIntParameterValue> IntParameters; // 0x218 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectFloatParameterValue> FloatParameters; // 0x228 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> TextureParameters; // 0x238 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectVectorParameterValue> VectorParameters; // 0x248 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectProjectorParameterValue> ProjectorParameters; // 0x258 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_268[0x8]; // 0x268 (Size: 0x8, Type: PaddingProperty)

public:
    int32_t AddValueToFloatRange(FString& ParamName); // 0xb225c28 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    int32_t AddValueToIntRange(FString& ParamName); // 0xb225f24 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    int32_t AddValueToProjectorRange(FString& ParamName); // 0xb226220 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UCustomizableObjectInstance* Clone(); // 0xb22651c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    UCustomizableObjectInstance* CloneStatic(UObject*& Outer); // 0xb22656c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    bool ContainsBoolParameter(FString& ParameterName) const; // 0xb2267ac (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ContainsFloatParameter(FString& ParameterName) const; // 0xb226f1c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ContainsIntParameter(FString& ParameterName) const; // 0xb227220 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ContainsProjectorParameter(FString& ParameterName) const; // 0xb227828 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ContainsTransformParameter(FString& ParameterName) const; // 0xb227b2c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ContainsVectorParameter(FString& ParameterName) const; // 0xb227e30 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t FindBoolParameterNameIndex(FString& ParamName) const; // 0xb228158 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t FindFloatParameterNameIndex(FString& ParamName) const; // 0xb228458 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t FindIntParameterNameIndex(FString& ParamName) const; // 0xb228758 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t FindProjectorParameterNameIndex(FString& ParamName) const; // 0xb228d58 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t FindVectorParameterNameIndex(FString& ParamName) const; // 0xb229058 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ForEachAnimInstance(int32_t& ObjectComponentIndex, FDelegate& Delegate) const; // 0xb229358 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|Const)
    void ForEachComponentAnimInstance(FName& ComponentName, FDelegate& Delegate) const; // 0xb229590 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|Const)
    FGameplayTagContainer GetAnimationGameplayTags() const; // 0xb229b30 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UClass* GetAnimBP(FName& ComponentName, const FName Slot) const; // 0xb2297b8 (Index: 0x13, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetBoolParameterSelectedOption(FString& BoolParamName) const; // 0xb229e50 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetBuildParameterRelevancy() const; // 0xb22a170 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FLinearColor GetColorParameterSelectedOption(FString& ColorParamName) const; // 0xb22a48c (Index: 0x16, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    USkeletalMesh* GetComponentMeshSkeletalMesh(const FName ComponentName) const; // 0xb22a8a8 (Index: 0x17, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetComponentNames() const; // 0xb22aaf8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetCurrentState() const; // 0xb22ab38 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomizableObject* GetCustomizableObject() const; // 0x572f8a8 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FInstancedStruct GetExtensionInstanceData(UCustomizableObjectExtension*& const Extension) const; // 0xb22bce4 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFloatParameterSelectedOption(FString& FloatParamName, int32_t& RangeIndex) const; // 0xb22c130 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetFloatValueRange(FString& ParamName) const; // 0xb22c514 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetIntParameterSelectedOption(FString& ParamName, int32_t& RangeIndex) const; // 0xb22cb98 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetIntValueRange(FString& ParamName) const; // 0xb22cf84 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TSet<UAssetUserData*> GetMergedAssetUserData(int32_t& ComponentIndex) const; // 0xb22d29c (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumComponents() const; // 0xb22d52c (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetProjectorAngle(FString& ParamName, int32_t& RangeIndex) const; // 0xb22de08 (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetProjectorDirection(FString& ParamName, int32_t& RangeIndex) const; // 0xb22e1ec (Index: 0x23, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    ECustomizableObjectProjectorType GetProjectorParameterType(FString& ParamName, int32_t& RangeIndex) const; // 0xb22e904 (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetProjectorPosition(FString& ParamName, int32_t& RangeIndex) const; // 0xb22ece4 (Index: 0x25, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetProjectorScale(FString& ParamName, int32_t& RangeIndex) const; // 0xb22f0e0 (Index: 0x26, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetProjectorUp(FString& ParamName, int32_t& RangeIndex) const; // 0xb22f4dc (Index: 0x27, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void GetProjectorValue(FString& ProjectorParamName, FVector& OutPos, FVector& OutDirection, FVector& OutUp, FVector& OutScale, float& OutAngle, ECustomizableObjectProjectorType& OutType, int32_t& RangeIndex) const; // 0xb22f8d8 (Index: 0x28, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetProjectorValueRange(FString& ParamName) const; // 0xb22ff64 (Index: 0x29, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMesh* GetSkeletalMesh(int32_t& ComponentIndex) const; // 0xb23027c (Index: 0x2a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetTextureParameterSelectedOption(FString& TextureParamName, int32_t& RangeIndex) const; // 0xb231160 (Index: 0x2b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTextureValueRange(FString& ParamName) const; // 0xb23153c (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetTransformParameterSelectedOption(FString& TransformParamName) const; // 0xb231b80 (Index: 0x2d, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool HasAnyParameters() const; // 0xb231ea8 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasAnySkeletalMesh() const; // 0xb231f00 (Index: 0x2f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsParameterDirty(FString& ParamName, int32_t& RangeIndex) const; // 0xb231f6c (Index: 0x30, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsParameterRelevant(FString& ParamName) const; // 0xb23264c (Index: 0x31, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void MultilayerProjectorCreateLayer(const FName ProjectorParamName, int32_t& Index); // 0xb232964 (Index: 0x32, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FMultilayerProjectorLayer MultilayerProjectorGetLayer(const FName ProjectorParamName, int32_t& Index) const; // 0xb232ad4 (Index: 0x33, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t MultilayerProjectorNumLayers(const FName ProjectorParamName) const; // 0xb232ee8 (Index: 0x34, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void MultilayerProjectorRemoveLayerAt(const FName ProjectorParamName, int32_t& Index); // 0xb232fdc (Index: 0x35, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void MultilayerProjectorUpdateLayer(const FName ProjectorParamName, int32_t& Index, const FMultilayerProjectorLayer Layer); // 0xb23314c (Index: 0x36, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    int32_t RemoveValueFromFloatRange(FString& ParamName, int32_t& RangeIndex); // 0xb233564 (Index: 0x37, Flags: Final|Native|Public|BlueprintCallable)
    int32_t RemoveValueFromIntRange(FString& ParamName, int32_t& RangeIndex); // 0xb233944 (Index: 0x38, Flags: Final|Native|Public|BlueprintCallable)
    int32_t RemoveValueFromProjectorRange(FString& ParamName, int32_t& RangeIndex); // 0xb233d24 (Index: 0x39, Flags: Final|Native|Public|BlueprintCallable)
    void SetBoolParameterSelectedOption(FString& BoolParamName, bool& BoolValue); // 0xb234104 (Index: 0x3a, Flags: Final|Native|Public|BlueprintCallable)
    void SetBuildParameterRelevancy(bool& Value); // 0xb2344d8 (Index: 0x3b, Flags: Final|Native|Public|BlueprintCallable)
    void SetColorParameterSelectedOption(FString& ColorParamName, const FLinearColor ColorValue); // 0xb234604 (Index: 0x3c, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetCurrentState(FString& StateName); // 0xb234afc (Index: 0x3d, Flags: Final|Native|Public|BlueprintCallable)
    void SetDefaultValue(FString& ParamName); // 0xb2350cc (Index: 0x3e, Flags: Final|Native|Public|BlueprintCallable)
    void SetDefaultValues(); // 0xb2353d8 (Index: 0x3f, Flags: Final|Native|Public|BlueprintCallable)
    void SetFloatParameterSelectedOption(FString& FloatParamName, float& FloatValue, int32_t& RangeIndex); // 0xb2353ec (Index: 0x40, Flags: Final|Native|Public|BlueprintCallable)
    void SetIntParameterSelectedOption(FString& ParamName, FString& SelectedOptionName, int32_t& RangeIndex); // 0xb235898 (Index: 0x41, Flags: Final|Native|Public|BlueprintCallable)
    void SetObject(UCustomizableObject*& InObject); // 0xb235dc8 (Index: 0x42, Flags: Final|Native|Public|BlueprintCallable)
    void SetProjectorAngle(FString& ProjectorParamName, float& Angle, int32_t& RangeIndex); // 0xb235ef4 (Index: 0x43, Flags: Final|Native|Public|BlueprintCallable)
    void SetProjectorDirection(FString& ProjectorParamName, const FVector Direction, int32_t& RangeIndex); // 0xb2363a0 (Index: 0x44, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetProjectorPosition(FString& ProjectorParamName, const FVector Pos, int32_t& RangeIndex); // 0xb2367b8 (Index: 0x45, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetProjectorScale(FString& ProjectorParamName, const FVector Scale, int32_t& RangeIndex); // 0xb236bd0 (Index: 0x46, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetProjectorUp(FString& ProjectorParamName, const FVector Up, int32_t& RangeIndex); // 0xb236fe8 (Index: 0x47, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetProjectorValue(FString& ProjectorParamName, const FVector OutPos, const FVector OutDirection, const FVector OutUp, const FVector OutScale, float& OutAngle, int32_t& RangeIndex); // 0xb237400 (Index: 0x48, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetRandomValues(); // 0xb237a20 (Index: 0x49, Flags: Final|Native|Public|BlueprintCallable)
    void SetRandomValuesFromStream(const FRandomStream InStream); // 0xb237a64 (Index: 0x4a, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetReplacePhysicsAssets(bool& bReplaceEnabled); // 0xb237b44 (Index: 0x4b, Flags: Final|Native|Public|BlueprintCallable)
    void SetTextureParameterSelectedOption(FString& TextureParamName, FString& TextureValue, int32_t& RangeIndex); // 0xb237d9c (Index: 0x4c, Flags: Final|Native|Public|BlueprintCallable)
    void SetTransformParameterSelectedOption(FString& TransformParamName, const FTransform TransformValue); // 0xb2382cc (Index: 0x4d, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetVectorParameterSelectedOption(FString& VectorParamName, const FLinearColor VectorValue); // 0xb2386ac (Index: 0x4e, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void UpdateSkeletalMeshAsync(bool& bIgnoreCloseDist, bool& bForceHighPriority); // 0xb238a30 (Index: 0x4f, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateSkeletalMeshAsyncResult(FDelegate& Callback, bool& bIgnoreCloseDist, bool& bForceHighPriority); // 0xb238d70 (Index: 0x50, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCustomizableObjectInstance) == 0x270, "Size mismatch for UCustomizableObjectInstance");
static_assert(offsetof(UCustomizableObjectInstance, UpdatedDelegate) == 0x28, "Offset mismatch for UCustomizableObjectInstance::UpdatedDelegate");
static_assert(offsetof(UCustomizableObjectInstance, Descriptor) == 0x78, "Offset mismatch for UCustomizableObjectInstance::Descriptor");
static_assert(offsetof(UCustomizableObjectInstance, PrivateData) == 0x1f8, "Offset mismatch for UCustomizableObjectInstance::PrivateData");
static_assert(offsetof(UCustomizableObjectInstance, CustomizableObject) == 0x200, "Offset mismatch for UCustomizableObjectInstance::CustomizableObject");
static_assert(offsetof(UCustomizableObjectInstance, BoolParameters) == 0x208, "Offset mismatch for UCustomizableObjectInstance::BoolParameters");
static_assert(offsetof(UCustomizableObjectInstance, IntParameters) == 0x218, "Offset mismatch for UCustomizableObjectInstance::IntParameters");
static_assert(offsetof(UCustomizableObjectInstance, FloatParameters) == 0x228, "Offset mismatch for UCustomizableObjectInstance::FloatParameters");
static_assert(offsetof(UCustomizableObjectInstance, TextureParameters) == 0x238, "Offset mismatch for UCustomizableObjectInstance::TextureParameters");
static_assert(offsetof(UCustomizableObjectInstance, VectorParameters) == 0x248, "Offset mismatch for UCustomizableObjectInstance::VectorParameters");
static_assert(offsetof(UCustomizableObjectInstance, ProjectorParameters) == 0x258, "Offset mismatch for UCustomizableObjectInstance::ProjectorParameters");

// Size: 0x60 (Inherited: 0x78, Single: 0xffffffe8)
class UMutableTextureMipDataProviderFactory : public UTextureMipDataProviderFactory
{
public:
    UCustomizableObjectInstance* CustomizableObjectInstance; // 0x28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_30[0x30]; // 0x30 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(UMutableTextureMipDataProviderFactory) == 0x60, "Size mismatch for UMutableTextureMipDataProviderFactory");
static_assert(offsetof(UMutableTextureMipDataProviderFactory, CustomizableObjectInstance) == 0x28, "Offset mismatch for UMutableTextureMipDataProviderFactory::CustomizableObjectInstance");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCustomizableObjectSystem : public UObject
{
public:
    UCustomizableObjectSystemPrivate* Private; // 0x28 (Size: 0x8, Type: ObjectProperty)

public:
    int32_t GetAverageBuildTime() const; // 0xb2469c0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static UCustomizableObjectSystem* GetInstance(); // 0xb246a24 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UCustomizableObjectSystem* GetInstanceChecked(); // 0xb246a24 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    int32_t GetNumInstances() const; // 0xb246a48 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumPendingInstances() const; // 0xb246a84 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetPluginVersion() const; // 0xb246ac4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int64_t GetTextureMemoryUsed() const; // 0xb246b10 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTotalInstances() const; // 0xb246b60 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetWorkingMemory() const; // 0xb246b84 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static bool IsUpdateResultValid(EUpdateResult& const UpdateResult); // 0xb246bc4 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    bool IsUpdating(UCustomizableObjectInstance*& const Instance) const; // 0xb246cec (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetReleaseMutableTexturesImmediately(bool& bReleaseTextures); // 0xb247108 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetWorkingMemory(int32_t& KiloBytes); // 0xb247238 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCustomizableObjectSystem) == 0x30, "Size mismatch for UCustomizableObjectSystem");
static_assert(offsetof(UCustomizableObjectSystem, Private) == 0x28, "Offset mismatch for UCustomizableObjectSystem::Private");

// Size: 0x360 (Inherited: 0x5f8, Single: 0xfffffd68)
class ACustomizableSkeletalMeshActor : public ASkeletalMeshActor
{
public:
    TArray<UCustomizableSkeletalComponent*> CustomizableSkeletalComponents; // 0x328 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeletalMeshComponent*> SkeletalMeshComponents; // 0x338 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* DebugMaterial; // 0x348 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_350[0x8]; // 0x350 (Size: 0x8, Type: PaddingProperty)
    UCustomizableSkeletalMeshActorPrivate* Private; // 0x358 (Size: 0x8, Type: ObjectProperty)

public:
    void EnableDebugMaterial(bool& bEnableDebugMaterial); // 0xb246894 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetDebugMaterial(UMaterialInterface*& InDebugMaterial); // 0xb246e30 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

private:
    void SwitchComponentsMaterials(UCustomizableObjectInstance*& Instance); // 0xb247350 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(ACustomizableSkeletalMeshActor) == 0x360, "Size mismatch for ACustomizableSkeletalMeshActor");
static_assert(offsetof(ACustomizableSkeletalMeshActor, CustomizableSkeletalComponents) == 0x328, "Offset mismatch for ACustomizableSkeletalMeshActor::CustomizableSkeletalComponents");
static_assert(offsetof(ACustomizableSkeletalMeshActor, SkeletalMeshComponents) == 0x338, "Offset mismatch for ACustomizableSkeletalMeshActor::SkeletalMeshComponents");
static_assert(offsetof(ACustomizableSkeletalMeshActor, DebugMaterial) == 0x348, "Offset mismatch for ACustomizableSkeletalMeshActor::DebugMaterial");
static_assert(offsetof(ACustomizableSkeletalMeshActor, Private) == 0x358, "Offset mismatch for ACustomizableSkeletalMeshActor::Private");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UDefaultImageProvider : public UCustomizableSystemImageProvider
{
public:
    TMap<UTexture2D*, FName> Textures; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDefaultImageProvider) == 0x78, "Size mismatch for UDefaultImageProvider");
static_assert(offsetof(UDefaultImageProvider, Textures) == 0x28, "Offset mismatch for UDefaultImageProvider::Textures");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCustomizableObjectInstanceBakeOutput
{
    bool bWasBakeSuccessful; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FBakedResourceData> SavedPackages; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomizableObjectInstanceBakeOutput) == 0x18, "Size mismatch for FCustomizableObjectInstanceBakeOutput");
static_assert(offsetof(FCustomizableObjectInstanceBakeOutput, bWasBakeSuccessful) == 0x0, "Offset mismatch for FCustomizableObjectInstanceBakeOutput::bWasBakeSuccessful");
static_assert(offsetof(FCustomizableObjectInstanceBakeOutput, SavedPackages) == 0x8, "Offset mismatch for FCustomizableObjectInstanceBakeOutput::SavedPackages");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBakedResourceData
{
    uint8_t SaveType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString AssetPath; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FBakedResourceData) == 0x18, "Size mismatch for FBakedResourceData");
static_assert(offsetof(FBakedResourceData, SaveType) == 0x0, "Offset mismatch for FBakedResourceData::SaveType");
static_assert(offsetof(FBakedResourceData, AssetPath) == 0x8, "Offset mismatch for FBakedResourceData::AssetPath");

// Size: 0x5 (Inherited: 0x0, Single: 0x5)
struct FCompileCallbackParams
{
    bool bRequestFailed; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWarnings; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bErrors; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bSkipped; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bCompiled; // 0x4 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FCompileCallbackParams) == 0x5, "Size mismatch for FCompileCallbackParams");
static_assert(offsetof(FCompileCallbackParams, bRequestFailed) == 0x0, "Offset mismatch for FCompileCallbackParams::bRequestFailed");
static_assert(offsetof(FCompileCallbackParams, bWarnings) == 0x1, "Offset mismatch for FCompileCallbackParams::bWarnings");
static_assert(offsetof(FCompileCallbackParams, bErrors) == 0x2, "Offset mismatch for FCompileCallbackParams::bErrors");
static_assert(offsetof(FCompileCallbackParams, bSkipped) == 0x3, "Offset mismatch for FCompileCallbackParams::bSkipped");
static_assert(offsetof(FCompileCallbackParams, bCompiled) == 0x4, "Offset mismatch for FCompileCallbackParams::bCompiled");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FUpdateContext
{
    uint8_t UpdateResult; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FUpdateContext) == 0x1, "Size mismatch for FUpdateContext");
static_assert(offsetof(FUpdateContext, UpdateResult) == 0x0, "Offset mismatch for FUpdateContext::UpdateResult");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPreSetSkeletalMeshParams
{
    UCustomizableObjectInstance* Instance; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMesh* SkeletalMesh; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FPreSetSkeletalMeshParams) == 0x10, "Size mismatch for FPreSetSkeletalMeshParams");
static_assert(offsetof(FPreSetSkeletalMeshParams, Instance) == 0x0, "Offset mismatch for FPreSetSkeletalMeshParams::Instance");
static_assert(offsetof(FPreSetSkeletalMeshParams, SkeletalMesh) == 0x8, "Offset mismatch for FPreSetSkeletalMeshParams::SkeletalMesh");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCustomizableObjectClothConfigData
{
    FString ClassPath; // 0x0 (Size: 0x10, Type: StrProperty)
    FName ConfigName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<char> ConfigBytes; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomizableObjectClothConfigData) == 0x28, "Size mismatch for FCustomizableObjectClothConfigData");
static_assert(offsetof(FCustomizableObjectClothConfigData, ClassPath) == 0x0, "Offset mismatch for FCustomizableObjectClothConfigData::ClassPath");
static_assert(offsetof(FCustomizableObjectClothConfigData, ConfigName) == 0x10, "Offset mismatch for FCustomizableObjectClothConfigData::ConfigName");
static_assert(offsetof(FCustomizableObjectClothConfigData, ConfigBytes) == 0x18, "Offset mismatch for FCustomizableObjectClothConfigData::ConfigBytes");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FCustomizableObjectClothingAssetData
{
    TArray<FClothLODDataCommon> LODData; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> LodMap; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> UsedBoneNames; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> UsedBoneIndices; // 0x30 (Size: 0x10, Type: ArrayProperty)
    int32_t ReferenceBoneIndex; // 0x40 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    TArray<FCustomizableObjectClothConfigData> ConfigsData; // 0x48 (Size: 0x10, Type: ArrayProperty)
    FName Name; // 0x58 (Size: 0x4, Type: NameProperty)
    FGuid OriginalAssetGuid; // 0x5c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCustomizableObjectClothingAssetData) == 0x70, "Size mismatch for FCustomizableObjectClothingAssetData");
static_assert(offsetof(FCustomizableObjectClothingAssetData, LODData) == 0x0, "Offset mismatch for FCustomizableObjectClothingAssetData::LODData");
static_assert(offsetof(FCustomizableObjectClothingAssetData, LodMap) == 0x10, "Offset mismatch for FCustomizableObjectClothingAssetData::LodMap");
static_assert(offsetof(FCustomizableObjectClothingAssetData, UsedBoneNames) == 0x20, "Offset mismatch for FCustomizableObjectClothingAssetData::UsedBoneNames");
static_assert(offsetof(FCustomizableObjectClothingAssetData, UsedBoneIndices) == 0x30, "Offset mismatch for FCustomizableObjectClothingAssetData::UsedBoneIndices");
static_assert(offsetof(FCustomizableObjectClothingAssetData, ReferenceBoneIndex) == 0x40, "Offset mismatch for FCustomizableObjectClothingAssetData::ReferenceBoneIndex");
static_assert(offsetof(FCustomizableObjectClothingAssetData, ConfigsData) == 0x48, "Offset mismatch for FCustomizableObjectClothingAssetData::ConfigsData");
static_assert(offsetof(FCustomizableObjectClothingAssetData, Name) == 0x58, "Offset mismatch for FCustomizableObjectClothingAssetData::Name");
static_assert(offsetof(FCustomizableObjectClothingAssetData, OriginalAssetGuid) == 0x5c, "Offset mismatch for FCustomizableObjectClothingAssetData::OriginalAssetGuid");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCustomizableObjectAnimationSlot
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr AnimInstance; // 0x8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FCustomizableObjectAnimationSlot) == 0x28, "Size mismatch for FCustomizableObjectAnimationSlot");
static_assert(offsetof(FCustomizableObjectAnimationSlot, Name) == 0x0, "Offset mismatch for FCustomizableObjectAnimationSlot::Name");
static_assert(offsetof(FCustomizableObjectAnimationSlot, AnimInstance) == 0x8, "Offset mismatch for FCustomizableObjectAnimationSlot::AnimInstance");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FReferencedPhysicsAssets
{
    TArray<UPhysicsAsset*> PhysicsAssetsToMerge; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UPhysicsAsset*> AdditionalPhysicsAssets; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReferencedPhysicsAssets) == 0x40, "Size mismatch for FReferencedPhysicsAssets");
static_assert(offsetof(FReferencedPhysicsAssets, PhysicsAssetsToMerge) == 0x10, "Offset mismatch for FReferencedPhysicsAssets::PhysicsAssetsToMerge");
static_assert(offsetof(FReferencedPhysicsAssets, AdditionalPhysicsAssets) == 0x30, "Offset mismatch for FReferencedPhysicsAssets::AdditionalPhysicsAssets");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FReferencedSkeletons
{
    USkeleton* Skeleton; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<uint16_t> SkeletonIds; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeleton*> SkeletonsToMerge; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReferencedSkeletons) == 0x28, "Size mismatch for FReferencedSkeletons");
static_assert(offsetof(FReferencedSkeletons, Skeleton) == 0x0, "Offset mismatch for FReferencedSkeletons::Skeleton");
static_assert(offsetof(FReferencedSkeletons, SkeletonIds) == 0x8, "Offset mismatch for FReferencedSkeletons::SkeletonIds");
static_assert(offsetof(FReferencedSkeletons, SkeletonsToMerge) == 0x18, "Offset mismatch for FReferencedSkeletons::SkeletonsToMerge");

// Size: 0x150 (Inherited: 0x0, Single: 0x150)
struct FCustomizableInstanceComponentData
{
    TMap<TSoftClassPtr, FName> AnimSlotToBP; // 0x0 (Size: 0x50, Type: MapProperty)
    TSet<UAssetUserData*> AssetUserDataArray; // 0x50 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_a0[0x10]; // 0xa0 (Size: 0x10, Type: PaddingProperty)
    FReferencedSkeletons Skeletons; // 0xb0 (Size: 0x28, Type: StructProperty)
    FReferencedPhysicsAssets PhysicsAssets; // 0xd8 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_118[0x20]; // 0x118 (Size: 0x20, Type: PaddingProperty)
    TArray<UMaterialInterface*> OverrideMaterials; // 0x138 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* OverlayMaterial; // 0x148 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCustomizableInstanceComponentData) == 0x150, "Size mismatch for FCustomizableInstanceComponentData");
static_assert(offsetof(FCustomizableInstanceComponentData, AnimSlotToBP) == 0x0, "Offset mismatch for FCustomizableInstanceComponentData::AnimSlotToBP");
static_assert(offsetof(FCustomizableInstanceComponentData, AssetUserDataArray) == 0x50, "Offset mismatch for FCustomizableInstanceComponentData::AssetUserDataArray");
static_assert(offsetof(FCustomizableInstanceComponentData, Skeletons) == 0xb0, "Offset mismatch for FCustomizableInstanceComponentData::Skeletons");
static_assert(offsetof(FCustomizableInstanceComponentData, PhysicsAssets) == 0xd8, "Offset mismatch for FCustomizableInstanceComponentData::PhysicsAssets");
static_assert(offsetof(FCustomizableInstanceComponentData, OverrideMaterials) == 0x138, "Offset mismatch for FCustomizableInstanceComponentData::OverrideMaterials");
static_assert(offsetof(FCustomizableInstanceComponentData, OverlayMaterial) == 0x148, "Offset mismatch for FCustomizableInstanceComponentData::OverlayMaterial");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAnimInstanceOverridePhysicsAsset
{
    int32_t PropertyIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UPhysicsAsset* PhysicsAsset; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAnimInstanceOverridePhysicsAsset) == 0x10, "Size mismatch for FAnimInstanceOverridePhysicsAsset");
static_assert(offsetof(FAnimInstanceOverridePhysicsAsset, PropertyIndex) == 0x0, "Offset mismatch for FAnimInstanceOverridePhysicsAsset::PropertyIndex");
static_assert(offsetof(FAnimInstanceOverridePhysicsAsset, PhysicsAsset) == 0x8, "Offset mismatch for FAnimInstanceOverridePhysicsAsset::PhysicsAsset");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAnimBpGeneratedPhysicsAssets
{
    TArray<FAnimInstanceOverridePhysicsAsset> AnimInstancePropertyIndexAndPhysicsAssets; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAnimBpGeneratedPhysicsAssets) == 0x10, "Size mismatch for FAnimBpGeneratedPhysicsAssets");
static_assert(offsetof(FAnimBpGeneratedPhysicsAssets, AnimInstancePropertyIndexAndPhysicsAssets) == 0x0, "Offset mismatch for FAnimBpGeneratedPhysicsAssets::AnimInstancePropertyIndexAndPhysicsAssets");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FExtensionInstanceData
{
    TWeakObjectPtr<UCustomizableObjectExtension*> Extension; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FInstancedStruct Data; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FExtensionInstanceData) == 0x18, "Size mismatch for FExtensionInstanceData");
static_assert(offsetof(FExtensionInstanceData, Extension) == 0x0, "Offset mismatch for FExtensionInstanceData::Extension");
static_assert(offsetof(FExtensionInstanceData, Data) == 0x8, "Offset mismatch for FExtensionInstanceData::Data");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCustomizableObjectBoolParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    bool ParameterValue; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FGuid ID; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCustomizableObjectBoolParameterValue) == 0x28, "Size mismatch for FCustomizableObjectBoolParameterValue");
static_assert(offsetof(FCustomizableObjectBoolParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectBoolParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectBoolParameterValue, ParameterValue) == 0x10, "Offset mismatch for FCustomizableObjectBoolParameterValue::ParameterValue");
static_assert(offsetof(FCustomizableObjectBoolParameterValue, ID) == 0x14, "Offset mismatch for FCustomizableObjectBoolParameterValue::ID");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FCustomizableObjectIntParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString ParameterValueName; // 0x10 (Size: 0x10, Type: StrProperty)
    FGuid ID; // 0x20 (Size: 0x10, Type: StructProperty)
    TArray<FString> ParameterRangeValueNames; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomizableObjectIntParameterValue) == 0x40, "Size mismatch for FCustomizableObjectIntParameterValue");
static_assert(offsetof(FCustomizableObjectIntParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectIntParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectIntParameterValue, ParameterValueName) == 0x10, "Offset mismatch for FCustomizableObjectIntParameterValue::ParameterValueName");
static_assert(offsetof(FCustomizableObjectIntParameterValue, ID) == 0x20, "Offset mismatch for FCustomizableObjectIntParameterValue::ID");
static_assert(offsetof(FCustomizableObjectIntParameterValue, ParameterRangeValueNames) == 0x30, "Offset mismatch for FCustomizableObjectIntParameterValue::ParameterRangeValueNames");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCustomizableObjectFloatParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    float ParameterValue; // 0x10 (Size: 0x4, Type: FloatProperty)
    FGuid ID; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<float> ParameterRangeValues; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomizableObjectFloatParameterValue) == 0x38, "Size mismatch for FCustomizableObjectFloatParameterValue");
static_assert(offsetof(FCustomizableObjectFloatParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectFloatParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectFloatParameterValue, ParameterValue) == 0x10, "Offset mismatch for FCustomizableObjectFloatParameterValue::ParameterValue");
static_assert(offsetof(FCustomizableObjectFloatParameterValue, ID) == 0x14, "Offset mismatch for FCustomizableObjectFloatParameterValue::ID");
static_assert(offsetof(FCustomizableObjectFloatParameterValue, ParameterRangeValues) == 0x28, "Offset mismatch for FCustomizableObjectFloatParameterValue::ParameterRangeValues");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCustomizableObjectAssetParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    FName ParameterValue; // 0x10 (Size: 0x4, Type: NameProperty)
    FGuid ID; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FName> ParameterRangeValues; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomizableObjectAssetParameterValue) == 0x38, "Size mismatch for FCustomizableObjectAssetParameterValue");
static_assert(offsetof(FCustomizableObjectAssetParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectAssetParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectAssetParameterValue, ParameterValue) == 0x10, "Offset mismatch for FCustomizableObjectAssetParameterValue::ParameterValue");
static_assert(offsetof(FCustomizableObjectAssetParameterValue, ID) == 0x14, "Offset mismatch for FCustomizableObjectAssetParameterValue::ID");
static_assert(offsetof(FCustomizableObjectAssetParameterValue, ParameterRangeValues) == 0x28, "Offset mismatch for FCustomizableObjectAssetParameterValue::ParameterRangeValues");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCustomizableObjectVectorParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    FLinearColor ParameterValue; // 0x10 (Size: 0x10, Type: StructProperty)
    FGuid ID; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCustomizableObjectVectorParameterValue) == 0x30, "Size mismatch for FCustomizableObjectVectorParameterValue");
static_assert(offsetof(FCustomizableObjectVectorParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectVectorParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectVectorParameterValue, ParameterValue) == 0x10, "Offset mismatch for FCustomizableObjectVectorParameterValue::ParameterValue");
static_assert(offsetof(FCustomizableObjectVectorParameterValue, ID) == 0x20, "Offset mismatch for FCustomizableObjectVectorParameterValue::ID");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FCustomizableObjectTransformParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    FTransform ParameterValue; // 0x10 (Size: 0x60, Type: StructProperty)
    FGuid ID; // 0x70 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCustomizableObjectTransformParameterValue) == 0x80, "Size mismatch for FCustomizableObjectTransformParameterValue");
static_assert(offsetof(FCustomizableObjectTransformParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectTransformParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectTransformParameterValue, ParameterValue) == 0x10, "Offset mismatch for FCustomizableObjectTransformParameterValue::ParameterValue");
static_assert(offsetof(FCustomizableObjectTransformParameterValue, ID) == 0x70, "Offset mismatch for FCustomizableObjectTransformParameterValue::ID");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCustomizableObjectProjector
{
    FVector3f Position; // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f Direction; // 0xc (Size: 0xc, Type: StructProperty)
    FVector3f Up; // 0x18 (Size: 0xc, Type: StructProperty)
    FVector3f Scale; // 0x24 (Size: 0xc, Type: StructProperty)
    uint8_t ProjectionType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Angle; // 0x34 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FCustomizableObjectProjector) == 0x38, "Size mismatch for FCustomizableObjectProjector");
static_assert(offsetof(FCustomizableObjectProjector, Position) == 0x0, "Offset mismatch for FCustomizableObjectProjector::Position");
static_assert(offsetof(FCustomizableObjectProjector, Direction) == 0xc, "Offset mismatch for FCustomizableObjectProjector::Direction");
static_assert(offsetof(FCustomizableObjectProjector, Up) == 0x18, "Offset mismatch for FCustomizableObjectProjector::Up");
static_assert(offsetof(FCustomizableObjectProjector, Scale) == 0x24, "Offset mismatch for FCustomizableObjectProjector::Scale");
static_assert(offsetof(FCustomizableObjectProjector, ProjectionType) == 0x30, "Offset mismatch for FCustomizableObjectProjector::ProjectionType");
static_assert(offsetof(FCustomizableObjectProjector, Angle) == 0x34, "Offset mismatch for FCustomizableObjectProjector::Angle");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FCustomizableObjectProjectorParameterValue
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    FCustomizableObjectProjector Value; // 0x10 (Size: 0x38, Type: StructProperty)
    FGuid ID; // 0x48 (Size: 0x10, Type: StructProperty)
    TArray<FCustomizableObjectProjector> RangeValues; // 0x58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomizableObjectProjectorParameterValue) == 0x68, "Size mismatch for FCustomizableObjectProjectorParameterValue");
static_assert(offsetof(FCustomizableObjectProjectorParameterValue, ParameterName) == 0x0, "Offset mismatch for FCustomizableObjectProjectorParameterValue::ParameterName");
static_assert(offsetof(FCustomizableObjectProjectorParameterValue, Value) == 0x10, "Offset mismatch for FCustomizableObjectProjectorParameterValue::Value");
static_assert(offsetof(FCustomizableObjectProjectorParameterValue, ID) == 0x48, "Offset mismatch for FCustomizableObjectProjectorParameterValue::ID");
static_assert(offsetof(FCustomizableObjectProjectorParameterValue, RangeValues) == 0x58, "Offset mismatch for FCustomizableObjectProjectorParameterValue::RangeValues");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FCustomizableObjectMeshToMeshVertData
{
    float PositionBaryCoordsAndDist[0x4]; // 0x0 (Size: 0x10, Type: FloatProperty)
    float NormalBaryCoordsAndDist[0x4]; // 0x10 (Size: 0x10, Type: FloatProperty)
    float TangentBaryCoordsAndDist[0x4]; // 0x20 (Size: 0x10, Type: FloatProperty)
    uint16_t SourceMeshVertIndices[0x4]; // 0x30 (Size: 0x8, Type: UInt16Property)
    float Weight; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCustomizableObjectMeshToMeshVertData) == 0x40, "Size mismatch for FCustomizableObjectMeshToMeshVertData");
static_assert(offsetof(FCustomizableObjectMeshToMeshVertData, PositionBaryCoordsAndDist) == 0x0, "Offset mismatch for FCustomizableObjectMeshToMeshVertData::PositionBaryCoordsAndDist");
static_assert(offsetof(FCustomizableObjectMeshToMeshVertData, NormalBaryCoordsAndDist) == 0x10, "Offset mismatch for FCustomizableObjectMeshToMeshVertData::NormalBaryCoordsAndDist");
static_assert(offsetof(FCustomizableObjectMeshToMeshVertData, TangentBaryCoordsAndDist) == 0x20, "Offset mismatch for FCustomizableObjectMeshToMeshVertData::TangentBaryCoordsAndDist");
static_assert(offsetof(FCustomizableObjectMeshToMeshVertData, SourceMeshVertIndices) == 0x30, "Offset mismatch for FCustomizableObjectMeshToMeshVertData::SourceMeshVertIndices");
static_assert(offsetof(FCustomizableObjectMeshToMeshVertData, Weight) == 0x38, "Offset mismatch for FCustomizableObjectMeshToMeshVertData::Weight");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FMutableRemappedBone
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint32_t Hash; // 0x4 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FMutableRemappedBone) == 0x8, "Size mismatch for FMutableRemappedBone");
static_assert(offsetof(FMutableRemappedBone, Name) == 0x0, "Offset mismatch for FMutableRemappedBone::Name");
static_assert(offsetof(FMutableRemappedBone, Hash) == 0x4, "Offset mismatch for FMutableRemappedBone::Hash");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FMutableModelParameterValue
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t Value; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FMutableModelParameterValue) == 0x18, "Size mismatch for FMutableModelParameterValue");
static_assert(offsetof(FMutableModelParameterValue, Name) == 0x0, "Offset mismatch for FMutableModelParameterValue::Name");
static_assert(offsetof(FMutableModelParameterValue, Value) == 0x10, "Offset mismatch for FMutableModelParameterValue::Value");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FMutableModelParameterProperties
{
    uint8_t Type; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TArray<FMutableModelParameterValue> PossibleValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMutableModelParameterProperties) == 0x28, "Size mismatch for FMutableModelParameterProperties");
static_assert(offsetof(FMutableModelParameterProperties, Type) == 0x10, "Offset mismatch for FMutableModelParameterProperties::Type");
static_assert(offsetof(FMutableModelParameterProperties, PossibleValues) == 0x18, "Offset mismatch for FMutableModelParameterProperties::PossibleValues");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FMutableModelImageProperties
{
    FString TextureParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<TextureFilter> Filter; // 0x10 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    uint8_t SRGB : 1; // 0x14:0 (Size: 0x1, Type: BoolProperty)
    uint8_t FlipGreenChannel : 1; // 0x14:1 (Size: 0x1, Type: BoolProperty)
    uint8_t IsPassThrough : 1; // 0x14:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    int32_t LODBias; // 0x18 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<TextureMipGenSettings> MipGenSettings; // 0x1c (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<TextureGroup> LODGroup; // 0x1d (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<TextureAddress> AddressX; // 0x1e (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<TextureAddress> AddressY; // 0x1f (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FMutableModelImageProperties) == 0x20, "Size mismatch for FMutableModelImageProperties");
static_assert(offsetof(FMutableModelImageProperties, TextureParameterName) == 0x0, "Offset mismatch for FMutableModelImageProperties::TextureParameterName");
static_assert(offsetof(FMutableModelImageProperties, Filter) == 0x10, "Offset mismatch for FMutableModelImageProperties::Filter");
static_assert(offsetof(FMutableModelImageProperties, SRGB) == 0x14, "Offset mismatch for FMutableModelImageProperties::SRGB");
static_assert(offsetof(FMutableModelImageProperties, FlipGreenChannel) == 0x14, "Offset mismatch for FMutableModelImageProperties::FlipGreenChannel");
static_assert(offsetof(FMutableModelImageProperties, IsPassThrough) == 0x14, "Offset mismatch for FMutableModelImageProperties::IsPassThrough");
static_assert(offsetof(FMutableModelImageProperties, LODBias) == 0x18, "Offset mismatch for FMutableModelImageProperties::LODBias");
static_assert(offsetof(FMutableModelImageProperties, MipGenSettings) == 0x1c, "Offset mismatch for FMutableModelImageProperties::MipGenSettings");
static_assert(offsetof(FMutableModelImageProperties, LODGroup) == 0x1d, "Offset mismatch for FMutableModelImageProperties::LODGroup");
static_assert(offsetof(FMutableModelImageProperties, AddressX) == 0x1e, "Offset mismatch for FMutableModelImageProperties::AddressX");
static_assert(offsetof(FMutableModelImageProperties, AddressY) == 0x1f, "Offset mismatch for FMutableModelImageProperties::AddressY");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FMutableRefSocket
{
    FName SocketName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName; // 0x4 (Size: 0x4, Type: NameProperty)
    FVector RelativeLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator RelativeRotation; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector RelativeScale; // 0x38 (Size: 0x18, Type: StructProperty)
    bool bForceAlwaysAnimated; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x3]; // 0x51 (Size: 0x3, Type: PaddingProperty)
    int32_t Priority; // 0x54 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FMutableRefSocket) == 0x58, "Size mismatch for FMutableRefSocket");
static_assert(offsetof(FMutableRefSocket, SocketName) == 0x0, "Offset mismatch for FMutableRefSocket::SocketName");
static_assert(offsetof(FMutableRefSocket, BoneName) == 0x4, "Offset mismatch for FMutableRefSocket::BoneName");
static_assert(offsetof(FMutableRefSocket, RelativeLocation) == 0x8, "Offset mismatch for FMutableRefSocket::RelativeLocation");
static_assert(offsetof(FMutableRefSocket, RelativeRotation) == 0x20, "Offset mismatch for FMutableRefSocket::RelativeRotation");
static_assert(offsetof(FMutableRefSocket, RelativeScale) == 0x38, "Offset mismatch for FMutableRefSocket::RelativeScale");
static_assert(offsetof(FMutableRefSocket, bForceAlwaysAnimated) == 0x50, "Offset mismatch for FMutableRefSocket::bForceAlwaysAnimated");
static_assert(offsetof(FMutableRefSocket, Priority) == 0x54, "Offset mismatch for FMutableRefSocket::Priority");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FMutableRefLODInfo
{
    float ScreenSize; // 0x0 (Size: 0x4, Type: FloatProperty)
    float LODHysteresis; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bSupportUniformlyDistributedSampling; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bAllowCPUAccess; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FMutableRefLODInfo) == 0xc, "Size mismatch for FMutableRefLODInfo");
static_assert(offsetof(FMutableRefLODInfo, ScreenSize) == 0x0, "Offset mismatch for FMutableRefLODInfo::ScreenSize");
static_assert(offsetof(FMutableRefLODInfo, LODHysteresis) == 0x4, "Offset mismatch for FMutableRefLODInfo::LODHysteresis");
static_assert(offsetof(FMutableRefLODInfo, bSupportUniformlyDistributedSampling) == 0x8, "Offset mismatch for FMutableRefLODInfo::bSupportUniformlyDistributedSampling");
static_assert(offsetof(FMutableRefLODInfo, bAllowCPUAccess) == 0x9, "Offset mismatch for FMutableRefLODInfo::bAllowCPUAccess");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FMutableRefLODRenderData
{
    bool bIsLODOptional; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bStreamedDataInlined; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FMutableRefLODRenderData) == 0x2, "Size mismatch for FMutableRefLODRenderData");
static_assert(offsetof(FMutableRefLODRenderData, bIsLODOptional) == 0x0, "Offset mismatch for FMutableRefLODRenderData::bIsLODOptional");
static_assert(offsetof(FMutableRefLODRenderData, bStreamedDataInlined) == 0x1, "Offset mismatch for FMutableRefLODRenderData::bStreamedDataInlined");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FMutableRefLODData
{
    FMutableRefLODInfo LODInfo; // 0x0 (Size: 0xc, Type: StructProperty)
    FMutableRefLODRenderData RenderData; // 0xc (Size: 0x2, Type: StructProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FMutableRefLODData) == 0x10, "Size mismatch for FMutableRefLODData");
static_assert(offsetof(FMutableRefLODData, LODInfo) == 0x0, "Offset mismatch for FMutableRefLODData::LODInfo");
static_assert(offsetof(FMutableRefLODData, RenderData) == 0xc, "Offset mismatch for FMutableRefLODData::RenderData");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FMutableRefSkeletalMeshSettings
{
    bool bEnablePerPolyCollision; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float DefaultUVChannelDensity; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FMutableRefSkeletalMeshSettings) == 0x8, "Size mismatch for FMutableRefSkeletalMeshSettings");
static_assert(offsetof(FMutableRefSkeletalMeshSettings, bEnablePerPolyCollision) == 0x0, "Offset mismatch for FMutableRefSkeletalMeshSettings::bEnablePerPolyCollision");
static_assert(offsetof(FMutableRefSkeletalMeshSettings, DefaultUVChannelDensity) == 0x4, "Offset mismatch for FMutableRefSkeletalMeshSettings::DefaultUVChannelDensity");

// Size: 0xd8 (Inherited: 0x0, Single: 0xd8)
struct FMutableRefSkeletalMeshData
{
    USkeletalMesh* SkeletalMesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<USkeletalMesh*> SoftSkeletalMesh; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    USkeletalMeshLODSettings* SkeletalMeshLODSettings; // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FMutableRefLODData> LODData; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FMutableRefSocket> Sockets; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FBoxSphereBounds Bounds; // 0x50 (Size: 0x38, Type: StructProperty)
    FMutableRefSkeletalMeshSettings Settings; // 0x88 (Size: 0x8, Type: StructProperty)
    USkeleton* Skeleton; // 0x90 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset; // 0x98 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr PostProcessAnimInst; // 0xa0 (Size: 0x20, Type: SoftClassProperty)
    UPhysicsAsset* ShadowPhysicsAsset; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TArray<int32_t> AssetUserDataIndices; // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMutableRefSkeletalMeshData) == 0xd8, "Size mismatch for FMutableRefSkeletalMeshData");
static_assert(offsetof(FMutableRefSkeletalMeshData, SkeletalMesh) == 0x0, "Offset mismatch for FMutableRefSkeletalMeshData::SkeletalMesh");
static_assert(offsetof(FMutableRefSkeletalMeshData, SoftSkeletalMesh) == 0x8, "Offset mismatch for FMutableRefSkeletalMeshData::SoftSkeletalMesh");
static_assert(offsetof(FMutableRefSkeletalMeshData, SkeletalMeshLODSettings) == 0x28, "Offset mismatch for FMutableRefSkeletalMeshData::SkeletalMeshLODSettings");
static_assert(offsetof(FMutableRefSkeletalMeshData, LODData) == 0x30, "Offset mismatch for FMutableRefSkeletalMeshData::LODData");
static_assert(offsetof(FMutableRefSkeletalMeshData, Sockets) == 0x40, "Offset mismatch for FMutableRefSkeletalMeshData::Sockets");
static_assert(offsetof(FMutableRefSkeletalMeshData, Bounds) == 0x50, "Offset mismatch for FMutableRefSkeletalMeshData::Bounds");
static_assert(offsetof(FMutableRefSkeletalMeshData, Settings) == 0x88, "Offset mismatch for FMutableRefSkeletalMeshData::Settings");
static_assert(offsetof(FMutableRefSkeletalMeshData, Skeleton) == 0x90, "Offset mismatch for FMutableRefSkeletalMeshData::Skeleton");
static_assert(offsetof(FMutableRefSkeletalMeshData, PhysicsAsset) == 0x98, "Offset mismatch for FMutableRefSkeletalMeshData::PhysicsAsset");
static_assert(offsetof(FMutableRefSkeletalMeshData, PostProcessAnimInst) == 0xa0, "Offset mismatch for FMutableRefSkeletalMeshData::PostProcessAnimInst");
static_assert(offsetof(FMutableRefSkeletalMeshData, ShadowPhysicsAsset) == 0xc0, "Offset mismatch for FMutableRefSkeletalMeshData::ShadowPhysicsAsset");
static_assert(offsetof(FMutableRefSkeletalMeshData, AssetUserDataIndices) == 0xc8, "Offset mismatch for FMutableRefSkeletalMeshData::AssetUserDataIndices");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FAnimBpOverridePhysicsAssetsInfo
{
    TSoftClassPtr AnimInstanceClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    TSoftObjectPtr<UPhysicsAsset*> SourceAsset; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    int32_t PropertyIndex; // 0x40 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimBpOverridePhysicsAssetsInfo) == 0x48, "Size mismatch for FAnimBpOverridePhysicsAssetsInfo");
static_assert(offsetof(FAnimBpOverridePhysicsAssetsInfo, AnimInstanceClass) == 0x0, "Offset mismatch for FAnimBpOverridePhysicsAssetsInfo::AnimInstanceClass");
static_assert(offsetof(FAnimBpOverridePhysicsAssetsInfo, SourceAsset) == 0x20, "Offset mismatch for FAnimBpOverridePhysicsAssetsInfo::SourceAsset");
static_assert(offsetof(FAnimBpOverridePhysicsAssetsInfo, PropertyIndex) == 0x40, "Offset mismatch for FAnimBpOverridePhysicsAssetsInfo::PropertyIndex");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FMutableSkinWeightProfileInfo
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint32_t NameId; // 0x4 (Size: 0x4, Type: UInt32Property)
    bool DefaultProfile; // 0x8 (Size: 0x1, Type: BoolProperty)
    int8_t DefaultProfileFromLODIndex; // 0x9 (Size: 0x1, Type: Int8Property)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FMutableSkinWeightProfileInfo) == 0xc, "Size mismatch for FMutableSkinWeightProfileInfo");
static_assert(offsetof(FMutableSkinWeightProfileInfo, Name) == 0x0, "Offset mismatch for FMutableSkinWeightProfileInfo::Name");
static_assert(offsetof(FMutableSkinWeightProfileInfo, NameId) == 0x4, "Offset mismatch for FMutableSkinWeightProfileInfo::NameId");
static_assert(offsetof(FMutableSkinWeightProfileInfo, DefaultProfile) == 0x8, "Offset mismatch for FMutableSkinWeightProfileInfo::DefaultProfile");
static_assert(offsetof(FMutableSkinWeightProfileInfo, DefaultProfileFromLODIndex) == 0x9, "Offset mismatch for FMutableSkinWeightProfileInfo::DefaultProfileFromLODIndex");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FMutableStreamableBlock
{
    uint32_t FileId; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint16_t Flags; // 0x4 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    uint64_t Offset; // 0x8 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FMutableStreamableBlock) == 0x10, "Size mismatch for FMutableStreamableBlock");
static_assert(offsetof(FMutableStreamableBlock, FileId) == 0x0, "Offset mismatch for FMutableStreamableBlock::FileId");
static_assert(offsetof(FMutableStreamableBlock, Flags) == 0x4, "Offset mismatch for FMutableStreamableBlock::Flags");
static_assert(offsetof(FMutableStreamableBlock, Offset) == 0x8, "Offset mismatch for FMutableStreamableBlock::Offset");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FRealTimeMorphStreamable
{
    TArray<FName> NameResolutionMap; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FMutableStreamableBlock bLock; // 0x10 (Size: 0x10, Type: StructProperty)
    uint32_t Size; // 0x20 (Size: 0x4, Type: UInt32Property)
    uint32_t SourceId; // 0x24 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FRealTimeMorphStreamable) == 0x28, "Size mismatch for FRealTimeMorphStreamable");
static_assert(offsetof(FRealTimeMorphStreamable, NameResolutionMap) == 0x0, "Offset mismatch for FRealTimeMorphStreamable::NameResolutionMap");
static_assert(offsetof(FRealTimeMorphStreamable, bLock) == 0x10, "Offset mismatch for FRealTimeMorphStreamable::bLock");
static_assert(offsetof(FRealTimeMorphStreamable, Size) == 0x20, "Offset mismatch for FRealTimeMorphStreamable::Size");
static_assert(offsetof(FRealTimeMorphStreamable, SourceId) == 0x24, "Offset mismatch for FRealTimeMorphStreamable::SourceId");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FMutableMeshMetadata
{
    uint32_t MorphMetadataId; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t ClothingMetadataId; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t SurfaceMetadataId; // 0x8 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FMutableMeshMetadata) == 0xc, "Size mismatch for FMutableMeshMetadata");
static_assert(offsetof(FMutableMeshMetadata, MorphMetadataId) == 0x0, "Offset mismatch for FMutableMeshMetadata::MorphMetadataId");
static_assert(offsetof(FMutableMeshMetadata, ClothingMetadataId) == 0x4, "Offset mismatch for FMutableMeshMetadata::ClothingMetadataId");
static_assert(offsetof(FMutableMeshMetadata, SurfaceMetadataId) == 0x8, "Offset mismatch for FMutableMeshMetadata::SurfaceMetadataId");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FMutableSurfaceMetadata
{
    FName MaterialSlotName; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bCastShadow; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FMutableSurfaceMetadata) == 0x8, "Size mismatch for FMutableSurfaceMetadata");
static_assert(offsetof(FMutableSurfaceMetadata, MaterialSlotName) == 0x0, "Offset mismatch for FMutableSurfaceMetadata::MaterialSlotName");
static_assert(offsetof(FMutableSurfaceMetadata, bCastShadow) == 0x4, "Offset mismatch for FMutableSurfaceMetadata::bCastShadow");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FClothingStreamable
{
    int32_t ClothingAssetIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ClothingAssetLOD; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t PhysicsAssetIndex; // 0x8 (Size: 0x4, Type: IntProperty)
    uint32_t Size; // 0xc (Size: 0x4, Type: UInt32Property)
    FMutableStreamableBlock bLock; // 0x10 (Size: 0x10, Type: StructProperty)
    uint32_t SourceId; // 0x20 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FClothingStreamable) == 0x28, "Size mismatch for FClothingStreamable");
static_assert(offsetof(FClothingStreamable, ClothingAssetIndex) == 0x0, "Offset mismatch for FClothingStreamable::ClothingAssetIndex");
static_assert(offsetof(FClothingStreamable, ClothingAssetLOD) == 0x4, "Offset mismatch for FClothingStreamable::ClothingAssetLOD");
static_assert(offsetof(FClothingStreamable, PhysicsAssetIndex) == 0x8, "Offset mismatch for FClothingStreamable::PhysicsAssetIndex");
static_assert(offsetof(FClothingStreamable, Size) == 0xc, "Offset mismatch for FClothingStreamable::Size");
static_assert(offsetof(FClothingStreamable, bLock) == 0x10, "Offset mismatch for FClothingStreamable::bLock");
static_assert(offsetof(FClothingStreamable, SourceId) == 0x20, "Offset mismatch for FClothingStreamable::SourceId");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FMorphTargetVertexData
{
    FVector3f PositionDelta; // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f TangentZDelta; // 0xc (Size: 0xc, Type: StructProperty)
    uint32_t MorphNameIndex; // 0x18 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FMorphTargetVertexData) == 0x1c, "Size mismatch for FMorphTargetVertexData");
static_assert(offsetof(FMorphTargetVertexData, PositionDelta) == 0x0, "Offset mismatch for FMorphTargetVertexData::PositionDelta");
static_assert(offsetof(FMorphTargetVertexData, TangentZDelta) == 0xc, "Offset mismatch for FMorphTargetVertexData::TangentZDelta");
static_assert(offsetof(FMorphTargetVertexData, MorphNameIndex) == 0x18, "Offset mismatch for FMorphTargetVertexData::MorphNameIndex");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FIntegerParameterOptionKey
{
    FString ParameterName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString ParameterOption; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FIntegerParameterOptionKey) == 0x20, "Size mismatch for FIntegerParameterOptionKey");
static_assert(offsetof(FIntegerParameterOptionKey, ParameterName) == 0x0, "Offset mismatch for FIntegerParameterOptionKey::ParameterName");
static_assert(offsetof(FIntegerParameterOptionKey, ParameterOption) == 0x10, "Offset mismatch for FIntegerParameterOptionKey::ParameterOption");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FIntegerParameterOptionDataTable
{
    TSet<TSoftObjectPtr<UDataTable*>> DataTables; // 0x0 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FIntegerParameterOptionDataTable) == 0x50, "Size mismatch for FIntegerParameterOptionDataTable");
static_assert(offsetof(FIntegerParameterOptionDataTable, DataTables) == 0x0, "Offset mismatch for FIntegerParameterOptionDataTable::DataTables");

// Size: 0x110 (Inherited: 0x0, Single: 0x110)
struct FIntegerParameterUIData
{
    FMutableParamUIMetadata ParamUIMetadata; // 0x0 (Size: 0x110, Type: StructProperty)
};

static_assert(sizeof(FIntegerParameterUIData) == 0x110, "Size mismatch for FIntegerParameterUIData");
static_assert(offsetof(FIntegerParameterUIData, ParamUIMetadata) == 0x0, "Offset mismatch for FIntegerParameterUIData::ParamUIMetadata");

// Size: 0xe8 (Inherited: 0x0, Single: 0xe8)
struct FMutableUIMetadata
{
    FString ObjectFriendlyName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString UISectionName; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t UIOrder; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UTexture2D*> UIThumbnail; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FString, FString> ExtraInformation; // 0x48 (Size: 0x50, Type: MapProperty)
    TMap<TSoftObjectPtr<UObject*>, FString> ExtraAssets; // 0x98 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FMutableUIMetadata) == 0xe8, "Size mismatch for FMutableUIMetadata");
static_assert(offsetof(FMutableUIMetadata, ObjectFriendlyName) == 0x0, "Offset mismatch for FMutableUIMetadata::ObjectFriendlyName");
static_assert(offsetof(FMutableUIMetadata, UISectionName) == 0x10, "Offset mismatch for FMutableUIMetadata::UISectionName");
static_assert(offsetof(FMutableUIMetadata, UIOrder) == 0x20, "Offset mismatch for FMutableUIMetadata::UIOrder");
static_assert(offsetof(FMutableUIMetadata, UIThumbnail) == 0x28, "Offset mismatch for FMutableUIMetadata::UIThumbnail");
static_assert(offsetof(FMutableUIMetadata, ExtraInformation) == 0x48, "Offset mismatch for FMutableUIMetadata::ExtraInformation");
static_assert(offsetof(FMutableUIMetadata, ExtraAssets) == 0x98, "Offset mismatch for FMutableUIMetadata::ExtraAssets");

// Size: 0x110 (Inherited: 0xe8, Single: 0x28)
struct FMutableParamUIMetadata : FMutableUIMetadata
{
    float MinimumValue; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float MaximumValue; // 0xec (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer GameplayTags; // 0xf0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FMutableParamUIMetadata) == 0x110, "Size mismatch for FMutableParamUIMetadata");
static_assert(offsetof(FMutableParamUIMetadata, MinimumValue) == 0xe8, "Offset mismatch for FMutableParamUIMetadata::MinimumValue");
static_assert(offsetof(FMutableParamUIMetadata, MaximumValue) == 0xec, "Offset mismatch for FMutableParamUIMetadata::MaximumValue");
static_assert(offsetof(FMutableParamUIMetadata, GameplayTags) == 0xf0, "Offset mismatch for FMutableParamUIMetadata::GameplayTags");

// Size: 0x170 (Inherited: 0x0, Single: 0x170)
struct FMutableParameterData
{
    FMutableParamUIMetadata ParamUIMetadata; // 0x0 (Size: 0x110, Type: StructProperty)
    uint8_t Type; // 0x110 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
    TMap<FIntegerParameterUIData, FString> ArrayIntegerParameterOption; // 0x118 (Size: 0x50, Type: MapProperty)
    uint8_t IntegerParameterGroupType; // 0x168 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_169[0x7]; // 0x169 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FMutableParameterData) == 0x170, "Size mismatch for FMutableParameterData");
static_assert(offsetof(FMutableParameterData, ParamUIMetadata) == 0x0, "Offset mismatch for FMutableParameterData::ParamUIMetadata");
static_assert(offsetof(FMutableParameterData, Type) == 0x110, "Offset mismatch for FMutableParameterData::Type");
static_assert(offsetof(FMutableParameterData, ArrayIntegerParameterOption) == 0x118, "Offset mismatch for FMutableParameterData::ArrayIntegerParameterOption");
static_assert(offsetof(FMutableParameterData, IntegerParameterGroupType) == 0x168, "Offset mismatch for FMutableParameterData::IntegerParameterGroupType");

// Size: 0x140 (Inherited: 0x0, Single: 0x140)
struct FMutableStateData
{
    FMutableStateUIMetadata StateUIMetadata; // 0x0 (Size: 0xe8, Type: StructProperty)
    bool bLiveUpdateMode; // 0xe8 (Size: 0x1, Type: BoolProperty)
    bool bDisableTextureStreaming; // 0xe9 (Size: 0x1, Type: BoolProperty)
    bool bReuseInstanceTextures; // 0xea (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_eb[0x5]; // 0xeb (Size: 0x5, Type: PaddingProperty)
    TMap<FString, FString> ForcedParameterValues; // 0xf0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FMutableStateData) == 0x140, "Size mismatch for FMutableStateData");
static_assert(offsetof(FMutableStateData, StateUIMetadata) == 0x0, "Offset mismatch for FMutableStateData::StateUIMetadata");
static_assert(offsetof(FMutableStateData, bLiveUpdateMode) == 0xe8, "Offset mismatch for FMutableStateData::bLiveUpdateMode");
static_assert(offsetof(FMutableStateData, bDisableTextureStreaming) == 0xe9, "Offset mismatch for FMutableStateData::bDisableTextureStreaming");
static_assert(offsetof(FMutableStateData, bReuseInstanceTextures) == 0xea, "Offset mismatch for FMutableStateData::bReuseInstanceTextures");
static_assert(offsetof(FMutableStateData, ForcedParameterValues) == 0xf0, "Offset mismatch for FMutableStateData::ForcedParameterValues");

// Size: 0xe8 (Inherited: 0xe8, Single: 0x0)
struct FMutableStateUIMetadata : FMutableUIMetadata
{
};

static_assert(sizeof(FMutableStateUIMetadata) == 0xe8, "Size mismatch for FMutableStateUIMetadata");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FMutableParamNameSet
{
};

static_assert(sizeof(FMutableParamNameSet) == 0x50, "Size mismatch for FMutableParamNameSet");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FMutableMeshComponentData
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    USkeletalMesh* ReferenceSkeletalMesh; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FMutableMeshComponentData) == 0x10, "Size mismatch for FMutableMeshComponentData");
static_assert(offsetof(FMutableMeshComponentData, Name) == 0x0, "Offset mismatch for FMutableMeshComponentData::Name");
static_assert(offsetof(FMutableMeshComponentData, ReferenceSkeletalMesh) == 0x8, "Offset mismatch for FMutableMeshComponentData::ReferenceSkeletalMesh");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCustomizableObjectComponentIndex
{
};

static_assert(sizeof(FCustomizableObjectComponentIndex) == 0x4, "Size mismatch for FCustomizableObjectComponentIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCustomizableObjectResourceData
{
    uint8_t Type[0x2]; // 0x0 (Size: 0x2, Type: EnumProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    FInstancedStruct Data; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCustomizableObjectResourceData) == 0x18, "Size mismatch for FCustomizableObjectResourceData");
static_assert(offsetof(FCustomizableObjectResourceData, Type) == 0x0, "Offset mismatch for FCustomizableObjectResourceData::Type");
static_assert(offsetof(FCustomizableObjectResourceData, Data) == 0x8, "Offset mismatch for FCustomizableObjectResourceData::Data");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCustomizableObjectAssetUserData
{
    UAssetUserData* AssetUserData; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCustomizableObjectAssetUserData) == 0x8, "Size mismatch for FCustomizableObjectAssetUserData");
static_assert(offsetof(FCustomizableObjectAssetUserData, AssetUserData) == 0x0, "Offset mismatch for FCustomizableObjectAssetUserData::AssetUserData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeneratedTexture
{
    FString Name; // 0x10 (Size: 0x10, Type: StrProperty)
    UTexture* Texture; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGeneratedTexture) == 0x28, "Size mismatch for FGeneratedTexture");
static_assert(offsetof(FGeneratedTexture, Name) == 0x10, "Offset mismatch for FGeneratedTexture::Name");
static_assert(offsetof(FGeneratedTexture, Texture) == 0x20, "Offset mismatch for FGeneratedTexture::Texture");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeneratedMaterial
{
    UMaterialInterface* MaterialInterface; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGeneratedTexture> Textures; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGeneratedMaterial) == 0x20, "Size mismatch for FGeneratedMaterial");
static_assert(offsetof(FGeneratedMaterial, MaterialInterface) == 0x0, "Offset mismatch for FGeneratedMaterial::MaterialInterface");
static_assert(offsetof(FGeneratedMaterial, Textures) == 0x8, "Offset mismatch for FGeneratedMaterial::Textures");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPendingReleaseSkeletalMeshInfo
{
    USkeletalMesh* SkeletalMesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    double Timestamp; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FPendingReleaseSkeletalMeshInfo) == 0x10, "Size mismatch for FPendingReleaseSkeletalMeshInfo");
static_assert(offsetof(FPendingReleaseSkeletalMeshInfo, SkeletalMesh) == 0x0, "Offset mismatch for FPendingReleaseSkeletalMeshInfo::SkeletalMesh");
static_assert(offsetof(FPendingReleaseSkeletalMeshInfo, Timestamp) == 0x8, "Offset mismatch for FPendingReleaseSkeletalMeshInfo::Timestamp");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCompilationOptions_DEPRECATED
{
    uint8_t TextureCompression; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t OptimizationLevel; // 0x4 (Size: 0x4, Type: IntProperty)
    bool bUseDiskCompilation; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    uint64_t PackagedDataBytesLimit; // 0x10 (Size: 0x8, Type: UInt64Property)
    uint64_t EmbeddedDataBytesLimit; // 0x18 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FCompilationOptions_DEPRECATED) == 0x20, "Size mismatch for FCompilationOptions_DEPRECATED");
static_assert(offsetof(FCompilationOptions_DEPRECATED, TextureCompression) == 0x0, "Offset mismatch for FCompilationOptions_DEPRECATED::TextureCompression");
static_assert(offsetof(FCompilationOptions_DEPRECATED, OptimizationLevel) == 0x4, "Offset mismatch for FCompilationOptions_DEPRECATED::OptimizationLevel");
static_assert(offsetof(FCompilationOptions_DEPRECATED, bUseDiskCompilation) == 0x8, "Offset mismatch for FCompilationOptions_DEPRECATED::bUseDiskCompilation");
static_assert(offsetof(FCompilationOptions_DEPRECATED, PackagedDataBytesLimit) == 0x10, "Offset mismatch for FCompilationOptions_DEPRECATED::PackagedDataBytesLimit");
static_assert(offsetof(FCompilationOptions_DEPRECATED, EmbeddedDataBytesLimit) == 0x18, "Offset mismatch for FCompilationOptions_DEPRECATED::EmbeddedDataBytesLimit");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFParameterOptionsTags
{
    TArray<FString> Tags; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFParameterOptionsTags) == 0x10, "Size mismatch for FFParameterOptionsTags");
static_assert(offsetof(FFParameterOptionsTags, Tags) == 0x0, "Offset mismatch for FFParameterOptionsTags::Tags");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FParameterTags
{
    TArray<FString> Tags; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<FFParameterOptionsTags, FString> ParameterOptions; // 0x10 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FParameterTags) == 0x60, "Size mismatch for FParameterTags");
static_assert(offsetof(FParameterTags, Tags) == 0x0, "Offset mismatch for FParameterTags::Tags");
static_assert(offsetof(FParameterTags, ParameterOptions) == 0x10, "Offset mismatch for FParameterTags::ParameterOptions");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FProfileParameterDat
{
    FString ProfileName; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FCustomizableObjectBoolParameterValue> BoolParameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectIntParameterValue> IntParameters; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectFloatParameterValue> FloatParameters; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> TextureParameters; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> MeshParameters; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectVectorParameterValue> VectorParameters; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectProjectorParameterValue> ProjectorParameters; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectTransformParameterValue> TransformParameters; // 0x80 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FProfileParameterDat) == 0x90, "Size mismatch for FProfileParameterDat");
static_assert(offsetof(FProfileParameterDat, ProfileName) == 0x0, "Offset mismatch for FProfileParameterDat::ProfileName");
static_assert(offsetof(FProfileParameterDat, BoolParameters) == 0x10, "Offset mismatch for FProfileParameterDat::BoolParameters");
static_assert(offsetof(FProfileParameterDat, IntParameters) == 0x20, "Offset mismatch for FProfileParameterDat::IntParameters");
static_assert(offsetof(FProfileParameterDat, FloatParameters) == 0x30, "Offset mismatch for FProfileParameterDat::FloatParameters");
static_assert(offsetof(FProfileParameterDat, TextureParameters) == 0x40, "Offset mismatch for FProfileParameterDat::TextureParameters");
static_assert(offsetof(FProfileParameterDat, MeshParameters) == 0x50, "Offset mismatch for FProfileParameterDat::MeshParameters");
static_assert(offsetof(FProfileParameterDat, VectorParameters) == 0x60, "Offset mismatch for FProfileParameterDat::VectorParameters");
static_assert(offsetof(FProfileParameterDat, ProjectorParameters) == 0x70, "Offset mismatch for FProfileParameterDat::ProjectorParameters");
static_assert(offsetof(FProfileParameterDat, TransformParameters) == 0x80, "Offset mismatch for FProfileParameterDat::TransformParameters");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FMutableLODSettings
{
    FPerPlatformInt MinLOD; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FPerQualityLevelInt MinQualityLevelLOD; // 0x8 (Size: 0x68, Type: StructProperty)
};

static_assert(sizeof(FMutableLODSettings) == 0x70, "Size mismatch for FMutableLODSettings");
static_assert(offsetof(FMutableLODSettings, MinLOD) == 0x0, "Offset mismatch for FMutableLODSettings::MinLOD");
static_assert(offsetof(FMutableLODSettings, MinQualityLevelLOD) == 0x8, "Offset mismatch for FMutableLODSettings::MinQualityLevelLOD");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCompileParams
{
    bool bSkipIfCompiled; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSkipIfOutOfDate; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bGatherReferneces; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAsync; // 0x3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UCustomizableObjectInstance* CompileOnlySelectedInstance; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t OptimizationLevel; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t TextureCompression; // 0x11 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_12[0x2]; // 0x12 (Size: 0x2, Type: PaddingProperty)
    uint8_t Callback[0xc]; // 0x14 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FCompileParams) == 0x30, "Size mismatch for FCompileParams");
static_assert(offsetof(FCompileParams, bSkipIfCompiled) == 0x0, "Offset mismatch for FCompileParams::bSkipIfCompiled");
static_assert(offsetof(FCompileParams, bSkipIfOutOfDate) == 0x1, "Offset mismatch for FCompileParams::bSkipIfOutOfDate");
static_assert(offsetof(FCompileParams, bGatherReferneces) == 0x2, "Offset mismatch for FCompileParams::bGatherReferneces");
static_assert(offsetof(FCompileParams, bAsync) == 0x3, "Offset mismatch for FCompileParams::bAsync");
static_assert(offsetof(FCompileParams, CompileOnlySelectedInstance) == 0x8, "Offset mismatch for FCompileParams::CompileOnlySelectedInstance");
static_assert(offsetof(FCompileParams, OptimizationLevel) == 0x10, "Offset mismatch for FCompileParams::OptimizationLevel");
static_assert(offsetof(FCompileParams, TextureCompression) == 0x11, "Offset mismatch for FCompileParams::TextureCompression");
static_assert(offsetof(FCompileParams, Callback) == 0x14, "Offset mismatch for FCompileParams::Callback");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCustomizableObjectIdPair
{
    FString CustomizableObjectGroupName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString CustomizableObjectName; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCustomizableObjectIdPair) == 0x20, "Size mismatch for FCustomizableObjectIdPair");
static_assert(offsetof(FCustomizableObjectIdPair, CustomizableObjectGroupName) == 0x0, "Offset mismatch for FCustomizableObjectIdPair::CustomizableObjectGroupName");
static_assert(offsetof(FCustomizableObjectIdPair, CustomizableObjectName) == 0x10, "Offset mismatch for FCustomizableObjectIdPair::CustomizableObjectName");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBakingConfiguration
{
    FString OutputPath; // 0x0 (Size: 0x10, Type: StrProperty)
    FString OutputFilesBaseName; // 0x10 (Size: 0x10, Type: StrProperty)
    bool bExportAllResourcesOnBake; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bGenerateConstantMaterialInstancesOnBake; // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bAllowOverridingOfFiles; // 0x22 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_23[0x1]; // 0x23 (Size: 0x1, Type: PaddingProperty)
    uint8_t OnBakeOperationCompletedCallback[0xc]; // 0x24 (Size: 0xc, Type: DelegateProperty)
};

static_assert(sizeof(FBakingConfiguration) == 0x30, "Size mismatch for FBakingConfiguration");
static_assert(offsetof(FBakingConfiguration, OutputPath) == 0x0, "Offset mismatch for FBakingConfiguration::OutputPath");
static_assert(offsetof(FBakingConfiguration, OutputFilesBaseName) == 0x10, "Offset mismatch for FBakingConfiguration::OutputFilesBaseName");
static_assert(offsetof(FBakingConfiguration, bExportAllResourcesOnBake) == 0x20, "Offset mismatch for FBakingConfiguration::bExportAllResourcesOnBake");
static_assert(offsetof(FBakingConfiguration, bGenerateConstantMaterialInstancesOnBake) == 0x21, "Offset mismatch for FBakingConfiguration::bGenerateConstantMaterialInstancesOnBake");
static_assert(offsetof(FBakingConfiguration, bAllowOverridingOfFiles) == 0x22, "Offset mismatch for FBakingConfiguration::bAllowOverridingOfFiles");
static_assert(offsetof(FBakingConfiguration, OnBakeOperationCompletedCallback) == 0x24, "Offset mismatch for FBakingConfiguration::OnBakeOperationCompletedCallback");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FCustomizableObjectInstanceDescriptor
{
    UCustomizableObject* CustomizableObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FCustomizableObjectBoolParameterValue> BoolParameters; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectIntParameterValue> IntParameters; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectFloatParameterValue> FloatParameters; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> TextureParameters; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> MeshParameters; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectVectorParameterValue> VectorParameters; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectProjectorParameterValue> ProjectorParameters; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectTransformParameterValue> TransformParameters; // 0x78 (Size: 0x10, Type: ArrayProperty)
    int32_t State; // 0x88 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8c[0xf4]; // 0x8c (Size: 0xf4, Type: PaddingProperty)
};

static_assert(sizeof(FCustomizableObjectInstanceDescriptor) == 0x180, "Size mismatch for FCustomizableObjectInstanceDescriptor");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, CustomizableObject) == 0x0, "Offset mismatch for FCustomizableObjectInstanceDescriptor::CustomizableObject");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, BoolParameters) == 0x8, "Offset mismatch for FCustomizableObjectInstanceDescriptor::BoolParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, IntParameters) == 0x18, "Offset mismatch for FCustomizableObjectInstanceDescriptor::IntParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, FloatParameters) == 0x28, "Offset mismatch for FCustomizableObjectInstanceDescriptor::FloatParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, TextureParameters) == 0x38, "Offset mismatch for FCustomizableObjectInstanceDescriptor::TextureParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, MeshParameters) == 0x48, "Offset mismatch for FCustomizableObjectInstanceDescriptor::MeshParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, VectorParameters) == 0x58, "Offset mismatch for FCustomizableObjectInstanceDescriptor::VectorParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, ProjectorParameters) == 0x68, "Offset mismatch for FCustomizableObjectInstanceDescriptor::ProjectorParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, TransformParameters) == 0x78, "Offset mismatch for FCustomizableObjectInstanceDescriptor::TransformParameters");
static_assert(offsetof(FCustomizableObjectInstanceDescriptor, State) == 0x88, "Offset mismatch for FCustomizableObjectInstanceDescriptor::State");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCustomizableObjectStreamedResourceData
{
    TSoftObjectPtr<UCustomizableObjectResourceDataContainer*> ContainerPath; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    UCustomizableObjectResourceDataContainer* Container; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCustomizableObjectStreamedResourceData) == 0x28, "Size mismatch for FCustomizableObjectStreamedResourceData");
static_assert(offsetof(FCustomizableObjectStreamedResourceData, ContainerPath) == 0x0, "Offset mismatch for FCustomizableObjectStreamedResourceData::ContainerPath");
static_assert(offsetof(FCustomizableObjectStreamedResourceData, Container) == 0x20, "Offset mismatch for FCustomizableObjectStreamedResourceData::Container");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FPendingReleaseMaterialsInfo
{
    TArray<UMaterialInterface*> Materials; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t TicksUntilRelease; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FPendingReleaseMaterialsInfo) == 0x18, "Size mismatch for FPendingReleaseMaterialsInfo");
static_assert(offsetof(FPendingReleaseMaterialsInfo, Materials) == 0x0, "Offset mismatch for FPendingReleaseMaterialsInfo::Materials");
static_assert(offsetof(FPendingReleaseMaterialsInfo, TicksUntilRelease) == 0x10, "Offset mismatch for FPendingReleaseMaterialsInfo::TicksUntilRelease");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FMultilayerProjectorLayer
{
};

static_assert(sizeof(FMultilayerProjectorLayer) == 0x80, "Size mismatch for FMultilayerProjectorLayer");

