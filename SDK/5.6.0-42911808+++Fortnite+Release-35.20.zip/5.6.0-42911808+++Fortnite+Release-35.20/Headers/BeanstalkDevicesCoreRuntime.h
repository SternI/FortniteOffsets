/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkDevicesCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBeanDeviceFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FVector CalculateKnockbackForce(const FBeanKnockbackForceCalculator KnockbackForceCalculator, FVector& SourceLocation, FVector& TargetLocation); // 0x12338288 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UBeanDeviceFunctionLibrary) == 0x28, "Size mismatch for UBeanDeviceFunctionLibrary");

// Size: 0x148 (Inherited: 0xe0, Single: 0x68)
class UBeanObstacleImpactComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnObstacleImpact[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bApplyDefaultKnockback; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bApplyRagdoll; // 0xd1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d2[0x6]; // 0xd2 (Size: 0x6, Type: PaddingProperty)
    TArray<FComponentReference> AffectedColliders; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    FBeanKnockbackForceCalculator KnockbackForce; // 0xe8 (Size: 0x30, Type: StructProperty)
    bool bApplyImpactLocally; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x7]; // 0x119 (Size: 0x7, Type: PaddingProperty)
    double MaxExpectedComponentVelocityForServerValidation; // 0x120 (Size: 0x8, Type: DoubleProperty)
    TArray<TWeakObjectPtr<UPrimitiveComponent*>> CachedColliders; // 0x128 (Size: 0x10, Type: ArrayProperty)
    TArray<FBeanComponentTransformDelta> CachedColliderDeltas; // 0x138 (Size: 0x10, Type: ArrayProperty)

protected:
    void OnAffectedComponentHit(UPrimitiveComponent*& HitComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, FVector& NormalImpulse, const FHitResult Hit); // 0x123384e0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|HasDefaults)
    void OnSleepStateChanged(bool& bIsSleeping); // 0x12339510 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UBeanObstacleImpactComponent) == 0x148, "Size mismatch for UBeanObstacleImpactComponent");
static_assert(offsetof(UBeanObstacleImpactComponent, OnObstacleImpact) == 0xc0, "Offset mismatch for UBeanObstacleImpactComponent::OnObstacleImpact");
static_assert(offsetof(UBeanObstacleImpactComponent, bApplyDefaultKnockback) == 0xd0, "Offset mismatch for UBeanObstacleImpactComponent::bApplyDefaultKnockback");
static_assert(offsetof(UBeanObstacleImpactComponent, bApplyRagdoll) == 0xd1, "Offset mismatch for UBeanObstacleImpactComponent::bApplyRagdoll");
static_assert(offsetof(UBeanObstacleImpactComponent, AffectedColliders) == 0xd8, "Offset mismatch for UBeanObstacleImpactComponent::AffectedColliders");
static_assert(offsetof(UBeanObstacleImpactComponent, KnockbackForce) == 0xe8, "Offset mismatch for UBeanObstacleImpactComponent::KnockbackForce");
static_assert(offsetof(UBeanObstacleImpactComponent, bApplyImpactLocally) == 0x118, "Offset mismatch for UBeanObstacleImpactComponent::bApplyImpactLocally");
static_assert(offsetof(UBeanObstacleImpactComponent, MaxExpectedComponentVelocityForServerValidation) == 0x120, "Offset mismatch for UBeanObstacleImpactComponent::MaxExpectedComponentVelocityForServerValidation");
static_assert(offsetof(UBeanObstacleImpactComponent, CachedColliders) == 0x128, "Offset mismatch for UBeanObstacleImpactComponent::CachedColliders");
static_assert(offsetof(UBeanObstacleImpactComponent, CachedColliderDeltas) == 0x138, "Offset mismatch for UBeanObstacleImpactComponent::CachedColliderDeltas");

// Size: 0x108 (Inherited: 0xe0, Single: 0x28)
class UBeanObstacleMeshSelectorComponent : public UActorComponent
{
public:
    uint8_t OnSelectedMeshSetDelegate[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FComponentReference TargetStaticMeshComponentRef; // 0xc8 (Size: 0x28, Type: StructProperty)
    TArray<FSelectableMeshData> SelectableMeshes; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    UStaticMeshComponent* TargetStaticMeshComponent; // 0x100 (Size: 0x8, Type: ObjectProperty)

public:
    bool SetSelectedMeshIndex(int32_t& MeshIndex); // 0x12339cd0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UBeanObstacleMeshSelectorComponent) == 0x108, "Size mismatch for UBeanObstacleMeshSelectorComponent");
static_assert(offsetof(UBeanObstacleMeshSelectorComponent, OnSelectedMeshSetDelegate) == 0xb8, "Offset mismatch for UBeanObstacleMeshSelectorComponent::OnSelectedMeshSetDelegate");
static_assert(offsetof(UBeanObstacleMeshSelectorComponent, TargetStaticMeshComponentRef) == 0xc8, "Offset mismatch for UBeanObstacleMeshSelectorComponent::TargetStaticMeshComponentRef");
static_assert(offsetof(UBeanObstacleMeshSelectorComponent, SelectableMeshes) == 0xf0, "Offset mismatch for UBeanObstacleMeshSelectorComponent::SelectableMeshes");
static_assert(offsetof(UBeanObstacleMeshSelectorComponent, TargetStaticMeshComponent) == 0x100, "Offset mismatch for UBeanObstacleMeshSelectorComponent::TargetStaticMeshComponent");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UBeanObstacleMotion : public UObject
{
public:
};

static_assert(sizeof(UBeanObstacleMotion) == 0x28, "Size mismatch for UBeanObstacleMotion");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UBeanObstacleMotion_Rotational : public UBeanObstacleMotion
{
public:
    TEnumAsByte<EAxis> RotationAxis; // 0x28 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float RotationSpeed; // 0x2c (Size: 0x4, Type: FloatProperty)
    float StartRotation; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBeanObstacleMotion_Rotational) == 0x38, "Size mismatch for UBeanObstacleMotion_Rotational");
static_assert(offsetof(UBeanObstacleMotion_Rotational, RotationAxis) == 0x28, "Offset mismatch for UBeanObstacleMotion_Rotational::RotationAxis");
static_assert(offsetof(UBeanObstacleMotion_Rotational, RotationSpeed) == 0x2c, "Offset mismatch for UBeanObstacleMotion_Rotational::RotationSpeed");
static_assert(offsetof(UBeanObstacleMotion_Rotational, StartRotation) == 0x30, "Offset mismatch for UBeanObstacleMotion_Rotational::StartRotation");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UBeanObstacleMotion_Punch : public UBeanObstacleMotion
{
public:
    FVector MovementVector; // 0x28 (Size: 0x18, Type: StructProperty)
    float StartDelay; // 0x40 (Size: 0x4, Type: FloatProperty)
    float MoveOutDuration; // 0x44 (Size: 0x4, Type: FloatProperty)
    float OutPauseDuration; // 0x48 (Size: 0x4, Type: FloatProperty)
    float MoveInDuration; // 0x4c (Size: 0x4, Type: FloatProperty)
    float InPauseDuration; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBeanObstacleMotion_Punch) == 0x58, "Size mismatch for UBeanObstacleMotion_Punch");
static_assert(offsetof(UBeanObstacleMotion_Punch, MovementVector) == 0x28, "Offset mismatch for UBeanObstacleMotion_Punch::MovementVector");
static_assert(offsetof(UBeanObstacleMotion_Punch, StartDelay) == 0x40, "Offset mismatch for UBeanObstacleMotion_Punch::StartDelay");
static_assert(offsetof(UBeanObstacleMotion_Punch, MoveOutDuration) == 0x44, "Offset mismatch for UBeanObstacleMotion_Punch::MoveOutDuration");
static_assert(offsetof(UBeanObstacleMotion_Punch, OutPauseDuration) == 0x48, "Offset mismatch for UBeanObstacleMotion_Punch::OutPauseDuration");
static_assert(offsetof(UBeanObstacleMotion_Punch, MoveInDuration) == 0x4c, "Offset mismatch for UBeanObstacleMotion_Punch::MoveInDuration");
static_assert(offsetof(UBeanObstacleMotion_Punch, InPauseDuration) == 0x50, "Offset mismatch for UBeanObstacleMotion_Punch::InPauseDuration");

// Size: 0x1e0 (Inherited: 0xe0, Single: 0x100)
class UBeanObstacleMovementComponent : public UActorComponent
{
public:
    uint8_t bRegisterWithBeanTickManager : 1; // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnRewindStateChangedDelegate[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t ClientOnStartedMoving[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t ClientOnStoppedMoving[0x10]; // 0xe0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FComponentReference TargetComponentRef; // 0xf0 (Size: 0x28, Type: StructProperty)
    UBeanObstacleMotion* ObstacleMotion; // 0x118 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSweep; // 0x120 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_121[0x3]; // 0x121 (Size: 0x3, Type: PaddingProperty)
    float ReconciliationInterpSpeed; // 0x124 (Size: 0x4, Type: FloatProperty)
    bool bEnableEventSleeping; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x7]; // 0x129 (Size: 0x7, Type: PaddingProperty)
    double EventSleepDistanceThreshold; // 0x130 (Size: 0x8, Type: DoubleProperty)
    double EventSleepPollInterval; // 0x138 (Size: 0x8, Type: DoubleProperty)
    FVector TargetComponentOriginalRelativeLocation; // 0x140 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
    FQuat TargetComponentOriginalRelativeRotation; // 0x160 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<USceneComponent*> TargetComponent; // 0x180 (Size: 0x8, Type: WeakObjectProperty)
    double LastEventSleepPollTime; // 0x188 (Size: 0x8, Type: DoubleProperty)
    uint8_t bLastFiredEventWasStart : 1; // 0x190:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAreEventsAsleep : 1; // 0x190:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsUsingTickManager : 1; // 0x190:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsObstacleTickSleeping : 1; // 0x190:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bStartWithMotionEnabled : 1; // 0x190:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_191[0x7]; // 0x191 (Size: 0x7, Type: PaddingProperty)
    FBeanObstacleMotionRuntimeState ObstacleMotionRuntimeState; // 0x198 (Size: 0x30, Type: StructProperty)
    double CurrentEvalTime; // 0x1c8 (Size: 0x8, Type: DoubleProperty)
    uint8_t LastObstacleMovementState; // 0x1d0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1d1[0xf]; // 0x1d1 (Size: 0xf, Type: PaddingProperty)

public:
    bool IsMotionLocked() const; // 0x123384c4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRewinding() const; // 0x113e064c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetIsMotionLocked(bool& bNewIsLocked, bool& bResetToInitial); // 0x12339988 (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetIsRewinding(bool& bNewRewind); // 0x12339ba4 (Index: 0x5, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

protected:
    void OnRep_ObstacleMotionRuntimeState(const FBeanObstacleMotionRuntimeState OldRuntimeState); // 0x1233942c (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    void OnSleepStateChanged(bool& bIsSleeping); // 0x1233963c (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UBeanObstacleMovementComponent) == 0x1e0, "Size mismatch for UBeanObstacleMovementComponent");
static_assert(offsetof(UBeanObstacleMovementComponent, bRegisterWithBeanTickManager) == 0xb8, "Offset mismatch for UBeanObstacleMovementComponent::bRegisterWithBeanTickManager");
static_assert(offsetof(UBeanObstacleMovementComponent, OnRewindStateChangedDelegate) == 0xc0, "Offset mismatch for UBeanObstacleMovementComponent::OnRewindStateChangedDelegate");
static_assert(offsetof(UBeanObstacleMovementComponent, ClientOnStartedMoving) == 0xd0, "Offset mismatch for UBeanObstacleMovementComponent::ClientOnStartedMoving");
static_assert(offsetof(UBeanObstacleMovementComponent, ClientOnStoppedMoving) == 0xe0, "Offset mismatch for UBeanObstacleMovementComponent::ClientOnStoppedMoving");
static_assert(offsetof(UBeanObstacleMovementComponent, TargetComponentRef) == 0xf0, "Offset mismatch for UBeanObstacleMovementComponent::TargetComponentRef");
static_assert(offsetof(UBeanObstacleMovementComponent, ObstacleMotion) == 0x118, "Offset mismatch for UBeanObstacleMovementComponent::ObstacleMotion");
static_assert(offsetof(UBeanObstacleMovementComponent, bShouldSweep) == 0x120, "Offset mismatch for UBeanObstacleMovementComponent::bShouldSweep");
static_assert(offsetof(UBeanObstacleMovementComponent, ReconciliationInterpSpeed) == 0x124, "Offset mismatch for UBeanObstacleMovementComponent::ReconciliationInterpSpeed");
static_assert(offsetof(UBeanObstacleMovementComponent, bEnableEventSleeping) == 0x128, "Offset mismatch for UBeanObstacleMovementComponent::bEnableEventSleeping");
static_assert(offsetof(UBeanObstacleMovementComponent, EventSleepDistanceThreshold) == 0x130, "Offset mismatch for UBeanObstacleMovementComponent::EventSleepDistanceThreshold");
static_assert(offsetof(UBeanObstacleMovementComponent, EventSleepPollInterval) == 0x138, "Offset mismatch for UBeanObstacleMovementComponent::EventSleepPollInterval");
static_assert(offsetof(UBeanObstacleMovementComponent, TargetComponentOriginalRelativeLocation) == 0x140, "Offset mismatch for UBeanObstacleMovementComponent::TargetComponentOriginalRelativeLocation");
static_assert(offsetof(UBeanObstacleMovementComponent, TargetComponentOriginalRelativeRotation) == 0x160, "Offset mismatch for UBeanObstacleMovementComponent::TargetComponentOriginalRelativeRotation");
static_assert(offsetof(UBeanObstacleMovementComponent, TargetComponent) == 0x180, "Offset mismatch for UBeanObstacleMovementComponent::TargetComponent");
static_assert(offsetof(UBeanObstacleMovementComponent, LastEventSleepPollTime) == 0x188, "Offset mismatch for UBeanObstacleMovementComponent::LastEventSleepPollTime");
static_assert(offsetof(UBeanObstacleMovementComponent, bLastFiredEventWasStart) == 0x190, "Offset mismatch for UBeanObstacleMovementComponent::bLastFiredEventWasStart");
static_assert(offsetof(UBeanObstacleMovementComponent, bAreEventsAsleep) == 0x190, "Offset mismatch for UBeanObstacleMovementComponent::bAreEventsAsleep");
static_assert(offsetof(UBeanObstacleMovementComponent, bIsUsingTickManager) == 0x190, "Offset mismatch for UBeanObstacleMovementComponent::bIsUsingTickManager");
static_assert(offsetof(UBeanObstacleMovementComponent, bIsObstacleTickSleeping) == 0x190, "Offset mismatch for UBeanObstacleMovementComponent::bIsObstacleTickSleeping");
static_assert(offsetof(UBeanObstacleMovementComponent, bStartWithMotionEnabled) == 0x190, "Offset mismatch for UBeanObstacleMovementComponent::bStartWithMotionEnabled");
static_assert(offsetof(UBeanObstacleMovementComponent, ObstacleMotionRuntimeState) == 0x198, "Offset mismatch for UBeanObstacleMovementComponent::ObstacleMotionRuntimeState");
static_assert(offsetof(UBeanObstacleMovementComponent, CurrentEvalTime) == 0x1c8, "Offset mismatch for UBeanObstacleMovementComponent::CurrentEvalTime");
static_assert(offsetof(UBeanObstacleMovementComponent, LastObstacleMovementState) == 0x1d0, "Offset mismatch for UBeanObstacleMovementComponent::LastObstacleMovementState");

// Size: 0x5e0 (Inherited: 0x12d0, Single: 0xfffff310)
class UBeanObstacleOptimizerComponent : public UBoxComponent
{
public:
    float ExtraMarginSize; // 0x550 (Size: 0x4, Type: FloatProperty)
    bool bDisableCollidersWhenSleeping; // 0x554 (Size: 0x1, Type: BoolProperty)
    bool bDetachFromParentAndAttachToOptimizerActor; // 0x555 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_556[0x2]; // 0x556 (Size: 0x2, Type: PaddingProperty)
    uint8_t OnSleepStateChanged[0x10]; // 0x558 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bIsSleeping; // 0x568 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_569[0x3]; // 0x569 (Size: 0x3, Type: PaddingProperty)
    int32_t NumPawnsOverlapping; // 0x56c (Size: 0x4, Type: IntProperty)
    TArray<TWeakObjectPtr<UPrimitiveComponent*>> OptimizableColliders; // 0x570 (Size: 0x10, Type: ArrayProperty)
    TMap<TEnumAsByte<ECollisionEnabled>, UPrimitiveComponent*> OptimizableCollidersOriginalCollisionEnabled; // 0x580 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_5d0[0x10]; // 0x5d0 (Size: 0x10, Type: PaddingProperty)

public:
    void OnSleepStateChanged__DelegateSignature(bool& bIsSleeping); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)

protected:
    void OnOptimizerBeginOverlap(UPrimitiveComponent*& OverlappedComp, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x12338908 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnOptimizerEndOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0x12338e68 (Index: 0x1, Flags: Final|Native|Protected)
    void OnOriginalOwnerEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x12339220 (Index: 0x2, Flags: Final|Native|Protected)
    void RecalculateEstimatedBounds(); // 0x12339974 (Index: 0x4, Flags: Final|Native|Protected)
};

static_assert(sizeof(UBeanObstacleOptimizerComponent) == 0x5e0, "Size mismatch for UBeanObstacleOptimizerComponent");
static_assert(offsetof(UBeanObstacleOptimizerComponent, ExtraMarginSize) == 0x550, "Offset mismatch for UBeanObstacleOptimizerComponent::ExtraMarginSize");
static_assert(offsetof(UBeanObstacleOptimizerComponent, bDisableCollidersWhenSleeping) == 0x554, "Offset mismatch for UBeanObstacleOptimizerComponent::bDisableCollidersWhenSleeping");
static_assert(offsetof(UBeanObstacleOptimizerComponent, bDetachFromParentAndAttachToOptimizerActor) == 0x555, "Offset mismatch for UBeanObstacleOptimizerComponent::bDetachFromParentAndAttachToOptimizerActor");
static_assert(offsetof(UBeanObstacleOptimizerComponent, OnSleepStateChanged) == 0x558, "Offset mismatch for UBeanObstacleOptimizerComponent::OnSleepStateChanged");
static_assert(offsetof(UBeanObstacleOptimizerComponent, bIsSleeping) == 0x568, "Offset mismatch for UBeanObstacleOptimizerComponent::bIsSleeping");
static_assert(offsetof(UBeanObstacleOptimizerComponent, NumPawnsOverlapping) == 0x56c, "Offset mismatch for UBeanObstacleOptimizerComponent::NumPawnsOverlapping");
static_assert(offsetof(UBeanObstacleOptimizerComponent, OptimizableColliders) == 0x570, "Offset mismatch for UBeanObstacleOptimizerComponent::OptimizableColliders");
static_assert(offsetof(UBeanObstacleOptimizerComponent, OptimizableCollidersOriginalCollisionEnabled) == 0x580, "Offset mismatch for UBeanObstacleOptimizerComponent::OptimizableCollidersOriginalCollisionEnabled");

// Size: 0x2c0 (Inherited: 0x2d0, Single: 0xfffffff0)
class ABeanObstacleTickManager : public AActor
{
public:

private:
    void OnTickableComponentEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x12339768 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(ABeanObstacleTickManager) == 0x2c0, "Size mismatch for ABeanObstacleTickManager");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBeanKnockbackForceCalculator
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ForceApplicationType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    double Strength; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double HorizontalStrength; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double VerticalStrength; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double Angle; // 0x20 (Size: 0x8, Type: DoubleProperty)
    bool bAddSourceColliderVelocity; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float SourceColliderVelocityMultiplier; // 0x2c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanKnockbackForceCalculator) == 0x30, "Size mismatch for FBeanKnockbackForceCalculator");
static_assert(offsetof(FBeanKnockbackForceCalculator, Type) == 0x0, "Offset mismatch for FBeanKnockbackForceCalculator::Type");
static_assert(offsetof(FBeanKnockbackForceCalculator, ForceApplicationType) == 0x1, "Offset mismatch for FBeanKnockbackForceCalculator::ForceApplicationType");
static_assert(offsetof(FBeanKnockbackForceCalculator, Strength) == 0x8, "Offset mismatch for FBeanKnockbackForceCalculator::Strength");
static_assert(offsetof(FBeanKnockbackForceCalculator, HorizontalStrength) == 0x10, "Offset mismatch for FBeanKnockbackForceCalculator::HorizontalStrength");
static_assert(offsetof(FBeanKnockbackForceCalculator, VerticalStrength) == 0x18, "Offset mismatch for FBeanKnockbackForceCalculator::VerticalStrength");
static_assert(offsetof(FBeanKnockbackForceCalculator, Angle) == 0x20, "Offset mismatch for FBeanKnockbackForceCalculator::Angle");
static_assert(offsetof(FBeanKnockbackForceCalculator, bAddSourceColliderVelocity) == 0x28, "Offset mismatch for FBeanKnockbackForceCalculator::bAddSourceColliderVelocity");
static_assert(offsetof(FBeanKnockbackForceCalculator, SourceColliderVelocityMultiplier) == 0x2c, "Offset mismatch for FBeanKnockbackForceCalculator::SourceColliderVelocityMultiplier");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FBeanComponentTransformDelta
{
};

static_assert(sizeof(FBeanComponentTransformDelta) == 0xd0, "Size mismatch for FBeanComponentTransformDelta");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSelectableMeshData
{
    TSoftObjectPtr<UStaticMesh*> Mesh; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FSelectableMeshData) == 0x20, "Size mismatch for FSelectableMeshData");
static_assert(offsetof(FSelectableMeshData, Mesh) == 0x0, "Offset mismatch for FSelectableMeshData::Mesh");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBeanObstacleMotionRuntimeState
{
    uint8_t MotionLockedState[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double MotionLockedChangedTime; // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bRewinding; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    double RewindChangedTime; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double AccumulatedTimeOffset; // 0x20 (Size: 0x8, Type: DoubleProperty)
    double LocalAccumulatedTimeOffset; // 0x28 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanObstacleMotionRuntimeState) == 0x30, "Size mismatch for FBeanObstacleMotionRuntimeState");
static_assert(offsetof(FBeanObstacleMotionRuntimeState, MotionLockedState) == 0x0, "Offset mismatch for FBeanObstacleMotionRuntimeState::MotionLockedState");
static_assert(offsetof(FBeanObstacleMotionRuntimeState, MotionLockedChangedTime) == 0x8, "Offset mismatch for FBeanObstacleMotionRuntimeState::MotionLockedChangedTime");
static_assert(offsetof(FBeanObstacleMotionRuntimeState, bRewinding) == 0x10, "Offset mismatch for FBeanObstacleMotionRuntimeState::bRewinding");
static_assert(offsetof(FBeanObstacleMotionRuntimeState, RewindChangedTime) == 0x18, "Offset mismatch for FBeanObstacleMotionRuntimeState::RewindChangedTime");
static_assert(offsetof(FBeanObstacleMotionRuntimeState, AccumulatedTimeOffset) == 0x20, "Offset mismatch for FBeanObstacleMotionRuntimeState::AccumulatedTimeOffset");
static_assert(offsetof(FBeanObstacleMotionRuntimeState, LocalAccumulatedTimeOffset) == 0x28, "Offset mismatch for FBeanObstacleMotionRuntimeState::LocalAccumulatedTimeOffset");

