/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Environments
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "UI.h"
#include "CommonUI.h"
#include "InputCore.h"
#include "GameplayTags.h"
#include "UMG.h"

// Size: 0x2c9 (Inherited: 0x2d0, Single: 0xfffffff9)
class ACameraAnimationTransition_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    AFortnitePartyBackdrop_Camera_C* CameraBR; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    AFortnitePartyBackdrop_Camera_C* CameraBR16Player; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t CameraState; // 0x2c8 (Size: 0x1, Type: EnumProperty)

public:
    void CanChangeCamera(EFrontEndCamera& FromCamera, EFrontEndCamera& ToCamera, bool& CanChangeCamera); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(ACameraAnimationTransition_C) == 0x2c9, "Size mismatch for ACameraAnimationTransition_C");
static_assert(offsetof(ACameraAnimationTransition_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ACameraAnimationTransition_C::UberGraphFrame");
static_assert(offsetof(ACameraAnimationTransition_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ACameraAnimationTransition_C::DefaultSceneRoot");
static_assert(offsetof(ACameraAnimationTransition_C, CameraBR) == 0x2b8, "Offset mismatch for ACameraAnimationTransition_C::CameraBR");
static_assert(offsetof(ACameraAnimationTransition_C, CameraBR16Player) == 0x2c0, "Offset mismatch for ACameraAnimationTransition_C::CameraBR16Player");
static_assert(offsetof(ACameraAnimationTransition_C, CameraState) == 0x2c8, "Offset mismatch for ACameraAnimationTransition_C::CameraState");

// Size: 0x334 (Inherited: 0x2d0, Single: 0x64)
class ABP_FortniteLobbyLightSwitcher_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    ADirectionalLight* DirectionLight; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    ASkyLight* SkyLight; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    TArray<APointLight*> Pointlights; // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    AExponentialHeightFog* ExponentialHeightFog; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    ADirectionalLight* DirectionalLight_LowDetailMode; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TArray<AEmitter*> ParticleSystems; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    bool IsActive; // 0x2f8 (Size: 0x1, Type: BoolProperty)
    bool DebugLOWQualityLighting; // 0x2f9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2fa[0x6]; // 0x2fa (Size: 0x6, Type: PaddingProperty)
    ASkyLight* SkyLight_LowDetailMode; // 0x300 (Size: 0x8, Type: ObjectProperty)
    AExponentialHeightFog* ExponentialHeightfog_LowDetailMode; // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool LOW_FX_Setting_Use_MobileLighting; // 0x310 (Size: 0x1, Type: BoolProperty)
    bool IsLightalreadyActive; // 0x311 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_312[0x2]; // 0x312 (Size: 0x2, Type: PaddingProperty)
    FLinearColor MPC_ManualSunlightVector; // 0x314 (Size: 0x10, Type: StructProperty)
    FLinearColor MPC_ManualSunlightColor; // 0x324 (Size: 0x10, Type: StructProperty)

public:
    void SetVisiblityofDetailSpecificMeshes(); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void SetVisiblityofSceneLighting(bool& Activate); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_FortniteLobbyLightSwitcher_C) == 0x334, "Size mismatch for ABP_FortniteLobbyLightSwitcher_C");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::UberGraphFrame");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::DefaultSceneRoot");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, DirectionLight) == 0x2b8, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::DirectionLight");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, SkyLight) == 0x2c0, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::SkyLight");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, Pointlights) == 0x2c8, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::Pointlights");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, ExponentialHeightFog) == 0x2d8, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::ExponentialHeightFog");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, DirectionalLight_LowDetailMode) == 0x2e0, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::DirectionalLight_LowDetailMode");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, ParticleSystems) == 0x2e8, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::ParticleSystems");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, IsActive) == 0x2f8, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::IsActive");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, DebugLOWQualityLighting) == 0x2f9, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::DebugLOWQualityLighting");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, SkyLight_LowDetailMode) == 0x300, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::SkyLight_LowDetailMode");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, ExponentialHeightfog_LowDetailMode) == 0x308, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::ExponentialHeightfog_LowDetailMode");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, LOW_FX_Setting_Use_MobileLighting) == 0x310, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::LOW_FX_Setting_Use_MobileLighting");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, IsLightalreadyActive) == 0x311, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::IsLightalreadyActive");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, MPC_ManualSunlightVector) == 0x314, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::MPC_ManualSunlightVector");
static_assert(offsetof(ABP_FortniteLobbyLightSwitcher_C, MPC_ManualSunlightColor) == 0x324, "Offset mismatch for ABP_FortniteLobbyLightSwitcher_C::MPC_ManualSunlightColor");

// Size: 0x610 (Inherited: 0xb78, Single: 0xfffffa98)
class AVaultRotator_C : public AItemPreviewRotator
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x458 (Size: 0x8, Type: StructProperty)
    UDirectionalLightComponent* DirectionalLightMobile; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLight_LOWPC; // 0x468 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DirectionalLights; // 0x470 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightLowMobile; // 0x478 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLight; // 0x480 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLight_LOWPC; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x490 (Size: 0x8, Type: ObjectProperty)
    UPostProcessComponent* PostProcess_Mobile; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UPostProcessComponent* PostProcess_LOWPC; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* GenericLighting; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    float Timeline_YawRotation_YawInterpAlpha_F13714DD4AFE0C9C8857E2950BEC127B; // 0x4b0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_YawRotation__Direction_F13714DD4AFE0C9C8857E2950BEC127B; // 0x4b4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4b5[0x3]; // 0x4b5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_YawRotation; // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    float Timeline_Zoom_ZoomLevel_6FFD6729471BD965D850258DA1C0AF39; // 0x4c0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_Zoom__Direction_6FFD6729471BD965D850258DA1C0AF39; // 0x4c4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4c5[0x3]; // 0x4c5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_Zoom; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    FVector CameraTurn_180_to_360_CameraRotationOffset_DF51680448A0BDB5D459C9BB5786D714; // 0x4d0 (Size: 0x18, Type: StructProperty)
    FVector CameraTurn_180_to_360_CameraPositionOffset_DF51680448A0BDB5D459C9BB5786D714; // 0x4e8 (Size: 0x18, Type: StructProperty)
    float CameraTurn_180_to_360_DirectionRotation_DF51680448A0BDB5D459C9BB5786D714; // 0x500 (Size: 0x4, Type: FloatProperty)
    float CameraTurn_180_to_360_FoV_DF51680448A0BDB5D459C9BB5786D714; // 0x504 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CameraTurn_180_to_360__Direction_DF51680448A0BDB5D459C9BB5786D714; // 0x508 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_509[0x7]; // 0x509 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* CameraTurn_180_to_360; // 0x510 (Size: 0x8, Type: ObjectProperty)
    FVector CameraTurn_0_to_180_CameraRotationOffset_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0; // 0x518 (Size: 0x18, Type: StructProperty)
    FVector CameraTurn_0_to_180_CameraPositionOffset_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0; // 0x530 (Size: 0x18, Type: StructProperty)
    float CameraTurn_0_to_180_DirectionalRotation_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0; // 0x548 (Size: 0x4, Type: FloatProperty)
    float CameraTurn_0_to_180_FoV_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0; // 0x54c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CameraTurn_0_to_180__Direction_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0; // 0x550 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_551[0x7]; // 0x551 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* CameraTurn_0_to_180; // 0x558 (Size: 0x8, Type: ObjectProperty)
    FTransform InitialCameraTransform; // 0x560 (Size: 0x60, Type: StructProperty)
    USoundBase* ClockwiseSound; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* CounterClockwiseSound; // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    bool DebugMobile_Lighting; // 0x5d0 (Size: 0x1, Type: BoolProperty)
    bool DebugLightingPC; // 0x5d1 (Size: 0x1, Type: BoolProperty)
    bool IsActive; // 0x5d2 (Size: 0x1, Type: BoolProperty)
    bool AlwaysOn; // 0x5d3 (Size: 0x1, Type: BoolProperty)
    bool DebugLighting_LOWDetailPC; // 0x5d4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5d5[0x3]; // 0x5d5 (Size: 0x3, Type: PaddingProperty)
    double TargetZoomLevel; // 0x5d8 (Size: 0x8, Type: DoubleProperty)
    FRotator StartingRotationOffset; // 0x5e0 (Size: 0x18, Type: StructProperty)
    FRotator TargetRotationOffset; // 0x5f8 (Size: 0x18, Type: StructProperty)

public:
    void ToggleBackgroundText(bool& bDisplayText); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting_LOWDetail(bool& Visibility); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting(bool& Visibility); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchMobileLighting(bool& Visibility); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetBackgroundString(FText& CustomText); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetBackgroundColor(FLinearColor& RGBA0, FLinearColor& RGBA1); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PlaySoundWhenEnabled(USoundBase*& Sound); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void LightControl(bool& Active); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateBackgroundColor(bool& bEnableAutotestBackground); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTargetZoomLevelSet(float& TargetZoomLevel); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetBackgroundMessageText(const FText BackgroundMessageText); // 0x288a61c (Index: 0xe, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnCameraTransitionReady(bool& bPrimaryToSecondary, UFortAccountItemDefinition*& const PrimaryRequestedItem, const FSceneTransitionOptions Options); // 0x288a61c (Index: 0xf, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTargetRotationOffsetSet(const FRotator TargetRotationOffset); // 0x288a61c (Index: 0x15, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTargetRotationOffsetCanceled(); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTargetZoomLevelCanceled(); // 0x288a61c (Index: 0x19, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AVaultRotator_C) == 0x610, "Size mismatch for AVaultRotator_C");
static_assert(offsetof(AVaultRotator_C, UberGraphFrame) == 0x458, "Offset mismatch for AVaultRotator_C::UberGraphFrame");
static_assert(offsetof(AVaultRotator_C, DirectionalLightMobile) == 0x460, "Offset mismatch for AVaultRotator_C::DirectionalLightMobile");
static_assert(offsetof(AVaultRotator_C, DirectionalLight_LOWPC) == 0x468, "Offset mismatch for AVaultRotator_C::DirectionalLight_LOWPC");
static_assert(offsetof(AVaultRotator_C, DirectionalLights) == 0x470, "Offset mismatch for AVaultRotator_C::DirectionalLights");
static_assert(offsetof(AVaultRotator_C, SkyLightLowMobile) == 0x478, "Offset mismatch for AVaultRotator_C::SkyLightLowMobile");
static_assert(offsetof(AVaultRotator_C, SkyLight) == 0x480, "Offset mismatch for AVaultRotator_C::SkyLight");
static_assert(offsetof(AVaultRotator_C, SkyLight_LOWPC) == 0x488, "Offset mismatch for AVaultRotator_C::SkyLight_LOWPC");
static_assert(offsetof(AVaultRotator_C, Arrow) == 0x490, "Offset mismatch for AVaultRotator_C::Arrow");
static_assert(offsetof(AVaultRotator_C, PostProcess_Mobile) == 0x498, "Offset mismatch for AVaultRotator_C::PostProcess_Mobile");
static_assert(offsetof(AVaultRotator_C, PostProcess_LOWPC) == 0x4a0, "Offset mismatch for AVaultRotator_C::PostProcess_LOWPC");
static_assert(offsetof(AVaultRotator_C, GenericLighting) == 0x4a8, "Offset mismatch for AVaultRotator_C::GenericLighting");
static_assert(offsetof(AVaultRotator_C, Timeline_YawRotation_YawInterpAlpha_F13714DD4AFE0C9C8857E2950BEC127B) == 0x4b0, "Offset mismatch for AVaultRotator_C::Timeline_YawRotation_YawInterpAlpha_F13714DD4AFE0C9C8857E2950BEC127B");
static_assert(offsetof(AVaultRotator_C, Timeline_YawRotation__Direction_F13714DD4AFE0C9C8857E2950BEC127B) == 0x4b4, "Offset mismatch for AVaultRotator_C::Timeline_YawRotation__Direction_F13714DD4AFE0C9C8857E2950BEC127B");
static_assert(offsetof(AVaultRotator_C, Timeline_YawRotation) == 0x4b8, "Offset mismatch for AVaultRotator_C::Timeline_YawRotation");
static_assert(offsetof(AVaultRotator_C, Timeline_Zoom_ZoomLevel_6FFD6729471BD965D850258DA1C0AF39) == 0x4c0, "Offset mismatch for AVaultRotator_C::Timeline_Zoom_ZoomLevel_6FFD6729471BD965D850258DA1C0AF39");
static_assert(offsetof(AVaultRotator_C, Timeline_Zoom__Direction_6FFD6729471BD965D850258DA1C0AF39) == 0x4c4, "Offset mismatch for AVaultRotator_C::Timeline_Zoom__Direction_6FFD6729471BD965D850258DA1C0AF39");
static_assert(offsetof(AVaultRotator_C, Timeline_Zoom) == 0x4c8, "Offset mismatch for AVaultRotator_C::Timeline_Zoom");
static_assert(offsetof(AVaultRotator_C, CameraTurn_180_to_360_CameraRotationOffset_DF51680448A0BDB5D459C9BB5786D714) == 0x4d0, "Offset mismatch for AVaultRotator_C::CameraTurn_180_to_360_CameraRotationOffset_DF51680448A0BDB5D459C9BB5786D714");
static_assert(offsetof(AVaultRotator_C, CameraTurn_180_to_360_CameraPositionOffset_DF51680448A0BDB5D459C9BB5786D714) == 0x4e8, "Offset mismatch for AVaultRotator_C::CameraTurn_180_to_360_CameraPositionOffset_DF51680448A0BDB5D459C9BB5786D714");
static_assert(offsetof(AVaultRotator_C, CameraTurn_180_to_360_DirectionRotation_DF51680448A0BDB5D459C9BB5786D714) == 0x500, "Offset mismatch for AVaultRotator_C::CameraTurn_180_to_360_DirectionRotation_DF51680448A0BDB5D459C9BB5786D714");
static_assert(offsetof(AVaultRotator_C, CameraTurn_180_to_360_FoV_DF51680448A0BDB5D459C9BB5786D714) == 0x504, "Offset mismatch for AVaultRotator_C::CameraTurn_180_to_360_FoV_DF51680448A0BDB5D459C9BB5786D714");
static_assert(offsetof(AVaultRotator_C, CameraTurn_180_to_360__Direction_DF51680448A0BDB5D459C9BB5786D714) == 0x508, "Offset mismatch for AVaultRotator_C::CameraTurn_180_to_360__Direction_DF51680448A0BDB5D459C9BB5786D714");
static_assert(offsetof(AVaultRotator_C, CameraTurn_180_to_360) == 0x510, "Offset mismatch for AVaultRotator_C::CameraTurn_180_to_360");
static_assert(offsetof(AVaultRotator_C, CameraTurn_0_to_180_CameraRotationOffset_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0) == 0x518, "Offset mismatch for AVaultRotator_C::CameraTurn_0_to_180_CameraRotationOffset_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0");
static_assert(offsetof(AVaultRotator_C, CameraTurn_0_to_180_CameraPositionOffset_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0) == 0x530, "Offset mismatch for AVaultRotator_C::CameraTurn_0_to_180_CameraPositionOffset_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0");
static_assert(offsetof(AVaultRotator_C, CameraTurn_0_to_180_DirectionalRotation_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0) == 0x548, "Offset mismatch for AVaultRotator_C::CameraTurn_0_to_180_DirectionalRotation_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0");
static_assert(offsetof(AVaultRotator_C, CameraTurn_0_to_180_FoV_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0) == 0x54c, "Offset mismatch for AVaultRotator_C::CameraTurn_0_to_180_FoV_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0");
static_assert(offsetof(AVaultRotator_C, CameraTurn_0_to_180__Direction_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0) == 0x550, "Offset mismatch for AVaultRotator_C::CameraTurn_0_to_180__Direction_EEFFCB9D4EE2DC181BC00CBD7C0E7EF0");
static_assert(offsetof(AVaultRotator_C, CameraTurn_0_to_180) == 0x558, "Offset mismatch for AVaultRotator_C::CameraTurn_0_to_180");
static_assert(offsetof(AVaultRotator_C, InitialCameraTransform) == 0x560, "Offset mismatch for AVaultRotator_C::InitialCameraTransform");
static_assert(offsetof(AVaultRotator_C, ClockwiseSound) == 0x5c0, "Offset mismatch for AVaultRotator_C::ClockwiseSound");
static_assert(offsetof(AVaultRotator_C, CounterClockwiseSound) == 0x5c8, "Offset mismatch for AVaultRotator_C::CounterClockwiseSound");
static_assert(offsetof(AVaultRotator_C, DebugMobile_Lighting) == 0x5d0, "Offset mismatch for AVaultRotator_C::DebugMobile_Lighting");
static_assert(offsetof(AVaultRotator_C, DebugLightingPC) == 0x5d1, "Offset mismatch for AVaultRotator_C::DebugLightingPC");
static_assert(offsetof(AVaultRotator_C, IsActive) == 0x5d2, "Offset mismatch for AVaultRotator_C::IsActive");
static_assert(offsetof(AVaultRotator_C, AlwaysOn) == 0x5d3, "Offset mismatch for AVaultRotator_C::AlwaysOn");
static_assert(offsetof(AVaultRotator_C, DebugLighting_LOWDetailPC) == 0x5d4, "Offset mismatch for AVaultRotator_C::DebugLighting_LOWDetailPC");
static_assert(offsetof(AVaultRotator_C, TargetZoomLevel) == 0x5d8, "Offset mismatch for AVaultRotator_C::TargetZoomLevel");
static_assert(offsetof(AVaultRotator_C, StartingRotationOffset) == 0x5e0, "Offset mismatch for AVaultRotator_C::StartingRotationOffset");
static_assert(offsetof(AVaultRotator_C, TargetRotationOffset) == 0x5f8, "Offset mismatch for AVaultRotator_C::TargetRotationOffset");

// Size: 0x3a8 (Inherited: 0x678, Single: 0xfffffd30)
class AVaultSceneSinglePedestal_C : public AItemPreviewScene
{
public:
};

static_assert(sizeof(AVaultSceneSinglePedestal_C) == 0x3a8, "Size mismatch for AVaultSceneSinglePedestal_C");

// Size: 0x728 (Inherited: 0x1388, Single: 0xfffff3a0)
class AWrapPreview_C : public AAthenaWrapPreviewActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x660 (Size: 0x8, Type: StructProperty)
    USkyLightComponent* SkyLightPC; // 0x668 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* AssaultRiflePreview; // 0x670 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* MechPreview; // 0x678 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightLowMobile; // 0x680 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x688 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLightMobile; // 0x690 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight_StandaloneForSwitch; // 0x698 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLigh4; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight7; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight8; // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight3; // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimLowerRight2; // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimLeft2; // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* Bounce2; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* BounceRear2; // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimTopRight2; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimBottomLeft2; // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* LightingPivot; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Plane; // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    bool bLightsScaledForVehicle; // 0x700 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_701[0x7]; // 0x701 (Size: 0x7, Type: PaddingProperty)
    double DeltaScale; // 0x708 (Size: 0x8, Type: DoubleProperty)
    bool IsActive; // 0x710 (Size: 0x1, Type: BoolProperty)
    bool AlwaysOn; // 0x711 (Size: 0x1, Type: BoolProperty)
    bool FloorEverAllowed; // 0x712 (Size: 0x1, Type: BoolProperty)
    bool debugConstructionLighting; // 0x713 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_714[0x4]; // 0x714 (Size: 0x4, Type: PaddingProperty)
    FStateTransitionPauseRequestHandle ItemsPendingTransitionOutHandle; // 0x718 (Size: 0x10, Type: StructProperty)

public:
    void SwitchErebusLighting(bool& Visibility); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateFloorVisibility(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting(bool& Visibility); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchMobileLighting(bool& NewParam); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnSetFloorMaterial(UMaterialInterface*& InMaterialInstance); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    void SetFloorEnabled(bool& Floor_Enabled); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void LightControl(bool& Active); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateLightingScale(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleLightingScale(); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnItemsPendingTransitionOut(const FStateTransitionControllerHandle TransitionController); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnPreviewVisualsSpawned(bool& const bUseSecondaryTransitionEffects, bool& const bShowFloor); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateFloorMaterial(bool& bEnableAutotestBackground); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AWrapPreview_C) == 0x728, "Size mismatch for AWrapPreview_C");
static_assert(offsetof(AWrapPreview_C, UberGraphFrame) == 0x660, "Offset mismatch for AWrapPreview_C::UberGraphFrame");
static_assert(offsetof(AWrapPreview_C, SkyLightPC) == 0x668, "Offset mismatch for AWrapPreview_C::SkyLightPC");
static_assert(offsetof(AWrapPreview_C, AssaultRiflePreview) == 0x670, "Offset mismatch for AWrapPreview_C::AssaultRiflePreview");
static_assert(offsetof(AWrapPreview_C, MechPreview) == 0x678, "Offset mismatch for AWrapPreview_C::MechPreview");
static_assert(offsetof(AWrapPreview_C, SkyLightLowMobile) == 0x680, "Offset mismatch for AWrapPreview_C::SkyLightLowMobile");
static_assert(offsetof(AWrapPreview_C, Arrow) == 0x688, "Offset mismatch for AWrapPreview_C::Arrow");
static_assert(offsetof(AWrapPreview_C, DirectionalLightMobile) == 0x690, "Offset mismatch for AWrapPreview_C::DirectionalLightMobile");
static_assert(offsetof(AWrapPreview_C, KeyLight_StandaloneForSwitch) == 0x698, "Offset mismatch for AWrapPreview_C::KeyLight_StandaloneForSwitch");
static_assert(offsetof(AWrapPreview_C, KeyLigh4) == 0x6a0, "Offset mismatch for AWrapPreview_C::KeyLigh4");
static_assert(offsetof(AWrapPreview_C, KeyLight7) == 0x6a8, "Offset mismatch for AWrapPreview_C::KeyLight7");
static_assert(offsetof(AWrapPreview_C, KeyLight8) == 0x6b0, "Offset mismatch for AWrapPreview_C::KeyLight8");
static_assert(offsetof(AWrapPreview_C, KeyLight3) == 0x6b8, "Offset mismatch for AWrapPreview_C::KeyLight3");
static_assert(offsetof(AWrapPreview_C, RimLowerRight2) == 0x6c0, "Offset mismatch for AWrapPreview_C::RimLowerRight2");
static_assert(offsetof(AWrapPreview_C, RimLeft2) == 0x6c8, "Offset mismatch for AWrapPreview_C::RimLeft2");
static_assert(offsetof(AWrapPreview_C, Bounce2) == 0x6d0, "Offset mismatch for AWrapPreview_C::Bounce2");
static_assert(offsetof(AWrapPreview_C, BounceRear2) == 0x6d8, "Offset mismatch for AWrapPreview_C::BounceRear2");
static_assert(offsetof(AWrapPreview_C, RimTopRight2) == 0x6e0, "Offset mismatch for AWrapPreview_C::RimTopRight2");
static_assert(offsetof(AWrapPreview_C, RimBottomLeft2) == 0x6e8, "Offset mismatch for AWrapPreview_C::RimBottomLeft2");
static_assert(offsetof(AWrapPreview_C, LightingPivot) == 0x6f0, "Offset mismatch for AWrapPreview_C::LightingPivot");
static_assert(offsetof(AWrapPreview_C, Plane) == 0x6f8, "Offset mismatch for AWrapPreview_C::Plane");
static_assert(offsetof(AWrapPreview_C, bLightsScaledForVehicle) == 0x700, "Offset mismatch for AWrapPreview_C::bLightsScaledForVehicle");
static_assert(offsetof(AWrapPreview_C, DeltaScale) == 0x708, "Offset mismatch for AWrapPreview_C::DeltaScale");
static_assert(offsetof(AWrapPreview_C, IsActive) == 0x710, "Offset mismatch for AWrapPreview_C::IsActive");
static_assert(offsetof(AWrapPreview_C, AlwaysOn) == 0x711, "Offset mismatch for AWrapPreview_C::AlwaysOn");
static_assert(offsetof(AWrapPreview_C, FloorEverAllowed) == 0x712, "Offset mismatch for AWrapPreview_C::FloorEverAllowed");
static_assert(offsetof(AWrapPreview_C, debugConstructionLighting) == 0x713, "Offset mismatch for AWrapPreview_C::debugConstructionLighting");
static_assert(offsetof(AWrapPreview_C, ItemsPendingTransitionOutHandle) == 0x718, "Offset mismatch for AWrapPreview_C::ItemsPendingTransitionOutHandle");

// Size: 0x5a1 (Inherited: 0x868, Single: 0xfffffd39)
class AItemPreviewPedestal_C : public AFortCameraTargetPedestal
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x598 (Size: 0x8, Type: StructProperty)
    bool Floor_Enabled; // 0x5a0 (Size: 0x1, Type: BoolProperty)

public:
    void Remove_Floor(AFortItemPreviewActor*& Preview); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnItemDisplayed(EFortItemType& ItemType); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AItemPreviewPedestal_C) == 0x5a1, "Size mismatch for AItemPreviewPedestal_C");
static_assert(offsetof(AItemPreviewPedestal_C, UberGraphFrame) == 0x598, "Offset mismatch for AItemPreviewPedestal_C::UberGraphFrame");
static_assert(offsetof(AItemPreviewPedestal_C, Floor_Enabled) == 0x5a0, "Offset mismatch for AItemPreviewPedestal_C::Floor_Enabled");

// Size: 0x408 (Inherited: 0x9c1, Single: 0xfffffa47)
class ASpecialEventVaultWorld_C : public AVaultWorld_C
{
public:
    uint8_t Pad_381[0x7]; // 0x381 (Size: 0x7, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x388 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* floor; // 0x390 (Size: 0x8, Type: ObjectProperty)
    float ItemDetails_X_Offset_1EDCEF5F41216A9DADD25897C8B68493; // 0x398 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ItemDetails__Direction_1EDCEF5F41216A9DADD25897C8B68493; // 0x39c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39d[0x3]; // 0x39d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ItemDetails; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    float Floor_Visibility_FloorMask_37382717410D795E9E7E0990FC3EFCC2; // 0x3a8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Floor_Visibility__Direction_37382717410D795E9E7E0990FC3EFCC2; // 0x3ac (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3ad[0x3]; // 0x3ad (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Floor_Visibility; // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    float Background_Effects_SetStreaks_7B5688E44724D9F68D3C20A520093829; // 0x3b8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Background_Effects__Direction_7B5688E44724D9F68D3C20A520093829; // 0x3bc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3bd[0x3]; // 0x3bd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Background_Effects; // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    float TransitionForward_FX_Transition_Fade_FDB9DC244ED5578954F07A87EDA84CA5; // 0x3c8 (Size: 0x4, Type: FloatProperty)
    float TransitionForward_Pre_TransitionOffset_FDB9DC244ED5578954F07A87EDA84CA5; // 0x3cc (Size: 0x4, Type: FloatProperty)
    float TransitionForward_Forward_FDB9DC244ED5578954F07A87EDA84CA5; // 0x3d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TransitionForward__Direction_FDB9DC244ED5578954F07A87EDA84CA5; // 0x3d4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3d5[0x3]; // 0x3d5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TransitionForward; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    float TransitionBackward_fx_Transition_fade_9CCDE9524354AF859735079DD2ED12AA; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    float TransitionBackward_Pre_Transition_Offset_9CCDE9524354AF859735079DD2ED12AA; // 0x3e4 (Size: 0x4, Type: FloatProperty)
    float TransitionBackward_Backward_9CCDE9524354AF859735079DD2ED12AA; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TransitionBackward__Direction_9CCDE9524354AF859735079DD2ED12AA; // 0x3ec (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3ed[0x3]; // 0x3ed (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TransitionBackward; // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* FloorMI; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* FloorMID; // 0x400 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void TransitionBackgroundForward(double& Forward, double& PreTransitionOffset, double& FXTransitionFade, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TransitionBackgroundBackward(double& Backward, double& PreTransitionOffset, double& FXTransitionFade, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetupBackgroundMaterial(UTexture2D* TextureBackground, FVaultWorldBackgroundData BackgroundInfo, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateMaterialIndex(int32_t& MaterialIndex); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateDisplay(bool& bShowFloor, bool& bShowEffects, EFortItemType& ItemType); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionItemDetails(bool& const bShowItemDetails); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionBackground(EVaultWorldTransitionDirection& TransitionDirection, EBackgroundIntensityLevel& IntensityTransition); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ASpecialEventVaultWorld_C) == 0x408, "Size mismatch for ASpecialEventVaultWorld_C");
static_assert(offsetof(ASpecialEventVaultWorld_C, UberGraphFrame) == 0x388, "Offset mismatch for ASpecialEventVaultWorld_C::UberGraphFrame");
static_assert(offsetof(ASpecialEventVaultWorld_C, floor) == 0x390, "Offset mismatch for ASpecialEventVaultWorld_C::floor");
static_assert(offsetof(ASpecialEventVaultWorld_C, ItemDetails_X_Offset_1EDCEF5F41216A9DADD25897C8B68493) == 0x398, "Offset mismatch for ASpecialEventVaultWorld_C::ItemDetails_X_Offset_1EDCEF5F41216A9DADD25897C8B68493");
static_assert(offsetof(ASpecialEventVaultWorld_C, ItemDetails__Direction_1EDCEF5F41216A9DADD25897C8B68493) == 0x39c, "Offset mismatch for ASpecialEventVaultWorld_C::ItemDetails__Direction_1EDCEF5F41216A9DADD25897C8B68493");
static_assert(offsetof(ASpecialEventVaultWorld_C, ItemDetails) == 0x3a0, "Offset mismatch for ASpecialEventVaultWorld_C::ItemDetails");
static_assert(offsetof(ASpecialEventVaultWorld_C, Floor_Visibility_FloorMask_37382717410D795E9E7E0990FC3EFCC2) == 0x3a8, "Offset mismatch for ASpecialEventVaultWorld_C::Floor_Visibility_FloorMask_37382717410D795E9E7E0990FC3EFCC2");
static_assert(offsetof(ASpecialEventVaultWorld_C, Floor_Visibility__Direction_37382717410D795E9E7E0990FC3EFCC2) == 0x3ac, "Offset mismatch for ASpecialEventVaultWorld_C::Floor_Visibility__Direction_37382717410D795E9E7E0990FC3EFCC2");
static_assert(offsetof(ASpecialEventVaultWorld_C, Floor_Visibility) == 0x3b0, "Offset mismatch for ASpecialEventVaultWorld_C::Floor_Visibility");
static_assert(offsetof(ASpecialEventVaultWorld_C, Background_Effects_SetStreaks_7B5688E44724D9F68D3C20A520093829) == 0x3b8, "Offset mismatch for ASpecialEventVaultWorld_C::Background_Effects_SetStreaks_7B5688E44724D9F68D3C20A520093829");
static_assert(offsetof(ASpecialEventVaultWorld_C, Background_Effects__Direction_7B5688E44724D9F68D3C20A520093829) == 0x3bc, "Offset mismatch for ASpecialEventVaultWorld_C::Background_Effects__Direction_7B5688E44724D9F68D3C20A520093829");
static_assert(offsetof(ASpecialEventVaultWorld_C, Background_Effects) == 0x3c0, "Offset mismatch for ASpecialEventVaultWorld_C::Background_Effects");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionForward_FX_Transition_Fade_FDB9DC244ED5578954F07A87EDA84CA5) == 0x3c8, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionForward_FX_Transition_Fade_FDB9DC244ED5578954F07A87EDA84CA5");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionForward_Pre_TransitionOffset_FDB9DC244ED5578954F07A87EDA84CA5) == 0x3cc, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionForward_Pre_TransitionOffset_FDB9DC244ED5578954F07A87EDA84CA5");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionForward_Forward_FDB9DC244ED5578954F07A87EDA84CA5) == 0x3d0, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionForward_Forward_FDB9DC244ED5578954F07A87EDA84CA5");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionForward__Direction_FDB9DC244ED5578954F07A87EDA84CA5) == 0x3d4, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionForward__Direction_FDB9DC244ED5578954F07A87EDA84CA5");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionForward) == 0x3d8, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionForward");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionBackward_fx_Transition_fade_9CCDE9524354AF859735079DD2ED12AA) == 0x3e0, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionBackward_fx_Transition_fade_9CCDE9524354AF859735079DD2ED12AA");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionBackward_Pre_Transition_Offset_9CCDE9524354AF859735079DD2ED12AA) == 0x3e4, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionBackward_Pre_Transition_Offset_9CCDE9524354AF859735079DD2ED12AA");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionBackward_Backward_9CCDE9524354AF859735079DD2ED12AA) == 0x3e8, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionBackward_Backward_9CCDE9524354AF859735079DD2ED12AA");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionBackward__Direction_9CCDE9524354AF859735079DD2ED12AA) == 0x3ec, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionBackward__Direction_9CCDE9524354AF859735079DD2ED12AA");
static_assert(offsetof(ASpecialEventVaultWorld_C, TransitionBackward) == 0x3f0, "Offset mismatch for ASpecialEventVaultWorld_C::TransitionBackward");
static_assert(offsetof(ASpecialEventVaultWorld_C, FloorMI) == 0x3f8, "Offset mismatch for ASpecialEventVaultWorld_C::FloorMI");
static_assert(offsetof(ASpecialEventVaultWorld_C, FloorMID) == 0x400, "Offset mismatch for ASpecialEventVaultWorld_C::FloorMID");

// Size: 0x9b0 (Inherited: 0x1578, Single: 0xfffff438)
class AItemOnPawnPreview_C : public AFortItemPreviewOnPawnActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x850 (Size: 0x8, Type: StructProperty)
    UArrowComponent* Temp_IASDerezAbsorbPoint; // 0x858 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow1; // 0x860 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* Directional_Light_For_Atmosphere_PC; // 0x868 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightPC; // 0x870 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x878 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightLowMobile; // 0x880 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLightMobile; // 0x888 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight_StandaloneForSwitch; // 0x890 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight5; // 0x898 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight6; // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLigh3; // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight2; // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* BounceRear1; // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimLowerRight1; // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimLeft1; // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimTopRight1; // 0x8d0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimBottomLeft1; // 0x8d8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* Bounce1; // 0x8e0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* LightTransform; // 0x8e8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Plane; // 0x8f0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Sample_Mesh; // 0x8f8 (Size: 0x8, Type: ObjectProperty)
    float RezInMaterialEffectTimeLine2_NewTrack_0_FBE08AE14EC4BA399756F0BBFA6ABC31; // 0x900 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> RezInMaterialEffectTimeLine2__Direction_FBE08AE14EC4BA399756F0BBFA6ABC31; // 0x904 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_905[0x3]; // 0x905 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* RezInMaterialEffectTimeLine2; // 0x908 (Size: 0x8, Type: ObjectProperty)
    float RezInMaterialEffectTimeLine_NewTrack_0_963A663B4B1DFB2954D581893C8ACFD8; // 0x910 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> RezInMaterialEffectTimeLine__Direction_963A663B4B1DFB2954D581893C8ACFD8; // 0x914 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_915[0x3]; // 0x915 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* RezInMaterialEffectTimeLine; // 0x918 (Size: 0x8, Type: ObjectProperty)
    bool AlwaysOn; // 0x920 (Size: 0x1, Type: BoolProperty)
    bool IsActive; // 0x921 (Size: 0x1, Type: BoolProperty)
    bool debugConstructionLighting; // 0x922 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_923[0x5]; // 0x923 (Size: 0x5, Type: PaddingProperty)
    UParticleSystemComponent* ObscuringLoopEmitter; // 0x928 (Size: 0x8, Type: ObjectProperty)
    FRotator ToonLightRotatio; // 0x930 (Size: 0x18, Type: StructProperty)
    bool bIsBattlePassReward; // 0x948 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_949[0x7]; // 0x949 (Size: 0x7, Type: PaddingProperty)
    FTimerHandle LOD_StreamingSafetyTimer; // 0x950 (Size: 0x8, Type: StructProperty)
    UMaterialInterface* DefaultFloorMaterial; // 0x958 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* CustomFloorMaterial; // 0x960 (Size: 0x8, Type: ObjectProperty)
    FStateTransitionPauseRequestHandle ItemsPendingTransitionOutHandle; // 0x968 (Size: 0x10, Type: StructProperty)
    UFXSystemComponent* IASLoadingFX_LoopFX; // 0x978 (Size: 0x8, Type: ObjectProperty)
    bool Use_Secondary_Transition_Effects; // 0x980 (Size: 0x1, Type: BoolProperty)
    bool Show_Floor; // 0x981 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_982[0x6]; // 0x982 (Size: 0x6, Type: PaddingProperty)
    FTimerHandle IASLoadingDelayTimer; // 0x988 (Size: 0x8, Type: StructProperty)
    FTimerHandle IASLoadingFXDestroyDelayTimer; // 0x990 (Size: 0x8, Type: StructProperty)
    FTimerHandle IASResInDelayTimer; // 0x998 (Size: 0x8, Type: StructProperty)
    TArray<FGuid> PawnMaterialOverrideGuids; // 0x9a0 (Size: 0x10, Type: ArrayProperty)

public:
    virtual void OnSetFloorMaterial(UMaterialInterface*& InMaterialInstance); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurrentVisualsCleanedUp(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    void LightControl(bool& Active); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetupLighting(); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnPreviewVisualsBeginLoading(); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    void SpawnLoadingEffects(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting(bool& Visibility); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OutroAndDestroyLoadingEffects(); // 0x288a61c (Index: 0x10, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SwitchMobileLighting(bool& NewParam); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchErebusLighting(bool& Visibility); // 0x288a61c (Index: 0x13, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetFloorEnabled(bool& Show_Floor); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsSkyDiveContrailItem(bool& bSuccess); // 0x288a61c (Index: 0x15, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void HandleLightingSettingsChanged(); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnAllLODStreamingComplete(); // 0x288a61c (Index: 0x18, Flags: Event|Public|BlueprintEvent)
    void Get_LOD_Streaming_Safety_Duration(); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void SpawnResInEffects(); // 0x288a61c (Index: 0x1b, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void DestroyLoadingEffects(); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnPreviewVisualsSpawned(bool& const bUseSecondaryTransitionEffects, bool& const bShowFloor); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnItemsPendingTransitionOut(const FStateTransitionControllerHandle TransitionController); // 0x288a61c (Index: 0xb, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnUpdateFloorMaterial(bool& bEnableAutotestBackground); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AItemOnPawnPreview_C) == 0x9b0, "Size mismatch for AItemOnPawnPreview_C");
static_assert(offsetof(AItemOnPawnPreview_C, UberGraphFrame) == 0x850, "Offset mismatch for AItemOnPawnPreview_C::UberGraphFrame");
static_assert(offsetof(AItemOnPawnPreview_C, Temp_IASDerezAbsorbPoint) == 0x858, "Offset mismatch for AItemOnPawnPreview_C::Temp_IASDerezAbsorbPoint");
static_assert(offsetof(AItemOnPawnPreview_C, Arrow1) == 0x860, "Offset mismatch for AItemOnPawnPreview_C::Arrow1");
static_assert(offsetof(AItemOnPawnPreview_C, Directional_Light_For_Atmosphere_PC) == 0x868, "Offset mismatch for AItemOnPawnPreview_C::Directional_Light_For_Atmosphere_PC");
static_assert(offsetof(AItemOnPawnPreview_C, SkyLightPC) == 0x870, "Offset mismatch for AItemOnPawnPreview_C::SkyLightPC");
static_assert(offsetof(AItemOnPawnPreview_C, Arrow) == 0x878, "Offset mismatch for AItemOnPawnPreview_C::Arrow");
static_assert(offsetof(AItemOnPawnPreview_C, SkyLightLowMobile) == 0x880, "Offset mismatch for AItemOnPawnPreview_C::SkyLightLowMobile");
static_assert(offsetof(AItemOnPawnPreview_C, DirectionalLightMobile) == 0x888, "Offset mismatch for AItemOnPawnPreview_C::DirectionalLightMobile");
static_assert(offsetof(AItemOnPawnPreview_C, KeyLight_StandaloneForSwitch) == 0x890, "Offset mismatch for AItemOnPawnPreview_C::KeyLight_StandaloneForSwitch");
static_assert(offsetof(AItemOnPawnPreview_C, KeyLight5) == 0x898, "Offset mismatch for AItemOnPawnPreview_C::KeyLight5");
static_assert(offsetof(AItemOnPawnPreview_C, KeyLight6) == 0x8a0, "Offset mismatch for AItemOnPawnPreview_C::KeyLight6");
static_assert(offsetof(AItemOnPawnPreview_C, KeyLigh3) == 0x8a8, "Offset mismatch for AItemOnPawnPreview_C::KeyLigh3");
static_assert(offsetof(AItemOnPawnPreview_C, KeyLight2) == 0x8b0, "Offset mismatch for AItemOnPawnPreview_C::KeyLight2");
static_assert(offsetof(AItemOnPawnPreview_C, BounceRear1) == 0x8b8, "Offset mismatch for AItemOnPawnPreview_C::BounceRear1");
static_assert(offsetof(AItemOnPawnPreview_C, RimLowerRight1) == 0x8c0, "Offset mismatch for AItemOnPawnPreview_C::RimLowerRight1");
static_assert(offsetof(AItemOnPawnPreview_C, RimLeft1) == 0x8c8, "Offset mismatch for AItemOnPawnPreview_C::RimLeft1");
static_assert(offsetof(AItemOnPawnPreview_C, RimTopRight1) == 0x8d0, "Offset mismatch for AItemOnPawnPreview_C::RimTopRight1");
static_assert(offsetof(AItemOnPawnPreview_C, RimBottomLeft1) == 0x8d8, "Offset mismatch for AItemOnPawnPreview_C::RimBottomLeft1");
static_assert(offsetof(AItemOnPawnPreview_C, Bounce1) == 0x8e0, "Offset mismatch for AItemOnPawnPreview_C::Bounce1");
static_assert(offsetof(AItemOnPawnPreview_C, LightTransform) == 0x8e8, "Offset mismatch for AItemOnPawnPreview_C::LightTransform");
static_assert(offsetof(AItemOnPawnPreview_C, Plane) == 0x8f0, "Offset mismatch for AItemOnPawnPreview_C::Plane");
static_assert(offsetof(AItemOnPawnPreview_C, Sample_Mesh) == 0x8f8, "Offset mismatch for AItemOnPawnPreview_C::Sample_Mesh");
static_assert(offsetof(AItemOnPawnPreview_C, RezInMaterialEffectTimeLine2_NewTrack_0_FBE08AE14EC4BA399756F0BBFA6ABC31) == 0x900, "Offset mismatch for AItemOnPawnPreview_C::RezInMaterialEffectTimeLine2_NewTrack_0_FBE08AE14EC4BA399756F0BBFA6ABC31");
static_assert(offsetof(AItemOnPawnPreview_C, RezInMaterialEffectTimeLine2__Direction_FBE08AE14EC4BA399756F0BBFA6ABC31) == 0x904, "Offset mismatch for AItemOnPawnPreview_C::RezInMaterialEffectTimeLine2__Direction_FBE08AE14EC4BA399756F0BBFA6ABC31");
static_assert(offsetof(AItemOnPawnPreview_C, RezInMaterialEffectTimeLine2) == 0x908, "Offset mismatch for AItemOnPawnPreview_C::RezInMaterialEffectTimeLine2");
static_assert(offsetof(AItemOnPawnPreview_C, RezInMaterialEffectTimeLine_NewTrack_0_963A663B4B1DFB2954D581893C8ACFD8) == 0x910, "Offset mismatch for AItemOnPawnPreview_C::RezInMaterialEffectTimeLine_NewTrack_0_963A663B4B1DFB2954D581893C8ACFD8");
static_assert(offsetof(AItemOnPawnPreview_C, RezInMaterialEffectTimeLine__Direction_963A663B4B1DFB2954D581893C8ACFD8) == 0x914, "Offset mismatch for AItemOnPawnPreview_C::RezInMaterialEffectTimeLine__Direction_963A663B4B1DFB2954D581893C8ACFD8");
static_assert(offsetof(AItemOnPawnPreview_C, RezInMaterialEffectTimeLine) == 0x918, "Offset mismatch for AItemOnPawnPreview_C::RezInMaterialEffectTimeLine");
static_assert(offsetof(AItemOnPawnPreview_C, AlwaysOn) == 0x920, "Offset mismatch for AItemOnPawnPreview_C::AlwaysOn");
static_assert(offsetof(AItemOnPawnPreview_C, IsActive) == 0x921, "Offset mismatch for AItemOnPawnPreview_C::IsActive");
static_assert(offsetof(AItemOnPawnPreview_C, debugConstructionLighting) == 0x922, "Offset mismatch for AItemOnPawnPreview_C::debugConstructionLighting");
static_assert(offsetof(AItemOnPawnPreview_C, ObscuringLoopEmitter) == 0x928, "Offset mismatch for AItemOnPawnPreview_C::ObscuringLoopEmitter");
static_assert(offsetof(AItemOnPawnPreview_C, ToonLightRotatio) == 0x930, "Offset mismatch for AItemOnPawnPreview_C::ToonLightRotatio");
static_assert(offsetof(AItemOnPawnPreview_C, bIsBattlePassReward) == 0x948, "Offset mismatch for AItemOnPawnPreview_C::bIsBattlePassReward");
static_assert(offsetof(AItemOnPawnPreview_C, LOD_StreamingSafetyTimer) == 0x950, "Offset mismatch for AItemOnPawnPreview_C::LOD_StreamingSafetyTimer");
static_assert(offsetof(AItemOnPawnPreview_C, DefaultFloorMaterial) == 0x958, "Offset mismatch for AItemOnPawnPreview_C::DefaultFloorMaterial");
static_assert(offsetof(AItemOnPawnPreview_C, CustomFloorMaterial) == 0x960, "Offset mismatch for AItemOnPawnPreview_C::CustomFloorMaterial");
static_assert(offsetof(AItemOnPawnPreview_C, ItemsPendingTransitionOutHandle) == 0x968, "Offset mismatch for AItemOnPawnPreview_C::ItemsPendingTransitionOutHandle");
static_assert(offsetof(AItemOnPawnPreview_C, IASLoadingFX_LoopFX) == 0x978, "Offset mismatch for AItemOnPawnPreview_C::IASLoadingFX_LoopFX");
static_assert(offsetof(AItemOnPawnPreview_C, Use_Secondary_Transition_Effects) == 0x980, "Offset mismatch for AItemOnPawnPreview_C::Use_Secondary_Transition_Effects");
static_assert(offsetof(AItemOnPawnPreview_C, Show_Floor) == 0x981, "Offset mismatch for AItemOnPawnPreview_C::Show_Floor");
static_assert(offsetof(AItemOnPawnPreview_C, IASLoadingDelayTimer) == 0x988, "Offset mismatch for AItemOnPawnPreview_C::IASLoadingDelayTimer");
static_assert(offsetof(AItemOnPawnPreview_C, IASLoadingFXDestroyDelayTimer) == 0x990, "Offset mismatch for AItemOnPawnPreview_C::IASLoadingFXDestroyDelayTimer");
static_assert(offsetof(AItemOnPawnPreview_C, IASResInDelayTimer) == 0x998, "Offset mismatch for AItemOnPawnPreview_C::IASResInDelayTimer");
static_assert(offsetof(AItemOnPawnPreview_C, PawnMaterialOverrideGuids) == 0x9a0, "Offset mismatch for AItemOnPawnPreview_C::PawnMaterialOverrideGuids");

// Size: 0x2ba (Inherited: 0x2d0, Single: 0xffffffea)
class ABP_DetailLevelMesh_C : public AActor
{
public:
    UStaticMeshComponent* StaticMesh; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    bool AlwaysVisible; // 0x2b8 (Size: 0x1, Type: BoolProperty)
    bool NotVisibleOnSwitch; // 0x2b9 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(ABP_DetailLevelMesh_C) == 0x2ba, "Size mismatch for ABP_DetailLevelMesh_C");
static_assert(offsetof(ABP_DetailLevelMesh_C, StaticMesh) == 0x2a8, "Offset mismatch for ABP_DetailLevelMesh_C::StaticMesh");
static_assert(offsetof(ABP_DetailLevelMesh_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ABP_DetailLevelMesh_C::DefaultSceneRoot");
static_assert(offsetof(ABP_DetailLevelMesh_C, AlwaysVisible) == 0x2b8, "Offset mismatch for ABP_DetailLevelMesh_C::AlwaysVisible");
static_assert(offsetof(ABP_DetailLevelMesh_C, NotVisibleOnSwitch) == 0x2b9, "Offset mismatch for ABP_DetailLevelMesh_C::NotVisibleOnSwitch");

// Size: 0xb01 (Inherited: 0x1790, Single: 0xfffff371)
class AFortnitePartyBackdrop_Camera_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)
    UArrowComponent* Arrow; // 0xa98 (Size: 0x8, Type: ObjectProperty)
    FTransform SavedTransform; // 0xaa0 (Size: 0x60, Type: StructProperty)
    bool Active; // 0xb00 (Size: 0x1, Type: BoolProperty)

public:
    virtual void BP_OnDeactivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(AFortnitePartyBackdrop_Camera_C) == 0xb01, "Size mismatch for AFortnitePartyBackdrop_Camera_C");
static_assert(offsetof(AFortnitePartyBackdrop_Camera_C, UberGraphFrame) == 0xa90, "Offset mismatch for AFortnitePartyBackdrop_Camera_C::UberGraphFrame");
static_assert(offsetof(AFortnitePartyBackdrop_Camera_C, Arrow) == 0xa98, "Offset mismatch for AFortnitePartyBackdrop_Camera_C::Arrow");
static_assert(offsetof(AFortnitePartyBackdrop_Camera_C, SavedTransform) == 0xaa0, "Offset mismatch for AFortnitePartyBackdrop_Camera_C::SavedTransform");
static_assert(offsetof(AFortnitePartyBackdrop_Camera_C, Active) == 0xb00, "Offset mismatch for AFortnitePartyBackdrop_Camera_C::Active");

// Size: 0x2b8 (Inherited: 0x588, Single: 0xfffffd30)
class ALobbyActorDirector_C : public ALobbyActorDirector
{
public:
};

static_assert(sizeof(ALobbyActorDirector_C) == 0x2b8, "Size mismatch for ALobbyActorDirector_C");

// Size: 0x2e8 (Inherited: 0x2d0, Single: 0x18)
class ABP_Background_Raytracing_C : public AActor
{
public:
    UStaticMeshComponent* SM_InvertedSphere_BackPlate_Half; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    bool FullSphere; // 0x2b8 (Size: 0x1, Type: BoolProperty)
    bool UseCubemap; // 0x2b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ba[0x6]; // 0x2ba (Size: 0x6, Type: PaddingProperty)
    double Brightness; // 0x2c0 (Size: 0x8, Type: DoubleProperty)
    UTexture* 2dTexture; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UTexture* Cubemap; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    FLinearColor FadeColor; // 0x2d8 (Size: 0x10, Type: StructProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(ABP_Background_Raytracing_C) == 0x2e8, "Size mismatch for ABP_Background_Raytracing_C");
static_assert(offsetof(ABP_Background_Raytracing_C, SM_InvertedSphere_BackPlate_Half) == 0x2a8, "Offset mismatch for ABP_Background_Raytracing_C::SM_InvertedSphere_BackPlate_Half");
static_assert(offsetof(ABP_Background_Raytracing_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ABP_Background_Raytracing_C::DefaultSceneRoot");
static_assert(offsetof(ABP_Background_Raytracing_C, FullSphere) == 0x2b8, "Offset mismatch for ABP_Background_Raytracing_C::FullSphere");
static_assert(offsetof(ABP_Background_Raytracing_C, UseCubemap) == 0x2b9, "Offset mismatch for ABP_Background_Raytracing_C::UseCubemap");
static_assert(offsetof(ABP_Background_Raytracing_C, Brightness) == 0x2c0, "Offset mismatch for ABP_Background_Raytracing_C::Brightness");
static_assert(offsetof(ABP_Background_Raytracing_C, 2dTexture) == 0x2c8, "Offset mismatch for ABP_Background_Raytracing_C::2dTexture");
static_assert(offsetof(ABP_Background_Raytracing_C, Cubemap) == 0x2d0, "Offset mismatch for ABP_Background_Raytracing_C::Cubemap");
static_assert(offsetof(ABP_Background_Raytracing_C, FadeColor) == 0x2d8, "Offset mismatch for ABP_Background_Raytracing_C::FadeColor");

// Size: 0x4a0 (Inherited: 0x768, Single: 0xfffffd38)
class ACMSLobbyDirector_C : public ADynamicBackgroundDirector
{
public:
    USceneComponent* DefaultSceneRoot; // 0x498 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ACMSLobbyDirector_C) == 0x4a0, "Size mismatch for ACMSLobbyDirector_C");
static_assert(offsetof(ACMSLobbyDirector_C, DefaultSceneRoot) == 0x498, "Offset mismatch for ACMSLobbyDirector_C::DefaultSceneRoot");

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class ABP_CharacterRimlightDisabler_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_CharacterRimlightDisabler_C) == 0x2b8, "Size mismatch for ABP_CharacterRimlightDisabler_C");
static_assert(offsetof(ABP_CharacterRimlightDisabler_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ABP_CharacterRimlightDisabler_C::UberGraphFrame");
static_assert(offsetof(ABP_CharacterRimlightDisabler_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ABP_CharacterRimlightDisabler_C::DefaultSceneRoot");

// Size: 0xab0 (Inherited: 0x1790, Single: 0xfffff320)
class AFortnitePartyHeroSelect_Camera_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa90 (Size: 0x8, Type: StructProperty)
    UCameraComponent* CameraActor_0; // 0xa98 (Size: 0x8, Type: ObjectProperty)
    bool MouseDown; // 0xaa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_aa1[0x7]; // 0xaa1 (Size: 0x7, Type: PaddingProperty)
    AFortPlayerPawn* CachedPawn; // 0xaa8 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    void HandleMouseRelease(); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void BP_OnDeactivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnActivated(AFortPlayerController*& PlayerController); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    void HandleMousePress(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AFortnitePartyHeroSelect_Camera_C) == 0xab0, "Size mismatch for AFortnitePartyHeroSelect_Camera_C");
static_assert(offsetof(AFortnitePartyHeroSelect_Camera_C, UberGraphFrame) == 0xa90, "Offset mismatch for AFortnitePartyHeroSelect_Camera_C::UberGraphFrame");
static_assert(offsetof(AFortnitePartyHeroSelect_Camera_C, CameraActor_0) == 0xa98, "Offset mismatch for AFortnitePartyHeroSelect_Camera_C::CameraActor_0");
static_assert(offsetof(AFortnitePartyHeroSelect_Camera_C, MouseDown) == 0xaa0, "Offset mismatch for AFortnitePartyHeroSelect_Camera_C::MouseDown");
static_assert(offsetof(AFortnitePartyHeroSelect_Camera_C, CachedPawn) == 0xaa8, "Offset mismatch for AFortnitePartyHeroSelect_Camera_C::CachedPawn");

// Size: 0x378 (Inherited: 0x2d0, Single: 0xa8)
class AVaultCharacterLightingBP_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    UArrowComponent* Arrow1; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight4; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight3; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight2; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UPostProcessComponent* PostProcess_Mobile; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UPostProcessComponent* PostProcess_LOWPC; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLight_LOWPC; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLight_LOWPC; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLightMobile; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightLowMobil; // 0x300 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLight; // 0x308 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimLowerRight; // 0x310 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimLeft; // 0x318 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimTopRight; // 0x320 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimBottomLeft; // 0x328 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* KeyLight; // 0x330 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* Bounce; // 0x338 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* BounceRear; // 0x340 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* SharedRoot; // 0x348 (Size: 0x8, Type: ObjectProperty)
    bool DebugMobile_Lighting; // 0x350 (Size: 0x1, Type: BoolProperty)
    bool DebugLightingPC; // 0x351 (Size: 0x1, Type: BoolProperty)
    bool IsActive; // 0x352 (Size: 0x1, Type: BoolProperty)
    bool AlwaysOn; // 0x353 (Size: 0x1, Type: BoolProperty)
    bool DebugLighting_LOWDetailPC; // 0x354 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_355[0x3]; // 0x355 (Size: 0x3, Type: PaddingProperty)
    FLinearColor MPC_ManualSunlightVector; // 0x358 (Size: 0x10, Type: StructProperty)
    FLinearColor MPC_ManualSunlightColor; // 0x368 (Size: 0x10, Type: StructProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting_LOWDetail(bool& Visibility); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting(bool& Visibility); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchMobileLighting(bool& Visibilty); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AVaultCharacterLightingBP_C) == 0x378, "Size mismatch for AVaultCharacterLightingBP_C");
static_assert(offsetof(AVaultCharacterLightingBP_C, UberGraphFrame) == 0x2a8, "Offset mismatch for AVaultCharacterLightingBP_C::UberGraphFrame");
static_assert(offsetof(AVaultCharacterLightingBP_C, Arrow1) == 0x2b0, "Offset mismatch for AVaultCharacterLightingBP_C::Arrow1");
static_assert(offsetof(AVaultCharacterLightingBP_C, KeyLight4) == 0x2b8, "Offset mismatch for AVaultCharacterLightingBP_C::KeyLight4");
static_assert(offsetof(AVaultCharacterLightingBP_C, KeyLight3) == 0x2c0, "Offset mismatch for AVaultCharacterLightingBP_C::KeyLight3");
static_assert(offsetof(AVaultCharacterLightingBP_C, KeyLight2) == 0x2c8, "Offset mismatch for AVaultCharacterLightingBP_C::KeyLight2");
static_assert(offsetof(AVaultCharacterLightingBP_C, PostProcess_Mobile) == 0x2d0, "Offset mismatch for AVaultCharacterLightingBP_C::PostProcess_Mobile");
static_assert(offsetof(AVaultCharacterLightingBP_C, PostProcess_LOWPC) == 0x2d8, "Offset mismatch for AVaultCharacterLightingBP_C::PostProcess_LOWPC");
static_assert(offsetof(AVaultCharacterLightingBP_C, SkyLight_LOWPC) == 0x2e0, "Offset mismatch for AVaultCharacterLightingBP_C::SkyLight_LOWPC");
static_assert(offsetof(AVaultCharacterLightingBP_C, DirectionalLight_LOWPC) == 0x2e8, "Offset mismatch for AVaultCharacterLightingBP_C::DirectionalLight_LOWPC");
static_assert(offsetof(AVaultCharacterLightingBP_C, Arrow) == 0x2f0, "Offset mismatch for AVaultCharacterLightingBP_C::Arrow");
static_assert(offsetof(AVaultCharacterLightingBP_C, DirectionalLightMobile) == 0x2f8, "Offset mismatch for AVaultCharacterLightingBP_C::DirectionalLightMobile");
static_assert(offsetof(AVaultCharacterLightingBP_C, SkyLightLowMobil) == 0x300, "Offset mismatch for AVaultCharacterLightingBP_C::SkyLightLowMobil");
static_assert(offsetof(AVaultCharacterLightingBP_C, SkyLight) == 0x308, "Offset mismatch for AVaultCharacterLightingBP_C::SkyLight");
static_assert(offsetof(AVaultCharacterLightingBP_C, RimLowerRight) == 0x310, "Offset mismatch for AVaultCharacterLightingBP_C::RimLowerRight");
static_assert(offsetof(AVaultCharacterLightingBP_C, RimLeft) == 0x318, "Offset mismatch for AVaultCharacterLightingBP_C::RimLeft");
static_assert(offsetof(AVaultCharacterLightingBP_C, RimTopRight) == 0x320, "Offset mismatch for AVaultCharacterLightingBP_C::RimTopRight");
static_assert(offsetof(AVaultCharacterLightingBP_C, RimBottomLeft) == 0x328, "Offset mismatch for AVaultCharacterLightingBP_C::RimBottomLeft");
static_assert(offsetof(AVaultCharacterLightingBP_C, KeyLight) == 0x330, "Offset mismatch for AVaultCharacterLightingBP_C::KeyLight");
static_assert(offsetof(AVaultCharacterLightingBP_C, Bounce) == 0x338, "Offset mismatch for AVaultCharacterLightingBP_C::Bounce");
static_assert(offsetof(AVaultCharacterLightingBP_C, BounceRear) == 0x340, "Offset mismatch for AVaultCharacterLightingBP_C::BounceRear");
static_assert(offsetof(AVaultCharacterLightingBP_C, SharedRoot) == 0x348, "Offset mismatch for AVaultCharacterLightingBP_C::SharedRoot");
static_assert(offsetof(AVaultCharacterLightingBP_C, DebugMobile_Lighting) == 0x350, "Offset mismatch for AVaultCharacterLightingBP_C::DebugMobile_Lighting");
static_assert(offsetof(AVaultCharacterLightingBP_C, DebugLightingPC) == 0x351, "Offset mismatch for AVaultCharacterLightingBP_C::DebugLightingPC");
static_assert(offsetof(AVaultCharacterLightingBP_C, IsActive) == 0x352, "Offset mismatch for AVaultCharacterLightingBP_C::IsActive");
static_assert(offsetof(AVaultCharacterLightingBP_C, AlwaysOn) == 0x353, "Offset mismatch for AVaultCharacterLightingBP_C::AlwaysOn");
static_assert(offsetof(AVaultCharacterLightingBP_C, DebugLighting_LOWDetailPC) == 0x354, "Offset mismatch for AVaultCharacterLightingBP_C::DebugLighting_LOWDetailPC");
static_assert(offsetof(AVaultCharacterLightingBP_C, MPC_ManualSunlightVector) == 0x358, "Offset mismatch for AVaultCharacterLightingBP_C::MPC_ManualSunlightVector");
static_assert(offsetof(AVaultCharacterLightingBP_C, MPC_ManualSunlightColor) == 0x368, "Offset mismatch for AVaultCharacterLightingBP_C::MPC_ManualSunlightColor");

// Size: 0x2f8 (Inherited: 0x2d0, Single: 0x28)
class AVaultWeaponPlacementHelper_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* CUBE; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* PS_NoPlayer_Sparkle; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* PS_NoPlayer_Swirl02; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* PS_NoPlayer_Swirl01; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* CharacterPlacement; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Root; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* Mesh; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t NewEventDispatcher_0[0x10]; // 0x2e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnFrontendCameraChanged(EFrontEndCamera& NewCamera, EFrontEndCamera& OldCamera); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetFrontEndAnimInstance(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void NewEventDispatcher_0__DelegateSignature(); // 0x288a61c (Index: 0x6, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AVaultWeaponPlacementHelper_C) == 0x2f8, "Size mismatch for AVaultWeaponPlacementHelper_C");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, UberGraphFrame) == 0x2a8, "Offset mismatch for AVaultWeaponPlacementHelper_C::UberGraphFrame");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, CUBE) == 0x2b0, "Offset mismatch for AVaultWeaponPlacementHelper_C::CUBE");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, PS_NoPlayer_Sparkle) == 0x2b8, "Offset mismatch for AVaultWeaponPlacementHelper_C::PS_NoPlayer_Sparkle");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, PS_NoPlayer_Swirl02) == 0x2c0, "Offset mismatch for AVaultWeaponPlacementHelper_C::PS_NoPlayer_Swirl02");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, PS_NoPlayer_Swirl01) == 0x2c8, "Offset mismatch for AVaultWeaponPlacementHelper_C::PS_NoPlayer_Swirl01");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, CharacterPlacement) == 0x2d0, "Offset mismatch for AVaultWeaponPlacementHelper_C::CharacterPlacement");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, Root) == 0x2d8, "Offset mismatch for AVaultWeaponPlacementHelper_C::Root");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, Mesh) == 0x2e0, "Offset mismatch for AVaultWeaponPlacementHelper_C::Mesh");
static_assert(offsetof(AVaultWeaponPlacementHelper_C, NewEventDispatcher_0) == 0x2e8, "Offset mismatch for AVaultWeaponPlacementHelper_C::NewEventDispatcher_0");

// Size: 0x381 (Inherited: 0x640, Single: 0xfffffd41)
class AVaultWorld_C : public AFortItemPreviewWorld
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x370 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* SM_InvertedHalfSphere; // 0x378 (Size: 0x8, Type: ObjectProperty)
    bool bIsPrimaryBackgroundActive; // 0x380 (Size: 0x1, Type: BoolProperty)

public:
    void Assign_Background_Dynamic_Materials(AStaticMeshActor*& TargetBackground); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ToggleBackgroundText(bool& DisplayText); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetVaultRotator(AVaultRotator_C*& VaultRotator); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnNewSceneBackgroundChildActor(AFortStaticMeshActor*& NewActor); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AVaultWorld_C) == 0x381, "Size mismatch for AVaultWorld_C");
static_assert(offsetof(AVaultWorld_C, UberGraphFrame) == 0x370, "Offset mismatch for AVaultWorld_C::UberGraphFrame");
static_assert(offsetof(AVaultWorld_C, SM_InvertedHalfSphere) == 0x378, "Offset mismatch for AVaultWorld_C::SM_InvertedHalfSphere");
static_assert(offsetof(AVaultWorld_C, bIsPrimaryBackgroundActive) == 0x380, "Offset mismatch for AVaultWorld_C::bIsPrimaryBackgroundActive");

// Size: 0x740 (Inherited: 0x810, Single: 0xffffff30)
class APartyDisplayManagerBP_C : public APartyDisplayManager
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x540 (Size: 0x8, Type: StructProperty)
    UChildActorComponent* PrefabActorComp; // 0x548 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* SkeletalMesh; // 0x550 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh; // 0x558 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* ScalePivot; // 0x560 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* PivotHolder; // 0x568 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* CelebratoryFX; // 0x570 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot; // 0x578 (Size: 0x8, Type: ObjectProperty)
    float HoloMatColorPulse_Alpha_E6C257BB472EFEF7971B66A1E8FAE3D8; // 0x580 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> HoloMatColorPulse__Direction_E6C257BB472EFEF7971B66A1E8FAE3D8; // 0x584 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_585[0x3]; // 0x585 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* HoloMatColorPulse; // 0x588 (Size: 0x8, Type: ObjectProperty)
    float ScaleAnimEvolve_Scaling_6D0D09564D54A0DEA88CCC96FA6653CC; // 0x590 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ScaleAnimEvolve__Direction_6D0D09564D54A0DEA88CCC96FA6653CC; // 0x594 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_595[0x3]; // 0x595 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ScaleAnimEvolve; // 0x598 (Size: 0x8, Type: ObjectProperty)
    float ScaleAnimLevel_Scaling_CC68128E49202D0C982B7A945E41AF43; // 0x5a0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ScaleAnimLevel__Direction_CC68128E49202D0C982B7A945E41AF43; // 0x5a4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5a5[0x3]; // 0x5a5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ScaleAnimLevel; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle TimerHandle; // 0x5b0 (Size: 0x8, Type: StructProperty)
    double Rotation; // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    UFortItem* ItemToRepresent; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    bool PreviewRotation; // 0x5c8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5c9[0x7]; // 0x5c9 (Size: 0x7, Type: PaddingProperty)
    UCurveFloat* RotationAnimation; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* LevelUpFX; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* EvolveUpFX; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    FVector FXTargetLocation; // 0x5e8 (Size: 0x18, Type: StructProperty)
    bool IsCharacter; // 0x600 (Size: 0x1, Type: BoolProperty)
    bool IsEvolve; // 0x601 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_602[0x6]; // 0x602 (Size: 0x6, Type: PaddingProperty)
    UParticleSystem* CharLevelUpFX; // 0x608 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* CharEvolveUpFX; // 0x610 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* UIoverrideMID; // 0x618 (Size: 0x8, Type: ObjectProperty)
    bool HasResetVisuals; // 0x620 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_621[0x7]; // 0x621 (Size: 0x7, Type: PaddingProperty)
    UParticleSystemComponent* ParticleSystem1; // 0x628 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* ParticleSystem2; // 0x630 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* CharSwapTransitionFX; // 0x638 (Size: 0x8, Type: ObjectProperty)
    bool IsCharacterVisible; // 0x640 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_641[0x7]; // 0x641 (Size: 0x7, Type: PaddingProperty)
    AFortPlayerPawn* HeroPawn; // 0x648 (Size: 0x8, Type: ObjectProperty)
    bool SanityChecker; // 0x650 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_651[0x7]; // 0x651 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_HoloMaterial; // 0x658 (Size: 0x8, Type: ObjectProperty)
    FName HideElement_1; // 0x660 (Size: 0x4, Type: NameProperty)
    FName VertexRange; // 0x664 (Size: 0x4, Type: NameProperty)
    FName HideElement_2; // 0x668 (Size: 0x4, Type: NameProperty)
    FName HideElement_3; // 0x66c (Size: 0x4, Type: NameProperty)
    FName HideElement_4; // 0x670 (Size: 0x4, Type: NameProperty)
    FName HideElement_5; // 0x674 (Size: 0x4, Type: NameProperty)
    FName HideElement_6; // 0x678 (Size: 0x4, Type: NameProperty)
    FName HideElement_7; // 0x67c (Size: 0x4, Type: NameProperty)
    FName HideElement_8; // 0x680 (Size: 0x4, Type: NameProperty)
    FName HideElement_9; // 0x684 (Size: 0x4, Type: NameProperty)
    FName HideElement_10; // 0x688 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_68c[0x4]; // 0x68c (Size: 0x4, Type: PaddingProperty)
    FVector ScalePivotPreScaleLocation; // 0x690 (Size: 0x18, Type: StructProperty)
    FVector StaticMeshPreScaleLocation; // 0x6a8 (Size: 0x18, Type: StructProperty)
    FVector SkelMeshPreScaleLocation; // 0x6c0 (Size: 0x18, Type: StructProperty)
    FVector PrefabPreScaleLocation; // 0x6d8 (Size: 0x18, Type: StructProperty)
    UParticleSystemComponent* GhostPistolVFX; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Ghost_Sword_VFX; // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Ghost_Sword_Mesh; // 0x700 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* TransitionFXComponent; // 0x708 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* CharSwapTransitionFXLoop; // 0x710 (Size: 0x8, Type: ObjectProperty)
    FName HideElementsOnlyConsidersRedChannel; // 0x718 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_71c[0x4]; // 0x71c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer Context_Tags; // 0x720 (Size: 0x20, Type: StructProperty)

public:
    virtual void PlayEvolutionEffect(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void PlayLevelUpEffect(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    void PostSetupPrefabVisuals(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    void ResetPreScaleLocations(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ResOutPawnFromLobby(AFortPlayerPawn*& Pawn, int32_t& PartyIndex); // 0x288a61c (Index: 0x9, Flags: Event|Public|BlueprintEvent)
    void RestoreTeleportMIDsInProgress(AFortPlayerPawn*& const Pawn); // 0x288a61c (Index: 0xa, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetUIOverrideVisuals(UTexture2D*& Large_Texture, UFortItemDefinition*& Item, EFortRarity& Rarity); // 0x288a61c (Index: 0xf, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void SetupPrefabVisuals(); // 0x288a61c (Index: 0x10, Flags: Event|Public|BlueprintEvent)
    virtual void CharacterCustomizationFinished(AFortPlayerPawn*& Pawn); // 0x288a61c (Index: 0x13, Flags: Event|Public|BlueprintEvent)
    virtual void OnMeshLODStreamingFinished(); // 0x288a61c (Index: 0x16, Flags: Event|Public|BlueprintEvent)
    virtual void OnPlayerPawnAddedToLobby(AFortPlayerPawn*& Pawn); // 0x288a61c (Index: 0x17, Flags: Event|Public|BlueprintEvent)
    void PartyMemberInProgressCheck(AFortPlayerPawn*& Pawn); // 0x288a61c (Index: 0x18, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetItemDefinitionToShow(UFortItemDefinition*& ItemDefinition); // 0x288a61c (Index: 0x1b, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void GetMeshForCurrentDisplayedItem(UMeshComponent*& OutDisplayedMesh); // 0x288a61c (Index: 0x1d, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual AActor* GetPrefabActorForCurrentDisplayedItem() const; // 0x288a61c (Index: 0x1e, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    FTransform GetWeaponPlacementTransform(); // 0x288a61c (Index: 0x20, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void HandleLoadingAssetsForItemCompleted(UFortItem*& ItemWhoseAssetsWereLoaded, const TArray<UObject*> LoadedAssets, const FGuid RequestID); // 0x288a61c (Index: 0x21, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void HandlePartyMemberInProgressDisplayChanges(AFortPlayerPawn*& Pawn); // 0x288a61c (Index: 0x22, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ShowItem(UFortItem*& const ItemToView, const FGuid RequestID); // 0x288a61c (Index: 0x25, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void UpdatePreviewMeshTransforms(); // 0x288a61c (Index: 0x26, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)

private:
    void ResetVisuals(); // 0x288a61c (Index: 0x8, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetupSkeletalMeshVisuals(USkeletalMesh*& NewMesh); // 0x288a61c (Index: 0x11, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    FTransform GetItemPreviewOffset(UFortItemDefinition*& ItemDefinition); // 0x288a61c (Index: 0x1c, Flags: Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    FTransform GetPreviewMeshWorldTransform(); // 0x288a61c (Index: 0x1f, Flags: Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void SetupStaticMeshVisuals(UStaticMesh*& NewMesh); // 0x288a61c (Index: 0x24, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(APartyDisplayManagerBP_C) == 0x740, "Size mismatch for APartyDisplayManagerBP_C");
static_assert(offsetof(APartyDisplayManagerBP_C, UberGraphFrame) == 0x540, "Offset mismatch for APartyDisplayManagerBP_C::UberGraphFrame");
static_assert(offsetof(APartyDisplayManagerBP_C, PrefabActorComp) == 0x548, "Offset mismatch for APartyDisplayManagerBP_C::PrefabActorComp");
static_assert(offsetof(APartyDisplayManagerBP_C, SkeletalMesh) == 0x550, "Offset mismatch for APartyDisplayManagerBP_C::SkeletalMesh");
static_assert(offsetof(APartyDisplayManagerBP_C, StaticMesh) == 0x558, "Offset mismatch for APartyDisplayManagerBP_C::StaticMesh");
static_assert(offsetof(APartyDisplayManagerBP_C, ScalePivot) == 0x560, "Offset mismatch for APartyDisplayManagerBP_C::ScalePivot");
static_assert(offsetof(APartyDisplayManagerBP_C, PivotHolder) == 0x568, "Offset mismatch for APartyDisplayManagerBP_C::PivotHolder");
static_assert(offsetof(APartyDisplayManagerBP_C, CelebratoryFX) == 0x570, "Offset mismatch for APartyDisplayManagerBP_C::CelebratoryFX");
static_assert(offsetof(APartyDisplayManagerBP_C, DefaultSceneRoot) == 0x578, "Offset mismatch for APartyDisplayManagerBP_C::DefaultSceneRoot");
static_assert(offsetof(APartyDisplayManagerBP_C, HoloMatColorPulse_Alpha_E6C257BB472EFEF7971B66A1E8FAE3D8) == 0x580, "Offset mismatch for APartyDisplayManagerBP_C::HoloMatColorPulse_Alpha_E6C257BB472EFEF7971B66A1E8FAE3D8");
static_assert(offsetof(APartyDisplayManagerBP_C, HoloMatColorPulse__Direction_E6C257BB472EFEF7971B66A1E8FAE3D8) == 0x584, "Offset mismatch for APartyDisplayManagerBP_C::HoloMatColorPulse__Direction_E6C257BB472EFEF7971B66A1E8FAE3D8");
static_assert(offsetof(APartyDisplayManagerBP_C, HoloMatColorPulse) == 0x588, "Offset mismatch for APartyDisplayManagerBP_C::HoloMatColorPulse");
static_assert(offsetof(APartyDisplayManagerBP_C, ScaleAnimEvolve_Scaling_6D0D09564D54A0DEA88CCC96FA6653CC) == 0x590, "Offset mismatch for APartyDisplayManagerBP_C::ScaleAnimEvolve_Scaling_6D0D09564D54A0DEA88CCC96FA6653CC");
static_assert(offsetof(APartyDisplayManagerBP_C, ScaleAnimEvolve__Direction_6D0D09564D54A0DEA88CCC96FA6653CC) == 0x594, "Offset mismatch for APartyDisplayManagerBP_C::ScaleAnimEvolve__Direction_6D0D09564D54A0DEA88CCC96FA6653CC");
static_assert(offsetof(APartyDisplayManagerBP_C, ScaleAnimEvolve) == 0x598, "Offset mismatch for APartyDisplayManagerBP_C::ScaleAnimEvolve");
static_assert(offsetof(APartyDisplayManagerBP_C, ScaleAnimLevel_Scaling_CC68128E49202D0C982B7A945E41AF43) == 0x5a0, "Offset mismatch for APartyDisplayManagerBP_C::ScaleAnimLevel_Scaling_CC68128E49202D0C982B7A945E41AF43");
static_assert(offsetof(APartyDisplayManagerBP_C, ScaleAnimLevel__Direction_CC68128E49202D0C982B7A945E41AF43) == 0x5a4, "Offset mismatch for APartyDisplayManagerBP_C::ScaleAnimLevel__Direction_CC68128E49202D0C982B7A945E41AF43");
static_assert(offsetof(APartyDisplayManagerBP_C, ScaleAnimLevel) == 0x5a8, "Offset mismatch for APartyDisplayManagerBP_C::ScaleAnimLevel");
static_assert(offsetof(APartyDisplayManagerBP_C, TimerHandle) == 0x5b0, "Offset mismatch for APartyDisplayManagerBP_C::TimerHandle");
static_assert(offsetof(APartyDisplayManagerBP_C, Rotation) == 0x5b8, "Offset mismatch for APartyDisplayManagerBP_C::Rotation");
static_assert(offsetof(APartyDisplayManagerBP_C, ItemToRepresent) == 0x5c0, "Offset mismatch for APartyDisplayManagerBP_C::ItemToRepresent");
static_assert(offsetof(APartyDisplayManagerBP_C, PreviewRotation) == 0x5c8, "Offset mismatch for APartyDisplayManagerBP_C::PreviewRotation");
static_assert(offsetof(APartyDisplayManagerBP_C, RotationAnimation) == 0x5d0, "Offset mismatch for APartyDisplayManagerBP_C::RotationAnimation");
static_assert(offsetof(APartyDisplayManagerBP_C, LevelUpFX) == 0x5d8, "Offset mismatch for APartyDisplayManagerBP_C::LevelUpFX");
static_assert(offsetof(APartyDisplayManagerBP_C, EvolveUpFX) == 0x5e0, "Offset mismatch for APartyDisplayManagerBP_C::EvolveUpFX");
static_assert(offsetof(APartyDisplayManagerBP_C, FXTargetLocation) == 0x5e8, "Offset mismatch for APartyDisplayManagerBP_C::FXTargetLocation");
static_assert(offsetof(APartyDisplayManagerBP_C, IsCharacter) == 0x600, "Offset mismatch for APartyDisplayManagerBP_C::IsCharacter");
static_assert(offsetof(APartyDisplayManagerBP_C, IsEvolve) == 0x601, "Offset mismatch for APartyDisplayManagerBP_C::IsEvolve");
static_assert(offsetof(APartyDisplayManagerBP_C, CharLevelUpFX) == 0x608, "Offset mismatch for APartyDisplayManagerBP_C::CharLevelUpFX");
static_assert(offsetof(APartyDisplayManagerBP_C, CharEvolveUpFX) == 0x610, "Offset mismatch for APartyDisplayManagerBP_C::CharEvolveUpFX");
static_assert(offsetof(APartyDisplayManagerBP_C, UIoverrideMID) == 0x618, "Offset mismatch for APartyDisplayManagerBP_C::UIoverrideMID");
static_assert(offsetof(APartyDisplayManagerBP_C, HasResetVisuals) == 0x620, "Offset mismatch for APartyDisplayManagerBP_C::HasResetVisuals");
static_assert(offsetof(APartyDisplayManagerBP_C, ParticleSystem1) == 0x628, "Offset mismatch for APartyDisplayManagerBP_C::ParticleSystem1");
static_assert(offsetof(APartyDisplayManagerBP_C, ParticleSystem2) == 0x630, "Offset mismatch for APartyDisplayManagerBP_C::ParticleSystem2");
static_assert(offsetof(APartyDisplayManagerBP_C, CharSwapTransitionFX) == 0x638, "Offset mismatch for APartyDisplayManagerBP_C::CharSwapTransitionFX");
static_assert(offsetof(APartyDisplayManagerBP_C, IsCharacterVisible) == 0x640, "Offset mismatch for APartyDisplayManagerBP_C::IsCharacterVisible");
static_assert(offsetof(APartyDisplayManagerBP_C, HeroPawn) == 0x648, "Offset mismatch for APartyDisplayManagerBP_C::HeroPawn");
static_assert(offsetof(APartyDisplayManagerBP_C, SanityChecker) == 0x650, "Offset mismatch for APartyDisplayManagerBP_C::SanityChecker");
static_assert(offsetof(APartyDisplayManagerBP_C, MID_HoloMaterial) == 0x658, "Offset mismatch for APartyDisplayManagerBP_C::MID_HoloMaterial");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_1) == 0x660, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_1");
static_assert(offsetof(APartyDisplayManagerBP_C, VertexRange) == 0x664, "Offset mismatch for APartyDisplayManagerBP_C::VertexRange");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_2) == 0x668, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_2");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_3) == 0x66c, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_3");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_4) == 0x670, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_4");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_5) == 0x674, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_5");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_6) == 0x678, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_6");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_7) == 0x67c, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_7");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_8) == 0x680, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_8");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_9) == 0x684, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_9");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElement_10) == 0x688, "Offset mismatch for APartyDisplayManagerBP_C::HideElement_10");
static_assert(offsetof(APartyDisplayManagerBP_C, ScalePivotPreScaleLocation) == 0x690, "Offset mismatch for APartyDisplayManagerBP_C::ScalePivotPreScaleLocation");
static_assert(offsetof(APartyDisplayManagerBP_C, StaticMeshPreScaleLocation) == 0x6a8, "Offset mismatch for APartyDisplayManagerBP_C::StaticMeshPreScaleLocation");
static_assert(offsetof(APartyDisplayManagerBP_C, SkelMeshPreScaleLocation) == 0x6c0, "Offset mismatch for APartyDisplayManagerBP_C::SkelMeshPreScaleLocation");
static_assert(offsetof(APartyDisplayManagerBP_C, PrefabPreScaleLocation) == 0x6d8, "Offset mismatch for APartyDisplayManagerBP_C::PrefabPreScaleLocation");
static_assert(offsetof(APartyDisplayManagerBP_C, GhostPistolVFX) == 0x6f0, "Offset mismatch for APartyDisplayManagerBP_C::GhostPistolVFX");
static_assert(offsetof(APartyDisplayManagerBP_C, Ghost_Sword_VFX) == 0x6f8, "Offset mismatch for APartyDisplayManagerBP_C::Ghost_Sword_VFX");
static_assert(offsetof(APartyDisplayManagerBP_C, Ghost_Sword_Mesh) == 0x700, "Offset mismatch for APartyDisplayManagerBP_C::Ghost_Sword_Mesh");
static_assert(offsetof(APartyDisplayManagerBP_C, TransitionFXComponent) == 0x708, "Offset mismatch for APartyDisplayManagerBP_C::TransitionFXComponent");
static_assert(offsetof(APartyDisplayManagerBP_C, CharSwapTransitionFXLoop) == 0x710, "Offset mismatch for APartyDisplayManagerBP_C::CharSwapTransitionFXLoop");
static_assert(offsetof(APartyDisplayManagerBP_C, HideElementsOnlyConsidersRedChannel) == 0x718, "Offset mismatch for APartyDisplayManagerBP_C::HideElementsOnlyConsidersRedChannel");
static_assert(offsetof(APartyDisplayManagerBP_C, Context_Tags) == 0x720, "Offset mismatch for APartyDisplayManagerBP_C::Context_Tags");

// Size: 0xaf8 (Inherited: 0xda0, Single: 0xfffffd58)
class ATeamMemberPedestal_C : public AFortTeamMemberPedestal
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x610 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* SM_Lobby_Character_TopSpot; // 0x618 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Character_ShadowBlob; // 0x620 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_ObserverPlaceholder; // 0x628 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_LobbyFXSkipMatch; // 0x630 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_LobbyLightDisc_Floating_FX; // 0x638 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* CharacterPlacement; // 0x640 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* P_FE_Smoke; // 0x648 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* LightsParent; // 0x650 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* PS_NoPlayer_Sparkle; // 0x658 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* PS_NoPlayer_Swirl02; // 0x660 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* PS_NoPlayer_Swirl01; // 0x668 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Lobby_Character_Pad_Light_Ring; // 0x670 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Lobby_Character_Pad; // 0x678 (Size: 0x8, Type: ObjectProperty)
    UPointLightComponent* UnderlightBluePoint02; // 0x680 (Size: 0x8, Type: ObjectProperty)
    UPointLightComponent* UnderlightBluePoint01; // 0x688 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* UnderlightBlue02; // 0x690 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* UnderlightBlue01; // 0x698 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* RimSpotLight; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* TopSpotLight; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    float Timeline_2_NewTrack_1_5B2A92484943393ABEA8BF9AE94A7E65; // 0x6b0 (Size: 0x4, Type: FloatProperty)
    float Timeline_2_NewTrack_0_5B2A92484943393ABEA8BF9AE94A7E65; // 0x6b4 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_2__Direction_5B2A92484943393ABEA8BF9AE94A7E65; // 0x6b8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_6b9[0x7]; // 0x6b9 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* Timeline_2; // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    float Timeline_1_NewTrack_0_C7A2C78B4F1CEAE900A2CABA9772C922; // 0x6c8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_1__Direction_C7A2C78B4F1CEAE900A2CABA9772C922; // 0x6cc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_6cd[0x3]; // 0x6cd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_1; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_NewTrack_0_29F162B244A0FAE20371E7AE14A584FA; // 0x6d8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_29F162B244A0FAE20371E7AE14A584FA; // 0x6dc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_6dd[0x3]; // 0x6dd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_0; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    float FadeInPodium_NewTrack_0_AF4A58DF4085C76AD6B3168E661AB7DD; // 0x6e8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> FadeInPodium__Direction_AF4A58DF4085C76AD6B3168E661AB7DD; // 0x6ec (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_6ed[0x3]; // 0x6ed (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* FadeInPodium; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    bool PreviewMesh; // 0x6f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6f9[0x7]; // 0x6f9 (Size: 0x7, Type: PaddingProperty)
    UStaticMesh* Mesh; // 0x700 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayerSelected; // 0x708 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_709[0x7]; // 0x709 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_Pad; // 0x710 (Size: 0x8, Type: ObjectProperty)
    uint8_t Debug_OnFriendLFGRequest[0x10]; // 0x718 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UOverlay* Hovered_InputAction; // 0x728 (Size: 0x8, Type: ObjectProperty)
    ULobbyPlayerPadGadgets_C* Gadgets; // 0x730 (Size: 0x8, Type: ObjectProperty)
    UWBP_Lobby_AddPlayerBubble_C* PlayerAdd; // 0x738 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* LastAnimatedPlayerPawn; // 0x740 (Size: 0x8, Type: ObjectProperty)
    bool bAllowPartySuggestions; // 0x748 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_749[0x7]; // 0x749 (Size: 0x7, Type: PaddingProperty)
    double OffsetLobbyAddPlayer; // 0x750 (Size: 0x8, Type: DoubleProperty)
    bool bPlayerPodiumHovered; // 0x758 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_759[0x7]; // 0x759 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_Pad_Light_Ring; // 0x760 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_Top_Light_Ring; // 0x768 (Size: 0x8, Type: ObjectProperty)
    bool FxActive; // 0x770 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_771[0x7]; // 0x771 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_Holo; // 0x778 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* HoloMaterial; // 0x780 (Size: 0x8, Type: ObjectProperty)
    USizeBox* Hovered_WithPlayer_InputAction; // 0x788 (Size: 0x8, Type: ObjectProperty)
    bool NewLobbyLayout; // 0x790 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_791[0x7]; // 0x791 (Size: 0x7, Type: PaddingProperty)
    double LightBrightnessScale; // 0x798 (Size: 0x8, Type: DoubleProperty)
    double TopSpotLight_Brightness; // 0x7a0 (Size: 0x8, Type: DoubleProperty)
    double TopSpotLight_Brightness_Hovered; // 0x7a8 (Size: 0x8, Type: DoubleProperty)
    double RimSpotLight_Brightness; // 0x7b0 (Size: 0x8, Type: DoubleProperty)
    double UnderlightBlueSpot_Brightness; // 0x7b8 (Size: 0x8, Type: DoubleProperty)
    double UnderlightBlueSpot_Brightness_Hovered; // 0x7c0 (Size: 0x8, Type: DoubleProperty)
    double UnderlightBluePoint_Brightness; // 0x7c8 (Size: 0x8, Type: DoubleProperty)
    double UnderlightBluePoint_Brightness_Hovered; // 0x7d0 (Size: 0x8, Type: DoubleProperty)
    bool debugHoveredLighting; // 0x7d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7d9[0x7]; // 0x7d9 (Size: 0x7, Type: PaddingProperty)
    TArray<FMcpVariantChannelInfo> NewVar_0; // 0x7e0 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* HoloMaterialInst; // 0x7f0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_SkipMatchFX; // 0x7f8 (Size: 0x8, Type: ObjectProperty)
    bool isPopulated; // 0x800 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_801[0x7]; // 0x801 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_Pad_FX; // 0x808 (Size: 0x8, Type: ObjectProperty)
    FFortTeamMemberInfo TeamMemberInfo; // 0x810 (Size: 0x220, Type: StructProperty)
    UMaterialInstanceDynamic* MID_ObserverScreen; // 0xa30 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_Observer_Screen_Frame; // 0xa38 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_FakeBlobShadow; // 0xa40 (Size: 0x8, Type: ObjectProperty)
    USizeBox* Hovered_WithPlayer_InputAction_AddFriend; // 0xa48 (Size: 0x8, Type: ObjectProperty)
    FGuid MaterialOverride; // 0xa50 (Size: 0x10, Type: StructProperty)
    FFortPawnMaterialOverrideCopiedParameters Material_Params_to_Copy; // 0xa60 (Size: 0x30, Type: StructProperty)
    uint8_t Material_Override_Flags; // 0xa90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a91[0x7]; // 0xa91 (Size: 0x7, Type: PaddingProperty)
    FVector New_Location; // 0xa98 (Size: 0x18, Type: StructProperty)
    double DefaultNameplateHeight; // 0xab0 (Size: 0x8, Type: DoubleProperty)
    double DefaultSuggestionHeight; // 0xab8 (Size: 0x8, Type: DoubleProperty)
    bool isHoverSoundDisabled; // 0xac0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ac1[0x7]; // 0xac1 (Size: 0x7, Type: PaddingProperty)
    UWBP_Nameplate_C* WBP_Nameplate; // 0xac8 (Size: 0x8, Type: ObjectProperty)
    UWBP_SocialNudge_C* WBP_SocialNudge; // 0xad0 (Size: 0x8, Type: ObjectProperty)
    bool SignInPromptVisible; // 0xad8 (Size: 0x1, Type: BoolProperty)
    bool TakeControlPromptVisible; // 0xad9 (Size: 0x1, Type: BoolProperty)
    bool Multiple_Squads_Populated; // 0xada (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_adb[0x5]; // 0xadb (Size: 0x5, Type: PaddingProperty)
    USoundBase* PlayerSuggesstionSound; // 0xae0 (Size: 0x8, Type: ObjectProperty)
    UFXSystemComponent* Loading_FX_Loop; // 0xae8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle IASLoading_FXDestroy_Delay_Timer; // 0xaf0 (Size: 0x8, Type: StructProperty)

public:
    void OnCurrentContextProductChanged(); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnContextMenuClosed(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnAllLODStreamingComplete(); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    void InitilizeLightValuesFromContext(); // 0x288a61c (Index: 0xa, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void InitializeInputActionRefs(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void InitializeContextEvents(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HasSuggestedSocialUser(bool& HasSuggestedSocialUser); // 0x288a61c (Index: 0x10, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void HandleProductLightingSettings(FGameplayTag& Selection); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual bool HandleNavigationUp(); // 0x288a61c (Index: 0x12, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual bool HandleNavigationDown(); // 0x288a61c (Index: 0x13, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void HandleHoverInputActions(bool& bIsHovered); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EnableHologram(bool& Enabled); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void DestroyLoadingEffects(); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Debug_OnFriendLFGRequest__DelegateSignature(int32_t& PlayerIndex); // 0x288a61c (Index: 0x1c, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ClearPawnMaterialOverride(); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ApplyHoloMaterialOverrideToPawn(); // 0x288a61c (Index: 0x1f, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void StopLobbyAnimation(); // 0x288a61c (Index: 0x22, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSparkleParticlesEnabled(bool& IsEnabled); // 0x288a61c (Index: 0x24, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFNCrew(); // 0x288a61c (Index: 0x25, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFakeBlobShadowVisiblity(bool& Visible); // 0x288a61c (Index: 0x26, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Default_Widget_Component_Heights(); // 0x288a61c (Index: 0x27, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RefreshWidgets(); // 0x288a61c (Index: 0x28, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PlayLobbyAnimation(); // 0x288a61c (Index: 0x2b, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OutroAndDestroyLoadingEffects(); // 0x288a61c (Index: 0x2d, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnTeamMemberStateChanged(FFortTeamMemberInfo& Team_Member_Info); // 0x288a61c (Index: 0x2f, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnSetSuggestionHeight(float& Height); // 0x288a61c (Index: 0x33, Flags: Event|Public|BlueprintEvent)
    virtual void OnSetNameplateHeight(float& Height); // 0x288a61c (Index: 0x34, Flags: Event|Public|BlueprintEvent)
    void OnPartyDataChanged(FFortTeamMemberInfo Member_Info); // 0x288a61c (Index: 0x39, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x41, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void UpdateLightValues(float& PadLightRingOpacityScale, float& PadLightRingConePower, double& LightBrightnessScale); // 0x288a61c (Index: 0x42, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Update_Add_Friend_Button_Interaction_Enabled(bool& IsHovered); // 0x288a61c (Index: 0x43, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UninitializeContextEvents(); // 0x288a61c (Index: 0x44, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void PlayHoverSound(); // 0x288a61c (Index: 0x2c, Flags: Private|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnHovered(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnHeroPawnSetupCompleted(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnGameReadinessChanged(EGameReadiness& GameReadiness); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnDisconnectedToCampaignLobby(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnConnectedToCampaignLobby(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnAvatarChanged(UTexture2D*& AvatarImage, FColor& AvatarBackground, FColor& HighlightColor); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnFrontendCameraChanged(EFrontEndCamera& const NewCamera, EFrontEndCamera& const OldCamera); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x29, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2a, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUnhovered(); // 0x288a61c (Index: 0x2e, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTeamMemberSet(bool& bHasValidTeamMember); // 0x288a61c (Index: 0x30, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTakeControlPromptVisibilityChanged(bool& bVisible, FUIActionBindingHandle& BindingHandle); // 0x288a61c (Index: 0x31, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSignInPromptVisibilityChanged(bool& bVisible, FUIActionBindingHandle& BindingHandle); // 0x288a61c (Index: 0x32, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRemovePreviewActor(); // 0x288a61c (Index: 0x35, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPreviewActorSpawned(); // 0x288a61c (Index: 0x36, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPedestalIsPopulatedChanged(bool& bIsPopulated, bool& bOwningSquadContainsLocalPlayer); // 0x288a61c (Index: 0x37, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPartySuggestionChanged(FUniqueNetIdRepl& SuggestedSocialUserId); // 0x288a61c (Index: 0x38, Flags: Event|Protected|BlueprintEvent)
    virtual void OnOwningPlayerChanged(ULocalPlayer*& const LocalPlayer); // 0x288a61c (Index: 0x3a, Flags: Event|Protected|BlueprintEvent)
    virtual void OnOwningPedestalGroupEstablished(int32_t& SquadIdx, bool& bSquadHasLocalPlayer, bool& bIsPopulated); // 0x288a61c (Index: 0x3b, Flags: Event|Protected|BlueprintEvent)
    virtual void OnNewSquadEstablished(bool& bMultipleSquadsPopulated, bool& bOwningSquadContainsLocalPlayer, const FAthenaTeamDisplayInfo OwningSquadStyle); // 0x288a61c (Index: 0x3c, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnItemClicked(); // 0x288a61c (Index: 0x3f, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsCurrentlyInMatchChanged(bool& bIsInMatch); // 0x288a61c (Index: 0x40, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ATeamMemberPedestal_C) == 0xaf8, "Size mismatch for ATeamMemberPedestal_C");
static_assert(offsetof(ATeamMemberPedestal_C, UberGraphFrame) == 0x610, "Offset mismatch for ATeamMemberPedestal_C::UberGraphFrame");
static_assert(offsetof(ATeamMemberPedestal_C, SM_Lobby_Character_TopSpot) == 0x618, "Offset mismatch for ATeamMemberPedestal_C::SM_Lobby_Character_TopSpot");
static_assert(offsetof(ATeamMemberPedestal_C, SM_Character_ShadowBlob) == 0x620, "Offset mismatch for ATeamMemberPedestal_C::SM_Character_ShadowBlob");
static_assert(offsetof(ATeamMemberPedestal_C, SM_ObserverPlaceholder) == 0x628, "Offset mismatch for ATeamMemberPedestal_C::SM_ObserverPlaceholder");
static_assert(offsetof(ATeamMemberPedestal_C, SM_LobbyFXSkipMatch) == 0x630, "Offset mismatch for ATeamMemberPedestal_C::SM_LobbyFXSkipMatch");
static_assert(offsetof(ATeamMemberPedestal_C, SM_LobbyLightDisc_Floating_FX) == 0x638, "Offset mismatch for ATeamMemberPedestal_C::SM_LobbyLightDisc_Floating_FX");
static_assert(offsetof(ATeamMemberPedestal_C, CharacterPlacement) == 0x640, "Offset mismatch for ATeamMemberPedestal_C::CharacterPlacement");
static_assert(offsetof(ATeamMemberPedestal_C, P_FE_Smoke) == 0x648, "Offset mismatch for ATeamMemberPedestal_C::P_FE_Smoke");
static_assert(offsetof(ATeamMemberPedestal_C, LightsParent) == 0x650, "Offset mismatch for ATeamMemberPedestal_C::LightsParent");
static_assert(offsetof(ATeamMemberPedestal_C, PS_NoPlayer_Sparkle) == 0x658, "Offset mismatch for ATeamMemberPedestal_C::PS_NoPlayer_Sparkle");
static_assert(offsetof(ATeamMemberPedestal_C, PS_NoPlayer_Swirl02) == 0x660, "Offset mismatch for ATeamMemberPedestal_C::PS_NoPlayer_Swirl02");
static_assert(offsetof(ATeamMemberPedestal_C, PS_NoPlayer_Swirl01) == 0x668, "Offset mismatch for ATeamMemberPedestal_C::PS_NoPlayer_Swirl01");
static_assert(offsetof(ATeamMemberPedestal_C, SM_Lobby_Character_Pad_Light_Ring) == 0x670, "Offset mismatch for ATeamMemberPedestal_C::SM_Lobby_Character_Pad_Light_Ring");
static_assert(offsetof(ATeamMemberPedestal_C, SM_Lobby_Character_Pad) == 0x678, "Offset mismatch for ATeamMemberPedestal_C::SM_Lobby_Character_Pad");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBluePoint02) == 0x680, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBluePoint02");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBluePoint01) == 0x688, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBluePoint01");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBlue02) == 0x690, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBlue02");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBlue01) == 0x698, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBlue01");
static_assert(offsetof(ATeamMemberPedestal_C, RimSpotLight) == 0x6a0, "Offset mismatch for ATeamMemberPedestal_C::RimSpotLight");
static_assert(offsetof(ATeamMemberPedestal_C, TopSpotLight) == 0x6a8, "Offset mismatch for ATeamMemberPedestal_C::TopSpotLight");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_2_NewTrack_1_5B2A92484943393ABEA8BF9AE94A7E65) == 0x6b0, "Offset mismatch for ATeamMemberPedestal_C::Timeline_2_NewTrack_1_5B2A92484943393ABEA8BF9AE94A7E65");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_2_NewTrack_0_5B2A92484943393ABEA8BF9AE94A7E65) == 0x6b4, "Offset mismatch for ATeamMemberPedestal_C::Timeline_2_NewTrack_0_5B2A92484943393ABEA8BF9AE94A7E65");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_2__Direction_5B2A92484943393ABEA8BF9AE94A7E65) == 0x6b8, "Offset mismatch for ATeamMemberPedestal_C::Timeline_2__Direction_5B2A92484943393ABEA8BF9AE94A7E65");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_2) == 0x6c0, "Offset mismatch for ATeamMemberPedestal_C::Timeline_2");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_1_NewTrack_0_C7A2C78B4F1CEAE900A2CABA9772C922) == 0x6c8, "Offset mismatch for ATeamMemberPedestal_C::Timeline_1_NewTrack_0_C7A2C78B4F1CEAE900A2CABA9772C922");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_1__Direction_C7A2C78B4F1CEAE900A2CABA9772C922) == 0x6cc, "Offset mismatch for ATeamMemberPedestal_C::Timeline_1__Direction_C7A2C78B4F1CEAE900A2CABA9772C922");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_1) == 0x6d0, "Offset mismatch for ATeamMemberPedestal_C::Timeline_1");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_0_NewTrack_0_29F162B244A0FAE20371E7AE14A584FA) == 0x6d8, "Offset mismatch for ATeamMemberPedestal_C::Timeline_0_NewTrack_0_29F162B244A0FAE20371E7AE14A584FA");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_0__Direction_29F162B244A0FAE20371E7AE14A584FA) == 0x6dc, "Offset mismatch for ATeamMemberPedestal_C::Timeline_0__Direction_29F162B244A0FAE20371E7AE14A584FA");
static_assert(offsetof(ATeamMemberPedestal_C, Timeline_0) == 0x6e0, "Offset mismatch for ATeamMemberPedestal_C::Timeline_0");
static_assert(offsetof(ATeamMemberPedestal_C, FadeInPodium_NewTrack_0_AF4A58DF4085C76AD6B3168E661AB7DD) == 0x6e8, "Offset mismatch for ATeamMemberPedestal_C::FadeInPodium_NewTrack_0_AF4A58DF4085C76AD6B3168E661AB7DD");
static_assert(offsetof(ATeamMemberPedestal_C, FadeInPodium__Direction_AF4A58DF4085C76AD6B3168E661AB7DD) == 0x6ec, "Offset mismatch for ATeamMemberPedestal_C::FadeInPodium__Direction_AF4A58DF4085C76AD6B3168E661AB7DD");
static_assert(offsetof(ATeamMemberPedestal_C, FadeInPodium) == 0x6f0, "Offset mismatch for ATeamMemberPedestal_C::FadeInPodium");
static_assert(offsetof(ATeamMemberPedestal_C, PreviewMesh) == 0x6f8, "Offset mismatch for ATeamMemberPedestal_C::PreviewMesh");
static_assert(offsetof(ATeamMemberPedestal_C, Mesh) == 0x700, "Offset mismatch for ATeamMemberPedestal_C::Mesh");
static_assert(offsetof(ATeamMemberPedestal_C, bIsPlayerSelected) == 0x708, "Offset mismatch for ATeamMemberPedestal_C::bIsPlayerSelected");
static_assert(offsetof(ATeamMemberPedestal_C, MID_Pad) == 0x710, "Offset mismatch for ATeamMemberPedestal_C::MID_Pad");
static_assert(offsetof(ATeamMemberPedestal_C, Debug_OnFriendLFGRequest) == 0x718, "Offset mismatch for ATeamMemberPedestal_C::Debug_OnFriendLFGRequest");
static_assert(offsetof(ATeamMemberPedestal_C, Hovered_InputAction) == 0x728, "Offset mismatch for ATeamMemberPedestal_C::Hovered_InputAction");
static_assert(offsetof(ATeamMemberPedestal_C, Gadgets) == 0x730, "Offset mismatch for ATeamMemberPedestal_C::Gadgets");
static_assert(offsetof(ATeamMemberPedestal_C, PlayerAdd) == 0x738, "Offset mismatch for ATeamMemberPedestal_C::PlayerAdd");
static_assert(offsetof(ATeamMemberPedestal_C, LastAnimatedPlayerPawn) == 0x740, "Offset mismatch for ATeamMemberPedestal_C::LastAnimatedPlayerPawn");
static_assert(offsetof(ATeamMemberPedestal_C, bAllowPartySuggestions) == 0x748, "Offset mismatch for ATeamMemberPedestal_C::bAllowPartySuggestions");
static_assert(offsetof(ATeamMemberPedestal_C, OffsetLobbyAddPlayer) == 0x750, "Offset mismatch for ATeamMemberPedestal_C::OffsetLobbyAddPlayer");
static_assert(offsetof(ATeamMemberPedestal_C, bPlayerPodiumHovered) == 0x758, "Offset mismatch for ATeamMemberPedestal_C::bPlayerPodiumHovered");
static_assert(offsetof(ATeamMemberPedestal_C, MID_Pad_Light_Ring) == 0x760, "Offset mismatch for ATeamMemberPedestal_C::MID_Pad_Light_Ring");
static_assert(offsetof(ATeamMemberPedestal_C, MID_Top_Light_Ring) == 0x768, "Offset mismatch for ATeamMemberPedestal_C::MID_Top_Light_Ring");
static_assert(offsetof(ATeamMemberPedestal_C, FxActive) == 0x770, "Offset mismatch for ATeamMemberPedestal_C::FxActive");
static_assert(offsetof(ATeamMemberPedestal_C, MID_Holo) == 0x778, "Offset mismatch for ATeamMemberPedestal_C::MID_Holo");
static_assert(offsetof(ATeamMemberPedestal_C, HoloMaterial) == 0x780, "Offset mismatch for ATeamMemberPedestal_C::HoloMaterial");
static_assert(offsetof(ATeamMemberPedestal_C, Hovered_WithPlayer_InputAction) == 0x788, "Offset mismatch for ATeamMemberPedestal_C::Hovered_WithPlayer_InputAction");
static_assert(offsetof(ATeamMemberPedestal_C, NewLobbyLayout) == 0x790, "Offset mismatch for ATeamMemberPedestal_C::NewLobbyLayout");
static_assert(offsetof(ATeamMemberPedestal_C, LightBrightnessScale) == 0x798, "Offset mismatch for ATeamMemberPedestal_C::LightBrightnessScale");
static_assert(offsetof(ATeamMemberPedestal_C, TopSpotLight_Brightness) == 0x7a0, "Offset mismatch for ATeamMemberPedestal_C::TopSpotLight_Brightness");
static_assert(offsetof(ATeamMemberPedestal_C, TopSpotLight_Brightness_Hovered) == 0x7a8, "Offset mismatch for ATeamMemberPedestal_C::TopSpotLight_Brightness_Hovered");
static_assert(offsetof(ATeamMemberPedestal_C, RimSpotLight_Brightness) == 0x7b0, "Offset mismatch for ATeamMemberPedestal_C::RimSpotLight_Brightness");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBlueSpot_Brightness) == 0x7b8, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBlueSpot_Brightness");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBlueSpot_Brightness_Hovered) == 0x7c0, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBlueSpot_Brightness_Hovered");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBluePoint_Brightness) == 0x7c8, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBluePoint_Brightness");
static_assert(offsetof(ATeamMemberPedestal_C, UnderlightBluePoint_Brightness_Hovered) == 0x7d0, "Offset mismatch for ATeamMemberPedestal_C::UnderlightBluePoint_Brightness_Hovered");
static_assert(offsetof(ATeamMemberPedestal_C, debugHoveredLighting) == 0x7d8, "Offset mismatch for ATeamMemberPedestal_C::debugHoveredLighting");
static_assert(offsetof(ATeamMemberPedestal_C, NewVar_0) == 0x7e0, "Offset mismatch for ATeamMemberPedestal_C::NewVar_0");
static_assert(offsetof(ATeamMemberPedestal_C, HoloMaterialInst) == 0x7f0, "Offset mismatch for ATeamMemberPedestal_C::HoloMaterialInst");
static_assert(offsetof(ATeamMemberPedestal_C, MID_SkipMatchFX) == 0x7f8, "Offset mismatch for ATeamMemberPedestal_C::MID_SkipMatchFX");
static_assert(offsetof(ATeamMemberPedestal_C, isPopulated) == 0x800, "Offset mismatch for ATeamMemberPedestal_C::isPopulated");
static_assert(offsetof(ATeamMemberPedestal_C, MID_Pad_FX) == 0x808, "Offset mismatch for ATeamMemberPedestal_C::MID_Pad_FX");
static_assert(offsetof(ATeamMemberPedestal_C, TeamMemberInfo) == 0x810, "Offset mismatch for ATeamMemberPedestal_C::TeamMemberInfo");
static_assert(offsetof(ATeamMemberPedestal_C, MID_ObserverScreen) == 0xa30, "Offset mismatch for ATeamMemberPedestal_C::MID_ObserverScreen");
static_assert(offsetof(ATeamMemberPedestal_C, MID_Observer_Screen_Frame) == 0xa38, "Offset mismatch for ATeamMemberPedestal_C::MID_Observer_Screen_Frame");
static_assert(offsetof(ATeamMemberPedestal_C, MID_FakeBlobShadow) == 0xa40, "Offset mismatch for ATeamMemberPedestal_C::MID_FakeBlobShadow");
static_assert(offsetof(ATeamMemberPedestal_C, Hovered_WithPlayer_InputAction_AddFriend) == 0xa48, "Offset mismatch for ATeamMemberPedestal_C::Hovered_WithPlayer_InputAction_AddFriend");
static_assert(offsetof(ATeamMemberPedestal_C, MaterialOverride) == 0xa50, "Offset mismatch for ATeamMemberPedestal_C::MaterialOverride");
static_assert(offsetof(ATeamMemberPedestal_C, Material_Params_to_Copy) == 0xa60, "Offset mismatch for ATeamMemberPedestal_C::Material_Params_to_Copy");
static_assert(offsetof(ATeamMemberPedestal_C, Material_Override_Flags) == 0xa90, "Offset mismatch for ATeamMemberPedestal_C::Material_Override_Flags");
static_assert(offsetof(ATeamMemberPedestal_C, New_Location) == 0xa98, "Offset mismatch for ATeamMemberPedestal_C::New_Location");
static_assert(offsetof(ATeamMemberPedestal_C, DefaultNameplateHeight) == 0xab0, "Offset mismatch for ATeamMemberPedestal_C::DefaultNameplateHeight");
static_assert(offsetof(ATeamMemberPedestal_C, DefaultSuggestionHeight) == 0xab8, "Offset mismatch for ATeamMemberPedestal_C::DefaultSuggestionHeight");
static_assert(offsetof(ATeamMemberPedestal_C, isHoverSoundDisabled) == 0xac0, "Offset mismatch for ATeamMemberPedestal_C::isHoverSoundDisabled");
static_assert(offsetof(ATeamMemberPedestal_C, WBP_Nameplate) == 0xac8, "Offset mismatch for ATeamMemberPedestal_C::WBP_Nameplate");
static_assert(offsetof(ATeamMemberPedestal_C, WBP_SocialNudge) == 0xad0, "Offset mismatch for ATeamMemberPedestal_C::WBP_SocialNudge");
static_assert(offsetof(ATeamMemberPedestal_C, SignInPromptVisible) == 0xad8, "Offset mismatch for ATeamMemberPedestal_C::SignInPromptVisible");
static_assert(offsetof(ATeamMemberPedestal_C, TakeControlPromptVisible) == 0xad9, "Offset mismatch for ATeamMemberPedestal_C::TakeControlPromptVisible");
static_assert(offsetof(ATeamMemberPedestal_C, Multiple_Squads_Populated) == 0xada, "Offset mismatch for ATeamMemberPedestal_C::Multiple_Squads_Populated");
static_assert(offsetof(ATeamMemberPedestal_C, PlayerSuggesstionSound) == 0xae0, "Offset mismatch for ATeamMemberPedestal_C::PlayerSuggesstionSound");
static_assert(offsetof(ATeamMemberPedestal_C, Loading_FX_Loop) == 0xae8, "Offset mismatch for ATeamMemberPedestal_C::Loading_FX_Loop");
static_assert(offsetof(ATeamMemberPedestal_C, IASLoading_FXDestroy_Delay_Timer) == 0xaf0, "Offset mismatch for ATeamMemberPedestal_C::IASLoading_FXDestroy_Delay_Timer");

// Size: 0x401 (Inherited: 0x2d0, Single: 0x131)
class ABP_FrontendBackPlate_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* SM_INvertedSphere; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_FrontendBackPlate_Floor; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh_fog; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    float StopHyperSpeed_BlurControl_740818E745B3B8A476EC3CA79F88917D; // 0x2d8 (Size: 0x4, Type: FloatProperty)
    float StopHyperSpeed_LessBrightFlash_740818E745B3B8A476EC3CA79F88917D; // 0x2dc (Size: 0x4, Type: FloatProperty)
    float StopHyperSpeed_Flash_740818E745B3B8A476EC3CA79F88917D; // 0x2e0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> StopHyperSpeed__Direction_740818E745B3B8A476EC3CA79F88917D; // 0x2e4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2e5[0x3]; // 0x2e5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* StopHyperSpeed; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    float HyperSpace_StarUVScale_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x2f0 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_StarFieldFade_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x2f4 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_StarBloom_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_NumStarLoops_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x2fc (Size: 0x4, Type: FloatProperty)
    float HyperSpace_UVScale_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x300 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_ShowStarLines_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x304 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_bloom_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x308 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_Tunnel_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x30c (Size: 0x4, Type: FloatProperty)
    float HyperSpace_flash_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x310 (Size: 0x4, Type: FloatProperty)
    float HyperSpace_starlines_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x314 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> HyperSpace__Direction_BA3E59114EDDA7E96C3E87A6A52D0356; // 0x318 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_319[0x7]; // 0x319 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* HyperSpace; // 0x320 (Size: 0x8, Type: ObjectProperty)
    float UISpecailEventTransition_UsingUISpecialEventColors_26FA49894E4D045B21346598A2D837C2; // 0x328 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> UISpecailEventTransition__Direction_26FA49894E4D045B21346598A2D837C2; // 0x32c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_32d[0x3]; // 0x32d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* UISpecailEventTransition; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UTexture* BackgroundTexture; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* Material_background; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* Material_Fog; // 0x348 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* BlurMaterial; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* RenderTarget; // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool UpdateFoginRealTime; // 0x360 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_361[0x7]; // 0x361 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_Floor; // 0x368 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* PreBlurMaterial; // 0x370 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* RenderTarget_preblur; // 0x378 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_Background; // 0x380 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_Preblur; // 0x388 (Size: 0x8, Type: ObjectProperty)
    uint8_t BeginRockyRidge[0x10]; // 0x390 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRockyRidgeFinished[0x10]; // 0x3a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t HidePlayer[0x10]; // 0x3b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t RequestLobbyColorChanges[0x10]; // 0x3c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FLinearColor CurrentUIColorScheme; // 0x3d0 (Size: 0x10, Type: StructProperty)
    bool bHasUIColorOverride; // 0x3e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e1[0x7]; // 0x3e1 (Size: 0x7, Type: PaddingProperty)
    TArray<AActor*> FloatingShapes; // 0x3e8 (Size: 0x10, Type: ArrayProperty)
    UAudioComponent* LoopingAudio; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    bool AllowMatchmakingInteraction; // 0x400 (Size: 0x1, Type: BoolProperty)

public:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void OnRockyRidgeFinished__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void MatchmakingEnded(bool& bWasSuccess); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HidePlayer__DelegateSignature(); // 0x288a61c (Index: 0x8, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HasUIColorOverride(bool& HasUIColorOverride); // 0x288a61c (Index: 0x9, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void RequestLobbyColorChanges__DelegateSignature(FLinearColor& Color_A, bool& UseDefaultScheme); // 0x288a61c (Index: 0xa, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HasMatcmakingInteraction(bool& HasInteraction); // 0x288a61c (Index: 0xb, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetUIColorScheme(FLinearColor& ColorScheme, bool& bHasOverride); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void EnteringMatchmaking(); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EnableRealtimeUpdate(bool& Enabled); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x13, Flags: Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateRenderTargetRealtime(); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateRenderTarget(); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSpecialEventUIColorScheme(bool& SetUIPanelColors, FLinearColor& Backing, FLinearColor& Backing_Hover, FLinearColor& Backing_Selection, bool& SetFontColors, FLinearColor& Primary, FLinearColor& Secondary, FLinearColor& Tertiary, FLinearColor& Quaternary); // 0x288a61c (Index: 0x1c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFloatingShapeVisibility(bool& Show); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetBackgroundTexture(UTexture*& InTexture, UMaterialInterface*& InMaterial, UMaterialInterface*& InPreBlurMaterial); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetUIColorScheme(); // 0x288a61c (Index: 0x20, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RequestUIColorScheme(FLinearColor& MainUIColor); // 0x288a61c (Index: 0x22, Flags: Public|BlueprintCallable|BlueprintEvent)
    void BeginRockyRidge__DelegateSignature(); // 0x288a61c (Index: 0x23, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

private:
    void CreateUniqueMaterialName(FString& PostFix, FString& UniqueString); // 0x288a61c (Index: 0x12, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_FrontendBackPlate_C) == 0x401, "Size mismatch for ABP_FrontendBackPlate_C");
static_assert(offsetof(ABP_FrontendBackPlate_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ABP_FrontendBackPlate_C::UberGraphFrame");
static_assert(offsetof(ABP_FrontendBackPlate_C, SM_INvertedSphere) == 0x2b0, "Offset mismatch for ABP_FrontendBackPlate_C::SM_INvertedSphere");
static_assert(offsetof(ABP_FrontendBackPlate_C, SM_FrontendBackPlate_Floor) == 0x2b8, "Offset mismatch for ABP_FrontendBackPlate_C::SM_FrontendBackPlate_Floor");
static_assert(offsetof(ABP_FrontendBackPlate_C, StaticMesh_fog) == 0x2c0, "Offset mismatch for ABP_FrontendBackPlate_C::StaticMesh_fog");
static_assert(offsetof(ABP_FrontendBackPlate_C, StaticMesh) == 0x2c8, "Offset mismatch for ABP_FrontendBackPlate_C::StaticMesh");
static_assert(offsetof(ABP_FrontendBackPlate_C, DefaultSceneRoot) == 0x2d0, "Offset mismatch for ABP_FrontendBackPlate_C::DefaultSceneRoot");
static_assert(offsetof(ABP_FrontendBackPlate_C, StopHyperSpeed_BlurControl_740818E745B3B8A476EC3CA79F88917D) == 0x2d8, "Offset mismatch for ABP_FrontendBackPlate_C::StopHyperSpeed_BlurControl_740818E745B3B8A476EC3CA79F88917D");
static_assert(offsetof(ABP_FrontendBackPlate_C, StopHyperSpeed_LessBrightFlash_740818E745B3B8A476EC3CA79F88917D) == 0x2dc, "Offset mismatch for ABP_FrontendBackPlate_C::StopHyperSpeed_LessBrightFlash_740818E745B3B8A476EC3CA79F88917D");
static_assert(offsetof(ABP_FrontendBackPlate_C, StopHyperSpeed_Flash_740818E745B3B8A476EC3CA79F88917D) == 0x2e0, "Offset mismatch for ABP_FrontendBackPlate_C::StopHyperSpeed_Flash_740818E745B3B8A476EC3CA79F88917D");
static_assert(offsetof(ABP_FrontendBackPlate_C, StopHyperSpeed__Direction_740818E745B3B8A476EC3CA79F88917D) == 0x2e4, "Offset mismatch for ABP_FrontendBackPlate_C::StopHyperSpeed__Direction_740818E745B3B8A476EC3CA79F88917D");
static_assert(offsetof(ABP_FrontendBackPlate_C, StopHyperSpeed) == 0x2e8, "Offset mismatch for ABP_FrontendBackPlate_C::StopHyperSpeed");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_StarUVScale_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x2f0, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_StarUVScale_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_StarFieldFade_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x2f4, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_StarFieldFade_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_StarBloom_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x2f8, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_StarBloom_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_NumStarLoops_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x2fc, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_NumStarLoops_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_UVScale_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x300, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_UVScale_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_ShowStarLines_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x304, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_ShowStarLines_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_bloom_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x308, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_bloom_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_Tunnel_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x30c, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_Tunnel_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_flash_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x310, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_flash_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace_starlines_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x314, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace_starlines_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace__Direction_BA3E59114EDDA7E96C3E87A6A52D0356) == 0x318, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace__Direction_BA3E59114EDDA7E96C3E87A6A52D0356");
static_assert(offsetof(ABP_FrontendBackPlate_C, HyperSpace) == 0x320, "Offset mismatch for ABP_FrontendBackPlate_C::HyperSpace");
static_assert(offsetof(ABP_FrontendBackPlate_C, UISpecailEventTransition_UsingUISpecialEventColors_26FA49894E4D045B21346598A2D837C2) == 0x328, "Offset mismatch for ABP_FrontendBackPlate_C::UISpecailEventTransition_UsingUISpecialEventColors_26FA49894E4D045B21346598A2D837C2");
static_assert(offsetof(ABP_FrontendBackPlate_C, UISpecailEventTransition__Direction_26FA49894E4D045B21346598A2D837C2) == 0x32c, "Offset mismatch for ABP_FrontendBackPlate_C::UISpecailEventTransition__Direction_26FA49894E4D045B21346598A2D837C2");
static_assert(offsetof(ABP_FrontendBackPlate_C, UISpecailEventTransition) == 0x330, "Offset mismatch for ABP_FrontendBackPlate_C::UISpecailEventTransition");
static_assert(offsetof(ABP_FrontendBackPlate_C, BackgroundTexture) == 0x338, "Offset mismatch for ABP_FrontendBackPlate_C::BackgroundTexture");
static_assert(offsetof(ABP_FrontendBackPlate_C, Material_background) == 0x340, "Offset mismatch for ABP_FrontendBackPlate_C::Material_background");
static_assert(offsetof(ABP_FrontendBackPlate_C, Material_Fog) == 0x348, "Offset mismatch for ABP_FrontendBackPlate_C::Material_Fog");
static_assert(offsetof(ABP_FrontendBackPlate_C, BlurMaterial) == 0x350, "Offset mismatch for ABP_FrontendBackPlate_C::BlurMaterial");
static_assert(offsetof(ABP_FrontendBackPlate_C, RenderTarget) == 0x358, "Offset mismatch for ABP_FrontendBackPlate_C::RenderTarget");
static_assert(offsetof(ABP_FrontendBackPlate_C, UpdateFoginRealTime) == 0x360, "Offset mismatch for ABP_FrontendBackPlate_C::UpdateFoginRealTime");
static_assert(offsetof(ABP_FrontendBackPlate_C, MID_Floor) == 0x368, "Offset mismatch for ABP_FrontendBackPlate_C::MID_Floor");
static_assert(offsetof(ABP_FrontendBackPlate_C, PreBlurMaterial) == 0x370, "Offset mismatch for ABP_FrontendBackPlate_C::PreBlurMaterial");
static_assert(offsetof(ABP_FrontendBackPlate_C, RenderTarget_preblur) == 0x378, "Offset mismatch for ABP_FrontendBackPlate_C::RenderTarget_preblur");
static_assert(offsetof(ABP_FrontendBackPlate_C, MID_Background) == 0x380, "Offset mismatch for ABP_FrontendBackPlate_C::MID_Background");
static_assert(offsetof(ABP_FrontendBackPlate_C, MID_Preblur) == 0x388, "Offset mismatch for ABP_FrontendBackPlate_C::MID_Preblur");
static_assert(offsetof(ABP_FrontendBackPlate_C, BeginRockyRidge) == 0x390, "Offset mismatch for ABP_FrontendBackPlate_C::BeginRockyRidge");
static_assert(offsetof(ABP_FrontendBackPlate_C, OnRockyRidgeFinished) == 0x3a0, "Offset mismatch for ABP_FrontendBackPlate_C::OnRockyRidgeFinished");
static_assert(offsetof(ABP_FrontendBackPlate_C, HidePlayer) == 0x3b0, "Offset mismatch for ABP_FrontendBackPlate_C::HidePlayer");
static_assert(offsetof(ABP_FrontendBackPlate_C, RequestLobbyColorChanges) == 0x3c0, "Offset mismatch for ABP_FrontendBackPlate_C::RequestLobbyColorChanges");
static_assert(offsetof(ABP_FrontendBackPlate_C, CurrentUIColorScheme) == 0x3d0, "Offset mismatch for ABP_FrontendBackPlate_C::CurrentUIColorScheme");
static_assert(offsetof(ABP_FrontendBackPlate_C, bHasUIColorOverride) == 0x3e0, "Offset mismatch for ABP_FrontendBackPlate_C::bHasUIColorOverride");
static_assert(offsetof(ABP_FrontendBackPlate_C, FloatingShapes) == 0x3e8, "Offset mismatch for ABP_FrontendBackPlate_C::FloatingShapes");
static_assert(offsetof(ABP_FrontendBackPlate_C, LoopingAudio) == 0x3f8, "Offset mismatch for ABP_FrontendBackPlate_C::LoopingAudio");
static_assert(offsetof(ABP_FrontendBackPlate_C, AllowMatchmakingInteraction) == 0x400, "Offset mismatch for ABP_FrontendBackPlate_C::AllowMatchmakingInteraction");

// Size: 0x308 (Inherited: 0x5b0, Single: 0xfffffd58)
class APedestalGroup_Background_C : public AAthenaSquadPedestalGroup
{
public:
    UChildActorComponent* CAC_Pedestal4; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal3; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal2; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal1; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal0; // 0x300 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(APedestalGroup_Background_C) == 0x308, "Size mismatch for APedestalGroup_Background_C");
static_assert(offsetof(APedestalGroup_Background_C, CAC_Pedestal4) == 0x2e0, "Offset mismatch for APedestalGroup_Background_C::CAC_Pedestal4");
static_assert(offsetof(APedestalGroup_Background_C, CAC_Pedestal3) == 0x2e8, "Offset mismatch for APedestalGroup_Background_C::CAC_Pedestal3");
static_assert(offsetof(APedestalGroup_Background_C, CAC_Pedestal2) == 0x2f0, "Offset mismatch for APedestalGroup_Background_C::CAC_Pedestal2");
static_assert(offsetof(APedestalGroup_Background_C, CAC_Pedestal1) == 0x2f8, "Offset mismatch for APedestalGroup_Background_C::CAC_Pedestal1");
static_assert(offsetof(APedestalGroup_Background_C, CAC_Pedestal0) == 0x300, "Offset mismatch for APedestalGroup_Background_C::CAC_Pedestal0");

// Size: 0x308 (Inherited: 0x5b0, Single: 0xfffffd58)
class APedestalGroup_Primary_C : public AAthenaSquadPedestalGroup
{
public:
    UChildActorComponent* CAC_Pedestal4; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal3; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal2; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal1; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* CAC_Pedestal0; // 0x300 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(APedestalGroup_Primary_C) == 0x308, "Size mismatch for APedestalGroup_Primary_C");
static_assert(offsetof(APedestalGroup_Primary_C, CAC_Pedestal4) == 0x2e0, "Offset mismatch for APedestalGroup_Primary_C::CAC_Pedestal4");
static_assert(offsetof(APedestalGroup_Primary_C, CAC_Pedestal3) == 0x2e8, "Offset mismatch for APedestalGroup_Primary_C::CAC_Pedestal3");
static_assert(offsetof(APedestalGroup_Primary_C, CAC_Pedestal2) == 0x2f0, "Offset mismatch for APedestalGroup_Primary_C::CAC_Pedestal2");
static_assert(offsetof(APedestalGroup_Primary_C, CAC_Pedestal1) == 0x2f8, "Offset mismatch for APedestalGroup_Primary_C::CAC_Pedestal1");
static_assert(offsetof(APedestalGroup_Primary_C, CAC_Pedestal0) == 0x300, "Offset mismatch for APedestalGroup_Primary_C::CAC_Pedestal0");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UI_FrontendBackplateMatchmakingInteraction_C : public UInterface
{
public:

public:
    void MatchmakingEnded(bool& bWasSuccess); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HasMatcmakingInteraction(bool& HasInteraction); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void EnteringMatchmaking(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UI_FrontendBackplateMatchmakingInteraction_C) == 0x28, "Size mismatch for UI_FrontendBackplateMatchmakingInteraction_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UVaultWorldInterface_C : public UInterface
{
public:

public:
    void ToggleBackgroundText(bool& DisplayText); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UVaultWorldInterface_C) == 0x28, "Size mismatch for UVaultWorldInterface_C");

// Size: 0x468 (Inherited: 0x9c1, Single: 0xfffffaa7)
class ABattlePassVaultWorld_C : public AVaultWorld_C
{
public:
    uint8_t Pad_381[0x7]; // 0x381 (Size: 0x7, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x388 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* floor; // 0x390 (Size: 0x8, Type: ObjectProperty)
    float TransitionForward_FX_Transition_Fade_46DACBD74D0A8B2278950785C007984A; // 0x398 (Size: 0x4, Type: FloatProperty)
    float TransitionForward_Fade_46DACBD74D0A8B2278950785C007984A; // 0x39c (Size: 0x4, Type: FloatProperty)
    float TransitionForward_Forward_46DACBD74D0A8B2278950785C007984A; // 0x3a0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TransitionForward__Direction_46DACBD74D0A8B2278950785C007984A; // 0x3a4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3a5[0x3]; // 0x3a5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TransitionForward; // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    float BackgroundIntenstiy_Intensity_8C51F99C4026F0204F2184AD9661CD23; // 0x3b0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> BackgroundIntenstiy__Direction_8C51F99C4026F0204F2184AD9661CD23; // 0x3b4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3b5[0x3]; // 0x3b5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* BackgroundIntenstiy; // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    float ItemDetailsIntensity_TextureIntensity_1EC6205345E5A708DA53B5A9449F1700; // 0x3c0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ItemDetailsIntensity__Direction_1EC6205345E5A708DA53B5A9449F1700; // 0x3c4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3c5[0x3]; // 0x3c5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ItemDetailsIntensity; // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    float Background_Effects_SetStreaks_50767E4640E86998EC96B7B2D57E5E27; // 0x3d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Background_Effects__Direction_50767E4640E86998EC96B7B2D57E5E27; // 0x3d4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3d5[0x3]; // 0x3d5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Background_Effects; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    float IconDissolve_NewTrack_0_983A4DA644BE5CFAED0C378063FC66FC; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> IconDissolve__Direction_983A4DA644BE5CFAED0C378063FC66FC; // 0x3e4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3e5[0x3]; // 0x3e5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* IconDissolve; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    float ItemDetails_Icon_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781; // 0x3f0 (Size: 0x4, Type: FloatProperty)
    float ItemDetails_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781; // 0x3f4 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ItemDetails__Direction_F4D1C4E246C708FA1F53EDA5A3FEE781; // 0x3f8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3f9[0x7]; // 0x3f9 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* ItemDetails; // 0x400 (Size: 0x8, Type: ObjectProperty)
    float Floor_Visibility_FloorMask_CE7E338346E82397065B65AA77823F50; // 0x408 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Floor_Visibility__Direction_CE7E338346E82397065B65AA77823F50; // 0x40c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_40d[0x3]; // 0x40d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Floor_Visibility; // 0x410 (Size: 0x8, Type: ObjectProperty)
    float TransitionBackward_fx_Transition_fade_7073CD0840227233D3A64795A5A1B1B8; // 0x418 (Size: 0x4, Type: FloatProperty)
    float TransitionBackward_Fade_7073CD0840227233D3A64795A5A1B1B8; // 0x41c (Size: 0x4, Type: FloatProperty)
    float TransitionBackward_Backward_7073CD0840227233D3A64795A5A1B1B8; // 0x420 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TransitionBackward__Direction_7073CD0840227233D3A64795A5A1B1B8; // 0x424 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_425[0x3]; // 0x425 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* TransitionBackward; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* FloorMI; // 0x430 (Size: 0x8, Type: ObjectProperty)
    double BG_Intensity_Max; // 0x438 (Size: 0x8, Type: DoubleProperty)
    double BG_Intensity_Mid; // 0x440 (Size: 0x8, Type: DoubleProperty)
    UMaterialInstanceDynamic* FloorMID; // 0x448 (Size: 0x8, Type: ObjectProperty)
    double BG_Intensity_Min; // 0x450 (Size: 0x8, Type: DoubleProperty)
    bool bIsTransitioning; // 0x458 (Size: 0x1, Type: BoolProperty)
    uint8_t Intensity_Transition; // 0x459 (Size: 0x1, Type: EnumProperty)
    bool bIsPageA_Max; // 0x45a (Size: 0x1, Type: BoolProperty)
    bool bIsPageB_Max; // 0x45b (Size: 0x1, Type: BoolProperty)
    float PageA_X_Offset; // 0x45c (Size: 0x4, Type: FloatProperty)
    float PageB_X_Offset; // 0x460 (Size: 0x4, Type: FloatProperty)
    float X_Offset_Anim_Distance; // 0x464 (Size: 0x4, Type: FloatProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void TransitionBackgroundForward(double& Forward, double& Fade, double& FXTransitionFade, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TransitionBackgroundBackward(double& Backward, double& Fade, double& FXTransitionFade, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetupBackgroundMaterial(UTexture2D* TextureBackground, FVaultWorldBackgroundData BackgroundInfo, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Set_Backgrounds_Scalar_Value(FName& Param, double& FloatValue); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PageTransitionIntensityUpdate(UMaterialInstanceDynamic*& MID_Background, UMaterialInstanceDynamic*& MID_Floor); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnIntensityChange(bool& bToLowIntensity); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintEvent)
    void AssignMaterials(AStaticMeshActor*& TargetBackground); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionItemDetails(bool& const bShowItemDetails); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionBackground(EVaultWorldTransitionDirection& TransitionDirection, EBackgroundIntensityLevel& IntensityTransition); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetupTextureBackground(UTexture2D*& const LoadedBackgroundTexture, const FVaultWorldBackgroundData BackgroundInfo); // 0x288a61c (Index: 0xa, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnSetupMaterialBackground(UMaterialInterface*& const LoadedBackgroundMaterial, const FVaultWorldBackgroundData BackgroundInfo); // 0x288a61c (Index: 0xb, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnNewSceneBackgroundChildActor(AFortStaticMeshActor*& NewActor); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateDisplay(bool& bShowFloor, bool& bShowEffects, EFortItemType& ItemType); // 0x288a61c (Index: 0x1f, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABattlePassVaultWorld_C) == 0x468, "Size mismatch for ABattlePassVaultWorld_C");
static_assert(offsetof(ABattlePassVaultWorld_C, UberGraphFrame) == 0x388, "Offset mismatch for ABattlePassVaultWorld_C::UberGraphFrame");
static_assert(offsetof(ABattlePassVaultWorld_C, floor) == 0x390, "Offset mismatch for ABattlePassVaultWorld_C::floor");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionForward_FX_Transition_Fade_46DACBD74D0A8B2278950785C007984A) == 0x398, "Offset mismatch for ABattlePassVaultWorld_C::TransitionForward_FX_Transition_Fade_46DACBD74D0A8B2278950785C007984A");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionForward_Fade_46DACBD74D0A8B2278950785C007984A) == 0x39c, "Offset mismatch for ABattlePassVaultWorld_C::TransitionForward_Fade_46DACBD74D0A8B2278950785C007984A");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionForward_Forward_46DACBD74D0A8B2278950785C007984A) == 0x3a0, "Offset mismatch for ABattlePassVaultWorld_C::TransitionForward_Forward_46DACBD74D0A8B2278950785C007984A");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionForward__Direction_46DACBD74D0A8B2278950785C007984A) == 0x3a4, "Offset mismatch for ABattlePassVaultWorld_C::TransitionForward__Direction_46DACBD74D0A8B2278950785C007984A");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionForward) == 0x3a8, "Offset mismatch for ABattlePassVaultWorld_C::TransitionForward");
static_assert(offsetof(ABattlePassVaultWorld_C, BackgroundIntenstiy_Intensity_8C51F99C4026F0204F2184AD9661CD23) == 0x3b0, "Offset mismatch for ABattlePassVaultWorld_C::BackgroundIntenstiy_Intensity_8C51F99C4026F0204F2184AD9661CD23");
static_assert(offsetof(ABattlePassVaultWorld_C, BackgroundIntenstiy__Direction_8C51F99C4026F0204F2184AD9661CD23) == 0x3b4, "Offset mismatch for ABattlePassVaultWorld_C::BackgroundIntenstiy__Direction_8C51F99C4026F0204F2184AD9661CD23");
static_assert(offsetof(ABattlePassVaultWorld_C, BackgroundIntenstiy) == 0x3b8, "Offset mismatch for ABattlePassVaultWorld_C::BackgroundIntenstiy");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetailsIntensity_TextureIntensity_1EC6205345E5A708DA53B5A9449F1700) == 0x3c0, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetailsIntensity_TextureIntensity_1EC6205345E5A708DA53B5A9449F1700");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetailsIntensity__Direction_1EC6205345E5A708DA53B5A9449F1700) == 0x3c4, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetailsIntensity__Direction_1EC6205345E5A708DA53B5A9449F1700");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetailsIntensity) == 0x3c8, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetailsIntensity");
static_assert(offsetof(ABattlePassVaultWorld_C, Background_Effects_SetStreaks_50767E4640E86998EC96B7B2D57E5E27) == 0x3d0, "Offset mismatch for ABattlePassVaultWorld_C::Background_Effects_SetStreaks_50767E4640E86998EC96B7B2D57E5E27");
static_assert(offsetof(ABattlePassVaultWorld_C, Background_Effects__Direction_50767E4640E86998EC96B7B2D57E5E27) == 0x3d4, "Offset mismatch for ABattlePassVaultWorld_C::Background_Effects__Direction_50767E4640E86998EC96B7B2D57E5E27");
static_assert(offsetof(ABattlePassVaultWorld_C, Background_Effects) == 0x3d8, "Offset mismatch for ABattlePassVaultWorld_C::Background_Effects");
static_assert(offsetof(ABattlePassVaultWorld_C, IconDissolve_NewTrack_0_983A4DA644BE5CFAED0C378063FC66FC) == 0x3e0, "Offset mismatch for ABattlePassVaultWorld_C::IconDissolve_NewTrack_0_983A4DA644BE5CFAED0C378063FC66FC");
static_assert(offsetof(ABattlePassVaultWorld_C, IconDissolve__Direction_983A4DA644BE5CFAED0C378063FC66FC) == 0x3e4, "Offset mismatch for ABattlePassVaultWorld_C::IconDissolve__Direction_983A4DA644BE5CFAED0C378063FC66FC");
static_assert(offsetof(ABattlePassVaultWorld_C, IconDissolve) == 0x3e8, "Offset mismatch for ABattlePassVaultWorld_C::IconDissolve");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetails_Icon_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781) == 0x3f0, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetails_Icon_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetails_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781) == 0x3f4, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetails_X_Offset_F4D1C4E246C708FA1F53EDA5A3FEE781");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetails__Direction_F4D1C4E246C708FA1F53EDA5A3FEE781) == 0x3f8, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetails__Direction_F4D1C4E246C708FA1F53EDA5A3FEE781");
static_assert(offsetof(ABattlePassVaultWorld_C, ItemDetails) == 0x400, "Offset mismatch for ABattlePassVaultWorld_C::ItemDetails");
static_assert(offsetof(ABattlePassVaultWorld_C, Floor_Visibility_FloorMask_CE7E338346E82397065B65AA77823F50) == 0x408, "Offset mismatch for ABattlePassVaultWorld_C::Floor_Visibility_FloorMask_CE7E338346E82397065B65AA77823F50");
static_assert(offsetof(ABattlePassVaultWorld_C, Floor_Visibility__Direction_CE7E338346E82397065B65AA77823F50) == 0x40c, "Offset mismatch for ABattlePassVaultWorld_C::Floor_Visibility__Direction_CE7E338346E82397065B65AA77823F50");
static_assert(offsetof(ABattlePassVaultWorld_C, Floor_Visibility) == 0x410, "Offset mismatch for ABattlePassVaultWorld_C::Floor_Visibility");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionBackward_fx_Transition_fade_7073CD0840227233D3A64795A5A1B1B8) == 0x418, "Offset mismatch for ABattlePassVaultWorld_C::TransitionBackward_fx_Transition_fade_7073CD0840227233D3A64795A5A1B1B8");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionBackward_Fade_7073CD0840227233D3A64795A5A1B1B8) == 0x41c, "Offset mismatch for ABattlePassVaultWorld_C::TransitionBackward_Fade_7073CD0840227233D3A64795A5A1B1B8");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionBackward_Backward_7073CD0840227233D3A64795A5A1B1B8) == 0x420, "Offset mismatch for ABattlePassVaultWorld_C::TransitionBackward_Backward_7073CD0840227233D3A64795A5A1B1B8");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionBackward__Direction_7073CD0840227233D3A64795A5A1B1B8) == 0x424, "Offset mismatch for ABattlePassVaultWorld_C::TransitionBackward__Direction_7073CD0840227233D3A64795A5A1B1B8");
static_assert(offsetof(ABattlePassVaultWorld_C, TransitionBackward) == 0x428, "Offset mismatch for ABattlePassVaultWorld_C::TransitionBackward");
static_assert(offsetof(ABattlePassVaultWorld_C, FloorMI) == 0x430, "Offset mismatch for ABattlePassVaultWorld_C::FloorMI");
static_assert(offsetof(ABattlePassVaultWorld_C, BG_Intensity_Max) == 0x438, "Offset mismatch for ABattlePassVaultWorld_C::BG_Intensity_Max");
static_assert(offsetof(ABattlePassVaultWorld_C, BG_Intensity_Mid) == 0x440, "Offset mismatch for ABattlePassVaultWorld_C::BG_Intensity_Mid");
static_assert(offsetof(ABattlePassVaultWorld_C, FloorMID) == 0x448, "Offset mismatch for ABattlePassVaultWorld_C::FloorMID");
static_assert(offsetof(ABattlePassVaultWorld_C, BG_Intensity_Min) == 0x450, "Offset mismatch for ABattlePassVaultWorld_C::BG_Intensity_Min");
static_assert(offsetof(ABattlePassVaultWorld_C, bIsTransitioning) == 0x458, "Offset mismatch for ABattlePassVaultWorld_C::bIsTransitioning");
static_assert(offsetof(ABattlePassVaultWorld_C, Intensity_Transition) == 0x459, "Offset mismatch for ABattlePassVaultWorld_C::Intensity_Transition");
static_assert(offsetof(ABattlePassVaultWorld_C, bIsPageA_Max) == 0x45a, "Offset mismatch for ABattlePassVaultWorld_C::bIsPageA_Max");
static_assert(offsetof(ABattlePassVaultWorld_C, bIsPageB_Max) == 0x45b, "Offset mismatch for ABattlePassVaultWorld_C::bIsPageB_Max");
static_assert(offsetof(ABattlePassVaultWorld_C, PageA_X_Offset) == 0x45c, "Offset mismatch for ABattlePassVaultWorld_C::PageA_X_Offset");
static_assert(offsetof(ABattlePassVaultWorld_C, PageB_X_Offset) == 0x460, "Offset mismatch for ABattlePassVaultWorld_C::PageB_X_Offset");
static_assert(offsetof(ABattlePassVaultWorld_C, X_Offset_Anim_Distance) == 0x464, "Offset mismatch for ABattlePassVaultWorld_C::X_Offset_Anim_Distance");

// Size: 0x378 (Inherited: 0x2d0, Single: 0xa8)
class AVaultCharacterPlacementHelper_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* floor; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* CharacterPlacement; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Root; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c8[0x8]; // 0x2c8 (Size: 0x8, Type: PaddingProperty)
    FTransform OriginalTransform; // 0x2d0 (Size: 0x60, Type: StructProperty)
    FVector OffsetTranslate; // 0x330 (Size: 0x18, Type: StructProperty)
    FRotator OffsetRotate; // 0x348 (Size: 0x18, Type: StructProperty)
    bool Athena; // 0x360 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_361[0x7]; // 0x361 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnZoomLevelUpdated[0x10]; // 0x368 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdatePosition_For_Camera(EFrontEndCamera& FrontendCamera); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnZoomLevelUpdated__DelegateSignature(double& CurrentZoomLevel); // 0x288a61c (Index: 0x7, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AVaultCharacterPlacementHelper_C) == 0x378, "Size mismatch for AVaultCharacterPlacementHelper_C");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, UberGraphFrame) == 0x2a8, "Offset mismatch for AVaultCharacterPlacementHelper_C::UberGraphFrame");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, floor) == 0x2b0, "Offset mismatch for AVaultCharacterPlacementHelper_C::floor");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, CharacterPlacement) == 0x2b8, "Offset mismatch for AVaultCharacterPlacementHelper_C::CharacterPlacement");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, Root) == 0x2c0, "Offset mismatch for AVaultCharacterPlacementHelper_C::Root");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, OriginalTransform) == 0x2d0, "Offset mismatch for AVaultCharacterPlacementHelper_C::OriginalTransform");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, OffsetTranslate) == 0x330, "Offset mismatch for AVaultCharacterPlacementHelper_C::OffsetTranslate");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, OffsetRotate) == 0x348, "Offset mismatch for AVaultCharacterPlacementHelper_C::OffsetRotate");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, Athena) == 0x360, "Offset mismatch for AVaultCharacterPlacementHelper_C::Athena");
static_assert(offsetof(AVaultCharacterPlacementHelper_C, OnZoomLevelUpdated) == 0x368, "Offset mismatch for AVaultCharacterPlacementHelper_C::OnZoomLevelUpdated");

// Size: 0x5e0 (Inherited: 0xb80, Single: 0xfffffa60)
class AItemPreviewSideSwap_C : public AItemPreviewSwapper
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x460 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess_Mobile; // 0x468 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightLowMobile; // 0x470 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLight; // 0x478 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLight_LOWPC; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UPostProcessComponent* PostProcess_LOWPC; // 0x490 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLight_LOWPC; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* DirectionalLightMobile; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DirectionalLights; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* GenericLighting; // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    float Timeline_1_RotationOffsetLerp_F81FDC884C74C17EBF78B0B928138870; // 0x4b8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_1__Direction_F81FDC884C74C17EBF78B0B928138870; // 0x4bc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4bd[0x3]; // 0x4bd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_1; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_ZoomLevel_F92CF88A423F8300F5A67CB744A0DA45; // 0x4c8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_F92CF88A423F8300F5A67CB744A0DA45; // 0x4cc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4cd[0x3]; // 0x4cd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_0; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    FVector MoveOutRight_Location_89D9209D4024EFFF08326CBAE53949F1; // 0x4d8 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETimelineDirection> MoveOutRight__Direction_89D9209D4024EFFF08326CBAE53949F1; // 0x4f0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4f1[0x7]; // 0x4f1 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* MoveOutRight; // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    FVector MoveInRight_Location_3FE1D8EB4B6BCBA0C3D120B521728FCE; // 0x500 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETimelineDirection> MoveInRight__Direction_3FE1D8EB4B6BCBA0C3D120B521728FCE; // 0x518 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_519[0x7]; // 0x519 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* MoveInRight; // 0x520 (Size: 0x8, Type: ObjectProperty)
    FVector MoveInLeft_Location_B344DA1A46B3CB2F19E2E0A1F7E36A47; // 0x528 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETimelineDirection> MoveInLeft__Direction_B344DA1A46B3CB2F19E2E0A1F7E36A47; // 0x540 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_541[0x7]; // 0x541 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* MoveInLeft; // 0x548 (Size: 0x8, Type: ObjectProperty)
    FVector MoveOutLeft_Location_6890893D4037128B5CB3B2AE9A4AE0A1; // 0x550 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETimelineDirection> MoveOutLeft__Direction_6890893D4037128B5CB3B2AE9A4AE0A1; // 0x568 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_569[0x7]; // 0x569 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* MoveOutLeft; // 0x570 (Size: 0x8, Type: ObjectProperty)
    bool DebugMobile_Lighting; // 0x578 (Size: 0x1, Type: BoolProperty)
    bool DebugLightingPC; // 0x579 (Size: 0x1, Type: BoolProperty)
    bool IsActive; // 0x57a (Size: 0x1, Type: BoolProperty)
    bool AlwaysOn; // 0x57b (Size: 0x1, Type: BoolProperty)
    bool DebugLighting_LOWDetailPC; // 0x57c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_57d[0x3]; // 0x57d (Size: 0x3, Type: PaddingProperty)
    uint8_t On_New_Item_Spawned[0x10]; // 0x580 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double CurrentZoomLevel; // 0x590 (Size: 0x8, Type: DoubleProperty)
    double TargetZoomLevel; // 0x598 (Size: 0x8, Type: DoubleProperty)
    FRotator TargetRotationOffset; // 0x5a0 (Size: 0x18, Type: StructProperty)
    FRotator OrigRotationOffset; // 0x5b8 (Size: 0x18, Type: StructProperty)
    UFortAccountItemDefinition* Primary_Requested_Item; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UFortAccountItemDefinition* Previous_Requested_Item; // 0x5d8 (Size: 0x8, Type: ObjectProperty)

public:
    void SwitchPCLighting_LOWDetail(bool& Visibility); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchPCLighting(bool& Visibility); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwitchMobileLighting(bool& Visibility); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void LightControl(bool& Active); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void On_New_Item_Spawned__DelegateSignature(bool& Should_Show_Floor); // 0x288a61c (Index: 0x13, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTargetZoomLevelSet(float& TargetZoomLevel); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTargetRotationOffsetSet(const FRotator TargetRotationOffset); // 0x288a61c (Index: 0xc, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnReadyToSwap(UFortAccountItemDefinition*& const PrimaryRequestedItem, const FSceneTransitionOptions Options); // 0x288a61c (Index: 0xd, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnNewSceneRequested(UFortAccountItemDefinition*& const PrimaryRequestedItem, const FSceneTransitionOptions TransitionOptions); // 0x288a61c (Index: 0x12, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AItemPreviewSideSwap_C) == 0x5e0, "Size mismatch for AItemPreviewSideSwap_C");
static_assert(offsetof(AItemPreviewSideSwap_C, UberGraphFrame) == 0x460, "Offset mismatch for AItemPreviewSideSwap_C::UberGraphFrame");
static_assert(offsetof(AItemPreviewSideSwap_C, PostProcess_Mobile) == 0x468, "Offset mismatch for AItemPreviewSideSwap_C::PostProcess_Mobile");
static_assert(offsetof(AItemPreviewSideSwap_C, SkyLightLowMobile) == 0x470, "Offset mismatch for AItemPreviewSideSwap_C::SkyLightLowMobile");
static_assert(offsetof(AItemPreviewSideSwap_C, SkyLight) == 0x478, "Offset mismatch for AItemPreviewSideSwap_C::SkyLight");
static_assert(offsetof(AItemPreviewSideSwap_C, SkyLight_LOWPC) == 0x480, "Offset mismatch for AItemPreviewSideSwap_C::SkyLight_LOWPC");
static_assert(offsetof(AItemPreviewSideSwap_C, Arrow) == 0x488, "Offset mismatch for AItemPreviewSideSwap_C::Arrow");
static_assert(offsetof(AItemPreviewSideSwap_C, PostProcess_LOWPC) == 0x490, "Offset mismatch for AItemPreviewSideSwap_C::PostProcess_LOWPC");
static_assert(offsetof(AItemPreviewSideSwap_C, DirectionalLight_LOWPC) == 0x498, "Offset mismatch for AItemPreviewSideSwap_C::DirectionalLight_LOWPC");
static_assert(offsetof(AItemPreviewSideSwap_C, DirectionalLightMobile) == 0x4a0, "Offset mismatch for AItemPreviewSideSwap_C::DirectionalLightMobile");
static_assert(offsetof(AItemPreviewSideSwap_C, DirectionalLights) == 0x4a8, "Offset mismatch for AItemPreviewSideSwap_C::DirectionalLights");
static_assert(offsetof(AItemPreviewSideSwap_C, GenericLighting) == 0x4b0, "Offset mismatch for AItemPreviewSideSwap_C::GenericLighting");
static_assert(offsetof(AItemPreviewSideSwap_C, Timeline_1_RotationOffsetLerp_F81FDC884C74C17EBF78B0B928138870) == 0x4b8, "Offset mismatch for AItemPreviewSideSwap_C::Timeline_1_RotationOffsetLerp_F81FDC884C74C17EBF78B0B928138870");
static_assert(offsetof(AItemPreviewSideSwap_C, Timeline_1__Direction_F81FDC884C74C17EBF78B0B928138870) == 0x4bc, "Offset mismatch for AItemPreviewSideSwap_C::Timeline_1__Direction_F81FDC884C74C17EBF78B0B928138870");
static_assert(offsetof(AItemPreviewSideSwap_C, Timeline_1) == 0x4c0, "Offset mismatch for AItemPreviewSideSwap_C::Timeline_1");
static_assert(offsetof(AItemPreviewSideSwap_C, Timeline_0_ZoomLevel_F92CF88A423F8300F5A67CB744A0DA45) == 0x4c8, "Offset mismatch for AItemPreviewSideSwap_C::Timeline_0_ZoomLevel_F92CF88A423F8300F5A67CB744A0DA45");
static_assert(offsetof(AItemPreviewSideSwap_C, Timeline_0__Direction_F92CF88A423F8300F5A67CB744A0DA45) == 0x4cc, "Offset mismatch for AItemPreviewSideSwap_C::Timeline_0__Direction_F92CF88A423F8300F5A67CB744A0DA45");
static_assert(offsetof(AItemPreviewSideSwap_C, Timeline_0) == 0x4d0, "Offset mismatch for AItemPreviewSideSwap_C::Timeline_0");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveOutRight_Location_89D9209D4024EFFF08326CBAE53949F1) == 0x4d8, "Offset mismatch for AItemPreviewSideSwap_C::MoveOutRight_Location_89D9209D4024EFFF08326CBAE53949F1");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveOutRight__Direction_89D9209D4024EFFF08326CBAE53949F1) == 0x4f0, "Offset mismatch for AItemPreviewSideSwap_C::MoveOutRight__Direction_89D9209D4024EFFF08326CBAE53949F1");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveOutRight) == 0x4f8, "Offset mismatch for AItemPreviewSideSwap_C::MoveOutRight");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveInRight_Location_3FE1D8EB4B6BCBA0C3D120B521728FCE) == 0x500, "Offset mismatch for AItemPreviewSideSwap_C::MoveInRight_Location_3FE1D8EB4B6BCBA0C3D120B521728FCE");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveInRight__Direction_3FE1D8EB4B6BCBA0C3D120B521728FCE) == 0x518, "Offset mismatch for AItemPreviewSideSwap_C::MoveInRight__Direction_3FE1D8EB4B6BCBA0C3D120B521728FCE");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveInRight) == 0x520, "Offset mismatch for AItemPreviewSideSwap_C::MoveInRight");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveInLeft_Location_B344DA1A46B3CB2F19E2E0A1F7E36A47) == 0x528, "Offset mismatch for AItemPreviewSideSwap_C::MoveInLeft_Location_B344DA1A46B3CB2F19E2E0A1F7E36A47");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveInLeft__Direction_B344DA1A46B3CB2F19E2E0A1F7E36A47) == 0x540, "Offset mismatch for AItemPreviewSideSwap_C::MoveInLeft__Direction_B344DA1A46B3CB2F19E2E0A1F7E36A47");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveInLeft) == 0x548, "Offset mismatch for AItemPreviewSideSwap_C::MoveInLeft");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveOutLeft_Location_6890893D4037128B5CB3B2AE9A4AE0A1) == 0x550, "Offset mismatch for AItemPreviewSideSwap_C::MoveOutLeft_Location_6890893D4037128B5CB3B2AE9A4AE0A1");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveOutLeft__Direction_6890893D4037128B5CB3B2AE9A4AE0A1) == 0x568, "Offset mismatch for AItemPreviewSideSwap_C::MoveOutLeft__Direction_6890893D4037128B5CB3B2AE9A4AE0A1");
static_assert(offsetof(AItemPreviewSideSwap_C, MoveOutLeft) == 0x570, "Offset mismatch for AItemPreviewSideSwap_C::MoveOutLeft");
static_assert(offsetof(AItemPreviewSideSwap_C, DebugMobile_Lighting) == 0x578, "Offset mismatch for AItemPreviewSideSwap_C::DebugMobile_Lighting");
static_assert(offsetof(AItemPreviewSideSwap_C, DebugLightingPC) == 0x579, "Offset mismatch for AItemPreviewSideSwap_C::DebugLightingPC");
static_assert(offsetof(AItemPreviewSideSwap_C, IsActive) == 0x57a, "Offset mismatch for AItemPreviewSideSwap_C::IsActive");
static_assert(offsetof(AItemPreviewSideSwap_C, AlwaysOn) == 0x57b, "Offset mismatch for AItemPreviewSideSwap_C::AlwaysOn");
static_assert(offsetof(AItemPreviewSideSwap_C, DebugLighting_LOWDetailPC) == 0x57c, "Offset mismatch for AItemPreviewSideSwap_C::DebugLighting_LOWDetailPC");
static_assert(offsetof(AItemPreviewSideSwap_C, On_New_Item_Spawned) == 0x580, "Offset mismatch for AItemPreviewSideSwap_C::On_New_Item_Spawned");
static_assert(offsetof(AItemPreviewSideSwap_C, CurrentZoomLevel) == 0x590, "Offset mismatch for AItemPreviewSideSwap_C::CurrentZoomLevel");
static_assert(offsetof(AItemPreviewSideSwap_C, TargetZoomLevel) == 0x598, "Offset mismatch for AItemPreviewSideSwap_C::TargetZoomLevel");
static_assert(offsetof(AItemPreviewSideSwap_C, TargetRotationOffset) == 0x5a0, "Offset mismatch for AItemPreviewSideSwap_C::TargetRotationOffset");
static_assert(offsetof(AItemPreviewSideSwap_C, OrigRotationOffset) == 0x5b8, "Offset mismatch for AItemPreviewSideSwap_C::OrigRotationOffset");
static_assert(offsetof(AItemPreviewSideSwap_C, Primary_Requested_Item) == 0x5d0, "Offset mismatch for AItemPreviewSideSwap_C::Primary_Requested_Item");
static_assert(offsetof(AItemPreviewSideSwap_C, Previous_Requested_Item) == 0x5d8, "Offset mismatch for AItemPreviewSideSwap_C::Previous_Requested_Item");

