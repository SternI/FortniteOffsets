/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AndroidFileServer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAndroidFileServerBPLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static TEnumAsByte<EAFSActiveType> IsFileServerRunning(); // 0x4c4e47c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool StartFileServer(bool& bUSB, bool& bNetwork, int32_t& Port); // 0x12e1ffb0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool StopFileServer(bool& bUSB, bool& bNetwork); // 0x12e20274 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAndroidFileServerBPLibrary) == 0x28, "Size mismatch for UAndroidFileServerBPLibrary");

