/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "AIModule.h"
#include "FortniteAI.h"
#include "DelMarTrackRuntime.h"
#include "EnhancedInput.h"
#include "GameplayAbilities.h"
#include "PlayspaceSystem.h"
#include "GameFeatures.h"
#include "VehicleCosmeticsRuntime.h"
#include "AudioGameplay.h"
#include "VehicleAudioRuntime.h"
#include "ClientPilot.h"
#include "ItemizationCoreRuntime.h"
#include "McpProfileSys.h"
#include "GameplayTags.h"
#include "LinkId.h"
#include "CosmeticsFrameworkLoadouts.h"
#include "Niagara.h"
#include "PhysicsCore.h"
#include "DelMarSettings.h"
#include "GameplayEventRouter.h"

// Size: 0x110 (Inherited: 0x308, Single: 0xfffffe08)
class UDelMarPlayerPreferencesComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t OnUseToggleOnExpandableHudWidgetChanged[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnUseIconOnlyPlayerNameplatesChanged[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTouchControlsLayoutChanged[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t InvertSteerMethod; // 0xe8 (Size: 0x1, Type: EnumProperty)
    bool bPitchInverted; // 0xe9 (Size: 0x1, Type: BoolProperty)
    bool bVerticalKickflipInverted; // 0xea (Size: 0x1, Type: BoolProperty)
    bool bAerialPitchActivationEnabled; // 0xeb (Size: 0x1, Type: BoolProperty)
    bool bUseToggleOnExpandableHudWidget; // 0xec (Size: 0x1, Type: BoolProperty)
    bool bUseIconOnlyPlayerNameplates; // 0xed (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ee[0x2]; // 0xee (Size: 0x2, Type: PaddingProperty)
    FGameplayTag TouchControlsLayout; // 0xf0 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0xf4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortClientSettingsRecord*> FortSettings; // 0xfc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_104[0xc]; // 0x104 (Size: 0xc, Type: PaddingProperty)

public:
    FGameplayTag GetTouchControlsLayout() const; // 0xa956af4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetUseIconOnlyPlayerNameplates() const; // 0x1139d634 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetUseToggleOnExpandableHudWidget() const; // 0x11c253a8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ServerSetInvertSteerMethod(EDelMarInvertSteerMethod& InInvertSteerMethod); // 0xd57865c (Index: 0x9, Flags: Net|NetReliableNative|Event|Public|NetServer)

protected:
    void HandleAerialPitchActivationSettingChanged(); // 0x11c2547c (Index: 0x3, Flags: Final|Native|Protected)
    void HandleIconOnlyNameplatesSettingChanged(); // 0x11c254a4 (Index: 0x4, Flags: Final|Native|Protected)
    void HandleInvertSteerSettingChanged(); // 0x11c254b8 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleLocalFortInputSettingsChanged(); // 0x11c2559c (Index: 0x6, Flags: Final|Native|Protected)
    void HandleTouchControlsSettingsChanged(); // 0x11c255b0 (Index: 0x7, Flags: Final|Native|Protected)
    void HandleVerticalKickflipInvertedSettingChanged(); // 0x11c255f4 (Index: 0x8, Flags: Final|Native|Protected)
    virtual void ServerUpdateAerialPitchActivation(bool& const bInAerialPitchActivationEnabled); // 0x11c283b4 (Index: 0xa, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerUpdatePitchInverted(bool& const bInPitchInverted); // 0x11c284e4 (Index: 0xb, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerUpdateVerticalKickflipInverted(bool& const bInVerticalKickflipInverted); // 0x1007dd38 (Index: 0xc, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    void TryGetFortClientSettings(); // 0x11c28b18 (Index: 0xd, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerPreferencesComponent) == 0x110, "Size mismatch for UDelMarPlayerPreferencesComponent");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, OnUseToggleOnExpandableHudWidgetChanged) == 0xb8, "Offset mismatch for UDelMarPlayerPreferencesComponent::OnUseToggleOnExpandableHudWidgetChanged");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, OnUseIconOnlyPlayerNameplatesChanged) == 0xc8, "Offset mismatch for UDelMarPlayerPreferencesComponent::OnUseIconOnlyPlayerNameplatesChanged");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, OnTouchControlsLayoutChanged) == 0xd8, "Offset mismatch for UDelMarPlayerPreferencesComponent::OnTouchControlsLayoutChanged");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, InvertSteerMethod) == 0xe8, "Offset mismatch for UDelMarPlayerPreferencesComponent::InvertSteerMethod");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, bPitchInverted) == 0xe9, "Offset mismatch for UDelMarPlayerPreferencesComponent::bPitchInverted");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, bVerticalKickflipInverted) == 0xea, "Offset mismatch for UDelMarPlayerPreferencesComponent::bVerticalKickflipInverted");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, bAerialPitchActivationEnabled) == 0xeb, "Offset mismatch for UDelMarPlayerPreferencesComponent::bAerialPitchActivationEnabled");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, bUseToggleOnExpandableHudWidget) == 0xec, "Offset mismatch for UDelMarPlayerPreferencesComponent::bUseToggleOnExpandableHudWidget");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, bUseIconOnlyPlayerNameplates) == 0xed, "Offset mismatch for UDelMarPlayerPreferencesComponent::bUseIconOnlyPlayerNameplates");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, TouchControlsLayout) == 0xf0, "Offset mismatch for UDelMarPlayerPreferencesComponent::TouchControlsLayout");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, CachedDelMarVehicle) == 0xf4, "Offset mismatch for UDelMarPlayerPreferencesComponent::CachedDelMarVehicle");
static_assert(offsetof(UDelMarPlayerPreferencesComponent, FortSettings) == 0xfc, "Offset mismatch for UDelMarPlayerPreferencesComponent::FortSettings");

// Size: 0xb8 (Inherited: 0x250, Single: 0xfffffe68)
class UDelMarPlayerStateComponent : public UPlayerStateComponent
{
public:
};

static_assert(sizeof(UDelMarPlayerStateComponent) == 0xb8, "Size mismatch for UDelMarPlayerStateComponent");

// Size: 0x4e0 (Inherited: 0x2d0, Single: 0x210)
class ADelMarRaceManager : public AActor
{
public:
    uint8_t Pad_2a8[0xa8]; // 0x2a8 (Size: 0xa8, Type: PaddingProperty)
    uint8_t OnRaceFinished[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRaceStarted[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRaceCountdownStarted[0x10]; // 0x370 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRaceReset[0x10]; // 0x380 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerFinishedRace[0x10]; // 0x390 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerLapComplete[0x10]; // 0x3a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerResetRun[0x10]; // 0x3b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bRaceStarted; // 0x3c0 (Size: 0x1, Type: BoolProperty)
    bool bRaceFinished; // 0x3c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c2[0x6]; // 0x3c2 (Size: 0x6, Type: PaddingProperty)
    TArray<AFortPlayerState*> SpectatorPlayerStates; // 0x3c8 (Size: 0x10, Type: ArrayProperty)
    TArray<AFortPlayerState*> ActiveRacerPlayerStates; // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    UDelMarRaceConfigComponent* RaceConfig; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarRaceLevelConfig*> ActiveRaceLevelConfig; // 0x3f0 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarTimeManagerComponent* TimeManager; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UDelMarRespawnManagerComponent* RespawnManager; // 0x400 (Size: 0x8, Type: ObjectProperty)
    UDelMarCheckpointManagerComponent* CheckpointManager; // 0x408 (Size: 0x8, Type: ObjectProperty)
    UDelMarRubberbandingManagerComponent* RubberbandingManager; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UDelMarGameplayModifierComponent* GameplayModifierComponent; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UDelMarPositionalTrackerComponent* PositionalTracker; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UDelMarEliminationRaceManagerComponent* EliminationManager; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UDelMarGlobalInputDisabler* InputDisablerComponent; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UDelMarMatchEventSystemComponent* MatchEventSystemComponent; // 0x438 (Size: 0x8, Type: ObjectProperty)
    TSet<AFortPlayerState*> ManagedPlayerStates; // 0x440 (Size: 0x50, Type: SetProperty)
    TSet<TWeakObjectPtr<AFortPlayerState*>> InactivePlayerStates; // 0x490 (Size: 0x50, Type: SetProperty)

public:
    void FinalizeRegisteredPlayerInitialization(AFortPlayerState*& PlayerState); // 0x11ca3060 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    void FinishRace(); // 0x53076e4 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    ADelMarRaceLevelConfig* GetActiveRaceLevelConfig() const; // 0x11ca3190 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AFortPlayerState*> GetActiveRacers() const; // 0x11ca31b4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDelMarRaceMode GetCurrentRaceMode() const; // 0x11ca32f0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDelMarRaceSpawnMode GetCurrentSpawnMode() const; // 0x11ca3314 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarEliminationRaceManagerComponent* GetEliminationManagerComponent() const; // 0x11ca3388 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarGameplayModifierComponent* GetGameplayModifierComponent() const; // 0xf691f0c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AFortPlayerState*> GetManagedPlayerStatesArray() const; // 0x11ca33a0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOfLapsForRace() const; // 0x11ca33fc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumInactiveRacers() const; // 0x11ca33dc (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarPositionalTrackerComponent* GetPositionalTracker() const; // 0xec9a100 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarRaceConfigComponent* GetRaceConfig() const; // 0xd0c2eb8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarRespawnManagerComponent* GetRespawnManagerComponent() const; // 0xe399cc4 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarRubberbandingManagerComponent* GetRubberbandingManager() const; // 0x11ca3584 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AFortPlayerState*> GetSpectators() const; // 0x11ca35b4 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarTimeManagerComponent* GetTimeManager() const; // 0x11ca35f0 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsActiveRacer(AFortPlayerState*& const PlayerState) const; // 0x11ca3ef4 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSpectator(AFortPlayerState*& const PlayerState) const; // 0x11ca40b4 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RegisterPlayerController(AController*& InController); // 0x11ca5114 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void RegisterPlayerState(AFortPlayerState*& InPlayerState); // 0x11ca5240 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void RequestCountdownForPlayer(AFortPlayerState*& PlayerState); // 0xa5533c0 (Index: 0x1b, Flags: Native|Public|BlueprintCallable)
    void RequestStartRace(bool& bSkipCountdown); // 0x11ca5604 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void ResetRace(bool& bIsRoundReset); // 0xa2a3c44 (Index: 0x1d, Flags: Native|Public|BlueprintCallable)
    void ResetRun(AFortPlayerState*& PlayerState, bool& bPlayerTriggered); // 0xd411d34 (Index: 0x1e, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetActiveRaceLevelConfig(ADelMarRaceLevelConfig*& InRaceLevelConfig); // 0xea9be9c (Index: 0x1f, Flags: Native|Public|BlueprintCallable)
    void SetPlayerAsSpectator(AFortPlayerState*& PlayerState); // 0x11ca64c8 (Index: 0x20, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetSpectatorAsPlayer(AFortPlayerState*& PlayerState); // 0xea9f274 (Index: 0x21, Flags: BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void UnregisterAllPlayers(bool& bSetAsInactive); // 0x11ca6818 (Index: 0x22, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void UnregisterPlayerController(AController*& InController, bool& bSetAsInactive); // 0x11ca6944 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterPlayerState(AFortPlayerState*& InPlayerState, bool& bSetAsInactive); // 0x11ca6b50 (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleRegisteredPlayerPawnSet(APlayerState*& Player, APawn*& NewPawn, APawn*& OldPawn); // 0x11ca3b08 (Index: 0x11, Flags: Final|Native|Protected)
    virtual void NetMulticast_FinishRace(double& RaceFinishedTime); // 0xc58edec (Index: 0x14, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_ResetRace(bool& bNextRound); // 0x11ca432c (Index: 0x15, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_ResetRun(AFortPlayerState*& const InPlayerState, bool& bPlayerTriggered); // 0x11ca445c (Index: 0x16, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    void OnRep_ActiveRaceLevelConfig(); // 0x11ca47d8 (Index: 0x17, Flags: Final|Native|Protected)
    void OnRep_ActiveRacerPlayerStates(); // 0x11ca47ec (Index: 0x18, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarRaceManager) == 0x4e0, "Size mismatch for ADelMarRaceManager");
static_assert(offsetof(ADelMarRaceManager, OnRaceFinished) == 0x350, "Offset mismatch for ADelMarRaceManager::OnRaceFinished");
static_assert(offsetof(ADelMarRaceManager, OnRaceStarted) == 0x360, "Offset mismatch for ADelMarRaceManager::OnRaceStarted");
static_assert(offsetof(ADelMarRaceManager, OnRaceCountdownStarted) == 0x370, "Offset mismatch for ADelMarRaceManager::OnRaceCountdownStarted");
static_assert(offsetof(ADelMarRaceManager, OnRaceReset) == 0x380, "Offset mismatch for ADelMarRaceManager::OnRaceReset");
static_assert(offsetof(ADelMarRaceManager, OnPlayerFinishedRace) == 0x390, "Offset mismatch for ADelMarRaceManager::OnPlayerFinishedRace");
static_assert(offsetof(ADelMarRaceManager, OnPlayerLapComplete) == 0x3a0, "Offset mismatch for ADelMarRaceManager::OnPlayerLapComplete");
static_assert(offsetof(ADelMarRaceManager, OnPlayerResetRun) == 0x3b0, "Offset mismatch for ADelMarRaceManager::OnPlayerResetRun");
static_assert(offsetof(ADelMarRaceManager, bRaceStarted) == 0x3c0, "Offset mismatch for ADelMarRaceManager::bRaceStarted");
static_assert(offsetof(ADelMarRaceManager, bRaceFinished) == 0x3c1, "Offset mismatch for ADelMarRaceManager::bRaceFinished");
static_assert(offsetof(ADelMarRaceManager, SpectatorPlayerStates) == 0x3c8, "Offset mismatch for ADelMarRaceManager::SpectatorPlayerStates");
static_assert(offsetof(ADelMarRaceManager, ActiveRacerPlayerStates) == 0x3d8, "Offset mismatch for ADelMarRaceManager::ActiveRacerPlayerStates");
static_assert(offsetof(ADelMarRaceManager, RaceConfig) == 0x3e8, "Offset mismatch for ADelMarRaceManager::RaceConfig");
static_assert(offsetof(ADelMarRaceManager, ActiveRaceLevelConfig) == 0x3f0, "Offset mismatch for ADelMarRaceManager::ActiveRaceLevelConfig");
static_assert(offsetof(ADelMarRaceManager, TimeManager) == 0x3f8, "Offset mismatch for ADelMarRaceManager::TimeManager");
static_assert(offsetof(ADelMarRaceManager, RespawnManager) == 0x400, "Offset mismatch for ADelMarRaceManager::RespawnManager");
static_assert(offsetof(ADelMarRaceManager, CheckpointManager) == 0x408, "Offset mismatch for ADelMarRaceManager::CheckpointManager");
static_assert(offsetof(ADelMarRaceManager, RubberbandingManager) == 0x410, "Offset mismatch for ADelMarRaceManager::RubberbandingManager");
static_assert(offsetof(ADelMarRaceManager, GameplayModifierComponent) == 0x418, "Offset mismatch for ADelMarRaceManager::GameplayModifierComponent");
static_assert(offsetof(ADelMarRaceManager, PositionalTracker) == 0x420, "Offset mismatch for ADelMarRaceManager::PositionalTracker");
static_assert(offsetof(ADelMarRaceManager, EliminationManager) == 0x428, "Offset mismatch for ADelMarRaceManager::EliminationManager");
static_assert(offsetof(ADelMarRaceManager, InputDisablerComponent) == 0x430, "Offset mismatch for ADelMarRaceManager::InputDisablerComponent");
static_assert(offsetof(ADelMarRaceManager, MatchEventSystemComponent) == 0x438, "Offset mismatch for ADelMarRaceManager::MatchEventSystemComponent");
static_assert(offsetof(ADelMarRaceManager, ManagedPlayerStates) == 0x440, "Offset mismatch for ADelMarRaceManager::ManagedPlayerStates");
static_assert(offsetof(ADelMarRaceManager, InactivePlayerStates) == 0x490, "Offset mismatch for ADelMarRaceManager::InactivePlayerStates");

// Size: 0x1a8 (Inherited: 0x88, Single: 0x120)
class UDelMarVehicleManager : public UWorldSubsystem
{
public:

public:
    void BP_GetAllVehicles(TArray<ADelMarVehicle*>& OutVehicles); // 0x11b25588 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BP_GetVehiclesInRange(const FVector SourcePosition, float& const Range, bool& const bDo2DCheck, TArray<ADelMarVehicle*>& OutVehicles); // 0x11b25814 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void HandlePawnEnteredVehicle(const TScriptInterface<Class> Vehicle, AFortPawn*& Pawn, int32_t& SeatIndex); // 0x11b26240 (Index: 0x2, Flags: Final|Native|Public|HasOutParms)
    void HandlePawnExitedVehicle(const TScriptInterface<Class> Vehicle, AFortPawn*& Pawn, int32_t& SeatIndex); // 0x11b263fc (Index: 0x3, Flags: Final|Native|Public|HasOutParms)
    void HandlePawnPlayerStateSet(AFortPlayerPawn*& Pawn); // 0x11b265b8 (Index: 0x4, Flags: Final|Native|Public)
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11b27308 (Index: 0x5, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleManager) == 0x1a8, "Size mismatch for UDelMarVehicleManager");

// Size: 0x130 (Inherited: 0x250, Single: 0xfffffee0)
class UDelMarPreRaceControllerComponent : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    UInputAction* NavigateAction; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ReadyUpAction; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    FViewTargetTransitionParams ViewTargetTransitionParams; // 0xe0 (Size: 0x10, Type: StructProperty)
    float NavigateInputDeadzone; // 0xf0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_f4[0x4]; // 0xf4 (Size: 0x4, Type: PaddingProperty)
    UClass* InputManagerClass; // 0xf8 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UDelMarPlayerInputManagerComponent*> InputManager; // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent; // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionTracker; // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CurrentViewTarget; // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    float CellDistThreshold; // 0x120 (Size: 0x4, Type: FloatProperty)
    float MaxGridDim; // 0x124 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_128[0x8]; // 0x128 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void ServerSetViewTarget(AFortPlayerState*& PlayerState); // 0xcb1b9c4 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
};

static_assert(sizeof(UDelMarPreRaceControllerComponent) == 0x130, "Size mismatch for UDelMarPreRaceControllerComponent");
static_assert(offsetof(UDelMarPreRaceControllerComponent, NavigateAction) == 0xd0, "Offset mismatch for UDelMarPreRaceControllerComponent::NavigateAction");
static_assert(offsetof(UDelMarPreRaceControllerComponent, ReadyUpAction) == 0xd8, "Offset mismatch for UDelMarPreRaceControllerComponent::ReadyUpAction");
static_assert(offsetof(UDelMarPreRaceControllerComponent, ViewTargetTransitionParams) == 0xe0, "Offset mismatch for UDelMarPreRaceControllerComponent::ViewTargetTransitionParams");
static_assert(offsetof(UDelMarPreRaceControllerComponent, NavigateInputDeadzone) == 0xf0, "Offset mismatch for UDelMarPreRaceControllerComponent::NavigateInputDeadzone");
static_assert(offsetof(UDelMarPreRaceControllerComponent, InputManagerClass) == 0xf8, "Offset mismatch for UDelMarPreRaceControllerComponent::InputManagerClass");
static_assert(offsetof(UDelMarPreRaceControllerComponent, InputManager) == 0x100, "Offset mismatch for UDelMarPreRaceControllerComponent::InputManager");
static_assert(offsetof(UDelMarPreRaceControllerComponent, InputComponent) == 0x108, "Offset mismatch for UDelMarPreRaceControllerComponent::InputComponent");
static_assert(offsetof(UDelMarPreRaceControllerComponent, PositionTracker) == 0x110, "Offset mismatch for UDelMarPreRaceControllerComponent::PositionTracker");
static_assert(offsetof(UDelMarPreRaceControllerComponent, CurrentViewTarget) == 0x118, "Offset mismatch for UDelMarPreRaceControllerComponent::CurrentViewTarget");
static_assert(offsetof(UDelMarPreRaceControllerComponent, CellDistThreshold) == 0x120, "Offset mismatch for UDelMarPreRaceControllerComponent::CellDistThreshold");
static_assert(offsetof(UDelMarPreRaceControllerComponent, MaxGridDim) == 0x124, "Offset mismatch for UDelMarPreRaceControllerComponent::MaxGridDim");

// Size: 0x830 (Inherited: 0x1240, Single: 0xfffff5f0)
class ADelMarPlayspace : public AFortPlayspace
{
public:
    uint8_t Pad_6e0[0x48]; // 0x6e0 (Size: 0x48, Type: PaddingProperty)
    TWeakObjectPtr<UFortPlaylistAthena*> MRSPlaylistData; // 0x728 (Size: 0x8, Type: WeakObjectProperty)
    FString MRSLinkId; // 0x730 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_740[0x10]; // 0x740 (Size: 0x10, Type: PaddingProperty)
    UDelMarGameStateMachine* PrimaryStateMachine; // 0x750 (Size: 0x8, Type: ObjectProperty)
    bool bShouldShowLoadingScreen; // 0x758 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_759[0x7]; // 0x759 (Size: 0x7, Type: PaddingProperty)
    TMap<TSoftClassPtr, EDelMarRaceMode> DefaultRaceLevelConfigs; // 0x760 (Size: 0x50, Type: MapProperty)
    TWeakObjectPtr<ADelMarRaceManager*> ActiveRaceManager; // 0x7b0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortPlaylistAthena*> PlaylistData; // 0x7b8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarLevelManagerComponent*> LevelManager; // 0x7c0 (Size: 0x8, Type: WeakObjectProperty)
    UFortLevelStreamComponent* LevelStreamComponent; // 0x7c8 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayspaceComponent_ServerExpiration* ServerExpirationComponent; // 0x7d0 (Size: 0x8, Type: ObjectProperty)
    FDelMarMapSet MapSet; // 0x7d8 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer PlaylistDefinedMapTags; // 0x7f0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_810[0x20]; // 0x810 (Size: 0x20, Type: PaddingProperty)

public:
    ADelMarRaceManager* GetActiveRaceManager() const; // 0x11c2536c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnRep_MRSLinkId(); // 0x11c263cc (Index: 0x2, Flags: Final|Native|Public)
    virtual void RequestNextMapFromMapSet(); // 0xcfbefc0 (Index: 0x3, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerRequestLoadingLevel(FGameplayTagContainer& const DesiredMap); // 0x11c26e58 (Index: 0x4, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerRequestLoadingLevelWithLinkCode(FOnlineLinkId& const DesiredMap); // 0x11c27154 (Index: 0x5, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerReturnToSetup(FGameplayTagContainer& const OptionalMapToForceLoad); // 0x11c27a10 (Index: 0x6, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerReturnToSetupWithLinkCode(FOnlineLinkId& const OptionalMapToForceLoad); // 0x11c27d24 (Index: 0x7, Flags: Net|NetReliableNative|Event|Public|NetServer)
    void SetLoadingScreenVisibiliy(bool& bInShouldShowLoadingScreen); // 0x11c28874 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    bool ShouldShowLoadingScreen() const; // 0x11c28acc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void OnRep_ActiveRaceManagerUpdated(); // 0x11c261c0 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarPlayspace) == 0x830, "Size mismatch for ADelMarPlayspace");
static_assert(offsetof(ADelMarPlayspace, MRSPlaylistData) == 0x728, "Offset mismatch for ADelMarPlayspace::MRSPlaylistData");
static_assert(offsetof(ADelMarPlayspace, MRSLinkId) == 0x730, "Offset mismatch for ADelMarPlayspace::MRSLinkId");
static_assert(offsetof(ADelMarPlayspace, PrimaryStateMachine) == 0x750, "Offset mismatch for ADelMarPlayspace::PrimaryStateMachine");
static_assert(offsetof(ADelMarPlayspace, bShouldShowLoadingScreen) == 0x758, "Offset mismatch for ADelMarPlayspace::bShouldShowLoadingScreen");
static_assert(offsetof(ADelMarPlayspace, DefaultRaceLevelConfigs) == 0x760, "Offset mismatch for ADelMarPlayspace::DefaultRaceLevelConfigs");
static_assert(offsetof(ADelMarPlayspace, ActiveRaceManager) == 0x7b0, "Offset mismatch for ADelMarPlayspace::ActiveRaceManager");
static_assert(offsetof(ADelMarPlayspace, PlaylistData) == 0x7b8, "Offset mismatch for ADelMarPlayspace::PlaylistData");
static_assert(offsetof(ADelMarPlayspace, LevelManager) == 0x7c0, "Offset mismatch for ADelMarPlayspace::LevelManager");
static_assert(offsetof(ADelMarPlayspace, LevelStreamComponent) == 0x7c8, "Offset mismatch for ADelMarPlayspace::LevelStreamComponent");
static_assert(offsetof(ADelMarPlayspace, ServerExpirationComponent) == 0x7d0, "Offset mismatch for ADelMarPlayspace::ServerExpirationComponent");
static_assert(offsetof(ADelMarPlayspace, MapSet) == 0x7d8, "Offset mismatch for ADelMarPlayspace::MapSet");
static_assert(offsetof(ADelMarPlayspace, PlaylistDefinedMapTags) == 0x7f0, "Offset mismatch for ADelMarPlayspace::PlaylistDefinedMapTags");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDelMarEvent_FinalFirstPlaceChanged : public UObject
{
public:
    TWeakObjectPtr<AFortPlayerState*> NewFirstPlace; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PrevFirstPlace; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarEvent_FinalFirstPlaceChanged) == 0x38, "Size mismatch for UDelMarEvent_FinalFirstPlaceChanged");
static_assert(offsetof(UDelMarEvent_FinalFirstPlaceChanged, NewFirstPlace) == 0x28, "Offset mismatch for UDelMarEvent_FinalFirstPlaceChanged::NewFirstPlace");
static_assert(offsetof(UDelMarEvent_FinalFirstPlaceChanged, PrevFirstPlace) == 0x30, "Offset mismatch for UDelMarEvent_FinalFirstPlaceChanged::PrevFirstPlace");

// Size: 0xde0 (Inherited: 0x45b0, Single: 0xffffc830)
class ADelMarCheckpoint : public AFortCreativeDeviceProp
{
public:
    uint8_t OnCheckpointTirggeredEvent[0x10]; // 0xc10 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t bIsFinishLine : 1; // 0xc20:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsStartingLine : 1; // 0xc20:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsTimeTrialSectionEnd : 1; // 0xc20:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsTeleportEnabled : 1; // 0xc20:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c21[0x7]; // 0xc21 (Size: 0x7, Type: PaddingProperty)
    TSet<ADelMarCheckpoint*> NextCheckpoints; // 0xc28 (Size: 0x50, Type: SetProperty)
    float DynamicSpawnOffset; // 0xc78 (Size: 0x4, Type: FloatProperty)
    float SpawnDistanceBeforeOrAfterSplineLocation; // 0xc7c (Size: 0x4, Type: FloatProperty)
    float BaseRadius; // 0xc80 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c84[0x4]; // 0xc84 (Size: 0x4, Type: PaddingProperty)
    FVector IntersectionTolerance; // 0xc88 (Size: 0x18, Type: StructProperty)
    int32_t CheckpointId; // 0xca0 (Size: 0x4, Type: IntProperty)
    int32_t SplinePointIndex; // 0xca4 (Size: 0x4, Type: IntProperty)
    ADelMarPlayerStart* SpawnPoint; // 0xca8 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackSnapToComponent* SnapToComponent; // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    TSet<ADelMarCheckpoint*> PreviousCheckpoints; // 0xcb8 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_d08[0x20]; // 0xd08 (Size: 0x20, Type: PaddingProperty)
    int32_t NearestTrackIndex; // 0xd28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d2c[0x4]; // 0xd2c (Size: 0x4, Type: PaddingProperty)
    TArray<FCheckpointTrackDistance> AssociatedTracks; // 0xd30 (Size: 0x10, Type: ArrayProperty)
    int32_t ComputedCheckpointIndex; // 0xd40 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d44[0x4]; // 0xd44 (Size: 0x4, Type: PaddingProperty)
    UStaticMeshComponent* ColliderVolume; // 0xd48 (Size: 0x8, Type: ObjectProperty)
    UDelMarCheckpointTheme* CheckpointTheme; // 0xd50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d58[0x78]; // 0xd58 (Size: 0x78, Type: PaddingProperty)
    ADelMarCheckpoint* CheckpointToTeleportTo; // 0xdd0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_dd8[0x8]; // 0xdd8 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void BP_ActivateRift(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_DeactivateRift(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_FirstPlaceChanged(bool& bValidPrevFirstPlace); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void BP_LapFinished(int32_t& CompletedLap, int32_t& CurrentLap, int32_t& TotalLaps); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void BP_RaceFinished(); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void BP_RaceReset(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void ClientSetCheckpointActive(int32_t& CurrentLap, int32_t& TotalLaps); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void ClientSetCheckpointInactive(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    EDelMarCheckpointMeshType GetCheckpointMeshType() const; // 0x11b70e2c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FCheckpointTrackDistance GetFurthestAheadTrackDistance() const; // 0x11b718e4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FCheckpointTrackDistance GetFurthestBehindTrackDistance() const; // 0x11b71914 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FCheckpointTrackDistance GetNearestTrackData() const; // 0x11b71944 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetSpawnTransform() const; // 0x11b71f4c (Index: 0xc, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FCheckpointTrackDistance GetTrackDistanceDataForTrack(ADelMarTrackBase*& const InTrack, bool& const bEnsureAssociated) const; // 0x11b723d0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAssociatedWithTrack(ADelMarTrackBase*& const InTrack) const; // 0x11b72890 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsFinishLine() const; // 0x11b72c3c (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsStartingLine() const; // 0x11b72f4c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnTriggered(ADelMarVehicle*& InDelMarVehicle); // 0xd358b74 (Index: 0x12, Flags: Native|Public|BlueprintCallable)

protected:
    void HandlePawnEnteredVehicle(const TScriptInterface<Class> Vehicle, AFortPawn*& Pawn, int32_t& SeatIndex); // 0x11b72614 (Index: 0xe, Flags: Final|Native|Protected|HasOutParms)
    virtual void UpdateCheckpointMesh(EDelMarCheckpointMeshType& MeshType); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateCheckpointTheme(UDelMarCheckpointTheme*& Theme); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ADelMarCheckpoint) == 0xde0, "Size mismatch for ADelMarCheckpoint");
static_assert(offsetof(ADelMarCheckpoint, OnCheckpointTirggeredEvent) == 0xc10, "Offset mismatch for ADelMarCheckpoint::OnCheckpointTirggeredEvent");
static_assert(offsetof(ADelMarCheckpoint, bIsFinishLine) == 0xc20, "Offset mismatch for ADelMarCheckpoint::bIsFinishLine");
static_assert(offsetof(ADelMarCheckpoint, bIsStartingLine) == 0xc20, "Offset mismatch for ADelMarCheckpoint::bIsStartingLine");
static_assert(offsetof(ADelMarCheckpoint, bIsTimeTrialSectionEnd) == 0xc20, "Offset mismatch for ADelMarCheckpoint::bIsTimeTrialSectionEnd");
static_assert(offsetof(ADelMarCheckpoint, bIsTeleportEnabled) == 0xc20, "Offset mismatch for ADelMarCheckpoint::bIsTeleportEnabled");
static_assert(offsetof(ADelMarCheckpoint, NextCheckpoints) == 0xc28, "Offset mismatch for ADelMarCheckpoint::NextCheckpoints");
static_assert(offsetof(ADelMarCheckpoint, DynamicSpawnOffset) == 0xc78, "Offset mismatch for ADelMarCheckpoint::DynamicSpawnOffset");
static_assert(offsetof(ADelMarCheckpoint, SpawnDistanceBeforeOrAfterSplineLocation) == 0xc7c, "Offset mismatch for ADelMarCheckpoint::SpawnDistanceBeforeOrAfterSplineLocation");
static_assert(offsetof(ADelMarCheckpoint, BaseRadius) == 0xc80, "Offset mismatch for ADelMarCheckpoint::BaseRadius");
static_assert(offsetof(ADelMarCheckpoint, IntersectionTolerance) == 0xc88, "Offset mismatch for ADelMarCheckpoint::IntersectionTolerance");
static_assert(offsetof(ADelMarCheckpoint, CheckpointId) == 0xca0, "Offset mismatch for ADelMarCheckpoint::CheckpointId");
static_assert(offsetof(ADelMarCheckpoint, SplinePointIndex) == 0xca4, "Offset mismatch for ADelMarCheckpoint::SplinePointIndex");
static_assert(offsetof(ADelMarCheckpoint, SpawnPoint) == 0xca8, "Offset mismatch for ADelMarCheckpoint::SpawnPoint");
static_assert(offsetof(ADelMarCheckpoint, SnapToComponent) == 0xcb0, "Offset mismatch for ADelMarCheckpoint::SnapToComponent");
static_assert(offsetof(ADelMarCheckpoint, PreviousCheckpoints) == 0xcb8, "Offset mismatch for ADelMarCheckpoint::PreviousCheckpoints");
static_assert(offsetof(ADelMarCheckpoint, NearestTrackIndex) == 0xd28, "Offset mismatch for ADelMarCheckpoint::NearestTrackIndex");
static_assert(offsetof(ADelMarCheckpoint, AssociatedTracks) == 0xd30, "Offset mismatch for ADelMarCheckpoint::AssociatedTracks");
static_assert(offsetof(ADelMarCheckpoint, ComputedCheckpointIndex) == 0xd40, "Offset mismatch for ADelMarCheckpoint::ComputedCheckpointIndex");
static_assert(offsetof(ADelMarCheckpoint, ColliderVolume) == 0xd48, "Offset mismatch for ADelMarCheckpoint::ColliderVolume");
static_assert(offsetof(ADelMarCheckpoint, CheckpointTheme) == 0xd50, "Offset mismatch for ADelMarCheckpoint::CheckpointTheme");
static_assert(offsetof(ADelMarCheckpoint, CheckpointToTeleportTo) == 0xdd0, "Offset mismatch for ADelMarCheckpoint::CheckpointToTeleportTo");

// Size: 0x328 (Inherited: 0xb90, Single: 0xfffff798)
class ADelMarPlayerStart : public AFortPlayerStart
{
public:
    int32_t StartlinePriority; // 0x318 (Size: 0x4, Type: IntProperty)
    float IsClaimedZDistanceCheck; // 0x31c (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarRaceManager*> DelMarRaceManager; // 0x320 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(ADelMarPlayerStart) == 0x328, "Size mismatch for ADelMarPlayerStart");
static_assert(offsetof(ADelMarPlayerStart, StartlinePriority) == 0x318, "Offset mismatch for ADelMarPlayerStart::StartlinePriority");
static_assert(offsetof(ADelMarPlayerStart, IsClaimedZDistanceCheck) == 0x31c, "Offset mismatch for ADelMarPlayerStart::IsClaimedZDistanceCheck");
static_assert(offsetof(ADelMarPlayerStart, DelMarRaceManager) == 0x320, "Offset mismatch for ADelMarPlayerStart::DelMarRaceManager");

// Size: 0x278 (Inherited: 0x308, Single: 0xffffff70)
class UDelMarPlayerRaceDataComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t Pad_b8[0x30]; // 0xb8 (Size: 0x30, Type: PaddingProperty)
    TSet<int32_t> VisitedCheckpoints; // 0xe8 (Size: 0x50, Type: SetProperty)
    TSet<ADelMarCheckpoint*> VisitedCheckpoints_ParallelPath; // 0x138 (Size: 0x50, Type: SetProperty)
    double RunStartTime; // 0x188 (Size: 0x8, Type: DoubleProperty)
    double RunFinishTime; // 0x190 (Size: 0x8, Type: DoubleProperty)
    double CheckpointStartTime; // 0x198 (Size: 0x8, Type: DoubleProperty)
    double LapStartTime; // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    float DistanceToFinishLine; // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float LapDistance; // 0x1ac (Size: 0x4, Type: FloatProperty)
    float PrimaryTrackDistance; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float IndependentTrackDistance; // 0x1b4 (Size: 0x4, Type: FloatProperty)
    int32_t LapsCompleted; // 0x1b8 (Size: 0x4, Type: IntProperty)
    bool bHasStartedFirstLap; // 0x1bc (Size: 0x1, Type: BoolProperty)
    bool bFinishedRace; // 0x1bd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1be[0x2]; // 0x1be (Size: 0x2, Type: PaddingProperty)
    int32_t Points; // 0x1c0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c4[0x4]; // 0x1c4 (Size: 0x4, Type: PaddingProperty)
    TArray<APlayerState*> ViewingSpectators; // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    ADelMarCheckpoint* MostRecentlyVisitedCheckpoint; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager; // 0x1e0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> CachedPositionalTracker; // 0x1f8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> CachedLapTracker; // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    TSet<ADelMarCheckpoint*> CheckpointsVisitedThisLap; // 0x208 (Size: 0x50, Type: SetProperty)
    int32_t TimeTrialSectionIndex; // 0x258 (Size: 0x4, Type: IntProperty)
    int32_t CheckPointIndex; // 0x25c (Size: 0x4, Type: IntProperty)
    UDelMarEvent_PlayerPointsChanged* PointsUpdatedEvent; // 0x260 (Size: 0x8, Type: ObjectProperty)
    UDelMarEvent_PlayerFinishRace* FinishRaceEvent; // 0x268 (Size: 0x8, Type: ObjectProperty)
    int32_t CachedBotPenaltyCurveIndex; // 0x270 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_274[0x4]; // 0x274 (Size: 0x4, Type: PaddingProperty)

public:
    int32_t GetNumViewingSpectator(); // 0x11c25390 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<APlayerState*> GetViewingSpectators(); // 0x11c253c0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void NetMulticast_CheckpointPassed_ParallelPath(FDelMarEvent_CheckpointPassed_ParallelPath& const CheckpointEvent); // 0x11c25944 (Index: 0x2, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_CheckpointPassedOutOfOrder_ParallelPath(FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath& const InCheckpointPassedOutOfOrderEvent); // 0x11c2587c (Index: 0x3, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_LapCompleted(FDelMarEvent_LapComplete& const InLapEvent); // 0x11c25a14 (Index: 0x4, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_RaceCompleted(double& RunTime, bool& const bValidRun); // 0x11c25be0 (Index: 0x5, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_SectionCompleted_ParallelPath(FDelMarEvent_SectionComplete_ParallelPath& const InSectionEvent); // 0x11c25f04 (Index: 0x6, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_TeleportEntered(FDelMarEvent_TeleportEnteredEvent& const InCheckpointTeleportingEvent); // 0x11c260f8 (Index: 0x7, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    void OnRep_Points(); // 0x11c263e0 (Index: 0x8, Flags: Final|Native|Protected)
    void OnRep_ViewingSpectators(); // 0x11c26418 (Index: 0x9, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerRaceDataComponent) == 0x278, "Size mismatch for UDelMarPlayerRaceDataComponent");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, VisitedCheckpoints) == 0xe8, "Offset mismatch for UDelMarPlayerRaceDataComponent::VisitedCheckpoints");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, VisitedCheckpoints_ParallelPath) == 0x138, "Offset mismatch for UDelMarPlayerRaceDataComponent::VisitedCheckpoints_ParallelPath");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, RunStartTime) == 0x188, "Offset mismatch for UDelMarPlayerRaceDataComponent::RunStartTime");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, RunFinishTime) == 0x190, "Offset mismatch for UDelMarPlayerRaceDataComponent::RunFinishTime");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CheckpointStartTime) == 0x198, "Offset mismatch for UDelMarPlayerRaceDataComponent::CheckpointStartTime");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, LapStartTime) == 0x1a0, "Offset mismatch for UDelMarPlayerRaceDataComponent::LapStartTime");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, DistanceToFinishLine) == 0x1a8, "Offset mismatch for UDelMarPlayerRaceDataComponent::DistanceToFinishLine");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, LapDistance) == 0x1ac, "Offset mismatch for UDelMarPlayerRaceDataComponent::LapDistance");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, PrimaryTrackDistance) == 0x1b0, "Offset mismatch for UDelMarPlayerRaceDataComponent::PrimaryTrackDistance");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, IndependentTrackDistance) == 0x1b4, "Offset mismatch for UDelMarPlayerRaceDataComponent::IndependentTrackDistance");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, LapsCompleted) == 0x1b8, "Offset mismatch for UDelMarPlayerRaceDataComponent::LapsCompleted");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, bHasStartedFirstLap) == 0x1bc, "Offset mismatch for UDelMarPlayerRaceDataComponent::bHasStartedFirstLap");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, bFinishedRace) == 0x1bd, "Offset mismatch for UDelMarPlayerRaceDataComponent::bFinishedRace");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, Points) == 0x1c0, "Offset mismatch for UDelMarPlayerRaceDataComponent::Points");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, ViewingSpectators) == 0x1c8, "Offset mismatch for UDelMarPlayerRaceDataComponent::ViewingSpectators");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, MostRecentlyVisitedCheckpoint) == 0x1d8, "Offset mismatch for UDelMarPlayerRaceDataComponent::MostRecentlyVisitedCheckpoint");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CachedCheckpointManager) == 0x1e0, "Offset mismatch for UDelMarPlayerRaceDataComponent::CachedCheckpointManager");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CachedRaceManager) == 0x1e8, "Offset mismatch for UDelMarPlayerRaceDataComponent::CachedRaceManager");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CachedDelMarVehicle) == 0x1f0, "Offset mismatch for UDelMarPlayerRaceDataComponent::CachedDelMarVehicle");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CachedPositionalTracker) == 0x1f8, "Offset mismatch for UDelMarPlayerRaceDataComponent::CachedPositionalTracker");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CachedLapTracker) == 0x200, "Offset mismatch for UDelMarPlayerRaceDataComponent::CachedLapTracker");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CheckpointsVisitedThisLap) == 0x208, "Offset mismatch for UDelMarPlayerRaceDataComponent::CheckpointsVisitedThisLap");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, TimeTrialSectionIndex) == 0x258, "Offset mismatch for UDelMarPlayerRaceDataComponent::TimeTrialSectionIndex");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CheckPointIndex) == 0x25c, "Offset mismatch for UDelMarPlayerRaceDataComponent::CheckPointIndex");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, PointsUpdatedEvent) == 0x260, "Offset mismatch for UDelMarPlayerRaceDataComponent::PointsUpdatedEvent");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, FinishRaceEvent) == 0x268, "Offset mismatch for UDelMarPlayerRaceDataComponent::FinishRaceEvent");
static_assert(offsetof(UDelMarPlayerRaceDataComponent, CachedBotPenaltyCurveIndex) == 0x270, "Offset mismatch for UDelMarPlayerRaceDataComponent::CachedBotPenaltyCurveIndex");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDelMarEvent_PlayerPointsChanged : public UObject
{
public:
    int32_t PreviousPoints; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPoints; // 0x2c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UDelMarEvent_PlayerPointsChanged) == 0x30, "Size mismatch for UDelMarEvent_PlayerPointsChanged");
static_assert(offsetof(UDelMarEvent_PlayerPointsChanged, PreviousPoints) == 0x28, "Offset mismatch for UDelMarEvent_PlayerPointsChanged::PreviousPoints");
static_assert(offsetof(UDelMarEvent_PlayerPointsChanged, CurrentPoints) == 0x2c, "Offset mismatch for UDelMarEvent_PlayerPointsChanged::CurrentPoints");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDelMarEvent_AttachmentChanged : public UObject
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerAttachedTo; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PrevPlayerAttachedTo; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarEvent_AttachmentChanged) == 0x38, "Size mismatch for UDelMarEvent_AttachmentChanged");
static_assert(offsetof(UDelMarEvent_AttachmentChanged, PlayerAttachedTo) == 0x28, "Offset mismatch for UDelMarEvent_AttachmentChanged::PlayerAttachedTo");
static_assert(offsetof(UDelMarEvent_AttachmentChanged, PrevPlayerAttachedTo) == 0x30, "Offset mismatch for UDelMarEvent_AttachmentChanged::PrevPlayerAttachedTo");

// Size: 0x3d70 (Inherited: 0x4db8, Single: 0xffffefb8)
class ADelMarVehicle : public AFortAthenaSKVehicle
{
public:
    uint8_t Pad_21b0[0x50]; // 0x21b0 (Size: 0x50, Type: PaddingProperty)
    UClass* DefaultCameraMode; // 0x2200 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> SeatIndexCameraModes; // 0x2208 (Size: 0x10, Type: ArrayProperty)
    bool bLocalDriverHasReplicatedVehicle; // 0x2218 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2219[0xf]; // 0x2219 (Size: 0xf, Type: PaddingProperty)
    FFortAthenaVehicleInputState PendingDriverInputState; // 0x2228 (Size: 0x40, Type: StructProperty)
    uint8_t CurrentInputType; // 0x2268 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2269[0x1f]; // 0x2269 (Size: 0x1f, Type: PaddingProperty)
    float DistanceToPack; // 0x2288 (Size: 0x4, Type: FloatProperty)
    float DistanceFromTrackFinish; // 0x228c (Size: 0x4, Type: FloatProperty)
    float RaceStatusSpeedModifier; // 0x2290 (Size: 0x4, Type: FloatProperty)
    float TurboBoostChanceCache; // 0x2294 (Size: 0x4, Type: FloatProperty)
    bool ATTR_bVehicleThrottleDisabled; // 0x2298 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2299[0x7]; // 0x2299 (Size: 0x7, Type: PaddingProperty)
    FDelMarInputAction ThrottleAction; // 0x22a0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction BrakeAction; // 0x22b0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction SteerAction; // 0x22c0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction SteerLeftAction; // 0x22d0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction SteerRightAction; // 0x22e0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction PitchAction; // 0x22f0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction PitchUpAction; // 0x2300 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction PitchDownAction; // 0x2310 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction RollAction; // 0x2320 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction YawAction; // 0x2330 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction DriftAction; // 0x2340 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction JumpAction; // 0x2350 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction KickFlipAction; // 0x2360 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction UnderthrustAction; // 0x2370 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction TurboAction; // 0x2380 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction DelMarExitAction; // 0x2390 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction ResetRunAction; // 0x23a0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction AirFreestyleAction; // 0x23b0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction StrafeAction; // 0x23c0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction AerialPitchAction; // 0x23d0 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction DemolishAction; // 0x23e0 (Size: 0x10, Type: StructProperty)
    UClass* InputManagerClass; // 0x23f0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_23f8[0x18]; // 0x23f8 (Size: 0x18, Type: PaddingProperty)
    float IdleVelocityLengthThreshold; // 0x2410 (Size: 0x4, Type: FloatProperty)
    float IdleInputSecondsThreshold; // 0x2414 (Size: 0x4, Type: FloatProperty)
    bool bIdleFromNoInput; // 0x2418 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2419[0x47]; // 0x2419 (Size: 0x47, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x2460 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarVehicleNetworkPhysicsComponent* NetworkPhysicsComponent; // 0x2468 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleCosmeticComponent* CosmeticComponent; // 0x2470 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleMovementSet* DelMarVehicleMovementSet; // 0x2478 (Size: 0x8, Type: ObjectProperty)
    UFortClientSettingsRecord* FortSettings; // 0x2480 (Size: 0x8, Type: ObjectProperty)
    UClass* TrackPositionComponentClass; // 0x2488 (Size: 0x8, Type: ClassProperty)
    UDelMarTrackPositionComponent* TrackPositionComponent; // 0x2490 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2498[0x8]; // 0x2498 (Size: 0x8, Type: PaddingProperty)
    TArray<TWeakObjectPtr<USkeletalMeshComponent*>> WheelSkeletalMeshComps; // 0x24a0 (Size: 0x10, Type: ArrayProperty)
    TMap<UDelMarEvent_PlayerInVehicle*, TWeakObjectPtr<AFortPlayerState*>> PlayerInVehicleEvents; // 0x24b0 (Size: 0x50, Type: MapProperty)
    int32_t NumAllowedVehicleCosmeticChanges; // 0x2500 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2504[0x4]; // 0x2504 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarVehicleCachedContact> CachedContacts; // 0x2508 (Size: 0x10, Type: ArrayProperty)
    float NearbyTrackDistanceThreshold; // 0x2518 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_251c[0x14]; // 0x251c (Size: 0x14, Type: PaddingProperty)
    float MaxStableSpeedToUpdateWheels; // 0x2530 (Size: 0x4, Type: FloatProperty)
    float SecondsUntilVehicleHitVelocityClears; // 0x2534 (Size: 0x4, Type: FloatProperty)
    bool bOverrideDamageFromInstigator; // 0x2538 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2539[0x5f]; // 0x2539 (Size: 0x5f, Type: PaddingProperty)
    FDelMarVehicleConfigOverrides ConfigOverrides; // 0x2598 (Size: 0xa0, Type: StructProperty)
    uint8_t Pad_2638[0xc08]; // 0x2638 (Size: 0xc08, Type: PaddingProperty)
    float VisualSteerAngleInterpRate; // 0x3240 (Size: 0x4, Type: FloatProperty)
    float DriftVisualSteerAngleInterpRate; // 0x3244 (Size: 0x4, Type: FloatProperty)
    bool bOverrideVisualSteeringAngle; // 0x3248 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3249[0x3]; // 0x3249 (Size: 0x3, Type: PaddingProperty)
    float DrivingVisualSteeringDegrees; // 0x324c (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve DriftSteeringDegreesCurve; // 0x3250 (Size: 0x90, Type: StructProperty)
    bool bShowVisualSteerAngleInAir; // 0x32e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32e1[0x7]; // 0x32e1 (Size: 0x7, Type: PaddingProperty)
    UDelMarVehicleBodySetup* BodySetup; // 0x32e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_32f0[0x18]; // 0x32f0 (Size: 0x18, Type: PaddingProperty)
    TWeakObjectPtr<UDelMarRaceConfigComponent*> ActiveRaceConfig; // 0x3308 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTimeManagerComponent*> RaceTimeManager; // 0x3310 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarGlobalInputDisabler*> GlobalInputDisabler; // 0x3318 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3320[0x10]; // 0x3320 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnVehicleWheelsLeftGround[0x10]; // 0x3330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSpeedometerSpeedChanged[0x10]; // 0x3340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float MinNoThrottleSpeed; // 0x3350 (Size: 0x4, Type: FloatProperty)
    float SpeedSlowdownSpeedometerSeconds; // 0x3354 (Size: 0x4, Type: FloatProperty)
    TArray<FGameplayTag> SpeedSlowdownTags; // 0x3358 (Size: 0x10, Type: ArrayProperty)
    uint8_t InvertSteerMethod; // 0x3368 (Size: 0x1, Type: EnumProperty)
    bool bPitchInverted; // 0x3369 (Size: 0x1, Type: BoolProperty)
    bool bVerticalKickflipInverted; // 0x336a (Size: 0x1, Type: BoolProperty)
    bool bAerialPitchActivationEnabled; // 0x336b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_336c[0x34]; // 0x336c (Size: 0x34, Type: PaddingProperty)
    uint8_t OnBonusSpeedActivated[0x10]; // 0x33a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBonusSpeedDeactivated[0x10]; // 0x33b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBonusSpeedChanged[0x10]; // 0x33c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAnyWheelsOnGroundChanged[0x10]; // 0x33d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWheelsOnGroundChanged[0x10]; // 0x33e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleForwardStateChanged[0x10]; // 0x33f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3400[0xc0]; // 0x3400 (Size: 0xc0, Type: PaddingProperty)
    uint8_t OnDelMarVehicleHitWall[0x10]; // 0x34c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDelMarVehicleHitVehicle[0x10]; // 0x34d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDelMarVehicleHitByVehicle[0x10]; // 0x34e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleLanded[0x10]; // 0x34f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3500[0x40]; // 0x3500 (Size: 0x40, Type: PaddingProperty)
    uint8_t OnWorldBonusSpeedStackGained[0x10]; // 0x3540 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWorldBonusSpeedStackLost[0x10]; // 0x3550 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3560[0x70]; // 0x3560 (Size: 0x70, Type: PaddingProperty)
    uint8_t OnVehicleStartedSkydiving[0x10]; // 0x35d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleStoppedSkydiving[0x10]; // 0x35e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_35f0[0x10]; // 0x35f0 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnDriftActivated[0x10]; // 0x3600 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftDeactivated[0x10]; // 0x3610 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftSlipAngleRatioChanged[0x10]; // 0x3620 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftKickActivated[0x10]; // 0x3630 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftKickDeactivated[0x10]; // 0x3640 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftControlChanged[0x10]; // 0x3650 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftDurationChanged[0x10]; // 0x3660 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3670[0x50]; // 0x3670 (Size: 0x50, Type: PaddingProperty)
    uint8_t OnEnteredDriftBoostRange[0x10]; // 0x36c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnExitedDriftBoostRange[0x10]; // 0x36d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStartedLosingAppliedDriftBoost[0x10]; // 0x36e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftBoostActivated[0x10]; // 0x36f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDriftBoostDeactivated[0x10]; // 0x3700 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMaxPotentialReached[0x10]; // 0x3710 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMaxPotentialLost[0x10]; // 0x3720 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAllPotentialLost[0x10]; // 0x3730 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEarnedDriftBoost[0x10]; // 0x3740 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPotentialDriftBoostChanged[0x10]; // 0x3750 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3760[0x38]; // 0x3760 (Size: 0x38, Type: PaddingProperty)
    uint8_t OnDraftActivated[0x10]; // 0x3798 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDraftDeactivated[0x10]; // 0x37a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDraftStateChanged[0x10]; // 0x37b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnReachedMaxBonusSpeed[0x10]; // 0x37c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_37d8[0x34]; // 0x37d8 (Size: 0x34, Type: PaddingProperty)
    FDelMarRubberbandingConfig RubberbandingConfig; // 0x380c (Size: 0x28, Type: StructProperty)
    uint8_t Pad_3834[0x34]; // 0x3834 (Size: 0x34, Type: PaddingProperty)
    uint8_t OnStartlineBoostActivated[0x10]; // 0x3868 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStartlineBoostDeactivated[0x10]; // 0x3878 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStartlineBoostFailed[0x10]; // 0x3888 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FDelMarStartlineBoostData StartlineBoostData; // 0x3898 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_38ac[0x1c]; // 0x38ac (Size: 0x1c, Type: PaddingProperty)
    uint8_t OnStrafeActivated[0x10]; // 0x38c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStrafeDeactivated[0x10]; // 0x38d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStrafeCooldownChanged[0x10]; // 0x38e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStrafeUsabilityChanged[0x10]; // 0x38f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStrafeDisabledChanged[0x10]; // 0x3908 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3918[0x20]; // 0x3918 (Size: 0x20, Type: PaddingProperty)
    uint8_t OnTurboActivated[0x10]; // 0x3938 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTurboDeactivated[0x10]; // 0x3948 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTurboChargesUpdated[0x10]; // 0x3958 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTurboBonusZoneStateChanged[0x10]; // 0x3968 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTurboChargeUsed[0x10]; // 0x3978 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float TurboCharges; // 0x3988 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_398c[0x44]; // 0x398c (Size: 0x44, Type: PaddingProperty)
    uint8_t OnKickflipActivated[0x10]; // 0x39d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKickflipDeactivated[0x10]; // 0x39e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKickflipSuctionActivated[0x10]; // 0x39f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKickflipSuctionDeactivated[0x10]; // 0x3a00 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKickflipDistanceToSuctionSurfaceChanged[0x10]; // 0x3a10 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKickflipDurationChanged[0x10]; // 0x3a20 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKickflipActivationChargesChanged[0x10]; // 0x3a30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3a40[0x88]; // 0x3a40 (Size: 0x88, Type: PaddingProperty)
    uint8_t OnReattachmentActivated[0x10]; // 0x3ac8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnReattachmentDeactivated[0x10]; // 0x3ad8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FVector ForcedReattachmentDirection; // 0x3ae8 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_3b00[0x28]; // 0x3b00 (Size: 0x28, Type: PaddingProperty)
    uint8_t OnUnderthrustActivated[0x10]; // 0x3b28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnUnderthrustDeactivated[0x10]; // 0x3b38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnUnderthrustPercentChanged[0x10]; // 0x3b48 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnUnderthrustExhausted[0x10]; // 0x3b58 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3b68[0x18]; // 0x3b68 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnJumpActivated[0x10]; // 0x3b80 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnJumpDeactivated[0x10]; // 0x3b90 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3ba0[0x8]; // 0x3ba0 (Size: 0x8, Type: PaddingProperty)
    float DemolitionRespawnSeconds; // 0x3ba8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3bac[0x4]; // 0x3bac (Size: 0x4, Type: PaddingProperty)
    uint8_t OnVehicleDemolished[0x10]; // 0x3bb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDemolishPressDurationUpdated[0x10]; // 0x3bc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float HealthOverride; // 0x3bd0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3bd4[0x1c]; // 0x3bd4 (Size: 0x1c, Type: PaddingProperty)
    uint8_t OnHazardHit[0x10]; // 0x3bf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInvulnerabilityActivated[0x10]; // 0x3c00 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInvulnerabilityDeactivated[0x10]; // 0x3c10 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3c20[0x4]; // 0x3c20 (Size: 0x4, Type: PaddingProperty)
    float MaxSpawnBroadcastSeconds; // 0x3c24 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleSpawnInfo SpawnInfo; // 0x3c28 (Size: 0x10, Type: StructProperty)
    uint8_t OnDelMarVehicleSpawned[0x10]; // 0x3c38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bAllowExitingVehicle; // 0x3c48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c49[0x7]; // 0x3c49 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnVehicleTeleportEntered[0x10]; // 0x3c50 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleTeleportExit[0x10]; // 0x3c60 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleAppliedTeleportRotation[0x10]; // 0x3c70 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleAppliedTeleportLocation[0x10]; // 0x3c80 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnvironmentEffectCueActivated[0x10]; // 0x3c90 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnvironmentEffectCueRemoved[0x10]; // 0x3ca0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAirFreestyleActivated[0x10]; // 0x3cb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAirFreestyleDeactivated[0x10]; // 0x3cc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3cd0[0x8]; // 0x3cd0 (Size: 0x8, Type: PaddingProperty)
    ADelMarAudioController* CachedVehicleAudioController; // 0x3cd8 (Size: 0x8, Type: ObjectProperty)
    bool bVehicleCollisionsEnabled; // 0x3ce0 (Size: 0x1, Type: BoolProperty)
    bool bPawnCollisionsEnabled; // 0x3ce1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ce2[0xe]; // 0x3ce2 (Size: 0xe, Type: PaddingProperty)
    bool bUsePredictiveInterpolation; // 0x3cf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3cf1[0x7]; // 0x3cf1 (Size: 0x7, Type: PaddingProperty)
    UPostProcessComponent* PostProcessComp; // 0x3cf8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3d00[0x8]; // 0x3d00 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnVehicleCustomizationCompletedDelegate[0x10]; // 0x3d08 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3d18[0x58]; // 0x3d18 (Size: 0x58, Type: PaddingProperty)

public:
    virtual void AddTargetSpeedAdjustment(FName& const Source, float& Value); // 0x11ca2c6c (Index: 0x0, Flags: Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable)
    void AddWorldBonusSpeedStack(const FDelMarWorldBonusSpeedStack BonusSpeedStack); // 0x11ca2e78 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ClearConfigOverrides(); // 0x11ca2f88 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    virtual void DemolishVehicle(FGameplayTag& InCausedByTag); // 0x11ca2f9c (Index: 0x3, Flags: Net|NetReliableNative|Event|NetMulticast|Public)
    UDelMarVehicleCosmeticComponent* GetCosmeticComponent() const; // 0x11ca32c0 (Index: 0x4, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarRaceManager* GetRaceManager() const; // 0x11ca3558 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarTrackPositionComponent* GetTrackPositionComponent() const; // 0x11ca3608 (Index: 0x6, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInvulnerabilityActive() const; // 0x11ca402c (Index: 0xf, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsWheelOnGround(EDelMarVehicleWheelIndex& WheelIndex) const; // 0x11ca41ec (Index: 0x11, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnRep_TurboCharges(); // 0x11ca4a00 (Index: 0x18, Flags: Final|Native|Public)
    virtual void ResetRunPressed(); // 0x11ca57f0 (Index: 0x19, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ResetTrackPosition(ADelMarTrackBase*& Track, int32_t& TrackSegment); // 0x11ca5808 (Index: 0x1a, Flags: Net|NetReliableNative|Event|NetMulticast|Public)
    virtual void ServerAddReplicatedGameplayTag(FGameplayTag& const InTag); // 0x11ca5a14 (Index: 0x1b, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerAddReplicatedGameplayTags(FGameplayTagContainer& const InTags); // 0x11ca5adc (Index: 0x1c, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerDemolishVehicle(FGameplayTag& InCausedByTag); // 0x11ca5dd8 (Index: 0x1d, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerNotifyTurboActivated(); // 0xebed380 (Index: 0x1e, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerRemoveReplicatedGameplayTag(FGameplayTag& const InTag); // 0x11ca5e9c (Index: 0x20, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerRemoveReplicatedGameplayTags(FGameplayTagContainer& const InTags); // 0x11ca5f64 (Index: 0x21, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerTeleportVehicleEntered(); // 0xec006e0 (Index: 0x23, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerTeleportVehicleExited(); // 0xebff57c (Index: 0x24, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    void SetConfigOverrides(FDelMarVehicleConfigOverrides& InConfigOverrides); // 0x11ca6390 (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)
    void SetVehicleMesh(USkeletalMesh*& NewMesh, UPhysicsAsset*& PhysicsAsset); // 0x11ca65f4 (Index: 0x26, Flags: Native|Public|BlueprintCallable)
    virtual void TeleportVehicleEntered(); // 0xd124e88 (Index: 0x27, Flags: Net|NetReliableNative|Event|NetMulticast|Public)
    virtual void TeleportVehicleExited(); // 0xcf5b3d8 (Index: 0x28, Flags: Net|NetReliableNative|Event|NetMulticast|Public)
    bool VehicleHasTag(FGameplayTag& const InTag) const; // 0x11ca6d5c (Index: 0x2a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    bool IsRespawnEffectSignificant() const; // 0x11ca4080 (Index: 0x10, Flags: Final|Native|Private|BlueprintCallable|Const)
    void OnRep_ConfigOverrides() const; // 0x11ca4808 (Index: 0x15, Flags: Final|Native|Private|Const)
    void OnRep_SpawnInfo(); // 0x11ca49d4 (Index: 0x16, Flags: Final|Native|Private)
    void OnRep_StartlineBoostData(); // 0x11ca49e8 (Index: 0x17, Flags: Final|Native|Private)

protected:
    void HandleAerialThrottleBrakeChanged(); // 0x11ca3638 (Index: 0x7, Flags: Final|Native|Protected)
    void HandleFinishedCharacterCustomization(AFortPlayerPawn*& PlayerPawn); // 0x11ca3718 (Index: 0x8, Flags: Final|Native|Protected)
    void HandleFinishVehicleCosmeticsEvent(const FVehicleCosmeticsFinishedPayload Payload); // 0x11ca364c (Index: 0x9, Flags: Final|Native|Protected|HasOutParms)
    void HandleNewPlayerState(AFortPlayerPawn*& Pawn); // 0x11ca38f4 (Index: 0xa, Flags: Final|Native|Protected)
    void HandlePitchDeadzoneChanged(); // 0x11ca3a20 (Index: 0xb, Flags: Final|Native|Protected)
    void HandleSteerDeadzoneChanged(); // 0x11ca3eb8 (Index: 0xc, Flags: Final|Native|Protected)
    void HandleThrottleDeadzoneChanged(); // 0x11ca3ecc (Index: 0xd, Flags: Final|Native|Protected)
    void HandleThrottleToggleChanged(); // 0x11ca3ee0 (Index: 0xe, Flags: Final|Native|Protected)
    virtual void OnApplyOverlapFilter(); // 0x11ca466c (Index: 0x12, Flags: Native|Event|Protected|BlueprintEvent)
    void OnRep_bPawnCollisionsEnabled(); // 0x11ca4afc (Index: 0x13, Flags: Final|Native|Protected)
    void OnRep_bVehicleCollisionsEnabled(); // 0x11ca4b14 (Index: 0x14, Flags: Final|Native|Protected)
    virtual void ServerOnClientTeleport(); // 0xeb5aab0 (Index: 0x1f, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerSetLocalDriverHasReplicatedTheVehicle(bool& bNewValue); // 0x11ca6260 (Index: 0x22, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    void TryGetFortClientSettings(); // 0x11ca6804 (Index: 0x29, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarVehicle) == 0x3d70, "Size mismatch for ADelMarVehicle");
static_assert(offsetof(ADelMarVehicle, DefaultCameraMode) == 0x2200, "Offset mismatch for ADelMarVehicle::DefaultCameraMode");
static_assert(offsetof(ADelMarVehicle, SeatIndexCameraModes) == 0x2208, "Offset mismatch for ADelMarVehicle::SeatIndexCameraModes");
static_assert(offsetof(ADelMarVehicle, bLocalDriverHasReplicatedVehicle) == 0x2218, "Offset mismatch for ADelMarVehicle::bLocalDriverHasReplicatedVehicle");
static_assert(offsetof(ADelMarVehicle, PendingDriverInputState) == 0x2228, "Offset mismatch for ADelMarVehicle::PendingDriverInputState");
static_assert(offsetof(ADelMarVehicle, CurrentInputType) == 0x2268, "Offset mismatch for ADelMarVehicle::CurrentInputType");
static_assert(offsetof(ADelMarVehicle, DistanceToPack) == 0x2288, "Offset mismatch for ADelMarVehicle::DistanceToPack");
static_assert(offsetof(ADelMarVehicle, DistanceFromTrackFinish) == 0x228c, "Offset mismatch for ADelMarVehicle::DistanceFromTrackFinish");
static_assert(offsetof(ADelMarVehicle, RaceStatusSpeedModifier) == 0x2290, "Offset mismatch for ADelMarVehicle::RaceStatusSpeedModifier");
static_assert(offsetof(ADelMarVehicle, TurboBoostChanceCache) == 0x2294, "Offset mismatch for ADelMarVehicle::TurboBoostChanceCache");
static_assert(offsetof(ADelMarVehicle, ATTR_bVehicleThrottleDisabled) == 0x2298, "Offset mismatch for ADelMarVehicle::ATTR_bVehicleThrottleDisabled");
static_assert(offsetof(ADelMarVehicle, ThrottleAction) == 0x22a0, "Offset mismatch for ADelMarVehicle::ThrottleAction");
static_assert(offsetof(ADelMarVehicle, BrakeAction) == 0x22b0, "Offset mismatch for ADelMarVehicle::BrakeAction");
static_assert(offsetof(ADelMarVehicle, SteerAction) == 0x22c0, "Offset mismatch for ADelMarVehicle::SteerAction");
static_assert(offsetof(ADelMarVehicle, SteerLeftAction) == 0x22d0, "Offset mismatch for ADelMarVehicle::SteerLeftAction");
static_assert(offsetof(ADelMarVehicle, SteerRightAction) == 0x22e0, "Offset mismatch for ADelMarVehicle::SteerRightAction");
static_assert(offsetof(ADelMarVehicle, PitchAction) == 0x22f0, "Offset mismatch for ADelMarVehicle::PitchAction");
static_assert(offsetof(ADelMarVehicle, PitchUpAction) == 0x2300, "Offset mismatch for ADelMarVehicle::PitchUpAction");
static_assert(offsetof(ADelMarVehicle, PitchDownAction) == 0x2310, "Offset mismatch for ADelMarVehicle::PitchDownAction");
static_assert(offsetof(ADelMarVehicle, RollAction) == 0x2320, "Offset mismatch for ADelMarVehicle::RollAction");
static_assert(offsetof(ADelMarVehicle, YawAction) == 0x2330, "Offset mismatch for ADelMarVehicle::YawAction");
static_assert(offsetof(ADelMarVehicle, DriftAction) == 0x2340, "Offset mismatch for ADelMarVehicle::DriftAction");
static_assert(offsetof(ADelMarVehicle, JumpAction) == 0x2350, "Offset mismatch for ADelMarVehicle::JumpAction");
static_assert(offsetof(ADelMarVehicle, KickFlipAction) == 0x2360, "Offset mismatch for ADelMarVehicle::KickFlipAction");
static_assert(offsetof(ADelMarVehicle, UnderthrustAction) == 0x2370, "Offset mismatch for ADelMarVehicle::UnderthrustAction");
static_assert(offsetof(ADelMarVehicle, TurboAction) == 0x2380, "Offset mismatch for ADelMarVehicle::TurboAction");
static_assert(offsetof(ADelMarVehicle, DelMarExitAction) == 0x2390, "Offset mismatch for ADelMarVehicle::DelMarExitAction");
static_assert(offsetof(ADelMarVehicle, ResetRunAction) == 0x23a0, "Offset mismatch for ADelMarVehicle::ResetRunAction");
static_assert(offsetof(ADelMarVehicle, AirFreestyleAction) == 0x23b0, "Offset mismatch for ADelMarVehicle::AirFreestyleAction");
static_assert(offsetof(ADelMarVehicle, StrafeAction) == 0x23c0, "Offset mismatch for ADelMarVehicle::StrafeAction");
static_assert(offsetof(ADelMarVehicle, AerialPitchAction) == 0x23d0, "Offset mismatch for ADelMarVehicle::AerialPitchAction");
static_assert(offsetof(ADelMarVehicle, DemolishAction) == 0x23e0, "Offset mismatch for ADelMarVehicle::DemolishAction");
static_assert(offsetof(ADelMarVehicle, InputManagerClass) == 0x23f0, "Offset mismatch for ADelMarVehicle::InputManagerClass");
static_assert(offsetof(ADelMarVehicle, IdleVelocityLengthThreshold) == 0x2410, "Offset mismatch for ADelMarVehicle::IdleVelocityLengthThreshold");
static_assert(offsetof(ADelMarVehicle, IdleInputSecondsThreshold) == 0x2414, "Offset mismatch for ADelMarVehicle::IdleInputSecondsThreshold");
static_assert(offsetof(ADelMarVehicle, bIdleFromNoInput) == 0x2418, "Offset mismatch for ADelMarVehicle::bIdleFromNoInput");
static_assert(offsetof(ADelMarVehicle, RaceManager) == 0x2460, "Offset mismatch for ADelMarVehicle::RaceManager");
static_assert(offsetof(ADelMarVehicle, NetworkPhysicsComponent) == 0x2468, "Offset mismatch for ADelMarVehicle::NetworkPhysicsComponent");
static_assert(offsetof(ADelMarVehicle, CosmeticComponent) == 0x2470, "Offset mismatch for ADelMarVehicle::CosmeticComponent");
static_assert(offsetof(ADelMarVehicle, DelMarVehicleMovementSet) == 0x2478, "Offset mismatch for ADelMarVehicle::DelMarVehicleMovementSet");
static_assert(offsetof(ADelMarVehicle, FortSettings) == 0x2480, "Offset mismatch for ADelMarVehicle::FortSettings");
static_assert(offsetof(ADelMarVehicle, TrackPositionComponentClass) == 0x2488, "Offset mismatch for ADelMarVehicle::TrackPositionComponentClass");
static_assert(offsetof(ADelMarVehicle, TrackPositionComponent) == 0x2490, "Offset mismatch for ADelMarVehicle::TrackPositionComponent");
static_assert(offsetof(ADelMarVehicle, WheelSkeletalMeshComps) == 0x24a0, "Offset mismatch for ADelMarVehicle::WheelSkeletalMeshComps");
static_assert(offsetof(ADelMarVehicle, PlayerInVehicleEvents) == 0x24b0, "Offset mismatch for ADelMarVehicle::PlayerInVehicleEvents");
static_assert(offsetof(ADelMarVehicle, NumAllowedVehicleCosmeticChanges) == 0x2500, "Offset mismatch for ADelMarVehicle::NumAllowedVehicleCosmeticChanges");
static_assert(offsetof(ADelMarVehicle, CachedContacts) == 0x2508, "Offset mismatch for ADelMarVehicle::CachedContacts");
static_assert(offsetof(ADelMarVehicle, NearbyTrackDistanceThreshold) == 0x2518, "Offset mismatch for ADelMarVehicle::NearbyTrackDistanceThreshold");
static_assert(offsetof(ADelMarVehicle, MaxStableSpeedToUpdateWheels) == 0x2530, "Offset mismatch for ADelMarVehicle::MaxStableSpeedToUpdateWheels");
static_assert(offsetof(ADelMarVehicle, SecondsUntilVehicleHitVelocityClears) == 0x2534, "Offset mismatch for ADelMarVehicle::SecondsUntilVehicleHitVelocityClears");
static_assert(offsetof(ADelMarVehicle, bOverrideDamageFromInstigator) == 0x2538, "Offset mismatch for ADelMarVehicle::bOverrideDamageFromInstigator");
static_assert(offsetof(ADelMarVehicle, ConfigOverrides) == 0x2598, "Offset mismatch for ADelMarVehicle::ConfigOverrides");
static_assert(offsetof(ADelMarVehicle, VisualSteerAngleInterpRate) == 0x3240, "Offset mismatch for ADelMarVehicle::VisualSteerAngleInterpRate");
static_assert(offsetof(ADelMarVehicle, DriftVisualSteerAngleInterpRate) == 0x3244, "Offset mismatch for ADelMarVehicle::DriftVisualSteerAngleInterpRate");
static_assert(offsetof(ADelMarVehicle, bOverrideVisualSteeringAngle) == 0x3248, "Offset mismatch for ADelMarVehicle::bOverrideVisualSteeringAngle");
static_assert(offsetof(ADelMarVehicle, DrivingVisualSteeringDegrees) == 0x324c, "Offset mismatch for ADelMarVehicle::DrivingVisualSteeringDegrees");
static_assert(offsetof(ADelMarVehicle, DriftSteeringDegreesCurve) == 0x3250, "Offset mismatch for ADelMarVehicle::DriftSteeringDegreesCurve");
static_assert(offsetof(ADelMarVehicle, bShowVisualSteerAngleInAir) == 0x32e0, "Offset mismatch for ADelMarVehicle::bShowVisualSteerAngleInAir");
static_assert(offsetof(ADelMarVehicle, BodySetup) == 0x32e8, "Offset mismatch for ADelMarVehicle::BodySetup");
static_assert(offsetof(ADelMarVehicle, ActiveRaceConfig) == 0x3308, "Offset mismatch for ADelMarVehicle::ActiveRaceConfig");
static_assert(offsetof(ADelMarVehicle, RaceTimeManager) == 0x3310, "Offset mismatch for ADelMarVehicle::RaceTimeManager");
static_assert(offsetof(ADelMarVehicle, GlobalInputDisabler) == 0x3318, "Offset mismatch for ADelMarVehicle::GlobalInputDisabler");
static_assert(offsetof(ADelMarVehicle, OnVehicleWheelsLeftGround) == 0x3330, "Offset mismatch for ADelMarVehicle::OnVehicleWheelsLeftGround");
static_assert(offsetof(ADelMarVehicle, OnSpeedometerSpeedChanged) == 0x3340, "Offset mismatch for ADelMarVehicle::OnSpeedometerSpeedChanged");
static_assert(offsetof(ADelMarVehicle, MinNoThrottleSpeed) == 0x3350, "Offset mismatch for ADelMarVehicle::MinNoThrottleSpeed");
static_assert(offsetof(ADelMarVehicle, SpeedSlowdownSpeedometerSeconds) == 0x3354, "Offset mismatch for ADelMarVehicle::SpeedSlowdownSpeedometerSeconds");
static_assert(offsetof(ADelMarVehicle, SpeedSlowdownTags) == 0x3358, "Offset mismatch for ADelMarVehicle::SpeedSlowdownTags");
static_assert(offsetof(ADelMarVehicle, InvertSteerMethod) == 0x3368, "Offset mismatch for ADelMarVehicle::InvertSteerMethod");
static_assert(offsetof(ADelMarVehicle, bPitchInverted) == 0x3369, "Offset mismatch for ADelMarVehicle::bPitchInverted");
static_assert(offsetof(ADelMarVehicle, bVerticalKickflipInverted) == 0x336a, "Offset mismatch for ADelMarVehicle::bVerticalKickflipInverted");
static_assert(offsetof(ADelMarVehicle, bAerialPitchActivationEnabled) == 0x336b, "Offset mismatch for ADelMarVehicle::bAerialPitchActivationEnabled");
static_assert(offsetof(ADelMarVehicle, OnBonusSpeedActivated) == 0x33a0, "Offset mismatch for ADelMarVehicle::OnBonusSpeedActivated");
static_assert(offsetof(ADelMarVehicle, OnBonusSpeedDeactivated) == 0x33b0, "Offset mismatch for ADelMarVehicle::OnBonusSpeedDeactivated");
static_assert(offsetof(ADelMarVehicle, OnBonusSpeedChanged) == 0x33c0, "Offset mismatch for ADelMarVehicle::OnBonusSpeedChanged");
static_assert(offsetof(ADelMarVehicle, OnAnyWheelsOnGroundChanged) == 0x33d0, "Offset mismatch for ADelMarVehicle::OnAnyWheelsOnGroundChanged");
static_assert(offsetof(ADelMarVehicle, OnWheelsOnGroundChanged) == 0x33e0, "Offset mismatch for ADelMarVehicle::OnWheelsOnGroundChanged");
static_assert(offsetof(ADelMarVehicle, OnVehicleForwardStateChanged) == 0x33f0, "Offset mismatch for ADelMarVehicle::OnVehicleForwardStateChanged");
static_assert(offsetof(ADelMarVehicle, OnDelMarVehicleHitWall) == 0x34c0, "Offset mismatch for ADelMarVehicle::OnDelMarVehicleHitWall");
static_assert(offsetof(ADelMarVehicle, OnDelMarVehicleHitVehicle) == 0x34d0, "Offset mismatch for ADelMarVehicle::OnDelMarVehicleHitVehicle");
static_assert(offsetof(ADelMarVehicle, OnDelMarVehicleHitByVehicle) == 0x34e0, "Offset mismatch for ADelMarVehicle::OnDelMarVehicleHitByVehicle");
static_assert(offsetof(ADelMarVehicle, OnVehicleLanded) == 0x34f0, "Offset mismatch for ADelMarVehicle::OnVehicleLanded");
static_assert(offsetof(ADelMarVehicle, OnWorldBonusSpeedStackGained) == 0x3540, "Offset mismatch for ADelMarVehicle::OnWorldBonusSpeedStackGained");
static_assert(offsetof(ADelMarVehicle, OnWorldBonusSpeedStackLost) == 0x3550, "Offset mismatch for ADelMarVehicle::OnWorldBonusSpeedStackLost");
static_assert(offsetof(ADelMarVehicle, OnVehicleStartedSkydiving) == 0x35d0, "Offset mismatch for ADelMarVehicle::OnVehicleStartedSkydiving");
static_assert(offsetof(ADelMarVehicle, OnVehicleStoppedSkydiving) == 0x35e0, "Offset mismatch for ADelMarVehicle::OnVehicleStoppedSkydiving");
static_assert(offsetof(ADelMarVehicle, OnDriftActivated) == 0x3600, "Offset mismatch for ADelMarVehicle::OnDriftActivated");
static_assert(offsetof(ADelMarVehicle, OnDriftDeactivated) == 0x3610, "Offset mismatch for ADelMarVehicle::OnDriftDeactivated");
static_assert(offsetof(ADelMarVehicle, OnDriftSlipAngleRatioChanged) == 0x3620, "Offset mismatch for ADelMarVehicle::OnDriftSlipAngleRatioChanged");
static_assert(offsetof(ADelMarVehicle, OnDriftKickActivated) == 0x3630, "Offset mismatch for ADelMarVehicle::OnDriftKickActivated");
static_assert(offsetof(ADelMarVehicle, OnDriftKickDeactivated) == 0x3640, "Offset mismatch for ADelMarVehicle::OnDriftKickDeactivated");
static_assert(offsetof(ADelMarVehicle, OnDriftControlChanged) == 0x3650, "Offset mismatch for ADelMarVehicle::OnDriftControlChanged");
static_assert(offsetof(ADelMarVehicle, OnDriftDurationChanged) == 0x3660, "Offset mismatch for ADelMarVehicle::OnDriftDurationChanged");
static_assert(offsetof(ADelMarVehicle, OnEnteredDriftBoostRange) == 0x36c0, "Offset mismatch for ADelMarVehicle::OnEnteredDriftBoostRange");
static_assert(offsetof(ADelMarVehicle, OnExitedDriftBoostRange) == 0x36d0, "Offset mismatch for ADelMarVehicle::OnExitedDriftBoostRange");
static_assert(offsetof(ADelMarVehicle, OnStartedLosingAppliedDriftBoost) == 0x36e0, "Offset mismatch for ADelMarVehicle::OnStartedLosingAppliedDriftBoost");
static_assert(offsetof(ADelMarVehicle, OnDriftBoostActivated) == 0x36f0, "Offset mismatch for ADelMarVehicle::OnDriftBoostActivated");
static_assert(offsetof(ADelMarVehicle, OnDriftBoostDeactivated) == 0x3700, "Offset mismatch for ADelMarVehicle::OnDriftBoostDeactivated");
static_assert(offsetof(ADelMarVehicle, OnMaxPotentialReached) == 0x3710, "Offset mismatch for ADelMarVehicle::OnMaxPotentialReached");
static_assert(offsetof(ADelMarVehicle, OnMaxPotentialLost) == 0x3720, "Offset mismatch for ADelMarVehicle::OnMaxPotentialLost");
static_assert(offsetof(ADelMarVehicle, OnAllPotentialLost) == 0x3730, "Offset mismatch for ADelMarVehicle::OnAllPotentialLost");
static_assert(offsetof(ADelMarVehicle, OnEarnedDriftBoost) == 0x3740, "Offset mismatch for ADelMarVehicle::OnEarnedDriftBoost");
static_assert(offsetof(ADelMarVehicle, OnPotentialDriftBoostChanged) == 0x3750, "Offset mismatch for ADelMarVehicle::OnPotentialDriftBoostChanged");
static_assert(offsetof(ADelMarVehicle, OnDraftActivated) == 0x3798, "Offset mismatch for ADelMarVehicle::OnDraftActivated");
static_assert(offsetof(ADelMarVehicle, OnDraftDeactivated) == 0x37a8, "Offset mismatch for ADelMarVehicle::OnDraftDeactivated");
static_assert(offsetof(ADelMarVehicle, OnDraftStateChanged) == 0x37b8, "Offset mismatch for ADelMarVehicle::OnDraftStateChanged");
static_assert(offsetof(ADelMarVehicle, OnReachedMaxBonusSpeed) == 0x37c8, "Offset mismatch for ADelMarVehicle::OnReachedMaxBonusSpeed");
static_assert(offsetof(ADelMarVehicle, RubberbandingConfig) == 0x380c, "Offset mismatch for ADelMarVehicle::RubberbandingConfig");
static_assert(offsetof(ADelMarVehicle, OnStartlineBoostActivated) == 0x3868, "Offset mismatch for ADelMarVehicle::OnStartlineBoostActivated");
static_assert(offsetof(ADelMarVehicle, OnStartlineBoostDeactivated) == 0x3878, "Offset mismatch for ADelMarVehicle::OnStartlineBoostDeactivated");
static_assert(offsetof(ADelMarVehicle, OnStartlineBoostFailed) == 0x3888, "Offset mismatch for ADelMarVehicle::OnStartlineBoostFailed");
static_assert(offsetof(ADelMarVehicle, StartlineBoostData) == 0x3898, "Offset mismatch for ADelMarVehicle::StartlineBoostData");
static_assert(offsetof(ADelMarVehicle, OnStrafeActivated) == 0x38c8, "Offset mismatch for ADelMarVehicle::OnStrafeActivated");
static_assert(offsetof(ADelMarVehicle, OnStrafeDeactivated) == 0x38d8, "Offset mismatch for ADelMarVehicle::OnStrafeDeactivated");
static_assert(offsetof(ADelMarVehicle, OnStrafeCooldownChanged) == 0x38e8, "Offset mismatch for ADelMarVehicle::OnStrafeCooldownChanged");
static_assert(offsetof(ADelMarVehicle, OnStrafeUsabilityChanged) == 0x38f8, "Offset mismatch for ADelMarVehicle::OnStrafeUsabilityChanged");
static_assert(offsetof(ADelMarVehicle, OnStrafeDisabledChanged) == 0x3908, "Offset mismatch for ADelMarVehicle::OnStrafeDisabledChanged");
static_assert(offsetof(ADelMarVehicle, OnTurboActivated) == 0x3938, "Offset mismatch for ADelMarVehicle::OnTurboActivated");
static_assert(offsetof(ADelMarVehicle, OnTurboDeactivated) == 0x3948, "Offset mismatch for ADelMarVehicle::OnTurboDeactivated");
static_assert(offsetof(ADelMarVehicle, OnTurboChargesUpdated) == 0x3958, "Offset mismatch for ADelMarVehicle::OnTurboChargesUpdated");
static_assert(offsetof(ADelMarVehicle, OnTurboBonusZoneStateChanged) == 0x3968, "Offset mismatch for ADelMarVehicle::OnTurboBonusZoneStateChanged");
static_assert(offsetof(ADelMarVehicle, OnTurboChargeUsed) == 0x3978, "Offset mismatch for ADelMarVehicle::OnTurboChargeUsed");
static_assert(offsetof(ADelMarVehicle, TurboCharges) == 0x3988, "Offset mismatch for ADelMarVehicle::TurboCharges");
static_assert(offsetof(ADelMarVehicle, OnKickflipActivated) == 0x39d0, "Offset mismatch for ADelMarVehicle::OnKickflipActivated");
static_assert(offsetof(ADelMarVehicle, OnKickflipDeactivated) == 0x39e0, "Offset mismatch for ADelMarVehicle::OnKickflipDeactivated");
static_assert(offsetof(ADelMarVehicle, OnKickflipSuctionActivated) == 0x39f0, "Offset mismatch for ADelMarVehicle::OnKickflipSuctionActivated");
static_assert(offsetof(ADelMarVehicle, OnKickflipSuctionDeactivated) == 0x3a00, "Offset mismatch for ADelMarVehicle::OnKickflipSuctionDeactivated");
static_assert(offsetof(ADelMarVehicle, OnKickflipDistanceToSuctionSurfaceChanged) == 0x3a10, "Offset mismatch for ADelMarVehicle::OnKickflipDistanceToSuctionSurfaceChanged");
static_assert(offsetof(ADelMarVehicle, OnKickflipDurationChanged) == 0x3a20, "Offset mismatch for ADelMarVehicle::OnKickflipDurationChanged");
static_assert(offsetof(ADelMarVehicle, OnKickflipActivationChargesChanged) == 0x3a30, "Offset mismatch for ADelMarVehicle::OnKickflipActivationChargesChanged");
static_assert(offsetof(ADelMarVehicle, OnReattachmentActivated) == 0x3ac8, "Offset mismatch for ADelMarVehicle::OnReattachmentActivated");
static_assert(offsetof(ADelMarVehicle, OnReattachmentDeactivated) == 0x3ad8, "Offset mismatch for ADelMarVehicle::OnReattachmentDeactivated");
static_assert(offsetof(ADelMarVehicle, ForcedReattachmentDirection) == 0x3ae8, "Offset mismatch for ADelMarVehicle::ForcedReattachmentDirection");
static_assert(offsetof(ADelMarVehicle, OnUnderthrustActivated) == 0x3b28, "Offset mismatch for ADelMarVehicle::OnUnderthrustActivated");
static_assert(offsetof(ADelMarVehicle, OnUnderthrustDeactivated) == 0x3b38, "Offset mismatch for ADelMarVehicle::OnUnderthrustDeactivated");
static_assert(offsetof(ADelMarVehicle, OnUnderthrustPercentChanged) == 0x3b48, "Offset mismatch for ADelMarVehicle::OnUnderthrustPercentChanged");
static_assert(offsetof(ADelMarVehicle, OnUnderthrustExhausted) == 0x3b58, "Offset mismatch for ADelMarVehicle::OnUnderthrustExhausted");
static_assert(offsetof(ADelMarVehicle, OnJumpActivated) == 0x3b80, "Offset mismatch for ADelMarVehicle::OnJumpActivated");
static_assert(offsetof(ADelMarVehicle, OnJumpDeactivated) == 0x3b90, "Offset mismatch for ADelMarVehicle::OnJumpDeactivated");
static_assert(offsetof(ADelMarVehicle, DemolitionRespawnSeconds) == 0x3ba8, "Offset mismatch for ADelMarVehicle::DemolitionRespawnSeconds");
static_assert(offsetof(ADelMarVehicle, OnVehicleDemolished) == 0x3bb0, "Offset mismatch for ADelMarVehicle::OnVehicleDemolished");
static_assert(offsetof(ADelMarVehicle, OnDemolishPressDurationUpdated) == 0x3bc0, "Offset mismatch for ADelMarVehicle::OnDemolishPressDurationUpdated");
static_assert(offsetof(ADelMarVehicle, HealthOverride) == 0x3bd0, "Offset mismatch for ADelMarVehicle::HealthOverride");
static_assert(offsetof(ADelMarVehicle, OnHazardHit) == 0x3bf0, "Offset mismatch for ADelMarVehicle::OnHazardHit");
static_assert(offsetof(ADelMarVehicle, OnInvulnerabilityActivated) == 0x3c00, "Offset mismatch for ADelMarVehicle::OnInvulnerabilityActivated");
static_assert(offsetof(ADelMarVehicle, OnInvulnerabilityDeactivated) == 0x3c10, "Offset mismatch for ADelMarVehicle::OnInvulnerabilityDeactivated");
static_assert(offsetof(ADelMarVehicle, MaxSpawnBroadcastSeconds) == 0x3c24, "Offset mismatch for ADelMarVehicle::MaxSpawnBroadcastSeconds");
static_assert(offsetof(ADelMarVehicle, SpawnInfo) == 0x3c28, "Offset mismatch for ADelMarVehicle::SpawnInfo");
static_assert(offsetof(ADelMarVehicle, OnDelMarVehicleSpawned) == 0x3c38, "Offset mismatch for ADelMarVehicle::OnDelMarVehicleSpawned");
static_assert(offsetof(ADelMarVehicle, bAllowExitingVehicle) == 0x3c48, "Offset mismatch for ADelMarVehicle::bAllowExitingVehicle");
static_assert(offsetof(ADelMarVehicle, OnVehicleTeleportEntered) == 0x3c50, "Offset mismatch for ADelMarVehicle::OnVehicleTeleportEntered");
static_assert(offsetof(ADelMarVehicle, OnVehicleTeleportExit) == 0x3c60, "Offset mismatch for ADelMarVehicle::OnVehicleTeleportExit");
static_assert(offsetof(ADelMarVehicle, OnVehicleAppliedTeleportRotation) == 0x3c70, "Offset mismatch for ADelMarVehicle::OnVehicleAppliedTeleportRotation");
static_assert(offsetof(ADelMarVehicle, OnVehicleAppliedTeleportLocation) == 0x3c80, "Offset mismatch for ADelMarVehicle::OnVehicleAppliedTeleportLocation");
static_assert(offsetof(ADelMarVehicle, OnEnvironmentEffectCueActivated) == 0x3c90, "Offset mismatch for ADelMarVehicle::OnEnvironmentEffectCueActivated");
static_assert(offsetof(ADelMarVehicle, OnEnvironmentEffectCueRemoved) == 0x3ca0, "Offset mismatch for ADelMarVehicle::OnEnvironmentEffectCueRemoved");
static_assert(offsetof(ADelMarVehicle, OnAirFreestyleActivated) == 0x3cb0, "Offset mismatch for ADelMarVehicle::OnAirFreestyleActivated");
static_assert(offsetof(ADelMarVehicle, OnAirFreestyleDeactivated) == 0x3cc0, "Offset mismatch for ADelMarVehicle::OnAirFreestyleDeactivated");
static_assert(offsetof(ADelMarVehicle, CachedVehicleAudioController) == 0x3cd8, "Offset mismatch for ADelMarVehicle::CachedVehicleAudioController");
static_assert(offsetof(ADelMarVehicle, bVehicleCollisionsEnabled) == 0x3ce0, "Offset mismatch for ADelMarVehicle::bVehicleCollisionsEnabled");
static_assert(offsetof(ADelMarVehicle, bPawnCollisionsEnabled) == 0x3ce1, "Offset mismatch for ADelMarVehicle::bPawnCollisionsEnabled");
static_assert(offsetof(ADelMarVehicle, bUsePredictiveInterpolation) == 0x3cf0, "Offset mismatch for ADelMarVehicle::bUsePredictiveInterpolation");
static_assert(offsetof(ADelMarVehicle, PostProcessComp) == 0x3cf8, "Offset mismatch for ADelMarVehicle::PostProcessComp");
static_assert(offsetof(ADelMarVehicle, OnVehicleCustomizationCompletedDelegate) == 0x3d08, "Offset mismatch for ADelMarVehicle::OnVehicleCustomizationCompletedDelegate");

// Size: 0x158 (Inherited: 0x250, Single: 0xffffff08)
class UDelMarUIInputControllerComponent : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x68]; // 0xb8 (Size: 0x68, Type: PaddingProperty)
    UInputAction* HudWidgetExpandAction; // 0x120 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ToggleQuestListAction; // 0x128 (Size: 0x8, Type: ObjectProperty)
    UClass* InputManagerClass; // 0x130 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent; // 0x138 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0x140 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> PlayerController; // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerPreferencesComponent*> PlayerPreferences; // 0x150 (Size: 0x8, Type: WeakObjectProperty)

protected:
    void HandleHudWidgetExpandCompleted(); // 0x11b20478 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleHudWidgetExpandTriggered(); // 0x11b2048c (Index: 0x1, Flags: Final|Native|Protected)
    void HandleToggleQuestList(); // 0x11b205c8 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarUIInputControllerComponent) == 0x158, "Size mismatch for UDelMarUIInputControllerComponent");
static_assert(offsetof(UDelMarUIInputControllerComponent, HudWidgetExpandAction) == 0x120, "Offset mismatch for UDelMarUIInputControllerComponent::HudWidgetExpandAction");
static_assert(offsetof(UDelMarUIInputControllerComponent, ToggleQuestListAction) == 0x128, "Offset mismatch for UDelMarUIInputControllerComponent::ToggleQuestListAction");
static_assert(offsetof(UDelMarUIInputControllerComponent, InputManagerClass) == 0x130, "Offset mismatch for UDelMarUIInputControllerComponent::InputManagerClass");
static_assert(offsetof(UDelMarUIInputControllerComponent, InputComponent) == 0x138, "Offset mismatch for UDelMarUIInputControllerComponent::InputComponent");
static_assert(offsetof(UDelMarUIInputControllerComponent, PlayerState) == 0x140, "Offset mismatch for UDelMarUIInputControllerComponent::PlayerState");
static_assert(offsetof(UDelMarUIInputControllerComponent, PlayerController) == 0x148, "Offset mismatch for UDelMarUIInputControllerComponent::PlayerController");
static_assert(offsetof(UDelMarUIInputControllerComponent, PlayerPreferences) == 0x150, "Offset mismatch for UDelMarUIInputControllerComponent::PlayerPreferences");

// Size: 0x68 (Inherited: 0x28, Single: 0x40)
class UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved : public UObject
{
public:
    FDelMarGlobalLeaderboardEntry PersonalBest; // 0x28 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved) == 0x68, "Size mismatch for UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved");
static_assert(offsetof(UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved, PersonalBest) == 0x28, "Offset mismatch for UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved::PersonalBest");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarEvent_GlobalLeaderboardTopLeaderboardEntriesPopulated : public UObject
{
public:
};

static_assert(sizeof(UDelMarEvent_GlobalLeaderboardTopLeaderboardEntriesPopulated) == 0x28, "Size mismatch for UDelMarEvent_GlobalLeaderboardTopLeaderboardEntriesPopulated");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarEvent_GlobalLeaderboardFocusedLeaderboardEntriesPopulated : public UObject
{
public:
};

static_assert(sizeof(UDelMarEvent_GlobalLeaderboardFocusedLeaderboardEntriesPopulated) == 0x28, "Size mismatch for UDelMarEvent_GlobalLeaderboardFocusedLeaderboardEntriesPopulated");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarEvent_GlobalLeaderboardFriendLeaderboardEntriesPopulated : public UObject
{
public:
};

static_assert(sizeof(UDelMarEvent_GlobalLeaderboardFriendLeaderboardEntriesPopulated) == 0x28, "Size mismatch for UDelMarEvent_GlobalLeaderboardFriendLeaderboardEntriesPopulated");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDelMarEvent_PlayerInVehicle : public UObject
{
public:
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    int32_t SeatIndex; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarEvent_PlayerInVehicle) == 0x38, "Size mismatch for UDelMarEvent_PlayerInVehicle");
static_assert(offsetof(UDelMarEvent_PlayerInVehicle, DelMarVehicle) == 0x28, "Offset mismatch for UDelMarEvent_PlayerInVehicle::DelMarVehicle");
static_assert(offsetof(UDelMarEvent_PlayerInVehicle, SeatIndex) == 0x30, "Offset mismatch for UDelMarEvent_PlayerInVehicle::SeatIndex");

// Size: 0xe8 (Inherited: 0x308, Single: 0xfffffde0)
class UDelMarPlayerIdleComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_c8[0x20]; // 0xc8 (Size: 0x20, Type: PaddingProperty)

protected:
    void OnPlayerDisconnected(AFortPlayerStateAthena*& PlayerState, bool& bIsDisconnected); // 0x11b1d00c (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerIdleComponent) == 0xe8, "Size mismatch for UDelMarPlayerIdleComponent");
static_assert(offsetof(UDelMarPlayerIdleComponent, CachedRaceManager) == 0xb8, "Offset mismatch for UDelMarPlayerIdleComponent::CachedRaceManager");
static_assert(offsetof(UDelMarPlayerIdleComponent, CachedDelMarVehicle) == 0xc0, "Offset mismatch for UDelMarPlayerIdleComponent::CachedDelMarVehicle");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDelMarEvent_VehicleDemolish : public UObject
{
public:
    FGameplayTag DemolishReason; // 0x28 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> Vehicle; // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarEvent_VehicleDemolish) == 0x38, "Size mismatch for UDelMarEvent_VehicleDemolish");
static_assert(offsetof(UDelMarEvent_VehicleDemolish, DemolishReason) == 0x28, "Offset mismatch for UDelMarEvent_VehicleDemolish::DemolishReason");
static_assert(offsetof(UDelMarEvent_VehicleDemolish, Vehicle) == 0x2c, "Offset mismatch for UDelMarEvent_VehicleDemolish::Vehicle");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDelMarEvent_PlayerFinishRace : public UObject
{
public:
    double RunTime; // 0x28 (Size: 0x8, Type: DoubleProperty)
    bool bValidRun; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarEvent_PlayerFinishRace) == 0x38, "Size mismatch for UDelMarEvent_PlayerFinishRace");
static_assert(offsetof(UDelMarEvent_PlayerFinishRace, RunTime) == 0x28, "Offset mismatch for UDelMarEvent_PlayerFinishRace::RunTime");
static_assert(offsetof(UDelMarEvent_PlayerFinishRace, bValidRun) == 0x30, "Offset mismatch for UDelMarEvent_PlayerFinishRace::bValidRun");

// Size: 0xc50 (Inherited: 0x45b0, Single: 0xffffc6a0)
class ADelMarActorMover : public AFortCreativeDeviceProp
{
public:
    UClass* ActorClass; // 0xc10 (Size: 0x8, Type: ClassProperty)
    USplineComponent* MovementSpline; // 0xc18 (Size: 0x8, Type: ObjectProperty)
    uint8_t MovementType; // 0xc20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c21[0x7]; // 0xc21 (Size: 0x7, Type: PaddingProperty)
    AActor* ManagedActor; // 0xc28 (Size: 0x8, Type: ObjectProperty)
    UDelMarSplineActorMovementComponent* SplineMovementComponent; // 0xc30 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c38[0x10]; // 0xc38 (Size: 0x10, Type: PaddingProperty)
    float ServerMovementStartTime; // 0xc48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4c[0x4]; // 0xc4c (Size: 0x4, Type: PaddingProperty)

protected:
    void InitializeMovement(); // 0x11b133a8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void OnRep_ServerStartTime(); // 0x11b133bc (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarActorMover) == 0xc50, "Size mismatch for ADelMarActorMover");
static_assert(offsetof(ADelMarActorMover, ActorClass) == 0xc10, "Offset mismatch for ADelMarActorMover::ActorClass");
static_assert(offsetof(ADelMarActorMover, MovementSpline) == 0xc18, "Offset mismatch for ADelMarActorMover::MovementSpline");
static_assert(offsetof(ADelMarActorMover, MovementType) == 0xc20, "Offset mismatch for ADelMarActorMover::MovementType");
static_assert(offsetof(ADelMarActorMover, ManagedActor) == 0xc28, "Offset mismatch for ADelMarActorMover::ManagedActor");
static_assert(offsetof(ADelMarActorMover, SplineMovementComponent) == 0xc30, "Offset mismatch for ADelMarActorMover::SplineMovementComponent");
static_assert(offsetof(ADelMarActorMover, ServerMovementStartTime) == 0xc48, "Offset mismatch for ADelMarActorMover::ServerMovementStartTime");

// Size: 0x5d0 (Inherited: 0x9d8, Single: 0xfffffbf8)
class ADelMarAIController : public AAIController
{
public:
    uint8_t Pad_3c8[0x20]; // 0x3c8 (Size: 0x20, Type: PaddingProperty)
    uint8_t OnLoadoutChanged[0x10]; // 0x3e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FGameplayTag DescriptorTag; // 0x3f8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_3fc[0x4]; // 0x3fc (Size: 0x4, Type: PaddingProperty)
    FFortAthenaLoadout CosmeticLoadoutBC; // 0x400 (Size: 0x140, Type: StructProperty)
    FCosmeticLoadout VehicleCosmeticLoadout; // 0x540 (Size: 0x10, Type: StructProperty)
    FGameplayTag VehicleArchetype; // 0x550 (Size: 0x4, Type: StructProperty)
    uint8_t BotSteerMethod; // 0x554 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_555[0x3]; // 0x555 (Size: 0x3, Type: PaddingProperty)
    UBehaviorTree* BTAssetToRunOnPawnAISpawned; // 0x558 (Size: 0x8, Type: ObjectProperty)
    TArray<UBehaviorTree*> SkillLevelBehaviorTrees; // 0x560 (Size: 0x10, Type: ArrayProperty)
    int32_t MinSkillLevelForRubberbanding; // 0x570 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_574[0x4]; // 0x574 (Size: 0x4, Type: PaddingProperty)
    UClass* OobTubePositionRenderingComponentClass; // 0x578 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle; // 0x580 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_588[0x10]; // 0x588 (Size: 0x10, Type: PaddingProperty)
    int32_t DelMarBotControllerUID; // 0x598 (Size: 0x4, Type: IntProperty)
    int32_t DelMarBotSkillLevel; // 0x59c (Size: 0x4, Type: IntProperty)
    FString DelMarBotPlayerName; // 0x5a0 (Size: 0x10, Type: StrProperty)
    UDelMarAIService* DelMarAIService; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* PlayerBotPawn; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5c0[0x10]; // 0x5c0 (Size: 0x10, Type: PaddingProperty)

protected:
    void HandleGroundedStateChanged(const TScriptInterface<Class> VehicleRef, bool& bValue); // 0x11b125ac (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(ADelMarAIController) == 0x5d0, "Size mismatch for ADelMarAIController");
static_assert(offsetof(ADelMarAIController, OnLoadoutChanged) == 0x3e8, "Offset mismatch for ADelMarAIController::OnLoadoutChanged");
static_assert(offsetof(ADelMarAIController, DescriptorTag) == 0x3f8, "Offset mismatch for ADelMarAIController::DescriptorTag");
static_assert(offsetof(ADelMarAIController, CosmeticLoadoutBC) == 0x400, "Offset mismatch for ADelMarAIController::CosmeticLoadoutBC");
static_assert(offsetof(ADelMarAIController, VehicleCosmeticLoadout) == 0x540, "Offset mismatch for ADelMarAIController::VehicleCosmeticLoadout");
static_assert(offsetof(ADelMarAIController, VehicleArchetype) == 0x550, "Offset mismatch for ADelMarAIController::VehicleArchetype");
static_assert(offsetof(ADelMarAIController, BotSteerMethod) == 0x554, "Offset mismatch for ADelMarAIController::BotSteerMethod");
static_assert(offsetof(ADelMarAIController, BTAssetToRunOnPawnAISpawned) == 0x558, "Offset mismatch for ADelMarAIController::BTAssetToRunOnPawnAISpawned");
static_assert(offsetof(ADelMarAIController, SkillLevelBehaviorTrees) == 0x560, "Offset mismatch for ADelMarAIController::SkillLevelBehaviorTrees");
static_assert(offsetof(ADelMarAIController, MinSkillLevelForRubberbanding) == 0x570, "Offset mismatch for ADelMarAIController::MinSkillLevelForRubberbanding");
static_assert(offsetof(ADelMarAIController, OobTubePositionRenderingComponentClass) == 0x578, "Offset mismatch for ADelMarAIController::OobTubePositionRenderingComponentClass");
static_assert(offsetof(ADelMarAIController, DelMarVehicle) == 0x580, "Offset mismatch for ADelMarAIController::DelMarVehicle");
static_assert(offsetof(ADelMarAIController, DelMarBotControllerUID) == 0x598, "Offset mismatch for ADelMarAIController::DelMarBotControllerUID");
static_assert(offsetof(ADelMarAIController, DelMarBotSkillLevel) == 0x59c, "Offset mismatch for ADelMarAIController::DelMarBotSkillLevel");
static_assert(offsetof(ADelMarAIController, DelMarBotPlayerName) == 0x5a0, "Offset mismatch for ADelMarAIController::DelMarBotPlayerName");
static_assert(offsetof(ADelMarAIController, DelMarAIService) == 0x5b0, "Offset mismatch for ADelMarAIController::DelMarAIService");
static_assert(offsetof(ADelMarAIController, PlayerBotPawn) == 0x5b8, "Offset mismatch for ADelMarAIController::PlayerBotPawn");

// Size: 0x188 (Inherited: 0xa0, Single: 0xe8)
class UDelMarAIService : public UAthenaAIService
{
public:
    UClass* CosmeticComponentClass; // 0x78 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UDelMarAIVehicleCosmeticLibraryData*> VehicleCosmeticLibrary; // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    bool bBotsUniqueIDUseValidAccountID; // 0xa0 (Size: 0x1, Type: BoolProperty)
    bool bUseRegionalNameList; // 0xa1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a2[0x6]; // 0xa2 (Size: 0x6, Type: PaddingProperty)
    TSoftObjectPtr<UFortAthenaAIBotNameDataAsset*> BotNameDataAsset; // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    UClass* AIControllerClass; // 0xc8 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UDataTable*> MMRSpawnTablePtr; // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    int32_t MaxBotFillRandomDeviation; // 0xf0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_f4[0x4]; // 0xf4 (Size: 0x4, Type: PaddingProperty)
    TArray<ADelMarAIController*> DelMarAIControllers; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRespawnManagerComponent*> RespawnManagerComponent; // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackManager*> TrackManager; // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<ADelMarTrack*>> SortedSecondaryTracksAlongPrimary; // 0x120 (Size: 0x10, Type: ArrayProperty)
    TSet<FString> ReservedPlayerNames; // 0x130 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_180[0x8]; // 0x180 (Size: 0x8, Type: PaddingProperty)

public:
    int32_t GetMaxNumberOfPlayers() const; // 0xa2b9a20 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<ADelMarAIController*> GetRegisteredAIBotControllers() const; // 0x11b12520 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void HandlePlayerRegistered(AFortPlayerState*& RegisteredPlayerState); // 0x11b12828 (Index: 0x2, Flags: Final|Native|Protected)
    void HandlePlayerUnregistered(AFortPlayerState*& UnregisteredPlayerState, bool& bSetAsInactive); // 0x11b12bcc (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarAIService) == 0x188, "Size mismatch for UDelMarAIService");
static_assert(offsetof(UDelMarAIService, CosmeticComponentClass) == 0x78, "Offset mismatch for UDelMarAIService::CosmeticComponentClass");
static_assert(offsetof(UDelMarAIService, VehicleCosmeticLibrary) == 0x80, "Offset mismatch for UDelMarAIService::VehicleCosmeticLibrary");
static_assert(offsetof(UDelMarAIService, bBotsUniqueIDUseValidAccountID) == 0xa0, "Offset mismatch for UDelMarAIService::bBotsUniqueIDUseValidAccountID");
static_assert(offsetof(UDelMarAIService, bUseRegionalNameList) == 0xa1, "Offset mismatch for UDelMarAIService::bUseRegionalNameList");
static_assert(offsetof(UDelMarAIService, BotNameDataAsset) == 0xa8, "Offset mismatch for UDelMarAIService::BotNameDataAsset");
static_assert(offsetof(UDelMarAIService, AIControllerClass) == 0xc8, "Offset mismatch for UDelMarAIService::AIControllerClass");
static_assert(offsetof(UDelMarAIService, MMRSpawnTablePtr) == 0xd0, "Offset mismatch for UDelMarAIService::MMRSpawnTablePtr");
static_assert(offsetof(UDelMarAIService, MaxBotFillRandomDeviation) == 0xf0, "Offset mismatch for UDelMarAIService::MaxBotFillRandomDeviation");
static_assert(offsetof(UDelMarAIService, DelMarAIControllers) == 0xf8, "Offset mismatch for UDelMarAIService::DelMarAIControllers");
static_assert(offsetof(UDelMarAIService, RaceManager) == 0x108, "Offset mismatch for UDelMarAIService::RaceManager");
static_assert(offsetof(UDelMarAIService, RespawnManagerComponent) == 0x110, "Offset mismatch for UDelMarAIService::RespawnManagerComponent");
static_assert(offsetof(UDelMarAIService, TrackManager) == 0x118, "Offset mismatch for UDelMarAIService::TrackManager");
static_assert(offsetof(UDelMarAIService, SortedSecondaryTracksAlongPrimary) == 0x120, "Offset mismatch for UDelMarAIService::SortedSecondaryTracksAlongPrimary");
static_assert(offsetof(UDelMarAIService, ReservedPlayerNames) == 0x130, "Offset mismatch for UDelMarAIService::ReservedPlayerNames");

// Size: 0x58 (Inherited: 0x88, Single: 0xffffffd0)
class UDelMarAIVehicleCosmeticLibraryData : public UPrimaryDataAsset
{
public:
    TSoftObjectPtr<UDataTable*> PredefineVehiclCosmeticSetsDataTable; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag CachedArchetypeTag; // 0x50 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarAIVehicleCosmeticLibraryData) == 0x58, "Size mismatch for UDelMarAIVehicleCosmeticLibraryData");
static_assert(offsetof(UDelMarAIVehicleCosmeticLibraryData, PredefineVehiclCosmeticSetsDataTable) == 0x30, "Offset mismatch for UDelMarAIVehicleCosmeticLibraryData::PredefineVehiclCosmeticSetsDataTable");
static_assert(offsetof(UDelMarAIVehicleCosmeticLibraryData, CachedArchetypeTag) == 0x50, "Offset mismatch for UDelMarAIVehicleCosmeticLibraryData::CachedArchetypeTag");

// Size: 0x240 (Inherited: 0x1f0, Single: 0x50)
class UDelMarBTService_ChooseNextTrack : public UDelMarBTService_VehicleBase
{
public:
    FBlackboardKeySelector TargetTrackDecisionKey; // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsOffRoadDriveGoalKey; // 0xc8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsJumpDriveGoalKey; // 0xf0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsFullyBlockedCollisionKey; // 0x118 (Size: 0x28, Type: StructProperty)
    float TrackDecisionMaxTrackDistanceOffset; // 0x140 (Size: 0x4, Type: FloatProperty)
    float TrackDecisionMinTrackDistanceOffset; // 0x144 (Size: 0x4, Type: FloatProperty)
    float TrackEndCheckTrackDistanceOffset; // 0x148 (Size: 0x4, Type: FloatProperty)
    float BotReachedNewTrackDistanceOffset; // 0x14c (Size: 0x4, Type: FloatProperty)
    float SplineResetAvailableTrackIndexThreshold; // 0x150 (Size: 0x4, Type: FloatProperty)
    float AddKickflipWeightDegreeThreshold; // 0x154 (Size: 0x4, Type: FloatProperty)
    float TrackDecisionWeightMaxDistanceFromBot; // 0x158 (Size: 0x4, Type: FloatProperty)
    float TrackDecisionWeightMaxHeightFromBot; // 0x15c (Size: 0x4, Type: FloatProperty)
    float TrackDecisionWeightDesirableHeightFromBot; // 0x160 (Size: 0x4, Type: FloatProperty)
    float MinDecisionDelaySecondsAfterChangingTracks; // 0x164 (Size: 0x4, Type: FloatProperty)
    float MaxDecisionDelaySecondsAfterChangingTracks; // 0x168 (Size: 0x4, Type: FloatProperty)
    float ShortcutWeightLookAheadTrackDistance; // 0x16c (Size: 0x4, Type: FloatProperty)
    float PrimaryTrackGapMinDistanceThreshold; // 0x170 (Size: 0x4, Type: FloatProperty)
    float ForceNewTrackDecisionAfterSecondsIfFullyBlocked; // 0x174 (Size: 0x4, Type: FloatProperty)
    float SwitchTrackMaxDistanceThreshold; // 0x178 (Size: 0x4, Type: FloatProperty)
    float SwitchTrackMinDistanceThreshold; // 0x17c (Size: 0x4, Type: FloatProperty)
    float TrackLengthRemainingPartitionAmount; // 0x180 (Size: 0x4, Type: FloatProperty)
    float TrackLengthRemainingCap; // 0x184 (Size: 0x4, Type: FloatProperty)
    float ValidRaycastDistanceThreshold; // 0x188 (Size: 0x4, Type: FloatProperty)
    float OffRoadSurfaceMaxNormalToTrackAngleThreshold; // 0x18c (Size: 0x4, Type: FloatProperty)
    float RaycastVehicleForwardOffset; // 0x190 (Size: 0x4, Type: FloatProperty)
    float RaycastEndTrackForwardOffset; // 0x194 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> RaycastCollisionChannel; // 0x198 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_199[0x3]; // 0x199 (Size: 0x3, Type: PaddingProperty)
    float TrackLengthWeightPercentage; // 0x19c (Size: 0x4, Type: FloatProperty)
    float DistanceFromBotWeightPercentage; // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float HeightFromBotWeightPercentage; // 0x1a4 (Size: 0x4, Type: FloatProperty)
    float TrackOrientationWeightPercentage; // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float ShortcutWeightMultiplier; // 0x1ac (Size: 0x4, Type: FloatProperty)
    float AdditionalIndependentWeight; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float MaxRandomWeight; // 0x1b4 (Size: 0x4, Type: FloatProperty)
    float PrimaryTrackGapStaticWeightDeduction; // 0x1b8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBlackboardComponent*> BlackboardComponent; // 0x1bc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> TargetTrackDecision; // 0x1c4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> NextTrackDecision; // 0x1cc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_1d4[0x4]; // 0x1d4 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarAITrackDecision> AvailableTrackDecisions; // 0x1d8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UDelMarAIService*> AIService; // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent; // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_1f8[0x48]; // 0x1f8 (Size: 0x48, Type: PaddingProperty)

protected:
    void HandleVehicleAnyWheelsOnGroundStateChanged(const TScriptInterface<Class> VehicleRef, bool& bAnyWheelsOnGround); // 0x11b12fa0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UDelMarBTService_ChooseNextTrack) == 0x240, "Size mismatch for UDelMarBTService_ChooseNextTrack");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TargetTrackDecisionKey) == 0xa0, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TargetTrackDecisionKey");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, IsOffRoadDriveGoalKey) == 0xc8, "Offset mismatch for UDelMarBTService_ChooseNextTrack::IsOffRoadDriveGoalKey");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, IsJumpDriveGoalKey) == 0xf0, "Offset mismatch for UDelMarBTService_ChooseNextTrack::IsJumpDriveGoalKey");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, IsFullyBlockedCollisionKey) == 0x118, "Offset mismatch for UDelMarBTService_ChooseNextTrack::IsFullyBlockedCollisionKey");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackDecisionMaxTrackDistanceOffset) == 0x140, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackDecisionMaxTrackDistanceOffset");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackDecisionMinTrackDistanceOffset) == 0x144, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackDecisionMinTrackDistanceOffset");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackEndCheckTrackDistanceOffset) == 0x148, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackEndCheckTrackDistanceOffset");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, BotReachedNewTrackDistanceOffset) == 0x14c, "Offset mismatch for UDelMarBTService_ChooseNextTrack::BotReachedNewTrackDistanceOffset");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, SplineResetAvailableTrackIndexThreshold) == 0x150, "Offset mismatch for UDelMarBTService_ChooseNextTrack::SplineResetAvailableTrackIndexThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, AddKickflipWeightDegreeThreshold) == 0x154, "Offset mismatch for UDelMarBTService_ChooseNextTrack::AddKickflipWeightDegreeThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackDecisionWeightMaxDistanceFromBot) == 0x158, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackDecisionWeightMaxDistanceFromBot");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackDecisionWeightMaxHeightFromBot) == 0x15c, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackDecisionWeightMaxHeightFromBot");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackDecisionWeightDesirableHeightFromBot) == 0x160, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackDecisionWeightDesirableHeightFromBot");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, MinDecisionDelaySecondsAfterChangingTracks) == 0x164, "Offset mismatch for UDelMarBTService_ChooseNextTrack::MinDecisionDelaySecondsAfterChangingTracks");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, MaxDecisionDelaySecondsAfterChangingTracks) == 0x168, "Offset mismatch for UDelMarBTService_ChooseNextTrack::MaxDecisionDelaySecondsAfterChangingTracks");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, ShortcutWeightLookAheadTrackDistance) == 0x16c, "Offset mismatch for UDelMarBTService_ChooseNextTrack::ShortcutWeightLookAheadTrackDistance");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, PrimaryTrackGapMinDistanceThreshold) == 0x170, "Offset mismatch for UDelMarBTService_ChooseNextTrack::PrimaryTrackGapMinDistanceThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, ForceNewTrackDecisionAfterSecondsIfFullyBlocked) == 0x174, "Offset mismatch for UDelMarBTService_ChooseNextTrack::ForceNewTrackDecisionAfterSecondsIfFullyBlocked");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, SwitchTrackMaxDistanceThreshold) == 0x178, "Offset mismatch for UDelMarBTService_ChooseNextTrack::SwitchTrackMaxDistanceThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, SwitchTrackMinDistanceThreshold) == 0x17c, "Offset mismatch for UDelMarBTService_ChooseNextTrack::SwitchTrackMinDistanceThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackLengthRemainingPartitionAmount) == 0x180, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackLengthRemainingPartitionAmount");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackLengthRemainingCap) == 0x184, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackLengthRemainingCap");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, ValidRaycastDistanceThreshold) == 0x188, "Offset mismatch for UDelMarBTService_ChooseNextTrack::ValidRaycastDistanceThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, OffRoadSurfaceMaxNormalToTrackAngleThreshold) == 0x18c, "Offset mismatch for UDelMarBTService_ChooseNextTrack::OffRoadSurfaceMaxNormalToTrackAngleThreshold");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, RaycastVehicleForwardOffset) == 0x190, "Offset mismatch for UDelMarBTService_ChooseNextTrack::RaycastVehicleForwardOffset");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, RaycastEndTrackForwardOffset) == 0x194, "Offset mismatch for UDelMarBTService_ChooseNextTrack::RaycastEndTrackForwardOffset");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, RaycastCollisionChannel) == 0x198, "Offset mismatch for UDelMarBTService_ChooseNextTrack::RaycastCollisionChannel");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackLengthWeightPercentage) == 0x19c, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackLengthWeightPercentage");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, DistanceFromBotWeightPercentage) == 0x1a0, "Offset mismatch for UDelMarBTService_ChooseNextTrack::DistanceFromBotWeightPercentage");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, HeightFromBotWeightPercentage) == 0x1a4, "Offset mismatch for UDelMarBTService_ChooseNextTrack::HeightFromBotWeightPercentage");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackOrientationWeightPercentage) == 0x1a8, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackOrientationWeightPercentage");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, ShortcutWeightMultiplier) == 0x1ac, "Offset mismatch for UDelMarBTService_ChooseNextTrack::ShortcutWeightMultiplier");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, AdditionalIndependentWeight) == 0x1b0, "Offset mismatch for UDelMarBTService_ChooseNextTrack::AdditionalIndependentWeight");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, MaxRandomWeight) == 0x1b4, "Offset mismatch for UDelMarBTService_ChooseNextTrack::MaxRandomWeight");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, PrimaryTrackGapStaticWeightDeduction) == 0x1b8, "Offset mismatch for UDelMarBTService_ChooseNextTrack::PrimaryTrackGapStaticWeightDeduction");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, BlackboardComponent) == 0x1bc, "Offset mismatch for UDelMarBTService_ChooseNextTrack::BlackboardComponent");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TargetTrackDecision) == 0x1c4, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TargetTrackDecision");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, NextTrackDecision) == 0x1cc, "Offset mismatch for UDelMarBTService_ChooseNextTrack::NextTrackDecision");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, AvailableTrackDecisions) == 0x1d8, "Offset mismatch for UDelMarBTService_ChooseNextTrack::AvailableTrackDecisions");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, AIService) == 0x1e8, "Offset mismatch for UDelMarBTService_ChooseNextTrack::AIService");
static_assert(offsetof(UDelMarBTService_ChooseNextTrack, TrackPositionComponent) == 0x1f0, "Offset mismatch for UDelMarBTService_ChooseNextTrack::TrackPositionComponent");

// Size: 0xa0 (Inherited: 0x150, Single: 0xffffff50)
class UDelMarBTService_VehicleBase : public UBTService
{
public:
    FBlackboardKeySelector VehicleKey; // 0x70 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle; // 0x98 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarBTService_VehicleBase) == 0xa0, "Size mismatch for UDelMarBTService_VehicleBase");
static_assert(offsetof(UDelMarBTService_VehicleBase, VehicleKey) == 0x70, "Offset mismatch for UDelMarBTService_VehicleBase::VehicleKey");
static_assert(offsetof(UDelMarBTService_VehicleBase, DelMarVehicle) == 0x98, "Offset mismatch for UDelMarBTService_VehicleBase::DelMarVehicle");

// Size: 0x6c0 (Inherited: 0x1f0, Single: 0x4d0)
class UDelMarBTService_FindDriveGoal : public UDelMarBTService_VehicleBase
{
public:
    FBlackboardKeySelector TargetTrackDecisionKey; // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalLocationKey; // 0xc8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalRotationKey; // 0xf0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsJumpDriveGoalKey; // 0x118 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsOffRoadDriveGoalKey; // 0x140 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsKickflipDriveGoalKey; // 0x168 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector KickflipDirectionKey; // 0x190 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector HasUpcomingCollisionKey; // 0x1b8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsFullyBlockedCollisionKey; // 0x1e0 (Size: 0x28, Type: StructProperty)
    float GroundedDriveGoalVehicleForwardOffset; // 0x208 (Size: 0x4, Type: FloatProperty)
    float TrackGapDriveGoalVehicleForwardOffset; // 0x20c (Size: 0x4, Type: FloatProperty)
    float AirDriveGoalVehicleForwardOffset; // 0x210 (Size: 0x4, Type: FloatProperty)
    float PathNoiseAmplitude; // 0x214 (Size: 0x4, Type: FloatProperty)
    float PathNoiseFrequency; // 0x218 (Size: 0x4, Type: FloatProperty)
    int32_t MaxNumberOfCheckedTrackSegments; // 0x21c (Size: 0x4, Type: IntProperty)
    float GroundedOffroadRaycastDistance; // 0x220 (Size: 0x4, Type: FloatProperty)
    float GroundedOffRoadRaycastTrackForwardOffset; // 0x224 (Size: 0x4, Type: FloatProperty)
    float TrackGapCheckForwardOffset; // 0x228 (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackRaycastForwardOffset; // 0x22c (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackRaycastDepthPadding; // 0x230 (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackMaintainVehicleOffsetDegreeThreshold; // 0x234 (Size: 0x4, Type: FloatProperty)
    float ReturnToTrackRaycastMinAngleDifference; // 0x238 (Size: 0x4, Type: FloatProperty)
    float UnsafeLandingDesiredUnderthrustHeightFactor; // 0x23c (Size: 0x4, Type: FloatProperty)
    float UnsafeLandingJumpGoalTrackOffsetReductionFactor; // 0x240 (Size: 0x4, Type: FloatProperty)
    float OffRoadSurfaceMaxNormalToTrackAngleThreshold; // 0x244 (Size: 0x4, Type: FloatProperty)
    float MaxVehicleAirRollAngleToReturnToTrackFromBelow; // 0x248 (Size: 0x4, Type: FloatProperty)
    int32_t NumberOfSideAvoidanceRaycasts; // 0x24c (Size: 0x4, Type: IntProperty)
    float DegreesBetweenRaycasts; // 0x250 (Size: 0x4, Type: FloatProperty)
    float TrackInclineMaxRaycastDirectionRotationDegrees; // 0x254 (Size: 0x4, Type: FloatProperty)
    float DriftPrimaryTraceRotationFactor; // 0x258 (Size: 0x4, Type: FloatProperty)
    float NonJumpableHazardMinHitNormalDegrees; // 0x25c (Size: 0x4, Type: FloatProperty)
    float AvoidanceTraceVerticalSpread; // 0x260 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> RaycastCollisionChannel; // 0x264 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_265[0x3]; // 0x265 (Size: 0x3, Type: PaddingProperty)
    TArray<UClass*> IgnoredActorClasses; // 0x268 (Size: 0x10, Type: ArrayProperty)
    FDelMarScaledCurve RaycastDistanceCurve; // 0x278 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve RayCastDistanceContributionCurve; // 0x308 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VehicleDistanceAvoidanceCurve; // 0x398 (Size: 0x90, Type: StructProperty)
    float DriveGoalOffsetCancelPadding; // 0x428 (Size: 0x4, Type: FloatProperty)
    float DriveHazardOffsetCancelPadding; // 0x42c (Size: 0x4, Type: FloatProperty)
    float VehicleTrackOffsetCancelPadding; // 0x430 (Size: 0x4, Type: FloatProperty)
    float DriveGoalOffsetMinTrackDepth; // 0x434 (Size: 0x4, Type: FloatProperty)
    float DriveHazardMaxJumpDistanceFactor; // 0x438 (Size: 0x4, Type: FloatProperty)
    float DriveHazardMinJumpDistanceFactor; // 0x43c (Size: 0x4, Type: FloatProperty)
    float HazardJumpGoalMaxHeightOffset; // 0x440 (Size: 0x4, Type: FloatProperty)
    float HazardJumpGoalMinHeightOffset; // 0x444 (Size: 0x4, Type: FloatProperty)
    float BlockedJumpTracePadding; // 0x448 (Size: 0x4, Type: FloatProperty)
    float TrackGapJumpHeightThreshold; // 0x44c (Size: 0x4, Type: FloatProperty)
    float TrackGapDriveGoalHeightOffset; // 0x450 (Size: 0x4, Type: FloatProperty)
    float VerticalTrackTransitionVehicleExtentMultiplier; // 0x454 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> JumpableActorClasses; // 0x458 (Size: 0x10, Type: ArrayProperty)
    float SideKickflipSurfaceNormalDegreeThreshold; // 0x468 (Size: 0x4, Type: FloatProperty)
    float UpwardKickflipMinNormalDegreesToWorldUp; // 0x46c (Size: 0x4, Type: FloatProperty)
    float KickflipDriveGoalTrackHeightOffset; // 0x470 (Size: 0x4, Type: FloatProperty)
    float KickflipDriveGoalForwardDistanceThreshold; // 0x474 (Size: 0x4, Type: FloatProperty)
    float UnderKickflipSurfaceForwardDistanceThreshold; // 0x478 (Size: 0x4, Type: FloatProperty)
    float KickflipTraceHeightOffset; // 0x47c (Size: 0x4, Type: FloatProperty)
    float KickflipTraceMaximumHeightFromTrack; // 0x480 (Size: 0x4, Type: FloatProperty)
    float KickflipMinimumDownwardDistanceFromTrack; // 0x484 (Size: 0x4, Type: FloatProperty)
    float PercentChanceToAllowDownKickflip; // 0x488 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_48c[0x4]; // 0x48c (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve PercentChanceToExecuteDownKickflipCurve; // 0x490 (Size: 0x90, Type: StructProperty)
    float SwitchTrackJumpHeightThreshold; // 0x520 (Size: 0x4, Type: FloatProperty)
    float SwitchTrackToPipeHeightOffsetFactor; // 0x524 (Size: 0x4, Type: FloatProperty)
    float PercentChanceToIgnoreDriveHazard; // 0x528 (Size: 0x4, Type: FloatProperty)
    float PercentChanceToNotCheckForSafeLanding; // 0x52c (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBlackboardComponent*> BlackboardComponent; // 0x530 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent; // 0x538 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> TargetTrack; // 0x540 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> TargetTrackSplineComponent; // 0x548 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> ActiveTrack; // 0x550 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> ActiveTrackSplineComponent; // 0x558 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackOobTubePositionalRenderingComponent*> OobTubePositionalRenderingComponent; // 0x560 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_568[0x50]; // 0x568 (Size: 0x50, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> OffRoadDriveActor; // 0x5b8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_5c0[0x10]; // 0x5c0 (Size: 0x10, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarTrack*> KickflipTrack; // 0x5d0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_5d8[0xe8]; // 0x5d8 (Size: 0xe8, Type: PaddingProperty)

protected:
    void HandleKickflipActivated(bool& bLeft); // 0x11b12704 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleVehicleAnyWheelsOnGroundStateChanged(const TScriptInterface<Class> VehicleRef, bool& bAnyWheelsOnGround); // 0x11b130f8 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UDelMarBTService_FindDriveGoal) == 0x6c0, "Size mismatch for UDelMarBTService_FindDriveGoal");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TargetTrackDecisionKey) == 0xa0, "Offset mismatch for UDelMarBTService_FindDriveGoal::TargetTrackDecisionKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveGoalLocationKey) == 0xc8, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveGoalLocationKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveGoalRotationKey) == 0xf0, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveGoalRotationKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, IsJumpDriveGoalKey) == 0x118, "Offset mismatch for UDelMarBTService_FindDriveGoal::IsJumpDriveGoalKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, IsOffRoadDriveGoalKey) == 0x140, "Offset mismatch for UDelMarBTService_FindDriveGoal::IsOffRoadDriveGoalKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, IsKickflipDriveGoalKey) == 0x168, "Offset mismatch for UDelMarBTService_FindDriveGoal::IsKickflipDriveGoalKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipDirectionKey) == 0x190, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipDirectionKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, HasUpcomingCollisionKey) == 0x1b8, "Offset mismatch for UDelMarBTService_FindDriveGoal::HasUpcomingCollisionKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, IsFullyBlockedCollisionKey) == 0x1e0, "Offset mismatch for UDelMarBTService_FindDriveGoal::IsFullyBlockedCollisionKey");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, GroundedDriveGoalVehicleForwardOffset) == 0x208, "Offset mismatch for UDelMarBTService_FindDriveGoal::GroundedDriveGoalVehicleForwardOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TrackGapDriveGoalVehicleForwardOffset) == 0x20c, "Offset mismatch for UDelMarBTService_FindDriveGoal::TrackGapDriveGoalVehicleForwardOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, AirDriveGoalVehicleForwardOffset) == 0x210, "Offset mismatch for UDelMarBTService_FindDriveGoal::AirDriveGoalVehicleForwardOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, PathNoiseAmplitude) == 0x214, "Offset mismatch for UDelMarBTService_FindDriveGoal::PathNoiseAmplitude");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, PathNoiseFrequency) == 0x218, "Offset mismatch for UDelMarBTService_FindDriveGoal::PathNoiseFrequency");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, MaxNumberOfCheckedTrackSegments) == 0x21c, "Offset mismatch for UDelMarBTService_FindDriveGoal::MaxNumberOfCheckedTrackSegments");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, GroundedOffroadRaycastDistance) == 0x220, "Offset mismatch for UDelMarBTService_FindDriveGoal::GroundedOffroadRaycastDistance");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, GroundedOffRoadRaycastTrackForwardOffset) == 0x224, "Offset mismatch for UDelMarBTService_FindDriveGoal::GroundedOffRoadRaycastTrackForwardOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TrackGapCheckForwardOffset) == 0x228, "Offset mismatch for UDelMarBTService_FindDriveGoal::TrackGapCheckForwardOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, ReturnToTrackRaycastForwardOffset) == 0x22c, "Offset mismatch for UDelMarBTService_FindDriveGoal::ReturnToTrackRaycastForwardOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, ReturnToTrackRaycastDepthPadding) == 0x230, "Offset mismatch for UDelMarBTService_FindDriveGoal::ReturnToTrackRaycastDepthPadding");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, ReturnToTrackMaintainVehicleOffsetDegreeThreshold) == 0x234, "Offset mismatch for UDelMarBTService_FindDriveGoal::ReturnToTrackMaintainVehicleOffsetDegreeThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, ReturnToTrackRaycastMinAngleDifference) == 0x238, "Offset mismatch for UDelMarBTService_FindDriveGoal::ReturnToTrackRaycastMinAngleDifference");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, UnsafeLandingDesiredUnderthrustHeightFactor) == 0x23c, "Offset mismatch for UDelMarBTService_FindDriveGoal::UnsafeLandingDesiredUnderthrustHeightFactor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, UnsafeLandingJumpGoalTrackOffsetReductionFactor) == 0x240, "Offset mismatch for UDelMarBTService_FindDriveGoal::UnsafeLandingJumpGoalTrackOffsetReductionFactor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, OffRoadSurfaceMaxNormalToTrackAngleThreshold) == 0x244, "Offset mismatch for UDelMarBTService_FindDriveGoal::OffRoadSurfaceMaxNormalToTrackAngleThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, MaxVehicleAirRollAngleToReturnToTrackFromBelow) == 0x248, "Offset mismatch for UDelMarBTService_FindDriveGoal::MaxVehicleAirRollAngleToReturnToTrackFromBelow");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, NumberOfSideAvoidanceRaycasts) == 0x24c, "Offset mismatch for UDelMarBTService_FindDriveGoal::NumberOfSideAvoidanceRaycasts");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DegreesBetweenRaycasts) == 0x250, "Offset mismatch for UDelMarBTService_FindDriveGoal::DegreesBetweenRaycasts");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TrackInclineMaxRaycastDirectionRotationDegrees) == 0x254, "Offset mismatch for UDelMarBTService_FindDriveGoal::TrackInclineMaxRaycastDirectionRotationDegrees");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriftPrimaryTraceRotationFactor) == 0x258, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriftPrimaryTraceRotationFactor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, NonJumpableHazardMinHitNormalDegrees) == 0x25c, "Offset mismatch for UDelMarBTService_FindDriveGoal::NonJumpableHazardMinHitNormalDegrees");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, AvoidanceTraceVerticalSpread) == 0x260, "Offset mismatch for UDelMarBTService_FindDriveGoal::AvoidanceTraceVerticalSpread");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, RaycastCollisionChannel) == 0x264, "Offset mismatch for UDelMarBTService_FindDriveGoal::RaycastCollisionChannel");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, IgnoredActorClasses) == 0x268, "Offset mismatch for UDelMarBTService_FindDriveGoal::IgnoredActorClasses");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, RaycastDistanceCurve) == 0x278, "Offset mismatch for UDelMarBTService_FindDriveGoal::RaycastDistanceCurve");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, RayCastDistanceContributionCurve) == 0x308, "Offset mismatch for UDelMarBTService_FindDriveGoal::RayCastDistanceContributionCurve");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, VehicleDistanceAvoidanceCurve) == 0x398, "Offset mismatch for UDelMarBTService_FindDriveGoal::VehicleDistanceAvoidanceCurve");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveGoalOffsetCancelPadding) == 0x428, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveGoalOffsetCancelPadding");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveHazardOffsetCancelPadding) == 0x42c, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveHazardOffsetCancelPadding");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, VehicleTrackOffsetCancelPadding) == 0x430, "Offset mismatch for UDelMarBTService_FindDriveGoal::VehicleTrackOffsetCancelPadding");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveGoalOffsetMinTrackDepth) == 0x434, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveGoalOffsetMinTrackDepth");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveHazardMaxJumpDistanceFactor) == 0x438, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveHazardMaxJumpDistanceFactor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, DriveHazardMinJumpDistanceFactor) == 0x43c, "Offset mismatch for UDelMarBTService_FindDriveGoal::DriveHazardMinJumpDistanceFactor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, HazardJumpGoalMaxHeightOffset) == 0x440, "Offset mismatch for UDelMarBTService_FindDriveGoal::HazardJumpGoalMaxHeightOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, HazardJumpGoalMinHeightOffset) == 0x444, "Offset mismatch for UDelMarBTService_FindDriveGoal::HazardJumpGoalMinHeightOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, BlockedJumpTracePadding) == 0x448, "Offset mismatch for UDelMarBTService_FindDriveGoal::BlockedJumpTracePadding");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TrackGapJumpHeightThreshold) == 0x44c, "Offset mismatch for UDelMarBTService_FindDriveGoal::TrackGapJumpHeightThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TrackGapDriveGoalHeightOffset) == 0x450, "Offset mismatch for UDelMarBTService_FindDriveGoal::TrackGapDriveGoalHeightOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, VerticalTrackTransitionVehicleExtentMultiplier) == 0x454, "Offset mismatch for UDelMarBTService_FindDriveGoal::VerticalTrackTransitionVehicleExtentMultiplier");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, JumpableActorClasses) == 0x458, "Offset mismatch for UDelMarBTService_FindDriveGoal::JumpableActorClasses");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, SideKickflipSurfaceNormalDegreeThreshold) == 0x468, "Offset mismatch for UDelMarBTService_FindDriveGoal::SideKickflipSurfaceNormalDegreeThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, UpwardKickflipMinNormalDegreesToWorldUp) == 0x46c, "Offset mismatch for UDelMarBTService_FindDriveGoal::UpwardKickflipMinNormalDegreesToWorldUp");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipDriveGoalTrackHeightOffset) == 0x470, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipDriveGoalTrackHeightOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipDriveGoalForwardDistanceThreshold) == 0x474, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipDriveGoalForwardDistanceThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, UnderKickflipSurfaceForwardDistanceThreshold) == 0x478, "Offset mismatch for UDelMarBTService_FindDriveGoal::UnderKickflipSurfaceForwardDistanceThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipTraceHeightOffset) == 0x47c, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipTraceHeightOffset");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipTraceMaximumHeightFromTrack) == 0x480, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipTraceMaximumHeightFromTrack");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipMinimumDownwardDistanceFromTrack) == 0x484, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipMinimumDownwardDistanceFromTrack");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, PercentChanceToAllowDownKickflip) == 0x488, "Offset mismatch for UDelMarBTService_FindDriveGoal::PercentChanceToAllowDownKickflip");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, PercentChanceToExecuteDownKickflipCurve) == 0x490, "Offset mismatch for UDelMarBTService_FindDriveGoal::PercentChanceToExecuteDownKickflipCurve");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, SwitchTrackJumpHeightThreshold) == 0x520, "Offset mismatch for UDelMarBTService_FindDriveGoal::SwitchTrackJumpHeightThreshold");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, SwitchTrackToPipeHeightOffsetFactor) == 0x524, "Offset mismatch for UDelMarBTService_FindDriveGoal::SwitchTrackToPipeHeightOffsetFactor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, PercentChanceToIgnoreDriveHazard) == 0x528, "Offset mismatch for UDelMarBTService_FindDriveGoal::PercentChanceToIgnoreDriveHazard");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, PercentChanceToNotCheckForSafeLanding) == 0x52c, "Offset mismatch for UDelMarBTService_FindDriveGoal::PercentChanceToNotCheckForSafeLanding");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, BlackboardComponent) == 0x530, "Offset mismatch for UDelMarBTService_FindDriveGoal::BlackboardComponent");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TrackPositionComponent) == 0x538, "Offset mismatch for UDelMarBTService_FindDriveGoal::TrackPositionComponent");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TargetTrack) == 0x540, "Offset mismatch for UDelMarBTService_FindDriveGoal::TargetTrack");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, TargetTrackSplineComponent) == 0x548, "Offset mismatch for UDelMarBTService_FindDriveGoal::TargetTrackSplineComponent");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, ActiveTrack) == 0x550, "Offset mismatch for UDelMarBTService_FindDriveGoal::ActiveTrack");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, ActiveTrackSplineComponent) == 0x558, "Offset mismatch for UDelMarBTService_FindDriveGoal::ActiveTrackSplineComponent");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, OobTubePositionalRenderingComponent) == 0x560, "Offset mismatch for UDelMarBTService_FindDriveGoal::OobTubePositionalRenderingComponent");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, OffRoadDriveActor) == 0x5b8, "Offset mismatch for UDelMarBTService_FindDriveGoal::OffRoadDriveActor");
static_assert(offsetof(UDelMarBTService_FindDriveGoal, KickflipTrack) == 0x5d0, "Offset mismatch for UDelMarBTService_FindDriveGoal::KickflipTrack");

// Size: 0xd0 (Inherited: 0x1f0, Single: 0xfffffee0)
class UDelMarBTService_ResetVehicle : public UDelMarBTService_VehicleBase
{
public:
    float CancelResetMinRequiredDistance; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float CancelResetMaxRequiredDistance; // 0xa4 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> PlayerRaceDataComponent; // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent; // 0xb0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarBTService_ResetVehicle) == 0xd0, "Size mismatch for UDelMarBTService_ResetVehicle");
static_assert(offsetof(UDelMarBTService_ResetVehicle, CancelResetMinRequiredDistance) == 0xa0, "Offset mismatch for UDelMarBTService_ResetVehicle::CancelResetMinRequiredDistance");
static_assert(offsetof(UDelMarBTService_ResetVehicle, CancelResetMaxRequiredDistance) == 0xa4, "Offset mismatch for UDelMarBTService_ResetVehicle::CancelResetMaxRequiredDistance");
static_assert(offsetof(UDelMarBTService_ResetVehicle, PlayerRaceDataComponent) == 0xa8, "Offset mismatch for UDelMarBTService_ResetVehicle::PlayerRaceDataComponent");
static_assert(offsetof(UDelMarBTService_ResetVehicle, TrackPositionComponent) == 0xb0, "Offset mismatch for UDelMarBTService_ResetVehicle::TrackPositionComponent");

// Size: 0xa70 (Inherited: 0x190, Single: 0x8e0)
class UDelMarBTTask_DriveTrack : public UDelMarBTTask_VehicleBase
{
public:
    FBlackboardKeySelector TargetTrackDecisionKey; // 0xa0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalLocationKey; // 0xc8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DriveGoalRotationKey; // 0xf0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsJumpDriveGoalKey; // 0x118 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsOffRoadDriveGoalKey; // 0x140 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector IsKickflipDriveGoalKey; // 0x168 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector KickflipDirectionKey; // 0x190 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector HasUpcomingCollisionKey; // 0x1b8 (Size: 0x28, Type: StructProperty)
    FDelMarScaledCurve GroundedTrackHorizontalOffsetSteerCurve; // 0x1e0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AirTrackHorizontalOffsetSteerCurve; // 0x270 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve CollisionAvoidanceHorizontalOffsetSteerCurve; // 0x300 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AirCollisionAvoidanceHorizontalSteerDecisionCurve; // 0x390 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve GroundedTurnDegreesSteerDecisionCurve; // 0x420 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AirTurnDegreesSteerDecisionCurve; // 0x4b0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve CollisionTurnDegreesSteerDecisionCurve; // 0x540 (Size: 0x90, Type: StructProperty)
    float DriveThrottle; // 0x5d0 (Size: 0x4, Type: FloatProperty)
    bool bCanKickDrift; // 0x5d4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5d5[0x3]; // 0x5d5 (Size: 0x3, Type: PaddingProperty)
    int32_t NumberOfDriftCheckSamples; // 0x5d8 (Size: 0x4, Type: IntProperty)
    float MinDriftSampleDistanceScaleFactor; // 0x5dc (Size: 0x4, Type: FloatProperty)
    float MaxDriftSampleDistanceScaleFactor; // 0x5e0 (Size: 0x4, Type: FloatProperty)
    float MinExitDriftSampleDistanceFromVehicle; // 0x5e4 (Size: 0x4, Type: FloatProperty)
    float MaxExitDriftSampleDistanceFromVehicle; // 0x5e8 (Size: 0x4, Type: FloatProperty)
    float MinRequiredDriftDegrees; // 0x5ec (Size: 0x4, Type: FloatProperty)
    float MaxRequiredDriftDegrees; // 0x5f0 (Size: 0x4, Type: FloatProperty)
    float MinRequiredKickDriftDegrees; // 0x5f4 (Size: 0x4, Type: FloatProperty)
    float MaxRequiredKickDriftDegrees; // 0x5f8 (Size: 0x4, Type: FloatProperty)
    float MinSecondsToUpdateRandomDriftConfigValues; // 0x5fc (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve PercentChanceToKickDriftCurve; // 0x600 (Size: 0x90, Type: StructProperty)
    float MinDriftSlipRatioForExitKickDrift; // 0x690 (Size: 0x4, Type: FloatProperty)
    float MinDriftSpeed; // 0x694 (Size: 0x4, Type: FloatProperty)
    float DriftKickUnderSteerDegreesThreshold; // 0x698 (Size: 0x4, Type: FloatProperty)
    float DriftKickOverSteerDegreesThreshold; // 0x69c (Size: 0x4, Type: FloatProperty)
    float DriftTapUnderSteerDegreesThreshold; // 0x6a0 (Size: 0x4, Type: FloatProperty)
    float DriftTapOverSteerDegreesThreshold; // 0x6a4 (Size: 0x4, Type: FloatProperty)
    float DriftCounterSteerDegreesThreshold; // 0x6a8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6ac[0x4]; // 0x6ac (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve MinDriftSlipRatioCurve; // 0x6b0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DistanceBetweenDriftSamplesCurve; // 0x740 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DriftSampleDistanceFromVehicleCurve; // 0x7d0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DriveGoalJumpHeightThresholdCurve; // 0x860 (Size: 0x90, Type: StructProperty)
    float JumpGoalTrackAngleDistanceOffset; // 0x8f0 (Size: 0x4, Type: FloatProperty)
    float JumpMinSpeed; // 0x8f4 (Size: 0x4, Type: FloatProperty)
    float MinimumUnderthrustPitch; // 0x8f8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8fc[0x4]; // 0x8fc (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve AirPitchAdjustmentCurve; // 0x900 (Size: 0x90, Type: StructProperty)
    float AirPitchAdjustmentMaxVerticalDegrees; // 0x990 (Size: 0x4, Type: FloatProperty)
    float MinNumTurboChargesNeededToTurbo; // 0x994 (Size: 0x4, Type: FloatProperty)
    float MaxTurboTrackCutoffAngleInDegrees; // 0x998 (Size: 0x4, Type: FloatProperty)
    float TurboActivationBaseChance; // 0x99c (Size: 0x4, Type: FloatProperty)
    float SecondaryTurboBoostChance; // 0x9a0 (Size: 0x4, Type: FloatProperty)
    float MinTimeBetweenTurboCheck; // 0x9a4 (Size: 0x4, Type: FloatProperty)
    float MaxTimeBetweenTurboCheck; // 0x9a8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPositionComponent; // 0x9ac (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> TargetTrack; // 0x9b4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> TargetTrackSplineComponent; // 0x9bc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UBlackboardComponent*> BlackboardComponent; // 0x9c4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_9cc[0xa4]; // 0x9cc (Size: 0xa4, Type: PaddingProperty)

protected:
    void HandleTurboActivated(); // 0x11b12f8c (Index: 0x0, Flags: Final|Native|Protected)
    void HandleVehicleAnyWheelsOnGroundStateChanged(const TScriptInterface<Class> VehicleRef, bool& bAnyWheelsOnGround); // 0x11b13250 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void TurboBonusZoneStateChanged(EDelMarTurboZoneState& NewState); // 0x11b133d4 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarBTTask_DriveTrack) == 0xa70, "Size mismatch for UDelMarBTTask_DriveTrack");
static_assert(offsetof(UDelMarBTTask_DriveTrack, TargetTrackDecisionKey) == 0xa0, "Offset mismatch for UDelMarBTTask_DriveTrack::TargetTrackDecisionKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriveGoalLocationKey) == 0xc8, "Offset mismatch for UDelMarBTTask_DriveTrack::DriveGoalLocationKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriveGoalRotationKey) == 0xf0, "Offset mismatch for UDelMarBTTask_DriveTrack::DriveGoalRotationKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, IsJumpDriveGoalKey) == 0x118, "Offset mismatch for UDelMarBTTask_DriveTrack::IsJumpDriveGoalKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, IsOffRoadDriveGoalKey) == 0x140, "Offset mismatch for UDelMarBTTask_DriveTrack::IsOffRoadDriveGoalKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, IsKickflipDriveGoalKey) == 0x168, "Offset mismatch for UDelMarBTTask_DriveTrack::IsKickflipDriveGoalKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, KickflipDirectionKey) == 0x190, "Offset mismatch for UDelMarBTTask_DriveTrack::KickflipDirectionKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, HasUpcomingCollisionKey) == 0x1b8, "Offset mismatch for UDelMarBTTask_DriveTrack::HasUpcomingCollisionKey");
static_assert(offsetof(UDelMarBTTask_DriveTrack, GroundedTrackHorizontalOffsetSteerCurve) == 0x1e0, "Offset mismatch for UDelMarBTTask_DriveTrack::GroundedTrackHorizontalOffsetSteerCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, AirTrackHorizontalOffsetSteerCurve) == 0x270, "Offset mismatch for UDelMarBTTask_DriveTrack::AirTrackHorizontalOffsetSteerCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, CollisionAvoidanceHorizontalOffsetSteerCurve) == 0x300, "Offset mismatch for UDelMarBTTask_DriveTrack::CollisionAvoidanceHorizontalOffsetSteerCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, AirCollisionAvoidanceHorizontalSteerDecisionCurve) == 0x390, "Offset mismatch for UDelMarBTTask_DriveTrack::AirCollisionAvoidanceHorizontalSteerDecisionCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, GroundedTurnDegreesSteerDecisionCurve) == 0x420, "Offset mismatch for UDelMarBTTask_DriveTrack::GroundedTurnDegreesSteerDecisionCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, AirTurnDegreesSteerDecisionCurve) == 0x4b0, "Offset mismatch for UDelMarBTTask_DriveTrack::AirTurnDegreesSteerDecisionCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, CollisionTurnDegreesSteerDecisionCurve) == 0x540, "Offset mismatch for UDelMarBTTask_DriveTrack::CollisionTurnDegreesSteerDecisionCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriveThrottle) == 0x5d0, "Offset mismatch for UDelMarBTTask_DriveTrack::DriveThrottle");
static_assert(offsetof(UDelMarBTTask_DriveTrack, bCanKickDrift) == 0x5d4, "Offset mismatch for UDelMarBTTask_DriveTrack::bCanKickDrift");
static_assert(offsetof(UDelMarBTTask_DriveTrack, NumberOfDriftCheckSamples) == 0x5d8, "Offset mismatch for UDelMarBTTask_DriveTrack::NumberOfDriftCheckSamples");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinDriftSampleDistanceScaleFactor) == 0x5dc, "Offset mismatch for UDelMarBTTask_DriveTrack::MinDriftSampleDistanceScaleFactor");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MaxDriftSampleDistanceScaleFactor) == 0x5e0, "Offset mismatch for UDelMarBTTask_DriveTrack::MaxDriftSampleDistanceScaleFactor");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinExitDriftSampleDistanceFromVehicle) == 0x5e4, "Offset mismatch for UDelMarBTTask_DriveTrack::MinExitDriftSampleDistanceFromVehicle");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MaxExitDriftSampleDistanceFromVehicle) == 0x5e8, "Offset mismatch for UDelMarBTTask_DriveTrack::MaxExitDriftSampleDistanceFromVehicle");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinRequiredDriftDegrees) == 0x5ec, "Offset mismatch for UDelMarBTTask_DriveTrack::MinRequiredDriftDegrees");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MaxRequiredDriftDegrees) == 0x5f0, "Offset mismatch for UDelMarBTTask_DriveTrack::MaxRequiredDriftDegrees");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinRequiredKickDriftDegrees) == 0x5f4, "Offset mismatch for UDelMarBTTask_DriveTrack::MinRequiredKickDriftDegrees");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MaxRequiredKickDriftDegrees) == 0x5f8, "Offset mismatch for UDelMarBTTask_DriveTrack::MaxRequiredKickDriftDegrees");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinSecondsToUpdateRandomDriftConfigValues) == 0x5fc, "Offset mismatch for UDelMarBTTask_DriveTrack::MinSecondsToUpdateRandomDriftConfigValues");
static_assert(offsetof(UDelMarBTTask_DriveTrack, PercentChanceToKickDriftCurve) == 0x600, "Offset mismatch for UDelMarBTTask_DriveTrack::PercentChanceToKickDriftCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinDriftSlipRatioForExitKickDrift) == 0x690, "Offset mismatch for UDelMarBTTask_DriveTrack::MinDriftSlipRatioForExitKickDrift");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinDriftSpeed) == 0x694, "Offset mismatch for UDelMarBTTask_DriveTrack::MinDriftSpeed");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriftKickUnderSteerDegreesThreshold) == 0x698, "Offset mismatch for UDelMarBTTask_DriveTrack::DriftKickUnderSteerDegreesThreshold");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriftKickOverSteerDegreesThreshold) == 0x69c, "Offset mismatch for UDelMarBTTask_DriveTrack::DriftKickOverSteerDegreesThreshold");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriftTapUnderSteerDegreesThreshold) == 0x6a0, "Offset mismatch for UDelMarBTTask_DriveTrack::DriftTapUnderSteerDegreesThreshold");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriftTapOverSteerDegreesThreshold) == 0x6a4, "Offset mismatch for UDelMarBTTask_DriveTrack::DriftTapOverSteerDegreesThreshold");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriftCounterSteerDegreesThreshold) == 0x6a8, "Offset mismatch for UDelMarBTTask_DriveTrack::DriftCounterSteerDegreesThreshold");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinDriftSlipRatioCurve) == 0x6b0, "Offset mismatch for UDelMarBTTask_DriveTrack::MinDriftSlipRatioCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DistanceBetweenDriftSamplesCurve) == 0x740, "Offset mismatch for UDelMarBTTask_DriveTrack::DistanceBetweenDriftSamplesCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriftSampleDistanceFromVehicleCurve) == 0x7d0, "Offset mismatch for UDelMarBTTask_DriveTrack::DriftSampleDistanceFromVehicleCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, DriveGoalJumpHeightThresholdCurve) == 0x860, "Offset mismatch for UDelMarBTTask_DriveTrack::DriveGoalJumpHeightThresholdCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, JumpGoalTrackAngleDistanceOffset) == 0x8f0, "Offset mismatch for UDelMarBTTask_DriveTrack::JumpGoalTrackAngleDistanceOffset");
static_assert(offsetof(UDelMarBTTask_DriveTrack, JumpMinSpeed) == 0x8f4, "Offset mismatch for UDelMarBTTask_DriveTrack::JumpMinSpeed");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinimumUnderthrustPitch) == 0x8f8, "Offset mismatch for UDelMarBTTask_DriveTrack::MinimumUnderthrustPitch");
static_assert(offsetof(UDelMarBTTask_DriveTrack, AirPitchAdjustmentCurve) == 0x900, "Offset mismatch for UDelMarBTTask_DriveTrack::AirPitchAdjustmentCurve");
static_assert(offsetof(UDelMarBTTask_DriveTrack, AirPitchAdjustmentMaxVerticalDegrees) == 0x990, "Offset mismatch for UDelMarBTTask_DriveTrack::AirPitchAdjustmentMaxVerticalDegrees");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinNumTurboChargesNeededToTurbo) == 0x994, "Offset mismatch for UDelMarBTTask_DriveTrack::MinNumTurboChargesNeededToTurbo");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MaxTurboTrackCutoffAngleInDegrees) == 0x998, "Offset mismatch for UDelMarBTTask_DriveTrack::MaxTurboTrackCutoffAngleInDegrees");
static_assert(offsetof(UDelMarBTTask_DriveTrack, TurboActivationBaseChance) == 0x99c, "Offset mismatch for UDelMarBTTask_DriveTrack::TurboActivationBaseChance");
static_assert(offsetof(UDelMarBTTask_DriveTrack, SecondaryTurboBoostChance) == 0x9a0, "Offset mismatch for UDelMarBTTask_DriveTrack::SecondaryTurboBoostChance");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MinTimeBetweenTurboCheck) == 0x9a4, "Offset mismatch for UDelMarBTTask_DriveTrack::MinTimeBetweenTurboCheck");
static_assert(offsetof(UDelMarBTTask_DriveTrack, MaxTimeBetweenTurboCheck) == 0x9a8, "Offset mismatch for UDelMarBTTask_DriveTrack::MaxTimeBetweenTurboCheck");
static_assert(offsetof(UDelMarBTTask_DriveTrack, TrackPositionComponent) == 0x9ac, "Offset mismatch for UDelMarBTTask_DriveTrack::TrackPositionComponent");
static_assert(offsetof(UDelMarBTTask_DriveTrack, TargetTrack) == 0x9b4, "Offset mismatch for UDelMarBTTask_DriveTrack::TargetTrack");
static_assert(offsetof(UDelMarBTTask_DriveTrack, TargetTrackSplineComponent) == 0x9bc, "Offset mismatch for UDelMarBTTask_DriveTrack::TargetTrackSplineComponent");
static_assert(offsetof(UDelMarBTTask_DriveTrack, BlackboardComponent) == 0x9c4, "Offset mismatch for UDelMarBTTask_DriveTrack::BlackboardComponent");

// Size: 0xa0 (Inherited: 0xf0, Single: 0xffffffb0)
class UDelMarBTTask_VehicleBase : public UBTTaskNode
{
public:
    FBlackboardKeySelector VehicleKey; // 0x70 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle; // 0x98 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarBTTask_VehicleBase) == 0xa0, "Size mismatch for UDelMarBTTask_VehicleBase");
static_assert(offsetof(UDelMarBTTask_VehicleBase, VehicleKey) == 0x70, "Offset mismatch for UDelMarBTTask_VehicleBase::VehicleKey");
static_assert(offsetof(UDelMarBTTask_VehicleBase, DelMarVehicle) == 0x98, "Offset mismatch for UDelMarBTTask_VehicleBase::DelMarVehicle");

// Size: 0xb8 (Inherited: 0x190, Single: 0xffffff28)
class UDelMarBTTask_RaceCountdown : public UDelMarBTTask_VehicleBase
{
public:
    float MaxReactionTime; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float MinReactionTime; // 0xa4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_a8[0x10]; // 0xa8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarBTTask_RaceCountdown) == 0xb8, "Size mismatch for UDelMarBTTask_RaceCountdown");
static_assert(offsetof(UDelMarBTTask_RaceCountdown, MaxReactionTime) == 0xa0, "Offset mismatch for UDelMarBTTask_RaceCountdown::MaxReactionTime");
static_assert(offsetof(UDelMarBTTask_RaceCountdown, MinReactionTime) == 0xa4, "Offset mismatch for UDelMarBTTask_RaceCountdown::MinReactionTime");

// Size: 0xc0 (Inherited: 0x1a0, Single: 0xffffff20)
class UDelMarCameraModeOverrideComponent : public UFortCameraModeOverrideComponent
{
public:
};

static_assert(sizeof(UDelMarCameraModeOverrideComponent) == 0xc0, "Size mismatch for UDelMarCameraModeOverrideComponent");

// Size: 0xf0 (Inherited: 0x250, Single: 0xfffffea0)
class UDelMarChallengeGhostSystemControllerComponent : public UControllerComponent
{
public:
    UClass* GhostPlaybackSessionComponentClass; // 0xb8 (Size: 0x8, Type: ClassProperty)
    UClass* GhostRecordingSessionComponentClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    double BestRunTime; // 0xc8 (Size: 0x8, Type: DoubleProperty)
    TWeakObjectPtr<UDelMarGhostPlaybackSessionComponent*> CachedPlaybackSession; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarGhostRecordingSessionComponent*> CachedRecordingSession; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarChallengeRaceManager*> CachedRaceManager; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedLocalPlayerState; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarChallengeGhostSystemControllerComponent) == 0xf0, "Size mismatch for UDelMarChallengeGhostSystemControllerComponent");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, GhostPlaybackSessionComponentClass) == 0xb8, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::GhostPlaybackSessionComponentClass");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, GhostRecordingSessionComponentClass) == 0xc0, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::GhostRecordingSessionComponentClass");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, BestRunTime) == 0xc8, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::BestRunTime");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, CachedPlaybackSession) == 0xd0, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::CachedPlaybackSession");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, CachedRecordingSession) == 0xd8, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::CachedRecordingSession");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, CachedRaceManager) == 0xe0, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::CachedRaceManager");
static_assert(offsetof(UDelMarChallengeGhostSystemControllerComponent, CachedLocalPlayerState) == 0xe8, "Offset mismatch for UDelMarChallengeGhostSystemControllerComponent::CachedLocalPlayerState");

// Size: 0x4f0 (Inherited: 0x7b0, Single: 0xfffffd40)
class ADelMarChallengeRaceManager : public ADelMarRaceManager
{
public:
    bool bIsOvertime; // 0x4e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e1[0x7]; // 0x4e1 (Size: 0x7, Type: PaddingProperty)
    FTimerHandle OvertimeTimer; // 0x4e8 (Size: 0x8, Type: StructProperty)

protected:
    virtual void NetMulticast_StartOvertime(double& const RaceFinishTimestamp); // 0x11b16214 (Index: 0x0, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
};

static_assert(sizeof(ADelMarChallengeRaceManager) == 0x4f0, "Size mismatch for ADelMarChallengeRaceManager");
static_assert(offsetof(ADelMarChallengeRaceManager, bIsOvertime) == 0x4e0, "Offset mismatch for ADelMarChallengeRaceManager::bIsOvertime");
static_assert(offsetof(ADelMarChallengeRaceManager, OvertimeTimer) == 0x4e8, "Offset mismatch for ADelMarChallengeRaceManager::OvertimeTimer");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UDelMarChallengeRacerState_RunActive : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

static_assert(sizeof(UDelMarChallengeRacerState_RunActive) == 0x30, "Size mismatch for UDelMarChallengeRacerState_RunActive");

// Size: 0x1c0 (Inherited: 0xe0, Single: 0xe0)
class UDelMarStateMachine : public UActorComponent
{
public:
    TArray<FDelMarStateOverride> StateOverrides; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TMap<UClass*, FGameplayTag> StateMappings; // 0xc8 (Size: 0x50, Type: MapProperty)
    FGameplayTag RequestedStateTag; // 0x118 (Size: 0x4, Type: StructProperty)
    FGameplayTag CurrentStateTag; // 0x11c (Size: 0x4, Type: StructProperty)
    FGameplayTag DefaultStateTag; // 0x120 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
    TArray<UDelMarState*> ActiveStates; // 0x128 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarState*> ReplicatedStates; // 0x138 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag WaitingForStateReplicationTag; // 0x148 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14c[0x74]; // 0x14c (Size: 0x74, Type: PaddingProperty)

public:
    UDelMarState* GetActiveStateByTag(FGameplayTag& GameplayTag) const; // 0x11ca31f0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarState* GetCurrentState() const; // 0x11ca3334 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetCurrentStateTag() const; // 0xc846444 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetRequestedStateTag() const; // 0xc84613c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RequestState(FGameplayTag& StateTag); // 0x11ca5730 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_RequestedStateTag(); // 0x11ca4970 (Index: 0x4, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarStateMachine) == 0x1c0, "Size mismatch for UDelMarStateMachine");
static_assert(offsetof(UDelMarStateMachine, StateOverrides) == 0xb8, "Offset mismatch for UDelMarStateMachine::StateOverrides");
static_assert(offsetof(UDelMarStateMachine, StateMappings) == 0xc8, "Offset mismatch for UDelMarStateMachine::StateMappings");
static_assert(offsetof(UDelMarStateMachine, RequestedStateTag) == 0x118, "Offset mismatch for UDelMarStateMachine::RequestedStateTag");
static_assert(offsetof(UDelMarStateMachine, CurrentStateTag) == 0x11c, "Offset mismatch for UDelMarStateMachine::CurrentStateTag");
static_assert(offsetof(UDelMarStateMachine, DefaultStateTag) == 0x120, "Offset mismatch for UDelMarStateMachine::DefaultStateTag");
static_assert(offsetof(UDelMarStateMachine, ActiveStates) == 0x128, "Offset mismatch for UDelMarStateMachine::ActiveStates");
static_assert(offsetof(UDelMarStateMachine, ReplicatedStates) == 0x138, "Offset mismatch for UDelMarStateMachine::ReplicatedStates");
static_assert(offsetof(UDelMarStateMachine, WaitingForStateReplicationTag) == 0x148, "Offset mismatch for UDelMarStateMachine::WaitingForStateReplicationTag");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UDelMarRacerState_WithSpectatorTransitionBase : public UDelMarRacerState
{
public:
};

static_assert(sizeof(UDelMarRacerState_WithSpectatorTransitionBase) == 0x30, "Size mismatch for UDelMarRacerState_WithSpectatorTransitionBase");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UDelMarRacerState : public UDelMarState
{
public:
};

static_assert(sizeof(UDelMarRacerState) == 0x30, "Size mismatch for UDelMarRacerState");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDelMarState : public UObject
{
public:
    FGameplayTag StateTag; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarState) == 0x30, "Size mismatch for UDelMarState");
static_assert(offsetof(UDelMarState, StateTag) == 0x28, "Offset mismatch for UDelMarState::StateTag");

// Size: 0x1f0 (Inherited: 0x490, Single: 0xfffffd60)
class UDelMarChallengeRacerStateMachineComponent : public UDelMarRacerStateMachineComponent
{
public:
};

static_assert(sizeof(UDelMarChallengeRacerStateMachineComponent) == 0x1f0, "Size mismatch for UDelMarChallengeRacerStateMachineComponent");

// Size: 0x1f0 (Inherited: 0x2a0, Single: 0xffffff50)
class UDelMarRacerStateMachineComponent : public UDelMarStateMachine
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x1c0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag PreviousStateTag; // 0x1c8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1cc[0x24]; // 0x1cc (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarRacerStateMachineComponent) == 0x1f0, "Size mismatch for UDelMarRacerStateMachineComponent");
static_assert(offsetof(UDelMarRacerStateMachineComponent, RaceManager) == 0x1c0, "Offset mismatch for UDelMarRacerStateMachineComponent::RaceManager");
static_assert(offsetof(UDelMarRacerStateMachineComponent, PreviousStateTag) == 0x1c8, "Offset mismatch for UDelMarRacerStateMachineComponent::PreviousStateTag");

// Size: 0x118 (Inherited: 0x368, Single: 0xfffffdb0)
class UDelMarChallengeSpectatorControllerComponent : public UDelMarSpectatorControllerComponent
{
public:

protected:
    virtual void ClientUpdateFinishedSpectatorTarget(); // 0xc019b98 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetClient|BlueprintCallable)
};

static_assert(sizeof(UDelMarChallengeSpectatorControllerComponent) == 0x118, "Size mismatch for UDelMarChallengeSpectatorControllerComponent");

// Size: 0x118 (Inherited: 0x250, Single: 0xfffffec8)
class UDelMarSpectatorControllerComponent : public UControllerComponent
{
public:
    UInputAction* SpectateNextPlayerAction; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UInputAction* SpectatePrevPlayerAction; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ExitSpectateAction; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UClass* InputManagerClass; // 0xd0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRequestComponent*> SpectatorRequestComponent; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CurrentViewTarget; // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PrevValidViewTarget; // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> SpectatorPlayerState; // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerControllerZone*> SpectatorController; // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    bool bIsLateJoinSpectator; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)

public:
    bool IsLateJoinSpectator() const; // 0xa06501c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void NetMulticast_BeginSpectating(); // 0xcc87b74 (Index: 0x2, Flags: Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable)
    virtual void NetMulticast_FinishSpectating(); // 0x3abd220 (Index: 0x3, Flags: Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable)
    void SetIsLateJoinSpectator(bool& bNewLateJoinSpectator); // 0x11c28748 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetSpectatorTarget(AFortPlayerState*& PlayerState); // 0xd385b00 (Index: 0x6, Flags: Native|Public|BlueprintCallable)

protected:
    void ExitSpectate(); // 0x11c25358 (Index: 0x0, Flags: Final|Native|Protected)
    virtual void ServerSetSpectatorTarget(AFortPlayerState*& PlayerState); // 0xcb1b9c4 (Index: 0x4, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
    void SpectateNextPlayer(); // 0x11c28af0 (Index: 0x7, Flags: Final|Native|Protected)
    void SpectatePrevPlayer(); // 0x11c28b04 (Index: 0x8, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarSpectatorControllerComponent) == 0x118, "Size mismatch for UDelMarSpectatorControllerComponent");
static_assert(offsetof(UDelMarSpectatorControllerComponent, SpectateNextPlayerAction) == 0xb8, "Offset mismatch for UDelMarSpectatorControllerComponent::SpectateNextPlayerAction");
static_assert(offsetof(UDelMarSpectatorControllerComponent, SpectatePrevPlayerAction) == 0xc0, "Offset mismatch for UDelMarSpectatorControllerComponent::SpectatePrevPlayerAction");
static_assert(offsetof(UDelMarSpectatorControllerComponent, ExitSpectateAction) == 0xc8, "Offset mismatch for UDelMarSpectatorControllerComponent::ExitSpectateAction");
static_assert(offsetof(UDelMarSpectatorControllerComponent, InputManagerClass) == 0xd0, "Offset mismatch for UDelMarSpectatorControllerComponent::InputManagerClass");
static_assert(offsetof(UDelMarSpectatorControllerComponent, InputComponent) == 0xd8, "Offset mismatch for UDelMarSpectatorControllerComponent::InputComponent");
static_assert(offsetof(UDelMarSpectatorControllerComponent, CachedRaceManager) == 0xe0, "Offset mismatch for UDelMarSpectatorControllerComponent::CachedRaceManager");
static_assert(offsetof(UDelMarSpectatorControllerComponent, SpectatorRequestComponent) == 0xe8, "Offset mismatch for UDelMarSpectatorControllerComponent::SpectatorRequestComponent");
static_assert(offsetof(UDelMarSpectatorControllerComponent, CurrentViewTarget) == 0xf0, "Offset mismatch for UDelMarSpectatorControllerComponent::CurrentViewTarget");
static_assert(offsetof(UDelMarSpectatorControllerComponent, PrevValidViewTarget) == 0xf8, "Offset mismatch for UDelMarSpectatorControllerComponent::PrevValidViewTarget");
static_assert(offsetof(UDelMarSpectatorControllerComponent, SpectatorPlayerState) == 0x100, "Offset mismatch for UDelMarSpectatorControllerComponent::SpectatorPlayerState");
static_assert(offsetof(UDelMarSpectatorControllerComponent, SpectatorController) == 0x108, "Offset mismatch for UDelMarSpectatorControllerComponent::SpectatorController");
static_assert(offsetof(UDelMarSpectatorControllerComponent, bIsLateJoinSpectator) == 0x110, "Offset mismatch for UDelMarSpectatorControllerComponent::bIsLateJoinSpectator");

// Size: 0x1a0 (Inherited: 0x3a0, Single: 0xfffffe00)
class UDelMarChallengeTimeManagerComponent : public UDelMarTimeManagerComponent
{
public:
    TSet<TWeakObjectPtr<AFortPlayerState*>> SubsequentRunStartSet; // 0x150 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(UDelMarChallengeTimeManagerComponent) == 0x1a0, "Size mismatch for UDelMarChallengeTimeManagerComponent");
static_assert(offsetof(UDelMarChallengeTimeManagerComponent, SubsequentRunStartSet) == 0x150, "Offset mismatch for UDelMarChallengeTimeManagerComponent::SubsequentRunStartSet");

// Size: 0x150 (Inherited: 0x250, Single: 0xffffff00)
class UDelMarTimeManagerComponent : public UDelMarRaceManagerComponent
{
public:
    uint8_t OnPlayerCountdownStarted[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double ServerCountdownStartTime; // 0xc8 (Size: 0x8, Type: DoubleProperty)
    double ServerRaceStartTime; // 0xd0 (Size: 0x8, Type: DoubleProperty)
    double ServerRaceFinishTime; // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double ServerCountdownIntervalTime; // 0xe0 (Size: 0x8, Type: DoubleProperty)
    TWeakObjectPtr<UDelMarRaceConfigComponent*> RaceConfig; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceLevelConfig*> RaceLevelConfig; // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    TMap<double, TWeakObjectPtr<AFortPlayerState*>> ActiveCountdownRunStartTimeMap; // 0x100 (Size: 0x50, Type: MapProperty)

public:
    double GetRaceTimeRemaining() const; // 0x11b1f840 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    double GetSecondsRemainingTillRaceStart() const; // 0x11b1f868 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    double GetSecondsSinceRaceStart() const; // 0x11b1f890 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    double GetServerCountdownIntervalTime() const; // 0xbd722dc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    double GetServerRaceFinishTime() const; // 0xa7461d8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    double GetServerRaceStartTime() const; // 0xdc2db3c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ResetClocks(); // 0x270d644 (Index: 0x6, Flags: Net|NetReliableNative|Event|NetMulticast|Public)

protected:
    virtual void StartCountdownForPlayer(AFortPlayerState*& InPlayerState, double& InServerCountdownStartTime, double& InServerRunStartTime); // 0x11b2135c (Index: 0x7, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void StartCountdownForRace(double& InServerCountdownStartTime, double& InServerRaceStartTime, double& InServerCountdownIntervalTime); // 0x11b21644 (Index: 0x8, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
};

static_assert(sizeof(UDelMarTimeManagerComponent) == 0x150, "Size mismatch for UDelMarTimeManagerComponent");
static_assert(offsetof(UDelMarTimeManagerComponent, OnPlayerCountdownStarted) == 0xb8, "Offset mismatch for UDelMarTimeManagerComponent::OnPlayerCountdownStarted");
static_assert(offsetof(UDelMarTimeManagerComponent, ServerCountdownStartTime) == 0xc8, "Offset mismatch for UDelMarTimeManagerComponent::ServerCountdownStartTime");
static_assert(offsetof(UDelMarTimeManagerComponent, ServerRaceStartTime) == 0xd0, "Offset mismatch for UDelMarTimeManagerComponent::ServerRaceStartTime");
static_assert(offsetof(UDelMarTimeManagerComponent, ServerRaceFinishTime) == 0xd8, "Offset mismatch for UDelMarTimeManagerComponent::ServerRaceFinishTime");
static_assert(offsetof(UDelMarTimeManagerComponent, ServerCountdownIntervalTime) == 0xe0, "Offset mismatch for UDelMarTimeManagerComponent::ServerCountdownIntervalTime");
static_assert(offsetof(UDelMarTimeManagerComponent, RaceConfig) == 0xe8, "Offset mismatch for UDelMarTimeManagerComponent::RaceConfig");
static_assert(offsetof(UDelMarTimeManagerComponent, RaceLevelConfig) == 0xf0, "Offset mismatch for UDelMarTimeManagerComponent::RaceLevelConfig");
static_assert(offsetof(UDelMarTimeManagerComponent, CachedRaceManager) == 0xf8, "Offset mismatch for UDelMarTimeManagerComponent::CachedRaceManager");
static_assert(offsetof(UDelMarTimeManagerComponent, ActiveCountdownRunStartTimeMap) == 0x100, "Offset mismatch for UDelMarTimeManagerComponent::ActiveCountdownRunStartTimeMap");

// Size: 0xb8 (Inherited: 0x198, Single: 0xffffff20)
class UDelMarRaceManagerComponent : public UGameFrameworkComponent
{
public:
};

static_assert(sizeof(UDelMarRaceManagerComponent) == 0xb8, "Size mismatch for UDelMarRaceManagerComponent");

// Size: 0x58 (Inherited: 0x88, Single: 0xffffffd0)
class UDelMarCheckpointTheme : public UPrimaryDataAsset
{
public:
    UStaticMesh* RimMesh; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* DefaultTentMesh; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* DefaultHoloMesh; // 0x40 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* StartLineTentMesh; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* StartLineHoloMesh; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarCheckpointTheme) == 0x58, "Size mismatch for UDelMarCheckpointTheme");
static_assert(offsetof(UDelMarCheckpointTheme, RimMesh) == 0x30, "Offset mismatch for UDelMarCheckpointTheme::RimMesh");
static_assert(offsetof(UDelMarCheckpointTheme, DefaultTentMesh) == 0x38, "Offset mismatch for UDelMarCheckpointTheme::DefaultTentMesh");
static_assert(offsetof(UDelMarCheckpointTheme, DefaultHoloMesh) == 0x40, "Offset mismatch for UDelMarCheckpointTheme::DefaultHoloMesh");
static_assert(offsetof(UDelMarCheckpointTheme, StartLineTentMesh) == 0x48, "Offset mismatch for UDelMarCheckpointTheme::StartLineTentMesh");
static_assert(offsetof(UDelMarCheckpointTheme, StartLineHoloMesh) == 0x50, "Offset mismatch for UDelMarCheckpointTheme::StartLineHoloMesh");

// Size: 0xb8 (Inherited: 0x250, Single: 0xfffffe68)
class UDelMarClientReplayRecordingComponent : public UControllerComponent
{
public:
};

static_assert(sizeof(UDelMarClientReplayRecordingComponent) == 0xb8, "Size mismatch for UDelMarClientReplayRecordingComponent");

// Size: 0x4f8 (Inherited: 0x7b0, Single: 0xfffffd48)
class ADelMarCompetitiveRaceManager : public ADelMarRaceManager
{
public:
    float FinishRaceAfterFirstPlayerFinishedSeconds; // 0x4e0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4e4[0xc]; // 0x4e4 (Size: 0xc, Type: PaddingProperty)
    double FirstPlayerFinishedTimestamp; // 0x4f0 (Size: 0x8, Type: DoubleProperty)

protected:
    void HandleFinalRacePositionsUpdated(const TArray<FDelMarFinalRacePositionEntry> FinalRacePositions, const FDelMarEvent_RunRecorded RecordedRun); // 0x11b154d0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnRep_FirstPlayerFinishedTimestamp(); // 0x11b173d0 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarCompetitiveRaceManager) == 0x4f8, "Size mismatch for ADelMarCompetitiveRaceManager");
static_assert(offsetof(ADelMarCompetitiveRaceManager, FinishRaceAfterFirstPlayerFinishedSeconds) == 0x4e0, "Offset mismatch for ADelMarCompetitiveRaceManager::FinishRaceAfterFirstPlayerFinishedSeconds");
static_assert(offsetof(ADelMarCompetitiveRaceManager, FirstPlayerFinishedTimestamp) == 0x4f0, "Offset mismatch for ADelMarCompetitiveRaceManager::FirstPlayerFinishedTimestamp");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UDelMarCompetitiveRacerState_RunActive : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

static_assert(sizeof(UDelMarCompetitiveRacerState_RunActive) == 0x30, "Size mismatch for UDelMarCompetitiveRacerState_RunActive");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UDelMarCompetitiveRacerState_RunFinished : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

static_assert(sizeof(UDelMarCompetitiveRacerState_RunFinished) == 0x30, "Size mismatch for UDelMarCompetitiveRacerState_RunFinished");

// Size: 0x1f0 (Inherited: 0x490, Single: 0xfffffd60)
class UDelMarCompetitiveRacerStateMachineComponent : public UDelMarRacerStateMachineComponent
{
public:
};

static_assert(sizeof(UDelMarCompetitiveRacerStateMachineComponent) == 0x1f0, "Size mismatch for UDelMarCompetitiveRacerStateMachineComponent");

// Size: 0x108 (Inherited: 0xe0, Single: 0x28)
class UDelMarConnectedHintComponent : public UActorComponent
{
public:
    bool bShouldShowHint; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    UClass* VehicleActionClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    bool bAcceptMultipleTags; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer MultipleTagContainer; // 0xd0 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarVehicleAction* VehicleAction; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_100[0x8]; // 0x100 (Size: 0x8, Type: PaddingProperty)

public:
    void BeginPlay(); // 0xa39cb48 (Index: 0x0, Flags: Native|Public)
    void HandleActorBeginOverlap(AActor*& OverlappedActor, AActor*& OtherActor); // 0x11b14f44 (Index: 0x1, Flags: Final|Native|Public)
    void HandleActorEndOverlap(AActor*& OverlappedActor, AActor*& OtherActor); // 0x11b151b8 (Index: 0x2, Flags: Final|Native|Public)
    void PassNuxHintTypeToConnectedHintComponent(FGameplayTag& const HintTypeTag); // 0x11b17478 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleVehicleActionPerformed(); // 0x11b15828 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarConnectedHintComponent) == 0x108, "Size mismatch for UDelMarConnectedHintComponent");
static_assert(offsetof(UDelMarConnectedHintComponent, bShouldShowHint) == 0xb8, "Offset mismatch for UDelMarConnectedHintComponent::bShouldShowHint");
static_assert(offsetof(UDelMarConnectedHintComponent, VehicleActionClass) == 0xc0, "Offset mismatch for UDelMarConnectedHintComponent::VehicleActionClass");
static_assert(offsetof(UDelMarConnectedHintComponent, bAcceptMultipleTags) == 0xc8, "Offset mismatch for UDelMarConnectedHintComponent::bAcceptMultipleTags");
static_assert(offsetof(UDelMarConnectedHintComponent, MultipleTagContainer) == 0xd0, "Offset mismatch for UDelMarConnectedHintComponent::MultipleTagContainer");
static_assert(offsetof(UDelMarConnectedHintComponent, CachedVehicle) == 0xf0, "Offset mismatch for UDelMarConnectedHintComponent::CachedVehicle");
static_assert(offsetof(UDelMarConnectedHintComponent, VehicleAction) == 0xf8, "Offset mismatch for UDelMarConnectedHintComponent::VehicleAction");

// Size: 0x130 (Inherited: 0x378, Single: 0xfffffdb8)
class UDelMarCoreOobTubePositionalRenderingComponent : public UDelMarTrackOobTubePositionalRenderingComponent
{
public:
    TWeakObjectPtr<APlayerState*> ViewTargetPlayerState; // 0x128 (Size: 0x8, Type: WeakObjectProperty)

private:
    void HandleAIPawnSpawned(AAIController*& BotController, AFortPawn*& BotPawn); // 0x11b14cd4 (Index: 0x0, Flags: Final|Native|Private)
    void HandleViewTargetChanged(AFortPlayerController*& FortPC, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11b15840 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UDelMarCoreOobTubePositionalRenderingComponent) == 0x130, "Size mismatch for UDelMarCoreOobTubePositionalRenderingComponent");
static_assert(offsetof(UDelMarCoreOobTubePositionalRenderingComponent, ViewTargetPlayerState) == 0x128, "Offset mismatch for UDelMarCoreOobTubePositionalRenderingComponent::ViewTargetPlayerState");

// Size: 0x740 (Inherited: 0x1af0, Single: 0xffffec50)
class UDelMarCoreSplineMeshComponent : public USplineMeshComponent
{
public:

private:
    void OnBeginActorOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b16348 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UDelMarCoreSplineMeshComponent) == 0x740, "Size mismatch for UDelMarCoreSplineMeshComponent");

// Size: 0x50 (Inherited: 0x88, Single: 0xffffffc8)
class UDelMarCosmeticsDatabase : public UPrimaryDataAsset
{
public:
    TArray<UDelMarCosmeticItemDefinition*> Items; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarCosmeticSlotInfo> SlotInfos; // 0x40 (Size: 0x10, Type: ArrayProperty)

public:
    TArray<UDelMarCosmeticItemDefinition*> GetItemsForSlot(FGameplayTag& Slot); // 0x11b14ae0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FDelMarCosmeticSlotInfo> GetSlotInfos() const; // 0x11b14c48 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarCosmeticsDatabase) == 0x50, "Size mismatch for UDelMarCosmeticsDatabase");
static_assert(offsetof(UDelMarCosmeticsDatabase, Items) == 0x30, "Offset mismatch for UDelMarCosmeticsDatabase::Items");
static_assert(offsetof(UDelMarCosmeticsDatabase, SlotInfos) == 0x40, "Offset mismatch for UDelMarCosmeticsDatabase::SlotInfos");

// Size: 0x40 (Inherited: 0xb8, Single: 0xffffff88)
class UDelMarDeathRacerState_ActiveRace : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
    TWeakObjectPtr<ADelMarDeathRaceManager*> DeathRaceManager; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    bool bFinishedRound; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarDeathRacerState_ActiveRace) == 0x40, "Size mismatch for UDelMarDeathRacerState_ActiveRace");
static_assert(offsetof(UDelMarDeathRacerState_ActiveRace, DeathRaceManager) == 0x30, "Offset mismatch for UDelMarDeathRacerState_ActiveRace::DeathRaceManager");
static_assert(offsetof(UDelMarDeathRacerState_ActiveRace, bFinishedRound) == 0x38, "Offset mismatch for UDelMarDeathRacerState_ActiveRace::bFinishedRound");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UDelMarDeathRacerState_FinishedRace : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
};

static_assert(sizeof(UDelMarDeathRacerState_FinishedRace) == 0x30, "Size mismatch for UDelMarDeathRacerState_FinishedRace");

// Size: 0x1f0 (Inherited: 0x490, Single: 0xfffffd60)
class UDelMarDeathRacerStateMachineComponent : public UDelMarRacerStateMachineComponent
{
public:
};

static_assert(sizeof(UDelMarDeathRacerStateMachineComponent) == 0x1f0, "Size mismatch for UDelMarDeathRacerStateMachineComponent");

// Size: 0x60 (Inherited: 0x78, Single: 0xffffffe8)
class UDelMarDoubleTapInputTrigger : public UInputTrigger
{
public:
    float Delay; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0xc]; // 0x54 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarDoubleTapInputTrigger) == 0x60, "Size mismatch for UDelMarDoubleTapInputTrigger");
static_assert(offsetof(UDelMarDoubleTapInputTrigger, Delay) == 0x50, "Offset mismatch for UDelMarDoubleTapInputTrigger::Delay");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarDriveParticlesPhysMatAttribute : public UDelMarPhysMatAttribute
{
public:
    UNiagaraSystem* DriveParticles; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarDriveParticlesPhysMatAttribute) == 0x30, "Size mismatch for UDelMarDriveParticlesPhysMatAttribute");
static_assert(offsetof(UDelMarDriveParticlesPhysMatAttribute, DriveParticles) == 0x28, "Offset mismatch for UDelMarDriveParticlesPhysMatAttribute::DriveParticles");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarPhysMatAttribute : public UObject
{
public:
};

static_assert(sizeof(UDelMarPhysMatAttribute) == 0x28, "Size mismatch for UDelMarPhysMatAttribute");

// Size: 0x110 (Inherited: 0x250, Single: 0xfffffec0)
class UDelMarDriverInteractionComponent : public UControllerComponent
{
public:
    AFortPlayerState* ViewPlayerState; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* ViewVehicle; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0x30]; // 0xc8 (Size: 0x30, Type: PaddingProperty)
    float PassEventSquareDistThreshold; // 0xf8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
    UDelMarPlayerRaceDataComponent* RaceData; // 0x100 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)

protected:
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11b15b94 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarDriverInteractionComponent) == 0x110, "Size mismatch for UDelMarDriverInteractionComponent");
static_assert(offsetof(UDelMarDriverInteractionComponent, ViewPlayerState) == 0xb8, "Offset mismatch for UDelMarDriverInteractionComponent::ViewPlayerState");
static_assert(offsetof(UDelMarDriverInteractionComponent, ViewVehicle) == 0xc0, "Offset mismatch for UDelMarDriverInteractionComponent::ViewVehicle");
static_assert(offsetof(UDelMarDriverInteractionComponent, PassEventSquareDistThreshold) == 0xf8, "Offset mismatch for UDelMarDriverInteractionComponent::PassEventSquareDistThreshold");
static_assert(offsetof(UDelMarDriverInteractionComponent, RaceData) == 0x100, "Offset mismatch for UDelMarDriverInteractionComponent::RaceData");

// Size: 0x330 (Inherited: 0x5e0, Single: 0xfffffd50)
class ADelMarEnvironmentEffectCueNotify_Actor : public AGameplayCueNotify_Actor
{
public:
    FDelMarEnvironmentVFX Effects; // 0x310 (Size: 0x18, Type: StructProperty)
    bool bShowOnAllClients; // 0x328 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_329[0x7]; // 0x329 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarEnvironmentEffectCueNotify_Actor) == 0x330, "Size mismatch for ADelMarEnvironmentEffectCueNotify_Actor");
static_assert(offsetof(ADelMarEnvironmentEffectCueNotify_Actor, Effects) == 0x310, "Offset mismatch for ADelMarEnvironmentEffectCueNotify_Actor::Effects");
static_assert(offsetof(ADelMarEnvironmentEffectCueNotify_Actor, bShowOnAllClients) == 0x328, "Offset mismatch for ADelMarEnvironmentEffectCueNotify_Actor::bShowOnAllClients");

// Size: 0x308 (Inherited: 0x2d0, Single: 0x38)
class ADelMarEnvironmentEffectsVolume : public AActor
{
public:
    UClass* AppliedEffect; // 0x2a8 (Size: 0x8, Type: ClassProperty)
    UBoxComponent* BoxCollider; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x50]; // 0x2b8 (Size: 0x50, Type: PaddingProperty)

protected:
    void OnBeginOverlap(UPrimitiveComponent*& OverlappedComp, AActor*& Other, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b16acc (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnEndOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0x11b1702c (Index: 0x1, Flags: Final|Native|Protected)
    void RemoveGameplayEffect(AActor*& Actor); // 0x11b17538 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarEnvironmentEffectsVolume) == 0x308, "Size mismatch for ADelMarEnvironmentEffectsVolume");
static_assert(offsetof(ADelMarEnvironmentEffectsVolume, AppliedEffect) == 0x2a8, "Offset mismatch for ADelMarEnvironmentEffectsVolume::AppliedEffect");
static_assert(offsetof(ADelMarEnvironmentEffectsVolume, BoxCollider) == 0x2b0, "Offset mismatch for ADelMarEnvironmentEffectsVolume::BoxCollider");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UDelMarEvent_GlobalLeaderboardActive : public UObject
{
public:
    FString LeaderboardEventId; // 0x28 (Size: 0x10, Type: StrProperty)
    FString LeaderboardWindowId; // 0x38 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UDelMarEvent_GlobalLeaderboardActive) == 0x48, "Size mismatch for UDelMarEvent_GlobalLeaderboardActive");
static_assert(offsetof(UDelMarEvent_GlobalLeaderboardActive, LeaderboardEventId) == 0x28, "Offset mismatch for UDelMarEvent_GlobalLeaderboardActive::LeaderboardEventId");
static_assert(offsetof(UDelMarEvent_GlobalLeaderboardActive, LeaderboardWindowId) == 0x38, "Offset mismatch for UDelMarEvent_GlobalLeaderboardActive::LeaderboardWindowId");

// Size: 0xd0 (Inherited: 0x250, Single: 0xfffffe80)
class UDelMarFlowAnalyticsControllerComponent : public UControllerComponent
{
public:
    FString FlowAnalyicsEventName; // 0xb8 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<AFortPlayerController*> PlayerController; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)

public:
    void TutorialComplete(); // 0x11b19aac (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void TutorialGoRace(); // 0x11b19ac0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void TutorialKeepTraining(); // 0x11b19ad4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void TutorialReplay(); // 0x11b19ae8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarFlowAnalyticsControllerComponent) == 0xd0, "Size mismatch for UDelMarFlowAnalyticsControllerComponent");
static_assert(offsetof(UDelMarFlowAnalyticsControllerComponent, FlowAnalyicsEventName) == 0xb8, "Offset mismatch for UDelMarFlowAnalyticsControllerComponent::FlowAnalyicsEventName");
static_assert(offsetof(UDelMarFlowAnalyticsControllerComponent, PlayerController) == 0xc8, "Offset mismatch for UDelMarFlowAnalyticsControllerComponent::PlayerController");

// Size: 0x130 (Inherited: 0x250, Single: 0xfffffee0)
class UDelMarGameAnalyticsComponent : public UGameStateComponent
{
public:
    TWeakObjectPtr<AFortGameState*> CachedGameState; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    TMap<FGameplayTagContainer, EDelMarRaceMode> TrackQuestUsageRaceModes; // 0xd0 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<AFortPlayerState*>> CachedOpenedQuestPlayers; // 0x120 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarGameAnalyticsComponent) == 0x130, "Size mismatch for UDelMarGameAnalyticsComponent");
static_assert(offsetof(UDelMarGameAnalyticsComponent, CachedGameState) == 0xb8, "Offset mismatch for UDelMarGameAnalyticsComponent::CachedGameState");
static_assert(offsetof(UDelMarGameAnalyticsComponent, CachedRaceManager) == 0xc0, "Offset mismatch for UDelMarGameAnalyticsComponent::CachedRaceManager");
static_assert(offsetof(UDelMarGameAnalyticsComponent, TrackQuestUsageRaceModes) == 0xd0, "Offset mismatch for UDelMarGameAnalyticsComponent::TrackQuestUsageRaceModes");
static_assert(offsetof(UDelMarGameAnalyticsComponent, CachedOpenedQuestPlayers) == 0x120, "Offset mismatch for UDelMarGameAnalyticsComponent::CachedOpenedQuestPlayers");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UDelMarGameplayState : public UDelMarState
{
public:
};

static_assert(sizeof(UDelMarGameplayState) == 0x30, "Size mismatch for UDelMarGameplayState");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UDelMarGameUserSettings : public UObject
{
public:
    int32_t NuxLastViewedVideoVersion; // 0x28 (Size: 0x4, Type: IntProperty)
    bool bNuxHasPromptedToPlayTutorial; // 0x2c (Size: 0x1, Type: BoolProperty)
    bool bHasPromptedToPlaySpeedRun; // 0x2d (Size: 0x1, Type: BoolProperty)
    bool bNuxHasShownDefaultMode; // 0x2e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f[0x1]; // 0x2f (Size: 0x1, Type: PaddingProperty)
    FString LastPlayedDelMarMnemonic; // 0x30 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UDelMarGameUserSettings) == 0x40, "Size mismatch for UDelMarGameUserSettings");
static_assert(offsetof(UDelMarGameUserSettings, NuxLastViewedVideoVersion) == 0x28, "Offset mismatch for UDelMarGameUserSettings::NuxLastViewedVideoVersion");
static_assert(offsetof(UDelMarGameUserSettings, bNuxHasPromptedToPlayTutorial) == 0x2c, "Offset mismatch for UDelMarGameUserSettings::bNuxHasPromptedToPlayTutorial");
static_assert(offsetof(UDelMarGameUserSettings, bHasPromptedToPlaySpeedRun) == 0x2d, "Offset mismatch for UDelMarGameUserSettings::bHasPromptedToPlaySpeedRun");
static_assert(offsetof(UDelMarGameUserSettings, bNuxHasShownDefaultMode) == 0x2e, "Offset mismatch for UDelMarGameUserSettings::bNuxHasShownDefaultMode");
static_assert(offsetof(UDelMarGameUserSettings, LastPlayedDelMarMnemonic) == 0x30, "Offset mismatch for UDelMarGameUserSettings::LastPlayedDelMarMnemonic");

// Size: 0x110 (Inherited: 0x318, Single: 0xfffffdf8)
class UDelMarGhostPlaybackSessionComponent : public UDelMarGhostSessionComponent
{
public:
    uint8_t Pad_c8[0x20]; // 0xc8 (Size: 0x20, Type: PaddingProperty)
    uint8_t TeleportSetting; // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)
    UClass* PlaybackActorClass; // 0xf0 (Size: 0x8, Type: ClassProperty)
    int32_t CurrentFrame; // 0xf8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
    UDelMarGhostReplayLog* PlaybackLog; // 0x100 (Size: 0x8, Type: ObjectProperty)
    AFortPhysicsPawn* PlaybackActor; // 0x108 (Size: 0x8, Type: ObjectProperty)

public:
    void SetPlaybackLog(UDelMarGhostReplayLog*& InLog); // 0x11b19854 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarGhostPlaybackSessionComponent) == 0x110, "Size mismatch for UDelMarGhostPlaybackSessionComponent");
static_assert(offsetof(UDelMarGhostPlaybackSessionComponent, TeleportSetting) == 0xe8, "Offset mismatch for UDelMarGhostPlaybackSessionComponent::TeleportSetting");
static_assert(offsetof(UDelMarGhostPlaybackSessionComponent, PlaybackActorClass) == 0xf0, "Offset mismatch for UDelMarGhostPlaybackSessionComponent::PlaybackActorClass");
static_assert(offsetof(UDelMarGhostPlaybackSessionComponent, CurrentFrame) == 0xf8, "Offset mismatch for UDelMarGhostPlaybackSessionComponent::CurrentFrame");
static_assert(offsetof(UDelMarGhostPlaybackSessionComponent, PlaybackLog) == 0x100, "Offset mismatch for UDelMarGhostPlaybackSessionComponent::PlaybackLog");
static_assert(offsetof(UDelMarGhostPlaybackSessionComponent, PlaybackActor) == 0x108, "Offset mismatch for UDelMarGhostPlaybackSessionComponent::PlaybackActor");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UDelMarGhostSessionComponent : public UControllerComponent
{
public:

public:
    bool IsSessionActive() const; // 0xca9e578 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void StartSession(); // 0x270d644 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void StopSession(); // 0x3abd220 (Index: 0x2, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarGhostSessionComponent) == 0xc8, "Size mismatch for UDelMarGhostSessionComponent");

// Size: 0x2d8 (Inherited: 0x2d0, Single: 0x8)
class ADelMarGhostPlaybackTrigger : public AActor
{
public:
    int32_t PreviewFrame; // 0x2a8 (Size: 0x4, Type: IntProperty)
    int32_t StartFrame; // 0x2ac (Size: 0x4, Type: IntProperty)
    int32_t EndFrame; // 0x2b0 (Size: 0x4, Type: IntProperty)
    int32_t MaxFrame; // 0x2b4 (Size: 0x4, Type: IntProperty)
    UDelMarGhostReplayLog* PlaybackLog; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* BoxCollider; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UClass* PlaybackSessionClassOverride; // 0x2c8 (Size: 0x8, Type: ClassProperty)
    UDelMarGhostPlaybackSessionComponent* PlaybackSession; // 0x2d0 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BP_HandlePlaybackCompleted(FVector& const Location); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasDefaults|BlueprintEvent)
    void HandlePlaybackCompleted(); // 0x11b182e4 (Index: 0x1, Flags: Final|Native|Protected)
    void OnBeginOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b183b4 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(ADelMarGhostPlaybackTrigger) == 0x2d8, "Size mismatch for ADelMarGhostPlaybackTrigger");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, PreviewFrame) == 0x2a8, "Offset mismatch for ADelMarGhostPlaybackTrigger::PreviewFrame");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, StartFrame) == 0x2ac, "Offset mismatch for ADelMarGhostPlaybackTrigger::StartFrame");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, EndFrame) == 0x2b0, "Offset mismatch for ADelMarGhostPlaybackTrigger::EndFrame");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, MaxFrame) == 0x2b4, "Offset mismatch for ADelMarGhostPlaybackTrigger::MaxFrame");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, PlaybackLog) == 0x2b8, "Offset mismatch for ADelMarGhostPlaybackTrigger::PlaybackLog");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, BoxCollider) == 0x2c0, "Offset mismatch for ADelMarGhostPlaybackTrigger::BoxCollider");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, PlaybackSessionClassOverride) == 0x2c8, "Offset mismatch for ADelMarGhostPlaybackTrigger::PlaybackSessionClassOverride");
static_assert(offsetof(ADelMarGhostPlaybackTrigger, PlaybackSession) == 0x2d0, "Offset mismatch for ADelMarGhostPlaybackTrigger::PlaybackSession");

// Size: 0x118 (Inherited: 0x318, Single: 0xfffffe00)
class UDelMarGhostRecordingSessionComponent : public UDelMarGhostSessionComponent
{
public:
    uint8_t Pad_c8[0x18]; // 0xc8 (Size: 0x18, Type: PaddingProperty)
    UDelMarGhostReplayLog* RecordLog; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    bool bRecordOffPhysicsDelegate; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x23]; // 0xe9 (Size: 0x23, Type: PaddingProperty)
    int32_t CurrentFrame; // 0x10c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0x110 (Size: 0x8, Type: WeakObjectProperty)

public:
    void SetRecordOffPhysicsDelegate(bool& bEnabled); // 0x11b19980 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarGhostRecordingSessionComponent) == 0x118, "Size mismatch for UDelMarGhostRecordingSessionComponent");
static_assert(offsetof(UDelMarGhostRecordingSessionComponent, RecordLog) == 0xe0, "Offset mismatch for UDelMarGhostRecordingSessionComponent::RecordLog");
static_assert(offsetof(UDelMarGhostRecordingSessionComponent, bRecordOffPhysicsDelegate) == 0xe8, "Offset mismatch for UDelMarGhostRecordingSessionComponent::bRecordOffPhysicsDelegate");
static_assert(offsetof(UDelMarGhostRecordingSessionComponent, CurrentFrame) == 0x10c, "Offset mismatch for UDelMarGhostRecordingSessionComponent::CurrentFrame");
static_assert(offsetof(UDelMarGhostRecordingSessionComponent, CachedDelMarVehicle) == 0x110, "Offset mismatch for UDelMarGhostRecordingSessionComponent::CachedDelMarVehicle");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UDelMarGhostReplayLog : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<FGhostReplayFrame> Frames; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarGhostReplayLog) == 0x40, "Size mismatch for UDelMarGhostReplayLog");
static_assert(offsetof(UDelMarGhostReplayLog, Frames) == 0x30, "Offset mismatch for UDelMarGhostReplayLog::Frames");

// Size: 0x168 (Inherited: 0x250, Single: 0xffffff18)
class UDelMarGlobalLeaderboardControllerComponent : public UControllerComponent
{
public:
    bool bIsLeaderboardEnabled; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    TArray<FDelMarGlobalLeaderboardEntry> TopLeaderboardEntries; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarGlobalLeaderboardEntry> FocusedLeaderboardEntries; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarGlobalLeaderboardEntry> FriendLeaderboardEntries; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    bool bHasRequestedLeaderboards; // 0xf0 (Size: 0x1, Type: BoolProperty)
    bool bHasPersonalBest; // 0xf1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f2[0x6]; // 0xf2 (Size: 0x6, Type: PaddingProperty)
    FDelMarGlobalLeaderboardEntry PersonalBest; // 0xf8 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_138[0x8]; // 0x138 (Size: 0x8, Type: PaddingProperty)
    UDelMarEvent_GlobalLeaderboardActive* GlobalLeaderboardActiveEvent; // 0x140 (Size: 0x8, Type: ObjectProperty)
    FDelMarLeaderboardSettings LeaderboardSettings; // 0x148 (Size: 0x20, Type: StructProperty)

private:
    void OnRep_LeaderboardSettings(); // 0x11b19768 (Index: 0x2, Flags: Final|Native|Private)

protected:
    virtual void ClientNewPersonalBest(FDelMarEvent_GlobalLeaderboardNewPersonalBest& const PersonalBestEvent); // 0x11b1820c (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientUpdateLeaderboards(); // 0x270d644 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ServerNewPersonalBest(FDelMarEvent_GlobalLeaderboardNewPersonalBest& const PersonalBestRetrievedEvent); // 0x11b1977c (Index: 0x3, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(UDelMarGlobalLeaderboardControllerComponent) == 0x168, "Size mismatch for UDelMarGlobalLeaderboardControllerComponent");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, bIsLeaderboardEnabled) == 0xb8, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::bIsLeaderboardEnabled");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, TopLeaderboardEntries) == 0xc0, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::TopLeaderboardEntries");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, FocusedLeaderboardEntries) == 0xd0, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::FocusedLeaderboardEntries");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, FriendLeaderboardEntries) == 0xe0, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::FriendLeaderboardEntries");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, bHasRequestedLeaderboards) == 0xf0, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::bHasRequestedLeaderboards");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, bHasPersonalBest) == 0xf1, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::bHasPersonalBest");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, PersonalBest) == 0xf8, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::PersonalBest");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, GlobalLeaderboardActiveEvent) == 0x140, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::GlobalLeaderboardActiveEvent");
static_assert(offsetof(UDelMarGlobalLeaderboardControllerComponent, LeaderboardSettings) == 0x148, "Offset mismatch for UDelMarGlobalLeaderboardControllerComponent::LeaderboardSettings");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGuidedZoneRequirement : public UObject
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement) == 0x28, "Size mismatch for UGuidedZoneRequirement");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_Drift : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_Drift) == 0x28, "Size mismatch for UGuidedZoneRequirement_Drift");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_DriftKick : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_DriftKick) == 0x28, "Size mismatch for UGuidedZoneRequirement_DriftKick");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_Kickflip : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_Kickflip) == 0x28, "Size mismatch for UGuidedZoneRequirement_Kickflip");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_Turbo : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_Turbo) == 0x28, "Size mismatch for UGuidedZoneRequirement_Turbo");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_TurboBonusZone : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_TurboBonusZone) == 0x28, "Size mismatch for UGuidedZoneRequirement_TurboBonusZone");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_Underthrust : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_Underthrust) == 0x28, "Size mismatch for UGuidedZoneRequirement_Underthrust");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_Jump : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_Jump) == 0x28, "Size mismatch for UGuidedZoneRequirement_Jump");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UGuidedZoneRequirement_JumpOrUnderthrust : public UGuidedZoneRequirement_Jump
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_JumpOrUnderthrust) == 0x28, "Size mismatch for UGuidedZoneRequirement_JumpOrUnderthrust");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_DriftActive : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_DriftActive) == 0x28, "Size mismatch for UGuidedZoneRequirement_DriftActive");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGuidedZoneRequirement_DriftBoostActive : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_DriftBoostActive) == 0x28, "Size mismatch for UGuidedZoneRequirement_DriftBoostActive");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UGuidedZoneRequirement_MidTutorial : public UGuidedZoneRequirement
{
public:
};

static_assert(sizeof(UGuidedZoneRequirement_MidTutorial) == 0x38, "Size mismatch for UGuidedZoneRequirement_MidTutorial");

// Size: 0x3c0 (Inherited: 0x2d0, Single: 0xf0)
class ADelMarGuidedTutorialZoneActor : public AActor
{
public:
    UBoxComponent* BoxCollider; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    float FinalTimeDilation; // 0x2b0 (Size: 0x4, Type: FloatProperty)
    float TransitionSeconds; // 0x2b4 (Size: 0x4, Type: FloatProperty)
    float MaxTimeDilationSeconds; // 0x2b8 (Size: 0x4, Type: FloatProperty)
    bool bDemoVehicleOnFail; // 0x2bc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2bd[0x3]; // 0x2bd (Size: 0x3, Type: PaddingProperty)
    FDelMarEvent_SetTutorialAnnouncement ScreenMessage; // 0x2c0 (Size: 0x40, Type: StructProperty)
    float HintDelaySeconds; // 0x300 (Size: 0x4, Type: FloatProperty)
    float HintRemovalDelaySeconds; // 0x304 (Size: 0x4, Type: FloatProperty)
    UClass* ZoneRequirementClass; // 0x308 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer InputTagsToRemoveOnZoneStart; // 0x310 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InputTagsToAddOnZoneStart; // 0x330 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InputTagsToRemoveOnZoneEnd; // 0x350 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InputTagsToAddOnZoneEnd; // 0x370 (Size: 0x20, Type: StructProperty)
    UGuidedZoneRequirement* ZoneRequirement; // 0x390 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x398 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> ActiveVehicle; // 0x3a0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> ActivePlayerController; // 0x3a8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3b0[0x10]; // 0x3b0 (Size: 0x10, Type: PaddingProperty)

protected:
    virtual void BP_OnTutorialZoneComplete(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnTutorialZoneFailed(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnTutorialZoneStarted(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11b182f8 (Index: 0x3, Flags: Final|Native|Protected)
    void OnBeginOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b188f0 (Index: 0x4, Flags: Final|Native|Protected|HasOutParms)
    void OnEndOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0x11b193b0 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarGuidedTutorialZoneActor) == 0x3c0, "Size mismatch for ADelMarGuidedTutorialZoneActor");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, BoxCollider) == 0x2a8, "Offset mismatch for ADelMarGuidedTutorialZoneActor::BoxCollider");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, FinalTimeDilation) == 0x2b0, "Offset mismatch for ADelMarGuidedTutorialZoneActor::FinalTimeDilation");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, TransitionSeconds) == 0x2b4, "Offset mismatch for ADelMarGuidedTutorialZoneActor::TransitionSeconds");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, MaxTimeDilationSeconds) == 0x2b8, "Offset mismatch for ADelMarGuidedTutorialZoneActor::MaxTimeDilationSeconds");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, bDemoVehicleOnFail) == 0x2bc, "Offset mismatch for ADelMarGuidedTutorialZoneActor::bDemoVehicleOnFail");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, ScreenMessage) == 0x2c0, "Offset mismatch for ADelMarGuidedTutorialZoneActor::ScreenMessage");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, HintDelaySeconds) == 0x300, "Offset mismatch for ADelMarGuidedTutorialZoneActor::HintDelaySeconds");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, HintRemovalDelaySeconds) == 0x304, "Offset mismatch for ADelMarGuidedTutorialZoneActor::HintRemovalDelaySeconds");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, ZoneRequirementClass) == 0x308, "Offset mismatch for ADelMarGuidedTutorialZoneActor::ZoneRequirementClass");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, InputTagsToRemoveOnZoneStart) == 0x310, "Offset mismatch for ADelMarGuidedTutorialZoneActor::InputTagsToRemoveOnZoneStart");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, InputTagsToAddOnZoneStart) == 0x330, "Offset mismatch for ADelMarGuidedTutorialZoneActor::InputTagsToAddOnZoneStart");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, InputTagsToRemoveOnZoneEnd) == 0x350, "Offset mismatch for ADelMarGuidedTutorialZoneActor::InputTagsToRemoveOnZoneEnd");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, InputTagsToAddOnZoneEnd) == 0x370, "Offset mismatch for ADelMarGuidedTutorialZoneActor::InputTagsToAddOnZoneEnd");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, ZoneRequirement) == 0x390, "Offset mismatch for ADelMarGuidedTutorialZoneActor::ZoneRequirement");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, RaceManager) == 0x398, "Offset mismatch for ADelMarGuidedTutorialZoneActor::RaceManager");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, ActiveVehicle) == 0x3a0, "Offset mismatch for ADelMarGuidedTutorialZoneActor::ActiveVehicle");
static_assert(offsetof(ADelMarGuidedTutorialZoneActor, ActivePlayerController) == 0x3a8, "Offset mismatch for ADelMarGuidedTutorialZoneActor::ActivePlayerController");

// Size: 0x2e8 (Inherited: 0x2d0, Single: 0x18)
class ADelMarInputModifierHazard : public AActor
{
public:
    TArray<FDelMarActivatedInputFrame> ActivatedInputSequence; // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarDisabledInputData> DisabledEffects; // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    UBoxComponent* BoxCollider; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    APlayerController* LocalController; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UEnhancedPlayerInput* LocalPlayerInput; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    float StartOverlapTime; // 0x2e0 (Size: 0x4, Type: FloatProperty)
    float TotalActivationSequenceTime; // 0x2e4 (Size: 0x4, Type: FloatProperty)

protected:
    void OnBeginOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b18e50 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(ADelMarInputModifierHazard) == 0x2e8, "Size mismatch for ADelMarInputModifierHazard");
static_assert(offsetof(ADelMarInputModifierHazard, ActivatedInputSequence) == 0x2a8, "Offset mismatch for ADelMarInputModifierHazard::ActivatedInputSequence");
static_assert(offsetof(ADelMarInputModifierHazard, DisabledEffects) == 0x2b8, "Offset mismatch for ADelMarInputModifierHazard::DisabledEffects");
static_assert(offsetof(ADelMarInputModifierHazard, BoxCollider) == 0x2c8, "Offset mismatch for ADelMarInputModifierHazard::BoxCollider");
static_assert(offsetof(ADelMarInputModifierHazard, LocalController) == 0x2d0, "Offset mismatch for ADelMarInputModifierHazard::LocalController");
static_assert(offsetof(ADelMarInputModifierHazard, LocalPlayerInput) == 0x2d8, "Offset mismatch for ADelMarInputModifierHazard::LocalPlayerInput");
static_assert(offsetof(ADelMarInputModifierHazard, StartOverlapTime) == 0x2e0, "Offset mismatch for ADelMarInputModifierHazard::StartOverlapTime");
static_assert(offsetof(ADelMarInputModifierHazard, TotalActivationSequenceTime) == 0x2e4, "Offset mismatch for ADelMarInputModifierHazard::TotalActivationSequenceTime");

// Size: 0xb0 (Inherited: 0x88, Single: 0x28)
class UDelMarLevelDataAsset : public UPrimaryDataAsset
{
public:
    FText DisplayName; // 0x30 (Size: 0x10, Type: TextProperty)
    FText LevelDescription; // 0x40 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> LevelBackgroundImage; // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TArray<TSoftObjectPtr<UWorld*>> Levels; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UDataLayerAsset*>> WorldPartitionDataLayers; // 0x80 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer LevelDescriptionTags; // 0x90 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UDelMarLevelDataAsset) == 0xb0, "Size mismatch for UDelMarLevelDataAsset");
static_assert(offsetof(UDelMarLevelDataAsset, DisplayName) == 0x30, "Offset mismatch for UDelMarLevelDataAsset::DisplayName");
static_assert(offsetof(UDelMarLevelDataAsset, LevelDescription) == 0x40, "Offset mismatch for UDelMarLevelDataAsset::LevelDescription");
static_assert(offsetof(UDelMarLevelDataAsset, LevelBackgroundImage) == 0x50, "Offset mismatch for UDelMarLevelDataAsset::LevelBackgroundImage");
static_assert(offsetof(UDelMarLevelDataAsset, Levels) == 0x70, "Offset mismatch for UDelMarLevelDataAsset::Levels");
static_assert(offsetof(UDelMarLevelDataAsset, WorldPartitionDataLayers) == 0x80, "Offset mismatch for UDelMarLevelDataAsset::WorldPartitionDataLayers");
static_assert(offsetof(UDelMarLevelDataAsset, LevelDescriptionTags) == 0x90, "Offset mismatch for UDelMarLevelDataAsset::LevelDescriptionTags");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UDelMarLoadoutSave : public USaveGame
{
public:
    TMap<TSoftObjectPtr<UDelMarCosmeticItemDefinition*>, FGameplayTag> EquippedLoadout; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarLoadoutSave) == 0x78, "Size mismatch for UDelMarLoadoutSave");
static_assert(offsetof(UDelMarLoadoutSave, EquippedLoadout) == 0x28, "Offset mismatch for UDelMarLoadoutSave::EquippedLoadout");

// Size: 0x120 (Inherited: 0x250, Single: 0xfffffed0)
class UDelMarMatchEventSystemComponent : public UDelMarRaceManagerComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    TSet<FGameplayTag> EnabledMatchEventTags; // 0xd0 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(UDelMarMatchEventSystemComponent) == 0x120, "Size mismatch for UDelMarMatchEventSystemComponent");
static_assert(offsetof(UDelMarMatchEventSystemComponent, EnabledMatchEventTags) == 0xd0, "Offset mismatch for UDelMarMatchEventSystemComponent::EnabledMatchEventTags");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UDelMarNetModelSubsystem : public UWorldSubsystem
{
public:
};

static_assert(sizeof(UDelMarNetModelSubsystem) == 0x38, "Size mismatch for UDelMarNetModelSubsystem");

// Size: 0x3c0 (Inherited: 0xf28, Single: 0xfffff498)
class ADelMarNetworkPredictionMutator : public ADelMarMutator
{
public:
};

static_assert(sizeof(ADelMarNetworkPredictionMutator) == 0x3c0, "Size mismatch for ADelMarNetworkPredictionMutator");

// Size: 0x368 (Inherited: 0xbc0, Single: 0xfffff7a8)
class ADelMarMutator : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(ADelMarMutator) == 0x368, "Size mismatch for ADelMarMutator");

// Size: 0x98 (Inherited: 0x190, Single: 0xffffff08)
class UDelMarObjectiveProcessorBase : public UFortObjectiveProcessor
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessorBase) == 0x98, "Size mismatch for UDelMarObjectiveProcessorBase");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_BeatPlayers : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_BeatPlayers) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_BeatPlayers");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_BonusTurboActivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_BonusTurboActivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_BonusTurboActivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_BoostPadBonusSpeedEnded : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_BoostPadBonusSpeedEnded) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_BoostPadBonusSpeedEnded");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_BoostPadHit : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_BoostPadHit) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_BoostPadHit");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_Demolished : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_Demolished) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_Demolished");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_DistanceTraveled : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_DistanceTraveled) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_DistanceTraveled");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_DraftActivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_DraftActivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_DraftActivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_DriftBoostActivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_DriftBoostActivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_DriftBoostActivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_DriftBoostDeactivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_DriftBoostDeactivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_DriftBoostDeactivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_DriftComplete : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_DriftComplete) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_DriftComplete");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_HighestSpeedUpdated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_HighestSpeedUpdated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_HighestSpeedUpdated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_InitialTurboActivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_InitialTurboActivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_InitialTurboActivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_JellyHit : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_JellyHit) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_JellyHit");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_Kickflipped : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_Kickflipped) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_Kickflipped");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_LapComplete : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_LapComplete) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_LapComplete");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_LapStarted : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_LapStarted) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_LapStarted");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_PlacementUpdated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_PlacementUpdated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_PlacementUpdated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_PlayedDelMarExperience : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_PlayedDelMarExperience) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_PlayedDelMarExperience");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_RaceFinished : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_RaceFinished) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_RaceFinished");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_RankAchieved : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_RankAchieved) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_RankAchieved");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_RunComplete : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_RunComplete) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_RunComplete");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_StartlineBoostActivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_StartlineBoostActivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_StartlineBoostActivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_StartlineBoostPercentEarned : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_StartlineBoostPercentEarned) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_StartlineBoostPercentEarned");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_UnderthrustDeactivated : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_UnderthrustDeactivated) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_UnderthrustDeactivated");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_UnderthrustPercentUsed : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_UnderthrustPercentUsed) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_UnderthrustPercentUsed");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_VehicleJumped : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_VehicleJumped) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_VehicleJumped");

// Size: 0x98 (Inherited: 0x228, Single: 0xfffffe70)
class UDelMarObjectiveProcessor_VehicleLanded : public UDelMarObjectiveProcessorBase
{
public:
};

static_assert(sizeof(UDelMarObjectiveProcessor_VehicleLanded) == 0x98, "Size mismatch for UDelMarObjectiveProcessor_VehicleLanded");

// Size: 0xf0 (Inherited: 0x308, Single: 0xfffffde8)
class UDelMarPedestrianComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPreRaceControllerComponent*> PreRaceControllerComponent; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    bool bAllowExitVehicle; // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bPlayerIsPedestrian; // 0xe1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e2[0xe]; // 0xe2 (Size: 0xe, Type: PaddingProperty)

protected:
    void HandleEnterVehicle(); // 0x11b1a8b4 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleExitVehicle(); // 0x11b1a8c8 (Index: 0x1, Flags: Final|Native|Protected)
    void OnRep_bPlayerIsPedestrian(); // 0x11b1a8dc (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPedestrianComponent) == 0xf0, "Size mismatch for UDelMarPedestrianComponent");
static_assert(offsetof(UDelMarPedestrianComponent, CachedDelMarVehicle) == 0xd0, "Offset mismatch for UDelMarPedestrianComponent::CachedDelMarVehicle");
static_assert(offsetof(UDelMarPedestrianComponent, PreRaceControllerComponent) == 0xd8, "Offset mismatch for UDelMarPedestrianComponent::PreRaceControllerComponent");
static_assert(offsetof(UDelMarPedestrianComponent, bAllowExitVehicle) == 0xe0, "Offset mismatch for UDelMarPedestrianComponent::bAllowExitVehicle");
static_assert(offsetof(UDelMarPedestrianComponent, bPlayerIsPedestrian) == 0xe1, "Offset mismatch for UDelMarPedestrianComponent::bPlayerIsPedestrian");

// Size: 0xc60 (Inherited: 0x45b0, Single: 0xffffc6b0)
class ADelMarPhysicsRateDevice : public AFortCreativeDeviceProp
{
public:

public:
    void SetPhysicsRate(EDelMarPhysicsRate& PhysicsRate); // 0x11b1d470 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADelMarPhysicsRateDevice) == 0xc60, "Size mismatch for ADelMarPhysicsRateDevice");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarPhysMatAttribute_SoundTag : public UDelMarPhysMatAttribute
{
public:
    FName SoundTag; // 0x28 (Size: 0x4, Type: NameProperty)
    int32_t Priority; // 0x2c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UDelMarPhysMatAttribute_SoundTag) == 0x30, "Size mismatch for UDelMarPhysMatAttribute_SoundTag");
static_assert(offsetof(UDelMarPhysMatAttribute_SoundTag, SoundTag) == 0x28, "Offset mismatch for UDelMarPhysMatAttribute_SoundTag::SoundTag");
static_assert(offsetof(UDelMarPhysMatAttribute_SoundTag, Priority) == 0x2c, "Offset mismatch for UDelMarPhysMatAttribute_SoundTag::Priority");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UDelMarPhysMatAttribute_Terrain : public UDelMarPhysMatAttribute
{
public:
    FDelMarTerrainData TerrainData; // 0x28 (Size: 0x18, Type: StructProperty)
    bool bDriveableSurface; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarPhysMatAttribute_Terrain) == 0x48, "Size mismatch for UDelMarPhysMatAttribute_Terrain");
static_assert(offsetof(UDelMarPhysMatAttribute_Terrain, TerrainData) == 0x28, "Offset mismatch for UDelMarPhysMatAttribute_Terrain::TerrainData");
static_assert(offsetof(UDelMarPhysMatAttribute_Terrain, bDriveableSurface) == 0x40, "Offset mismatch for UDelMarPhysMatAttribute_Terrain::bDriveableSurface");

// Size: 0xd8 (Inherited: 0x308, Single: 0xfffffdd0)
class UDelMarPlayerActiveRaceManagerComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    ADelMarRaceManager* ActiveRaceManager; // 0xd0 (Size: 0x8, Type: ObjectProperty)

public:
    ADelMarRaceManager* GetActiveRaceManager() const; // 0xdc2db3c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetActiveRaceManager(ADelMarRaceManager*& RaceManager); // 0x11b1d344 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

protected:
    void OnRep_ActiveRaceManager(ADelMarRaceManager*& PreviousRaceManager); // 0x11b1d218 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerActiveRaceManagerComponent) == 0xd8, "Size mismatch for UDelMarPlayerActiveRaceManagerComponent");
static_assert(offsetof(UDelMarPlayerActiveRaceManagerComponent, ActiveRaceManager) == 0xd0, "Offset mismatch for UDelMarPlayerActiveRaceManagerComponent::ActiveRaceManager");

// Size: 0x1b8 (Inherited: 0x308, Single: 0xfffffeb0)
class UDelMarPlayerAnalyticsComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedPlayerController; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> CachedPlayerRaceData; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRaceInfoComponent*> CachedRaceInfo; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> CachedPositionalTracker; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*> MatchmakeRatingComponent; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    FDelMarAnalyticsPlayerRaceData CurrentRaceData; // 0xf0 (Size: 0x40, Type: StructProperty)
    FDelMarAnalyticsPlayerRaceData CurrentRunData; // 0x130 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_170[0x48]; // 0x170 (Size: 0x48, Type: PaddingProperty)

protected:
    void HandleDraftActivated(); // 0x11b1b6d4 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleDriftBoostDeactivated(); // 0x11b1b6e8 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleDriftKickActivated(float& DriftDirection, EDelMarVehicleDriftState& DriftState); // 0x11b1b700 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleKickflipActivated(bool& bLeft); // 0x11b1bd28 (Index: 0x3, Flags: Final|Native|Protected)
    void HandlePlayerResetRun(AFortPlayerState*& PlayerState); // 0x11b1c3c0 (Index: 0x4, Flags: Final|Native|Protected)
    void HandlePotentialDriftBoostChanged(float& Percent); // 0x11b1c4f8 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleRaceFinished(); // 0x11b1c624 (Index: 0x6, Flags: Final|Native|Protected)
    void HandleRaceStarted(); // 0x11b1c64c (Index: 0x7, Flags: Final|Native|Protected)
    void HandleTurboBonusZoneChanged(EDelMarTurboZoneState& BonusZoneState); // 0x11b1c6a4 (Index: 0x8, Flags: Final|Native|Protected)
    void HandleTurboChargeUsed(); // 0x11b1c7e4 (Index: 0x9, Flags: Final|Native|Protected)
    void HandleUnderthrustActivated(); // 0x11b1c7f8 (Index: 0xa, Flags: Final|Native|Protected)
    void HandleUnderthrustDeactivated(); // 0x11b1c80c (Index: 0xb, Flags: Final|Native|Protected)
    void HandleUnderthrustPercentChanged(float& PercentageUnderthrustRemaining); // 0x11b1c820 (Index: 0xc, Flags: Final|Native|Protected)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11b1c94c (Index: 0xd, Flags: Final|Native|Protected)
    void HandleVehicleHitHazard(); // 0x11b1cb8c (Index: 0xe, Flags: Final|Native|Protected)
    void HandleWorldBonusSpeedStackGained(FGameplayTag& Source, int32_t& Stacks); // 0x11b1ced8 (Index: 0xf, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerAnalyticsComponent) == 0x1b8, "Size mismatch for UDelMarPlayerAnalyticsComponent");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CachedRaceManager) == 0xb8, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CachedRaceManager");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CachedPlayerController) == 0xc0, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CachedPlayerController");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CachedVehicle) == 0xc8, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CachedVehicle");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CachedPlayerRaceData) == 0xd0, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CachedPlayerRaceData");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CachedRaceInfo) == 0xd8, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CachedRaceInfo");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CachedPositionalTracker) == 0xe0, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CachedPositionalTracker");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, MatchmakeRatingComponent) == 0xe8, "Offset mismatch for UDelMarPlayerAnalyticsComponent::MatchmakeRatingComponent");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CurrentRaceData) == 0xf0, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CurrentRaceData");
static_assert(offsetof(UDelMarPlayerAnalyticsComponent, CurrentRunData) == 0x130, "Offset mismatch for UDelMarPlayerAnalyticsComponent::CurrentRunData");

// Size: 0x278 (Inherited: 0x580, Single: 0xfffffcf8)
class UDelMarPlayerChallengeRaceDataComponent : public UDelMarPlayerRaceDataComponent
{
public:
};

static_assert(sizeof(UDelMarPlayerChallengeRaceDataComponent) == 0x278, "Size mismatch for UDelMarPlayerChallengeRaceDataComponent");

// Size: 0x108 (Inherited: 0x308, Single: 0xfffffe00)
class UDelMarPlayerQuestDistanceTraveledComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedPlayerState; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    FTimerHandle DistanceTraveledTimer; // 0xd0 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_d8[0x28]; // 0xd8 (Size: 0x28, Type: PaddingProperty)
    TWeakObjectPtr<UDelMarObjectiveProcessor_DistanceTraveled*> DistanceTravelledObjectiveProcessor; // 0x100 (Size: 0x8, Type: WeakObjectProperty)

protected:
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11b1ca0c (Index: 0x0, Flags: Final|Native|Protected)
    void HandleVehicleTeleportExited(); // 0x11b1cbb8 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerQuestDistanceTraveledComponent) == 0x108, "Size mismatch for UDelMarPlayerQuestDistanceTraveledComponent");
static_assert(offsetof(UDelMarPlayerQuestDistanceTraveledComponent, CachedVehicle) == 0xb8, "Offset mismatch for UDelMarPlayerQuestDistanceTraveledComponent::CachedVehicle");
static_assert(offsetof(UDelMarPlayerQuestDistanceTraveledComponent, CachedPlayerState) == 0xc0, "Offset mismatch for UDelMarPlayerQuestDistanceTraveledComponent::CachedPlayerState");
static_assert(offsetof(UDelMarPlayerQuestDistanceTraveledComponent, CachedRaceManager) == 0xc8, "Offset mismatch for UDelMarPlayerQuestDistanceTraveledComponent::CachedRaceManager");
static_assert(offsetof(UDelMarPlayerQuestDistanceTraveledComponent, DistanceTraveledTimer) == 0xd0, "Offset mismatch for UDelMarPlayerQuestDistanceTraveledComponent::DistanceTraveledTimer");
static_assert(offsetof(UDelMarPlayerQuestDistanceTraveledComponent, DistanceTravelledObjectiveProcessor) == 0x100, "Offset mismatch for UDelMarPlayerQuestDistanceTraveledComponent::DistanceTravelledObjectiveProcessor");

// Size: 0xd8 (Inherited: 0x308, Single: 0xfffffdd0)
class UDelMarPlayerQuestMatchInfoComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t Pad_b8[0x4]; // 0xb8 (Size: 0x4, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedPlayerState; // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)

protected:
    void HandleRaceStarted(); // 0x11b1c660 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11b1cacc (Index: 0x1, Flags: Final|Native|Protected)
    void HandleVehicleHitHazard(); // 0x11b1cba0 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerQuestMatchInfoComponent) == 0xd8, "Size mismatch for UDelMarPlayerQuestMatchInfoComponent");
static_assert(offsetof(UDelMarPlayerQuestMatchInfoComponent, CachedVehicle) == 0xbc, "Offset mismatch for UDelMarPlayerQuestMatchInfoComponent::CachedVehicle");
static_assert(offsetof(UDelMarPlayerQuestMatchInfoComponent, CachedRaceManager) == 0xc4, "Offset mismatch for UDelMarPlayerQuestMatchInfoComponent::CachedRaceManager");
static_assert(offsetof(UDelMarPlayerQuestMatchInfoComponent, CachedPlayerState) == 0xcc, "Offset mismatch for UDelMarPlayerQuestMatchInfoComponent::CachedPlayerState");

// Size: 0x140 (Inherited: 0x308, Single: 0xfffffe38)
class UDelMarPlayerWrongwayComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> CachedTrackPositionComp; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> CachedRaceData; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackManager*> CachedTrackManager; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_e8[0x58]; // 0xe8 (Size: 0x58, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarPlayerWrongwayComponent) == 0x140, "Size mismatch for UDelMarPlayerWrongwayComponent");
static_assert(offsetof(UDelMarPlayerWrongwayComponent, CachedDelMarVehicle) == 0xb8, "Offset mismatch for UDelMarPlayerWrongwayComponent::CachedDelMarVehicle");
static_assert(offsetof(UDelMarPlayerWrongwayComponent, CachedRaceManager) == 0xc0, "Offset mismatch for UDelMarPlayerWrongwayComponent::CachedRaceManager");
static_assert(offsetof(UDelMarPlayerWrongwayComponent, CachedTrackPositionComp) == 0xc8, "Offset mismatch for UDelMarPlayerWrongwayComponent::CachedTrackPositionComp");
static_assert(offsetof(UDelMarPlayerWrongwayComponent, CachedRaceData) == 0xd0, "Offset mismatch for UDelMarPlayerWrongwayComponent::CachedRaceData");
static_assert(offsetof(UDelMarPlayerWrongwayComponent, CachedCheckpointManager) == 0xd8, "Offset mismatch for UDelMarPlayerWrongwayComponent::CachedCheckpointManager");
static_assert(offsetof(UDelMarPlayerWrongwayComponent, CachedTrackManager) == 0xe0, "Offset mismatch for UDelMarPlayerWrongwayComponent::CachedTrackManager");

// Size: 0x210 (Inherited: 0x570, Single: 0xfffffca0)
class UDelMarPlayspaceComponent_ServerExpiration : public UPlayspaceComponent_ServerExpiration
{
public:
};

static_assert(sizeof(UDelMarPlayspaceComponent_ServerExpiration) == 0x210, "Size mismatch for UDelMarPlayspaceComponent_ServerExpiration");

// Size: 0x120 (Inherited: 0x308, Single: 0xfffffe18)
class UDelMarProxyGhostVisualComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<AFortAthenaVehicle*> CachedVehicle; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UVehicleCosmeticsAssembledMeshUserComponent*> CachedVCAMUC; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    UMaterialInterface* ProxyGhostMaterial; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TMap<FDelMarProxyMeshMaterialInfo, FGameplayTag> VehicleMaterialInfoMap; // 0xd0 (Size: 0x50, Type: MapProperty)

protected:
    void HandleFinishVehicleCosmeticsEvent(const FVehicleCosmeticsFinishedPayload Payload); // 0x11b1bc6c (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandlePartCustomizationUpdated(int32_t& const MeshPartIndex); // 0x11b1be54 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11b1cbcc (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarProxyGhostVisualComponent) == 0x120, "Size mismatch for UDelMarProxyGhostVisualComponent");
static_assert(offsetof(UDelMarProxyGhostVisualComponent, CachedVehicle) == 0xb8, "Offset mismatch for UDelMarProxyGhostVisualComponent::CachedVehicle");
static_assert(offsetof(UDelMarProxyGhostVisualComponent, CachedVCAMUC) == 0xc0, "Offset mismatch for UDelMarProxyGhostVisualComponent::CachedVCAMUC");
static_assert(offsetof(UDelMarProxyGhostVisualComponent, ProxyGhostMaterial) == 0xc8, "Offset mismatch for UDelMarProxyGhostVisualComponent::ProxyGhostMaterial");
static_assert(offsetof(UDelMarProxyGhostVisualComponent, VehicleMaterialInfoMap) == 0xd0, "Offset mismatch for UDelMarProxyGhostVisualComponent::VehicleMaterialInfoMap");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UDelMarRaceInfoComponent : public UDelMarRaceManagerComponent
{
public:
    FString RaceGUID; // 0xb8 (Size: 0x10, Type: StrProperty)

protected:
    void HandleRaceStarted(); // 0x11b1c67c (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarRaceInfoComponent) == 0xc8, "Size mismatch for UDelMarRaceInfoComponent");
static_assert(offsetof(UDelMarRaceInfoComponent, RaceGUID) == 0xb8, "Offset mismatch for UDelMarRaceInfoComponent::RaceGUID");

// Size: 0xcb0 (Inherited: 0x45b0, Single: 0xffffc700)
class ADelMarRaceLevelConfig : public AFortCreativeDeviceProp
{
public:
    uint8_t RaceMode; // 0xc10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c11[0x3]; // 0xc11 (Size: 0x3, Type: PaddingProperty)
    int32_t DefaultNumRequiredLaps; // 0xc14 (Size: 0x4, Type: IntProperty)
    int32_t NumVisibleNextCheckpoints; // 0xc18 (Size: 0x4, Type: IntProperty)
    float ZKillOffsetDistanceFromLowestSplinePoint; // 0xc1c (Size: 0x4, Type: FloatProperty)
    bool bShouldRunAsADelMarExperience; // 0xc20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c21[0x3]; // 0xc21 (Size: 0x3, Type: PaddingProperty)
    int32_t OvertimeSeconds; // 0xc24 (Size: 0x4, Type: IntProperty)
    bool bOverrideTurboChargeRegenRateSeconds; // 0xc28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c29[0x3]; // 0xc29 (Size: 0x3, Type: PaddingProperty)
    float TurboChargeRegenRateSeconds; // 0xc2c (Size: 0x4, Type: FloatProperty)
    bool bOverrideTurboRaceStartCharges; // 0xc30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c31[0x3]; // 0xc31 (Size: 0x3, Type: PaddingProperty)
    float TurboRaceStartCharges; // 0xc34 (Size: 0x4, Type: FloatProperty)
    bool bOverrideTurboLapCompleteCharges; // 0xc38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c39[0x3]; // 0xc39 (Size: 0x3, Type: PaddingProperty)
    float TurboLapCompleteCharges; // 0xc3c (Size: 0x4, Type: FloatProperty)
    bool bNonTrackVelocityRedirectEnabled; // 0xc40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c41[0x3]; // 0xc41 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag LevelTag; // 0xc44 (Size: 0x4, Type: StructProperty)
    bool bHasMatchTimeLimit; // 0xc48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c49[0x3]; // 0xc49 (Size: 0x3, Type: PaddingProperty)
    int32_t MatchTimeLimitSeconds; // 0xc4c (Size: 0x4, Type: IntProperty)
    TMap<UClass*, EDelMarRaceMode> RaceManagerClassMap; // 0xc50 (Size: 0x50, Type: MapProperty)
    TArray<FDelMarRaceCVar> RaceCVars; // 0xca0 (Size: 0x10, Type: ArrayProperty)

public:
    UClass* GetRaceManagerClass() const; // 0x11b1b660 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetRaceModeTag() const; // 0x11b1b694 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarRaceManager* SpawnRaceManager(bool& bFireInitializationEvent); // 0x11b1d59c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADelMarRaceLevelConfig) == 0xcb0, "Size mismatch for ADelMarRaceLevelConfig");
static_assert(offsetof(ADelMarRaceLevelConfig, RaceMode) == 0xc10, "Offset mismatch for ADelMarRaceLevelConfig::RaceMode");
static_assert(offsetof(ADelMarRaceLevelConfig, DefaultNumRequiredLaps) == 0xc14, "Offset mismatch for ADelMarRaceLevelConfig::DefaultNumRequiredLaps");
static_assert(offsetof(ADelMarRaceLevelConfig, NumVisibleNextCheckpoints) == 0xc18, "Offset mismatch for ADelMarRaceLevelConfig::NumVisibleNextCheckpoints");
static_assert(offsetof(ADelMarRaceLevelConfig, ZKillOffsetDistanceFromLowestSplinePoint) == 0xc1c, "Offset mismatch for ADelMarRaceLevelConfig::ZKillOffsetDistanceFromLowestSplinePoint");
static_assert(offsetof(ADelMarRaceLevelConfig, bShouldRunAsADelMarExperience) == 0xc20, "Offset mismatch for ADelMarRaceLevelConfig::bShouldRunAsADelMarExperience");
static_assert(offsetof(ADelMarRaceLevelConfig, OvertimeSeconds) == 0xc24, "Offset mismatch for ADelMarRaceLevelConfig::OvertimeSeconds");
static_assert(offsetof(ADelMarRaceLevelConfig, bOverrideTurboChargeRegenRateSeconds) == 0xc28, "Offset mismatch for ADelMarRaceLevelConfig::bOverrideTurboChargeRegenRateSeconds");
static_assert(offsetof(ADelMarRaceLevelConfig, TurboChargeRegenRateSeconds) == 0xc2c, "Offset mismatch for ADelMarRaceLevelConfig::TurboChargeRegenRateSeconds");
static_assert(offsetof(ADelMarRaceLevelConfig, bOverrideTurboRaceStartCharges) == 0xc30, "Offset mismatch for ADelMarRaceLevelConfig::bOverrideTurboRaceStartCharges");
static_assert(offsetof(ADelMarRaceLevelConfig, TurboRaceStartCharges) == 0xc34, "Offset mismatch for ADelMarRaceLevelConfig::TurboRaceStartCharges");
static_assert(offsetof(ADelMarRaceLevelConfig, bOverrideTurboLapCompleteCharges) == 0xc38, "Offset mismatch for ADelMarRaceLevelConfig::bOverrideTurboLapCompleteCharges");
static_assert(offsetof(ADelMarRaceLevelConfig, TurboLapCompleteCharges) == 0xc3c, "Offset mismatch for ADelMarRaceLevelConfig::TurboLapCompleteCharges");
static_assert(offsetof(ADelMarRaceLevelConfig, bNonTrackVelocityRedirectEnabled) == 0xc40, "Offset mismatch for ADelMarRaceLevelConfig::bNonTrackVelocityRedirectEnabled");
static_assert(offsetof(ADelMarRaceLevelConfig, LevelTag) == 0xc44, "Offset mismatch for ADelMarRaceLevelConfig::LevelTag");
static_assert(offsetof(ADelMarRaceLevelConfig, bHasMatchTimeLimit) == 0xc48, "Offset mismatch for ADelMarRaceLevelConfig::bHasMatchTimeLimit");
static_assert(offsetof(ADelMarRaceLevelConfig, MatchTimeLimitSeconds) == 0xc4c, "Offset mismatch for ADelMarRaceLevelConfig::MatchTimeLimitSeconds");
static_assert(offsetof(ADelMarRaceLevelConfig, RaceManagerClassMap) == 0xc50, "Offset mismatch for ADelMarRaceLevelConfig::RaceManagerClassMap");
static_assert(offsetof(ADelMarRaceLevelConfig, RaceCVars) == 0xca0, "Offset mismatch for ADelMarRaceLevelConfig::RaceCVars");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UDelMarRaceManagerVerbComponent : public UDelMarRaceManagerComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTracker; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<AFortPlayerState*> PrevRacePositions; // 0xc8 (Size: 0x10, Type: ArrayProperty)

protected:
    void HandleCountdownStarted(); // 0x11b1b6c0 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleFinalRacePositionsChanged(const TArray<FDelMarFinalRacePositionEntry> FinalRacePositions, const FDelMarEvent_RunRecorded RecordedRun); // 0x11b1b914 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void HandlePlayerLapCompleted(const FDelMarEvent_LapComplete LapCompleteEvent); // 0x11b1bf7c (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    void HandlePlayerLapStarted(const FDelMarEvent_LapStarted LapStartedEvent); // 0x11b1c064 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms)
    void HandlePlayerPositionsChanged(const TArray<AFortPlayerState*> RacePositions); // 0x11b1c134 (Index: 0x4, Flags: Final|Native|Protected|HasOutParms)
    void HandleRaceFinished(); // 0x11b1c638 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleRaceStarted(); // 0x11b1c690 (Index: 0x6, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarRaceManagerVerbComponent) == 0xd8, "Size mismatch for UDelMarRaceManagerVerbComponent");
static_assert(offsetof(UDelMarRaceManagerVerbComponent, CachedRaceManager) == 0xb8, "Offset mismatch for UDelMarRaceManagerVerbComponent::CachedRaceManager");
static_assert(offsetof(UDelMarRaceManagerVerbComponent, PositionalTracker) == 0xc0, "Offset mismatch for UDelMarRaceManagerVerbComponent::PositionalTracker");
static_assert(offsetof(UDelMarRaceManagerVerbComponent, PrevRacePositions) == 0xc8, "Offset mismatch for UDelMarRaceManagerVerbComponent::PrevRacePositions");

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UDelMarRaceMusicPlaylist : public UPrimaryDataAsset
{
public:
    TArray<FDelMarMusicTrack> Tracks; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarRaceMusicPlaylist) == 0x40, "Size mismatch for UDelMarRaceMusicPlaylist");
static_assert(offsetof(UDelMarRaceMusicPlaylist, Tracks) == 0x30, "Offset mismatch for UDelMarRaceMusicPlaylist::Tracks");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UDelMarRaceMusicPlaylistComponent : public UActorComponent
{
public:

protected:
    void SetMusicPlaylist(UDelMarRaceMusicPlaylist*& SetPlaylist, bool& bEnableMusic); // 0xf4547ac (Index: 0x0, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarRaceMusicPlaylistComponent) == 0xb8, "Size mismatch for UDelMarRaceMusicPlaylistComponent");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UDelMarRacerState_Spectator : public UDelMarRacerState
{
public:
};

static_assert(sizeof(UDelMarRacerState_Spectator) == 0x30, "Size mismatch for UDelMarRacerState_Spectator");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UDelMarRacerState_Countdown : public UDelMarRacerState
{
public:
    TWeakObjectPtr<ADelMarVehicle*> Vehicle; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarRacerState_Countdown) == 0x38, "Size mismatch for UDelMarRacerState_Countdown");
static_assert(offsetof(UDelMarRacerState_Countdown, Vehicle) == 0x30, "Offset mismatch for UDelMarRacerState_Countdown::Vehicle");

// Size: 0x38 (Inherited: 0xb8, Single: 0xffffff80)
class UDelMarRacerState_RunFinished : public UDelMarRacerState_WithSpectatorTransitionBase
{
public:
    TWeakObjectPtr<ADelMarVehicle*> Vehicle; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarRacerState_RunFinished) == 0x38, "Size mismatch for UDelMarRacerState_RunFinished");
static_assert(offsetof(UDelMarRacerState_RunFinished, Vehicle) == 0x30, "Offset mismatch for UDelMarRacerState_RunFinished::Vehicle");

// Size: 0xd08 (Inherited: 0x45b0, Single: 0xffffc758)
class ADelMarSpeedUpDevice : public AFortCreativeDeviceProp
{
public:
    float SpeedAmount; // 0xc10 (Size: 0x4, Type: FloatProperty)
    float SpeedEffectDuration; // 0xc14 (Size: 0x4, Type: FloatProperty)
    float TurboChargesGained; // 0xc18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c1c[0x1c]; // 0xc1c (Size: 0x1c, Type: PaddingProperty)
    float MinDotProductAngleValue; // 0xc38 (Size: 0x4, Type: FloatProperty)
    FGameplayTag SpeedSourceTag; // 0xc3c (Size: 0x4, Type: StructProperty)
    bool bApplyForce; // 0xc40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c41[0x3]; // 0xc41 (Size: 0x3, Type: PaddingProperty)
    int32_t GroupId; // 0xc44 (Size: 0x4, Type: IntProperty)
    FDelMarScaledCurve PowerIntensityScalarCurve; // 0xc48 (Size: 0x90, Type: StructProperty)
    float MaxLifetimePowerIntensitySeconds; // 0xcd8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cdc[0x4]; // 0xcdc (Size: 0x4, Type: PaddingProperty)
    UStaticMeshComponent* Collider; // 0xce0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_ce8[0x20]; // 0xce8 (Size: 0x20, Type: PaddingProperty)

protected:
    virtual void BP_HandleSpeedEffectGranted(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    void OnBeginOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b20608 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    virtual bool ShouldGrantSpeedEffect(AActor*& OtherActor); // 0x10d1f574 (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ADelMarSpeedUpDevice) == 0xd08, "Size mismatch for ADelMarSpeedUpDevice");
static_assert(offsetof(ADelMarSpeedUpDevice, SpeedAmount) == 0xc10, "Offset mismatch for ADelMarSpeedUpDevice::SpeedAmount");
static_assert(offsetof(ADelMarSpeedUpDevice, SpeedEffectDuration) == 0xc14, "Offset mismatch for ADelMarSpeedUpDevice::SpeedEffectDuration");
static_assert(offsetof(ADelMarSpeedUpDevice, TurboChargesGained) == 0xc18, "Offset mismatch for ADelMarSpeedUpDevice::TurboChargesGained");
static_assert(offsetof(ADelMarSpeedUpDevice, MinDotProductAngleValue) == 0xc38, "Offset mismatch for ADelMarSpeedUpDevice::MinDotProductAngleValue");
static_assert(offsetof(ADelMarSpeedUpDevice, SpeedSourceTag) == 0xc3c, "Offset mismatch for ADelMarSpeedUpDevice::SpeedSourceTag");
static_assert(offsetof(ADelMarSpeedUpDevice, bApplyForce) == 0xc40, "Offset mismatch for ADelMarSpeedUpDevice::bApplyForce");
static_assert(offsetof(ADelMarSpeedUpDevice, GroupId) == 0xc44, "Offset mismatch for ADelMarSpeedUpDevice::GroupId");
static_assert(offsetof(ADelMarSpeedUpDevice, PowerIntensityScalarCurve) == 0xc48, "Offset mismatch for ADelMarSpeedUpDevice::PowerIntensityScalarCurve");
static_assert(offsetof(ADelMarSpeedUpDevice, MaxLifetimePowerIntensitySeconds) == 0xcd8, "Offset mismatch for ADelMarSpeedUpDevice::MaxLifetimePowerIntensitySeconds");
static_assert(offsetof(ADelMarSpeedUpDevice, Collider) == 0xce0, "Offset mismatch for ADelMarSpeedUpDevice::Collider");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UDelMarSplineActorMovementComponent : public UActorComponent
{
public:
    TWeakObjectPtr<USplineComponent*> MovementSpline; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    float MovementSpeed; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarSplineActorMovementComponent) == 0xc8, "Size mismatch for UDelMarSplineActorMovementComponent");
static_assert(offsetof(UDelMarSplineActorMovementComponent, MovementSpline) == 0xb8, "Offset mismatch for UDelMarSplineActorMovementComponent::MovementSpline");
static_assert(offsetof(UDelMarSplineActorMovementComponent, MovementSpeed) == 0xc0, "Offset mismatch for UDelMarSplineActorMovementComponent::MovementSpeed");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ADelMarStartLineActor : public AActor
{
public:
    ADelMarCheckpoint* Checkpoint; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ADelMarStartLineActor) == 0x2b0, "Size mismatch for ADelMarStartLineActor");
static_assert(offsetof(ADelMarStartLineActor, Checkpoint) == 0x2a8, "Offset mismatch for ADelMarStartLineActor::Checkpoint");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UDelMarTutorialConfigComponent : public UActorComponent
{
public:
    TArray<FDelMarTutorialSection> Sections; // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarTutorialConfigComponent) == 0xc8, "Size mismatch for UDelMarTutorialConfigComponent");
static_assert(offsetof(UDelMarTutorialConfigComponent, Sections) == 0xb8, "Offset mismatch for UDelMarTutorialConfigComponent::Sections");

// Size: 0x308 (Inherited: 0x2d0, Single: 0x38)
class ADelMarTutorialInteractableSpline : public AActor
{
public:
    bool bMustTriggerInOrder; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
    FVector ChildActorScaleMultiplier; // 0x2b0 (Size: 0x18, Type: StructProperty)
    uint8_t SplineGenerationMode; // 0x2c8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2c9[0x3]; // 0x2c9 (Size: 0x3, Type: PaddingProperty)
    int32_t ChildActorCount; // 0x2cc (Size: 0x4, Type: IntProperty)
    bool bUseSplineRotationForActors; // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bShowDebugNumbers; // 0x2d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d2[0x2]; // 0x2d2 (Size: 0x2, Type: PaddingProperty)
    float DebugTextZOffset; // 0x2d4 (Size: 0x4, Type: FloatProperty)
    float DebugTextSize; // 0x2d8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
    UMaterial* DebugTextMaterial; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    USplineComponent* SplineComponent; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UClass* ChildActorClass; // 0x2f0 (Size: 0x8, Type: ClassProperty)
    TArray<UChildActorComponent*> ChildActorComponents; // 0x2f8 (Size: 0x10, Type: ArrayProperty)

public:
    bool GetHaveAllTriggersCompleted() const; // 0x11b1f81c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTriggerIndex(ADelMarTutorialTriggerActor*& InTrigger) const; // 0x11b1f8b8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTriggerIndexAsRatio(ADelMarTutorialTriggerActor*& InTrigger) const; // 0x11b1fa24 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ResetTriggers(); // 0x11b21348 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void BP_HandleAllSplineTriggersCompleted(AActor*& FinalCompletedTrigger); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    void HandleColliderOverlap(ADelMarTutorialTriggerActor*& InTrigger); // 0x11b1fbd0 (Index: 0x4, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarTutorialInteractableSpline) == 0x308, "Size mismatch for ADelMarTutorialInteractableSpline");
static_assert(offsetof(ADelMarTutorialInteractableSpline, bMustTriggerInOrder) == 0x2a8, "Offset mismatch for ADelMarTutorialInteractableSpline::bMustTriggerInOrder");
static_assert(offsetof(ADelMarTutorialInteractableSpline, ChildActorScaleMultiplier) == 0x2b0, "Offset mismatch for ADelMarTutorialInteractableSpline::ChildActorScaleMultiplier");
static_assert(offsetof(ADelMarTutorialInteractableSpline, SplineGenerationMode) == 0x2c8, "Offset mismatch for ADelMarTutorialInteractableSpline::SplineGenerationMode");
static_assert(offsetof(ADelMarTutorialInteractableSpline, ChildActorCount) == 0x2cc, "Offset mismatch for ADelMarTutorialInteractableSpline::ChildActorCount");
static_assert(offsetof(ADelMarTutorialInteractableSpline, bUseSplineRotationForActors) == 0x2d0, "Offset mismatch for ADelMarTutorialInteractableSpline::bUseSplineRotationForActors");
static_assert(offsetof(ADelMarTutorialInteractableSpline, bShowDebugNumbers) == 0x2d1, "Offset mismatch for ADelMarTutorialInteractableSpline::bShowDebugNumbers");
static_assert(offsetof(ADelMarTutorialInteractableSpline, DebugTextZOffset) == 0x2d4, "Offset mismatch for ADelMarTutorialInteractableSpline::DebugTextZOffset");
static_assert(offsetof(ADelMarTutorialInteractableSpline, DebugTextSize) == 0x2d8, "Offset mismatch for ADelMarTutorialInteractableSpline::DebugTextSize");
static_assert(offsetof(ADelMarTutorialInteractableSpline, DebugTextMaterial) == 0x2e0, "Offset mismatch for ADelMarTutorialInteractableSpline::DebugTextMaterial");
static_assert(offsetof(ADelMarTutorialInteractableSpline, SplineComponent) == 0x2e8, "Offset mismatch for ADelMarTutorialInteractableSpline::SplineComponent");
static_assert(offsetof(ADelMarTutorialInteractableSpline, ChildActorClass) == 0x2f0, "Offset mismatch for ADelMarTutorialInteractableSpline::ChildActorClass");
static_assert(offsetof(ADelMarTutorialInteractableSpline, ChildActorComponents) == 0x2f8, "Offset mismatch for ADelMarTutorialInteractableSpline::ChildActorComponents");

// Size: 0x4f8 (Inherited: 0x7b0, Single: 0xfffffd48)
class ADelMarTutorialRaceManager : public ADelMarRaceManager
{
public:
    FDelMarVehicleAbilityConfig InitialVehicleAbilityConfig; // 0x4e0 (Size: 0x11, Type: StructProperty)
    uint8_t Pad_4f1[0x7]; // 0x4f1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarTutorialRaceManager) == 0x4f8, "Size mismatch for ADelMarTutorialRaceManager");
static_assert(offsetof(ADelMarTutorialRaceManager, InitialVehicleAbilityConfig) == 0x4e0, "Offset mismatch for ADelMarTutorialRaceManager::InitialVehicleAbilityConfig");

// Size: 0x2d0 (Inherited: 0x2d0, Single: 0x0)
class ADelMarTutorialTriggerActor : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    UBoxComponent* BoxCollider; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x18]; // 0x2b8 (Size: 0x18, Type: PaddingProperty)

public:
    void ResetTrigger(); // 0x11b21334 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual bool BP_CanTriggerActor(AActor*& OtherActor); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_HandleColliderReset(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_HandleColliderTriggered(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    bool CanTriggerActor(AActor*& OtherActor); // 0x11b1f68c (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleColliderOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11b1fcfc (Index: 0x4, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(ADelMarTutorialTriggerActor) == 0x2d0, "Size mismatch for ADelMarTutorialTriggerActor");
static_assert(offsetof(ADelMarTutorialTriggerActor, BoxCollider) == 0x2b0, "Offset mismatch for ADelMarTutorialTriggerActor::BoxCollider");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UDelMarVehicleAction : public UObject
{
public:
    uint8_t OnActionPerformed[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarVehicleAction) == 0x40, "Size mismatch for UDelMarVehicleAction");
static_assert(offsetof(UDelMarVehicleAction, OnActionPerformed) == 0x28, "Offset mismatch for UDelMarVehicleAction::OnActionPerformed");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarVehicleAction_Jump : public UDelMarVehicleAction
{
public:

public:
    void HandleJump(); // 0x11b20460 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleAction_Jump) == 0x40, "Size mismatch for UDelMarVehicleAction_Jump");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarVehicleAction_Drift : public UDelMarVehicleAction
{
public:

public:
    void HandleDrift(float& DriftDirection, EDelMarVehicleDriftState& DriftState); // 0x11b2025c (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleAction_Drift) == 0x40, "Size mismatch for UDelMarVehicleAction_Drift");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarVehicleAction_HazardHit : public UDelMarVehicleAction
{
public:

public:
    void HandleHazardHit(); // 0x11b20460 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleAction_HazardHit) == 0x40, "Size mismatch for UDelMarVehicleAction_HazardHit");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarVehicleAction_KickFlip : public UDelMarVehicleAction
{
public:

public:
    void HandleKickflip(bool& bLeftSide); // 0x11b204a0 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleAction_KickFlip) == 0x40, "Size mismatch for UDelMarVehicleAction_KickFlip");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarVehicleAction_Turbo : public UDelMarVehicleAction
{
public:

public:
    void HandleTurbo(); // 0x11b20460 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleAction_Turbo) == 0x40, "Size mismatch for UDelMarVehicleAction_Turbo");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarVehicleAction_Underthrust : public UDelMarVehicleAction
{
public:

public:
    void HandleUnderthrust(); // 0x11b20460 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarVehicleAction_Underthrust) == 0x40, "Size mismatch for UDelMarVehicleAction_Underthrust");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UDelMarVehicleAutoInputComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UDelMarVehicleAutoInputComponent) == 0xd8, "Size mismatch for UDelMarVehicleAutoInputComponent");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UDelMarVehicleBodySetup : public UDataAsset
{
public:
    FDelMarVehicleAxleConfig FrontAxle; // 0x30 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleAxleConfig BackAxle; // 0x58 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UDelMarVehicleBodySetup) == 0x80, "Size mismatch for UDelMarVehicleBodySetup");
static_assert(offsetof(UDelMarVehicleBodySetup, FrontAxle) == 0x30, "Offset mismatch for UDelMarVehicleBodySetup::FrontAxle");
static_assert(offsetof(UDelMarVehicleBodySetup, BackAxle) == 0x58, "Offset mismatch for UDelMarVehicleBodySetup::BackAxle");

// Size: 0xd0 (Inherited: 0x58, Single: 0x78)
class UDelMarVehicleBodySetupMap : public UDataAsset
{
public:
    TMap<UDelMarVehicleBodySetup*, FName> BodySetupNameMap; // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<UDelMarVehicleBodySetup*, FGameplayTag> BodySetupArchetypeMap; // 0x80 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarVehicleBodySetupMap) == 0xd0, "Size mismatch for UDelMarVehicleBodySetupMap");
static_assert(offsetof(UDelMarVehicleBodySetupMap, BodySetupNameMap) == 0x30, "Offset mismatch for UDelMarVehicleBodySetupMap::BodySetupNameMap");
static_assert(offsetof(UDelMarVehicleBodySetupMap, BodySetupArchetypeMap) == 0x80, "Offset mismatch for UDelMarVehicleBodySetupMap::BodySetupArchetypeMap");

// Size: 0x3420 (Inherited: 0x88, Single: 0x3398)
class UDelMarVehicleCameraMode_V2 : public UFortCameraMode
{
public:
    UClass* CameraInputControllerComponentClass; // 0x60 (Size: 0x8, Type: ClassProperty)
    TMap<FDelMarDefaultCameraValues, FGameplayTag> VehicleArchetypeDefaults; // 0x68 (Size: 0x50, Type: MapProperty)
    float DefaultInterpLambda; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float FOV; // 0xbc (Size: 0x4, Type: FloatProperty)
    float TotalFOVInterpLambda; // 0xc0 (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalFOVClamp; // 0xc4 (Size: 0x10, Type: StructProperty)
    float Distance; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float TotalDistanceInterpLambda; // 0xd8 (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalDistanceClamp; // 0xdc (Size: 0x10, Type: StructProperty)
    float Height; // 0xec (Size: 0x4, Type: FloatProperty)
    float TotalHeightInterpLambda; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float HeightOffsetInterpLambda; // 0xf4 (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalHeightClamp; // 0xf8 (Size: 0x10, Type: StructProperty)
    float AngleToOriginDegrees; // 0x108 (Size: 0x4, Type: FloatProperty)
    float AngleToOriginInterpLambda; // 0x10c (Size: 0x4, Type: FloatProperty)
    FFloatRange TotalAngleToOriginClamp; // 0x110 (Size: 0x10, Type: StructProperty)
    float SwivelInterpLambda; // 0x120 (Size: 0x4, Type: FloatProperty)
    float SwivelPitchMax; // 0x124 (Size: 0x4, Type: FloatProperty)
    float SwivelYawMax; // 0x128 (Size: 0x4, Type: FloatProperty)
    float GroundNormalInterpLambda; // 0x12c (Size: 0x4, Type: FloatProperty)
    float ForwardInterpLambda; // 0x130 (Size: 0x4, Type: FloatProperty)
    float CarPitchInterpLambda; // 0x134 (Size: 0x4, Type: FloatProperty)
    float AerialCarPitchInterpLambda; // 0x138 (Size: 0x4, Type: FloatProperty)
    float MaxAerialCarPitch; // 0x13c (Size: 0x4, Type: FloatProperty)
    float PitchRotationAxisInterpLambda; // 0x140 (Size: 0x4, Type: FloatProperty)
    float VerticalDriftDegreeThreshold; // 0x144 (Size: 0x4, Type: FloatProperty)
    float MinDegreesVehicleWorldUpThreshold; // 0x148 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve MaxUpRotationPerSecondCurve; // 0x150 (Size: 0x90, Type: StructProperty)
    float MaxUpRotationPerSecondStatic; // 0x1e0 (Size: 0x4, Type: FloatProperty)
    float WorldUpInterpRate; // 0x1e4 (Size: 0x4, Type: FloatProperty)
    bool bPreventPenetration; // 0x1e8 (Size: 0x1, Type: BoolProperty)
    bool bDoPredictiveAvoidance; // 0x1e9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1ea[0x2]; // 0x1ea (Size: 0x2, Type: PaddingProperty)
    float CollisionPushOutDistance; // 0x1ec (Size: 0x4, Type: FloatProperty)
    float PenetrationBlendOutTime; // 0x1f0 (Size: 0x4, Type: FloatProperty)
    float PenetrationBlendInTime; // 0x1f4 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> PenetrationTraceChannel; // 0x1f8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    TArray<FPenetrationAvoidanceFeeler> PenetrationAvoidanceFeelers; // 0x200 (Size: 0x10, Type: ArrayProperty)
    FDelMarScaledCurve ForwardAirInterpLambdaCurve; // 0x210 (Size: 0x90, Type: StructProperty)
    FRuntimeFloatCurve ForwardAirBlendCurve; // 0x2a0 (Size: 0x88, Type: StructProperty)
    float MinForwardSpeedForAerialBlend; // 0x328 (Size: 0x4, Type: FloatProperty)
    float MinTimeInAirBeforeUsingVehicleUp; // 0x32c (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve GroundNormalAirInterpLambdaCurve; // 0x330 (Size: 0x90, Type: StructProperty)
    float AirFreestyleDeactivationExtendedSeconds; // 0x3c0 (Size: 0x4, Type: FloatProperty)
    float AirFreestyleDeactivationLambdaSeconds; // 0x3c4 (Size: 0x4, Type: FloatProperty)
    float AirFreestyleDeactivationForwardLambda; // 0x3c8 (Size: 0x4, Type: FloatProperty)
    float AirFreestyleDeactivationNormalLambda; // 0x3cc (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve DriftForwardBlendCurve; // 0x3d0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialDriftForwardBlendCurve; // 0x458 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve DriftForwardInterpLambdaCurve; // 0x4e0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve DriftOriginOffsetCurve; // 0x568 (Size: 0x88, Type: StructProperty)
    FDelMarScaledCurve DriftOriginOffsetInterpLambdaCurve; // 0x5f0 (Size: 0x90, Type: StructProperty)
    float DriftOriginOffsetInactiveLambda; // 0x680 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_684[0x4]; // 0x684 (Size: 0x4, Type: PaddingProperty)
    FDelMarCameraFloatBlendedProperty DriftKickOffsetDistance; // 0x688 (Size: 0x1d0, Type: StructProperty)
    float DriftKickOffsetLambda; // 0x858 (Size: 0x4, Type: FloatProperty)
    float DriftKickOffsetInactiveLambda; // 0x85c (Size: 0x4, Type: FloatProperty)
    bool bDeactivateKickOffsetOnKickEnd; // 0x860 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_861[0x7]; // 0x861 (Size: 0x7, Type: PaddingProperty)
    FRuntimeFloatCurve DriftRollDegreesCurve; // 0x868 (Size: 0x88, Type: StructProperty)
    FDelMarScaledCurve DriftRollDegreesInterpLambdaCurve; // 0x8f0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve DriftScalarCurveCurve; // 0x980 (Size: 0x90, Type: StructProperty)
    float GroundMaxPitchForNormalBlend; // 0xa10 (Size: 0x4, Type: FloatProperty)
    float GroundExtraPitchForNormalBlend; // 0xa14 (Size: 0x4, Type: FloatProperty)
    FDelMarCameraFloatProperty StableSpeedDistance; // 0xa18 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty StableSpeedFOV; // 0xac8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty StableSpeedHeight; // 0xb78 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty StableSpeedAngleToOrigin; // 0xc28 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationDistance; // 0xcd8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationFOV; // 0xd88 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationHeight; // 0xe38 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty AccelerationAngleToOrigin; // 0xee8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedDistance; // 0xf98 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedFOV; // 0x1048 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedHeight; // 0x10f8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseSpeedAngleToOrigin; // 0x11a8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationDistance; // 0x1258 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationFOV; // 0x1308 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationHeight; // 0x13b8 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty BaseAccelerationAngleToOrigin; // 0x1468 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboDistance; // 0x1518 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboFOV; // 0x16e8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboBonusZoneSuccessDistance; // 0x18b8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty TurboBonusZoneSuccessFOV; // 0x1a88 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty DriftBonusDistance; // 0x1c58 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty DriftBonusFOV; // 0x1e28 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty StartlineDistance; // 0x1ff8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty StartlineFOV; // 0x21c8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatProperty DraftDistance; // 0x2398 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatProperty DraftFOV; // 0x2448 (Size: 0xb0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty WorldBonusSpeedDistance; // 0x24f8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatBlendedProperty WorldBonusSpeedFOV; // 0x26c8 (Size: 0x1d0, Type: StructProperty)
    FDelMarCameraFloatProperty AerialDivingBonusSpeedDistance; // 0x2898 (Size: 0xb0, Type: StructProperty)
    float NonSkydivingDistanceScalar; // 0x2948 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_294c[0x4]; // 0x294c (Size: 0x4, Type: PaddingProperty)
    FDelMarCameraFloatProperty AerialDivingBonusSpeedFOV; // 0x2950 (Size: 0xb0, Type: StructProperty)
    float NonSkydivingFOVScalar; // 0x2a00 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> VehicleTarget; // 0x2a04 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCameraInputControllerComponent*> CameraInputControllerComponent; // 0x2a0c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_2a14[0xa0c]; // 0x2a14 (Size: 0xa0c, Type: PaddingProperty)

protected:
    void OnAirFreestyleDeactivated(); // 0x11b205dc (Index: 0x0, Flags: Final|Native|Protected)
    void OnAppliedTeleportRotation(); // 0x11b205f4 (Index: 0x1, Flags: Final|Native|Protected)
    void OnDriftBonusActivated(); // 0x11b20b68 (Index: 0x2, Flags: Final|Native|Protected)
    void OnDriftBonusDeactivated(); // 0x11b20b7c (Index: 0x3, Flags: Final|Native|Protected)
    void OnDriftKickActivated(float& DriftDirection, EDelMarVehicleDriftState& DriftState); // 0x11b20b9c (Index: 0x4, Flags: Final|Native|Protected)
    void OnDriftKickDeactivated(); // 0x11b20da8 (Index: 0x5, Flags: Final|Native|Protected)
    void OnStartlineBoostActivated(float& StartlineBoostPerc); // 0x11b20dcc (Index: 0x6, Flags: Final|Native|Protected)
    void OnStartlineBoostDeactivated(); // 0x11b20ef8 (Index: 0x7, Flags: Final|Native|Protected)
    void OnTurboActivated(); // 0x11b20f18 (Index: 0x8, Flags: Final|Native|Protected)
    void OnTurboBonusZoneStateChanged(EDelMarTurboZoneState& ZoneState); // 0x11b20f2c (Index: 0x9, Flags: Final|Native|Protected)
    void OnTurboDeactivated(); // 0x11b21090 (Index: 0xa, Flags: Final|Native|Protected)
    void OnWorldBonusSpeedStackGained(FGameplayTag& Source, int32_t& Stacks); // 0x11b210c0 (Index: 0xb, Flags: Final|Native|Protected)
    void OnWorldBonusSpeedStackLost(FGameplayTag& Source, int32_t& Stacks); // 0x11b211f8 (Index: 0xc, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarVehicleCameraMode_V2) == 0x3420, "Size mismatch for UDelMarVehicleCameraMode_V2");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, CameraInputControllerComponentClass) == 0x60, "Offset mismatch for UDelMarVehicleCameraMode_V2::CameraInputControllerComponentClass");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, VehicleArchetypeDefaults) == 0x68, "Offset mismatch for UDelMarVehicleCameraMode_V2::VehicleArchetypeDefaults");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DefaultInterpLambda) == 0xb8, "Offset mismatch for UDelMarVehicleCameraMode_V2::DefaultInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, FOV) == 0xbc, "Offset mismatch for UDelMarVehicleCameraMode_V2::FOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalFOVInterpLambda) == 0xc0, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalFOVInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalFOVClamp) == 0xc4, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalFOVClamp");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, Distance) == 0xd4, "Offset mismatch for UDelMarVehicleCameraMode_V2::Distance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalDistanceInterpLambda) == 0xd8, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalDistanceInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalDistanceClamp) == 0xdc, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalDistanceClamp");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, Height) == 0xec, "Offset mismatch for UDelMarVehicleCameraMode_V2::Height");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalHeightInterpLambda) == 0xf0, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalHeightInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, HeightOffsetInterpLambda) == 0xf4, "Offset mismatch for UDelMarVehicleCameraMode_V2::HeightOffsetInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalHeightClamp) == 0xf8, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalHeightClamp");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AngleToOriginDegrees) == 0x108, "Offset mismatch for UDelMarVehicleCameraMode_V2::AngleToOriginDegrees");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AngleToOriginInterpLambda) == 0x10c, "Offset mismatch for UDelMarVehicleCameraMode_V2::AngleToOriginInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TotalAngleToOriginClamp) == 0x110, "Offset mismatch for UDelMarVehicleCameraMode_V2::TotalAngleToOriginClamp");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, SwivelInterpLambda) == 0x120, "Offset mismatch for UDelMarVehicleCameraMode_V2::SwivelInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, SwivelPitchMax) == 0x124, "Offset mismatch for UDelMarVehicleCameraMode_V2::SwivelPitchMax");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, SwivelYawMax) == 0x128, "Offset mismatch for UDelMarVehicleCameraMode_V2::SwivelYawMax");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, GroundNormalInterpLambda) == 0x12c, "Offset mismatch for UDelMarVehicleCameraMode_V2::GroundNormalInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, ForwardInterpLambda) == 0x130, "Offset mismatch for UDelMarVehicleCameraMode_V2::ForwardInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, CarPitchInterpLambda) == 0x134, "Offset mismatch for UDelMarVehicleCameraMode_V2::CarPitchInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AerialCarPitchInterpLambda) == 0x138, "Offset mismatch for UDelMarVehicleCameraMode_V2::AerialCarPitchInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, MaxAerialCarPitch) == 0x13c, "Offset mismatch for UDelMarVehicleCameraMode_V2::MaxAerialCarPitch");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, PitchRotationAxisInterpLambda) == 0x140, "Offset mismatch for UDelMarVehicleCameraMode_V2::PitchRotationAxisInterpLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, VerticalDriftDegreeThreshold) == 0x144, "Offset mismatch for UDelMarVehicleCameraMode_V2::VerticalDriftDegreeThreshold");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, MinDegreesVehicleWorldUpThreshold) == 0x148, "Offset mismatch for UDelMarVehicleCameraMode_V2::MinDegreesVehicleWorldUpThreshold");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, MaxUpRotationPerSecondCurve) == 0x150, "Offset mismatch for UDelMarVehicleCameraMode_V2::MaxUpRotationPerSecondCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, MaxUpRotationPerSecondStatic) == 0x1e0, "Offset mismatch for UDelMarVehicleCameraMode_V2::MaxUpRotationPerSecondStatic");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, WorldUpInterpRate) == 0x1e4, "Offset mismatch for UDelMarVehicleCameraMode_V2::WorldUpInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, bPreventPenetration) == 0x1e8, "Offset mismatch for UDelMarVehicleCameraMode_V2::bPreventPenetration");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, bDoPredictiveAvoidance) == 0x1e9, "Offset mismatch for UDelMarVehicleCameraMode_V2::bDoPredictiveAvoidance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, CollisionPushOutDistance) == 0x1ec, "Offset mismatch for UDelMarVehicleCameraMode_V2::CollisionPushOutDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, PenetrationBlendOutTime) == 0x1f0, "Offset mismatch for UDelMarVehicleCameraMode_V2::PenetrationBlendOutTime");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, PenetrationBlendInTime) == 0x1f4, "Offset mismatch for UDelMarVehicleCameraMode_V2::PenetrationBlendInTime");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, PenetrationTraceChannel) == 0x1f8, "Offset mismatch for UDelMarVehicleCameraMode_V2::PenetrationTraceChannel");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, PenetrationAvoidanceFeelers) == 0x200, "Offset mismatch for UDelMarVehicleCameraMode_V2::PenetrationAvoidanceFeelers");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, ForwardAirInterpLambdaCurve) == 0x210, "Offset mismatch for UDelMarVehicleCameraMode_V2::ForwardAirInterpLambdaCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, ForwardAirBlendCurve) == 0x2a0, "Offset mismatch for UDelMarVehicleCameraMode_V2::ForwardAirBlendCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, MinForwardSpeedForAerialBlend) == 0x328, "Offset mismatch for UDelMarVehicleCameraMode_V2::MinForwardSpeedForAerialBlend");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, MinTimeInAirBeforeUsingVehicleUp) == 0x32c, "Offset mismatch for UDelMarVehicleCameraMode_V2::MinTimeInAirBeforeUsingVehicleUp");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, GroundNormalAirInterpLambdaCurve) == 0x330, "Offset mismatch for UDelMarVehicleCameraMode_V2::GroundNormalAirInterpLambdaCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AirFreestyleDeactivationExtendedSeconds) == 0x3c0, "Offset mismatch for UDelMarVehicleCameraMode_V2::AirFreestyleDeactivationExtendedSeconds");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AirFreestyleDeactivationLambdaSeconds) == 0x3c4, "Offset mismatch for UDelMarVehicleCameraMode_V2::AirFreestyleDeactivationLambdaSeconds");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AirFreestyleDeactivationForwardLambda) == 0x3c8, "Offset mismatch for UDelMarVehicleCameraMode_V2::AirFreestyleDeactivationForwardLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AirFreestyleDeactivationNormalLambda) == 0x3cc, "Offset mismatch for UDelMarVehicleCameraMode_V2::AirFreestyleDeactivationNormalLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftForwardBlendCurve) == 0x3d0, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftForwardBlendCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AerialDriftForwardBlendCurve) == 0x458, "Offset mismatch for UDelMarVehicleCameraMode_V2::AerialDriftForwardBlendCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftForwardInterpLambdaCurve) == 0x4e0, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftForwardInterpLambdaCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftOriginOffsetCurve) == 0x568, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftOriginOffsetCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftOriginOffsetInterpLambdaCurve) == 0x5f0, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftOriginOffsetInterpLambdaCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftOriginOffsetInactiveLambda) == 0x680, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftOriginOffsetInactiveLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftKickOffsetDistance) == 0x688, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftKickOffsetDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftKickOffsetLambda) == 0x858, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftKickOffsetLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftKickOffsetInactiveLambda) == 0x85c, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftKickOffsetInactiveLambda");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, bDeactivateKickOffsetOnKickEnd) == 0x860, "Offset mismatch for UDelMarVehicleCameraMode_V2::bDeactivateKickOffsetOnKickEnd");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftRollDegreesCurve) == 0x868, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftRollDegreesCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftRollDegreesInterpLambdaCurve) == 0x8f0, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftRollDegreesInterpLambdaCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftScalarCurveCurve) == 0x980, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftScalarCurveCurve");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, GroundMaxPitchForNormalBlend) == 0xa10, "Offset mismatch for UDelMarVehicleCameraMode_V2::GroundMaxPitchForNormalBlend");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, GroundExtraPitchForNormalBlend) == 0xa14, "Offset mismatch for UDelMarVehicleCameraMode_V2::GroundExtraPitchForNormalBlend");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, StableSpeedDistance) == 0xa18, "Offset mismatch for UDelMarVehicleCameraMode_V2::StableSpeedDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, StableSpeedFOV) == 0xac8, "Offset mismatch for UDelMarVehicleCameraMode_V2::StableSpeedFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, StableSpeedHeight) == 0xb78, "Offset mismatch for UDelMarVehicleCameraMode_V2::StableSpeedHeight");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, StableSpeedAngleToOrigin) == 0xc28, "Offset mismatch for UDelMarVehicleCameraMode_V2::StableSpeedAngleToOrigin");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AccelerationDistance) == 0xcd8, "Offset mismatch for UDelMarVehicleCameraMode_V2::AccelerationDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AccelerationFOV) == 0xd88, "Offset mismatch for UDelMarVehicleCameraMode_V2::AccelerationFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AccelerationHeight) == 0xe38, "Offset mismatch for UDelMarVehicleCameraMode_V2::AccelerationHeight");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AccelerationAngleToOrigin) == 0xee8, "Offset mismatch for UDelMarVehicleCameraMode_V2::AccelerationAngleToOrigin");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseSpeedDistance) == 0xf98, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseSpeedDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseSpeedFOV) == 0x1048, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseSpeedFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseSpeedHeight) == 0x10f8, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseSpeedHeight");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseSpeedAngleToOrigin) == 0x11a8, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseSpeedAngleToOrigin");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseAccelerationDistance) == 0x1258, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseAccelerationDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseAccelerationFOV) == 0x1308, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseAccelerationFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseAccelerationHeight) == 0x13b8, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseAccelerationHeight");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, BaseAccelerationAngleToOrigin) == 0x1468, "Offset mismatch for UDelMarVehicleCameraMode_V2::BaseAccelerationAngleToOrigin");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TurboDistance) == 0x1518, "Offset mismatch for UDelMarVehicleCameraMode_V2::TurboDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TurboFOV) == 0x16e8, "Offset mismatch for UDelMarVehicleCameraMode_V2::TurboFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TurboBonusZoneSuccessDistance) == 0x18b8, "Offset mismatch for UDelMarVehicleCameraMode_V2::TurboBonusZoneSuccessDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, TurboBonusZoneSuccessFOV) == 0x1a88, "Offset mismatch for UDelMarVehicleCameraMode_V2::TurboBonusZoneSuccessFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftBonusDistance) == 0x1c58, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftBonusDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DriftBonusFOV) == 0x1e28, "Offset mismatch for UDelMarVehicleCameraMode_V2::DriftBonusFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, StartlineDistance) == 0x1ff8, "Offset mismatch for UDelMarVehicleCameraMode_V2::StartlineDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, StartlineFOV) == 0x21c8, "Offset mismatch for UDelMarVehicleCameraMode_V2::StartlineFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DraftDistance) == 0x2398, "Offset mismatch for UDelMarVehicleCameraMode_V2::DraftDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, DraftFOV) == 0x2448, "Offset mismatch for UDelMarVehicleCameraMode_V2::DraftFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, WorldBonusSpeedDistance) == 0x24f8, "Offset mismatch for UDelMarVehicleCameraMode_V2::WorldBonusSpeedDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, WorldBonusSpeedFOV) == 0x26c8, "Offset mismatch for UDelMarVehicleCameraMode_V2::WorldBonusSpeedFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AerialDivingBonusSpeedDistance) == 0x2898, "Offset mismatch for UDelMarVehicleCameraMode_V2::AerialDivingBonusSpeedDistance");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, NonSkydivingDistanceScalar) == 0x2948, "Offset mismatch for UDelMarVehicleCameraMode_V2::NonSkydivingDistanceScalar");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, AerialDivingBonusSpeedFOV) == 0x2950, "Offset mismatch for UDelMarVehicleCameraMode_V2::AerialDivingBonusSpeedFOV");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, NonSkydivingFOVScalar) == 0x2a00, "Offset mismatch for UDelMarVehicleCameraMode_V2::NonSkydivingFOVScalar");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, VehicleTarget) == 0x2a04, "Offset mismatch for UDelMarVehicleCameraMode_V2::VehicleTarget");
static_assert(offsetof(UDelMarVehicleCameraMode_V2, CameraInputControllerComponent) == 0x2a0c, "Offset mismatch for UDelMarVehicleCameraMode_V2::CameraInputControllerComponent");

// Size: 0xc8 (Inherited: 0x1a8, Single: 0xffffff20)
class UDelMarVehicleInteractionOverrideComponent : public UFortVehicleInteractionOverrideComponent
{
public:
};

static_assert(sizeof(UDelMarVehicleInteractionOverrideComponent) == 0xc8, "Size mismatch for UDelMarVehicleInteractionOverrideComponent");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UDelMarVehicleLoadoutSetup : public UPrimaryDataAsset
{
public:
    FDelMarLoadout Loadout; // 0x30 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UDelMarVehicleLoadoutSetup) == 0x80, "Size mismatch for UDelMarVehicleLoadoutSetup");
static_assert(offsetof(UDelMarVehicleLoadoutSetup, Loadout) == 0x30, "Offset mismatch for UDelMarVehicleLoadoutSetup::Loadout");

// Size: 0x600 (Inherited: 0xe0, Single: 0x520)
class UDelMarVehicleNetworkPhysicsComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    FDelMarVehicleReplicatedState ReplicatedState; // 0xd0 (Size: 0x290, Type: StructProperty)
    uint8_t Pad_360[0x2a0]; // 0x360 (Size: 0x2a0, Type: PaddingProperty)

protected:
    void OnPhysicsStateChanged(UPrimitiveComponent*& ChangedComponent, EComponentPhysicsStateChange& StateChange); // 0x11b27acc (Index: 0x0, Flags: Final|Native|Protected)
    void OnRep_ReplicatedState(const FDelMarVehicleReplicatedState PrevReplicatedState); // 0x11b27cd4 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UDelMarVehicleNetworkPhysicsComponent) == 0x600, "Size mismatch for UDelMarVehicleNetworkPhysicsComponent");
static_assert(offsetof(UDelMarVehicleNetworkPhysicsComponent, ReplicatedState) == 0xd0, "Offset mismatch for UDelMarVehicleNetworkPhysicsComponent::ReplicatedState");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UDelMarVehicleStateTagManagerComponent : public UActorComponent
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> CachedASC; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

protected:
    void HandleAnyWheelsOnGroundChanged(const TScriptInterface<Class> Vehicle, bool& bWheelsOnGround); // 0x11b25c40 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandleDraftActivated(); // 0x11b25ef0 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleDraftDeactivated(); // 0x11b25f18 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleDriftActivated(); // 0x11b25f2c (Index: 0x3, Flags: Final|Native|Protected)
    void HandleDriftBoostActivated(); // 0x11b25f40 (Index: 0x4, Flags: Final|Native|Protected)
    void HandleDriftBoostDeactivated(); // 0x11b25f68 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleDriftDeactivated(); // 0x11b25f90 (Index: 0x6, Flags: Final|Native|Protected)
    void HandleTurboChargeUsed(); // 0x11b26ec0 (Index: 0x7, Flags: Final|Native|Protected)
    void HandleTurboDeactivated(); // 0x11b26ee8 (Index: 0x8, Flags: Final|Native|Protected)
    void HandleWorldBonusSpeedStackGained(FGameplayTag& Source, int32_t& Stacks); // 0x11b275ec (Index: 0x9, Flags: Final|Native|Protected)
    void HandleWorldBonusSpeedStackLost(FGameplayTag& Source, int32_t& Stacks); // 0x11b2785c (Index: 0xa, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarVehicleStateTagManagerComponent) == 0xc8, "Size mismatch for UDelMarVehicleStateTagManagerComponent");
static_assert(offsetof(UDelMarVehicleStateTagManagerComponent, CachedVehicle) == 0xb8, "Offset mismatch for UDelMarVehicleStateTagManagerComponent::CachedVehicle");
static_assert(offsetof(UDelMarVehicleStateTagManagerComponent, CachedASC) == 0xc0, "Offset mismatch for UDelMarVehicleStateTagManagerComponent::CachedASC");

// Size: 0xe0 (Inherited: 0xe0, Single: 0x0)
class UDelMarVehicleVerbComponent : public UActorComponent
{
public:

protected:
    void HandleAnyWheelsOnGroundChanged(const TScriptInterface<Class> Vehicle, bool& bWheelsOnGround); // 0x11b25d98 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandleDraftActivated(); // 0x11b25f04 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleDriftBoostActivated(); // 0x11b25f54 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleDriftBoostDeactivated(); // 0x11b25f7c (Index: 0x3, Flags: Final|Native|Protected)
    void HandleDriftDeactivated(); // 0x11b25fa4 (Index: 0x4, Flags: Final|Native|Protected)
    void HandleDriftDurationChanged(float& duration); // 0x11b25fb8 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleHazardHit(); // 0x11b260ec (Index: 0x6, Flags: Final|Native|Protected)
    void HandleJumpActivated(); // 0x11b26100 (Index: 0x7, Flags: Final|Native|Protected)
    void HandleKickflipped(bool& bLeft); // 0x11b26114 (Index: 0x8, Flags: Final|Native|Protected)
    void HandlePotentialDriftBoostChanged(float& Percent); // 0x11b266e4 (Index: 0x9, Flags: Final|Native|Protected)
    void HandleSpeedometerSpeedChanged(float& UpdatedSpeedometerSpeed); // 0x11b26818 (Index: 0xa, Flags: Final|Native|Protected)
    void HandleStartlineBoostActivated(float& BoostPercent); // 0x11b26944 (Index: 0xb, Flags: Final|Native|Protected)
    void HandleTurboBonusZoneChanged(EDelMarTurboZoneState& BonusZoneState); // 0x11b26a70 (Index: 0xc, Flags: Final|Native|Protected)
    void HandleTurboChargeUsed(); // 0x11b26ed4 (Index: 0xd, Flags: Final|Native|Protected)
    void HandleUnderthrustDeactivated(); // 0x11b26efc (Index: 0xe, Flags: Final|Native|Protected)
    void HandleUnderthrustPercentChanged(float& PercentageUnderthrustRemaining); // 0x11b26f10 (Index: 0xf, Flags: Final|Native|Protected)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11b2703c (Index: 0x10, Flags: Final|Native|Protected)
    void HandleVehicleLanded(float& LandingForce, bool& bLandedKickflip); // 0x11b270fc (Index: 0x11, Flags: Final|Native|Protected)
    void HandleWorldBonusSpeedStackGained(FGameplayTag& Source, int32_t& Stacks); // 0x11b27724 (Index: 0x12, Flags: Final|Native|Protected)
    void HandleWorldBonusSpeedStackLost(FGameplayTag& Source, int32_t& Stacks); // 0x11b27994 (Index: 0x13, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarVehicleVerbComponent) == 0xe0, "Size mismatch for UDelMarVehicleVerbComponent");

// Size: 0x68 (Inherited: 0x90, Single: 0xffffffd8)
class UFortAutomationRpcManager_DelMar : public UFortAutomationRpcManager
{
public:
};

static_assert(sizeof(UFortAutomationRpcManager_DelMar) == 0x68, "Size mismatch for UFortAutomationRpcManager_DelMar");

// Size: 0x68 (Inherited: 0x50, Single: 0x18)
class UGameFeatureAction_MergeRankedDisplayData : public UGameFeatureAction
{
public:
    TSoftObjectPtr<UFortHabaneroDisplayData*> MergeSource; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortHabaneroDisplayData*> MergeDestination; // 0x48 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UGameFeatureAction_MergeRankedDisplayData) == 0x68, "Size mismatch for UGameFeatureAction_MergeRankedDisplayData");
static_assert(offsetof(UGameFeatureAction_MergeRankedDisplayData, MergeSource) == 0x28, "Offset mismatch for UGameFeatureAction_MergeRankedDisplayData::MergeSource");
static_assert(offsetof(UGameFeatureAction_MergeRankedDisplayData, MergeDestination) == 0x48, "Offset mismatch for UGameFeatureAction_MergeRankedDisplayData::MergeDestination");

// Size: 0xd0 (Inherited: 0x250, Single: 0xfffffe80)
class UUDelMarPlayerSuspendComponent : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UUDelMarPlayerSuspendComponent) == 0xd0, "Size mismatch for UUDelMarPlayerSuspendComponent");
static_assert(offsetof(UUDelMarPlayerSuspendComponent, CachedRaceManager) == 0xc0, "Offset mismatch for UUDelMarPlayerSuspendComponent::CachedRaceManager");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDelMarVehicleInterface : public UVehicleCosmeticsInterface
{
public:

public:
    bool AnyWheelsOnGround() const; // 0xbea6ef4 (Index: 0x0, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool CanStrafeBeActivated() const; // 0x54e573c (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetAcceleration() const; // 0x11b286f0 (Index: 0x2, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetBaseForwardSpeed() const; // 0xa32d2d8 (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetBaseTargetSpeed() const; // 0xee17a64 (Index: 0x4, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetBonusSpeed() const; // 0x11b2871c (Index: 0x5, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarVehicleCosmeticComponent* GetCosmeticComponent() const; // 0x11b28748 (Index: 0x6, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentFastestSpeed() const; // 0x11b28770 (Index: 0x7, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentNumTurboCharges() const; // 0x11b2879c (Index: 0x8, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDelMarTurboZoneState GetCurrentTurboBonusZoneState() const; // 0xd7afbcc (Index: 0x9, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDraftingCurrentBonusSpeedPercentage() const; // 0x11b287c8 (Index: 0xa, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDraftingMaxBonusSpeedPercentage() const; // 0x11b287f4 (Index: 0xb, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDelmarDraftingState GetDraftingState() const; // 0x11b28820 (Index: 0xc, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDraftingTargetDegrees() const; // 0x11b28848 (Index: 0xd, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDriftAngle() const; // 0x11b28874 (Index: 0xe, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDriftBoostAppliedBonusSpeed() const; // 0x11b288a0 (Index: 0xf, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDriftDuration() const; // 0x11b288cc (Index: 0x10, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDriftSlipAngleRatio() const; // 0x11b288f8 (Index: 0x11, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetForwardSpeed() const; // 0x11b28924 (Index: 0x12, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetKickflipActivationCharges() const; // 0x11b28950 (Index: 0x13, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetKickflipDistanceToSuctionSurface() const; // 0x11b28978 (Index: 0x14, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetKickflipDuration() const; // 0x11b289a4 (Index: 0x15, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDelMarVehicleLandingData GetLandingData() const; // 0x11b289d0 (Index: 0x16, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetMaxNumTurboCharges() const; // 0x11b28a08 (Index: 0x17, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetNormalizedBonusSpeed() const; // 0x11b28a34 (Index: 0x18, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetNormalizedForwardSpeed() const; // 0x11b28a60 (Index: 0x19, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetOversteerAccumulationPercentage() const; // 0x11b28a8c (Index: 0x1a, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPercentageTurboActiveTimeRemaining() const; // 0x11b28ab8 (Index: 0x1b, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UPostProcessComponent* GetPostProcessComponent() const; // 0x11b28ae4 (Index: 0x1c, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPotentialDriftBoostPercentage() const; // 0x11b28b0c (Index: 0x1d, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetQueuedBonusSpeed() const; // 0x11b28b38 (Index: 0x1e, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetReattachmentDirection() const; // 0x11b28b64 (Index: 0x1f, Flags: Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetRemainingTurboActiveSeconds() const; // 0x11b28ba0 (Index: 0x20, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSideSpeed() const; // 0x11b28bcc (Index: 0x21, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMeshComponent* GetSkeletalMeshComponent() const; // 0x11b28bf8 (Index: 0x22, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSpeedometerSpeed() const; // 0x11b28c20 (Index: 0x23, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStableSpeed() const; // 0xee179e8 (Index: 0x24, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStartlineAppliedBonusSpeed() const; // 0xf1bc2fc (Index: 0x25, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStartlineMaxEarnedBonusSpeed() const; // 0xa43d9f4 (Index: 0x26, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStartlinePercentageMaxBonusSpeedEarned() const; // 0xf768874 (Index: 0x27, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSteering() const; // 0xfdbfdbc (Index: 0x28, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSteeringAngle() const; // 0x11b28c4c (Index: 0x29, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStrafeCooldownPercentage() const; // 0x11b28c78 (Index: 0x2a, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTargetDriftSide() const; // 0x11b28ca4 (Index: 0x2b, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTargetSpeed() const; // 0xee17a38 (Index: 0x2c, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetThrottle() const; // 0x11b28cd0 (Index: 0x2d, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTotalTimeSkydiving() const; // 0x11b28cfc (Index: 0x2e, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarTrackPositionComponent* GetTrackPositionComponent() const; // 0x11b28d28 (Index: 0x2f, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTurboAdditionalActiveSeconds() const; // 0x11b28d50 (Index: 0x30, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTurboAppliedBonusSpeed() const; // 0x11b28d7c (Index: 0x31, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTurboBonusZoneBonusSpeed() const; // 0x11b28da8 (Index: 0x32, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetUnderthrustActiveDuration() const; // 0x11b28dd4 (Index: 0x33, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetUnderthrustPercentageTankRemaining() const; // 0x11b28e00 (Index: 0x34, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDelMarVehicleForwardState GetVehicleForwardState() const; // 0xa51e4cc (Index: 0x35, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetVelocity() const; // 0x11b28e2c (Index: 0x36, Flags: Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetWorldAppliedBonusSpeed() const; // 0x5946d90 (Index: 0x37, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasValidDraftingTarget() const; // 0x5989588 (Index: 0x38, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool InDriftBoostRange() const; // 0x11b28e68 (Index: 0x39, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAccelerating() const; // 0xdbad5a4 (Index: 0x3a, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAirFreestyling() const; // 0xa29c5f0 (Index: 0x3b, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAllVehicleInputDisabled() const; // 0x99797ac (Index: 0x3c, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsBraking() const; // 0x11b28e90 (Index: 0x3d, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDriftControlled() const; // 0x1077dc4c (Index: 0x3e, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInvulnerabilityActive() const; // 0x11b28eb8 (Index: 0x3f, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsKickflipSuctionActive() const; // 0x11b28ee0 (Index: 0x40, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsKickingWheels() const; // 0xdd0f68c (Index: 0x41, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLosingAppliedBonusSpeed() const; // 0xdd10c2c (Index: 0x42, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsReattaching() const; // 0x11b28f08 (Index: 0x43, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSkyDiving() const; // 0xdd0f374 (Index: 0x44, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsStrafeActive() const; // 0xca98820 (Index: 0x45, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsStrafeDisabled() const; // 0xca987f8 (Index: 0x46, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsStrafeLeft() const; // 0xca987d0 (Index: 0x47, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool WheelsOnGround() const; // 0x1146c8ac (Index: 0x48, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarVehicleInterface) == 0x28, "Size mismatch for UDelMarVehicleInterface");

// Size: 0x400 (Inherited: 0x710, Single: 0xfffffcf0)
class UDelMarAudioComponentGroup : public UAudioComponentGroup
{
public:
    UDelMarAudioMixModifierExtension* MixModifierExtension; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    UDelMarSubmixSendExtension* SubmixSendExtension; // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3f8[0x8]; // 0x3f8 (Size: 0x8, Type: PaddingProperty)

public:
    UDelMarAudioMixModifierExtension* GetMixModifiers() const; // 0xd0c2eb8 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarSubmixSendExtension* GetSubmixSends() const; // 0x11b71fa8 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarAudioComponentGroup) == 0x400, "Size mismatch for UDelMarAudioComponentGroup");
static_assert(offsetof(UDelMarAudioComponentGroup, MixModifierExtension) == 0x3e8, "Offset mismatch for UDelMarAudioComponentGroup::MixModifierExtension");
static_assert(offsetof(UDelMarAudioComponentGroup, SubmixSendExtension) == 0x3f0, "Offset mismatch for UDelMarAudioComponentGroup::SubmixSendExtension");

// Size: 0x528 (Inherited: 0xce8, Single: 0xfffff840)
class ADelMarAudioController : public AFortAthenaVehicleAudioController
{
public:
    uint8_t Pad_438[0x18]; // 0x438 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnBigAirStarted[0x10]; // 0x450 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBigAirStopped[0x10]; // 0x460 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UDelMarAudioComponentGroup* ComponentGroup; // 0x470 (Size: 0x8, Type: ObjectProperty)
    bool bIsLocal; // 0x478 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_479[0x3]; // 0x479 (Size: 0x3, Type: PaddingProperty)
    float FinishLineDistanceThreshold; // 0x47c (Size: 0x4, Type: FloatProperty)
    float ApproachingFinishLineMinTime; // 0x480 (Size: 0x4, Type: FloatProperty)
    float BigAirLandingDistanceThreshold; // 0x484 (Size: 0x4, Type: FloatProperty)
    float BigAirTimeThreshold; // 0x488 (Size: 0x4, Type: FloatProperty)
    float BigAirDownSpeedThreshold; // 0x48c (Size: 0x4, Type: FloatProperty)
    float NonLocalVelocityInterpSpeed; // 0x490 (Size: 0x4, Type: FloatProperty)
    float MaxAcceleration; // 0x494 (Size: 0x4, Type: FloatProperty)
    bool bInBigAir; // 0x498 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_499[0x7]; // 0x499 (Size: 0x7, Type: PaddingProperty)
    ADelMarVehicle* CachedVehicle; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    bool bCanShift; // 0x4a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a9[0x7f]; // 0x4a9 (Size: 0x7f, Type: PaddingProperty)

public:
    virtual void BP_OnIsLocalChanged(bool& const bNewValue); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    UDelMarAudioComponentGroup* GetComponentGroup() const; // 0x11b70f90 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11b727d0 (Index: 0x2, Flags: Final|Native|Public)
    bool IsVirtualized() const; // 0x11b72f68 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAudioComponent* PlaySound(USoundBase*& Sound, float& InFadeInTime, float& InTargetVolume, bool& bDisableAttenuation, EAudioFaderCurve& const InFadeCurve); // 0x11b72f88 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADelMarAudioController) == 0x528, "Size mismatch for ADelMarAudioController");
static_assert(offsetof(ADelMarAudioController, OnBigAirStarted) == 0x450, "Offset mismatch for ADelMarAudioController::OnBigAirStarted");
static_assert(offsetof(ADelMarAudioController, OnBigAirStopped) == 0x460, "Offset mismatch for ADelMarAudioController::OnBigAirStopped");
static_assert(offsetof(ADelMarAudioController, ComponentGroup) == 0x470, "Offset mismatch for ADelMarAudioController::ComponentGroup");
static_assert(offsetof(ADelMarAudioController, bIsLocal) == 0x478, "Offset mismatch for ADelMarAudioController::bIsLocal");
static_assert(offsetof(ADelMarAudioController, FinishLineDistanceThreshold) == 0x47c, "Offset mismatch for ADelMarAudioController::FinishLineDistanceThreshold");
static_assert(offsetof(ADelMarAudioController, ApproachingFinishLineMinTime) == 0x480, "Offset mismatch for ADelMarAudioController::ApproachingFinishLineMinTime");
static_assert(offsetof(ADelMarAudioController, BigAirLandingDistanceThreshold) == 0x484, "Offset mismatch for ADelMarAudioController::BigAirLandingDistanceThreshold");
static_assert(offsetof(ADelMarAudioController, BigAirTimeThreshold) == 0x488, "Offset mismatch for ADelMarAudioController::BigAirTimeThreshold");
static_assert(offsetof(ADelMarAudioController, BigAirDownSpeedThreshold) == 0x48c, "Offset mismatch for ADelMarAudioController::BigAirDownSpeedThreshold");
static_assert(offsetof(ADelMarAudioController, NonLocalVelocityInterpSpeed) == 0x490, "Offset mismatch for ADelMarAudioController::NonLocalVelocityInterpSpeed");
static_assert(offsetof(ADelMarAudioController, MaxAcceleration) == 0x494, "Offset mismatch for ADelMarAudioController::MaxAcceleration");
static_assert(offsetof(ADelMarAudioController, bInBigAir) == 0x498, "Offset mismatch for ADelMarAudioController::bInBigAir");
static_assert(offsetof(ADelMarAudioController, CachedVehicle) == 0x4a0, "Offset mismatch for ADelMarAudioController::CachedVehicle");
static_assert(offsetof(ADelMarAudioController, bCanShift) == 0x4a8, "Offset mismatch for ADelMarAudioController::bCanShift");

// Size: 0xe0 (Inherited: 0xe0, Single: 0x0)
class UDelMarAudioMixModifierExtension : public UActorComponent
{
public:

public:
    void AddMixGroup(const FAudioMixModifierGroup InMixModifier); // 0x11b6f354 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveMixGroup(const FAudioMixModifierGroup InMixModifier); // 0x11b73494 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveMixGroupByName(FName& const InName); // 0x11b73578 (Index: 0x2, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarAudioMixModifierExtension) == 0xe0, "Size mismatch for UDelMarAudioMixModifierExtension");

// Size: 0x340 (Inherited: 0xe0, Single: 0x260)
class UDelMarAudioReverbComponent : public UActorComponent
{
public:
    USoundSubmixBase* ReverbSend; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* EarlyReflectionSend; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    FRuntimeFloatCurve EnclosureReverbBlendCurve; // 0xc8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WallDistanceBlendCurve; // 0x150 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve EnclosureSendLevelCurve; // 0x1d8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WallDistanceSendLevelCurve; // 0x260 (Size: 0x88, Type: StructProperty)
    int32_t NumPoints; // 0x2e8 (Size: 0x4, Type: IntProperty)
    float TraceRadius; // 0x2ec (Size: 0x4, Type: FloatProperty)
    FVector TraceOrigin; // 0x2f0 (Size: 0x18, Type: StructProperty)
    int32_t NumTracesPerFrame; // 0x308 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_30c[0x4]; // 0x30c (Size: 0x4, Type: PaddingProperty)
    ADelMarVehicle* CachedVehicleOwner; // 0x310 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_318[0x28]; // 0x318 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarAudioReverbComponent) == 0x340, "Size mismatch for UDelMarAudioReverbComponent");
static_assert(offsetof(UDelMarAudioReverbComponent, ReverbSend) == 0xb8, "Offset mismatch for UDelMarAudioReverbComponent::ReverbSend");
static_assert(offsetof(UDelMarAudioReverbComponent, EarlyReflectionSend) == 0xc0, "Offset mismatch for UDelMarAudioReverbComponent::EarlyReflectionSend");
static_assert(offsetof(UDelMarAudioReverbComponent, EnclosureReverbBlendCurve) == 0xc8, "Offset mismatch for UDelMarAudioReverbComponent::EnclosureReverbBlendCurve");
static_assert(offsetof(UDelMarAudioReverbComponent, WallDistanceBlendCurve) == 0x150, "Offset mismatch for UDelMarAudioReverbComponent::WallDistanceBlendCurve");
static_assert(offsetof(UDelMarAudioReverbComponent, EnclosureSendLevelCurve) == 0x1d8, "Offset mismatch for UDelMarAudioReverbComponent::EnclosureSendLevelCurve");
static_assert(offsetof(UDelMarAudioReverbComponent, WallDistanceSendLevelCurve) == 0x260, "Offset mismatch for UDelMarAudioReverbComponent::WallDistanceSendLevelCurve");
static_assert(offsetof(UDelMarAudioReverbComponent, NumPoints) == 0x2e8, "Offset mismatch for UDelMarAudioReverbComponent::NumPoints");
static_assert(offsetof(UDelMarAudioReverbComponent, TraceRadius) == 0x2ec, "Offset mismatch for UDelMarAudioReverbComponent::TraceRadius");
static_assert(offsetof(UDelMarAudioReverbComponent, TraceOrigin) == 0x2f0, "Offset mismatch for UDelMarAudioReverbComponent::TraceOrigin");
static_assert(offsetof(UDelMarAudioReverbComponent, NumTracesPerFrame) == 0x308, "Offset mismatch for UDelMarAudioReverbComponent::NumTracesPerFrame");
static_assert(offsetof(UDelMarAudioReverbComponent, CachedVehicleOwner) == 0x310, "Offset mismatch for UDelMarAudioReverbComponent::CachedVehicleOwner");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UDelMarSubmixSendExtension : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    float SendInterpTime; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0x14]; // 0xc4 (Size: 0x14, Type: PaddingProperty)

public:
    void RemoveSend(USoundSubmixBase*& InSubmix); // 0x11b736a4 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SetSend(USoundSubmixBase*& InSubmix, float& const InLevel, bool& const bTrackCount); // 0x11b73c0c (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarSubmixSendExtension) == 0xd8, "Size mismatch for UDelMarSubmixSendExtension");
static_assert(offsetof(UDelMarSubmixSendExtension, SendInterpTime) == 0xc0, "Offset mismatch for UDelMarSubmixSendExtension::SendInterpTime");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarNuxBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static int32_t GetCurrentLapNumber(ADelMarVehicle*& const Vehicle); // 0x11b70fa8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FDelMarRankedInfo GetCurrentRankedInfoForVehicle(ADelMarVehicle*& const Vehicle); // 0x11b710d0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarNuxBlueprintFunctionLibrary) == 0x28, "Size mismatch for UDelMarNuxBlueprintFunctionLibrary");

// Size: 0x340 (Inherited: 0x4f0, Single: 0xfffffe50)
class UFortClientPilot_QuickSmokeDelMar : public UFortClientPilot_GameplayBase
{
public:
};

static_assert(sizeof(UFortClientPilot_QuickSmokeDelMar) == 0x340, "Size mismatch for UFortClientPilot_QuickSmokeDelMar");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool AreAllLeaderboardFiltersEnabled(); // 0x11b6f438 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool BP_KillAndRespawnVehicle(AController*& const Controller, FGameplayTag& CausedByTag); // 0x11b6f464 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FText DelMarFormatTime(double& const TimeSeconds, bool& const bIncludeMilliseconds); // 0x11b706a0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static double GetClientWorldTimeSeconds(UObject*& const WorldContextObject); // 0x11b70e4c (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ADelMarPlayspace* GetDelMarPlayspace(UObject*& const WorldContextObject); // 0x11b71618 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static ADelMarVehicle* GetDelMarVehicle(APlayerController*& const PlayerController); // 0x11b71748 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static EDelMarNetModel GetNetModel(UObject*& const WorldContextObject); // 0x11b7196c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static AFortPlayerController* GetPrimaryPlayerController(UObject*& const WorldContextObject); // 0x11b71cc4 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static AFortPlayerState* GetPrimaryPlayerState(UObject*& const WorldContextObject); // 0x11b71e24 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static double GetTimerDeltaFromServerTime(double& const TimestampSeconds, EDelMarTimerDirection& const Direction, bool& const bCapAtZero, bool& bIsPositive, UObject*& const WorldContextObject); // 0x11b71fc0 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsDelMarExperience(bool& bEnableCaching); // 0x11b729c8 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsDelMarGFSActive(); // 0x11b72af0 (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsDelMarPlaylist(UObject*& ContextObject); // 0x11b72b14 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsPlaylistNameARotationPlaylist(FString& PlaylistName); // 0x11b72c58 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void SetDelMarControlsText(APlayerController*& const PlayerController, const FDelMarEvent_SetControlsText Event); // 0x11b73804 (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetDelMarTutorialHint(APlayerController*& const PlayerController, const FDelMarEvent_SetTutorialHint Event); // 0x11b73a1c (Index: 0xf, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDelMarBlueprintLibrary) == 0x28, "Size mismatch for UDelMarBlueprintLibrary");

// Size: 0x38 (Inherited: 0x78, Single: 0xffffffc0)
class UDelMarCheatManager : public UChildCheatManager
{
public:
    TArray<FString> SafePlayerNames; // 0x28 (Size: 0x10, Type: ArrayProperty)

protected:
    void BugIt(FString& BugName) const; // 0x11b6f68c (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void BugItGo(float& X, float& Y, float& Z, float& pitch, float& Yaw, float& Roll) const; // 0x11b6f980 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void DelMarAttachPlayerToPlayer(FString& const PlayerName, FString& const OtherPlayerName); // 0xcf8d51c (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarAttachToFirstPlayer(); // 0x554e3c4 (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarAttachToPlayer(FString& const PlayerName); // 0xd7d6cf4 (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarBugIt(FString& BugName) const; // 0x11b6fe40 (Index: 0x5, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void DelMarBugItGo(float& X, float& Y, float& Z, float& pitch, float& Yaw, float& Roll) const; // 0x11b70134 (Index: 0x6, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void DelMarCancelMissedCheckpointDemoCountdown(); // 0x554e3c4 (Index: 0x7, Flags: Final|Exec|Native|Protected)
    void DelMarCancelReturnToTrackDemoCountdown(); // 0x554e3c4 (Index: 0x8, Flags: Final|Exec|Native|Protected)
    void DelMarClearActiveAutoInput(); // 0x554e3c4 (Index: 0x9, Flags: Final|Exec|Native|Protected)
    void DelMarClearQueuedAutoInput(); // 0x554e3c4 (Index: 0xa, Flags: Final|Exec|Native|Protected)
    void DelMarCreateTrackScrubberForProfiling() const; // 0x554e3c4 (Index: 0xb, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void DelMarDemolishSelf(); // 0x554e3c4 (Index: 0xc, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarDemolishSelfWithTag(FString& DemolishTagString); // 0xa63baa0 (Index: 0xd, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarDestroyTrackScrubbers() const; // 0x554e3c4 (Index: 0xe, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void DelMarDetachSelf(); // 0x554e3c4 (Index: 0xf, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarEndSpectate(); // 0x11b705f4 (Index: 0x10, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarExitVehicle(); // 0x554e3c4 (Index: 0x11, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarFetchFocusedLeaderboard(); // 0x11b70608 (Index: 0x12, Flags: Final|Exec|Native|Protected)
    void DelMarFetchFriendsLeaderboard(); // 0x11b70648 (Index: 0x13, Flags: Final|Exec|Native|Protected)
    void DelMarFetchGlobalLeaderboard(); // 0x11b70674 (Index: 0x14, Flags: Final|Exec|Native|Protected)
    void DelMarFinishRace(); // 0x554e3c4 (Index: 0x15, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarFinishRaceSelf(); // 0x554e3c4 (Index: 0x16, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarForceEveryoneToReadyUp(); // 0x554e3c4 (Index: 0x17, Flags: Final|Exec|Native|Protected)
    void DelMarForceLoadLevel(FString& const LevelName); // 0xd7d6cf4 (Index: 0x18, Flags: Final|Exec|Native|Protected)
    void DelMarForceLoadUEFNIsland(FString& IslandCode); // 0xa63baa0 (Index: 0x19, Flags: Final|Exec|Native|Protected)
    void DelMarGhostClearPlaybackFile(); // 0x554e3c4 (Index: 0x1a, Flags: Final|Exec|Native|Protected)
    void DelMarGhostForcePlayAllTriggers(); // 0x554e3c4 (Index: 0x1b, Flags: Final|Exec|Native|Protected)
    void DelMarGhostSetRecordOffPhysics(bool& bEnabled); // 0x9e6e1b8 (Index: 0x1c, Flags: Final|Exec|Native|Protected)
    void DelMarGhostSetReplayEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x1d, Flags: Final|Exec|Native|Protected)
    void DelMarGhostStartPlayerPlayback(); // 0x554e3c4 (Index: 0x1e, Flags: Final|Exec|Native|Protected)
    void DelMarGhostStartPlayerRecording(FString& SaveFileName, bool& bSaveToFile); // 0xcf91740 (Index: 0x1f, Flags: Final|Exec|Native|Protected)
    void DelMarGhostStopPlayerRecording(); // 0x554e3c4 (Index: 0x20, Flags: Final|Exec|Native|Protected)
    void DelMarGiveSelfSomeCompetitiveMMRStats(int32_t& const MyPosition, int32_t& const TotalNumberOfPlayers, int32_t& const NumberOfTimesToSendMMRUpdate); // 0xc06bbb0 (Index: 0x21, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarGrantQuestsInDir(FString& Dir); // 0xa63baa0 (Index: 0x22, Flags: Final|Exec|Native|Protected)
    void DelMarGrantTurboCharges(float& const Amount, bool& const bGrantToEveryone); // 0xefdc7f0 (Index: 0x23, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarInitiateMissedCheckpointDemoCountdown(float& SecondsUntilDemo); // 0xa35c334 (Index: 0x24, Flags: Final|Exec|Native|Protected)
    void DelMarInitiateReturnToTrackDemoCountdown(float& SecondsUntilDemo); // 0xa35c334 (Index: 0x25, Flags: Final|Exec|Native|Protected)
    void DelMarNextTutorialSection(); // 0x554e3c4 (Index: 0x26, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarPauseAllBots(); // 0x554e3c4 (Index: 0x27, Flags: Final|Exec|Native|Protected)
    void DelMarPrevTutorialSection(); // 0x554e3c4 (Index: 0x28, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarPrintInputDisableLogs(); // 0x554e3c4 (Index: 0x29, Flags: Final|Exec|Native|Protected)
    void DelMarPrintLogsToDiagnoseSpinout(); // 0x554e3c4 (Index: 0x2a, Flags: Final|Exec|Native|Protected)
    void DelMarPrintQuestProgress(); // 0x554e3c4 (Index: 0x2b, Flags: Final|Exec|Native|Protected)
    void DelMarQueueAutoInputDriveThenTurn(int32_t& Repeat, float& Throttle, float& StraightDuration, float& Steer, float& TurnDuration); // 0x11b708c8 (Index: 0x2c, Flags: Final|Exec|Native|Protected)
    void DelMarQueueAutoInputJump(int32_t& Repeat, float& Delay); // 0xcf938e8 (Index: 0x2d, Flags: Final|Exec|Native|Protected)
    void DelMarQueueAutoInputThrottle(float& Throttle, float& duration); // 0xd411464 (Index: 0x2e, Flags: Final|Exec|Native|Protected)
    void DelMarReadyUpSelf(); // 0x554e3c4 (Index: 0x2f, Flags: Final|Exec|Native|Protected)
    void DelMarRemoveAllBots(); // 0x554e3c4 (Index: 0x30, Flags: Final|Exec|Native|Protected)
    void DelMarRemoveBotByName(FString& BotName); // 0xa974244 (Index: 0x31, Flags: Final|Exec|Native|Protected|HasOutParms)
    void DelMarRemoveNumberOfBots(int32_t& NumberOfBotsToRemove); // 0xa5dc3cc (Index: 0x32, Flags: Final|Exec|Native|Protected)
    void DelMarRenamePlayers(); // 0x554e3c4 (Index: 0x33, Flags: Final|Exec|Native|Protected)
    void DelMarResetAttachments(); // 0x554e3c4 (Index: 0x34, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarResetPreRaceViewTarget(); // 0x554e3c4 (Index: 0x35, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarResetRace(); // 0x554e3c4 (Index: 0x36, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarResetTutorialSplines(); // 0x554e3c4 (Index: 0x37, Flags: Final|Exec|Native|Protected)
    void DelMarRespawnAtLastCheckpoint(); // 0x554e3c4 (Index: 0x38, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarRespawnAtLastCheckpoint_ParallelPath(); // 0x554e3c4 (Index: 0x39, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarRespawnPointLocked(bool& bLocked); // 0x9e6e1b8 (Index: 0x3a, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarResumeAllBots(); // 0x554e3c4 (Index: 0x3b, Flags: Final|Exec|Native|Protected)
    void DelMarReturnToLobby(); // 0x554e3c4 (Index: 0x3c, Flags: Final|Exec|Native|Protected)
    void DelMarSetAdditiveRechargeRateModifierSeconds(float& const Amount, bool& const bGrantToEveryone); // 0xefdc7f0 (Index: 0x3d, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetAirFreestyleEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x3e, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetCollisionDemosEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x3f, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetDemoModeEnabled(bool& const bEnabled); // 0x9e6e1b8 (Index: 0x40, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetDraftingEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x41, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetGameplayModifiersEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x42, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetGameplayModifiersMode(FString& const ModeName); // 0xd7d6cf4 (Index: 0x43, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetGlobalInputEnabled(FString& InputTag, bool& const bEnableInput); // 0xcf91740 (Index: 0x44, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetInfiniteUnderthrustEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x45, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetInputMappingContextEnabled(FString& InputTag, bool& const bEnableInput); // 0xcf91740 (Index: 0x46, Flags: Final|Exec|Native|Protected)
    void DelMarSetInvertSteerMethod(EDelMarInvertSteerMethod& InInvertSteerMethod); // 0xcf8da58 (Index: 0x47, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetLap(int32_t& LapNum); // 0xa5dc3cc (Index: 0x48, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetLapTotal(int32_t& NewTotal); // 0xa5dc3cc (Index: 0x49, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetLoadingScreenVisibility(bool& bShouldBeVisible); // 0x11b70cc4 (Index: 0x4a, Flags: Final|Exec|Native|Protected)
    void DelMarSetReplicatedTagEnabledOnSelf(FString& InputTag, bool& const bEnabled); // 0xcf91740 (Index: 0x4b, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRespawnCollisionProtectionEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x4c, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRespawnCollisionProtectionSeconds(float& Seconds); // 0xa35c334 (Index: 0x4d, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRespawnInvulnerabilityEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x4e, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRespawnInvulnerabilitySeconds(float& Seconds); // 0xa35c334 (Index: 0x4f, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRespawnTracesEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x50, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x51, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMaxBonusSpeedScalar(float& InMaxBonusSpeedScalar); // 0xa35c334 (Index: 0x52, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMaxDistanceFromPack(float& InMaxDistanceFromPack); // 0xa35c334 (Index: 0x53, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMaxPackDistance(float& InMaxPackDistance); // 0xa35c334 (Index: 0x54, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMaxPackDistanceGainedPerSecond(float& InMaxPackDistanceGainedPerSecond); // 0xa35c334 (Index: 0x55, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMaxPackDistanceLostPerSecond(float& InMaxPackDistanceLostPerSecond); // 0xa35c334 (Index: 0x56, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMinDistanceFromPack(float& InMinDistanceFromPack); // 0xa35c334 (Index: 0x57, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMinPackDistance(float& InMinPackDistance); // 0xa35c334 (Index: 0x58, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingMMR(int32_t& InMMR); // 0xa5dc3cc (Index: 0x59, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetRubberbandingNumPlayersForPackDistance(int32_t& InNumPlayersForPackDistance); // 0xa5dc3cc (Index: 0x5a, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetSpawnMode(EDelMarRaceSpawnMode& SpawnMode); // 0xcf8da58 (Index: 0x5b, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetStartlineBoostEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x5c, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetStartlineBoostPotentialOverride(float& PotentialOverride); // 0xa35c334 (Index: 0x5d, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetStrafeEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x5e, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetTurboCharges(float& const Amount, bool& const bGrantToEveryone); // 0xefdc7f0 (Index: 0x5f, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetTutorialSection(int32_t& Index); // 0xa5dc3cc (Index: 0x60, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetupMode(FString& const ModeName); // 0xd7d6cf4 (Index: 0x61, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetupTetheredPlayers(); // 0x554e3c4 (Index: 0x62, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetVehicleCollisionsOverrideForSelf(EDelMarVehicleCollisionOverrideSetting& NewValue); // 0xcf8da58 (Index: 0x63, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetVehicleCollisionsOverrideGlobal(EDelMarVehicleCollisionOverrideSetting& NewValue); // 0xcf8da58 (Index: 0x64, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSetVerticalKickflipInverted(bool& InbVerticalKickflipInverted); // 0x9e6e1b8 (Index: 0x65, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSkipWaitingForPlayers(); // 0x554e3c4 (Index: 0x66, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSpawnBots(int32_t& NumberOfBotsToSpawn); // 0xa5dc3cc (Index: 0x67, Flags: Final|Exec|Native|Protected)
    void DelMarSpawnBotsAtSkillLevel(int32_t& NumberOfBotsToSpawn, int32_t& SkillLevel); // 0xc06c0bc (Index: 0x68, Flags: Final|Exec|Native|Protected)
    void DelMarSpawnVehicleForSelf(); // 0x554e3c4 (Index: 0x69, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarSpectate(); // 0x554e3c4 (Index: 0x6a, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarStartFollowTrack(float& Throttle); // 0xa35c334 (Index: 0x6b, Flags: Final|Exec|Native|Protected)
    void DelMarStartQueuedAutoInput(); // 0x554e3c4 (Index: 0x6c, Flags: Final|Exec|Native|Protected)
    void DelMarStartRace(); // 0x554e3c4 (Index: 0x6d, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarStartTrackScrubberWithViewTarget(bool& bRunCsvProfilerDuringScrub) const; // 0x9e6e1b8 (Index: 0x6e, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected|Const)
    void DelMarTeleportToNextCheckpoint_ParallelPath(int32_t& const ParallelPathIndex); // 0xa5dc3cc (Index: 0x6f, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarTeleportToPreviousCheckpoint_ParallelPath(int32_t& const ParallelPathIndex); // 0xa5dc3cc (Index: 0x70, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Protected)
    void DelMarUsePredictiveInterpolation(bool& bEnabled, bool& bEveryOther); // 0xc2b3320 (Index: 0x71, Flags: Final|Exec|Native|Protected)
};

static_assert(sizeof(UDelMarCheatManager) == 0x38, "Size mismatch for UDelMarCheatManager");
static_assert(offsetof(UDelMarCheatManager, SafePlayerNames) == 0x28, "Offset mismatch for UDelMarCheatManager::SafePlayerNames");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarGlobals : public UObject
{
public:
};

static_assert(sizeof(UDelMarGlobals) == 0x28, "Size mismatch for UDelMarGlobals");

// Size: 0x2660 (Inherited: 0x40d8, Single: 0xffffe588)
class UDelMarVehicleCameraMode : public UFortCameraMode_AthenaVehicle
{
public:
    FDelMarVehicleCameraSettings CameraSettings; // 0x2030 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_204c[0x4]; // 0x204c (Size: 0x4, Type: PaddingProperty)
    FRuntimeFloatCurve VelocityViewDistance; // 0x2050 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve VelocityFOV; // 0x20d8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialViewDistance; // 0x2160 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialFocusOffset; // 0x21e8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AerialPitch; // 0x2270 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AccelViewDistance; // 0x22f8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AccelPitch; // 0x2380 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve AirRotationInterpRate; // 0x2408 (Size: 0x88, Type: StructProperty)
    float DriftSwivelSpeed; // 0x2490 (Size: 0x4, Type: FloatProperty)
    float ViewDistanceInterpSpeed; // 0x2494 (Size: 0x4, Type: FloatProperty)
    float FOVInterpSpeed; // 0x2498 (Size: 0x4, Type: FloatProperty)
    float AccelerationViewDistanceDecayRate; // 0x249c (Size: 0x4, Type: FloatProperty)
    float MaxAccumulatedAccelViewDistance; // 0x24a0 (Size: 0x4, Type: FloatProperty)
    float MinAccumulatedAccelViewDistance; // 0x24a4 (Size: 0x4, Type: FloatProperty)
    float AerialOffsetInterpSpeed; // 0x24a8 (Size: 0x4, Type: FloatProperty)
    float MaximumDownwardAerialPitch; // 0x24ac (Size: 0x4, Type: FloatProperty)
    float MaximumUpwardAerialPitch; // 0x24b0 (Size: 0x4, Type: FloatProperty)
    float AccelerationPitchDecayRate; // 0x24b4 (Size: 0x4, Type: FloatProperty)
    float MaxAccumulatedAccelPitch; // 0x24b8 (Size: 0x4, Type: FloatProperty)
    float MinAccumulatedAccelPitch; // 0x24bc (Size: 0x4, Type: FloatProperty)
    bool bPreventSpeedIncreaseInAir; // 0x24c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_24c1[0x3]; // 0x24c1 (Size: 0x3, Type: PaddingProperty)
    float SpeedInputScalar; // 0x24c4 (Size: 0x4, Type: FloatProperty)
    float SwivelPitchMax; // 0x24c8 (Size: 0x4, Type: FloatProperty)
    float SwivelYawMax; // 0x24cc (Size: 0x4, Type: FloatProperty)
    float GroundPitchInterpRate; // 0x24d0 (Size: 0x4, Type: FloatProperty)
    float GroundMaxPitchForNormalBlend; // 0x24d4 (Size: 0x4, Type: FloatProperty)
    float GroundNormalInterpRate; // 0x24d8 (Size: 0x4, Type: FloatProperty)
    float GroundNormalAirInterpRate; // 0x24dc (Size: 0x4, Type: FloatProperty)
    float GroundYawRateMin; // 0x24e0 (Size: 0x4, Type: FloatProperty)
    float GroundYawRateMax; // 0x24e4 (Size: 0x4, Type: FloatProperty)
    float WallYawRateMin; // 0x24e8 (Size: 0x4, Type: FloatProperty)
    float WallYawRateMax; // 0x24ec (Size: 0x4, Type: FloatProperty)
    float InterpToGroundTime; // 0x24f0 (Size: 0x4, Type: FloatProperty)
    float InterpToAirTime; // 0x24f4 (Size: 0x4, Type: FloatProperty)
    float AverageVelocityInterpRate; // 0x24f8 (Size: 0x4, Type: FloatProperty)
    float FocusOffsetInterpRate; // 0x24fc (Size: 0x4, Type: FloatProperty)
    float DistanceSpeedScale; // 0x2500 (Size: 0x4, Type: FloatProperty)
    float DistanceOffsetMin; // 0x2504 (Size: 0x4, Type: FloatProperty)
    float DistanceOffsetMax; // 0x2508 (Size: 0x4, Type: FloatProperty)
    float DistanceInterpRate; // 0x250c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedFOVOffset; // 0x2510 (Size: 0x4, Type: FloatProperty)
    float SupersonicFOVOffset; // 0x2514 (Size: 0x4, Type: FloatProperty)
    float FOVInterpRate; // 0x2518 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_251c[0x4]; // 0x251c (Size: 0x4, Type: PaddingProperty)
    ADelMarVehicle* VehicleTarget; // 0x2520 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2528[0x138]; // 0x2528 (Size: 0x138, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarVehicleCameraMode) == 0x2660, "Size mismatch for UDelMarVehicleCameraMode");
static_assert(offsetof(UDelMarVehicleCameraMode, CameraSettings) == 0x2030, "Offset mismatch for UDelMarVehicleCameraMode::CameraSettings");
static_assert(offsetof(UDelMarVehicleCameraMode, VelocityViewDistance) == 0x2050, "Offset mismatch for UDelMarVehicleCameraMode::VelocityViewDistance");
static_assert(offsetof(UDelMarVehicleCameraMode, VelocityFOV) == 0x20d8, "Offset mismatch for UDelMarVehicleCameraMode::VelocityFOV");
static_assert(offsetof(UDelMarVehicleCameraMode, AerialViewDistance) == 0x2160, "Offset mismatch for UDelMarVehicleCameraMode::AerialViewDistance");
static_assert(offsetof(UDelMarVehicleCameraMode, AerialFocusOffset) == 0x21e8, "Offset mismatch for UDelMarVehicleCameraMode::AerialFocusOffset");
static_assert(offsetof(UDelMarVehicleCameraMode, AerialPitch) == 0x2270, "Offset mismatch for UDelMarVehicleCameraMode::AerialPitch");
static_assert(offsetof(UDelMarVehicleCameraMode, AccelViewDistance) == 0x22f8, "Offset mismatch for UDelMarVehicleCameraMode::AccelViewDistance");
static_assert(offsetof(UDelMarVehicleCameraMode, AccelPitch) == 0x2380, "Offset mismatch for UDelMarVehicleCameraMode::AccelPitch");
static_assert(offsetof(UDelMarVehicleCameraMode, AirRotationInterpRate) == 0x2408, "Offset mismatch for UDelMarVehicleCameraMode::AirRotationInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, DriftSwivelSpeed) == 0x2490, "Offset mismatch for UDelMarVehicleCameraMode::DriftSwivelSpeed");
static_assert(offsetof(UDelMarVehicleCameraMode, ViewDistanceInterpSpeed) == 0x2494, "Offset mismatch for UDelMarVehicleCameraMode::ViewDistanceInterpSpeed");
static_assert(offsetof(UDelMarVehicleCameraMode, FOVInterpSpeed) == 0x2498, "Offset mismatch for UDelMarVehicleCameraMode::FOVInterpSpeed");
static_assert(offsetof(UDelMarVehicleCameraMode, AccelerationViewDistanceDecayRate) == 0x249c, "Offset mismatch for UDelMarVehicleCameraMode::AccelerationViewDistanceDecayRate");
static_assert(offsetof(UDelMarVehicleCameraMode, MaxAccumulatedAccelViewDistance) == 0x24a0, "Offset mismatch for UDelMarVehicleCameraMode::MaxAccumulatedAccelViewDistance");
static_assert(offsetof(UDelMarVehicleCameraMode, MinAccumulatedAccelViewDistance) == 0x24a4, "Offset mismatch for UDelMarVehicleCameraMode::MinAccumulatedAccelViewDistance");
static_assert(offsetof(UDelMarVehicleCameraMode, AerialOffsetInterpSpeed) == 0x24a8, "Offset mismatch for UDelMarVehicleCameraMode::AerialOffsetInterpSpeed");
static_assert(offsetof(UDelMarVehicleCameraMode, MaximumDownwardAerialPitch) == 0x24ac, "Offset mismatch for UDelMarVehicleCameraMode::MaximumDownwardAerialPitch");
static_assert(offsetof(UDelMarVehicleCameraMode, MaximumUpwardAerialPitch) == 0x24b0, "Offset mismatch for UDelMarVehicleCameraMode::MaximumUpwardAerialPitch");
static_assert(offsetof(UDelMarVehicleCameraMode, AccelerationPitchDecayRate) == 0x24b4, "Offset mismatch for UDelMarVehicleCameraMode::AccelerationPitchDecayRate");
static_assert(offsetof(UDelMarVehicleCameraMode, MaxAccumulatedAccelPitch) == 0x24b8, "Offset mismatch for UDelMarVehicleCameraMode::MaxAccumulatedAccelPitch");
static_assert(offsetof(UDelMarVehicleCameraMode, MinAccumulatedAccelPitch) == 0x24bc, "Offset mismatch for UDelMarVehicleCameraMode::MinAccumulatedAccelPitch");
static_assert(offsetof(UDelMarVehicleCameraMode, bPreventSpeedIncreaseInAir) == 0x24c0, "Offset mismatch for UDelMarVehicleCameraMode::bPreventSpeedIncreaseInAir");
static_assert(offsetof(UDelMarVehicleCameraMode, SpeedInputScalar) == 0x24c4, "Offset mismatch for UDelMarVehicleCameraMode::SpeedInputScalar");
static_assert(offsetof(UDelMarVehicleCameraMode, SwivelPitchMax) == 0x24c8, "Offset mismatch for UDelMarVehicleCameraMode::SwivelPitchMax");
static_assert(offsetof(UDelMarVehicleCameraMode, SwivelYawMax) == 0x24cc, "Offset mismatch for UDelMarVehicleCameraMode::SwivelYawMax");
static_assert(offsetof(UDelMarVehicleCameraMode, GroundPitchInterpRate) == 0x24d0, "Offset mismatch for UDelMarVehicleCameraMode::GroundPitchInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, GroundMaxPitchForNormalBlend) == 0x24d4, "Offset mismatch for UDelMarVehicleCameraMode::GroundMaxPitchForNormalBlend");
static_assert(offsetof(UDelMarVehicleCameraMode, GroundNormalInterpRate) == 0x24d8, "Offset mismatch for UDelMarVehicleCameraMode::GroundNormalInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, GroundNormalAirInterpRate) == 0x24dc, "Offset mismatch for UDelMarVehicleCameraMode::GroundNormalAirInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, GroundYawRateMin) == 0x24e0, "Offset mismatch for UDelMarVehicleCameraMode::GroundYawRateMin");
static_assert(offsetof(UDelMarVehicleCameraMode, GroundYawRateMax) == 0x24e4, "Offset mismatch for UDelMarVehicleCameraMode::GroundYawRateMax");
static_assert(offsetof(UDelMarVehicleCameraMode, WallYawRateMin) == 0x24e8, "Offset mismatch for UDelMarVehicleCameraMode::WallYawRateMin");
static_assert(offsetof(UDelMarVehicleCameraMode, WallYawRateMax) == 0x24ec, "Offset mismatch for UDelMarVehicleCameraMode::WallYawRateMax");
static_assert(offsetof(UDelMarVehicleCameraMode, InterpToGroundTime) == 0x24f0, "Offset mismatch for UDelMarVehicleCameraMode::InterpToGroundTime");
static_assert(offsetof(UDelMarVehicleCameraMode, InterpToAirTime) == 0x24f4, "Offset mismatch for UDelMarVehicleCameraMode::InterpToAirTime");
static_assert(offsetof(UDelMarVehicleCameraMode, AverageVelocityInterpRate) == 0x24f8, "Offset mismatch for UDelMarVehicleCameraMode::AverageVelocityInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, FocusOffsetInterpRate) == 0x24fc, "Offset mismatch for UDelMarVehicleCameraMode::FocusOffsetInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, DistanceSpeedScale) == 0x2500, "Offset mismatch for UDelMarVehicleCameraMode::DistanceSpeedScale");
static_assert(offsetof(UDelMarVehicleCameraMode, DistanceOffsetMin) == 0x2504, "Offset mismatch for UDelMarVehicleCameraMode::DistanceOffsetMin");
static_assert(offsetof(UDelMarVehicleCameraMode, DistanceOffsetMax) == 0x2508, "Offset mismatch for UDelMarVehicleCameraMode::DistanceOffsetMax");
static_assert(offsetof(UDelMarVehicleCameraMode, DistanceInterpRate) == 0x250c, "Offset mismatch for UDelMarVehicleCameraMode::DistanceInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, MaxSpeedFOVOffset) == 0x2510, "Offset mismatch for UDelMarVehicleCameraMode::MaxSpeedFOVOffset");
static_assert(offsetof(UDelMarVehicleCameraMode, SupersonicFOVOffset) == 0x2514, "Offset mismatch for UDelMarVehicleCameraMode::SupersonicFOVOffset");
static_assert(offsetof(UDelMarVehicleCameraMode, FOVInterpRate) == 0x2518, "Offset mismatch for UDelMarVehicleCameraMode::FOVInterpRate");
static_assert(offsetof(UDelMarVehicleCameraMode, VehicleTarget) == 0x2520, "Offset mismatch for UDelMarVehicleCameraMode::VehicleTarget");

// Size: 0xd0 (Inherited: 0x250, Single: 0xfffffe80)
class UDelMarEliminationRaceManagerComponent : public UDelMarRaceManagerComponent
{
public:
    TArray<FDelMarEliminationMMRCountPair> EliminationsConfig; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    int32_t ParsedNumberOfPlayersToEliminate; // 0xc8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarEliminationRaceManagerComponent) == 0xd0, "Size mismatch for UDelMarEliminationRaceManagerComponent");
static_assert(offsetof(UDelMarEliminationRaceManagerComponent, EliminationsConfig) == 0xb8, "Offset mismatch for UDelMarEliminationRaceManagerComponent::EliminationsConfig");
static_assert(offsetof(UDelMarEliminationRaceManagerComponent, ParsedNumberOfPlayersToEliminate) == 0xc8, "Offset mismatch for UDelMarEliminationRaceManagerComponent::ParsedNumberOfPlayersToEliminate");

// Size: 0x1e0 (Inherited: 0xe0, Single: 0x100)
class UDelMarStateSequencerFXComponent : public UActorComponent
{
public:
    float FXSizeScalar; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    TMap<UNiagaraSystem*, FGameplayTag> ParticleClassMap; // 0xc0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)
    FFXSystemSpawnParameters SpawnParams; // 0x118 (Size: 0x70, Type: StructProperty)
    ADelMarTimeDelayedStateSequencer* ParentRef; // 0x188 (Size: 0x8, Type: ObjectProperty)
    TMap<UNiagaraComponent*, FGameplayTag> ParticleComponentMap; // 0x190 (Size: 0x50, Type: MapProperty)

protected:
    void HandleCurrentStateChanged(FGameplayTag& NewState); // 0x11bce6e4 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleEnabledChanged(bool& bEnabled); // 0x11bce7a4 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarStateSequencerFXComponent) == 0x1e0, "Size mismatch for UDelMarStateSequencerFXComponent");
static_assert(offsetof(UDelMarStateSequencerFXComponent, FXSizeScalar) == 0xb8, "Offset mismatch for UDelMarStateSequencerFXComponent::FXSizeScalar");
static_assert(offsetof(UDelMarStateSequencerFXComponent, ParticleClassMap) == 0xc0, "Offset mismatch for UDelMarStateSequencerFXComponent::ParticleClassMap");
static_assert(offsetof(UDelMarStateSequencerFXComponent, SpawnParams) == 0x118, "Offset mismatch for UDelMarStateSequencerFXComponent::SpawnParams");
static_assert(offsetof(UDelMarStateSequencerFXComponent, ParentRef) == 0x188, "Offset mismatch for UDelMarStateSequencerFXComponent::ParentRef");
static_assert(offsetof(UDelMarStateSequencerFXComponent, ParticleComponentMap) == 0x190, "Offset mismatch for UDelMarStateSequencerFXComponent::ParticleComponentMap");

// Size: 0x2f8 (Inherited: 0x2d0, Single: 0x28)
class ADelMarTimeDelayedStateSequencer : public AActor
{
public:
    uint8_t OnCurrentStateChanged[0x10]; // 0x2a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnabledChanged[0x10]; // 0x2b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bEnableOnSpawn; // 0x2c8 (Size: 0x1, Type: BoolProperty)
    bool bLoopSpecificAmount; // 0x2c9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ca[0x2]; // 0x2ca (Size: 0x2, Type: PaddingProperty)
    int32_t TotalLoopCount; // 0x2cc (Size: 0x4, Type: IntProperty)
    TArray<FDelMarTimeDelayedState> StateArray; // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2e0[0xc]; // 0x2e0 (Size: 0xc, Type: PaddingProperty)
    bool bIsEnabled; // 0x2ec (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ed[0x3]; // 0x2ed (Size: 0x3, Type: PaddingProperty)
    int32_t CurrentStateIndex; // 0x2f0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2f4[0x4]; // 0x2f4 (Size: 0x4, Type: PaddingProperty)

public:
    FGameplayTag GetCurrentStateTag() const; // 0x11bce4a0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetStateCount() const; // 0xd828e3c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetStateTagAtIndex(int32_t& const Index) const; // 0x11bce4c8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetEnabled(bool& const bEnabled); // 0x11bcf2b0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_bIsEnabled(); // 0x11bcf29c (Index: 0x3, Flags: Final|Native|Protected)
    void OnRep_CurrentStateIndex(); // 0x11bcf274 (Index: 0x4, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarTimeDelayedStateSequencer) == 0x2f8, "Size mismatch for ADelMarTimeDelayedStateSequencer");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, OnCurrentStateChanged) == 0x2a8, "Offset mismatch for ADelMarTimeDelayedStateSequencer::OnCurrentStateChanged");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, OnEnabledChanged) == 0x2b8, "Offset mismatch for ADelMarTimeDelayedStateSequencer::OnEnabledChanged");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, bEnableOnSpawn) == 0x2c8, "Offset mismatch for ADelMarTimeDelayedStateSequencer::bEnableOnSpawn");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, bLoopSpecificAmount) == 0x2c9, "Offset mismatch for ADelMarTimeDelayedStateSequencer::bLoopSpecificAmount");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, TotalLoopCount) == 0x2cc, "Offset mismatch for ADelMarTimeDelayedStateSequencer::TotalLoopCount");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, StateArray) == 0x2d0, "Offset mismatch for ADelMarTimeDelayedStateSequencer::StateArray");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, bIsEnabled) == 0x2ec, "Offset mismatch for ADelMarTimeDelayedStateSequencer::bIsEnabled");
static_assert(offsetof(ADelMarTimeDelayedStateSequencer, CurrentStateIndex) == 0x2f0, "Offset mismatch for ADelMarTimeDelayedStateSequencer::CurrentStateIndex");

// Size: 0x2200 (Inherited: 0x2c08, Single: 0xfffff5f8)
class ADelMarGhostVehicle : public AFortAthenaVehicle
{
public:
    uint8_t Pad_2120[0x78]; // 0x2120 (Size: 0x78, Type: PaddingProperty)
    UMaterial* GhostMaterial; // 0x2198 (Size: 0x8, Type: ObjectProperty)
    int32_t NumAllowedVehicleCosmeticChanges; // 0x21a0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_21a4[0x5c]; // 0x21a4 (Size: 0x5c, Type: PaddingProperty)

protected:
    void HandleFinishVehicleCosmeticsEvent(const FVehicleCosmeticsFinishedPayload Payload); // 0x11bce8d0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void VehicleCosmeticsPartUpdated(int32_t& PartIndex); // 0x11bcf768 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarGhostVehicle) == 0x2200, "Size mismatch for ADelMarGhostVehicle");
static_assert(offsetof(ADelMarGhostVehicle, GhostMaterial) == 0x2198, "Offset mismatch for ADelMarGhostVehicle::GhostMaterial");
static_assert(offsetof(ADelMarGhostVehicle, NumAllowedVehicleCosmeticChanges) == 0x21a0, "Offset mismatch for ADelMarGhostVehicle::NumAllowedVehicleCosmeticChanges");

// Size: 0xf0 (Inherited: 0x250, Single: 0xfffffea0)
class UDelMarGlobalInputDisabler : public UDelMarRaceManagerComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    FGameplayTagContainer DisabledInputTags; // 0xd0 (Size: 0x20, Type: StructProperty)

public:
    void SetGlobalInputsEnabled(FGameplayTagContainer& InputTags, bool& const bEnable); // 0x11bcf3dc (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarGlobalInputDisabler) == 0xf0, "Size mismatch for UDelMarGlobalInputDisabler");
static_assert(offsetof(UDelMarGlobalInputDisabler, DisabledInputTags) == 0xd0, "Offset mismatch for UDelMarGlobalInputDisabler::DisabledInputTags");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarCosmeticActorSpawnLogic : public UObject
{
public:
};

static_assert(sizeof(UDelMarCosmeticActorSpawnLogic) == 0x28, "Size mismatch for UDelMarCosmeticActorSpawnLogic");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarCosmeticActorSpawnLogic_AttachTo : public UDelMarCosmeticActorSpawnLogic
{
public:
    FName AttachSocket; // 0x28 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarCosmeticActorSpawnLogic_AttachTo) == 0x30, "Size mismatch for UDelMarCosmeticActorSpawnLogic_AttachTo");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_AttachTo, AttachSocket) == 0x28, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_AttachTo::AttachSocket");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UDelMarCosmeticActorSpawnLogic_AttachToEach : public UDelMarCosmeticActorSpawnLogic
{
public:
    TArray<FName> AttachSockets; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarCosmeticActorSpawnLogic_AttachToEach) == 0x38, "Size mismatch for UDelMarCosmeticActorSpawnLogic_AttachToEach");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_AttachToEach, AttachSockets) == 0x28, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_AttachToEach::AttachSockets");

// Size: 0x2e0 (Inherited: 0x2d0, Single: 0x10)
class ADelMarCosmeticActor : public AActor
{
public:
    UDelMarCosmeticActorSpawnLogic* SpawnLogic; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> CosmeticDependencies; // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TScriptInterface<Class> Vehicle; // 0x2c0 (Size: 0x10, Type: InterfaceProperty)
    UDelMarVehicleConfigs* VehicleConfig; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleCosmeticComponent* VehicleCosmeticComponent; // 0x2d8 (Size: 0x8, Type: ObjectProperty)

public:
    void ApplyCosmetic(); // 0x328ca4c (Index: 0x0, Flags: Native|Public)

protected:
    virtual void BP_OnAnyWheelsOnGroundChanged(const TScriptInterface<Class> VehicleRef, bool& bValue); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_OnBonusSpeedActivated(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnBonusSpeedChanged(float& BonusSpeed); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnBonusSpeedDeactivated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnCosmeticApplied(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDelMarAppliedTeleportRotation(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDelMarTeleportEntered(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDelMarTeleportExited(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDelMarVehicleSpawned(bool& bFirstVehicleForPlayer, bool& bPrevVehicleDemolished); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDraftStateChanged(EDelmarDraftingState& CurrentState); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftActivated(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftBoostActivated(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftBoostDeactivated(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftControlChanged(bool& bIsDriftingControlled); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftDeactivated(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftDurationChanged(float& duration); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftKickActivated(float& DriftDirection, EDelMarVehicleDriftState& DriftState); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDriftKickDeactivated(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnInvulnerabilityActivated(); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnInvulnerabilityDeactivated(); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnJumpActivated(); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnJumpDeactivated(); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipActivated(bool& bLeftSide); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipActivationChargesChanged(int32_t& ActivationCharges); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipDeactivated(); // 0x288a61c (Index: 0x19, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipDistanceToSuctionSurfaceChanged(float& Distance); // 0x288a61c (Index: 0x1a, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipDurationChanged(float& duration); // 0x288a61c (Index: 0x1b, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipSuctionActivated(); // 0x288a61c (Index: 0x1c, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnKickflipSuctionDeactivated(); // 0x288a61c (Index: 0x1d, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnReachedMaxDraftBonusSpeed(); // 0x288a61c (Index: 0x1e, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnReattachmentActivated(); // 0x288a61c (Index: 0x1f, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnReattachmentDeactivated(); // 0x288a61c (Index: 0x20, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStartlineBoostActivated(float& PercentageMaxBonusSpeedEarned); // 0x288a61c (Index: 0x21, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStartlineBoostDeactivated(); // 0x288a61c (Index: 0x22, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStartlineBoostFailed(); // 0x288a61c (Index: 0x23, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStrafeActivated(bool& bLeftSide); // 0x288a61c (Index: 0x24, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStrafeCooldownChanged(float& CooldownPercentage); // 0x288a61c (Index: 0x25, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStrafeDeactivated(); // 0x288a61c (Index: 0x26, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStrafeDisabledChanged(bool& bDisabled); // 0x288a61c (Index: 0x27, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnStrafeUsabilityChanged(bool& bCanActivate); // 0x288a61c (Index: 0x28, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnTurboActivated(); // 0x288a61c (Index: 0x29, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnTurboBonusStateChanged(EDelMarTurboZoneState& NewState); // 0x288a61c (Index: 0x2a, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnTurboDeactivated(); // 0x288a61c (Index: 0x2b, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnderthrustActivated(); // 0x288a61c (Index: 0x2c, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnderthrustDeactivated(); // 0x288a61c (Index: 0x2d, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnVehicleDemolished(FGameplayTag& CausedByTag); // 0x288a61c (Index: 0x2e, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnVehicleForwardStateChanged(EDelMarVehicleForwardState& NewForwardState); // 0x288a61c (Index: 0x2f, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnVehicleLanded(float& LandingForced, bool& bLandedKickflip); // 0x288a61c (Index: 0x30, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnVehicleStartedSkydiving(); // 0x288a61c (Index: 0x31, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnVehicleStoppedSkydiving(); // 0x288a61c (Index: 0x32, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnVehicleWheelsLeftGround(); // 0x288a61c (Index: 0x33, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnWheelsOnGroundChanged(const TScriptInterface<Class> VehicleRef, bool& bValue); // 0x288a61c (Index: 0x34, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_OnWorldBonusSpeedStackGained(FGameplayTag& Source, int32_t& Stacks); // 0x288a61c (Index: 0x35, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnWorldBonusSpeedStackLost(FGameplayTag& Source, int32_t& Stacks); // 0x288a61c (Index: 0x36, Flags: Event|Protected|BlueprintEvent)
    USkeletalMeshComponent* GetBodyMeshComponent() const; // 0x11bce47c (Index: 0x37, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsLocallyViewed() const; // 0x11bcf1f8 (Index: 0x38, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ADelMarCosmeticActor) == 0x2e0, "Size mismatch for ADelMarCosmeticActor");
static_assert(offsetof(ADelMarCosmeticActor, SpawnLogic) == 0x2a8, "Offset mismatch for ADelMarCosmeticActor::SpawnLogic");
static_assert(offsetof(ADelMarCosmeticActor, CosmeticDependencies) == 0x2b0, "Offset mismatch for ADelMarCosmeticActor::CosmeticDependencies");
static_assert(offsetof(ADelMarCosmeticActor, Vehicle) == 0x2c0, "Offset mismatch for ADelMarCosmeticActor::Vehicle");
static_assert(offsetof(ADelMarCosmeticActor, VehicleConfig) == 0x2d0, "Offset mismatch for ADelMarCosmeticActor::VehicleConfig");
static_assert(offsetof(ADelMarCosmeticActor, VehicleCosmeticComponent) == 0x2d8, "Offset mismatch for ADelMarCosmeticActor::VehicleCosmeticComponent");

// Size: 0x148 (Inherited: 0x3b8, Single: 0xfffffd90)
class UDelMarCosmeticItemDefinition : public UFortAccountItemDefinition
{
public:
    FGameplayTag Slot; // 0x130 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_134[0x4]; // 0x134 (Size: 0x4, Type: PaddingProperty)
    TArray<TSoftClassPtr> CosmeticActorClasses; // 0x138 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarCosmeticItemDefinition) == 0x148, "Size mismatch for UDelMarCosmeticItemDefinition");
static_assert(offsetof(UDelMarCosmeticItemDefinition, Slot) == 0x130, "Offset mismatch for UDelMarCosmeticItemDefinition::Slot");
static_assert(offsetof(UDelMarCosmeticItemDefinition, CosmeticActorClasses) == 0x138, "Offset mismatch for UDelMarCosmeticItemDefinition::CosmeticActorClasses");

// Size: 0x148 (Inherited: 0x500, Single: 0xfffffc48)
class UDelMarVehicleBodyItemDefinition : public UDelMarCosmeticItemDefinition
{
public:
};

static_assert(sizeof(UDelMarVehicleBodyItemDefinition) == 0x148, "Size mismatch for UDelMarVehicleBodyItemDefinition");

// Size: 0x280 (Inherited: 0x250, Single: 0x30)
class UDelMarLeaderboardManager : public UDelMarRaceManagerComponent
{
public:
    FString CurrentSeasonIdentifier; // 0xb8 (Size: 0x10, Type: StrProperty)
    UDelMarEvent_GlobalLeaderboardPersonalBestRetrieved* PersonalBestRetrievedEvent; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x70]; // 0xd0 (Size: 0x70, Type: PaddingProperty)
    FDelMarLeaderboardConfig LeaderboardConfig; // 0x140 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_160[0x120]; // 0x160 (Size: 0x120, Type: PaddingProperty)

private:
    void OnRep_LeaderboardConfig(); // 0x11bcf288 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UDelMarLeaderboardManager) == 0x280, "Size mismatch for UDelMarLeaderboardManager");
static_assert(offsetof(UDelMarLeaderboardManager, CurrentSeasonIdentifier) == 0xb8, "Offset mismatch for UDelMarLeaderboardManager::CurrentSeasonIdentifier");
static_assert(offsetof(UDelMarLeaderboardManager, PersonalBestRetrievedEvent) == 0xc8, "Offset mismatch for UDelMarLeaderboardManager::PersonalBestRetrievedEvent");
static_assert(offsetof(UDelMarLeaderboardManager, LeaderboardConfig) == 0x140, "Offset mismatch for UDelMarLeaderboardManager::LeaderboardConfig");

// Size: 0xb8 (Inherited: 0x250, Single: 0xfffffe68)
class UDelMarMatchmakingComponent : public UControllerComponent
{
public:

public:
    virtual void ClientStartMatchmaking(FOnlineLinkId& const LinkId); // 0x11bce1f8 (Index: 0x0, Flags: Net|NetReliableNative|Event|Public|NetClient)
};

static_assert(sizeof(UDelMarMatchmakingComponent) == 0xb8, "Size mismatch for UDelMarMatchmakingComponent");

// Size: 0x2a8 (Inherited: 0x2d0, Single: 0xffffffd8)
class ADelMarGameplayModifier : public AActor
{
public:
};

static_assert(sizeof(ADelMarGameplayModifier) == 0x2a8, "Size mismatch for ADelMarGameplayModifier");

// Size: 0x2b8 (Inherited: 0x578, Single: 0xfffffd40)
class ADelMarGameplayModifier_AttachmentManager : public ADelMarGameplayModifier
{
public:
};

static_assert(sizeof(ADelMarGameplayModifier_AttachmentManager) == 0x2b8, "Size mismatch for ADelMarGameplayModifier_AttachmentManager");

// Size: 0x2d8 (Inherited: 0x578, Single: 0xfffffd60)
class ADelMarGameplayModifier_CVarOverride : public ADelMarGameplayModifier
{
public:
    FString VariableName; // 0x2a8 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x2b8 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_2c8[0x10]; // 0x2c8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarGameplayModifier_CVarOverride) == 0x2d8, "Size mismatch for ADelMarGameplayModifier_CVarOverride");
static_assert(offsetof(ADelMarGameplayModifier_CVarOverride, VariableName) == 0x2a8, "Offset mismatch for ADelMarGameplayModifier_CVarOverride::VariableName");
static_assert(offsetof(ADelMarGameplayModifier_CVarOverride, Value) == 0x2b8, "Offset mismatch for ADelMarGameplayModifier_CVarOverride::Value");

// Size: 0x2b0 (Inherited: 0x578, Single: 0xfffffd38)
class ADelMarGameplayModifier_FriendlyFire : public ADelMarGameplayModifier
{
public:
    uint8_t FriendlyFireType; // 0x2a8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarGameplayModifier_FriendlyFire) == 0x2b0, "Size mismatch for ADelMarGameplayModifier_FriendlyFire");
static_assert(offsetof(ADelMarGameplayModifier_FriendlyFire, FriendlyFireType) == 0x2a8, "Offset mismatch for ADelMarGameplayModifier_FriendlyFire::FriendlyFireType");

// Size: 0x300 (Inherited: 0x578, Single: 0xfffffd88)
class ADelMarGameplayModifier_PlacementSpawner : public ADelMarGameplayModifier
{
public:
    UClass* ActorClassToSpawn; // 0x2a8 (Size: 0x8, Type: ClassProperty)
    int32_t MaxPlacement; // 0x2b0 (Size: 0x4, Type: IntProperty)
    float SecondsBetweenSpawns; // 0x2b4 (Size: 0x4, Type: FloatProperty)
    float RaceStartDelaySeconds; // 0x2b8 (Size: 0x4, Type: FloatProperty)
    float ActorLifespanSeconds; // 0x2bc (Size: 0x4, Type: FloatProperty)
    float ActorDisplacementUnits; // 0x2c0 (Size: 0x4, Type: FloatProperty)
    int32_t MaxSpawnedActors; // 0x2c4 (Size: 0x4, Type: IntProperty)
    float MinSpeedForVelocityOrientation; // 0x2c8 (Size: 0x4, Type: FloatProperty)
    int32_t SpawnPoints; // 0x2cc (Size: 0x4, Type: IntProperty)
    int32_t TriggerPoints; // 0x2d0 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0x2d4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> CachedPositionComponent; // 0x2dc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_2e4[0x1c]; // 0x2e4 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarGameplayModifier_PlacementSpawner) == 0x300, "Size mismatch for ADelMarGameplayModifier_PlacementSpawner");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, ActorClassToSpawn) == 0x2a8, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::ActorClassToSpawn");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, MaxPlacement) == 0x2b0, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::MaxPlacement");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, SecondsBetweenSpawns) == 0x2b4, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::SecondsBetweenSpawns");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, RaceStartDelaySeconds) == 0x2b8, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::RaceStartDelaySeconds");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, ActorLifespanSeconds) == 0x2bc, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::ActorLifespanSeconds");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, ActorDisplacementUnits) == 0x2c0, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::ActorDisplacementUnits");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, MaxSpawnedActors) == 0x2c4, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::MaxSpawnedActors");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, MinSpeedForVelocityOrientation) == 0x2c8, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::MinSpeedForVelocityOrientation");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, SpawnPoints) == 0x2cc, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::SpawnPoints");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, TriggerPoints) == 0x2d0, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::TriggerPoints");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, CachedRaceManager) == 0x2d4, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::CachedRaceManager");
static_assert(offsetof(ADelMarGameplayModifier_PlacementSpawner, CachedPositionComponent) == 0x2dc, "Offset mismatch for ADelMarGameplayModifier_PlacementSpawner::CachedPositionComponent");

// Size: 0x2c8 (Inherited: 0x578, Single: 0xfffffd50)
class ADelMarGameplayModifier_VehicleClassOverride : public ADelMarGameplayModifier
{
public:
    TSoftClassPtr VehicleClassOverride; // 0x2a8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(ADelMarGameplayModifier_VehicleClassOverride) == 0x2c8, "Size mismatch for ADelMarGameplayModifier_VehicleClassOverride");
static_assert(offsetof(ADelMarGameplayModifier_VehicleClassOverride, VehicleClassOverride) == 0x2a8, "Offset mismatch for ADelMarGameplayModifier_VehicleClassOverride::VehicleClassOverride");

// Size: 0x368 (Inherited: 0xf28, Single: 0xfffff440)
class ADelMarMutator_AllowSpectateOtherTeams : public AFortAthenaMutator_AllowSpectateOtherTeams
{
public:
};

static_assert(sizeof(ADelMarMutator_AllowSpectateOtherTeams) == 0x368, "Size mismatch for ADelMarMutator_AllowSpectateOtherTeams");

// Size: 0x378 (Inherited: 0xf28, Single: 0xfffff450)
class ADelMarAsyncPhysicsTickMutator : public ADelMarMutator
{
public:
    float AsyncTickRate; // 0x368 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_36c[0xc]; // 0x36c (Size: 0xc, Type: PaddingProperty)

protected:
    void TryToApplySolverOverrides(); // 0x11bcf754 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarAsyncPhysicsTickMutator) == 0x378, "Size mismatch for ADelMarAsyncPhysicsTickMutator");
static_assert(offsetof(ADelMarAsyncPhysicsTickMutator, AsyncTickRate) == 0x368, "Offset mismatch for ADelMarAsyncPhysicsTickMutator::AsyncTickRate");

// Size: 0x398 (Inherited: 0xf28, Single: 0xfffff470)
class ADelMarConsoleVariableMutator : public ADelMarMutator
{
public:
    FString VariableName; // 0x368 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x378 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_388[0x10]; // 0x388 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarConsoleVariableMutator) == 0x398, "Size mismatch for ADelMarConsoleVariableMutator");
static_assert(offsetof(ADelMarConsoleVariableMutator, VariableName) == 0x368, "Offset mismatch for ADelMarConsoleVariableMutator::VariableName");
static_assert(offsetof(ADelMarConsoleVariableMutator, Value) == 0x378, "Offset mismatch for ADelMarConsoleVariableMutator::Value");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UDelMarPhysMatAttributeMap : public UDataAsset
{
public:
    TMap<FPhysicalMaterialAttributes_X, UPhysicalMaterial*> MaterialAttributesMap; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarPhysMatAttributeMap) == 0x80, "Size mismatch for UDelMarPhysMatAttributeMap");
static_assert(offsetof(UDelMarPhysMatAttributeMap, MaterialAttributesMap) == 0x30, "Offset mismatch for UDelMarPhysMatAttributeMap::MaterialAttributesMap");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class UDelMarCameraComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<UDelMarVehicleManager*> VehicleManager; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarCameraComponent) == 0xc0, "Size mismatch for UDelMarCameraComponent");
static_assert(offsetof(UDelMarCameraComponent, VehicleManager) == 0xb8, "Offset mismatch for UDelMarCameraComponent::VehicleManager");

// Size: 0x118 (Inherited: 0x250, Single: 0xfffffec8)
class UDelMarCameraInputControllerComponent : public UControllerComponent
{
public:
    FDelMarInputAction TurnCameraAction; // 0xb8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction LookUpCameraAction; // 0xc8 (Size: 0x10, Type: StructProperty)
    FDelMarInputAction ReverseCameraAction; // 0xd8 (Size: 0x10, Type: StructProperty)
    UClass* InputManagerClass; // 0xe8 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UEnhancedInputComponent*> InputComponent; // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortClientSettingsRecord*> FortSettings; // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_100[0x18]; // 0x100 (Size: 0x18, Type: PaddingProperty)

protected:
    void HandleCameraSwivelDeadzoneChanged(); // 0x11bce5f8 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleInputSettingsChanged(); // 0x11bce99c (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarCameraInputControllerComponent) == 0x118, "Size mismatch for UDelMarCameraInputControllerComponent");
static_assert(offsetof(UDelMarCameraInputControllerComponent, TurnCameraAction) == 0xb8, "Offset mismatch for UDelMarCameraInputControllerComponent::TurnCameraAction");
static_assert(offsetof(UDelMarCameraInputControllerComponent, LookUpCameraAction) == 0xc8, "Offset mismatch for UDelMarCameraInputControllerComponent::LookUpCameraAction");
static_assert(offsetof(UDelMarCameraInputControllerComponent, ReverseCameraAction) == 0xd8, "Offset mismatch for UDelMarCameraInputControllerComponent::ReverseCameraAction");
static_assert(offsetof(UDelMarCameraInputControllerComponent, InputManagerClass) == 0xe8, "Offset mismatch for UDelMarCameraInputControllerComponent::InputManagerClass");
static_assert(offsetof(UDelMarCameraInputControllerComponent, InputComponent) == 0xf0, "Offset mismatch for UDelMarCameraInputControllerComponent::InputComponent");
static_assert(offsetof(UDelMarCameraInputControllerComponent, FortSettings) == 0xf8, "Offset mismatch for UDelMarCameraInputControllerComponent::FortSettings");

// Size: 0x1b0 (Inherited: 0x250, Single: 0xffffff60)
class UDelMarContextualHintComponent : public UControllerComponent
{
public:
    FDelMarEvent_SetTutorialHint HazardHitHint; // 0xb8 (Size: 0x48, Type: StructProperty)
    TMap<FDelMarEvent_SetTutorialHint, FGameplayTag> DemolishedByHints; // 0x100 (Size: 0x50, Type: MapProperty)
    FDelMarEvent_SetTutorialHint SlowerTerrainHint; // 0x150 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<ADelMarVehicle*> Vehicle; // 0x198 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerController*> CachedPlayerController; // 0x1a0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)

private:
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11bcea98 (Index: 0x0, Flags: Final|Native|Private)
    void HandleVehicleHazardHit(); // 0x11bceb58 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UDelMarContextualHintComponent) == 0x1b0, "Size mismatch for UDelMarContextualHintComponent");
static_assert(offsetof(UDelMarContextualHintComponent, HazardHitHint) == 0xb8, "Offset mismatch for UDelMarContextualHintComponent::HazardHitHint");
static_assert(offsetof(UDelMarContextualHintComponent, DemolishedByHints) == 0x100, "Offset mismatch for UDelMarContextualHintComponent::DemolishedByHints");
static_assert(offsetof(UDelMarContextualHintComponent, SlowerTerrainHint) == 0x150, "Offset mismatch for UDelMarContextualHintComponent::SlowerTerrainHint");
static_assert(offsetof(UDelMarContextualHintComponent, Vehicle) == 0x198, "Offset mismatch for UDelMarContextualHintComponent::Vehicle");
static_assert(offsetof(UDelMarContextualHintComponent, CachedPlayerController) == 0x1a0, "Offset mismatch for UDelMarContextualHintComponent::CachedPlayerController");

// Size: 0x130 (Inherited: 0x250, Single: 0xfffffee0)
class UDelMarLocalCheckpointVisibilityControllerComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> ViewTargetPlayerState; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> CachedLocalPlayerState; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TSet<ADelMarCheckpoint*> CurrentlyActiveCheckpoints; // 0xd8 (Size: 0x50, Type: SetProperty)
    bool bVisitedStartingCheckpoint; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x7]; // 0x129 (Size: 0x7, Type: PaddingProperty)

protected:
    void HandleCheckpointPassed(const FDelMarEvent_CheckpointPassed_ParallelPath CheckpointEvent); // 0x11bce60c (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandleLapComplete(const FDelMarEvent_LapComplete LapEvent); // 0x11bce9b0 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void HandleViewTargetChanged(AFortPlayerController*& PlayerController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11bceb6c (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarLocalCheckpointVisibilityControllerComponent) == 0x130, "Size mismatch for UDelMarLocalCheckpointVisibilityControllerComponent");
static_assert(offsetof(UDelMarLocalCheckpointVisibilityControllerComponent, CachedRaceManager) == 0xb8, "Offset mismatch for UDelMarLocalCheckpointVisibilityControllerComponent::CachedRaceManager");
static_assert(offsetof(UDelMarLocalCheckpointVisibilityControllerComponent, CachedCheckpointManager) == 0xc0, "Offset mismatch for UDelMarLocalCheckpointVisibilityControllerComponent::CachedCheckpointManager");
static_assert(offsetof(UDelMarLocalCheckpointVisibilityControllerComponent, ViewTargetPlayerState) == 0xc8, "Offset mismatch for UDelMarLocalCheckpointVisibilityControllerComponent::ViewTargetPlayerState");
static_assert(offsetof(UDelMarLocalCheckpointVisibilityControllerComponent, CachedLocalPlayerState) == 0xd0, "Offset mismatch for UDelMarLocalCheckpointVisibilityControllerComponent::CachedLocalPlayerState");
static_assert(offsetof(UDelMarLocalCheckpointVisibilityControllerComponent, CurrentlyActiveCheckpoints) == 0xd8, "Offset mismatch for UDelMarLocalCheckpointVisibilityControllerComponent::CurrentlyActiveCheckpoints");
static_assert(offsetof(UDelMarLocalCheckpointVisibilityControllerComponent, bVisitedStartingCheckpoint) == 0x128, "Offset mismatch for UDelMarLocalCheckpointVisibilityControllerComponent::bVisitedStartingCheckpoint");

// Size: 0x118 (Inherited: 0x250, Single: 0xfffffec8)
class UDelMarNetworkInputComponent : public UControllerComponent
{
public:

private:
    virtual void ServerSendInputs(FDelMarNetworkInputPacket& const InputPacket); // 0x11c27fb8 (Index: 0x0, Flags: Final|Net|Native|Event|Private|NetServer|NetValidate)
};

static_assert(sizeof(UDelMarNetworkInputComponent) == 0x118, "Size mismatch for UDelMarNetworkInputComponent");

// Size: 0xc0 (Inherited: 0x308, Single: 0xfffffdb8)
class UDelMarPlayerAttachmentComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<AFortPlayerState*> AttachedPlayer; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)

protected:
    void OnRep_AttachedPlayer(TWeakObjectPtr<AFortPlayerState*>& PrevPlayer); // 0x11c261d4 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerAttachmentComponent) == 0xc0, "Size mismatch for UDelMarPlayerAttachmentComponent");
static_assert(offsetof(UDelMarPlayerAttachmentComponent, AttachedPlayer) == 0xb8, "Offset mismatch for UDelMarPlayerAttachmentComponent::AttachedPlayer");

// Size: 0x280 (Inherited: 0x580, Single: 0xfffffd00)
class UDelMarPlayerDeathRaceDataComponent : public UDelMarPlayerRaceDataComponent
{
public:
    int32_t Score; // 0x278 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_27c[0x4]; // 0x27c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarPlayerDeathRaceDataComponent) == 0x280, "Size mismatch for UDelMarPlayerDeathRaceDataComponent");
static_assert(offsetof(UDelMarPlayerDeathRaceDataComponent, Score) == 0x278, "Offset mismatch for UDelMarPlayerDeathRaceDataComponent::Score");

// Size: 0x128 (Inherited: 0x308, Single: 0xfffffe20)
class UDelMarPlayerInputManagerComponent : public UDelMarPlayerStateComponent
{
public:
    TMap<FDelMarInputMappingContextData, FGameplayTag> InputMappingContextMap; // 0xb8 (Size: 0x50, Type: MapProperty)
    UDelMarInputContextRedirectMap* PlatformDigitalRedirect; // 0x108 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedController; // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0x120 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarPlayerInputManagerComponent) == 0x128, "Size mismatch for UDelMarPlayerInputManagerComponent");
static_assert(offsetof(UDelMarPlayerInputManagerComponent, InputMappingContextMap) == 0xb8, "Offset mismatch for UDelMarPlayerInputManagerComponent::InputMappingContextMap");
static_assert(offsetof(UDelMarPlayerInputManagerComponent, PlatformDigitalRedirect) == 0x108, "Offset mismatch for UDelMarPlayerInputManagerComponent::PlatformDigitalRedirect");
static_assert(offsetof(UDelMarPlayerInputManagerComponent, CachedController) == 0x110, "Offset mismatch for UDelMarPlayerInputManagerComponent::CachedController");
static_assert(offsetof(UDelMarPlayerInputManagerComponent, CachedVehicle) == 0x118, "Offset mismatch for UDelMarPlayerInputManagerComponent::CachedVehicle");
static_assert(offsetof(UDelMarPlayerInputManagerComponent, CachedRaceManager) == 0x120, "Offset mismatch for UDelMarPlayerInputManagerComponent::CachedRaceManager");

// Size: 0x1d0 (Inherited: 0x308, Single: 0xfffffec8)
class UDelMarPlayerRespawnComponent : public UDelMarPlayerStateComponent
{
public:
    float TeleportEnterPhaseSeconds; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float RespawnBackwardsRangeDistance; // 0xbc (Size: 0x4, Type: FloatProperty)
    float RespawnForwardRangeDistance; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float RespawnHeightStartDistance; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float RespawnHeightPenetrationDistance; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float RespawnValidTrackRadius; // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bCheckForObstacles; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x3]; // 0xd1 (Size: 0x3, Type: PaddingProperty)
    float OppositeSideThreshold; // 0xd4 (Size: 0x4, Type: FloatProperty)
    FVector ObstacleAreaBounds; // 0xd8 (Size: 0x18, Type: StructProperty)
    TArray<UClass*> ObstacleActorClasses; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ObstacleActorIgnoreClasses; // 0x100 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle; // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CheckpointManager; // 0x120 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerRaceDataComponent*> PlayerRaceData; // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRaceConfigComponent*> RaceConfig; // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrack*> LastActiveTrack; // 0x138 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackPositionComponent*> TrackPosition; // 0x140 (Size: 0x8, Type: WeakObjectProperty)
    int32_t LastValidSegmentIndex; // 0x148 (Size: 0x4, Type: IntProperty)
    float LastValidDistanceAlongSpline; // 0x14c (Size: 0x4, Type: FloatProperty)
    float LastValidFurthestDistance; // 0x150 (Size: 0x4, Type: FloatProperty)
    bool bSpawnOnOppositeSide; // 0x154 (Size: 0x1, Type: BoolProperty)
    bool bPreviousVehicleDemolished; // 0x155 (Size: 0x1, Type: BoolProperty)
    bool bFirstVehicleForPlayer; // 0x156 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_157[0x1]; // 0x157 (Size: 0x1, Type: PaddingProperty)
    ADelMarCheckpoint* CachedTeleportCheckpoint; // 0x158 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_160[0x70]; // 0x160 (Size: 0x70, Type: PaddingProperty)

protected:
    void HandleVehicleAppliedTeleportLocation(); // 0x11c255e0 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerRespawnComponent) == 0x1d0, "Size mismatch for UDelMarPlayerRespawnComponent");
static_assert(offsetof(UDelMarPlayerRespawnComponent, TeleportEnterPhaseSeconds) == 0xb8, "Offset mismatch for UDelMarPlayerRespawnComponent::TeleportEnterPhaseSeconds");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RespawnBackwardsRangeDistance) == 0xbc, "Offset mismatch for UDelMarPlayerRespawnComponent::RespawnBackwardsRangeDistance");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RespawnForwardRangeDistance) == 0xc0, "Offset mismatch for UDelMarPlayerRespawnComponent::RespawnForwardRangeDistance");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RespawnHeightStartDistance) == 0xc4, "Offset mismatch for UDelMarPlayerRespawnComponent::RespawnHeightStartDistance");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RespawnHeightPenetrationDistance) == 0xc8, "Offset mismatch for UDelMarPlayerRespawnComponent::RespawnHeightPenetrationDistance");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RespawnValidTrackRadius) == 0xcc, "Offset mismatch for UDelMarPlayerRespawnComponent::RespawnValidTrackRadius");
static_assert(offsetof(UDelMarPlayerRespawnComponent, bCheckForObstacles) == 0xd0, "Offset mismatch for UDelMarPlayerRespawnComponent::bCheckForObstacles");
static_assert(offsetof(UDelMarPlayerRespawnComponent, OppositeSideThreshold) == 0xd4, "Offset mismatch for UDelMarPlayerRespawnComponent::OppositeSideThreshold");
static_assert(offsetof(UDelMarPlayerRespawnComponent, ObstacleAreaBounds) == 0xd8, "Offset mismatch for UDelMarPlayerRespawnComponent::ObstacleAreaBounds");
static_assert(offsetof(UDelMarPlayerRespawnComponent, ObstacleActorClasses) == 0xf0, "Offset mismatch for UDelMarPlayerRespawnComponent::ObstacleActorClasses");
static_assert(offsetof(UDelMarPlayerRespawnComponent, ObstacleActorIgnoreClasses) == 0x100, "Offset mismatch for UDelMarPlayerRespawnComponent::ObstacleActorIgnoreClasses");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RaceManager) == 0x110, "Offset mismatch for UDelMarPlayerRespawnComponent::RaceManager");
static_assert(offsetof(UDelMarPlayerRespawnComponent, DelMarVehicle) == 0x118, "Offset mismatch for UDelMarPlayerRespawnComponent::DelMarVehicle");
static_assert(offsetof(UDelMarPlayerRespawnComponent, CheckpointManager) == 0x120, "Offset mismatch for UDelMarPlayerRespawnComponent::CheckpointManager");
static_assert(offsetof(UDelMarPlayerRespawnComponent, PlayerRaceData) == 0x128, "Offset mismatch for UDelMarPlayerRespawnComponent::PlayerRaceData");
static_assert(offsetof(UDelMarPlayerRespawnComponent, RaceConfig) == 0x130, "Offset mismatch for UDelMarPlayerRespawnComponent::RaceConfig");
static_assert(offsetof(UDelMarPlayerRespawnComponent, LastActiveTrack) == 0x138, "Offset mismatch for UDelMarPlayerRespawnComponent::LastActiveTrack");
static_assert(offsetof(UDelMarPlayerRespawnComponent, TrackPosition) == 0x140, "Offset mismatch for UDelMarPlayerRespawnComponent::TrackPosition");
static_assert(offsetof(UDelMarPlayerRespawnComponent, LastValidSegmentIndex) == 0x148, "Offset mismatch for UDelMarPlayerRespawnComponent::LastValidSegmentIndex");
static_assert(offsetof(UDelMarPlayerRespawnComponent, LastValidDistanceAlongSpline) == 0x14c, "Offset mismatch for UDelMarPlayerRespawnComponent::LastValidDistanceAlongSpline");
static_assert(offsetof(UDelMarPlayerRespawnComponent, LastValidFurthestDistance) == 0x150, "Offset mismatch for UDelMarPlayerRespawnComponent::LastValidFurthestDistance");
static_assert(offsetof(UDelMarPlayerRespawnComponent, bSpawnOnOppositeSide) == 0x154, "Offset mismatch for UDelMarPlayerRespawnComponent::bSpawnOnOppositeSide");
static_assert(offsetof(UDelMarPlayerRespawnComponent, bPreviousVehicleDemolished) == 0x155, "Offset mismatch for UDelMarPlayerRespawnComponent::bPreviousVehicleDemolished");
static_assert(offsetof(UDelMarPlayerRespawnComponent, bFirstVehicleForPlayer) == 0x156, "Offset mismatch for UDelMarPlayerRespawnComponent::bFirstVehicleForPlayer");
static_assert(offsetof(UDelMarPlayerRespawnComponent, CachedTeleportCheckpoint) == 0x158, "Offset mismatch for UDelMarPlayerRespawnComponent::CachedTeleportCheckpoint");

// Size: 0x108 (Inherited: 0x308, Single: 0xfffffe00)
class UDelMarPlayerStartlineComponent : public UDelMarPlayerStateComponent
{
public:
    float FailBufferSeconds; // 0xb8 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> DelMarVehicle; // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_c4[0x44]; // 0xc4 (Size: 0x44, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarPlayerStartlineComponent) == 0x108, "Size mismatch for UDelMarPlayerStartlineComponent");
static_assert(offsetof(UDelMarPlayerStartlineComponent, FailBufferSeconds) == 0xb8, "Offset mismatch for UDelMarPlayerStartlineComponent::FailBufferSeconds");
static_assert(offsetof(UDelMarPlayerStartlineComponent, DelMarVehicle) == 0xbc, "Offset mismatch for UDelMarPlayerStartlineComponent::DelMarVehicle");

// Size: 0xe8 (Inherited: 0x308, Single: 0xfffffde0)
class UDelMarPlayerTurboManagerComponent : public UDelMarPlayerStateComponent
{
public:
    float TurboCharges; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float RechargeRateSeconds; // 0xbc (Size: 0x4, Type: FloatProperty)
    float AdditiveRechargeRateModifierSeconds; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float LapCompleteCharges; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float RaceStartCharges; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float MaxCharges; // 0xcc (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_e0[0x8]; // 0xe0 (Size: 0x8, Type: PaddingProperty)

public:
    void ModifyTurboCharges(float& TurboChargeAmount); // 0x11c2561c (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void ModifyTurboCharges_Delayed(float& TurboChargeAmount); // 0x11c25748 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetAdditiveRechargeRateModifierSeconds(float& const InAdditionalRechargeRateSeconds); // 0x11c28614 (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetTurboCharges(float& TurboChargeAmount); // 0x11c289a0 (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

protected:
    void HandleTurboChargeUsed(); // 0x11c255c4 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerTurboManagerComponent) == 0xe8, "Size mismatch for UDelMarPlayerTurboManagerComponent");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, TurboCharges) == 0xb8, "Offset mismatch for UDelMarPlayerTurboManagerComponent::TurboCharges");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, RechargeRateSeconds) == 0xbc, "Offset mismatch for UDelMarPlayerTurboManagerComponent::RechargeRateSeconds");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, AdditiveRechargeRateModifierSeconds) == 0xc0, "Offset mismatch for UDelMarPlayerTurboManagerComponent::AdditiveRechargeRateModifierSeconds");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, LapCompleteCharges) == 0xc4, "Offset mismatch for UDelMarPlayerTurboManagerComponent::LapCompleteCharges");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, RaceStartCharges) == 0xc8, "Offset mismatch for UDelMarPlayerTurboManagerComponent::RaceStartCharges");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, MaxCharges) == 0xcc, "Offset mismatch for UDelMarPlayerTurboManagerComponent::MaxCharges");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, CachedDelMarVehicle) == 0xd0, "Offset mismatch for UDelMarPlayerTurboManagerComponent::CachedDelMarVehicle");
static_assert(offsetof(UDelMarPlayerTurboManagerComponent, CachedRaceManager) == 0xd8, "Offset mismatch for UDelMarPlayerTurboManagerComponent::CachedRaceManager");

// Size: 0xb8 (Inherited: 0x250, Single: 0xfffffe68)
class UDelMarRemoveAthenaMarkerComponent : public UControllerComponent
{
public:
};

static_assert(sizeof(UDelMarRemoveAthenaMarkerComponent) == 0xb8, "Size mismatch for UDelMarRemoveAthenaMarkerComponent");

// Size: 0x140 (Inherited: 0x308, Single: 0xfffffe38)
class UDelMarRequestComponent : public UDelMarPlayerStateComponent
{
public:
    uint8_t Pad_b8[0x48]; // 0xb8 (Size: 0x48, Type: PaddingProperty)
    FGameplayTagContainer MapChoice; // 0x100 (Size: 0x20, Type: StructProperty)
    bool bIsLoadingScreenActive; // 0x120 (Size: 0x1, Type: BoolProperty)
    bool bIsReadyToStartRace; // 0x121 (Size: 0x1, Type: BoolProperty)
    bool bIsReadyToJoinRace; // 0x122 (Size: 0x1, Type: BoolProperty)
    uint8_t PostRaceVote; // 0x123 (Size: 0x1, Type: EnumProperty)
    bool bVotedPostRace; // 0x124 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_125[0x3]; // 0x125 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarRespawnManagerComponent*> CachedRespawnManager; // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0x138 (Size: 0x8, Type: WeakObjectProperty)

public:
    void HandleArchetypeChangedOnServer(); // 0x11c25490 (Index: 0x0, Flags: Final|Native|Public)
    void HandleLoadoutsChangedOnServer(const FCosmeticLoadout CosmeticLoadout); // 0x11c254cc (Index: 0x1, Flags: Final|Native|Public|HasOutParms)
    void PostRaceNextRaceSelected(); // 0x11c26460 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void PostRaceReturnToLobbySelected(); // 0x11c26474 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ServerReadyUp(bool& bInReadyUp); // 0x11c26a2c (Index: 0xb, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestBecomeSpectator(); // 0xb4a87ec (Index: 0xc, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestFinalInitialization(); // 0x5fca794 (Index: 0xd, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestIdleKickExtension(); // 0xc019b98 (Index: 0xe, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestMap(FGameplayTagContainer& InMapChoice); // 0x11c273e8 (Index: 0xf, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestMapFromGameplay(FGameplayTagContainer& InMapChoice); // 0x11c276fc (Index: 0x10, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestRacerCountdown(); // 0xd4b56f4 (Index: 0x11, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestResetRun(); // 0xeb6b8b4 (Index: 0x12, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestSpectatorBecomePlayer(); // 0xb4a87d4 (Index: 0x13, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerRequestVehicleSpawn(); // 0xb4a8804 (Index: 0x14, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerSetJoinNextRace(bool& bInReadyToJoinRace); // 0xf726ce4 (Index: 0x15, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerSetLoadingScreenActive(bool& bInLoadingScreenActive); // 0x11c28284 (Index: 0x16, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void ServerSetPostRaceVote(EDelMarPostRaceVote& NewVote); // 0xf141874 (Index: 0x17, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)

protected:
    void OnRep_bIsReadyToJoinRace() const; // 0x11c26438 (Index: 0x2, Flags: Final|Native|Protected|Const)
    void OnRep_bIsReadyToStartRace() const; // 0x11c2644c (Index: 0x3, Flags: Final|Native|Protected|Const)
    void OnRep_PostRaceVote() const; // 0x11c263f4 (Index: 0x4, Flags: Final|Native|Protected|Const)
    virtual void ServerOnQuestScreenClosed(float& const OpenedDuration, FGameplayTag& const RaceState); // 0x11c267b8 (Index: 0x7, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerOnQuestScreenOpened(FGameplayTag& const RaceState); // 0x11c26964 (Index: 0x8, Flags: Net|NetReliableNative|Event|Protected|NetServer)
    virtual void ServerPostRaceNextRaceSelected(); // 0xcc87b74 (Index: 0x9, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
    virtual void ServerPostRaceReturnToLobbySelected(); // 0xc0194b8 (Index: 0xa, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
};

static_assert(sizeof(UDelMarRequestComponent) == 0x140, "Size mismatch for UDelMarRequestComponent");
static_assert(offsetof(UDelMarRequestComponent, MapChoice) == 0x100, "Offset mismatch for UDelMarRequestComponent::MapChoice");
static_assert(offsetof(UDelMarRequestComponent, bIsLoadingScreenActive) == 0x120, "Offset mismatch for UDelMarRequestComponent::bIsLoadingScreenActive");
static_assert(offsetof(UDelMarRequestComponent, bIsReadyToStartRace) == 0x121, "Offset mismatch for UDelMarRequestComponent::bIsReadyToStartRace");
static_assert(offsetof(UDelMarRequestComponent, bIsReadyToJoinRace) == 0x122, "Offset mismatch for UDelMarRequestComponent::bIsReadyToJoinRace");
static_assert(offsetof(UDelMarRequestComponent, PostRaceVote) == 0x123, "Offset mismatch for UDelMarRequestComponent::PostRaceVote");
static_assert(offsetof(UDelMarRequestComponent, bVotedPostRace) == 0x124, "Offset mismatch for UDelMarRequestComponent::bVotedPostRace");
static_assert(offsetof(UDelMarRequestComponent, CachedRaceManager) == 0x128, "Offset mismatch for UDelMarRequestComponent::CachedRaceManager");
static_assert(offsetof(UDelMarRequestComponent, CachedRespawnManager) == 0x130, "Offset mismatch for UDelMarRequestComponent::CachedRespawnManager");
static_assert(offsetof(UDelMarRequestComponent, PlayerState) == 0x138, "Offset mismatch for UDelMarRequestComponent::PlayerState");

// Size: 0x128 (Inherited: 0x308, Single: 0xfffffe20)
class UDelMarRunRecordPlayerComponent : public UDelMarPlayerStateComponent
{
public:
    FDelMarRunRecord CurrentRunRecord; // 0xb8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord BestRunRecord; // 0xd8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord BestSectionsRecord; // 0xf8 (Size: 0x20, Type: StructProperty)
    double BestSingleLapTime; // 0x118 (Size: 0x8, Type: DoubleProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x120 (Size: 0x8, Type: WeakObjectProperty)

protected:
    virtual void NetMulticast_LapRecorded(FDelMarEvent_LapRecorded& const InLapRecordedEvent); // 0x11c25af4 (Index: 0x0, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_RunRecorded(FDelMarEvent_RunRecorded& const InRunRecordedEvent); // 0x11c25df4 (Index: 0x1, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    virtual void NetMulticast_SectionRecorded(FDelMarEvent_SectionRecorded& const InSectionRecordedEvent); // 0x11c25fe0 (Index: 0x2, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
};

static_assert(sizeof(UDelMarRunRecordPlayerComponent) == 0x128, "Size mismatch for UDelMarRunRecordPlayerComponent");
static_assert(offsetof(UDelMarRunRecordPlayerComponent, CurrentRunRecord) == 0xb8, "Offset mismatch for UDelMarRunRecordPlayerComponent::CurrentRunRecord");
static_assert(offsetof(UDelMarRunRecordPlayerComponent, BestRunRecord) == 0xd8, "Offset mismatch for UDelMarRunRecordPlayerComponent::BestRunRecord");
static_assert(offsetof(UDelMarRunRecordPlayerComponent, BestSectionsRecord) == 0xf8, "Offset mismatch for UDelMarRunRecordPlayerComponent::BestSectionsRecord");
static_assert(offsetof(UDelMarRunRecordPlayerComponent, BestSingleLapTime) == 0x118, "Offset mismatch for UDelMarRunRecordPlayerComponent::BestSingleLapTime");
static_assert(offsetof(UDelMarRunRecordPlayerComponent, RaceManager) == 0x120, "Offset mismatch for UDelMarRunRecordPlayerComponent::RaceManager");

// Size: 0xc8 (Inherited: 0x308, Single: 0xfffffdc0)
class UDelMarTutorialRequestComponent : public UDelMarPlayerStateComponent
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTutorialRaceManager*> TutorialRaceManager; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

public:
    void GoRace() const; // 0x11c25468 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|Const)
    void KeepTraining() const; // 0x11c25608 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|Const)
    void Replay(); // 0x11c26488 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    virtual void Server_KeepTraining() const; // 0x270d644 (Index: 0x3, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|Const)
    virtual void Server_RequestNextSection(); // 0xb4a85b4 (Index: 0x4, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void Server_RequestPrevSection(); // 0xc0194b8 (Index: 0x5, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void Server_RequestSection(int32_t& SectionIndex); // 0xa7afb10 (Index: 0x6, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void Server_RequestStartRace(bool& const bSkipCountdown); // 0x11c283b4 (Index: 0x7, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    void TutorialComplete() const; // 0x11c25468 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|Const)
};

static_assert(sizeof(UDelMarTutorialRequestComponent) == 0xc8, "Size mismatch for UDelMarTutorialRequestComponent");
static_assert(offsetof(UDelMarTutorialRequestComponent, PlayerState) == 0xb8, "Offset mismatch for UDelMarTutorialRequestComponent::PlayerState");
static_assert(offsetof(UDelMarTutorialRequestComponent, TutorialRaceManager) == 0xc0, "Offset mismatch for UDelMarTutorialRequestComponent::TutorialRaceManager");

// Size: 0x168 (Inherited: 0x250, Single: 0xffffff18)
class UDelMarLevelManagerComponent : public UPlayspaceComponent
{
public:
    uint8_t Pad_b8[0x30]; // 0xb8 (Size: 0x30, Type: PaddingProperty)
    TWeakObjectPtr<UDelMarLevelDataAsset*> CurrentLevelData; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    FOnlineLinkId CurrentLevelLinkId; // 0xf0 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer DesiredMapDescription; // 0x108 (Size: 0x20, Type: StructProperty)
    FOnlineLinkId DesiredLinkId; // 0x128 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_140[0x28]; // 0x140 (Size: 0x28, Type: PaddingProperty)

public:
    void RequestLevelLoad(const FGameplayTagContainer DesiredMap); // 0x11c2649c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    virtual void ServerRequestLevel(FGameplayTagContainer& const DesiredMap); // 0x11c26b5c (Index: 0x1, Flags: Net|NetReliableNative|Event|Public|NetServer)
};

static_assert(sizeof(UDelMarLevelManagerComponent) == 0x168, "Size mismatch for UDelMarLevelManagerComponent");
static_assert(offsetof(UDelMarLevelManagerComponent, CurrentLevelData) == 0xe8, "Offset mismatch for UDelMarLevelManagerComponent::CurrentLevelData");
static_assert(offsetof(UDelMarLevelManagerComponent, CurrentLevelLinkId) == 0xf0, "Offset mismatch for UDelMarLevelManagerComponent::CurrentLevelLinkId");
static_assert(offsetof(UDelMarLevelManagerComponent, DesiredMapDescription) == 0x108, "Offset mismatch for UDelMarLevelManagerComponent::DesiredMapDescription");
static_assert(offsetof(UDelMarLevelManagerComponent, DesiredLinkId) == 0x128, "Offset mismatch for UDelMarLevelManagerComponent::DesiredLinkId");

// Size: 0x370 (Inherited: 0xbc0, Single: 0xfffff7b0)
class ADelMarLoadingScreenMutator : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(ADelMarLoadingScreenMutator) == 0x370, "Size mismatch for ADelMarLoadingScreenMutator");

// Size: 0x120 (Inherited: 0x250, Single: 0xfffffed0)
class UDelMarCheckpointManagerComponent : public UDelMarRaceManagerComponent
{
public:
    bool bPromptFirstPlaceEvent; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    ADelMarCheckpoint* StartingLineCheckpoint; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    ADelMarCheckpoint* FinishLineCheckpoint; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TSet<ADelMarCheckpoint*> LevelCheckpoints; // 0xd0 (Size: 0x50, Type: SetProperty)

private:
    void HandleRaceFinished(const FDelMarEvent_RaceFinished Event); // 0x11ca3a34 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void HandleResetRace(const FDelMarEvent_ResetRace Event); // 0x11ca3dec (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UDelMarCheckpointManagerComponent) == 0x120, "Size mismatch for UDelMarCheckpointManagerComponent");
static_assert(offsetof(UDelMarCheckpointManagerComponent, bPromptFirstPlaceEvent) == 0xb8, "Offset mismatch for UDelMarCheckpointManagerComponent::bPromptFirstPlaceEvent");
static_assert(offsetof(UDelMarCheckpointManagerComponent, StartingLineCheckpoint) == 0xc0, "Offset mismatch for UDelMarCheckpointManagerComponent::StartingLineCheckpoint");
static_assert(offsetof(UDelMarCheckpointManagerComponent, FinishLineCheckpoint) == 0xc8, "Offset mismatch for UDelMarCheckpointManagerComponent::FinishLineCheckpoint");
static_assert(offsetof(UDelMarCheckpointManagerComponent, LevelCheckpoints) == 0xd0, "Offset mismatch for UDelMarCheckpointManagerComponent::LevelCheckpoints");

// Size: 0x510 (Inherited: 0x7b0, Single: 0xfffffd60)
class ADelMarDeathRaceManager : public ADelMarRaceManager
{
public:
    float NextRoundSeconds; // 0x4e0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4e4[0x4]; // 0x4e4 (Size: 0x4, Type: PaddingProperty)
    FDelMarDeathRaceConfig DeathRaceConfigData; // 0x4e8 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_500[0x8]; // 0x500 (Size: 0x8, Type: PaddingProperty)
    int32_t NumPlayersFinished; // 0x508 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_50c[0x4]; // 0x50c (Size: 0x4, Type: PaddingProperty)

public:
    int32_t GetPointsAwardForPlacement(int32_t& const InPlacement) const; // 0x11ca3420 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetScoreThresholdToEndMatch() const; // 0x11ca359c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ADelMarDeathRaceManager) == 0x510, "Size mismatch for ADelMarDeathRaceManager");
static_assert(offsetof(ADelMarDeathRaceManager, NextRoundSeconds) == 0x4e0, "Offset mismatch for ADelMarDeathRaceManager::NextRoundSeconds");
static_assert(offsetof(ADelMarDeathRaceManager, DeathRaceConfigData) == 0x4e8, "Offset mismatch for ADelMarDeathRaceManager::DeathRaceConfigData");
static_assert(offsetof(ADelMarDeathRaceManager, NumPlayersFinished) == 0x508, "Offset mismatch for ADelMarDeathRaceManager::NumPlayersFinished");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UDelMarGameplayModifierMap : public UDataAsset
{
public:
    TMap<FDelMarGameplayModifierList, FString> ModifierMap; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarGameplayModifierMap) == 0x80, "Size mismatch for UDelMarGameplayModifierMap");
static_assert(offsetof(UDelMarGameplayModifierMap, ModifierMap) == 0x30, "Offset mismatch for UDelMarGameplayModifierMap::ModifierMap");

// Size: 0xe8 (Inherited: 0x250, Single: 0xfffffe98)
class UDelMarGameplayModifierComponent : public UDelMarRaceManagerComponent
{
public:
    bool bEnabled; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    UDelMarGameplayModifierMap* ModifierModes; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    FString ModeName; // 0xc8 (Size: 0x10, Type: StrProperty)
    TArray<ADelMarGameplayModifier*> SpawnedModifiers; // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarGameplayModifierComponent) == 0xe8, "Size mismatch for UDelMarGameplayModifierComponent");
static_assert(offsetof(UDelMarGameplayModifierComponent, bEnabled) == 0xb8, "Offset mismatch for UDelMarGameplayModifierComponent::bEnabled");
static_assert(offsetof(UDelMarGameplayModifierComponent, ModifierModes) == 0xc0, "Offset mismatch for UDelMarGameplayModifierComponent::ModifierModes");
static_assert(offsetof(UDelMarGameplayModifierComponent, ModeName) == 0xc8, "Offset mismatch for UDelMarGameplayModifierComponent::ModeName");
static_assert(offsetof(UDelMarGameplayModifierComponent, SpawnedModifiers) == 0xd8, "Offset mismatch for UDelMarGameplayModifierComponent::SpawnedModifiers");

// Size: 0xb8 (Inherited: 0x250, Single: 0xfffffe68)
class UDelMarMatchmakeRatingComponentBase : public UDelMarRaceManagerComponent
{
public:
};

static_assert(sizeof(UDelMarMatchmakeRatingComponentBase) == 0xb8, "Size mismatch for UDelMarMatchmakeRatingComponentBase");

// Size: 0x1c0 (Inherited: 0x308, Single: 0xfffffeb8)
class UDelmarCompetitiveMatchmakeRatingComponent : public UDelMarMatchmakeRatingComponentBase
{
public:
    TMap<int32_t, AFortPlayerState*> CachedPlayerRankMap; // 0xb8 (Size: 0x50, Type: MapProperty)
    TSet<FString> PlayerUniqueIdsGivenMMR; // 0x108 (Size: 0x50, Type: SetProperty)
    TSet<FString> PlayerUniqueIds; // 0x158 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_1a8[0x18]; // 0x1a8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UDelmarCompetitiveMatchmakeRatingComponent) == 0x1c0, "Size mismatch for UDelmarCompetitiveMatchmakeRatingComponent");
static_assert(offsetof(UDelmarCompetitiveMatchmakeRatingComponent, CachedPlayerRankMap) == 0xb8, "Offset mismatch for UDelmarCompetitiveMatchmakeRatingComponent::CachedPlayerRankMap");
static_assert(offsetof(UDelmarCompetitiveMatchmakeRatingComponent, PlayerUniqueIdsGivenMMR) == 0x108, "Offset mismatch for UDelmarCompetitiveMatchmakeRatingComponent::PlayerUniqueIdsGivenMMR");
static_assert(offsetof(UDelmarCompetitiveMatchmakeRatingComponent, PlayerUniqueIds) == 0x158, "Offset mismatch for UDelmarCompetitiveMatchmakeRatingComponent::PlayerUniqueIds");

// Size: 0x170 (Inherited: 0x250, Single: 0xffffff20)
class UDelMarPositionalTrackerComponent : public UDelMarRaceManagerComponent
{
public:
    float TargetUpdateRateInSeconds; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x34]; // 0xbc (Size: 0x34, Type: PaddingProperty)
    TMap<FDelMarPositionValue, AFortPlayerState*> SplinePositions; // 0xf0 (Size: 0x50, Type: MapProperty)
    TArray<AFortPlayerState*> RacePositions; // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarFinalRacePositionEntry> FinalRacePositions; // 0x150 (Size: 0x10, Type: ArrayProperty)
    float TimeSinceLastUpdate; // 0x160 (Size: 0x4, Type: FloatProperty)
    int32_t NumLapsInRace; // 0x164 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_168[0x8]; // 0x168 (Size: 0x8, Type: PaddingProperty)

protected:
    void OnRep_FinalRacePositions(); // 0x11ca4824 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPositionalTrackerComponent) == 0x170, "Size mismatch for UDelMarPositionalTrackerComponent");
static_assert(offsetof(UDelMarPositionalTrackerComponent, TargetUpdateRateInSeconds) == 0xb8, "Offset mismatch for UDelMarPositionalTrackerComponent::TargetUpdateRateInSeconds");
static_assert(offsetof(UDelMarPositionalTrackerComponent, SplinePositions) == 0xf0, "Offset mismatch for UDelMarPositionalTrackerComponent::SplinePositions");
static_assert(offsetof(UDelMarPositionalTrackerComponent, RacePositions) == 0x140, "Offset mismatch for UDelMarPositionalTrackerComponent::RacePositions");
static_assert(offsetof(UDelMarPositionalTrackerComponent, FinalRacePositions) == 0x150, "Offset mismatch for UDelMarPositionalTrackerComponent::FinalRacePositions");
static_assert(offsetof(UDelMarPositionalTrackerComponent, TimeSinceLastUpdate) == 0x160, "Offset mismatch for UDelMarPositionalTrackerComponent::TimeSinceLastUpdate");
static_assert(offsetof(UDelMarPositionalTrackerComponent, NumLapsInRace) == 0x164, "Offset mismatch for UDelMarPositionalTrackerComponent::NumLapsInRace");

// Size: 0x2f8 (Inherited: 0x250, Single: 0xa8)
class UDelMarRaceConfigComponent : public UDelMarRaceManagerComponent
{
public:
    bool bGhostReplayEnabled; // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool bAllowExitingVehicles; // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool bResetPlayerRunOnUnregister; // 0xba (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bb[0x1]; // 0xbb (Size: 0x1, Type: PaddingProperty)
    float MatchStartDelaySecondsOverride; // 0xbc (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeWrongwayWarning; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeDemoWarningsAppear; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeMissedCheckpointDemo; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float SecondsBeforeReturnToTrackDemo; // 0xcc (Size: 0x4, Type: FloatProperty)
    double DistanceFromTrackBeforeDemoWarning; // 0xd0 (Size: 0x8, Type: DoubleProperty)
    double DistanceFromVehicleBeforeReset; // 0xd8 (Size: 0x8, Type: DoubleProperty)
    TSoftClassPtr DefaultVehicleClass; // 0xe0 (Size: 0x20, Type: SoftClassProperty)
    TArray<UClass*> ServerPlayerStateComponents; // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ClientPlayerStateComponents; // 0x110 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ServerControllerComponents; // 0x120 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ClientControllerComponents; // 0x130 (Size: 0x10, Type: ArrayProperty)
    UClass* SpectatorControllerComponentClass; // 0x140 (Size: 0x8, Type: ClassProperty)
    FDelMarBotRuntimeConfig BotRuntimeConfig; // 0x148 (Size: 0x28, Type: StructProperty)
    FDelMarMatchmakingConfig MatchmakingConfig; // 0x170 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_18c[0x4]; // 0x18c (Size: 0x4, Type: PaddingProperty)
    FDelMarStartlineConfig StartlineConfig; // 0x190 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleRuntimeConfig VehicleRuntimeConfig; // 0x1b8 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleAbilityConfig VehicleAbilityConfig; // 0x1c4 (Size: 0x11, Type: StructProperty)
    uint8_t Pad_1d5[0x3]; // 0x1d5 (Size: 0x3, Type: PaddingProperty)
    FDelMarRespawnConfig RespawnConfig; // 0x1d8 (Size: 0x10, Type: StructProperty)
    FDelMarRubberbandingConfig DefaultRubberbandingConfig; // 0x1e8 (Size: 0x28, Type: StructProperty)
    TArray<FDelMarRubberbandingMMRConfig> RubberbandingMMRConfigs; // 0x210 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarRubberbandingMMRConfig> RubberbandingMMROverrideConfigs; // 0x220 (Size: 0x10, Type: ArrayProperty)
    TMap<FDelMarRubberbandingConfig, FString> NonMMRRubberbandingConfigs; // 0x230 (Size: 0x50, Type: MapProperty)
    TMap<FDelMarRubberbandingConfig, FString> NonMMRRubberbandingOverrideConfigs; // 0x280 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_2d0[0x28]; // 0x2d0 (Size: 0x28, Type: PaddingProperty)

public:
    void BroadcastVehicleAbilityConfigUpdated(); // 0x11ca2f64 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_VehicleAbilityConfig(const FDelMarVehicleAbilityConfig OldConfig); // 0x11ca4a1c (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UDelMarRaceConfigComponent) == 0x2f8, "Size mismatch for UDelMarRaceConfigComponent");
static_assert(offsetof(UDelMarRaceConfigComponent, bGhostReplayEnabled) == 0xb8, "Offset mismatch for UDelMarRaceConfigComponent::bGhostReplayEnabled");
static_assert(offsetof(UDelMarRaceConfigComponent, bAllowExitingVehicles) == 0xb9, "Offset mismatch for UDelMarRaceConfigComponent::bAllowExitingVehicles");
static_assert(offsetof(UDelMarRaceConfigComponent, bResetPlayerRunOnUnregister) == 0xba, "Offset mismatch for UDelMarRaceConfigComponent::bResetPlayerRunOnUnregister");
static_assert(offsetof(UDelMarRaceConfigComponent, MatchStartDelaySecondsOverride) == 0xbc, "Offset mismatch for UDelMarRaceConfigComponent::MatchStartDelaySecondsOverride");
static_assert(offsetof(UDelMarRaceConfigComponent, SecondsBeforeWrongwayWarning) == 0xc0, "Offset mismatch for UDelMarRaceConfigComponent::SecondsBeforeWrongwayWarning");
static_assert(offsetof(UDelMarRaceConfigComponent, SecondsBeforeDemoWarningsAppear) == 0xc4, "Offset mismatch for UDelMarRaceConfigComponent::SecondsBeforeDemoWarningsAppear");
static_assert(offsetof(UDelMarRaceConfigComponent, SecondsBeforeMissedCheckpointDemo) == 0xc8, "Offset mismatch for UDelMarRaceConfigComponent::SecondsBeforeMissedCheckpointDemo");
static_assert(offsetof(UDelMarRaceConfigComponent, SecondsBeforeReturnToTrackDemo) == 0xcc, "Offset mismatch for UDelMarRaceConfigComponent::SecondsBeforeReturnToTrackDemo");
static_assert(offsetof(UDelMarRaceConfigComponent, DistanceFromTrackBeforeDemoWarning) == 0xd0, "Offset mismatch for UDelMarRaceConfigComponent::DistanceFromTrackBeforeDemoWarning");
static_assert(offsetof(UDelMarRaceConfigComponent, DistanceFromVehicleBeforeReset) == 0xd8, "Offset mismatch for UDelMarRaceConfigComponent::DistanceFromVehicleBeforeReset");
static_assert(offsetof(UDelMarRaceConfigComponent, DefaultVehicleClass) == 0xe0, "Offset mismatch for UDelMarRaceConfigComponent::DefaultVehicleClass");
static_assert(offsetof(UDelMarRaceConfigComponent, ServerPlayerStateComponents) == 0x100, "Offset mismatch for UDelMarRaceConfigComponent::ServerPlayerStateComponents");
static_assert(offsetof(UDelMarRaceConfigComponent, ClientPlayerStateComponents) == 0x110, "Offset mismatch for UDelMarRaceConfigComponent::ClientPlayerStateComponents");
static_assert(offsetof(UDelMarRaceConfigComponent, ServerControllerComponents) == 0x120, "Offset mismatch for UDelMarRaceConfigComponent::ServerControllerComponents");
static_assert(offsetof(UDelMarRaceConfigComponent, ClientControllerComponents) == 0x130, "Offset mismatch for UDelMarRaceConfigComponent::ClientControllerComponents");
static_assert(offsetof(UDelMarRaceConfigComponent, SpectatorControllerComponentClass) == 0x140, "Offset mismatch for UDelMarRaceConfigComponent::SpectatorControllerComponentClass");
static_assert(offsetof(UDelMarRaceConfigComponent, BotRuntimeConfig) == 0x148, "Offset mismatch for UDelMarRaceConfigComponent::BotRuntimeConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, MatchmakingConfig) == 0x170, "Offset mismatch for UDelMarRaceConfigComponent::MatchmakingConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, StartlineConfig) == 0x190, "Offset mismatch for UDelMarRaceConfigComponent::StartlineConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, VehicleRuntimeConfig) == 0x1b8, "Offset mismatch for UDelMarRaceConfigComponent::VehicleRuntimeConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, VehicleAbilityConfig) == 0x1c4, "Offset mismatch for UDelMarRaceConfigComponent::VehicleAbilityConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, RespawnConfig) == 0x1d8, "Offset mismatch for UDelMarRaceConfigComponent::RespawnConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, DefaultRubberbandingConfig) == 0x1e8, "Offset mismatch for UDelMarRaceConfigComponent::DefaultRubberbandingConfig");
static_assert(offsetof(UDelMarRaceConfigComponent, RubberbandingMMRConfigs) == 0x210, "Offset mismatch for UDelMarRaceConfigComponent::RubberbandingMMRConfigs");
static_assert(offsetof(UDelMarRaceConfigComponent, RubberbandingMMROverrideConfigs) == 0x220, "Offset mismatch for UDelMarRaceConfigComponent::RubberbandingMMROverrideConfigs");
static_assert(offsetof(UDelMarRaceConfigComponent, NonMMRRubberbandingConfigs) == 0x230, "Offset mismatch for UDelMarRaceConfigComponent::NonMMRRubberbandingConfigs");
static_assert(offsetof(UDelMarRaceConfigComponent, NonMMRRubberbandingOverrideConfigs) == 0x280, "Offset mismatch for UDelMarRaceConfigComponent::NonMMRRubberbandingOverrideConfigs");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UDelMarRequestTrackerComponent : public UDelMarRaceManagerComponent
{
public:
    FDelMarEvent_TrackedPlayerReadyStates PlayerReadyStates; // 0xb8 (Size: 0x20, Type: StructProperty)

protected:
    void OnRep_PlayerReadyStates(); // 0x11ca48f4 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarRequestTrackerComponent) == 0xd8, "Size mismatch for UDelMarRequestTrackerComponent");
static_assert(offsetof(UDelMarRequestTrackerComponent, PlayerReadyStates) == 0xb8, "Offset mismatch for UDelMarRequestTrackerComponent::PlayerReadyStates");

// Size: 0x150 (Inherited: 0x250, Single: 0xffffff00)
class UDelMarRespawnManagerComponent : public UDelMarRaceManagerComponent
{
public:
    float RespawnRetrySeconds; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x14]; // 0xbc (Size: 0x14, Type: PaddingProperty)
    TWeakObjectPtr<UDelMarCheckpointManagerComponent*> CachedCheckpointManager; // 0xd0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarPlayerStart*> CachedChallengeStartSpawnPoint; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AController*>> RespawnRetryQueue; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TMap<TWeakObjectPtr<ADelMarVehicle*>, TWeakObjectPtr<AFortPlayerState*>> LastSpawnedVehicleMap; // 0xf8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_148[0x8]; // 0x148 (Size: 0x8, Type: PaddingProperty)

public:
    ADelMarVehicle* RequestRespawnPawnAndVehicle(AController*& InController); // 0x11ca536c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    ADelMarVehicle* RequestRespawnVehicleForPawn(AFortPlayerPawn*& InPlayerPawn); // 0x11ca54c8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarRespawnManagerComponent) == 0x150, "Size mismatch for UDelMarRespawnManagerComponent");
static_assert(offsetof(UDelMarRespawnManagerComponent, RespawnRetrySeconds) == 0xb8, "Offset mismatch for UDelMarRespawnManagerComponent::RespawnRetrySeconds");
static_assert(offsetof(UDelMarRespawnManagerComponent, CachedCheckpointManager) == 0xd0, "Offset mismatch for UDelMarRespawnManagerComponent::CachedCheckpointManager");
static_assert(offsetof(UDelMarRespawnManagerComponent, CachedRaceManager) == 0xd8, "Offset mismatch for UDelMarRespawnManagerComponent::CachedRaceManager");
static_assert(offsetof(UDelMarRespawnManagerComponent, CachedChallengeStartSpawnPoint) == 0xe0, "Offset mismatch for UDelMarRespawnManagerComponent::CachedChallengeStartSpawnPoint");
static_assert(offsetof(UDelMarRespawnManagerComponent, RespawnRetryQueue) == 0xe8, "Offset mismatch for UDelMarRespawnManagerComponent::RespawnRetryQueue");
static_assert(offsetof(UDelMarRespawnManagerComponent, LastSpawnedVehicleMap) == 0xf8, "Offset mismatch for UDelMarRespawnManagerComponent::LastSpawnedVehicleMap");

// Size: 0x100 (Inherited: 0x250, Single: 0xfffffeb0)
class UDelMarRubberbandingManagerComponent : public UDelMarRaceManagerComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    float PackDistance; // 0xd0 (Size: 0x4, Type: FloatProperty)
    FDelMarRubberbandingConfig RubberbandingConfig; // 0xd4 (Size: 0x28, Type: StructProperty)
    int32_t MMRUsed; // 0xfc (Size: 0x4, Type: IntProperty)

protected:
    void OnRep_RubberbandingConfig(); // 0x11ca4984 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarRubberbandingManagerComponent) == 0x100, "Size mismatch for UDelMarRubberbandingManagerComponent");
static_assert(offsetof(UDelMarRubberbandingManagerComponent, PackDistance) == 0xd0, "Offset mismatch for UDelMarRubberbandingManagerComponent::PackDistance");
static_assert(offsetof(UDelMarRubberbandingManagerComponent, RubberbandingConfig) == 0xd4, "Offset mismatch for UDelMarRubberbandingManagerComponent::RubberbandingConfig");
static_assert(offsetof(UDelMarRubberbandingManagerComponent, MMRUsed) == 0xfc, "Offset mismatch for UDelMarRubberbandingManagerComponent::MMRUsed");

// Size: 0x1c0 (Inherited: 0x2a0, Single: 0xffffff20)
class UDelMarGameStateMachine : public UDelMarStateMachine
{
public:
};

static_assert(sizeof(UDelMarGameStateMachine) == 0x1c0, "Size mismatch for UDelMarGameStateMachine");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UDelMarState_Gameplay : public UDelMarState
{
public:
};

static_assert(sizeof(UDelMarState_Gameplay) == 0x30, "Size mismatch for UDelMarState_Gameplay");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UDelMarState_Gameplay_ActiveRace : public UDelMarGameplayState
{
public:
};

static_assert(sizeof(UDelMarState_Gameplay_ActiveRace) == 0x30, "Size mismatch for UDelMarState_Gameplay_ActiveRace");

// Size: 0x2b0 (Inherited: 0x88, Single: 0x228)
class UDelMarState_Gameplay_Postrace : public UDelMarGameplayState
{
public:
    float PostRaceDuration; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    double PostRaceEndServerTime; // 0x38 (Size: 0x8, Type: DoubleProperty)
    TSet<TWeakObjectPtr<AFortPlayerState*>> ReadyPlayers; // 0x40 (Size: 0x50, Type: SetProperty)
    TWeakObjectPtr<ADelMarPlayspace*> CachedPlayspace; // 0x90 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0x98 (Size: 0x8, Type: WeakObjectProperty)
    FString EliminationList; // 0xd0 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_e0[0x1d0]; // 0xe0 (Size: 0x1d0, Type: PaddingProperty)

public:
    static bool IsNextRaceActionDisabled(); // 0x11ca405c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)

private:
    void OnRep_EliminationList(); // 0x10dd5298 (Index: 0x1, Flags: Final|Native|Private)

protected:
    void OnRep_PostRaceEndServerTime(); // 0x11ca4948 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarState_Gameplay_Postrace) == 0x2b0, "Size mismatch for UDelMarState_Gameplay_Postrace");
static_assert(offsetof(UDelMarState_Gameplay_Postrace, PostRaceDuration) == 0x30, "Offset mismatch for UDelMarState_Gameplay_Postrace::PostRaceDuration");
static_assert(offsetof(UDelMarState_Gameplay_Postrace, PostRaceEndServerTime) == 0x38, "Offset mismatch for UDelMarState_Gameplay_Postrace::PostRaceEndServerTime");
static_assert(offsetof(UDelMarState_Gameplay_Postrace, ReadyPlayers) == 0x40, "Offset mismatch for UDelMarState_Gameplay_Postrace::ReadyPlayers");
static_assert(offsetof(UDelMarState_Gameplay_Postrace, CachedPlayspace) == 0x90, "Offset mismatch for UDelMarState_Gameplay_Postrace::CachedPlayspace");
static_assert(offsetof(UDelMarState_Gameplay_Postrace, CachedRaceManager) == 0x98, "Offset mismatch for UDelMarState_Gameplay_Postrace::CachedRaceManager");
static_assert(offsetof(UDelMarState_Gameplay_Postrace, EliminationList) == 0xd0, "Offset mismatch for UDelMarState_Gameplay_Postrace::EliminationList");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UDelMarState_Gameplay_Prerace : public UDelMarGameplayState
{
public:
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    double PreRaceCountdownFinishServerTime; // 0x40 (Size: 0x8, Type: DoubleProperty)

private:
    void OnRep_PreRaceCountdownFinishServerTime(); // 0x11ca495c (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UDelMarState_Gameplay_Prerace) == 0x48, "Size mismatch for UDelMarState_Gameplay_Prerace");
static_assert(offsetof(UDelMarState_Gameplay_Prerace, RaceManager) == 0x30, "Offset mismatch for UDelMarState_Gameplay_Prerace::RaceManager");
static_assert(offsetof(UDelMarState_Gameplay_Prerace, PreRaceCountdownFinishServerTime) == 0x40, "Offset mismatch for UDelMarState_Gameplay_Prerace::PreRaceCountdownFinishServerTime");

// Size: 0x90 (Inherited: 0x88, Single: 0x8)
class UDelMarState_Gameplay_WaitingForPlayers : public UDelMarGameplayState
{
public:
    uint8_t Pad_30[0x4]; // 0x30 (Size: 0x4, Type: PaddingProperty)
    int32_t MinPlayers; // 0x34 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelmarCompetitiveMatchmakeRatingComponent*> MatchmakeRatingComponent; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    FDelMarEvent_LoadedPlayerStates LoadedPlayerStates; // 0x48 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<AFortPartyBeaconHost*> FortPartyBeacon; // 0x50 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AContentBeaconHostObjectV2*> ContentBeacon; // 0x58 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_60[0x30]; // 0x60 (Size: 0x30, Type: PaddingProperty)

protected:
    void OnRep_LoadedPlayerStates(); // 0x11ca48a8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarState_Gameplay_WaitingForPlayers) == 0x90, "Size mismatch for UDelMarState_Gameplay_WaitingForPlayers");
static_assert(offsetof(UDelMarState_Gameplay_WaitingForPlayers, MinPlayers) == 0x34, "Offset mismatch for UDelMarState_Gameplay_WaitingForPlayers::MinPlayers");
static_assert(offsetof(UDelMarState_Gameplay_WaitingForPlayers, RaceManager) == 0x38, "Offset mismatch for UDelMarState_Gameplay_WaitingForPlayers::RaceManager");
static_assert(offsetof(UDelMarState_Gameplay_WaitingForPlayers, MatchmakeRatingComponent) == 0x40, "Offset mismatch for UDelMarState_Gameplay_WaitingForPlayers::MatchmakeRatingComponent");
static_assert(offsetof(UDelMarState_Gameplay_WaitingForPlayers, LoadedPlayerStates) == 0x48, "Offset mismatch for UDelMarState_Gameplay_WaitingForPlayers::LoadedPlayerStates");
static_assert(offsetof(UDelMarState_Gameplay_WaitingForPlayers, FortPartyBeacon) == 0x50, "Offset mismatch for UDelMarState_Gameplay_WaitingForPlayers::FortPartyBeacon");
static_assert(offsetof(UDelMarState_Gameplay_WaitingForPlayers, ContentBeacon) == 0x58, "Offset mismatch for UDelMarState_Gameplay_WaitingForPlayers::ContentBeacon");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UDelMarState_LevelSetup : public UDelMarGameplayState
{
public:
    bool bVehiclesReady; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bVehiclesSpawned; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarState_LevelSetup) == 0x38, "Size mismatch for UDelMarState_LevelSetup");
static_assert(offsetof(UDelMarState_LevelSetup, bVehiclesReady) == 0x30, "Offset mismatch for UDelMarState_LevelSetup::bVehiclesReady");
static_assert(offsetof(UDelMarState_LevelSetup, bVehiclesSpawned) == 0x31, "Offset mismatch for UDelMarState_LevelSetup::bVehiclesSpawned");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UDelMarState_Loading : public UDelMarGameplayState
{
public:
    float DelayBeforeLoadingActuallyStarts; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer DesiredMap; // 0x38 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_58[0x10]; // 0x58 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarState_Loading) == 0x68, "Size mismatch for UDelMarState_Loading");
static_assert(offsetof(UDelMarState_Loading, DelayBeforeLoadingActuallyStarts) == 0x30, "Offset mismatch for UDelMarState_Loading::DelayBeforeLoadingActuallyStarts");
static_assert(offsetof(UDelMarState_Loading, DesiredMap) == 0x38, "Offset mismatch for UDelMarState_Loading::DesiredMap");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UDelMarState_Lobby : public UDelMarGameplayState
{
public:
    bool bLevelLoadRequested; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarState_Lobby) == 0x38, "Size mismatch for UDelMarState_Lobby");
static_assert(offsetof(UDelMarState_Lobby, bLevelLoadRequested) == 0x30, "Offset mismatch for UDelMarState_Lobby::bLevelLoadRequested");

// Size: 0x70 (Inherited: 0x88, Single: 0xffffffe8)
class UDelMarState_Setup : public UDelMarGameplayState
{
public:
    bool bHasRequestedLink; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bHasRecievedMatchAssignment; // 0x31 (Size: 0x1, Type: BoolProperty)
    bool bRequiresMatchAssignmentToProceed; // 0x32 (Size: 0x1, Type: BoolProperty)
    bool bCalledMapRotationService; // 0x33 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer DebugMapToLoad; // 0x38 (Size: 0x20, Type: StructProperty)
    FOnlineLinkId DebugIslandCodeToLoad; // 0x58 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UDelMarState_Setup) == 0x70, "Size mismatch for UDelMarState_Setup");
static_assert(offsetof(UDelMarState_Setup, bHasRequestedLink) == 0x30, "Offset mismatch for UDelMarState_Setup::bHasRequestedLink");
static_assert(offsetof(UDelMarState_Setup, bHasRecievedMatchAssignment) == 0x31, "Offset mismatch for UDelMarState_Setup::bHasRecievedMatchAssignment");
static_assert(offsetof(UDelMarState_Setup, bRequiresMatchAssignmentToProceed) == 0x32, "Offset mismatch for UDelMarState_Setup::bRequiresMatchAssignmentToProceed");
static_assert(offsetof(UDelMarState_Setup, bCalledMapRotationService) == 0x33, "Offset mismatch for UDelMarState_Setup::bCalledMapRotationService");
static_assert(offsetof(UDelMarState_Setup, DebugMapToLoad) == 0x38, "Offset mismatch for UDelMarState_Setup::DebugMapToLoad");
static_assert(offsetof(UDelMarState_Setup, DebugIslandCodeToLoad) == 0x58, "Offset mismatch for UDelMarState_Setup::DebugIslandCodeToLoad");

// Size: 0x588 (Inherited: 0x250, Single: 0x338)
class UDelMarCameraShakeComponent : public UControllerComponent
{
public:
    TMap<float, EBrelmarCameraShake> ShakeIntensitySettingMap; // 0xb8 (Size: 0x50, Type: MapProperty)
    UClass* JumpShakeEffect; // 0x108 (Size: 0x8, Type: ClassProperty)
    UClass* HazardShakeEffect; // 0x110 (Size: 0x8, Type: ClassProperty)
    bool bUseVehicleLandedKickflipShake; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x7]; // 0x119 (Size: 0x7, Type: PaddingProperty)
    UClass* VehicleLandedKickflipShake; // 0x120 (Size: 0x8, Type: ClassProperty)
    FDelMarScaledCurve VehicleLandedKickflipShakeIntensityCurve; // 0x128 (Size: 0x90, Type: StructProperty)
    UClass* VehicleLandedCameraShakeEffect; // 0x1b8 (Size: 0x8, Type: ClassProperty)
    FDelMarScaledCurve VehicleLandedShakeIntensityCurve; // 0x1c0 (Size: 0x90, Type: StructProperty)
    float MaxSecondsToDampenVehicleHit; // 0x250 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_254[0x4]; // 0x254 (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve VehicleHitShakeIntensityCurve; // 0x258 (Size: 0x90, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect VehicleImpactShakeEffect; // 0x2e8 (Size: 0xa0, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect WallImpactShakeEffect; // 0x388 (Size: 0xa0, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect WallNoRedirectImpactShakeEffect; // 0x428 (Size: 0xa0, Type: StructProperty)
    FDelMarDynamicCameraShakeEffect BaseAccelerationShakeEffect; // 0x4c8 (Size: 0xa0, Type: StructProperty)
    TScriptInterface<Class> Vehicle; // 0x568 (Size: 0x10, Type: InterfaceProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedPlayerController; // 0x578 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_580[0x8]; // 0x580 (Size: 0x8, Type: PaddingProperty)

private:
    void OnCameraShakeIntensitySettingsChanged(UFortClientSettingsRecord*& Settings); // 0x11ca4684 (Index: 0x0, Flags: Final|Native|Private)

protected:
    void OnHazardHit(); // 0x11ca47b0 (Index: 0x1, Flags: Final|Native|Protected)
    void OnJumpActivated(); // 0x11ca47c4 (Index: 0x2, Flags: Final|Native|Protected)
    void OnVehicleHitVehicle(float& Magnitude, FVector& WorldLocation); // 0x11ca4b2c (Index: 0x3, Flags: Final|Native|Protected|HasDefaults)
    void OnVehicleHitWall(float& Magnitude, FVector& WorldLocation, float& ForwardRotationDegrees); // 0x11ca4cf0 (Index: 0x4, Flags: Final|Native|Protected|HasDefaults)
    void OnVehicleLanded(float& LandingForce, bool& bLandedKickflip); // 0x11ca4f08 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarCameraShakeComponent) == 0x588, "Size mismatch for UDelMarCameraShakeComponent");
static_assert(offsetof(UDelMarCameraShakeComponent, ShakeIntensitySettingMap) == 0xb8, "Offset mismatch for UDelMarCameraShakeComponent::ShakeIntensitySettingMap");
static_assert(offsetof(UDelMarCameraShakeComponent, JumpShakeEffect) == 0x108, "Offset mismatch for UDelMarCameraShakeComponent::JumpShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, HazardShakeEffect) == 0x110, "Offset mismatch for UDelMarCameraShakeComponent::HazardShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, bUseVehicleLandedKickflipShake) == 0x118, "Offset mismatch for UDelMarCameraShakeComponent::bUseVehicleLandedKickflipShake");
static_assert(offsetof(UDelMarCameraShakeComponent, VehicleLandedKickflipShake) == 0x120, "Offset mismatch for UDelMarCameraShakeComponent::VehicleLandedKickflipShake");
static_assert(offsetof(UDelMarCameraShakeComponent, VehicleLandedKickflipShakeIntensityCurve) == 0x128, "Offset mismatch for UDelMarCameraShakeComponent::VehicleLandedKickflipShakeIntensityCurve");
static_assert(offsetof(UDelMarCameraShakeComponent, VehicleLandedCameraShakeEffect) == 0x1b8, "Offset mismatch for UDelMarCameraShakeComponent::VehicleLandedCameraShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, VehicleLandedShakeIntensityCurve) == 0x1c0, "Offset mismatch for UDelMarCameraShakeComponent::VehicleLandedShakeIntensityCurve");
static_assert(offsetof(UDelMarCameraShakeComponent, MaxSecondsToDampenVehicleHit) == 0x250, "Offset mismatch for UDelMarCameraShakeComponent::MaxSecondsToDampenVehicleHit");
static_assert(offsetof(UDelMarCameraShakeComponent, VehicleHitShakeIntensityCurve) == 0x258, "Offset mismatch for UDelMarCameraShakeComponent::VehicleHitShakeIntensityCurve");
static_assert(offsetof(UDelMarCameraShakeComponent, VehicleImpactShakeEffect) == 0x2e8, "Offset mismatch for UDelMarCameraShakeComponent::VehicleImpactShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, WallImpactShakeEffect) == 0x388, "Offset mismatch for UDelMarCameraShakeComponent::WallImpactShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, WallNoRedirectImpactShakeEffect) == 0x428, "Offset mismatch for UDelMarCameraShakeComponent::WallNoRedirectImpactShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, BaseAccelerationShakeEffect) == 0x4c8, "Offset mismatch for UDelMarCameraShakeComponent::BaseAccelerationShakeEffect");
static_assert(offsetof(UDelMarCameraShakeComponent, Vehicle) == 0x568, "Offset mismatch for UDelMarCameraShakeComponent::Vehicle");
static_assert(offsetof(UDelMarCameraShakeComponent, CachedPlayerController) == 0x578, "Offset mismatch for UDelMarCameraShakeComponent::CachedPlayerController");

// Size: 0x23c0 (Inherited: 0xd20, Single: 0x16a0)
class UDelMarVehicleConfigs : public UFortPhysicsVehicleConfigs
{
public:
    FDelMarVehicleCollisionConfig Collision; // 0x9c0 (Size: 0x1f8, Type: StructProperty)
    UDelMarVehicleBodySetup* DefaultBodySetup; // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleBodySetupMap* BodySetupMap; // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    FDelMarVehicleDriveSetup DriveSetup; // 0xbc8 (Size: 0x370, Type: StructProperty)
    UDelMarPhysMatAttributeMap* PhysMatAttributeMap; // 0xf38 (Size: 0x8, Type: ObjectProperty)
    FDelMarVehicleRigidBodyConfig RigidBody; // 0xf40 (Size: 0x38, Type: StructProperty)
    FDelMarVehicleConfig_Terrain Terrain; // 0xf78 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleConfig_WorldBonusSpeed WorldBonusSpeed; // 0xfa8 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleConfig_AutoAerialRotation AerialRotation; // 0xfd0 (Size: 0xa8, Type: StructProperty)
    FDelMarVehicleConfig_AirControl AirControl; // 0x1078 (Size: 0xd0, Type: StructProperty)
    FDelMarVehicleConfig_AirFreestyle AirFreestyle; // 0x1148 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleConfig_AirThrottle AirThrottle; // 0x1178 (Size: 0xa0, Type: StructProperty)
    FDelMarVehicleConfig_AutoUpright AutoUpright; // 0x1218 (Size: 0x24, Type: StructProperty)
    uint8_t Pad_123c[0x4]; // 0x123c (Size: 0x4, Type: PaddingProperty)
    FDelMarVehicleDraftingConfig Drafting; // 0x1240 (Size: 0xc8, Type: StructProperty)
    FDelMarVehicleDriftConfig Drift; // 0x1308 (Size: 0x718, Type: StructProperty)
    FDelMarVehicleDriftBoostConfig DriftBoost; // 0x1a20 (Size: 0x1d8, Type: StructProperty)
    FDelMarVehicleConfig_Gravity Gravity; // 0x1bf8 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleConfig_Jump Jump; // 0x1c18 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleConfig_Kickflip Kickflip; // 0x1c30 (Size: 0x158, Type: StructProperty)
    FDelMarVehicleOversteerConfig Oversteer; // 0x1d88 (Size: 0x138, Type: StructProperty)
    FDelMarVehicleConfig_Reattachment Reattachment; // 0x1ec0 (Size: 0xa0, Type: StructProperty)
    FDelMarVehicleConfig_Rubberbanding Rubberbanding; // 0x1f60 (Size: 0x1b8, Type: StructProperty)
    FDelMarVehicleConfig_StartlineBoost StartlineBoost; // 0x2118 (Size: 0xa8, Type: StructProperty)
    FDelMarVehicleConfig_Strafe Strafe; // 0x21c0 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_21dc[0x4]; // 0x21dc (Size: 0x4, Type: PaddingProperty)
    FDelMarVehicleTurboConfig Turbo; // 0x21e0 (Size: 0x70, Type: StructProperty)
    FDelMarVehicleConfig_Underthrust Underthrust; // 0x2250 (Size: 0x168, Type: StructProperty)
    FDelMarVehicleConfig_SelfDemolish SelfDemolish; // 0x23b8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UDelMarVehicleConfigs) == 0x23c0, "Size mismatch for UDelMarVehicleConfigs");
static_assert(offsetof(UDelMarVehicleConfigs, Collision) == 0x9c0, "Offset mismatch for UDelMarVehicleConfigs::Collision");
static_assert(offsetof(UDelMarVehicleConfigs, DefaultBodySetup) == 0xbb8, "Offset mismatch for UDelMarVehicleConfigs::DefaultBodySetup");
static_assert(offsetof(UDelMarVehicleConfigs, BodySetupMap) == 0xbc0, "Offset mismatch for UDelMarVehicleConfigs::BodySetupMap");
static_assert(offsetof(UDelMarVehicleConfigs, DriveSetup) == 0xbc8, "Offset mismatch for UDelMarVehicleConfigs::DriveSetup");
static_assert(offsetof(UDelMarVehicleConfigs, PhysMatAttributeMap) == 0xf38, "Offset mismatch for UDelMarVehicleConfigs::PhysMatAttributeMap");
static_assert(offsetof(UDelMarVehicleConfigs, RigidBody) == 0xf40, "Offset mismatch for UDelMarVehicleConfigs::RigidBody");
static_assert(offsetof(UDelMarVehicleConfigs, Terrain) == 0xf78, "Offset mismatch for UDelMarVehicleConfigs::Terrain");
static_assert(offsetof(UDelMarVehicleConfigs, WorldBonusSpeed) == 0xfa8, "Offset mismatch for UDelMarVehicleConfigs::WorldBonusSpeed");
static_assert(offsetof(UDelMarVehicleConfigs, AerialRotation) == 0xfd0, "Offset mismatch for UDelMarVehicleConfigs::AerialRotation");
static_assert(offsetof(UDelMarVehicleConfigs, AirControl) == 0x1078, "Offset mismatch for UDelMarVehicleConfigs::AirControl");
static_assert(offsetof(UDelMarVehicleConfigs, AirFreestyle) == 0x1148, "Offset mismatch for UDelMarVehicleConfigs::AirFreestyle");
static_assert(offsetof(UDelMarVehicleConfigs, AirThrottle) == 0x1178, "Offset mismatch for UDelMarVehicleConfigs::AirThrottle");
static_assert(offsetof(UDelMarVehicleConfigs, AutoUpright) == 0x1218, "Offset mismatch for UDelMarVehicleConfigs::AutoUpright");
static_assert(offsetof(UDelMarVehicleConfigs, Drafting) == 0x1240, "Offset mismatch for UDelMarVehicleConfigs::Drafting");
static_assert(offsetof(UDelMarVehicleConfigs, Drift) == 0x1308, "Offset mismatch for UDelMarVehicleConfigs::Drift");
static_assert(offsetof(UDelMarVehicleConfigs, DriftBoost) == 0x1a20, "Offset mismatch for UDelMarVehicleConfigs::DriftBoost");
static_assert(offsetof(UDelMarVehicleConfigs, Gravity) == 0x1bf8, "Offset mismatch for UDelMarVehicleConfigs::Gravity");
static_assert(offsetof(UDelMarVehicleConfigs, Jump) == 0x1c18, "Offset mismatch for UDelMarVehicleConfigs::Jump");
static_assert(offsetof(UDelMarVehicleConfigs, Kickflip) == 0x1c30, "Offset mismatch for UDelMarVehicleConfigs::Kickflip");
static_assert(offsetof(UDelMarVehicleConfigs, Oversteer) == 0x1d88, "Offset mismatch for UDelMarVehicleConfigs::Oversteer");
static_assert(offsetof(UDelMarVehicleConfigs, Reattachment) == 0x1ec0, "Offset mismatch for UDelMarVehicleConfigs::Reattachment");
static_assert(offsetof(UDelMarVehicleConfigs, Rubberbanding) == 0x1f60, "Offset mismatch for UDelMarVehicleConfigs::Rubberbanding");
static_assert(offsetof(UDelMarVehicleConfigs, StartlineBoost) == 0x2118, "Offset mismatch for UDelMarVehicleConfigs::StartlineBoost");
static_assert(offsetof(UDelMarVehicleConfigs, Strafe) == 0x21c0, "Offset mismatch for UDelMarVehicleConfigs::Strafe");
static_assert(offsetof(UDelMarVehicleConfigs, Turbo) == 0x21e0, "Offset mismatch for UDelMarVehicleConfigs::Turbo");
static_assert(offsetof(UDelMarVehicleConfigs, Underthrust) == 0x2250, "Offset mismatch for UDelMarVehicleConfigs::Underthrust");
static_assert(offsetof(UDelMarVehicleConfigs, SelfDemolish) == 0x23b8, "Offset mismatch for UDelMarVehicleConfigs::SelfDemolish");

// Size: 0x108 (Inherited: 0xe0, Single: 0x28)
class UDelMarVehicleCosmeticComponent : public UActorComponent
{
public:
    uint8_t OnCosmeticActorSpawned[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAllCosmeticActorsSpawned[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<TSoftClassPtr> StaticCosmeticActorClasses; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> AllowedServerCosmeticActorClasses; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TArray<ADelMarCosmeticActor*> SpawnedCosmeticActors; // 0xf8 (Size: 0x10, Type: ArrayProperty)

public:
    void DelMarOnAllCosmeticActorsSpawned__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void DelMarOnCosmeticItemSpawned__DelegateSignature(ADelMarCosmeticActor*& CosmeticActor); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    ADelMarCosmeticActor* GetCosmeticActor(UClass*& CosmeticClass, bool& bLookForChildClasses) const; // 0x11ce2104 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<ADelMarCosmeticActor*> GetCosmeticActors(UClass*& CosmeticClass, bool& bLookForChildClasses) const; // 0x11ce24bc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarVehicleCosmeticComponent) == 0x108, "Size mismatch for UDelMarVehicleCosmeticComponent");
static_assert(offsetof(UDelMarVehicleCosmeticComponent, OnCosmeticActorSpawned) == 0xb8, "Offset mismatch for UDelMarVehicleCosmeticComponent::OnCosmeticActorSpawned");
static_assert(offsetof(UDelMarVehicleCosmeticComponent, OnAllCosmeticActorsSpawned) == 0xc8, "Offset mismatch for UDelMarVehicleCosmeticComponent::OnAllCosmeticActorsSpawned");
static_assert(offsetof(UDelMarVehicleCosmeticComponent, StaticCosmeticActorClasses) == 0xd8, "Offset mismatch for UDelMarVehicleCosmeticComponent::StaticCosmeticActorClasses");
static_assert(offsetof(UDelMarVehicleCosmeticComponent, AllowedServerCosmeticActorClasses) == 0xe8, "Offset mismatch for UDelMarVehicleCosmeticComponent::AllowedServerCosmeticActorClasses");
static_assert(offsetof(UDelMarVehicleCosmeticComponent, SpawnedCosmeticActors) == 0xf8, "Offset mismatch for UDelMarVehicleCosmeticComponent::SpawnedCosmeticActors");

// Size: 0x410 (Inherited: 0x250, Single: 0x1c0)
class UDelMarVehicleForceFeedbackComponent : public UControllerComponent
{
public:
    FDelMarDynamicForceFeedbackEffect DrivingForceFeedback; // 0xb8 (Size: 0x128, Type: StructProperty)
    UForceFeedbackEffect* JumpForceFeedbackEffect; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* OversteerLeftForceFeedbackEffect; // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* OversteerRightForceFeedbackEffect; // 0x1f0 (Size: 0x8, Type: ObjectProperty)
    TArray<UForceFeedbackEffect*> LandingForceFeedbackEffects; // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    FRuntimeFloatCurve LandingForceLevelLookupCurve; // 0x208 (Size: 0x88, Type: StructProperty)
    UForceFeedbackEffect* TurboForceFeedbackEffect; // 0x290 (Size: 0x8, Type: ObjectProperty)
    FDelMarDynamicForceFeedbackEffect DriftForceFeedback; // 0x298 (Size: 0x128, Type: StructProperty)
    UForceFeedbackEffect* DriftUncontrolledForceFeedbackEffect; // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* DriftBoostForceFeedbackEffect; // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* DriftTractionForceFeedback; // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    float MaxTractionDriftShakeAngle; // 0x3d8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3dc[0x4]; // 0x3dc (Size: 0x4, Type: PaddingProperty)
    UForceFeedbackEffect* HazardHitForceFeedback; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> Vehicle; // 0x3e8 (Size: 0x10, Type: InterfaceProperty)
    TWeakObjectPtr<APlayerController*> CachedPlayerController; // 0x3f8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UForceFeedbackEffect*> CurrentOversteerForceFeedbackEffect; // 0x400 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)

protected:
    void HandleLoadingScreenVisibilityChanged(bool& bVisibility); // 0x11ce2928 (Index: 0x0, Flags: Final|Native|Protected)
    void OnDriftActivated(); // 0x11ce2a54 (Index: 0x1, Flags: Final|Native|Protected)
    void OnDriftBoostActivated(); // 0x11ce2a68 (Index: 0x2, Flags: Final|Native|Protected)
    void OnDriftBoostDeactivated(); // 0x11ce2a7c (Index: 0x3, Flags: Final|Native|Protected)
    void OnDriftControlChanged(bool& bIsDriftControlled); // 0x11ce2a90 (Index: 0x4, Flags: Final|Native|Protected)
    void OnDriftDeactivated(); // 0x11ce2bbc (Index: 0x5, Flags: Final|Native|Protected)
    void OnHazardHit(); // 0x11ce2bd0 (Index: 0x6, Flags: Final|Native|Protected)
    void OnJumpActivated(); // 0x11ce2be4 (Index: 0x7, Flags: Final|Native|Protected)
    void OnTurboActivated(); // 0x11ce2f10 (Index: 0x8, Flags: Final|Native|Protected)
    void OnTurboDeactivated(); // 0x11ce2f24 (Index: 0x9, Flags: Final|Native|Protected)
    void OnUnderthrustActivated(); // 0x11ce2f38 (Index: 0xa, Flags: Final|Native|Protected)
    void OnUnderthrustDeactivated(); // 0x11ce2f4c (Index: 0xb, Flags: Final|Native|Protected)
    void OnVehicleLanded(float& LandingForce, bool& bLandedKickflip); // 0x11ce2f60 (Index: 0xc, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarVehicleForceFeedbackComponent) == 0x410, "Size mismatch for UDelMarVehicleForceFeedbackComponent");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, DrivingForceFeedback) == 0xb8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::DrivingForceFeedback");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, JumpForceFeedbackEffect) == 0x1e0, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::JumpForceFeedbackEffect");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, OversteerLeftForceFeedbackEffect) == 0x1e8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::OversteerLeftForceFeedbackEffect");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, OversteerRightForceFeedbackEffect) == 0x1f0, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::OversteerRightForceFeedbackEffect");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, LandingForceFeedbackEffects) == 0x1f8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::LandingForceFeedbackEffects");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, LandingForceLevelLookupCurve) == 0x208, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::LandingForceLevelLookupCurve");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, TurboForceFeedbackEffect) == 0x290, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::TurboForceFeedbackEffect");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, DriftForceFeedback) == 0x298, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::DriftForceFeedback");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, DriftUncontrolledForceFeedbackEffect) == 0x3c0, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::DriftUncontrolledForceFeedbackEffect");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, DriftBoostForceFeedbackEffect) == 0x3c8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::DriftBoostForceFeedbackEffect");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, DriftTractionForceFeedback) == 0x3d0, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::DriftTractionForceFeedback");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, MaxTractionDriftShakeAngle) == 0x3d8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::MaxTractionDriftShakeAngle");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, HazardHitForceFeedback) == 0x3e0, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::HazardHitForceFeedback");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, Vehicle) == 0x3e8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::Vehicle");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, CachedPlayerController) == 0x3f8, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::CachedPlayerController");
static_assert(offsetof(UDelMarVehicleForceFeedbackComponent, CurrentOversteerForceFeedbackEffect) == 0x400, "Offset mismatch for UDelMarVehicleForceFeedbackComponent::CurrentOversteerForceFeedbackEffect");

// Size: 0xa8 (Inherited: 0x88, Single: 0x20)
class UDelMarVehicleMovementSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData AccelMultiplier; // 0x30 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData bVehicleThrottleDisabled; // 0x58 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData BonusSpeed; // 0x80 (Size: 0x28, Type: StructProperty)

protected:
    void OnRep_AccelMultiplier(const FFortGameplayAttributeData OldSpeedMultiplier); // 0x11ce2bf8 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnRep_BonusSpeed(const FFortGameplayAttributeData OldBonusSpeed); // 0x11ce2d00 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void OnRep_VehicleThrottleDisabled(const FFortGameplayAttributeData OldInputDisabled); // 0x11ce2e08 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UDelMarVehicleMovementSet) == 0xa8, "Size mismatch for UDelMarVehicleMovementSet");
static_assert(offsetof(UDelMarVehicleMovementSet, AccelMultiplier) == 0x30, "Offset mismatch for UDelMarVehicleMovementSet::AccelMultiplier");
static_assert(offsetof(UDelMarVehicleMovementSet, bVehicleThrottleDisabled) == 0x58, "Offset mismatch for UDelMarVehicleMovementSet::bVehicleThrottleDisabled");
static_assert(offsetof(UDelMarVehicleMovementSet, BonusSpeed) == 0x80, "Offset mismatch for UDelMarVehicleMovementSet::BonusSpeed");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UDelMarVehicleTurboManagerComponent : public UActorComponent
{
public:
    float TurboCharges; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float RechargeRateSeconds; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxCharges; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
    ADelMarVehicle* OwnerVehicle; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x8]; // 0xd0 (Size: 0x8, Type: PaddingProperty)

public:
    void ModifyTurboCharges(float& TurboChargeAmount); // 0x11cf630c (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void ModifyTurboCharges_Delayed(float& TurboChargeAmount); // 0x11cf6438 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetTurboCharges(float& TurboChargeAmount); // 0x11cf6580 (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

protected:
    void HandleTurboChargeUsed(); // 0x11cf62f0 (Index: 0x0, Flags: Final|Native|Protected)
    void OnConfigOverridesSet(); // 0x11cf656c (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarVehicleTurboManagerComponent) == 0xd8, "Size mismatch for UDelMarVehicleTurboManagerComponent");
static_assert(offsetof(UDelMarVehicleTurboManagerComponent, TurboCharges) == 0xb8, "Offset mismatch for UDelMarVehicleTurboManagerComponent::TurboCharges");
static_assert(offsetof(UDelMarVehicleTurboManagerComponent, RechargeRateSeconds) == 0xbc, "Offset mismatch for UDelMarVehicleTurboManagerComponent::RechargeRateSeconds");
static_assert(offsetof(UDelMarVehicleTurboManagerComponent, MaxCharges) == 0xc0, "Offset mismatch for UDelMarVehicleTurboManagerComponent::MaxCharges");
static_assert(offsetof(UDelMarVehicleTurboManagerComponent, OwnerVehicle) == 0xc8, "Offset mismatch for UDelMarVehicleTurboManagerComponent::OwnerVehicle");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarEnvironmentVFX
{
    UNiagaraSystem* OnAppliedFX; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* WhileAppliedFX; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* OnRemovedFX; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEnvironmentVFX) == 0x18, "Size mismatch for FDelMarEnvironmentVFX");
static_assert(offsetof(FDelMarEnvironmentVFX, OnAppliedFX) == 0x0, "Offset mismatch for FDelMarEnvironmentVFX::OnAppliedFX");
static_assert(offsetof(FDelMarEnvironmentVFX, WhileAppliedFX) == 0x8, "Offset mismatch for FDelMarEnvironmentVFX::WhileAppliedFX");
static_assert(offsetof(FDelMarEnvironmentVFX, OnRemovedFX) == 0x10, "Offset mismatch for FDelMarEnvironmentVFX::OnRemovedFX");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarAIDifficultySpawnInfo
{
    int32_t SkillLevel; // 0x0 (Size: 0x4, Type: IntProperty)
    float BotFillPercentage; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarAIDifficultySpawnInfo) == 0x8, "Size mismatch for FDelMarAIDifficultySpawnInfo");
static_assert(offsetof(FDelMarAIDifficultySpawnInfo, SkillLevel) == 0x0, "Offset mismatch for FDelMarAIDifficultySpawnInfo::SkillLevel");
static_assert(offsetof(FDelMarAIDifficultySpawnInfo, BotFillPercentage) == 0x4, "Offset mismatch for FDelMarAIDifficultySpawnInfo::BotFillPercentage");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FDelMarAIMMRSpawnDataTableRow : FTableRowBase
{
    int32_t MMRBracketLow; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MMRBracketHigh; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t FallbackSkillLevel; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarAIDifficultySpawnInfo> BotSpawnInfo; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarAIMMRSpawnDataTableRow) == 0x28, "Size mismatch for FDelMarAIMMRSpawnDataTableRow");
static_assert(offsetof(FDelMarAIMMRSpawnDataTableRow, MMRBracketLow) == 0x8, "Offset mismatch for FDelMarAIMMRSpawnDataTableRow::MMRBracketLow");
static_assert(offsetof(FDelMarAIMMRSpawnDataTableRow, MMRBracketHigh) == 0xc, "Offset mismatch for FDelMarAIMMRSpawnDataTableRow::MMRBracketHigh");
static_assert(offsetof(FDelMarAIMMRSpawnDataTableRow, FallbackSkillLevel) == 0x10, "Offset mismatch for FDelMarAIMMRSpawnDataTableRow::FallbackSkillLevel");
static_assert(offsetof(FDelMarAIMMRSpawnDataTableRow, BotSpawnInfo) == 0x18, "Offset mismatch for FDelMarAIMMRSpawnDataTableRow::BotSpawnInfo");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarAIVehicleCosmeticSlotDataTableInfo
{
    TSoftObjectPtr<UCosmeticLoadoutSlotTemplate*> SlotTemplate; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UDataTable*> VehicleSlotCosmeticDataTable; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FDelMarAIVehicleCosmeticSlotDataTableInfo) == 0x40, "Size mismatch for FDelMarAIVehicleCosmeticSlotDataTableInfo");
static_assert(offsetof(FDelMarAIVehicleCosmeticSlotDataTableInfo, SlotTemplate) == 0x0, "Offset mismatch for FDelMarAIVehicleCosmeticSlotDataTableInfo::SlotTemplate");
static_assert(offsetof(FDelMarAIVehicleCosmeticSlotDataTableInfo, VehicleSlotCosmeticDataTable) == 0x20, "Offset mismatch for FDelMarAIVehicleCosmeticSlotDataTableInfo::VehicleSlotCosmeticDataTable");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarCosmeticLoadoutSlotData
{
    TSoftObjectPtr<UCosmeticLoadoutSlotTemplate*> SlotTemplate; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UObject*> EquippedItemDefinitionObject; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FDelMarCosmeticLoadoutSlotData) == 0x40, "Size mismatch for FDelMarCosmeticLoadoutSlotData");
static_assert(offsetof(FDelMarCosmeticLoadoutSlotData, SlotTemplate) == 0x0, "Offset mismatch for FDelMarCosmeticLoadoutSlotData::SlotTemplate");
static_assert(offsetof(FDelMarCosmeticLoadoutSlotData, EquippedItemDefinitionObject) == 0x20, "Offset mismatch for FDelMarCosmeticLoadoutSlotData::EquippedItemDefinitionObject");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FDelMarAIVehicleCosmeticLoadoutSetDataTableRow : FTableRowBase
{
    TArray<FDelMarCosmeticLoadoutSlotData> LoadoutSlots; // 0x8 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarAIVehicleCosmeticLoadoutSetDataTableRow) == 0x20, "Size mismatch for FDelMarAIVehicleCosmeticLoadoutSetDataTableRow");
static_assert(offsetof(FDelMarAIVehicleCosmeticLoadoutSetDataTableRow, LoadoutSlots) == 0x8, "Offset mismatch for FDelMarAIVehicleCosmeticLoadoutSetDataTableRow::LoadoutSlots");
static_assert(offsetof(FDelMarAIVehicleCosmeticLoadoutSetDataTableRow, Weight) == 0x18, "Offset mismatch for FDelMarAIVehicleCosmeticLoadoutSetDataTableRow::Weight");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FDelMarAIVehicleCosmeticSlotDataTableRow : FTableRowBase
{
    TSoftObjectPtr<UObject*> EquippedItemDefinitionObject; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    float Weight; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarAIVehicleCosmeticSlotDataTableRow) == 0x30, "Size mismatch for FDelMarAIVehicleCosmeticSlotDataTableRow");
static_assert(offsetof(FDelMarAIVehicleCosmeticSlotDataTableRow, EquippedItemDefinitionObject) == 0x8, "Offset mismatch for FDelMarAIVehicleCosmeticSlotDataTableRow::EquippedItemDefinitionObject");
static_assert(offsetof(FDelMarAIVehicleCosmeticSlotDataTableRow, Weight) == 0x28, "Offset mismatch for FDelMarAIVehicleCosmeticSlotDataTableRow::Weight");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarAITrackDecision
{
    TWeakObjectPtr<ADelMarTrack*> Track; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarAITrackDecision) == 0x10, "Size mismatch for FDelMarAITrackDecision");
static_assert(offsetof(FDelMarAITrackDecision, Track) == 0x0, "Offset mismatch for FDelMarAITrackDecision::Track");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FDriveHazardInfo
{
    TWeakObjectPtr<AActor*> Actor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> HazardTrackSplineComponent; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_10[0xc0]; // 0x10 (Size: 0xc0, Type: PaddingProperty)
};

static_assert(sizeof(FDriveHazardInfo) == 0xd0, "Size mismatch for FDriveHazardInfo");
static_assert(offsetof(FDriveHazardInfo, Actor) == 0x0, "Offset mismatch for FDriveHazardInfo::Actor");
static_assert(offsetof(FDriveHazardInfo, HazardTrackSplineComponent) == 0x8, "Offset mismatch for FDriveHazardInfo::HazardTrackSplineComponent");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FAvoidanceInfo
{
};

static_assert(sizeof(FAvoidanceInfo) == 0x90, "Size mismatch for FAvoidanceInfo");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDelMarCosmeticSlotInfo
{
    FGameplayTag SlotTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FText SlotName; // 0x8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription; // 0x18 (Size: 0x10, Type: TextProperty)
    bool bCanBeEmpty; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TSoftObjectPtr<UTexture2D*> UnassignedPreviewImage; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FDelMarCosmeticSlotInfo) == 0x50, "Size mismatch for FDelMarCosmeticSlotInfo");
static_assert(offsetof(FDelMarCosmeticSlotInfo, SlotTag) == 0x0, "Offset mismatch for FDelMarCosmeticSlotInfo::SlotTag");
static_assert(offsetof(FDelMarCosmeticSlotInfo, SlotName) == 0x8, "Offset mismatch for FDelMarCosmeticSlotInfo::SlotName");
static_assert(offsetof(FDelMarCosmeticSlotInfo, ShortDescription) == 0x18, "Offset mismatch for FDelMarCosmeticSlotInfo::ShortDescription");
static_assert(offsetof(FDelMarCosmeticSlotInfo, bCanBeEmpty) == 0x28, "Offset mismatch for FDelMarCosmeticSlotInfo::bCanBeEmpty");
static_assert(offsetof(FDelMarCosmeticSlotInfo, UnassignedPreviewImage) == 0x30, "Offset mismatch for FDelMarCosmeticSlotInfo::UnassignedPreviewImage");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_DriverInteractionAdded
{
};

static_assert(sizeof(FDelMarEvent_DriverInteractionAdded) == 0x8, "Size mismatch for FDelMarEvent_DriverInteractionAdded");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarEventRouterExt
{
    bool bWorldIsTearingDown; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UGameplayEventRouterComponent* EventRouter; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UObject* EventRouterContextObject; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEventRouterExt) == 0x18, "Size mismatch for FDelMarEventRouterExt");
static_assert(offsetof(FDelMarEventRouterExt, bWorldIsTearingDown) == 0x0, "Offset mismatch for FDelMarEventRouterExt::bWorldIsTearingDown");
static_assert(offsetof(FDelMarEventRouterExt, EventRouter) == 0x8, "Offset mismatch for FDelMarEventRouterExt::EventRouter");
static_assert(offsetof(FDelMarEventRouterExt, EventRouterContextObject) == 0x10, "Offset mismatch for FDelMarEventRouterExt::EventRouterContextObject");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarGameplayStateChangedEvent
{
    FGameplayTag PrevStateId; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewStateId; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarGameplayStateChangedEvent) == 0x8, "Size mismatch for FDelMarGameplayStateChangedEvent");
static_assert(offsetof(FDelMarGameplayStateChangedEvent, PrevStateId) == 0x0, "Offset mismatch for FDelMarGameplayStateChangedEvent::PrevStateId");
static_assert(offsetof(FDelMarGameplayStateChangedEvent, NewStateId) == 0x4, "Offset mismatch for FDelMarGameplayStateChangedEvent::NewStateId");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_ResetRace
{
};

static_assert(sizeof(FDelMarEvent_ResetRace) == 0x1, "Size mismatch for FDelMarEvent_ResetRace");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_ResetRun
{
};

static_assert(sizeof(FDelMarEvent_ResetRun) == 0x1, "Size mismatch for FDelMarEvent_ResetRun");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_RaceFinished
{
};

static_assert(sizeof(FDelMarEvent_RaceFinished) == 0x8, "Size mismatch for FDelMarEvent_RaceFinished");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarEvent_FirstPlayerFinishedCountdown
{
};

static_assert(sizeof(FDelMarEvent_FirstPlayerFinishedCountdown) == 0x10, "Size mismatch for FDelMarEvent_FirstPlayerFinishedCountdown");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_RaceActive
{
};

static_assert(sizeof(FDelMarEvent_RaceActive) == 0x8, "Size mismatch for FDelMarEvent_RaceActive");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarEvent_RunActive
{
};

static_assert(sizeof(FDelMarEvent_RunActive) == 0x10, "Size mismatch for FDelMarEvent_RunActive");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_OvertimeActive
{
};

static_assert(sizeof(FDelMarEvent_OvertimeActive) == 0x8, "Size mismatch for FDelMarEvent_OvertimeActive");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarEvent_CountdownActive
{
};

static_assert(sizeof(FDelMarEvent_CountdownActive) == 0x28, "Size mismatch for FDelMarEvent_CountdownActive");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarEvent_PlayerFinishedRace
{
};

static_assert(sizeof(FDelMarEvent_PlayerFinishedRace) == 0x18, "Size mismatch for FDelMarEvent_PlayerFinishedRace");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarEvent_RacerStateChanged
{
    FGameplayTag PrevStateId; // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewStateId; // 0xc (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_RacerStateChanged) == 0x10, "Size mismatch for FDelMarEvent_RacerStateChanged");
static_assert(offsetof(FDelMarEvent_RacerStateChanged, PrevStateId) == 0x8, "Offset mismatch for FDelMarEvent_RacerStateChanged::PrevStateId");
static_assert(offsetof(FDelMarEvent_RacerStateChanged, NewStateId) == 0xc, "Offset mismatch for FDelMarEvent_RacerStateChanged::NewStateId");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_PlayerBecomeSpectator
{
};

static_assert(sizeof(FDelMarEvent_PlayerBecomeSpectator) == 0x8, "Size mismatch for FDelMarEvent_PlayerBecomeSpectator");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_RaceManagerInitialized
{
};

static_assert(sizeof(FDelMarEvent_RaceManagerInitialized) == 0x8, "Size mismatch for FDelMarEvent_RaceManagerInitialized");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_VehicleAssignedToPawn
{
};

static_assert(sizeof(FDelMarEvent_VehicleAssignedToPawn) == 0x8, "Size mismatch for FDelMarEvent_VehicleAssignedToPawn");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_ServerRaceStartCountdownTime
{
    double ServerTime; // 0x0 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarEvent_ServerRaceStartCountdownTime) == 0x8, "Size mismatch for FDelMarEvent_ServerRaceStartCountdownTime");
static_assert(offsetof(FDelMarEvent_ServerRaceStartCountdownTime, ServerTime) == 0x0, "Offset mismatch for FDelMarEvent_ServerRaceStartCountdownTime::ServerTime");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_ServerPostRaceEndTime
{
    double ServerTime; // 0x0 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarEvent_ServerPostRaceEndTime) == 0x8, "Size mismatch for FDelMarEvent_ServerPostRaceEndTime");
static_assert(offsetof(FDelMarEvent_ServerPostRaceEndTime, ServerTime) == 0x0, "Offset mismatch for FDelMarEvent_ServerPostRaceEndTime::ServerTime");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarEvent_VehicleDemolished
{
    FGameplayTag CausedByTag; // 0x8 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_VehicleDemolished) == 0xc, "Size mismatch for FDelMarEvent_VehicleDemolished");
static_assert(offsetof(FDelMarEvent_VehicleDemolished, CausedByTag) == 0x8, "Offset mismatch for FDelMarEvent_VehicleDemolished::CausedByTag");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_VehicleWrongwayStatus
{
};

static_assert(sizeof(FDelMarEvent_VehicleWrongwayStatus) == 0x1, "Size mismatch for FDelMarEvent_VehicleWrongwayStatus");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_MissedCheckpointDemoCountdown
{
};

static_assert(sizeof(FDelMarEvent_MissedCheckpointDemoCountdown) == 0x8, "Size mismatch for FDelMarEvent_MissedCheckpointDemoCountdown");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_ReturnToTrackDemoCountdown
{
};

static_assert(sizeof(FDelMarEvent_ReturnToTrackDemoCountdown) == 0x8, "Size mismatch for FDelMarEvent_ReturnToTrackDemoCountdown");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarEvent_TrackedPlayerReadyStates
{
    TArray<TWeakObjectPtr<AFortPlayerState*>> ReadyPlayers; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFortPlayerState*>> UnreadyPlayers; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarEvent_TrackedPlayerReadyStates) == 0x20, "Size mismatch for FDelMarEvent_TrackedPlayerReadyStates");
static_assert(offsetof(FDelMarEvent_TrackedPlayerReadyStates, ReadyPlayers) == 0x0, "Offset mismatch for FDelMarEvent_TrackedPlayerReadyStates::ReadyPlayers");
static_assert(offsetof(FDelMarEvent_TrackedPlayerReadyStates, UnreadyPlayers) == 0x10, "Offset mismatch for FDelMarEvent_TrackedPlayerReadyStates::UnreadyPlayers");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_LoadedPlayerStates
{
    int32_t NumLoadedPlayers; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TotalPlayers; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDelMarEvent_LoadedPlayerStates) == 0x8, "Size mismatch for FDelMarEvent_LoadedPlayerStates");
static_assert(offsetof(FDelMarEvent_LoadedPlayerStates, NumLoadedPlayers) == 0x0, "Offset mismatch for FDelMarEvent_LoadedPlayerStates::NumLoadedPlayers");
static_assert(offsetof(FDelMarEvent_LoadedPlayerStates, TotalPlayers) == 0x4, "Offset mismatch for FDelMarEvent_LoadedPlayerStates::TotalPlayers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarEvent_LoadingScreenData
{
    UDelMarLevelDataAsset* LevelData; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag RaceMode; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_LoadingScreenData) == 0x10, "Size mismatch for FDelMarEvent_LoadingScreenData");
static_assert(offsetof(FDelMarEvent_LoadingScreenData, LevelData) == 0x0, "Offset mismatch for FDelMarEvent_LoadingScreenData::LevelData");
static_assert(offsetof(FDelMarEvent_LoadingScreenData, RaceMode) == 0x8, "Offset mismatch for FDelMarEvent_LoadingScreenData::RaceMode");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDelMarEvent_DialogRequest
{
    FGameplayTag DialogTag; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_DialogRequest) == 0x4, "Size mismatch for FDelMarEvent_DialogRequest");
static_assert(offsetof(FDelMarEvent_DialogRequest, DialogTag) == 0x0, "Offset mismatch for FDelMarEvent_DialogRequest::DialogTag");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_MatchmakingReadyUp
{
    TWeakObjectPtr<UFortLocalPlayer*> LocalPlayer; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FDelMarEvent_MatchmakingReadyUp) == 0x8, "Size mismatch for FDelMarEvent_MatchmakingReadyUp");
static_assert(offsetof(FDelMarEvent_MatchmakingReadyUp, LocalPlayer) == 0x0, "Offset mismatch for FDelMarEvent_MatchmakingReadyUp::LocalPlayer");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FDelMarEvent_SetTutorialHint
{
    FText KBMText; // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText; // 0x10 (Size: 0x10, Type: TextProperty)
    FText TouchText; // 0x20 (Size: 0x10, Type: TextProperty)
    float DisplayTime; // 0x30 (Size: 0x4, Type: FloatProperty)
    int32_t Priority; // 0x34 (Size: 0x4, Type: IntProperty)
    TArray<UInputAction*> AssociatedInputActions; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarEvent_SetTutorialHint) == 0x48, "Size mismatch for FDelMarEvent_SetTutorialHint");
static_assert(offsetof(FDelMarEvent_SetTutorialHint, KBMText) == 0x0, "Offset mismatch for FDelMarEvent_SetTutorialHint::KBMText");
static_assert(offsetof(FDelMarEvent_SetTutorialHint, GamepadText) == 0x10, "Offset mismatch for FDelMarEvent_SetTutorialHint::GamepadText");
static_assert(offsetof(FDelMarEvent_SetTutorialHint, TouchText) == 0x20, "Offset mismatch for FDelMarEvent_SetTutorialHint::TouchText");
static_assert(offsetof(FDelMarEvent_SetTutorialHint, DisplayTime) == 0x30, "Offset mismatch for FDelMarEvent_SetTutorialHint::DisplayTime");
static_assert(offsetof(FDelMarEvent_SetTutorialHint, Priority) == 0x34, "Offset mismatch for FDelMarEvent_SetTutorialHint::Priority");
static_assert(offsetof(FDelMarEvent_SetTutorialHint, AssociatedInputActions) == 0x38, "Offset mismatch for FDelMarEvent_SetTutorialHint::AssociatedInputActions");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarEvent_SetTutorialAnnouncement
{
    FText KBMText; // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText; // 0x10 (Size: 0x10, Type: TextProperty)
    FText TouchText; // 0x20 (Size: 0x10, Type: TextProperty)
    TArray<UInputAction*> AssociatedInputActions; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarEvent_SetTutorialAnnouncement) == 0x40, "Size mismatch for FDelMarEvent_SetTutorialAnnouncement");
static_assert(offsetof(FDelMarEvent_SetTutorialAnnouncement, KBMText) == 0x0, "Offset mismatch for FDelMarEvent_SetTutorialAnnouncement::KBMText");
static_assert(offsetof(FDelMarEvent_SetTutorialAnnouncement, GamepadText) == 0x10, "Offset mismatch for FDelMarEvent_SetTutorialAnnouncement::GamepadText");
static_assert(offsetof(FDelMarEvent_SetTutorialAnnouncement, TouchText) == 0x20, "Offset mismatch for FDelMarEvent_SetTutorialAnnouncement::TouchText");
static_assert(offsetof(FDelMarEvent_SetTutorialAnnouncement, AssociatedInputActions) == 0x30, "Offset mismatch for FDelMarEvent_SetTutorialAnnouncement::AssociatedInputActions");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_MidTutorialModal
{
};

static_assert(sizeof(FDelMarEvent_MidTutorialModal) == 0x1, "Size mismatch for FDelMarEvent_MidTutorialModal");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarEvent_SetControlsText
{
    FText KBMText; // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText; // 0x10 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FDelMarEvent_SetControlsText) == 0x20, "Size mismatch for FDelMarEvent_SetControlsText");
static_assert(offsetof(FDelMarEvent_SetControlsText, KBMText) == 0x0, "Offset mismatch for FDelMarEvent_SetControlsText::KBMText");
static_assert(offsetof(FDelMarEvent_SetControlsText, GamepadText) == 0x10, "Offset mismatch for FDelMarEvent_SetControlsText::GamepadText");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarEvent_CheckpointPassed_ParallelPath
{
    AFortPlayerState* PlayerState; // 0x0 (Size: 0x8, Type: ObjectProperty)
    ADelMarCheckpoint* CurrentCheckPoint; // 0x8 (Size: 0x8, Type: ObjectProperty)
    int32_t CheckpointIndexForLap; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_CheckpointPassed_ParallelPath) == 0x18, "Size mismatch for FDelMarEvent_CheckpointPassed_ParallelPath");
static_assert(offsetof(FDelMarEvent_CheckpointPassed_ParallelPath, PlayerState) == 0x0, "Offset mismatch for FDelMarEvent_CheckpointPassed_ParallelPath::PlayerState");
static_assert(offsetof(FDelMarEvent_CheckpointPassed_ParallelPath, CurrentCheckPoint) == 0x8, "Offset mismatch for FDelMarEvent_CheckpointPassed_ParallelPath::CurrentCheckPoint");
static_assert(offsetof(FDelMarEvent_CheckpointPassed_ParallelPath, CheckpointIndexForLap) == 0x10, "Offset mismatch for FDelMarEvent_CheckpointPassed_ParallelPath::CheckpointIndexForLap");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath
{
    ADelMarCheckpoint* CurrentCheckPoint; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath) == 0x8, "Size mismatch for FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath");
static_assert(offsetof(FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath, CurrentCheckPoint) == 0x0, "Offset mismatch for FDelMarEvent_CheckpointPassedOutOfOrder_ParallelPath::CurrentCheckPoint");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_TeleportEnteredEvent
{
    ADelMarCheckpoint* CheckpointEntered; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEvent_TeleportEnteredEvent) == 0x8, "Size mismatch for FDelMarEvent_TeleportEnteredEvent");
static_assert(offsetof(FDelMarEvent_TeleportEnteredEvent, CheckpointEntered) == 0x0, "Offset mismatch for FDelMarEvent_TeleportEnteredEvent::CheckpointEntered");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_TeleportExitedEvent
{
    ADelMarCheckpoint* CheckpointExited; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEvent_TeleportExitedEvent) == 0x8, "Size mismatch for FDelMarEvent_TeleportExitedEvent");
static_assert(offsetof(FDelMarEvent_TeleportExitedEvent, CheckpointExited) == 0x0, "Offset mismatch for FDelMarEvent_TeleportExitedEvent::CheckpointExited");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarEvent_SectionComplete_ParallelPath
{
    int32_t ActiveLap; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SectionIndex; // 0x4 (Size: 0x4, Type: IntProperty)
    ADelMarCheckpoint* CompletedCheckpoint; // 0x8 (Size: 0x8, Type: ObjectProperty)
    ADelMarCheckpoint* CurrentCheckPoint; // 0x10 (Size: 0x8, Type: ObjectProperty)
    double CompletedSectionTime; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarEvent_SectionComplete_ParallelPath) == 0x20, "Size mismatch for FDelMarEvent_SectionComplete_ParallelPath");
static_assert(offsetof(FDelMarEvent_SectionComplete_ParallelPath, ActiveLap) == 0x0, "Offset mismatch for FDelMarEvent_SectionComplete_ParallelPath::ActiveLap");
static_assert(offsetof(FDelMarEvent_SectionComplete_ParallelPath, SectionIndex) == 0x4, "Offset mismatch for FDelMarEvent_SectionComplete_ParallelPath::SectionIndex");
static_assert(offsetof(FDelMarEvent_SectionComplete_ParallelPath, CompletedCheckpoint) == 0x8, "Offset mismatch for FDelMarEvent_SectionComplete_ParallelPath::CompletedCheckpoint");
static_assert(offsetof(FDelMarEvent_SectionComplete_ParallelPath, CurrentCheckPoint) == 0x10, "Offset mismatch for FDelMarEvent_SectionComplete_ParallelPath::CurrentCheckPoint");
static_assert(offsetof(FDelMarEvent_SectionComplete_ParallelPath, CompletedSectionTime) == 0x18, "Offset mismatch for FDelMarEvent_SectionComplete_ParallelPath::CompletedSectionTime");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_LapStarted
{
    AFortPlayerState* PlayerState; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEvent_LapStarted) == 0x8, "Size mismatch for FDelMarEvent_LapStarted");
static_assert(offsetof(FDelMarEvent_LapStarted, PlayerState) == 0x0, "Offset mismatch for FDelMarEvent_LapStarted::PlayerState");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarEvent_LapComplete
{
    AFortPlayerState* PlayerState; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t CompletedLap; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t CurrentLap; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t TotalLaps; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    double CompletedLapTime; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarEvent_LapComplete) == 0x20, "Size mismatch for FDelMarEvent_LapComplete");
static_assert(offsetof(FDelMarEvent_LapComplete, PlayerState) == 0x0, "Offset mismatch for FDelMarEvent_LapComplete::PlayerState");
static_assert(offsetof(FDelMarEvent_LapComplete, CompletedLap) == 0x8, "Offset mismatch for FDelMarEvent_LapComplete::CompletedLap");
static_assert(offsetof(FDelMarEvent_LapComplete, CurrentLap) == 0xc, "Offset mismatch for FDelMarEvent_LapComplete::CurrentLap");
static_assert(offsetof(FDelMarEvent_LapComplete, TotalLaps) == 0x10, "Offset mismatch for FDelMarEvent_LapComplete::TotalLaps");
static_assert(offsetof(FDelMarEvent_LapComplete, CompletedLapTime) == 0x18, "Offset mismatch for FDelMarEvent_LapComplete::CompletedLapTime");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarEvent_LapRecorded
{
    int32_t CompletedLap; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDelMarRunRecord CurrentRunRecord; // 0x8 (Size: 0x20, Type: StructProperty)
    float BestSingleLapTime; // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bIsNewLapRecord; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_LapRecorded) == 0x30, "Size mismatch for FDelMarEvent_LapRecorded");
static_assert(offsetof(FDelMarEvent_LapRecorded, CompletedLap) == 0x0, "Offset mismatch for FDelMarEvent_LapRecorded::CompletedLap");
static_assert(offsetof(FDelMarEvent_LapRecorded, CurrentRunRecord) == 0x8, "Offset mismatch for FDelMarEvent_LapRecorded::CurrentRunRecord");
static_assert(offsetof(FDelMarEvent_LapRecorded, BestSingleLapTime) == 0x28, "Offset mismatch for FDelMarEvent_LapRecorded::BestSingleLapTime");
static_assert(offsetof(FDelMarEvent_LapRecorded, bIsNewLapRecord) == 0x2c, "Offset mismatch for FDelMarEvent_LapRecorded::bIsNewLapRecord");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarRunRecord
{
    double RunDuration; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double RunStartTimestamp; // 0x8 (Size: 0x8, Type: DoubleProperty)
    TArray<FDelMarLapRecord> LapRecords; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarRunRecord) == 0x20, "Size mismatch for FDelMarRunRecord");
static_assert(offsetof(FDelMarRunRecord, RunDuration) == 0x0, "Offset mismatch for FDelMarRunRecord::RunDuration");
static_assert(offsetof(FDelMarRunRecord, RunStartTimestamp) == 0x8, "Offset mismatch for FDelMarRunRecord::RunStartTimestamp");
static_assert(offsetof(FDelMarRunRecord, LapRecords) == 0x10, "Offset mismatch for FDelMarRunRecord::LapRecords");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarLapRecord
{
    double LapDuration; // 0x0 (Size: 0x8, Type: DoubleProperty)
    TArray<double> SectionTimes; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarLapRecord) == 0x18, "Size mismatch for FDelMarLapRecord");
static_assert(offsetof(FDelMarLapRecord, LapDuration) == 0x0, "Offset mismatch for FDelMarLapRecord::LapDuration");
static_assert(offsetof(FDelMarLapRecord, SectionTimes) == 0x8, "Offset mismatch for FDelMarLapRecord::SectionTimes");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDelMarEvent_SectionRecorded
{
    int32_t ActiveLap; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SectionIndex; // 0x4 (Size: 0x4, Type: IntProperty)
    FDelMarRunRecord BestSectionsRunRecord; // 0x8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord CurrentRunRecord; // 0x28 (Size: 0x20, Type: StructProperty)
    bool bIsNewSectionRecord; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_SectionRecorded) == 0x50, "Size mismatch for FDelMarEvent_SectionRecorded");
static_assert(offsetof(FDelMarEvent_SectionRecorded, ActiveLap) == 0x0, "Offset mismatch for FDelMarEvent_SectionRecorded::ActiveLap");
static_assert(offsetof(FDelMarEvent_SectionRecorded, SectionIndex) == 0x4, "Offset mismatch for FDelMarEvent_SectionRecorded::SectionIndex");
static_assert(offsetof(FDelMarEvent_SectionRecorded, BestSectionsRunRecord) == 0x8, "Offset mismatch for FDelMarEvent_SectionRecorded::BestSectionsRunRecord");
static_assert(offsetof(FDelMarEvent_SectionRecorded, CurrentRunRecord) == 0x28, "Offset mismatch for FDelMarEvent_SectionRecorded::CurrentRunRecord");
static_assert(offsetof(FDelMarEvent_SectionRecorded, bIsNewSectionRecord) == 0x48, "Offset mismatch for FDelMarEvent_SectionRecorded::bIsNewSectionRecord");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDelMarEvent_RunRecorded
{
    AFortPlayerState* PlayerState; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FDelMarRunRecord CurrentRunRecord; // 0x8 (Size: 0x20, Type: StructProperty)
    FDelMarRunRecord BestRunRecord; // 0x28 (Size: 0x20, Type: StructProperty)
    bool bIsNewBestRun; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_RunRecorded) == 0x50, "Size mismatch for FDelMarEvent_RunRecorded");
static_assert(offsetof(FDelMarEvent_RunRecorded, PlayerState) == 0x0, "Offset mismatch for FDelMarEvent_RunRecorded::PlayerState");
static_assert(offsetof(FDelMarEvent_RunRecorded, CurrentRunRecord) == 0x8, "Offset mismatch for FDelMarEvent_RunRecorded::CurrentRunRecord");
static_assert(offsetof(FDelMarEvent_RunRecorded, BestRunRecord) == 0x28, "Offset mismatch for FDelMarEvent_RunRecorded::BestRunRecord");
static_assert(offsetof(FDelMarEvent_RunRecorded, bIsNewBestRun) == 0x48, "Offset mismatch for FDelMarEvent_RunRecorded::bIsNewBestRun");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_NuxConnectedHintActionPerformed
{
    FGameplayTag HintTypeTag; // 0x0 (Size: 0x4, Type: StructProperty)
    bool bDidPerformAction; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_NuxConnectedHintActionPerformed) == 0x8, "Size mismatch for FDelMarEvent_NuxConnectedHintActionPerformed");
static_assert(offsetof(FDelMarEvent_NuxConnectedHintActionPerformed, HintTypeTag) == 0x0, "Offset mismatch for FDelMarEvent_NuxConnectedHintActionPerformed::HintTypeTag");
static_assert(offsetof(FDelMarEvent_NuxConnectedHintActionPerformed, bDidPerformAction) == 0x4, "Offset mismatch for FDelMarEvent_NuxConnectedHintActionPerformed::bDidPerformAction");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDelMarEvent_RaceModeSet
{
    FGameplayTag RaceModeTag; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_RaceModeSet) == 0x4, "Size mismatch for FDelMarEvent_RaceModeSet");
static_assert(offsetof(FDelMarEvent_RaceModeSet, RaceModeTag) == 0x0, "Offset mismatch for FDelMarEvent_RaceModeSet::RaceModeTag");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FDelMarEvent_GlobalLeaderboardNewPersonalBest
{
    TWeakObjectPtr<AFortPlayerState*> Player; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FDelMarGlobalLeaderboardEntry PersonalBest; // 0x8 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_GlobalLeaderboardNewPersonalBest) == 0x48, "Size mismatch for FDelMarEvent_GlobalLeaderboardNewPersonalBest");
static_assert(offsetof(FDelMarEvent_GlobalLeaderboardNewPersonalBest, Player) == 0x0, "Offset mismatch for FDelMarEvent_GlobalLeaderboardNewPersonalBest::Player");
static_assert(offsetof(FDelMarEvent_GlobalLeaderboardNewPersonalBest, PersonalBest) == 0x8, "Offset mismatch for FDelMarEvent_GlobalLeaderboardNewPersonalBest::PersonalBest");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarGlobalLeaderboardEntry
{
    FString PlayerAccountId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString PlayerName; // 0x10 (Size: 0x10, Type: StrProperty)
    double RunDuration; // 0x20 (Size: 0x8, Type: DoubleProperty)
    int64_t Rank; // 0x28 (Size: 0x8, Type: Int64Property)
    double Percentile; // 0x30 (Size: 0x8, Type: DoubleProperty)
    bool bIsLocalPlayer; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarGlobalLeaderboardEntry) == 0x40, "Size mismatch for FDelMarGlobalLeaderboardEntry");
static_assert(offsetof(FDelMarGlobalLeaderboardEntry, PlayerAccountId) == 0x0, "Offset mismatch for FDelMarGlobalLeaderboardEntry::PlayerAccountId");
static_assert(offsetof(FDelMarGlobalLeaderboardEntry, PlayerName) == 0x10, "Offset mismatch for FDelMarGlobalLeaderboardEntry::PlayerName");
static_assert(offsetof(FDelMarGlobalLeaderboardEntry, RunDuration) == 0x20, "Offset mismatch for FDelMarGlobalLeaderboardEntry::RunDuration");
static_assert(offsetof(FDelMarGlobalLeaderboardEntry, Rank) == 0x28, "Offset mismatch for FDelMarGlobalLeaderboardEntry::Rank");
static_assert(offsetof(FDelMarGlobalLeaderboardEntry, Percentile) == 0x30, "Offset mismatch for FDelMarGlobalLeaderboardEntry::Percentile");
static_assert(offsetof(FDelMarGlobalLeaderboardEntry, bIsLocalPlayer) == 0x38, "Offset mismatch for FDelMarGlobalLeaderboardEntry::bIsLocalPlayer");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_MatchmakingStateChanged
{
    char NewPostMatchState; // 0x0 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FDelMarEvent_MatchmakingStateChanged) == 0x1, "Size mismatch for FDelMarEvent_MatchmakingStateChanged");
static_assert(offsetof(FDelMarEvent_MatchmakingStateChanged, NewPostMatchState) == 0x0, "Offset mismatch for FDelMarEvent_MatchmakingStateChanged::NewPostMatchState");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_PostRaceReturnToLobbySelected
{
};

static_assert(sizeof(FDelMarEvent_PostRaceReturnToLobbySelected) == 0x1, "Size mismatch for FDelMarEvent_PostRaceReturnToLobbySelected");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDelMarEvent_PostRaceNextRaceSelected
{
};

static_assert(sizeof(FDelMarEvent_PostRaceNextRaceSelected) == 0x1, "Size mismatch for FDelMarEvent_PostRaceNextRaceSelected");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarEvent_QuestScreenOpened
{
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag RaceState; // 0x8 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_QuestScreenOpened) == 0xc, "Size mismatch for FDelMarEvent_QuestScreenOpened");
static_assert(offsetof(FDelMarEvent_QuestScreenOpened, PlayerState) == 0x0, "Offset mismatch for FDelMarEvent_QuestScreenOpened::PlayerState");
static_assert(offsetof(FDelMarEvent_QuestScreenOpened, RaceState) == 0x8, "Offset mismatch for FDelMarEvent_QuestScreenOpened::RaceState");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_QuestScreenClosed
{
    float OpenedDuration; // 0x0 (Size: 0x4, Type: FloatProperty)
    FGameplayTag RaceState; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarEvent_QuestScreenClosed) == 0x8, "Size mismatch for FDelMarEvent_QuestScreenClosed");
static_assert(offsetof(FDelMarEvent_QuestScreenClosed, OpenedDuration) == 0x0, "Offset mismatch for FDelMarEvent_QuestScreenClosed::OpenedDuration");
static_assert(offsetof(FDelMarEvent_QuestScreenClosed, RaceState) == 0x4, "Offset mismatch for FDelMarEvent_QuestScreenClosed::RaceState");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FDelMarFloatModifier
{
    FName Category; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t Priority; // 0x4 (Size: 0x4, Type: IntProperty)
    float Value; // 0x8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EDelMarFloatOperation> Operation; // 0xc (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EDelMarModifierStackingPolicy> StackingPolicy; // 0xd (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
    int32_t Handle; // 0x10 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDelMarFloatModifier) == 0x14, "Size mismatch for FDelMarFloatModifier");
static_assert(offsetof(FDelMarFloatModifier, Category) == 0x0, "Offset mismatch for FDelMarFloatModifier::Category");
static_assert(offsetof(FDelMarFloatModifier, Priority) == 0x4, "Offset mismatch for FDelMarFloatModifier::Priority");
static_assert(offsetof(FDelMarFloatModifier, Value) == 0x8, "Offset mismatch for FDelMarFloatModifier::Value");
static_assert(offsetof(FDelMarFloatModifier, Operation) == 0xc, "Offset mismatch for FDelMarFloatModifier::Operation");
static_assert(offsetof(FDelMarFloatModifier, StackingPolicy) == 0xd, "Offset mismatch for FDelMarFloatModifier::StackingPolicy");
static_assert(offsetof(FDelMarFloatModifier, Handle) == 0x10, "Offset mismatch for FDelMarFloatModifier::Handle");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarFloatAttribute
{
    float BaseValue; // 0x0 (Size: 0x4, Type: FloatProperty)
    float FinalValue; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bClampMin; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float MinValue; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bClampMax; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float MaxValue; // 0x14 (Size: 0x4, Type: FloatProperty)
    TArray<FDelMarFloatModifier> Modifiers; // 0x18 (Size: 0x10, Type: ArrayProperty)
    int32_t CurrentHandleIdx; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarFloatAttribute) == 0x30, "Size mismatch for FDelMarFloatAttribute");
static_assert(offsetof(FDelMarFloatAttribute, BaseValue) == 0x0, "Offset mismatch for FDelMarFloatAttribute::BaseValue");
static_assert(offsetof(FDelMarFloatAttribute, FinalValue) == 0x4, "Offset mismatch for FDelMarFloatAttribute::FinalValue");
static_assert(offsetof(FDelMarFloatAttribute, bClampMin) == 0x8, "Offset mismatch for FDelMarFloatAttribute::bClampMin");
static_assert(offsetof(FDelMarFloatAttribute, MinValue) == 0xc, "Offset mismatch for FDelMarFloatAttribute::MinValue");
static_assert(offsetof(FDelMarFloatAttribute, bClampMax) == 0x10, "Offset mismatch for FDelMarFloatAttribute::bClampMax");
static_assert(offsetof(FDelMarFloatAttribute, MaxValue) == 0x14, "Offset mismatch for FDelMarFloatAttribute::MaxValue");
static_assert(offsetof(FDelMarFloatAttribute, Modifiers) == 0x18, "Offset mismatch for FDelMarFloatAttribute::Modifiers");
static_assert(offsetof(FDelMarFloatAttribute, CurrentHandleIdx) == 0x28, "Offset mismatch for FDelMarFloatAttribute::CurrentHandleIdx");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGhostReplayFrame
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FQuat Rotation; // 0x20 (Size: 0x20, Type: StructProperty)
    double time; // 0x40 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGhostReplayFrame) == 0x50, "Size mismatch for FGhostReplayFrame");
static_assert(offsetof(FGhostReplayFrame, Location) == 0x0, "Offset mismatch for FGhostReplayFrame::Location");
static_assert(offsetof(FGhostReplayFrame, Rotation) == 0x20, "Offset mismatch for FGhostReplayFrame::Rotation");
static_assert(offsetof(FGhostReplayFrame, time) == 0x40, "Offset mismatch for FGhostReplayFrame::time");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarLeaderboardSettings
{
    FString EventId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString WindowId; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDelMarLeaderboardSettings) == 0x20, "Size mismatch for FDelMarLeaderboardSettings");
static_assert(offsetof(FDelMarLeaderboardSettings, EventId) == 0x0, "Offset mismatch for FDelMarLeaderboardSettings::EventId");
static_assert(offsetof(FDelMarLeaderboardSettings, WindowId) == 0x10, "Offset mismatch for FDelMarLeaderboardSettings::WindowId");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarInputAction
{
    UInputAction* Action; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag DisabledTag; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarInputAction) == 0x10, "Size mismatch for FDelMarInputAction");
static_assert(offsetof(FDelMarInputAction, Action) == 0x0, "Offset mismatch for FDelMarInputAction::Action");
static_assert(offsetof(FDelMarInputAction, DisabledTag) == 0x8, "Offset mismatch for FDelMarInputAction::DisabledTag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarInputMappingContextData
{
    int32_t Priority; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UFortInputMappingContext* MappingContext; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarInputMappingContextData) == 0x10, "Size mismatch for FDelMarInputMappingContextData");
static_assert(offsetof(FDelMarInputMappingContextData, Priority) == 0x0, "Offset mismatch for FDelMarInputMappingContextData::Priority");
static_assert(offsetof(FDelMarInputMappingContextData, MappingContext) == 0x8, "Offset mismatch for FDelMarInputMappingContextData::MappingContext");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarActivatedInput
{
    UInputAction* Action; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector Value; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarActivatedInput) == 0x20, "Size mismatch for FDelMarActivatedInput");
static_assert(offsetof(FDelMarActivatedInput, Action) == 0x0, "Offset mismatch for FDelMarActivatedInput::Action");
static_assert(offsetof(FDelMarActivatedInput, Value) == 0x8, "Offset mismatch for FDelMarActivatedInput::Value");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarActivatedInputFrame
{
    float duration; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarActivatedInput> Inputs; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarActivatedInputFrame) == 0x18, "Size mismatch for FDelMarActivatedInputFrame");
static_assert(offsetof(FDelMarActivatedInputFrame, duration) == 0x0, "Offset mismatch for FDelMarActivatedInputFrame::duration");
static_assert(offsetof(FDelMarActivatedInputFrame, Inputs) == 0x8, "Offset mismatch for FDelMarActivatedInputFrame::Inputs");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarDisabledInputData
{
    float duration; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UClass* EffectClass; // 0x8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FDelMarDisabledInputData) == 0x10, "Size mismatch for FDelMarDisabledInputData");
static_assert(offsetof(FDelMarDisabledInputData, duration) == 0x0, "Offset mismatch for FDelMarDisabledInputData::duration");
static_assert(offsetof(FDelMarDisabledInputData, EffectClass) == 0x8, "Offset mismatch for FDelMarDisabledInputData::EffectClass");

// Size: 0x190 (Inherited: 0xa0, Single: 0xf0)
struct FDelMarObjectiveFilterBase : FObjectiveFilter
{
    FObjectiveSubjectTags LevelDescriptionId; // 0xa0 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags GameModeId; // 0xe8 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags VehicleTags; // 0x130 (Size: 0x48, Type: StructProperty)
    uint8_t RequiredPlaylistTypeInfo; // 0x178 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_179[0x7]; // 0x179 (Size: 0x7, Type: PaddingProperty)
    TArray<TSoftObjectPtr<UDelMarCosmeticItemDefinition*>> RequiredCosmetics; // 0x180 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarObjectiveFilterBase) == 0x190, "Size mismatch for FDelMarObjectiveFilterBase");
static_assert(offsetof(FDelMarObjectiveFilterBase, LevelDescriptionId) == 0xa0, "Offset mismatch for FDelMarObjectiveFilterBase::LevelDescriptionId");
static_assert(offsetof(FDelMarObjectiveFilterBase, GameModeId) == 0xe8, "Offset mismatch for FDelMarObjectiveFilterBase::GameModeId");
static_assert(offsetof(FDelMarObjectiveFilterBase, VehicleTags) == 0x130, "Offset mismatch for FDelMarObjectiveFilterBase::VehicleTags");
static_assert(offsetof(FDelMarObjectiveFilterBase, RequiredPlaylistTypeInfo) == 0x178, "Offset mismatch for FDelMarObjectiveFilterBase::RequiredPlaylistTypeInfo");
static_assert(offsetof(FDelMarObjectiveFilterBase, RequiredCosmetics) == 0x180, "Offset mismatch for FDelMarObjectiveFilterBase::RequiredCosmetics");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_BeatPlayers : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_BeatPlayers) == 0x190, "Size mismatch for FDelMarObjectiveFilter_BeatPlayers");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_BonusTurboActivated : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_BonusTurboActivated) == 0x190, "Size mismatch for FDelMarObjectiveFilter_BonusTurboActivated");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_BoostPadBonusSpeedEnded : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_BoostPadBonusSpeedEnded) == 0x190, "Size mismatch for FDelMarObjectiveFilter_BoostPadBonusSpeedEnded");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_BoostPadHit : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_BoostPadHit) == 0x190, "Size mismatch for FDelMarObjectiveFilter_BoostPadHit");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_Demolished : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_Demolished) == 0x190, "Size mismatch for FDelMarObjectiveFilter_Demolished");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_DistanceTraveled : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_DistanceTraveled) == 0x190, "Size mismatch for FDelMarObjectiveFilter_DistanceTraveled");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_DraftActivated : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_DraftActivated) == 0x190, "Size mismatch for FDelMarObjectiveFilter_DraftActivated");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_DriftBoostActivated : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredDriftBoostPercent; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_DriftBoostActivated) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_DriftBoostActivated");
static_assert(offsetof(FDelMarObjectiveFilter_DriftBoostActivated, RequiredDriftBoostPercent) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_DriftBoostActivated::RequiredDriftBoostPercent");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_DriftBoostDeactivated : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredTotalDistance; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_DriftBoostDeactivated) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_DriftBoostDeactivated");
static_assert(offsetof(FDelMarObjectiveFilter_DriftBoostDeactivated, RequiredTotalDistance) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_DriftBoostDeactivated::RequiredTotalDistance");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_DriftComplete : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredDriftDuration; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_DriftComplete) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_DriftComplete");
static_assert(offsetof(FDelMarObjectiveFilter_DriftComplete, RequiredDriftDuration) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_DriftComplete::RequiredDriftDuration");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_HighestSpeedUpdated : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredHighestSpeed; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_HighestSpeedUpdated) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_HighestSpeedUpdated");
static_assert(offsetof(FDelMarObjectiveFilter_HighestSpeedUpdated, RequiredHighestSpeed) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_HighestSpeedUpdated::RequiredHighestSpeed");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_InitialTurboActivated : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_InitialTurboActivated) == 0x190, "Size mismatch for FDelMarObjectiveFilter_InitialTurboActivated");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_JellyHit : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_JellyHit) == 0x190, "Size mismatch for FDelMarObjectiveFilter_JellyHit");

// Size: 0x198 (Inherited: 0x230, Single: 0xffffff68)
struct FDelMarObjectiveFilter_Kickflipped : FDelMarObjectiveFilterBase
{
    uint8_t RequiredKickflipDirection; // 0x190 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_191[0x7]; // 0x191 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_Kickflipped) == 0x198, "Size mismatch for FDelMarObjectiveFilter_Kickflipped");
static_assert(offsetof(FDelMarObjectiveFilter_Kickflipped, RequiredKickflipDirection) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_Kickflipped::RequiredKickflipDirection");

// Size: 0x1d0 (Inherited: 0x230, Single: 0xffffffa0)
struct FDelMarObjectiveFilter_LapComplete : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredLapCompleteTime; // 0x190 (Size: 0x20, Type: StructProperty)
    FInt32Range RequiredLapCount; // 0x1b0 (Size: 0x10, Type: StructProperty)
    FInt32Range RequiredLapPlacement; // 0x1c0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_LapComplete) == 0x1d0, "Size mismatch for FDelMarObjectiveFilter_LapComplete");
static_assert(offsetof(FDelMarObjectiveFilter_LapComplete, RequiredLapCompleteTime) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_LapComplete::RequiredLapCompleteTime");
static_assert(offsetof(FDelMarObjectiveFilter_LapComplete, RequiredLapCount) == 0x1b0, "Offset mismatch for FDelMarObjectiveFilter_LapComplete::RequiredLapCount");
static_assert(offsetof(FDelMarObjectiveFilter_LapComplete, RequiredLapPlacement) == 0x1c0, "Offset mismatch for FDelMarObjectiveFilter_LapComplete::RequiredLapPlacement");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_LapStarted : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_LapStarted) == 0x190, "Size mismatch for FDelMarObjectiveFilter_LapStarted");

// Size: 0x1a8 (Inherited: 0x230, Single: 0xffffff78)
struct FDelMarObjectiveFilter_PlacementUpdated : FDelMarObjectiveFilterBase
{
    FInt32Range RequiredCurrentPosition; // 0x190 (Size: 0x10, Type: StructProperty)
    uint8_t RequiredPositionChangeInfo; // 0x1a0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1a1[0x7]; // 0x1a1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_PlacementUpdated) == 0x1a8, "Size mismatch for FDelMarObjectiveFilter_PlacementUpdated");
static_assert(offsetof(FDelMarObjectiveFilter_PlacementUpdated, RequiredCurrentPosition) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_PlacementUpdated::RequiredCurrentPosition");
static_assert(offsetof(FDelMarObjectiveFilter_PlacementUpdated, RequiredPositionChangeInfo) == 0x1a0, "Offset mismatch for FDelMarObjectiveFilter_PlacementUpdated::RequiredPositionChangeInfo");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_PlayedDelMarExperience : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_PlayedDelMarExperience) == 0x190, "Size mismatch for FDelMarObjectiveFilter_PlayedDelMarExperience");

// Size: 0x1d8 (Inherited: 0x230, Single: 0xffffffa8)
struct FDelMarObjectiveFilter_RaceFinished : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredFinishTime; // 0x190 (Size: 0x20, Type: StructProperty)
    FInt32Range RequiredFinalPlacement; // 0x1b0 (Size: 0x10, Type: StructProperty)
    FInt32Range RequiredPlayerCompetitiveRank; // 0x1c0 (Size: 0x10, Type: StructProperty)
    uint8_t RequiredJellyHazardInfo[0x4]; // 0x1d0 (Size: 0x4, Type: EnumProperty)
    uint8_t RequiredDemolishedInfo[0x4]; // 0x1d4 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_RaceFinished) == 0x1d8, "Size mismatch for FDelMarObjectiveFilter_RaceFinished");
static_assert(offsetof(FDelMarObjectiveFilter_RaceFinished, RequiredFinishTime) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_RaceFinished::RequiredFinishTime");
static_assert(offsetof(FDelMarObjectiveFilter_RaceFinished, RequiredFinalPlacement) == 0x1b0, "Offset mismatch for FDelMarObjectiveFilter_RaceFinished::RequiredFinalPlacement");
static_assert(offsetof(FDelMarObjectiveFilter_RaceFinished, RequiredPlayerCompetitiveRank) == 0x1c0, "Offset mismatch for FDelMarObjectiveFilter_RaceFinished::RequiredPlayerCompetitiveRank");
static_assert(offsetof(FDelMarObjectiveFilter_RaceFinished, RequiredJellyHazardInfo) == 0x1d0, "Offset mismatch for FDelMarObjectiveFilter_RaceFinished::RequiredJellyHazardInfo");
static_assert(offsetof(FDelMarObjectiveFilter_RaceFinished, RequiredDemolishedInfo) == 0x1d4, "Offset mismatch for FDelMarObjectiveFilter_RaceFinished::RequiredDemolishedInfo");

// Size: 0x1a0 (Inherited: 0x230, Single: 0xffffff70)
struct FDelMarObjectiveFilter_RankAchieved : FDelMarObjectiveFilterBase
{
    FInt32Range RequiredRank; // 0x190 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_RankAchieved) == 0x1a0, "Size mismatch for FDelMarObjectiveFilter_RankAchieved");
static_assert(offsetof(FDelMarObjectiveFilter_RankAchieved, RequiredRank) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_RankAchieved::RequiredRank");

// Size: 0x1c8 (Inherited: 0x230, Single: 0xffffff98)
struct FDelMarObjectiveFilter_RunComplete : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredFinishTime; // 0x190 (Size: 0x20, Type: StructProperty)
    FInt32Range RequiredFinalPlacement; // 0x1b0 (Size: 0x10, Type: StructProperty)
    uint8_t RequiredJellyHazardInfo[0x4]; // 0x1c0 (Size: 0x4, Type: EnumProperty)
    uint8_t RequiredDemolishedInfo[0x4]; // 0x1c4 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_RunComplete) == 0x1c8, "Size mismatch for FDelMarObjectiveFilter_RunComplete");
static_assert(offsetof(FDelMarObjectiveFilter_RunComplete, RequiredFinishTime) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_RunComplete::RequiredFinishTime");
static_assert(offsetof(FDelMarObjectiveFilter_RunComplete, RequiredFinalPlacement) == 0x1b0, "Offset mismatch for FDelMarObjectiveFilter_RunComplete::RequiredFinalPlacement");
static_assert(offsetof(FDelMarObjectiveFilter_RunComplete, RequiredJellyHazardInfo) == 0x1c0, "Offset mismatch for FDelMarObjectiveFilter_RunComplete::RequiredJellyHazardInfo");
static_assert(offsetof(FDelMarObjectiveFilter_RunComplete, RequiredDemolishedInfo) == 0x1c4, "Offset mismatch for FDelMarObjectiveFilter_RunComplete::RequiredDemolishedInfo");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_StartlineBoostActivated : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredStartlineBoostPercent; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_StartlineBoostActivated) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_StartlineBoostActivated");
static_assert(offsetof(FDelMarObjectiveFilter_StartlineBoostActivated, RequiredStartlineBoostPercent) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_StartlineBoostActivated::RequiredStartlineBoostPercent");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_StartlineBoostPercentEarned : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_StartlineBoostPercentEarned) == 0x190, "Size mismatch for FDelMarObjectiveFilter_StartlineBoostPercentEarned");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_UnderthrustDeactivated : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredPercentUsed; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_UnderthrustDeactivated) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_UnderthrustDeactivated");
static_assert(offsetof(FDelMarObjectiveFilter_UnderthrustDeactivated, RequiredPercentUsed) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_UnderthrustDeactivated::RequiredPercentUsed");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_UnderthrustPercentUsed : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_UnderthrustPercentUsed) == 0x190, "Size mismatch for FDelMarObjectiveFilter_UnderthrustPercentUsed");

// Size: 0x190 (Inherited: 0x230, Single: 0xffffff60)
struct FDelMarObjectiveFilter_VehicleJumped : FDelMarObjectiveFilterBase
{
};

static_assert(sizeof(FDelMarObjectiveFilter_VehicleJumped) == 0x190, "Size mismatch for FDelMarObjectiveFilter_VehicleJumped");

// Size: 0x1b0 (Inherited: 0x230, Single: 0xffffff80)
struct FDelMarObjectiveFilter_VehicleLanded : FDelMarObjectiveFilterBase
{
    FDoubleRange RequiredTimeInAir; // 0x190 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDelMarObjectiveFilter_VehicleLanded) == 0x1b0, "Size mismatch for FDelMarObjectiveFilter_VehicleLanded");
static_assert(offsetof(FDelMarObjectiveFilter_VehicleLanded, RequiredTimeInAir) == 0x190, "Offset mismatch for FDelMarObjectiveFilter_VehicleLanded::RequiredTimeInAir");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarAnalyticsPlayerRaceData
{
    AFortPlayerController* DriverPC; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x38]; // 0x8 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarAnalyticsPlayerRaceData) == 0x40, "Size mismatch for FDelMarAnalyticsPlayerRaceData");
static_assert(offsetof(FDelMarAnalyticsPlayerRaceData, DriverPC) == 0x0, "Offset mismatch for FDelMarAnalyticsPlayerRaceData::DriverPC");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarProxyMeshMaterialInfo
{
    TArray<UMaterialInstanceDynamic*> MaterialArray; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarProxyMeshMaterialInfo) == 0x10, "Size mismatch for FDelMarProxyMeshMaterialInfo");
static_assert(offsetof(FDelMarProxyMeshMaterialInfo, MaterialArray) == 0x0, "Offset mismatch for FDelMarProxyMeshMaterialInfo::MaterialArray");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarRaceCVar
{
    FString VariableName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarRaceCVar) == 0x30, "Size mismatch for FDelMarRaceCVar");
static_assert(offsetof(FDelMarRaceCVar, VariableName) == 0x0, "Offset mismatch for FDelMarRaceCVar::VariableName");
static_assert(offsetof(FDelMarRaceCVar, Value) == 0x10, "Offset mismatch for FDelMarRaceCVar::Value");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarMusicTrack
{
    USoundWave* StartLineIntro; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundWave* MainTrack; // 0x8 (Size: 0x8, Type: ObjectProperty)
    USoundWave* MainTrack_LowSpec; // 0x10 (Size: 0x8, Type: ObjectProperty)
    float BPM; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarMusicTrack) == 0x20, "Size mismatch for FDelMarMusicTrack");
static_assert(offsetof(FDelMarMusicTrack, StartLineIntro) == 0x0, "Offset mismatch for FDelMarMusicTrack::StartLineIntro");
static_assert(offsetof(FDelMarMusicTrack, MainTrack) == 0x8, "Offset mismatch for FDelMarMusicTrack::MainTrack");
static_assert(offsetof(FDelMarMusicTrack, MainTrack_LowSpec) == 0x10, "Offset mismatch for FDelMarMusicTrack::MainTrack_LowSpec");
static_assert(offsetof(FDelMarMusicTrack, BPM) == 0x18, "Offset mismatch for FDelMarMusicTrack::BPM");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDelMarEvent_MusicPlaylistUpdated
{
    TWeakObjectPtr<USoundBase*> PreRaceMusic; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USoundBase*> PostRaceMusic; // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_18[0x4]; // 0x18 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_MusicPlaylistUpdated) == 0x1c, "Size mismatch for FDelMarEvent_MusicPlaylistUpdated");
static_assert(offsetof(FDelMarEvent_MusicPlaylistUpdated, PreRaceMusic) == 0x8, "Offset mismatch for FDelMarEvent_MusicPlaylistUpdated::PreRaceMusic");
static_assert(offsetof(FDelMarEvent_MusicPlaylistUpdated, PostRaceMusic) == 0x10, "Offset mismatch for FDelMarEvent_MusicPlaylistUpdated::PostRaceMusic");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FDelMarTutorialSection
{
    float FinishTargetTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    ADelMarStartLineActor* StartLine; // 0x8 (Size: 0x8, Type: ObjectProperty)
    ADelMarStartLineActor* FinishLine; // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> DisabledActors; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer InputDisabledTags; // 0x28 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleAbilityConfig VehicleAbilityConfig; // 0x48 (Size: 0x11, Type: StructProperty)
    uint8_t Pad_59[0x3]; // 0x59 (Size: 0x3, Type: PaddingProperty)
    float StartingTurboCharges; // 0x5c (Size: 0x4, Type: FloatProperty)
    FText Title; // 0x60 (Size: 0x10, Type: TextProperty)
    FDelMarEvent_SetControlsText ControlsText; // 0x70 (Size: 0x20, Type: StructProperty)
    FGameplayTag DialogTag; // 0x90 (Size: 0x4, Type: StructProperty)
    bool bSkipCountdown; // 0x94 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_95[0x3]; // 0x95 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarTutorialSection) == 0x98, "Size mismatch for FDelMarTutorialSection");
static_assert(offsetof(FDelMarTutorialSection, FinishTargetTime) == 0x0, "Offset mismatch for FDelMarTutorialSection::FinishTargetTime");
static_assert(offsetof(FDelMarTutorialSection, StartLine) == 0x8, "Offset mismatch for FDelMarTutorialSection::StartLine");
static_assert(offsetof(FDelMarTutorialSection, FinishLine) == 0x10, "Offset mismatch for FDelMarTutorialSection::FinishLine");
static_assert(offsetof(FDelMarTutorialSection, DisabledActors) == 0x18, "Offset mismatch for FDelMarTutorialSection::DisabledActors");
static_assert(offsetof(FDelMarTutorialSection, InputDisabledTags) == 0x28, "Offset mismatch for FDelMarTutorialSection::InputDisabledTags");
static_assert(offsetof(FDelMarTutorialSection, VehicleAbilityConfig) == 0x48, "Offset mismatch for FDelMarTutorialSection::VehicleAbilityConfig");
static_assert(offsetof(FDelMarTutorialSection, StartingTurboCharges) == 0x5c, "Offset mismatch for FDelMarTutorialSection::StartingTurboCharges");
static_assert(offsetof(FDelMarTutorialSection, Title) == 0x60, "Offset mismatch for FDelMarTutorialSection::Title");
static_assert(offsetof(FDelMarTutorialSection, ControlsText) == 0x70, "Offset mismatch for FDelMarTutorialSection::ControlsText");
static_assert(offsetof(FDelMarTutorialSection, DialogTag) == 0x90, "Offset mismatch for FDelMarTutorialSection::DialogTag");
static_assert(offsetof(FDelMarTutorialSection, bSkipCountdown) == 0x94, "Offset mismatch for FDelMarTutorialSection::bSkipCountdown");

// Size: 0x11 (Inherited: 0x0, Single: 0x11)
struct FDelMarVehicleAbilityConfig
{
    bool bAirControlEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAirFreestyleEnabled; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bAirThrottleEnabled; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAutoAerialRotationEnabled; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bAutoUprightEnabled; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bDraftingEnabled; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bDriftEnabled; // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bDriftBoostEnabled; // 0x7 (Size: 0x1, Type: BoolProperty)
    bool bInfiniteUnderthrustEnabled; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bJumpEnabled; // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bKickflipEnabled; // 0xa (Size: 0x1, Type: BoolProperty)
    bool bOversteerEnabled; // 0xb (Size: 0x1, Type: BoolProperty)
    bool bReattachmentEnabled; // 0xc (Size: 0x1, Type: BoolProperty)
    bool bStartlineBoostEnabled; // 0xd (Size: 0x1, Type: BoolProperty)
    bool bStrafeEnabled; // 0xe (Size: 0x1, Type: BoolProperty)
    bool bTurboEnabled; // 0xf (Size: 0x1, Type: BoolProperty)
    bool bUnderthrustEnabled; // 0x10 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FDelMarVehicleAbilityConfig) == 0x11, "Size mismatch for FDelMarVehicleAbilityConfig");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bAirControlEnabled) == 0x0, "Offset mismatch for FDelMarVehicleAbilityConfig::bAirControlEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bAirFreestyleEnabled) == 0x1, "Offset mismatch for FDelMarVehicleAbilityConfig::bAirFreestyleEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bAirThrottleEnabled) == 0x2, "Offset mismatch for FDelMarVehicleAbilityConfig::bAirThrottleEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bAutoAerialRotationEnabled) == 0x3, "Offset mismatch for FDelMarVehicleAbilityConfig::bAutoAerialRotationEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bAutoUprightEnabled) == 0x4, "Offset mismatch for FDelMarVehicleAbilityConfig::bAutoUprightEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bDraftingEnabled) == 0x5, "Offset mismatch for FDelMarVehicleAbilityConfig::bDraftingEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bDriftEnabled) == 0x6, "Offset mismatch for FDelMarVehicleAbilityConfig::bDriftEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bDriftBoostEnabled) == 0x7, "Offset mismatch for FDelMarVehicleAbilityConfig::bDriftBoostEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bInfiniteUnderthrustEnabled) == 0x8, "Offset mismatch for FDelMarVehicleAbilityConfig::bInfiniteUnderthrustEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bJumpEnabled) == 0x9, "Offset mismatch for FDelMarVehicleAbilityConfig::bJumpEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bKickflipEnabled) == 0xa, "Offset mismatch for FDelMarVehicleAbilityConfig::bKickflipEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bOversteerEnabled) == 0xb, "Offset mismatch for FDelMarVehicleAbilityConfig::bOversteerEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bReattachmentEnabled) == 0xc, "Offset mismatch for FDelMarVehicleAbilityConfig::bReattachmentEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bStartlineBoostEnabled) == 0xd, "Offset mismatch for FDelMarVehicleAbilityConfig::bStartlineBoostEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bStrafeEnabled) == 0xe, "Offset mismatch for FDelMarVehicleAbilityConfig::bStrafeEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bTurboEnabled) == 0xf, "Offset mismatch for FDelMarVehicleAbilityConfig::bTurboEnabled");
static_assert(offsetof(FDelMarVehicleAbilityConfig, bUnderthrustEnabled) == 0x10, "Offset mismatch for FDelMarVehicleAbilityConfig::bUnderthrustEnabled");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FDelMarEvent_TutorialSectionChanged
{
    FDelMarTutorialSection CurrentSection; // 0x0 (Size: 0x98, Type: StructProperty)
    int32_t CurrentSectionIndex; // 0x98 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarEvent_TutorialSectionChanged) == 0xa0, "Size mismatch for FDelMarEvent_TutorialSectionChanged");
static_assert(offsetof(FDelMarEvent_TutorialSectionChanged, CurrentSection) == 0x0, "Offset mismatch for FDelMarEvent_TutorialSectionChanged::CurrentSection");
static_assert(offsetof(FDelMarEvent_TutorialSectionChanged, CurrentSectionIndex) == 0x98, "Offset mismatch for FDelMarEvent_TutorialSectionChanged::CurrentSectionIndex");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FDelMarScaledCurve
{
    float Scale; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FRuntimeFloatCurve Curve; // 0x8 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(FDelMarScaledCurve) == 0x90, "Size mismatch for FDelMarScaledCurve");
static_assert(offsetof(FDelMarScaledCurve, Scale) == 0x0, "Offset mismatch for FDelMarScaledCurve::Scale");
static_assert(offsetof(FDelMarScaledCurve, Curve) == 0x8, "Offset mismatch for FDelMarScaledCurve::Curve");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarHintText
{
    FText KBMText; // 0x0 (Size: 0x10, Type: TextProperty)
    FText GamepadText; // 0x10 (Size: 0x10, Type: TextProperty)
    FText TouchText; // 0x20 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FDelMarHintText) == 0x30, "Size mismatch for FDelMarHintText");
static_assert(offsetof(FDelMarHintText, KBMText) == 0x0, "Offset mismatch for FDelMarHintText::KBMText");
static_assert(offsetof(FDelMarHintText, GamepadText) == 0x10, "Offset mismatch for FDelMarHintText::GamepadText");
static_assert(offsetof(FDelMarHintText, TouchText) == 0x20, "Offset mismatch for FDelMarHintText::TouchText");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FDelMarVehicleSuspensionConfig
{
    float MaxRaise; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxDrop; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Stiffness; // 0x8 (Size: 0x4, Type: FloatProperty)
    float DampingCompression; // 0xc (Size: 0x4, Type: FloatProperty)
    float DampingRelaxation; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleSuspensionConfig) == 0x14, "Size mismatch for FDelMarVehicleSuspensionConfig");
static_assert(offsetof(FDelMarVehicleSuspensionConfig, MaxRaise) == 0x0, "Offset mismatch for FDelMarVehicleSuspensionConfig::MaxRaise");
static_assert(offsetof(FDelMarVehicleSuspensionConfig, MaxDrop) == 0x4, "Offset mismatch for FDelMarVehicleSuspensionConfig::MaxDrop");
static_assert(offsetof(FDelMarVehicleSuspensionConfig, Stiffness) == 0x8, "Offset mismatch for FDelMarVehicleSuspensionConfig::Stiffness");
static_assert(offsetof(FDelMarVehicleSuspensionConfig, DampingCompression) == 0xc, "Offset mismatch for FDelMarVehicleSuspensionConfig::DampingCompression");
static_assert(offsetof(FDelMarVehicleSuspensionConfig, DampingRelaxation) == 0x10, "Offset mismatch for FDelMarVehicleSuspensionConfig::DampingRelaxation");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarVehicleAxleConfig
{
    float TranslateX; // 0x0 (Size: 0x4, Type: FloatProperty)
    float TranslateY; // 0x4 (Size: 0x4, Type: FloatProperty)
    float TranslateZ; // 0x8 (Size: 0x4, Type: FloatProperty)
    float WheelRadius; // 0xc (Size: 0x4, Type: FloatProperty)
    float RestDistanceZ; // 0x10 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleSuspensionConfig Suspension; // 0x14 (Size: 0x14, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleAxleConfig) == 0x28, "Size mismatch for FDelMarVehicleAxleConfig");
static_assert(offsetof(FDelMarVehicleAxleConfig, TranslateX) == 0x0, "Offset mismatch for FDelMarVehicleAxleConfig::TranslateX");
static_assert(offsetof(FDelMarVehicleAxleConfig, TranslateY) == 0x4, "Offset mismatch for FDelMarVehicleAxleConfig::TranslateY");
static_assert(offsetof(FDelMarVehicleAxleConfig, TranslateZ) == 0x8, "Offset mismatch for FDelMarVehicleAxleConfig::TranslateZ");
static_assert(offsetof(FDelMarVehicleAxleConfig, WheelRadius) == 0xc, "Offset mismatch for FDelMarVehicleAxleConfig::WheelRadius");
static_assert(offsetof(FDelMarVehicleAxleConfig, RestDistanceZ) == 0x10, "Offset mismatch for FDelMarVehicleAxleConfig::RestDistanceZ");
static_assert(offsetof(FDelMarVehicleAxleConfig, Suspension) == 0x14, "Offset mismatch for FDelMarVehicleAxleConfig::Suspension");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FDelMarCameraFloatProperty
{
    bool bEvaluateInputOnCurve; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAccumulateInput; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    FRuntimeFloatCurve Curve; // 0x8 (Size: 0x88, Type: StructProperty)
    float InterpLambda; // 0x90 (Size: 0x4, Type: FloatProperty)
    float DecayLambda; // 0x94 (Size: 0x4, Type: FloatProperty)
    FFloatRange ClampedRange; // 0x98 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarCameraFloatProperty) == 0xb0, "Size mismatch for FDelMarCameraFloatProperty");
static_assert(offsetof(FDelMarCameraFloatProperty, bEvaluateInputOnCurve) == 0x0, "Offset mismatch for FDelMarCameraFloatProperty::bEvaluateInputOnCurve");
static_assert(offsetof(FDelMarCameraFloatProperty, bAccumulateInput) == 0x1, "Offset mismatch for FDelMarCameraFloatProperty::bAccumulateInput");
static_assert(offsetof(FDelMarCameraFloatProperty, Curve) == 0x8, "Offset mismatch for FDelMarCameraFloatProperty::Curve");
static_assert(offsetof(FDelMarCameraFloatProperty, InterpLambda) == 0x90, "Offset mismatch for FDelMarCameraFloatProperty::InterpLambda");
static_assert(offsetof(FDelMarCameraFloatProperty, DecayLambda) == 0x94, "Offset mismatch for FDelMarCameraFloatProperty::DecayLambda");
static_assert(offsetof(FDelMarCameraFloatProperty, ClampedRange) == 0x98, "Offset mismatch for FDelMarCameraFloatProperty::ClampedRange");

// Size: 0x1d0 (Inherited: 0x0, Single: 0x1d0)
struct FDelMarCameraFloatBlendedProperty
{
    bool bEvaluateInputOnCurve; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FRuntimeFloatCurve InputCurve; // 0x8 (Size: 0x88, Type: StructProperty)
    float ActiveValue; // 0x90 (Size: 0x4, Type: FloatProperty)
    bool bRemapOutputValue; // 0x94 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_95[0x3]; // 0x95 (Size: 0x3, Type: PaddingProperty)
    FRuntimeFloatCurve RemapCurve; // 0x98 (Size: 0x88, Type: StructProperty)
    float BlendInLambda; // 0x120 (Size: 0x4, Type: FloatProperty)
    float BlendOutLambda; // 0x124 (Size: 0x4, Type: FloatProperty)
    bool bUseBlendOutCurve; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x7]; // 0x129 (Size: 0x7, Type: PaddingProperty)
    FRuntimeFloatCurve BlendOutLambdaCurve; // 0x130 (Size: 0x88, Type: StructProperty)
    float Tolerance; // 0x1b8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1bc[0x14]; // 0x1bc (Size: 0x14, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarCameraFloatBlendedProperty) == 0x1d0, "Size mismatch for FDelMarCameraFloatBlendedProperty");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, bEvaluateInputOnCurve) == 0x0, "Offset mismatch for FDelMarCameraFloatBlendedProperty::bEvaluateInputOnCurve");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, InputCurve) == 0x8, "Offset mismatch for FDelMarCameraFloatBlendedProperty::InputCurve");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, ActiveValue) == 0x90, "Offset mismatch for FDelMarCameraFloatBlendedProperty::ActiveValue");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, bRemapOutputValue) == 0x94, "Offset mismatch for FDelMarCameraFloatBlendedProperty::bRemapOutputValue");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, RemapCurve) == 0x98, "Offset mismatch for FDelMarCameraFloatBlendedProperty::RemapCurve");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, BlendInLambda) == 0x120, "Offset mismatch for FDelMarCameraFloatBlendedProperty::BlendInLambda");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, BlendOutLambda) == 0x124, "Offset mismatch for FDelMarCameraFloatBlendedProperty::BlendOutLambda");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, bUseBlendOutCurve) == 0x128, "Offset mismatch for FDelMarCameraFloatBlendedProperty::bUseBlendOutCurve");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, BlendOutLambdaCurve) == 0x130, "Offset mismatch for FDelMarCameraFloatBlendedProperty::BlendOutLambdaCurve");
static_assert(offsetof(FDelMarCameraFloatBlendedProperty, Tolerance) == 0x1b8, "Offset mismatch for FDelMarCameraFloatBlendedProperty::Tolerance");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarDefaultCameraValues
{
    float FOV; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Distance; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Height; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AngleToOriginDegrees; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarDefaultCameraValues) == 0x10, "Size mismatch for FDelMarDefaultCameraValues");
static_assert(offsetof(FDelMarDefaultCameraValues, FOV) == 0x0, "Offset mismatch for FDelMarDefaultCameraValues::FOV");
static_assert(offsetof(FDelMarDefaultCameraValues, Distance) == 0x4, "Offset mismatch for FDelMarDefaultCameraValues::Distance");
static_assert(offsetof(FDelMarDefaultCameraValues, Height) == 0x8, "Offset mismatch for FDelMarDefaultCameraValues::Height");
static_assert(offsetof(FDelMarDefaultCameraValues, AngleToOriginDegrees) == 0xc, "Offset mismatch for FDelMarDefaultCameraValues::AngleToOriginDegrees");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FDelMarVehicleReplay_FrameData
{
    int32_t FrameCaptureIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double SecondsSinceCountdownFinished; // 0x8 (Size: 0x8, Type: DoubleProperty)
    FDelMarVehicleReplay_InputState_RL Input; // 0x10 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleReplay_InputState_DM Input_DM; // 0x30 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FDelMarVehicleReplay_RigidBodyState PreSimRBState; // 0x40 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleReplay_FrameData) == 0xb0, "Size mismatch for FDelMarVehicleReplay_FrameData");
static_assert(offsetof(FDelMarVehicleReplay_FrameData, FrameCaptureIndex) == 0x0, "Offset mismatch for FDelMarVehicleReplay_FrameData::FrameCaptureIndex");
static_assert(offsetof(FDelMarVehicleReplay_FrameData, SecondsSinceCountdownFinished) == 0x8, "Offset mismatch for FDelMarVehicleReplay_FrameData::SecondsSinceCountdownFinished");
static_assert(offsetof(FDelMarVehicleReplay_FrameData, Input) == 0x10, "Offset mismatch for FDelMarVehicleReplay_FrameData::Input");
static_assert(offsetof(FDelMarVehicleReplay_FrameData, Input_DM) == 0x30, "Offset mismatch for FDelMarVehicleReplay_FrameData::Input_DM");
static_assert(offsetof(FDelMarVehicleReplay_FrameData, PreSimRBState) == 0x40, "Offset mismatch for FDelMarVehicleReplay_FrameData::PreSimRBState");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FDelMarVehicleReplay_RigidBodyState
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FQuat Rotation; // 0x20 (Size: 0x20, Type: StructProperty)
    FVector LinearVelocity; // 0x40 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x58 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleReplay_RigidBodyState) == 0x70, "Size mismatch for FDelMarVehicleReplay_RigidBodyState");
static_assert(offsetof(FDelMarVehicleReplay_RigidBodyState, Location) == 0x0, "Offset mismatch for FDelMarVehicleReplay_RigidBodyState::Location");
static_assert(offsetof(FDelMarVehicleReplay_RigidBodyState, Rotation) == 0x20, "Offset mismatch for FDelMarVehicleReplay_RigidBodyState::Rotation");
static_assert(offsetof(FDelMarVehicleReplay_RigidBodyState, LinearVelocity) == 0x40, "Offset mismatch for FDelMarVehicleReplay_RigidBodyState::LinearVelocity");
static_assert(offsetof(FDelMarVehicleReplay_RigidBodyState, AngularVelocity) == 0x58, "Offset mismatch for FDelMarVehicleReplay_RigidBodyState::AngularVelocity");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleReplay_InputState_DM
{
    float AerialPitch; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bDrift; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bGroundedFlip; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bKickflip; // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bShunt; // 0x7 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FDelMarVehicleReplay_InputState_DM) == 0x8, "Size mismatch for FDelMarVehicleReplay_InputState_DM");
static_assert(offsetof(FDelMarVehicleReplay_InputState_DM, AerialPitch) == 0x0, "Offset mismatch for FDelMarVehicleReplay_InputState_DM::AerialPitch");
static_assert(offsetof(FDelMarVehicleReplay_InputState_DM, bDrift) == 0x4, "Offset mismatch for FDelMarVehicleReplay_InputState_DM::bDrift");
static_assert(offsetof(FDelMarVehicleReplay_InputState_DM, bGroundedFlip) == 0x5, "Offset mismatch for FDelMarVehicleReplay_InputState_DM::bGroundedFlip");
static_assert(offsetof(FDelMarVehicleReplay_InputState_DM, bKickflip) == 0x6, "Offset mismatch for FDelMarVehicleReplay_InputState_DM::bKickflip");
static_assert(offsetof(FDelMarVehicleReplay_InputState_DM, bShunt) == 0x7, "Offset mismatch for FDelMarVehicleReplay_InputState_DM::bShunt");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarVehicleReplay_InputState_RL
{
    float Throttle; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Steer; // 0x4 (Size: 0x4, Type: FloatProperty)
    float pitch; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Yaw; // 0xc (Size: 0x4, Type: FloatProperty)
    float Roll; // 0x10 (Size: 0x4, Type: FloatProperty)
    float DodgeForward; // 0x14 (Size: 0x4, Type: FloatProperty)
    float DodgeRight; // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bHandbrake; // 0x1c (Size: 0x1, Type: BoolProperty)
    bool bJump; // 0x1d (Size: 0x1, Type: BoolProperty)
    bool bBoost; // 0x1e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f[0x1]; // 0x1f (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleReplay_InputState_RL) == 0x20, "Size mismatch for FDelMarVehicleReplay_InputState_RL");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, Throttle) == 0x0, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::Throttle");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, Steer) == 0x4, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::Steer");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, pitch) == 0x8, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::pitch");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, Yaw) == 0xc, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::Yaw");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, Roll) == 0x10, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::Roll");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, DodgeForward) == 0x14, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::DodgeForward");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, DodgeRight) == 0x18, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::DodgeRight");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, bHandbrake) == 0x1c, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::bHandbrake");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, bJump) == 0x1d, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::bJump");
static_assert(offsetof(FDelMarVehicleReplay_InputState_RL, bBoost) == 0x1e, "Offset mismatch for FDelMarVehicleReplay_InputState_RL::bBoost");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FDelMarVehicleCachedContact
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Impulse; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector DeltaVelocity; // 0x48 (Size: 0x18, Type: StructProperty)
    bool bVehicleContact; // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bDriveableContact; // 0x61 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_62[0x2]; // 0x62 (Size: 0x2, Type: PaddingProperty)
    TWeakObjectPtr<UPrimitiveComponent*> Component; // 0x64 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleCachedContact) == 0x70, "Size mismatch for FDelMarVehicleCachedContact");
static_assert(offsetof(FDelMarVehicleCachedContact, Location) == 0x0, "Offset mismatch for FDelMarVehicleCachedContact::Location");
static_assert(offsetof(FDelMarVehicleCachedContact, Normal) == 0x18, "Offset mismatch for FDelMarVehicleCachedContact::Normal");
static_assert(offsetof(FDelMarVehicleCachedContact, Impulse) == 0x30, "Offset mismatch for FDelMarVehicleCachedContact::Impulse");
static_assert(offsetof(FDelMarVehicleCachedContact, DeltaVelocity) == 0x48, "Offset mismatch for FDelMarVehicleCachedContact::DeltaVelocity");
static_assert(offsetof(FDelMarVehicleCachedContact, bVehicleContact) == 0x60, "Offset mismatch for FDelMarVehicleCachedContact::bVehicleContact");
static_assert(offsetof(FDelMarVehicleCachedContact, bDriveableContact) == 0x61, "Offset mismatch for FDelMarVehicleCachedContact::bDriveableContact");
static_assert(offsetof(FDelMarVehicleCachedContact, Component) == 0x64, "Offset mismatch for FDelMarVehicleCachedContact::Component");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarWorldBonusSpeedStack
{
    FGameplayTag Source; // 0x0 (Size: 0x4, Type: StructProperty)
    float BonusSpeed; // 0x4 (Size: 0x4, Type: FloatProperty)
    float duration; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bApplyForce; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    int32_t GroupId; // 0x10 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AActor*> ActorSource; // 0x14 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_1c[0xc]; // 0x1c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarWorldBonusSpeedStack) == 0x28, "Size mismatch for FDelMarWorldBonusSpeedStack");
static_assert(offsetof(FDelMarWorldBonusSpeedStack, Source) == 0x0, "Offset mismatch for FDelMarWorldBonusSpeedStack::Source");
static_assert(offsetof(FDelMarWorldBonusSpeedStack, BonusSpeed) == 0x4, "Offset mismatch for FDelMarWorldBonusSpeedStack::BonusSpeed");
static_assert(offsetof(FDelMarWorldBonusSpeedStack, duration) == 0x8, "Offset mismatch for FDelMarWorldBonusSpeedStack::duration");
static_assert(offsetof(FDelMarWorldBonusSpeedStack, bApplyForce) == 0xc, "Offset mismatch for FDelMarWorldBonusSpeedStack::bApplyForce");
static_assert(offsetof(FDelMarWorldBonusSpeedStack, GroupId) == 0x10, "Offset mismatch for FDelMarWorldBonusSpeedStack::GroupId");
static_assert(offsetof(FDelMarWorldBonusSpeedStack, ActorSource) == 0x14, "Offset mismatch for FDelMarWorldBonusSpeedStack::ActorSource");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarWorldBonusSpeedGroup
{
};

static_assert(sizeof(FDelMarWorldBonusSpeedGroup) == 0x18, "Size mismatch for FDelMarWorldBonusSpeedGroup");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarVehicleLandingData
{
};

static_assert(sizeof(FDelMarVehicleLandingData) == 0xc, "Size mismatch for FDelMarVehicleLandingData");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleSkydivingData
{
};

static_assert(sizeof(FDelMarVehicleSkydivingData) == 0x8, "Size mismatch for FDelMarVehicleSkydivingData");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FDelMarStartlineBoostData
{
    bool bFailed; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ReactionSeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
    float RunStartTime; // 0x8 (Size: 0x4, Type: FloatProperty)
    float IntervalSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    float EarnedPotential; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarStartlineBoostData) == 0x14, "Size mismatch for FDelMarStartlineBoostData");
static_assert(offsetof(FDelMarStartlineBoostData, bFailed) == 0x0, "Offset mismatch for FDelMarStartlineBoostData::bFailed");
static_assert(offsetof(FDelMarStartlineBoostData, ReactionSeconds) == 0x4, "Offset mismatch for FDelMarStartlineBoostData::ReactionSeconds");
static_assert(offsetof(FDelMarStartlineBoostData, RunStartTime) == 0x8, "Offset mismatch for FDelMarStartlineBoostData::RunStartTime");
static_assert(offsetof(FDelMarStartlineBoostData, IntervalSeconds) == 0xc, "Offset mismatch for FDelMarStartlineBoostData::IntervalSeconds");
static_assert(offsetof(FDelMarStartlineBoostData, EarnedPotential) == 0x10, "Offset mismatch for FDelMarStartlineBoostData::EarnedPotential");

// Size: 0x130 (Inherited: 0x0, Single: 0x130)
struct FDelMarKickflipSimulationResult
{
    FHitResult Hit; // 0x0 (Size: 0xf8, Type: StructProperty)
    uint8_t Pad_f8[0x8]; // 0xf8 (Size: 0x8, Type: PaddingProperty)
    FQuat VehicleLandingRotation; // 0x100 (Size: 0x20, Type: StructProperty)
    bool bValidLandingRotation; // 0x120 (Size: 0x1, Type: BoolProperty)
    bool bDriveableSurfaceHit; // 0x121 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_122[0x2]; // 0x122 (Size: 0x2, Type: PaddingProperty)
    float SuctionVelocityUsed; // 0x124 (Size: 0x4, Type: FloatProperty)
    float ElapsedTime; // 0x128 (Size: 0x4, Type: FloatProperty)
    float DistanceTravelled; // 0x12c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarKickflipSimulationResult) == 0x130, "Size mismatch for FDelMarKickflipSimulationResult");
static_assert(offsetof(FDelMarKickflipSimulationResult, Hit) == 0x0, "Offset mismatch for FDelMarKickflipSimulationResult::Hit");
static_assert(offsetof(FDelMarKickflipSimulationResult, VehicleLandingRotation) == 0x100, "Offset mismatch for FDelMarKickflipSimulationResult::VehicleLandingRotation");
static_assert(offsetof(FDelMarKickflipSimulationResult, bValidLandingRotation) == 0x120, "Offset mismatch for FDelMarKickflipSimulationResult::bValidLandingRotation");
static_assert(offsetof(FDelMarKickflipSimulationResult, bDriveableSurfaceHit) == 0x121, "Offset mismatch for FDelMarKickflipSimulationResult::bDriveableSurfaceHit");
static_assert(offsetof(FDelMarKickflipSimulationResult, SuctionVelocityUsed) == 0x124, "Offset mismatch for FDelMarKickflipSimulationResult::SuctionVelocityUsed");
static_assert(offsetof(FDelMarKickflipSimulationResult, ElapsedTime) == 0x128, "Offset mismatch for FDelMarKickflipSimulationResult::ElapsedTime");
static_assert(offsetof(FDelMarKickflipSimulationResult, DistanceTravelled) == 0x12c, "Offset mismatch for FDelMarKickflipSimulationResult::DistanceTravelled");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleReplicatedState_Ability
{
    bool bActive; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float duration; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Ability) == 0x8, "Size mismatch for FDelMarVehicleReplicatedState_Ability");
static_assert(offsetof(FDelMarVehicleReplicatedState_Ability, bActive) == 0x0, "Offset mismatch for FDelMarVehicleReplicatedState_Ability::bActive");
static_assert(offsetof(FDelMarVehicleReplicatedState_Ability, duration) == 0x4, "Offset mismatch for FDelMarVehicleReplicatedState_Ability::duration");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FDelMarVehicleReplicatedState_BonusSpeedAbility : FDelMarVehicleReplicatedState_Ability
{
    float AppliedBonusSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_BonusSpeedAbility) == 0xc, "Size mismatch for FDelMarVehicleReplicatedState_BonusSpeedAbility");
static_assert(offsetof(FDelMarVehicleReplicatedState_BonusSpeedAbility, AppliedBonusSpeed) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_BonusSpeedAbility::AppliedBonusSpeed");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FDelMarVehicleReplicatedState_AutoUpright : FDelMarVehicleReplicatedState_Ability
{
    FVector_NetQuantizeNormal TargetVehicleUp; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_AutoUpright) == 0x20, "Size mismatch for FDelMarVehicleReplicatedState_AutoUpright");
static_assert(offsetof(FDelMarVehicleReplicatedState_AutoUpright, TargetVehicleUp) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_AutoUpright::TargetVehicleUp");

// Size: 0x18 (Inherited: 0x14, Single: 0x4)
struct FDelMarVehicleReplicatedState_Drafting : FDelMarVehicleReplicatedState_BonusSpeedAbility
{
    float AccumulatedLosingSpeedSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    float AccumulatedStartDraftingSeconds; // 0x10 (Size: 0x4, Type: FloatProperty)
    float TotalEarnedBonusSpeed; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Drafting) == 0x18, "Size mismatch for FDelMarVehicleReplicatedState_Drafting");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drafting, AccumulatedLosingSpeedSeconds) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_Drafting::AccumulatedLosingSpeedSeconds");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drafting, AccumulatedStartDraftingSeconds) == 0x10, "Offset mismatch for FDelMarVehicleReplicatedState_Drafting::AccumulatedStartDraftingSeconds");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drafting, TotalEarnedBonusSpeed) == 0x14, "Offset mismatch for FDelMarVehicleReplicatedState_Drafting::TotalEarnedBonusSpeed");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FDelMarVehicleReplicatedState_Drift : FDelMarVehicleReplicatedState_Ability
{
    float CurrentRotationAngle; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t DriftState; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    float TargetDriftSide; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FVector_NetQuantize100 InitialImpulseTorque; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Drift) == 0x30, "Size mismatch for FDelMarVehicleReplicatedState_Drift");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drift, CurrentRotationAngle) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_Drift::CurrentRotationAngle");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drift, DriftState) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_Drift::DriftState");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drift, TargetDriftSide) == 0x10, "Offset mismatch for FDelMarVehicleReplicatedState_Drift::TargetDriftSide");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drift, InitialImpulseTorque) == 0x18, "Offset mismatch for FDelMarVehicleReplicatedState_Drift::InitialImpulseTorque");

// Size: 0x20 (Inherited: 0x14, Single: 0xc)
struct FDelMarVehicleReplicatedState_DriftBoost : FDelMarVehicleReplicatedState_BonusSpeedAbility
{
    float AccumulatedDriftBoostSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    float AccumulatedWaitingPeriodSeconds; // 0x10 (Size: 0x4, Type: FloatProperty)
    float TotalEarnedBonusSpeed; // 0x14 (Size: 0x4, Type: FloatProperty)
    float QueuedBonusSpeed; // 0x18 (Size: 0x4, Type: FloatProperty)
    float QueuedBoostExtraSeconds; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_DriftBoost) == 0x20, "Size mismatch for FDelMarVehicleReplicatedState_DriftBoost");
static_assert(offsetof(FDelMarVehicleReplicatedState_DriftBoost, AccumulatedDriftBoostSeconds) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_DriftBoost::AccumulatedDriftBoostSeconds");
static_assert(offsetof(FDelMarVehicleReplicatedState_DriftBoost, AccumulatedWaitingPeriodSeconds) == 0x10, "Offset mismatch for FDelMarVehicleReplicatedState_DriftBoost::AccumulatedWaitingPeriodSeconds");
static_assert(offsetof(FDelMarVehicleReplicatedState_DriftBoost, TotalEarnedBonusSpeed) == 0x14, "Offset mismatch for FDelMarVehicleReplicatedState_DriftBoost::TotalEarnedBonusSpeed");
static_assert(offsetof(FDelMarVehicleReplicatedState_DriftBoost, QueuedBonusSpeed) == 0x18, "Offset mismatch for FDelMarVehicleReplicatedState_DriftBoost::QueuedBonusSpeed");
static_assert(offsetof(FDelMarVehicleReplicatedState_DriftBoost, QueuedBoostExtraSeconds) == 0x1c, "Offset mismatch for FDelMarVehicleReplicatedState_DriftBoost::QueuedBoostExtraSeconds");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarVehicleReplicatedState_Drive
{
    float BaseTargetSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bInvertedSteeringActive; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t bDisableDriveForces; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t bDisableWheelFriction; // 0xc (Size: 0x4, Type: IntProperty)
    FVector_NetQuantizeNormal LastAverageWheelWorldContactNormal; // 0x10 (Size: 0x18, Type: StructProperty)
    float MinimumLandingSpeed; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Drive) == 0x30, "Size mismatch for FDelMarVehicleReplicatedState_Drive");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drive, BaseTargetSpeed) == 0x0, "Offset mismatch for FDelMarVehicleReplicatedState_Drive::BaseTargetSpeed");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drive, bInvertedSteeringActive) == 0x4, "Offset mismatch for FDelMarVehicleReplicatedState_Drive::bInvertedSteeringActive");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drive, bDisableDriveForces) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_Drive::bDisableDriveForces");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drive, bDisableWheelFriction) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_Drive::bDisableWheelFriction");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drive, LastAverageWheelWorldContactNormal) == 0x10, "Offset mismatch for FDelMarVehicleReplicatedState_Drive::LastAverageWheelWorldContactNormal");
static_assert(offsetof(FDelMarVehicleReplicatedState_Drive, MinimumLandingSpeed) == 0x28, "Offset mismatch for FDelMarVehicleReplicatedState_Drive::MinimumLandingSpeed");

// Size: 0x60 (Inherited: 0x8, Single: 0x58)
struct FDelMarVehicleReplicatedState_Kickflip : FDelMarVehicleReplicatedState_Ability
{
    FVector_NetQuantizeNormal RelativeUpDirection; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantizeNormal KickDirection; // 0x20 (Size: 0x18, Type: StructProperty)
    bool bLeftSide; // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bTakeLongestRoll; // 0x39 (Size: 0x1, Type: BoolProperty)
    bool bRotateTowardsVelocity; // 0x3a (Size: 0x1, Type: BoolProperty)
    bool bCanStartLongRoll; // 0x3b (Size: 0x1, Type: BoolProperty)
    int32_t StartingRollSign; // 0x3c (Size: 0x4, Type: IntProperty)
    float KickflipKeybindPressTime; // 0x40 (Size: 0x4, Type: FloatProperty)
    int32_t ActivationCharges; // 0x44 (Size: 0x4, Type: IntProperty)
    FVector_NetQuantizeNormal StartingPrimaryDirection; // 0x48 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Kickflip) == 0x60, "Size mismatch for FDelMarVehicleReplicatedState_Kickflip");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, RelativeUpDirection) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::RelativeUpDirection");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, KickDirection) == 0x20, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::KickDirection");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, bLeftSide) == 0x38, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::bLeftSide");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, bTakeLongestRoll) == 0x39, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::bTakeLongestRoll");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, bRotateTowardsVelocity) == 0x3a, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::bRotateTowardsVelocity");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, bCanStartLongRoll) == 0x3b, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::bCanStartLongRoll");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, StartingRollSign) == 0x3c, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::StartingRollSign");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, KickflipKeybindPressTime) == 0x40, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::KickflipKeybindPressTime");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, ActivationCharges) == 0x44, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::ActivationCharges");
static_assert(offsetof(FDelMarVehicleReplicatedState_Kickflip, StartingPrimaryDirection) == 0x48, "Offset mismatch for FDelMarVehicleReplicatedState_Kickflip::StartingPrimaryDirection");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDelMarVehicleReplicatedState_Oversteer
{
    float AccumulatedSteer; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Oversteer) == 0x4, "Size mismatch for FDelMarVehicleReplicatedState_Oversteer");
static_assert(offsetof(FDelMarVehicleReplicatedState_Oversteer, AccumulatedSteer) == 0x0, "Offset mismatch for FDelMarVehicleReplicatedState_Oversteer::AccumulatedSteer");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FDelMarVehicleReplicatedState_Reattachment : FDelMarVehicleReplicatedState_Ability
{
    FVector_NetQuantizeNormal AttachmentDirection; // 0x8 (Size: 0x18, Type: StructProperty)
    bool bCanActivate; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Reattachment) == 0x28, "Size mismatch for FDelMarVehicleReplicatedState_Reattachment");
static_assert(offsetof(FDelMarVehicleReplicatedState_Reattachment, AttachmentDirection) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_Reattachment::AttachmentDirection");
static_assert(offsetof(FDelMarVehicleReplicatedState_Reattachment, bCanActivate) == 0x20, "Offset mismatch for FDelMarVehicleReplicatedState_Reattachment::bCanActivate");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDelMarVehicleReplicatedState_Rubberbanding
{
    float AppliedBonusSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Rubberbanding) == 0x4, "Size mismatch for FDelMarVehicleReplicatedState_Rubberbanding");
static_assert(offsetof(FDelMarVehicleReplicatedState_Rubberbanding, AppliedBonusSpeed) == 0x0, "Offset mismatch for FDelMarVehicleReplicatedState_Rubberbanding::AppliedBonusSpeed");

// Size: 0x14 (Inherited: 0x14, Single: 0x0)
struct FDelMarVehicleReplicatedState_StartlineBoost : FDelMarVehicleReplicatedState_BonusSpeedAbility
{
    float PercentageMaxBonusSpeedEarned; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bFailedAttempt; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_StartlineBoost) == 0x14, "Size mismatch for FDelMarVehicleReplicatedState_StartlineBoost");
static_assert(offsetof(FDelMarVehicleReplicatedState_StartlineBoost, PercentageMaxBonusSpeedEarned) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_StartlineBoost::PercentageMaxBonusSpeedEarned");
static_assert(offsetof(FDelMarVehicleReplicatedState_StartlineBoost, bFailedAttempt) == 0x10, "Offset mismatch for FDelMarVehicleReplicatedState_StartlineBoost::bFailedAttempt");

// Size: 0x18 (Inherited: 0x14, Single: 0x4)
struct FDelMarVehicleReplicatedState_Turbo : FDelMarVehicleReplicatedState_BonusSpeedAbility
{
    int32_t LastBonusZoneInteractionIndex; // 0xc (Size: 0x4, Type: IntProperty)
    bool bSuccessfulBonusZone; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float AdditionalActiveSeconds; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Turbo) == 0x18, "Size mismatch for FDelMarVehicleReplicatedState_Turbo");
static_assert(offsetof(FDelMarVehicleReplicatedState_Turbo, LastBonusZoneInteractionIndex) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_Turbo::LastBonusZoneInteractionIndex");
static_assert(offsetof(FDelMarVehicleReplicatedState_Turbo, bSuccessfulBonusZone) == 0x10, "Offset mismatch for FDelMarVehicleReplicatedState_Turbo::bSuccessfulBonusZone");
static_assert(offsetof(FDelMarVehicleReplicatedState_Turbo, AdditionalActiveSeconds) == 0x14, "Offset mismatch for FDelMarVehicleReplicatedState_Turbo::AdditionalActiveSeconds");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FDelMarVehicleReplicatedState_Underthrust : FDelMarVehicleReplicatedState_Ability
{
    float RemainingThrustSeconds; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Underthrust) == 0xc, "Size mismatch for FDelMarVehicleReplicatedState_Underthrust");
static_assert(offsetof(FDelMarVehicleReplicatedState_Underthrust, RemainingThrustSeconds) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_Underthrust::RemainingThrustSeconds");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FDelMarVehicleReplicatedState_Strafe : FDelMarVehicleReplicatedState_Ability
{
    bool bLeftSide; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float StrafeKeybindPressTime; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_Strafe) == 0x10, "Size mismatch for FDelMarVehicleReplicatedState_Strafe");
static_assert(offsetof(FDelMarVehicleReplicatedState_Strafe, bLeftSide) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_Strafe::bLeftSide");
static_assert(offsetof(FDelMarVehicleReplicatedState_Strafe, StrafeKeybindPressTime) == 0xc, "Offset mismatch for FDelMarVehicleReplicatedState_Strafe::StrafeKeybindPressTime");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FDelMarVehicleReplicatedState_AirControl : FDelMarVehicleReplicatedState_Ability
{
    float AerialDivingBonusSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState_AirControl) == 0xc, "Size mismatch for FDelMarVehicleReplicatedState_AirControl");
static_assert(offsetof(FDelMarVehicleReplicatedState_AirControl, AerialDivingBonusSpeed) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState_AirControl::AerialDivingBonusSpeed");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarInputBufferData
{
};

static_assert(sizeof(FDelMarInputBufferData) == 0x18, "Size mismatch for FDelMarInputBufferData");

// Size: 0x40 (Inherited: 0x40, Single: 0x0)
struct FDelMarVehicleInContinuous : FFortAthenaVehicleInputState
{
};

static_assert(sizeof(FDelMarVehicleInContinuous) == 0x40, "Size mismatch for FDelMarVehicleInContinuous");

// Size: 0x290 (Inherited: 0x0, Single: 0x290)
struct FDelMarVehicleReplicatedState
{
    int32_t FrameNum; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDelMarVehicleInContinuous Input; // 0x8 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    FRigidBodyState RBState; // 0x50 (Size: 0x80, Type: StructProperty)
    FDelMarVehicleReplicatedState_AutoUpright AutoUpright; // 0xd0 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleReplicatedState_Drafting Drafting; // 0xf0 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleReplicatedState_Drift Drift; // 0x108 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleReplicatedState_DriftBoost DriftBoost; // 0x138 (Size: 0x20, Type: StructProperty)
    FDelMarVehicleReplicatedState_Drive Drive; // 0x158 (Size: 0x30, Type: StructProperty)
    FDelMarVehicleReplicatedState_Ability Jump; // 0x188 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleReplicatedState_Kickflip Kickflip; // 0x190 (Size: 0x60, Type: StructProperty)
    FDelMarVehicleReplicatedState_Oversteer Oversteer; // 0x1f0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1f4[0x4]; // 0x1f4 (Size: 0x4, Type: PaddingProperty)
    FDelMarVehicleReplicatedState_Reattachment Reattachment; // 0x1f8 (Size: 0x28, Type: StructProperty)
    FDelMarVehicleReplicatedState_Rubberbanding Rubberbanding; // 0x220 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleReplicatedState_StartlineBoost StartlineBoost; // 0x224 (Size: 0x14, Type: StructProperty)
    FDelMarVehicleReplicatedState_Strafe Strafe; // 0x238 (Size: 0x10, Type: StructProperty)
    FDelMarVehicleReplicatedState_Turbo Turbo; // 0x248 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleReplicatedState_Underthrust Underthrust; // 0x260 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleReplicatedState_AirControl AirControl; // 0x26c (Size: 0xc, Type: StructProperty)
    FDelMarInputBufferData BufferData; // 0x278 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleReplicatedState) == 0x290, "Size mismatch for FDelMarVehicleReplicatedState");
static_assert(offsetof(FDelMarVehicleReplicatedState, FrameNum) == 0x0, "Offset mismatch for FDelMarVehicleReplicatedState::FrameNum");
static_assert(offsetof(FDelMarVehicleReplicatedState, Input) == 0x8, "Offset mismatch for FDelMarVehicleReplicatedState::Input");
static_assert(offsetof(FDelMarVehicleReplicatedState, RBState) == 0x50, "Offset mismatch for FDelMarVehicleReplicatedState::RBState");
static_assert(offsetof(FDelMarVehicleReplicatedState, AutoUpright) == 0xd0, "Offset mismatch for FDelMarVehicleReplicatedState::AutoUpright");
static_assert(offsetof(FDelMarVehicleReplicatedState, Drafting) == 0xf0, "Offset mismatch for FDelMarVehicleReplicatedState::Drafting");
static_assert(offsetof(FDelMarVehicleReplicatedState, Drift) == 0x108, "Offset mismatch for FDelMarVehicleReplicatedState::Drift");
static_assert(offsetof(FDelMarVehicleReplicatedState, DriftBoost) == 0x138, "Offset mismatch for FDelMarVehicleReplicatedState::DriftBoost");
static_assert(offsetof(FDelMarVehicleReplicatedState, Drive) == 0x158, "Offset mismatch for FDelMarVehicleReplicatedState::Drive");
static_assert(offsetof(FDelMarVehicleReplicatedState, Jump) == 0x188, "Offset mismatch for FDelMarVehicleReplicatedState::Jump");
static_assert(offsetof(FDelMarVehicleReplicatedState, Kickflip) == 0x190, "Offset mismatch for FDelMarVehicleReplicatedState::Kickflip");
static_assert(offsetof(FDelMarVehicleReplicatedState, Oversteer) == 0x1f0, "Offset mismatch for FDelMarVehicleReplicatedState::Oversteer");
static_assert(offsetof(FDelMarVehicleReplicatedState, Reattachment) == 0x1f8, "Offset mismatch for FDelMarVehicleReplicatedState::Reattachment");
static_assert(offsetof(FDelMarVehicleReplicatedState, Rubberbanding) == 0x220, "Offset mismatch for FDelMarVehicleReplicatedState::Rubberbanding");
static_assert(offsetof(FDelMarVehicleReplicatedState, StartlineBoost) == 0x224, "Offset mismatch for FDelMarVehicleReplicatedState::StartlineBoost");
static_assert(offsetof(FDelMarVehicleReplicatedState, Strafe) == 0x238, "Offset mismatch for FDelMarVehicleReplicatedState::Strafe");
static_assert(offsetof(FDelMarVehicleReplicatedState, Turbo) == 0x248, "Offset mismatch for FDelMarVehicleReplicatedState::Turbo");
static_assert(offsetof(FDelMarVehicleReplicatedState, Underthrust) == 0x260, "Offset mismatch for FDelMarVehicleReplicatedState::Underthrust");
static_assert(offsetof(FDelMarVehicleReplicatedState, AirControl) == 0x26c, "Offset mismatch for FDelMarVehicleReplicatedState::AirControl");
static_assert(offsetof(FDelMarVehicleReplicatedState, BufferData) == 0x278, "Offset mismatch for FDelMarVehicleReplicatedState::BufferData");

// Size: 0xa40 (Inherited: 0x1a0, Single: 0x8a0)
struct FDelMarVehicleInPersistent : FFortVehicleInPersistent
{
};

static_assert(sizeof(FDelMarVehicleInPersistent) == 0xa40, "Size mismatch for FDelMarVehicleInPersistent");

// Size: 0xb40 (Inherited: 0xe0, Single: 0xa60)
struct FDelMarVehicleInternalPersistent : FFortVehicleInternalPersistent
{
};

static_assert(sizeof(FDelMarVehicleInternalPersistent) == 0xb40, "Size mismatch for FDelMarVehicleInternalPersistent");

// Size: 0x1b0 (Inherited: 0x50, Single: 0x160)
struct FDelMarVehicleOutContinuous : FFortVehicleOutContinuous
{
};

static_assert(sizeof(FDelMarVehicleOutContinuous) == 0x1b0, "Size mismatch for FDelMarVehicleOutContinuous");

// Size: 0xa50 (Inherited: 0x28, Single: 0xa28)
struct FDelMarVehicleOutPersistent : FFortVehicleOutPersistent
{
};

static_assert(sizeof(FDelMarVehicleOutPersistent) == 0xa50, "Size mismatch for FDelMarVehicleOutPersistent");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FDelMarVehicleNetworkInput
{
    int32_t FrameNum; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDelMarVehicleInContinuous Input; // 0x8 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleNetworkInput) == 0x48, "Size mismatch for FDelMarVehicleNetworkInput");
static_assert(offsetof(FDelMarVehicleNetworkInput, FrameNum) == 0x0, "Offset mismatch for FDelMarVehicleNetworkInput::FrameNum");
static_assert(offsetof(FDelMarVehicleNetworkInput, Input) == 0x8, "Offset mismatch for FDelMarVehicleNetworkInput::Input");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarVehicleSpawnInfo
{
    bool bFirstVehicleForPlayer; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bPreviousVehicleDemolished; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    double ServerSpawnTime; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarVehicleSpawnInfo) == 0x10, "Size mismatch for FDelMarVehicleSpawnInfo");
static_assert(offsetof(FDelMarVehicleSpawnInfo, bFirstVehicleForPlayer) == 0x0, "Offset mismatch for FDelMarVehicleSpawnInfo::bFirstVehicleForPlayer");
static_assert(offsetof(FDelMarVehicleSpawnInfo, bPreviousVehicleDemolished) == 0x1, "Offset mismatch for FDelMarVehicleSpawnInfo::bPreviousVehicleDemolished");
static_assert(offsetof(FDelMarVehicleSpawnInfo, ServerSpawnTime) == 0x8, "Offset mismatch for FDelMarVehicleSpawnInfo::ServerSpawnTime");

// Size: 0x138 (Inherited: 0x78, Single: 0xc0)
struct FDelMarVerbMessageBase : FVerbMessage
{
    FSubjectTagsPair LevelDescriptionId; // 0x78 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair GameModeId; // 0xb0 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair VehicleTags; // 0xe8 (Size: 0x38, Type: StructProperty)
    uint8_t RankedPlaylistInfo; // 0x120 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_121[0x7]; // 0x121 (Size: 0x7, Type: PaddingProperty)
    TArray<FFortVerb_ObjectWrapper> Cosmetics; // 0x128 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarVerbMessageBase) == 0x138, "Size mismatch for FDelMarVerbMessageBase");
static_assert(offsetof(FDelMarVerbMessageBase, LevelDescriptionId) == 0x78, "Offset mismatch for FDelMarVerbMessageBase::LevelDescriptionId");
static_assert(offsetof(FDelMarVerbMessageBase, GameModeId) == 0xb0, "Offset mismatch for FDelMarVerbMessageBase::GameModeId");
static_assert(offsetof(FDelMarVerbMessageBase, VehicleTags) == 0xe8, "Offset mismatch for FDelMarVerbMessageBase::VehicleTags");
static_assert(offsetof(FDelMarVerbMessageBase, RankedPlaylistInfo) == 0x120, "Offset mismatch for FDelMarVerbMessageBase::RankedPlaylistInfo");
static_assert(offsetof(FDelMarVerbMessageBase, Cosmetics) == 0x128, "Offset mismatch for FDelMarVerbMessageBase::Cosmetics");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_BeatPlayers : FDelMarVerbMessageBase
{
    char AmountOfPlayersBeat; // 0x138 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_139[0x7]; // 0x139 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_BeatPlayers) == 0x140, "Size mismatch for FDelMarVerbMessage_BeatPlayers");
static_assert(offsetof(FDelMarVerbMessage_BeatPlayers, AmountOfPlayersBeat) == 0x138, "Offset mismatch for FDelMarVerbMessage_BeatPlayers::AmountOfPlayersBeat");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_BonusTurboActivated : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_BonusTurboActivated) == 0x138, "Size mismatch for FDelMarVerbMessage_BonusTurboActivated");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_BoostPadBonusSpeedEnded : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_BoostPadBonusSpeedEnded) == 0x138, "Size mismatch for FDelMarVerbMessage_BoostPadBonusSpeedEnded");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_BoostPadHit : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_BoostPadHit) == 0x138, "Size mismatch for FDelMarVerbMessage_BoostPadHit");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_Demolished : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_Demolished) == 0x138, "Size mismatch for FDelMarVerbMessage_Demolished");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_DistanceTraveled : FDelMarVerbMessageBase
{
    float TotalDistance; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_DistanceTraveled) == 0x140, "Size mismatch for FDelMarVerbMessage_DistanceTraveled");
static_assert(offsetof(FDelMarVerbMessage_DistanceTraveled, TotalDistance) == 0x138, "Offset mismatch for FDelMarVerbMessage_DistanceTraveled::TotalDistance");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_DraftActivated : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_DraftActivated) == 0x138, "Size mismatch for FDelMarVerbMessage_DraftActivated");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_DriftBoostActivated : FDelMarVerbMessageBase
{
    float DriftBoostPercent; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_DriftBoostActivated) == 0x140, "Size mismatch for FDelMarVerbMessage_DriftBoostActivated");
static_assert(offsetof(FDelMarVerbMessage_DriftBoostActivated, DriftBoostPercent) == 0x138, "Offset mismatch for FDelMarVerbMessage_DriftBoostActivated::DriftBoostPercent");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_DriftBoostDeactivated : FDelMarVerbMessageBase
{
    float TotalDistance; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_DriftBoostDeactivated) == 0x140, "Size mismatch for FDelMarVerbMessage_DriftBoostDeactivated");
static_assert(offsetof(FDelMarVerbMessage_DriftBoostDeactivated, TotalDistance) == 0x138, "Offset mismatch for FDelMarVerbMessage_DriftBoostDeactivated::TotalDistance");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_DriftComplete : FDelMarVerbMessageBase
{
    float DriftDuration; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_DriftComplete) == 0x140, "Size mismatch for FDelMarVerbMessage_DriftComplete");
static_assert(offsetof(FDelMarVerbMessage_DriftComplete, DriftDuration) == 0x138, "Offset mismatch for FDelMarVerbMessage_DriftComplete::DriftDuration");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_HighestSpeedUpdated : FDelMarVerbMessageBase
{
    float HighestSpeed; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_HighestSpeedUpdated) == 0x140, "Size mismatch for FDelMarVerbMessage_HighestSpeedUpdated");
static_assert(offsetof(FDelMarVerbMessage_HighestSpeedUpdated, HighestSpeed) == 0x138, "Offset mismatch for FDelMarVerbMessage_HighestSpeedUpdated::HighestSpeed");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_InitialTurboActivated : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_InitialTurboActivated) == 0x138, "Size mismatch for FDelMarVerbMessage_InitialTurboActivated");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_JellyHit : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_JellyHit) == 0x138, "Size mismatch for FDelMarVerbMessage_JellyHit");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_Kickflipped : FDelMarVerbMessageBase
{
    uint8_t Direction; // 0x138 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_139[0x7]; // 0x139 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_Kickflipped) == 0x140, "Size mismatch for FDelMarVerbMessage_Kickflipped");
static_assert(offsetof(FDelMarVerbMessage_Kickflipped, Direction) == 0x138, "Offset mismatch for FDelMarVerbMessage_Kickflipped::Direction");

// Size: 0x148 (Inherited: 0x1b0, Single: 0xffffff98)
struct FDelMarVerbMessage_LapComplete : FDelMarVerbMessageBase
{
    double LapCompleteTime; // 0x138 (Size: 0x8, Type: DoubleProperty)
    char LapCount; // 0x140 (Size: 0x1, Type: ByteProperty)
    char LapPlacement; // 0x141 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_142[0x6]; // 0x142 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_LapComplete) == 0x148, "Size mismatch for FDelMarVerbMessage_LapComplete");
static_assert(offsetof(FDelMarVerbMessage_LapComplete, LapCompleteTime) == 0x138, "Offset mismatch for FDelMarVerbMessage_LapComplete::LapCompleteTime");
static_assert(offsetof(FDelMarVerbMessage_LapComplete, LapCount) == 0x140, "Offset mismatch for FDelMarVerbMessage_LapComplete::LapCount");
static_assert(offsetof(FDelMarVerbMessage_LapComplete, LapPlacement) == 0x141, "Offset mismatch for FDelMarVerbMessage_LapComplete::LapPlacement");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_LapStarted : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_LapStarted) == 0x138, "Size mismatch for FDelMarVerbMessage_LapStarted");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_PlacementUpdated : FDelMarVerbMessageBase
{
    char CurrentPosition; // 0x138 (Size: 0x1, Type: ByteProperty)
    uint8_t PositionChangeInfo; // 0x139 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_13a[0x6]; // 0x13a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_PlacementUpdated) == 0x140, "Size mismatch for FDelMarVerbMessage_PlacementUpdated");
static_assert(offsetof(FDelMarVerbMessage_PlacementUpdated, CurrentPosition) == 0x138, "Offset mismatch for FDelMarVerbMessage_PlacementUpdated::CurrentPosition");
static_assert(offsetof(FDelMarVerbMessage_PlacementUpdated, PositionChangeInfo) == 0x139, "Offset mismatch for FDelMarVerbMessage_PlacementUpdated::PositionChangeInfo");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_PlayedDelMarExperience : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_PlayedDelMarExperience) == 0x138, "Size mismatch for FDelMarVerbMessage_PlayedDelMarExperience");

// Size: 0x150 (Inherited: 0x1b0, Single: 0xffffffa0)
struct FDelMarVerbMessage_RaceFinished : FDelMarVerbMessageBase
{
    double FinishTime; // 0x138 (Size: 0x8, Type: DoubleProperty)
    char FinalPlacement; // 0x140 (Size: 0x1, Type: ByteProperty)
    char PlayerRank; // 0x141 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_142[0x2]; // 0x142 (Size: 0x2, Type: PaddingProperty)
    uint8_t JellyHazardInfo[0x4]; // 0x144 (Size: 0x4, Type: EnumProperty)
    uint8_t DemolishedInfo[0x4]; // 0x148 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_RaceFinished) == 0x150, "Size mismatch for FDelMarVerbMessage_RaceFinished");
static_assert(offsetof(FDelMarVerbMessage_RaceFinished, FinishTime) == 0x138, "Offset mismatch for FDelMarVerbMessage_RaceFinished::FinishTime");
static_assert(offsetof(FDelMarVerbMessage_RaceFinished, FinalPlacement) == 0x140, "Offset mismatch for FDelMarVerbMessage_RaceFinished::FinalPlacement");
static_assert(offsetof(FDelMarVerbMessage_RaceFinished, PlayerRank) == 0x141, "Offset mismatch for FDelMarVerbMessage_RaceFinished::PlayerRank");
static_assert(offsetof(FDelMarVerbMessage_RaceFinished, JellyHazardInfo) == 0x144, "Offset mismatch for FDelMarVerbMessage_RaceFinished::JellyHazardInfo");
static_assert(offsetof(FDelMarVerbMessage_RaceFinished, DemolishedInfo) == 0x148, "Offset mismatch for FDelMarVerbMessage_RaceFinished::DemolishedInfo");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_RankAchieved : FDelMarVerbMessageBase
{
    int32_t RankAchieved; // 0x138 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_RankAchieved) == 0x140, "Size mismatch for FDelMarVerbMessage_RankAchieved");
static_assert(offsetof(FDelMarVerbMessage_RankAchieved, RankAchieved) == 0x138, "Offset mismatch for FDelMarVerbMessage_RankAchieved::RankAchieved");

// Size: 0x150 (Inherited: 0x1b0, Single: 0xffffffa0)
struct FDelMarVerbMessage_RunComplete : FDelMarVerbMessageBase
{
    double FinishTime; // 0x138 (Size: 0x8, Type: DoubleProperty)
    char FinalPlacement; // 0x140 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_141[0x3]; // 0x141 (Size: 0x3, Type: PaddingProperty)
    uint8_t JellyHazardInfo[0x4]; // 0x144 (Size: 0x4, Type: EnumProperty)
    uint8_t DemolishedInfo[0x4]; // 0x148 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_RunComplete) == 0x150, "Size mismatch for FDelMarVerbMessage_RunComplete");
static_assert(offsetof(FDelMarVerbMessage_RunComplete, FinishTime) == 0x138, "Offset mismatch for FDelMarVerbMessage_RunComplete::FinishTime");
static_assert(offsetof(FDelMarVerbMessage_RunComplete, FinalPlacement) == 0x140, "Offset mismatch for FDelMarVerbMessage_RunComplete::FinalPlacement");
static_assert(offsetof(FDelMarVerbMessage_RunComplete, JellyHazardInfo) == 0x144, "Offset mismatch for FDelMarVerbMessage_RunComplete::JellyHazardInfo");
static_assert(offsetof(FDelMarVerbMessage_RunComplete, DemolishedInfo) == 0x148, "Offset mismatch for FDelMarVerbMessage_RunComplete::DemolishedInfo");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_StartlineBoostActivated : FDelMarVerbMessageBase
{
    float StartLineBoostPercent; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_StartlineBoostActivated) == 0x140, "Size mismatch for FDelMarVerbMessage_StartlineBoostActivated");
static_assert(offsetof(FDelMarVerbMessage_StartlineBoostActivated, StartLineBoostPercent) == 0x138, "Offset mismatch for FDelMarVerbMessage_StartlineBoostActivated::StartLineBoostPercent");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_StartlineBoostPercentEarned : FDelMarVerbMessageBase
{
    float PercentEarned; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_StartlineBoostPercentEarned) == 0x140, "Size mismatch for FDelMarVerbMessage_StartlineBoostPercentEarned");
static_assert(offsetof(FDelMarVerbMessage_StartlineBoostPercentEarned, PercentEarned) == 0x138, "Offset mismatch for FDelMarVerbMessage_StartlineBoostPercentEarned::PercentEarned");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_UnderthrustDeactivated : FDelMarVerbMessageBase
{
    float PercentUsed; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_UnderthrustDeactivated) == 0x140, "Size mismatch for FDelMarVerbMessage_UnderthrustDeactivated");
static_assert(offsetof(FDelMarVerbMessage_UnderthrustDeactivated, PercentUsed) == 0x138, "Offset mismatch for FDelMarVerbMessage_UnderthrustDeactivated::PercentUsed");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_UnderthrustPercentUsed : FDelMarVerbMessageBase
{
    float PercentUsed; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_UnderthrustPercentUsed) == 0x140, "Size mismatch for FDelMarVerbMessage_UnderthrustPercentUsed");
static_assert(offsetof(FDelMarVerbMessage_UnderthrustPercentUsed, PercentUsed) == 0x138, "Offset mismatch for FDelMarVerbMessage_UnderthrustPercentUsed::PercentUsed");

// Size: 0x138 (Inherited: 0x1b0, Single: 0xffffff88)
struct FDelMarVerbMessage_VehicleJumped : FDelMarVerbMessageBase
{
};

static_assert(sizeof(FDelMarVerbMessage_VehicleJumped) == 0x138, "Size mismatch for FDelMarVerbMessage_VehicleJumped");

// Size: 0x140 (Inherited: 0x1b0, Single: 0xffffff90)
struct FDelMarVerbMessage_VehicleLanded : FDelMarVerbMessageBase
{
    float TimeInAir; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVerbMessage_VehicleLanded) == 0x140, "Size mismatch for FDelMarVerbMessage_VehicleLanded");
static_assert(offsetof(FDelMarVerbMessage_VehicleLanded, TimeInAir) == 0x138, "Offset mismatch for FDelMarVerbMessage_VehicleLanded::TimeInAir");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FAudioMixModifier
{
    FName ParamName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Target; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float DefaultValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FRuntimeFloatCurve Curve; // 0x10 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(FAudioMixModifier) == 0x98, "Size mismatch for FAudioMixModifier");
static_assert(offsetof(FAudioMixModifier, ParamName) == 0x0, "Offset mismatch for FAudioMixModifier::ParamName");
static_assert(offsetof(FAudioMixModifier, Target) == 0x4, "Offset mismatch for FAudioMixModifier::Target");
static_assert(offsetof(FAudioMixModifier, DefaultValue) == 0x8, "Offset mismatch for FAudioMixModifier::DefaultValue");
static_assert(offsetof(FAudioMixModifier, Curve) == 0x10, "Offset mismatch for FAudioMixModifier::Curve");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAudioMixModifierGroup
{
    FName GroupName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FAudioMixModifier> Modifiers; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAudioMixModifierGroup) == 0x18, "Size mismatch for FAudioMixModifierGroup");
static_assert(offsetof(FAudioMixModifierGroup, GroupName) == 0x0, "Offset mismatch for FAudioMixModifierGroup::GroupName");
static_assert(offsetof(FAudioMixModifierGroup, Modifiers) == 0x8, "Offset mismatch for FAudioMixModifierGroup::Modifiers");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarRankedInfo
{
    FString RankType; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t CurrentRank; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarRankedInfo) == 0x18, "Size mismatch for FDelMarRankedInfo");
static_assert(offsetof(FDelMarRankedInfo, RankType) == 0x0, "Offset mismatch for FDelMarRankedInfo::RankType");
static_assert(offsetof(FDelMarRankedInfo, CurrentRank) == 0x10, "Offset mismatch for FDelMarRankedInfo::CurrentRank");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCheckpointTrackDistance
{
    ADelMarTrack* Track; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float LocalDistance; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x14]; // 0xc (Size: 0x14, Type: PaddingProperty)
};

static_assert(sizeof(FCheckpointTrackDistance) == 0x20, "Size mismatch for FCheckpointTrackDistance");
static_assert(offsetof(FCheckpointTrackDistance, Track) == 0x0, "Offset mismatch for FCheckpointTrackDistance::Track");
static_assert(offsetof(FCheckpointTrackDistance, LocalDistance) == 0x8, "Offset mismatch for FCheckpointTrackDistance::LocalDistance");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarTerrainData
{
    float MaxForwardSpeedPercentage; // 0x0 (Size: 0x4, Type: FloatProperty)
    float AccelerationMultiplier; // 0x4 (Size: 0x4, Type: FloatProperty)
    float DecelerationMultiplier; // 0x8 (Size: 0x4, Type: FloatProperty)
    float SteerMultiplier; // 0xc (Size: 0x4, Type: FloatProperty)
    float SlipMultiplier; // 0x10 (Size: 0x4, Type: FloatProperty)
    float TargetSpeedPenalty; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarTerrainData) == 0x18, "Size mismatch for FDelMarTerrainData");
static_assert(offsetof(FDelMarTerrainData, MaxForwardSpeedPercentage) == 0x0, "Offset mismatch for FDelMarTerrainData::MaxForwardSpeedPercentage");
static_assert(offsetof(FDelMarTerrainData, AccelerationMultiplier) == 0x4, "Offset mismatch for FDelMarTerrainData::AccelerationMultiplier");
static_assert(offsetof(FDelMarTerrainData, DecelerationMultiplier) == 0x8, "Offset mismatch for FDelMarTerrainData::DecelerationMultiplier");
static_assert(offsetof(FDelMarTerrainData, SteerMultiplier) == 0xc, "Offset mismatch for FDelMarTerrainData::SteerMultiplier");
static_assert(offsetof(FDelMarTerrainData, SlipMultiplier) == 0x10, "Offset mismatch for FDelMarTerrainData::SlipMultiplier");
static_assert(offsetof(FDelMarTerrainData, TargetSpeedPenalty) == 0x14, "Offset mismatch for FDelMarTerrainData::TargetSpeedPenalty");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDelMarVehicleCameraSettings
{
    float FOV; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Height; // 0x4 (Size: 0x4, Type: FloatProperty)
    float pitch; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Distance; // 0xc (Size: 0x4, Type: FloatProperty)
    float Stiffness; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SwivelSpeed; // 0x14 (Size: 0x4, Type: FloatProperty)
    float TransitionSpeed; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleCameraSettings) == 0x1c, "Size mismatch for FDelMarVehicleCameraSettings");
static_assert(offsetof(FDelMarVehicleCameraSettings, FOV) == 0x0, "Offset mismatch for FDelMarVehicleCameraSettings::FOV");
static_assert(offsetof(FDelMarVehicleCameraSettings, Height) == 0x4, "Offset mismatch for FDelMarVehicleCameraSettings::Height");
static_assert(offsetof(FDelMarVehicleCameraSettings, pitch) == 0x8, "Offset mismatch for FDelMarVehicleCameraSettings::pitch");
static_assert(offsetof(FDelMarVehicleCameraSettings, Distance) == 0xc, "Offset mismatch for FDelMarVehicleCameraSettings::Distance");
static_assert(offsetof(FDelMarVehicleCameraSettings, Stiffness) == 0x10, "Offset mismatch for FDelMarVehicleCameraSettings::Stiffness");
static_assert(offsetof(FDelMarVehicleCameraSettings, SwivelSpeed) == 0x14, "Offset mismatch for FDelMarVehicleCameraSettings::SwivelSpeed");
static_assert(offsetof(FDelMarVehicleCameraSettings, TransitionSpeed) == 0x18, "Offset mismatch for FDelMarVehicleCameraSettings::TransitionSpeed");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEliminationMMRCountPair
{
    int32_t MaxMmr; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PlayersToEliminate; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDelMarEliminationMMRCountPair) == 0x8, "Size mismatch for FDelMarEliminationMMRCountPair");
static_assert(offsetof(FDelMarEliminationMMRCountPair, MaxMmr) == 0x0, "Offset mismatch for FDelMarEliminationMMRCountPair::MaxMmr");
static_assert(offsetof(FDelMarEliminationMMRCountPair, PlayersToEliminate) == 0x4, "Offset mismatch for FDelMarEliminationMMRCountPair::PlayersToEliminate");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarTimeDelayedState
{
    FGameplayTag Name; // 0x0 (Size: 0x4, Type: StructProperty)
    float duration; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarTimeDelayedState) == 0x8, "Size mismatch for FDelMarTimeDelayedState");
static_assert(offsetof(FDelMarTimeDelayedState, Name) == 0x0, "Offset mismatch for FDelMarTimeDelayedState::Name");
static_assert(offsetof(FDelMarTimeDelayedState, duration) == 0x4, "Offset mismatch for FDelMarTimeDelayedState::duration");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarReplicatedLoadout
{
    TArray<UDelMarCosmeticItemDefinition*> Items; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarReplicatedLoadout) == 0x10, "Size mismatch for FDelMarReplicatedLoadout");
static_assert(offsetof(FDelMarReplicatedLoadout, Items) == 0x0, "Offset mismatch for FDelMarReplicatedLoadout::Items");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDelMarLoadout
{
    TMap<UDelMarCosmeticItemDefinition*, FGameplayTag> Items; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FDelMarLoadout) == 0x50, "Size mismatch for FDelMarLoadout");
static_assert(offsetof(FDelMarLoadout, Items) == 0x0, "Offset mismatch for FDelMarLoadout::Items");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarLeaderboardConfig
{
    FString EventId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString WindowId; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDelMarLeaderboardConfig) == 0x20, "Size mismatch for FDelMarLeaderboardConfig");
static_assert(offsetof(FDelMarLeaderboardConfig, EventId) == 0x0, "Offset mismatch for FDelMarLeaderboardConfig::EventId");
static_assert(offsetof(FDelMarLeaderboardConfig, WindowId) == 0x10, "Offset mismatch for FDelMarLeaderboardConfig::WindowId");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPhysicalMaterialAttributes_X
{
    TArray<UDelMarPhysMatAttribute*> Attributes; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPhysicalMaterialAttributes_X) == 0x10, "Size mismatch for FPhysicalMaterialAttributes_X");
static_assert(offsetof(FPhysicalMaterialAttributes_X, Attributes) == 0x0, "Offset mismatch for FPhysicalMaterialAttributes_X::Attributes");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarNetworkInputPacket
{
};

static_assert(sizeof(FDelMarNetworkInputPacket) == 0x18, "Size mismatch for FDelMarNetworkInputPacket");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarMapStatus
{
    UDelMarLevelDataAsset* MapAsset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bHasBeenPlayed; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarMapStatus) == 0x10, "Size mismatch for FDelMarMapStatus");
static_assert(offsetof(FDelMarMapStatus, MapAsset) == 0x0, "Offset mismatch for FDelMarMapStatus::MapAsset");
static_assert(offsetof(FDelMarMapStatus, bHasBeenPlayed) == 0x8, "Offset mismatch for FDelMarMapStatus::bHasBeenPlayed");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarMapSet
{
    bool bShouldConsiderValid; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bPlayLevelsRandomly; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bShouldRepeat; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x5]; // 0x3 (Size: 0x5, Type: PaddingProperty)
    TArray<FDelMarMapStatus> Levels; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarMapSet) == 0x18, "Size mismatch for FDelMarMapSet");
static_assert(offsetof(FDelMarMapSet, bShouldConsiderValid) == 0x0, "Offset mismatch for FDelMarMapSet::bShouldConsiderValid");
static_assert(offsetof(FDelMarMapSet, bPlayLevelsRandomly) == 0x1, "Offset mismatch for FDelMarMapSet::bPlayLevelsRandomly");
static_assert(offsetof(FDelMarMapSet, bShouldRepeat) == 0x2, "Offset mismatch for FDelMarMapSet::bShouldRepeat");
static_assert(offsetof(FDelMarMapSet, Levels) == 0x8, "Offset mismatch for FDelMarMapSet::Levels");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarDeathRaceConfig
{
    TArray<int32_t> PlacementPointsMap; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ScoreThresholdToEndMatch; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarDeathRaceConfig) == 0x18, "Size mismatch for FDelMarDeathRaceConfig");
static_assert(offsetof(FDelMarDeathRaceConfig, PlacementPointsMap) == 0x0, "Offset mismatch for FDelMarDeathRaceConfig::PlacementPointsMap");
static_assert(offsetof(FDelMarDeathRaceConfig, ScoreThresholdToEndMatch) == 0x10, "Offset mismatch for FDelMarDeathRaceConfig::ScoreThresholdToEndMatch");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarGameplayModifierList
{
    TArray<UClass*> Modifiers; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarGameplayModifierList) == 0x10, "Size mismatch for FDelMarGameplayModifierList");
static_assert(offsetof(FDelMarGameplayModifierList, Modifiers) == 0x0, "Offset mismatch for FDelMarGameplayModifierList::Modifiers");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarPositionValue
{
};

static_assert(sizeof(FDelMarPositionValue) == 0x18, "Size mismatch for FDelMarPositionValue");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarFinalRacePositionEntry
{
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    double RunTime; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarFinalRacePositionEntry) == 0x10, "Size mismatch for FDelMarFinalRacePositionEntry");
static_assert(offsetof(FDelMarFinalRacePositionEntry, PlayerState) == 0x0, "Offset mismatch for FDelMarFinalRacePositionEntry::PlayerState");
static_assert(offsetof(FDelMarFinalRacePositionEntry, RunTime) == 0x8, "Offset mismatch for FDelMarFinalRacePositionEntry::RunTime");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarVehicleRuntimeConfig
{
    bool bCollisionDemosEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIdleDisablesVehicleCollision; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float SecondsToSetIdle; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t VehicleCollisionsGlobalOverride; // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bApplyOverlapFilter; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleRuntimeConfig) == 0xc, "Size mismatch for FDelMarVehicleRuntimeConfig");
static_assert(offsetof(FDelMarVehicleRuntimeConfig, bCollisionDemosEnabled) == 0x0, "Offset mismatch for FDelMarVehicleRuntimeConfig::bCollisionDemosEnabled");
static_assert(offsetof(FDelMarVehicleRuntimeConfig, bIdleDisablesVehicleCollision) == 0x1, "Offset mismatch for FDelMarVehicleRuntimeConfig::bIdleDisablesVehicleCollision");
static_assert(offsetof(FDelMarVehicleRuntimeConfig, SecondsToSetIdle) == 0x4, "Offset mismatch for FDelMarVehicleRuntimeConfig::SecondsToSetIdle");
static_assert(offsetof(FDelMarVehicleRuntimeConfig, VehicleCollisionsGlobalOverride) == 0x8, "Offset mismatch for FDelMarVehicleRuntimeConfig::VehicleCollisionsGlobalOverride");
static_assert(offsetof(FDelMarVehicleRuntimeConfig, bApplyOverlapFilter) == 0x9, "Offset mismatch for FDelMarVehicleRuntimeConfig::bApplyOverlapFilter");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarRespawnConfig
{
    uint8_t SpawnMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bUseTracesToDetermineRespawn; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bRespawnInvulnerabilityEnabled; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float RespawnInvulnerabilitySeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bRespawnCollisionProtectionEnabled; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float RespawnCollisionProtectionSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarRespawnConfig) == 0x10, "Size mismatch for FDelMarRespawnConfig");
static_assert(offsetof(FDelMarRespawnConfig, SpawnMode) == 0x0, "Offset mismatch for FDelMarRespawnConfig::SpawnMode");
static_assert(offsetof(FDelMarRespawnConfig, bUseTracesToDetermineRespawn) == 0x1, "Offset mismatch for FDelMarRespawnConfig::bUseTracesToDetermineRespawn");
static_assert(offsetof(FDelMarRespawnConfig, bRespawnInvulnerabilityEnabled) == 0x2, "Offset mismatch for FDelMarRespawnConfig::bRespawnInvulnerabilityEnabled");
static_assert(offsetof(FDelMarRespawnConfig, RespawnInvulnerabilitySeconds) == 0x4, "Offset mismatch for FDelMarRespawnConfig::RespawnInvulnerabilitySeconds");
static_assert(offsetof(FDelMarRespawnConfig, bRespawnCollisionProtectionEnabled) == 0x8, "Offset mismatch for FDelMarRespawnConfig::bRespawnCollisionProtectionEnabled");
static_assert(offsetof(FDelMarRespawnConfig, RespawnCollisionProtectionSeconds) == 0xc, "Offset mismatch for FDelMarRespawnConfig::RespawnCollisionProtectionSeconds");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarRubberbandingConfig
{
    bool bRubberbandingEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MinPackDistance; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxPackDistance; // 0x8 (Size: 0x4, Type: FloatProperty)
    float PackDistanceOffset; // 0xc (Size: 0x4, Type: FloatProperty)
    float MinDistanceFromPack; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromPack; // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t NumPlayersForPackDistance; // 0x18 (Size: 0x4, Type: IntProperty)
    float MaxPackDistanceGainedPerSecond; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MaxPackDistanceLostPerSecond; // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeedScalar; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarRubberbandingConfig) == 0x28, "Size mismatch for FDelMarRubberbandingConfig");
static_assert(offsetof(FDelMarRubberbandingConfig, bRubberbandingEnabled) == 0x0, "Offset mismatch for FDelMarRubberbandingConfig::bRubberbandingEnabled");
static_assert(offsetof(FDelMarRubberbandingConfig, MinPackDistance) == 0x4, "Offset mismatch for FDelMarRubberbandingConfig::MinPackDistance");
static_assert(offsetof(FDelMarRubberbandingConfig, MaxPackDistance) == 0x8, "Offset mismatch for FDelMarRubberbandingConfig::MaxPackDistance");
static_assert(offsetof(FDelMarRubberbandingConfig, PackDistanceOffset) == 0xc, "Offset mismatch for FDelMarRubberbandingConfig::PackDistanceOffset");
static_assert(offsetof(FDelMarRubberbandingConfig, MinDistanceFromPack) == 0x10, "Offset mismatch for FDelMarRubberbandingConfig::MinDistanceFromPack");
static_assert(offsetof(FDelMarRubberbandingConfig, MaxDistanceFromPack) == 0x14, "Offset mismatch for FDelMarRubberbandingConfig::MaxDistanceFromPack");
static_assert(offsetof(FDelMarRubberbandingConfig, NumPlayersForPackDistance) == 0x18, "Offset mismatch for FDelMarRubberbandingConfig::NumPlayersForPackDistance");
static_assert(offsetof(FDelMarRubberbandingConfig, MaxPackDistanceGainedPerSecond) == 0x1c, "Offset mismatch for FDelMarRubberbandingConfig::MaxPackDistanceGainedPerSecond");
static_assert(offsetof(FDelMarRubberbandingConfig, MaxPackDistanceLostPerSecond) == 0x20, "Offset mismatch for FDelMarRubberbandingConfig::MaxPackDistanceLostPerSecond");
static_assert(offsetof(FDelMarRubberbandingConfig, MaxBonusSpeedScalar) == 0x24, "Offset mismatch for FDelMarRubberbandingConfig::MaxBonusSpeedScalar");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarRubberbandingMMRConfig
{
    float MinMmr; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxMmr; // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarRubberbandingConfig RubberbandingConfig; // 0x8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FDelMarRubberbandingMMRConfig) == 0x30, "Size mismatch for FDelMarRubberbandingMMRConfig");
static_assert(offsetof(FDelMarRubberbandingMMRConfig, MinMmr) == 0x0, "Offset mismatch for FDelMarRubberbandingMMRConfig::MinMmr");
static_assert(offsetof(FDelMarRubberbandingMMRConfig, MaxMmr) == 0x4, "Offset mismatch for FDelMarRubberbandingMMRConfig::MaxMmr");
static_assert(offsetof(FDelMarRubberbandingMMRConfig, RubberbandingConfig) == 0x8, "Offset mismatch for FDelMarRubberbandingMMRConfig::RubberbandingConfig");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDelMarMatchmakingConfig
{
    float MaxLoadWaitSeconds; // 0x0 (Size: 0x4, Type: FloatProperty)
    float LoadWaitBufferSeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
    float CODGracePeriodSeconds; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MatchStartDelaySeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bMatchInProgressBackFillEnabled; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float MinSecondsRemainingForBackfill; // 0x14 (Size: 0x4, Type: FloatProperty)
    float TimeIntervalBetweenAnalyticsSeconds; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarMatchmakingConfig) == 0x1c, "Size mismatch for FDelMarMatchmakingConfig");
static_assert(offsetof(FDelMarMatchmakingConfig, MaxLoadWaitSeconds) == 0x0, "Offset mismatch for FDelMarMatchmakingConfig::MaxLoadWaitSeconds");
static_assert(offsetof(FDelMarMatchmakingConfig, LoadWaitBufferSeconds) == 0x4, "Offset mismatch for FDelMarMatchmakingConfig::LoadWaitBufferSeconds");
static_assert(offsetof(FDelMarMatchmakingConfig, CODGracePeriodSeconds) == 0x8, "Offset mismatch for FDelMarMatchmakingConfig::CODGracePeriodSeconds");
static_assert(offsetof(FDelMarMatchmakingConfig, MatchStartDelaySeconds) == 0xc, "Offset mismatch for FDelMarMatchmakingConfig::MatchStartDelaySeconds");
static_assert(offsetof(FDelMarMatchmakingConfig, bMatchInProgressBackFillEnabled) == 0x10, "Offset mismatch for FDelMarMatchmakingConfig::bMatchInProgressBackFillEnabled");
static_assert(offsetof(FDelMarMatchmakingConfig, MinSecondsRemainingForBackfill) == 0x14, "Offset mismatch for FDelMarMatchmakingConfig::MinSecondsRemainingForBackfill");
static_assert(offsetof(FDelMarMatchmakingConfig, TimeIntervalBetweenAnalyticsSeconds) == 0x18, "Offset mismatch for FDelMarMatchmakingConfig::TimeIntervalBetweenAnalyticsSeconds");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarCurveFloat
{
    float Scale; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UCurveFloat* Curve; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarCurveFloat) == 0x10, "Size mismatch for FDelMarCurveFloat");
static_assert(offsetof(FDelMarCurveFloat, Scale) == 0x0, "Offset mismatch for FDelMarCurveFloat::Scale");
static_assert(offsetof(FDelMarCurveFloat, Curve) == 0x8, "Offset mismatch for FDelMarCurveFloat::Curve");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarBotMMRPenaltyConfig
{
    float MinMmr; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxMmr; // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarCurveFloat TargetSpeedPenaltyCurve; // 0x8 (Size: 0x10, Type: StructProperty)
    FDelMarCurveFloat TargetTurboChancesCurve; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDelMarBotMMRPenaltyConfig) == 0x28, "Size mismatch for FDelMarBotMMRPenaltyConfig");
static_assert(offsetof(FDelMarBotMMRPenaltyConfig, MinMmr) == 0x0, "Offset mismatch for FDelMarBotMMRPenaltyConfig::MinMmr");
static_assert(offsetof(FDelMarBotMMRPenaltyConfig, MaxMmr) == 0x4, "Offset mismatch for FDelMarBotMMRPenaltyConfig::MaxMmr");
static_assert(offsetof(FDelMarBotMMRPenaltyConfig, TargetSpeedPenaltyCurve) == 0x8, "Offset mismatch for FDelMarBotMMRPenaltyConfig::TargetSpeedPenaltyCurve");
static_assert(offsetof(FDelMarBotMMRPenaltyConfig, TargetTurboChancesCurve) == 0x18, "Offset mismatch for FDelMarBotMMRPenaltyConfig::TargetTurboChancesCurve");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarBotRuntimeConfig
{
    FDelMarCurveFloat BotTargetSpeedPenaltyCurve; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FDelMarBotMMRPenaltyConfig> BotTargetSpeedMMRPenalty; // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t NumPlayersAheadForNoBotPenalty; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarBotRuntimeConfig) == 0x28, "Size mismatch for FDelMarBotRuntimeConfig");
static_assert(offsetof(FDelMarBotRuntimeConfig, BotTargetSpeedPenaltyCurve) == 0x0, "Offset mismatch for FDelMarBotRuntimeConfig::BotTargetSpeedPenaltyCurve");
static_assert(offsetof(FDelMarBotRuntimeConfig, BotTargetSpeedMMRPenalty) == 0x10, "Offset mismatch for FDelMarBotRuntimeConfig::BotTargetSpeedMMRPenalty");
static_assert(offsetof(FDelMarBotRuntimeConfig, NumPlayersAheadForNoBotPenalty) == 0x20, "Offset mismatch for FDelMarBotRuntimeConfig::NumPlayersAheadForNoBotPenalty");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarRandomRange
{
    float MinValue; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxValue; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarRandomRange) == 0x8, "Size mismatch for FDelMarRandomRange");
static_assert(offsetof(FDelMarRandomRange, MinValue) == 0x0, "Offset mismatch for FDelMarRandomRange::MinValue");
static_assert(offsetof(FDelMarRandomRange, MaxValue) == 0x4, "Offset mismatch for FDelMarRandomRange::MaxValue");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarStartlineConfig
{
    bool bEnableDynamicStartline; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float InitialCountdownDelayTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float RequestCountdownDelayTime; // 0x8 (Size: 0x4, Type: FloatProperty)
    float DefaultIntervalSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    TArray<FDelMarRandomRange> IntervalRanges; // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t CountdownIntervalNum; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarStartlineConfig) == 0x28, "Size mismatch for FDelMarStartlineConfig");
static_assert(offsetof(FDelMarStartlineConfig, bEnableDynamicStartline) == 0x0, "Offset mismatch for FDelMarStartlineConfig::bEnableDynamicStartline");
static_assert(offsetof(FDelMarStartlineConfig, InitialCountdownDelayTime) == 0x4, "Offset mismatch for FDelMarStartlineConfig::InitialCountdownDelayTime");
static_assert(offsetof(FDelMarStartlineConfig, RequestCountdownDelayTime) == 0x8, "Offset mismatch for FDelMarStartlineConfig::RequestCountdownDelayTime");
static_assert(offsetof(FDelMarStartlineConfig, DefaultIntervalSeconds) == 0xc, "Offset mismatch for FDelMarStartlineConfig::DefaultIntervalSeconds");
static_assert(offsetof(FDelMarStartlineConfig, IntervalRanges) == 0x10, "Offset mismatch for FDelMarStartlineConfig::IntervalRanges");
static_assert(offsetof(FDelMarStartlineConfig, CountdownIntervalNum) == 0x20, "Offset mismatch for FDelMarStartlineConfig::CountdownIntervalNum");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarStateOverride
{
    FGameplayTag StateTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr StateClass; // 0x8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FDelMarStateOverride) == 0x28, "Size mismatch for FDelMarStateOverride");
static_assert(offsetof(FDelMarStateOverride, StateTag) == 0x0, "Offset mismatch for FDelMarStateOverride::StateTag");
static_assert(offsetof(FDelMarStateOverride, StateClass) == 0x8, "Offset mismatch for FDelMarStateOverride::StateClass");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarStateMachineConfig
{
    TArray<FDelMarStateOverride> StateOverrides; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarStateMachineConfig) == 0x10, "Size mismatch for FDelMarStateMachineConfig");
static_assert(offsetof(FDelMarStateMachineConfig, StateOverrides) == 0x0, "Offset mismatch for FDelMarStateMachineConfig::StateOverrides");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FDelMarDynamicCameraShakeEffect
{
    UClass* CameraShakeClass; // 0x0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UCameraShakeBase*> CameraShakeInstance; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    FRuntimeFloatCurve ShakeIntensityCurve; // 0x10 (Size: 0x88, Type: StructProperty)
    float CurrentShakeIntensity; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarDynamicCameraShakeEffect) == 0xa0, "Size mismatch for FDelMarDynamicCameraShakeEffect");
static_assert(offsetof(FDelMarDynamicCameraShakeEffect, CameraShakeClass) == 0x0, "Offset mismatch for FDelMarDynamicCameraShakeEffect::CameraShakeClass");
static_assert(offsetof(FDelMarDynamicCameraShakeEffect, CameraShakeInstance) == 0x8, "Offset mismatch for FDelMarDynamicCameraShakeEffect::CameraShakeInstance");
static_assert(offsetof(FDelMarDynamicCameraShakeEffect, ShakeIntensityCurve) == 0x10, "Offset mismatch for FDelMarDynamicCameraShakeEffect::ShakeIntensityCurve");
static_assert(offsetof(FDelMarDynamicCameraShakeEffect, CurrentShakeIntensity) == 0x98, "Offset mismatch for FDelMarDynamicCameraShakeEffect::CurrentShakeIntensity");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarThrottledValue
{
    float RiseRate; // 0x0 (Size: 0x4, Type: FloatProperty)
    float FallRate; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarThrottledValue) == 0x8, "Size mismatch for FDelMarThrottledValue");
static_assert(offsetof(FDelMarThrottledValue, RiseRate) == 0x0, "Offset mismatch for FDelMarThrottledValue::RiseRate");
static_assert(offsetof(FDelMarThrottledValue, FallRate) == 0x4, "Offset mismatch for FDelMarThrottledValue::FallRate");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleLandingLevel
{
    float MinForce; // 0x0 (Size: 0x4, Type: FloatProperty)
    float SpeedChange; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleLandingLevel) == 0x8, "Size mismatch for FDelMarVehicleLandingLevel");
static_assert(offsetof(FDelMarVehicleLandingLevel, MinForce) == 0x0, "Offset mismatch for FDelMarVehicleLandingLevel::MinForce");
static_assert(offsetof(FDelMarVehicleLandingLevel, SpeedChange) == 0x4, "Offset mismatch for FDelMarVehicleLandingLevel::SpeedChange");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarTurboBonusZone
{
    float ZoneStartTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ZoneEndTime; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarTurboBonusZone) == 0x8, "Size mismatch for FDelMarTurboBonusZone");
static_assert(offsetof(FDelMarTurboBonusZone, ZoneStartTime) == 0x0, "Offset mismatch for FDelMarTurboBonusZone::ZoneStartTime");
static_assert(offsetof(FDelMarTurboBonusZone, ZoneEndTime) == 0x4, "Offset mismatch for FDelMarTurboBonusZone::ZoneEndTime");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarWorldBonusSpeedSourceCap
{
    FGameplayTag Source; // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t StackCap; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDelMarWorldBonusSpeedSourceCap) == 0x8, "Size mismatch for FDelMarWorldBonusSpeedSourceCap");
static_assert(offsetof(FDelMarWorldBonusSpeedSourceCap, Source) == 0x0, "Offset mismatch for FDelMarWorldBonusSpeedSourceCap::Source");
static_assert(offsetof(FDelMarWorldBonusSpeedSourceCap, StackCap) == 0x4, "Offset mismatch for FDelMarWorldBonusSpeedSourceCap::StackCap");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDelMarVehicleRigidBodyConfig
{
    bool bApplyGlobalBodySettings; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float LinearDamping; // 0x4 (Size: 0x4, Type: FloatProperty)
    float AngularDamping; // 0x8 (Size: 0x4, Type: FloatProperty)
    float VehicleMass; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bNotifyRigidBodyCollisions; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bSmoothEdgeCollisionsEnabled; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bUseCCD; // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13[0x5]; // 0x13 (Size: 0x5, Type: PaddingProperty)
    FVector CenterOfMassOffset; // 0x18 (Size: 0x18, Type: StructProperty)
    bool bSuspensionIgnoresBodyCollision; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleRigidBodyConfig) == 0x38, "Size mismatch for FDelMarVehicleRigidBodyConfig");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, bApplyGlobalBodySettings) == 0x0, "Offset mismatch for FDelMarVehicleRigidBodyConfig::bApplyGlobalBodySettings");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, LinearDamping) == 0x4, "Offset mismatch for FDelMarVehicleRigidBodyConfig::LinearDamping");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, AngularDamping) == 0x8, "Offset mismatch for FDelMarVehicleRigidBodyConfig::AngularDamping");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, VehicleMass) == 0xc, "Offset mismatch for FDelMarVehicleRigidBodyConfig::VehicleMass");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, bNotifyRigidBodyCollisions) == 0x10, "Offset mismatch for FDelMarVehicleRigidBodyConfig::bNotifyRigidBodyCollisions");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, bSmoothEdgeCollisionsEnabled) == 0x11, "Offset mismatch for FDelMarVehicleRigidBodyConfig::bSmoothEdgeCollisionsEnabled");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, bUseCCD) == 0x12, "Offset mismatch for FDelMarVehicleRigidBodyConfig::bUseCCD");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, CenterOfMassOffset) == 0x18, "Offset mismatch for FDelMarVehicleRigidBodyConfig::CenterOfMassOffset");
static_assert(offsetof(FDelMarVehicleRigidBodyConfig, bSuspensionIgnoresBodyCollision) == 0x30, "Offset mismatch for FDelMarVehicleRigidBodyConfig::bSuspensionIgnoresBodyCollision");

// Size: 0x370 (Inherited: 0x0, Single: 0x370)
struct FDelMarVehicleDriveSetup
{
    float MaxBaseForwardSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve DriveAccel; // 0x8 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve TargetSpeedMaxAccelCurve; // 0x98 (Size: 0x90, Type: StructProperty)
    float TargetSpeedAerialFriction; // 0x128 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForPersistentTargetSpeedModifier; // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bAllowBrakingInAir; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0x3]; // 0x131 (Size: 0x3, Type: PaddingProperty)
    float BrakeAccel; // 0x134 (Size: 0x4, Type: FloatProperty)
    float StopSpeed; // 0x138 (Size: 0x4, Type: FloatProperty)
    float IdleBrakeFactor; // 0x13c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedToResetTargetSpeedDirection; // 0x140 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_144[0x4]; // 0x144 (Size: 0x4, Type: PaddingProperty)
    FRuntimeFloatCurve SteerAngleCurve; // 0x148 (Size: 0x88, Type: StructProperty)
    TArray<FRuntimeFloatCurve> SteerAngleCurveOverrides; // 0x1d0 (Size: 0x10, Type: ArrayProperty)
    FDelMarScaledCurve LatFrictionCurve; // 0x1e0 (Size: 0x90, Type: StructProperty)
    FRuntimeFloatCurve WheelsGroundedFrictionCurve; // 0x270 (Size: 0x88, Type: StructProperty)
    float MaxForwardSpeedToIgnoreLandingSpeed; // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float MaxKickflipLandingSeconds; // 0x2fc (Size: 0x4, Type: FloatProperty)
    float SkydiveVerticalVelocitySensitivity; // 0x300 (Size: 0x4, Type: FloatProperty)
    float SkydiveVerticalPitchSensitivity; // 0x304 (Size: 0x4, Type: FloatProperty)
    float MinInAirTimeStableLanding; // 0x308 (Size: 0x4, Type: FloatProperty)
    int32_t NumWheelsForActivelyLanding; // 0x30c (Size: 0x4, Type: IntProperty)
    float MinAerialSpeedForPrimaryDirection; // 0x310 (Size: 0x4, Type: FloatProperty)
    float MaxGroundNormalDiffForPrimaryDirection; // 0x314 (Size: 0x4, Type: FloatProperty)
    float MinPrevVelocityDotProductForPrimaryDirection; // 0x318 (Size: 0x4, Type: FloatProperty)
    float ForwardMaxSpeed; // 0x31c (Size: 0x4, Type: FloatProperty)
    float UpwardMaxLandingSpeed; // 0x320 (Size: 0x4, Type: FloatProperty)
    float UpwardMaxSpeed; // 0x324 (Size: 0x4, Type: FloatProperty)
    float MaxLandingAngularVelocity; // 0x328 (Size: 0x4, Type: FloatProperty)
    float MaxLinearSpeed; // 0x32c (Size: 0x4, Type: FloatProperty)
    float MaxAngularSpeed; // 0x330 (Size: 0x4, Type: FloatProperty)
    float MinCeilingDegrees; // 0x334 (Size: 0x4, Type: FloatProperty)
    float MaxCeilingDegrees; // 0x338 (Size: 0x4, Type: FloatProperty)
    float AerialCeilingDegrees; // 0x33c (Size: 0x4, Type: FloatProperty)
    float MaxInvertedControlSteering; // 0x340 (Size: 0x4, Type: FloatProperty)
    float MinCeilingSecondsToInvertControls; // 0x344 (Size: 0x4, Type: FloatProperty)
    float WheelPushForce; // 0x348 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForVelocityDirection; // 0x34c (Size: 0x4, Type: FloatProperty)
    float MinZSpeedForUpwardDirection; // 0x350 (Size: 0x4, Type: FloatProperty)
    float VerticalOrientationSensitivity; // 0x354 (Size: 0x4, Type: FloatProperty)
    float MaxInactiveLandedFlipTime; // 0x358 (Size: 0x4, Type: FloatProperty)
    int32_t NumWheelsForWheelsOnGround; // 0x35c (Size: 0x4, Type: IntProperty)
    float MaxLandingSpeedSpringVarianceDegrees; // 0x360 (Size: 0x4, Type: FloatProperty)
    float MinDownDegreesForForwardDirection; // 0x364 (Size: 0x4, Type: FloatProperty)
    float MaxNormalizedForwardSpeed; // 0x368 (Size: 0x4, Type: FloatProperty)
    float MaxNormalizedBonusSpeed; // 0x36c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleDriveSetup) == 0x370, "Size mismatch for FDelMarVehicleDriveSetup");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxBaseForwardSpeed) == 0x0, "Offset mismatch for FDelMarVehicleDriveSetup::MaxBaseForwardSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, DriveAccel) == 0x8, "Offset mismatch for FDelMarVehicleDriveSetup::DriveAccel");
static_assert(offsetof(FDelMarVehicleDriveSetup, TargetSpeedMaxAccelCurve) == 0x98, "Offset mismatch for FDelMarVehicleDriveSetup::TargetSpeedMaxAccelCurve");
static_assert(offsetof(FDelMarVehicleDriveSetup, TargetSpeedAerialFriction) == 0x128, "Offset mismatch for FDelMarVehicleDriveSetup::TargetSpeedAerialFriction");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinSpeedForPersistentTargetSpeedModifier) == 0x12c, "Offset mismatch for FDelMarVehicleDriveSetup::MinSpeedForPersistentTargetSpeedModifier");
static_assert(offsetof(FDelMarVehicleDriveSetup, bAllowBrakingInAir) == 0x130, "Offset mismatch for FDelMarVehicleDriveSetup::bAllowBrakingInAir");
static_assert(offsetof(FDelMarVehicleDriveSetup, BrakeAccel) == 0x134, "Offset mismatch for FDelMarVehicleDriveSetup::BrakeAccel");
static_assert(offsetof(FDelMarVehicleDriveSetup, StopSpeed) == 0x138, "Offset mismatch for FDelMarVehicleDriveSetup::StopSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, IdleBrakeFactor) == 0x13c, "Offset mismatch for FDelMarVehicleDriveSetup::IdleBrakeFactor");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxSpeedToResetTargetSpeedDirection) == 0x140, "Offset mismatch for FDelMarVehicleDriveSetup::MaxSpeedToResetTargetSpeedDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, SteerAngleCurve) == 0x148, "Offset mismatch for FDelMarVehicleDriveSetup::SteerAngleCurve");
static_assert(offsetof(FDelMarVehicleDriveSetup, SteerAngleCurveOverrides) == 0x1d0, "Offset mismatch for FDelMarVehicleDriveSetup::SteerAngleCurveOverrides");
static_assert(offsetof(FDelMarVehicleDriveSetup, LatFrictionCurve) == 0x1e0, "Offset mismatch for FDelMarVehicleDriveSetup::LatFrictionCurve");
static_assert(offsetof(FDelMarVehicleDriveSetup, WheelsGroundedFrictionCurve) == 0x270, "Offset mismatch for FDelMarVehicleDriveSetup::WheelsGroundedFrictionCurve");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxForwardSpeedToIgnoreLandingSpeed) == 0x2f8, "Offset mismatch for FDelMarVehicleDriveSetup::MaxForwardSpeedToIgnoreLandingSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxKickflipLandingSeconds) == 0x2fc, "Offset mismatch for FDelMarVehicleDriveSetup::MaxKickflipLandingSeconds");
static_assert(offsetof(FDelMarVehicleDriveSetup, SkydiveVerticalVelocitySensitivity) == 0x300, "Offset mismatch for FDelMarVehicleDriveSetup::SkydiveVerticalVelocitySensitivity");
static_assert(offsetof(FDelMarVehicleDriveSetup, SkydiveVerticalPitchSensitivity) == 0x304, "Offset mismatch for FDelMarVehicleDriveSetup::SkydiveVerticalPitchSensitivity");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinInAirTimeStableLanding) == 0x308, "Offset mismatch for FDelMarVehicleDriveSetup::MinInAirTimeStableLanding");
static_assert(offsetof(FDelMarVehicleDriveSetup, NumWheelsForActivelyLanding) == 0x30c, "Offset mismatch for FDelMarVehicleDriveSetup::NumWheelsForActivelyLanding");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinAerialSpeedForPrimaryDirection) == 0x310, "Offset mismatch for FDelMarVehicleDriveSetup::MinAerialSpeedForPrimaryDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxGroundNormalDiffForPrimaryDirection) == 0x314, "Offset mismatch for FDelMarVehicleDriveSetup::MaxGroundNormalDiffForPrimaryDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinPrevVelocityDotProductForPrimaryDirection) == 0x318, "Offset mismatch for FDelMarVehicleDriveSetup::MinPrevVelocityDotProductForPrimaryDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, ForwardMaxSpeed) == 0x31c, "Offset mismatch for FDelMarVehicleDriveSetup::ForwardMaxSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, UpwardMaxLandingSpeed) == 0x320, "Offset mismatch for FDelMarVehicleDriveSetup::UpwardMaxLandingSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, UpwardMaxSpeed) == 0x324, "Offset mismatch for FDelMarVehicleDriveSetup::UpwardMaxSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxLandingAngularVelocity) == 0x328, "Offset mismatch for FDelMarVehicleDriveSetup::MaxLandingAngularVelocity");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxLinearSpeed) == 0x32c, "Offset mismatch for FDelMarVehicleDriveSetup::MaxLinearSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxAngularSpeed) == 0x330, "Offset mismatch for FDelMarVehicleDriveSetup::MaxAngularSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinCeilingDegrees) == 0x334, "Offset mismatch for FDelMarVehicleDriveSetup::MinCeilingDegrees");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxCeilingDegrees) == 0x338, "Offset mismatch for FDelMarVehicleDriveSetup::MaxCeilingDegrees");
static_assert(offsetof(FDelMarVehicleDriveSetup, AerialCeilingDegrees) == 0x33c, "Offset mismatch for FDelMarVehicleDriveSetup::AerialCeilingDegrees");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxInvertedControlSteering) == 0x340, "Offset mismatch for FDelMarVehicleDriveSetup::MaxInvertedControlSteering");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinCeilingSecondsToInvertControls) == 0x344, "Offset mismatch for FDelMarVehicleDriveSetup::MinCeilingSecondsToInvertControls");
static_assert(offsetof(FDelMarVehicleDriveSetup, WheelPushForce) == 0x348, "Offset mismatch for FDelMarVehicleDriveSetup::WheelPushForce");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinSpeedForVelocityDirection) == 0x34c, "Offset mismatch for FDelMarVehicleDriveSetup::MinSpeedForVelocityDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinZSpeedForUpwardDirection) == 0x350, "Offset mismatch for FDelMarVehicleDriveSetup::MinZSpeedForUpwardDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, VerticalOrientationSensitivity) == 0x354, "Offset mismatch for FDelMarVehicleDriveSetup::VerticalOrientationSensitivity");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxInactiveLandedFlipTime) == 0x358, "Offset mismatch for FDelMarVehicleDriveSetup::MaxInactiveLandedFlipTime");
static_assert(offsetof(FDelMarVehicleDriveSetup, NumWheelsForWheelsOnGround) == 0x35c, "Offset mismatch for FDelMarVehicleDriveSetup::NumWheelsForWheelsOnGround");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxLandingSpeedSpringVarianceDegrees) == 0x360, "Offset mismatch for FDelMarVehicleDriveSetup::MaxLandingSpeedSpringVarianceDegrees");
static_assert(offsetof(FDelMarVehicleDriveSetup, MinDownDegreesForForwardDirection) == 0x364, "Offset mismatch for FDelMarVehicleDriveSetup::MinDownDegreesForForwardDirection");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxNormalizedForwardSpeed) == 0x368, "Offset mismatch for FDelMarVehicleDriveSetup::MaxNormalizedForwardSpeed");
static_assert(offsetof(FDelMarVehicleDriveSetup, MaxNormalizedBonusSpeed) == 0x36c, "Offset mismatch for FDelMarVehicleDriveSetup::MaxNormalizedBonusSpeed");

// Size: 0x1f8 (Inherited: 0x0, Single: 0x1f8)
struct FDelMarVehicleCollisionConfig
{
    float MinWallAngleDegrees; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinTimeBetweenSpeedLossHits; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForTargetSpeedReduction; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve SpeedReductionPercentageCurve; // 0x10 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AerialSpeedReductionPercentageCurve; // 0xa0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve WallTargetRedirectAngleDegreesCurve; // 0x130 (Size: 0x90, Type: StructProperty)
    float WallTargetRedirectPercent; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float WallTargetRedirectDriftPercent; // 0x1c4 (Size: 0x4, Type: FloatProperty)
    float WallDriftHeadOnThresholdDegrees; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    float WallHeadOnDriftRedirectAngleDegrees; // 0x1cc (Size: 0x4, Type: FloatProperty)
    float WallTargetRedirectHeadOnDriftPercent; // 0x1d0 (Size: 0x4, Type: FloatProperty)
    float MinGroundedDemolitionSpeed; // 0x1d4 (Size: 0x4, Type: FloatProperty)
    float MinAerialDemolitionSpeed; // 0x1d8 (Size: 0x4, Type: FloatProperty)
    float MaxGroundedDemolitionAngleDegrees; // 0x1dc (Size: 0x4, Type: FloatProperty)
    float MaxAerialDemolitionAngleDegrees; // 0x1e0 (Size: 0x4, Type: FloatProperty)
    float ParallelCollisionThresholdDegrees; // 0x1e4 (Size: 0x4, Type: FloatProperty)
    float HeadOnCollisionThresholdDegrees; // 0x1e8 (Size: 0x4, Type: FloatProperty)
    float BumperToBumperThresholdDegrees; // 0x1ec (Size: 0x4, Type: FloatProperty)
    float ContactNormalToVehicleRightThresholdDegrees; // 0x1f0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> TrackTraceChannel; // 0x1f4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1f5[0x3]; // 0x1f5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleCollisionConfig) == 0x1f8, "Size mismatch for FDelMarVehicleCollisionConfig");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MinWallAngleDegrees) == 0x0, "Offset mismatch for FDelMarVehicleCollisionConfig::MinWallAngleDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MinTimeBetweenSpeedLossHits) == 0x4, "Offset mismatch for FDelMarVehicleCollisionConfig::MinTimeBetweenSpeedLossHits");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MinSpeedForTargetSpeedReduction) == 0x8, "Offset mismatch for FDelMarVehicleCollisionConfig::MinSpeedForTargetSpeedReduction");
static_assert(offsetof(FDelMarVehicleCollisionConfig, SpeedReductionPercentageCurve) == 0x10, "Offset mismatch for FDelMarVehicleCollisionConfig::SpeedReductionPercentageCurve");
static_assert(offsetof(FDelMarVehicleCollisionConfig, AerialSpeedReductionPercentageCurve) == 0xa0, "Offset mismatch for FDelMarVehicleCollisionConfig::AerialSpeedReductionPercentageCurve");
static_assert(offsetof(FDelMarVehicleCollisionConfig, WallTargetRedirectAngleDegreesCurve) == 0x130, "Offset mismatch for FDelMarVehicleCollisionConfig::WallTargetRedirectAngleDegreesCurve");
static_assert(offsetof(FDelMarVehicleCollisionConfig, WallTargetRedirectPercent) == 0x1c0, "Offset mismatch for FDelMarVehicleCollisionConfig::WallTargetRedirectPercent");
static_assert(offsetof(FDelMarVehicleCollisionConfig, WallTargetRedirectDriftPercent) == 0x1c4, "Offset mismatch for FDelMarVehicleCollisionConfig::WallTargetRedirectDriftPercent");
static_assert(offsetof(FDelMarVehicleCollisionConfig, WallDriftHeadOnThresholdDegrees) == 0x1c8, "Offset mismatch for FDelMarVehicleCollisionConfig::WallDriftHeadOnThresholdDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, WallHeadOnDriftRedirectAngleDegrees) == 0x1cc, "Offset mismatch for FDelMarVehicleCollisionConfig::WallHeadOnDriftRedirectAngleDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, WallTargetRedirectHeadOnDriftPercent) == 0x1d0, "Offset mismatch for FDelMarVehicleCollisionConfig::WallTargetRedirectHeadOnDriftPercent");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MinGroundedDemolitionSpeed) == 0x1d4, "Offset mismatch for FDelMarVehicleCollisionConfig::MinGroundedDemolitionSpeed");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MinAerialDemolitionSpeed) == 0x1d8, "Offset mismatch for FDelMarVehicleCollisionConfig::MinAerialDemolitionSpeed");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MaxGroundedDemolitionAngleDegrees) == 0x1dc, "Offset mismatch for FDelMarVehicleCollisionConfig::MaxGroundedDemolitionAngleDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, MaxAerialDemolitionAngleDegrees) == 0x1e0, "Offset mismatch for FDelMarVehicleCollisionConfig::MaxAerialDemolitionAngleDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, ParallelCollisionThresholdDegrees) == 0x1e4, "Offset mismatch for FDelMarVehicleCollisionConfig::ParallelCollisionThresholdDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, HeadOnCollisionThresholdDegrees) == 0x1e8, "Offset mismatch for FDelMarVehicleCollisionConfig::HeadOnCollisionThresholdDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, BumperToBumperThresholdDegrees) == 0x1ec, "Offset mismatch for FDelMarVehicleCollisionConfig::BumperToBumperThresholdDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, ContactNormalToVehicleRightThresholdDegrees) == 0x1f0, "Offset mismatch for FDelMarVehicleCollisionConfig::ContactNormalToVehicleRightThresholdDegrees");
static_assert(offsetof(FDelMarVehicleCollisionConfig, TrackTraceChannel) == 0x1f4, "Offset mismatch for FDelMarVehicleCollisionConfig::TrackTraceChannel");

// Size: 0x718 (Inherited: 0x0, Single: 0x718)
struct FDelMarVehicleDriftConfig
{
    float MinSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinDirectedDriftTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinInAirTime; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AerialDriftNoKeybindGracePeriod; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxForcedDriftTime; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MinKickDriftActiveSeconds; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bForceSteerWhenKicking; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    float MinForcedSteerWhenKicking; // 0x1c (Size: 0x4, Type: FloatProperty)
    float KickCooldownSeconds; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bActivateDriftOnStrafeEnd; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bActivateDriftOnLanding; // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bActivateDriftOnKickflipLanding; // 0x26 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27[0x1]; // 0x27 (Size: 0x1, Type: PaddingProperty)
    float ActivateExitDriftTime; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinSteerInput; // 0x2c (Size: 0x4, Type: FloatProperty)
    float MinFullThrottleInput; // 0x30 (Size: 0x4, Type: FloatProperty)
    float MinFullDriftInput; // 0x34 (Size: 0x4, Type: FloatProperty)
    float ForcedDriftSteer; // 0x38 (Size: 0x4, Type: FloatProperty)
    float InitialTorqueImpulse; // 0x3c (Size: 0x4, Type: FloatProperty)
    float MaxAllowedGroundedSpringVarianceDegrees; // 0x40 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelInDriftDir; // 0x44 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelNoSteer; // 0x48 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelNotInDriftDir; // 0x4c (Size: 0x4, Type: FloatProperty)
    float TorqueAccelChangeDir; // 0x50 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelDampening; // 0x54 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelWithKick; // 0x58 (Size: 0x4, Type: FloatProperty)
    float TorqueAccelWithKickV2; // 0x5c (Size: 0x4, Type: FloatProperty)
    float TorqueAccelForcedDrift; // 0x60 (Size: 0x4, Type: FloatProperty)
    float TorqueAgainstExit; // 0x64 (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedWithThrottle; // 0x68 (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedNoThrottle; // 0x6c (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedWithKick; // 0x70 (Size: 0x4, Type: FloatProperty)
    float MaxRotationSpeedSwapDirections; // 0x74 (Size: 0x4, Type: FloatProperty)
    float MinDriftDegrees; // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaxDriftDegrees; // 0x7c (Size: 0x4, Type: FloatProperty)
    float ExitDriftDegrees; // 0x80 (Size: 0x4, Type: FloatProperty)
    float ApproachDistance; // 0x84 (Size: 0x4, Type: FloatProperty)
    float PeakForwardSpeedDegrees; // 0x88 (Size: 0x4, Type: FloatProperty)
    float KickRedirectRate; // 0x8c (Size: 0x4, Type: FloatProperty)
    float KickRedirectRateV2; // 0x90 (Size: 0x4, Type: FloatProperty)
    float ForcedDriftRedirectRate; // 0x94 (Size: 0x4, Type: FloatProperty)
    float MinSteerRedirectInput; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve NonKickRedirectRateCurve; // 0xa0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveControlled; // 0x130 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAgainstAngleCurveControlled; // 0x1c0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveNoSteer; // 0x250 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveUncontrolled; // 0x2e0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveKickback; // 0x370 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve VelocityRedirectAngleCurveKickbackV2; // 0x400 (Size: 0x90, Type: StructProperty)
    float PeakSpeedIncreaseDegrees; // 0x490 (Size: 0x4, Type: FloatProperty)
    float MaxAccelSpeed; // 0x494 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve AccelerationScalarCurve; // 0x498 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AdditionalSpeedLossNoThrottle; // 0x528 (Size: 0x90, Type: StructProperty)
    float MaxControlledDriftRatio; // 0x5b8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5bc[0x4]; // 0x5bc (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve ControlledSpeedCapBySlipAngle; // 0x5c0 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve ControlledSpeedCapDecelRate; // 0x650 (Size: 0x90, Type: StructProperty)
    float UncontrolledSpeedCap; // 0x6e0 (Size: 0x4, Type: FloatProperty)
    float UncontrolledSpeedLoss; // 0x6e4 (Size: 0x4, Type: FloatProperty)
    float ExitVelocityMaxDegrees; // 0x6e8 (Size: 0x4, Type: FloatProperty)
    float ExitKickEndMaxDegrees; // 0x6ec (Size: 0x4, Type: FloatProperty)
    float ExitVelocityTorqueAccel; // 0x6f0 (Size: 0x4, Type: FloatProperty)
    float ExitVelocityMaxRotationSpeed; // 0x6f4 (Size: 0x4, Type: FloatProperty)
    float ExitForwardMaxDegrees; // 0x6f8 (Size: 0x4, Type: FloatProperty)
    float ExitForwardTorqueSteer; // 0x6fc (Size: 0x4, Type: FloatProperty)
    float ExitForwardMaxRotation; // 0x700 (Size: 0x4, Type: FloatProperty)
    float ExitForwardTargetRedirectRate; // 0x704 (Size: 0x4, Type: FloatProperty)
    float ExitForwardRedirectRate; // 0x708 (Size: 0x4, Type: FloatProperty)
    float MaxExitForwardLandingSpeed; // 0x70c (Size: 0x4, Type: FloatProperty)
    bool bEnforceThrottleForControlledDrift; // 0x710 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_711[0x7]; // 0x711 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleDriftConfig) == 0x718, "Size mismatch for FDelMarVehicleDriftConfig");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinSpeed) == 0x0, "Offset mismatch for FDelMarVehicleDriftConfig::MinSpeed");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinDirectedDriftTime) == 0x4, "Offset mismatch for FDelMarVehicleDriftConfig::MinDirectedDriftTime");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinInAirTime) == 0x8, "Offset mismatch for FDelMarVehicleDriftConfig::MinInAirTime");
static_assert(offsetof(FDelMarVehicleDriftConfig, AerialDriftNoKeybindGracePeriod) == 0xc, "Offset mismatch for FDelMarVehicleDriftConfig::AerialDriftNoKeybindGracePeriod");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxForcedDriftTime) == 0x10, "Offset mismatch for FDelMarVehicleDriftConfig::MaxForcedDriftTime");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinKickDriftActiveSeconds) == 0x14, "Offset mismatch for FDelMarVehicleDriftConfig::MinKickDriftActiveSeconds");
static_assert(offsetof(FDelMarVehicleDriftConfig, bForceSteerWhenKicking) == 0x18, "Offset mismatch for FDelMarVehicleDriftConfig::bForceSteerWhenKicking");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinForcedSteerWhenKicking) == 0x1c, "Offset mismatch for FDelMarVehicleDriftConfig::MinForcedSteerWhenKicking");
static_assert(offsetof(FDelMarVehicleDriftConfig, KickCooldownSeconds) == 0x20, "Offset mismatch for FDelMarVehicleDriftConfig::KickCooldownSeconds");
static_assert(offsetof(FDelMarVehicleDriftConfig, bActivateDriftOnStrafeEnd) == 0x24, "Offset mismatch for FDelMarVehicleDriftConfig::bActivateDriftOnStrafeEnd");
static_assert(offsetof(FDelMarVehicleDriftConfig, bActivateDriftOnLanding) == 0x25, "Offset mismatch for FDelMarVehicleDriftConfig::bActivateDriftOnLanding");
static_assert(offsetof(FDelMarVehicleDriftConfig, bActivateDriftOnKickflipLanding) == 0x26, "Offset mismatch for FDelMarVehicleDriftConfig::bActivateDriftOnKickflipLanding");
static_assert(offsetof(FDelMarVehicleDriftConfig, ActivateExitDriftTime) == 0x28, "Offset mismatch for FDelMarVehicleDriftConfig::ActivateExitDriftTime");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinSteerInput) == 0x2c, "Offset mismatch for FDelMarVehicleDriftConfig::MinSteerInput");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinFullThrottleInput) == 0x30, "Offset mismatch for FDelMarVehicleDriftConfig::MinFullThrottleInput");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinFullDriftInput) == 0x34, "Offset mismatch for FDelMarVehicleDriftConfig::MinFullDriftInput");
static_assert(offsetof(FDelMarVehicleDriftConfig, ForcedDriftSteer) == 0x38, "Offset mismatch for FDelMarVehicleDriftConfig::ForcedDriftSteer");
static_assert(offsetof(FDelMarVehicleDriftConfig, InitialTorqueImpulse) == 0x3c, "Offset mismatch for FDelMarVehicleDriftConfig::InitialTorqueImpulse");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxAllowedGroundedSpringVarianceDegrees) == 0x40, "Offset mismatch for FDelMarVehicleDriftConfig::MaxAllowedGroundedSpringVarianceDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelInDriftDir) == 0x44, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelInDriftDir");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelNoSteer) == 0x48, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelNoSteer");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelNotInDriftDir) == 0x4c, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelNotInDriftDir");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelChangeDir) == 0x50, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelChangeDir");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelDampening) == 0x54, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelDampening");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelWithKick) == 0x58, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelWithKick");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelWithKickV2) == 0x5c, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelWithKickV2");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAccelForcedDrift) == 0x60, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAccelForcedDrift");
static_assert(offsetof(FDelMarVehicleDriftConfig, TorqueAgainstExit) == 0x64, "Offset mismatch for FDelMarVehicleDriftConfig::TorqueAgainstExit");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxRotationSpeedWithThrottle) == 0x68, "Offset mismatch for FDelMarVehicleDriftConfig::MaxRotationSpeedWithThrottle");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxRotationSpeedNoThrottle) == 0x6c, "Offset mismatch for FDelMarVehicleDriftConfig::MaxRotationSpeedNoThrottle");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxRotationSpeedWithKick) == 0x70, "Offset mismatch for FDelMarVehicleDriftConfig::MaxRotationSpeedWithKick");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxRotationSpeedSwapDirections) == 0x74, "Offset mismatch for FDelMarVehicleDriftConfig::MaxRotationSpeedSwapDirections");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinDriftDegrees) == 0x78, "Offset mismatch for FDelMarVehicleDriftConfig::MinDriftDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxDriftDegrees) == 0x7c, "Offset mismatch for FDelMarVehicleDriftConfig::MaxDriftDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitDriftDegrees) == 0x80, "Offset mismatch for FDelMarVehicleDriftConfig::ExitDriftDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, ApproachDistance) == 0x84, "Offset mismatch for FDelMarVehicleDriftConfig::ApproachDistance");
static_assert(offsetof(FDelMarVehicleDriftConfig, PeakForwardSpeedDegrees) == 0x88, "Offset mismatch for FDelMarVehicleDriftConfig::PeakForwardSpeedDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, KickRedirectRate) == 0x8c, "Offset mismatch for FDelMarVehicleDriftConfig::KickRedirectRate");
static_assert(offsetof(FDelMarVehicleDriftConfig, KickRedirectRateV2) == 0x90, "Offset mismatch for FDelMarVehicleDriftConfig::KickRedirectRateV2");
static_assert(offsetof(FDelMarVehicleDriftConfig, ForcedDriftRedirectRate) == 0x94, "Offset mismatch for FDelMarVehicleDriftConfig::ForcedDriftRedirectRate");
static_assert(offsetof(FDelMarVehicleDriftConfig, MinSteerRedirectInput) == 0x98, "Offset mismatch for FDelMarVehicleDriftConfig::MinSteerRedirectInput");
static_assert(offsetof(FDelMarVehicleDriftConfig, NonKickRedirectRateCurve) == 0xa0, "Offset mismatch for FDelMarVehicleDriftConfig::NonKickRedirectRateCurve");
static_assert(offsetof(FDelMarVehicleDriftConfig, VelocityRedirectAngleCurveControlled) == 0x130, "Offset mismatch for FDelMarVehicleDriftConfig::VelocityRedirectAngleCurveControlled");
static_assert(offsetof(FDelMarVehicleDriftConfig, VelocityRedirectAgainstAngleCurveControlled) == 0x1c0, "Offset mismatch for FDelMarVehicleDriftConfig::VelocityRedirectAgainstAngleCurveControlled");
static_assert(offsetof(FDelMarVehicleDriftConfig, VelocityRedirectAngleCurveNoSteer) == 0x250, "Offset mismatch for FDelMarVehicleDriftConfig::VelocityRedirectAngleCurveNoSteer");
static_assert(offsetof(FDelMarVehicleDriftConfig, VelocityRedirectAngleCurveUncontrolled) == 0x2e0, "Offset mismatch for FDelMarVehicleDriftConfig::VelocityRedirectAngleCurveUncontrolled");
static_assert(offsetof(FDelMarVehicleDriftConfig, VelocityRedirectAngleCurveKickback) == 0x370, "Offset mismatch for FDelMarVehicleDriftConfig::VelocityRedirectAngleCurveKickback");
static_assert(offsetof(FDelMarVehicleDriftConfig, VelocityRedirectAngleCurveKickbackV2) == 0x400, "Offset mismatch for FDelMarVehicleDriftConfig::VelocityRedirectAngleCurveKickbackV2");
static_assert(offsetof(FDelMarVehicleDriftConfig, PeakSpeedIncreaseDegrees) == 0x490, "Offset mismatch for FDelMarVehicleDriftConfig::PeakSpeedIncreaseDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxAccelSpeed) == 0x494, "Offset mismatch for FDelMarVehicleDriftConfig::MaxAccelSpeed");
static_assert(offsetof(FDelMarVehicleDriftConfig, AccelerationScalarCurve) == 0x498, "Offset mismatch for FDelMarVehicleDriftConfig::AccelerationScalarCurve");
static_assert(offsetof(FDelMarVehicleDriftConfig, AdditionalSpeedLossNoThrottle) == 0x528, "Offset mismatch for FDelMarVehicleDriftConfig::AdditionalSpeedLossNoThrottle");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxControlledDriftRatio) == 0x5b8, "Offset mismatch for FDelMarVehicleDriftConfig::MaxControlledDriftRatio");
static_assert(offsetof(FDelMarVehicleDriftConfig, ControlledSpeedCapBySlipAngle) == 0x5c0, "Offset mismatch for FDelMarVehicleDriftConfig::ControlledSpeedCapBySlipAngle");
static_assert(offsetof(FDelMarVehicleDriftConfig, ControlledSpeedCapDecelRate) == 0x650, "Offset mismatch for FDelMarVehicleDriftConfig::ControlledSpeedCapDecelRate");
static_assert(offsetof(FDelMarVehicleDriftConfig, UncontrolledSpeedCap) == 0x6e0, "Offset mismatch for FDelMarVehicleDriftConfig::UncontrolledSpeedCap");
static_assert(offsetof(FDelMarVehicleDriftConfig, UncontrolledSpeedLoss) == 0x6e4, "Offset mismatch for FDelMarVehicleDriftConfig::UncontrolledSpeedLoss");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitVelocityMaxDegrees) == 0x6e8, "Offset mismatch for FDelMarVehicleDriftConfig::ExitVelocityMaxDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitKickEndMaxDegrees) == 0x6ec, "Offset mismatch for FDelMarVehicleDriftConfig::ExitKickEndMaxDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitVelocityTorqueAccel) == 0x6f0, "Offset mismatch for FDelMarVehicleDriftConfig::ExitVelocityTorqueAccel");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitVelocityMaxRotationSpeed) == 0x6f4, "Offset mismatch for FDelMarVehicleDriftConfig::ExitVelocityMaxRotationSpeed");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitForwardMaxDegrees) == 0x6f8, "Offset mismatch for FDelMarVehicleDriftConfig::ExitForwardMaxDegrees");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitForwardTorqueSteer) == 0x6fc, "Offset mismatch for FDelMarVehicleDriftConfig::ExitForwardTorqueSteer");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitForwardMaxRotation) == 0x700, "Offset mismatch for FDelMarVehicleDriftConfig::ExitForwardMaxRotation");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitForwardTargetRedirectRate) == 0x704, "Offset mismatch for FDelMarVehicleDriftConfig::ExitForwardTargetRedirectRate");
static_assert(offsetof(FDelMarVehicleDriftConfig, ExitForwardRedirectRate) == 0x708, "Offset mismatch for FDelMarVehicleDriftConfig::ExitForwardRedirectRate");
static_assert(offsetof(FDelMarVehicleDriftConfig, MaxExitForwardLandingSpeed) == 0x70c, "Offset mismatch for FDelMarVehicleDriftConfig::MaxExitForwardLandingSpeed");
static_assert(offsetof(FDelMarVehicleDriftConfig, bEnforceThrottleForControlledDrift) == 0x710, "Offset mismatch for FDelMarVehicleDriftConfig::bEnforceThrottleForControlledDrift");

// Size: 0x1d8 (Inherited: 0x0, Single: 0x1d8)
struct FDelMarVehicleDriftBoostConfig
{
    float MaxDriftBoostRatio; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeed; // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve BonusSpeedPercentageCurve; // 0x8 (Size: 0x90, Type: StructProperty)
    float WaitingPeriodSeconds; // 0x98 (Size: 0x4, Type: FloatProperty)
    float MaxDriftBoostSeconds; // 0x9c (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve PotentialDriftBoostPercentageCurve; // 0xa0 (Size: 0x90, Type: StructProperty)
    float MaxNumActiveBonusSpeedSeconds; // 0x130 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_134[0x4]; // 0x134 (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve DriftBoostDurationCurve; // 0x138 (Size: 0x90, Type: StructProperty)
    float BonusSpeedDecaySeconds; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    float PotentialRemovalRate; // 0x1cc (Size: 0x4, Type: FloatProperty)
    bool bEnforceThrottleForDriftBoost; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d1[0x3]; // 0x1d1 (Size: 0x3, Type: PaddingProperty)
    float QueuedBoostImpulseScalar; // 0x1d4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleDriftBoostConfig) == 0x1d8, "Size mismatch for FDelMarVehicleDriftBoostConfig");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, MaxDriftBoostRatio) == 0x0, "Offset mismatch for FDelMarVehicleDriftBoostConfig::MaxDriftBoostRatio");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, MaxBonusSpeed) == 0x4, "Offset mismatch for FDelMarVehicleDriftBoostConfig::MaxBonusSpeed");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, BonusSpeedPercentageCurve) == 0x8, "Offset mismatch for FDelMarVehicleDriftBoostConfig::BonusSpeedPercentageCurve");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, WaitingPeriodSeconds) == 0x98, "Offset mismatch for FDelMarVehicleDriftBoostConfig::WaitingPeriodSeconds");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, MaxDriftBoostSeconds) == 0x9c, "Offset mismatch for FDelMarVehicleDriftBoostConfig::MaxDriftBoostSeconds");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, PotentialDriftBoostPercentageCurve) == 0xa0, "Offset mismatch for FDelMarVehicleDriftBoostConfig::PotentialDriftBoostPercentageCurve");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, MaxNumActiveBonusSpeedSeconds) == 0x130, "Offset mismatch for FDelMarVehicleDriftBoostConfig::MaxNumActiveBonusSpeedSeconds");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, DriftBoostDurationCurve) == 0x138, "Offset mismatch for FDelMarVehicleDriftBoostConfig::DriftBoostDurationCurve");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, BonusSpeedDecaySeconds) == 0x1c8, "Offset mismatch for FDelMarVehicleDriftBoostConfig::BonusSpeedDecaySeconds");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, PotentialRemovalRate) == 0x1cc, "Offset mismatch for FDelMarVehicleDriftBoostConfig::PotentialRemovalRate");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, bEnforceThrottleForDriftBoost) == 0x1d0, "Offset mismatch for FDelMarVehicleDriftBoostConfig::bEnforceThrottleForDriftBoost");
static_assert(offsetof(FDelMarVehicleDriftBoostConfig, QueuedBoostImpulseScalar) == 0x1d4, "Offset mismatch for FDelMarVehicleDriftBoostConfig::QueuedBoostImpulseScalar");

// Size: 0xc8 (Inherited: 0x0, Single: 0xc8)
struct FDelMarVehicleDraftingConfig
{
    float TraceDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinEligibleDistance; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxHorizontalDegreesToDraftTarget; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxVerticalDegreesToDraftTarget; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bEnableDynamicAngle; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FDelMarScaledCurve MaxBonusSpeedPercentageCurve; // 0x18 (Size: 0x90, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> LineOfSightChannel; // 0xa8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a9[0x3]; // 0xa9 (Size: 0x3, Type: PaddingProperty)
    float MinSpeedToStartDrafting; // 0xac (Size: 0x4, Type: FloatProperty)
    float NumSecondsToActivateDrafting; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float NumForgivenessSeconds; // 0xb4 (Size: 0x4, Type: FloatProperty)
    float NumGracePeriodSeconds; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float NumSecondsToMaxBonusSpeed; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeed; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float NumSpeedRemovalSeconds; // 0xc4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleDraftingConfig) == 0xc8, "Size mismatch for FDelMarVehicleDraftingConfig");
static_assert(offsetof(FDelMarVehicleDraftingConfig, TraceDistance) == 0x0, "Offset mismatch for FDelMarVehicleDraftingConfig::TraceDistance");
static_assert(offsetof(FDelMarVehicleDraftingConfig, MinEligibleDistance) == 0x4, "Offset mismatch for FDelMarVehicleDraftingConfig::MinEligibleDistance");
static_assert(offsetof(FDelMarVehicleDraftingConfig, MaxHorizontalDegreesToDraftTarget) == 0x8, "Offset mismatch for FDelMarVehicleDraftingConfig::MaxHorizontalDegreesToDraftTarget");
static_assert(offsetof(FDelMarVehicleDraftingConfig, MaxVerticalDegreesToDraftTarget) == 0xc, "Offset mismatch for FDelMarVehicleDraftingConfig::MaxVerticalDegreesToDraftTarget");
static_assert(offsetof(FDelMarVehicleDraftingConfig, bEnableDynamicAngle) == 0x10, "Offset mismatch for FDelMarVehicleDraftingConfig::bEnableDynamicAngle");
static_assert(offsetof(FDelMarVehicleDraftingConfig, MaxBonusSpeedPercentageCurve) == 0x18, "Offset mismatch for FDelMarVehicleDraftingConfig::MaxBonusSpeedPercentageCurve");
static_assert(offsetof(FDelMarVehicleDraftingConfig, LineOfSightChannel) == 0xa8, "Offset mismatch for FDelMarVehicleDraftingConfig::LineOfSightChannel");
static_assert(offsetof(FDelMarVehicleDraftingConfig, MinSpeedToStartDrafting) == 0xac, "Offset mismatch for FDelMarVehicleDraftingConfig::MinSpeedToStartDrafting");
static_assert(offsetof(FDelMarVehicleDraftingConfig, NumSecondsToActivateDrafting) == 0xb0, "Offset mismatch for FDelMarVehicleDraftingConfig::NumSecondsToActivateDrafting");
static_assert(offsetof(FDelMarVehicleDraftingConfig, NumForgivenessSeconds) == 0xb4, "Offset mismatch for FDelMarVehicleDraftingConfig::NumForgivenessSeconds");
static_assert(offsetof(FDelMarVehicleDraftingConfig, NumGracePeriodSeconds) == 0xb8, "Offset mismatch for FDelMarVehicleDraftingConfig::NumGracePeriodSeconds");
static_assert(offsetof(FDelMarVehicleDraftingConfig, NumSecondsToMaxBonusSpeed) == 0xbc, "Offset mismatch for FDelMarVehicleDraftingConfig::NumSecondsToMaxBonusSpeed");
static_assert(offsetof(FDelMarVehicleDraftingConfig, MaxBonusSpeed) == 0xc0, "Offset mismatch for FDelMarVehicleDraftingConfig::MaxBonusSpeed");
static_assert(offsetof(FDelMarVehicleDraftingConfig, NumSpeedRemovalSeconds) == 0xc4, "Offset mismatch for FDelMarVehicleDraftingConfig::NumSpeedRemovalSeconds");

// Size: 0x138 (Inherited: 0x0, Single: 0x138)
struct FDelMarVehicleOversteerConfig
{
    float MinInput; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxAccumulatedSteer; // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve CappedAccumulatedSteerCurve; // 0x8 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve AccumulatedSteerRateCurve; // 0x98 (Size: 0x90, Type: StructProperty)
    float AccumulatedSteerDecayRate; // 0x128 (Size: 0x4, Type: FloatProperty)
    float DriftImpulseForce; // 0x12c (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x130 (Size: 0x4, Type: FloatProperty)
    bool bDecayAccumulatedSteer; // 0x134 (Size: 0x1, Type: BoolProperty)
    bool bClearAccumulatedSteerOnDrift; // 0x135 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_136[0x2]; // 0x136 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleOversteerConfig) == 0x138, "Size mismatch for FDelMarVehicleOversteerConfig");
static_assert(offsetof(FDelMarVehicleOversteerConfig, MinInput) == 0x0, "Offset mismatch for FDelMarVehicleOversteerConfig::MinInput");
static_assert(offsetof(FDelMarVehicleOversteerConfig, MaxAccumulatedSteer) == 0x4, "Offset mismatch for FDelMarVehicleOversteerConfig::MaxAccumulatedSteer");
static_assert(offsetof(FDelMarVehicleOversteerConfig, CappedAccumulatedSteerCurve) == 0x8, "Offset mismatch for FDelMarVehicleOversteerConfig::CappedAccumulatedSteerCurve");
static_assert(offsetof(FDelMarVehicleOversteerConfig, AccumulatedSteerRateCurve) == 0x98, "Offset mismatch for FDelMarVehicleOversteerConfig::AccumulatedSteerRateCurve");
static_assert(offsetof(FDelMarVehicleOversteerConfig, AccumulatedSteerDecayRate) == 0x128, "Offset mismatch for FDelMarVehicleOversteerConfig::AccumulatedSteerDecayRate");
static_assert(offsetof(FDelMarVehicleOversteerConfig, DriftImpulseForce) == 0x12c, "Offset mismatch for FDelMarVehicleOversteerConfig::DriftImpulseForce");
static_assert(offsetof(FDelMarVehicleOversteerConfig, MinSpeed) == 0x130, "Offset mismatch for FDelMarVehicleOversteerConfig::MinSpeed");
static_assert(offsetof(FDelMarVehicleOversteerConfig, bDecayAccumulatedSteer) == 0x134, "Offset mismatch for FDelMarVehicleOversteerConfig::bDecayAccumulatedSteer");
static_assert(offsetof(FDelMarVehicleOversteerConfig, bClearAccumulatedSteerOnDrift) == 0x135, "Offset mismatch for FDelMarVehicleOversteerConfig::bClearAccumulatedSteerOnDrift");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarVehicleConfig_Terrain
{
    float TargetSpeedPenaltyCooldownSeconds; // 0x0 (Size: 0x4, Type: FloatProperty)
    int32_t NumWheelsTargetSpeedPenalty; // 0x4 (Size: 0x4, Type: IntProperty)
    float NoGripBrakeFactorWithThrottle; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinForwardSpeedPercentage; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bDemolishInWater; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float MaxWaterDepth; // 0x14 (Size: 0x4, Type: FloatProperty)
    float WaterDestructionDelay; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<UClass*> NonDriveableActorClasses; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Terrain) == 0x30, "Size mismatch for FDelMarVehicleConfig_Terrain");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, TargetSpeedPenaltyCooldownSeconds) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Terrain::TargetSpeedPenaltyCooldownSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, NumWheelsTargetSpeedPenalty) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Terrain::NumWheelsTargetSpeedPenalty");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, NoGripBrakeFactorWithThrottle) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Terrain::NoGripBrakeFactorWithThrottle");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, MinForwardSpeedPercentage) == 0xc, "Offset mismatch for FDelMarVehicleConfig_Terrain::MinForwardSpeedPercentage");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, bDemolishInWater) == 0x10, "Offset mismatch for FDelMarVehicleConfig_Terrain::bDemolishInWater");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, MaxWaterDepth) == 0x14, "Offset mismatch for FDelMarVehicleConfig_Terrain::MaxWaterDepth");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, WaterDestructionDelay) == 0x18, "Offset mismatch for FDelMarVehicleConfig_Terrain::WaterDestructionDelay");
static_assert(offsetof(FDelMarVehicleConfig_Terrain, NonDriveableActorClasses) == 0x20, "Offset mismatch for FDelMarVehicleConfig_Terrain::NonDriveableActorClasses");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FDelMarVehicleTurboConfig
{
    float MaxActiveTimeSeconds; // 0x0 (Size: 0x4, Type: FloatProperty)
    float CooldownSeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
    float InitialImpulseForce; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinBaseTargetSpeed; // 0xc (Size: 0x4, Type: FloatProperty)
    FDelMarFloatModifier TargetSpeedModifier; // 0x10 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarTurboBonusZone> BonusZones; // 0x28 (Size: 0x10, Type: ArrayProperty)
    float BonusZoneImpulseForce; // 0x38 (Size: 0x4, Type: FloatProperty)
    float BonusZoneSpeedDecaySeconds; // 0x3c (Size: 0x4, Type: FloatProperty)
    float SuccessfulBonusZoneHitSeconds; // 0x40 (Size: 0x4, Type: FloatProperty)
    float ApproachingBonusZoneSeconds; // 0x44 (Size: 0x4, Type: FloatProperty)
    float MaxMissingZoneSeconds; // 0x48 (Size: 0x4, Type: FloatProperty)
    float MaxNumCharges; // 0x4c (Size: 0x4, Type: FloatProperty)
    float ChargeRegenRateSeconds; // 0x50 (Size: 0x4, Type: FloatProperty)
    float RaceStartCharges; // 0x54 (Size: 0x4, Type: FloatProperty)
    float LapCompleteCharges; // 0x58 (Size: 0x4, Type: FloatProperty)
    float TurboGainedForDriftBoostPotential; // 0x5c (Size: 0x4, Type: FloatProperty)
    float TurboGainedPerSecondAtMaxDriftPotential; // 0x60 (Size: 0x4, Type: FloatProperty)
    float MaxTurboChargesFromDrift; // 0x64 (Size: 0x4, Type: FloatProperty)
    bool bTerrainInvulnerabilityDuringTurbo; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleTurboConfig) == 0x70, "Size mismatch for FDelMarVehicleTurboConfig");
static_assert(offsetof(FDelMarVehicleTurboConfig, MaxActiveTimeSeconds) == 0x0, "Offset mismatch for FDelMarVehicleTurboConfig::MaxActiveTimeSeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, CooldownSeconds) == 0x4, "Offset mismatch for FDelMarVehicleTurboConfig::CooldownSeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, InitialImpulseForce) == 0x8, "Offset mismatch for FDelMarVehicleTurboConfig::InitialImpulseForce");
static_assert(offsetof(FDelMarVehicleTurboConfig, MinBaseTargetSpeed) == 0xc, "Offset mismatch for FDelMarVehicleTurboConfig::MinBaseTargetSpeed");
static_assert(offsetof(FDelMarVehicleTurboConfig, TargetSpeedModifier) == 0x10, "Offset mismatch for FDelMarVehicleTurboConfig::TargetSpeedModifier");
static_assert(offsetof(FDelMarVehicleTurboConfig, BonusZones) == 0x28, "Offset mismatch for FDelMarVehicleTurboConfig::BonusZones");
static_assert(offsetof(FDelMarVehicleTurboConfig, BonusZoneImpulseForce) == 0x38, "Offset mismatch for FDelMarVehicleTurboConfig::BonusZoneImpulseForce");
static_assert(offsetof(FDelMarVehicleTurboConfig, BonusZoneSpeedDecaySeconds) == 0x3c, "Offset mismatch for FDelMarVehicleTurboConfig::BonusZoneSpeedDecaySeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, SuccessfulBonusZoneHitSeconds) == 0x40, "Offset mismatch for FDelMarVehicleTurboConfig::SuccessfulBonusZoneHitSeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, ApproachingBonusZoneSeconds) == 0x44, "Offset mismatch for FDelMarVehicleTurboConfig::ApproachingBonusZoneSeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, MaxMissingZoneSeconds) == 0x48, "Offset mismatch for FDelMarVehicleTurboConfig::MaxMissingZoneSeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, MaxNumCharges) == 0x4c, "Offset mismatch for FDelMarVehicleTurboConfig::MaxNumCharges");
static_assert(offsetof(FDelMarVehicleTurboConfig, ChargeRegenRateSeconds) == 0x50, "Offset mismatch for FDelMarVehicleTurboConfig::ChargeRegenRateSeconds");
static_assert(offsetof(FDelMarVehicleTurboConfig, RaceStartCharges) == 0x54, "Offset mismatch for FDelMarVehicleTurboConfig::RaceStartCharges");
static_assert(offsetof(FDelMarVehicleTurboConfig, LapCompleteCharges) == 0x58, "Offset mismatch for FDelMarVehicleTurboConfig::LapCompleteCharges");
static_assert(offsetof(FDelMarVehicleTurboConfig, TurboGainedForDriftBoostPotential) == 0x5c, "Offset mismatch for FDelMarVehicleTurboConfig::TurboGainedForDriftBoostPotential");
static_assert(offsetof(FDelMarVehicleTurboConfig, TurboGainedPerSecondAtMaxDriftPotential) == 0x60, "Offset mismatch for FDelMarVehicleTurboConfig::TurboGainedPerSecondAtMaxDriftPotential");
static_assert(offsetof(FDelMarVehicleTurboConfig, MaxTurboChargesFromDrift) == 0x64, "Offset mismatch for FDelMarVehicleTurboConfig::MaxTurboChargesFromDrift");
static_assert(offsetof(FDelMarVehicleTurboConfig, bTerrainInvulnerabilityDuringTurbo) == 0x68, "Offset mismatch for FDelMarVehicleTurboConfig::bTerrainInvulnerabilityDuringTurbo");

// Size: 0x1b8 (Inherited: 0x0, Single: 0x1b8)
struct FDelMarVehicleConfig_Rubberbanding
{
    float MinSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeedLostPerSecond; // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve MaxBonusSpeedGainedPerSecond; // 0x8 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve MaxBonusSpeed; // 0x98 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve MaxSpeed; // 0x128 (Size: 0x90, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Rubberbanding) == 0x1b8, "Size mismatch for FDelMarVehicleConfig_Rubberbanding");
static_assert(offsetof(FDelMarVehicleConfig_Rubberbanding, MinSpeed) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Rubberbanding::MinSpeed");
static_assert(offsetof(FDelMarVehicleConfig_Rubberbanding, MaxBonusSpeedLostPerSecond) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Rubberbanding::MaxBonusSpeedLostPerSecond");
static_assert(offsetof(FDelMarVehicleConfig_Rubberbanding, MaxBonusSpeedGainedPerSecond) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Rubberbanding::MaxBonusSpeedGainedPerSecond");
static_assert(offsetof(FDelMarVehicleConfig_Rubberbanding, MaxBonusSpeed) == 0x98, "Offset mismatch for FDelMarVehicleConfig_Rubberbanding::MaxBonusSpeed");
static_assert(offsetof(FDelMarVehicleConfig_Rubberbanding, MaxSpeed) == 0x128, "Offset mismatch for FDelMarVehicleConfig_Rubberbanding::MaxSpeed");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FDelMarVehicleConfig_StartlineBoost
{
    float MaxBonusSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve PercentageMaxBonusSpeedEarned; // 0x8 (Size: 0x90, Type: StructProperty)
    float BoostGainSeconds; // 0x98 (Size: 0x4, Type: FloatProperty)
    float BoostDurationSeconds; // 0x9c (Size: 0x4, Type: FloatProperty)
    bool bEnforceForwardThrottle; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_StartlineBoost) == 0xa8, "Size mismatch for FDelMarVehicleConfig_StartlineBoost");
static_assert(offsetof(FDelMarVehicleConfig_StartlineBoost, MaxBonusSpeed) == 0x0, "Offset mismatch for FDelMarVehicleConfig_StartlineBoost::MaxBonusSpeed");
static_assert(offsetof(FDelMarVehicleConfig_StartlineBoost, PercentageMaxBonusSpeedEarned) == 0x8, "Offset mismatch for FDelMarVehicleConfig_StartlineBoost::PercentageMaxBonusSpeedEarned");
static_assert(offsetof(FDelMarVehicleConfig_StartlineBoost, BoostGainSeconds) == 0x98, "Offset mismatch for FDelMarVehicleConfig_StartlineBoost::BoostGainSeconds");
static_assert(offsetof(FDelMarVehicleConfig_StartlineBoost, BoostDurationSeconds) == 0x9c, "Offset mismatch for FDelMarVehicleConfig_StartlineBoost::BoostDurationSeconds");
static_assert(offsetof(FDelMarVehicleConfig_StartlineBoost, bEnforceForwardThrottle) == 0xa0, "Offset mismatch for FDelMarVehicleConfig_StartlineBoost::bEnforceForwardThrottle");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDelMarVehicleConfig_Strafe
{
    float InitialVelocityForce; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bVelocityRelative; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float MinSteerInput; // 0x8 (Size: 0x4, Type: FloatProperty)
    float KeybindPressLandedBufferSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxActiveSeconds; // 0x10 (Size: 0x4, Type: FloatProperty)
    float RaceStartCooldownSeconds; // 0x14 (Size: 0x4, Type: FloatProperty)
    float CooldownSeconds; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Strafe) == 0x1c, "Size mismatch for FDelMarVehicleConfig_Strafe");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, InitialVelocityForce) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Strafe::InitialVelocityForce");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, bVelocityRelative) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Strafe::bVelocityRelative");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, MinSteerInput) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Strafe::MinSteerInput");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, KeybindPressLandedBufferSeconds) == 0xc, "Offset mismatch for FDelMarVehicleConfig_Strafe::KeybindPressLandedBufferSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, MaxActiveSeconds) == 0x10, "Offset mismatch for FDelMarVehicleConfig_Strafe::MaxActiveSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, RaceStartCooldownSeconds) == 0x14, "Offset mismatch for FDelMarVehicleConfig_Strafe::RaceStartCooldownSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Strafe, CooldownSeconds) == 0x18, "Offset mismatch for FDelMarVehicleConfig_Strafe::CooldownSeconds");

// Size: 0x168 (Inherited: 0x0, Single: 0x168)
struct FDelMarVehicleConfig_Underthrust
{
    float UpwardAccel; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ForwardAccel; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxUpwardSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxForwardSpeed; // 0xc (Size: 0x4, Type: FloatProperty)
    float EndThrustForce; // 0x10 (Size: 0x4, Type: FloatProperty)
    float StartingTankPercentage; // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxThrustSeconds; // 0x18 (Size: 0x4, Type: FloatProperty)
    float ForwardSpeedCap; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedReduction; // 0x20 (Size: 0x4, Type: FloatProperty)
    float SpeedCapSecondsBuffer; // 0x24 (Size: 0x4, Type: FloatProperty)
    float MinJumpActiveSecondsBeforeActivating; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve FallingUpsideDownThrustDampeningPercentage; // 0x30 (Size: 0x90, Type: StructProperty)
    FDelMarScaledCurve PitchRatioScalarCurve; // 0xc0 (Size: 0x90, Type: StructProperty)
    bool bVehicleRelativeWithFreestyle; // 0x150 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_151[0x3]; // 0x151 (Size: 0x3, Type: PaddingProperty)
    float MinUpwardAccel; // 0x154 (Size: 0x4, Type: FloatProperty)
    float LateralRelativeAccel; // 0x158 (Size: 0x4, Type: FloatProperty)
    bool bReplenishTankOnLanding; // 0x15c (Size: 0x1, Type: BoolProperty)
    bool bReplenishTankOverTime; // 0x15d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15e[0x2]; // 0x15e (Size: 0x2, Type: PaddingProperty)
    float TankReplenishDelaySeconds; // 0x160 (Size: 0x4, Type: FloatProperty)
    float TankReplenishRatePerSecond; // 0x164 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Underthrust) == 0x168, "Size mismatch for FDelMarVehicleConfig_Underthrust");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, UpwardAccel) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Underthrust::UpwardAccel");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, ForwardAccel) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Underthrust::ForwardAccel");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, MaxUpwardSpeed) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Underthrust::MaxUpwardSpeed");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, MaxForwardSpeed) == 0xc, "Offset mismatch for FDelMarVehicleConfig_Underthrust::MaxForwardSpeed");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, EndThrustForce) == 0x10, "Offset mismatch for FDelMarVehicleConfig_Underthrust::EndThrustForce");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, StartingTankPercentage) == 0x14, "Offset mismatch for FDelMarVehicleConfig_Underthrust::StartingTankPercentage");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, MaxThrustSeconds) == 0x18, "Offset mismatch for FDelMarVehicleConfig_Underthrust::MaxThrustSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, ForwardSpeedCap) == 0x1c, "Offset mismatch for FDelMarVehicleConfig_Underthrust::ForwardSpeedCap");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, MaxSpeedReduction) == 0x20, "Offset mismatch for FDelMarVehicleConfig_Underthrust::MaxSpeedReduction");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, SpeedCapSecondsBuffer) == 0x24, "Offset mismatch for FDelMarVehicleConfig_Underthrust::SpeedCapSecondsBuffer");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, MinJumpActiveSecondsBeforeActivating) == 0x28, "Offset mismatch for FDelMarVehicleConfig_Underthrust::MinJumpActiveSecondsBeforeActivating");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, FallingUpsideDownThrustDampeningPercentage) == 0x30, "Offset mismatch for FDelMarVehicleConfig_Underthrust::FallingUpsideDownThrustDampeningPercentage");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, PitchRatioScalarCurve) == 0xc0, "Offset mismatch for FDelMarVehicleConfig_Underthrust::PitchRatioScalarCurve");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, bVehicleRelativeWithFreestyle) == 0x150, "Offset mismatch for FDelMarVehicleConfig_Underthrust::bVehicleRelativeWithFreestyle");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, MinUpwardAccel) == 0x154, "Offset mismatch for FDelMarVehicleConfig_Underthrust::MinUpwardAccel");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, LateralRelativeAccel) == 0x158, "Offset mismatch for FDelMarVehicleConfig_Underthrust::LateralRelativeAccel");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, bReplenishTankOnLanding) == 0x15c, "Offset mismatch for FDelMarVehicleConfig_Underthrust::bReplenishTankOnLanding");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, bReplenishTankOverTime) == 0x15d, "Offset mismatch for FDelMarVehicleConfig_Underthrust::bReplenishTankOverTime");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, TankReplenishDelaySeconds) == 0x160, "Offset mismatch for FDelMarVehicleConfig_Underthrust::TankReplenishDelaySeconds");
static_assert(offsetof(FDelMarVehicleConfig_Underthrust, TankReplenishRatePerSecond) == 0x164, "Offset mismatch for FDelMarVehicleConfig_Underthrust::TankReplenishRatePerSecond");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FDelMarVehicleConfig_AirControl
{
    float MaxPitchAdjustmentForwardSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve LateralTurnRateCurve; // 0x8 (Size: 0x90, Type: StructProperty)
    float UnderthrustTurnRate; // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bAllowRedirectDuringKickflip; // 0x9c (Size: 0x1, Type: BoolProperty)
    bool bAllowVerticalRedirectDuringVerticalKickflip; // 0x9d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9e[0x2]; // 0x9e (Size: 0x2, Type: PaddingProperty)
    float LateralKickflipScalar; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float VerticalTurnRate; // 0xa4 (Size: 0x4, Type: FloatProperty)
    float VerticalTurnRateAboveHorizon; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float MinSteerInput; // 0xac (Size: 0x4, Type: FloatProperty)
    float MinPitchVerticalDegreesFromWorldDown; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float MaxPitchVerticalDegreesFromWorldDown; // 0xb4 (Size: 0x4, Type: FloatProperty)
    bool bAerialDivingBonusEnabled; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    float MinPitchForAerialDivingBonus; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxAerialDivingBonusSpeed; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MinAerialDivingBonusSpeed; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float AerialDivingBonusSpeedChangeRate; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float AerialDivingBonusSpeedDecayRate; // 0xcc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_AirControl) == 0xd0, "Size mismatch for FDelMarVehicleConfig_AirControl");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MaxPitchAdjustmentForwardSpeed) == 0x0, "Offset mismatch for FDelMarVehicleConfig_AirControl::MaxPitchAdjustmentForwardSpeed");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, LateralTurnRateCurve) == 0x8, "Offset mismatch for FDelMarVehicleConfig_AirControl::LateralTurnRateCurve");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, UnderthrustTurnRate) == 0x98, "Offset mismatch for FDelMarVehicleConfig_AirControl::UnderthrustTurnRate");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, bAllowRedirectDuringKickflip) == 0x9c, "Offset mismatch for FDelMarVehicleConfig_AirControl::bAllowRedirectDuringKickflip");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, bAllowVerticalRedirectDuringVerticalKickflip) == 0x9d, "Offset mismatch for FDelMarVehicleConfig_AirControl::bAllowVerticalRedirectDuringVerticalKickflip");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, LateralKickflipScalar) == 0xa0, "Offset mismatch for FDelMarVehicleConfig_AirControl::LateralKickflipScalar");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, VerticalTurnRate) == 0xa4, "Offset mismatch for FDelMarVehicleConfig_AirControl::VerticalTurnRate");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, VerticalTurnRateAboveHorizon) == 0xa8, "Offset mismatch for FDelMarVehicleConfig_AirControl::VerticalTurnRateAboveHorizon");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MinSteerInput) == 0xac, "Offset mismatch for FDelMarVehicleConfig_AirControl::MinSteerInput");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MinPitchVerticalDegreesFromWorldDown) == 0xb0, "Offset mismatch for FDelMarVehicleConfig_AirControl::MinPitchVerticalDegreesFromWorldDown");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MaxPitchVerticalDegreesFromWorldDown) == 0xb4, "Offset mismatch for FDelMarVehicleConfig_AirControl::MaxPitchVerticalDegreesFromWorldDown");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, bAerialDivingBonusEnabled) == 0xb8, "Offset mismatch for FDelMarVehicleConfig_AirControl::bAerialDivingBonusEnabled");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MinPitchForAerialDivingBonus) == 0xbc, "Offset mismatch for FDelMarVehicleConfig_AirControl::MinPitchForAerialDivingBonus");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MaxAerialDivingBonusSpeed) == 0xc0, "Offset mismatch for FDelMarVehicleConfig_AirControl::MaxAerialDivingBonusSpeed");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, MinAerialDivingBonusSpeed) == 0xc4, "Offset mismatch for FDelMarVehicleConfig_AirControl::MinAerialDivingBonusSpeed");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, AerialDivingBonusSpeedChangeRate) == 0xc8, "Offset mismatch for FDelMarVehicleConfig_AirControl::AerialDivingBonusSpeedChangeRate");
static_assert(offsetof(FDelMarVehicleConfig_AirControl, AerialDivingBonusSpeedDecayRate) == 0xcc, "Offset mismatch for FDelMarVehicleConfig_AirControl::AerialDivingBonusSpeedDecayRate");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarVehicleConfig_AirFreestyle
{
    FVector TorqueAccel; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector TorqueDamping; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_AirFreestyle) == 0x30, "Size mismatch for FDelMarVehicleConfig_AirFreestyle");
static_assert(offsetof(FDelMarVehicleConfig_AirFreestyle, TorqueAccel) == 0x0, "Offset mismatch for FDelMarVehicleConfig_AirFreestyle::TorqueAccel");
static_assert(offsetof(FDelMarVehicleConfig_AirFreestyle, TorqueDamping) == 0x18, "Offset mismatch for FDelMarVehicleConfig_AirFreestyle::TorqueDamping");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FDelMarVehicleConfig_AirThrottle
{
    FDelMarScaledCurve AccelerationScalarCurve; // 0x0 (Size: 0x90, Type: StructProperty)
    float AerialSpeedCap; // 0x90 (Size: 0x4, Type: FloatProperty)
    float OverCapSpeedLossPerSecond; // 0x94 (Size: 0x4, Type: FloatProperty)
    float AerialSlowdownImmunitySeconds; // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bApplyNoThrottleSlowdown; // 0x9c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9d[0x3]; // 0x9d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_AirThrottle) == 0xa0, "Size mismatch for FDelMarVehicleConfig_AirThrottle");
static_assert(offsetof(FDelMarVehicleConfig_AirThrottle, AccelerationScalarCurve) == 0x0, "Offset mismatch for FDelMarVehicleConfig_AirThrottle::AccelerationScalarCurve");
static_assert(offsetof(FDelMarVehicleConfig_AirThrottle, AerialSpeedCap) == 0x90, "Offset mismatch for FDelMarVehicleConfig_AirThrottle::AerialSpeedCap");
static_assert(offsetof(FDelMarVehicleConfig_AirThrottle, OverCapSpeedLossPerSecond) == 0x94, "Offset mismatch for FDelMarVehicleConfig_AirThrottle::OverCapSpeedLossPerSecond");
static_assert(offsetof(FDelMarVehicleConfig_AirThrottle, AerialSlowdownImmunitySeconds) == 0x98, "Offset mismatch for FDelMarVehicleConfig_AirThrottle::AerialSlowdownImmunitySeconds");
static_assert(offsetof(FDelMarVehicleConfig_AirThrottle, bApplyNoThrottleSlowdown) == 0x9c, "Offset mismatch for FDelMarVehicleConfig_AirThrottle::bApplyNoThrottleSlowdown");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FDelMarVehicleConfig_AutoAerialRotation
{
    FVector StabilizationDampingFactor; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector StabilizationFactor; // 0x18 (Size: 0x18, Type: StructProperty)
    float MaxUpsideDownDegreesForForcedRoll; // 0x30 (Size: 0x4, Type: FloatProperty)
    float IdleRotationThreshold; // 0x34 (Size: 0x4, Type: FloatProperty)
    float UpsideDownRollTorque; // 0x38 (Size: 0x4, Type: FloatProperty)
    float UpsideDownRollDamping; // 0x3c (Size: 0x4, Type: FloatProperty)
    float MinRollInput; // 0x40 (Size: 0x4, Type: FloatProperty)
    float SteerRollOffsetDegrees; // 0x44 (Size: 0x4, Type: FloatProperty)
    float MinPitchInput; // 0x48 (Size: 0x4, Type: FloatProperty)
    float MaxUserPitchOffsetDegrees; // 0x4c (Size: 0x4, Type: FloatProperty)
    float LateralPitchOffsetDegrees; // 0x50 (Size: 0x4, Type: FloatProperty)
    float UnderthrustPitchDegrees; // 0x54 (Size: 0x4, Type: FloatProperty)
    float MinThrottleInput; // 0x58 (Size: 0x4, Type: FloatProperty)
    float MaxUserThrottleOffsetDegrees; // 0x5c (Size: 0x4, Type: FloatProperty)
    float YawTorque; // 0x60 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    FVector MaxRotationSpeed; // 0x68 (Size: 0x18, Type: StructProperty)
    float MinApproachTargetScalar; // 0x80 (Size: 0x4, Type: FloatProperty)
    float MinForwardSpeedForYawRotation; // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinSteerInputForForwardStateTurning; // 0x88 (Size: 0x4, Type: FloatProperty)
    float ForwardStateTurnRate; // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bLandingAssistanceEnabled; // 0x90 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ECollisionChannel> LandingCollisionChannel; // 0x91 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_92[0x2]; // 0x92 (Size: 0x2, Type: PaddingProperty)
    float LandingDetectionSeconds; // 0x94 (Size: 0x4, Type: FloatProperty)
    float MinLandingDetectionDistance; // 0x98 (Size: 0x4, Type: FloatProperty)
    float LandingSurfaceNormalMaxDegrees; // 0x9c (Size: 0x4, Type: FloatProperty)
    float LandingRotationAmplifier; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_AutoAerialRotation) == 0xa8, "Size mismatch for FDelMarVehicleConfig_AutoAerialRotation");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, StabilizationDampingFactor) == 0x0, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::StabilizationDampingFactor");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, StabilizationFactor) == 0x18, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::StabilizationFactor");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MaxUpsideDownDegreesForForcedRoll) == 0x30, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MaxUpsideDownDegreesForForcedRoll");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, IdleRotationThreshold) == 0x34, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::IdleRotationThreshold");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, UpsideDownRollTorque) == 0x38, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::UpsideDownRollTorque");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, UpsideDownRollDamping) == 0x3c, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::UpsideDownRollDamping");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinRollInput) == 0x40, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinRollInput");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, SteerRollOffsetDegrees) == 0x44, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::SteerRollOffsetDegrees");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinPitchInput) == 0x48, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinPitchInput");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MaxUserPitchOffsetDegrees) == 0x4c, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MaxUserPitchOffsetDegrees");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, LateralPitchOffsetDegrees) == 0x50, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::LateralPitchOffsetDegrees");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, UnderthrustPitchDegrees) == 0x54, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::UnderthrustPitchDegrees");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinThrottleInput) == 0x58, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinThrottleInput");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MaxUserThrottleOffsetDegrees) == 0x5c, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MaxUserThrottleOffsetDegrees");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, YawTorque) == 0x60, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::YawTorque");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MaxRotationSpeed) == 0x68, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MaxRotationSpeed");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinApproachTargetScalar) == 0x80, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinApproachTargetScalar");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinForwardSpeedForYawRotation) == 0x84, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinForwardSpeedForYawRotation");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinSteerInputForForwardStateTurning) == 0x88, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinSteerInputForForwardStateTurning");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, ForwardStateTurnRate) == 0x8c, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::ForwardStateTurnRate");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, bLandingAssistanceEnabled) == 0x90, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::bLandingAssistanceEnabled");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, LandingCollisionChannel) == 0x91, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::LandingCollisionChannel");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, LandingDetectionSeconds) == 0x94, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::LandingDetectionSeconds");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, MinLandingDetectionDistance) == 0x98, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::MinLandingDetectionDistance");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, LandingSurfaceNormalMaxDegrees) == 0x9c, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::LandingSurfaceNormalMaxDegrees");
static_assert(offsetof(FDelMarVehicleConfig_AutoAerialRotation, LandingRotationAmplifier) == 0xa0, "Offset mismatch for FDelMarVehicleConfig_AutoAerialRotation::LandingRotationAmplifier");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FDelMarVehicleConfig_AutoUpright
{
    float RotationTorque; // 0x0 (Size: 0x4, Type: FloatProperty)
    float RotationDamping; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinActiveSeconds; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinActiveSecondsGrounded; // 0xc (Size: 0x4, Type: FloatProperty)
    float WheelsOnGroundChangedDelaySeconds; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bClearAngularVelocity; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    float MinDegreesFromVehicleUpThreshold; // 0x18 (Size: 0x4, Type: FloatProperty)
    float MinThrottleForWheelRotation; // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bAllowActiveStateOnGround; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_AutoUpright) == 0x24, "Size mismatch for FDelMarVehicleConfig_AutoUpright");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, RotationTorque) == 0x0, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::RotationTorque");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, RotationDamping) == 0x4, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::RotationDamping");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, MinActiveSeconds) == 0x8, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::MinActiveSeconds");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, MinActiveSecondsGrounded) == 0xc, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::MinActiveSecondsGrounded");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, WheelsOnGroundChangedDelaySeconds) == 0x10, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::WheelsOnGroundChangedDelaySeconds");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, bClearAngularVelocity) == 0x14, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::bClearAngularVelocity");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, MinDegreesFromVehicleUpThreshold) == 0x18, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::MinDegreesFromVehicleUpThreshold");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, MinThrottleForWheelRotation) == 0x1c, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::MinThrottleForWheelRotation");
static_assert(offsetof(FDelMarVehicleConfig_AutoUpright, bAllowActiveStateOnGround) == 0x20, "Offset mismatch for FDelMarVehicleConfig_AutoUpright::bAllowActiveStateOnGround");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarVehicleConfig_Jump
{
    float MinJumpTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxJumpTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float JumpVelocity; // 0x8 (Size: 0x4, Type: FloatProperty)
    float ForwardVelocity; // 0xc (Size: 0x4, Type: FloatProperty)
    float PitchTorque; // 0x10 (Size: 0x4, Type: FloatProperty)
    float EndThrustForce; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Jump) == 0x18, "Size mismatch for FDelMarVehicleConfig_Jump");
static_assert(offsetof(FDelMarVehicleConfig_Jump, MinJumpTime) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Jump::MinJumpTime");
static_assert(offsetof(FDelMarVehicleConfig_Jump, MaxJumpTime) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Jump::MaxJumpTime");
static_assert(offsetof(FDelMarVehicleConfig_Jump, JumpVelocity) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Jump::JumpVelocity");
static_assert(offsetof(FDelMarVehicleConfig_Jump, ForwardVelocity) == 0xc, "Offset mismatch for FDelMarVehicleConfig_Jump::ForwardVelocity");
static_assert(offsetof(FDelMarVehicleConfig_Jump, PitchTorque) == 0x10, "Offset mismatch for FDelMarVehicleConfig_Jump::PitchTorque");
static_assert(offsetof(FDelMarVehicleConfig_Jump, EndThrustForce) == 0x14, "Offset mismatch for FDelMarVehicleConfig_Jump::EndThrustForce");

// Size: 0x158 (Inherited: 0x0, Single: 0x158)
struct FDelMarVehicleConfig_Kickflip
{
    float DirectionalSensitivity; // 0x0 (Size: 0x4, Type: FloatProperty)
    float SecondaryDirectionalSensitivity; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bAllowDiagonalKickDirection; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    int32_t NumWheelsForLanding; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t NumActivationCharges; // 0x10 (Size: 0x4, Type: IntProperty)
    bool bResetChargesOnLanding; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    float MinActiveSecondsToReactivate; // 0x18 (Size: 0x4, Type: FloatProperty)
    float MinActiveTime; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MaxActiveLateralTime; // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxActiveUpwardTime; // 0x24 (Size: 0x4, Type: FloatProperty)
    float MaxActiveDownwardTime; // 0x28 (Size: 0x4, Type: FloatProperty)
    float CooldownSeconds; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bAllowGroundedKickflips; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float GroundedKickflipForce; // 0x34 (Size: 0x4, Type: FloatProperty)
    float LateralVelocity; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FDelMarScaledCurve LateralVelocityScalarCurve; // 0x40 (Size: 0x90, Type: StructProperty)
    float MinForwardSpeedForLateralScalar; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float MaxLateralVelocityCancelled; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float UpwardVerticalVelocity; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float DownwardVerticalVelocity; // 0xdc (Size: 0x4, Type: FloatProperty)
    float LateralVerticalForce; // 0xe0 (Size: 0x4, Type: FloatProperty)
    float RotationDamping; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float RotationTorque; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float RotationTorqueIncomingCollision; // 0xec (Size: 0x4, Type: FloatProperty)
    float MinSpeedToRotateYaw; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float MaxVerticalYawLandingDegrees; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float MaxLateralYawLandingDegrees; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float MaxVerticalNormalLandingDegrees; // 0xfc (Size: 0x4, Type: FloatProperty)
    float MaxLateralNormalLandingDegrees; // 0x100 (Size: 0x4, Type: FloatProperty)
    float MinLongRollTimeCheck; // 0x104 (Size: 0x4, Type: FloatProperty)
    float MinLongRollTimeCheckDownwardKick; // 0x108 (Size: 0x4, Type: FloatProperty)
    float MaxLongRollDegrees; // 0x10c (Size: 0x4, Type: FloatProperty)
    float MinDegreesToCompleteRoll; // 0x110 (Size: 0x4, Type: FloatProperty)
    float FastTorqueDistanceCheck; // 0x114 (Size: 0x4, Type: FloatProperty)
    bool bUseStartingDirectionWhenLanding; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x3]; // 0x119 (Size: 0x3, Type: PaddingProperty)
    int32_t PredictionTickInterval; // 0x11c (Size: 0x4, Type: IntProperty)
    float MaxSimulationRedirectSeconds; // 0x120 (Size: 0x4, Type: FloatProperty)
    float MaxSimulationDistanceLateral; // 0x124 (Size: 0x4, Type: FloatProperty)
    float MaxSimulationDistanceUpward; // 0x128 (Size: 0x4, Type: FloatProperty)
    float MaxSimulationDistanceDownward; // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bApplySuctionToSurfaces; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0x3]; // 0x131 (Size: 0x3, Type: PaddingProperty)
    float SuctionVelocity; // 0x134 (Size: 0x4, Type: FloatProperty)
    float MaxSuctionPerSecond; // 0x138 (Size: 0x4, Type: FloatProperty)
    float SuctionDistanceCheck; // 0x13c (Size: 0x4, Type: FloatProperty)
    float MaxAdditionalVelocitySuctionDistance; // 0x140 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> SuctionChannel; // 0x144 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_145[0x3]; // 0x145 (Size: 0x3, Type: PaddingProperty)
    float MaxForwardVelocityDegreeDifference; // 0x148 (Size: 0x4, Type: FloatProperty)
    float MinSpeedForPrimaryForwardRotation; // 0x14c (Size: 0x4, Type: FloatProperty)
    float MaxGroundedDirectionDegrees; // 0x150 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_154[0x4]; // 0x154 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Kickflip) == 0x158, "Size mismatch for FDelMarVehicleConfig_Kickflip");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, DirectionalSensitivity) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Kickflip::DirectionalSensitivity");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, SecondaryDirectionalSensitivity) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Kickflip::SecondaryDirectionalSensitivity");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, bAllowDiagonalKickDirection) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Kickflip::bAllowDiagonalKickDirection");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, NumWheelsForLanding) == 0xc, "Offset mismatch for FDelMarVehicleConfig_Kickflip::NumWheelsForLanding");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, NumActivationCharges) == 0x10, "Offset mismatch for FDelMarVehicleConfig_Kickflip::NumActivationCharges");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, bResetChargesOnLanding) == 0x14, "Offset mismatch for FDelMarVehicleConfig_Kickflip::bResetChargesOnLanding");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinActiveSecondsToReactivate) == 0x18, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinActiveSecondsToReactivate");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinActiveTime) == 0x1c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinActiveTime");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxActiveLateralTime) == 0x20, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxActiveLateralTime");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxActiveUpwardTime) == 0x24, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxActiveUpwardTime");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxActiveDownwardTime) == 0x28, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxActiveDownwardTime");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, CooldownSeconds) == 0x2c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::CooldownSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, bAllowGroundedKickflips) == 0x30, "Offset mismatch for FDelMarVehicleConfig_Kickflip::bAllowGroundedKickflips");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, GroundedKickflipForce) == 0x34, "Offset mismatch for FDelMarVehicleConfig_Kickflip::GroundedKickflipForce");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, LateralVelocity) == 0x38, "Offset mismatch for FDelMarVehicleConfig_Kickflip::LateralVelocity");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, LateralVelocityScalarCurve) == 0x40, "Offset mismatch for FDelMarVehicleConfig_Kickflip::LateralVelocityScalarCurve");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinForwardSpeedForLateralScalar) == 0xd0, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinForwardSpeedForLateralScalar");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxLateralVelocityCancelled) == 0xd4, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxLateralVelocityCancelled");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, UpwardVerticalVelocity) == 0xd8, "Offset mismatch for FDelMarVehicleConfig_Kickflip::UpwardVerticalVelocity");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, DownwardVerticalVelocity) == 0xdc, "Offset mismatch for FDelMarVehicleConfig_Kickflip::DownwardVerticalVelocity");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, LateralVerticalForce) == 0xe0, "Offset mismatch for FDelMarVehicleConfig_Kickflip::LateralVerticalForce");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, RotationDamping) == 0xe4, "Offset mismatch for FDelMarVehicleConfig_Kickflip::RotationDamping");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, RotationTorque) == 0xe8, "Offset mismatch for FDelMarVehicleConfig_Kickflip::RotationTorque");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, RotationTorqueIncomingCollision) == 0xec, "Offset mismatch for FDelMarVehicleConfig_Kickflip::RotationTorqueIncomingCollision");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinSpeedToRotateYaw) == 0xf0, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinSpeedToRotateYaw");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxVerticalYawLandingDegrees) == 0xf4, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxVerticalYawLandingDegrees");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxLateralYawLandingDegrees) == 0xf8, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxLateralYawLandingDegrees");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxVerticalNormalLandingDegrees) == 0xfc, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxVerticalNormalLandingDegrees");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxLateralNormalLandingDegrees) == 0x100, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxLateralNormalLandingDegrees");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinLongRollTimeCheck) == 0x104, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinLongRollTimeCheck");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinLongRollTimeCheckDownwardKick) == 0x108, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinLongRollTimeCheckDownwardKick");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxLongRollDegrees) == 0x10c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxLongRollDegrees");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinDegreesToCompleteRoll) == 0x110, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinDegreesToCompleteRoll");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, FastTorqueDistanceCheck) == 0x114, "Offset mismatch for FDelMarVehicleConfig_Kickflip::FastTorqueDistanceCheck");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, bUseStartingDirectionWhenLanding) == 0x118, "Offset mismatch for FDelMarVehicleConfig_Kickflip::bUseStartingDirectionWhenLanding");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, PredictionTickInterval) == 0x11c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::PredictionTickInterval");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxSimulationRedirectSeconds) == 0x120, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxSimulationRedirectSeconds");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxSimulationDistanceLateral) == 0x124, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxSimulationDistanceLateral");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxSimulationDistanceUpward) == 0x128, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxSimulationDistanceUpward");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxSimulationDistanceDownward) == 0x12c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxSimulationDistanceDownward");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, bApplySuctionToSurfaces) == 0x130, "Offset mismatch for FDelMarVehicleConfig_Kickflip::bApplySuctionToSurfaces");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, SuctionVelocity) == 0x134, "Offset mismatch for FDelMarVehicleConfig_Kickflip::SuctionVelocity");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxSuctionPerSecond) == 0x138, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxSuctionPerSecond");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, SuctionDistanceCheck) == 0x13c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::SuctionDistanceCheck");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxAdditionalVelocitySuctionDistance) == 0x140, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxAdditionalVelocitySuctionDistance");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, SuctionChannel) == 0x144, "Offset mismatch for FDelMarVehicleConfig_Kickflip::SuctionChannel");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxForwardVelocityDegreeDifference) == 0x148, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxForwardVelocityDegreeDifference");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MinSpeedForPrimaryForwardRotation) == 0x14c, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MinSpeedForPrimaryForwardRotation");
static_assert(offsetof(FDelMarVehicleConfig_Kickflip, MaxGroundedDirectionDegrees) == 0x150, "Offset mismatch for FDelMarVehicleConfig_Kickflip::MaxGroundedDirectionDegrees");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarVehicleConfig_Gravity
{
    float ForceScaleCeiling; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ForceScaleWall; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ForceScaleGround; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AerialGravityForceMultiplier; // 0xc (Size: 0x4, Type: FloatProperty)
    float CoyoteTimeDuration; // 0x10 (Size: 0x4, Type: FloatProperty)
    int32_t MinWheelsForCounterGravityMeasures; // 0x14 (Size: 0x4, Type: IntProperty)
    float MaxCounterGravitySpringVarianceDegrees; // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bCounterGravityInKickflipSuctionDirection; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Gravity) == 0x20, "Size mismatch for FDelMarVehicleConfig_Gravity");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, ForceScaleCeiling) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Gravity::ForceScaleCeiling");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, ForceScaleWall) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Gravity::ForceScaleWall");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, ForceScaleGround) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Gravity::ForceScaleGround");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, AerialGravityForceMultiplier) == 0xc, "Offset mismatch for FDelMarVehicleConfig_Gravity::AerialGravityForceMultiplier");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, CoyoteTimeDuration) == 0x10, "Offset mismatch for FDelMarVehicleConfig_Gravity::CoyoteTimeDuration");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, MinWheelsForCounterGravityMeasures) == 0x14, "Offset mismatch for FDelMarVehicleConfig_Gravity::MinWheelsForCounterGravityMeasures");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, MaxCounterGravitySpringVarianceDegrees) == 0x18, "Offset mismatch for FDelMarVehicleConfig_Gravity::MaxCounterGravitySpringVarianceDegrees");
static_assert(offsetof(FDelMarVehicleConfig_Gravity, bCounterGravityInKickflipSuctionDirection) == 0x1c, "Offset mismatch for FDelMarVehicleConfig_Gravity::bCounterGravityInKickflipSuctionDirection");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FDelMarVehicleConfig_Reattachment
{
    float SurfaceTraceDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ReattachmentForceAmount; // 0x4 (Size: 0x4, Type: FloatProperty)
    FDelMarScaledCurve ReattachmentForceScalarCurve; // 0x8 (Size: 0x90, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> ReattachmentChannel; // 0x98 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_Reattachment) == 0xa0, "Size mismatch for FDelMarVehicleConfig_Reattachment");
static_assert(offsetof(FDelMarVehicleConfig_Reattachment, SurfaceTraceDistance) == 0x0, "Offset mismatch for FDelMarVehicleConfig_Reattachment::SurfaceTraceDistance");
static_assert(offsetof(FDelMarVehicleConfig_Reattachment, ReattachmentForceAmount) == 0x4, "Offset mismatch for FDelMarVehicleConfig_Reattachment::ReattachmentForceAmount");
static_assert(offsetof(FDelMarVehicleConfig_Reattachment, ReattachmentForceScalarCurve) == 0x8, "Offset mismatch for FDelMarVehicleConfig_Reattachment::ReattachmentForceScalarCurve");
static_assert(offsetof(FDelMarVehicleConfig_Reattachment, ReattachmentChannel) == 0x98, "Offset mismatch for FDelMarVehicleConfig_Reattachment::ReattachmentChannel");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarVehicleConfig_WorldBonusSpeed
{
    TArray<FDelMarWorldBonusSpeedSourceCap> BonusSpeedSourceCaps; // 0x0 (Size: 0x10, Type: ArrayProperty)
    float MaxBonusSpeedPerStack; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxStackDuration; // 0x14 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> WorldBonusSpeedActors; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_WorldBonusSpeed) == 0x28, "Size mismatch for FDelMarVehicleConfig_WorldBonusSpeed");
static_assert(offsetof(FDelMarVehicleConfig_WorldBonusSpeed, BonusSpeedSourceCaps) == 0x0, "Offset mismatch for FDelMarVehicleConfig_WorldBonusSpeed::BonusSpeedSourceCaps");
static_assert(offsetof(FDelMarVehicleConfig_WorldBonusSpeed, MaxBonusSpeedPerStack) == 0x10, "Offset mismatch for FDelMarVehicleConfig_WorldBonusSpeed::MaxBonusSpeedPerStack");
static_assert(offsetof(FDelMarVehicleConfig_WorldBonusSpeed, MaxStackDuration) == 0x14, "Offset mismatch for FDelMarVehicleConfig_WorldBonusSpeed::MaxStackDuration");
static_assert(offsetof(FDelMarVehicleConfig_WorldBonusSpeed, WorldBonusSpeedActors) == 0x18, "Offset mismatch for FDelMarVehicleConfig_WorldBonusSpeed::WorldBonusSpeedActors");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleConfig_SelfDemolish
{
    bool bSelfDemolishEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float RequiredDemolishActionDuration; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfig_SelfDemolish) == 0x8, "Size mismatch for FDelMarVehicleConfig_SelfDemolish");
static_assert(offsetof(FDelMarVehicleConfig_SelfDemolish, bSelfDemolishEnabled) == 0x0, "Offset mismatch for FDelMarVehicleConfig_SelfDemolish::bSelfDemolishEnabled");
static_assert(offsetof(FDelMarVehicleConfig_SelfDemolish, RequiredDemolishActionDuration) == 0x4, "Offset mismatch for FDelMarVehicleConfig_SelfDemolish::RequiredDemolishActionDuration");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDelMarVehicleConfigOverride_AutoUpright
{
    float MaxWorldContactDegreeThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_AutoUpright) == 0x4, "Size mismatch for FDelMarVehicleConfigOverride_AutoUpright");
static_assert(offsetof(FDelMarVehicleConfigOverride_AutoUpright, MaxWorldContactDegreeThreshold) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_AutoUpright::MaxWorldContactDegreeThreshold");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleConfigOverride_Collision
{
    bool bCollisionDemosEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWallRicochetEnabled; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bNonTrackVelocityRedirectEnabled; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float DemoSpeedScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Collision) == 0x8, "Size mismatch for FDelMarVehicleConfigOverride_Collision");
static_assert(offsetof(FDelMarVehicleConfigOverride_Collision, bCollisionDemosEnabled) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Collision::bCollisionDemosEnabled");
static_assert(offsetof(FDelMarVehicleConfigOverride_Collision, bWallRicochetEnabled) == 0x1, "Offset mismatch for FDelMarVehicleConfigOverride_Collision::bWallRicochetEnabled");
static_assert(offsetof(FDelMarVehicleConfigOverride_Collision, bNonTrackVelocityRedirectEnabled) == 0x2, "Offset mismatch for FDelMarVehicleConfigOverride_Collision::bNonTrackVelocityRedirectEnabled");
static_assert(offsetof(FDelMarVehicleConfigOverride_Collision, DemoSpeedScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Collision::DemoSpeedScalar");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarVehicleConfigOverride_Drift
{
    float SpeedCapScalar; // 0x0 (Size: 0x4, Type: FloatProperty)
    float AccelerationRateScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
    float DecelerationRateScalar; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Drift) == 0xc, "Size mismatch for FDelMarVehicleConfigOverride_Drift");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drift, SpeedCapScalar) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Drift::SpeedCapScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drift, AccelerationRateScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Drift::AccelerationRateScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drift, DecelerationRateScalar) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverride_Drift::DecelerationRateScalar");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarVehicleConfigOverride_DriftBoost
{
    float MaxBonusSpeedScalar; // 0x0 (Size: 0x4, Type: FloatProperty)
    float DurationScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
    float PotentialRateScalar; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_DriftBoost) == 0xc, "Size mismatch for FDelMarVehicleConfigOverride_DriftBoost");
static_assert(offsetof(FDelMarVehicleConfigOverride_DriftBoost, MaxBonusSpeedScalar) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_DriftBoost::MaxBonusSpeedScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_DriftBoost, DurationScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_DriftBoost::DurationScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_DriftBoost, PotentialRateScalar) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverride_DriftBoost::PotentialRateScalar");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FDelMarVehicleConfigOverride_Drive
{
    float MaxBaseForwardSpeedScalar; // 0x0 (Size: 0x4, Type: FloatProperty)
    float AccelerationScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
    float DecelerationScalar; // 0x8 (Size: 0x4, Type: FloatProperty)
    float BrakeScalar; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxAerialSpeedScalar; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Drive) == 0x14, "Size mismatch for FDelMarVehicleConfigOverride_Drive");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drive, MaxBaseForwardSpeedScalar) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Drive::MaxBaseForwardSpeedScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drive, AccelerationScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Drive::AccelerationScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drive, DecelerationScalar) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverride_Drive::DecelerationScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drive, BrakeScalar) == 0xc, "Offset mismatch for FDelMarVehicleConfigOverride_Drive::BrakeScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Drive, MaxAerialSpeedScalar) == 0x10, "Offset mismatch for FDelMarVehicleConfigOverride_Drive::MaxAerialSpeedScalar");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleConfigOverride_Gravity
{
    float CounterGravityContactDegreeThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
    float AerialGravityScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Gravity) == 0x8, "Size mismatch for FDelMarVehicleConfigOverride_Gravity");
static_assert(offsetof(FDelMarVehicleConfigOverride_Gravity, CounterGravityContactDegreeThreshold) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Gravity::CounterGravityContactDegreeThreshold");
static_assert(offsetof(FDelMarVehicleConfigOverride_Gravity, AerialGravityScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Gravity::AerialGravityScalar");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDelMarVehicleConfigOverride_Jump
{
    float JumpImpulseScalar; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Jump) == 0x4, "Size mismatch for FDelMarVehicleConfigOverride_Jump");
static_assert(offsetof(FDelMarVehicleConfigOverride_Jump, JumpImpulseScalar) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Jump::JumpImpulseScalar");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarVehicleConfigOverride_Kickflip
{
    bool bResetChargesOnLanding; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t NumActivationCharges; // 0x4 (Size: 0x4, Type: IntProperty)
    float CooldownSeconds; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Kickflip) == 0xc, "Size mismatch for FDelMarVehicleConfigOverride_Kickflip");
static_assert(offsetof(FDelMarVehicleConfigOverride_Kickflip, bResetChargesOnLanding) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Kickflip::bResetChargesOnLanding");
static_assert(offsetof(FDelMarVehicleConfigOverride_Kickflip, NumActivationCharges) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Kickflip::NumActivationCharges");
static_assert(offsetof(FDelMarVehicleConfigOverride_Kickflip, CooldownSeconds) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverride_Kickflip::CooldownSeconds");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleConfigOverride_Oversteer
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float AccumulatedSteerThresholdScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Oversteer) == 0x8, "Size mismatch for FDelMarVehicleConfigOverride_Oversteer");
static_assert(offsetof(FDelMarVehicleConfigOverride_Oversteer, bEnabled) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Oversteer::bEnabled");
static_assert(offsetof(FDelMarVehicleConfigOverride_Oversteer, AccumulatedSteerThresholdScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Oversteer::AccumulatedSteerThresholdScalar");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleConfigOverride_Terrain
{
    bool bDemolishInWater; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float WaterDestructionDelay; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Terrain) == 0x8, "Size mismatch for FDelMarVehicleConfigOverride_Terrain");
static_assert(offsetof(FDelMarVehicleConfigOverride_Terrain, bDemolishInWater) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Terrain::bDemolishInWater");
static_assert(offsetof(FDelMarVehicleConfigOverride_Terrain, WaterDestructionDelay) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Terrain::WaterDestructionDelay");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarVehicleConfigOverride_Turbo
{
    float StartingVehicleCharges; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ChargeRegenRateScalar; // 0x4 (Size: 0x4, Type: FloatProperty)
    float DriftBoostTurboGenerationScalar; // 0x8 (Size: 0x4, Type: FloatProperty)
    float TurboSpeedScalar; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxActiveTimeSeconds; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SuccessfulBonusZoneHitSeconds; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Turbo) == 0x18, "Size mismatch for FDelMarVehicleConfigOverride_Turbo");
static_assert(offsetof(FDelMarVehicleConfigOverride_Turbo, StartingVehicleCharges) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Turbo::StartingVehicleCharges");
static_assert(offsetof(FDelMarVehicleConfigOverride_Turbo, ChargeRegenRateScalar) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Turbo::ChargeRegenRateScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Turbo, DriftBoostTurboGenerationScalar) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverride_Turbo::DriftBoostTurboGenerationScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Turbo, TurboSpeedScalar) == 0xc, "Offset mismatch for FDelMarVehicleConfigOverride_Turbo::TurboSpeedScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Turbo, MaxActiveTimeSeconds) == 0x10, "Offset mismatch for FDelMarVehicleConfigOverride_Turbo::MaxActiveTimeSeconds");
static_assert(offsetof(FDelMarVehicleConfigOverride_Turbo, SuccessfulBonusZoneHitSeconds) == 0x14, "Offset mismatch for FDelMarVehicleConfigOverride_Turbo::SuccessfulBonusZoneHitSeconds");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDelMarVehicleConfigOverride_Underthrust
{
    float StartingTankPercentage; // 0x0 (Size: 0x4, Type: FloatProperty)
    float ConsumptionRateMultiplier; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bReplenishTankOnLanding; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bReplenishTankOverTime; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
    float TankReplenishDelaySeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    float TankReplenishRateMultiplier; // 0x10 (Size: 0x4, Type: FloatProperty)
    float AccelScalar; // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxUpwardSpeedScalar; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_Underthrust) == 0x1c, "Size mismatch for FDelMarVehicleConfigOverride_Underthrust");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, StartingTankPercentage) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::StartingTankPercentage");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, ConsumptionRateMultiplier) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::ConsumptionRateMultiplier");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, bReplenishTankOnLanding) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::bReplenishTankOnLanding");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, bReplenishTankOverTime) == 0x9, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::bReplenishTankOverTime");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, TankReplenishDelaySeconds) == 0xc, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::TankReplenishDelaySeconds");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, TankReplenishRateMultiplier) == 0x10, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::TankReplenishRateMultiplier");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, AccelScalar) == 0x14, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::AccelScalar");
static_assert(offsetof(FDelMarVehicleConfigOverride_Underthrust, MaxUpwardSpeedScalar) == 0x18, "Offset mismatch for FDelMarVehicleConfigOverride_Underthrust::MaxUpwardSpeedScalar");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleConfigOverride_SelfDemolish
{
    bool bSelfDemolishEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float RequiredDemolishActionDuration; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverride_SelfDemolish) == 0x8, "Size mismatch for FDelMarVehicleConfigOverride_SelfDemolish");
static_assert(offsetof(FDelMarVehicleConfigOverride_SelfDemolish, bSelfDemolishEnabled) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverride_SelfDemolish::bSelfDemolishEnabled");
static_assert(offsetof(FDelMarVehicleConfigOverride_SelfDemolish, RequiredDemolishActionDuration) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverride_SelfDemolish::RequiredDemolishActionDuration");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FDelMarVehicleConfigOverrides
{
    bool bValid; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FDelMarVehicleConfigOverride_AutoUpright AutoUpright; // 0x4 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleConfigOverride_Collision Collision; // 0x8 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Drift Drift; // 0x10 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleConfigOverride_DriftBoost DriftBoost; // 0x1c (Size: 0xc, Type: StructProperty)
    FDelMarVehicleConfigOverride_Drive Drive; // 0x28 (Size: 0x14, Type: StructProperty)
    FDelMarVehicleConfigOverride_Gravity Gravity; // 0x3c (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Jump Jump; // 0x44 (Size: 0x4, Type: StructProperty)
    FDelMarVehicleConfigOverride_Kickflip Kickflip; // 0x48 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleConfigOverride_Oversteer Oversteer; // 0x54 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Terrain Terrain; // 0x5c (Size: 0x8, Type: StructProperty)
    FDelMarVehicleConfigOverride_Turbo Turbo; // 0x64 (Size: 0x18, Type: StructProperty)
    FDelMarVehicleConfigOverride_Underthrust Underthrust; // 0x7c (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleConfigOverride_SelfDemolish SelfDemolish; // 0x98 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleConfigOverrides) == 0xa0, "Size mismatch for FDelMarVehicleConfigOverrides");
static_assert(offsetof(FDelMarVehicleConfigOverrides, bValid) == 0x0, "Offset mismatch for FDelMarVehicleConfigOverrides::bValid");
static_assert(offsetof(FDelMarVehicleConfigOverrides, AutoUpright) == 0x4, "Offset mismatch for FDelMarVehicleConfigOverrides::AutoUpright");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Collision) == 0x8, "Offset mismatch for FDelMarVehicleConfigOverrides::Collision");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Drift) == 0x10, "Offset mismatch for FDelMarVehicleConfigOverrides::Drift");
static_assert(offsetof(FDelMarVehicleConfigOverrides, DriftBoost) == 0x1c, "Offset mismatch for FDelMarVehicleConfigOverrides::DriftBoost");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Drive) == 0x28, "Offset mismatch for FDelMarVehicleConfigOverrides::Drive");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Gravity) == 0x3c, "Offset mismatch for FDelMarVehicleConfigOverrides::Gravity");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Jump) == 0x44, "Offset mismatch for FDelMarVehicleConfigOverrides::Jump");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Kickflip) == 0x48, "Offset mismatch for FDelMarVehicleConfigOverrides::Kickflip");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Oversteer) == 0x54, "Offset mismatch for FDelMarVehicleConfigOverrides::Oversteer");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Terrain) == 0x5c, "Offset mismatch for FDelMarVehicleConfigOverrides::Terrain");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Turbo) == 0x64, "Offset mismatch for FDelMarVehicleConfigOverrides::Turbo");
static_assert(offsetof(FDelMarVehicleConfigOverrides, Underthrust) == 0x7c, "Offset mismatch for FDelMarVehicleConfigOverrides::Underthrust");
static_assert(offsetof(FDelMarVehicleConfigOverrides, SelfDemolish) == 0x98, "Offset mismatch for FDelMarVehicleConfigOverrides::SelfDemolish");

// Size: 0x128 (Inherited: 0x0, Single: 0x128)
struct FDelMarDynamicForceFeedbackEffect
{
    FForceFeedbackChannelDetails Effect; // 0x0 (Size: 0x90, Type: StructProperty)
    FRuntimeFloatCurve IntensityAmplifierCurve; // 0x90 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_118[0x10]; // 0x118 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarDynamicForceFeedbackEffect) == 0x128, "Size mismatch for FDelMarDynamicForceFeedbackEffect");
static_assert(offsetof(FDelMarDynamicForceFeedbackEffect, Effect) == 0x0, "Offset mismatch for FDelMarDynamicForceFeedbackEffect::Effect");
static_assert(offsetof(FDelMarDynamicForceFeedbackEffect, IntensityAmplifierCurve) == 0x90, "Offset mismatch for FDelMarDynamicForceFeedbackEffect::IntensityAmplifierCurve");

