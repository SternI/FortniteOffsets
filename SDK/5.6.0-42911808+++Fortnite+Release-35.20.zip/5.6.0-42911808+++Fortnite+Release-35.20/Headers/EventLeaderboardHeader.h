/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventLeaderboardHeader
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "Engine.h"
#include "CommonUI.h"

// Size: 0x740 (Inherited: 0xe58, Single: 0xfffff8e8)
class UEventLeaderboardHeader_C : public UFortShowdownDetailView
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x728 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_RoundTitle; // 0x730 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* CommonBorder_ScoringTitleBG; // 0x738 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void RefreshDataBP(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UEventLeaderboardHeader_C) == 0x740, "Size mismatch for UEventLeaderboardHeader_C");
static_assert(offsetof(UEventLeaderboardHeader_C, UberGraphFrame) == 0x728, "Offset mismatch for UEventLeaderboardHeader_C::UberGraphFrame");
static_assert(offsetof(UEventLeaderboardHeader_C, Text_RoundTitle) == 0x730, "Offset mismatch for UEventLeaderboardHeader_C::Text_RoundTitle");
static_assert(offsetof(UEventLeaderboardHeader_C, CommonBorder_ScoringTitleBG) == 0x738, "Offset mismatch for UEventLeaderboardHeader_C::CommonBorder_ScoringTitleBG");

