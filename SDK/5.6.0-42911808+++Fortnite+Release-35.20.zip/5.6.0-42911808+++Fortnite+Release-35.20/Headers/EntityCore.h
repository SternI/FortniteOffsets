/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "_Verse.h"

// Size: 0x60 (Inherited: 0xe0, Single: 0xffffff80)
class UEntityPositionComponent : public UEntityDataBackedComponent
{
public:
};

static_assert(sizeof(UEntityPositionComponent) == 0x60, "Size mismatch for UEntityPositionComponent");

// Size: 0x60 (Inherited: 0x80, Single: 0xffffffe0)
class UEntityDataBackedComponent : public UEntityComponent
{
public:
};

static_assert(sizeof(UEntityDataBackedComponent) == 0x60, "Size mismatch for UEntityDataBackedComponent");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UEntityComponent : public UObject
{
public:
};

static_assert(sizeof(UEntityComponent) == 0x58, "Size mismatch for UEntityComponent");

// Size: 0x60 (Inherited: 0xe0, Single: 0xffffff80)
class UEntityRotationComponent : public UEntityDataBackedComponent
{
public:
};

static_assert(sizeof(UEntityRotationComponent) == 0x60, "Size mismatch for UEntityRotationComponent");

// Size: 0x60 (Inherited: 0xe0, Single: 0xffffff80)
class UEntityScaleComponent : public UEntityDataBackedComponent
{
public:
};

static_assert(sizeof(UEntityScaleComponent) == 0x60, "Size mismatch for UEntityScaleComponent");

// Size: 0x60 (Inherited: 0xe0, Single: 0xffffff80)
class UEntityCoreDataBackedRelativePositionComponent : public UEntityDataBackedComponent
{
public:
};

static_assert(sizeof(UEntityCoreDataBackedRelativePositionComponent) == 0x60, "Size mismatch for UEntityCoreDataBackedRelativePositionComponent");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UEntity : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    ULevel* Level; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UEntity) == 0x38, "Size mismatch for UEntity");
static_assert(offsetof(UEntity, Level) == 0x30, "Offset mismatch for UEntity::Level");

// Size: 0x150 (Inherited: 0x88, Single: 0xc8)
class UEntityCoreSubsystem : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x10]; // 0x30 (Size: 0x10, Type: PaddingProperty)
    TMap<FEntityComponentContainer, uint32_t> ComponentMap; // 0x40 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_90[0x58]; // 0x90 (Size: 0x58, Type: PaddingProperty)
    TArray<UEntityComponent*> ComponentArray; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TMap<UEntity*, uint32_t> Entities; // 0xf8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_148[0x8]; // 0x148 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UEntityCoreSubsystem) == 0x150, "Size mismatch for UEntityCoreSubsystem");
static_assert(offsetof(UEntityCoreSubsystem, ComponentMap) == 0x40, "Offset mismatch for UEntityCoreSubsystem::ComponentMap");
static_assert(offsetof(UEntityCoreSubsystem, ComponentArray) == 0xe8, "Offset mismatch for UEntityCoreSubsystem::ComponentArray");
static_assert(offsetof(UEntityCoreSubsystem, Entities) == 0xf8, "Offset mismatch for UEntityCoreSubsystem::Entities");

// Size: 0x78 (Inherited: 0x80, Single: 0xfffffff8)
class UEntityEnableableComponent : public UEntityComponent
{
public:
    uint8_t IsEnabled : 1; // 0x58:0 (Size: 0x1, Type: BoolProperty)
    uint8_t LastIsEnabled : 1; // 0x58:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x1f]; // 0x59 (Size: 0x1f, Type: PaddingProperty)

private:
    void OnRep_Enabled(); // 0xb57d340 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityEnableableComponent) == 0x78, "Size mismatch for UEntityEnableableComponent");
static_assert(offsetof(UEntityEnableableComponent, IsEnabled) == 0x58, "Offset mismatch for UEntityEnableableComponent::IsEnabled");
static_assert(offsetof(UEntityEnableableComponent, LastIsEnabled) == 0x58, "Offset mismatch for UEntityEnableableComponent::LastIsEnabled");

// Size: 0xb0 (Inherited: 0x1a8, Single: 0xffffff08)
class UEntityScriptComponent : public UEntityTickableComponent
{
public:
};

static_assert(sizeof(UEntityScriptComponent) == 0xb0, "Size mismatch for UEntityScriptComponent");

// Size: 0xb0 (Inherited: 0xf8, Single: 0xffffffb8)
class UEntityTickableComponent : public UEntityEnableableComponent
{
public:
};

static_assert(sizeof(UEntityTickableComponent) == 0xb0, "Size mismatch for UEntityTickableComponent");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FComponentData
{
};

static_assert(sizeof(FComponentData) == 0x1, "Size mismatch for FComponentData");

// Size: 0x18 (Inherited: 0x1, Single: 0x17)
struct FEntityPositionComponentData : FComponentData
{
    FVector WorldPosition; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FEntityPositionComponentData) == 0x18, "Size mismatch for FEntityPositionComponentData");
static_assert(offsetof(FEntityPositionComponentData, WorldPosition) == 0x0, "Offset mismatch for FEntityPositionComponentData::WorldPosition");

// Size: 0x18 (Inherited: 0x1, Single: 0x17)
struct FEntityRotationComponentData : FComponentData
{
    FRotator WorldRotation; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FEntityRotationComponentData) == 0x18, "Size mismatch for FEntityRotationComponentData");
static_assert(offsetof(FEntityRotationComponentData, WorldRotation) == 0x0, "Offset mismatch for FEntityRotationComponentData::WorldRotation");

// Size: 0x18 (Inherited: 0x1, Single: 0x17)
struct FEntityScaleComponentData : FComponentData
{
    FVector WorldScale3D; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FEntityScaleComponentData) == 0x18, "Size mismatch for FEntityScaleComponentData");
static_assert(offsetof(FEntityScaleComponentData, WorldScale3D) == 0x0, "Offset mismatch for FEntityScaleComponentData::WorldScale3D");

// Size: 0x20 (Inherited: 0x1, Single: 0x1f)
struct FEntityCoreSystemRelativePositionComponentData : FComponentData
{
};

static_assert(sizeof(FEntityCoreSystemRelativePositionComponentData) == 0x20, "Size mismatch for FEntityCoreSystemRelativePositionComponentData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEntityComponentContainer
{
    TArray<UEntityComponent*> Array; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEntityComponentContainer) == 0x10, "Size mismatch for FEntityComponentContainer");
static_assert(offsetof(FEntityComponentContainer, Array) == 0x0, "Offset mismatch for FEntityComponentContainer::Array");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
struct FEntityTickFunction : FTickFunction
{
};

static_assert(sizeof(FEntityTickFunction) == 0x30, "Size mismatch for FEntityTickFunction");

