/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimPresetsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "AnimPresetsCore.h"
#include "GameFeatures.h"

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UAnimPresetComponent : public UActorComponent
{
public:
    TSoftClassPtr AnimPreset; // 0xb8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UAnimPresetComponent) == 0xd8, "Size mismatch for UAnimPresetComponent");
static_assert(offsetof(UAnimPresetComponent, AnimPreset) == 0xb8, "Offset mismatch for UAnimPresetComponent::AnimPreset");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UAnimPreset_BasicLocomotion : public UAnimPreset
{
public:
    FAnimPreset_SingleAnimationData Idle; // 0x28 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveForward; // 0x38 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveBackward; // 0x48 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveLeft; // 0x58 (Size: 0x10, Type: StructProperty)
    FAnimPreset_SingleAnimationData MoveRight; // 0x68 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAnimPreset_BasicLocomotion) == 0x78, "Size mismatch for UAnimPreset_BasicLocomotion");
static_assert(offsetof(UAnimPreset_BasicLocomotion, Idle) == 0x28, "Offset mismatch for UAnimPreset_BasicLocomotion::Idle");
static_assert(offsetof(UAnimPreset_BasicLocomotion, MoveForward) == 0x38, "Offset mismatch for UAnimPreset_BasicLocomotion::MoveForward");
static_assert(offsetof(UAnimPreset_BasicLocomotion, MoveBackward) == 0x48, "Offset mismatch for UAnimPreset_BasicLocomotion::MoveBackward");
static_assert(offsetof(UAnimPreset_BasicLocomotion, MoveLeft) == 0x58, "Offset mismatch for UAnimPreset_BasicLocomotion::MoveLeft");
static_assert(offsetof(UAnimPreset_BasicLocomotion, MoveRight) == 0x68, "Offset mismatch for UAnimPreset_BasicLocomotion::MoveRight");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UGameFeatureAction_AnimPreset : public UGameFeatureAction
{
public:
    TSoftClassPtr AnimBP_Preset_BasicLocomotion; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UGameFeatureAction_AnimPreset) == 0x48, "Size mismatch for UGameFeatureAction_AnimPreset");
static_assert(offsetof(UGameFeatureAction_AnimPreset, AnimBP_Preset_BasicLocomotion) == 0x28, "Offset mismatch for UGameFeatureAction_AnimPreset::AnimBP_Preset_BasicLocomotion");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAnimPreset_SingleAnimationData
{
    UAnimSequence* Animation; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float PlayRate; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimPreset_SingleAnimationData) == 0x10, "Size mismatch for FAnimPreset_SingleAnimationData");
static_assert(offsetof(FAnimPreset_SingleAnimationData, Animation) == 0x0, "Offset mismatch for FAnimPreset_SingleAnimationData::Animation");
static_assert(offsetof(FAnimPreset_SingleAnimationData, PlayRate) == 0x8, "Offset mismatch for FAnimPreset_SingleAnimationData::PlayRate");

