/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GeometryFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDynamicMeshProcessorBlueprint : public UObject
{
public:

public:
    virtual void ProcessDynamicMesh(UDynamicMesh*& TargetMesh, bool& bFailed); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UDynamicMeshProcessorBlueprint) == 0x28, "Size mismatch for UDynamicMeshProcessorBlueprint");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UMeshCommandChangeTarget : public UInterface
{
public:
};

static_assert(sizeof(UMeshCommandChangeTarget) == 0x28, "Size mismatch for UMeshCommandChangeTarget");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UMeshReplacementCommandChangeTarget : public UInterface
{
public:
};

static_assert(sizeof(UMeshReplacementCommandChangeTarget) == 0x28, "Size mismatch for UMeshReplacementCommandChangeTarget");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UMeshVertexCommandChangeTarget : public UInterface
{
public:
};

static_assert(sizeof(UMeshVertexCommandChangeTarget) == 0x28, "Size mismatch for UMeshVertexCommandChangeTarget");

// Size: 0x5e0 (Inherited: 0xda0, Single: 0xfffff840)
class UBaseDynamicMeshComponent : public UMeshComponent
{
public:
    uint8_t Pad_560[0x20]; // 0x560 (Size: 0x20, Type: PaddingProperty)
    bool bExplicitShowWireframe; // 0x580 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_581[0x3]; // 0x581 (Size: 0x3, Type: PaddingProperty)
    FLinearColor WireframeColor; // 0x584 (Size: 0x10, Type: StructProperty)
    uint8_t ColorMode; // 0x594 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_595[0x3]; // 0x595 (Size: 0x3, Type: PaddingProperty)
    FColor ConstantColor; // 0x598 (Size: 0x4, Type: StructProperty)
    uint8_t ColorSpaceMode; // 0x59c (Size: 0x1, Type: EnumProperty)
    bool bEnableFlatShading; // 0x59d (Size: 0x1, Type: BoolProperty)
    bool bEnableViewModeOverrides; // 0x59e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59f[0x1]; // 0x59f (Size: 0x1, Type: PaddingProperty)
    UMaterialInterface* OverrideRenderMaterial; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* SecondaryRenderMaterial; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5b0[0x8]; // 0x5b0 (Size: 0x8, Type: PaddingProperty)
    UMaterialInterface* WireframeMaterialOverride; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* SecondaryWireframeMaterialOverride; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    bool bEnableRayTracing; // 0x5c8 (Size: 0x1, Type: BoolProperty)
    uint8_t DrawPath; // 0x5c9 (Size: 0x1, Type: EnumProperty)
    uint8_t DistanceFieldMode; // 0x5ca (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5cb[0x5]; // 0x5cb (Size: 0x5, Type: PaddingProperty)
    TArray<UMaterialInterface*> BaseMaterials; // 0x5d0 (Size: 0x10, Type: ArrayProperty)

public:
    void ClearOverrideRenderMaterial(); // 0x10871dd8 (Index: 0x0, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void ClearOverrideSecondaryWireframeRenderMaterial(); // 0x10871df0 (Index: 0x1, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void ClearOverrideWireframeRenderMaterial(); // 0xd357bdc (Index: 0x2, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void ClearSecondaryRenderMaterial(); // 0x4f6c140 (Index: 0x3, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    EDynamicMeshComponentColorOverrideMode GetColorOverrideMode() const; // 0x10872160 (Index: 0x4, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FColor GetConstantOverrideColor() const; // 0x108721ac (Index: 0x5, Flags: Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    EDynamicMeshComponentDistanceFieldMode GetDistanceFieldMode() const; // 0x53d5184 (Index: 0x6, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDynamicMesh* GetDynamicMesh(); // 0x108721dc (Index: 0x7, Flags: Native|Public|BlueprintCallable)
    bool GetEnableRaytracing() const; // 0xa7f6188 (Index: 0x8, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetEnableWireframeRenderPass() const; // 0x10872204 (Index: 0x9, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetFlatShadingEnabled() const; // 0x1087222c (Index: 0xa, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDynamicMeshDrawPath GetMeshDrawPath() const; // 0x10872254 (Index: 0xb, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMaterialInterface* GetOverrideRenderMaterial(int32_t& MaterialIndex) const; // 0x1087227c (Index: 0xc, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMaterialInterface* GetOverrideSecondaryWireframeRenderMaterial() const; // 0x108723bc (Index: 0xd, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMaterialInterface* GetOverrideWireframeRenderMaterial() const; // 0x108723e4 (Index: 0xe, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSecondaryBuffersVisibility() const; // 0x1087240c (Index: 0xf, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMaterialInterface* GetSecondaryRenderMaterial() const; // 0x10872434 (Index: 0x10, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetShadowsEnabled() const; // 0x61affc8 (Index: 0x11, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDynamicMeshVertexColorTransformMode GetVertexColorSpaceTransformMode() const; // 0x108724a0 (Index: 0x12, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetViewModeOverridesEnabled() const; // 0x108724c8 (Index: 0x13, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasOverrideRenderMaterial(int32_t& K) const; // 0x108724f0 (Index: 0x14, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetColorOverrideMode(EDynamicMeshComponentColorOverrideMode& NewMode); // 0x10873578 (Index: 0x15, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetConstantOverrideColor(FColor& NewColor); // 0x108738c4 (Index: 0x16, Flags: RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetDistanceFieldMode(EDynamicMeshComponentDistanceFieldMode& NewDistFieldMode); // 0x10873bb4 (Index: 0x17, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetEnableFlatShading(bool& bEnable); // 0x10874090 (Index: 0x18, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetEnableRaytracing(bool& bSetEnabled); // 0x108741c0 (Index: 0x19, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetEnableWireframeRenderPass(bool& bEnable); // 0x108742f0 (Index: 0x1a, Flags: Native|Public|BlueprintCallable)
    void SetMeshDrawPath(EDynamicMeshDrawPath& NewDrawPath); // 0x10874420 (Index: 0x1b, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetOverrideRenderMaterial(UMaterialInterface*& Material); // 0x10874550 (Index: 0x1c, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetOverrideSecondaryWireframeRenderMaterial(UMaterialInterface*& Material); // 0x10874680 (Index: 0x1d, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetOverrideWireframeRenderMaterial(UMaterialInterface*& Material); // 0x108747b0 (Index: 0x1e, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetSecondaryBuffersVisibility(bool& bSetVisible); // 0x108748e0 (Index: 0x1f, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetSecondaryRenderMaterial(UMaterialInterface*& Material); // 0x10874a10 (Index: 0x20, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetShadowsEnabled(bool& bEnabled); // 0x10874b40 (Index: 0x21, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetVertexColorSpaceTransformMode(EDynamicMeshVertexColorTransformMode& NewMode); // 0x10874d9c (Index: 0x22, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetViewModeOverridesEnabled(bool& bEnabled); // 0x10874ecc (Index: 0x23, Flags: RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UBaseDynamicMeshComponent) == 0x5e0, "Size mismatch for UBaseDynamicMeshComponent");
static_assert(offsetof(UBaseDynamicMeshComponent, bExplicitShowWireframe) == 0x580, "Offset mismatch for UBaseDynamicMeshComponent::bExplicitShowWireframe");
static_assert(offsetof(UBaseDynamicMeshComponent, WireframeColor) == 0x584, "Offset mismatch for UBaseDynamicMeshComponent::WireframeColor");
static_assert(offsetof(UBaseDynamicMeshComponent, ColorMode) == 0x594, "Offset mismatch for UBaseDynamicMeshComponent::ColorMode");
static_assert(offsetof(UBaseDynamicMeshComponent, ConstantColor) == 0x598, "Offset mismatch for UBaseDynamicMeshComponent::ConstantColor");
static_assert(offsetof(UBaseDynamicMeshComponent, ColorSpaceMode) == 0x59c, "Offset mismatch for UBaseDynamicMeshComponent::ColorSpaceMode");
static_assert(offsetof(UBaseDynamicMeshComponent, bEnableFlatShading) == 0x59d, "Offset mismatch for UBaseDynamicMeshComponent::bEnableFlatShading");
static_assert(offsetof(UBaseDynamicMeshComponent, bEnableViewModeOverrides) == 0x59e, "Offset mismatch for UBaseDynamicMeshComponent::bEnableViewModeOverrides");
static_assert(offsetof(UBaseDynamicMeshComponent, OverrideRenderMaterial) == 0x5a0, "Offset mismatch for UBaseDynamicMeshComponent::OverrideRenderMaterial");
static_assert(offsetof(UBaseDynamicMeshComponent, SecondaryRenderMaterial) == 0x5a8, "Offset mismatch for UBaseDynamicMeshComponent::SecondaryRenderMaterial");
static_assert(offsetof(UBaseDynamicMeshComponent, WireframeMaterialOverride) == 0x5b8, "Offset mismatch for UBaseDynamicMeshComponent::WireframeMaterialOverride");
static_assert(offsetof(UBaseDynamicMeshComponent, SecondaryWireframeMaterialOverride) == 0x5c0, "Offset mismatch for UBaseDynamicMeshComponent::SecondaryWireframeMaterialOverride");
static_assert(offsetof(UBaseDynamicMeshComponent, bEnableRayTracing) == 0x5c8, "Offset mismatch for UBaseDynamicMeshComponent::bEnableRayTracing");
static_assert(offsetof(UBaseDynamicMeshComponent, DrawPath) == 0x5c9, "Offset mismatch for UBaseDynamicMeshComponent::DrawPath");
static_assert(offsetof(UBaseDynamicMeshComponent, DistanceFieldMode) == 0x5ca, "Offset mismatch for UBaseDynamicMeshComponent::DistanceFieldMode");
static_assert(offsetof(UBaseDynamicMeshComponent, BaseMaterials) == 0x5d0, "Offset mismatch for UBaseDynamicMeshComponent::BaseMaterials");

// Size: 0x900 (Inherited: 0x1380, Single: 0xfffff580)
class UDynamicMeshComponent : public UBaseDynamicMeshComponent
{
public:
    uint8_t Pad_5e0[0x8]; // 0x5e0 (Size: 0x8, Type: PaddingProperty)
    UDynamicMesh* MeshObject; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5f0[0x59]; // 0x5f0 (Size: 0x59, Type: PaddingProperty)
    bool bAllowsGeometrySelection; // 0x649 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_64a[0xc6]; // 0x64a (Size: 0xc6, Type: PaddingProperty)
    uint8_t TangentsType; // 0x710 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_711[0xef]; // 0x711 (Size: 0xef, Type: PaddingProperty)
    TEnumAsByte<ECollisionTraceFlag> CollisionType; // 0x800 (Size: 0x1, Type: ByteProperty)
    bool bUseAsyncCooking; // 0x801 (Size: 0x1, Type: BoolProperty)
    bool bEnableComplexCollision; // 0x802 (Size: 0x1, Type: BoolProperty)
    bool bDeferCollisionUpdates; // 0x803 (Size: 0x1, Type: BoolProperty)
    bool bDisableMeshUVHitResults; // 0x804 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_805[0x3]; // 0x805 (Size: 0x3, Type: PaddingProperty)
    UBodySetup* MeshBodySetup; // 0x808 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_810[0x38]; // 0x810 (Size: 0x38, Type: PaddingProperty)
    FKAggregateGeom AggGeom; // 0x848 (Size: 0xa0, Type: StructProperty)
    TArray<UBodySetup*> AsyncBodySetupQueue; // 0x8e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_8f8[0x8]; // 0x8f8 (Size: 0x8, Type: PaddingProperty)

public:
    bool AllowsGeometrySelection() const; // 0xb641a20 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ConfigureMaterialSet(const TArray<UMaterialInterface*> NewMaterialSet, bool& bDeleteExtraSlots); // 0x10871e08 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void EnableComplexAsSimpleCollision(); // 0x1087210c (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    EDynamicMeshComponentTangentsMode GetTangentsType() const; // 0x1087245c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void NotifyMeshModified(); // 0xeac99fc (Index: 0x5, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void NotifyMeshVertexAttributesModified(bool& bPositions, bool& bNormals, bool& bUVs, bool& bColors); // 0x10872654 (Index: 0x6, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetAllowsGeometrySelection(bool& bInAllowsGeometrySelection); // 0x1087344c (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetComplexAsSimpleCollisionEnabled(bool& bEnabled, bool& bImmediateUpdate); // 0x108736a8 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetDeferredCollisionUpdatesEnabled(bool& bEnabled, bool& bImmediateUpdate); // 0x10873988 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetDynamicMesh(UDynamicMesh*& NewMesh); // 0x10873ce4 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetTangentsType(EDynamicMeshComponentTangentsMode& NewTangentsType); // 0x10874c70 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void UpdateCollision(bool& bOnlyIfPending); // 0x10874ffc (Index: 0xc, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    bool ValidateMaterialSlots(bool& bCreateIfMissing, bool& bDeleteExtraSlots); // 0x1087512c (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)

private:
    EDynamicMeshComponentTangentsMode GetTangentsTypePure() const; // 0x1087245c (Index: 0x4, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDynamicMeshComponent) == 0x900, "Size mismatch for UDynamicMeshComponent");
static_assert(offsetof(UDynamicMeshComponent, MeshObject) == 0x5e8, "Offset mismatch for UDynamicMeshComponent::MeshObject");
static_assert(offsetof(UDynamicMeshComponent, bAllowsGeometrySelection) == 0x649, "Offset mismatch for UDynamicMeshComponent::bAllowsGeometrySelection");
static_assert(offsetof(UDynamicMeshComponent, TangentsType) == 0x710, "Offset mismatch for UDynamicMeshComponent::TangentsType");
static_assert(offsetof(UDynamicMeshComponent, CollisionType) == 0x800, "Offset mismatch for UDynamicMeshComponent::CollisionType");
static_assert(offsetof(UDynamicMeshComponent, bUseAsyncCooking) == 0x801, "Offset mismatch for UDynamicMeshComponent::bUseAsyncCooking");
static_assert(offsetof(UDynamicMeshComponent, bEnableComplexCollision) == 0x802, "Offset mismatch for UDynamicMeshComponent::bEnableComplexCollision");
static_assert(offsetof(UDynamicMeshComponent, bDeferCollisionUpdates) == 0x803, "Offset mismatch for UDynamicMeshComponent::bDeferCollisionUpdates");
static_assert(offsetof(UDynamicMeshComponent, bDisableMeshUVHitResults) == 0x804, "Offset mismatch for UDynamicMeshComponent::bDisableMeshUVHitResults");
static_assert(offsetof(UDynamicMeshComponent, MeshBodySetup) == 0x808, "Offset mismatch for UDynamicMeshComponent::MeshBodySetup");
static_assert(offsetof(UDynamicMeshComponent, AggGeom) == 0x848, "Offset mismatch for UDynamicMeshComponent::AggGeom");
static_assert(offsetof(UDynamicMeshComponent, AsyncBodySetupQueue) == 0x8e8, "Offset mismatch for UDynamicMeshComponent::AsyncBodySetupQueue");

// Size: 0x2c0 (Inherited: 0x2d0, Single: 0xfffffff0)
class ADynamicMeshActor : public AActor
{
public:
    UDynamicMeshComponent* DynamicMeshComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    bool bEnableComputeMeshPool; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x7]; // 0x2b1 (Size: 0x7, Type: PaddingProperty)
    UDynamicMeshPool* DynamicMeshPool; // 0x2b8 (Size: 0x8, Type: ObjectProperty)

public:
    UDynamicMesh* AllocateComputeMesh(); // 0x10871d88 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void FreeAllComputeMeshes(); // 0x10872124 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    UDynamicMeshPool* GetComputeMeshPool(); // 0x10872188 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    UDynamicMeshComponent* GetDynamicMeshComponent() const; // 0xa598a54 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ReleaseAllComputeMeshes(); // 0x10872a34 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool ReleaseComputeMesh(UDynamicMesh*& Mesh); // 0x10872a5c (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADynamicMeshActor) == 0x2c0, "Size mismatch for ADynamicMeshActor");
static_assert(offsetof(ADynamicMeshActor, DynamicMeshComponent) == 0x2a8, "Offset mismatch for ADynamicMeshActor::DynamicMeshComponent");
static_assert(offsetof(ADynamicMeshActor, bEnableComputeMeshPool) == 0x2b0, "Offset mismatch for ADynamicMeshActor::bEnableComputeMeshPool");
static_assert(offsetof(ADynamicMeshActor, DynamicMeshPool) == 0x2b8, "Offset mismatch for ADynamicMeshActor::DynamicMeshPool");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDynamicMeshGenerator : public UObject
{
public:
};

static_assert(sizeof(UDynamicMeshGenerator) == 0x28, "Size mismatch for UDynamicMeshGenerator");

// Size: 0xb0 (Inherited: 0x28, Single: 0x88)
class UDynamicMesh : public UObject
{
public:
    uint8_t Pad_28[0x48]; // 0x28 (Size: 0x48, Type: PaddingProperty)
    uint8_t MeshModifiedBPEvent[0x10]; // 0x70 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_80[0x20]; // 0x80 (Size: 0x20, Type: PaddingProperty)
    UDynamicMeshGenerator* MeshGenerator; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    bool bEnableMeshGenerator; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)

public:
    int32_t GetTriangleCount() const; // 0x10872480 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsEmpty() const; // 0x10872630 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDynamicMesh* Reset(); // 0x10872f50 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    UDynamicMesh* ResetToCube(); // 0x10872f74 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDynamicMesh) == 0xb0, "Size mismatch for UDynamicMesh");
static_assert(offsetof(UDynamicMesh, MeshModifiedBPEvent) == 0x70, "Offset mismatch for UDynamicMesh::MeshModifiedBPEvent");
static_assert(offsetof(UDynamicMesh, MeshGenerator) == 0xa0, "Offset mismatch for UDynamicMesh::MeshGenerator");
static_assert(offsetof(UDynamicMesh, bEnableMeshGenerator) == 0xa8, "Offset mismatch for UDynamicMesh::bEnableMeshGenerator");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UDynamicMeshPool : public UObject
{
public:
    TArray<UDynamicMesh*> CachedMeshes; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicMesh*> AllCreatedMeshes; // 0x38 (Size: 0x10, Type: ArrayProperty)

public:
    void FreeAllMeshes(); // 0x1087214c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    UDynamicMesh* RequestMesh(); // 0x10872f2c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ReturnAllMeshes(); // 0x10872f98 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ReturnMesh(UDynamicMesh*& Mesh); // 0x10872fac (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDynamicMeshPool) == 0x48, "Size mismatch for UDynamicMeshPool");
static_assert(offsetof(UDynamicMeshPool, CachedMeshes) == 0x28, "Offset mismatch for UDynamicMeshPool::CachedMeshes");
static_assert(offsetof(UDynamicMeshPool, AllCreatedMeshes) == 0x38, "Offset mismatch for UDynamicMeshPool::AllCreatedMeshes");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDynamicMeshChangeInfo
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Flags; // 0x1 (Size: 0x1, Type: EnumProperty)
    bool bIsRevertChange; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1d]; // 0x3 (Size: 0x1d, Type: PaddingProperty)
};

static_assert(sizeof(FDynamicMeshChangeInfo) == 0x20, "Size mismatch for FDynamicMeshChangeInfo");
static_assert(offsetof(FDynamicMeshChangeInfo, Type) == 0x0, "Offset mismatch for FDynamicMeshChangeInfo::Type");
static_assert(offsetof(FDynamicMeshChangeInfo, Flags) == 0x1, "Offset mismatch for FDynamicMeshChangeInfo::Flags");
static_assert(offsetof(FDynamicMeshChangeInfo, bIsRevertChange) == 0x2, "Offset mismatch for FDynamicMeshChangeInfo::bIsRevertChange");

