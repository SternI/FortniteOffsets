/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventScreenBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "CommonUILegacy.h"
#include "FortniteGame.h"
#include "GameplayTags.h"

// Size: 0x310 (Inherited: 0x58, Single: 0x2b8)
class UFortEventScreenData : public UDataAsset
{
public:
    FString EventCMSId; // 0x30 (Size: 0x10, Type: StrProperty)
    FString AccountResourceName; // 0x40 (Size: 0x10, Type: StrProperty)
    FString AccountResourceNameGranter; // 0x50 (Size: 0x10, Type: StrProperty)
    FString LevelOfferId; // 0x60 (Size: 0x10, Type: StrProperty)
    FString PremiumTrackOfferId; // 0x70 (Size: 0x10, Type: StrProperty)
    UFortTokenType* PremiumTrackPurchasedToken; // 0x80 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag VaultWorldTag; // 0x88 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    FVaultWorldBackgroundData PreviewScreenBackgroundData; // 0x90 (Size: 0x58, Type: StructProperty)
    TSoftObjectPtr<UFortChallengeBundleItemDefinition*> QuestBundle; // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortItemDefinition*> SpecialRewardItem; // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortItemDefinition*> SpecialPremiumRewardItem; // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FEventItemOverride> ItemOverrides; // 0x148 (Size: 0x10, Type: ArrayProperty)
    FEventScreenTrackData FreeTrackData; // 0x158 (Size: 0x30, Type: StructProperty)
    FEventScreenTrackData PremiumTrackData; // 0x188 (Size: 0x30, Type: StructProperty)
    FGameplayTag QuestCategoryTag; // 0x1b8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1bc[0x4]; // 0x1bc (Size: 0x4, Type: PaddingProperty)
    TArray<UClass*> RichTextDecorators; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    TMap<FLinearColor, FName> RewardTileBackgroundColors; // 0x1d0 (Size: 0x50, Type: MapProperty)
    FText TimeRemainingFormat; // 0x220 (Size: 0x10, Type: TextProperty)
    FText CurrencyFormat; // 0x230 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject*> MoreInfoKeyArt; // 0x240 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FEventScreenMoreInfoGroup> MoreInfoGroups; // 0x260 (Size: 0x10, Type: ArrayProperty)
    float RewardPreviewZoomLevel; // 0x270 (Size: 0x4, Type: FloatProperty)
    bool bUseWidgetCameraFraming; // 0x274 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_275[0x3]; // 0x275 (Size: 0x3, Type: PaddingProperty)
    TSoftClassPtr MoreInfoModalClass; // 0x278 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr PurchaseLevelsModalClass; // 0x298 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr PremiumTrackUpsellModalClass; // 0x2b8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr PurchasePremiumTrackModalClass; // 0x2d8 (Size: 0x20, Type: SoftClassProperty)
    TArray<FString> CalendarEvents; // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    bool bUseRewardTrackProgressInsteadOfCurrentResource; // 0x308 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_309[0x7]; // 0x309 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortEventScreenData) == 0x310, "Size mismatch for UFortEventScreenData");
static_assert(offsetof(UFortEventScreenData, EventCMSId) == 0x30, "Offset mismatch for UFortEventScreenData::EventCMSId");
static_assert(offsetof(UFortEventScreenData, AccountResourceName) == 0x40, "Offset mismatch for UFortEventScreenData::AccountResourceName");
static_assert(offsetof(UFortEventScreenData, AccountResourceNameGranter) == 0x50, "Offset mismatch for UFortEventScreenData::AccountResourceNameGranter");
static_assert(offsetof(UFortEventScreenData, LevelOfferId) == 0x60, "Offset mismatch for UFortEventScreenData::LevelOfferId");
static_assert(offsetof(UFortEventScreenData, PremiumTrackOfferId) == 0x70, "Offset mismatch for UFortEventScreenData::PremiumTrackOfferId");
static_assert(offsetof(UFortEventScreenData, PremiumTrackPurchasedToken) == 0x80, "Offset mismatch for UFortEventScreenData::PremiumTrackPurchasedToken");
static_assert(offsetof(UFortEventScreenData, VaultWorldTag) == 0x88, "Offset mismatch for UFortEventScreenData::VaultWorldTag");
static_assert(offsetof(UFortEventScreenData, PreviewScreenBackgroundData) == 0x90, "Offset mismatch for UFortEventScreenData::PreviewScreenBackgroundData");
static_assert(offsetof(UFortEventScreenData, QuestBundle) == 0xe8, "Offset mismatch for UFortEventScreenData::QuestBundle");
static_assert(offsetof(UFortEventScreenData, SpecialRewardItem) == 0x108, "Offset mismatch for UFortEventScreenData::SpecialRewardItem");
static_assert(offsetof(UFortEventScreenData, SpecialPremiumRewardItem) == 0x128, "Offset mismatch for UFortEventScreenData::SpecialPremiumRewardItem");
static_assert(offsetof(UFortEventScreenData, ItemOverrides) == 0x148, "Offset mismatch for UFortEventScreenData::ItemOverrides");
static_assert(offsetof(UFortEventScreenData, FreeTrackData) == 0x158, "Offset mismatch for UFortEventScreenData::FreeTrackData");
static_assert(offsetof(UFortEventScreenData, PremiumTrackData) == 0x188, "Offset mismatch for UFortEventScreenData::PremiumTrackData");
static_assert(offsetof(UFortEventScreenData, QuestCategoryTag) == 0x1b8, "Offset mismatch for UFortEventScreenData::QuestCategoryTag");
static_assert(offsetof(UFortEventScreenData, RichTextDecorators) == 0x1c0, "Offset mismatch for UFortEventScreenData::RichTextDecorators");
static_assert(offsetof(UFortEventScreenData, RewardTileBackgroundColors) == 0x1d0, "Offset mismatch for UFortEventScreenData::RewardTileBackgroundColors");
static_assert(offsetof(UFortEventScreenData, TimeRemainingFormat) == 0x220, "Offset mismatch for UFortEventScreenData::TimeRemainingFormat");
static_assert(offsetof(UFortEventScreenData, CurrencyFormat) == 0x230, "Offset mismatch for UFortEventScreenData::CurrencyFormat");
static_assert(offsetof(UFortEventScreenData, MoreInfoKeyArt) == 0x240, "Offset mismatch for UFortEventScreenData::MoreInfoKeyArt");
static_assert(offsetof(UFortEventScreenData, MoreInfoGroups) == 0x260, "Offset mismatch for UFortEventScreenData::MoreInfoGroups");
static_assert(offsetof(UFortEventScreenData, RewardPreviewZoomLevel) == 0x270, "Offset mismatch for UFortEventScreenData::RewardPreviewZoomLevel");
static_assert(offsetof(UFortEventScreenData, bUseWidgetCameraFraming) == 0x274, "Offset mismatch for UFortEventScreenData::bUseWidgetCameraFraming");
static_assert(offsetof(UFortEventScreenData, MoreInfoModalClass) == 0x278, "Offset mismatch for UFortEventScreenData::MoreInfoModalClass");
static_assert(offsetof(UFortEventScreenData, PurchaseLevelsModalClass) == 0x298, "Offset mismatch for UFortEventScreenData::PurchaseLevelsModalClass");
static_assert(offsetof(UFortEventScreenData, PremiumTrackUpsellModalClass) == 0x2b8, "Offset mismatch for UFortEventScreenData::PremiumTrackUpsellModalClass");
static_assert(offsetof(UFortEventScreenData, PurchasePremiumTrackModalClass) == 0x2d8, "Offset mismatch for UFortEventScreenData::PurchasePremiumTrackModalClass");
static_assert(offsetof(UFortEventScreenData, CalendarEvents) == 0x2f8, "Offset mismatch for UFortEventScreenData::CalendarEvents");
static_assert(offsetof(UFortEventScreenData, bUseRewardTrackProgressInsteadOfCurrentResource) == 0x308, "Offset mismatch for UFortEventScreenData::bUseRewardTrackProgressInsteadOfCurrentResource");

// Size: 0x418 (Inherited: 0xb38, Single: 0xfffff8e0)
class UFortEventModalBase : public UCommonActivatableWidget
{
public:

public:
    void CloseModal(); // 0x58f6d9c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortEventModalBase) == 0x418, "Size mismatch for UFortEventModalBase");

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class UFortEventMoreInfoGroup : public UUserWidget
{
public:

protected:
    virtual void OnEventScreenDataSet(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIconLoaded(UObject*& const Icon); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetGroupText(const FText Header, const FText Body); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventMoreInfoGroup) == 0x2b0, "Size mismatch for UFortEventMoreInfoGroup");

// Size: 0x440 (Inherited: 0xf50, Single: 0xfffff4f0)
class UFortEventMoreInfoModal : public UFortEventModalBase
{
public:
    UDynamicEntryBox* DynamicEntryBox_Groups; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x428 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_430[0x8]; // 0x430 (Size: 0x8, Type: PaddingProperty)
    UScrollBox* SB_Vertical; // 0x438 (Size: 0x8, Type: ObjectProperty)

protected:
    UFortEventScreenData* GetEventScreenData() const; // 0x1116bbb4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnEventScreenDataSet(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnKeyArtLoaded(UObject*& const Icon); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnModalBackout(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void SetModalText(const FText Header, const FText SubHeader, const FText Legal); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventMoreInfoModal) == 0x440, "Size mismatch for UFortEventMoreInfoModal");
static_assert(offsetof(UFortEventMoreInfoModal, DynamicEntryBox_Groups) == 0x418, "Offset mismatch for UFortEventMoreInfoModal::DynamicEntryBox_Groups");
static_assert(offsetof(UFortEventMoreInfoModal, Button_Back) == 0x420, "Offset mismatch for UFortEventMoreInfoModal::Button_Back");
static_assert(offsetof(UFortEventMoreInfoModal, Button_CloseTouch) == 0x428, "Offset mismatch for UFortEventMoreInfoModal::Button_CloseTouch");
static_assert(offsetof(UFortEventMoreInfoModal, SB_Vertical) == 0x438, "Offset mismatch for UFortEventMoreInfoModal::SB_Vertical");

// Size: 0x488 (Inherited: 0xf50, Single: 0xfffff538)
class UFortEventPurchaseLevelsModal : public UFortEventModalBase
{
public:
    UCommonButtonBase* Button_Addition; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Subtraction; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Purchase; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_GetVBucks; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UEventScreenListView* ListView_RewardPreview; // 0x448 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentResourceValue; // 0x450 (Size: 0x4, Type: IntProperty)
    int32_t MaxResourceValue; // 0x454 (Size: 0x4, Type: IntProperty)
    int32_t CurrentVBucks; // 0x458 (Size: 0x4, Type: IntProperty)
    int32_t OfferResourceQuantity; // 0x45c (Size: 0x4, Type: IntProperty)
    bool bAnimateListViewFromEmpty; // 0x460 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_461[0x27]; // 0x461 (Size: 0x27, Type: PaddingProperty)

protected:
    UFortEventScreenData* GetEventScreenData() const; // 0x1116bbe0 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnAmountChangeButtonClicked(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCMSTextApplied(const FText LegalText); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnEventScreenDataSet(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPurchaseAmountChanged(int32_t& const TotalPrice, int32_t& const LevelQuantity, int32_t& const PurchaseQuantity, int32_t& const ResourceQuantity); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventPurchaseLevelsModal) == 0x488, "Size mismatch for UFortEventPurchaseLevelsModal");
static_assert(offsetof(UFortEventPurchaseLevelsModal, Button_Addition) == 0x418, "Offset mismatch for UFortEventPurchaseLevelsModal::Button_Addition");
static_assert(offsetof(UFortEventPurchaseLevelsModal, Button_Subtraction) == 0x420, "Offset mismatch for UFortEventPurchaseLevelsModal::Button_Subtraction");
static_assert(offsetof(UFortEventPurchaseLevelsModal, Button_Purchase) == 0x428, "Offset mismatch for UFortEventPurchaseLevelsModal::Button_Purchase");
static_assert(offsetof(UFortEventPurchaseLevelsModal, Button_GetVBucks) == 0x430, "Offset mismatch for UFortEventPurchaseLevelsModal::Button_GetVBucks");
static_assert(offsetof(UFortEventPurchaseLevelsModal, Button_Back) == 0x438, "Offset mismatch for UFortEventPurchaseLevelsModal::Button_Back");
static_assert(offsetof(UFortEventPurchaseLevelsModal, Button_CloseTouch) == 0x440, "Offset mismatch for UFortEventPurchaseLevelsModal::Button_CloseTouch");
static_assert(offsetof(UFortEventPurchaseLevelsModal, ListView_RewardPreview) == 0x448, "Offset mismatch for UFortEventPurchaseLevelsModal::ListView_RewardPreview");
static_assert(offsetof(UFortEventPurchaseLevelsModal, CurrentResourceValue) == 0x450, "Offset mismatch for UFortEventPurchaseLevelsModal::CurrentResourceValue");
static_assert(offsetof(UFortEventPurchaseLevelsModal, MaxResourceValue) == 0x454, "Offset mismatch for UFortEventPurchaseLevelsModal::MaxResourceValue");
static_assert(offsetof(UFortEventPurchaseLevelsModal, CurrentVBucks) == 0x458, "Offset mismatch for UFortEventPurchaseLevelsModal::CurrentVBucks");
static_assert(offsetof(UFortEventPurchaseLevelsModal, OfferResourceQuantity) == 0x45c, "Offset mismatch for UFortEventPurchaseLevelsModal::OfferResourceQuantity");
static_assert(offsetof(UFortEventPurchaseLevelsModal, bAnimateListViewFromEmpty) == 0x460, "Offset mismatch for UFortEventPurchaseLevelsModal::bAnimateListViewFromEmpty");

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class UFortPurchasePremiumTrackBody : public UUserWidget
{
public:

public:
    virtual void OnPopulate(int32_t& const BodyIndex, const FText BodyText); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortPurchasePremiumTrackBody) == 0x2b0, "Size mismatch for UFortPurchasePremiumTrackBody");

// Size: 0x488 (Inherited: 0xf50, Single: 0xfffff538)
class UFortEventPurchasePremiumTrackModal : public UFortEventModalBase
{
public:
    UDynamicEntryBox* DynamicEntryBox_Body; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* ScrollBox_Body; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UFortCTAButton* Button_Purchase; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_GetVBucks; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PreviewReward; // 0x448 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentVBucks; // 0x450 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_454[0x34]; // 0x454 (Size: 0x34, Type: PaddingProperty)

protected:
    UFortEventScreenData* GetEventScreenData() const; // 0x1116bc0c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnCMSTextApplied(const FText HeaderText, const FText LegalText); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnEventScreenDataSet(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPriceSet(int32_t& const Price); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventPurchasePremiumTrackModal) == 0x488, "Size mismatch for UFortEventPurchasePremiumTrackModal");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, DynamicEntryBox_Body) == 0x418, "Offset mismatch for UFortEventPurchasePremiumTrackModal::DynamicEntryBox_Body");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, ScrollBox_Body) == 0x420, "Offset mismatch for UFortEventPurchasePremiumTrackModal::ScrollBox_Body");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, Button_Purchase) == 0x428, "Offset mismatch for UFortEventPurchasePremiumTrackModal::Button_Purchase");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, Button_GetVBucks) == 0x430, "Offset mismatch for UFortEventPurchasePremiumTrackModal::Button_GetVBucks");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, Button_Back) == 0x438, "Offset mismatch for UFortEventPurchasePremiumTrackModal::Button_Back");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, Button_CloseTouch) == 0x440, "Offset mismatch for UFortEventPurchasePremiumTrackModal::Button_CloseTouch");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, Button_PreviewReward) == 0x448, "Offset mismatch for UFortEventPurchasePremiumTrackModal::Button_PreviewReward");
static_assert(offsetof(UFortEventPurchasePremiumTrackModal, CurrentVBucks) == 0x450, "Offset mismatch for UFortEventPurchasePremiumTrackModal::CurrentVBucks");

// Size: 0x2b8 (Inherited: 0x458, Single: 0xfffffe60)
class UFortEventListViewWidgetBase : public UUserWidget
{
public:
};

static_assert(sizeof(UFortEventListViewWidgetBase) == 0x2b8, "Size mismatch for UFortEventListViewWidgetBase");

// Size: 0x308 (Inherited: 0x710, Single: 0xfffffbf8)
class UFortEventRewardTracksWidget : public UFortEventListViewWidgetBase
{
public:
    UDynamicEntryBox* DynamicEntryBox_RewardTracks; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    bool bPreviewMode; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c1[0x47]; // 0x2c1 (Size: 0x47, Type: PaddingProperty)

protected:
    virtual void BPOnEventScreenDataSet(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BPOnSetRewardItem(int32_t& const RequiredProgress, int32_t& const RemainingProgress, float& const RewardProgressPercent, float& const PreviewProgressPercent, float& const OverallProgressPercent, bool& const bInPreviewMode); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BPSetAllRewardsCollected(bool& const bAllCollected); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BPSetProgressPercent(float& const Percent); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventRewardTracksWidget) == 0x308, "Size mismatch for UFortEventRewardTracksWidget");
static_assert(offsetof(UFortEventRewardTracksWidget, DynamicEntryBox_RewardTracks) == 0x2b8, "Offset mismatch for UFortEventRewardTracksWidget::DynamicEntryBox_RewardTracks");
static_assert(offsetof(UFortEventRewardTracksWidget, bPreviewMode) == 0x2c0, "Offset mismatch for UFortEventRewardTracksWidget::bPreviewMode");

// Size: 0x2b8 (Inherited: 0x710, Single: 0xfffffba8)
class UFortEventSpacerWidget : public UFortEventListViewWidgetBase
{
public:
};

static_assert(sizeof(UFortEventSpacerWidget) == 0x2b8, "Size mismatch for UFortEventSpacerWidget");

// Size: 0x340 (Inherited: 0x458, Single: 0xfffffee8)
class UFortEventRewardWidget : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    UCommonButtonBase* Button_RewardPreview; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UFortCosmeticItemCard* UserWidget_ItemCard; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    bool bIsTrackOwned; // 0x2c8 (Size: 0x1, Type: BoolProperty)
    bool bPreviewMode; // 0x2c9 (Size: 0x1, Type: BoolProperty)
    bool bInPreviewSelectedState; // 0x2ca (Size: 0x1, Type: BoolProperty)
    bool bInPremiumUpgradeState; // 0x2cb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2cc[0x74]; // 0x2cc (Size: 0x74, Type: PaddingProperty)

public:
    virtual void OnRewardWidgetReset(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void SetAllRewardsCollected(bool& const bAllCollected); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void SetDoubleWidth(bool& const bDoubleWidth); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    virtual void SetInPreviewedState(bool& const bPreviewed); // 0x288a61c (Index: 0x9, Flags: Event|Public|BlueprintEvent)
    virtual void SetInSelectedState(bool& const bSelected); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)
    virtual void SetProgressPercent(float& const Percent); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintEvent)

protected:
    UFortEventScreenData* GetEventScreenData() const; // 0x1116bc38 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnEventScreenDataSet(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInputMethodChanged(ECommonInputType& const NewInputType); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetRewardItem(int32_t& const RequiredProgress, int32_t& const RemainingProgress, float& const RewardProgressPercent, float& const PreviewProgressPercent, float& const OverallProgressPercent, bool& const bInPreviewMode); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void SetCustomItemIcon(UTexture2D*& const CustomItemIcon); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void SetInPremiumUpgradeState(bool& const bHighlighted); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void SetInPreviewSelectedState(bool& const bSelected); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void SetIsBannerItem(bool& const bIsBanner); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void SetTrackData(const FEventScreenTrackData TrackData, bool& const bIsOwned); // 0x288a61c (Index: 0xe, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventRewardWidget) == 0x340, "Size mismatch for UFortEventRewardWidget");
static_assert(offsetof(UFortEventRewardWidget, Button_RewardPreview) == 0x2b8, "Offset mismatch for UFortEventRewardWidget::Button_RewardPreview");
static_assert(offsetof(UFortEventRewardWidget, UserWidget_ItemCard) == 0x2c0, "Offset mismatch for UFortEventRewardWidget::UserWidget_ItemCard");
static_assert(offsetof(UFortEventRewardWidget, bIsTrackOwned) == 0x2c8, "Offset mismatch for UFortEventRewardWidget::bIsTrackOwned");
static_assert(offsetof(UFortEventRewardWidget, bPreviewMode) == 0x2c9, "Offset mismatch for UFortEventRewardWidget::bPreviewMode");
static_assert(offsetof(UFortEventRewardWidget, bInPreviewSelectedState) == 0x2ca, "Offset mismatch for UFortEventRewardWidget::bInPreviewSelectedState");
static_assert(offsetof(UFortEventRewardWidget, bInPremiumUpgradeState) == 0x2cb, "Offset mismatch for UFortEventRewardWidget::bInPremiumUpgradeState");

// Size: 0xbc0 (Inherited: 0x1e10, Single: 0xffffedb0)
class UFortEventScreenBase : public UFortItemPreviewScreen
{
public:
    uint8_t Pad_820[0x28]; // 0x820 (Size: 0x28, Type: PaddingProperty)
    TArray<UNamedSlot*> LayoutTemplateSlots; // 0x848 (Size: 0x10, Type: ArrayProperty)
    UFortLazyImage* LazyImage_KeyArt; // 0x858 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ViewQuests; // 0x860 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MoreInfo; // 0x868 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PurchaseLevels; // 0x870 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Preview; // 0x878 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ShowInItemShop; // 0x880 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Previous; // 0x888 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Next; // 0x890 (Size: 0x8, Type: ObjectProperty)
    UFortEventTrackerModule_CustomText* CustomText_InspectItem; // 0x898 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_LoadError; // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Close; // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_DebugLoadingErrorReason; // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8c8[0x18]; // 0x8c8 (Size: 0x18, Type: PaddingProperty)
    UFortEventScreenData* EventScreenData; // 0x8e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t ActiveRewardPreviewType; // 0x8e8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_8e9[0x7]; // 0x8e9 (Size: 0x7, Type: PaddingProperty)
    UFortChallengeBundleItemDefinition* LoadedQuestBundle; // 0x8f0 (Size: 0x8, Type: ObjectProperty)
    UFortItemVM* CachedItemVM; // 0x8f8 (Size: 0x8, Type: ObjectProperty)
    UEventScreenVariantManager* VariantManager; // 0x900 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_908[0x2b8]; // 0x908 (Size: 0x2b8, Type: PaddingProperty)

private:
    void HandleActiveSeasonDataChanged(const TArray<FString> ActiveEventFlags); // 0x1116bce0 (Index: 0x5, Flags: Final|Native|Private|HasOutParms)
    void HandleGiftBoxClosed(); // 0x1116be98 (Index: 0x6, Flags: Final|Native|Private)
    UWidget* HandleRewardListNavigateRightEvent(EUINavigation& InNavigation); // 0x1116beac (Index: 0x7, Flags: Final|Native|Private)
    UWidget* HandleRewardListNavigateUpEvent(EUINavigation& InNavigation); // 0x1116bfe4 (Index: 0x8, Flags: Final|Native|Private)
    void HandleToggleFullscreenMap(bool& bVisible); // 0x1116c11c (Index: 0x9, Flags: Final|Native|Private)
    UWidget* HandleUpsellPromptNavigateUpEvent(EUINavigation& InNavigation); // 0x1116c248 (Index: 0xa, Flags: Final|Native|Private)

protected:
    UFortEventModalBase* GetActiveModal() const; // 0x1116bb5c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    FTimespan GetEventTimeRemaining() const; // 0x1116bc64 (Index: 0x1, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    AFortItemPreviewWorld* GetVaultWorld() const; // 0xf7f10f0 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    UMaterialInstanceDynamic* GetVaultWorldBackgroundMID() const; // 0x1116bc90 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    UMaterialInstanceDynamic* GetVaultWorldFloorMID() const; // 0x1116bcb8 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool HasAllRewardsCollected() const; // 0x1116c37c (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool HasPurchasedPremiumTrack() const; // 0x1116c3a0 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsCalendarEventActive(FString& EventName) const; // 0x1116c3c4 (Index: 0xd, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnCalendarEventEnded(FString& EventName); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCalendarEventStarted(FString& EventName); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnExitPremiumUpsellScreen(); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnFirstViewAfterCompletion(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRewardPreviewItemChanged(UFortAccountItemDefinition*& const Item, bool& const bFreeTrack); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRewardTrackReady(); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void OnScreenViewChanged(EEventScreenView& const PrevScreenView, EEventScreenView& const NewScreenView); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetBonusInfo(const FBonusInfoMiniTagData BonusInfo); // 0x288a61c (Index: 0x15, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnShowPremiumUpsellScreen(); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual void RegisterLayoutSlots(); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    void SetCurrentView(EEventScreenView& const View); // 0x1116c9c4 (Index: 0x18, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void SetItemShopCallout(const FText ItemShopCalloutText); // 0x288a61c (Index: 0x19, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void SetItemShopOfferInfoVisibility(bool& bIsVisible); // 0x288a61c (Index: 0x1a, Flags: Event|Protected|BlueprintEvent)
    virtual void SetRewardTrackLegal(const FText LegalText); // 0x288a61c (Index: 0x1b, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdateVariantCounter(int32_t& CurrentVariantIndex, int32_t& TotalNumVariants); // 0x288a61c (Index: 0x1c, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventScreenBase) == 0xbc0, "Size mismatch for UFortEventScreenBase");
static_assert(offsetof(UFortEventScreenBase, LayoutTemplateSlots) == 0x848, "Offset mismatch for UFortEventScreenBase::LayoutTemplateSlots");
static_assert(offsetof(UFortEventScreenBase, LazyImage_KeyArt) == 0x858, "Offset mismatch for UFortEventScreenBase::LazyImage_KeyArt");
static_assert(offsetof(UFortEventScreenBase, Button_ViewQuests) == 0x860, "Offset mismatch for UFortEventScreenBase::Button_ViewQuests");
static_assert(offsetof(UFortEventScreenBase, Button_MoreInfo) == 0x868, "Offset mismatch for UFortEventScreenBase::Button_MoreInfo");
static_assert(offsetof(UFortEventScreenBase, Button_PurchaseLevels) == 0x870, "Offset mismatch for UFortEventScreenBase::Button_PurchaseLevels");
static_assert(offsetof(UFortEventScreenBase, Button_Preview) == 0x878, "Offset mismatch for UFortEventScreenBase::Button_Preview");
static_assert(offsetof(UFortEventScreenBase, Button_ShowInItemShop) == 0x880, "Offset mismatch for UFortEventScreenBase::Button_ShowInItemShop");
static_assert(offsetof(UFortEventScreenBase, Button_Previous) == 0x888, "Offset mismatch for UFortEventScreenBase::Button_Previous");
static_assert(offsetof(UFortEventScreenBase, Button_Next) == 0x890, "Offset mismatch for UFortEventScreenBase::Button_Next");
static_assert(offsetof(UFortEventScreenBase, CustomText_InspectItem) == 0x898, "Offset mismatch for UFortEventScreenBase::CustomText_InspectItem");
static_assert(offsetof(UFortEventScreenBase, Panel_LoadError) == 0x8a0, "Offset mismatch for UFortEventScreenBase::Panel_LoadError");
static_assert(offsetof(UFortEventScreenBase, Button_Close) == 0x8a8, "Offset mismatch for UFortEventScreenBase::Button_Close");
static_assert(offsetof(UFortEventScreenBase, Button_CloseTouch) == 0x8b0, "Offset mismatch for UFortEventScreenBase::Button_CloseTouch");
static_assert(offsetof(UFortEventScreenBase, Button_Back) == 0x8b8, "Offset mismatch for UFortEventScreenBase::Button_Back");
static_assert(offsetof(UFortEventScreenBase, Text_DebugLoadingErrorReason) == 0x8c0, "Offset mismatch for UFortEventScreenBase::Text_DebugLoadingErrorReason");
static_assert(offsetof(UFortEventScreenBase, EventScreenData) == 0x8e0, "Offset mismatch for UFortEventScreenBase::EventScreenData");
static_assert(offsetof(UFortEventScreenBase, ActiveRewardPreviewType) == 0x8e8, "Offset mismatch for UFortEventScreenBase::ActiveRewardPreviewType");
static_assert(offsetof(UFortEventScreenBase, LoadedQuestBundle) == 0x8f0, "Offset mismatch for UFortEventScreenBase::LoadedQuestBundle");
static_assert(offsetof(UFortEventScreenBase, CachedItemVM) == 0x8f8, "Offset mismatch for UFortEventScreenBase::CachedItemVM");
static_assert(offsetof(UFortEventScreenBase, VariantManager) == 0x900, "Offset mismatch for UFortEventScreenBase::VariantManager");

// Size: 0x478 (Inherited: 0x438, Single: 0x40)
class UEventScreenListView : public UListViewBase
{
public:
    uint8_t Pad_290[0xe8]; // 0x290 (Size: 0xe8, Type: PaddingProperty)
    uint8_t OnProgressBarAnimationStartedEvent[0x10]; // 0x378 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnProgressBarAnimationCompletedEvent[0x10]; // 0x388 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnProgressBarAnimationInterruptedEvent[0x10]; // 0x398 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnResourcePreviewOffsetAnimationEvent[0x10]; // 0x3a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3b8[0x20]; // 0x3b8 (Size: 0x20, Type: PaddingProperty)
    UClass* RewardTrackWidgetClass; // 0x3d8 (Size: 0x8, Type: ClassProperty)
    UClass* SpacerWidgetClass; // 0x3e0 (Size: 0x8, Type: ClassProperty)
    float EntrySpacing; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    bool bCenterSelection; // 0x3ec (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ed[0x3]; // 0x3ed (Size: 0x3, Type: PaddingProperty)
    float MaxItemsInView; // 0x3f0 (Size: 0x4, Type: FloatProperty)
    bool bPreviewMode; // 0x3f4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3f5[0x3]; // 0x3f5 (Size: 0x3, Type: PaddingProperty)
    UCurveFloat* ProgressAnimationCurve; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    bool bCanAnimateOnceComplete; // 0x400 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_401[0x77]; // 0x401 (Size: 0x77, Type: PaddingProperty)

public:
    void SetNativeTickAllowed(bool& const bAllowed); // 0x1116caf0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

protected:
    UFortEventScreenData* GetEventScreenData() const; // 0x1116bb88 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEventScreenListView) == 0x478, "Size mismatch for UEventScreenListView");
static_assert(offsetof(UEventScreenListView, OnProgressBarAnimationStartedEvent) == 0x378, "Offset mismatch for UEventScreenListView::OnProgressBarAnimationStartedEvent");
static_assert(offsetof(UEventScreenListView, OnProgressBarAnimationCompletedEvent) == 0x388, "Offset mismatch for UEventScreenListView::OnProgressBarAnimationCompletedEvent");
static_assert(offsetof(UEventScreenListView, OnProgressBarAnimationInterruptedEvent) == 0x398, "Offset mismatch for UEventScreenListView::OnProgressBarAnimationInterruptedEvent");
static_assert(offsetof(UEventScreenListView, OnResourcePreviewOffsetAnimationEvent) == 0x3a8, "Offset mismatch for UEventScreenListView::OnResourcePreviewOffsetAnimationEvent");
static_assert(offsetof(UEventScreenListView, RewardTrackWidgetClass) == 0x3d8, "Offset mismatch for UEventScreenListView::RewardTrackWidgetClass");
static_assert(offsetof(UEventScreenListView, SpacerWidgetClass) == 0x3e0, "Offset mismatch for UEventScreenListView::SpacerWidgetClass");
static_assert(offsetof(UEventScreenListView, EntrySpacing) == 0x3e8, "Offset mismatch for UEventScreenListView::EntrySpacing");
static_assert(offsetof(UEventScreenListView, bCenterSelection) == 0x3ec, "Offset mismatch for UEventScreenListView::bCenterSelection");
static_assert(offsetof(UEventScreenListView, MaxItemsInView) == 0x3f0, "Offset mismatch for UEventScreenListView::MaxItemsInView");
static_assert(offsetof(UEventScreenListView, bPreviewMode) == 0x3f4, "Offset mismatch for UEventScreenListView::bPreviewMode");
static_assert(offsetof(UEventScreenListView, ProgressAnimationCurve) == 0x3f8, "Offset mismatch for UEventScreenListView::ProgressAnimationCurve");
static_assert(offsetof(UEventScreenListView, bCanAnimateOnceComplete) == 0x400, "Offset mismatch for UEventScreenListView::bCanAnimateOnceComplete");

// Size: 0x5b8 (Inherited: 0x15f0, Single: 0xffffefc8)
class UFortEventScreenTeaser : public UFortActivatablePanel
{
public:
    FString CountdownCalendarEventFlag; // 0x578 (Size: 0x10, Type: StrProperty)
    TArray<FString> CalendarEvents; // 0x588 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag QuestCategoryTag; // 0x598 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_59c[0x4]; // 0x59c (Size: 0x4, Type: PaddingProperty)
    UCommonButtonBase* Button_ViewQuests; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5a8[0x10]; // 0x5a8 (Size: 0x10, Type: PaddingProperty)

private:
    void HandleActiveSeasonDataChanged(const TArray<FString> ActiveEventFlags); // 0x1116bdbc (Index: 0x1, Flags: Final|Native|Private|HasOutParms)

protected:
    virtual void BP_SetCountdownTimeRemaining(const FTimespan TimeRemaining); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    bool IsCalendarEventActive(FString& EventName) const; // 0x1116c6c4 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnCalendarEventEnded(FString& EventName); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCalendarEventStarted(FString& EventName); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventScreenTeaser) == 0x5b8, "Size mismatch for UFortEventScreenTeaser");
static_assert(offsetof(UFortEventScreenTeaser, CountdownCalendarEventFlag) == 0x578, "Offset mismatch for UFortEventScreenTeaser::CountdownCalendarEventFlag");
static_assert(offsetof(UFortEventScreenTeaser, CalendarEvents) == 0x588, "Offset mismatch for UFortEventScreenTeaser::CalendarEvents");
static_assert(offsetof(UFortEventScreenTeaser, QuestCategoryTag) == 0x598, "Offset mismatch for UFortEventScreenTeaser::QuestCategoryTag");
static_assert(offsetof(UFortEventScreenTeaser, Button_ViewQuests) == 0x5a0, "Offset mismatch for UFortEventScreenTeaser::Button_ViewQuests");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UEventScreenVariantManager : public UObject
{
public:
};

static_assert(sizeof(UEventScreenVariantManager) == 0x70, "Size mismatch for UEventScreenVariantManager");

// Size: 0x310 (Inherited: 0x458, Single: 0xfffffeb8)
class UFortEventTokenCollectionWidget : public UUserWidget
{
public:
    UCommonLazyImage* LazyImage_GhostIcon; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_CompletedIcon; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Glow; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UTexture2D*> FallbackBrush; // 0x2c8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortTokenType*> TokenDefinition; // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_308[0x8]; // 0x308 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void OnRefreshIcon(bool& const IsCollected, bool& const bIsFirstViewAfterCollection); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventTokenCollectionWidget) == 0x310, "Size mismatch for UFortEventTokenCollectionWidget");
static_assert(offsetof(UFortEventTokenCollectionWidget, LazyImage_GhostIcon) == 0x2b0, "Offset mismatch for UFortEventTokenCollectionWidget::LazyImage_GhostIcon");
static_assert(offsetof(UFortEventTokenCollectionWidget, LazyImage_CompletedIcon) == 0x2b8, "Offset mismatch for UFortEventTokenCollectionWidget::LazyImage_CompletedIcon");
static_assert(offsetof(UFortEventTokenCollectionWidget, Image_Glow) == 0x2c0, "Offset mismatch for UFortEventTokenCollectionWidget::Image_Glow");
static_assert(offsetof(UFortEventTokenCollectionWidget, FallbackBrush) == 0x2c8, "Offset mismatch for UFortEventTokenCollectionWidget::FallbackBrush");
static_assert(offsetof(UFortEventTokenCollectionWidget, TokenDefinition) == 0x2e8, "Offset mismatch for UFortEventTokenCollectionWidget::TokenDefinition");

// Size: 0x2b8 (Inherited: 0x458, Single: 0xfffffe60)
class UFortEventTrackerModule : public UUserWidget
{
public:

protected:
    UFortEventScreenData* GetEventScreenData() const; // 0xf6383cc (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnModuleInitialized(UFortEventScreenData*& const InEventScreenData); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule) == 0x2b8, "Size mismatch for UFortEventTrackerModule");

// Size: 0x2b8 (Inherited: 0x710, Single: 0xfffffba8)
class UFortEventTrackerModule_EventDetails : public UFortEventTrackerModule
{
public:

public:
    virtual void UpdateEventTimeRemaining(const FText EventTimeRemainingText, const FTimespan TimeRemaining); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)

protected:
    virtual void OnPopulateEventDetailsText(const FText OutEventName, const FText OutEventDescription); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_EventDetails) == 0x2b8, "Size mismatch for UFortEventTrackerModule_EventDetails");

// Size: 0x2b8 (Inherited: 0x710, Single: 0xfffffba8)
class UFortEventTrackerModule_Header : public UFortEventTrackerModule
{
public:

public:
    virtual void OnPopulateEventResourceHeader(const FText Header, int32_t& const ResourceValue); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnPopulateEventResourceStarterHeader(const FText Header); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_Header) == 0x2b8, "Size mismatch for UFortEventTrackerModule_Header");

// Size: 0x2c0 (Inherited: 0x710, Single: 0xfffffbb0)
class UFortEventTrackerModule_RewardDetails : public UFortEventTrackerModule
{
public:

public:
    virtual void OnPopulateCompletedReward(const TArray<FText> RewardNames); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnPopulateNextRewardDetails(const TArray<FText> RewardNames, int32_t& const ResourceNeeded); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintEvent)

protected:
    bool IsPremiumTrackOwned() const; // 0xf638294 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortEventTrackerModule_RewardDetails) == 0x2c0, "Size mismatch for UFortEventTrackerModule_RewardDetails");

// Size: 0x2d8 (Inherited: 0x710, Single: 0xfffffbc8)
class UFortEventTrackerModule_RewardRemaining : public UFortEventTrackerModule
{
public:
    UCommonButtonBase* Button_PurchasePremium; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c0[0x18]; // 0x2c0 (Size: 0x18, Type: PaddingProperty)

public:
    virtual void OnPopulateRemaining(int32_t& const ResourceNeeded, int32_t& const TotalResourceRequired, bool& const bRequiresPremiumTrackPurchase); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_RewardRemaining) == 0x2d8, "Size mismatch for UFortEventTrackerModule_RewardRemaining");
static_assert(offsetof(UFortEventTrackerModule_RewardRemaining, Button_PurchasePremium) == 0x2b8, "Offset mismatch for UFortEventTrackerModule_RewardRemaining::Button_PurchasePremium");

// Size: 0x2c0 (Inherited: 0x710, Single: 0xfffffbb0)
class UFortEventTrackerModule_ProgressiveRewards : public UFortEventTrackerModule
{
public:
    UEventScreenListView* ListView_Rewards; // 0x2b8 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnPopulateCompletionMessage(bool& const bIsComplete, const FText CompletionText); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_ProgressiveRewards) == 0x2c0, "Size mismatch for UFortEventTrackerModule_ProgressiveRewards");
static_assert(offsetof(UFortEventTrackerModule_ProgressiveRewards, ListView_Rewards) == 0x2b8, "Offset mismatch for UFortEventTrackerModule_ProgressiveRewards::ListView_Rewards");

// Size: 0x2b8 (Inherited: 0x710, Single: 0xfffffba8)
class UFortEventTrackerModule_Collection : public UFortEventTrackerModule
{
public:

protected:
    virtual void OnGatherTokenCollectionWidgets(TArray<UFortEventTokenCollectionWidget*>& OutCollectionWidgets) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent|Const)
};

static_assert(sizeof(UFortEventTrackerModule_Collection) == 0x2b8, "Size mismatch for UFortEventTrackerModule_Collection");

// Size: 0x2c0 (Inherited: 0x710, Single: 0xfffffbb0)
class UFortEventTrackerModule_Banner : public UFortEventTrackerModule
{
public:
    UFortLazyImage* LazyImage_BannerArt; // 0x2b8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnCTACompleted(bool& const bIsComplete); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPopulateBannerText(const FText BannerText); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnPopulateHeaderCTAText(const FText HeaderCTAText); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_Banner) == 0x2c0, "Size mismatch for UFortEventTrackerModule_Banner");
static_assert(offsetof(UFortEventTrackerModule_Banner, LazyImage_BannerArt) == 0x2b8, "Offset mismatch for UFortEventTrackerModule_Banner::LazyImage_BannerArt");

// Size: 0x318 (Inherited: 0x710, Single: 0xfffffc08)
class UFortEventTrackerModule_PremiumUpsell : public UFortEventTrackerModule
{
public:
    UFortCTAButton* Button_Prompt; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    FText PromptTextUnowned; // 0x2c0 (Size: 0x10, Type: TextProperty)
    FText PromptTextOwned; // 0x2d0 (Size: 0x10, Type: TextProperty)
    uint8_t Pad_2e0[0x38]; // 0x2e0 (Size: 0x38, Type: PaddingProperty)

protected:
    bool IsPremiumTrackOwned() const; // 0x10d24338 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnIconLoaded(UTexture*& const LoadedTexture); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPopulateText(const FText HeaderText, const FText BodyText); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_PremiumUpsell) == 0x318, "Size mismatch for UFortEventTrackerModule_PremiumUpsell");
static_assert(offsetof(UFortEventTrackerModule_PremiumUpsell, Button_Prompt) == 0x2b8, "Offset mismatch for UFortEventTrackerModule_PremiumUpsell::Button_Prompt");
static_assert(offsetof(UFortEventTrackerModule_PremiumUpsell, PromptTextUnowned) == 0x2c0, "Offset mismatch for UFortEventTrackerModule_PremiumUpsell::PromptTextUnowned");
static_assert(offsetof(UFortEventTrackerModule_PremiumUpsell, PromptTextOwned) == 0x2d0, "Offset mismatch for UFortEventTrackerModule_PremiumUpsell::PromptTextOwned");

// Size: 0x2b8 (Inherited: 0x710, Single: 0xfffffba8)
class UFortEventTrackerModule_CustomText : public UFortEventTrackerModule
{
public:

public:
    virtual void OnPopulateText(const FText CustomText); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEventTrackerModule_CustomText) == 0x2b8, "Size mismatch for UFortEventTrackerModule_CustomText");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FEventItemOverride
{
    TSoftObjectPtr<UFortItemDefinition*> ItemDefinition; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> CustomItemTexture; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> CustomItemTextureMobile; // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsDoubleWidth; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FEventItemOverride) == 0x68, "Size mismatch for FEventItemOverride");
static_assert(offsetof(FEventItemOverride, ItemDefinition) == 0x0, "Offset mismatch for FEventItemOverride::ItemDefinition");
static_assert(offsetof(FEventItemOverride, CustomItemTexture) == 0x20, "Offset mismatch for FEventItemOverride::CustomItemTexture");
static_assert(offsetof(FEventItemOverride, CustomItemTextureMobile) == 0x40, "Offset mismatch for FEventItemOverride::CustomItemTextureMobile");
static_assert(offsetof(FEventItemOverride, bIsDoubleWidth) == 0x60, "Offset mismatch for FEventItemOverride::bIsDoubleWidth");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEventScreenTrackData
{
    FLinearColor TrackColorPrimary; // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor TrackColorSecondary; // 0x10 (Size: 0x10, Type: StructProperty)
    FLinearColor TrackColorTertiary; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FEventScreenTrackData) == 0x30, "Size mismatch for FEventScreenTrackData");
static_assert(offsetof(FEventScreenTrackData, TrackColorPrimary) == 0x0, "Offset mismatch for FEventScreenTrackData::TrackColorPrimary");
static_assert(offsetof(FEventScreenTrackData, TrackColorSecondary) == 0x10, "Offset mismatch for FEventScreenTrackData::TrackColorSecondary");
static_assert(offsetof(FEventScreenTrackData, TrackColorTertiary) == 0x20, "Offset mismatch for FEventScreenTrackData::TrackColorTertiary");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FEventScreenMoreInfoGroup
{
    FText Header; // 0x0 (Size: 0x10, Type: TextProperty)
    FText Body; // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject*> Icon; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FEventScreenMoreInfoGroup) == 0x40, "Size mismatch for FEventScreenMoreInfoGroup");
static_assert(offsetof(FEventScreenMoreInfoGroup, Header) == 0x0, "Offset mismatch for FEventScreenMoreInfoGroup::Header");
static_assert(offsetof(FEventScreenMoreInfoGroup, Body) == 0x10, "Offset mismatch for FEventScreenMoreInfoGroup::Body");
static_assert(offsetof(FEventScreenMoreInfoGroup, Icon) == 0x20, "Offset mismatch for FEventScreenMoreInfoGroup::Icon");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEventScreenCMSMoreInfoGroup
{
    FText Header; // 0x0 (Size: 0x10, Type: TextProperty)
    FText Body; // 0x10 (Size: 0x10, Type: TextProperty)
    FString IconURL; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEventScreenCMSMoreInfoGroup) == 0x30, "Size mismatch for FEventScreenCMSMoreInfoGroup");
static_assert(offsetof(FEventScreenCMSMoreInfoGroup, Header) == 0x0, "Offset mismatch for FEventScreenCMSMoreInfoGroup::Header");
static_assert(offsetof(FEventScreenCMSMoreInfoGroup, Body) == 0x10, "Offset mismatch for FEventScreenCMSMoreInfoGroup::Body");
static_assert(offsetof(FEventScreenCMSMoreInfoGroup, IconURL) == 0x20, "Offset mismatch for FEventScreenCMSMoreInfoGroup::IconURL");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEventScreenCMSResourceGroupOverride
{
    int32_t ResourceValue; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString KeyArtOverrideURL; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEventScreenCMSResourceGroupOverride) == 0x18, "Size mismatch for FEventScreenCMSResourceGroupOverride");
static_assert(offsetof(FEventScreenCMSResourceGroupOverride, ResourceValue) == 0x0, "Offset mismatch for FEventScreenCMSResourceGroupOverride::ResourceValue");
static_assert(offsetof(FEventScreenCMSResourceGroupOverride, KeyArtOverrideURL) == 0x8, "Offset mismatch for FEventScreenCMSResourceGroupOverride::KeyArtOverrideURL");

// Size: 0x200 (Inherited: 0x0, Single: 0x200)
struct FEventScreenCMSData
{
    FString EventCMSId; // 0x0 (Size: 0x10, Type: StrProperty)
    FText EventName; // 0x10 (Size: 0x10, Type: TextProperty)
    FText EventDescription; // 0x20 (Size: 0x10, Type: TextProperty)
    FText ResourceHeader; // 0x30 (Size: 0x10, Type: TextProperty)
    FText StarterHeader; // 0x40 (Size: 0x10, Type: TextProperty)
    FText CompletionHeader; // 0x50 (Size: 0x10, Type: TextProperty)
    FText EventCTA; // 0x60 (Size: 0x10, Type: TextProperty)
    FText EventCTACompleted; // 0x70 (Size: 0x10, Type: TextProperty)
    FText HeaderCTA; // 0x80 (Size: 0x10, Type: TextProperty)
    FText ItemShopCallout; // 0x90 (Size: 0x10, Type: TextProperty)
    FString CTAIconURL; // 0xa0 (Size: 0x10, Type: StrProperty)
    FString KeyArtURL; // 0xb0 (Size: 0x10, Type: StrProperty)
    FText MoreInfoHeader; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText MoreInfoSubHeader; // 0xd0 (Size: 0x10, Type: TextProperty)
    FString MoreInfoKeyArtURL; // 0xe0 (Size: 0x10, Type: StrProperty)
    FText MoreInfoLegal; // 0xf0 (Size: 0x10, Type: TextProperty)
    TArray<FEventScreenCMSMoreInfoGroup> MoreInfoGroups; // 0x100 (Size: 0x10, Type: ArrayProperty)
    FText PurchaseLegal; // 0x110 (Size: 0x10, Type: TextProperty)
    FText RewardTrackLegal; // 0x120 (Size: 0x10, Type: TextProperty)
    FString ItemShopOfferId; // 0x130 (Size: 0x10, Type: StrProperty)
    FText PremiumUpsellUnownedHeader; // 0x140 (Size: 0x10, Type: TextProperty)
    FText PremiumUpsellUnownedBody; // 0x150 (Size: 0x10, Type: TextProperty)
    FText PremiumUpsellOwnedHeader; // 0x160 (Size: 0x10, Type: TextProperty)
    FText PremiumUpsellOwnedBody; // 0x170 (Size: 0x10, Type: TextProperty)
    FString PremiumUpsellIconURL; // 0x180 (Size: 0x10, Type: StrProperty)
    FText PurchasePremiumTrackHeader; // 0x190 (Size: 0x10, Type: TextProperty)
    TArray<FText> PurchasePremiumTrackBodyList; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    FText InspectSpecialItemUnowned; // 0x1b0 (Size: 0x10, Type: TextProperty)
    FText InspectSpecialItemOwned; // 0x1c0 (Size: 0x10, Type: TextProperty)
    FText InspectSpecialPremiumItemUnowned; // 0x1d0 (Size: 0x10, Type: TextProperty)
    FText InspectSpecialPremiumItemOwned; // 0x1e0 (Size: 0x10, Type: TextProperty)
    TArray<FEventScreenCMSResourceGroupOverride> ResourceGroupOverrides; // 0x1f0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEventScreenCMSData) == 0x200, "Size mismatch for FEventScreenCMSData");
static_assert(offsetof(FEventScreenCMSData, EventCMSId) == 0x0, "Offset mismatch for FEventScreenCMSData::EventCMSId");
static_assert(offsetof(FEventScreenCMSData, EventName) == 0x10, "Offset mismatch for FEventScreenCMSData::EventName");
static_assert(offsetof(FEventScreenCMSData, EventDescription) == 0x20, "Offset mismatch for FEventScreenCMSData::EventDescription");
static_assert(offsetof(FEventScreenCMSData, ResourceHeader) == 0x30, "Offset mismatch for FEventScreenCMSData::ResourceHeader");
static_assert(offsetof(FEventScreenCMSData, StarterHeader) == 0x40, "Offset mismatch for FEventScreenCMSData::StarterHeader");
static_assert(offsetof(FEventScreenCMSData, CompletionHeader) == 0x50, "Offset mismatch for FEventScreenCMSData::CompletionHeader");
static_assert(offsetof(FEventScreenCMSData, EventCTA) == 0x60, "Offset mismatch for FEventScreenCMSData::EventCTA");
static_assert(offsetof(FEventScreenCMSData, EventCTACompleted) == 0x70, "Offset mismatch for FEventScreenCMSData::EventCTACompleted");
static_assert(offsetof(FEventScreenCMSData, HeaderCTA) == 0x80, "Offset mismatch for FEventScreenCMSData::HeaderCTA");
static_assert(offsetof(FEventScreenCMSData, ItemShopCallout) == 0x90, "Offset mismatch for FEventScreenCMSData::ItemShopCallout");
static_assert(offsetof(FEventScreenCMSData, CTAIconURL) == 0xa0, "Offset mismatch for FEventScreenCMSData::CTAIconURL");
static_assert(offsetof(FEventScreenCMSData, KeyArtURL) == 0xb0, "Offset mismatch for FEventScreenCMSData::KeyArtURL");
static_assert(offsetof(FEventScreenCMSData, MoreInfoHeader) == 0xc0, "Offset mismatch for FEventScreenCMSData::MoreInfoHeader");
static_assert(offsetof(FEventScreenCMSData, MoreInfoSubHeader) == 0xd0, "Offset mismatch for FEventScreenCMSData::MoreInfoSubHeader");
static_assert(offsetof(FEventScreenCMSData, MoreInfoKeyArtURL) == 0xe0, "Offset mismatch for FEventScreenCMSData::MoreInfoKeyArtURL");
static_assert(offsetof(FEventScreenCMSData, MoreInfoLegal) == 0xf0, "Offset mismatch for FEventScreenCMSData::MoreInfoLegal");
static_assert(offsetof(FEventScreenCMSData, MoreInfoGroups) == 0x100, "Offset mismatch for FEventScreenCMSData::MoreInfoGroups");
static_assert(offsetof(FEventScreenCMSData, PurchaseLegal) == 0x110, "Offset mismatch for FEventScreenCMSData::PurchaseLegal");
static_assert(offsetof(FEventScreenCMSData, RewardTrackLegal) == 0x120, "Offset mismatch for FEventScreenCMSData::RewardTrackLegal");
static_assert(offsetof(FEventScreenCMSData, ItemShopOfferId) == 0x130, "Offset mismatch for FEventScreenCMSData::ItemShopOfferId");
static_assert(offsetof(FEventScreenCMSData, PremiumUpsellUnownedHeader) == 0x140, "Offset mismatch for FEventScreenCMSData::PremiumUpsellUnownedHeader");
static_assert(offsetof(FEventScreenCMSData, PremiumUpsellUnownedBody) == 0x150, "Offset mismatch for FEventScreenCMSData::PremiumUpsellUnownedBody");
static_assert(offsetof(FEventScreenCMSData, PremiumUpsellOwnedHeader) == 0x160, "Offset mismatch for FEventScreenCMSData::PremiumUpsellOwnedHeader");
static_assert(offsetof(FEventScreenCMSData, PremiumUpsellOwnedBody) == 0x170, "Offset mismatch for FEventScreenCMSData::PremiumUpsellOwnedBody");
static_assert(offsetof(FEventScreenCMSData, PremiumUpsellIconURL) == 0x180, "Offset mismatch for FEventScreenCMSData::PremiumUpsellIconURL");
static_assert(offsetof(FEventScreenCMSData, PurchasePremiumTrackHeader) == 0x190, "Offset mismatch for FEventScreenCMSData::PurchasePremiumTrackHeader");
static_assert(offsetof(FEventScreenCMSData, PurchasePremiumTrackBodyList) == 0x1a0, "Offset mismatch for FEventScreenCMSData::PurchasePremiumTrackBodyList");
static_assert(offsetof(FEventScreenCMSData, InspectSpecialItemUnowned) == 0x1b0, "Offset mismatch for FEventScreenCMSData::InspectSpecialItemUnowned");
static_assert(offsetof(FEventScreenCMSData, InspectSpecialItemOwned) == 0x1c0, "Offset mismatch for FEventScreenCMSData::InspectSpecialItemOwned");
static_assert(offsetof(FEventScreenCMSData, InspectSpecialPremiumItemUnowned) == 0x1d0, "Offset mismatch for FEventScreenCMSData::InspectSpecialPremiumItemUnowned");
static_assert(offsetof(FEventScreenCMSData, InspectSpecialPremiumItemOwned) == 0x1e0, "Offset mismatch for FEventScreenCMSData::InspectSpecialPremiumItemOwned");
static_assert(offsetof(FEventScreenCMSData, ResourceGroupOverrides) == 0x1f0, "Offset mismatch for FEventScreenCMSData::ResourceGroupOverrides");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEventScreenCMSGroup
{
    TMap<FEventScreenCMSData, FString> EventScreens; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FEventScreenCMSGroup) == 0x50, "Size mismatch for FEventScreenCMSGroup");
static_assert(offsetof(FEventScreenCMSGroup, EventScreens) == 0x0, "Offset mismatch for FEventScreenCMSGroup::EventScreens");

