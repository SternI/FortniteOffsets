/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortOvershieldHelpers
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0x160 (Inherited: 0xe0, Single: 0x80)
class UFortOvershieldHelperComponent : public UActorComponent
{
public:

public:
    static void AssignOvershieldListenerDelegates(UGameplayAbility*& OwningAbility, FFortOvershieldDelegateContainer& Delegates); // 0x1128aa7c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ClearOvershieldListenerDelegates(UGameplayAbility*& OwningAbility); // 0x1128ac44 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UFortOvershieldHelperComponent) == 0x160, "Size mismatch for UFortOvershieldHelperComponent");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FFortOvershieldDelegateContainer
{
    uint8_t OnOvershieldChanged[0xc]; // 0x0 (Size: 0xc, Type: DelegateProperty)
    uint8_t OnShieldedDamage[0xc]; // 0xc (Size: 0xc, Type: DelegateProperty)
    uint8_t OnOvershieldedDamage[0xc]; // 0x18 (Size: 0xc, Type: DelegateProperty)
    uint8_t OnShieldDestroyed[0xc]; // 0x24 (Size: 0xc, Type: DelegateProperty)
    uint8_t OnOvershieldDestroyed[0xc]; // 0x30 (Size: 0xc, Type: DelegateProperty)
    uint8_t OnDamageReceived[0xc]; // 0x3c (Size: 0xc, Type: DelegateProperty)
};

static_assert(sizeof(FFortOvershieldDelegateContainer) == 0x48, "Size mismatch for FFortOvershieldDelegateContainer");
static_assert(offsetof(FFortOvershieldDelegateContainer, OnOvershieldChanged) == 0x0, "Offset mismatch for FFortOvershieldDelegateContainer::OnOvershieldChanged");
static_assert(offsetof(FFortOvershieldDelegateContainer, OnShieldedDamage) == 0xc, "Offset mismatch for FFortOvershieldDelegateContainer::OnShieldedDamage");
static_assert(offsetof(FFortOvershieldDelegateContainer, OnOvershieldedDamage) == 0x18, "Offset mismatch for FFortOvershieldDelegateContainer::OnOvershieldedDamage");
static_assert(offsetof(FFortOvershieldDelegateContainer, OnShieldDestroyed) == 0x24, "Offset mismatch for FFortOvershieldDelegateContainer::OnShieldDestroyed");
static_assert(offsetof(FFortOvershieldDelegateContainer, OnOvershieldDestroyed) == 0x30, "Offset mismatch for FFortOvershieldDelegateContainer::OnOvershieldDestroyed");
static_assert(offsetof(FFortOvershieldDelegateContainer, OnDamageReceived) == 0x3c, "Offset mismatch for FFortOvershieldDelegateContainer::OnDamageReceived");

