/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortFirstPersonModeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimationBudgetAllocator.h"

// Size: 0x5b0 (Inherited: 0xf20, Single: 0xfffff690)
class AFortFirstPersonMode_CameraController : public AFortFirstPersonCameraController
{
public:
    float HeadMotionScalar; // 0x518 (Size: 0x4, Type: FloatProperty)
    bool bDisplayReticleWhileADS; // 0x51c (Size: 0x1, Type: BoolProperty)
    bool bDisplayAmmoCountWhileADS; // 0x51d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51e[0x2]; // 0x51e (Size: 0x2, Type: PaddingProperty)
    TArray<UClass*> AllowedWeaponClassList; // 0x520 (Size: 0x10, Type: ArrayProperty)
    UMaterialParameterCollection* MaterialParameterCollection; // 0x530 (Size: 0x8, Type: ObjectProperty)
    FName FP_MaterialParameterName; // 0x538 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_53c[0x4]; // 0x53c (Size: 0x4, Type: PaddingProperty)
    UCustomCharacterPart* DefaultGauntletPart; // 0x540 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* FirstPersonSkeletalMeshComp; // 0x548 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* KicksSkeletalMeshComp; // 0x550 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* GauntletSkeletalMeshComp; // 0x558 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* ThirdPersonWeaponMeshComp; // 0x560 (Size: 0x8, Type: ObjectProperty)
    float CameraYawClampAngleForStasis; // 0x568 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_56c[0x4]; // 0x56c (Size: 0x4, Type: PaddingProperty)
    UClass* CachedOutgoingCameraMode; // 0x570 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_578[0x38]; // 0x578 (Size: 0x38, Type: PaddingProperty)

private:
    void HandleWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x11a68400 (Index: 0x4, Flags: Final|Native|Private)
    void OnEmoteEnded(UFortItemDefinition*& const MontageItemDef, AFortPawn*& PawnEmoting); // 0xa93bc70 (Index: 0x5, Flags: Final|Native|Private)
    void OnEmoteStarted(UFortItemDefinition*& const MontageItemDef, AFortPawn*& PawnEmoting); // 0xa93bc70 (Index: 0x6, Flags: Final|Native|Private)
    void OnWeaponHolstered(); // 0x11a68630 (Index: 0xa, Flags: Final|Native|Private)
    void OnWeaponUnHolstered(); // 0x11a68644 (Index: 0xb, Flags: Final|Native|Private)
    void SetWeaponModMeshesFirstPersonVisibility(UFortWeaponModItemDefinition*& Mod, AFortWeapon*& Weapon); // 0x11a68abc (Index: 0xe, Flags: Final|Native|Private)

protected:
    void AssignFirstPersonMesh(AFortPlayerPawn*& FortPlayerPawn); // 0x11a68180 (Index: 0x0, Flags: Final|Native|Protected)
    void AssignGauntletsMesh(); // 0x11a682ac (Index: 0x1, Flags: Final|Native|Protected)
    void AssignKicksMesh(AFortPlayerPawn*& FortPlayerPawn); // 0x11a682c0 (Index: 0x2, Flags: Final|Native|Protected)
    void CreateFirstPersonProxyMeshes(); // 0x11a683ec (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnLocalPlayerVisibilityChanged(AFortPlayerController*& PC, bool& const bShouldBeVisible); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    void OnRep_DisplayAmmoCountWhileADS(); // 0x11a68608 (Index: 0x8, Flags: Final|Native|Protected)
    void OnRep_DisplayReticleWhileADS(); // 0x11a6861c (Index: 0x9, Flags: Final|Native|Protected)
    void PostResGauntletVisibility(AFortPlayerPawn*& Pawn); // 0x11a68658 (Index: 0xc, Flags: Final|Native|Protected)
    void SetVisibilityForProxyMeshes(AFortPlayerController*& PC, bool& const bNewVisibility); // 0x11a68784 (Index: 0xd, Flags: Final|Native|Protected|BlueprintCallable)
    void SetWPOEnabled(bool& const bEnable); // 0x11a68990 (Index: 0xf, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateCharacterMeshMaterials(AFortPlayerPawn*& FortPlayerPawn); // 0x11a68cc4 (Index: 0x10, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AFortFirstPersonMode_CameraController) == 0x5b0, "Size mismatch for AFortFirstPersonMode_CameraController");
static_assert(offsetof(AFortFirstPersonMode_CameraController, HeadMotionScalar) == 0x518, "Offset mismatch for AFortFirstPersonMode_CameraController::HeadMotionScalar");
static_assert(offsetof(AFortFirstPersonMode_CameraController, bDisplayReticleWhileADS) == 0x51c, "Offset mismatch for AFortFirstPersonMode_CameraController::bDisplayReticleWhileADS");
static_assert(offsetof(AFortFirstPersonMode_CameraController, bDisplayAmmoCountWhileADS) == 0x51d, "Offset mismatch for AFortFirstPersonMode_CameraController::bDisplayAmmoCountWhileADS");
static_assert(offsetof(AFortFirstPersonMode_CameraController, AllowedWeaponClassList) == 0x520, "Offset mismatch for AFortFirstPersonMode_CameraController::AllowedWeaponClassList");
static_assert(offsetof(AFortFirstPersonMode_CameraController, MaterialParameterCollection) == 0x530, "Offset mismatch for AFortFirstPersonMode_CameraController::MaterialParameterCollection");
static_assert(offsetof(AFortFirstPersonMode_CameraController, FP_MaterialParameterName) == 0x538, "Offset mismatch for AFortFirstPersonMode_CameraController::FP_MaterialParameterName");
static_assert(offsetof(AFortFirstPersonMode_CameraController, DefaultGauntletPart) == 0x540, "Offset mismatch for AFortFirstPersonMode_CameraController::DefaultGauntletPart");
static_assert(offsetof(AFortFirstPersonMode_CameraController, FirstPersonSkeletalMeshComp) == 0x548, "Offset mismatch for AFortFirstPersonMode_CameraController::FirstPersonSkeletalMeshComp");
static_assert(offsetof(AFortFirstPersonMode_CameraController, KicksSkeletalMeshComp) == 0x550, "Offset mismatch for AFortFirstPersonMode_CameraController::KicksSkeletalMeshComp");
static_assert(offsetof(AFortFirstPersonMode_CameraController, GauntletSkeletalMeshComp) == 0x558, "Offset mismatch for AFortFirstPersonMode_CameraController::GauntletSkeletalMeshComp");
static_assert(offsetof(AFortFirstPersonMode_CameraController, ThirdPersonWeaponMeshComp) == 0x560, "Offset mismatch for AFortFirstPersonMode_CameraController::ThirdPersonWeaponMeshComp");
static_assert(offsetof(AFortFirstPersonMode_CameraController, CameraYawClampAngleForStasis) == 0x568, "Offset mismatch for AFortFirstPersonMode_CameraController::CameraYawClampAngleForStasis");
static_assert(offsetof(AFortFirstPersonMode_CameraController, CachedOutgoingCameraMode) == 0x570, "Offset mismatch for AFortFirstPersonMode_CameraController::CachedOutgoingCameraMode");

// Size: 0x30 (Inherited: 0x78, Single: 0xffffffb8)
class UFortFirstPersonMode_CheatManager : public UChildCheatManager
{
public:
    UClass* CameraControllerClass; // 0x28 (Size: 0x8, Type: ClassProperty)

public:
    void EnableFpCamera(bool& const bEnable); // 0x9e6e1b8 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
    void EnableFpCameraForAllPlayers(bool& const bEnable); // 0x9e6e1b8 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
    void PrintFirstPersonPlayerInfo(); // 0x554e3c4 (Index: 0x2, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UFortFirstPersonMode_CheatManager) == 0x30, "Size mismatch for UFortFirstPersonMode_CheatManager");
static_assert(offsetof(UFortFirstPersonMode_CheatManager, CameraControllerClass) == 0x28, "Offset mismatch for UFortFirstPersonMode_CheatManager::CameraControllerClass");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCameraModeRotationClampSettings
{
};

static_assert(sizeof(FCameraModeRotationClampSettings) == 0x8, "Size mismatch for FCameraModeRotationClampSettings");

