/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BoostedJumpCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ModularGameplay.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0x1f0 (Inherited: 0x250, Single: 0xffffffa0)
class UFortControllerComponent_BoostedJump : public UControllerComponent
{
public:
    FGameplayTagContainer DefaultBlockingTags; // 0xb8 (Size: 0x20, Type: StructProperty)
    FGameplayTag BoostedJumpCanBeActivatedTag; // 0xd8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    UClass* MovementModeExtension; // 0xe0 (Size: 0x8, Type: ClassProperty)
    FFortBoostedJumpActivationConfig BoostJumpWalkingConfig; // 0xe8 (Size: 0xa0, Type: StructProperty)
    FScalableFloat BoostedJumpFeatureEnabled; // 0x188 (Size: 0x28, Type: StructProperty)
    float BoostedJumpMonitorRate; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1b4[0x3c]; // 0x1b4 (Size: 0x3c, Type: PaddingProperty)

private:
    void BindMutatorUpdatedDelegate(); // 0x112ac8f0 (Index: 0x0, Flags: Final|Native|Private)
    void EventCallback_OnJumpInput(bool& bPressed); // 0x112ac904 (Index: 0x1, Flags: Final|Native|Private)
    void EventCallback_OnMovementModeChanged(ACharacter*& Character, TEnumAsByte<EMovementMode>& PrevMovementMode, char& PreviousCustomMode); // 0x112aca30 (Index: 0x2, Flags: Final|Native|Private)
    void EventCallback_OnMutatorUpdated(); // 0x112acd14 (Index: 0x3, Flags: Final|Native|Private)
    void EventCallback_OnPawnChanged(APawn*& OldPawn, APawn*& NewPawn); // 0x112acd28 (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortControllerComponent_BoostedJump) == 0x1f0, "Size mismatch for UFortControllerComponent_BoostedJump");
static_assert(offsetof(UFortControllerComponent_BoostedJump, DefaultBlockingTags) == 0xb8, "Offset mismatch for UFortControllerComponent_BoostedJump::DefaultBlockingTags");
static_assert(offsetof(UFortControllerComponent_BoostedJump, BoostedJumpCanBeActivatedTag) == 0xd8, "Offset mismatch for UFortControllerComponent_BoostedJump::BoostedJumpCanBeActivatedTag");
static_assert(offsetof(UFortControllerComponent_BoostedJump, MovementModeExtension) == 0xe0, "Offset mismatch for UFortControllerComponent_BoostedJump::MovementModeExtension");
static_assert(offsetof(UFortControllerComponent_BoostedJump, BoostJumpWalkingConfig) == 0xe8, "Offset mismatch for UFortControllerComponent_BoostedJump::BoostJumpWalkingConfig");
static_assert(offsetof(UFortControllerComponent_BoostedJump, BoostedJumpFeatureEnabled) == 0x188, "Offset mismatch for UFortControllerComponent_BoostedJump::BoostedJumpFeatureEnabled");
static_assert(offsetof(UFortControllerComponent_BoostedJump, BoostedJumpMonitorRate) == 0x1b0, "Offset mismatch for UFortControllerComponent_BoostedJump::BoostedJumpMonitorRate");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UFortMovementMode_BoostedJumpRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_BoostedJumpRuntimeData) == 0x48, "Size mismatch for UFortMovementMode_BoostedJumpRuntimeData");

// Size: 0x300 (Inherited: 0x210, Single: 0xf0)
class UFortMovementMode_ExtLogicBoostedJump : public UFortMovementMode_BaseExtLogic
{
public:
    uint8_t Pad_1e8[0x8]; // 0x1e8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat JumpAddedVelocityMultiplier; // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpZVelocity; // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpHorizontalVelocityMax; // 0x240 (Size: 0x28, Type: StructProperty)
    float MaxTimeSpentInBoostedJump; // 0x268 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_26c[0x4]; // 0x26c (Size: 0x4, Type: PaddingProperty)
    UClass* AnimLayer; // 0x270 (Size: 0x8, Type: ClassProperty)
    UClass* CameraMode; // 0x278 (Size: 0x8, Type: ClassProperty)
    FGameplayTag CameraModeTag; // 0x280 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_284[0x4]; // 0x284 (Size: 0x4, Type: PaddingProperty)
    UClass* CameraStartShake; // 0x288 (Size: 0x8, Type: ClassProperty)
    FGameplayTag GC_BoostedJumpBeingActivated; // 0x290 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_294[0x4]; // 0x294 (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* AnimationMontage; // 0x298 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag SkipAnimationTag; // 0x2a0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2a4[0x4]; // 0x2a4 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer PreventHolsterTags; // 0x2a8 (Size: 0x20, Type: StructProperty)
    FGameplayTag AllowPrimaryFireTag; // 0x2c8 (Size: 0x4, Type: StructProperty)
    FGameplayTag AllowSecondaryFireTag; // 0x2cc (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2d0[0x30]; // 0x2d0 (Size: 0x30, Type: PaddingProperty)

private:
    void EventCallback_OnPawnLanded(const FHitResult Hit); // 0x112acf30 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void EventCallback_OnTargetingChanged(bool& bIsTargeting); // 0x112ad024 (Index: 0x1, Flags: Final|Native|Private)
    void EventCallback_OnWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x112ad150 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortMovementMode_ExtLogicBoostedJump) == 0x300, "Size mismatch for UFortMovementMode_ExtLogicBoostedJump");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, JumpAddedVelocityMultiplier) == 0x1f0, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::JumpAddedVelocityMultiplier");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, JumpZVelocity) == 0x218, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::JumpZVelocity");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, JumpHorizontalVelocityMax) == 0x240, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::JumpHorizontalVelocityMax");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, MaxTimeSpentInBoostedJump) == 0x268, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::MaxTimeSpentInBoostedJump");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, AnimLayer) == 0x270, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::AnimLayer");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, CameraMode) == 0x278, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::CameraMode");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, CameraModeTag) == 0x280, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::CameraModeTag");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, CameraStartShake) == 0x288, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::CameraStartShake");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, GC_BoostedJumpBeingActivated) == 0x290, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::GC_BoostedJumpBeingActivated");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, AnimationMontage) == 0x298, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::AnimationMontage");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, SkipAnimationTag) == 0x2a0, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::SkipAnimationTag");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, PreventHolsterTags) == 0x2a8, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::PreventHolsterTags");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, AllowPrimaryFireTag) == 0x2c8, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::AllowPrimaryFireTag");
static_assert(offsetof(UFortMovementMode_ExtLogicBoostedJump, AllowSecondaryFireTag) == 0x2cc, "Offset mismatch for UFortMovementMode_ExtLogicBoostedJump::AllowSecondaryFireTag");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FFortBoostedJumpActivationConfig
{
    FScalableFloat MinSpeedToActivate; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinTimeSpentInModeToActivate; // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat EdgeMinHeightToTheGround; // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat EdgeForwardPredictionMultiplier; // 0x78 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FFortBoostedJumpActivationConfig) == 0xa0, "Size mismatch for FFortBoostedJumpActivationConfig");
static_assert(offsetof(FFortBoostedJumpActivationConfig, MinSpeedToActivate) == 0x0, "Offset mismatch for FFortBoostedJumpActivationConfig::MinSpeedToActivate");
static_assert(offsetof(FFortBoostedJumpActivationConfig, MinTimeSpentInModeToActivate) == 0x28, "Offset mismatch for FFortBoostedJumpActivationConfig::MinTimeSpentInModeToActivate");
static_assert(offsetof(FFortBoostedJumpActivationConfig, EdgeMinHeightToTheGround) == 0x50, "Offset mismatch for FFortBoostedJumpActivationConfig::EdgeMinHeightToTheGround");
static_assert(offsetof(FFortBoostedJumpActivationConfig, EdgeForwardPredictionMultiplier) == 0x78, "Offset mismatch for FFortBoostedJumpActivationConfig::EdgeForwardPredictionMultiplier");

