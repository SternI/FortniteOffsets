/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayTasks
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UGameplayTask : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FName InstanceName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x2]; // 0x34 (Size: 0x2, Type: PaddingProperty)
    uint8_t ResourceOverlapPolicy; // 0x36 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_37[0x21]; // 0x37 (Size: 0x21, Type: PaddingProperty)
    UGameplayTask* ChildTask; // 0x58 (Size: 0x8, Type: ObjectProperty)

public:
    void EndTask(); // 0xaeb4e20 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void GenericGameplayTaskDelegate__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    void ReadyForActivation(); // 0xaeb5874 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayTask) == 0x60, "Size mismatch for UGameplayTask");
static_assert(offsetof(UGameplayTask, InstanceName) == 0x30, "Offset mismatch for UGameplayTask::InstanceName");
static_assert(offsetof(UGameplayTask, ResourceOverlapPolicy) == 0x36, "Offset mismatch for UGameplayTask::ResourceOverlapPolicy");
static_assert(offsetof(UGameplayTask, ChildTask) == 0x58, "Offset mismatch for UGameplayTask::ChildTask");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayTaskOwnerInterface : public UInterface
{
public:
};

static_assert(sizeof(UGameplayTaskOwnerInterface) == 0x28, "Size mismatch for UGameplayTaskOwnerInterface");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGameplayTaskResource : public UObject
{
public:
    int32_t ManualResourceID; // 0x28 (Size: 0x4, Type: IntProperty)
    int8_t AutoResourceID; // 0x2c (Size: 0x1, Type: Int8Property)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    uint8_t bManuallySetID : 1; // 0x30:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayTaskResource) == 0x38, "Size mismatch for UGameplayTaskResource");
static_assert(offsetof(UGameplayTaskResource, ManualResourceID) == 0x28, "Offset mismatch for UGameplayTaskResource::ManualResourceID");
static_assert(offsetof(UGameplayTaskResource, AutoResourceID) == 0x2c, "Offset mismatch for UGameplayTaskResource::AutoResourceID");
static_assert(offsetof(UGameplayTaskResource, bManuallySetID) == 0x30, "Offset mismatch for UGameplayTaskResource::bManuallySetID");

// Size: 0x130 (Inherited: 0xe0, Single: 0x50)
class UGameplayTasksComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    TArray<UGameplayTask*> TaskPriorityQueue; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e0[0x10]; // 0xe0 (Size: 0x10, Type: PaddingProperty)
    TArray<UGameplayTask*> TickingTasks; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<UGameplayTask*> KnownTasks; // 0x100 (Size: 0x10, Type: ArrayProperty)
    uint8_t OnClaimedResourcesChange[0x10]; // 0x110 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<UGameplayTask*> SimulatedTasks; // 0x120 (Size: 0x10, Type: ArrayProperty)

public:
    static EGameplayTaskRunResult K2_RunGameplayTask(TScriptInterface<Class>& TaskOwner, UGameplayTask*& Task, char& Priority, TArray<UClass*>& AdditionalRequiredResources, TArray<UClass*>& AdditionalClaimedResources); // 0xaeb5040 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    void OnRep_SimulatedTasks(const TArray<UGameplayTask*> PreviousSimulatedTasks); // 0x270c00c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms)
};

static_assert(sizeof(UGameplayTasksComponent) == 0x130, "Size mismatch for UGameplayTasksComponent");
static_assert(offsetof(UGameplayTasksComponent, TaskPriorityQueue) == 0xd0, "Offset mismatch for UGameplayTasksComponent::TaskPriorityQueue");
static_assert(offsetof(UGameplayTasksComponent, TickingTasks) == 0xf0, "Offset mismatch for UGameplayTasksComponent::TickingTasks");
static_assert(offsetof(UGameplayTasksComponent, KnownTasks) == 0x100, "Offset mismatch for UGameplayTasksComponent::KnownTasks");
static_assert(offsetof(UGameplayTasksComponent, OnClaimedResourcesChange) == 0x110, "Offset mismatch for UGameplayTasksComponent::OnClaimedResourcesChange");
static_assert(offsetof(UGameplayTasksComponent, SimulatedTasks) == 0x120, "Offset mismatch for UGameplayTasksComponent::SimulatedTasks");

// Size: 0x60 (Inherited: 0x88, Single: 0xffffffd8)
class UGameplayTask_ClaimResource : public UGameplayTask
{
public:

public:
    static UGameplayTask_ClaimResource* ClaimResource(TScriptInterface<Class>& InTaskOwner, UClass*& ResourceClass, char& const Priority, FName& const TaskInstanceName); // 0xaeb3fd0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static UGameplayTask_ClaimResource* ClaimResources(TScriptInterface<Class>& InTaskOwner, TArray<UClass*>& ResourceClasses, char& const Priority, FName& const TaskInstanceName); // 0xaeb4898 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayTask_ClaimResource) == 0x60, "Size mismatch for UGameplayTask_ClaimResource");

// Size: 0xb8 (Inherited: 0x88, Single: 0x30)
class UGameplayTask_SpawnActor : public UGameplayTask
{
public:
    uint8_t Success[0x10]; // 0x60 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t DidNotSpawn[0x10]; // 0x70 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_80[0x30]; // 0x80 (Size: 0x30, Type: PaddingProperty)
    UClass* ClassToSpawn; // 0xb0 (Size: 0x8, Type: ClassProperty)

public:
    bool BeginSpawningActor(UObject*& WorldContextObject, AActor*& SpawnedActor); // 0xaeb3c4c (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void FinishSpawningActor(UObject*& WorldContextObject, AActor*& SpawnedActor); // 0xaeb4e34 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    static UGameplayTask_SpawnActor* SpawnActor(TScriptInterface<Class>& TaskOwner, FVector& SpawnLocation, FRotator& SpawnRotation, UClass*& Class, bool& bSpawnOnlyOnAuthority); // 0xaeb5888 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGameplayTask_SpawnActor) == 0xb8, "Size mismatch for UGameplayTask_SpawnActor");
static_assert(offsetof(UGameplayTask_SpawnActor, Success) == 0x60, "Offset mismatch for UGameplayTask_SpawnActor::Success");
static_assert(offsetof(UGameplayTask_SpawnActor, DidNotSpawn) == 0x70, "Offset mismatch for UGameplayTask_SpawnActor::DidNotSpawn");
static_assert(offsetof(UGameplayTask_SpawnActor, ClassToSpawn) == 0xb0, "Offset mismatch for UGameplayTask_SpawnActor::ClassToSpawn");

// Size: 0x98 (Inherited: 0x88, Single: 0x10)
class UGameplayTask_TimeLimitedExecution : public UGameplayTask
{
public:
    uint8_t OnFinished[0x10]; // 0x60 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTimeExpired[0x10]; // 0x70 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_80[0x18]; // 0x80 (Size: 0x18, Type: PaddingProperty)

public:
    void TaskFinishDelegate__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UGameplayTask_TimeLimitedExecution) == 0x98, "Size mismatch for UGameplayTask_TimeLimitedExecution");
static_assert(offsetof(UGameplayTask_TimeLimitedExecution, OnFinished) == 0x60, "Offset mismatch for UGameplayTask_TimeLimitedExecution::OnFinished");
static_assert(offsetof(UGameplayTask_TimeLimitedExecution, OnTimeExpired) == 0x70, "Offset mismatch for UGameplayTask_TimeLimitedExecution::OnTimeExpired");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UGameplayTask_WaitDelay : public UGameplayTask
{
public:
    uint8_t OnFinish[0x10]; // 0x60 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_70[0x10]; // 0x70 (Size: 0x10, Type: PaddingProperty)

public:
    void TaskDelayDelegate__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    static UGameplayTask_WaitDelay* TaskWaitDelay(TScriptInterface<Class>& TaskOwner, float& time, char& const Priority); // 0xaeb5eec (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayTask_WaitDelay) == 0x80, "Size mismatch for UGameplayTask_WaitDelay");
static_assert(offsetof(UGameplayTask_WaitDelay, OnFinish) == 0x60, "Offset mismatch for UGameplayTask_WaitDelay::OnFinish");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGameplayResourceSet
{
};

static_assert(sizeof(FGameplayResourceSet) == 0x2, "Size mismatch for FGameplayResourceSet");

