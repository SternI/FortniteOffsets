/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GatedItemGrantsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DataRegistry.h"
#include "FortniteQuest.h"

// Size: 0x108 (Inherited: 0x310, Single: 0xfffffdf8)
class UFortControllerComponent_GatedItemGranter : public UFortControllerComponent
{
public:
    FSoftDataRegistryOrTable ItemGrantsRegistry; // 0xc0 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_f0[0x8]; // 0xf0 (Size: 0x8, Type: PaddingProperty)
    TArray<UObject*> CachedObjects; // 0xf8 (Size: 0x10, Type: ArrayProperty)

private:
    void HandleExitAircraft(AController*& ExitingController); // 0x1234bb00 (Index: 0x0, Flags: Final|Native|Private)
    void OnAthenaProfileInitialized(); // 0x1234bc58 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortControllerComponent_GatedItemGranter) == 0x108, "Size mismatch for UFortControllerComponent_GatedItemGranter");
static_assert(offsetof(UFortControllerComponent_GatedItemGranter, ItemGrantsRegistry) == 0xc0, "Offset mismatch for UFortControllerComponent_GatedItemGranter::ItemGrantsRegistry");
static_assert(offsetof(UFortControllerComponent_GatedItemGranter, CachedObjects) == 0xf8, "Offset mismatch for UFortControllerComponent_GatedItemGranter::CachedObjects");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FFortGatedItemGrantTableRow : FTableRowBase
{
    FEventReaction_Conditional ConditionalReactionGrant; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortGatedItemGrantTableRow) == 0x28, "Size mismatch for FFortGatedItemGrantTableRow");
static_assert(offsetof(FFortGatedItemGrantTableRow, ConditionalReactionGrant) == 0x8, "Offset mismatch for FFortGatedItemGrantTableRow::ConditionalReactionGrant");

