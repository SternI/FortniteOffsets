/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DaySequence
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MovieScene.h"
#include "DeveloperSettings.h"

// Size: 0x4b8 (Inherited: 0x9f8, Single: 0xfffffac0)
class ABaseDaySequenceActor : public ADaySequenceActor
{
public:
    USceneComponent* SunRootComponent; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* SunComponent; // 0x488 (Size: 0x8, Type: ObjectProperty)
    USkyAtmosphereComponent* SkyAtmosphereComponent; // 0x490 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightComponent; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UExponentialHeightFogComponent* ExponentialHeightFogComponent; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UVolumetricCloudComponent* VolumetricCloudComponent; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SkySphereComponent; // 0x4b0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ABaseDaySequenceActor) == 0x4b8, "Size mismatch for ABaseDaySequenceActor");
static_assert(offsetof(ABaseDaySequenceActor, SunRootComponent) == 0x480, "Offset mismatch for ABaseDaySequenceActor::SunRootComponent");
static_assert(offsetof(ABaseDaySequenceActor, SunComponent) == 0x488, "Offset mismatch for ABaseDaySequenceActor::SunComponent");
static_assert(offsetof(ABaseDaySequenceActor, SkyAtmosphereComponent) == 0x490, "Offset mismatch for ABaseDaySequenceActor::SkyAtmosphereComponent");
static_assert(offsetof(ABaseDaySequenceActor, SkyLightComponent) == 0x498, "Offset mismatch for ABaseDaySequenceActor::SkyLightComponent");
static_assert(offsetof(ABaseDaySequenceActor, ExponentialHeightFogComponent) == 0x4a0, "Offset mismatch for ABaseDaySequenceActor::ExponentialHeightFogComponent");
static_assert(offsetof(ABaseDaySequenceActor, VolumetricCloudComponent) == 0x4a8, "Offset mismatch for ABaseDaySequenceActor::VolumetricCloudComponent");
static_assert(offsetof(ABaseDaySequenceActor, SkySphereComponent) == 0x4b0, "Offset mismatch for ABaseDaySequenceActor::SkySphereComponent");

// Size: 0x480 (Inherited: 0x578, Single: 0xffffff08)
class ADaySequenceActor : public AInfo
{
public:
    uint8_t Pad_2a8[0x10]; // 0x2a8 (Size: 0x10, Type: PaddingProperty)
    UCurveFloat* DayInterpCurve; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UDaySequenceCollectionAsset* DaySequenceCollection; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    TArray<UDaySequenceCollectionAsset*> DaySequenceCollections; // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    int32_t Bias; // 0x2d8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
    UMovieSceneBindingOverrides* BindingOverrides; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t bReplicatePlayback : 1; // 0x2e8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e9[0x7]; // 0x2e9 (Size: 0x7, Type: PaddingProperty)
    UDaySequencePlayer* SequencePlayer; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UDaySequence* RootSequence; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    float SequenceUpdateInterval; // 0x300 (Size: 0x4, Type: FloatProperty)
    bool bRunDayCycle; // 0x304 (Size: 0x1, Type: BoolProperty)
    bool bUseInterpCurve; // 0x305 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_306[0x2]; // 0x306 (Size: 0x2, Type: PaddingProperty)
    FDaySequenceTime DayLength; // 0x308 (Size: 0xc, Type: StructProperty)
    FDaySequenceTime TimePerCycle; // 0x314 (Size: 0xc, Type: StructProperty)
    FDaySequenceTime InitialTimeOfDay; // 0x320 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_32c[0x14]; // 0x32c (Size: 0x14, Type: PaddingProperty)
    uint8_t StaticTimeMode[0x4]; // 0x340 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_344[0x4]; // 0x344 (Size: 0x4, Type: PaddingProperty)
    UDaySequenceCameraModifierManager* CameraModifierManager; // 0x348 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_350[0xe0]; // 0x350 (Size: 0xe0, Type: PaddingProperty)
    TMap<UDaySequenceConditionTag*, UClass*> TrackConditionMap; // 0x430 (Size: 0x50, Type: MapProperty)

public:
    bool ContainsDaySequence(UDaySequence*& const InDaySequence); // 0xcb5abc0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    float GetApparentTimeOfDay() const; // 0xcb5ad6c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDayLength() const; // 0xcb5b8f4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetInitialTimeOfDay() const; // 0xcb5baa8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPlayRate() const; // 0xcb5baf4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStaticTimeOfDay() const; // 0xcb5bc00 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimeOfDay() const; // 0xcb5bc28 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimeOfDayPreview() const; // 0x9e96880 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimePerCycle() const; // 0xcb5bc50 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasStaticTimeOfDay() const; // 0xcb5bcb0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPaused() const; // 0xcb5c284 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlaying() const; // 0xcb5c2a8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void Multicast_SetTimePerCycle(float& InHours); // 0x9e7e174 (Index: 0xc, Flags: Net|NetReliableNative|Event|NetMulticast|Public)
    void Pause(); // 0xcb5c2cc (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void Play(); // 0xcb5c2e0 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    virtual void SetPlayRate(float& NewRate); // 0x9e7e044 (Index: 0xf, Flags: Net|NetReliableNative|Event|NetMulticast|Public|BlueprintCallable)
    void SetReplicatePlayback(bool& ReplicatePlayback); // 0xcb5d250 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    bool SetTimeOfDay(float& InHours); // 0xcb5d38c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void SetTimeOfDayPreview(float& InHours); // 0xa35c334 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void StartDaySequenceUpdateTimer(); // 0xcb5d864 (Index: 0x13, Flags: Final|Native|Protected)
    void StopDaySequenceUpdateTimer(); // 0x60219ec (Index: 0x14, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADaySequenceActor) == 0x480, "Size mismatch for ADaySequenceActor");
static_assert(offsetof(ADaySequenceActor, DayInterpCurve) == 0x2b8, "Offset mismatch for ADaySequenceActor::DayInterpCurve");
static_assert(offsetof(ADaySequenceActor, DaySequenceCollection) == 0x2c0, "Offset mismatch for ADaySequenceActor::DaySequenceCollection");
static_assert(offsetof(ADaySequenceActor, DaySequenceCollections) == 0x2c8, "Offset mismatch for ADaySequenceActor::DaySequenceCollections");
static_assert(offsetof(ADaySequenceActor, Bias) == 0x2d8, "Offset mismatch for ADaySequenceActor::Bias");
static_assert(offsetof(ADaySequenceActor, BindingOverrides) == 0x2e0, "Offset mismatch for ADaySequenceActor::BindingOverrides");
static_assert(offsetof(ADaySequenceActor, bReplicatePlayback) == 0x2e8, "Offset mismatch for ADaySequenceActor::bReplicatePlayback");
static_assert(offsetof(ADaySequenceActor, SequencePlayer) == 0x2f0, "Offset mismatch for ADaySequenceActor::SequencePlayer");
static_assert(offsetof(ADaySequenceActor, RootSequence) == 0x2f8, "Offset mismatch for ADaySequenceActor::RootSequence");
static_assert(offsetof(ADaySequenceActor, SequenceUpdateInterval) == 0x300, "Offset mismatch for ADaySequenceActor::SequenceUpdateInterval");
static_assert(offsetof(ADaySequenceActor, bRunDayCycle) == 0x304, "Offset mismatch for ADaySequenceActor::bRunDayCycle");
static_assert(offsetof(ADaySequenceActor, bUseInterpCurve) == 0x305, "Offset mismatch for ADaySequenceActor::bUseInterpCurve");
static_assert(offsetof(ADaySequenceActor, DayLength) == 0x308, "Offset mismatch for ADaySequenceActor::DayLength");
static_assert(offsetof(ADaySequenceActor, TimePerCycle) == 0x314, "Offset mismatch for ADaySequenceActor::TimePerCycle");
static_assert(offsetof(ADaySequenceActor, InitialTimeOfDay) == 0x320, "Offset mismatch for ADaySequenceActor::InitialTimeOfDay");
static_assert(offsetof(ADaySequenceActor, StaticTimeMode) == 0x340, "Offset mismatch for ADaySequenceActor::StaticTimeMode");
static_assert(offsetof(ADaySequenceActor, CameraModifierManager) == 0x348, "Offset mismatch for ADaySequenceActor::CameraModifierManager");
static_assert(offsetof(ADaySequenceActor, TrackConditionMap) == 0x430, "Offset mismatch for ADaySequenceActor::TrackConditionMap");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDaySequenceCheatManagerExtension : public UCheatManagerExtension
{
public:

public:
    void SetTimeOfDay(float& NewTimeOfDay) const; // 0xcb5d4c8 (Index: 0x0, Flags: Final|Exec|Native|Public|Const)
    void SetTimeOfDaySpeed(float& NewTimeOfDaySpeedMultiplier) const; // 0xcb5d600 (Index: 0x1, Flags: Final|Exec|Native|Public|Const)
};

static_assert(sizeof(UDaySequenceCheatManagerExtension) == 0x28, "Size mismatch for UDaySequenceCheatManagerExtension");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UDaySequenceConditionTag : public UObject
{
public:
    FString ConditionName; // 0x28 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_38[0x20]; // 0x38 (Size: 0x20, Type: PaddingProperty)

public:
    virtual bool Evaluate() const; // 0x9e96840 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)

protected:
    void BroadcastOnConditionValueChanged() const; // 0xcb5ab64 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|Const)
    virtual void SetupOnConditionValueChanged() const; // 0x41f1e2c (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UDaySequenceConditionTag) == 0x58, "Size mismatch for UDaySequenceConditionTag");
static_assert(offsetof(UDaySequenceConditionTag, ConditionName) == 0x28, "Offset mismatch for UDaySequenceConditionTag::ConditionName");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UDaySequenceModifierEasingFunction : public UObject
{
public:
};

static_assert(sizeof(UDaySequenceModifierEasingFunction) == 0x60, "Size mismatch for UDaySequenceModifierEasingFunction");

// Size: 0x330 (Inherited: 0x320, Single: 0x10)
class UDaySequenceModifierComponent : public USceneComponent
{
public:
    ADaySequenceActor* TargetActor; // 0x240 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_248[0x10]; // 0x248 (Size: 0x10, Type: PaddingProperty)
    TArray<FComponentReference> VolumeShapeComponents; // 0x258 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<APlayerController*> WeakBlendTarget; // 0x268 (Size: 0x8, Type: WeakObjectProperty)
    UDaySequence* UserDaySequence; // 0x270 (Size: 0x8, Type: ObjectProperty)
    UDaySequence* TransientSequence; // 0x278 (Size: 0x8, Type: ObjectProperty)
    UDaySequenceCollectionAsset* DaySequenceCollection; // 0x280 (Size: 0x8, Type: ObjectProperty)
    TArray<UDaySequenceCollectionAsset*> DaySequenceCollections; // 0x288 (Size: 0x10, Type: ArrayProperty)
    UDaySequenceModifierEasingFunction* EasingFunction; // 0x298 (Size: 0x8, Type: ObjectProperty)
    int32_t Bias; // 0x2a0 (Size: 0x4, Type: IntProperty)
    float DayNightCycleTime; // 0x2a4 (Size: 0x4, Type: FloatProperty)
    float BlendAmount; // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float BlendTime; // 0x2ac (Size: 0x4, Type: FloatProperty)
    float UserBlendWeight; // 0x2b0 (Size: 0x4, Type: FloatProperty)
    uint8_t DayNightCycle; // 0x2b4 (Size: 0x1, Type: EnumProperty)
    uint8_t Mode; // 0x2b5 (Size: 0x1, Type: EnumProperty)
    uint8_t BlendPolicy; // 0x2b6 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2b7[0x1]; // 0x2b7 (Size: 0x1, Type: PaddingProperty)
    uint8_t OnPostReinitializeSubSequences[0x10]; // 0x2b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPostEnableModifier[0x10]; // 0x2c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t bIgnoreBias : 1; // 0x2d8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsComponentEnabled : 1; // 0x2d8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsEnabled : 1; // 0x2d8:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bPreview : 1; // 0x2d8:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseCollection : 1; // 0x2d8:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bSmoothBlending : 1; // 0x2d8:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bForceSmoothBlending : 1; // 0x2d8:6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d9[0x57]; // 0x2d9 (Size: 0x57, Type: PaddingProperty)

public:
    void BindToDaySequenceActor(ADaySequenceActor*& DaySequenceActor); // 0x4046500 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void DisableComponent(); // 0xcb5ad58 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void EnableComponent(); // 0x5814f64 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetBlendWeight() const; // 0xcb5ad94 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetBlendTarget(APlayerController*& InActor); // 0x401b04c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void UnbindFromDaySequenceActor(); // 0x4046300 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDaySequenceModifierComponent) == 0x330, "Size mismatch for UDaySequenceModifierComponent");
static_assert(offsetof(UDaySequenceModifierComponent, TargetActor) == 0x240, "Offset mismatch for UDaySequenceModifierComponent::TargetActor");
static_assert(offsetof(UDaySequenceModifierComponent, VolumeShapeComponents) == 0x258, "Offset mismatch for UDaySequenceModifierComponent::VolumeShapeComponents");
static_assert(offsetof(UDaySequenceModifierComponent, WeakBlendTarget) == 0x268, "Offset mismatch for UDaySequenceModifierComponent::WeakBlendTarget");
static_assert(offsetof(UDaySequenceModifierComponent, UserDaySequence) == 0x270, "Offset mismatch for UDaySequenceModifierComponent::UserDaySequence");
static_assert(offsetof(UDaySequenceModifierComponent, TransientSequence) == 0x278, "Offset mismatch for UDaySequenceModifierComponent::TransientSequence");
static_assert(offsetof(UDaySequenceModifierComponent, DaySequenceCollection) == 0x280, "Offset mismatch for UDaySequenceModifierComponent::DaySequenceCollection");
static_assert(offsetof(UDaySequenceModifierComponent, DaySequenceCollections) == 0x288, "Offset mismatch for UDaySequenceModifierComponent::DaySequenceCollections");
static_assert(offsetof(UDaySequenceModifierComponent, EasingFunction) == 0x298, "Offset mismatch for UDaySequenceModifierComponent::EasingFunction");
static_assert(offsetof(UDaySequenceModifierComponent, Bias) == 0x2a0, "Offset mismatch for UDaySequenceModifierComponent::Bias");
static_assert(offsetof(UDaySequenceModifierComponent, DayNightCycleTime) == 0x2a4, "Offset mismatch for UDaySequenceModifierComponent::DayNightCycleTime");
static_assert(offsetof(UDaySequenceModifierComponent, BlendAmount) == 0x2a8, "Offset mismatch for UDaySequenceModifierComponent::BlendAmount");
static_assert(offsetof(UDaySequenceModifierComponent, BlendTime) == 0x2ac, "Offset mismatch for UDaySequenceModifierComponent::BlendTime");
static_assert(offsetof(UDaySequenceModifierComponent, UserBlendWeight) == 0x2b0, "Offset mismatch for UDaySequenceModifierComponent::UserBlendWeight");
static_assert(offsetof(UDaySequenceModifierComponent, DayNightCycle) == 0x2b4, "Offset mismatch for UDaySequenceModifierComponent::DayNightCycle");
static_assert(offsetof(UDaySequenceModifierComponent, Mode) == 0x2b5, "Offset mismatch for UDaySequenceModifierComponent::Mode");
static_assert(offsetof(UDaySequenceModifierComponent, BlendPolicy) == 0x2b6, "Offset mismatch for UDaySequenceModifierComponent::BlendPolicy");
static_assert(offsetof(UDaySequenceModifierComponent, OnPostReinitializeSubSequences) == 0x2b8, "Offset mismatch for UDaySequenceModifierComponent::OnPostReinitializeSubSequences");
static_assert(offsetof(UDaySequenceModifierComponent, OnPostEnableModifier) == 0x2c8, "Offset mismatch for UDaySequenceModifierComponent::OnPostEnableModifier");
static_assert(offsetof(UDaySequenceModifierComponent, bIgnoreBias) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bIgnoreBias");
static_assert(offsetof(UDaySequenceModifierComponent, bIsComponentEnabled) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bIsComponentEnabled");
static_assert(offsetof(UDaySequenceModifierComponent, bIsEnabled) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bIsEnabled");
static_assert(offsetof(UDaySequenceModifierComponent, bPreview) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bPreview");
static_assert(offsetof(UDaySequenceModifierComponent, bUseCollection) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bUseCollection");
static_assert(offsetof(UDaySequenceModifierComponent, bSmoothBlending) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bSmoothBlending");
static_assert(offsetof(UDaySequenceModifierComponent, bForceSmoothBlending) == 0x2d8, "Offset mismatch for UDaySequenceModifierComponent::bForceSmoothBlending");

// Size: 0x330 (Inherited: 0x2d0, Single: 0x60)
class ADaySequenceModifierVolume : public AActor
{
public:
    UDaySequenceModifierComponent* DaySequenceModifier; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* DefaultBox; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    ADaySequenceActor* DaySequenceActor; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    APlayerController* CachedPlayerController; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c8[0x8]; // 0x2c8 (Size: 0x8, Type: PaddingProperty)
    bool bEnableSplitscreenSupport; // 0x2d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d1[0x7]; // 0x2d1 (Size: 0x7, Type: PaddingProperty)
    TMap<UDaySequenceModifierComponent*, APlayerController*> AdditionalPlayers; // 0x2d8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_328[0x8]; // 0x328 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void OnDaySequenceActorBound(ADaySequenceActor*& InActor); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(ADaySequenceModifierVolume) == 0x330, "Size mismatch for ADaySequenceModifierVolume");
static_assert(offsetof(ADaySequenceModifierVolume, DaySequenceModifier) == 0x2a8, "Offset mismatch for ADaySequenceModifierVolume::DaySequenceModifier");
static_assert(offsetof(ADaySequenceModifierVolume, DefaultBox) == 0x2b0, "Offset mismatch for ADaySequenceModifierVolume::DefaultBox");
static_assert(offsetof(ADaySequenceModifierVolume, DaySequenceActor) == 0x2b8, "Offset mismatch for ADaySequenceModifierVolume::DaySequenceActor");
static_assert(offsetof(ADaySequenceModifierVolume, CachedPlayerController) == 0x2c0, "Offset mismatch for ADaySequenceModifierVolume::CachedPlayerController");
static_assert(offsetof(ADaySequenceModifierVolume, bEnableSplitscreenSupport) == 0x2d0, "Offset mismatch for ADaySequenceModifierVolume::bEnableSplitscreenSupport");
static_assert(offsetof(ADaySequenceModifierVolume, AdditionalPlayers) == 0x2d8, "Offset mismatch for ADaySequenceModifierVolume::AdditionalPlayers");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UDaySequenceStaticTimeContributor : public UObject
{
public:
    float BlendWeight; // 0x28 (Size: 0x4, Type: FloatProperty)
    float StaticTime; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bWantsStaticTime; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    ADaySequenceActor* TargetActor; // 0x38 (Size: 0x8, Type: ObjectProperty)

public:
    void BindToDaySequenceActor(ADaySequenceActor*& InTargetActor, int32_t& Priority); // 0xcb5a438 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void UnbindFromDaySequenceActor(); // 0xcb5d8a0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDaySequenceStaticTimeContributor) == 0x40, "Size mismatch for UDaySequenceStaticTimeContributor");
static_assert(offsetof(UDaySequenceStaticTimeContributor, BlendWeight) == 0x28, "Offset mismatch for UDaySequenceStaticTimeContributor::BlendWeight");
static_assert(offsetof(UDaySequenceStaticTimeContributor, StaticTime) == 0x2c, "Offset mismatch for UDaySequenceStaticTimeContributor::StaticTime");
static_assert(offsetof(UDaySequenceStaticTimeContributor, bWantsStaticTime) == 0x30, "Offset mismatch for UDaySequenceStaticTimeContributor::bWantsStaticTime");
static_assert(offsetof(UDaySequenceStaticTimeContributor, TargetActor) == 0x38, "Offset mismatch for UDaySequenceStaticTimeContributor::TargetActor");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UProceduralDaySequenceBuilder : public UObject
{
public:

public:
    void AddBoolKey(FName& PropertyName, float& Key, bool& Value); // 0xcb5812c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddBoolOverride(FName& PropertyName, bool& Value); // 0xcb5841c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void AddColorMaterialParameterOverride(FName& ParameterName, int32_t& MaterialIndex, FLinearColor& Value); // 0xcb58624 (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void AddColorOverride(FName& PropertyName, FLinearColor& Value); // 0xcb58914 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void AddMaterialOverride(int32_t& MaterialIndex, UMaterialInterface*& Value); // 0xcb58ac4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void AddRotationKey(float& Key, const FRotator Value, TEnumAsByte<ERichCurveInterpMode>& InterpMode); // 0xcb58ccc (Index: 0x5, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void AddScalarKey(FName& PropertyName, float& Key, double& Value, TEnumAsByte<ERichCurveInterpMode>& InterpMode); // 0xcb58f24 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void AddScalarMaterialParameterOverride(FName& ParameterName, int32_t& MaterialIndex, float& Value); // 0xcb592e0 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void AddScalarOverride(FName& PropertyName, double& Value); // 0xcb595c0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void AddScaleKey(float& Key, const FVector Value, TEnumAsByte<ERichCurveInterpMode>& InterpMode); // 0xcb597cc (Index: 0x9, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void AddTransformOverride(const FTransform Value); // 0xcb59a24 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void AddTranslationKey(float& Key, const FVector Value, TEnumAsByte<ERichCurveInterpMode>& InterpMode); // 0xcb59b8c (Index: 0xb, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void AddVectorKey(FName& PropertyName, float& Key, FVector& Value, TEnumAsByte<ERichCurveInterpMode>& InterpMode); // 0xcb59de4 (Index: 0xc, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void AddVectorOverride(FName& PropertyName, FVector& Value); // 0xcb5a0e8 (Index: 0xd, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void AddVisibilityOverride(bool& bValue); // 0xcb5a2ac (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void ClearKeys(); // 0xcb5abac (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    UDaySequence* Initialize(ADaySequenceActor*& InActor, UDaySequence*& InitialSequence, bool& bClearInitialSequence); // 0xcb5bcd4 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    bool IsInitialized() const; // 0xcb5c264 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetActiveBoundObject(UObject*& InObject); // 0xcb5c8c0 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UProceduralDaySequenceBuilder) == 0x50, "Size mismatch for UProceduralDaySequenceBuilder");

// Size: 0x4c0 (Inherited: 0xeb0, Single: 0xfffff610)
class ASunMoonDaySequenceActor : public ABaseDaySequenceActor
{
public:
    UDirectionalLightComponent* MoonComponent; // 0x4b8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ASunMoonDaySequenceActor) == 0x4c0, "Size mismatch for ASunMoonDaySequenceActor");
static_assert(offsetof(ASunMoonDaySequenceActor, MoonComponent) == 0x4b8, "Offset mismatch for ASunMoonDaySequenceActor::MoonComponent");

// Size: 0x1d0 (Inherited: 0xe8, Single: 0xe8)
class UDaySequence : public UMovieSceneSequence
{
public:
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
    UMovieScene* MovieScene; // 0x70 (Size: 0x8, Type: ObjectProperty)
    FDaySequenceBindingReferences BindingReferences; // 0x78 (Size: 0x140, Type: StructProperty)
    UClass* DirectorClass; // 0x1b8 (Size: 0x8, Type: ClassProperty)
    TArray<UAssetUserData*> AssetUserData; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDaySequence) == 0x1d0, "Size mismatch for UDaySequence");
static_assert(offsetof(UDaySequence, MovieScene) == 0x70, "Offset mismatch for UDaySequence::MovieScene");
static_assert(offsetof(UDaySequence, BindingReferences) == 0x78, "Offset mismatch for UDaySequence::BindingReferences");
static_assert(offsetof(UDaySequence, DirectorClass) == 0x1b8, "Offset mismatch for UDaySequence::DirectorClass");
static_assert(offsetof(UDaySequence, AssetUserData) == 0x1c0, "Offset mismatch for UDaySequence::AssetUserData");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UDaySequenceCameraModifierManager : public UObject
{
public:
};

static_assert(sizeof(UDaySequenceCameraModifierManager) == 0x78, "Size mismatch for UDaySequenceCameraModifierManager");

// Size: 0x7b0 (Inherited: 0x70, Single: 0x740)
class UDaySequenceCameraModifier : public UCameraModifier
{
public:
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    FPostProcessSettings Settings; // 0x50 (Size: 0x760, Type: StructProperty)
};

static_assert(sizeof(UDaySequenceCameraModifier) == 0x7b0, "Size mismatch for UDaySequenceCameraModifier");
static_assert(offsetof(UDaySequenceCameraModifier, Settings) == 0x50, "Offset mismatch for UDaySequenceCameraModifier::Settings");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UDaySequenceCollectionAsset : public UDataAsset
{
public:
    TArray<FDaySequenceCollectionEntry> DaySequences; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ProceduralDaySequences; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDaySequenceCollectionAsset) == 0x50, "Size mismatch for UDaySequenceCollectionAsset");
static_assert(offsetof(UDaySequenceCollectionAsset, DaySequences) == 0x30, "Offset mismatch for UDaySequenceCollectionAsset::DaySequences");
static_assert(offsetof(UDaySequenceCollectionAsset, ProceduralDaySequences) == 0x40, "Offset mismatch for UDaySequenceCollectionAsset::ProceduralDaySequences");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDaySequenceDirector : public UObject
{
public:
    UDaySequencePlayer* Player; // 0x28 (Size: 0x8, Type: ObjectProperty)
    int32_t SubSequenceID; // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t MovieScenePlayerIndex; // 0x34 (Size: 0x4, Type: IntProperty)

public:
    AActor* GetBoundActor(FMovieSceneObjectBindingID& ObjectBinding); // 0xcb5adb4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<AActor*> GetBoundActors(FMovieSceneObjectBindingID& ObjectBinding); // 0xcb5aeb4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UObject* GetBoundObject(FMovieSceneObjectBindingID& ObjectBinding); // 0xcb5b16c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    TArray<UObject*> GetBoundObjects(FMovieSceneObjectBindingID& ObjectBinding); // 0xcb5b354 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    FQualifiedFrameTime GetCurrentTime() const; // 0xcb5b8c4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FQualifiedFrameTime GetRootSequenceTime() const; // 0xcb5bb1c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMovieSceneSequence* GetSequence(); // 0xcb5bb4c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    virtual void OnCreated(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDaySequenceDirector) == 0x38, "Size mismatch for UDaySequenceDirector");
static_assert(offsetof(UDaySequenceDirector, Player) == 0x28, "Offset mismatch for UDaySequenceDirector::Player");
static_assert(offsetof(UDaySequenceDirector, SubSequenceID) == 0x30, "Offset mismatch for UDaySequenceDirector::SubSequenceID");
static_assert(offsetof(UDaySequenceDirector, MovieScenePlayerIndex) == 0x34, "Offset mismatch for UDaySequenceDirector::MovieScenePlayerIndex");

// Size: 0x478 (Inherited: 0x28, Single: 0x450)
class UDaySequencePlayer : public UObject
{
public:
    uint8_t Pad_28[0x1f8]; // 0x28 (Size: 0x1f8, Type: PaddingProperty)
    TScriptInterface<Class> Observer; // 0x220 (Size: 0x10, Type: InterfaceProperty)
    uint8_t OnPlay[0x10]; // 0x230 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayReverse[0x10]; // 0x240 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStop[0x10]; // 0x250 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPause[0x10]; // 0x260 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFinished[0x10]; // 0x270 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_280[0x10]; // 0x280 (Size: 0x10, Type: PaddingProperty)
    TEnumAsByte<EMovieScenePlayerStatus> Status; // 0x290 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_291[0x7]; // 0x291 (Size: 0x7, Type: PaddingProperty)
    UMovieSceneSequence* Sequence; // 0x298 (Size: 0x8, Type: ObjectProperty)
    FFrameNumber StartTime; // 0x2a0 (Size: 0x4, Type: StructProperty)
    int32_t DurationFrames; // 0x2a4 (Size: 0x4, Type: IntProperty)
    float DurationSubFrames; // 0x2a8 (Size: 0x4, Type: FloatProperty)
    int32_t CurrentNumLoops; // 0x2ac (Size: 0x4, Type: IntProperty)
    int32_t SerialNumber; // 0x2b0 (Size: 0x4, Type: IntProperty)
    FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x2b4 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
    FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // 0x2e0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_300[0x84]; // 0x300 (Size: 0x84, Type: PaddingProperty)
    FMovieSceneSequenceReplProperties NetSyncProps; // 0x384 (Size: 0x14, Type: StructProperty)
    TScriptInterface<Class> PlaybackClient; // 0x398 (Size: 0x10, Type: InterfaceProperty)
    uint8_t Pad_3a8[0xa0]; // 0x3a8 (Size: 0xa0, Type: PaddingProperty)
    UMovieSceneEntitySystemLinker* Linker; // 0x448 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_450[0x28]; // 0x450 (Size: 0x28, Type: PaddingProperty)

public:
    TArray<UObject*> GetBoundObjects(FMovieSceneObjectBindingID& ObjectBinding); // 0xcb5b60c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    EMovieSceneCompletionModeOverride GetCompletionModeOverride() const; // 0x9eea4d8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetDisableCameraCuts(); // 0x9eea514 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    FQualifiedFrameTime GetEndTime() const; // 0xcb5ba7c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetFrameDuration() const; // 0x9eea5e8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FFrameRate GetFrameRate() const; // 0x55e1948 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FMovieSceneObjectBindingID> GetObjectBindings(UObject*& InObject); // 0x9eea634 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    float GetPlayRate() const; // 0x9eea950 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMovieSceneSequence* GetSequence() const; // 0x57df8dc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetSequenceName(bool& bAddClientInfo) const; // 0x9eea9c8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FQualifiedFrameTime GetStartTime() const; // 0xcb5bbc4 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GoToEndAndStop(); // 0xcb5bc9c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    bool IsPaused() const; // 0x9eead54 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlaying() const; // 0x9eead70 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Play(); // 0xcb5c2f4 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void PlayLooping(int32_t& NumLoops); // 0xcb5c308 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveWeight(); // 0xcb5c778 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void RequestInvalidateBinding(FMovieSceneObjectBindingID& ObjectBinding); // 0xcb5c7b0 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void Scrub(); // 0xcb5c8ac (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetCompletionModeOverride(EMovieSceneCompletionModeOverride& CompletionModeOverride); // 0xcb5c9ec (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetDisableCameraCuts(bool& bInDisableCameraCuts); // 0x9eebab0 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetFrameRange(int32_t& StartFrame, int32_t& duration, float& SubFrames); // 0xcb5cd78 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetFrameRate(FFrameRate& FrameRate); // 0xcb5d058 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlayRate(float& PlayRate); // 0xcb5d124 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void SetWeight(double& InWeight); // 0xcb5d72c (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void Stop(); // 0xcb5d878 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable)
    void StopAtCurrentTime(); // 0xcb5d88c (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable)

private:
    virtual void RPC_ExplicitServerUpdateEvent(EUpdatePositionMethod& Method, FFrameTime& RelevantTime, int32_t& NewSerialNumber); // 0xcb5c430 (Index: 0x12, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
    virtual void RPC_OnFinishPlaybackEvent(FFrameTime& StoppedTime, int32_t& NewSerialNumber); // 0x9eeb3f8 (Index: 0x13, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
    virtual void RPC_OnPlayRateChanged(); // 0x41f1e2c (Index: 0x14, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
    virtual void RPC_OnStopEvent(FFrameTime& StoppedTime, int32_t& NewSerialNumber); // 0xcb5c638 (Index: 0x15, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
};

static_assert(sizeof(UDaySequencePlayer) == 0x478, "Size mismatch for UDaySequencePlayer");
static_assert(offsetof(UDaySequencePlayer, Observer) == 0x220, "Offset mismatch for UDaySequencePlayer::Observer");
static_assert(offsetof(UDaySequencePlayer, OnPlay) == 0x230, "Offset mismatch for UDaySequencePlayer::OnPlay");
static_assert(offsetof(UDaySequencePlayer, OnPlayReverse) == 0x240, "Offset mismatch for UDaySequencePlayer::OnPlayReverse");
static_assert(offsetof(UDaySequencePlayer, OnStop) == 0x250, "Offset mismatch for UDaySequencePlayer::OnStop");
static_assert(offsetof(UDaySequencePlayer, OnPause) == 0x260, "Offset mismatch for UDaySequencePlayer::OnPause");
static_assert(offsetof(UDaySequencePlayer, OnFinished) == 0x270, "Offset mismatch for UDaySequencePlayer::OnFinished");
static_assert(offsetof(UDaySequencePlayer, Status) == 0x290, "Offset mismatch for UDaySequencePlayer::Status");
static_assert(offsetof(UDaySequencePlayer, Sequence) == 0x298, "Offset mismatch for UDaySequencePlayer::Sequence");
static_assert(offsetof(UDaySequencePlayer, StartTime) == 0x2a0, "Offset mismatch for UDaySequencePlayer::StartTime");
static_assert(offsetof(UDaySequencePlayer, DurationFrames) == 0x2a4, "Offset mismatch for UDaySequencePlayer::DurationFrames");
static_assert(offsetof(UDaySequencePlayer, DurationSubFrames) == 0x2a8, "Offset mismatch for UDaySequencePlayer::DurationSubFrames");
static_assert(offsetof(UDaySequencePlayer, CurrentNumLoops) == 0x2ac, "Offset mismatch for UDaySequencePlayer::CurrentNumLoops");
static_assert(offsetof(UDaySequencePlayer, SerialNumber) == 0x2b0, "Offset mismatch for UDaySequencePlayer::SerialNumber");
static_assert(offsetof(UDaySequencePlayer, PlaybackSettings) == 0x2b4, "Offset mismatch for UDaySequencePlayer::PlaybackSettings");
static_assert(offsetof(UDaySequencePlayer, RootTemplateInstance) == 0x2e0, "Offset mismatch for UDaySequencePlayer::RootTemplateInstance");
static_assert(offsetof(UDaySequencePlayer, NetSyncProps) == 0x384, "Offset mismatch for UDaySequencePlayer::NetSyncProps");
static_assert(offsetof(UDaySequencePlayer, PlaybackClient) == 0x398, "Offset mismatch for UDaySequencePlayer::PlaybackClient");
static_assert(offsetof(UDaySequencePlayer, Linker) == 0x448, "Offset mismatch for UDaySequencePlayer::Linker");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UDaySequenceProjectSettings : public UDeveloperSettings
{
public:
    bool bDefaultLockEngineToDisplayRate; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FString DefaultDisplayRate; // 0x38 (Size: 0x10, Type: StrProperty)
    FString DefaultTickResolution; // 0x48 (Size: 0x10, Type: StrProperty)
    uint8_t DefaultClockSource; // 0x58 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDaySequenceProjectSettings) == 0x60, "Size mismatch for UDaySequenceProjectSettings");
static_assert(offsetof(UDaySequenceProjectSettings, bDefaultLockEngineToDisplayRate) == 0x30, "Offset mismatch for UDaySequenceProjectSettings::bDefaultLockEngineToDisplayRate");
static_assert(offsetof(UDaySequenceProjectSettings, DefaultDisplayRate) == 0x38, "Offset mismatch for UDaySequenceProjectSettings::DefaultDisplayRate");
static_assert(offsetof(UDaySequenceProjectSettings, DefaultTickResolution) == 0x48, "Offset mismatch for UDaySequenceProjectSettings::DefaultTickResolution");
static_assert(offsetof(UDaySequenceProjectSettings, DefaultClockSource) == 0x58, "Offset mismatch for UDaySequenceProjectSettings::DefaultClockSource");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UDaySequenceSubsystem : public UWorldSubsystem
{
public:
    uint8_t OnDaySequenceActorSet[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_40[0x28]; // 0x40 (Size: 0x28, Type: PaddingProperty)

public:
    ADaySequenceActor* GetDaySequenceActor(bool& bFindFallbackOnNull) const; // 0xcb5b940 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetDaySequenceActor(ADaySequenceActor*& InActor); // 0xcb5cc4c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDaySequenceSubsystem) == 0x68, "Size mismatch for UDaySequenceSubsystem");
static_assert(offsetof(UDaySequenceSubsystem, OnDaySequenceActorSet) == 0x30, "Offset mismatch for UDaySequenceSubsystem::OnDaySequenceActorSet");

// Size: 0x120 (Inherited: 0x428, Single: 0xfffffcf8)
class UDaySequenceTrack : public UMovieSceneSubTrack
{
public:
};

static_assert(sizeof(UDaySequenceTrack) == 0x120, "Size mismatch for UDaySequenceTrack");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDaySequenceConditionSet
{
    TMap<bool, UClass*> Conditions; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FDaySequenceConditionSet) == 0x50, "Size mismatch for FDaySequenceConditionSet");
static_assert(offsetof(FDaySequenceConditionSet, Conditions) == 0x0, "Offset mismatch for FDaySequenceConditionSet::Conditions");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDaySequenceTime
{
    int32_t Hours; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Seconds; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDaySequenceTime) == 0xc, "Size mismatch for FDaySequenceTime");
static_assert(offsetof(FDaySequenceTime, Hours) == 0x0, "Offset mismatch for FDaySequenceTime::Hours");
static_assert(offsetof(FDaySequenceTime, Minutes) == 0x4, "Offset mismatch for FDaySequenceTime::Minutes");
static_assert(offsetof(FDaySequenceTime, Seconds) == 0x8, "Offset mismatch for FDaySequenceTime::Seconds");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDaySequenceBindingReference
{
    TSoftObjectPtr<UObject*> ExternalObjectPath; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FString ObjectPath; // 0x20 (Size: 0x10, Type: StrProperty)
    uint8_t Specialization[0x4]; // 0x30 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDaySequenceBindingReference) == 0x38, "Size mismatch for FDaySequenceBindingReference");
static_assert(offsetof(FDaySequenceBindingReference, ExternalObjectPath) == 0x0, "Offset mismatch for FDaySequenceBindingReference::ExternalObjectPath");
static_assert(offsetof(FDaySequenceBindingReference, ObjectPath) == 0x20, "Offset mismatch for FDaySequenceBindingReference::ObjectPath");
static_assert(offsetof(FDaySequenceBindingReference, Specialization) == 0x30, "Offset mismatch for FDaySequenceBindingReference::Specialization");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDaySequenceBindingReferenceArray
{
    TArray<FDaySequenceBindingReference> References; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDaySequenceBindingReferenceArray) == 0x10, "Size mismatch for FDaySequenceBindingReferenceArray");
static_assert(offsetof(FDaySequenceBindingReferenceArray, References) == 0x0, "Offset mismatch for FDaySequenceBindingReferenceArray::References");

// Size: 0x140 (Inherited: 0x0, Single: 0x140)
struct FDaySequenceBindingReferences
{
    TMap<FDaySequenceBindingReferenceArray, FGuid> BindingIdToReferences; // 0x0 (Size: 0x50, Type: MapProperty)
    TSet<FGuid> AnimSequenceInstances; // 0x50 (Size: 0x50, Type: SetProperty)
    TMap<FGuid, EDaySequenceBindingReferenceSpecialization> SpecializedReferenceToGuid; // 0xa0 (Size: 0x50, Type: MapProperty)
    TMap<EDaySequenceBindingReferenceSpecialization, FGuid> GuidToSpecializedReference; // 0xf0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FDaySequenceBindingReferences) == 0x140, "Size mismatch for FDaySequenceBindingReferences");
static_assert(offsetof(FDaySequenceBindingReferences, BindingIdToReferences) == 0x0, "Offset mismatch for FDaySequenceBindingReferences::BindingIdToReferences");
static_assert(offsetof(FDaySequenceBindingReferences, AnimSequenceInstances) == 0x50, "Offset mismatch for FDaySequenceBindingReferences::AnimSequenceInstances");
static_assert(offsetof(FDaySequenceBindingReferences, SpecializedReferenceToGuid) == 0xa0, "Offset mismatch for FDaySequenceBindingReferences::SpecializedReferenceToGuid");
static_assert(offsetof(FDaySequenceBindingReferences, GuidToSpecializedReference) == 0xf0, "Offset mismatch for FDaySequenceBindingReferences::GuidToSpecializedReference");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FDaySequenceCollectionEntry
{
    UDaySequence* Sequence; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t BiasOffset; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FDaySequenceConditionSet Conditions; // 0x10 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FDaySequenceCollectionEntry) == 0x60, "Size mismatch for FDaySequenceCollectionEntry");
static_assert(offsetof(FDaySequenceCollectionEntry, Sequence) == 0x0, "Offset mismatch for FDaySequenceCollectionEntry::Sequence");
static_assert(offsetof(FDaySequenceCollectionEntry, BiasOffset) == 0x8, "Offset mismatch for FDaySequenceCollectionEntry::BiasOffset");
static_assert(offsetof(FDaySequenceCollectionEntry, Conditions) == 0x10, "Offset mismatch for FDaySequenceCollectionEntry::Conditions");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDaySequencePlaybackParams
{
};

static_assert(sizeof(FDaySequencePlaybackParams) == 0xc, "Size mismatch for FDaySequencePlaybackParams");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FProceduralDaySequence
{
    FDaySequenceConditionSet Conditions; // 0x8 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FProceduralDaySequence) == 0x60, "Size mismatch for FProceduralDaySequence");
static_assert(offsetof(FProceduralDaySequence, Conditions) == 0x8, "Offset mismatch for FProceduralDaySequence::Conditions");

// Size: 0x80 (Inherited: 0x60, Single: 0x20)
struct FSineSequence : FProceduralDaySequence
{
    FName PropertyName; // 0x60 (Size: 0x4, Type: NameProperty)
    FName ComponentName; // 0x64 (Size: 0x4, Type: NameProperty)
    uint32_t KeyCount; // 0x68 (Size: 0x4, Type: UInt32Property)
    float Amplitude; // 0x6c (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x70 (Size: 0x4, Type: FloatProperty)
    float PhaseShift; // 0x74 (Size: 0x4, Type: FloatProperty)
    float VerticalShift; // 0x78 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSineSequence) == 0x80, "Size mismatch for FSineSequence");
static_assert(offsetof(FSineSequence, PropertyName) == 0x60, "Offset mismatch for FSineSequence::PropertyName");
static_assert(offsetof(FSineSequence, ComponentName) == 0x64, "Offset mismatch for FSineSequence::ComponentName");
static_assert(offsetof(FSineSequence, KeyCount) == 0x68, "Offset mismatch for FSineSequence::KeyCount");
static_assert(offsetof(FSineSequence, Amplitude) == 0x6c, "Offset mismatch for FSineSequence::Amplitude");
static_assert(offsetof(FSineSequence, Frequency) == 0x70, "Offset mismatch for FSineSequence::Frequency");
static_assert(offsetof(FSineSequence, PhaseShift) == 0x74, "Offset mismatch for FSineSequence::PhaseShift");
static_assert(offsetof(FSineSequence, VerticalShift) == 0x78, "Offset mismatch for FSineSequence::VerticalShift");

// Size: 0x68 (Inherited: 0x60, Single: 0x8)
struct FSunAngleSequence : FProceduralDaySequence
{
    FName SunComponentName; // 0x60 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSunAngleSequence) == 0x68, "Size mismatch for FSunAngleSequence");
static_assert(offsetof(FSunAngleSequence, SunComponentName) == 0x60, "Offset mismatch for FSunAngleSequence::SunComponentName");

// Size: 0x90 (Inherited: 0x60, Single: 0x30)
struct FSunPositionSequence : FProceduralDaySequence
{
    FName SunComponentName; // 0x60 (Size: 0x4, Type: NameProperty)
    uint32_t KeyCount; // 0x64 (Size: 0x4, Type: UInt32Property)
    FDateTime time; // 0x68 (Size: 0x8, Type: StructProperty)
    double TimeZone; // 0x70 (Size: 0x8, Type: DoubleProperty)
    double Latitude; // 0x78 (Size: 0x8, Type: DoubleProperty)
    double Longitude; // 0x80 (Size: 0x8, Type: DoubleProperty)
    bool bIsDaylightSavings; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSunPositionSequence) == 0x90, "Size mismatch for FSunPositionSequence");
static_assert(offsetof(FSunPositionSequence, SunComponentName) == 0x60, "Offset mismatch for FSunPositionSequence::SunComponentName");
static_assert(offsetof(FSunPositionSequence, KeyCount) == 0x64, "Offset mismatch for FSunPositionSequence::KeyCount");
static_assert(offsetof(FSunPositionSequence, time) == 0x68, "Offset mismatch for FSunPositionSequence::time");
static_assert(offsetof(FSunPositionSequence, TimeZone) == 0x70, "Offset mismatch for FSunPositionSequence::TimeZone");
static_assert(offsetof(FSunPositionSequence, Latitude) == 0x78, "Offset mismatch for FSunPositionSequence::Latitude");
static_assert(offsetof(FSunPositionSequence, Longitude) == 0x80, "Offset mismatch for FSunPositionSequence::Longitude");
static_assert(offsetof(FSunPositionSequence, bIsDaylightSavings) == 0x88, "Offset mismatch for FSunPositionSequence::bIsDaylightSavings");

