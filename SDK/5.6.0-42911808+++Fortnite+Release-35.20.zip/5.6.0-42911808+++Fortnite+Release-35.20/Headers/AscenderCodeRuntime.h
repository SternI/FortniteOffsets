/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AscenderCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "FortniteAI.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortCheatManager_AscenderZipline : public UChildCheatManager
{
public:

public:
    void RemoveAscenders(bool& const bRemoveAscendersOn); // 0x9e6e1b8 (Index: 0x0, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UFortCheatManager_AscenderZipline) == 0x28, "Size mismatch for UFortCheatManager_AscenderZipline");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UFortPawnComponent_AscenderMontageProvider : public UPawnComponent
{
public:
    UAnimMontage* M_Ascending; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* M_Descending; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* F_Ascending; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* F_Descending; // 0xd0 (Size: 0x8, Type: ObjectProperty)

public:
    UAnimMontage* GetSuitableMontage(bool& const bAscending); // 0x100a9fd0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFortPawnComponent_AscenderMontageProvider) == 0xd8, "Size mismatch for UFortPawnComponent_AscenderMontageProvider");
static_assert(offsetof(UFortPawnComponent_AscenderMontageProvider, M_Ascending) == 0xb8, "Offset mismatch for UFortPawnComponent_AscenderMontageProvider::M_Ascending");
static_assert(offsetof(UFortPawnComponent_AscenderMontageProvider, M_Descending) == 0xc0, "Offset mismatch for UFortPawnComponent_AscenderMontageProvider::M_Descending");
static_assert(offsetof(UFortPawnComponent_AscenderMontageProvider, F_Ascending) == 0xc8, "Offset mismatch for UFortPawnComponent_AscenderMontageProvider::F_Ascending");
static_assert(offsetof(UFortPawnComponent_AscenderMontageProvider, F_Descending) == 0xd0, "Offset mismatch for UFortPawnComponent_AscenderMontageProvider::F_Descending");

// Size: 0x1028 (Inherited: 0x3778, Single: 0xffffd8b0)
class AFortAscenderZipline : public AFortAthenaSplineZipline
{
public:
    uint8_t OnAscenderSetupComplete[0x10]; // 0xcc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FName SplineTopAttachPointName; // 0xcd8 (Size: 0x4, Type: NameProperty)
    bool bAutoFindSplineEndLocation; // 0xcdc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cdd[0x3]; // 0xcdd (Size: 0x3, Type: PaddingProperty)
    float SplineOffsetFromGround; // 0xce0 (Size: 0x4, Type: FloatProperty)
    float CableOffsetFromSplineEnd; // 0xce4 (Size: 0x4, Type: FloatProperty)
    float SplineLength; // 0xce8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cec[0x4]; // 0xcec (Size: 0x4, Type: PaddingProperty)
    UStaticMesh* SplineStaticMesh; // 0xcf0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ESplineMeshAxis> MeshForwardAxis; // 0xcf8 (Size: 0x1, Type: ByteProperty)
    bool bHandleReturning; // 0xcf9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cfa[0x2]; // 0xcfa (Size: 0x2, Type: PaddingProperty)
    float HandleReturnSpeed; // 0xcfc (Size: 0x4, Type: FloatProperty)
    bool bCableDropping; // 0xd00 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d01[0x3]; // 0xd01 (Size: 0x3, Type: PaddingProperty)
    float CableDropSpeed; // 0xd04 (Size: 0x4, Type: FloatProperty)
    float YawRotationOffsetWhileUsingHandle; // 0xd08 (Size: 0x4, Type: FloatProperty)
    float YawRotationOffsetWhileSlidingDown; // 0xd0c (Size: 0x4, Type: FloatProperty)
    bool bUseComplexSplineCollision; // 0xd10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d11[0x3]; // 0xd11 (Size: 0x3, Type: PaddingProperty)
    float SimpleSplineCollisionRadius; // 0xd14 (Size: 0x4, Type: FloatProperty)
    float SimpleSplineCollisionHeightExtension; // 0xd18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_d1c[0x4]; // 0xd1c (Size: 0x4, Type: PaddingProperty)
    FScalableFloat DescendMinDistanceFromBottom; // 0xd20 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendReachedEndHorizontalLaunchSpeed; // 0xd48 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendReachedEndVerticalLaunchSpeed; // 0xd70 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendJumpedOffHorizontalLaunchSpeed; // 0xd98 (Size: 0x28, Type: StructProperty)
    FScalableFloat AscendJumpedOffVerticalLaunchSpeed; // 0xdc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendReachedEndHorizontalLaunchSpeed; // 0xde8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendReachedEndVerticalLaunchSpeed; // 0xe10 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendJumpedOffHorizontalLaunchSpeed; // 0xe38 (Size: 0x28, Type: StructProperty)
    FScalableFloat DescendJumpedOffVerticalLaunchSpeed; // 0xe60 (Size: 0x28, Type: StructProperty)
    FScalableFloat HandleActorHitPlayerHorizontalLaunchSpeed; // 0xe88 (Size: 0x28, Type: StructProperty)
    FScalableFloat HandleActorHitPlayerVerticalLaunchSpeed; // 0xeb0 (Size: 0x28, Type: StructProperty)
    FVector HandleDestroyBuildingsOverlapExtents; // 0xed8 (Size: 0x18, Type: StructProperty)
    FVector PlayerDestroyBuildingsOverlapExtents; // 0xef0 (Size: 0x18, Type: StructProperty)
    FVector InitialSplineEndLocation; // 0xf08 (Size: 0x18, Type: StructProperty)
    FVector CurrentSplineEndLocation; // 0xf20 (Size: 0x18, Type: StructProperty)
    FVector TargetSplineEndLocation; // 0xf38 (Size: 0x18, Type: StructProperty)
    FVector CurrentHandleLocation; // 0xf50 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UPrimitiveComponent*> CurrentInteractComponent; // 0xf68 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> PawnUsingHandle; // 0xf70 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> PreviousPawnUsingHandle; // 0xf78 (Size: 0x8, Type: WeakObjectProperty)
    USplineMeshComponent* SplineMesh; // 0xf80 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* SimpleSplineMeshCollision; // 0xf88 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ABuildingActor*> FloorActor; // 0xf90 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AFortPlayerPawn*>> RotationLockedPawns; // 0xf98 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_fa8[0x70]; // 0xfa8 (Size: 0x70, Type: PaddingProperty)
    UFortLinkToActorComponent* LinkToActorComponent; // 0x1018 (Size: 0x8, Type: ObjectProperty)
    UFortZiplineLinkComponent* ZiplineLinkComponent; // 0x1020 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ApplyStructureDamage(ABuildingSMActor*& BuildingActor, AActor*& DamageSource) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent|Const)
    virtual void BP_HandlePlayerStartedUsingHandle(AFortPlayerPawn*& Player); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandlePlayerStoppedUsingHandle(AFortPlayerPawn*& Player); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandleStartedLoweringCable(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandleStartedLoweringHandle(); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandleStoppedLoweringCable(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandleStoppedLoweringHandle(); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandleUpdatedLoweringCable(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    virtual void BP_HandleUpdatedLoweringHandle(); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnVolumeReady(); // 0x288a61c (Index: 0x9, Flags: Event|Public|BlueprintEvent)
    virtual UPrimitiveComponent* GetHandleComponent() const; // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual UPrimitiveComponent* GetInteractComponentOverride(AFortPlayerPawn*& InteractingPawn, UPrimitiveComponent*& InteractComponent) const; // 0x100a9db0 (Index: 0xc, Flags: RequiredAPI|Native|Event|Public|BlueprintEvent|Const)
    AFortPlayerPawn* GetPawnUsingHandle() const; // 0x5e5bd30 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual UPrimitiveComponent* GetTopComponent() const; // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)

protected:
    void FindNewFloor(); // 0x100a9d9c (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleFloorActorDestroyed(AActor*& Actor); // 0x100aa160 (Index: 0xf, Flags: Final|Native|Protected)
    void HandleFloorActorHealthChanged(); // 0x100aa28c (Index: 0x10, Flags: Final|Native|Protected)
    void HandlePawnUsingHandleDied(AFortPawn*& DeadPawn); // 0x100aa2a0 (Index: 0x11, Flags: Final|Native|Protected)
    void OnRep_InitialSplineEndLocation(); // 0x41cd0f0 (Index: 0x12, Flags: Final|Native|Protected)
    void OnRep_PawnUsingHandle(); // 0x60fa260 (Index: 0x13, Flags: Final|Native|Protected)
    void OnRep_TargetSplineEndLocation(); // 0x61ea264 (Index: 0x14, Flags: Final|Native|Protected)
    void OnSpawningFromSaveFinish(); // 0x100aa3cc (Index: 0x15, Flags: Final|Native|Protected)
    void SetupAscender(bool& const bFromConstruction, bool& const bFromReplication); // 0x100aa3e0 (Index: 0x16, Flags: Final|Native|Protected|BlueprintCallable)
    void SetupEventForSpatialGameplayVolume(); // 0x100aa5fc (Index: 0x17, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AFortAscenderZipline) == 0x1028, "Size mismatch for AFortAscenderZipline");
static_assert(offsetof(AFortAscenderZipline, OnAscenderSetupComplete) == 0xcc8, "Offset mismatch for AFortAscenderZipline::OnAscenderSetupComplete");
static_assert(offsetof(AFortAscenderZipline, SplineTopAttachPointName) == 0xcd8, "Offset mismatch for AFortAscenderZipline::SplineTopAttachPointName");
static_assert(offsetof(AFortAscenderZipline, bAutoFindSplineEndLocation) == 0xcdc, "Offset mismatch for AFortAscenderZipline::bAutoFindSplineEndLocation");
static_assert(offsetof(AFortAscenderZipline, SplineOffsetFromGround) == 0xce0, "Offset mismatch for AFortAscenderZipline::SplineOffsetFromGround");
static_assert(offsetof(AFortAscenderZipline, CableOffsetFromSplineEnd) == 0xce4, "Offset mismatch for AFortAscenderZipline::CableOffsetFromSplineEnd");
static_assert(offsetof(AFortAscenderZipline, SplineLength) == 0xce8, "Offset mismatch for AFortAscenderZipline::SplineLength");
static_assert(offsetof(AFortAscenderZipline, SplineStaticMesh) == 0xcf0, "Offset mismatch for AFortAscenderZipline::SplineStaticMesh");
static_assert(offsetof(AFortAscenderZipline, MeshForwardAxis) == 0xcf8, "Offset mismatch for AFortAscenderZipline::MeshForwardAxis");
static_assert(offsetof(AFortAscenderZipline, bHandleReturning) == 0xcf9, "Offset mismatch for AFortAscenderZipline::bHandleReturning");
static_assert(offsetof(AFortAscenderZipline, HandleReturnSpeed) == 0xcfc, "Offset mismatch for AFortAscenderZipline::HandleReturnSpeed");
static_assert(offsetof(AFortAscenderZipline, bCableDropping) == 0xd00, "Offset mismatch for AFortAscenderZipline::bCableDropping");
static_assert(offsetof(AFortAscenderZipline, CableDropSpeed) == 0xd04, "Offset mismatch for AFortAscenderZipline::CableDropSpeed");
static_assert(offsetof(AFortAscenderZipline, YawRotationOffsetWhileUsingHandle) == 0xd08, "Offset mismatch for AFortAscenderZipline::YawRotationOffsetWhileUsingHandle");
static_assert(offsetof(AFortAscenderZipline, YawRotationOffsetWhileSlidingDown) == 0xd0c, "Offset mismatch for AFortAscenderZipline::YawRotationOffsetWhileSlidingDown");
static_assert(offsetof(AFortAscenderZipline, bUseComplexSplineCollision) == 0xd10, "Offset mismatch for AFortAscenderZipline::bUseComplexSplineCollision");
static_assert(offsetof(AFortAscenderZipline, SimpleSplineCollisionRadius) == 0xd14, "Offset mismatch for AFortAscenderZipline::SimpleSplineCollisionRadius");
static_assert(offsetof(AFortAscenderZipline, SimpleSplineCollisionHeightExtension) == 0xd18, "Offset mismatch for AFortAscenderZipline::SimpleSplineCollisionHeightExtension");
static_assert(offsetof(AFortAscenderZipline, DescendMinDistanceFromBottom) == 0xd20, "Offset mismatch for AFortAscenderZipline::DescendMinDistanceFromBottom");
static_assert(offsetof(AFortAscenderZipline, AscendReachedEndHorizontalLaunchSpeed) == 0xd48, "Offset mismatch for AFortAscenderZipline::AscendReachedEndHorizontalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, AscendReachedEndVerticalLaunchSpeed) == 0xd70, "Offset mismatch for AFortAscenderZipline::AscendReachedEndVerticalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, AscendJumpedOffHorizontalLaunchSpeed) == 0xd98, "Offset mismatch for AFortAscenderZipline::AscendJumpedOffHorizontalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, AscendJumpedOffVerticalLaunchSpeed) == 0xdc0, "Offset mismatch for AFortAscenderZipline::AscendJumpedOffVerticalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, DescendReachedEndHorizontalLaunchSpeed) == 0xde8, "Offset mismatch for AFortAscenderZipline::DescendReachedEndHorizontalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, DescendReachedEndVerticalLaunchSpeed) == 0xe10, "Offset mismatch for AFortAscenderZipline::DescendReachedEndVerticalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, DescendJumpedOffHorizontalLaunchSpeed) == 0xe38, "Offset mismatch for AFortAscenderZipline::DescendJumpedOffHorizontalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, DescendJumpedOffVerticalLaunchSpeed) == 0xe60, "Offset mismatch for AFortAscenderZipline::DescendJumpedOffVerticalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, HandleActorHitPlayerHorizontalLaunchSpeed) == 0xe88, "Offset mismatch for AFortAscenderZipline::HandleActorHitPlayerHorizontalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, HandleActorHitPlayerVerticalLaunchSpeed) == 0xeb0, "Offset mismatch for AFortAscenderZipline::HandleActorHitPlayerVerticalLaunchSpeed");
static_assert(offsetof(AFortAscenderZipline, HandleDestroyBuildingsOverlapExtents) == 0xed8, "Offset mismatch for AFortAscenderZipline::HandleDestroyBuildingsOverlapExtents");
static_assert(offsetof(AFortAscenderZipline, PlayerDestroyBuildingsOverlapExtents) == 0xef0, "Offset mismatch for AFortAscenderZipline::PlayerDestroyBuildingsOverlapExtents");
static_assert(offsetof(AFortAscenderZipline, InitialSplineEndLocation) == 0xf08, "Offset mismatch for AFortAscenderZipline::InitialSplineEndLocation");
static_assert(offsetof(AFortAscenderZipline, CurrentSplineEndLocation) == 0xf20, "Offset mismatch for AFortAscenderZipline::CurrentSplineEndLocation");
static_assert(offsetof(AFortAscenderZipline, TargetSplineEndLocation) == 0xf38, "Offset mismatch for AFortAscenderZipline::TargetSplineEndLocation");
static_assert(offsetof(AFortAscenderZipline, CurrentHandleLocation) == 0xf50, "Offset mismatch for AFortAscenderZipline::CurrentHandleLocation");
static_assert(offsetof(AFortAscenderZipline, CurrentInteractComponent) == 0xf68, "Offset mismatch for AFortAscenderZipline::CurrentInteractComponent");
static_assert(offsetof(AFortAscenderZipline, PawnUsingHandle) == 0xf70, "Offset mismatch for AFortAscenderZipline::PawnUsingHandle");
static_assert(offsetof(AFortAscenderZipline, PreviousPawnUsingHandle) == 0xf78, "Offset mismatch for AFortAscenderZipline::PreviousPawnUsingHandle");
static_assert(offsetof(AFortAscenderZipline, SplineMesh) == 0xf80, "Offset mismatch for AFortAscenderZipline::SplineMesh");
static_assert(offsetof(AFortAscenderZipline, SimpleSplineMeshCollision) == 0xf88, "Offset mismatch for AFortAscenderZipline::SimpleSplineMeshCollision");
static_assert(offsetof(AFortAscenderZipline, FloorActor) == 0xf90, "Offset mismatch for AFortAscenderZipline::FloorActor");
static_assert(offsetof(AFortAscenderZipline, RotationLockedPawns) == 0xf98, "Offset mismatch for AFortAscenderZipline::RotationLockedPawns");
static_assert(offsetof(AFortAscenderZipline, LinkToActorComponent) == 0x1018, "Offset mismatch for AFortAscenderZipline::LinkToActorComponent");
static_assert(offsetof(AFortAscenderZipline, ZiplineLinkComponent) == 0x1020, "Offset mismatch for AFortAscenderZipline::ZiplineLinkComponent");

