/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AutomationUtils
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAutomationUtilsBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void TakeGameplayAutomationScreenshot(FString& const ScreenshotName, float& MaxGlobalError, float& MaxLocalError, FString& MapNameOverride); // 0xcb7ead0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAutomationUtilsBlueprintLibrary) == 0x28, "Size mismatch for UAutomationUtilsBlueprintLibrary");

