/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosVDRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChaosVDWrapperDataBase
{
    bool bHasValidData; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDWrapperDataBase) == 0x10, "Size mismatch for FChaosVDWrapperDataBase");
static_assert(offsetof(FChaosVDWrapperDataBase, bHasValidData) == 0x8, "Offset mismatch for FChaosVDWrapperDataBase::bHasValidData");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FChaosVDAccelerationStructureBase : FChaosVDWrapperDataBase
{
    int32_t SolverId; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Type[0x4]; // 0x14 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FChaosVDAccelerationStructureBase) == 0x18, "Size mismatch for FChaosVDAccelerationStructureBase");
static_assert(offsetof(FChaosVDAccelerationStructureBase, SolverId) == 0x10, "Offset mismatch for FChaosVDAccelerationStructureBase::SolverId");
static_assert(offsetof(FChaosVDAccelerationStructureBase, Type) == 0x14, "Offset mismatch for FChaosVDAccelerationStructureBase::Type");

// Size: 0x68 (Inherited: 0x10, Single: 0x58)
struct FChaosVDBVCellElementDataWrapper : FChaosVDWrapperDataBase
{
    FBox Bounds; // 0x10 (Size: 0x38, Type: StructProperty)
    int32_t ParticleIndex; // 0x48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4c[0x1c]; // 0x4c (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDBVCellElementDataWrapper) == 0x68, "Size mismatch for FChaosVDBVCellElementDataWrapper");
static_assert(offsetof(FChaosVDBVCellElementDataWrapper, Bounds) == 0x10, "Offset mismatch for FChaosVDBVCellElementDataWrapper::Bounds");
static_assert(offsetof(FChaosVDBVCellElementDataWrapper, ParticleIndex) == 0x48, "Offset mismatch for FChaosVDBVCellElementDataWrapper::ParticleIndex");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
struct FChaosVDBoundingVolumeDataWrapper : FChaosVDAccelerationStructureBase
{
    uint8_t Pad_18[0x20]; // 0x18 (Size: 0x20, Type: PaddingProperty)
    double MaxPayloadBounds; // 0x38 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FChaosVDBoundingVolumeDataWrapper) == 0x40, "Size mismatch for FChaosVDBoundingVolumeDataWrapper");
static_assert(offsetof(FChaosVDBoundingVolumeDataWrapper, MaxPayloadBounds) == 0x38, "Offset mismatch for FChaosVDBoundingVolumeDataWrapper::MaxPayloadBounds");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FChaosVDAABBTreeNodeDataWrapper : FChaosVDWrapperDataBase
{
    FBox ChildrenBounds[0x2]; // 0x10 (Size: 0x70, Type: StructProperty)
    int32_t ChildrenNodes[0x2]; // 0x80 (Size: 0x8, Type: IntProperty)
    int32_t ParentNode; // 0x88 (Size: 0x4, Type: IntProperty)
    uint8_t bLeaf : 1; // 0x8c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bDirtyNode : 1; // 0x8c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d[0x3]; // 0x8d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDAABBTreeNodeDataWrapper) == 0x90, "Size mismatch for FChaosVDAABBTreeNodeDataWrapper");
static_assert(offsetof(FChaosVDAABBTreeNodeDataWrapper, ChildrenBounds) == 0x10, "Offset mismatch for FChaosVDAABBTreeNodeDataWrapper::ChildrenBounds");
static_assert(offsetof(FChaosVDAABBTreeNodeDataWrapper, ChildrenNodes) == 0x80, "Offset mismatch for FChaosVDAABBTreeNodeDataWrapper::ChildrenNodes");
static_assert(offsetof(FChaosVDAABBTreeNodeDataWrapper, ParentNode) == 0x88, "Offset mismatch for FChaosVDAABBTreeNodeDataWrapper::ParentNode");
static_assert(offsetof(FChaosVDAABBTreeNodeDataWrapper, bLeaf) == 0x8c, "Offset mismatch for FChaosVDAABBTreeNodeDataWrapper::bLeaf");
static_assert(offsetof(FChaosVDAABBTreeNodeDataWrapper, bDirtyNode) == 0x8c, "Offset mismatch for FChaosVDAABBTreeNodeDataWrapper::bDirtyNode");

// Size: 0x88 (Inherited: 0x10, Single: 0x78)
struct FChaosVDAABBTreePayloadBoundsElement : FChaosVDWrapperDataBase
{
    int32_t ParticleIndex; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FBox Bounds; // 0x18 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_50[0x38]; // 0x50 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDAABBTreePayloadBoundsElement) == 0x88, "Size mismatch for FChaosVDAABBTreePayloadBoundsElement");
static_assert(offsetof(FChaosVDAABBTreePayloadBoundsElement, ParticleIndex) == 0x10, "Offset mismatch for FChaosVDAABBTreePayloadBoundsElement::ParticleIndex");
static_assert(offsetof(FChaosVDAABBTreePayloadBoundsElement, Bounds) == 0x18, "Offset mismatch for FChaosVDAABBTreePayloadBoundsElement::Bounds");

// Size: 0x58 (Inherited: 0x10, Single: 0x48)
struct FChaosVDAABBTreeLeafDataWrapper : FChaosVDWrapperDataBase
{
    TArray<FChaosVDAABBTreePayloadBoundsElement> Elements; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FBox Bounds; // 0x20 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FChaosVDAABBTreeLeafDataWrapper) == 0x58, "Size mismatch for FChaosVDAABBTreeLeafDataWrapper");
static_assert(offsetof(FChaosVDAABBTreeLeafDataWrapper, Elements) == 0x10, "Offset mismatch for FChaosVDAABBTreeLeafDataWrapper::Elements");
static_assert(offsetof(FChaosVDAABBTreeLeafDataWrapper, Bounds) == 0x20, "Offset mismatch for FChaosVDAABBTreeLeafDataWrapper::Bounds");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChaosVDAccelerationStructureContainer
{
};

static_assert(sizeof(FChaosVDAccelerationStructureContainer) == 0x50, "Size mismatch for FChaosVDAccelerationStructureContainer");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
struct FChaosVDAABBTreeDataWrapper : FChaosVDAccelerationStructureBase
{
    int32_t RootNodeIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t TreeDepth; // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t NodesNum; // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t LeavesNum; // 0x24 (Size: 0x4, Type: IntProperty)
    bool bDynamicTree; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxChildrenInLeaf; // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t MaxTreeDepth; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    double MaxPayloadBounds; // 0x38 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_40[0x30]; // 0x40 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDAABBTreeDataWrapper) == 0x70, "Size mismatch for FChaosVDAABBTreeDataWrapper");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, RootNodeIndex) == 0x18, "Offset mismatch for FChaosVDAABBTreeDataWrapper::RootNodeIndex");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, TreeDepth) == 0x1c, "Offset mismatch for FChaosVDAABBTreeDataWrapper::TreeDepth");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, NodesNum) == 0x20, "Offset mismatch for FChaosVDAABBTreeDataWrapper::NodesNum");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, LeavesNum) == 0x24, "Offset mismatch for FChaosVDAABBTreeDataWrapper::LeavesNum");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, bDynamicTree) == 0x28, "Offset mismatch for FChaosVDAABBTreeDataWrapper::bDynamicTree");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, MaxChildrenInLeaf) == 0x2c, "Offset mismatch for FChaosVDAABBTreeDataWrapper::MaxChildrenInLeaf");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, MaxTreeDepth) == 0x30, "Offset mismatch for FChaosVDAABBTreeDataWrapper::MaxTreeDepth");
static_assert(offsetof(FChaosVDAABBTreeDataWrapper, MaxPayloadBounds) == 0x38, "Offset mismatch for FChaosVDAABBTreeDataWrapper::MaxPayloadBounds");

// Size: 0x58 (Inherited: 0x10, Single: 0x48)
struct FChaosVDCharacterGroundConstraintStateDataWrapper : FChaosVDWrapperDataBase
{
    uint8_t Pad_10[0x10]; // 0x10 (Size: 0x10, Type: PaddingProperty)
    bool bDisabled; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    FVector SolverAppliedForce; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector SolverAppliedTorque; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDCharacterGroundConstraintStateDataWrapper) == 0x58, "Size mismatch for FChaosVDCharacterGroundConstraintStateDataWrapper");
static_assert(offsetof(FChaosVDCharacterGroundConstraintStateDataWrapper, bDisabled) == 0x20, "Offset mismatch for FChaosVDCharacterGroundConstraintStateDataWrapper::bDisabled");
static_assert(offsetof(FChaosVDCharacterGroundConstraintStateDataWrapper, SolverAppliedForce) == 0x28, "Offset mismatch for FChaosVDCharacterGroundConstraintStateDataWrapper::SolverAppliedForce");
static_assert(offsetof(FChaosVDCharacterGroundConstraintStateDataWrapper, SolverAppliedTorque) == 0x40, "Offset mismatch for FChaosVDCharacterGroundConstraintStateDataWrapper::SolverAppliedTorque");

// Size: 0x68 (Inherited: 0x10, Single: 0x58)
struct FChaosVDCharacterGroundConstraintSettingsDataWrapper : FChaosVDWrapperDataBase
{
    FVector VerticalAxis; // 0x10 (Size: 0x18, Type: StructProperty)
    double TargetHeight; // 0x28 (Size: 0x8, Type: DoubleProperty)
    double RadialForceLimit; // 0x30 (Size: 0x8, Type: DoubleProperty)
    double FrictionForceLimit; // 0x38 (Size: 0x8, Type: DoubleProperty)
    double TwistTorqueLimit; // 0x40 (Size: 0x8, Type: DoubleProperty)
    double SwingTorqueLimit; // 0x48 (Size: 0x8, Type: DoubleProperty)
    double CosMaxWalkableSlopeAngle; // 0x50 (Size: 0x8, Type: DoubleProperty)
    double DampingFactor; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double AssumedOnGroundHeight; // 0x60 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FChaosVDCharacterGroundConstraintSettingsDataWrapper) == 0x68, "Size mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, VerticalAxis) == 0x10, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::VerticalAxis");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, TargetHeight) == 0x28, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::TargetHeight");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, RadialForceLimit) == 0x30, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::RadialForceLimit");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, FrictionForceLimit) == 0x38, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::FrictionForceLimit");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, TwistTorqueLimit) == 0x40, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::TwistTorqueLimit");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, SwingTorqueLimit) == 0x48, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::SwingTorqueLimit");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, CosMaxWalkableSlopeAngle) == 0x50, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::CosMaxWalkableSlopeAngle");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, DampingFactor) == 0x58, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::DampingFactor");
static_assert(offsetof(FChaosVDCharacterGroundConstraintSettingsDataWrapper, AssumedOnGroundHeight) == 0x60, "Offset mismatch for FChaosVDCharacterGroundConstraintSettingsDataWrapper::AssumedOnGroundHeight");

// Size: 0x58 (Inherited: 0x10, Single: 0x48)
struct FChaosVDCharacterGroundConstraintDataDataWrapper : FChaosVDWrapperDataBase
{
    FVector GroundNormal; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector TargetDeltaPosition; // 0x28 (Size: 0x18, Type: StructProperty)
    double TargetDeltaFacing; // 0x40 (Size: 0x8, Type: DoubleProperty)
    double GroundDistance; // 0x48 (Size: 0x8, Type: DoubleProperty)
    double CosMaxWalkableSlopeAngle; // 0x50 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FChaosVDCharacterGroundConstraintDataDataWrapper) == 0x58, "Size mismatch for FChaosVDCharacterGroundConstraintDataDataWrapper");
static_assert(offsetof(FChaosVDCharacterGroundConstraintDataDataWrapper, GroundNormal) == 0x10, "Offset mismatch for FChaosVDCharacterGroundConstraintDataDataWrapper::GroundNormal");
static_assert(offsetof(FChaosVDCharacterGroundConstraintDataDataWrapper, TargetDeltaPosition) == 0x28, "Offset mismatch for FChaosVDCharacterGroundConstraintDataDataWrapper::TargetDeltaPosition");
static_assert(offsetof(FChaosVDCharacterGroundConstraintDataDataWrapper, TargetDeltaFacing) == 0x40, "Offset mismatch for FChaosVDCharacterGroundConstraintDataDataWrapper::TargetDeltaFacing");
static_assert(offsetof(FChaosVDCharacterGroundConstraintDataDataWrapper, GroundDistance) == 0x48, "Offset mismatch for FChaosVDCharacterGroundConstraintDataDataWrapper::GroundDistance");
static_assert(offsetof(FChaosVDCharacterGroundConstraintDataDataWrapper, CosMaxWalkableSlopeAngle) == 0x50, "Offset mismatch for FChaosVDCharacterGroundConstraintDataDataWrapper::CosMaxWalkableSlopeAngle");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FChaosVDConstraintDataWrapperBase : FChaosVDWrapperDataBase
{
};

static_assert(sizeof(FChaosVDConstraintDataWrapperBase) == 0x10, "Size mismatch for FChaosVDConstraintDataWrapperBase");

// Size: 0x138 (Inherited: 0x20, Single: 0x118)
struct FChaosVDCharacterGroundConstraint : FChaosVDConstraintDataWrapperBase
{
    uint8_t Pad_10[0x4]; // 0x10 (Size: 0x4, Type: PaddingProperty)
    int32_t ConstraintIndex; // 0x14 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FChaosVDCharacterGroundConstraintStateDataWrapper State; // 0x20 (Size: 0x58, Type: StructProperty)
    FChaosVDCharacterGroundConstraintSettingsDataWrapper Settings; // 0x78 (Size: 0x68, Type: StructProperty)
    FChaosVDCharacterGroundConstraintDataDataWrapper Data; // 0xe0 (Size: 0x58, Type: StructProperty)
};

static_assert(sizeof(FChaosVDCharacterGroundConstraint) == 0x138, "Size mismatch for FChaosVDCharacterGroundConstraint");
static_assert(offsetof(FChaosVDCharacterGroundConstraint, ConstraintIndex) == 0x14, "Offset mismatch for FChaosVDCharacterGroundConstraint::ConstraintIndex");
static_assert(offsetof(FChaosVDCharacterGroundConstraint, State) == 0x20, "Offset mismatch for FChaosVDCharacterGroundConstraint::State");
static_assert(offsetof(FChaosVDCharacterGroundConstraint, Settings) == 0x78, "Offset mismatch for FChaosVDCharacterGroundConstraint::Settings");
static_assert(offsetof(FChaosVDCharacterGroundConstraint, Data) == 0xe0, "Offset mismatch for FChaosVDCharacterGroundConstraint::Data");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FChaosVDContactPoint
{
    FVector ShapeContactPoints[0x2]; // 0x0 (Size: 0x30, Type: StructProperty)
    FVector ShapeContactNormal; // 0x30 (Size: 0x18, Type: StructProperty)
    float Phi; // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t FaceIndex; // 0x4c (Size: 0x4, Type: IntProperty)
    uint8_t ContactType; // 0x50 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDContactPoint) == 0x58, "Size mismatch for FChaosVDContactPoint");
static_assert(offsetof(FChaosVDContactPoint, ShapeContactPoints) == 0x0, "Offset mismatch for FChaosVDContactPoint::ShapeContactPoints");
static_assert(offsetof(FChaosVDContactPoint, ShapeContactNormal) == 0x30, "Offset mismatch for FChaosVDContactPoint::ShapeContactNormal");
static_assert(offsetof(FChaosVDContactPoint, Phi) == 0x48, "Offset mismatch for FChaosVDContactPoint::Phi");
static_assert(offsetof(FChaosVDContactPoint, FaceIndex) == 0x4c, "Offset mismatch for FChaosVDContactPoint::FaceIndex");
static_assert(offsetof(FChaosVDContactPoint, ContactType) == 0x50, "Offset mismatch for FChaosVDContactPoint::ContactType");

// Size: 0x130 (Inherited: 0x0, Single: 0x130)
struct FChaosVDManifoldPoint
{
    uint8_t bDisabled : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bWasRestored : 1; // 0x0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bWasReplaced : 1; // 0x0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bHasStaticFrictionAnchor : 1; // 0x0:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsValid : 1; // 0x0:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bInsideStaticFrictionCone : 1; // 0x0:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector NetPushOut; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector NetImpulse; // 0x20 (Size: 0x18, Type: StructProperty)
    float TargetPhi; // 0x38 (Size: 0x4, Type: FloatProperty)
    float InitialPhi; // 0x3c (Size: 0x4, Type: FloatProperty)
    FVector ShapeAnchorPoints[0x2]; // 0x40 (Size: 0x30, Type: StructProperty)
    FVector InitialShapeContactPoints[0x2]; // 0x70 (Size: 0x30, Type: StructProperty)
    FChaosVDContactPoint ContactPoint; // 0xa0 (Size: 0x58, Type: StructProperty)
    FVector ShapeContactPoints[0x2]; // 0xf8 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_128[0x8]; // 0x128 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDManifoldPoint) == 0x130, "Size mismatch for FChaosVDManifoldPoint");
static_assert(offsetof(FChaosVDManifoldPoint, bDisabled) == 0x0, "Offset mismatch for FChaosVDManifoldPoint::bDisabled");
static_assert(offsetof(FChaosVDManifoldPoint, bWasRestored) == 0x0, "Offset mismatch for FChaosVDManifoldPoint::bWasRestored");
static_assert(offsetof(FChaosVDManifoldPoint, bWasReplaced) == 0x0, "Offset mismatch for FChaosVDManifoldPoint::bWasReplaced");
static_assert(offsetof(FChaosVDManifoldPoint, bHasStaticFrictionAnchor) == 0x0, "Offset mismatch for FChaosVDManifoldPoint::bHasStaticFrictionAnchor");
static_assert(offsetof(FChaosVDManifoldPoint, bIsValid) == 0x0, "Offset mismatch for FChaosVDManifoldPoint::bIsValid");
static_assert(offsetof(FChaosVDManifoldPoint, bInsideStaticFrictionCone) == 0x0, "Offset mismatch for FChaosVDManifoldPoint::bInsideStaticFrictionCone");
static_assert(offsetof(FChaosVDManifoldPoint, NetPushOut) == 0x8, "Offset mismatch for FChaosVDManifoldPoint::NetPushOut");
static_assert(offsetof(FChaosVDManifoldPoint, NetImpulse) == 0x20, "Offset mismatch for FChaosVDManifoldPoint::NetImpulse");
static_assert(offsetof(FChaosVDManifoldPoint, TargetPhi) == 0x38, "Offset mismatch for FChaosVDManifoldPoint::TargetPhi");
static_assert(offsetof(FChaosVDManifoldPoint, InitialPhi) == 0x3c, "Offset mismatch for FChaosVDManifoldPoint::InitialPhi");
static_assert(offsetof(FChaosVDManifoldPoint, ShapeAnchorPoints) == 0x40, "Offset mismatch for FChaosVDManifoldPoint::ShapeAnchorPoints");
static_assert(offsetof(FChaosVDManifoldPoint, InitialShapeContactPoints) == 0x70, "Offset mismatch for FChaosVDManifoldPoint::InitialShapeContactPoints");
static_assert(offsetof(FChaosVDManifoldPoint, ContactPoint) == 0xa0, "Offset mismatch for FChaosVDManifoldPoint::ContactPoint");
static_assert(offsetof(FChaosVDManifoldPoint, ShapeContactPoints) == 0xf8, "Offset mismatch for FChaosVDManifoldPoint::ShapeContactPoints");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FChaosVDCollisionMaterial
{
    int32_t FaceIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    float MaterialDynamicFriction; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaterialStaticFriction; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaterialRestitution; // 0xc (Size: 0x4, Type: FloatProperty)
    float DynamicFriction; // 0x10 (Size: 0x4, Type: FloatProperty)
    float StaticFriction; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Restitution; // 0x18 (Size: 0x4, Type: FloatProperty)
    float RestitutionThreshold; // 0x1c (Size: 0x4, Type: FloatProperty)
    float InvMassScale0; // 0x20 (Size: 0x4, Type: FloatProperty)
    float InvMassScale1; // 0x24 (Size: 0x4, Type: FloatProperty)
    float InvInertiaScale0; // 0x28 (Size: 0x4, Type: FloatProperty)
    float InvInertiaScale1; // 0x2c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FChaosVDCollisionMaterial) == 0x30, "Size mismatch for FChaosVDCollisionMaterial");
static_assert(offsetof(FChaosVDCollisionMaterial, FaceIndex) == 0x0, "Offset mismatch for FChaosVDCollisionMaterial::FaceIndex");
static_assert(offsetof(FChaosVDCollisionMaterial, MaterialDynamicFriction) == 0x4, "Offset mismatch for FChaosVDCollisionMaterial::MaterialDynamicFriction");
static_assert(offsetof(FChaosVDCollisionMaterial, MaterialStaticFriction) == 0x8, "Offset mismatch for FChaosVDCollisionMaterial::MaterialStaticFriction");
static_assert(offsetof(FChaosVDCollisionMaterial, MaterialRestitution) == 0xc, "Offset mismatch for FChaosVDCollisionMaterial::MaterialRestitution");
static_assert(offsetof(FChaosVDCollisionMaterial, DynamicFriction) == 0x10, "Offset mismatch for FChaosVDCollisionMaterial::DynamicFriction");
static_assert(offsetof(FChaosVDCollisionMaterial, StaticFriction) == 0x14, "Offset mismatch for FChaosVDCollisionMaterial::StaticFriction");
static_assert(offsetof(FChaosVDCollisionMaterial, Restitution) == 0x18, "Offset mismatch for FChaosVDCollisionMaterial::Restitution");
static_assert(offsetof(FChaosVDCollisionMaterial, RestitutionThreshold) == 0x1c, "Offset mismatch for FChaosVDCollisionMaterial::RestitutionThreshold");
static_assert(offsetof(FChaosVDCollisionMaterial, InvMassScale0) == 0x20, "Offset mismatch for FChaosVDCollisionMaterial::InvMassScale0");
static_assert(offsetof(FChaosVDCollisionMaterial, InvMassScale1) == 0x24, "Offset mismatch for FChaosVDCollisionMaterial::InvMassScale1");
static_assert(offsetof(FChaosVDCollisionMaterial, InvInertiaScale0) == 0x28, "Offset mismatch for FChaosVDCollisionMaterial::InvInertiaScale0");
static_assert(offsetof(FChaosVDCollisionMaterial, InvInertiaScale1) == 0x2c, "Offset mismatch for FChaosVDCollisionMaterial::InvInertiaScale1");

// Size: 0x280 (Inherited: 0x0, Single: 0x280)
struct FChaosVDConstraint
{
    uint8_t bIsCurrent : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bDisabled : 1; // 0x0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseManifold : 1; // 0x0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseIncrementalManifold : 1; // 0x0:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bCanRestoreManifold : 1; // 0x0:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bWasManifoldRestored : 1; // 0x0:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsQuadratic0 : 1; // 0x0:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsQuadratic1 : 1; // 0x0:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsProbe : 1; // 0x1:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCCDEnabled : 1; // 0x1:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bCCDSweepEnabled : 1; // 0x1:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bModifierApplied : 1; // 0x1:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bMaterialSet : 1; // 0x1:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FChaosVDCollisionMaterial Material; // 0x4 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FVector AccumulatedImpulse; // 0x38 (Size: 0x18, Type: StructProperty)
    uint8_t ShapesType[0x4]; // 0x50 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_54[0xc]; // 0x54 (Size: 0xc, Type: PaddingProperty)
    FTransform ShapeWorldTransforms[0x2]; // 0x60 (Size: 0xc0, Type: StructProperty)
    FTransform ImplicitTransforms[0x2]; // 0x120 (Size: 0xc0, Type: StructProperty)
    float CullDistance; // 0x1e0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1e4[0x4]; // 0x1e4 (Size: 0x4, Type: PaddingProperty)
    TArray<float> CollisionMargins; // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    float CollisionTolerance; // 0x1f8 (Size: 0x4, Type: FloatProperty)
    int32_t ClosestManifoldPointIndex; // 0x1fc (Size: 0x4, Type: IntProperty)
    int32_t ExpectedNumManifoldPoints; // 0x200 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_204[0x4]; // 0x204 (Size: 0x4, Type: PaddingProperty)
    FVector LastShapeWorldPositionDelta; // 0x208 (Size: 0x18, Type: StructProperty)
    FQuat LastShapeWorldRotationDelta; // 0x220 (Size: 0x20, Type: StructProperty)
    float Stiffness; // 0x240 (Size: 0x4, Type: FloatProperty)
    float MinInitialPhi; // 0x244 (Size: 0x4, Type: FloatProperty)
    float InitialOverlapDepenetrationVelocity; // 0x248 (Size: 0x4, Type: FloatProperty)
    float CCDTimeOfImpact; // 0x24c (Size: 0x4, Type: FloatProperty)
    float CCDEnablePenetration; // 0x250 (Size: 0x4, Type: FloatProperty)
    float CCDTargetPenetration; // 0x254 (Size: 0x4, Type: FloatProperty)
    TArray<FChaosVDManifoldPoint> ManifoldPoints; // 0x258 (Size: 0x10, Type: ArrayProperty)
    int32_t Particle0Index; // 0x268 (Size: 0x4, Type: IntProperty)
    int32_t Particle1Index; // 0x26c (Size: 0x4, Type: IntProperty)
    int32_t SolverId; // 0x270 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_274[0xc]; // 0x274 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDConstraint) == 0x280, "Size mismatch for FChaosVDConstraint");
static_assert(offsetof(FChaosVDConstraint, bIsCurrent) == 0x0, "Offset mismatch for FChaosVDConstraint::bIsCurrent");
static_assert(offsetof(FChaosVDConstraint, bDisabled) == 0x0, "Offset mismatch for FChaosVDConstraint::bDisabled");
static_assert(offsetof(FChaosVDConstraint, bUseManifold) == 0x0, "Offset mismatch for FChaosVDConstraint::bUseManifold");
static_assert(offsetof(FChaosVDConstraint, bUseIncrementalManifold) == 0x0, "Offset mismatch for FChaosVDConstraint::bUseIncrementalManifold");
static_assert(offsetof(FChaosVDConstraint, bCanRestoreManifold) == 0x0, "Offset mismatch for FChaosVDConstraint::bCanRestoreManifold");
static_assert(offsetof(FChaosVDConstraint, bWasManifoldRestored) == 0x0, "Offset mismatch for FChaosVDConstraint::bWasManifoldRestored");
static_assert(offsetof(FChaosVDConstraint, bIsQuadratic0) == 0x0, "Offset mismatch for FChaosVDConstraint::bIsQuadratic0");
static_assert(offsetof(FChaosVDConstraint, bIsQuadratic1) == 0x0, "Offset mismatch for FChaosVDConstraint::bIsQuadratic1");
static_assert(offsetof(FChaosVDConstraint, bIsProbe) == 0x1, "Offset mismatch for FChaosVDConstraint::bIsProbe");
static_assert(offsetof(FChaosVDConstraint, bCCDEnabled) == 0x1, "Offset mismatch for FChaosVDConstraint::bCCDEnabled");
static_assert(offsetof(FChaosVDConstraint, bCCDSweepEnabled) == 0x1, "Offset mismatch for FChaosVDConstraint::bCCDSweepEnabled");
static_assert(offsetof(FChaosVDConstraint, bModifierApplied) == 0x1, "Offset mismatch for FChaosVDConstraint::bModifierApplied");
static_assert(offsetof(FChaosVDConstraint, bMaterialSet) == 0x1, "Offset mismatch for FChaosVDConstraint::bMaterialSet");
static_assert(offsetof(FChaosVDConstraint, Material) == 0x4, "Offset mismatch for FChaosVDConstraint::Material");
static_assert(offsetof(FChaosVDConstraint, AccumulatedImpulse) == 0x38, "Offset mismatch for FChaosVDConstraint::AccumulatedImpulse");
static_assert(offsetof(FChaosVDConstraint, ShapesType) == 0x50, "Offset mismatch for FChaosVDConstraint::ShapesType");
static_assert(offsetof(FChaosVDConstraint, ShapeWorldTransforms) == 0x60, "Offset mismatch for FChaosVDConstraint::ShapeWorldTransforms");
static_assert(offsetof(FChaosVDConstraint, ImplicitTransforms) == 0x120, "Offset mismatch for FChaosVDConstraint::ImplicitTransforms");
static_assert(offsetof(FChaosVDConstraint, CullDistance) == 0x1e0, "Offset mismatch for FChaosVDConstraint::CullDistance");
static_assert(offsetof(FChaosVDConstraint, CollisionMargins) == 0x1e8, "Offset mismatch for FChaosVDConstraint::CollisionMargins");
static_assert(offsetof(FChaosVDConstraint, CollisionTolerance) == 0x1f8, "Offset mismatch for FChaosVDConstraint::CollisionTolerance");
static_assert(offsetof(FChaosVDConstraint, ClosestManifoldPointIndex) == 0x1fc, "Offset mismatch for FChaosVDConstraint::ClosestManifoldPointIndex");
static_assert(offsetof(FChaosVDConstraint, ExpectedNumManifoldPoints) == 0x200, "Offset mismatch for FChaosVDConstraint::ExpectedNumManifoldPoints");
static_assert(offsetof(FChaosVDConstraint, LastShapeWorldPositionDelta) == 0x208, "Offset mismatch for FChaosVDConstraint::LastShapeWorldPositionDelta");
static_assert(offsetof(FChaosVDConstraint, LastShapeWorldRotationDelta) == 0x220, "Offset mismatch for FChaosVDConstraint::LastShapeWorldRotationDelta");
static_assert(offsetof(FChaosVDConstraint, Stiffness) == 0x240, "Offset mismatch for FChaosVDConstraint::Stiffness");
static_assert(offsetof(FChaosVDConstraint, MinInitialPhi) == 0x244, "Offset mismatch for FChaosVDConstraint::MinInitialPhi");
static_assert(offsetof(FChaosVDConstraint, InitialOverlapDepenetrationVelocity) == 0x248, "Offset mismatch for FChaosVDConstraint::InitialOverlapDepenetrationVelocity");
static_assert(offsetof(FChaosVDConstraint, CCDTimeOfImpact) == 0x24c, "Offset mismatch for FChaosVDConstraint::CCDTimeOfImpact");
static_assert(offsetof(FChaosVDConstraint, CCDEnablePenetration) == 0x250, "Offset mismatch for FChaosVDConstraint::CCDEnablePenetration");
static_assert(offsetof(FChaosVDConstraint, CCDTargetPenetration) == 0x254, "Offset mismatch for FChaosVDConstraint::CCDTargetPenetration");
static_assert(offsetof(FChaosVDConstraint, ManifoldPoints) == 0x258, "Offset mismatch for FChaosVDConstraint::ManifoldPoints");
static_assert(offsetof(FChaosVDConstraint, Particle0Index) == 0x268, "Offset mismatch for FChaosVDConstraint::Particle0Index");
static_assert(offsetof(FChaosVDConstraint, Particle1Index) == 0x26c, "Offset mismatch for FChaosVDConstraint::Particle1Index");
static_assert(offsetof(FChaosVDConstraint, SolverId) == 0x270, "Offset mismatch for FChaosVDConstraint::SolverId");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FChaosVDParticlePairMidPhase
{
    int32_t SolverId; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t MidPhaseType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t bIsActive : 1; // 0x5:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsCCD : 1; // 0x5:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsCCDActive : 1; // 0x5:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsSleeping : 1; // 0x5:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsModified : 1; // 0x5:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    int32_t LastUsedEpoch; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Particle0Idx; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t Particle1Idx; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FChaosVDConstraint> Constraints; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChaosVDParticlePairMidPhase) == 0x28, "Size mismatch for FChaosVDParticlePairMidPhase");
static_assert(offsetof(FChaosVDParticlePairMidPhase, SolverId) == 0x0, "Offset mismatch for FChaosVDParticlePairMidPhase::SolverId");
static_assert(offsetof(FChaosVDParticlePairMidPhase, MidPhaseType) == 0x4, "Offset mismatch for FChaosVDParticlePairMidPhase::MidPhaseType");
static_assert(offsetof(FChaosVDParticlePairMidPhase, bIsActive) == 0x5, "Offset mismatch for FChaosVDParticlePairMidPhase::bIsActive");
static_assert(offsetof(FChaosVDParticlePairMidPhase, bIsCCD) == 0x5, "Offset mismatch for FChaosVDParticlePairMidPhase::bIsCCD");
static_assert(offsetof(FChaosVDParticlePairMidPhase, bIsCCDActive) == 0x5, "Offset mismatch for FChaosVDParticlePairMidPhase::bIsCCDActive");
static_assert(offsetof(FChaosVDParticlePairMidPhase, bIsSleeping) == 0x5, "Offset mismatch for FChaosVDParticlePairMidPhase::bIsSleeping");
static_assert(offsetof(FChaosVDParticlePairMidPhase, bIsModified) == 0x5, "Offset mismatch for FChaosVDParticlePairMidPhase::bIsModified");
static_assert(offsetof(FChaosVDParticlePairMidPhase, LastUsedEpoch) == 0x8, "Offset mismatch for FChaosVDParticlePairMidPhase::LastUsedEpoch");
static_assert(offsetof(FChaosVDParticlePairMidPhase, Particle0Idx) == 0xc, "Offset mismatch for FChaosVDParticlePairMidPhase::Particle0Idx");
static_assert(offsetof(FChaosVDParticlePairMidPhase, Particle1Idx) == 0x10, "Offset mismatch for FChaosVDParticlePairMidPhase::Particle1Idx");
static_assert(offsetof(FChaosVDParticlePairMidPhase, Constraints) == 0x18, "Offset mismatch for FChaosVDParticlePairMidPhase::Constraints");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChaosVDCollisionFilterData
{
    uint32_t Word0; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Word1; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Word2; // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t Word3; // 0xc (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FChaosVDCollisionFilterData) == 0x10, "Size mismatch for FChaosVDCollisionFilterData");
static_assert(offsetof(FChaosVDCollisionFilterData, Word0) == 0x0, "Offset mismatch for FChaosVDCollisionFilterData::Word0");
static_assert(offsetof(FChaosVDCollisionFilterData, Word1) == 0x4, "Offset mismatch for FChaosVDCollisionFilterData::Word1");
static_assert(offsetof(FChaosVDCollisionFilterData, Word2) == 0x8, "Offset mismatch for FChaosVDCollisionFilterData::Word2");
static_assert(offsetof(FChaosVDCollisionFilterData, Word3) == 0xc, "Offset mismatch for FChaosVDCollisionFilterData::Word3");

// Size: 0x2c (Inherited: 0x0, Single: 0x2c)
struct FChaosVDShapeCollisionData
{
    uint8_t CollisionTraceType[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    uint8_t bSimCollision : 1; // 0x4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bQueryCollision : 1; // 0x4:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsProbe : 1; // 0x4:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FChaosVDCollisionFilterData QueryData; // 0x8 (Size: 0x10, Type: StructProperty)
    FChaosVDCollisionFilterData SimData; // 0x18 (Size: 0x10, Type: StructProperty)
    bool bIsComplex; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsValid; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDShapeCollisionData) == 0x2c, "Size mismatch for FChaosVDShapeCollisionData");
static_assert(offsetof(FChaosVDShapeCollisionData, CollisionTraceType) == 0x0, "Offset mismatch for FChaosVDShapeCollisionData::CollisionTraceType");
static_assert(offsetof(FChaosVDShapeCollisionData, bSimCollision) == 0x4, "Offset mismatch for FChaosVDShapeCollisionData::bSimCollision");
static_assert(offsetof(FChaosVDShapeCollisionData, bQueryCollision) == 0x4, "Offset mismatch for FChaosVDShapeCollisionData::bQueryCollision");
static_assert(offsetof(FChaosVDShapeCollisionData, bIsProbe) == 0x4, "Offset mismatch for FChaosVDShapeCollisionData::bIsProbe");
static_assert(offsetof(FChaosVDShapeCollisionData, QueryData) == 0x8, "Offset mismatch for FChaosVDShapeCollisionData::QueryData");
static_assert(offsetof(FChaosVDShapeCollisionData, SimData) == 0x18, "Offset mismatch for FChaosVDShapeCollisionData::SimData");
static_assert(offsetof(FChaosVDShapeCollisionData, bIsComplex) == 0x28, "Offset mismatch for FChaosVDShapeCollisionData::bIsComplex");
static_assert(offsetof(FChaosVDShapeCollisionData, bIsValid) == 0x29, "Offset mismatch for FChaosVDShapeCollisionData::bIsValid");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosVDCollisionChannelInfo
{
    FString DisplayName; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t CollisionChannel; // 0x10 (Size: 0x4, Type: IntProperty)
    bool bIsTraceType; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDCollisionChannelInfo) == 0x18, "Size mismatch for FChaosVDCollisionChannelInfo");
static_assert(offsetof(FChaosVDCollisionChannelInfo, DisplayName) == 0x0, "Offset mismatch for FChaosVDCollisionChannelInfo::DisplayName");
static_assert(offsetof(FChaosVDCollisionChannelInfo, CollisionChannel) == 0x10, "Offset mismatch for FChaosVDCollisionChannelInfo::CollisionChannel");
static_assert(offsetof(FChaosVDCollisionChannelInfo, bIsTraceType) == 0x14, "Offset mismatch for FChaosVDCollisionChannelInfo::bIsTraceType");

// Size: 0x300 (Inherited: 0x0, Single: 0x300)
struct FChaosVDCollisionChannelsInfoContainer
{
    FChaosVDCollisionChannelInfo CustomChannelsNames[0x20]; // 0x0 (Size: 0x300, Type: StructProperty)
};

static_assert(sizeof(FChaosVDCollisionChannelsInfoContainer) == 0x300, "Size mismatch for FChaosVDCollisionChannelsInfoContainer");
static_assert(offsetof(FChaosVDCollisionChannelsInfoContainer, CustomChannelsNames) == 0x0, "Offset mismatch for FChaosVDCollisionChannelsInfoContainer::CustomChannelsNames");

// Size: 0x140 (Inherited: 0x0, Single: 0x140)
struct FChaosVDDebugShapeDataContainer
{
};

static_assert(sizeof(FChaosVDDebugShapeDataContainer) == 0x140, "Size mismatch for FChaosVDDebugShapeDataContainer");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FChaosVDDebugDrawShapeBase : FChaosVDWrapperDataBase
{
    int32_t SolverId; // 0x10 (Size: 0x4, Type: IntProperty)
    FName Tag; // 0x14 (Size: 0x4, Type: NameProperty)
    FColor Color; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDDebugDrawShapeBase) == 0x20, "Size mismatch for FChaosVDDebugDrawShapeBase");
static_assert(offsetof(FChaosVDDebugDrawShapeBase, SolverId) == 0x10, "Offset mismatch for FChaosVDDebugDrawShapeBase::SolverId");
static_assert(offsetof(FChaosVDDebugDrawShapeBase, Tag) == 0x14, "Offset mismatch for FChaosVDDebugDrawShapeBase::Tag");
static_assert(offsetof(FChaosVDDebugDrawShapeBase, Color) == 0x18, "Offset mismatch for FChaosVDDebugDrawShapeBase::Color");

// Size: 0x58 (Inherited: 0x30, Single: 0x28)
struct FChaosVDDebugDrawBoxDataWrapper : FChaosVDDebugDrawShapeBase
{
    FBox Box; // 0x20 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FChaosVDDebugDrawBoxDataWrapper) == 0x58, "Size mismatch for FChaosVDDebugDrawBoxDataWrapper");
static_assert(offsetof(FChaosVDDebugDrawBoxDataWrapper, Box) == 0x20, "Offset mismatch for FChaosVDDebugDrawBoxDataWrapper::Box");

// Size: 0x40 (Inherited: 0x30, Single: 0x10)
struct FChaosVDDebugDrawSphereDataWrapper : FChaosVDDebugDrawShapeBase
{
    FVector origin; // 0x20 (Size: 0x18, Type: StructProperty)
    float Radius; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDDebugDrawSphereDataWrapper) == 0x40, "Size mismatch for FChaosVDDebugDrawSphereDataWrapper");
static_assert(offsetof(FChaosVDDebugDrawSphereDataWrapper, origin) == 0x20, "Offset mismatch for FChaosVDDebugDrawSphereDataWrapper::origin");
static_assert(offsetof(FChaosVDDebugDrawSphereDataWrapper, Radius) == 0x38, "Offset mismatch for FChaosVDDebugDrawSphereDataWrapper::Radius");

// Size: 0x58 (Inherited: 0x30, Single: 0x28)
struct FChaosVDDebugDrawLineDataWrapper : FChaosVDDebugDrawShapeBase
{
    FVector StartLocation; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector EndLocation; // 0x38 (Size: 0x18, Type: StructProperty)
    bool bIsArrow; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDDebugDrawLineDataWrapper) == 0x58, "Size mismatch for FChaosVDDebugDrawLineDataWrapper");
static_assert(offsetof(FChaosVDDebugDrawLineDataWrapper, StartLocation) == 0x20, "Offset mismatch for FChaosVDDebugDrawLineDataWrapper::StartLocation");
static_assert(offsetof(FChaosVDDebugDrawLineDataWrapper, EndLocation) == 0x38, "Offset mismatch for FChaosVDDebugDrawLineDataWrapper::EndLocation");
static_assert(offsetof(FChaosVDDebugDrawLineDataWrapper, bIsArrow) == 0x50, "Offset mismatch for FChaosVDDebugDrawLineDataWrapper::bIsArrow");

// Size: 0x90 (Inherited: 0x30, Single: 0x60)
struct FChaosVDDebugDrawImplicitObjectDataWrapper : FChaosVDDebugDrawShapeBase
{
};

static_assert(sizeof(FChaosVDDebugDrawImplicitObjectDataWrapper) == 0x90, "Size mismatch for FChaosVDDebugDrawImplicitObjectDataWrapper");

// Size: 0x60 (Inherited: 0x10, Single: 0x50)
struct FChaosVDJointStateDataWrapper : FChaosVDWrapperDataBase
{
    uint8_t Pad_10[0x10]; // 0x10 (Size: 0x10, Type: PaddingProperty)
    uint8_t bDisabled : 1; // 0x20:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bBroken : 1; // 0x20:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bBreaking : 1; // 0x20:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bDriveTargetChanged : 1; // 0x20:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnabledDuringResim : 1; // 0x20:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    FVector LinearImpulse; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector AngularImpulse; // 0x40 (Size: 0x18, Type: StructProperty)
    uint8_t ResimType[0x4]; // 0x58 (Size: 0x4, Type: EnumProperty)
    uint8_t SyncState[0x4]; // 0x5c (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FChaosVDJointStateDataWrapper) == 0x60, "Size mismatch for FChaosVDJointStateDataWrapper");
static_assert(offsetof(FChaosVDJointStateDataWrapper, bDisabled) == 0x20, "Offset mismatch for FChaosVDJointStateDataWrapper::bDisabled");
static_assert(offsetof(FChaosVDJointStateDataWrapper, bBroken) == 0x20, "Offset mismatch for FChaosVDJointStateDataWrapper::bBroken");
static_assert(offsetof(FChaosVDJointStateDataWrapper, bBreaking) == 0x20, "Offset mismatch for FChaosVDJointStateDataWrapper::bBreaking");
static_assert(offsetof(FChaosVDJointStateDataWrapper, bDriveTargetChanged) == 0x20, "Offset mismatch for FChaosVDJointStateDataWrapper::bDriveTargetChanged");
static_assert(offsetof(FChaosVDJointStateDataWrapper, bEnabledDuringResim) == 0x20, "Offset mismatch for FChaosVDJointStateDataWrapper::bEnabledDuringResim");
static_assert(offsetof(FChaosVDJointStateDataWrapper, LinearImpulse) == 0x28, "Offset mismatch for FChaosVDJointStateDataWrapper::LinearImpulse");
static_assert(offsetof(FChaosVDJointStateDataWrapper, AngularImpulse) == 0x40, "Offset mismatch for FChaosVDJointStateDataWrapper::AngularImpulse");
static_assert(offsetof(FChaosVDJointStateDataWrapper, ResimType) == 0x58, "Offset mismatch for FChaosVDJointStateDataWrapper::ResimType");
static_assert(offsetof(FChaosVDJointStateDataWrapper, SyncState) == 0x5c, "Offset mismatch for FChaosVDJointStateDataWrapper::SyncState");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FChaosVDGTJointStateDataWrapper : FChaosVDWrapperDataBase
{
    uint8_t bIsBreaking : 1; // 0x10:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsBroken : 1; // 0x10:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bDriveTargetChanged : 1; // 0x10:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsViolating : 1; // 0x10:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FVector Force; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Torque; // 0x30 (Size: 0x18, Type: StructProperty)
    float LinearViolation; // 0x48 (Size: 0x4, Type: FloatProperty)
    float AngularViolation; // 0x4c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FChaosVDGTJointStateDataWrapper) == 0x50, "Size mismatch for FChaosVDGTJointStateDataWrapper");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, bIsBreaking) == 0x10, "Offset mismatch for FChaosVDGTJointStateDataWrapper::bIsBreaking");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, bIsBroken) == 0x10, "Offset mismatch for FChaosVDGTJointStateDataWrapper::bIsBroken");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, bDriveTargetChanged) == 0x10, "Offset mismatch for FChaosVDGTJointStateDataWrapper::bDriveTargetChanged");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, bIsViolating) == 0x10, "Offset mismatch for FChaosVDGTJointStateDataWrapper::bIsViolating");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, Force) == 0x18, "Offset mismatch for FChaosVDGTJointStateDataWrapper::Force");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, Torque) == 0x30, "Offset mismatch for FChaosVDGTJointStateDataWrapper::Torque");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, LinearViolation) == 0x48, "Offset mismatch for FChaosVDGTJointStateDataWrapper::LinearViolation");
static_assert(offsetof(FChaosVDGTJointStateDataWrapper, AngularViolation) == 0x4c, "Offset mismatch for FChaosVDGTJointStateDataWrapper::AngularViolation");

// Size: 0xd8 (Inherited: 0x10, Single: 0xc8)
struct FChaosVDJointSolverSettingsDataWrapper : FChaosVDWrapperDataBase
{
    double SwingTwistAngleTolerance; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double PositionTolerance; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double AngleTolerance; // 0x20 (Size: 0x8, Type: DoubleProperty)
    double MinParentMassRatio; // 0x28 (Size: 0x8, Type: DoubleProperty)
    double MaxInertiaRatio; // 0x30 (Size: 0x8, Type: DoubleProperty)
    double MinSolverStiffness; // 0x38 (Size: 0x8, Type: DoubleProperty)
    double MaxSolverStiffness; // 0x40 (Size: 0x8, Type: DoubleProperty)
    int32_t NumIterationsAtMaxSolverStiffness; // 0x48 (Size: 0x4, Type: IntProperty)
    int32_t NumShockPropagationIterations; // 0x4c (Size: 0x4, Type: IntProperty)
    uint8_t bUseLinearSolver : 1; // 0x50:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bSortEnabled : 1; // 0x50:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bSolvePositionLast : 1; // 0x50:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bUsePositionBasedDrives : 1; // 0x50:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableTwistLimits : 1; // 0x50:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableSwingLimits : 1; // 0x50:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableDrives : 1; // 0x50:6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    double LinearStiffnessOverride; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double TwistStiffnessOverride; // 0x60 (Size: 0x8, Type: DoubleProperty)
    double SwingStiffnessOverride; // 0x68 (Size: 0x8, Type: DoubleProperty)
    double LinearProjectionOverride; // 0x70 (Size: 0x8, Type: DoubleProperty)
    double AngularProjectionOverride; // 0x78 (Size: 0x8, Type: DoubleProperty)
    double ShockPropagationOverride; // 0x80 (Size: 0x8, Type: DoubleProperty)
    double LinearDriveStiffnessOverride; // 0x88 (Size: 0x8, Type: DoubleProperty)
    double LinearDriveDampingOverride; // 0x90 (Size: 0x8, Type: DoubleProperty)
    double AngularDriveStiffnessOverride; // 0x98 (Size: 0x8, Type: DoubleProperty)
    double AngularDriveDampingOverride; // 0xa0 (Size: 0x8, Type: DoubleProperty)
    double SoftLinearStiffnessOverride; // 0xa8 (Size: 0x8, Type: DoubleProperty)
    double SoftLinearDampingOverride; // 0xb0 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistStiffnessOverride; // 0xb8 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistDampingOverride; // 0xc0 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingStiffnessOverride; // 0xc8 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingDampingOverride; // 0xd0 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FChaosVDJointSolverSettingsDataWrapper) == 0xd8, "Size mismatch for FChaosVDJointSolverSettingsDataWrapper");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SwingTwistAngleTolerance) == 0x10, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SwingTwistAngleTolerance");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, PositionTolerance) == 0x18, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::PositionTolerance");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, AngleTolerance) == 0x20, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::AngleTolerance");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, MinParentMassRatio) == 0x28, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::MinParentMassRatio");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, MaxInertiaRatio) == 0x30, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::MaxInertiaRatio");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, MinSolverStiffness) == 0x38, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::MinSolverStiffness");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, MaxSolverStiffness) == 0x40, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::MaxSolverStiffness");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, NumIterationsAtMaxSolverStiffness) == 0x48, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::NumIterationsAtMaxSolverStiffness");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, NumShockPropagationIterations) == 0x4c, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::NumShockPropagationIterations");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bUseLinearSolver) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bUseLinearSolver");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bSortEnabled) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bSortEnabled");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bSolvePositionLast) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bSolvePositionLast");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bUsePositionBasedDrives) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bUsePositionBasedDrives");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bEnableTwistLimits) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bEnableTwistLimits");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bEnableSwingLimits) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bEnableSwingLimits");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, bEnableDrives) == 0x50, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::bEnableDrives");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, LinearStiffnessOverride) == 0x58, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::LinearStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, TwistStiffnessOverride) == 0x60, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::TwistStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SwingStiffnessOverride) == 0x68, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SwingStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, LinearProjectionOverride) == 0x70, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::LinearProjectionOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, AngularProjectionOverride) == 0x78, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::AngularProjectionOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, ShockPropagationOverride) == 0x80, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::ShockPropagationOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, LinearDriveStiffnessOverride) == 0x88, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::LinearDriveStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, LinearDriveDampingOverride) == 0x90, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::LinearDriveDampingOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, AngularDriveStiffnessOverride) == 0x98, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::AngularDriveStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, AngularDriveDampingOverride) == 0xa0, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::AngularDriveDampingOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SoftLinearStiffnessOverride) == 0xa8, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SoftLinearStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SoftLinearDampingOverride) == 0xb0, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SoftLinearDampingOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SoftTwistStiffnessOverride) == 0xb8, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SoftTwistStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SoftTwistDampingOverride) == 0xc0, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SoftTwistDampingOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SoftSwingStiffnessOverride) == 0xc8, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SoftSwingStiffnessOverride");
static_assert(offsetof(FChaosVDJointSolverSettingsDataWrapper, SoftSwingDampingOverride) == 0xd0, "Offset mismatch for FChaosVDJointSolverSettingsDataWrapper::SoftSwingDampingOverride");

// Size: 0x2f0 (Inherited: 0x10, Single: 0x2e0)
struct FChaosVDJointSettingsDataWrapper : FChaosVDWrapperDataBase
{
    FTransform ConnectorTransforms[0x2]; // 0x10 (Size: 0xc0, Type: StructProperty)
    double Stiffness; // 0xd0 (Size: 0x8, Type: DoubleProperty)
    double LinearProjection; // 0xd8 (Size: 0x8, Type: DoubleProperty)
    double AngularProjection; // 0xe0 (Size: 0x8, Type: DoubleProperty)
    double ShockPropagation; // 0xe8 (Size: 0x8, Type: DoubleProperty)
    double TeleportDistance; // 0xf0 (Size: 0x8, Type: DoubleProperty)
    double TeleportAngle; // 0xf8 (Size: 0x8, Type: DoubleProperty)
    double ParentInvMassScale; // 0x100 (Size: 0x8, Type: DoubleProperty)
    uint8_t bCollisionEnabled : 1; // 0x108:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bMassConditioningEnabled : 1; // 0x108:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseLinearSolver : 1; // 0x108:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bSoftLinearLimitsEnabled : 1; // 0x108:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bSoftTwistLimitsEnabled : 1; // 0x108:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bSoftSwingLimitsEnabled : 1; // 0x108:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularSLerpPositionDriveEnabled : 1; // 0x108:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularSLerpVelocityDriveEnabled : 1; // 0x108:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularTwistPositionDriveEnabled : 1; // 0x109:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularTwistVelocityDriveEnabled : 1; // 0x109:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularSwingPositionDriveEnabled : 1; // 0x109:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bAngularSwingVelocityDriveEnabled : 1; // 0x109:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_10a[0x2]; // 0x10a (Size: 0x2, Type: PaddingProperty)
    uint8_t LinearMotionTypes[0xc][0x3]; // 0x10c (Size: 0xc, Type: EnumProperty)
    double LinearLimit; // 0x118 (Size: 0x8, Type: DoubleProperty)
    uint8_t AngularMotionTypes[0xc][0x3]; // 0x120 (Size: 0xc, Type: EnumProperty)
    uint8_t Pad_12c[0x4]; // 0x12c (Size: 0x4, Type: PaddingProperty)
    FVector AngularLimits; // 0x130 (Size: 0x18, Type: StructProperty)
    uint8_t LinearSoftForceMode[0x4]; // 0x148 (Size: 0x4, Type: EnumProperty)
    uint8_t AngularSoftForceMode[0x4]; // 0x14c (Size: 0x4, Type: EnumProperty)
    double SoftLinearStiffness; // 0x150 (Size: 0x8, Type: DoubleProperty)
    double SoftLinearDamping; // 0x158 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistStiffness; // 0x160 (Size: 0x8, Type: DoubleProperty)
    double SoftTwistDamping; // 0x168 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingStiffness; // 0x170 (Size: 0x8, Type: DoubleProperty)
    double SoftSwingDamping; // 0x178 (Size: 0x8, Type: DoubleProperty)
    double LinearRestitution; // 0x180 (Size: 0x8, Type: DoubleProperty)
    double TwistRestitution; // 0x188 (Size: 0x8, Type: DoubleProperty)
    double SwingRestitution; // 0x190 (Size: 0x8, Type: DoubleProperty)
    double LinearContactDistance; // 0x198 (Size: 0x8, Type: DoubleProperty)
    double TwistContactDistance; // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    double SwingContactDistance; // 0x1a8 (Size: 0x8, Type: DoubleProperty)
    FVector LinearDrivePositionTarget; // 0x1b0 (Size: 0x18, Type: StructProperty)
    FVector LinearDriveVelocityTarget; // 0x1c8 (Size: 0x18, Type: StructProperty)
    uint8_t bLinearPositionDriveEnabled0 : 1; // 0x1e0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bLinearPositionDriveEnabled1 : 1; // 0x1e0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bLinearPositionDriveEnabled2 : 1; // 0x1e0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bLinearVelocityDriveEnabled0 : 1; // 0x1e0:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bLinearVelocityDriveEnabled1 : 1; // 0x1e0:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bLinearVelocityDriveEnabled2 : 1; // 0x1e0:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e1[0x3]; // 0x1e1 (Size: 0x3, Type: PaddingProperty)
    uint8_t LinearDriveForceMode[0x4]; // 0x1e4 (Size: 0x4, Type: EnumProperty)
    FVector LinearDriveStiffness; // 0x1e8 (Size: 0x18, Type: StructProperty)
    FVector LinearDriveDamping; // 0x200 (Size: 0x18, Type: StructProperty)
    FVector LinearDriveMaxForce; // 0x218 (Size: 0x18, Type: StructProperty)
    FQuat AngularDrivePositionTarget; // 0x230 (Size: 0x20, Type: StructProperty)
    FVector AngularDriveVelocityTarget; // 0x250 (Size: 0x18, Type: StructProperty)
    uint8_t AngularDriveForceMode[0x4]; // 0x268 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_26c[0x4]; // 0x26c (Size: 0x4, Type: PaddingProperty)
    FVector AngularDriveStiffness; // 0x270 (Size: 0x18, Type: StructProperty)
    FVector AngularDriveDamping; // 0x288 (Size: 0x18, Type: StructProperty)
    FVector AngularDriveMaxTorque; // 0x2a0 (Size: 0x18, Type: StructProperty)
    double LinearBreakForce; // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    double LinearPlasticityLimit; // 0x2c0 (Size: 0x8, Type: DoubleProperty)
    uint8_t LinearPlasticityType[0x4]; // 0x2c8 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_2cc[0x4]; // 0x2cc (Size: 0x4, Type: PaddingProperty)
    double LinearPlasticityInitialDistanceSquared; // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    double AngularBreakTorque; // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    double AngularPlasticityLimit; // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    double ContactTransferScale; // 0x2e8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FChaosVDJointSettingsDataWrapper) == 0x2f0, "Size mismatch for FChaosVDJointSettingsDataWrapper");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, ConnectorTransforms) == 0x10, "Offset mismatch for FChaosVDJointSettingsDataWrapper::ConnectorTransforms");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, Stiffness) == 0xd0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::Stiffness");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearProjection) == 0xd8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearProjection");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularProjection) == 0xe0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularProjection");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, ShockPropagation) == 0xe8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::ShockPropagation");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, TeleportDistance) == 0xf0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::TeleportDistance");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, TeleportAngle) == 0xf8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::TeleportAngle");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, ParentInvMassScale) == 0x100, "Offset mismatch for FChaosVDJointSettingsDataWrapper::ParentInvMassScale");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bCollisionEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bCollisionEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bMassConditioningEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bMassConditioningEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bUseLinearSolver) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bUseLinearSolver");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bSoftLinearLimitsEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bSoftLinearLimitsEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bSoftTwistLimitsEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bSoftTwistLimitsEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bSoftSwingLimitsEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bSoftSwingLimitsEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bAngularSLerpPositionDriveEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bAngularSLerpPositionDriveEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bAngularSLerpVelocityDriveEnabled) == 0x108, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bAngularSLerpVelocityDriveEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bAngularTwistPositionDriveEnabled) == 0x109, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bAngularTwistPositionDriveEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bAngularTwistVelocityDriveEnabled) == 0x109, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bAngularTwistVelocityDriveEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bAngularSwingPositionDriveEnabled) == 0x109, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bAngularSwingPositionDriveEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bAngularSwingVelocityDriveEnabled) == 0x109, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bAngularSwingVelocityDriveEnabled");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearMotionTypes) == 0x10c, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearMotionTypes");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearLimit) == 0x118, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearLimit");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularMotionTypes) == 0x120, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularMotionTypes");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularLimits) == 0x130, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularLimits");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearSoftForceMode) == 0x148, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearSoftForceMode");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularSoftForceMode) == 0x14c, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularSoftForceMode");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SoftLinearStiffness) == 0x150, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SoftLinearStiffness");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SoftLinearDamping) == 0x158, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SoftLinearDamping");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SoftTwistStiffness) == 0x160, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SoftTwistStiffness");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SoftTwistDamping) == 0x168, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SoftTwistDamping");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SoftSwingStiffness) == 0x170, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SoftSwingStiffness");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SoftSwingDamping) == 0x178, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SoftSwingDamping");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearRestitution) == 0x180, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearRestitution");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, TwistRestitution) == 0x188, "Offset mismatch for FChaosVDJointSettingsDataWrapper::TwistRestitution");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SwingRestitution) == 0x190, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SwingRestitution");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearContactDistance) == 0x198, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearContactDistance");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, TwistContactDistance) == 0x1a0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::TwistContactDistance");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, SwingContactDistance) == 0x1a8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::SwingContactDistance");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearDrivePositionTarget) == 0x1b0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearDrivePositionTarget");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearDriveVelocityTarget) == 0x1c8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearDriveVelocityTarget");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bLinearPositionDriveEnabled0) == 0x1e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bLinearPositionDriveEnabled0");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bLinearPositionDriveEnabled1) == 0x1e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bLinearPositionDriveEnabled1");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bLinearPositionDriveEnabled2) == 0x1e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bLinearPositionDriveEnabled2");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bLinearVelocityDriveEnabled0) == 0x1e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bLinearVelocityDriveEnabled0");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bLinearVelocityDriveEnabled1) == 0x1e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bLinearVelocityDriveEnabled1");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, bLinearVelocityDriveEnabled2) == 0x1e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::bLinearVelocityDriveEnabled2");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearDriveForceMode) == 0x1e4, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearDriveForceMode");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearDriveStiffness) == 0x1e8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearDriveStiffness");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearDriveDamping) == 0x200, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearDriveDamping");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearDriveMaxForce) == 0x218, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearDriveMaxForce");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularDrivePositionTarget) == 0x230, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularDrivePositionTarget");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularDriveVelocityTarget) == 0x250, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularDriveVelocityTarget");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularDriveForceMode) == 0x268, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularDriveForceMode");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularDriveStiffness) == 0x270, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularDriveStiffness");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularDriveDamping) == 0x288, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularDriveDamping");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularDriveMaxTorque) == 0x2a0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularDriveMaxTorque");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearBreakForce) == 0x2b8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearBreakForce");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearPlasticityLimit) == 0x2c0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearPlasticityLimit");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearPlasticityType) == 0x2c8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearPlasticityType");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, LinearPlasticityInitialDistanceSquared) == 0x2d0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::LinearPlasticityInitialDistanceSquared");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularBreakTorque) == 0x2d8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularBreakTorque");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, AngularPlasticityLimit) == 0x2e0, "Offset mismatch for FChaosVDJointSettingsDataWrapper::AngularPlasticityLimit");
static_assert(offsetof(FChaosVDJointSettingsDataWrapper, ContactTransferScale) == 0x2e8, "Offset mismatch for FChaosVDJointSettingsDataWrapper::ContactTransferScale");

// Size: 0x3c0 (Inherited: 0x20, Single: 0x3a0)
struct FChaosVDJointConstraint : FChaosVDConstraintDataWrapperBase
{
    uint8_t Pad_10[0x4]; // 0x10 (Size: 0x4, Type: PaddingProperty)
    int32_t ConstraintIndex; // 0x14 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FChaosVDJointStateDataWrapper PhysicsThreadJointState; // 0x20 (Size: 0x60, Type: StructProperty)
    FChaosVDGTJointStateDataWrapper GameThreadJointState; // 0x80 (Size: 0x50, Type: StructProperty)
    FChaosVDJointSettingsDataWrapper JointSettings; // 0xd0 (Size: 0x2f0, Type: StructProperty)
};

static_assert(sizeof(FChaosVDJointConstraint) == 0x3c0, "Size mismatch for FChaosVDJointConstraint");
static_assert(offsetof(FChaosVDJointConstraint, ConstraintIndex) == 0x14, "Offset mismatch for FChaosVDJointConstraint::ConstraintIndex");
static_assert(offsetof(FChaosVDJointConstraint, PhysicsThreadJointState) == 0x20, "Offset mismatch for FChaosVDJointConstraint::PhysicsThreadJointState");
static_assert(offsetof(FChaosVDJointConstraint, GameThreadJointState) == 0x80, "Offset mismatch for FChaosVDJointConstraint::GameThreadJointState");
static_assert(offsetof(FChaosVDJointConstraint, JointSettings) == 0xd0, "Offset mismatch for FChaosVDJointConstraint::JointSettings");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FChaosVDFRigidParticleControlFlags : FChaosVDWrapperDataBase
{
    bool bGravityEnabled; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bCCDEnabled; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bOneWayInteractionEnabled; // 0x12 (Size: 0x1, Type: BoolProperty)
    bool bInertiaConditioningEnabled; // 0x13 (Size: 0x1, Type: BoolProperty)
    int32_t GravityGroupIndex; // 0x14 (Size: 0x4, Type: IntProperty)
    bool bMACDEnabled; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bGyroscopicTorqueEnabled; // 0x19 (Size: 0x1, Type: BoolProperty)
    char PositionSolverIterationCount; // 0x1a (Size: 0x1, Type: ByteProperty)
    char VelocitySolverIterationCount; // 0x1b (Size: 0x1, Type: ByteProperty)
    char ProjectionSolverIterationCount; // 0x1c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDFRigidParticleControlFlags) == 0x20, "Size mismatch for FChaosVDFRigidParticleControlFlags");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, bGravityEnabled) == 0x10, "Offset mismatch for FChaosVDFRigidParticleControlFlags::bGravityEnabled");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, bCCDEnabled) == 0x11, "Offset mismatch for FChaosVDFRigidParticleControlFlags::bCCDEnabled");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, bOneWayInteractionEnabled) == 0x12, "Offset mismatch for FChaosVDFRigidParticleControlFlags::bOneWayInteractionEnabled");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, bInertiaConditioningEnabled) == 0x13, "Offset mismatch for FChaosVDFRigidParticleControlFlags::bInertiaConditioningEnabled");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, GravityGroupIndex) == 0x14, "Offset mismatch for FChaosVDFRigidParticleControlFlags::GravityGroupIndex");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, bMACDEnabled) == 0x18, "Offset mismatch for FChaosVDFRigidParticleControlFlags::bMACDEnabled");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, bGyroscopicTorqueEnabled) == 0x19, "Offset mismatch for FChaosVDFRigidParticleControlFlags::bGyroscopicTorqueEnabled");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, PositionSolverIterationCount) == 0x1a, "Offset mismatch for FChaosVDFRigidParticleControlFlags::PositionSolverIterationCount");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, VelocitySolverIterationCount) == 0x1b, "Offset mismatch for FChaosVDFRigidParticleControlFlags::VelocitySolverIterationCount");
static_assert(offsetof(FChaosVDFRigidParticleControlFlags, ProjectionSolverIterationCount) == 0x1c, "Offset mismatch for FChaosVDFRigidParticleControlFlags::ProjectionSolverIterationCount");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FChaosVDParticlePositionRotation : FChaosVDWrapperDataBase
{
    FVector MX; // 0x10 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FQuat MR; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FChaosVDParticlePositionRotation) == 0x50, "Size mismatch for FChaosVDParticlePositionRotation");
static_assert(offsetof(FChaosVDParticlePositionRotation, MX) == 0x10, "Offset mismatch for FChaosVDParticlePositionRotation::MX");
static_assert(offsetof(FChaosVDParticlePositionRotation, MR) == 0x30, "Offset mismatch for FChaosVDParticlePositionRotation::MR");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FChaosVDParticleVelocities : FChaosVDWrapperDataBase
{
    FVector MV; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MW; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDParticleVelocities) == 0x40, "Size mismatch for FChaosVDParticleVelocities");
static_assert(offsetof(FChaosVDParticleVelocities, MV) == 0x10, "Offset mismatch for FChaosVDParticleVelocities::MV");
static_assert(offsetof(FChaosVDParticleVelocities, MW) == 0x28, "Offset mismatch for FChaosVDParticleVelocities::MW");

// Size: 0x70 (Inherited: 0x10, Single: 0x60)
struct FChaosVDParticleDynamics : FChaosVDWrapperDataBase
{
    FVector MAcceleration; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MAngularAcceleration; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MLinearImpulseVelocity; // 0x40 (Size: 0x18, Type: StructProperty)
    FVector MAngularImpulseVelocity; // 0x58 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDParticleDynamics) == 0x70, "Size mismatch for FChaosVDParticleDynamics");
static_assert(offsetof(FChaosVDParticleDynamics, MAcceleration) == 0x10, "Offset mismatch for FChaosVDParticleDynamics::MAcceleration");
static_assert(offsetof(FChaosVDParticleDynamics, MAngularAcceleration) == 0x28, "Offset mismatch for FChaosVDParticleDynamics::MAngularAcceleration");
static_assert(offsetof(FChaosVDParticleDynamics, MLinearImpulseVelocity) == 0x40, "Offset mismatch for FChaosVDParticleDynamics::MLinearImpulseVelocity");
static_assert(offsetof(FChaosVDParticleDynamics, MAngularImpulseVelocity) == 0x58, "Offset mismatch for FChaosVDParticleDynamics::MAngularImpulseVelocity");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FChaosVDParticleMassProps : FChaosVDWrapperDataBase
{
    FVector MCenterOfMass; // 0x10 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FQuat MRotationOfMass; // 0x30 (Size: 0x20, Type: StructProperty)
    FVector MI; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector MInvI; // 0x68 (Size: 0x18, Type: StructProperty)
    double MM; // 0x80 (Size: 0x8, Type: DoubleProperty)
    double MInvM; // 0x88 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FChaosVDParticleMassProps) == 0x90, "Size mismatch for FChaosVDParticleMassProps");
static_assert(offsetof(FChaosVDParticleMassProps, MCenterOfMass) == 0x10, "Offset mismatch for FChaosVDParticleMassProps::MCenterOfMass");
static_assert(offsetof(FChaosVDParticleMassProps, MRotationOfMass) == 0x30, "Offset mismatch for FChaosVDParticleMassProps::MRotationOfMass");
static_assert(offsetof(FChaosVDParticleMassProps, MI) == 0x50, "Offset mismatch for FChaosVDParticleMassProps::MI");
static_assert(offsetof(FChaosVDParticleMassProps, MInvI) == 0x68, "Offset mismatch for FChaosVDParticleMassProps::MInvI");
static_assert(offsetof(FChaosVDParticleMassProps, MM) == 0x80, "Offset mismatch for FChaosVDParticleMassProps::MM");
static_assert(offsetof(FChaosVDParticleMassProps, MInvM) == 0x88, "Offset mismatch for FChaosVDParticleMassProps::MInvM");

// Size: 0x70 (Inherited: 0x10, Single: 0x60)
struct FChaosVDParticleDynamicMisc : FChaosVDWrapperDataBase
{
    double MLinearEtherDrag; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double MAngularEtherDrag; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double MMaxLinearSpeedSq; // 0x20 (Size: 0x8, Type: DoubleProperty)
    double MMaxAngularSpeedSq; // 0x28 (Size: 0x8, Type: DoubleProperty)
    float MInitialOverlapDepenetrationVelocity; // 0x30 (Size: 0x4, Type: FloatProperty)
    float MSleepThresholdMultiplier; // 0x34 (Size: 0x4, Type: FloatProperty)
    int32_t MCollisionGroup; // 0x38 (Size: 0x4, Type: IntProperty)
    uint8_t MObjectState; // 0x3c (Size: 0x1, Type: EnumProperty)
    uint8_t MSleepType; // 0x3d (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3e[0x2]; // 0x3e (Size: 0x2, Type: PaddingProperty)
    uint32_t MCollisionConstraintFlag; // 0x40 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FChaosVDFRigidParticleControlFlags MControlFlags; // 0x48 (Size: 0x20, Type: StructProperty)
    bool bDisabled; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDParticleDynamicMisc) == 0x70, "Size mismatch for FChaosVDParticleDynamicMisc");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MLinearEtherDrag) == 0x10, "Offset mismatch for FChaosVDParticleDynamicMisc::MLinearEtherDrag");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MAngularEtherDrag) == 0x18, "Offset mismatch for FChaosVDParticleDynamicMisc::MAngularEtherDrag");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MMaxLinearSpeedSq) == 0x20, "Offset mismatch for FChaosVDParticleDynamicMisc::MMaxLinearSpeedSq");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MMaxAngularSpeedSq) == 0x28, "Offset mismatch for FChaosVDParticleDynamicMisc::MMaxAngularSpeedSq");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MInitialOverlapDepenetrationVelocity) == 0x30, "Offset mismatch for FChaosVDParticleDynamicMisc::MInitialOverlapDepenetrationVelocity");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MSleepThresholdMultiplier) == 0x34, "Offset mismatch for FChaosVDParticleDynamicMisc::MSleepThresholdMultiplier");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MCollisionGroup) == 0x38, "Offset mismatch for FChaosVDParticleDynamicMisc::MCollisionGroup");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MObjectState) == 0x3c, "Offset mismatch for FChaosVDParticleDynamicMisc::MObjectState");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MSleepType) == 0x3d, "Offset mismatch for FChaosVDParticleDynamicMisc::MSleepType");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MCollisionConstraintFlag) == 0x40, "Offset mismatch for FChaosVDParticleDynamicMisc::MCollisionConstraintFlag");
static_assert(offsetof(FChaosVDParticleDynamicMisc, MControlFlags) == 0x48, "Offset mismatch for FChaosVDParticleDynamicMisc::MControlFlags");
static_assert(offsetof(FChaosVDParticleDynamicMisc, bDisabled) == 0x68, "Offset mismatch for FChaosVDParticleDynamicMisc::bDisabled");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChaosVDConnectivityEdge
{
    int32_t SiblingParticleID; // 0x0 (Size: 0x4, Type: IntProperty)
    float Strain; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FChaosVDConnectivityEdge) == 0x8, "Size mismatch for FChaosVDConnectivityEdge");
static_assert(offsetof(FChaosVDConnectivityEdge, SiblingParticleID) == 0x0, "Offset mismatch for FChaosVDConnectivityEdge::SiblingParticleID");
static_assert(offsetof(FChaosVDConnectivityEdge, Strain) == 0x4, "Offset mismatch for FChaosVDConnectivityEdge::Strain");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FChaosVDParticleCluster : FChaosVDWrapperDataBase
{
    int32_t ParentParticleID; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t NumChildren; // 0x14 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform ChildToParent; // 0x20 (Size: 0x60, Type: StructProperty)
    int32_t ClusterGroupIndex; // 0x80 (Size: 0x4, Type: IntProperty)
    bool bInternalCluster; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    float CollisionImpulse; // 0x88 (Size: 0x4, Type: FloatProperty)
    float ExternalStrains; // 0x8c (Size: 0x4, Type: FloatProperty)
    float InternalStrains; // 0x90 (Size: 0x4, Type: FloatProperty)
    float Strain; // 0x94 (Size: 0x4, Type: FloatProperty)
    TArray<FChaosVDConnectivityEdge> ConnectivityEdges; // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bIsAnchored; // 0xa8 (Size: 0x1, Type: BoolProperty)
    bool bUnbreakable; // 0xa9 (Size: 0x1, Type: BoolProperty)
    bool bIsChildToParentLocked; // 0xaa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ab[0x5]; // 0xab (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDParticleCluster) == 0xb0, "Size mismatch for FChaosVDParticleCluster");
static_assert(offsetof(FChaosVDParticleCluster, ParentParticleID) == 0x10, "Offset mismatch for FChaosVDParticleCluster::ParentParticleID");
static_assert(offsetof(FChaosVDParticleCluster, NumChildren) == 0x14, "Offset mismatch for FChaosVDParticleCluster::NumChildren");
static_assert(offsetof(FChaosVDParticleCluster, ChildToParent) == 0x20, "Offset mismatch for FChaosVDParticleCluster::ChildToParent");
static_assert(offsetof(FChaosVDParticleCluster, ClusterGroupIndex) == 0x80, "Offset mismatch for FChaosVDParticleCluster::ClusterGroupIndex");
static_assert(offsetof(FChaosVDParticleCluster, bInternalCluster) == 0x84, "Offset mismatch for FChaosVDParticleCluster::bInternalCluster");
static_assert(offsetof(FChaosVDParticleCluster, CollisionImpulse) == 0x88, "Offset mismatch for FChaosVDParticleCluster::CollisionImpulse");
static_assert(offsetof(FChaosVDParticleCluster, ExternalStrains) == 0x8c, "Offset mismatch for FChaosVDParticleCluster::ExternalStrains");
static_assert(offsetof(FChaosVDParticleCluster, InternalStrains) == 0x90, "Offset mismatch for FChaosVDParticleCluster::InternalStrains");
static_assert(offsetof(FChaosVDParticleCluster, Strain) == 0x94, "Offset mismatch for FChaosVDParticleCluster::Strain");
static_assert(offsetof(FChaosVDParticleCluster, ConnectivityEdges) == 0x98, "Offset mismatch for FChaosVDParticleCluster::ConnectivityEdges");
static_assert(offsetof(FChaosVDParticleCluster, bIsAnchored) == 0xa8, "Offset mismatch for FChaosVDParticleCluster::bIsAnchored");
static_assert(offsetof(FChaosVDParticleCluster, bUnbreakable) == 0xa9, "Offset mismatch for FChaosVDParticleCluster::bUnbreakable");
static_assert(offsetof(FChaosVDParticleCluster, bIsChildToParentLocked) == 0xaa, "Offset mismatch for FChaosVDParticleCluster::bIsChildToParentLocked");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FChaosVDKinematicTarget : FChaosVDWrapperDataBase
{
    FQuat Rotation; // 0x10 (Size: 0x20, Type: StructProperty)
    FVector Position; // 0x30 (Size: 0x18, Type: StructProperty)
    uint8_t Mode[0x4]; // 0x48 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDKinematicTarget) == 0x50, "Size mismatch for FChaosVDKinematicTarget");
static_assert(offsetof(FChaosVDKinematicTarget, Rotation) == 0x10, "Offset mismatch for FChaosVDKinematicTarget::Rotation");
static_assert(offsetof(FChaosVDKinematicTarget, Position) == 0x30, "Offset mismatch for FChaosVDKinematicTarget::Position");
static_assert(offsetof(FChaosVDKinematicTarget, Mode) == 0x48, "Offset mismatch for FChaosVDKinematicTarget::Mode");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FChaosVDVSmooth : FChaosVDWrapperDataBase
{
    FVector MV; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector MW; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDVSmooth) == 0x40, "Size mismatch for FChaosVDVSmooth");
static_assert(offsetof(FChaosVDVSmooth, MV) == 0x10, "Offset mismatch for FChaosVDVSmooth::MV");
static_assert(offsetof(FChaosVDVSmooth, MW) == 0x28, "Offset mismatch for FChaosVDVSmooth::MW");

// Size: 0x3b0 (Inherited: 0x10, Single: 0x3a0)
struct FChaosVDParticleDataWrapper : FChaosVDWrapperDataBase
{
    int32_t DirtyFlagsBits; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t ParticleContext[0x4]; // 0x14 (Size: 0x4, Type: EnumProperty)
    uint32_t GeometryHash; // 0x18 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FString DebugName; // 0x20 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    int32_t ParticleIndex; // 0x38 (Size: 0x4, Type: IntProperty)
    int32_t SolverId; // 0x3c (Size: 0x4, Type: IntProperty)
    uint8_t Type; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0xf]; // 0x41 (Size: 0xf, Type: PaddingProperty)
    FChaosVDParticlePositionRotation ParticlePositionRotation; // 0x50 (Size: 0x50, Type: StructProperty)
    FChaosVDParticleVelocities ParticleVelocities; // 0xa0 (Size: 0x40, Type: StructProperty)
    FChaosVDKinematicTarget ParticleKinematicTarget; // 0xe0 (Size: 0x50, Type: StructProperty)
    FChaosVDVSmooth ParticleVWSmooth; // 0x130 (Size: 0x40, Type: StructProperty)
    FChaosVDParticleDynamics ParticleDynamics; // 0x170 (Size: 0x70, Type: StructProperty)
    FChaosVDParticleDynamicMisc ParticleDynamicsMisc; // 0x1e0 (Size: 0x70, Type: StructProperty)
    FChaosVDParticleMassProps ParticleMassProps; // 0x250 (Size: 0x90, Type: StructProperty)
    FChaosVDParticleCluster ParticleCluster; // 0x2e0 (Size: 0xb0, Type: StructProperty)
    TArray<FChaosVDShapeCollisionData> CollisionDataPerShape; // 0x390 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChaosVDParticleDataWrapper) == 0x3b0, "Size mismatch for FChaosVDParticleDataWrapper");
static_assert(offsetof(FChaosVDParticleDataWrapper, DirtyFlagsBits) == 0x10, "Offset mismatch for FChaosVDParticleDataWrapper::DirtyFlagsBits");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleContext) == 0x14, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleContext");
static_assert(offsetof(FChaosVDParticleDataWrapper, GeometryHash) == 0x18, "Offset mismatch for FChaosVDParticleDataWrapper::GeometryHash");
static_assert(offsetof(FChaosVDParticleDataWrapper, DebugName) == 0x20, "Offset mismatch for FChaosVDParticleDataWrapper::DebugName");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleIndex) == 0x38, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleIndex");
static_assert(offsetof(FChaosVDParticleDataWrapper, SolverId) == 0x3c, "Offset mismatch for FChaosVDParticleDataWrapper::SolverId");
static_assert(offsetof(FChaosVDParticleDataWrapper, Type) == 0x40, "Offset mismatch for FChaosVDParticleDataWrapper::Type");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticlePositionRotation) == 0x50, "Offset mismatch for FChaosVDParticleDataWrapper::ParticlePositionRotation");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleVelocities) == 0xa0, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleVelocities");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleKinematicTarget) == 0xe0, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleKinematicTarget");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleVWSmooth) == 0x130, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleVWSmooth");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleDynamics) == 0x170, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleDynamics");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleDynamicsMisc) == 0x1e0, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleDynamicsMisc");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleMassProps) == 0x250, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleMassProps");
static_assert(offsetof(FChaosVDParticleDataWrapper, ParticleCluster) == 0x2e0, "Offset mismatch for FChaosVDParticleDataWrapper::ParticleCluster");
static_assert(offsetof(FChaosVDParticleDataWrapper, CollisionDataPerShape) == 0x390, "Offset mismatch for FChaosVDParticleDataWrapper::CollisionDataPerShape");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FChaosVDCollisionResponseParams : FChaosVDWrapperDataBase
{
};

static_assert(sizeof(FChaosVDCollisionResponseParams) == 0x40, "Size mismatch for FChaosVDCollisionResponseParams");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FChaosVDCollisionObjectQueryParams : FChaosVDWrapperDataBase
{
    char ObjectTypesToQuery; // 0x10 (Size: 0x1, Type: ByteProperty)
    char IgnoreMask; // 0x11 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDCollisionObjectQueryParams) == 0x18, "Size mismatch for FChaosVDCollisionObjectQueryParams");
static_assert(offsetof(FChaosVDCollisionObjectQueryParams, ObjectTypesToQuery) == 0x10, "Offset mismatch for FChaosVDCollisionObjectQueryParams::ObjectTypesToQuery");
static_assert(offsetof(FChaosVDCollisionObjectQueryParams, IgnoreMask) == 0x11, "Offset mismatch for FChaosVDCollisionObjectQueryParams::IgnoreMask");

// Size: 0x60 (Inherited: 0x10, Single: 0x50)
struct FChaosVDCollisionQueryParams : FChaosVDWrapperDataBase
{
    FName TraceTag; // 0x10 (Size: 0x4, Type: NameProperty)
    FName OwnerTag; // 0x14 (Size: 0x4, Type: NameProperty)
    uint8_t bTraceComplex : 1; // 0x18:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bFindInitialOverlaps : 1; // 0x18:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bReturnFaceIndex : 1; // 0x18:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bReturnPhysicalMaterial : 1; // 0x18:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bIgnoreBlocks : 1; // 0x18:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bIgnoreTouches : 1; // 0x18:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bSkipNarrowPhase : 1; // 0x18:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bTraceIntoSubComponents : 1; // 0x18:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bReplaceHitWithSubComponents : 1; // 0x19:0 (Size: 0x1, Type: BoolProperty)
    char IgnoreMask; // 0x1a (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1b[0x25]; // 0x1b (Size: 0x25, Type: PaddingProperty)
    TArray<FName> IgnoredActorsNames; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> IgnoredComponentsNames; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChaosVDCollisionQueryParams) == 0x60, "Size mismatch for FChaosVDCollisionQueryParams");
static_assert(offsetof(FChaosVDCollisionQueryParams, TraceTag) == 0x10, "Offset mismatch for FChaosVDCollisionQueryParams::TraceTag");
static_assert(offsetof(FChaosVDCollisionQueryParams, OwnerTag) == 0x14, "Offset mismatch for FChaosVDCollisionQueryParams::OwnerTag");
static_assert(offsetof(FChaosVDCollisionQueryParams, bTraceComplex) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bTraceComplex");
static_assert(offsetof(FChaosVDCollisionQueryParams, bFindInitialOverlaps) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bFindInitialOverlaps");
static_assert(offsetof(FChaosVDCollisionQueryParams, bReturnFaceIndex) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bReturnFaceIndex");
static_assert(offsetof(FChaosVDCollisionQueryParams, bReturnPhysicalMaterial) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bReturnPhysicalMaterial");
static_assert(offsetof(FChaosVDCollisionQueryParams, bIgnoreBlocks) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bIgnoreBlocks");
static_assert(offsetof(FChaosVDCollisionQueryParams, bIgnoreTouches) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bIgnoreTouches");
static_assert(offsetof(FChaosVDCollisionQueryParams, bSkipNarrowPhase) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bSkipNarrowPhase");
static_assert(offsetof(FChaosVDCollisionQueryParams, bTraceIntoSubComponents) == 0x18, "Offset mismatch for FChaosVDCollisionQueryParams::bTraceIntoSubComponents");
static_assert(offsetof(FChaosVDCollisionQueryParams, bReplaceHitWithSubComponents) == 0x19, "Offset mismatch for FChaosVDCollisionQueryParams::bReplaceHitWithSubComponents");
static_assert(offsetof(FChaosVDCollisionQueryParams, IgnoreMask) == 0x1a, "Offset mismatch for FChaosVDCollisionQueryParams::IgnoreMask");
static_assert(offsetof(FChaosVDCollisionQueryParams, IgnoredActorsNames) == 0x40, "Offset mismatch for FChaosVDCollisionQueryParams::IgnoredActorsNames");
static_assert(offsetof(FChaosVDCollisionQueryParams, IgnoredComponentsNames) == 0x50, "Offset mismatch for FChaosVDCollisionQueryParams::IgnoredComponentsNames");

// Size: 0x58 (Inherited: 0x10, Single: 0x48)
struct FChaosVDQueryFastData : FChaosVDWrapperDataBase
{
    FVector Dir; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector InvDir; // 0x28 (Size: 0x18, Type: StructProperty)
    double CurrentLength; // 0x40 (Size: 0x8, Type: DoubleProperty)
    double InvCurrentLength; // 0x48 (Size: 0x8, Type: DoubleProperty)
    uint8_t bParallel0 : 1; // 0x50:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bParallel1 : 1; // 0x50:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bParallel2 : 1; // 0x50:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDQueryFastData) == 0x58, "Size mismatch for FChaosVDQueryFastData");
static_assert(offsetof(FChaosVDQueryFastData, Dir) == 0x10, "Offset mismatch for FChaosVDQueryFastData::Dir");
static_assert(offsetof(FChaosVDQueryFastData, InvDir) == 0x28, "Offset mismatch for FChaosVDQueryFastData::InvDir");
static_assert(offsetof(FChaosVDQueryFastData, CurrentLength) == 0x40, "Offset mismatch for FChaosVDQueryFastData::CurrentLength");
static_assert(offsetof(FChaosVDQueryFastData, InvCurrentLength) == 0x48, "Offset mismatch for FChaosVDQueryFastData::InvCurrentLength");
static_assert(offsetof(FChaosVDQueryFastData, bParallel0) == 0x50, "Offset mismatch for FChaosVDQueryFastData::bParallel0");
static_assert(offsetof(FChaosVDQueryFastData, bParallel1) == 0x50, "Offset mismatch for FChaosVDQueryFastData::bParallel1");
static_assert(offsetof(FChaosVDQueryFastData, bParallel2) == 0x50, "Offset mismatch for FChaosVDQueryFastData::bParallel2");

// Size: 0x68 (Inherited: 0x10, Single: 0x58)
struct FChaosVDQueryHitData : FChaosVDWrapperDataBase
{
    float Distance; // 0x10 (Size: 0x4, Type: FloatProperty)
    int32_t FaceIdx; // 0x14 (Size: 0x4, Type: IntProperty)
    uint16_t Flags; // 0x18 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    FVector WorldPosition; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WorldNormal; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector FaceNormal; // 0x50 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDQueryHitData) == 0x68, "Size mismatch for FChaosVDQueryHitData");
static_assert(offsetof(FChaosVDQueryHitData, Distance) == 0x10, "Offset mismatch for FChaosVDQueryHitData::Distance");
static_assert(offsetof(FChaosVDQueryHitData, FaceIdx) == 0x14, "Offset mismatch for FChaosVDQueryHitData::FaceIdx");
static_assert(offsetof(FChaosVDQueryHitData, Flags) == 0x18, "Offset mismatch for FChaosVDQueryHitData::Flags");
static_assert(offsetof(FChaosVDQueryHitData, WorldPosition) == 0x20, "Offset mismatch for FChaosVDQueryHitData::WorldPosition");
static_assert(offsetof(FChaosVDQueryHitData, WorldNormal) == 0x38, "Offset mismatch for FChaosVDQueryHitData::WorldNormal");
static_assert(offsetof(FChaosVDQueryHitData, FaceNormal) == 0x50, "Offset mismatch for FChaosVDQueryHitData::FaceNormal");

// Size: 0x150 (Inherited: 0x10, Single: 0x140)
struct FChaosVDQueryVisitStep : FChaosVDWrapperDataBase
{
    uint8_t Pad_10[0x4]; // 0x10 (Size: 0x4, Type: PaddingProperty)
    uint8_t Type[0x4]; // 0x14 (Size: 0x4, Type: EnumProperty)
    uint32_t ShapeIndex; // 0x18 (Size: 0x4, Type: UInt32Property)
    int32_t ParticleIndex; // 0x1c (Size: 0x4, Type: IntProperty)
    FTransform ParticleTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FChaosVDQueryFastData QueryFastData; // 0x80 (Size: 0x58, Type: StructProperty)
    uint8_t HitType[0x4]; // 0xd8 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    FChaosVDQueryHitData HitData; // 0xe0 (Size: 0x68, Type: StructProperty)
    uint8_t RejectReason[0x4]; // 0x148 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDQueryVisitStep) == 0x150, "Size mismatch for FChaosVDQueryVisitStep");
static_assert(offsetof(FChaosVDQueryVisitStep, Type) == 0x14, "Offset mismatch for FChaosVDQueryVisitStep::Type");
static_assert(offsetof(FChaosVDQueryVisitStep, ShapeIndex) == 0x18, "Offset mismatch for FChaosVDQueryVisitStep::ShapeIndex");
static_assert(offsetof(FChaosVDQueryVisitStep, ParticleIndex) == 0x1c, "Offset mismatch for FChaosVDQueryVisitStep::ParticleIndex");
static_assert(offsetof(FChaosVDQueryVisitStep, ParticleTransform) == 0x20, "Offset mismatch for FChaosVDQueryVisitStep::ParticleTransform");
static_assert(offsetof(FChaosVDQueryVisitStep, QueryFastData) == 0x80, "Offset mismatch for FChaosVDQueryVisitStep::QueryFastData");
static_assert(offsetof(FChaosVDQueryVisitStep, HitType) == 0xd8, "Offset mismatch for FChaosVDQueryVisitStep::HitType");
static_assert(offsetof(FChaosVDQueryVisitStep, HitData) == 0xe0, "Offset mismatch for FChaosVDQueryVisitStep::HitData");
static_assert(offsetof(FChaosVDQueryVisitStep, RejectReason) == 0x148, "Offset mismatch for FChaosVDQueryVisitStep::RejectReason");

// Size: 0x170 (Inherited: 0x0, Single: 0x170)
struct FChaosVDQueryDataWrapper
{
    int32_t ID; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ParentQueryID; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t WorldSolverID; // 0x8 (Size: 0x4, Type: IntProperty)
    bool bIsRetryQuery; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x13]; // 0xd (Size: 0x13, Type: PaddingProperty)
    FQuat GeometryOrientation; // 0x20 (Size: 0x20, Type: StructProperty)
    uint8_t Type[0x4]; // 0x40 (Size: 0x4, Type: EnumProperty)
    uint8_t Mode[0x4]; // 0x44 (Size: 0x4, Type: EnumProperty)
    FVector StartLocation; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector EndLocation; // 0x60 (Size: 0x18, Type: StructProperty)
    int32_t CollisionChannel; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    FChaosVDCollisionQueryParams CollisionQueryParams; // 0x80 (Size: 0x60, Type: StructProperty)
    FChaosVDCollisionResponseParams CollisionResponseParams; // 0xe0 (Size: 0x40, Type: StructProperty)
    FChaosVDCollisionObjectQueryParams CollisionObjectQueryParams; // 0x120 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_138[0x10]; // 0x138 (Size: 0x10, Type: PaddingProperty)
    TArray<FChaosVDQueryVisitStep> Hits; // 0x148 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_158[0x18]; // 0x158 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDQueryDataWrapper) == 0x170, "Size mismatch for FChaosVDQueryDataWrapper");
static_assert(offsetof(FChaosVDQueryDataWrapper, ID) == 0x0, "Offset mismatch for FChaosVDQueryDataWrapper::ID");
static_assert(offsetof(FChaosVDQueryDataWrapper, ParentQueryID) == 0x4, "Offset mismatch for FChaosVDQueryDataWrapper::ParentQueryID");
static_assert(offsetof(FChaosVDQueryDataWrapper, WorldSolverID) == 0x8, "Offset mismatch for FChaosVDQueryDataWrapper::WorldSolverID");
static_assert(offsetof(FChaosVDQueryDataWrapper, bIsRetryQuery) == 0xc, "Offset mismatch for FChaosVDQueryDataWrapper::bIsRetryQuery");
static_assert(offsetof(FChaosVDQueryDataWrapper, GeometryOrientation) == 0x20, "Offset mismatch for FChaosVDQueryDataWrapper::GeometryOrientation");
static_assert(offsetof(FChaosVDQueryDataWrapper, Type) == 0x40, "Offset mismatch for FChaosVDQueryDataWrapper::Type");
static_assert(offsetof(FChaosVDQueryDataWrapper, Mode) == 0x44, "Offset mismatch for FChaosVDQueryDataWrapper::Mode");
static_assert(offsetof(FChaosVDQueryDataWrapper, StartLocation) == 0x48, "Offset mismatch for FChaosVDQueryDataWrapper::StartLocation");
static_assert(offsetof(FChaosVDQueryDataWrapper, EndLocation) == 0x60, "Offset mismatch for FChaosVDQueryDataWrapper::EndLocation");
static_assert(offsetof(FChaosVDQueryDataWrapper, CollisionChannel) == 0x78, "Offset mismatch for FChaosVDQueryDataWrapper::CollisionChannel");
static_assert(offsetof(FChaosVDQueryDataWrapper, CollisionQueryParams) == 0x80, "Offset mismatch for FChaosVDQueryDataWrapper::CollisionQueryParams");
static_assert(offsetof(FChaosVDQueryDataWrapper, CollisionResponseParams) == 0xe0, "Offset mismatch for FChaosVDQueryDataWrapper::CollisionResponseParams");
static_assert(offsetof(FChaosVDQueryDataWrapper, CollisionObjectQueryParams) == 0x120, "Offset mismatch for FChaosVDQueryDataWrapper::CollisionObjectQueryParams");
static_assert(offsetof(FChaosVDQueryDataWrapper, Hits) == 0x148, "Offset mismatch for FChaosVDQueryDataWrapper::Hits");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FChaosVDSceneQueriesDataContainer
{
};

static_assert(sizeof(FChaosVDSceneQueriesDataContainer) == 0xa0, "Size mismatch for FChaosVDSceneQueriesDataContainer");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FChaosVDTraceDetails
{
    FGuid TraceGuid; // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid SessionGuid; // 0x10 (Size: 0x10, Type: StructProperty)
    FString TraceTarget; // 0x20 (Size: 0x10, Type: StrProperty)
    bool bIsConnected; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Mode; // 0x31 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDTraceDetails) == 0x38, "Size mismatch for FChaosVDTraceDetails");
static_assert(offsetof(FChaosVDTraceDetails, TraceGuid) == 0x0, "Offset mismatch for FChaosVDTraceDetails::TraceGuid");
static_assert(offsetof(FChaosVDTraceDetails, SessionGuid) == 0x10, "Offset mismatch for FChaosVDTraceDetails::SessionGuid");
static_assert(offsetof(FChaosVDTraceDetails, TraceTarget) == 0x20, "Offset mismatch for FChaosVDTraceDetails::TraceTarget");
static_assert(offsetof(FChaosVDTraceDetails, bIsConnected) == 0x30, "Offset mismatch for FChaosVDTraceDetails::bIsConnected");
static_assert(offsetof(FChaosVDTraceDetails, Mode) == 0x31, "Offset mismatch for FChaosVDTraceDetails::Mode");

