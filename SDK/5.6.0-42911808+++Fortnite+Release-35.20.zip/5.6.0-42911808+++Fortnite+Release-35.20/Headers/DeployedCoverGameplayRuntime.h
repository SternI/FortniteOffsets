/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeployedCoverGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "ItemizedPropSpawnerParentRuntime.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDeployedCoverFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool CheckIfOverlapDenylistActor(UClass*& const DeployedCoverClass, const FItemizedPropSpawnerWeaponData WeaponData, const FVector TargetLocation); // 0x112a185c (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void CheckSpawnValidity(const FItemizedPropSpawnerWeaponData WeaponData, const FDeployedCoverSpawnerData CoverSpawnData, const FVector TargetLocation, double& const YawRotation, bool& bOutCanSpawn, FVector& OutSpawnLocation, FRotator& OutSpawnRotation, TArray<FHitResult>& OutHits, TArray<FDeployedCoverSpawnInfo>& OutSpawnInfo, bool& const bDebug, float& const DebugDrawTime); // 0x112a1c78 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void CustomCapsuleTraceByChannel(AActor*& const Instigator, FVector& const Start, FVector& const End, float& Radius, float& HalfHeight, const FQuat Rotation, TEnumAsByte<ETraceTypeQuery>& TraceChannel, TArray<FHitResult>& OutHits, FLinearColor& TraceColor, FLinearColor& TraceHitColor, bool& const bDrawDebug, float& const DrawTime); // 0x112a2340 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void CustomLineTraceByChannel(AActor*& const Instigator, FVector& const Start, FVector& const End, TEnumAsByte<ETraceTypeQuery>& TraceChannel, FLinearColor& TraceColor, FLinearColor& TraceHitColor, TArray<FHitResult>& OutHits, bool& const bDrawDebug, float& const DrawTime); // 0x112a2ae0 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UDeployedCoverFunctionLibrary) == 0x28, "Size mismatch for UDeployedCoverFunctionLibrary");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDeployedCoverSpawnerData
{
    bool bLineTraceForSpawnRot; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAdjustAttachBase; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bDontSpawnOnPlayers; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bDontSpawnOnPhysicsSim; // 0x3 (Size: 0x1, Type: BoolProperty)
    float TraceCapsuleRadius; // 0x4 (Size: 0x4, Type: FloatProperty)
    float TraceCapsuleHalfHeightCenter; // 0x8 (Size: 0x4, Type: FloatProperty)
    float TraceCapsuleHalfHeightSide; // 0xc (Size: 0x4, Type: FloatProperty)
    float BuildingPropMaxHealth; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    double MinDotWithUp; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ZOffsetTolerance; // 0x20 (Size: 0x8, Type: DoubleProperty)
    FName VolumeBlockTag; // 0x28 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel; // 0x2c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    TArray<FNativeItemizedPropSpawner_PropSpawnData> SpawnData; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ClassesToBlockSpawn; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDeployedCoverSpawnerData) == 0x50, "Size mismatch for FDeployedCoverSpawnerData");
static_assert(offsetof(FDeployedCoverSpawnerData, bLineTraceForSpawnRot) == 0x0, "Offset mismatch for FDeployedCoverSpawnerData::bLineTraceForSpawnRot");
static_assert(offsetof(FDeployedCoverSpawnerData, bAdjustAttachBase) == 0x1, "Offset mismatch for FDeployedCoverSpawnerData::bAdjustAttachBase");
static_assert(offsetof(FDeployedCoverSpawnerData, bDontSpawnOnPlayers) == 0x2, "Offset mismatch for FDeployedCoverSpawnerData::bDontSpawnOnPlayers");
static_assert(offsetof(FDeployedCoverSpawnerData, bDontSpawnOnPhysicsSim) == 0x3, "Offset mismatch for FDeployedCoverSpawnerData::bDontSpawnOnPhysicsSim");
static_assert(offsetof(FDeployedCoverSpawnerData, TraceCapsuleRadius) == 0x4, "Offset mismatch for FDeployedCoverSpawnerData::TraceCapsuleRadius");
static_assert(offsetof(FDeployedCoverSpawnerData, TraceCapsuleHalfHeightCenter) == 0x8, "Offset mismatch for FDeployedCoverSpawnerData::TraceCapsuleHalfHeightCenter");
static_assert(offsetof(FDeployedCoverSpawnerData, TraceCapsuleHalfHeightSide) == 0xc, "Offset mismatch for FDeployedCoverSpawnerData::TraceCapsuleHalfHeightSide");
static_assert(offsetof(FDeployedCoverSpawnerData, BuildingPropMaxHealth) == 0x10, "Offset mismatch for FDeployedCoverSpawnerData::BuildingPropMaxHealth");
static_assert(offsetof(FDeployedCoverSpawnerData, MinDotWithUp) == 0x18, "Offset mismatch for FDeployedCoverSpawnerData::MinDotWithUp");
static_assert(offsetof(FDeployedCoverSpawnerData, ZOffsetTolerance) == 0x20, "Offset mismatch for FDeployedCoverSpawnerData::ZOffsetTolerance");
static_assert(offsetof(FDeployedCoverSpawnerData, VolumeBlockTag) == 0x28, "Offset mismatch for FDeployedCoverSpawnerData::VolumeBlockTag");
static_assert(offsetof(FDeployedCoverSpawnerData, TraceChannel) == 0x2c, "Offset mismatch for FDeployedCoverSpawnerData::TraceChannel");
static_assert(offsetof(FDeployedCoverSpawnerData, SpawnData) == 0x30, "Offset mismatch for FDeployedCoverSpawnerData::SpawnData");
static_assert(offsetof(FDeployedCoverSpawnerData, ClassesToBlockSpawn) == 0x40, "Offset mismatch for FDeployedCoverSpawnerData::ClassesToBlockSpawn");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDeployedCoverSpawnInfo
{
    bool bIsValid; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<AActor*> OverlappingActors; // 0x8 (Size: 0x10, Type: ArrayProperty)
    AActor* BaseActor; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDeployedCoverSpawnInfo) == 0x20, "Size mismatch for FDeployedCoverSpawnInfo");
static_assert(offsetof(FDeployedCoverSpawnInfo, bIsValid) == 0x0, "Offset mismatch for FDeployedCoverSpawnInfo::bIsValid");
static_assert(offsetof(FDeployedCoverSpawnInfo, OverlappingActors) == 0x8, "Offset mismatch for FDeployedCoverSpawnInfo::OverlappingActors");
static_assert(offsetof(FDeployedCoverSpawnInfo, BaseActor) == 0x18, "Offset mismatch for FDeployedCoverSpawnInfo::BaseActor");

