/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricEngineSequencer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "MovieSceneTracks.h"
#include "MovieScene.h"
#include "CoreUObject.h"

// Size: 0x750 (Inherited: 0x830, Single: 0xffffff20)
class UFabricAudioSyncSection : public UMovieSceneAudioSection
{
public:
    FMovieSceneFloatChannel SyncSoundVolume; // 0x640 (Size: 0x110, Type: StructProperty)
};

static_assert(sizeof(UFabricAudioSyncSection) == 0x750, "Size mismatch for UFabricAudioSyncSection");
static_assert(offsetof(UFabricAudioSyncSection, SyncSoundVolume) == 0x640, "Offset mismatch for UFabricAudioSyncSection::SyncSoundVolume");

// Size: 0xc0 (Inherited: 0x78, Single: 0x48)
class UFabricAudioSyncTrackInstance : public UMovieSceneTrackInstance
{
public:
};

static_assert(sizeof(UFabricAudioSyncTrackInstance) == 0xc0, "Size mismatch for UFabricAudioSyncTrackInstance");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UMusicClockMovieSceneClockSource : public UObject
{
public:

public:
    FFrameTime OnRequestCurrentTime(const FQualifiedFrameTime InCurrentTime, float& InPlayRate); // 0x11229ff8 (Index: 0x0, Flags: Native|Public|HasOutParms)
    void OnStartPlaying(const FQualifiedFrameTime InStartTime); // 0x1122a168 (Index: 0x1, Flags: Native|Public|HasOutParms)
};

static_assert(sizeof(UMusicClockMovieSceneClockSource) == 0x50, "Size mismatch for UMusicClockMovieSceneClockSource");

// Size: 0x120 (Inherited: 0x428, Single: 0xfffffcf8)
class UFabricAudioSyncTrack : public UMovieSceneAudioTrack
{
public:
};

static_assert(sizeof(UFabricAudioSyncTrack) == 0x120, "Size mismatch for UFabricAudioSyncTrack");

