/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticItemFlowgraphRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x80 (Inherited: 0xd8, Single: 0xffffffa8)
class UCosmeticItemStep_GliderLoadAssets : public UFortCosmeticStep
{
public:
};

static_assert(sizeof(UCosmeticItemStep_GliderLoadAssets) == 0x80, "Size mismatch for UCosmeticItemStep_GliderLoadAssets");

// Size: 0x80 (Inherited: 0xd8, Single: 0xffffffa8)
class UCosmeticItemStep_GliderPostLoad : public UFortCosmeticStep
{
public:
};

static_assert(sizeof(UCosmeticItemStep_GliderPostLoad) == 0x80, "Size mismatch for UCosmeticItemStep_GliderPostLoad");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGliderFlowCommonData
{
};

static_assert(sizeof(FGliderFlowCommonData) == 0x10, "Size mismatch for FGliderFlowCommonData");

