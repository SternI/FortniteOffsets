/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayMessages
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x98 (Inherited: 0x58, Single: 0x40)
class UAsyncAction_RegisterGameplayMessageReceiver : public UBlueprintAsyncActionBase
{
public:
    uint8_t OnMessageReceived[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t HandleSavedState[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t HandleStateCleared[0x10]; // 0x50 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_60[0x38]; // 0x60 (Size: 0x38, Type: PaddingProperty)

public:
    bool GetPayload(int32_t OutPayload); // 0xae6c824 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    static UAsyncAction_RegisterGameplayMessageReceiver* RegisterGameplayMessageReceiver(UObject*& WorldContextObject, FEventMessageTag& Channel, UScriptStruct*& PayloadType, EGameplayMessageMatchType& MatchType, AActor*& ActorContext); // 0xae6cee0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    void Unregister(); // 0x472ef98 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAsyncAction_RegisterGameplayMessageReceiver) == 0x98, "Size mismatch for UAsyncAction_RegisterGameplayMessageReceiver");
static_assert(offsetof(UAsyncAction_RegisterGameplayMessageReceiver, OnMessageReceived) == 0x30, "Offset mismatch for UAsyncAction_RegisterGameplayMessageReceiver::OnMessageReceived");
static_assert(offsetof(UAsyncAction_RegisterGameplayMessageReceiver, HandleSavedState) == 0x40, "Offset mismatch for UAsyncAction_RegisterGameplayMessageReceiver::HandleSavedState");
static_assert(offsetof(UAsyncAction_RegisterGameplayMessageReceiver, HandleStateCleared) == 0x50, "Offset mismatch for UAsyncAction_RegisterGameplayMessageReceiver::HandleStateCleared");

// Size: 0x2a8 (Inherited: 0x2d0, Single: 0xffffffd8)
class AGameplayMessageReplicator : public AActor
{
public:

private:
    virtual void Multicast_ServerMessageTriggered(FEventMessageTag& Channel, FReplicatedMessage& const MessageData); // 0xae6cd68 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
};

static_assert(sizeof(AGameplayMessageReplicator) == 0x2a8, "Size mismatch for AGameplayMessageReplicator");

// Size: 0xd8 (Inherited: 0x88, Single: 0x50)
class UGameplayMessageRouter : public UGameInstanceSubsystem
{
public:
    uint8_t Pad_30[0xa0]; // 0x30 (Size: 0xa0, Type: PaddingProperty)
    AGameplayMessageReplicator* MessageReplicator; // 0xd0 (Size: 0x8, Type: ObjectProperty)

public:
    void ClearSavedMessage(FEventMessageTag& Channel); // 0xae6c698 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool HasValidSavedMessage(FEventMessageTag& Channel) const; // 0xae6ca20 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void K2_BroadcastMessage(FEventMessageTag& Channel, const int32_t Message, bool& bSaveToChannel, AActor*& ActorContext); // 0xae6caf0 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayMessageRouter) == 0xd8, "Size mismatch for UGameplayMessageRouter");
static_assert(offsetof(UGameplayMessageRouter, MessageReplicator) == 0xd0, "Offset mismatch for UGameplayMessageRouter::MessageReplicator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintEventMessageTagLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FEventMessageTag GetEventMessageTagFromGameplayTag(FGameplayTag& InTag); // 0xae6c758 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UBlueprintEventMessageTagLibrary) == 0x28, "Size mismatch for UBlueprintEventMessageTagLibrary");

// Size: 0x4 (Inherited: 0x4, Single: 0x0)
struct FEventMessageTag : FGameplayTag
{
};

static_assert(sizeof(FEventMessageTag) == 0x4, "Size mismatch for FEventMessageTag");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FReplicatedMessageData
{
    UScriptStruct* StructType; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x10]; // 0x8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FReplicatedMessageData) == 0x18, "Size mismatch for FReplicatedMessageData");
static_assert(offsetof(FReplicatedMessageData, StructType) == 0x0, "Offset mismatch for FReplicatedMessageData::StructType");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FReplicatedMessage
{
};

static_assert(sizeof(FReplicatedMessage) == 0x10, "Size mismatch for FReplicatedMessage");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayMessageReceiverHandle
{
    TWeakObjectPtr<UGameplayMessageRouter*> Subsystem; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FEventMessageTag Channel; // 0x8 (Size: 0x4, Type: StructProperty)
    int32_t ID; // 0xc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayMessageReceiverHandle) == 0x18, "Size mismatch for FGameplayMessageReceiverHandle");
static_assert(offsetof(FGameplayMessageReceiverHandle, Subsystem) == 0x0, "Offset mismatch for FGameplayMessageReceiverHandle::Subsystem");
static_assert(offsetof(FGameplayMessageReceiverHandle, Channel) == 0x8, "Offset mismatch for FGameplayMessageReceiverHandle::Channel");
static_assert(offsetof(FGameplayMessageReceiverHandle, ID) == 0xc, "Offset mismatch for FGameplayMessageReceiverHandle::ID");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FGameplayMessageReceiverData
{
};

static_assert(sizeof(FGameplayMessageReceiverData) == 0x80, "Size mismatch for FGameplayMessageReceiverData");

