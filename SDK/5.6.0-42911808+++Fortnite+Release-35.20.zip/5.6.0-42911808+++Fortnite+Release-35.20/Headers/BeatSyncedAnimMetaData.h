/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeatSyncedAnimMetaData
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UBeatSyncedAnimMetaData : public UAnimMetaData
{
public:
    bool bAllowBeatsyncing; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsForEmote; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bOverrideGroupEmoteBeatsyncingBehavior; // 0x2a (Size: 0x1, Type: BoolProperty)
    bool bAllowGroupEmoteLeaderToBeatSync; // 0x2b (Size: 0x1, Type: BoolProperty)
    bool bAllowGroupEmoteFollowerToBeatSync; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UBeatSyncedAnimMetaData) == 0x30, "Size mismatch for UBeatSyncedAnimMetaData");
static_assert(offsetof(UBeatSyncedAnimMetaData, bAllowBeatsyncing) == 0x28, "Offset mismatch for UBeatSyncedAnimMetaData::bAllowBeatsyncing");
static_assert(offsetof(UBeatSyncedAnimMetaData, bIsForEmote) == 0x29, "Offset mismatch for UBeatSyncedAnimMetaData::bIsForEmote");
static_assert(offsetof(UBeatSyncedAnimMetaData, bOverrideGroupEmoteBeatsyncingBehavior) == 0x2a, "Offset mismatch for UBeatSyncedAnimMetaData::bOverrideGroupEmoteBeatsyncingBehavior");
static_assert(offsetof(UBeatSyncedAnimMetaData, bAllowGroupEmoteLeaderToBeatSync) == 0x2b, "Offset mismatch for UBeatSyncedAnimMetaData::bAllowGroupEmoteLeaderToBeatSync");
static_assert(offsetof(UBeatSyncedAnimMetaData, bAllowGroupEmoteFollowerToBeatSync) == 0x2c, "Offset mismatch for UBeatSyncedAnimMetaData::bAllowGroupEmoteFollowerToBeatSync");

// Size: 0x50 (Inherited: 0x80, Single: 0xffffffd0)
class UPreciseBeatSyncedAnimMetaData : public UBeatSyncedAnimMetaData
{
public:
    bool bShouldHalfOrDoublePlayRate; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bOverrideGlobalHalfOrDoublePlayRateLimits; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float MaxPlayRateBeforeHalf; // 0x34 (Size: 0x4, Type: FloatProperty)
    float MinPlayRateBeforeDouble; // 0x38 (Size: 0x4, Type: FloatProperty)
    float FirstBeatAtFrame; // 0x3c (Size: 0x4, Type: FloatProperty)
    float BeatB; // 0x40 (Size: 0x4, Type: FloatProperty)
    float BPM; // 0x44 (Size: 0x4, Type: FloatProperty)
    FName FirstBeatSyncingSection; // 0x48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UPreciseBeatSyncedAnimMetaData) == 0x50, "Size mismatch for UPreciseBeatSyncedAnimMetaData");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, bShouldHalfOrDoublePlayRate) == 0x30, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::bShouldHalfOrDoublePlayRate");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, bOverrideGlobalHalfOrDoublePlayRateLimits) == 0x31, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::bOverrideGlobalHalfOrDoublePlayRateLimits");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, MaxPlayRateBeforeHalf) == 0x34, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::MaxPlayRateBeforeHalf");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, MinPlayRateBeforeDouble) == 0x38, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::MinPlayRateBeforeDouble");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, FirstBeatAtFrame) == 0x3c, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::FirstBeatAtFrame");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, BeatB) == 0x40, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::BeatB");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, BPM) == 0x44, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::BPM");
static_assert(offsetof(UPreciseBeatSyncedAnimMetaData, FirstBeatSyncingSection) == 0x48, "Offset mismatch for UPreciseBeatSyncedAnimMetaData::FirstBeatSyncingSection");

// Size: 0x38 (Inherited: 0x80, Single: 0xffffffb8)
class UTimeSyncedBeatSyncedAnimMetaData : public UBeatSyncedAnimMetaData
{
public:
    float AnimTimeZeroOffsetSeconds; // 0x30 (Size: 0x4, Type: FloatProperty)
    float PlaybackScale; // 0x34 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UTimeSyncedBeatSyncedAnimMetaData) == 0x38, "Size mismatch for UTimeSyncedBeatSyncedAnimMetaData");
static_assert(offsetof(UTimeSyncedBeatSyncedAnimMetaData, AnimTimeZeroOffsetSeconds) == 0x30, "Offset mismatch for UTimeSyncedBeatSyncedAnimMetaData::AnimTimeZeroOffsetSeconds");
static_assert(offsetof(UTimeSyncedBeatSyncedAnimMetaData, PlaybackScale) == 0x34, "Offset mismatch for UTimeSyncedBeatSyncedAnimMetaData::PlaybackScale");

